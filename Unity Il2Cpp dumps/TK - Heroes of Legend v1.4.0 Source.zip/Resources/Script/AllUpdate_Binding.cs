using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class AllUpdate_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BB7024 (12283940), len: 8  VirtAddr: 0x00BB7024 RVA: 0x00BB7024 token: 100663728 methodIndex: 29773 delegateWrapperIndex: 0 methodInvoker: 0
        public AllUpdate_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BB7024: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7028: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB702C (12283948), len: 1196  VirtAddr: 0x00BB702C RVA: 0x00BB702C token: 100663729 methodIndex: 29774 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_12;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_14;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_15;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_16;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_17;
            // 0x00BB702C: STP x28, x27, [sp, #-0x60]! | stack[1152921510039434736] = ???;  stack[1152921510039434744] = ???;  //  dest_result_addr=1152921510039434736 |  dest_result_addr=1152921510039434744
            // 0x00BB7030: STP x26, x25, [sp, #0x10]  | stack[1152921510039434752] = ???;  stack[1152921510039434760] = ???;  //  dest_result_addr=1152921510039434752 |  dest_result_addr=1152921510039434760
            // 0x00BB7034: STP x24, x23, [sp, #0x20]  | stack[1152921510039434768] = ???;  stack[1152921510039434776] = ???;  //  dest_result_addr=1152921510039434768 |  dest_result_addr=1152921510039434776
            // 0x00BB7038: STP x22, x21, [sp, #0x30]  | stack[1152921510039434784] = ???;  stack[1152921510039434792] = ???;  //  dest_result_addr=1152921510039434784 |  dest_result_addr=1152921510039434792
            // 0x00BB703C: STP x20, x19, [sp, #0x40]  | stack[1152921510039434800] = ???;  stack[1152921510039434808] = ???;  //  dest_result_addr=1152921510039434800 |  dest_result_addr=1152921510039434808
            // 0x00BB7040: STP x29, x30, [sp, #0x50]  | stack[1152921510039434816] = ???;  stack[1152921510039434824] = ???;  //  dest_result_addr=1152921510039434816 |  dest_result_addr=1152921510039434824
            // 0x00BB7044: ADD x29, sp, #0x50         | X29 = (1152921510039434736 + 80) = 1152921510039434816 (0x1000000143CEB640);
            // 0x00BB7048: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB704C: LDRB w8, [x20, #0xb41]     | W8 = (bool)static_value_03733B41;       
            // 0x00BB7050: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB7054: TBNZ w8, #0, #0xbb7070     | if (static_value_03733B41 == true) goto label_0;
            // 0x00BB7058: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB705C: LDR x8, [x8, #0x950]       | X8 = 0x2B8AC0C;                         
            // 0x00BB7060: LDR w0, [x8]               | W0 = 0x1C1;                             
            // 0x00BB7064: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C1, ????);      
            // 0x00BB7068: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB706C: STRB w8, [x20, #0xb41]     | static_value_03733B41 = true;            //  dest_result_addr=57883457
            label_0:
            // 0x00BB7070: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x00BB7074: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x00BB7078: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00BB707C: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x00BB7080: LDR x8, [x8, #0x3d0]       | X8 = 1152921504922128384;               
            // 0x00BB7084: LDR x20, [x8]              | X20 = typeof(AllUpdate);                
            // 0x00BB7088: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB708C: TBZ w8, #0, #0xbb709c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BB7090: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB7094: CBNZ w8, #0xbb709c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BB7098: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BB709C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB70A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB70A4: MOV x1, x20                | X1 = 1152921504922128384 (0x1000000012CAD000);//ML01
            // 0x00BB70A8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB70AC: ADRP x24, #0x35ef000       | X24 = 56553472 (0x35EF000);             
            // 0x00BB70B0: LDR x24, [x24, #0xff0]     | X24 = 1152921504987155056;              
            // 0x00BB70B4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BB70B8: LDR x21, [x24]             | X21 = typeof(System.Type[]);            
            // 0x00BB70BC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB70C0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB70C4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BB70C8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB70CC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB70D0: ADRP x27, #0x3680000       | X27 = 57147392 (0x3680000);             
            // 0x00BB70D4: LDR x27, [x27, #0x8d0]     | X27 = 1152921504921915392;              
            // 0x00BB70D8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB70DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB70E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB70E4: LDR x1, [x27]              | X1 = typeof(IZUpdate);                  
            // 0x00BB70E8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB70EC: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x00BB70F0: CBNZ x21, #0xbb70f8        | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x00BB70F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x00BB70F8: CBZ x22, #0xbb711c         | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x00BB70FC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB7100: MOV x0, x22                | X0 = val_2;//m1                         
            // 0x00BB7104: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB7108: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00BB710C: CBNZ x0, #0xbb711c         | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x00BB7110: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00BB7114: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7118: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_5:
            // 0x00BB711C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB7120: CBNZ w8, #0xbb7130         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x00BB7124: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00BB7128: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB712C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x00BB7130: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;
            // 0x00BB7134: CBNZ x20, #0xbb713c        | if (val_1 != null) goto label_7;        
            if(val_1 != null)
            {
                goto label_7;
            }
            // 0x00BB7138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x00BB713C: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
            // 0x00BB7140: LDR x8, [x8, #0x948]       | X8 = (string**)(1152921510039401136)("AddUpdate");
            // 0x00BB7144: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7148: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB714C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB7150: LDR x1, [x8]               | X1 = "AddUpdate";                       
            // 0x00BB7154: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB7158: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB715C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB7160: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "AddUpdate", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_3 = val_1.GetMethod(name:  "AddUpdate", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB7164: ADRP x25, #0x3679000       | X25 = 57118720 (0x3679000);             
            // 0x00BB7168: LDR x25, [x25, #0x2a8]     | X25 = 1152921504782618624;              
            // 0x00BB716C: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB7170: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB7174: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7178: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache0;
            val_12 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache0;
            // 0x00BB717C: CBNZ x22, #0xbb71c8        | if (ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache0 != null) goto label_8;
            if(val_12 != null)
            {
                goto label_8;
            }
            // 0x00BB7180: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x00BB7184: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB7188: LDR x8, [x8, #0x978]       | X8 = 1152921510039405328;               
            // 0x00BB718C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB7190: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::AddUpdate_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB7194: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_4 = null;
            // 0x00BB7198: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB719C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB71A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB71A4: MOV x2, x22                | X2 = 1152921510039405328 (0x1000000143CE4310);//ML01
            // 0x00BB71A8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_13 = val_4;
            // 0x00BB71AC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::AddUpdate_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::AddUpdate_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB71B0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB71B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB71B8: STR x23, [x8]              | ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782622720
            ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache0 = val_13;
            // 0x00BB71BC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB71C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB71C4: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_12 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache0;
            label_8:
            // 0x00BB71C8: CBNZ x19, #0xbb71d0        | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x00BB71CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::AddUpdate_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_9:
            // 0x00BB71D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB71D4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB71D8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB71DC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB71E0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_3, func:  val_12);
            X1.RegisterCLRMethodRedirection(mi:  val_3, func:  val_12);
            // 0x00BB71E4: LDR x21, [x24]             | X21 = typeof(System.Type[]);            
            // 0x00BB71E8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB71EC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB71F0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BB71F4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB71F8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB71FC: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BB7200: LDR x22, [x27]             | X22 = typeof(IZUpdate);                 
            // 0x00BB7204: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB7208: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB720C: TBZ w9, #0, #0xbb7220      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00BB7210: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB7214: CBNZ w9, #0xbb7220         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00BB7218: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB721C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_11:
            // 0x00BB7220: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB7224: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB7228: MOV x1, x22                | X1 = 1152921504921915392 (0x1000000012C79000);//ML01
            // 0x00BB722C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB7230: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB7234: CBNZ x21, #0xbb723c        | if ( != null) goto label_12;            
            if(null != null)
            {
                goto label_12;
            }
            // 0x00BB7238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x00BB723C: CBZ x22, #0xbb7260         | if (val_5 == null) goto label_14;       
            if(val_5 == null)
            {
                goto label_14;
            }
            // 0x00BB7240: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB7244: MOV x0, x22                | X0 = val_5;//m1                         
            // 0x00BB7248: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB724C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
            // 0x00BB7250: CBNZ x0, #0xbb7260         | if (val_5 != null) goto label_14;       
            if(val_5 != null)
            {
                goto label_14;
            }
            // 0x00BB7254: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
            // 0x00BB7258: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB725C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_14:
            // 0x00BB7260: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB7264: CBNZ w8, #0xbb7274         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_15;
            // 0x00BB7268: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x00BB726C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7270: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_15:
            // 0x00BB7274: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_5;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_5;
            // 0x00BB7278: CBNZ x20, #0xbb7280        | if (val_1 != null) goto label_16;       
            if(val_1 != null)
            {
                goto label_16;
            }
            // 0x00BB727C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_16:
            // 0x00BB7280: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BB7284: LDR x8, [x8, #0x280]       | X8 = (string**)(1152921510039410448)("RemoveUpdate");
            // 0x00BB7288: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB728C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB7290: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB7294: LDR x1, [x8]               | X1 = "RemoveUpdate";                    
            // 0x00BB7298: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB729C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB72A0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB72A4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "RemoveUpdate", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_6 = val_1.GetMethod(name:  "RemoveUpdate", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB72A8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB72AC: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x00BB72B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB72B4: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache1;
            val_14 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache1;
            // 0x00BB72B8: CBNZ x22, #0xbb7304        | if (ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache1 != null) goto label_17;
            if(val_14 != null)
            {
                goto label_17;
            }
            // 0x00BB72BC: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00BB72C0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB72C4: LDR x8, [x8, #0x360]       | X8 = 1152921510039414640;               
            // 0x00BB72C8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB72CC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::RemoveUpdate_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB72D0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_7 = null;
            // 0x00BB72D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB72D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB72DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB72E0: MOV x2, x22                | X2 = 1152921510039414640 (0x1000000143CE6770);//ML01
            // 0x00BB72E4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_13 = val_7;
            // 0x00BB72E8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::RemoveUpdate_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::RemoveUpdate_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB72EC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB72F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB72F4: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782622728
            ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache1 = val_13;
            // 0x00BB72F8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB72FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7300: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_14 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache1;
            label_17:
            // 0x00BB7304: CBNZ x19, #0xbb730c        | if (X1 != 0) goto label_18;             
            if(X1 != 0)
            {
                goto label_18;
            }
            // 0x00BB7308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::RemoveUpdate_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_18:
            // 0x00BB730C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7310: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7314: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x00BB7318: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB731C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_14);
            X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_14);
            // 0x00BB7320: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB7324: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7328: LDR x21, [x8, #0x18]       | X21 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache0;
            val_15 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache0;
            // 0x00BB732C: CBNZ x21, #0xbb7378        | if (ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache0 != null) goto label_19;
            if(val_15 != null)
            {
                goto label_19;
            }
            // 0x00BB7330: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x00BB7334: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00BB7338: LDR x8, [x8, #0x6d8]       | X8 = 1152921510039415664;               
            // 0x00BB733C: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x00BB7340: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AllUpdate_Binding::<Register>m__0();
            // 0x00BB7344: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_8 = null;
            // 0x00BB7348: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x00BB734C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7350: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7354: MOV x2, x21                | X2 = 1152921510039415664 (0x1000000143CE6B70);//ML01
            // 0x00BB7358: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BB735C: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AllUpdate_Binding::<Register>m__0());
            val_8 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AllUpdate_Binding::<Register>m__0());
            // 0x00BB7360: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB7364: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7368: STR x22, [x8, #0x18]       | ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504782622744
            ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache0 = val_8;
            // 0x00BB736C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB7370: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7374: LDR x21, [x8, #0x18]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_15 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache0;
            label_19:
            // 0x00BB7378: CBNZ x19, #0xbb7380        | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x00BB737C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AllUpdate_Binding::<Register>m__0()), ????);
            label_20:
            // 0x00BB7380: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7384: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7388: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB738C: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BB7390: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_15);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_15);
            // 0x00BB7394: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB7398: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB739C: LDR x21, [x8, #0x20]       | X21 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache1;
            val_16 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache1;
            // 0x00BB73A0: CBNZ x21, #0xbb73ec        | if (ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache1 != null) goto label_21;
            if(val_16 != null)
            {
                goto label_21;
            }
            // 0x00BB73A4: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00BB73A8: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x00BB73AC: LDR x8, [x8, #0x1b8]       | X8 = 1152921510039416688;               
            // 0x00BB73B0: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x00BB73B4: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AllUpdate_Binding::<Register>m__1(int s);
            // 0x00BB73B8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_9 = null;
            // 0x00BB73BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x00BB73C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB73C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB73C8: MOV x2, x21                | X2 = 1152921510039416688 (0x1000000143CE6F70);//ML01
            // 0x00BB73CC: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BB73D0: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AllUpdate_Binding::<Register>m__1(int s));
            val_9 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AllUpdate_Binding::<Register>m__1(int s));
            // 0x00BB73D4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB73D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB73DC: STR x22, [x8, #0x20]       | ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504782622752
            ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache1 = val_9;
            // 0x00BB73E0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB73E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB73E8: LDR x21, [x8, #0x20]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_16 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__am$cache1;
            label_21:
            // 0x00BB73EC: CBNZ x19, #0xbb73f4        | if (X1 != 0) goto label_22;             
            if(X1 != 0)
            {
                goto label_22;
            }
            // 0x00BB73F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AllUpdate_Binding::<Register>m__1(int s)), ????);
            label_22:
            // 0x00BB73F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB73F8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB73FC: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB7400: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BB7404: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_16);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_16);
            // 0x00BB7408: LDR x21, [x24]             | X21 = typeof(System.Type[]);            
            // 0x00BB740C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB7410: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB7414: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7418: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB741C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB7420: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB7424: CBNZ x20, #0xbb742c        | if (val_1 != null) goto label_23;       
            if(val_1 != null)
            {
                goto label_23;
            }
            // 0x00BB7428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_23:
            // 0x00BB742C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB7430: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB7434: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x00BB7438: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB743C: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB7440: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB7444: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_10 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB7448: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB744C: MOV x20, x0                | X20 = val_10;//m1                       
            // 0x00BB7450: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7454: LDR x21, [x8, #0x10]       | X21 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache2;
            val_17 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache2;
            // 0x00BB7458: CBNZ x21, #0xbb74a4        | if (ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache2 != null) goto label_24;
            if(val_17 != null)
            {
                goto label_24;
            }
            // 0x00BB745C: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00BB7460: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB7464: LDR x8, [x8, #0x430]       | X8 = 1152921510039421808;               
            // 0x00BB7468: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB746C: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB7470: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_11 = null;
            // 0x00BB7474: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB7478: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB747C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7480: MOV x2, x21                | X2 = 1152921510039421808 (0x1000000143CE8370);//ML01
            // 0x00BB7484: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB7488: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_11 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB748C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB7490: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7494: STR x22, [x8, #0x10]       | ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782622736
            ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache2 = val_11;
            // 0x00BB7498: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.AllUpdate_Binding);
            // 0x00BB749C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AllUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB74A0: LDR x21, [x8, #0x10]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_17 = ILRuntime.Runtime.Generated.AllUpdate_Binding.<>f__mg$cache2;
            label_24:
            // 0x00BB74A4: CBNZ x19, #0xbb74ac        | if (X1 != 0) goto label_25;             
            if(X1 != 0)
            {
                goto label_25;
            }
            // 0x00BB74A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AllUpdate_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_25:
            // 0x00BB74AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB74B0: MOV x1, x20                | X1 = val_10;//m1                        
            // 0x00BB74B4: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB74B8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB74BC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB74C0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB74C4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BB74C8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BB74CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB74D0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BB74D4: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_17); return;
            X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_17);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB74D8 (12285144), len: 544  VirtAddr: 0x00BB74D8 RVA: 0x00BB74D8 token: 100663730 methodIndex: 29775 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* AddUpdate_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB74D8: STP x24, x23, [sp, #-0x40]! | stack[1152921510039604112] = ???;  stack[1152921510039604120] = ???;  //  dest_result_addr=1152921510039604112 |  dest_result_addr=1152921510039604120
            // 0x00BB74DC: STP x22, x21, [sp, #0x10]  | stack[1152921510039604128] = ???;  stack[1152921510039604136] = ???;  //  dest_result_addr=1152921510039604128 |  dest_result_addr=1152921510039604136
            // 0x00BB74E0: STP x20, x19, [sp, #0x20]  | stack[1152921510039604144] = ???;  stack[1152921510039604152] = ???;  //  dest_result_addr=1152921510039604144 |  dest_result_addr=1152921510039604152
            // 0x00BB74E4: STP x29, x30, [sp, #0x30]  | stack[1152921510039604160] = ???;  stack[1152921510039604168] = ???;  //  dest_result_addr=1152921510039604160 |  dest_result_addr=1152921510039604168
            // 0x00BB74E8: ADD x29, sp, #0x30         | X29 = (1152921510039604112 + 48) = 1152921510039604160 (0x1000000143D14BC0);
            // 0x00BB74EC: SUB sp, sp, #0x10          | SP = (1152921510039604112 - 16) = 1152921510039604096 (0x1000000143D14B80);
            // 0x00BB74F0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB74F4: LDRB w8, [x20, #0xb42]     | W8 = (bool)static_value_03733B42;       
            // 0x00BB74F8: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB74FC: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB7500: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB7504: TBNZ w8, #0, #0xbb7520     | if (static_value_03733B42 == true) goto label_0;
            // 0x00BB7508: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00BB750C: LDR x8, [x8, #0x130]       | X8 = 0x2B8AC04;                         
            // 0x00BB7510: LDR w0, [x8]               | W0 = 0x1BF;                             
            // 0x00BB7514: BL #0x2782188              | X0 = sub_2782188( ?? 0x1BF, ????);      
            // 0x00BB7518: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB751C: STRB w8, [x20, #0xb42]     | static_value_03733B42 = true;            //  dest_result_addr=57883458
            label_0:
            // 0x00BB7520: CBNZ x19, #0xbb7528        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB7524: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1BF, ????);      
            label_1:
            // 0x00BB7528: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB752C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7530: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB7534: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB7538: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB753C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7540: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB7544: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB7548: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB754C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB7550: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB7554: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7558: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB755C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB7560: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB7564: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB7568: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB756C: ADRP x9, #0x3680000        | X9 = 57147392 (0x3680000);              
            // 0x00BB7570: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB7574: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB7578: LDR x9, [x9, #0x8d0]       | X9 = 1152921504921915392;               
            // 0x00BB757C: LDR x24, [x9]              | X24 = typeof(IZUpdate);                 
            // 0x00BB7580: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB7584: TBZ w9, #0, #0xbb7598      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB7588: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB758C: CBNZ w9, #0xbb7598         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB7590: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB7594: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB7598: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB759C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB75A0: MOV x1, x24                | X1 = 1152921504921915392 (0x1000000012C79000);//ML01
            // 0x00BB75A4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB75A8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB75AC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB75B0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB75B4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB75B8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB75BC: TBZ w9, #0, #0xbb75d0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB75C0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB75C4: CBNZ w9, #0xbb75d0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB75C8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB75CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB75D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB75D4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB75D8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB75DC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB75E0: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB75E4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB75E8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB75EC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB75F0: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB75F4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB75F8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB75FC: TBZ w9, #0, #0xbb7610      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB7600: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB7604: CBNZ w9, #0xbb7610         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB7608: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB760C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB7610: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB7614: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7618: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB761C: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BB7620: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB7624: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00BB7628: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00BB762C: CBZ x23, #0xbb7680         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BB7630: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BB7634: LDR x8, [x8, #0x388]       | X8 = 1152921504921915392;               
            // 0x00BB7638: MOV x0, x23                | X0 = val_6;//m1                         
            // 0x00BB763C: LDR x24, [x8]              | X24 = typeof(IZUpdate);                 
            // 0x00BB7640: MOV x1, x24                | X1 = 1152921504921915392 (0x1000000012C79000);//ML01
            // 0x00BB7644: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x00BB7648: MOV x22, x0                | X22 = val_6;//m1                        
            val_8 = val_6;
            // 0x00BB764C: CBNZ x22, #0xbb7680        | if (val_6 != null) goto label_9;        
            if(val_8 != null)
            {
                goto label_9;
            }
            // 0x00BB7650: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x00BB7654: MOV x1, x24                | X1 = 1152921504921915392 (0x1000000012C79000);//ML01
            // 0x00BB7658: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB765C: ADD x8, sp, #8             | X8 = (1152921510039604096 + 8) = 1152921510039604104 (0x1000000143D14B88);
            // 0x00BB7660: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB7664: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510039592176]
            // 0x00BB7668: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BB766C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7670: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BB7674: ADD x0, sp, #8             | X0 = (1152921510039604096 + 8) = 1152921510039604104 (0x1000000143D14B88);
            // 0x00BB7678: BL #0x299a140              | 
            // 0x00BB767C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00BB7680: CBNZ x19, #0xbb7688        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BB7684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143D14B88, ????);
            label_10:
            // 0x00BB7688: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB768C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7690: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB7694: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB7698: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x00BB769C: LDR x8, [x8, #0xf38]       | X8 = 1152921504922128384;               
            // 0x00BB76A0: LDR x0, [x8]               | X0 = typeof(AllUpdate);                 
            // 0x00BB76A4: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
            // 0x00BB76A8: TBZ w8, #0, #0xbb76b8      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00BB76AC: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
            // 0x00BB76B0: CBNZ w8, #0xbb76b8         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00BB76B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
            label_12:
            // 0x00BB76B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB76BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB76C0: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x00BB76C4: BL #0xb14d7c               | AllUpdate.AddUpdate(update:  0);        
            AllUpdate.AddUpdate(update:  0);
            // 0x00BB76C8: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BB76CC: SUB sp, x29, #0x30         | SP = (1152921510039604160 - 48) = 1152921510039604112 (0x1000000143D14B90);
            // 0x00BB76D0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB76D4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB76D8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB76DC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB76E0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB76E4: MOV x19, x0                | 
            // 0x00BB76E8: ADD x0, sp, #8             | 
            // 0x00BB76EC: BL #0x299a140              | 
            // 0x00BB76F0: MOV x0, x19                | 
            // 0x00BB76F4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB76F8 (12285688), len: 544  VirtAddr: 0x00BB76F8 RVA: 0x00BB76F8 token: 100663731 methodIndex: 29776 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* RemoveUpdate_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB76F8: STP x24, x23, [sp, #-0x40]! | stack[1152921510039773456] = ???;  stack[1152921510039773464] = ???;  //  dest_result_addr=1152921510039773456 |  dest_result_addr=1152921510039773464
            // 0x00BB76FC: STP x22, x21, [sp, #0x10]  | stack[1152921510039773472] = ???;  stack[1152921510039773480] = ???;  //  dest_result_addr=1152921510039773472 |  dest_result_addr=1152921510039773480
            // 0x00BB7700: STP x20, x19, [sp, #0x20]  | stack[1152921510039773488] = ???;  stack[1152921510039773496] = ???;  //  dest_result_addr=1152921510039773488 |  dest_result_addr=1152921510039773496
            // 0x00BB7704: STP x29, x30, [sp, #0x30]  | stack[1152921510039773504] = ???;  stack[1152921510039773512] = ???;  //  dest_result_addr=1152921510039773504 |  dest_result_addr=1152921510039773512
            // 0x00BB7708: ADD x29, sp, #0x30         | X29 = (1152921510039773456 + 48) = 1152921510039773504 (0x1000000143D3E140);
            // 0x00BB770C: SUB sp, sp, #0x10          | SP = (1152921510039773456 - 16) = 1152921510039773440 (0x1000000143D3E100);
            // 0x00BB7710: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB7714: LDRB w8, [x20, #0xb43]     | W8 = (bool)static_value_03733B43;       
            // 0x00BB7718: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB771C: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB7720: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB7724: TBNZ w8, #0, #0xbb7740     | if (static_value_03733B43 == true) goto label_0;
            // 0x00BB7728: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x00BB772C: LDR x8, [x8, #0x278]       | X8 = 0x2B8AC10;                         
            // 0x00BB7730: LDR w0, [x8]               | W0 = 0x1C2;                             
            // 0x00BB7734: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C2, ????);      
            // 0x00BB7738: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB773C: STRB w8, [x20, #0xb43]     | static_value_03733B43 = true;            //  dest_result_addr=57883459
            label_0:
            // 0x00BB7740: CBNZ x19, #0xbb7748        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB7744: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C2, ????);      
            label_1:
            // 0x00BB7748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB774C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7750: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB7754: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB7758: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB775C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7760: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB7764: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB7768: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB776C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB7770: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB7774: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7778: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB777C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB7780: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB7784: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB7788: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB778C: ADRP x9, #0x3680000        | X9 = 57147392 (0x3680000);              
            // 0x00BB7790: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB7794: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB7798: LDR x9, [x9, #0x8d0]       | X9 = 1152921504921915392;               
            // 0x00BB779C: LDR x24, [x9]              | X24 = typeof(IZUpdate);                 
            // 0x00BB77A0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB77A4: TBZ w9, #0, #0xbb77b8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB77A8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB77AC: CBNZ w9, #0xbb77b8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB77B0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB77B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB77B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB77BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB77C0: MOV x1, x24                | X1 = 1152921504921915392 (0x1000000012C79000);//ML01
            // 0x00BB77C4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB77C8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB77CC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB77D0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB77D4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB77D8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB77DC: TBZ w9, #0, #0xbb77f0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB77E0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB77E4: CBNZ w9, #0xbb77f0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB77E8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB77EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB77F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB77F4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB77F8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB77FC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB7800: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB7804: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB7808: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB780C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB7810: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB7814: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB7818: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB781C: TBZ w9, #0, #0xbb7830      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB7820: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB7824: CBNZ w9, #0xbb7830         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB7828: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB782C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB7830: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB7834: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7838: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB783C: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BB7840: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB7844: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00BB7848: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00BB784C: CBZ x23, #0xbb78a0         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BB7850: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BB7854: LDR x8, [x8, #0x388]       | X8 = 1152921504921915392;               
            // 0x00BB7858: MOV x0, x23                | X0 = val_6;//m1                         
            // 0x00BB785C: LDR x24, [x8]              | X24 = typeof(IZUpdate);                 
            // 0x00BB7860: MOV x1, x24                | X1 = 1152921504921915392 (0x1000000012C79000);//ML01
            // 0x00BB7864: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x00BB7868: MOV x22, x0                | X22 = val_6;//m1                        
            val_8 = val_6;
            // 0x00BB786C: CBNZ x22, #0xbb78a0        | if (val_6 != null) goto label_9;        
            if(val_8 != null)
            {
                goto label_9;
            }
            // 0x00BB7870: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x00BB7874: MOV x1, x24                | X1 = 1152921504921915392 (0x1000000012C79000);//ML01
            // 0x00BB7878: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB787C: ADD x8, sp, #8             | X8 = (1152921510039773440 + 8) = 1152921510039773448 (0x1000000143D3E108);
            // 0x00BB7880: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB7884: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510039761520]
            // 0x00BB7888: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BB788C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7890: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BB7894: ADD x0, sp, #8             | X0 = (1152921510039773440 + 8) = 1152921510039773448 (0x1000000143D3E108);
            // 0x00BB7898: BL #0x299a140              | 
            // 0x00BB789C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00BB78A0: CBNZ x19, #0xbb78a8        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BB78A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143D3E108, ????);
            label_10:
            // 0x00BB78A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB78AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB78B0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB78B4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB78B8: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x00BB78BC: LDR x8, [x8, #0xf38]       | X8 = 1152921504922128384;               
            // 0x00BB78C0: LDR x0, [x8]               | X0 = typeof(AllUpdate);                 
            // 0x00BB78C4: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
            // 0x00BB78C8: TBZ w8, #0, #0xbb78d8      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00BB78CC: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
            // 0x00BB78D0: CBNZ w8, #0xbb78d8         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00BB78D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
            label_12:
            // 0x00BB78D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB78DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB78E0: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x00BB78E4: BL #0xb25c84               | AllUpdate.RemoveUpdate(update:  0);     
            AllUpdate.RemoveUpdate(update:  0);
            // 0x00BB78E8: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BB78EC: SUB sp, x29, #0x30         | SP = (1152921510039773504 - 48) = 1152921510039773456 (0x1000000143D3E110);
            // 0x00BB78F0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB78F4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB78F8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB78FC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB7900: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB7904: MOV x19, x0                | 
            // 0x00BB7908: ADD x0, sp, #8             | 
            // 0x00BB790C: BL #0x299a140              | 
            // 0x00BB7910: MOV x0, x19                | 
            // 0x00BB7914: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB7918 (12286232), len: 180  VirtAddr: 0x00BB7918 RVA: 0x00BB7918 token: 100663732 methodIndex: 29777 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BB7918: STP x22, x21, [sp, #-0x30]! | stack[1152921510039930528] = ???;  stack[1152921510039930536] = ???;  //  dest_result_addr=1152921510039930528 |  dest_result_addr=1152921510039930536
            // 0x00BB791C: STP x20, x19, [sp, #0x10]  | stack[1152921510039930544] = ???;  stack[1152921510039930552] = ???;  //  dest_result_addr=1152921510039930544 |  dest_result_addr=1152921510039930552
            // 0x00BB7920: STP x29, x30, [sp, #0x20]  | stack[1152921510039930560] = ???;  stack[1152921510039930568] = ???;  //  dest_result_addr=1152921510039930560 |  dest_result_addr=1152921510039930568
            // 0x00BB7924: ADD x29, sp, #0x20         | X29 = (1152921510039930528 + 32) = 1152921510039930560 (0x1000000143D646C0);
            // 0x00BB7928: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00BB792C: LDRB w8, [x22, #0xb44]     | W8 = (bool)static_value_03733B44;       
            // 0x00BB7930: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BB7934: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BB7938: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BB793C: TBNZ w8, #0, #0xbb7958     | if (static_value_03733B44 == true) goto label_0;
            // 0x00BB7940: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x00BB7944: LDR x8, [x8, #0x920]       | X8 = 0x2B8AC08;                         
            // 0x00BB7948: LDR w0, [x8]               | W0 = 0x1C0;                             
            // 0x00BB794C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C0, ????);      
            // 0x00BB7950: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB7954: STRB w8, [x22, #0xb44]     | static_value_03733B44 = true;            //  dest_result_addr=57883460
            label_0:
            // 0x00BB7958: CBNZ x21, #0xbb7960        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB795C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C0, ????);      
            label_1:
            // 0x00BB7960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7964: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BB7968: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB796C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB7970: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BB7974: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BB7978: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB797C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BB7980: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x00BB7984: LDR x8, [x8, #0xf38]       | X8 = 1152921504922128384;               
            // 0x00BB7988: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB798C: LDR x8, [x8]               | X8 = typeof(AllUpdate);                 
            // 0x00BB7990: MOV x0, x8                 | X0 = 1152921504922128384 (0x1000000012CAD000);//ML01
            AllUpdate val_3 = null;
            // 0x00BB7994: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AllUpdate), ????);
            // 0x00BB7998: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB799C: MOV x21, x0                | X21 = 1152921504922128384 (0x1000000012CAD000);//ML01
            // 0x00BB79A0: BL #0xb25c7c               | .ctor();                                
            val_3 = new AllUpdate();
            // 0x00BB79A4: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BB79A8: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BB79AC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB79B0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB79B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB79B8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BB79BC: MOV x3, x21                | X3 = 1152921504922128384 (0x1000000012CAD000);//ML01
            // 0x00BB79C0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB79C4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB79C8: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB79CC (12286412), len: 92  VirtAddr: 0x00BB79CC RVA: 0x00BB79CC token: 100663733 methodIndex: 29778 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x00BB79CC: STP x20, x19, [sp, #-0x20]! | stack[1152921510040058928] = ???;  stack[1152921510040058936] = ???;  //  dest_result_addr=1152921510040058928 |  dest_result_addr=1152921510040058936
            // 0x00BB79D0: STP x29, x30, [sp, #0x10]  | stack[1152921510040058944] = ???;  stack[1152921510040058952] = ???;  //  dest_result_addr=1152921510040058944 |  dest_result_addr=1152921510040058952
            // 0x00BB79D4: ADD x29, sp, #0x10         | X29 = (1152921510040058928 + 16) = 1152921510040058944 (0x1000000143D83C40);
            // 0x00BB79D8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BB79DC: LDRB w8, [x19, #0xb45]     | W8 = (bool)static_value_03733B45;       
            // 0x00BB79E0: TBNZ w8, #0, #0xbb79fc     | if (static_value_03733B45 == true) goto label_0;
            // 0x00BB79E4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB79E8: LDR x8, [x8, #0x838]       | X8 = 0x2B8AC14;                         
            // 0x00BB79EC: LDR w0, [x8]               | W0 = 0x1C3;                             
            // 0x00BB79F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C3, ????);      
            // 0x00BB79F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB79F8: STRB w8, [x19, #0xb45]     | static_value_03733B45 = true;            //  dest_result_addr=57883461
            label_0:
            // 0x00BB79FC: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x00BB7A00: LDR x8, [x8, #0xf38]       | X8 = 1152921504922128384;               
            // 0x00BB7A04: LDR x0, [x8]               | X0 = typeof(AllUpdate);                 
            AllUpdate val_1 = null;
            // 0x00BB7A08: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AllUpdate), ????);
            // 0x00BB7A0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7A10: MOV x19, x0                | X19 = 1152921504922128384 (0x1000000012CAD000);//ML01
            // 0x00BB7A14: BL #0xb25c7c               | .ctor();                                
            val_1 = new AllUpdate();
            // 0x00BB7A18: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB7A1C: MOV x0, x19                | X0 = 1152921504922128384 (0x1000000012CAD000);//ML01
            // 0x00BB7A20: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB7A24: RET                        |  return (System.Object)typeof(AllUpdate);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB7A28 (12286504), len: 92  VirtAddr: 0x00BB7A28 RVA: 0x00BB7A28 token: 100663734 methodIndex: 29779 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x00BB7A28: STP x20, x19, [sp, #-0x20]! | stack[1152921510040175024] = ???;  stack[1152921510040175032] = ???;  //  dest_result_addr=1152921510040175024 |  dest_result_addr=1152921510040175032
            // 0x00BB7A2C: STP x29, x30, [sp, #0x10]  | stack[1152921510040175040] = ???;  stack[1152921510040175048] = ???;  //  dest_result_addr=1152921510040175040 |  dest_result_addr=1152921510040175048
            // 0x00BB7A30: ADD x29, sp, #0x10         | X29 = (1152921510040175024 + 16) = 1152921510040175040 (0x1000000143DA01C0);
            // 0x00BB7A34: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB7A38: LDRB w8, [x20, #0xb46]     | W8 = (bool)static_value_03733B46;       
            // 0x00BB7A3C: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00BB7A40: TBNZ w8, #0, #0xbb7a5c     | if (static_value_03733B46 == true) goto label_0;
            // 0x00BB7A44: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00BB7A48: LDR x8, [x8, #0xe0]        | X8 = 0x2B8AC18;                         
            // 0x00BB7A4C: LDR w0, [x8]               | W0 = 0x1C4;                             
            // 0x00BB7A50: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C4, ????);      
            // 0x00BB7A54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB7A58: STRB w8, [x20, #0xb46]     | static_value_03733B46 = true;            //  dest_result_addr=57883462
            label_0:
            // 0x00BB7A5C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BB7A60: LDR x8, [x8, #0x188]       | X8 = 1152921510040158960;               
            // 0x00BB7A64: LDR x20, [x8]              | X20 = typeof(AllUpdate[]);              
            // 0x00BB7A68: MOV x0, x20                | X0 = 1152921510040158960 (0x1000000143D9C2F0);//ML01
            // 0x00BB7A6C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(AllUpdate[]), ????);
            // 0x00BB7A70: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB7A74: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00BB7A78: MOV x0, x20                | X0 = 1152921510040158960 (0x1000000143D9C2F0);//ML01
            // 0x00BB7A7C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB7A80: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(AllUpdate[]), ????);
        
        }
    
    }

}
