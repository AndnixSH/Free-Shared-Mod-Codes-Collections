using UnityEngine;

namespace ILRuntime.Other
{
    internal class ByReferenceKeyComparer<T> : IEqualityComparer<T>
    {
        // Methods
        // Generic instance method:
        //
        // file offset: 0x01D4A214 VirtAddr: 0x01D4A214 -RVA: 0x01D4A214 
        // -ByReferenceKeyComparer<object>..ctor
        // -ByReferenceKeyComparer<System.Type>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x01D4A214 (30712340), len: 44  VirtAddr: 0x01D4A214 RVA: 0x01D4A214 token: 100679638 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public ByReferenceKeyComparer<T>()
        {
            //
            // Disasemble & Code
            // 0x01D4A214: STP x20, x19, [sp, #-0x20]! | stack[1152921512784790400] = ???;  stack[1152921512784790408] = ???;  //  dest_result_addr=1152921512784790400 |  dest_result_addr=1152921512784790408
            // 0x01D4A218: STP x29, x30, [sp, #0x10]  | stack[1152921512784790416] = ???;  stack[1152921512784790424] = ???;  //  dest_result_addr=1152921512784790416 |  dest_result_addr=1152921512784790424
            // 0x01D4A21C: ADD x29, sp, #0x10         | X29 = (1152921512784790400 + 16) = 1152921512784790416 (0x10000001E7718390);
            // 0x01D4A220: MOV x19, x0                | X19 = 1152921512784802432 (0x10000001E771B280);//ML01
            // 0x01D4A224: CBNZ x19, #0x1d4a22c       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D4A228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D4A22C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D4A230: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D4A234: MOV x0, x19                | X0 = 1152921512784802432 (0x10000001E771B280);//ML01
            // 0x01D4A238: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D4A23C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D4A240 VirtAddr: 0x01D4A240 -RVA: 0x01D4A240 
        // -ByReferenceKeyComparer<object>.Equals
        //
        //
        // Offset in libil2cpp.so: 0x01D4A240 (30712384), len: 12  VirtAddr: 0x01D4A240 RVA: 0x01D4A240 token: 100679639 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public bool Equals(T x, T y)
        {
            //
            // Disasemble & Code
            // 0x01D4A240: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D4A244: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01D4A248: B #0x1708e5c               | return System.Object.ReferenceEquals(objA:  0, objB:  x);
            return System.Object.ReferenceEquals(objA:  0, objB:  x);
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D4A24C VirtAddr: 0x01D4A24C -RVA: 0x01D4A24C 
        // -ByReferenceKeyComparer<object>.GetHashCode
        //
        //
        // Offset in libil2cpp.so: 0x01D4A24C (30712396), len: 12  VirtAddr: 0x01D4A24C RVA: 0x01D4A24C token: 100679640 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public int GetHashCode(T obj)
        {
            //
            // Disasemble & Code
            // 0x01D4A24C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D4A250: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01D4A254: B #0x13cafd4               | return System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(o:  0);
            return System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(o:  0);
        
        }
    
    }

}
