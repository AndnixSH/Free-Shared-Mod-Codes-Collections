using UnityEngine;

namespace Newtonsoft.Json.Converters
{
    public class BsonObjectIdConverter : JsonConverter
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x01302F00 (19934976), len: 8  VirtAddr: 0x01302F00 RVA: 0x01302F00 token: 100684837 methodIndex: 47481 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonObjectIdConverter()
        {
            //
            // Disasemble & Code
            // 0x01302F00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01302F04: B #0x16f59f0               | this..ctor(); return;                   
            val_1 = new System.Object();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01302F10 (19934992), len: 344  VirtAddr: 0x01302F10 RVA: 0x01302F10 token: 100684838 methodIndex: 47482 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteJson(Newtonsoft.Json.JsonWriter writer, object value, Newtonsoft.Json.JsonSerializer serializer)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x01302F10: STP x22, x21, [sp, #-0x30]! | stack[1152921513731334896] = ???;  stack[1152921513731334904] = ???;  //  dest_result_addr=1152921513731334896 |  dest_result_addr=1152921513731334904
            // 0x01302F14: STP x20, x19, [sp, #0x10]  | stack[1152921513731334912] = ???;  stack[1152921513731334920] = ???;  //  dest_result_addr=1152921513731334912 |  dest_result_addr=1152921513731334920
            // 0x01302F18: STP x29, x30, [sp, #0x20]  | stack[1152921513731334928] = ???;  stack[1152921513731334936] = ???;  //  dest_result_addr=1152921513731334928 |  dest_result_addr=1152921513731334936
            // 0x01302F1C: ADD x29, sp, #0x20         | X29 = (1152921513731334896 + 32) = 1152921513731334928 (0x100000021FDCA310);
            // 0x01302F20: SUB sp, sp, #0x10          | SP = (1152921513731334896 - 16) = 1152921513731334880 (0x100000021FDCA2E0);
            // 0x01302F24: ADRP x21, #0x3736000       | X21 = 57892864 (0x3736000);             
            // 0x01302F28: LDRB w8, [x21, #0x900]     | W8 = (bool)static_value_03736900;       
            // 0x01302F2C: MOV x20, x2                | X20 = value;//m1                        
            val_5 = value;
            // 0x01302F30: MOV x19, x1                | X19 = writer;//m1                       
            // 0x01302F34: TBNZ w8, #0, #0x1302f50    | if (static_value_03736900 == true) goto label_0;
            // 0x01302F38: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x01302F3C: LDR x8, [x8, #0x360]       | X8 = 0x2B8F990;                         
            // 0x01302F40: LDR w0, [x8]               | W0 = 0x1528;                            
            // 0x01302F44: BL #0x2782188              | X0 = sub_2782188( ?? 0x1528, ????);     
            // 0x01302F48: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01302F4C: STRB w8, [x21, #0x900]     | static_value_03736900 = true;            //  dest_result_addr=57895168
            label_0:
            // 0x01302F50: CBZ x20, #0x1302fac        | if (value == null) goto label_1;        
            if(val_5 == null)
            {
                goto label_1;
            }
            // 0x01302F54: ADRP x9, #0x3628000        | X9 = 56786944 (0x3628000);              
            // 0x01302F58: LDR x9, [x9, #0x6c0]       | X9 = 1152921504857485312;               
            // 0x01302F5C: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x01302F60: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonObjectId);
            // 0x01302F64: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01302F68: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonObjectId.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01302F6C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonObjectId.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01302F70: B.LO #0x1302f88            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonObjectId.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01302F74: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01302F78: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObjectId.__il2cpp
            // 0x01302F7C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObjectId.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01302F80: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObjectId.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonObjectId))
            // 0x01302F84: B.EQ #0x1302fb0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObjectId.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01302F88: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01302F8C: ADD x8, sp, #8             | X8 = (1152921513731334880 + 8) = 1152921513731334888 (0x100000021FDCA2E8);
            // 0x01302F90: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01302F94: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921513731322944]
            // 0x01302F98: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01302F9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01302FA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01302FA4: ADD x0, sp, #8             | X0 = (1152921513731334880 + 8) = 1152921513731334888 (0x100000021FDCA2E8);
            // 0x01302FA8: BL #0x299a140              | 
            label_1:
            // 0x01302FAC: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_5 = 0;
            label_3:
            // 0x01302FB0: CBZ x19, #0x1302fd4        | if (writer == null) goto label_4;       
            if(writer == null)
            {
                goto label_4;
            }
            // 0x01302FB4: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x01302FB8: LDR x8, [x8, #0xe98]       | X8 = 1152921504858124288;               
            // 0x01302FBC: LDR x9, [x19]              | X9 = typeof(Newtonsoft.Json.JsonWriter);
            // 0x01302FC0: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonWriter);
            // 0x01302FC4: LDRB w11, [x9, #0x104]     | W11 = Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01302FC8: LDRB w10, [x8, #0x104]     | W10 = Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01302FCC: CMP w11, w10               | STATE = COMPARE(Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01302FD0: B.HS #0x1302fdc            | if (Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchyDepth >= Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            label_4:
            // 0x01302FD4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x01302FD8: B #0x1302ff0               |  goto label_6;                          
            goto label_6;
            label_5:
            // 0x01302FDC: LDR x9, [x9, #0xb0]        | X9 = Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchy;
            // 0x01302FE0: ADD x9, x9, x10, lsl #3    | X9 = (Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonWrit
            // 0x01302FE4: LDUR x9, [x9, #-8]         | X9 = (Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01302FE8: CMP x9, x8                 | STATE = COMPARE((Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonWriter))
            // 0x01302FEC: CSEL x21, x19, xzr, eq     | X21 = (Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? writer : 0;
            var val_3 = (((Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (writer) : 0;
            label_6:
            // 0x01302FF0: CBNZ x20, #0x1302ff8       | if (0x0 != 0) goto label_7;             
            if(val_5 != 0)
            {
                goto label_7;
            }
            // 0x01302FF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021FDCA2E8, ????);
            label_7:
            // 0x01302FF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01302FFC: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x01303000: BL #0xad1e7c               | X0 = val_5.get_Value();                 
            System.Byte[] val_4 = val_5.Value;
            // 0x01303004: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x01303008: CBZ x21, #0x1303020        | if ((Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? writer : 0 == 0) goto label_8;
            // 0x0130300C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01303010: MOV x0, x21                | X0 = (Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? writer : 0;//m1
            // 0x01303014: MOV x1, x20                | X1 = val_4;//m1                         
            // 0x01303018: BL #0xad5e3c               | (Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonWriter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? writer : 0.WriteObjectId(value:  val_4);
            val_3.WriteObjectId(value:  val_4);
            // 0x0130301C: B #0x1303040               |  goto label_9;                          
            goto label_9;
            label_8:
            // 0x01303020: CBNZ x19, #0x1303028       | if (writer != null) goto label_10;      
            if(writer != null)
            {
                goto label_10;
            }
            // 0x01303024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_10:
            // 0x01303028: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.JsonWriter);
            // 0x0130302C: MOV x0, x19                | X0 = writer;//m1                        
            // 0x01303030: MOV x1, x20                | X1 = val_4;//m1                         
            // 0x01303034: LDR x9, [x8, #0x4c0]       | X9 = typeof(Newtonsoft.Json.JsonWriter).__il2cppRuntimeField_4C0;
            // 0x01303038: LDR x2, [x8, #0x4c8]       | X2 = typeof(Newtonsoft.Json.JsonWriter).__il2cppRuntimeField_4C8;
            // 0x0130303C: BLR x9                     | X0 = typeof(Newtonsoft.Json.JsonWriter).__il2cppRuntimeField_4C0();
            label_9:
            // 0x01303040: SUB sp, x29, #0x20         | SP = (1152921513731334928 - 32) = 1152921513731334896 (0x100000021FDCA2F0);
            // 0x01303044: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01303048: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0130304C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01303050: RET                        |  return;                                
            return;
            // 0x01303054: MOV x19, x0                | 
            // 0x01303058: ADD x0, sp, #8             | 
            // 0x0130305C: BL #0x299a140              | 
            // 0x01303060: MOV x0, x19                | 
            // 0x01303064: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01303068 (19935336), len: 576  VirtAddr: 0x01303068 RVA: 0x01303068 token: 100684839 methodIndex: 47483 delegateWrapperIndex: 0 methodInvoker: 0
        public override object ReadJson(Newtonsoft.Json.JsonReader reader, System.Type objectType, object existingValue, Newtonsoft.Json.JsonSerializer serializer)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            System.Byte[] val_7;
            // 0x01303068: STP x22, x21, [sp, #-0x30]! | stack[1152921513731525872] = ???;  stack[1152921513731525880] = ???;  //  dest_result_addr=1152921513731525872 |  dest_result_addr=1152921513731525880
            // 0x0130306C: STP x20, x19, [sp, #0x10]  | stack[1152921513731525888] = ???;  stack[1152921513731525896] = ???;  //  dest_result_addr=1152921513731525888 |  dest_result_addr=1152921513731525896
            // 0x01303070: STP x29, x30, [sp, #0x20]  | stack[1152921513731525904] = ???;  stack[1152921513731525912] = ???;  //  dest_result_addr=1152921513731525904 |  dest_result_addr=1152921513731525912
            // 0x01303074: ADD x29, sp, #0x20         | X29 = (1152921513731525872 + 32) = 1152921513731525904 (0x100000021FDF8D10);
            // 0x01303078: SUB sp, sp, #0x10          | SP = (1152921513731525872 - 16) = 1152921513731525856 (0x100000021FDF8CE0);
            // 0x0130307C: ADRP x20, #0x3736000       | X20 = 57892864 (0x3736000);             
            // 0x01303080: LDRB w8, [x20, #0x901]     | W8 = (bool)static_value_03736901;       
            // 0x01303084: MOV x19, x1                | X19 = reader;//m1                       
            // 0x01303088: TBNZ w8, #0, #0x13030a4    | if (static_value_03736901 == true) goto label_0;
            // 0x0130308C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x01303090: LDR x8, [x8, #0x390]       | X8 = 0x2B8F98C;                         
            // 0x01303094: LDR w0, [x8]               | W0 = 0x1527;                            
            // 0x01303098: BL #0x2782188              | X0 = sub_2782188( ?? 0x1527, ????);     
            // 0x0130309C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x013030A0: STRB w8, [x20, #0x901]     | static_value_03736901 = true;            //  dest_result_addr=57895169
            label_0:
            // 0x013030A4: CBNZ x19, #0x13030ac       | if (reader != null) goto label_1;       
            if(reader != null)
            {
                goto label_1;
            }
            // 0x013030A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1527, ????);     
            label_1:
            // 0x013030AC: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.JsonReader);
            // 0x013030B0: MOV x0, x19                | X0 = reader;//m1                        
            // 0x013030B4: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.JsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.JsonReader).__il2cppRuntimeField_188; //  | 
            // 0x013030B8: BLR x9                     | X0 = typeof(Newtonsoft.Json.JsonReader).__il2cppRuntimeField_180();
            // 0x013030BC: CMP w0, #0x11              | STATE = COMPARE(reader, 0x11)           
            // 0x013030C0: B.NE #0x1303164            | if (reader != 0x11) goto label_2;       
            if(reader != 17)
            {
                goto label_2;
            }
            // 0x013030C4: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.JsonReader);
            // 0x013030C8: MOV x0, x19                | X0 = reader;//m1                        
            // 0x013030CC: LDP x9, x1, [x8, #0x190]   | X9 = typeof(Newtonsoft.Json.JsonReader).__il2cppRuntimeField_190; X1 = typeof(Newtonsoft.Json.JsonReader).__il2cppRuntimeField_198; //  | 
            // 0x013030D0: BLR x9                     | X0 = typeof(Newtonsoft.Json.JsonReader).__il2cppRuntimeField_190();
            // 0x013030D4: MOV x21, x0                | X21 = reader;//m1                       
            // 0x013030D8: CBZ x21, #0x1303128        | if (reader == null) goto label_3;       
            if(reader == null)
            {
                goto label_3;
            }
            // 0x013030DC: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x013030E0: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x013030E4: MOV x0, x21                | X0 = reader;//m1                        
            // 0x013030E8: LDR x20, [x8]              | X20 = typeof(System.Byte[]);            
            // 0x013030EC: MOV x1, x20                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x013030F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? reader, ????);     
            // 0x013030F4: MOV x19, x0                | X19 = reader;//m1                       
            val_7 = reader;
            // 0x013030F8: CBNZ x19, #0x130312c       | if (reader != null) goto label_4;       
            if(val_7 != null)
            {
                goto label_4;
            }
            // 0x013030FC: LDR x8, [x21]              | X8 = typeof(Newtonsoft.Json.JsonReader);
            // 0x01303100: MOV x1, x20                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x01303104: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.JsonReader.__il2cppRuntimeField_element_class;
            // 0x01303108: ADD x8, sp, #8             | X8 = (1152921513731525856 + 8) = 1152921513731525864 (0x100000021FDF8CE8);
            // 0x0130310C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Newtonsoft.Json.JsonReader.__il2cppRuntimeField_element_class, ????);
            // 0x01303110: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513731513920]
            // 0x01303114: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x01303118: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0130311C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x01303120: ADD x0, sp, #8             | X0 = (1152921513731525856 + 8) = 1152921513731525864 (0x100000021FDF8CE8);
            // 0x01303124: BL #0x299a140              | 
            label_3:
            // 0x01303128: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_4:
            // 0x0130312C: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x01303130: LDR x8, [x8, #0x6c0]       | X8 = 1152921504857485312;               
            // 0x01303134: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonObjectId);
            Newtonsoft.Json.Bson.BsonObjectId val_2 = null;
            // 0x01303138: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonObjectId), ????);
            // 0x0130313C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01303140: MOV x1, x19                | X1 = 0 (0x0);//ML01                     
            // 0x01303144: MOV x20, x0                | X20 = 1152921504857485312 (0x100000000EF07000);//ML01
            // 0x01303148: BL #0xad1da8               | .ctor(value:  val_7);                   
            val_2 = new Newtonsoft.Json.Bson.BsonObjectId(value:  val_7);
            // 0x0130314C: MOV x0, x20                | X0 = 1152921504857485312 (0x100000000EF07000);//ML01
            // 0x01303150: SUB sp, x29, #0x20         | SP = (1152921513731525904 - 32) = 1152921513731525872 (0x100000021FDF8CF0);
            // 0x01303154: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01303158: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0130315C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01303160: RET                        |  return (System.Object)typeof(Newtonsoft.Json.Bson.BsonObjectId);
            return (object)val_2;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_2:
            // 0x01303164: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x01303168: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x0130316C: MOV x21, x19               | X21 = reader;//m1                       
            // 0x01303170: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x01303174: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x01303178: TBZ w8, #0, #0x1303188     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x0130317C: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x01303180: CBNZ w8, #0x1303188        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x01303184: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_6:
            // 0x01303188: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0130318C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01303190: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_3 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x01303194: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x01303198: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x0130319C: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x013031A0: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x013031A4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x013031A8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x013031AC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x013031B0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x013031B4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x013031B8: MOV x8, x21                | X8 = reader;//m1                        
            // 0x013031BC: LDR x9, [x8]               | X9 = typeof(Newtonsoft.Json.JsonReader);
            // 0x013031C0: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x013031C4: MOV x0, x8                 | X0 = reader;//m1                        
            // 0x013031C8: LDP x10, x1, [x9, #0x180]  | X10 = typeof(Newtonsoft.Json.JsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.JsonReader).__il2cppRuntimeField_188; //  | 
            // 0x013031CC: BLR x10                    | X0 = typeof(Newtonsoft.Json.JsonReader).__il2cppRuntimeField_180();
            // 0x013031D0: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x013031D4: LDR x8, [x8, #0xb48]       | X8 = 1152921504860467200;               
            // 0x013031D8: STR w0, [sp, #4]           | stack[1152921513731525860] = reader;     //  dest_result_addr=1152921513731525860
            // 0x013031DC: ADD x1, sp, #4             | X1 = (1152921513731525856 + 4) = 1152921513731525860 (0x100000021FDF8CE4);
            // 0x013031E0: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonToken); 
            // 0x013031E4: MOV x0, x8                 | X0 = 1152921504860467200 (0x100000000F1DF000);//ML01
            // 0x013031E8: BL #0x27bc028              | X0 = 1152921513731590400 = (Il2CppObject*)Box((RuntimeClass*)typeof(Newtonsoft.Json.JsonToken), reader);
            // 0x013031EC: MOV x21, x0                | X21 = 1152921513731590400 (0x100000021FE08900);//ML01
            // 0x013031F0: CBNZ x20, #0x13031f8       | if ( != null) goto label_7;             
            if(null != null)
            {
                goto label_7;
            }
            // 0x013031F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? reader, ????);     
            label_7:
            // 0x013031F8: CBZ x21, #0x130321c        | if (reader == 0) goto label_9;          
            if(reader == 0)
            {
                goto label_9;
            }
            // 0x013031FC: LDR x8, [x20]              | X8 = ;                                  
            // 0x01303200: MOV x0, x21                | X0 = 1152921513731590400 (0x100000021FE08900);//ML01
            // 0x01303204: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01303208: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? reader, ????);     
            // 0x0130320C: CBNZ x0, #0x130321c        | if (reader != 0) goto label_9;          
            if(reader != 0)
            {
                goto label_9;
            }
            // 0x01303210: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? reader, ????);     
            // 0x01303214: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01303218: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? reader, ????);     
            label_9:
            // 0x0130321C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01303220: CBNZ w8, #0x1303230        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_10;
            // 0x01303224: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? reader, ????);     
            // 0x01303228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0130322C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? reader, ????);     
            label_10:
            // 0x01303230: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = reader;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = reader;
            // 0x01303234: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x01303238: LDR x8, [x8, #0xd40]       | X8 = (string**)(1152921513731508672)("Expected Bytes but got {0}.");
            // 0x0130323C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01303240: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01303244: MOV x2, x19                | X2 = val_3;//m1                         
            // 0x01303248: LDR x1, [x8]               | X1 = "Expected Bytes but got {0}.";     
            // 0x0130324C: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01303250: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Expected Bytes but got {0}.", args:  val_3);
            string val_4 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Expected Bytes but got {0}.", args:  val_3);
            // 0x01303254: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
            // 0x01303258: LDR x8, [x8, #0x7d8]       | X8 = 1152921504860147712;               
            // 0x0130325C: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x01303260: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonSerializationException);
            // 0x01303264: MOV x0, x8                 | X0 = 1152921504860147712 (0x100000000F191000);//ML01
            System.Exception val_5 = null;
            // 0x01303268: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonSerializationException), ????);
            // 0x0130326C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01303270: MOV x1, x19                | X1 = val_4;//m1                         
            // 0x01303274: MOV x20, x0                | X20 = 1152921504860147712 (0x100000000F191000);//ML01
            // 0x01303278: BL #0x1c32b48              | .ctor(message:  val_4);                 
            val_5 = new System.Exception(message:  val_4);
            // 0x0130327C: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x01303280: LDR x8, [x8, #0x498]       | X8 = 1152921513731512896;               
            // 0x01303284: MOV x0, x20                | X0 = 1152921504860147712 (0x100000000F191000);//ML01
            // 0x01303288: LDR x1, [x8]               | X1 = public System.Object Newtonsoft.Json.Converters.BsonObjectIdConverter::ReadJson(Newtonsoft.Json.JsonReader reader, System.Type objectType, object existingValue, Newtonsoft.Json.JsonSerializer serializer);
            // 0x0130328C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonSerializationException), ????);
            // 0x01303290: BL #0x13032b0              | X0 = CanConvert(objectType:  public System.Object Newtonsoft.Json.Converters.BsonObjectIdConverter::ReadJson(Newtonsoft.Json.JsonReader reader, System.Type objectType, object existingValue, Newtonsoft.Json.JsonSerializer serializer));
            bool val_6 = CanConvert(objectType:  public System.Object Newtonsoft.Json.Converters.BsonObjectIdConverter::ReadJson(Newtonsoft.Json.JsonReader reader, System.Type objectType, object existingValue, Newtonsoft.Json.JsonSerializer serializer));
            // 0x01303294: MOV x19, x0                | X19 = val_6;//m1                        
            // 0x01303298: ADD x0, sp, #8             | X0 = (1152921513731525856 + 8) = 1152921513731525864 (0x100000021FDF8CE8);
            // 0x0130329C: BL #0x299a140              | 
            // 0x013032A0: MOV x0, x19                | X0 = val_6;//m1                         
            // 0x013032A4: BL #0x980800               | X0 = sub_980800( ?? val_6, ????);       
        
        }
        //
        // Offset in libil2cpp.so: 0x013032B0 (19935920), len: 132  VirtAddr: 0x013032B0 RVA: 0x013032B0 token: 100684840 methodIndex: 47484 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool CanConvert(System.Type objectType)
        {
            //
            // Disasemble & Code
            // 0x013032B0: STP x20, x19, [sp, #-0x20]! | stack[1152921513731674752] = ???;  stack[1152921513731674760] = ???;  //  dest_result_addr=1152921513731674752 |  dest_result_addr=1152921513731674760
            // 0x013032B4: STP x29, x30, [sp, #0x10]  | stack[1152921513731674768] = ???;  stack[1152921513731674776] = ???;  //  dest_result_addr=1152921513731674768 |  dest_result_addr=1152921513731674776
            // 0x013032B8: ADD x29, sp, #0x10         | X29 = (1152921513731674752 + 16) = 1152921513731674768 (0x100000021FE1D290);
            // 0x013032BC: ADRP x20, #0x3736000       | X20 = 57892864 (0x3736000);             
            // 0x013032C0: LDRB w8, [x20, #0x902]     | W8 = (bool)static_value_03736902;       
            // 0x013032C4: MOV x19, x1                | X19 = objectType;//m1                   
            // 0x013032C8: TBNZ w8, #0, #0x13032e4    | if (static_value_03736902 == true) goto label_0;
            // 0x013032CC: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x013032D0: LDR x8, [x8, #0x3e0]       | X8 = 0x2B8F988;                         
            // 0x013032D4: LDR w0, [x8]               | W0 = 0x1526;                            
            // 0x013032D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1526, ????);     
            // 0x013032DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x013032E0: STRB w8, [x20, #0x902]     | static_value_03736902 = true;            //  dest_result_addr=57895170
            label_0:
            // 0x013032E4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x013032E8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x013032EC: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x013032F0: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x013032F4: LDR x8, [x8, #0xdc8]       | X8 = 1152921504857485312;               
            // 0x013032F8: LDR x20, [x8]              | X20 = typeof(Newtonsoft.Json.Bson.BsonObjectId);
            // 0x013032FC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01303300: TBZ w8, #0, #0x1303310     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01303304: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01303308: CBNZ w8, #0x1303310        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0130330C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01303310: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01303314: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01303318: MOV x1, x20                | X1 = 1152921504857485312 (0x100000000EF07000);//ML01
            // 0x0130331C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01303320: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01303324: CMP x0, x19                | STATE = COMPARE(val_1, objectType)      
            // 0x01303328: CSET w0, eq                | W0 = val_1 == objectType ? 1 : 0;       
            var val_2 = (val_1 == objectType) ? 1 : 0;
            // 0x0130332C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01303330: RET                        |  return (System.Boolean)val_1 == objectType ? 1 : 0;
            return (bool)val_2;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
    
    }

}
