using UnityEngine;

namespace Newtonsoft.Json.Utilities
{
    internal class Base64Encoder
    {
        // Fields
        private const int Base64LineSize = 76;
        private const int LineSizeInBytes = 57;
        private readonly char[] _charsLine; //  0x00000010
        private readonly System.IO.TextWriter _writer; //  0x00000018
        private byte[] _leftOverBytes; //  0x00000020
        private int _leftOverBytesCount; //  0x00000028
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x02911764 (43063140), len: 148  VirtAddr: 0x02911764 RVA: 0x02911764 token: 100686536 methodIndex: 49112 delegateWrapperIndex: 0 methodInvoker: 0
        public Base64Encoder(System.IO.TextWriter writer)
        {
            //
            // Disasemble & Code
            // 0x02911764: STP x22, x21, [sp, #-0x30]! | stack[1152921513959599920] = ???;  stack[1152921513959599928] = ???;  //  dest_result_addr=1152921513959599920 |  dest_result_addr=1152921513959599928
            // 0x02911768: STP x20, x19, [sp, #0x10]  | stack[1152921513959599936] = ???;  stack[1152921513959599944] = ???;  //  dest_result_addr=1152921513959599936 |  dest_result_addr=1152921513959599944
            // 0x0291176C: STP x29, x30, [sp, #0x20]  | stack[1152921513959599952] = ???;  stack[1152921513959599960] = ???;  //  dest_result_addr=1152921513959599952 |  dest_result_addr=1152921513959599960
            // 0x02911770: ADD x29, sp, #0x20         | X29 = (1152921513959599920 + 32) = 1152921513959599952 (0x100000022D77AF50);
            // 0x02911774: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x02911778: LDRB w8, [x21, #0xae9]     | W8 = (bool)static_value_037B8AE9;       
            // 0x0291177C: MOV x19, x1                | X19 = writer;//m1                       
            // 0x02911780: MOV x20, x0                | X20 = 1152921513959611968 (0x100000022D77DE40);//ML01
            // 0x02911784: TBNZ w8, #0, #0x29117a0    | if (static_value_037B8AE9 == true) goto label_0;
            // 0x02911788: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x0291178C: LDR x8, [x8, #0x1c8]       | X8 = 0x2B8EFDC;                         
            // 0x02911790: LDR w0, [x8]               | W0 = 0x12B9;                            
            // 0x02911794: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B9, ????);     
            // 0x02911798: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0291179C: STRB w8, [x21, #0xae9]     | static_value_037B8AE9 = true;            //  dest_result_addr=58428137
            label_0:
            // 0x029117A0: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x029117A4: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
            // 0x029117A8: LDR x21, [x8]              | X21 = typeof(System.Char[]);            
            // 0x029117AC: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x029117B0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
            // 0x029117B4: MOVZ w1, #0x4c             | W1 = 76 (0x4C);//ML01                   
            // 0x029117B8: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x029117BC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
            // 0x029117C0: STR x0, [x20, #0x10]       | this._charsLine = typeof(System.Char[]);  //  dest_result_addr=1152921513959611984
            this._charsLine = null;
            // 0x029117C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029117C8: MOV x0, x20                | X0 = 1152921513959611968 (0x100000022D77DE40);//ML01
            // 0x029117CC: BL #0x16f59f0              | this..ctor();                           
            // 0x029117D0: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x029117D4: LDR x8, [x8, #0x38]        | X8 = (string**)(1152921513884557040)("writer");
            // 0x029117D8: MOV x1, x19                | X1 = writer;//m1                        
            // 0x029117DC: LDR x2, [x8]               | X2 = "writer";                          
            // 0x029117E0: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  this, parameterName:  writer);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  this, parameterName:  writer);
            // 0x029117E4: STR x19, [x20, #0x18]      | this._writer = writer;                   //  dest_result_addr=1152921513959611992
            this._writer = writer;
            // 0x029117E8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x029117EC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x029117F0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x029117F4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x029117F8 (43063288), len: 944  VirtAddr: 0x029117F8 RVA: 0x029117F8 token: 100686537 methodIndex: 49113 delegateWrapperIndex: 0 methodInvoker: 0
        public void Encode(byte[] buffer, int index, int count)
        {
            //
            // Disasemble & Code
            //  | 
            var val_15;
            //  | 
            int val_16;
            //  | 
            int val_17;
            //  | 
            System.IO.TextWriter val_18;
            //  | 
            var val_19;
            //  | 
            System.ArgumentOutOfRangeException val_20;
            //  | 
            string val_21;
            //  | 
            System.TypeCode val_22;
            //  | 
            var val_23;
            // 0x029117F8: STP x28, x27, [sp, #-0x60]! | stack[1152921513960061056] = ???;  stack[1152921513960061064] = ???;  //  dest_result_addr=1152921513960061056 |  dest_result_addr=1152921513960061064
            // 0x029117FC: STP x26, x25, [sp, #0x10]  | stack[1152921513960061072] = ???;  stack[1152921513960061080] = ???;  //  dest_result_addr=1152921513960061072 |  dest_result_addr=1152921513960061080
            // 0x02911800: STP x24, x23, [sp, #0x20]  | stack[1152921513960061088] = ???;  stack[1152921513960061096] = ???;  //  dest_result_addr=1152921513960061088 |  dest_result_addr=1152921513960061096
            // 0x02911804: STP x22, x21, [sp, #0x30]  | stack[1152921513960061104] = ???;  stack[1152921513960061112] = ???;  //  dest_result_addr=1152921513960061104 |  dest_result_addr=1152921513960061112
            // 0x02911808: STP x20, x19, [sp, #0x40]  | stack[1152921513960061120] = ???;  stack[1152921513960061128] = ???;  //  dest_result_addr=1152921513960061120 |  dest_result_addr=1152921513960061128
            // 0x0291180C: STP x29, x30, [sp, #0x50]  | stack[1152921513960061136] = ???;  stack[1152921513960061144] = ???;  //  dest_result_addr=1152921513960061136 |  dest_result_addr=1152921513960061144
            // 0x02911810: ADD x29, sp, #0x50         | X29 = (1152921513960061056 + 80) = 1152921513960061136 (0x100000022D7EB8D0);
            // 0x02911814: ADRP x23, #0x37b8000       | X23 = 58425344 (0x37B8000);             
            // 0x02911818: LDRB w8, [x23, #0xaea]     | W8 = (bool)static_value_037B8AEA;       
            // 0x0291181C: MOV w22, w3                | W22 = count;//m1                        
            val_15 = count;
            // 0x02911820: MOV w19, w2                | W19 = index;//m1                        
            val_16 = index;
            // 0x02911824: MOV x21, x1                | X21 = buffer;//m1                       
            // 0x02911828: MOV x20, x0                | X20 = 1152921513960073152 (0x100000022D7EE7C0);//ML01
            // 0x0291182C: TBNZ w8, #0, #0x2911848    | if (static_value_037B8AEA == true) goto label_0;
            // 0x02911830: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x02911834: LDR x8, [x8, #0xe60]       | X8 = 0x2B8EFE0;                         
            // 0x02911838: LDR w0, [x8]               | W0 = 0x12BA;                            
            // 0x0291183C: BL #0x2782188              | X0 = sub_2782188( ?? 0x12BA, ????);     
            // 0x02911840: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02911844: STRB w8, [x23, #0xaea]     | static_value_037B8AEA = true;            //  dest_result_addr=58428138
            label_0:
            // 0x02911848: CBZ x21, #0x2911b3c        | if (buffer == null) goto label_1;       
            if(buffer == null)
            {
                goto label_1;
            }
            // 0x0291184C: TBNZ w19, #0x1f, #0x2911b68 | if ((index & 0x80000000) != 0) goto label_2;
            if((val_16 & 2147483648) != 0)
            {
                goto label_2;
            }
            // 0x02911850: TBNZ w22, #0x1f, #0x2911b20 | if ((count & 0x80000000) != 0) goto label_4;
            if((val_15 & 2147483648) != 0)
            {
                goto label_4;
            }
            // 0x02911854: LDR w8, [x21, #0x18]       | W8 = buffer.Length; //P2                
            int val_14 = buffer.Length;
            // 0x02911858: SUB w8, w8, w19            | W8 = (buffer.Length - index);           
            val_14 = val_14 - val_16;
            // 0x0291185C: CMP w8, w22                | STATE = COMPARE((buffer.Length - index), count)
            // 0x02911860: B.LT #0x2911b20            | if (buffer.Length < val_15) goto label_4;
            if(val_14 < val_15)
            {
                goto label_4;
            }
            // 0x02911864: LDR w23, [x20, #0x28]      | W23 = this._leftOverBytesCount; //P2    
            val_17 = this._leftOverBytesCount;
            // 0x02911868: CMP w23, #1                | STATE = COMPARE(this._leftOverBytesCount, 0x1)
            // 0x0291186C: B.LT #0x2911970            | if (val_17 < 1) goto label_5;           
            if(val_17 < 1)
            {
                goto label_5;
            }
            // 0x02911870: CMP w23, #2                | STATE = COMPARE(this._leftOverBytesCount, 0x2)
            // 0x02911874: B.GT #0x29118f8            | if (val_17 > 2) goto label_12;          
            if(val_17 > 2)
            {
                goto label_12;
            }
            // 0x02911878: SXTW x8, w23               | X8 = (long)(int)(this._leftOverBytesCount);
            // 0x0291187C: SUB x24, x8, #1            | X24 = ((long)(int)(this._leftOverBytesCount) - 1);
            var val_1 = (long)val_17 - 1;
            label_11:
            // 0x02911880: CMP w22, #0                | STATE = COMPARE(count, 0x0)             
            // 0x02911884: B.LE #0x29118f4            | if (val_15 <= 0) goto label_7;          
            if(val_15 <= 0)
            {
                goto label_7;
            }
            // 0x02911888: LDR w8, [x21, #0x18]       | W8 = buffer.Length; //P2                
            // 0x0291188C: LDR x25, [x20, #0x20]      | X25 = this._leftOverBytes; //P2         
            // 0x02911890: SXTW x26, w19              | X26 = (long)(int)(index);               
            // 0x02911894: CMP w19, w8                | STATE = COMPARE(index, buffer.Length)   
            // 0x02911898: B.LO #0x29118a8            | if (val_16 < buffer.Length) goto label_8;
            if(val_16 < buffer.Length)
            {
                goto label_8;
            }
            // 0x0291189C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x12BA, ????);     
            // 0x029118A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029118A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x12BA, ????);     
            label_8:
            // 0x029118A8: ADD x8, x21, x26           | X8 = buffer[(long)(int)(index)]; //PARR1 
            // 0x029118AC: LDRB w26, [x8, #0x20]      | W26 = buffer[(long)(int)(index)][0]     
            byte val_15 = buffer[(long)val_16];
            // 0x029118B0: CBNZ x25, #0x29118b8       | if (this._leftOverBytes != null) goto label_9;
            if(this._leftOverBytes != null)
            {
                goto label_9;
            }
            // 0x029118B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12BA, ????);     
            label_9:
            // 0x029118B8: LDR w8, [x25, #0x18]       | W8 = this._leftOverBytes.Length; //P2   
            // 0x029118BC: ADD w19, w19, #1           | W19 = (index + 1);                      
            val_16 = val_16 + 1;
            // 0x029118C0: CMP w23, w8                | STATE = COMPARE(this._leftOverBytesCount, this._leftOverBytes.Length)
            // 0x029118C4: B.LO #0x29118d4            | if (val_17 < this._leftOverBytes.Length) goto label_10;
            if(val_17 < this._leftOverBytes.Length)
            {
                goto label_10;
            }
            // 0x029118C8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x12BA, ????);     
            // 0x029118CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029118D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x12BA, ????);     
            label_10:
            // 0x029118D4: ADD x8, x25, x24           | X8 = this._leftOverBytes[((long)(int)(this._leftOverBytesCount) - 1)]; //PARR1 
            // 0x029118D8: SUB w22, w22, #1           | W22 = (count - 1);                      
            val_15 = val_15 - 1;
            // 0x029118DC: ADD w23, w23, #1           | W23 = (this._leftOverBytesCount + 1);   
            val_17 = val_17 + 1;
            // 0x029118E0: ADD x24, x24, #1           | X24 = (((long)(int)(this._leftOverBytesCount) - 1) + 1);
            val_1 = val_1 + 1;
            // 0x029118E4: STRB w26, [x8, #0x21]      | this._leftOverBytes[((long)(int)(this._leftOverBytesCount) - 1)][1] = buffer[(long)(int)(index)][0];  //  dest_result_addr=0
            this._leftOverBytes[val_1] = val_15;
            // 0x029118E8: CMP x24, #1                | STATE = COMPARE((((long)(int)(this._leftOverBytesCount) - 1) + 1), 0x1)
            // 0x029118EC: B.LE #0x2911880            | if (val_1 <= 0x1) goto label_11;        
            if(val_1 <= 1)
            {
                goto label_11;
            }
            // 0x029118F0: B #0x29118f8               |  goto label_12;                         
            goto label_12;
            label_7:
            // 0x029118F4: CBZ w22, #0x2911b18        | if (count == 0) goto label_13;          
            if(val_15 == 0)
            {
                goto label_13;
            }
            label_12:
            // 0x029118F8: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x029118FC: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x02911900: LDR x24, [x20, #0x20]      | X24 = this._leftOverBytes; //P2         
            // 0x02911904: LDR x23, [x20, #0x10]      | X23 = this._charsLine; //P2             
            // 0x02911908: LDR x0, [x8]               | X0 = typeof(System.Convert);            
            // 0x0291190C: LDRB w8, [x0, #0x10a]      | W8 = System.Convert.__il2cppRuntimeField_10A;
            // 0x02911910: TBZ w8, #0, #0x2911920     | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x02911914: LDR w8, [x0, #0xbc]        | W8 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x02911918: CBNZ w8, #0x2911920        | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x0291191C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_15:
            // 0x02911920: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02911924: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x02911928: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x0291192C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x02911930: ORR w3, wzr, #3            | W3 = 3(0x3);                            
            // 0x02911934: MOV x1, x24                | X1 = this._leftOverBytes;//m1           
            // 0x02911938: MOV x4, x23                | X4 = this._charsLine;//m1               
            // 0x0291193C: BL #0x1ba2058              | X0 = System.Convert.ToBase64CharArray(inArray:  0, offsetIn:  this._leftOverBytes, length:  0, outArray:  3, offsetOut:  this._charsLine);
            int val_2 = System.Convert.ToBase64CharArray(inArray:  0, offsetIn:  this._leftOverBytes, length:  0, outArray:  3, offsetOut:  this._charsLine);
            // 0x02911940: LDP x23, x25, [x20, #0x10] | X23 = this._charsLine; //P2  X25 = this._writer; //P2  //  | 
            val_17 = this._charsLine;
            val_18 = this._writer;
            // 0x02911944: MOV w24, w0                | W24 = val_2;//m1                        
            // 0x02911948: CBNZ x25, #0x2911950       | if (this._writer != null) goto label_16;
            if(val_18 != null)
            {
                goto label_16;
            }
            // 0x0291194C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_16:
            // 0x02911950: LDR x8, [x25]              | X8 = typeof(System.IO.TextWriter);      
            // 0x02911954: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x02911958: MOV x0, x25                | X0 = this._writer;//m1                  
            // 0x0291195C: MOV x1, x23                | X1 = this._charsLine;//m1               
            // 0x02911960: LDR x9, [x8, #0x230]       | X9 = typeof(System.IO.TextWriter).__il2cppRuntimeField_230;
            // 0x02911964: LDR x4, [x8, #0x238]       | X4 = typeof(System.IO.TextWriter).__il2cppRuntimeField_238;
            // 0x02911968: MOV w3, w24                | W3 = val_2;//m1                         
            // 0x0291196C: BLR x9                     | X0 = typeof(System.IO.TextWriter).__il2cppRuntimeField_230();
            label_5:
            // 0x02911970: MOVZ w9, #0x5555, lsl #16  | W9 = 1431633920 (0x55550000);//ML01     
            // 0x02911974: SXTW x8, w22               | X8 = (long)(int)(count);                
            var val_16 = (long)val_15;
            // 0x02911978: MOVK w9, #0x5556           | W9 = 1431655766 (0x55555556);           
            // 0x0291197C: MUL x8, x8, x9             | X8 = ((long)(int)(count) * 1431655766); 
            val_16 = val_16 * 1431655766;
            // 0x02911980: LSR x9, x8, #0x3f          | X9 = (((long)(int)(count) * 1431655766) >> 63);
            var val_3 = val_16 >> 63;
            // 0x02911984: LSR x8, x8, #0x20          | X8 = (((long)(int)(count) * 1431655766) >> 32);
            val_16 = val_16 >> 32;
            // 0x02911988: ADD w8, w8, w9             | W8 = ((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63));
            val_16 = val_16 + val_3;
            // 0x0291198C: ADD w8, w8, w8, lsl #1     | W8 = (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + ((((
            val_16 = val_16 + (val_16 << 1);
            // 0x02911990: SUB w26, w22, w8           | W26 = (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 6
            int val_4 = val_15 - val_16;
            // 0x02911994: STR w26, [x20, #0x28]      | this._leftOverBytesCount = (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63))) << 1));  //  dest_result_addr=1152921513960073192
            this._leftOverBytesCount = val_4;
            // 0x02911998: CMP w26, #1                | STATE = COMPARE((count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63))) << 1)), 0x1)
            // 0x0291199C: B.LT #0x2911a5c            | if (val_4 < 1) goto label_17;           
            if(val_4 < 1)
            {
                goto label_17;
            }
            // 0x029119A0: LDR x23, [x20, #0x20]      | X23 = this._leftOverBytes; //P2         
            val_17 = this._leftOverBytes;
            // 0x029119A4: SUB w24, w22, w26          | W24 = (count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655
            int val_5 = val_15 - val_4;
            // 0x029119A8: CBNZ x23, #0x29119e0       | if (this._leftOverBytes != null) goto label_18;
            if(val_17 != null)
            {
                goto label_18;
            }
            // 0x029119AC: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x029119B0: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x029119B4: LDR x23, [x8]              | X23 = typeof(System.Byte[]);            
            // 0x029119B8: MOV x0, x23                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x029119BC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x029119C0: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x029119C4: MOV x0, x23                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x029119C8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x029119CC: LDR w8, [x20, #0x28]       | W8 = this._leftOverBytesCount; //P2     
            // 0x029119D0: MOV x23, x0                | X23 = 1152921504996170800 (0x1000000017349C30);//ML01
            val_17 = null;
            // 0x029119D4: STR x23, [x20, #0x20]      | this._leftOverBytes = typeof(System.Byte[]);  //  dest_result_addr=1152921513960073184
            this._leftOverBytes = val_17;
            // 0x029119D8: CMP w8, #1                 | STATE = COMPARE(this._leftOverBytesCount, 0x1)
            // 0x029119DC: B.LT #0x2911a58            | if (this._leftOverBytesCount < 1) goto label_19;
            if(this._leftOverBytesCount < 1)
            {
                goto label_19;
            }
            label_18:
            // 0x029119E0: ADD w8, w19, w22           | W8 = (index + count);                   
            int val_6 = val_16 + val_15;
            // 0x029119E4: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            // 0x029119E8: SUB w22, w8, w26           | W22 = ((index + count) - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count)
            val_15 = val_6 - val_4;
            // 0x029119EC: B #0x29119f4               |  goto label_20;                         
            goto label_20;
            label_24:
            // 0x029119F0: LDR x23, [x20, #0x20]      | X23 = this._leftOverBytes; //P2         
            val_17 = this._leftOverBytes;
            label_20:
            // 0x029119F4: LDR w8, [x21, #0x18]       | W8 = buffer.Length; //P2                
            // 0x029119F8: ADD w9, w22, w25           | W9 = (((index + count) - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count)
            val_3 = val_15 + 0;
            // 0x029119FC: SXTW x26, w9               | X26 = (long)(int)((((index + count) - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766));
            // 0x02911A00: CMP w9, w8                 | STATE = COMPARE((((index + count) - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766), buffer.Length)
            // 0x02911A04: B.LO #0x2911a14            | if (val_3 < buffer.Length) goto label_21;
            if(val_3 < buffer.Length)
            {
                goto label_21;
            }
            // 0x02911A08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x02911A0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02911A10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_21:
            // 0x02911A14: ADD x8, x21, x26           | X8 = buffer[(long)(int)((((index + count) - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766))]; //PARR1 
            // 0x02911A18: LDRB w26, [x8, #0x20]      | W26 = buffer[(long)(int)((((index + count) - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766))][0]
            byte val_17 = buffer[(long)val_3];
            // 0x02911A1C: CBNZ x23, #0x2911a24       | if (this._leftOverBytes != null) goto label_22;
            if(val_17 != null)
            {
                goto label_22;
            }
            // 0x02911A20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_22:
            // 0x02911A24: LDR w8, [x23, #0x18]       | W8 = this._leftOverBytes.Length; //P2   
            // 0x02911A28: SXTW x27, w25              | X27 = 0 (0x00000000);                   
            val_19 = 0;
            // 0x02911A2C: CMP w25, w8                | STATE = COMPARE(0x0, this._leftOverBytes.Length)
            // 0x02911A30: B.LO #0x2911a40            | if (0 < this._leftOverBytes.Length) goto label_23;
            if(0 < this._leftOverBytes.Length)
            {
                goto label_23;
            }
            // 0x02911A34: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x02911A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02911A3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_23:
            // 0x02911A40: ADD x8, x23, x27           | X8 = this._leftOverBytes[0x0]; //PARR1  
            // 0x02911A44: STRB w26, [x8, #0x20]      | this._leftOverBytes[0x0][0] = buffer[(long)(int)((((index + count) - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766))][0];  //  dest_result_addr=0
            val_17[val_19] = val_17;
            // 0x02911A48: LDR w8, [x20, #0x28]       | W8 = this._leftOverBytesCount; //P2     
            // 0x02911A4C: ADD w25, w25, #1           | W25 = (0 + 1);                          
            val_18 = 0 + 1;
            // 0x02911A50: CMP w25, w8                | STATE = COMPARE((0 + 1), this._leftOverBytesCount)
            // 0x02911A54: B.LT #0x29119f0            | if (val_18 < this._leftOverBytesCount) goto label_24;
            if(val_18 < this._leftOverBytesCount)
            {
                goto label_24;
            }
            label_19:
            // 0x02911A58: MOV w22, w24               | W22 = (count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63))) <;//m1
            val_15 = val_5;
            label_17:
            // 0x02911A5C: ADD w26, w22, w19          | W26 = ((count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 143165
            int val_7 = val_15 + val_16;
            // 0x02911A60: CMP w26, w19               | STATE = COMPARE(((count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63))) , index)
            // 0x02911A64: B.LE #0x2911afc            | if (val_7 <= val_16) goto label_30;     
            if(val_7 <= val_16)
            {
                goto label_30;
            }
            // 0x02911A68: ADRP x27, #0x3663000       | X27 = 57028608 (0x3663000);             
            // 0x02911A6C: LDR x27, [x27, #0xb48]     | X27 = 1152921504652587008;              
            val_19 = 1152921504652587008;
            // 0x02911A70: MOVZ w22, #0x39            | W22 = 57 (0x39);//ML01                  
            label_29:
            // 0x02911A74: LDR x0, [x27]              | X0 = typeof(System.Convert);            
            // 0x02911A78: LDR x23, [x20, #0x10]      | X23 = this._charsLine; //P2             
            // 0x02911A7C: ADD w8, w19, w22           | W8 = (index + 57);                      
            int val_8 = val_16 + 57;
            // 0x02911A80: SUB w10, w26, w19          | W10 = (((count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 14316
            int val_9 = val_7 - val_16;
            // 0x02911A84: LDRB w9, [x0, #0x10a]      | W9 = System.Convert.__il2cppRuntimeField_10A;
            // 0x02911A88: CMP w8, w26                | STATE = COMPARE((index + 57), ((count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63))) )
            // 0x02911A8C: CSEL w22, w10, w22, gt     | W22 = val_8 > val_7 ? (((count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63))) : 57;
            System.Char[] val_10 = (val_8 > val_7) ? (val_9) : 57;
            // 0x02911A90: TBZ w9, #0, #0x2911aa0     | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_27;
            // 0x02911A94: LDR w8, [x0, #0xbc]        | W8 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x02911A98: CBNZ w8, #0x2911aa0        | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x02911A9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_27:
            // 0x02911AA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02911AA4: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x02911AA8: MOV x1, x21                | X1 = buffer;//m1                        
            // 0x02911AAC: MOV w2, w19                | W2 = index;//m1                         
            // 0x02911AB0: MOV w3, w22                | W3 = val_8 > val_7 ? (((count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63))) : 57;//m1
            // 0x02911AB4: MOV x4, x23                | X4 = this._charsLine;//m1               
            // 0x02911AB8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x02911ABC: BL #0x1ba2058              | X0 = System.Convert.ToBase64CharArray(inArray:  0, offsetIn:  buffer, length:  val_16, outArray:  val_10, offsetOut:  this._charsLine);
            int val_11 = System.Convert.ToBase64CharArray(inArray:  0, offsetIn:  buffer, length:  val_16, outArray:  val_10, offsetOut:  this._charsLine);
            // 0x02911AC0: LDP x23, x25, [x20, #0x10] | X23 = this._charsLine; //P2  X25 = this._writer; //P2  //  | 
            val_17 = this._charsLine;
            val_18 = this._writer;
            // 0x02911AC4: MOV w24, w0                | W24 = val_11;//m1                       
            // 0x02911AC8: CBNZ x25, #0x2911ad0       | if (this._writer != null) goto label_28;
            if(val_18 != null)
            {
                goto label_28;
            }
            // 0x02911ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_28:
            // 0x02911AD0: LDR x8, [x25]              | X8 = typeof(System.IO.TextWriter);      
            // 0x02911AD4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x02911AD8: MOV x0, x25                | X0 = this._writer;//m1                  
            // 0x02911ADC: MOV x1, x23                | X1 = this._charsLine;//m1               
            // 0x02911AE0: LDR x9, [x8, #0x230]       | X9 = typeof(System.IO.TextWriter).__il2cppRuntimeField_230;
            // 0x02911AE4: LDR x4, [x8, #0x238]       | X4 = typeof(System.IO.TextWriter).__il2cppRuntimeField_238;
            // 0x02911AE8: MOV w3, w24                | W3 = val_11;//m1                        
            // 0x02911AEC: BLR x9                     | X0 = typeof(System.IO.TextWriter).__il2cppRuntimeField_230();
            // 0x02911AF0: ADD w19, w22, w19          | W19 = (val_8 > val_7 ? (((count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(in
            val_16 = val_10 + val_16;
            // 0x02911AF4: CMP w26, w19               | STATE = COMPARE(((count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63))) , (val_8 > val_7 ? (((count - (count - (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 1431655766) >> 63)) + (((((long)(int)(count) * 1431655766) >> 32) + (((long)(int)(count) * 143)
            // 0x02911AF8: B.GT #0x2911a74            | if (val_7 > val_16) goto label_29;      
            if(val_7 > val_16)
            {
                goto label_29;
            }
            label_30:
            // 0x02911AFC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x02911B00: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x02911B04: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x02911B08: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x02911B0C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x02911B10: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x02911B14: RET                        |  return;                                
            return;
            label_13:
            // 0x02911B18: STR w23, [x20, #0x28]      | this._leftOverBytesCount = this._leftOverBytesCount;  //  dest_result_addr=1152921513960073192
            this._leftOverBytesCount = val_17;
            // 0x02911B1C: B #0x2911afc               |  goto label_30;                         
            goto label_30;
            label_4:
            // 0x02911B20: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x02911B24: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x02911B28: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            val_20 = null;
            // 0x02911B2C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x02911B30: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x02911B34: LDR x8, [x8, #0xd0]        | X8 = (string**)(1152921509734373472)("count");
            val_21 = "count";
            // 0x02911B38: B #0x2911b80               |  goto label_31;                         
            goto label_31;
            label_1:
            // 0x02911B3C: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x02911B40: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x02911B44: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_12 = null;
            // 0x02911B48: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x02911B4C: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x02911B50: LDR x8, [x8, #0x500]       | X8 = (string**)(1152921509639236256)("buffer");
            // 0x02911B54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_22 = 0;
            // 0x02911B58: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            val_23 = val_12;
            // 0x02911B5C: LDR x1, [x8]               | X1 = "buffer";                          
            // 0x02911B60: BL #0x18b3df0              | .ctor(paramName:  "buffer");            
            val_12 = new System.ArgumentNullException(paramName:  "buffer");
            // 0x02911B64: B #0x2911b90               |  goto label_32;                         
            goto label_32;
            label_2:
            // 0x02911B68: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x02911B6C: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x02911B70: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            val_20 = null;
            // 0x02911B74: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x02911B78: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x02911B7C: LDR x8, [x8, #0x158]       | X8 = (string**)(1152921510064361328)("index");
            val_21 = "index";
            label_31:
            // 0x02911B80: LDR x1, [x8]               | X1 = "index";                           
            // 0x02911B84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_22 = 0;
            // 0x02911B88: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            val_23 = val_20;
            // 0x02911B8C: BL #0x18b81ac              | .ctor(paramName:  val_21 = "index");    
            val_20 = new System.ArgumentOutOfRangeException(paramName:  val_21);
            label_32:
            // 0x02911B90: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x02911B94: LDR x8, [x8, #0x318]       | X8 = 1152921513960044032;               
            // 0x02911B98: MOV x0, x19                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x02911B9C: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Utilities.Base64Encoder::Encode(byte[] buffer, int index, int count);
            // 0x02911BA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x02911BA4: BL #0x28fffbc              | X0 = Convert(value:  public System.Void Newtonsoft.Json.Utilities.Base64Encoder::Encode(byte[] buffer, int index, int count), typeCode:  val_22 = 0);
            object val_13 = Convert(value:  public System.Void Newtonsoft.Json.Utilities.Base64Encoder::Encode(byte[] buffer, int index, int count), typeCode:  val_22);
        
        }
        //
        // Offset in libil2cpp.so: 0x02911BFC (43064316), len: 208  VirtAddr: 0x02911BFC RVA: 0x02911BFC token: 100686538 methodIndex: 49114 delegateWrapperIndex: 0 methodInvoker: 0
        public void Flush()
        {
            //
            // Disasemble & Code
            // 0x02911BFC: STP x22, x21, [sp, #-0x30]! | stack[1152921513960631856] = ???;  stack[1152921513960631864] = ???;  //  dest_result_addr=1152921513960631856 |  dest_result_addr=1152921513960631864
            // 0x02911C00: STP x20, x19, [sp, #0x10]  | stack[1152921513960631872] = ???;  stack[1152921513960631880] = ???;  //  dest_result_addr=1152921513960631872 |  dest_result_addr=1152921513960631880
            // 0x02911C04: STP x29, x30, [sp, #0x20]  | stack[1152921513960631888] = ???;  stack[1152921513960631896] = ???;  //  dest_result_addr=1152921513960631888 |  dest_result_addr=1152921513960631896
            // 0x02911C08: ADD x29, sp, #0x20         | X29 = (1152921513960631856 + 32) = 1152921513960631888 (0x100000022D876E50);
            // 0x02911C0C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x02911C10: LDRB w8, [x20, #0xaeb]     | W8 = (bool)static_value_037B8AEB;       
            // 0x02911C14: MOV x19, x0                | X19 = 1152921513960643904 (0x100000022D879D40);//ML01
            // 0x02911C18: TBNZ w8, #0, #0x2911c34    | if (static_value_037B8AEB == true) goto label_0;
            // 0x02911C1C: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x02911C20: LDR x8, [x8, #0xfb0]       | X8 = 0x2B8EFE4;                         
            // 0x02911C24: LDR w0, [x8]               | W0 = 0x12BB;                            
            // 0x02911C28: BL #0x2782188              | X0 = sub_2782188( ?? 0x12BB, ????);     
            // 0x02911C2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02911C30: STRB w8, [x20, #0xaeb]     | static_value_037B8AEB = true;            //  dest_result_addr=58428139
            label_0:
            // 0x02911C34: LDR w20, [x19, #0x28]      | W20 = this._leftOverBytesCount; //P2    
            // 0x02911C38: CMP w20, #1                | STATE = COMPARE(this._leftOverBytesCount, 0x1)
            // 0x02911C3C: B.LT #0x2911cbc            | if (this._leftOverBytesCount < 1) goto label_1;
            if(this._leftOverBytesCount < 1)
            {
                goto label_1;
            }
            // 0x02911C40: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x02911C44: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x02911C48: LDR x22, [x19, #0x20]      | X22 = this._leftOverBytes; //P2         
            // 0x02911C4C: LDR x21, [x19, #0x10]      | X21 = this._charsLine; //P2             
            // 0x02911C50: LDR x0, [x8]               | X0 = typeof(System.Convert);            
            // 0x02911C54: LDRB w8, [x0, #0x10a]      | W8 = System.Convert.__il2cppRuntimeField_10A;
            // 0x02911C58: TBZ w8, #0, #0x2911c68     | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x02911C5C: LDR w8, [x0, #0xbc]        | W8 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x02911C60: CBNZ w8, #0x2911c68        | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x02911C64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_3:
            // 0x02911C68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02911C6C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x02911C70: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x02911C74: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x02911C78: MOV x1, x22                | X1 = this._leftOverBytes;//m1           
            // 0x02911C7C: MOV w3, w20                | W3 = this._leftOverBytesCount;//m1      
            // 0x02911C80: MOV x4, x21                | X4 = this._charsLine;//m1               
            // 0x02911C84: BL #0x1ba2058              | X0 = System.Convert.ToBase64CharArray(inArray:  0, offsetIn:  this._leftOverBytes, length:  0, outArray:  this._leftOverBytesCount, offsetOut:  this._charsLine);
            int val_1 = System.Convert.ToBase64CharArray(inArray:  0, offsetIn:  this._leftOverBytes, length:  0, outArray:  this._leftOverBytesCount, offsetOut:  this._charsLine);
            // 0x02911C88: LDP x20, x22, [x19, #0x10] | X20 = this._charsLine; //P2  X22 = this._writer; //P2  //  | 
            // 0x02911C8C: MOV w21, w0                | W21 = val_1;//m1                        
            // 0x02911C90: CBNZ x22, #0x2911c98       | if (this._writer != null) goto label_4; 
            if(this._writer != null)
            {
                goto label_4;
            }
            // 0x02911C94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x02911C98: LDR x8, [x22]              | X8 = typeof(System.IO.TextWriter);      
            // 0x02911C9C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x02911CA0: MOV x0, x22                | X0 = this._writer;//m1                  
            // 0x02911CA4: MOV x1, x20                | X1 = this._charsLine;//m1               
            // 0x02911CA8: LDR x9, [x8, #0x230]       | X9 = typeof(System.IO.TextWriter).__il2cppRuntimeField_230;
            // 0x02911CAC: LDR x4, [x8, #0x238]       | X4 = typeof(System.IO.TextWriter).__il2cppRuntimeField_238;
            // 0x02911CB0: MOV w3, w21                | W3 = val_1;//m1                         
            // 0x02911CB4: BLR x9                     | X0 = typeof(System.IO.TextWriter).__il2cppRuntimeField_230();
            // 0x02911CB8: STR wzr, [x19, #0x28]      | this._leftOverBytesCount = 0;            //  dest_result_addr=1152921513960643944
            this._leftOverBytesCount = 0;
            label_1:
            // 0x02911CBC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02911CC0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02911CC4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x02911CC8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x02911BA8 (43064232), len: 84  VirtAddr: 0x02911BA8 RVA: 0x02911BA8 token: 100686539 methodIndex: 49115 delegateWrapperIndex: 0 methodInvoker: 0
        private void WriteChars(char[] chars, int index, int count)
        {
            //
            // Disasemble & Code
            // 0x02911BA8: STP x22, x21, [sp, #-0x30]! | stack[1152921513960899504] = ???;  stack[1152921513960899512] = ???;  //  dest_result_addr=1152921513960899504 |  dest_result_addr=1152921513960899512
            // 0x02911BAC: STP x20, x19, [sp, #0x10]  | stack[1152921513960899520] = ???;  stack[1152921513960899528] = ???;  //  dest_result_addr=1152921513960899520 |  dest_result_addr=1152921513960899528
            // 0x02911BB0: STP x29, x30, [sp, #0x20]  | stack[1152921513960899536] = ???;  stack[1152921513960899544] = ???;  //  dest_result_addr=1152921513960899536 |  dest_result_addr=1152921513960899544
            // 0x02911BB4: ADD x29, sp, #0x20         | X29 = (1152921513960899504 + 32) = 1152921513960899536 (0x100000022D8B83D0);
            // 0x02911BB8: LDR x21, [x0, #0x18]       | X21 = this._writer; //P2                
            // 0x02911BBC: MOV w19, w3                | W19 = count;//m1                        
            // 0x02911BC0: MOV w20, w2                | W20 = index;//m1                        
            // 0x02911BC4: MOV x22, x1                | X22 = chars;//m1                        
            // 0x02911BC8: CBNZ x21, #0x2911bd0       | if (this._writer != null) goto label_0; 
            if(this._writer != null)
            {
                goto label_0;
            }
            // 0x02911BCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x02911BD0: LDR x8, [x21]              | X8 = typeof(System.IO.TextWriter);      
            // 0x02911BD4: MOV w2, w20                | W2 = index;//m1                         
            // 0x02911BD8: MOV w3, w19                | W3 = count;//m1                         
            // 0x02911BDC: MOV x0, x21                | X0 = this._writer;//m1                  
            // 0x02911BE0: LDR x5, [x8, #0x230]       | X5 = typeof(System.IO.TextWriter).__il2cppRuntimeField_230;
            // 0x02911BE4: LDR x4, [x8, #0x238]       | X4 = typeof(System.IO.TextWriter).__il2cppRuntimeField_238;
            // 0x02911BE8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02911BEC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02911BF0: MOV x1, x22                | X1 = chars;//m1                         
            // 0x02911BF4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x02911BF8: BR x5                      | goto typeof(System.IO.TextWriter).__il2cppRuntimeField_230;
            goto typeof(System.IO.TextWriter).__il2cppRuntimeField_230;
        
        }
    
    }

}
