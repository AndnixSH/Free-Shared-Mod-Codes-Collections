using UnityEngine;
public class CSArenaInterServiceData
{
    // Fields
    public CSAISPlayerData enemyPlayerData; //  0x00000010
    public CSAISPlayerData ourPlayerData; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B44A4C (11815500), len: 8  VirtAddr: 0x00B44A4C RVA: 0x00B44A4C token: 100693354 methodIndex: 26673 delegateWrapperIndex: 0 methodInvoker: 0
    public CSArenaInterServiceData()
    {
        //
        // Disasemble & Code
        // 0x00B44A4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B44A50: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B44A54 (11815508), len: 392  VirtAddr: 0x00B44A54 RVA: 0x00B44A54 token: 100693355 methodIndex: 26674 delegateWrapperIndex: 0 methodInvoker: 0
    public void LoadData(string jsonStr)
    {
        //
        // Disasemble & Code
        // 0x00B44A54: STP x22, x21, [sp, #-0x30]! | stack[1152921514979093616] = ???;  stack[1152921514979093624] = ???;  //  dest_result_addr=1152921514979093616 |  dest_result_addr=1152921514979093624
        // 0x00B44A58: STP x20, x19, [sp, #0x10]  | stack[1152921514979093632] = ???;  stack[1152921514979093640] = ???;  //  dest_result_addr=1152921514979093632 |  dest_result_addr=1152921514979093640
        // 0x00B44A5C: STP x29, x30, [sp, #0x20]  | stack[1152921514979093648] = ???;  stack[1152921514979093656] = ???;  //  dest_result_addr=1152921514979093648 |  dest_result_addr=1152921514979093656
        // 0x00B44A60: ADD x29, sp, #0x20         | X29 = (1152921514979093616 + 32) = 1152921514979093648 (0x100000026A3BEC90);
        // 0x00B44A64: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B44A68: LDRB w8, [x21, #0x7fa]     | W8 = (bool)static_value_037337FA;       
        // 0x00B44A6C: MOV x20, x1                | X20 = jsonStr;//m1                      
        // 0x00B44A70: MOV x19, x0                | X19 = 1152921514979105664 (0x100000026A3C1B80);//ML01
        // 0x00B44A74: TBNZ w8, #0, #0xb44a90     | if (static_value_037337FA == true) goto label_0;
        // 0x00B44A78: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
        // 0x00B44A7C: LDR x8, [x8, #0x8c8]       | X8 = 0x2B92F80;                         
        // 0x00B44A80: LDR w0, [x8]               | W0 = 0x22A5;                            
        // 0x00B44A84: BL #0x2782188              | X0 = sub_2782188( ?? 0x22A5, ????);     
        // 0x00B44A88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B44A8C: STRB w8, [x21, #0x7fa]     | static_value_037337FA = true;            //  dest_result_addr=57882618
        label_0:
        // 0x00B44A90: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
        // 0x00B44A94: LDR x8, [x8, #0x9c8]       | X8 = 1152921504859615232;               
        // 0x00B44A98: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonConvert);
        // 0x00B44A9C: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_10A;
        // 0x00B44AA0: TBZ w8, #0, #0xb44ab0      | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B44AA4: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished;
        // 0x00B44AA8: CBNZ w8, #0xb44ab0         | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B44AAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.JsonConvert), ????);
        label_2:
        // 0x00B44AB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B44AB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B44AB8: MOV x1, x20                | X1 = jsonStr;//m1                       
        // 0x00B44ABC: BL #0x1311974              | X0 = Newtonsoft.Json.JsonConvert.DeserializeObject(value:  0);
        object val_1 = Newtonsoft.Json.JsonConvert.DeserializeObject(value:  0);
        // 0x00B44AC0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B44AC4: CBZ x20, #0xb44afc         | if (val_1 == null) goto label_4;        
        if(val_1 == null)
        {
            goto label_4;
        }
        // 0x00B44AC8: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x00B44ACC: LDR x8, [x8, #0x5f0]       | X8 = 1152921504861265920;               
        // 0x00B44AD0: LDR x9, [x20]              | X9 = typeof(System.Object);             
        // 0x00B44AD4: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Linq.JObject);
        // 0x00B44AD8: LDRB w11, [x9, #0x104]     | W11 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x00B44ADC: LDRB w10, [x8, #0x104]     | W10 = Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x00B44AE0: CMP w11, w10               | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth)
        // 0x00B44AE4: B.LO #0xb44afc             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
        // 0x00B44AE8: LDR x9, [x9, #0xb0]        | X9 = System.Object.__il2cppRuntimeField_typeHierarchy;
        // 0x00B44AEC: ADD x9, x9, x10, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRunti
        // 0x00B44AF0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
        // 0x00B44AF4: CMP x9, x8                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Linq.JObject))
        // 0x00B44AF8: B.EQ #0xb44b98             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
        label_4:
        // 0x00B44AFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        // 0x00B44B00: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00B44B04: LDR x8, [x8, #0x7d8]       | X8 = (string**)(1152921510261100048)("enemyPlayerData");
        // 0x00B44B08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B44B0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B44B10: LDR x1, [x8]               | X1 = "enemyPlayerData";                 
        // 0x00B44B14: BL #0x2925c6c              | X0 = 0.get_Item(propertyName:  "enemyPlayerData");
        Newtonsoft.Json.Linq.JToken val_2 = 0.Item["enemyPlayerData"];
        // 0x00B44B18: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B44B1C: LDR x8, [x8, #0xd70]       | X8 = 1152921504904503296;               
        // 0x00B44B20: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B44B24: LDR x8, [x8]               | X8 = typeof(CSAISPlayerData);           
        // 0x00B44B28: MOV x0, x8                 | X0 = 1152921504904503296 (0x1000000011BDE000);//ML01
        CSAISPlayerData val_3 = null;
        // 0x00B44B2C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CSAISPlayerData), ????);
        // 0x00B44B30: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00B44B34: MOV x21, x0                | X21 = 1152921504904503296 (0x1000000011BDE000);//ML01
        // 0x00B44B38: BL #0xb43384               | .ctor(jToken:  val_2);                  
        val_3 = new CSAISPlayerData(jToken:  val_2);
        // 0x00B44B3C: STR x21, [x19, #0x10]      | this.enemyPlayerData = typeof(CSAISPlayerData);  //  dest_result_addr=1152921514979105680
        this.enemyPlayerData = val_3;
        // 0x00B44B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(jToken:  val_2), ????);
        // 0x00B44B44: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        label_6:
        // 0x00B44B48: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x00B44B4C: LDR x8, [x8, #0xe08]       | X8 = (string**)(1152921510261102208)("ourPlayerData");
        // 0x00B44B50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B44B54: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
        // 0x00B44B58: LDR x1, [x8]               | X1 = "ourPlayerData";                   
        // 0x00B44B5C: BL #0x2925c6c              | X0 = 0.get_Item(propertyName:  "ourPlayerData");
        Newtonsoft.Json.Linq.JToken val_4 = 0.Item["ourPlayerData"];
        // 0x00B44B60: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B44B64: LDR x8, [x8, #0xd70]       | X8 = 1152921504904503296;               
        // 0x00B44B68: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B44B6C: LDR x8, [x8]               | X8 = typeof(CSAISPlayerData);           
        // 0x00B44B70: MOV x0, x8                 | X0 = 1152921504904503296 (0x1000000011BDE000);//ML01
        CSAISPlayerData val_5 = null;
        // 0x00B44B74: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CSAISPlayerData), ????);
        // 0x00B44B78: MOV x1, x20                | X1 = val_4;//m1                         
        // 0x00B44B7C: MOV x21, x0                | X21 = 1152921504904503296 (0x1000000011BDE000);//ML01
        // 0x00B44B80: BL #0xb43384               | .ctor(jToken:  val_4);                  
        val_5 = new CSAISPlayerData(jToken:  val_4);
        // 0x00B44B84: STR x21, [x19, #0x18]      | this.ourPlayerData = typeof(CSAISPlayerData);  //  dest_result_addr=1152921514979105688
        this.ourPlayerData = val_5;
        // 0x00B44B88: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B44B8C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B44B90: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B44B94: RET                        |  return;                                
        return;
        label_5:
        // 0x00B44B98: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00B44B9C: LDR x8, [x8, #0x7d8]       | X8 = (string**)(1152921510261100048)("enemyPlayerData");
        // 0x00B44BA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B44BA4: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B44BA8: LDR x1, [x8]               | X1 = "enemyPlayerData";                 
        // 0x00B44BAC: BL #0x2925c6c              | X0 = val_1.get_Item(propertyName:  "enemyPlayerData");
        Newtonsoft.Json.Linq.JToken val_6 = val_1.Item["enemyPlayerData"];
        // 0x00B44BB0: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B44BB4: LDR x8, [x8, #0xd70]       | X8 = 1152921504904503296;               
        // 0x00B44BB8: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00B44BBC: LDR x8, [x8]               | X8 = typeof(CSAISPlayerData);           
        // 0x00B44BC0: MOV x0, x8                 | X0 = 1152921504904503296 (0x1000000011BDE000);//ML01
        CSAISPlayerData val_7 = null;
        // 0x00B44BC4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CSAISPlayerData), ????);
        // 0x00B44BC8: MOV x1, x21                | X1 = val_6;//m1                         
        // 0x00B44BCC: MOV x22, x0                | X22 = 1152921504904503296 (0x1000000011BDE000);//ML01
        // 0x00B44BD0: BL #0xb43384               | .ctor(jToken:  val_6);                  
        val_7 = new CSAISPlayerData(jToken:  val_6);
        // 0x00B44BD4: STR x22, [x19, #0x10]      | this.enemyPlayerData = typeof(CSAISPlayerData);  //  dest_result_addr=1152921514979105680
        this.enemyPlayerData = val_7;
        // 0x00B44BD8: B #0xb44b48                |  goto label_6;                          
        goto label_6;
    
    }

}
