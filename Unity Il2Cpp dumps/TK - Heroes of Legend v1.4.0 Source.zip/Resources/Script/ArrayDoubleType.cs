using UnityEngine;

namespace wxb
{
    internal class ArrayDoubleType : ArraySerialize<double>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2BB08 (14859016), len: 80  VirtAddr: 0x00E2BB08 RVA: 0x00E2BB08 token: 100681209 methodIndex: 57201 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayDoubleType()
        {
            //
            // Disasemble & Code
            // 0x00E2BB08: STP x20, x19, [sp, #-0x20]! | stack[1152921513026786208] = ???;  stack[1152921513026786216] = ???;  //  dest_result_addr=1152921513026786208 |  dest_result_addr=1152921513026786216
            // 0x00E2BB0C: STP x29, x30, [sp, #0x10]  | stack[1152921513026786224] = ???;  stack[1152921513026786232] = ???;  //  dest_result_addr=1152921513026786224 |  dest_result_addr=1152921513026786232
            // 0x00E2BB10: ADD x29, sp, #0x10         | X29 = (1152921513026786208 + 16) = 1152921513026786224 (0x10000001F5DE13B0);
            // 0x00E2BB14: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2BB18: LDRB w8, [x20, #0x8ec]     | W8 = (bool)static_value_037348EC;       
            // 0x00E2BB1C: MOV x19, x0                | X19 = 1152921513026798240 (0x10000001F5DE42A0);//ML01
            // 0x00E2BB20: TBNZ w8, #0, #0xe2bb3c     | if (static_value_037348EC == true) goto label_0;
            // 0x00E2BB24: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00E2BB28: LDR x8, [x8, #0x310]       | X8 = 0x2B8E734;                         
            // 0x00E2BB2C: LDR w0, [x8]               | W0 = 0x108B;                            
            // 0x00E2BB30: BL #0x2782188              | X0 = sub_2782188( ?? 0x108B, ????);     
            // 0x00E2BB34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2BB38: STRB w8, [x20, #0x8ec]     | static_value_037348EC = true;            //  dest_result_addr=57886956
            label_0:
            // 0x00E2BB3C: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x00E2BB40: LDR x8, [x8, #0x300]       | X8 = 1152921513026773216;               
            // 0x00E2BB44: MOV x0, x19                | X0 = 1152921513026798240 (0x10000001F5DE42A0);//ML01
            // 0x00E2BB48: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.Double>::.ctor();
            // 0x00E2BB4C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BB50: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BB54: B #0x1d86f7c               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BB58 (14859096), len: 8  VirtAddr: 0x00E2BB58 RVA: 0x00E2BB58 token: 100681210 methodIndex: 57202 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2BB58: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00E2BB5C: RET                        |  return (System.Int32)8;                
            return (int)8;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BB60 (14859104), len: 60  VirtAddr: 0x00E2BB60 RVA: 0x00E2BB60 token: 100681211 methodIndex: 57203 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, double value)
        {
            //
            // Disasemble & Code
            // 0x00E2BB60: STP d9, d8, [sp, #-0x30]!  | stack[1152921513027014288] = ???;  stack[1152921513027014296] = ???;  //  dest_result_addr=1152921513027014288 |  dest_result_addr=1152921513027014296
            // 0x00E2BB64: STP x20, x19, [sp, #0x10]  | stack[1152921513027014304] = ???;  stack[1152921513027014312] = ???;  //  dest_result_addr=1152921513027014304 |  dest_result_addr=1152921513027014312
            // 0x00E2BB68: STP x29, x30, [sp, #0x20]  | stack[1152921513027014320] = ???;  stack[1152921513027014328] = ???;  //  dest_result_addr=1152921513027014320 |  dest_result_addr=1152921513027014328
            // 0x00E2BB6C: ADD x29, sp, #0x20         | X29 = (1152921513027014288 + 32) = 1152921513027014320 (0x10000001F5E18EB0);
            // 0x00E2BB70: MOV v8.16b, v0.16b         | V8 = value;//m1                         
            // 0x00E2BB74: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2BB78: CBNZ x19, #0xe2bb80        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BB7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BB80: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2BB84: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BB88: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BB8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BB90: MOV v0.16b, v8.16b         | V0 = value;//m1                         
            // 0x00E2BB94: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
            // 0x00E2BB98: B #0x26a5a9c               | stream.WriteDouble(value:  value); return;
            stream.WriteDouble(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BB9C (14859164), len: 44  VirtAddr: 0x00E2BB9C RVA: 0x00E2BB9C token: 100681212 methodIndex: 57204 delegateWrapperIndex: 0 methodInvoker: 0
        protected override double Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2BB9C: STP x20, x19, [sp, #-0x20]! | stack[1152921513027134496] = ???;  stack[1152921513027134504] = ???;  //  dest_result_addr=1152921513027134496 |  dest_result_addr=1152921513027134504
            // 0x00E2BBA0: STP x29, x30, [sp, #0x10]  | stack[1152921513027134512] = ???;  stack[1152921513027134520] = ???;  //  dest_result_addr=1152921513027134512 |  dest_result_addr=1152921513027134520
            // 0x00E2BBA4: ADD x29, sp, #0x10         | X29 = (1152921513027134496 + 16) = 1152921513027134512 (0x10000001F5E36430);
            // 0x00E2BBA8: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2BBAC: CBNZ x19, #0xe2bbb4        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BBB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BBB4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BBB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BBBC: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2BBC0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BBC4: B #0x26a5b20               | return stream.ReadDouble();             
            return stream.ReadDouble();
        
        }
    
    }

}
