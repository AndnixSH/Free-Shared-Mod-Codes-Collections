using UnityEngine;
public enum UIBasicSprite.AdvancedType
{
    // Fields
    Invisible = 0
    ,Sliced = 1
    ,Tiled = 2
    

}
