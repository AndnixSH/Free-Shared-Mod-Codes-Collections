using UnityEngine;

namespace Entity.Behavior
{
    public class BiaocheMoveBvr : IBehavior
    {
        // Fields
        private UnityEngine.Vector3 targetPos; //  0x0000001C
        private float curTime; //  0x00000028
        private float intervalTime; //  0x0000002C
        
        // Properties
        public override Entity.Behavior.EBehaviorID id { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00B68D14 (11963668), len: 20  VirtAddr: 0x00B68D14 RVA: 0x00B68D14 token: 100691599 methodIndex: 27226 delegateWrapperIndex: 0 methodInvoker: 0
        public BiaocheMoveBvr()
        {
            //
            // Disasemble & Code
            // 0x00B68D14: MOVZ w8, #0x3f4c, lsl #16  | W8 = 1061945344 (0x3F4C0000);//ML01     
            // 0x00B68D18: MOVK w8, #0xcccd           | W8 = 1061997773 (0x3F4CCCCD);           
            // 0x00B68D1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68D20: STR w8, [x0, #0x2c]        | this.intervalTime = 0.8;                 //  dest_result_addr=1152921514680679804
            this.intervalTime = 0.8f;
            // 0x00B68D24: B #0xeb3a54                | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68D30 (11963696), len: 8  VirtAddr: 0x00B68D30 RVA: 0x00B68D30 token: 100691600 methodIndex: 27227 delegateWrapperIndex: 0 methodInvoker: 0
        public override Entity.Behavior.EBehaviorID get_id()
        {
            //
            // Disasemble & Code
            // 0x00B68D30: ORR w0, wzr, #2            | W0 = 2(0x2);                            
            // 0x00B68D34: RET                        |  return (Entity.Behavior.EBehaviorID)0x2;
            return (Entity.Behavior.EBehaviorID)2;
            //  |  // // {name=val_0, type=Entity.Behavior.EBehaviorID, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68D38 (11963704), len: 508  VirtAddr: 0x00B68D38 RVA: 0x00B68D38 token: 100691601 methodIndex: 27228 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Reason()
        {
            //
            // Disasemble & Code
            //  | 
            float val_8;
            //  | 
            var val_9;
            // 0x00B68D38: STP d13, d12, [sp, #-0x50]! | stack[1152921514680903968] = ???;  stack[1152921514680903976] = ???;  //  dest_result_addr=1152921514680903968 |  dest_result_addr=1152921514680903976
            // 0x00B68D3C: STP d11, d10, [sp, #0x10]  | stack[1152921514680903984] = ???;  stack[1152921514680903992] = ???;  //  dest_result_addr=1152921514680903984 |  dest_result_addr=1152921514680903992
            // 0x00B68D40: STP d9, d8, [sp, #0x20]    | stack[1152921514680904000] = ???;  stack[1152921514680904008] = ???;  //  dest_result_addr=1152921514680904000 |  dest_result_addr=1152921514680904008
            // 0x00B68D44: STP x20, x19, [sp, #0x30]  | stack[1152921514680904016] = ???;  stack[1152921514680904024] = ???;  //  dest_result_addr=1152921514680904016 |  dest_result_addr=1152921514680904024
            // 0x00B68D48: STP x29, x30, [sp, #0x40]  | stack[1152921514680904032] = ???;  stack[1152921514680904040] = ???;  //  dest_result_addr=1152921514680904032 |  dest_result_addr=1152921514680904040
            // 0x00B68D4C: ADD x29, sp, #0x40         | X29 = (1152921514680903968 + 64) = 1152921514680904032 (0x100000025875E960);
            // 0x00B68D50: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00B68D54: LDRB w8, [x20, #0x96b]     | W8 = (bool)static_value_0373396B;       
            // 0x00B68D58: MOV x19, x0                | X19 = 1152921514680916048 (0x1000000258761850);//ML01
            // 0x00B68D5C: TBNZ w8, #0, #0xb68d78     | if (static_value_0373396B == true) goto label_0;
            // 0x00B68D60: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00B68D64: LDR x8, [x8, #0xa78]       | X8 = 0x2B8F3C0;                         
            // 0x00B68D68: LDR w0, [x8]               | W0 = 0x13B2;                            
            // 0x00B68D6C: BL #0x2782188              | X0 = sub_2782188( ?? 0x13B2, ????);     
            // 0x00B68D70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B68D74: STRB w8, [x20, #0x96b]     | static_value_0373396B = true;            //  dest_result_addr=57882987
            label_0:
            // 0x00B68D78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68D7C: MOV x0, x19                | X0 = 1152921514680916048 (0x1000000258761850);//ML01
            // 0x00B68D80: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_1 = this.entity;
            // 0x00B68D84: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00B68D88: CBNZ x20, #0xb68d90        | if (val_1 != null) goto label_1;        
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x00B68D8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00B68D90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68D94: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00B68D98: BL #0xd89310               | X0 = val_1.get_position();              
            UnityEngine.Vector3 val_2 = val_1.position;
            // 0x00B68D9C: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x00B68DA0: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x00B68DA4: MOV v8.16b, v0.16b         | V8 = val_2.x;//m1                       
            val_8 = val_2.x;
            // 0x00B68DA8: MOV v9.16b, v1.16b         | V9 = val_2.y;//m1                       
            // 0x00B68DAC: MOV v13.16b, v2.16b        | V13 = val_2.z;//m1                      
            // 0x00B68DB0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x00B68DB4: LDP s12, s11, [x19, #0x1c] | S12 = this.targetPos; //P2               //  | 
            // 0x00B68DB8: LDR s10, [x19, #0x24]      | 
            // 0x00B68DBC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x00B68DC0: TBZ w8, #0, #0xb68dd0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00B68DC4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x00B68DC8: CBNZ w8, #0xb68dd0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00B68DCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_3:
            // 0x00B68DD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B68DD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68DD8: MOV v0.16b, v8.16b         | V0 = val_2.x;//m1                       
            // 0x00B68DDC: MOV v1.16b, v9.16b         | V1 = val_2.y;//m1                       
            // 0x00B68DE0: MOV v2.16b, v13.16b        | V2 = val_2.z;//m1                       
            // 0x00B68DE4: MOV v3.16b, v12.16b        | V3 = this.targetPos;//m1                
            // 0x00B68DE8: MOV v4.16b, v11.16b        | V4 = V11.16B;//m1                       
            // 0x00B68DEC: MOV v5.16b, v10.16b        | V5 = V10.16B;//m1                       
            // 0x00B68DF0: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_8, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = this.targetPos, y = V11.16B, z = V10.16B});
            float val_3 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_8, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = this.targetPos, y = V11.16B, z = V10.16B});
            // 0x00B68DF4: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x00B68DF8: FCMP s0, s1                | STATE = COMPARE(val_3, 0.5)             
            // 0x00B68DFC: B.LS #0xb68ec8             | if (val_3 <= 0.5f) goto label_4;        
            if(val_3 <= 0.5f)
            {
                goto label_4;
            }
            // 0x00B68E00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68E04: MOV x0, x19                | X0 = 1152921514680916048 (0x1000000258761850);//ML01
            // 0x00B68E08: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_4 = this.entity;
            // 0x00B68E0C: CBZ x0, #0xb68eb0          | if (val_4 == null) goto label_8;        
            if(val_4 == null)
            {
                goto label_8;
            }
            // 0x00B68E10: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x00B68E14: LDR x8, [x8, #0x330]       | X8 = 1152921504893906944;               
            // 0x00B68E18: LDR x9, [x0]               | X9 = typeof(CombatEntity);              
            // 0x00B68E1C: LDR x8, [x8]               | X8 = typeof(Biaoche);                   
            // 0x00B68E20: LDRB w11, [x9, #0x104]     | W11 = CombatEntity.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00B68E24: LDRB w10, [x8, #0x104]     | W10 = Biaoche.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00B68E28: CMP w11, w10               | STATE = COMPARE(CombatEntity.__il2cppRuntimeField_typeHierarchyDepth, Biaoche.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00B68E2C: B.LO #0xb68eb0             | if (CombatEntity.__il2cppRuntimeField_typeHierarchyDepth < Biaoche.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00B68E30: LDR x9, [x9, #0xb0]        | X9 = CombatEntity.__il2cppRuntimeField_typeHierarchy;
            // 0x00B68E34: ADD x9, x9, x10, lsl #3    | X9 = (CombatEntity.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyD
            // 0x00B68E38: LDUR x9, [x9, #-8]         | X9 = (CombatEntity.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00B68E3C: CMP x9, x8                 | STATE = COMPARE((CombatEntity.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Biaoche))
            // 0x00B68E40: B.NE #0xb68eb0             | if ((CombatEntity.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_8;
            // 0x00B68E44: LDR s8, [x19, #0x28]       | S8 = this.curTime; //P2                 
            val_8 = this.curTime;
            // 0x00B68E48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B68E4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68E50: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
            float val_5 = UnityEngine.Time.deltaTime;
            // 0x00B68E54: LDR s1, [x19, #0x2c]       | S1 = this.intervalTime; //P2            
            // 0x00B68E58: FADD s0, s8, s0            | S0 = (this.curTime + val_5);            
            val_5 = val_8 + val_5;
            // 0x00B68E5C: STR s0, [x19, #0x28]       | this.curTime = (this.curTime + val_5);   //  dest_result_addr=1152921514680916088
            this.curTime = val_5;
            // 0x00B68E60: FCMP s0, s1                | STATE = COMPARE((this.curTime + val_5), this.intervalTime)
            // 0x00B68E64: B.LT #0xb68eb0             | if (val_5 < this.intervalTime) goto label_8;
            if(val_5 < this.intervalTime)
            {
                goto label_8;
            }
            // 0x00B68E68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68E6C: MOV x0, x19                | X0 = 1152921514680916048 (0x1000000258761850);//ML01
            // 0x00B68E70: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_6 = this.entity;
            // 0x00B68E74: LDP s8, s9, [x19, #0x1c]   | S8 = this.targetPos; //P2                //  | 
            val_8 = this.targetPos;
            // 0x00B68E78: LDR s10, [x19, #0x24]      | 
            // 0x00B68E7C: MOV x20, x0                | X20 = val_6;//m1                        
            // 0x00B68E80: CBNZ x20, #0xb68e88        | if (val_6 != null) goto label_9;        
            if(val_6 != null)
            {
                goto label_9;
            }
            // 0x00B68E84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_9:
            // 0x00B68E88: LDR x8, [x20]              | X8 = typeof(CombatEntity);              
            // 0x00B68E8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68E90: MOV x0, x20                | X0 = val_6;//m1                         
            // 0x00B68E94: MOV v0.16b, v8.16b         | V0 = this.targetPos;//m1                
            // 0x00B68E98: LDR x9, [x8, #0x270]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_270;
            // 0x00B68E9C: LDR x2, [x8, #0x278]       | X2 = typeof(CombatEntity).__il2cppRuntimeField_278;
            // 0x00B68EA0: MOV v1.16b, v9.16b         | V1 = val_2.y;//m1                       
            // 0x00B68EA4: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
            // 0x00B68EA8: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_270();
            // 0x00B68EAC: STR wzr, [x19, #0x28]      | this.curTime = 0;                        //  dest_result_addr=1152921514680916088
            this.curTime = 0f;
            label_8:
            // 0x00B68EB0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68EB4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00B68EB8: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x00B68EBC: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x00B68EC0: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
            // 0x00B68EC4: RET                        |  return;                                
            return;
            label_4:
            // 0x00B68EC8: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00B68ECC: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
            // 0x00B68ED0: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
            CEvent.ZEvent val_7 = null;
            // 0x00B68ED4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
            // 0x00B68ED8: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00B68EDC: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921510058805600)("MOVE_TO_END");
            // 0x00B68EE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B68EE4: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x00B68EE8: LDR x1, [x8]               | X1 = "MOVE_TO_END";                     
            // 0x00B68EEC: BL #0xd80ce8               | .ctor(name:  "MOVE_TO_END");            
            val_7 = new CEvent.ZEvent(name:  "MOVE_TO_END");
            // 0x00B68EF0: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00B68EF4: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
            // 0x00B68EF8: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
            // 0x00B68EFC: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
            // 0x00B68F00: TBZ w8, #0, #0xb68f10      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00B68F04: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
            // 0x00B68F08: CBNZ w8, #0xb68f10         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00B68F0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
            label_11:
            // 0x00B68F10: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x00B68F14: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68F18: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00B68F1C: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x00B68F20: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x00B68F24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B68F28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B68F2C: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
            // 0x00B68F30: B #0xd7de90                | CEvent.ZEventCenter.DispatchEvent(ev:  0); return;
            CEvent.ZEventCenter.DispatchEvent(ev:  0);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68F34 (11964212), len: 4  VirtAddr: 0x00B68F34 RVA: 0x00B68F34 token: 100691602 methodIndex: 27229 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Action()
        {
            //
            // Disasemble & Code
            // 0x00B68F34: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68F38 (11964216), len: 104  VirtAddr: 0x00B68F38 RVA: 0x00B68F38 token: 100691603 methodIndex: 27230 delegateWrapperIndex: 0 methodInvoker: 0
        public override void DoEntering()
        {
            //
            // Disasemble & Code
            // 0x00B68F38: STP d11, d10, [sp, #-0x40]! | stack[1152921514681144368] = ???;  stack[1152921514681144376] = ???;  //  dest_result_addr=1152921514681144368 |  dest_result_addr=1152921514681144376
            // 0x00B68F3C: STP d9, d8, [sp, #0x10]    | stack[1152921514681144384] = ???;  stack[1152921514681144392] = ???;  //  dest_result_addr=1152921514681144384 |  dest_result_addr=1152921514681144392
            // 0x00B68F40: STP x20, x19, [sp, #0x20]  | stack[1152921514681144400] = ???;  stack[1152921514681144408] = ???;  //  dest_result_addr=1152921514681144400 |  dest_result_addr=1152921514681144408
            // 0x00B68F44: STP x29, x30, [sp, #0x30]  | stack[1152921514681144416] = ???;  stack[1152921514681144424] = ???;  //  dest_result_addr=1152921514681144416 |  dest_result_addr=1152921514681144424
            // 0x00B68F48: ADD x29, sp, #0x30         | X29 = (1152921514681144368 + 48) = 1152921514681144416 (0x1000000258799460);
            // 0x00B68F4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68F50: MOV x19, x0                | X19 = 1152921514681156432 (0x100000025879C350);//ML01
            // 0x00B68F54: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_1 = this.entity;
            // 0x00B68F58: LDP s8, s9, [x19, #0x1c]   | S8 = this.targetPos; //P2                //  | 
            // 0x00B68F5C: LDR s10, [x19, #0x24]      | 
            // 0x00B68F60: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00B68F64: CBNZ x19, #0xb68f6c        | if (val_1 != null) goto label_0;        
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x00B68F68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_0:
            // 0x00B68F6C: LDR x8, [x19]              | X8 = typeof(CombatEntity);              
            // 0x00B68F70: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00B68F74: MOV v0.16b, v8.16b         | V0 = this.targetPos;//m1                
            // 0x00B68F78: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
            // 0x00B68F7C: LDR x3, [x8, #0x270]       | X3 = typeof(CombatEntity).__il2cppRuntimeField_270;
            // 0x00B68F80: LDR x2, [x8, #0x278]       | X2 = typeof(CombatEntity).__il2cppRuntimeField_278;
            // 0x00B68F84: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68F88: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00B68F8C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x00B68F90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68F94: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
            // 0x00B68F98: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
            // 0x00B68F9C: BR x3                      | goto typeof(CombatEntity).__il2cppRuntimeField_270;
            goto typeof(CombatEntity).__il2cppRuntimeField_270;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68FA0 (11964320), len: 236  VirtAddr: 0x00B68FA0 RVA: 0x00B68FA0 token: 100691604 methodIndex: 27231 delegateWrapperIndex: 0 methodInvoker: 0
        public override void SetParams(object[] args)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00B68FA0: STP x22, x21, [sp, #-0x30]! | stack[1152921514681301440] = ???;  stack[1152921514681301448] = ???;  //  dest_result_addr=1152921514681301440 |  dest_result_addr=1152921514681301448
            // 0x00B68FA4: STP x20, x19, [sp, #0x10]  | stack[1152921514681301456] = ???;  stack[1152921514681301464] = ???;  //  dest_result_addr=1152921514681301456 |  dest_result_addr=1152921514681301464
            // 0x00B68FA8: STP x29, x30, [sp, #0x20]  | stack[1152921514681301472] = ???;  stack[1152921514681301480] = ???;  //  dest_result_addr=1152921514681301472 |  dest_result_addr=1152921514681301480
            // 0x00B68FAC: ADD x29, sp, #0x20         | X29 = (1152921514681301440 + 32) = 1152921514681301472 (0x10000002587BF9E0);
            // 0x00B68FB0: SUB sp, sp, #0x10          | SP = (1152921514681301440 - 16) = 1152921514681301424 (0x10000002587BF9B0);
            // 0x00B68FB4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00B68FB8: LDRB w8, [x21, #0x96c]     | W8 = (bool)static_value_0373396C;       
            // 0x00B68FBC: MOV x20, x1                | X20 = args;//m1                         
            // 0x00B68FC0: MOV x19, x0                | X19 = 1152921514681313488 (0x10000002587C28D0);//ML01
            // 0x00B68FC4: TBNZ w8, #0, #0xb68fe0     | if (static_value_0373396C == true) goto label_0;
            // 0x00B68FC8: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00B68FCC: LDR x8, [x8, #0xb58]       | X8 = 0x2B8F3C4;                         
            // 0x00B68FD0: LDR w0, [x8]               | W0 = 0x13B3;                            
            // 0x00B68FD4: BL #0x2782188              | X0 = sub_2782188( ?? 0x13B3, ????);     
            // 0x00B68FD8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B68FDC: STRB w8, [x21, #0x96c]     | static_value_0373396C = true;            //  dest_result_addr=57882988
            label_0:
            // 0x00B68FE0: CBNZ x20, #0xb68fe8        | if (args != null) goto label_1;         
            if(args != null)
            {
                goto label_1;
            }
            // 0x00B68FE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13B3, ????);     
            label_1:
            // 0x00B68FE8: LDR w8, [x20, #0x18]       | W8 = args.Length; //P2                  
            // 0x00B68FEC: CBNZ w8, #0xb68ffc         | if (args.Length != 0) goto label_2;     
            if(args.Length != 0)
            {
                goto label_2;
            }
            // 0x00B68FF0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x13B3, ????);     
            // 0x00B68FF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68FF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x13B3, ????);     
            label_2:
            // 0x00B68FFC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x00B69000: LDR x21, [x20, #0x20]      | X21 = args[0]                           
            object val_2 = args[0];
            // 0x00B69004: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x00B69008: LDR x20, [x8]              | X20 = typeof(UnityEngine.Vector3);      
            // 0x00B6900C: CBNZ x21, #0xb69014        | if (args[0] != null) goto label_3;      
            if(val_2 != null)
            {
                goto label_3;
            }
            // 0x00B69010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13B3, ????);     
            label_3:
            // 0x00B69014: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x00B69018: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00B6901C: LDR x8, [x20, #0x30]       | X8 = UnityEngine.Vector3.__il2cppRuntimeField_element_class;
            // 0x00B69020: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, UnityEngine.Vector3.__il2cppRuntimeField_element_class)
            // 0x00B69024: B.NE #0xb69054             | if (System.Object.__il2cppRuntimeField_element_class != UnityEngine.Vector3.__il2cppRuntimeField_element_class) goto label_4;
            // 0x00B69028: MOV x0, x21                | X0 = args[0];//m1                       
            // 0x00B6902C: BL #0x27bc4e8              | args[0].System.IDisposable.Dispose();   
            val_2.System.IDisposable.Dispose();
            // 0x00B69030: LDP w8, w9, [x0]           | W8 = typeof(System.Object);              //  | 
            // 0x00B69034: LDR w10, [x0, #8]          | 
            // 0x00B69038: STP w8, w9, [x19, #0x1c]   | this.targetPos = typeof(System.Object);  mem[1152921514681313520] = ???;  //  dest_result_addr=1152921514681313516 |  dest_result_addr=1152921514681313520
            this.targetPos = new UnityEngine.Vector3();
            mem[1152921514681313520] = ???;
            // 0x00B6903C: STR w10, [x19, #0x24]      | mem[1152921514681313524] = ???;          //  dest_result_addr=1152921514681313524
            mem[1152921514681313524] = ???;
            // 0x00B69040: SUB sp, x29, #0x20         | SP = (1152921514681301472 - 32) = 1152921514681301440 (0x10000002587BF9C0);
            // 0x00B69044: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00B69048: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00B6904C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00B69050: RET                        |  return;                                
            return;
            label_4:
            // 0x00B69054: ADD x8, sp, #8             | X8 = (1152921514681301424 + 8) = 1152921514681301432 (0x10000002587BF9B8);
            // 0x00B69058: MOV x1, x20                | X1 = 1152921504695078912 (0x1000000005425000);//ML01
            // 0x00B6905C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00B69060: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921514681289488]
            // 0x00B69064: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x00B69068: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B6906C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x00B69070: ADD x0, sp, #8             | X0 = (1152921514681301424 + 8) = 1152921514681301432 (0x10000002587BF9B8);
            // 0x00B69074: BL #0x299a140              | 
            // 0x00B69078: MOV x19, x0                | X19 = 1152921514681301432 (0x10000002587BF9B8);//ML01
            // 0x00B6907C: ADD x0, sp, #8             | X0 = (1152921514681301424 + 8) = 1152921514681301432 (0x10000002587BF9B8);
            // 0x00B69080: BL #0x299a140              | 
            // 0x00B69084: MOV x0, x19                | X0 = 1152921514681301432 (0x10000002587BF9B8);//ML01
            // 0x00B69088: BL #0x980800               | X0 = sub_980800( ?? 0x10000002587BF9B8, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00B6908C (11964556), len: 60  VirtAddr: 0x00B6908C RVA: 0x00B6908C token: 100691605 methodIndex: 27232 delegateWrapperIndex: 0 methodInvoker: 0
        public override void DoLeaving()
        {
            //
            // Disasemble & Code
            // 0x00B6908C: STP x20, x19, [sp, #-0x20]! | stack[1152921514681458512] = ???;  stack[1152921514681458520] = ???;  //  dest_result_addr=1152921514681458512 |  dest_result_addr=1152921514681458520
            // 0x00B69090: STP x29, x30, [sp, #0x10]  | stack[1152921514681458528] = ???;  stack[1152921514681458536] = ???;  //  dest_result_addr=1152921514681458528 |  dest_result_addr=1152921514681458536
            // 0x00B69094: ADD x29, sp, #0x10         | X29 = (1152921514681458512 + 16) = 1152921514681458528 (0x10000002587E5F60);
            // 0x00B69098: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B6909C: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_1 = this.entity;
            // 0x00B690A0: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00B690A4: CBNZ x19, #0xb690ac        | if (val_1 != null) goto label_0;        
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x00B690A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_0:
            // 0x00B690AC: LDR x8, [x19]              | X8 = typeof(CombatEntity);              
            // 0x00B690B0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00B690B4: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00B690B8: LDP x3, x2, [x8, #0x160]   | X3 = typeof(CombatEntity).__il2cppRuntimeField_160; X2 = typeof(CombatEntity).__il2cppRuntimeField_168; //  | 
            // 0x00B690BC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00B690C0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00B690C4: BR x3                      | goto typeof(CombatEntity).__il2cppRuntimeField_160;
            goto typeof(CombatEntity).__il2cppRuntimeField_160;
        
        }
    
    }

}
