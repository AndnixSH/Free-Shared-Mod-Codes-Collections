using UnityEngine;

namespace SevenZip
{
    internal class CRC
    {
        // Fields
        public static readonly uint[] Table; // static_offset: 0x00000000
        private uint _value; //  0x00000010
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD8724 (11372324), len: 236  VirtAddr: 0x00AD8724 RVA: 0x00AD8724 token: 100681423 methodIndex: 54752 delegateWrapperIndex: 0 methodInvoker: 0
        private static CRC()
        {
            //
            // Disasemble & Code
            // 0x00AD8724: STP x24, x23, [sp, #-0x40]! | stack[1152921513059085552] = ???;  stack[1152921513059085560] = ???;  //  dest_result_addr=1152921513059085552 |  dest_result_addr=1152921513059085560
            // 0x00AD8728: STP x22, x21, [sp, #0x10]  | stack[1152921513059085568] = ???;  stack[1152921513059085576] = ???;  //  dest_result_addr=1152921513059085568 |  dest_result_addr=1152921513059085576
            // 0x00AD872C: STP x20, x19, [sp, #0x20]  | stack[1152921513059085584] = ???;  stack[1152921513059085592] = ???;  //  dest_result_addr=1152921513059085584 |  dest_result_addr=1152921513059085592
            // 0x00AD8730: STP x29, x30, [sp, #0x30]  | stack[1152921513059085600] = ???;  stack[1152921513059085608] = ???;  //  dest_result_addr=1152921513059085600 |  dest_result_addr=1152921513059085608
            // 0x00AD8734: ADD x29, sp, #0x30         | X29 = (1152921513059085552 + 48) = 1152921513059085600 (0x10000001F7CAED20);
            // 0x00AD8738: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AD873C: LDRB w8, [x19, #0x50f]     | W8 = (bool)static_value_0373350F;       
            // 0x00AD8740: TBNZ w8, #0, #0xad875c     | if (static_value_0373350F == true) goto label_0;
            // 0x00AD8744: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00AD8748: LDR x8, [x8, #0x70]        | X8 = 0x2B92D78;                         
            // 0x00AD874C: LDR w0, [x8]               | W0 = 0x2223;                            
            // 0x00AD8750: BL #0x2782188              | X0 = sub_2782188( ?? 0x2223, ????);     
            // 0x00AD8754: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD8758: STRB w8, [x19, #0x50f]     | static_value_0373350F = true;            //  dest_result_addr=57881871
            label_0:
            // 0x00AD875C: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00AD8760: LDR x20, [x20, #0x988]     | X20 = 1152921504832512000;              
            // 0x00AD8764: ADRP x9, #0x367c000        | X9 = 57131008 (0x367C000);              
            // 0x00AD8768: LDR x8, [x20]              | X8 = typeof(SevenZip.CRC);              
            // 0x00AD876C: LDR x9, [x9, #0x1b8]       | X9 = 1152921505007033440;               
            // 0x00AD8770: LDR x21, [x8, #0xa0]       | X21 = SevenZip.CRC.__il2cppRuntimeField_static_fields;
            // 0x00AD8774: LDR x19, [x9]              | X19 = typeof(System.UInt32[]);          
            // 0x00AD8778: MOV x0, x19                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x00AD877C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.UInt32[]), ????);
            // 0x00AD8780: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
            // 0x00AD8784: MOV x0, x19                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x00AD8788: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.UInt32[]), ????);
            // 0x00AD878C: STR x0, [x21]              | SevenZip.CRC.Table = typeof(System.UInt32[]);  //  dest_result_addr=1152921504832516096
            SevenZip.CRC.Table = null;
            // 0x00AD8790: MOVZ w21, #0xedb8, lsl #16 | W21 = 3988258816 (0xEDB80000);//ML01    
            // 0x00AD8794: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x00AD8798: MOVK w21, #0x8320          | W21 = 3988292384 (0xEDB88320);          
            label_4:
            // 0x00AD879C: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            var val_3 = 8;
            // 0x00AD87A0: MOV w22, w19               | W22 = 0 (0x0);//ML01                    
            label_1:
            // 0x00AD87A4: LSR w9, w22, #1            | W9 = (0 >> 1) = 0 (0x00000000);         
            // 0x00AD87A8: EOR w10, w21, w22, lsr #1  | W10 = (3988292384 ^ 0);                 
            var val_1 = 3988292384 ^ 0;
            // 0x00AD87AC: TST w22, #1                | STATE = COMPARE(0x0, 0x1)               
            // 0x00AD87B0: CSEL w22, w9, w10, eq      | W22 = (0 & 0x1)!=0 ? 0 : (3988292384 ^ 0);
            var val_2 = ((val_4 & 1) != 0) ? (0) : (val_1);
            // 0x00AD87B4: SUB w8, w8, #1             | W8 = (8 - 1);                           
            val_3 = val_3 - 1;
            // 0x00AD87B8: CBNZ w8, #0xad87a4         | if ((8 - 1) != 0) goto label_1;         
            if(val_3 != 0)
            {
                goto label_1;
            }
            // 0x00AD87BC: LDR x8, [x20]              | X8 = typeof(SevenZip.CRC);              
            // 0x00AD87C0: LDR x8, [x8, #0xa0]        | X8 = SevenZip.CRC.__il2cppRuntimeField_static_fields;
            // 0x00AD87C4: LDR x23, [x8]              | X23 = typeof(System.UInt32[]);          
            // 0x00AD87C8: CBNZ x23, #0xad87d0        | if ( != null) goto label_2;             
            if(null != null)
            {
                goto label_2;
            }
            // 0x00AD87CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.UInt32[]), ????);
            label_2:
            // 0x00AD87D0: LDR w8, [x23, #0x18]       | W8 = System.UInt32[].__il2cppRuntimeField_namespaze;
            // 0x00AD87D4: CMP x19, x8                | STATE = COMPARE(0x0, System.UInt32[].__il2cppRuntimeField_namespaze)
            // 0x00AD87D8: B.LO #0xad87e8             | if (0 < System.UInt32[].__il2cppRuntimeField_namespaze) goto label_3;
            // 0x00AD87DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.UInt32[]), ????);
            // 0x00AD87E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD87E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.UInt32[]), ????);
            label_3:
            // 0x00AD87E8: ADD x8, x23, x19, lsl #2   |  //  not_find_field:typeof(System.UInt32[]).0
            // 0x00AD87EC: ADD x19, x19, #1           | X19 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x00AD87F0: STR w22, [x8, #0x20]       | System.UInt32[].__il2cppRuntimeField_namespaze.__unknownFiledOffset_20 = (0 & 0x1)!=0 ? 0 : (3988292384 ^ 0);  //  dest_result_addr=0
            System.UInt32[].__il2cppRuntimeField_namespaze.__unknownFiledOffset_20 = val_2;
            // 0x00AD87F4: CMP x19, #0x100            | STATE = COMPARE((0 + 1), 0x100)         
            // 0x00AD87F8: B.NE #0xad879c             | if (0 != 0x100) goto label_4;           
            if(val_4 != 256)
            {
                goto label_4;
            }
            // 0x00AD87FC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD8800: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD8804: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD8808: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AD880C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD8810 (11372560), len: 16  VirtAddr: 0x00AD8810 RVA: 0x00AD8810 token: 100681424 methodIndex: 54753 delegateWrapperIndex: 0 methodInvoker: 0
        public CRC()
        {
            //
            // Disasemble & Code
            // 0x00AD8810: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x00AD8814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD8818: STR w8, [x0, #0x10]        | this._value = null;                      //  dest_result_addr=1152921513059209632
            this._value = 0;
            // 0x00AD881C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD8820 (11372576), len: 12  VirtAddr: 0x00AD8820 RVA: 0x00AD8820 token: 100681425 methodIndex: 54754 delegateWrapperIndex: 0 methodInvoker: 0
        public void Init()
        {
            //
            // Disasemble & Code
            // 0x00AD8820: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x00AD8824: STR w8, [x0, #0x10]        | this._value = null;                      //  dest_result_addr=1152921513059321632
            this._value = 0;
            // 0x00AD8828: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD882C (11372588), len: 184  VirtAddr: 0x00AD882C RVA: 0x00AD882C token: 100681426 methodIndex: 54755 delegateWrapperIndex: 0 methodInvoker: 0
        public void UpdateByte(byte b)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x00AD882C: STP x22, x21, [sp, #-0x30]! | stack[1152921513059421568] = ???;  stack[1152921513059421576] = ???;  //  dest_result_addr=1152921513059421568 |  dest_result_addr=1152921513059421576
            // 0x00AD8830: STP x20, x19, [sp, #0x10]  | stack[1152921513059421584] = ???;  stack[1152921513059421592] = ???;  //  dest_result_addr=1152921513059421584 |  dest_result_addr=1152921513059421592
            // 0x00AD8834: STP x29, x30, [sp, #0x20]  | stack[1152921513059421600] = ???;  stack[1152921513059421608] = ???;  //  dest_result_addr=1152921513059421600 |  dest_result_addr=1152921513059421608
            // 0x00AD8838: ADD x29, sp, #0x20         | X29 = (1152921513059421568 + 32) = 1152921513059421600 (0x10000001F7D00DA0);
            // 0x00AD883C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD8840: LDRB w8, [x21, #0x510]     | W8 = (bool)static_value_03733510;       
            // 0x00AD8844: MOV w20, w1                | W20 = b;//m1                            
            byte val_3 = b;
            // 0x00AD8848: MOV x19, x0                | X19 = 1152921513059433616 (0x10000001F7D03C90);//ML01
            // 0x00AD884C: TBNZ w8, #0, #0xad8868     | if (static_value_03733510 == true) goto label_0;
            // 0x00AD8850: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x00AD8854: LDR x8, [x8, #0xfd8]       | X8 = 0x2B92D84;                         
            // 0x00AD8858: LDR w0, [x8]               | W0 = 0x2226;                            
            // 0x00AD885C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2226, ????);     
            // 0x00AD8860: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD8864: STRB w8, [x21, #0x510]     | static_value_03733510 = true;            //  dest_result_addr=57881872
            label_0:
            // 0x00AD8868: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00AD886C: LDR x21, [x21, #0x988]     | X21 = 1152921504832512000;              
            // 0x00AD8870: LDR x0, [x21]              | X0 = typeof(SevenZip.CRC);              
            val_3 = null;
            // 0x00AD8874: LDRB w8, [x0, #0x10a]      | W8 = SevenZip.CRC.__il2cppRuntimeField_10A;
            // 0x00AD8878: TBZ w8, #0, #0xad888c      | if (SevenZip.CRC.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AD887C: LDR w8, [x0, #0xbc]        | W8 = SevenZip.CRC.__il2cppRuntimeField_cctor_finished;
            // 0x00AD8880: CBNZ w8, #0xad888c         | if (SevenZip.CRC.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AD8884: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SevenZip.CRC), ????);
            // 0x00AD8888: LDR x0, [x21]              | X0 = typeof(SevenZip.CRC);              
            val_3 = null;
            label_2:
            // 0x00AD888C: LDR x8, [x0, #0xa0]        | X8 = SevenZip.CRC.__il2cppRuntimeField_static_fields;
            // 0x00AD8890: LDRB w22, [x19, #0x10]     | W22 = this._value; //P2                 
            // 0x00AD8894: LDR x21, [x8]              | X21 = SevenZip.CRC.Table;               
            // 0x00AD8898: CBNZ x21, #0xad88a0        | if (SevenZip.CRC.Table != null) goto label_3;
            if(SevenZip.CRC.Table != null)
            {
                goto label_3;
            }
            // 0x00AD889C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_3:
            // 0x00AD88A0: LDR w8, [x21, #0x18]       | W8 = SevenZip.CRC.Table.Length;         
            // 0x00AD88A4: AND w9, w20, #0xff         | W9 = (b & 255);                         
            byte val_1 = val_3 & 255;
            // 0x00AD88A8: EOR w20, w22, w9           | W20 = (this._value ^ (b & 255));        
            val_3 = this._value ^ val_1;
            // 0x00AD88AC: CMP w20, w8                | STATE = COMPARE((this._value ^ (b & 255)), SevenZip.CRC.Table.Length)
            // 0x00AD88B0: B.LO #0xad88c0             | if (b < SevenZip.CRC.Table.Length) goto label_4;
            if(val_3 < SevenZip.CRC.Table.Length)
            {
                goto label_4;
            }
            // 0x00AD88B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00AD88B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD88BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_4:
            // 0x00AD88C0: ADD x8, x21, x20, lsl #2   | X8 = (SevenZip.CRC.Table + ((this._value ^ (b & 255))) << 2);
            System.UInt32[] val_2 = SevenZip.CRC.Table + (((this._value ^ (b & 255))) << 2);
            // 0x00AD88C4: LDR w8, [x8, #0x20]        | W8 = (SevenZip.CRC.Table + ((this._value ^ (b & 255))) << 2) + 32; //  not_find_field!2:32
            uint val_4 = (SevenZip.CRC.Table + ((this._value ^ (b & 255))) << 2) + 32;
            // 0x00AD88C8: LDR w9, [x19, #0x10]       | W9 = this._value; //P2                  
            // 0x00AD88CC: EOR w8, w8, w9, lsr #8     | W8 = ((SevenZip.CRC.Table + ((this._value ^ (b & 255))) << 2) + 32 ^ (this._value) >> 8);
            val_4 = val_4 ^ (this._value >> 8);
            // 0x00AD88D0: STR w8, [x19, #0x10]       | this._value = ((SevenZip.CRC.Table + ((this._value ^ (b & 255))) << 2) + 32 ^ (this._value) >> 8);  //  dest_result_addr=1152921513059433632
            this._value = val_4;
            // 0x00AD88D4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD88D8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD88DC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD88E0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD88E4 (11372772), len: 264  VirtAddr: 0x00AD88E4 RVA: 0x00AD88E4 token: 100681427 methodIndex: 54756 delegateWrapperIndex: 0 methodInvoker: 0
        public void Update(byte[] data, uint offset, uint size)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x00AD88E4: STP x26, x25, [sp, #-0x50]! | stack[1152921513059570400] = ???;  stack[1152921513059570408] = ???;  //  dest_result_addr=1152921513059570400 |  dest_result_addr=1152921513059570408
            // 0x00AD88E8: STP x24, x23, [sp, #0x10]  | stack[1152921513059570416] = ???;  stack[1152921513059570424] = ???;  //  dest_result_addr=1152921513059570416 |  dest_result_addr=1152921513059570424
            // 0x00AD88EC: STP x22, x21, [sp, #0x20]  | stack[1152921513059570432] = ???;  stack[1152921513059570440] = ???;  //  dest_result_addr=1152921513059570432 |  dest_result_addr=1152921513059570440
            // 0x00AD88F0: STP x20, x19, [sp, #0x30]  | stack[1152921513059570448] = ???;  stack[1152921513059570456] = ???;  //  dest_result_addr=1152921513059570448 |  dest_result_addr=1152921513059570456
            // 0x00AD88F4: STP x29, x30, [sp, #0x40]  | stack[1152921513059570464] = ???;  stack[1152921513059570472] = ???;  //  dest_result_addr=1152921513059570464 |  dest_result_addr=1152921513059570472
            // 0x00AD88F8: ADD x29, sp, #0x40         | X29 = (1152921513059570400 + 64) = 1152921513059570464 (0x10000001F7D25320);
            // 0x00AD88FC: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
            // 0x00AD8900: LDRB w8, [x23, #0x511]     | W8 = (bool)static_value_03733511;       
            // 0x00AD8904: MOV w19, w3                | W19 = size;//m1                         
            val_3 = size;
            // 0x00AD8908: MOV w20, w2                | W20 = offset;//m1                       
            uint val_4 = offset;
            // 0x00AD890C: MOV x21, x1                | X21 = data;//m1                         
            // 0x00AD8910: MOV x22, x0                | X22 = 1152921513059582480 (0x10000001F7D28210);//ML01
            // 0x00AD8914: TBNZ w8, #0, #0xad8930     | if (static_value_03733511 == true) goto label_0;
            // 0x00AD8918: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00AD891C: LDR x8, [x8, #0x6e8]       | X8 = 0x2B92D80;                         
            // 0x00AD8920: LDR w0, [x8]               | W0 = 0x2225;                            
            // 0x00AD8924: BL #0x2782188              | X0 = sub_2782188( ?? 0x2225, ????);     
            // 0x00AD8928: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD892C: STRB w8, [x23, #0x511]     | static_value_03733511 = true;            //  dest_result_addr=57881873
            label_0:
            // 0x00AD8930: CBZ w19, #0xad89d4         | if (size == 0) goto label_1;            
            if(val_3 == 0)
            {
                goto label_1;
            }
            // 0x00AD8934: ADRP x23, #0x35c8000       | X23 = 56393728 (0x35C8000);             
            // 0x00AD8938: LDR x23, [x23, #0x988]     | X23 = 1152921504832512000;              
            val_2 = 1152921504832512000;
            label_8:
            // 0x00AD893C: LDR x0, [x23]              | X0 = typeof(SevenZip.CRC);              
            val_4 = null;
            // 0x00AD8940: LDRB w8, [x0, #0x10a]      | W8 = SevenZip.CRC.__il2cppRuntimeField_10A;
            // 0x00AD8944: TBZ w8, #0, #0xad8958      | if (SevenZip.CRC.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00AD8948: LDR w8, [x0, #0xbc]        | W8 = SevenZip.CRC.__il2cppRuntimeField_cctor_finished;
            // 0x00AD894C: CBNZ w8, #0xad8958         | if (SevenZip.CRC.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00AD8950: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SevenZip.CRC), ????);
            // 0x00AD8954: LDR x0, [x23]              | X0 = typeof(SevenZip.CRC);              
            val_4 = null;
            label_3:
            // 0x00AD8958: LDR x8, [x0, #0xa0]        | X8 = SevenZip.CRC.__il2cppRuntimeField_static_fields;
            // 0x00AD895C: LDRB w25, [x22, #0x10]     | W25 = this._value; //P2                 
            uint val_3 = this._value;
            // 0x00AD8960: LDR x24, [x8]              | X24 = SevenZip.CRC.Table;               
            // 0x00AD8964: CBNZ x21, #0xad896c        | if (data != null) goto label_4;         
            if(data != null)
            {
                goto label_4;
            }
            // 0x00AD8968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_4:
            // 0x00AD896C: LDR w8, [x21, #0x18]       | W8 = data.Length; //P2                  
            // 0x00AD8970: SXTW x26, w20              | X26 = (long)(int)(offset);              
            // 0x00AD8974: CMP w20, w8                | STATE = COMPARE(offset, data.Length)    
            // 0x00AD8978: B.LO #0xad8988             | if (offset < data.Length) goto label_5; 
            if(val_4 < data.Length)
            {
                goto label_5;
            }
            // 0x00AD897C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00AD8980: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD8984: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_5:
            // 0x00AD8988: ADD x8, x21, x26           | X8 = data[(long)(int)(offset)]; //PARR1 
            // 0x00AD898C: LDRB w26, [x8, #0x20]      | W26 = data[(long)(int)(offset)][0]      
            byte val_2 = data[(long)val_4];
            // 0x00AD8990: CBNZ x24, #0xad8998        | if (SevenZip.CRC.Table != null) goto label_6;
            if(SevenZip.CRC.Table != null)
            {
                goto label_6;
            }
            // 0x00AD8994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_6:
            // 0x00AD8998: LDR w8, [x24, #0x18]       | W8 = SevenZip.CRC.Table.Length;         
            // 0x00AD899C: EOR w25, w26, w25          | W25 = (data[(long)(int)(offset)][0] ^ this._value);
            val_3 = val_2 ^ val_3;
            // 0x00AD89A0: CMP w25, w8                | STATE = COMPARE((data[(long)(int)(offset)][0] ^ this._value), SevenZip.CRC.Table.Length)
            // 0x00AD89A4: B.LO #0xad89b4             | if (this._value < SevenZip.CRC.Table.Length) goto label_7;
            if(val_3 < SevenZip.CRC.Table.Length)
            {
                goto label_7;
            }
            // 0x00AD89A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00AD89AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD89B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_7:
            // 0x00AD89B4: ADD x8, x24, x25, lsl #2   | X8 = (SevenZip.CRC.Table + ((data[(long)(int)(offset)][0] ^ this._value)) << 2);
            System.UInt32[] val_1 = SevenZip.CRC.Table + (((data[(long)(int)(offset)][0] ^ this._value)) << 2);
            // 0x00AD89B8: LDR w9, [x22, #0x10]       | W9 = this._value; //P2                  
            // 0x00AD89BC: LDR w8, [x8, #0x20]        | W8 = (SevenZip.CRC.Table + ((data[(long)(int)(offset)][0] ^ this._value)) << 2) + 32; //  not_find_field!2:32
            uint val_5 = (SevenZip.CRC.Table + ((data[(long)(int)(offset)][0] ^ this._value)) << 2) + 32;
            // 0x00AD89C0: SUB w19, w19, #1           | W19 = (size - 1);                       
            val_3 = val_3 - 1;
            // 0x00AD89C4: ADD w20, w20, #1           | W20 = (offset + 1);                     
            val_4 = val_4 + 1;
            // 0x00AD89C8: EOR w8, w8, w9, lsr #8     | W8 = ((SevenZip.CRC.Table + ((data[(long)(int)(offset)][0] ^ this._value)) << 2) + 32 ^ (this._value
            val_5 = val_5 ^ (this._value >> 8);
            // 0x00AD89CC: STR w8, [x22, #0x10]       | this._value = ((SevenZip.CRC.Table + ((data[(long)(int)(offset)][0] ^ this._value)) << 2) + 32 ^ (this._value) >> 8);  //  dest_result_addr=1152921513059582496
            this._value = val_5;
            // 0x00AD89D0: CBNZ w19, #0xad893c        | if ((size - 1) != 0) goto label_8;      
            if(val_3 != 0)
            {
                goto label_8;
            }
            label_1:
            // 0x00AD89D4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD89D8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD89DC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD89E0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD89E4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AD89E8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD89EC (11373036), len: 12  VirtAddr: 0x00AD89EC RVA: 0x00AD89EC token: 100681428 methodIndex: 54757 delegateWrapperIndex: 0 methodInvoker: 0
        public uint GetDigest()
        {
            //
            // Disasemble & Code
            // 0x00AD89EC: LDR w8, [x0, #0x10]        | W8 = this._value; //P2                  
            // 0x00AD89F0: MVN w0, w8                 | W0 = ~(this._value);                    
            // 0x00AD89F4: RET                        |  return (System.UInt32)~(this._value);  
            return (uint)~this._value;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD89F8 (11373048), len: 180  VirtAddr: 0x00AD89F8 RVA: 0x00AD89F8 token: 100681429 methodIndex: 54758 delegateWrapperIndex: 0 methodInvoker: 0
        private static uint CalculateDigest(byte[] data, uint offset, uint size)
        {
            //
            // Disasemble & Code
            // 0x00AD89F8: STP x22, x21, [sp, #-0x30]! | stack[1152921513059868160] = ???;  stack[1152921513059868168] = ???;  //  dest_result_addr=1152921513059868160 |  dest_result_addr=1152921513059868168
            // 0x00AD89FC: STP x20, x19, [sp, #0x10]  | stack[1152921513059868176] = ???;  stack[1152921513059868184] = ???;  //  dest_result_addr=1152921513059868176 |  dest_result_addr=1152921513059868184
            // 0x00AD8A00: STP x29, x30, [sp, #0x20]  | stack[1152921513059868192] = ???;  stack[1152921513059868200] = ???;  //  dest_result_addr=1152921513059868192 |  dest_result_addr=1152921513059868200
            // 0x00AD8A04: ADD x29, sp, #0x20         | X29 = (1152921513059868160 + 32) = 1152921513059868192 (0x10000001F7D6DE20);
            // 0x00AD8A08: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00AD8A0C: LDRB w8, [x22, #0x512]     | W8 = (bool)static_value_03733512;       
            // 0x00AD8A10: MOV w19, w3                | W19 = W3;//m1                           
            // 0x00AD8A14: MOV w20, w2                | W20 = size;//m1                         
            // 0x00AD8A18: MOV x21, x1                | X21 = offset;//m1                       
            // 0x00AD8A1C: TBNZ w8, #0, #0xad8a38     | if (static_value_03733512 == true) goto label_0;
            // 0x00AD8A20: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x00AD8A24: LDR x8, [x8, #0x768]       | X8 = 0x2B92D7C;                         
            // 0x00AD8A28: LDR w0, [x8]               | W0 = 0x2224;                            
            // 0x00AD8A2C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2224, ????);     
            // 0x00AD8A30: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD8A34: STRB w8, [x22, #0x512]     | static_value_03733512 = true;            //  dest_result_addr=57881874
            label_0:
            // 0x00AD8A38: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AD8A3C: LDR x8, [x8, #0x988]       | X8 = 1152921504832512000;               
            // 0x00AD8A40: LDR x0, [x8]               | X0 = typeof(SevenZip.CRC);              
            object val_1 = null;
            // 0x00AD8A44: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(SevenZip.CRC), ????);
            // 0x00AD8A48: MOV x22, x0                | X22 = 1152921504832512000 (0x100000000D736000);//ML01
            // 0x00AD8A4C: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x00AD8A50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD8A54: STR w8, [x22, #0x10]       | typeof(SevenZip.CRC).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504832512016
            typeof(SevenZip.CRC).__il2cppRuntimeField_10 = 0;
            // 0x00AD8A58: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AD8A5C: CBZ x22, #0xad8a78         | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x00AD8A60: MOV x0, x22                | X0 = 1152921504832512000 (0x100000000D736000);//ML01
            // 0x00AD8A64: MOV x1, x21                | X1 = offset;//m1                        
            // 0x00AD8A68: MOV w2, w20                | W2 = size;//m1                          
            // 0x00AD8A6C: MOV w3, w19                | W3 = W3;//m1                            
            // 0x00AD8A70: BL #0xad88e4               | Update(data:  offset, offset:  size, size:  W3);
            Update(data:  offset, offset:  size, size:  W3);
            // 0x00AD8A74: B #0xad8a94                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00AD8A78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x00AD8A7C: MOV x0, x22                | X0 = 1152921504832512000 (0x100000000D736000);//ML01
            // 0x00AD8A80: MOV x1, x21                | X1 = offset;//m1                        
            // 0x00AD8A84: MOV w2, w20                | W2 = size;//m1                          
            // 0x00AD8A88: MOV w3, w19                | W3 = W3;//m1                            
            // 0x00AD8A8C: BL #0xad88e4               | Update(data:  offset, offset:  size, size:  W3);
            Update(data:  offset, offset:  size, size:  W3);
            // 0x00AD8A90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_2:
            // 0x00AD8A94: LDR w8, [x22, #0x10]       | W8 = 0x0;                               
            // 0x00AD8A98: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD8A9C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD8AA0: MVN w0, w8                 | W0 = 0 (0x0);//ML01                     
            // 0x00AD8AA4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD8AA8: RET                        |  return (System.UInt32)null;            
            return (uint)typeof(SevenZip.CRC).__il2cppRuntimeField_10;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD8AAC (11373228), len: 148  VirtAddr: 0x00AD8AAC RVA: 0x00AD8AAC token: 100681430 methodIndex: 54759 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool VerifyDigest(uint digest, byte[] data, uint offset, uint size)
        {
            //
            // Disasemble & Code
            // 0x00AD8AAC: STP x24, x23, [sp, #-0x40]! | stack[1152921513060053872] = ???;  stack[1152921513060053880] = ???;  //  dest_result_addr=1152921513060053872 |  dest_result_addr=1152921513060053880
            // 0x00AD8AB0: STP x22, x21, [sp, #0x10]  | stack[1152921513060053888] = ???;  stack[1152921513060053896] = ???;  //  dest_result_addr=1152921513060053888 |  dest_result_addr=1152921513060053896
            // 0x00AD8AB4: STP x20, x19, [sp, #0x20]  | stack[1152921513060053904] = ???;  stack[1152921513060053912] = ???;  //  dest_result_addr=1152921513060053904 |  dest_result_addr=1152921513060053912
            // 0x00AD8AB8: STP x29, x30, [sp, #0x30]  | stack[1152921513060053920] = ???;  stack[1152921513060053928] = ???;  //  dest_result_addr=1152921513060053920 |  dest_result_addr=1152921513060053928
            // 0x00AD8ABC: ADD x29, sp, #0x30         | X29 = (1152921513060053872 + 48) = 1152921513060053920 (0x10000001F7D9B3A0);
            // 0x00AD8AC0: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
            // 0x00AD8AC4: LDRB w8, [x23, #0x513]     | W8 = (bool)static_value_03733513;       
            // 0x00AD8AC8: MOV w19, w4                | W19 = W4;//m1                           
            // 0x00AD8ACC: MOV w21, w3                | W21 = size;//m1                         
            // 0x00AD8AD0: MOV x22, x2                | X22 = offset;//m1                       
            // 0x00AD8AD4: MOV w20, w1                | W20 = data;//m1                         
            // 0x00AD8AD8: TBNZ w8, #0, #0xad8af4     | if (static_value_03733513 == true) goto label_0;
            // 0x00AD8ADC: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00AD8AE0: LDR x8, [x8, #0xeb0]       | X8 = 0x2B92D88;                         
            // 0x00AD8AE4: LDR w0, [x8]               | W0 = 0x2227;                            
            // 0x00AD8AE8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2227, ????);     
            // 0x00AD8AEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD8AF0: STRB w8, [x23, #0x513]     | static_value_03733513 = true;            //  dest_result_addr=57881875
            label_0:
            // 0x00AD8AF4: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AD8AF8: LDR x8, [x8, #0x988]       | X8 = 1152921504832512000;               
            // 0x00AD8AFC: LDR x0, [x8]               | X0 = typeof(SevenZip.CRC);              
            // 0x00AD8B00: LDRB w8, [x0, #0x10a]      | W8 = SevenZip.CRC.__il2cppRuntimeField_10A;
            // 0x00AD8B04: TBZ w8, #0, #0xad8b14      | if (SevenZip.CRC.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AD8B08: LDR w8, [x0, #0xbc]        | W8 = SevenZip.CRC.__il2cppRuntimeField_cctor_finished;
            // 0x00AD8B0C: CBNZ w8, #0xad8b14         | if (SevenZip.CRC.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AD8B10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SevenZip.CRC), ????);
            label_2:
            // 0x00AD8B14: MOV x1, x22                | X1 = offset;//m1                        
            // 0x00AD8B18: MOV w2, w21                | W2 = size;//m1                          
            // 0x00AD8B1C: MOV w3, w19                | W3 = W4;//m1                            
            // 0x00AD8B20: BL #0xad89f8               | X0 = SevenZip.CRC.CalculateDigest(data:  null, offset:  offset, size:  size);
            uint val_1 = SevenZip.CRC.CalculateDigest(data:  null, offset:  offset, size:  size);
            // 0x00AD8B24: CMP w0, w20                | STATE = COMPARE(val_1, data)            
            // 0x00AD8B28: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD8B2C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD8B30: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD8B34: CSET w0, eq                | W0 = val_1 == data ? 1 : 0;             
            var val_2 = (val_1 == data) ? 1 : 0;
            // 0x00AD8B38: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AD8B3C: RET                        |  return (System.Boolean)val_1 == data ? 1 : 0;
            return (bool)val_2;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
    
    }

}
