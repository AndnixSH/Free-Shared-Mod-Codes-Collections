using UnityEngine;
public class AICtrl
{
    // Fields
    private CombatEntity entity; //  0x00000010
    private System.Collections.Generic.List<AIObject> aiList; //  0x00000018
    public readonly System.Collections.Generic.Dictionary<AIEnum.EAIEventtype, System.Collections.Generic.List<AIEventInfo>> aiObjDic; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B20AA0 (11668128), len: 172  VirtAddr: 0x00B20AA0 RVA: 0x00B20AA0 token: 100691849 methodIndex: 24710 delegateWrapperIndex: 0 methodInvoker: 0
    public AICtrl(CombatEntity entity)
    {
        //
        // Disasemble & Code
        // 0x00B20AA0: STP x22, x21, [sp, #-0x30]! | stack[1152921514723449648] = ???;  stack[1152921514723449656] = ???;  //  dest_result_addr=1152921514723449648 |  dest_result_addr=1152921514723449656
        // 0x00B20AA4: STP x20, x19, [sp, #0x10]  | stack[1152921514723449664] = ???;  stack[1152921514723449672] = ???;  //  dest_result_addr=1152921514723449664 |  dest_result_addr=1152921514723449672
        // 0x00B20AA8: STP x29, x30, [sp, #0x20]  | stack[1152921514723449680] = ???;  stack[1152921514723449688] = ???;  //  dest_result_addr=1152921514723449680 |  dest_result_addr=1152921514723449688
        // 0x00B20AAC: ADD x29, sp, #0x20         | X29 = (1152921514723449648 + 32) = 1152921514723449680 (0x100000025AFF1B50);
        // 0x00B20AB0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B20AB4: LDRB w8, [x21, #0x720]     | W8 = (bool)static_value_03733720;       
        // 0x00B20AB8: MOV x19, x1                | X19 = entity;//m1                       
        // 0x00B20ABC: MOV x20, x0                | X20 = 1152921514723461696 (0x100000025AFF4A40);//ML01
        // 0x00B20AC0: TBNZ w8, #0, #0xb20adc     | if (static_value_03733720 == true) goto label_0;
        // 0x00B20AC4: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00B20AC8: LDR x8, [x8, #0x228]       | X8 = 0x2B8AACC;                         
        // 0x00B20ACC: LDR w0, [x8]               | W0 = 0x171;                             
        // 0x00B20AD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x171, ????);      
        // 0x00B20AD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B20AD8: STRB w8, [x21, #0x720]     | static_value_03733720 = true;            //  dest_result_addr=57882400
        label_0:
        // 0x00B20ADC: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
        // 0x00B20AE0: LDR x8, [x8, #0x488]       | X8 = 1152921504616644608;               
        // 0x00B20AE4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<AIObject> val_1 = null;
        // 0x00B20AE8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B20AEC: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x00B20AF0: LDR x8, [x8, #0x9e8]       | X8 = 1152921514700041216;               
        // 0x00B20AF4: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B20AF8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<AIObject>::.ctor();
        // 0x00B20AFC: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<AIObject>();
        // 0x00B20B00: STR x21, [x20, #0x18]      | this.aiList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514723461720
        this.aiList = val_1;
        // 0x00B20B04: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B20B08: LDR x8, [x8, #0x130]       | X8 = 1152921504615792640;               
        // 0x00B20B0C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<AIEnum.EAIEventtype, System.Collections.Generic.List<AIEventInfo>> val_2 = null;
        // 0x00B20B10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B20B14: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
        // 0x00B20B18: LDR x8, [x8, #0x8b8]       | X8 = 1152921514723436672;               
        // 0x00B20B1C: MOV x21, x0                | X21 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B20B20: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<AIEnum.EAIEventtype, System.Collections.Generic.List<AIEventInfo>>::.ctor();
        // 0x00B20B24: BL #0x219e828              | .ctor();                                
        val_2 = new System.Collections.Generic.Dictionary<AIEnum.EAIEventtype, System.Collections.Generic.List<AIEventInfo>>();
        // 0x00B20B28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20B2C: MOV x0, x20                | X0 = 1152921514723461696 (0x100000025AFF4A40);//ML01
        // 0x00B20B30: STR x21, [x20, #0x20]      | this.aiObjDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921514723461728
        this.aiObjDic = val_2;
        // 0x00B20B34: BL #0x16f59f0              | this..ctor();                           
        // 0x00B20B38: STR x19, [x20, #0x10]      | this.entity = entity;                    //  dest_result_addr=1152921514723461712
        this.entity = entity;
        // 0x00B20B3C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B20B40: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B20B44: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B20B48: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B20B4C (11668300), len: 764  VirtAddr: 0x00B20B4C RVA: 0x00B20B4C token: 100691850 methodIndex: 24711 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init(string[] aiIDs)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        //  | 
        System.String[] val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        //  | 
        var val_17;
        // 0x00B20B4C: STP x28, x27, [sp, #-0x60]! | stack[1152921514723637376] = ???;  stack[1152921514723637384] = ???;  //  dest_result_addr=1152921514723637376 |  dest_result_addr=1152921514723637384
        // 0x00B20B50: STP x26, x25, [sp, #0x10]  | stack[1152921514723637392] = ???;  stack[1152921514723637400] = ???;  //  dest_result_addr=1152921514723637392 |  dest_result_addr=1152921514723637400
        // 0x00B20B54: STP x24, x23, [sp, #0x20]  | stack[1152921514723637408] = ???;  stack[1152921514723637416] = ???;  //  dest_result_addr=1152921514723637408 |  dest_result_addr=1152921514723637416
        // 0x00B20B58: STP x22, x21, [sp, #0x30]  | stack[1152921514723637424] = ???;  stack[1152921514723637432] = ???;  //  dest_result_addr=1152921514723637424 |  dest_result_addr=1152921514723637432
        // 0x00B20B5C: STP x20, x19, [sp, #0x40]  | stack[1152921514723637440] = ???;  stack[1152921514723637448] = ???;  //  dest_result_addr=1152921514723637440 |  dest_result_addr=1152921514723637448
        // 0x00B20B60: STP x29, x30, [sp, #0x50]  | stack[1152921514723637456] = ???;  stack[1152921514723637464] = ???;  //  dest_result_addr=1152921514723637456 |  dest_result_addr=1152921514723637464
        // 0x00B20B64: ADD x29, sp, #0x50         | X29 = (1152921514723637376 + 80) = 1152921514723637456 (0x100000025B01F8D0);
        // 0x00B20B68: MOV x22, x1                | X22 = aiIDs;//m1                        
        val_13 = aiIDs;
        // 0x00B20B6C: STR x22, [sp, #-0x10]!     | stack[1152921514723637360] = aiIDs;      //  dest_result_addr=1152921514723637360
        // 0x00B20B70: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B20B74: LDRB w8, [x19, #0x721]     | W8 = (bool)static_value_03733721;       
        // 0x00B20B78: MOV x20, x0                | X20 = 1152921514723649472 (0x100000025B0227C0);//ML01
        // 0x00B20B7C: TBNZ w8, #0, #0xb20b98     | if (static_value_03733721 == true) goto label_0;
        // 0x00B20B80: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B20B84: LDR x8, [x8, #0x9c8]       | X8 = 0x2B8AAD8;                         
        // 0x00B20B88: LDR w0, [x8]               | W0 = 0x174;                             
        // 0x00B20B8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x174, ????);      
        // 0x00B20B90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B20B94: STRB w8, [x19, #0x721]     | static_value_03733721 = true;            //  dest_result_addr=57882401
        label_0:
        // 0x00B20B98: ADRP x25, #0x3668000       | X25 = 57049088 (0x3668000);             
        // 0x00B20B9C: ADRP x19, #0x362e000       | X19 = 56811520 (0x362E000);             
        // 0x00B20BA0: ADRP x26, #0x35c7000       | X26 = 56389632 (0x35C7000);             
        // 0x00B20BA4: ADRP x27, #0x35f0000       | X27 = 56557568 (0x35F0000);             
        // 0x00B20BA8: LDR x25, [x25, #0x960]     | X25 = 1152921504911851520;              
        // 0x00B20BAC: LDR x19, [x19, #0x828]     | X19 = 1152921514723590656;              
        // 0x00B20BB0: LDR x26, [x26, #0xac8]     | X26 = 1152921514723591680;              
        val_14 = 1152921514723591680;
        // 0x00B20BB4: LDR x27, [x27, #0xf40]     | X27 = 1152921504895344640;              
        val_15 = 1152921504895344640;
        // 0x00B20BB8: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        val_16 = 0;
        // 0x00B20BBC: B #0xb20be0                |  goto label_1;                          
        goto label_1;
        label_27:
        // 0x00B20BC0: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B20BC4: LDR x8, [x8, #0xae0]       | X8 = 1152921514723592704;               
        // 0x00B20BC8: MOV x0, x22                | X0 = aiIDs;//m1                         
        // 0x00B20BCC: MOV x1, x21                | X1 = X21;//m1                           
        // 0x00B20BD0: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<AIObject>::Add(AIObject item);
        // 0x00B20BD4: BL #0x25ea480              | aiIDs.Add(item:  X21);                  
        val_13.Add(item:  X21);
        // 0x00B20BD8: LDP x22, x23, [sp]         | X22 = aiIDs; X23 = val_1;                //  |  find_add[1152921514723625472]
        val_13 = val_13;
        // 0x00B20BDC: ADD w23, w23, #1           | W23 = (val_1 + 1);                      
        val_16 = val_1 + 1;
        label_1:
        // 0x00B20BE0: CBNZ x22, #0xb20be8        | if (aiIDs != 0) goto label_2;           
        if(val_13 != 0)
        {
            goto label_2;
        }
        // 0x00B20BE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? aiIDs, ????);      
        label_2:
        // 0x00B20BE8: LDR w8, [x22, #0x18]       | W8 = aiIDs + 24;                        
        // 0x00B20BEC: CMP w23, w8                | STATE = COMPARE((val_1 + 1), aiIDs + 24)
        // 0x00B20BF0: B.GE #0xb20e28             | if (val_16 >= aiIDs + 24) goto label_3; 
        if(val_16 >= (aiIDs + 24))
        {
            goto label_3;
        }
        // 0x00B20BF4: SXTW x21, w23              | X21 = (long)(int)((val_1 + 1));         
        // 0x00B20BF8: CMP w23, w8                | STATE = COMPARE((val_1 + 1), aiIDs + 24)
        // 0x00B20BFC: B.LO #0xb20c0c             | if (val_16 < aiIDs + 24) goto label_4;  
        if(val_16 < (aiIDs + 24))
        {
            goto label_4;
        }
        // 0x00B20C00: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? aiIDs, ????);      
        // 0x00B20C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20C08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? aiIDs, ????);      
        label_4:
        // 0x00B20C0C: ADD x8, x22, x21, lsl #3   | X8 = (aiIDs + ((long)(int)((val_1 + 1))) << 3);
        System.String[] val_2 = val_13 + (((long)(int)((val_1 + 1))) << 3);
        // 0x00B20C10: LDR x1, [x8, #0x20]        | X1 = (aiIDs + ((long)(int)((val_1 + 1))) << 3) + 32;
        // 0x00B20C14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20C18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20C1C: STR x23, [sp, #8]          | val_1 = (val_1 + 1);                     //  dest_result_addr=1152921514723637368
        val_1 = val_16;
        // 0x00B20C20: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_3 = System.Int32.Parse(s:  0);
        // 0x00B20C24: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B20C28: LDR x8, [x8, #0xd8]        | X8 = 1152921504895451136;               
        // 0x00B20C2C: MOV w22, w0                | W22 = val_3;//m1                        
        // 0x00B20C30: LDR x8, [x8]               | X8 = typeof(AIObject);                  
        // 0x00B20C34: MOV x0, x8                 | X0 = 1152921504895451136 (0x100000001133C000);//ML01
        AIObject val_4 = null;
        // 0x00B20C38: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AIObject), ????);
        // 0x00B20C3C: MOV w1, w22                | W1 = val_3;//m1                         
        // 0x00B20C40: MOV x21, x0                | X21 = 1152921504895451136 (0x100000001133C000);//ML01
        // 0x00B20C44: BL #0xb20e48               | .ctor(id:  val_3);                      
        val_4 = new AIObject(id:  val_3);
        // 0x00B20C48: CBNZ x21, #0xb20c50        | if ( != 0) goto label_5;                
        if(null != 0)
        {
            goto label_5;
        }
        // 0x00B20C4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(id:  val_3), ????);
        label_5:
        // 0x00B20C50: LDR x8, [x21, #0x28]       | X8 = AIObject.__il2cppRuntimeField_this_arg;
        // 0x00B20C54: CBZ x8, #0xb20e18          | if (AIObject.__il2cppRuntimeField_this_arg == 0) goto label_10;
        // 0x00B20C58: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
        val_17 = 0;
        // 0x00B20C5C: B #0xb20c7c                |  goto label_7;                          
        goto label_7;
        label_25:
        // 0x00B20C60: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00B20C64: LDR x8, [x8, #0xd00]       | X8 = 1152921514723593728;               
        // 0x00B20C68: MOV x0, x23                | X0 = (val_1 + 1);//m1                   
        // 0x00B20C6C: MOV x1, x24                | X1 = X24;//m1                           
        // 0x00B20C70: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<AIEventInfo>::Add(AIEventInfo item);
        // 0x00B20C74: BL #0x25ea480              | (val_1 + 1).Add(item:  X24);            
        val_16.Add(item:  X24);
        // 0x00B20C78: ADD w28, w28, #1           | W28 = (val_17 + 1) = val_17 (0x00000001);
        val_17 = 1;
        label_7:
        // 0x00B20C7C: CBNZ x21, #0xb20c84        | if ( != 0) goto label_8;                
        if(null != 0)
        {
            goto label_8;
        }
        // 0x00B20C80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_1 + 1), ????);
        label_8:
        // 0x00B20C84: LDR x22, [x21, #0x28]      | X22 = AIObject.__il2cppRuntimeField_this_arg;
        // 0x00B20C88: CBNZ x22, #0xb20c90        | if (AIObject.__il2cppRuntimeField_this_arg != 0) goto label_9;
        // 0x00B20C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_1 + 1), ????);
        label_9:
        // 0x00B20C90: LDR w8, [x22, #0x18]       | W8 = AIObject.__il2cppRuntimeField_this_arg + 24; //  not_find_field!2:24
        // 0x00B20C94: CMP w28, w8                | STATE = COMPARE(0x1, AIObject.__il2cppRuntimeField_this_arg + 24)
        // 0x00B20C98: B.GE #0xb20e18             | if (val_17 >= AIObject.__il2cppRuntimeField_this_arg + 24) goto label_10;
        // 0x00B20C9C: LDR x0, [x25]              | X0 = typeof(ZMG);                       
        // 0x00B20CA0: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B20CA4: TBZ w8, #0, #0xb20cb4      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B20CA8: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B20CAC: CBNZ w8, #0xb20cb4         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B20CB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_12:
        // 0x00B20CB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20CB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20CBC: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
        CSDatacfgManager val_5 = ZMG.CfgDataMgr;
        // 0x00B20CC0: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00B20CC4: CBNZ x21, #0xb20ccc        | if ( != 0) goto label_13;               
        if(null != 0)
        {
            goto label_13;
        }
        // 0x00B20CC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_13:
        // 0x00B20CCC: LDR x23, [x21, #0x28]      | X23 = AIObject.__il2cppRuntimeField_this_arg;
        // 0x00B20CD0: CBNZ x23, #0xb20cd8        | if (AIObject.__il2cppRuntimeField_this_arg != 0) goto label_14;
        // 0x00B20CD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_14:
        // 0x00B20CD8: LDR w8, [x23, #0x18]       | W8 = AIObject.__il2cppRuntimeField_this_arg + 24; //  not_find_field!2:24
        // 0x00B20CDC: SXTW x24, w28              | X24 = 1 (0x00000001);                   
        // 0x00B20CE0: CMP w28, w8                | STATE = COMPARE(0x1, AIObject.__il2cppRuntimeField_this_arg + 24)
        // 0x00B20CE4: B.LO #0xb20cf4             | if (val_17 < AIObject.__il2cppRuntimeField_this_arg + 24) goto label_15;
        // 0x00B20CE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
        // 0x00B20CEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20CF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_15:
        // 0x00B20CF4: ADD x8, x23, x24, lsl #2   | X8 = (AIObject.__il2cppRuntimeField_this_arg + 4);
        // 0x00B20CF8: LDR w23, [x8, #0x20]       | W23 = (AIObject.__il2cppRuntimeField_this_arg + 4) + 32; //  not_find_field!2:32
        // 0x00B20CFC: CBNZ x22, #0xb20d04        | if (val_5 != null) goto label_16;       
        if(val_5 != null)
        {
            goto label_16;
        }
        // 0x00B20D00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_16:
        // 0x00B20D04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20D08: MOV x0, x22                | X0 = val_5;//m1                         
        // 0x00B20D0C: MOV w1, w23                | W1 = (AIObject.__il2cppRuntimeField_this_arg + 4) + 32;//m1
        // 0x00B20D10: BL #0xb48e58               | X0 = val_5.GetnpcAIConditionCfg(id:  (AIObject.__il2cppRuntimeField_this_arg + 4) + 32);
        npcAIConditionCfg val_7 = val_5.GetnpcAIConditionCfg(id:  (AIObject.__il2cppRuntimeField_this_arg + 4) + 32);
        // 0x00B20D14: MOV x22, x0                | X22 = val_7;//m1                        
        // 0x00B20D18: CBNZ x22, #0xb20d20        | if (val_7 != null) goto label_17;       
        if(val_7 != null)
        {
            goto label_17;
        }
        // 0x00B20D1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_17:
        // 0x00B20D20: LDR w23, [x22, #0x18]      | W23 = val_7.eventtype; //P2             
        // 0x00B20D24: LDR x24, [x20, #0x20]      | X24 = this.aiObjDic; //P2               
        // 0x00B20D28: CBNZ x24, #0xb20d30        | if (this.aiObjDic != null) goto label_18;
        if(this.aiObjDic != null)
        {
            goto label_18;
        }
        // 0x00B20D2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_18:
        // 0x00B20D30: LDR x2, [x19]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<AIEnum.EAIEventtype, System.Collections.Generic.List<AIEventInfo>>::ContainsKey(AIEnum.EAIEventtype key);
        // 0x00B20D34: MOV x0, x24                | X0 = this.aiObjDic;//m1                 
        // 0x00B20D38: MOV w1, w23                | W1 = val_7.eventtype;//m1               
        // 0x00B20D3C: BL #0x21a10e8              | X0 = this.aiObjDic.ContainsKey(key:  val_7.eventtype);
        bool val_8 = this.aiObjDic.ContainsKey(key:  val_7.eventtype);
        // 0x00B20D40: AND w8, w0, #1             | W8 = (val_8 & 1);                       
        bool val_9 = val_8;
        // 0x00B20D44: TBNZ w8, #0, #0xb20db4     | if ((val_8 & 1) == true) goto label_19; 
        if(val_9 == true)
        {
            goto label_19;
        }
        // 0x00B20D48: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00B20D4C: LDR x24, [x20, #0x20]      | X24 = this.aiObjDic; //P2               
        // 0x00B20D50: LDR x8, [x8, #0x5f0]       | X8 = 1152921504616644608;               
        // 0x00B20D54: MOV x27, x26               | X27 = 58058256 (0x375E610);//ML01       
        // 0x00B20D58: MOV x26, x19               | X26 = 58058232 (0x375E5F8);//ML01       
        // 0x00B20D5C: MOV x19, x25               | X19 = 57994112 (0x374EB80);//ML01       
        // 0x00B20D60: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<AIEventInfo> val_10 = null;
        // 0x00B20D64: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B20D68: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
        // 0x00B20D6C: LDR x8, [x8, #0x98]        | X8 = 1152921514723611136;               
        // 0x00B20D70: MOV x25, x0                | X25 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B20D74: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<AIEventInfo>::.ctor();
        // 0x00B20D78: BL #0x25e9474              | .ctor();                                
        val_10 = new System.Collections.Generic.List<AIEventInfo>();
        // 0x00B20D7C: CBNZ x24, #0xb20d84        | if (this.aiObjDic != null) goto label_20;
        if(this.aiObjDic != null)
        {
            goto label_20;
        }
        // 0x00B20D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_20:
        // 0x00B20D84: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00B20D88: LDR x8, [x8, #0xdf0]       | X8 = 1152921514723612160;               
        // 0x00B20D8C: MOV x0, x24                | X0 = this.aiObjDic;//m1                 
        // 0x00B20D90: MOV w1, w23                | W1 = val_7.eventtype;//m1               
        // 0x00B20D94: MOV x2, x25                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B20D98: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<AIEnum.EAIEventtype, System.Collections.Generic.List<AIEventInfo>>::Add(AIEnum.EAIEventtype key, System.Collections.Generic.List<AIEventInfo> value);
        // 0x00B20D9C: BL #0x21a0b74              | this.aiObjDic.Add(key:  val_7.eventtype, value:  val_10);
        this.aiObjDic.Add(key:  val_7.eventtype, value:  val_10);
        // 0x00B20DA0: MOV x25, x19               | X25 = 57994112 (0x374EB80);//ML01       
        // 0x00B20DA4: MOV x19, x26               | X19 = 58058232 (0x375E5F8);//ML01       
        // 0x00B20DA8: MOV x26, x27               | X26 = 58058256 (0x375E610);//ML01       
        val_14 = val_14;
        // 0x00B20DAC: ADRP x27, #0x35f0000       | X27 = 56557568 (0x35F0000);             
        // 0x00B20DB0: LDR x27, [x27, #0xf40]     | X27 = 1152921504895344640;              
        val_15 = 1152921504895344640;
        label_19:
        // 0x00B20DB4: LDR x24, [x20, #0x20]      | X24 = this.aiObjDic; //P2               
        // 0x00B20DB8: CBNZ x24, #0xb20dc0        | if (this.aiObjDic != null) goto label_21;
        if(this.aiObjDic != null)
        {
            goto label_21;
        }
        // 0x00B20DBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.aiObjDic, ????);
        label_21:
        // 0x00B20DC0: LDR x2, [x26]              | X2 = public System.Collections.Generic.List<AIEventInfo> System.Collections.Generic.Dictionary<AIEnum.EAIEventtype, System.Collections.Generic.List<AIEventInfo>>::get_Item(AIEnum.EAIEventtype key);
        // 0x00B20DC4: MOV x0, x24                | X0 = this.aiObjDic;//m1                 
        // 0x00B20DC8: MOV w1, w23                | W1 = val_7.eventtype;//m1               
        // 0x00B20DCC: BL #0x219f9f8              | X0 = this.aiObjDic.get_Item(key:  val_7.eventtype);
        System.Collections.Generic.List<AIEventInfo> val_11 = this.aiObjDic.Item[val_7.eventtype];
        // 0x00B20DD0: LDR x8, [x27]              | X8 = static_value_0374EBB8;             
        // 0x00B20DD4: MOV x23, x0                | X23 = val_11;//m1                       
        // 0x00B20DD8: MOV x0, x8                 | X0 = static_value_0374EBB8;//m1         
        object val_12 = static_value_0374EBB8;
        // 0x00B20DDC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? static_value_0374EBB8, ????);
        // 0x00B20DE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20DE4: MOV x24, x0                | X24 = static_value_0374EBB8;//m1        
        // 0x00B20DE8: BL #0x16f59f0              | static_value_0374EBB8..ctor();          
        val_12 = new System.Object();
        // 0x00B20DEC: CBZ x24, #0xb20df8         | if (static_value_0374EBB8 == 0) goto label_22;
        // 0x00B20DF0: STR x21, [x24, #0x10]      | mem2[0] = typeof(AIObject);              //  dest_result_addr=0
        mem2[0] = val_4;
        // 0x00B20DF4: B #0xb20e08                |  goto label_23;                         
        goto label_23;
        label_22:
        // 0x00B20DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? static_value_0374EBB8..ctor(), ????);
        // 0x00B20DFC: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
        // 0x00B20E00: STR x21, [x8]              | mem[16] = typeof(AIObject);              //  dest_result_addr=16
        mem[16] = val_4;
        // 0x00B20E04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? static_value_0374EBB8..ctor(), ????);
        label_23:
        // 0x00B20E08: STR x22, [x24, #0x18]      | mem2[0] = val_7;                         //  dest_result_addr=0
        mem2[0] = val_7;
        // 0x00B20E0C: CBNZ x23, #0xb20c60        | if (val_11 != null) goto label_25;      
        if(val_11 != null)
        {
            goto label_25;
        }
        // 0x00B20E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? static_value_0374EBB8..ctor(), ????);
        // 0x00B20E14: B #0xb20c60                |  goto label_25;                         
        goto label_25;
        label_10:
        // 0x00B20E18: LDR x22, [x20, #0x18]      | X22 = this.aiList; //P2                 
        // 0x00B20E1C: CBNZ x22, #0xb20bc0        | if (this.aiList != null) goto label_27; 
        if(this.aiList != null)
        {
            goto label_27;
        }
        // 0x00B20E20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(id:  val_3), ????);
        // 0x00B20E24: B #0xb20bc0                |  goto label_27;                         
        goto label_27;
        label_3:
        // 0x00B20E28: SUB sp, x29, #0x50         | SP = (1152921514723637456 - 80) = 1152921514723637376 (0x100000025B01F880);
        // 0x00B20E2C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B20E30: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B20E34: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B20E38: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B20E3C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B20E40: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B20E44: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B21268 (11670120), len: 708  VirtAddr: 0x00B21268 RVA: 0x00B21268 token: 100691851 methodIndex: 24712 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnObservableRequest(AIEnum.EAIEventtype eType, int tParam1, int tParam2)
    {
        //
        // Disasemble & Code
        //  | 
        CombatEntity val_22;
        // 0x00B21268: STP x26, x25, [sp, #-0x50]! | stack[1152921514723890704] = ???;  stack[1152921514723890712] = ???;  //  dest_result_addr=1152921514723890704 |  dest_result_addr=1152921514723890712
        // 0x00B2126C: STP x24, x23, [sp, #0x10]  | stack[1152921514723890720] = ???;  stack[1152921514723890728] = ???;  //  dest_result_addr=1152921514723890720 |  dest_result_addr=1152921514723890728
        // 0x00B21270: STP x22, x21, [sp, #0x20]  | stack[1152921514723890736] = ???;  stack[1152921514723890744] = ???;  //  dest_result_addr=1152921514723890736 |  dest_result_addr=1152921514723890744
        // 0x00B21274: STP x20, x19, [sp, #0x30]  | stack[1152921514723890752] = ???;  stack[1152921514723890760] = ???;  //  dest_result_addr=1152921514723890752 |  dest_result_addr=1152921514723890760
        // 0x00B21278: STP x29, x30, [sp, #0x40]  | stack[1152921514723890768] = ???;  stack[1152921514723890776] = ???;  //  dest_result_addr=1152921514723890768 |  dest_result_addr=1152921514723890776
        // 0x00B2127C: ADD x29, sp, #0x40         | X29 = (1152921514723890704 + 64) = 1152921514723890768 (0x100000025B05D650);
        // 0x00B21280: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
        // 0x00B21284: LDRB w8, [x23, #0x722]     | W8 = (bool)static_value_03733722;       
        // 0x00B21288: MOV w19, w3                | W19 = tParam2;//m1                      
        // 0x00B2128C: MOV w20, w2                | W20 = tParam1;//m1                      
        // 0x00B21290: MOV w22, w1                | W22 = eType;//m1                        
        // 0x00B21294: MOV x21, x0                | X21 = 1152921514723902784 (0x100000025B060540);//ML01
        // 0x00B21298: TBNZ w8, #0, #0xb212b4     | if (static_value_03733722 == true) goto label_0;
        // 0x00B2129C: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00B212A0: LDR x8, [x8, #0x6a0]       | X8 = 0x2B8AADC;                         
        // 0x00B212A4: LDR w0, [x8]               | W0 = 0x175;                             
        // 0x00B212A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x175, ????);      
        // 0x00B212AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B212B0: STRB w8, [x23, #0x722]     | static_value_03733722 = true;            //  dest_result_addr=57882402
        label_0:
        // 0x00B212B4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B212B8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B212BC: LDR x23, [x21, #0x10]      | X23 = this.entity; //P2                 
        val_22 = this.entity;
        // 0x00B212C0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B212C4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B212C8: TBZ w8, #0, #0xb212d8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B212CC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B212D0: CBNZ w8, #0xb212d8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B212D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B212D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B212DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B212E0: MOV x1, x23                | X1 = this.entity;//m1                   
        // 0x00B212E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B212E8: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_22);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  val_22);
        // 0x00B212EC: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B212F0: TBNZ w8, #0, #0xb21514     | if ((val_1 & 1) == true) goto label_11; 
        if(val_2 == true)
        {
            goto label_11;
        }
        // 0x00B212F4: LDR x23, [x21, #0x10]      | X23 = this.entity; //P2                 
        val_22 = this.entity;
        // 0x00B212F8: CBNZ x23, #0xb21300        | if (this.entity != null) goto label_4;  
        if(val_22 != null)
        {
            goto label_4;
        }
        // 0x00B212FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B21300: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21304: MOV x0, x23                | X0 = this.entity;//m1                   
        // 0x00B21308: BL #0xd89cfc               | X0 = this.entity.get_isDeath();         
        bool val_3 = val_22.isDeath;
        // 0x00B2130C: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00B21310: TBNZ w8, #0, #0xb21514     | if ((val_3 & 1) == true) goto label_11; 
        if(val_4 == true)
        {
            goto label_11;
        }
        // 0x00B21314: LDR x23, [x21, #0x20]      | X23 = this.aiObjDic; //P2               
        val_22 = this.aiObjDic;
        // 0x00B21318: CBNZ x23, #0xb21320        | if (this.aiObjDic != null) goto label_6;
        if(val_22 != null)
        {
            goto label_6;
        }
        // 0x00B2131C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B21320: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
        // 0x00B21324: LDR x8, [x8, #0x828]       | X8 = 1152921514723590656;               
        // 0x00B21328: MOV x0, x23                | X0 = this.aiObjDic;//m1                 
        // 0x00B2132C: MOV w1, w22                | W1 = eType;//m1                         
        // 0x00B21330: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<AIEnum.EAIEventtype, System.Collections.Generic.List<AIEventInfo>>::ContainsKey(AIEnum.EAIEventtype key);
        // 0x00B21334: BL #0x21a10e8              | X0 = this.aiObjDic.ContainsKey(key:  eType);
        bool val_5 = val_22.ContainsKey(key:  eType);
        // 0x00B21338: TBZ w0, #0, #0xb21514      | if (val_5 == false) goto label_11;      
        if(val_5 == false)
        {
            goto label_11;
        }
        // 0x00B2133C: LDR x23, [x21, #0x20]      | X23 = this.aiObjDic; //P2               
        // 0x00B21340: CBNZ x23, #0xb21348        | if (this.aiObjDic != null) goto label_8;
        if(this.aiObjDic != null)
        {
            goto label_8;
        }
        // 0x00B21344: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B21348: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x00B2134C: LDR x8, [x8, #0xac8]       | X8 = 1152921514723591680;               
        // 0x00B21350: MOV x0, x23                | X0 = this.aiObjDic;//m1                 
        // 0x00B21354: MOV w1, w22                | W1 = eType;//m1                         
        // 0x00B21358: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<AIEventInfo> System.Collections.Generic.Dictionary<AIEnum.EAIEventtype, System.Collections.Generic.List<AIEventInfo>>::get_Item(AIEnum.EAIEventtype key);
        // 0x00B2135C: BL #0x219f9f8              | X0 = this.aiObjDic.get_Item(key:  eType);
        System.Collections.Generic.List<AIEventInfo> val_6 = this.aiObjDic.Item[eType];
        // 0x00B21360: ADRP x25, #0x35c2000       | X25 = 56369152 (0x35C2000);             
        // 0x00B21364: ADRP x26, #0x366e000       | X26 = 57073664 (0x366E000);             
        // 0x00B21368: LDR x25, [x25, #0x518]     | X25 = 1152921514723827584;              
        // 0x00B2136C: LDR x26, [x26, #0x2d8]     | X26 = 1152921514723828608;              
        // 0x00B21370: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00B21374: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        val_22 = 0;
        // 0x00B21378: B #0xb21380                |  goto label_9;                          
        goto label_9;
        label_31:
        // 0x00B2137C: ADD w23, w23, #1           | W23 = (val_22 + 1) = val_22 (0x00000001);
        val_22 = 1;
        label_9:
        // 0x00B21380: CBNZ x22, #0xb21388        | if (val_6 != null) goto label_10;       
        if(val_6 != null)
        {
            goto label_10;
        }
        // 0x00B21384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_10:
        // 0x00B21388: LDR x1, [x25]              | X1 = public System.Int32 System.Collections.Generic.List<AIEventInfo>::get_Count();
        // 0x00B2138C: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B21390: BL #0x25ed72c              | X0 = val_6.get_Count();                 
        int val_7 = val_6.Count;
        // 0x00B21394: CMP w23, w0                | STATE = COMPARE(0x1, val_7)             
        // 0x00B21398: B.GE #0xb21514             | if (val_22 >= val_7) goto label_11;     
        if(val_22 >= val_7)
        {
            goto label_11;
        }
        // 0x00B2139C: CBNZ x22, #0xb213a4        | if (val_6 != null) goto label_12;       
        if(val_6 != null)
        {
            goto label_12;
        }
        // 0x00B213A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_12:
        // 0x00B213A4: LDR x2, [x26]              | X2 = public AIEventInfo System.Collections.Generic.List<AIEventInfo>::get_Item(int index);
        // 0x00B213A8: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B213AC: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
        // 0x00B213B0: BL #0x25ed734              | X0 = val_6.get_Item(index:  1);         
        AIEventInfo val_8 = val_6.Item[1];
        // 0x00B213B4: MOV x24, x0                | X24 = val_8;//m1                        
        // 0x00B213B8: CBNZ x24, #0xb213c0        | if (val_8 != null) goto label_13;       
        if(val_8 != null)
        {
            goto label_13;
        }
        // 0x00B213BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_13:
        // 0x00B213C0: LDR x24, [x24, #0x10]      | X24 = val_8.aiObj; //P2                 
        // 0x00B213C4: CBNZ x24, #0xb213cc        | if (val_8.aiObj != null) goto label_14; 
        if(val_8.aiObj != null)
        {
            goto label_14;
        }
        // 0x00B213C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_14:
        // 0x00B213CC: MOV x0, x24                | X0 = val_8.aiObj;//m1                   
        // 0x00B213D0: BL #0xb2152c               | X0 = val_8.aiObj.get_isInCD();          
        bool val_9 = val_8.aiObj.isInCD;
        // 0x00B213D4: AND w8, w0, #1             | W8 = (val_9 & 1);                       
        bool val_10 = val_9;
        // 0x00B213D8: TBNZ w8, #0, #0xb2137c     | if ((val_9 & 1) == true) goto label_31; 
        if(val_10 == true)
        {
            goto label_31;
        }
        // 0x00B213DC: CBNZ x22, #0xb213e4        | if (val_6 != null) goto label_16;       
        if(val_6 != null)
        {
            goto label_16;
        }
        // 0x00B213E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_16:
        // 0x00B213E4: LDR x2, [x26]              | X2 = public AIEventInfo System.Collections.Generic.List<AIEventInfo>::get_Item(int index);
        // 0x00B213E8: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B213EC: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
        // 0x00B213F0: BL #0x25ed734              | X0 = val_6.get_Item(index:  1);         
        AIEventInfo val_11 = val_6.Item[1];
        // 0x00B213F4: MOV x24, x0                | X24 = val_11;//m1                       
        // 0x00B213F8: CBNZ x24, #0xb21400        | if (val_11 != null) goto label_17;      
        if(val_11 != null)
        {
            goto label_17;
        }
        // 0x00B213FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_17:
        // 0x00B21400: LDR x24, [x24, #0x10]      | X24 = val_11.aiObj; //P2                
        // 0x00B21404: CBNZ x24, #0xb2140c        | if (val_11.aiObj != null) goto label_18;
        if(val_11.aiObj != null)
        {
            goto label_18;
        }
        // 0x00B21408: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_18:
        // 0x00B2140C: MOV x0, x24                | X0 = val_11.aiObj;//m1                  
        // 0x00B21410: BL #0xb21580               | X0 = val_11.aiObj.get_isComplete();     
        bool val_12 = val_11.aiObj.isComplete;
        // 0x00B21414: AND w8, w0, #1             | W8 = (val_12 & 1);                      
        bool val_13 = val_12;
        // 0x00B21418: TBNZ w8, #0, #0xb2137c     | if ((val_12 & 1) == true) goto label_31;
        if(val_13 == true)
        {
            goto label_31;
        }
        // 0x00B2141C: CBNZ x22, #0xb21424        | if (val_6 != null) goto label_20;       
        if(val_6 != null)
        {
            goto label_20;
        }
        // 0x00B21420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_20:
        // 0x00B21424: LDR x2, [x26]              | X2 = public AIEventInfo System.Collections.Generic.List<AIEventInfo>::get_Item(int index);
        // 0x00B21428: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B2142C: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
        // 0x00B21430: BL #0x25ed734              | X0 = val_6.get_Item(index:  1);         
        AIEventInfo val_14 = val_6.Item[1];
        // 0x00B21434: MOV x24, x0                | X24 = val_14;//m1                       
        // 0x00B21438: CBNZ x24, #0xb21440        | if (val_14 != null) goto label_21;      
        if(val_14 != null)
        {
            goto label_21;
        }
        // 0x00B2143C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_21:
        // 0x00B21440: LDR x1, [x24, #0x18]       | X1 = val_14.condition; //P2             
        // 0x00B21444: MOV x0, x21                | X0 = 1152921514723902784 (0x100000025B060540);//ML01
        // 0x00B21448: MOV w2, w20                | W2 = tParam1;//m1                       
        // 0x00B2144C: MOV w3, w19                | W3 = tParam2;//m1                       
        // 0x00B21450: BL #0xb215d8               | X0 = this.CheckCondition(condition:  val_14.condition, tParam1:  tParam1, tParam2:  tParam2);
        bool val_15 = this.CheckCondition(condition:  val_14.condition, tParam1:  tParam1, tParam2:  tParam2);
        // 0x00B21454: TBZ w0, #0, #0xb2137c      | if (val_15 == false) goto label_31;     
        if(val_15 == false)
        {
            goto label_31;
        }
        // 0x00B21458: CBNZ x22, #0xb21460        | if (val_6 != null) goto label_23;       
        if(val_6 != null)
        {
            goto label_23;
        }
        // 0x00B2145C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_23:
        // 0x00B21460: LDR x2, [x26]              | X2 = public AIEventInfo System.Collections.Generic.List<AIEventInfo>::get_Item(int index);
        // 0x00B21464: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B21468: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
        // 0x00B2146C: BL #0x25ed734              | X0 = val_6.get_Item(index:  1);         
        AIEventInfo val_16 = val_6.Item[1];
        // 0x00B21470: MOV x24, x0                | X24 = val_16;//m1                       
        // 0x00B21474: CBNZ x24, #0xb2147c        | if (val_16 != null) goto label_24;      
        if(val_16 != null)
        {
            goto label_24;
        }
        // 0x00B21478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_24:
        // 0x00B2147C: LDR x1, [x24, #0x10]       | X1 = val_16.aiObj; //P2                 
        // 0x00B21480: MOV x0, x21                | X0 = 1152921514723902784 (0x100000025B060540);//ML01
        // 0x00B21484: MOV w3, w20                | W3 = tParam1;//m1                       
        // 0x00B21488: MOV w4, w19                | W4 = tParam2;//m1                       
        // 0x00B2148C: BL #0xb21a68               | X0 = this.OnObserverHandle(aiObj:  val_16.aiObj, eType:  public AIEventInfo System.Collections.Generic.List<AIEventInfo>::get_Item(int index), tParam1:  tParam1, tParam2:  tParam2);
        bool val_17 = this.OnObserverHandle(aiObj:  val_16.aiObj, eType:  public AIEventInfo System.Collections.Generic.List<AIEventInfo>::get_Item(int index), tParam1:  tParam1, tParam2:  tParam2);
        // 0x00B21490: TBZ w0, #0, #0xb2137c      | if (val_17 == false) goto label_31;     
        if(val_17 == false)
        {
            goto label_31;
        }
        // 0x00B21494: CBNZ x22, #0xb2149c        | if (val_6 != null) goto label_26;       
        if(val_6 != null)
        {
            goto label_26;
        }
        // 0x00B21498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_26:
        // 0x00B2149C: LDR x2, [x26]              | X2 = public AIEventInfo System.Collections.Generic.List<AIEventInfo>::get_Item(int index);
        // 0x00B214A0: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B214A4: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
        // 0x00B214A8: BL #0x25ed734              | X0 = val_6.get_Item(index:  1);         
        AIEventInfo val_18 = val_6.Item[1];
        // 0x00B214AC: MOV x24, x0                | X24 = val_18;//m1                       
        // 0x00B214B0: CBNZ x24, #0xb214b8        | if (val_18 != null) goto label_27;      
        if(val_18 != null)
        {
            goto label_27;
        }
        // 0x00B214B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_27:
        // 0x00B214B8: LDR x24, [x24, #0x10]      | X24 = val_18.aiObj; //P2                
        // 0x00B214BC: CBNZ x24, #0xb214c4        | if (val_18.aiObj != null) goto label_28;
        if(val_18.aiObj != null)
        {
            goto label_28;
        }
        // 0x00B214C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_28:
        // 0x00B214C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B214C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B214CC: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_19 = UnityEngine.Time.time;
        // 0x00B214D0: LDR w8, [x24, #0x40]       | W8 = val_18.aiObj.curCount; //P2        
        int val_22 = val_18.aiObj.curCount;
        // 0x00B214D4: STR s0, [x24, #0x3c]       | val_18.aiObj.mLastUseTime = val_19;      //  dest_result_addr=0
        val_18.aiObj.mLastUseTime = val_19;
        // 0x00B214D8: ADD w8, w8, #1             | W8 = (val_18.aiObj.curCount + 1);       
        val_22 = val_22 + 1;
        // 0x00B214DC: STR w8, [x24, #0x40]       | val_18.aiObj.curCount = (val_18.aiObj.curCount + 1);  //  dest_result_addr=0
        val_18.aiObj.curCount = val_22;
        // 0x00B214E0: CBNZ x22, #0xb214e8        | if (val_6 != null) goto label_29;       
        if(val_6 != null)
        {
            goto label_29;
        }
        // 0x00B214E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_29:
        // 0x00B214E8: LDR x2, [x26]              | X2 = public AIEventInfo System.Collections.Generic.List<AIEventInfo>::get_Item(int index);
        // 0x00B214EC: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B214F0: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
        // 0x00B214F4: BL #0x25ed734              | X0 = val_6.get_Item(index:  1);         
        AIEventInfo val_20 = val_6.Item[1];
        // 0x00B214F8: MOV x24, x0                | X24 = val_20;//m1                       
        // 0x00B214FC: CBNZ x24, #0xb21504        | if (val_20 != null) goto label_30;      
        if(val_20 != null)
        {
            goto label_30;
        }
        // 0x00B21500: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_30:
        // 0x00B21504: LDR x1, [x24, #0x10]       | X1 = val_20.aiObj; //P2                 
        // 0x00B21508: MOV x0, x21                | X0 = 1152921514723902784 (0x100000025B060540);//ML01
        // 0x00B2150C: BL #0xb21bf8               | X0 = this.ProcessAIAction(aiObj:  val_20.aiObj, tParam1:  1527047040, tParam2:  tParam1);
        bool val_21 = this.ProcessAIAction(aiObj:  val_20.aiObj, tParam1:  1527047040, tParam2:  tParam1);
        // 0x00B21510: B #0xb2137c                |  goto label_31;                         
        goto label_31;
        label_11:
        // 0x00B21514: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B21518: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2151C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B21520: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B21524: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B21528: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B21A68 (11672168), len: 344  VirtAddr: 0x00B21A68 RVA: 0x00B21A68 token: 100691852 methodIndex: 24713 delegateWrapperIndex: 0 methodInvoker: 0
    private bool OnObserverHandle(AIObject aiObj, AIEnum.EAIEventtype eType, int tParam1, int tParam2)
    {
        //
        // Disasemble & Code
        //  | 
        System.Int32[] val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        // 0x00B21A68: STP x28, x27, [sp, #-0x60]! | stack[1152921514724203392] = ???;  stack[1152921514724203400] = ???;  //  dest_result_addr=1152921514724203392 |  dest_result_addr=1152921514724203400
        // 0x00B21A6C: STP x26, x25, [sp, #0x10]  | stack[1152921514724203408] = ???;  stack[1152921514724203416] = ???;  //  dest_result_addr=1152921514724203408 |  dest_result_addr=1152921514724203416
        // 0x00B21A70: STP x24, x23, [sp, #0x20]  | stack[1152921514724203424] = ???;  stack[1152921514724203432] = ???;  //  dest_result_addr=1152921514724203424 |  dest_result_addr=1152921514724203432
        // 0x00B21A74: STP x22, x21, [sp, #0x30]  | stack[1152921514724203440] = ???;  stack[1152921514724203448] = ???;  //  dest_result_addr=1152921514724203440 |  dest_result_addr=1152921514724203448
        // 0x00B21A78: STP x20, x19, [sp, #0x40]  | stack[1152921514724203456] = ???;  stack[1152921514724203464] = ???;  //  dest_result_addr=1152921514724203456 |  dest_result_addr=1152921514724203464
        // 0x00B21A7C: STP x29, x30, [sp, #0x50]  | stack[1152921514724203472] = ???;  stack[1152921514724203480] = ???;  //  dest_result_addr=1152921514724203472 |  dest_result_addr=1152921514724203480
        // 0x00B21A80: ADD x29, sp, #0x50         | X29 = (1152921514724203392 + 80) = 1152921514724203472 (0x100000025B0A9BD0);
        // 0x00B21A84: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
        // 0x00B21A88: LDRB w8, [x23, #0x723]     | W8 = (bool)static_value_03733723;       
        // 0x00B21A8C: MOV w19, w4                | W19 = tParam2;//m1                      
        // 0x00B21A90: MOV w20, w3                | W20 = tParam1;//m1                      
        // 0x00B21A94: MOV x21, x1                | X21 = aiObj;//m1                        
        // 0x00B21A98: MOV x22, x0                | X22 = 1152921514724215488 (0x100000025B0ACAC0);//ML01
        // 0x00B21A9C: TBNZ w8, #0, #0xb21ab8     | if (static_value_03733723 == true) goto label_0;
        // 0x00B21AA0: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
        // 0x00B21AA4: LDR x8, [x8, #0x790]       | X8 = 0x2B8AAE0;                         
        // 0x00B21AA8: LDR w0, [x8]               | W0 = 0x176;                             
        // 0x00B21AAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x176, ????);      
        // 0x00B21AB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B21AB4: STRB w8, [x23, #0x723]     | static_value_03733723 = true;            //  dest_result_addr=57882403
        label_0:
        // 0x00B21AB8: CBNZ x21, #0xb21ac0        | if (aiObj != null) goto label_1;        
        if(aiObj != null)
        {
            goto label_1;
        }
        // 0x00B21ABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x176, ????);      
        label_1:
        // 0x00B21AC0: LDR x23, [x21, #0x28]      | X23 = aiObj.conditionID; //P2           
        val_4 = aiObj.conditionID;
        // 0x00B21AC4: CBNZ x23, #0xb21acc        | if (aiObj.conditionID != null) goto label_2;
        if(val_4 != null)
        {
            goto label_2;
        }
        // 0x00B21AC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x176, ????);      
        label_2:
        // 0x00B21ACC: LDR w8, [x23, #0x18]       | W8 = aiObj.conditionID.Length; //P2     
        // 0x00B21AD0: CMP w8, #1                 | STATE = COMPARE(aiObj.conditionID.Length, 0x1)
        // 0x00B21AD4: B.LE #0xb21ba0             | if (aiObj.conditionID.Length <= 1) goto label_6;
        if(aiObj.conditionID.Length <= 1)
        {
            goto label_6;
        }
        // 0x00B21AD8: ADRP x26, #0x3668000       | X26 = 57049088 (0x3668000);             
        // 0x00B21ADC: LDR x26, [x26, #0x960]     | X26 = 1152921504911851520;              
        // 0x00B21AE0: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        val_5 = 0;
        label_13:
        // 0x00B21AE4: CBNZ x21, #0xb21aec        | if (aiObj != null) goto label_4;        
        if(aiObj != null)
        {
            goto label_4;
        }
        // 0x00B21AE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x176, ????);      
        label_4:
        // 0x00B21AEC: LDR x23, [x21, #0x28]      | X23 = aiObj.conditionID; //P2           
        val_4 = aiObj.conditionID;
        // 0x00B21AF0: CBNZ x23, #0xb21af8        | if (aiObj.conditionID != null) goto label_5;
        if(val_4 != null)
        {
            goto label_5;
        }
        // 0x00B21AF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x176, ????);      
        label_5:
        // 0x00B21AF8: LDR w8, [x23, #0x18]       | W8 = aiObj.conditionID.Length; //P2     
        // 0x00B21AFC: CMP w25, w8                | STATE = COMPARE(0x0, aiObj.conditionID.Length)
        // 0x00B21B00: B.GE #0xb21ba0             | if (val_5 >= aiObj.conditionID.Length) goto label_6;
        if(val_5 >= aiObj.conditionID.Length)
        {
            goto label_6;
        }
        // 0x00B21B04: LDR x0, [x26]              | X0 = typeof(ZMG);                       
        // 0x00B21B08: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B21B0C: TBZ w8, #0, #0xb21b1c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B21B10: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B21B14: CBNZ w8, #0xb21b1c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B21B18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_8:
        // 0x00B21B1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B21B20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21B24: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
        CSDatacfgManager val_1 = ZMG.CfgDataMgr;
        // 0x00B21B28: MOV x23, x0                | X23 = val_1;//m1                        
        val_4 = val_1;
        // 0x00B21B2C: CBNZ x21, #0xb21b34        | if (aiObj != null) goto label_9;        
        if(aiObj != null)
        {
            goto label_9;
        }
        // 0x00B21B30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00B21B34: LDR x24, [x21, #0x28]      | X24 = aiObj.conditionID; //P2           
        // 0x00B21B38: CBNZ x24, #0xb21b40        | if (aiObj.conditionID != null) goto label_10;
        if(aiObj.conditionID != null)
        {
            goto label_10;
        }
        // 0x00B21B3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_10:
        // 0x00B21B40: LDR w8, [x24, #0x18]       | W8 = aiObj.conditionID.Length; //P2     
        // 0x00B21B44: SXTW x27, w25              | X27 = 0 (0x00000000);                   
        // 0x00B21B48: CMP w25, w8                | STATE = COMPARE(0x0, aiObj.conditionID.Length)
        // 0x00B21B4C: B.LO #0xb21b5c             | if (val_5 < aiObj.conditionID.Length) goto label_11;
        if(val_5 < aiObj.conditionID.Length)
        {
            goto label_11;
        }
        // 0x00B21B50: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B21B54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21B58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_11:
        // 0x00B21B5C: ADD x8, x24, x27, lsl #2   | X8 = aiObj.conditionID[0x0]; //PARR1    
        // 0x00B21B60: LDR w24, [x8, #0x20]       | W24 = aiObj.conditionID[0x0][0]         
        int val_4 = aiObj.conditionID[0];
        // 0x00B21B64: CBNZ x23, #0xb21b6c        | if (val_1 != null) goto label_12;       
        if(val_4 != null)
        {
            goto label_12;
        }
        // 0x00B21B68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_12:
        // 0x00B21B6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B21B70: MOV x0, x23                | X0 = val_1;//m1                         
        // 0x00B21B74: MOV w1, w24                | W1 = aiObj.conditionID[0x0][0];//m1     
        // 0x00B21B78: BL #0xb48e58               | X0 = val_1.GetnpcAIConditionCfg(id:  aiObj.conditionID[0]);
        npcAIConditionCfg val_2 = val_4.GetnpcAIConditionCfg(id:  val_4);
        // 0x00B21B7C: MOV x1, x0                 | X1 = val_2;//m1                         
        // 0x00B21B80: MOV x0, x22                | X0 = 1152921514724215488 (0x100000025B0ACAC0);//ML01
        // 0x00B21B84: MOV w2, w20                | W2 = tParam1;//m1                       
        // 0x00B21B88: MOV w3, w19                | W3 = tParam2;//m1                       
        // 0x00B21B8C: BL #0xb215d8               | X0 = this.CheckCondition(condition:  val_2, tParam1:  tParam1, tParam2:  tParam2);
        bool val_3 = this.CheckCondition(condition:  val_2, tParam1:  tParam1, tParam2:  tParam2);
        // 0x00B21B90: ADD w25, w25, #1           | W25 = (val_5 + 1);                      
        val_5 = val_5 + 1;
        // 0x00B21B94: TBNZ w0, #0, #0xb21ae4     | if (val_3 == true) goto label_13;       
        if(val_3 == true)
        {
            goto label_13;
        }
        // 0x00B21B98: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_6 = 0;
        // 0x00B21B9C: B #0xb21ba4                |  goto label_14;                         
        goto label_14;
        label_6:
        // 0x00B21BA0: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        val_6 = 1;
        label_14:
        // 0x00B21BA4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B21BA8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B21BAC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B21BB0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B21BB4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B21BB8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B21BBC: RET                        |  return (System.Boolean)true;           
        return (bool)val_6;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B21BF8 (11672568), len: 2832  VirtAddr: 0x00B21BF8 RVA: 0x00B21BF8 token: 100691853 methodIndex: 24714 delegateWrapperIndex: 0 methodInvoker: 0
    private bool ProcessAIAction(AIObject aiObj, int tParam1, int tParam2)
    {
        //
        // Disasemble & Code
        //  | 
        var val_41;
        //  | 
        System.Int32[] val_42;
        //  | 
        var val_43;
        //  | 
        var val_44;
        //  | 
        var val_45;
        //  | 
        System.Object[] val_46;
        //  | 
        var val_47;
        //  | 
        var val_48;
        //  | 
        var val_49;
        //  | 
        var val_50;
        //  | 
        var val_51;
        //  | 
        var val_52;
        // 0x00B21BF8: STP d9, d8, [sp, #-0x70]!  | stack[1152921514724716784] = ???;  stack[1152921514724716792] = ???;  //  dest_result_addr=1152921514724716784 |  dest_result_addr=1152921514724716792
        // 0x00B21BFC: STP x28, x27, [sp, #0x10]  | stack[1152921514724716800] = ???;  stack[1152921514724716808] = ???;  //  dest_result_addr=1152921514724716800 |  dest_result_addr=1152921514724716808
        // 0x00B21C00: STP x26, x25, [sp, #0x20]  | stack[1152921514724716816] = ???;  stack[1152921514724716824] = ???;  //  dest_result_addr=1152921514724716816 |  dest_result_addr=1152921514724716824
        // 0x00B21C04: STP x24, x23, [sp, #0x30]  | stack[1152921514724716832] = ???;  stack[1152921514724716840] = ???;  //  dest_result_addr=1152921514724716832 |  dest_result_addr=1152921514724716840
        // 0x00B21C08: STP x22, x21, [sp, #0x40]  | stack[1152921514724716848] = ???;  stack[1152921514724716856] = ???;  //  dest_result_addr=1152921514724716848 |  dest_result_addr=1152921514724716856
        // 0x00B21C0C: STP x20, x19, [sp, #0x50]  | stack[1152921514724716864] = ???;  stack[1152921514724716872] = ???;  //  dest_result_addr=1152921514724716864 |  dest_result_addr=1152921514724716872
        // 0x00B21C10: STP x29, x30, [sp, #0x60]  | stack[1152921514724716880] = ???;  stack[1152921514724716888] = ???;  //  dest_result_addr=1152921514724716880 |  dest_result_addr=1152921514724716888
        // 0x00B21C14: ADD x29, sp, #0x60         | X29 = (1152921514724716784 + 96) = 1152921514724716880 (0x100000025B127150);
        // 0x00B21C18: SUB sp, sp, #0x10          | SP = (1152921514724716784 - 16) = 1152921514724716768 (0x100000025B1270E0);
        // 0x00B21C1C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B21C20: LDRB w8, [x21, #0x724]     | W8 = (bool)static_value_03733724;       
        // 0x00B21C24: MOV x19, x1                | X19 = aiObj;//m1                        
        // 0x00B21C28: MOV x20, x0                | X20 = 1152921514724728896 (0x100000025B12A040);//ML01
        // 0x00B21C2C: TBNZ w8, #0, #0xb21c48     | if (static_value_03733724 == true) goto label_0;
        // 0x00B21C30: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00B21C34: LDR x8, [x8, #0xb48]       | X8 = 0x2B8AAE4;                         
        // 0x00B21C38: LDR w0, [x8]               | W0 = 0x177;                             
        // 0x00B21C3C: BL #0x2782188              | X0 = sub_2782188( ?? 0x177, ????);      
        // 0x00B21C40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B21C44: STRB w8, [x21, #0x724]     | static_value_03733724 = true;            //  dest_result_addr=57882404
        label_0:
        // 0x00B21C48: ADRP x27, #0x3668000       | X27 = 57049088 (0x3668000);             
        // 0x00B21C4C: ADRP x25, #0x3630000       | X25 = 56819712 (0x3630000);             
        // 0x00B21C50: LDR x27, [x27, #0x960]     | X27 = 1152921504911851520;              
        // 0x00B21C54: LDR x25, [x25, #0x3d0]     | X25 = 1152921504954501264;              
        // 0x00B21C58: ADRP x28, #0x2a92000       | X28 = 44638208 (0x2A92000);             
        // 0x00B21C5C: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
        val_41 = 0;
        // 0x00B21C60: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
        var val_45 = 0;
        // 0x00B21C64: ADD x28, x28, #0x9f8       | X28 = (44638208 + 2552) = 44640760 (0x02A929F8);
        // 0x00B21C68: FMOV s8, wzr               | S8 = 0f;                                
        // 0x00B21C6C: B #0xb21c74                |  goto label_1;                          
        goto label_1;
        label_105:
        // 0x00B21C70: ADD w26, w26, #1           | W26 = (val_41 + 1) = val_41 (0x00000001);
        val_41 = 1;
        label_1:
        // 0x00B21C74: CBNZ x19, #0xb21c7c        | if (aiObj != null) goto label_2;        
        if(aiObj != null)
        {
            goto label_2;
        }
        // 0x00B21C78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x177, ????);      
        label_2:
        // 0x00B21C7C: LDR x21, [x19, #0x20]      | X21 = aiObj.behaviorID; //P2            
        val_42 = aiObj.behaviorID;
        // 0x00B21C80: CBNZ x21, #0xb21c88        | if (aiObj.behaviorID != null) goto label_3;
        if(val_42 != null)
        {
            goto label_3;
        }
        // 0x00B21C84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x177, ????);      
        label_3:
        // 0x00B21C88: LDR w8, [x21, #0x18]       | W8 = aiObj.behaviorID.Length; //P2      
        // 0x00B21C8C: CMP w26, w8                | STATE = COMPARE(0x1, aiObj.behaviorID.Length)
        // 0x00B21C90: B.GE #0xb226e0             | if (val_41 >= aiObj.behaviorID.Length) goto label_12;
        if(val_41 >= aiObj.behaviorID.Length)
        {
            goto label_12;
        }
        // 0x00B21C94: LDR x0, [x27]              | X0 = typeof(ZMG);                       
        // 0x00B21C98: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B21C9C: TBZ w8, #0, #0xb21cac      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B21CA0: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B21CA4: CBNZ w8, #0xb21cac         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B21CA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_6:
        // 0x00B21CAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B21CB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21CB4: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
        CSDatacfgManager val_1 = ZMG.CfgDataMgr;
        // 0x00B21CB8: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B21CBC: CBNZ x19, #0xb21cc4        | if (aiObj != null) goto label_7;        
        if(aiObj != null)
        {
            goto label_7;
        }
        // 0x00B21CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_7:
        // 0x00B21CC4: LDR x22, [x19, #0x20]      | X22 = aiObj.behaviorID; //P2            
        // 0x00B21CC8: CBNZ x22, #0xb21cd0        | if (aiObj.behaviorID != null) goto label_8;
        if(aiObj.behaviorID != null)
        {
            goto label_8;
        }
        // 0x00B21CCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_8:
        // 0x00B21CD0: LDR w8, [x22, #0x18]       | W8 = aiObj.behaviorID.Length; //P2      
        // 0x00B21CD4: SXTW x23, w26              | X23 = 1 (0x00000001);                   
        // 0x00B21CD8: CMP w26, w8                | STATE = COMPARE(0x1, aiObj.behaviorID.Length)
        // 0x00B21CDC: B.LO #0xb21cec             | if (val_41 < aiObj.behaviorID.Length) goto label_9;
        if(val_41 < aiObj.behaviorID.Length)
        {
            goto label_9;
        }
        // 0x00B21CE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B21CE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21CE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_9:
        // 0x00B21CEC: ADD x8, x22, x23, lsl #2   | X8 = aiObj.behaviorID[0x1]; //PARR1     
        // 0x00B21CF0: LDR w22, [x8, #0x20]       | W22 = aiObj.behaviorID[0x1][0]          
        int val_42 = aiObj.behaviorID[1];
        // 0x00B21CF4: CBNZ x21, #0xb21cfc        | if (val_1 != null) goto label_10;       
        if(val_1 != null)
        {
            goto label_10;
        }
        // 0x00B21CF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_10:
        // 0x00B21CFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B21D00: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B21D04: MOV w1, w22                | W1 = aiObj.behaviorID[0x1][0];//m1      
        // 0x00B21D08: BL #0xb48c78               | X0 = val_1.GetnpcAIBehaviorCfg(id:  aiObj.behaviorID[1]);
        npcAIBehaviorCfg val_2 = val_1.GetnpcAIBehaviorCfg(id:  val_42);
        // 0x00B21D0C: MOV x21, x0                | X21 = val_2;//m1                        
        val_42 = val_2;
        // 0x00B21D10: CBZ x21, #0xb21c70         | if (val_2 == null) goto label_105;      
        if(val_42 == null)
        {
            goto label_105;
        }
        // 0x00B21D14: LDRB w8, [x21, #0x14]      | W8 = val_2.type; //P2                   
        int val_43 = val_2.type;
        // 0x00B21D18: SUB w9, w8, #1             | W9 = (val_2.type - 1);                  
        int val_3 = val_43 - 1;
        // 0x00B21D1C: ADD w8, w8, #8             | W8 = (val_2.type + 8);                  
        val_43 = val_43 + 8;
        // 0x00B21D20: CMP w9, #0xc               | STATE = COMPARE((val_2.type - 1), 0xC)  
        // 0x00B21D24: CSEL w8, w8, wzr, lo       | W8 = val_3 < 12 ? (val_2.type + 8) : 0; 
        var val_4 = (val_3 < 12) ? (val_43) : 0;
        // 0x00B21D28: CMP w8, #0x14              | STATE = COMPARE(val_3 < 12 ? (val_2.type + 8) : 0, 0x14)
        // 0x00B21D2C: B.HI #0xb226e0             | if (val_4 > 0x14) goto label_12;        
        if(val_4 > 20)
        {
            goto label_12;
        }
        // 0x00B21D30: LDRSW x8, [x28, x8, lsl #2] | X8 = 44640760 + (val_3 < 12 ? (val_2.type + 8) : 0) << 2;
        var val_44 = 44640760 + (val_3 < 12 ? (val_2.type + 8) : 0) << 2;
        // 0x00B21D34: ADD x8, x8, x28            | X8 = (44640760 + (val_3 < 12 ? (val_2.type + 8) : 0) << 2 + 44640760);
        val_44 = val_44 + 44640760;
        // 0x00B21D38: BR x8                      | goto (44640760 + (val_3 < 12 ? (val_2.type + 8) : 0) << 2 + 44640760);
        goto (44640760 + (val_3 < 12 ? (val_2.type + 8) : 0) << 2 + 44640760);
        // 0x00B21D3C: LDR x22, [x20, #0x10]      | X22 = this.entity; //P2                 
        // 0x00B21D40: CBNZ x22, #0xb21d48        | if (this.entity != null) goto label_13; 
        if(this.entity != null)
        {
            goto label_13;
        }
        // 0x00B21D44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_13:
        // 0x00B21D48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21D4C: MOV x0, x22                | X0 = this.entity;//m1                   
        // 0x00B21D50: BL #0xd7dd78               | X0 = this.entity.get_fightCtrl();       
        FightCtrl val_5 = this.entity.fightCtrl;
        // 0x00B21D54: LDR w21, [x21, #0x18]      | W21 = val_2.param1; //P2                
        // 0x00B21D58: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00B21D5C: CBNZ x22, #0xb21d64        | if (val_5 != null) goto label_14;       
        if(val_5 != null)
        {
            goto label_14;
        }
        // 0x00B21D60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_14:
        // 0x00B21D64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B21D68: MOV x0, x22                | X0 = val_5;//m1                         
        // 0x00B21D6C: MOV w1, w21                | W1 = val_2.param1;//m1                  
        // 0x00B21D70: BL #0xeced9c               | X0 = val_5.SetNextSkillIDByAI(skillid:  val_2.param1);
        FightEnum.EFightRst val_6 = val_5.SetNextSkillIDByAI(skillid:  val_2.param1);
        // 0x00B21D74: CMP w0, #1                 | STATE = COMPARE(val_6, 0x1)             
        // 0x00B21D78: CSET w8, eq                | W8 = val_6 == 0x1 ? 1 : 0;              
        var val_7 = (val_6 == 1) ? 1 : 0;
        // 0x00B21D7C: ORR w24, w24, w8           | W24 = (0 | val_6 == 0x1 ? 1 : 0);       
        val_45 = val_45 | val_7;
        // 0x00B21D80: B #0xb21c70                |  goto label_105;                        
        goto label_105;
        // 0x00B21D84: LDP w1, w2, [x21, #0x18]   | W1 = val_2.param1 + 24; W2 = val_2.param1 + 24 + 4; //  | 
        // 0x00B21D88: LDR w3, [x21, #0x20]       | W3 = val_2.param1 + 32;                 
        // 0x00B21D8C: MOV x0, x20                | X0 = 1152921514724728896 (0x100000025B12A040);//ML01
        // 0x00B21D90: BL #0xb22708               | X0 = this.ChangeAtkTarget(tParam1:  val_2.param1 + 24, tParam2:  val_2.param1 + 24 + 4, tParam3:  val_2.param1 + 32);
        bool val_8 = this.ChangeAtkTarget(tParam1:  val_2.param1 + 24, tParam2:  val_2.param1 + 24 + 4, tParam3:  val_2.param1 + 32);
        // 0x00B21D94: ORR w24, w24, w0           | W24 = ((0 | val_6 == 0x1 ? 1 : 0) | val_8);
        val_45 = val_45 | val_8;
        // 0x00B21D98: B #0xb21c70                |  goto label_105;                        
        goto label_105;
        // 0x00B21D9C: LDR x22, [x20, #0x10]      | X22 = this.entity; //P2                 
        // 0x00B21DA0: CBNZ x22, #0xb21da8        | if (this.entity != null) goto label_17; 
        if(this.entity != null)
        {
            goto label_17;
        }
        // 0x00B21DA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_17:
        // 0x00B21DA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21DAC: MOV x0, x22                | X0 = this.entity;//m1                   
        // 0x00B21DB0: BL #0xd8a19c               | X0 = this.entity.get_buffCtrl();        
        BuffCtrl val_9 = this.entity.buffCtrl;
        // 0x00B21DB4: LDR w21, [x21, #0x18]      | W21 = val_2.param1 + 24;                
        // 0x00B21DB8: MOV x22, x0                | X22 = val_9;//m1                        
        // 0x00B21DBC: CBNZ x22, #0xb21dc4        | if (val_9 != null) goto label_18;       
        if(val_9 != null)
        {
            goto label_18;
        }
        // 0x00B21DC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_18:
        // 0x00B21DC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B21DC8: MOV x0, x22                | X0 = val_9;//m1                         
        // 0x00B21DCC: MOV w1, w21                | W1 = val_2.param1 + 24;//m1             
        // 0x00B21DD0: BL #0xb9e7e4               | val_9.AddBuff(id:  val_2.param1 + 24);  
        val_9.AddBuff(id:  val_2.param1 + 24);
        // 0x00B21DD4: B #0xb22640                |  goto label_86;                         
        goto label_86;
        // 0x00B21DD8: LDR x22, [x20, #0x10]      | X22 = this.entity; //P2                 
        // 0x00B21DDC: CBNZ x22, #0xb21de4        | if (this.entity != null) goto label_20; 
        if(this.entity != null)
        {
            goto label_20;
        }
        // 0x00B21DE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_20:
        // 0x00B21DE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21DE8: MOV x0, x22                | X0 = this.entity;//m1                   
        // 0x00B21DEC: BL #0xd7dd80               | X0 = this.entity.get_bvrCtrl();         
        Entity.Behavior.IBehaviorCtrl val_10 = this.entity.bvrCtrl;
        // 0x00B21DF0: LDR x23, [x25]             | X23 = typeof(System.Object[]);          
        // 0x00B21DF4: MOV x22, x0                | X22 = val_10;//m1                       
        // 0x00B21DF8: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B21DFC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B21E00: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B21E04: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B21E08: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B21E0C: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B21E10: LDR s0, [x21, #0x18]       | S0 = val_2.param1 + 24 + 24;            
        // 0x00B21E14: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
        // 0x00B21E18: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B21E1C: ADD x1, sp, #0xc           | X1 = (1152921514724716768 + 12) = 1152921514724716780 (0x100000025B1270EC);
        // 0x00B21E20: SCVTF s0, s0               | S0 = (float)(val_2.param1 + 24 + 24);   
        // 0x00B21E24: LDR x8, [x8]               | X8 = typeof(System.Single);             
        // 0x00B21E28: STR s0, [sp, #0xc]         | stack[1152921514724716780] = val_2.param1 + 24 + 24;  //  dest_result_addr=1152921514724716780
        // 0x00B21E2C: MOV x0, x8                 | X0 = 1152921504608444416 (0x1000000000186000);//ML01
        // 0x00B21E30: BL #0x27bc028              | X0 = 1152921514724875584 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_2.param1 + 24 + 24);
        // 0x00B21E34: MOV x24, x0                | X24 = 1152921514724875584 (0x100000025B14DD40);//ML01
        // 0x00B21E38: CBNZ x23, #0xb21e40        | if ( != null) goto label_21;            
        if(null != null)
        {
            goto label_21;
        }
        // 0x00B21E3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2.param1 + 24 + 24, ????);
        label_21:
        // 0x00B21E40: CBZ x24, #0xb21e64         | if (val_2.param1 + 24 + 24 == 0) goto label_23;
        if(((float)val_2.param1 + 24 + 24) == 0)
        {
            goto label_23;
        }
        // 0x00B21E44: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B21E48: MOV x0, x24                | X0 = 1152921514724875584 (0x100000025B14DD40);//ML01
        // 0x00B21E4C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B21E50: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2.param1 + 24 + 24, ????);
        // 0x00B21E54: CBNZ x0, #0xb21e64         | if (val_2.param1 + 24 + 24 != 0) goto label_23;
        if(((float)val_2.param1 + 24 + 24) != 0)
        {
            goto label_23;
        }
        // 0x00B21E58: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2.param1 + 24 + 24, ????);
        // 0x00B21E5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21E60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2.param1 + 24 + 24, ????);
        label_23:
        // 0x00B21E64: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B21E68: CBNZ w8, #0xb21e78         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_24;
        // 0x00B21E6C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2.param1 + 24 + 24, ????);
        // 0x00B21E70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21E74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2.param1 + 24 + 24, ????);
        label_24:
        // 0x00B21E78: STR x24, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2.param1 + 24 + 24; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = (float)val_2.param1 + 24 + 24;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00B21E7C: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00B21E80: LDR w8, [x21, #0x1c]       | W8 = val_2.param1 + 24 + 28;            
        // 0x00B21E84: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00B21E88: ADD x1, sp, #8             | X1 = (1152921514724716768 + 8) = 1152921514724716776 (0x100000025B1270E8);
        // 0x00B21E8C: STR w8, [sp, #8]           | stack[1152921514724716776] = val_2.param1 + 24 + 28;  //  dest_result_addr=1152921514724716776
        // 0x00B21E90: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00B21E94: BL #0x27bc028              | X0 = 1152921514724879680 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_2.param1 + 24 + 28);
        // 0x00B21E98: MOV x21, x0                | X21 = 1152921514724879680 (0x100000025B14ED40);//ML01
        // 0x00B21E9C: CBZ x21, #0xb21ec0         | if (val_2.param1 + 24 + 28 == 0) goto label_26;
        if((val_2.param1 + 24 + 28) == 0)
        {
            goto label_26;
        }
        // 0x00B21EA0: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B21EA4: MOV x0, x21                | X0 = 1152921514724879680 (0x100000025B14ED40);//ML01
        // 0x00B21EA8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B21EAC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2.param1 + 24 + 28, ????);
        // 0x00B21EB0: CBNZ x0, #0xb21ec0         | if (val_2.param1 + 24 + 28 != 0) goto label_26;
        if((val_2.param1 + 24 + 28) != 0)
        {
            goto label_26;
        }
        // 0x00B21EB4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2.param1 + 24 + 28, ????);
        // 0x00B21EB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21EBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2.param1 + 24 + 28, ????);
        label_26:
        // 0x00B21EC0: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B21EC4: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B21EC8: B.HI #0xb21ed8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_27;
        // 0x00B21ECC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2.param1 + 24 + 28, ????);
        // 0x00B21ED0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21ED4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2.param1 + 24 + 28, ????);
        label_27:
        // 0x00B21ED8: STR x21, [x23, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_2.param1 + 24 + 28; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_2.param1 + 24 + 28;
        typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
        // 0x00B21EDC: CBNZ x22, #0xb21ee4        | if (val_10 != null) goto label_28;      
        if(val_10 != null)
        {
            goto label_28;
        }
        // 0x00B21EE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2.param1 + 24 + 28, ????);
        label_28:
        // 0x00B21EE4: LDR x8, [x22]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
        // 0x00B21EE8: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
        // 0x00B21EEC: MOV x0, x22                | X0 = val_10;//m1                        
        // 0x00B21EF0: MOV x2, x23                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B21EF4: LDP x9, x3, [x8, #0x180]   | X9 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
        // 0x00B21EF8: BLR x9                     | X0 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180();
        // 0x00B21EFC: B #0xb22640                |  goto label_86;                         
        goto label_86;
        // 0x00B21F00: LDR x21, [x20, #0x10]      | X21 = this.entity; //P2                 
        // 0x00B21F04: CBNZ x21, #0xb21f0c        | if (this.entity != null) goto label_30; 
        if(this.entity != null)
        {
            goto label_30;
        }
        // 0x00B21F08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_30:
        // 0x00B21F0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21F10: MOV x0, x21                | X0 = this.entity;//m1                   
        // 0x00B21F14: BL #0xd95118               | this.entity.Suicide();                  
        this.entity.Suicide();
        // 0x00B21F18: B #0xb22640                |  goto label_86;                         
        goto label_86;
        // 0x00B21F1C: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00B21F20: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00B21F24: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00B21F28: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B21F2C: LDR x22, [x8]              | X22 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B21F30: CBNZ x22, #0xb21f38        | if (GameMgr.UPDATEOnOffEffect != null) goto label_32;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_32;
        }
        // 0x00B21F34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.entity, ????);
        label_32:
        // 0x00B21F38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21F3C: MOV x0, x22                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00B21F40: BL #0xc1933c               | GameMgr.UPDATEOnOffEffect.LockNpcBehaviour();
        GameMgr.UPDATEOnOffEffect.LockNpcBehaviour();
        // 0x00B21F44: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00B21F48: LDR w8, [x21, #0x18]       | 
        // 0x00B21F4C: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00B21F50: ADD x1, sp, #0xc           | X1 = (1152921514724716768 + 12) = 1152921514724716780 (0x100000025B1270EC);
        // 0x00B21F54: STR w8, [sp, #0xc]         | stack[1152921514724716780] = GameMgr.__il2cppRuntimeField_static_fields;  //  dest_result_addr=1152921514724716780
        // 0x00B21F58: MOV x22, x9                | X22 = 57977360 (0x374AA10);//ML01       
        // 0x00B21F5C: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00B21F60: BL #0x27bc028              | X0 = 1152921514724887872 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), GameMgr.__il2cppRuntimeField_static_fields);
        // 0x00B21F64: LDR x8, [x22]              | X8 = typeof(System.Int32);              
        // 0x00B21F68: LDR w9, [x21, #0x10]       | 
        // 0x00B21F6C: MOV x22, x0                | X22 = 1152921514724887872 (0x100000025B150D40);//ML01
        // 0x00B21F70: ADD x1, sp, #8             | X1 = (1152921514724716768 + 8) = 1152921514724716776 (0x100000025B1270E8);
        // 0x00B21F74: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00B21F78: STR w9, [sp, #8]           | stack[1152921514724716776] = 1152921504607113216;  //  dest_result_addr=1152921514724716776
        // 0x00B21F7C: BL #0x27bc028              | X0 = 1152921514724891968 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1152921504607113216);
        // 0x00B21F80: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B21F84: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00B21F88: MOV x23, x0                | X23 = 1152921514724891968 (0x100000025B151D40);//ML01
        // 0x00B21F8C: LDR x8, [x8]               | X8 = typeof(CEvent.ZEvent);             
        // 0x00B21F90: MOV x0, x8                 | X0 = 1152921504898326528 (0x10000000115FA000);//ML01
        CEvent.ZEvent val_11 = null;
        // 0x00B21F94: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00B21F98: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x00B21F9C: LDR x8, [x8, #0x418]       | X8 = (string**)(1152921510322329040)("EV_WILDERNESS_ADVENTURE");
        // 0x00B21FA0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B21FA4: MOV x2, x22                | X2 = 1152921514724887872 (0x100000025B150D40);//ML01
        // 0x00B21FA8: MOV x3, x23                | X3 = 1152921514724891968 (0x100000025B151D40);//ML01
        // 0x00B21FAC: LDR x1, [x8]               | X1 = "EV_WILDERNESS_ADVENTURE";         
        // 0x00B21FB0: MOV x21, x0                | X21 = 1152921504898326528 (0x10000000115FA000);//ML01
        val_43 = val_11;
        // 0x00B21FB4: BL #0xd81db8               | .ctor(name:  "EV_WILDERNESS_ADVENTURE", arg:  GameMgr.__il2cppRuntimeField_static_fields, arg1:  1152921504607113216);
        val_11 = new CEvent.ZEvent(name:  "EV_WILDERNESS_ADVENTURE", arg:  GameMgr.__il2cppRuntimeField_static_fields, arg1:  1152921504607113216);
        // 0x00B21FB8: B #0xb221a4                |  goto label_33;                         
        goto label_33;
        // 0x00B21FBC: LDR x0, [x27]              | X0 = typeof(ZMG);                       
        // 0x00B21FC0: LDR w9, [x21, #0x1c]       | W9 = typeof(CEvent.ZEvent).__il2cppRuntimeField_1C;
        // 0x00B21FC4: ADD x8, x0, #0x109         | X8 = (null + 265) = 1152921504911851785 (0x10000000122E0109);
        // 0x00B21FC8: LDRH w8, [x8]              | W8 = ZMG.__il2cppRuntimeField_109;      
        // 0x00B21FCC: AND w8, w8, #0x100         | W8 = (ZMG.__il2cppRuntimeField_109 & 256);
        // 0x00B21FD0: AND w8, w8, #0xffff        | W8 = ((ZMG.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00B21FD4: CBZ w9, #0xb22548          | if (typeof(CEvent.ZEvent).__il2cppRuntimeField_1C == 0) goto label_34;
        // 0x00B21FD8: CBZ w8, #0xb21fe8          | if (((ZMG.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_36;
        // 0x00B21FDC: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B21FE0: CBNZ w8, #0xb21fe8         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
        // 0x00B21FE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_36:
        // 0x00B21FE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B21FEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21FF0: BL #0x26a8450              | X0 = ZMG.get_FloatTextMgr();            
        FloatTextMgr val_14 = ZMG.FloatTextMgr;
        // 0x00B21FF4: LDR x23, [x25]             | X23 = typeof(System.Object[]);          
        // 0x00B21FF8: MOV x22, x0                | X22 = val_14;//m1                       
        // 0x00B21FFC: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B22000: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B22004: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B22008: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2200C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B22010: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B22014: LDR x8, [x8, #0xa90]       | X8 = 1152921504911745024;               
        // 0x00B22018: LDR w24, [x21, #0x18]      | W24 = CEvent.ZEvent.__il2cppRuntimeField_namespaze;
        // 0x00B2201C: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B22020: LDR x8, [x8]               | X8 = typeof(Util);                      
        // 0x00B22024: LDRB w9, [x8, #0x10a]      | W9 = Util.__il2cppRuntimeField_10A;     
        // 0x00B22028: TBZ w9, #0, #0xb2203c      | if (Util.__il2cppRuntimeField_has_cctor == 0) goto label_38;
        // 0x00B2202C: LDR w9, [x8, #0xbc]        | W9 = Util.__il2cppRuntimeField_cctor_finished;
        // 0x00B22030: CBNZ w9, #0xb2203c         | if (Util.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
        // 0x00B22034: MOV x0, x8                 | X0 = 1152921504911745024 (0x10000000122C6000);//ML01
        // 0x00B22038: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Util), ????);
        label_38:
        // 0x00B2203C: MOV x27, x25               | X27 = 57977496 (0x374AA98);//ML01       
        // 0x00B22040: LDR x25, [x27]             | X25 = typeof(System.Object[]);          
        // 0x00B22044: MOV x0, x25                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B22048: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B2204C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22050: MOV x0, x25                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B22054: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B22058: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2205C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22060: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B22064: MOV w1, w24                | W1 = 1152921508010578928 (0x10000000CAE0D3F0);//ML01
        // 0x00B22068: BL #0xe17610               | X0 = Util.FormatUIString(key:  0, datas:  CEvent.ZEvent.__il2cppRuntimeField_namespaze);
        string val_15 = Util.FormatUIString(key:  0, datas:  CEvent.ZEvent.__il2cppRuntimeField_namespaze);
        // 0x00B2206C: MOV x24, x0                | X24 = val_15;//m1                       
        // 0x00B22070: CBNZ x23, #0xb22078        | if ( != null) goto label_39;            
        if(null != null)
        {
            goto label_39;
        }
        // 0x00B22074: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_39:
        // 0x00B22078: CBZ x24, #0xb2209c         | if (val_15 == null) goto label_41;      
        if(val_15 == null)
        {
            goto label_41;
        }
        // 0x00B2207C: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B22080: MOV x0, x24                | X0 = val_15;//m1                        
        // 0x00B22084: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B22088: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
        // 0x00B2208C: CBNZ x0, #0xb2209c         | if (val_15 != null) goto label_41;      
        if(val_15 != null)
        {
            goto label_41;
        }
        // 0x00B22090: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
        // 0x00B22094: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22098: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
        label_41:
        // 0x00B2209C: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B220A0: MOV x25, x27               | X25 = 57977496 (0x374AA98);//ML01       
        // 0x00B220A4: CBNZ w8, #0xb220b4         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_42;
        // 0x00B220A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
        // 0x00B220AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B220B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
        label_42:
        // 0x00B220B4: STR x24, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_15;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_15;
        // 0x00B220B8: LDR x24, [x25]             | X24 = typeof(System.Object[]);          
        // 0x00B220BC: LDR w21, [x21, #0x1c]      | W21 = typeof(CEvent.ZEvent).__il2cppRuntimeField_1C;
        // 0x00B220C0: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B220C4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B220C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B220CC: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B220D0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B220D4: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B220D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B220DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B220E0: MOV w1, w21                | W1 = typeof(CEvent.ZEvent).__il2cppRuntimeField_1C;//m1
        // 0x00B220E4: BL #0xe17610               | X0 = Util.FormatUIString(key:  0, datas:  typeof(CEvent.ZEvent).__il2cppRuntimeField_1C);
        string val_16 = Util.FormatUIString(key:  0, datas:  typeof(CEvent.ZEvent).__il2cppRuntimeField_1C);
        // 0x00B220E8: ADRP x27, #0x3668000       | X27 = 57049088 (0x3668000);             
        // 0x00B220EC: LDR x27, [x27, #0x960]     | X27 = 1152921504911851520;              
        // 0x00B220F0: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x00B220F4: CBZ x21, #0xb22118         | if (val_16 == null) goto label_44;      
        if(val_16 == null)
        {
            goto label_44;
        }
        // 0x00B220F8: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B220FC: MOV x0, x21                | X0 = val_16;//m1                        
        // 0x00B22100: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B22104: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
        // 0x00B22108: CBNZ x0, #0xb22118         | if (val_16 != null) goto label_44;      
        if(val_16 != null)
        {
            goto label_44;
        }
        // 0x00B2210C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
        // 0x00B22110: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22114: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
        label_44:
        // 0x00B22118: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2211C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B22120: B.HI #0xb22130             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_45;
        // 0x00B22124: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
        // 0x00B22128: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2212C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
        label_45:
        // 0x00B22130: STR x21, [x23, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_16;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_16;
        // 0x00B22134: CBNZ x22, #0xb2213c        | if (val_14 != null) goto label_46;      
        if(val_14 != null)
        {
            goto label_46;
        }
        // 0x00B22138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_46:
        // 0x00B2213C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B22140: MOVZ w1, #0x16             | W1 = 22 (0x16);//ML01                   
        val_44 = 22;
        // 0x00B22144: ORR w2, wzr, #0xf0         | W2 = 240(0xF0);                         
        val_45 = 240;
        // 0x00B22148: MOV x0, x22                | X0 = val_14;//m1                        
        // 0x00B2214C: MOV x3, x23                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_46 = null;
        // 0x00B22150: B #0xb2263c                |  goto label_47;                         
        goto label_47;
        // 0x00B22154: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00B22158: LDR w8, [x21, #0x18]       | 
        // 0x00B2215C: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00B22160: ADD x1, sp, #0xc           | X1 = (1152921514724716768 + 12) = 1152921514724716780 (0x100000025B1270EC);
        // 0x00B22164: STR w8, [sp, #0xc]         | stack[1152921514724716780] = System.Object[].__il2cppRuntimeField_namespaze;  //  dest_result_addr=1152921514724716780
        // 0x00B22168: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00B2216C: BL #0x27bc028              | X0 = 1152921514724908352 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), System.Object[].__il2cppRuntimeField_namespaze);
        // 0x00B22170: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B22174: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00B22178: MOV x22, x0                | X22 = 1152921514724908352 (0x100000025B155D40);//ML01
        // 0x00B2217C: LDR x8, [x8]               | X8 = typeof(CEvent.ZEvent);             
        // 0x00B22180: MOV x0, x8                 | X0 = 1152921504898326528 (0x10000000115FA000);//ML01
        CEvent.ZEvent val_17 = null;
        // 0x00B22184: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00B22188: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x00B2218C: LDR x8, [x8, #0x538]       | X8 = (string**)(1152921510362009232)("OPEN_PlotMgr");
        // 0x00B22190: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B22194: MOV x2, x22                | X2 = 1152921514724908352 (0x100000025B155D40);//ML01
        // 0x00B22198: MOV x21, x0                | X21 = 1152921504898326528 (0x10000000115FA000);//ML01
        val_43 = val_17;
        // 0x00B2219C: LDR x1, [x8]               | X1 = "OPEN_PlotMgr";                    
        // 0x00B221A0: BL #0xd7de54               | .ctor(name:  "OPEN_PlotMgr", arg:  System.Object[].__il2cppRuntimeField_namespaze);
        val_17 = new CEvent.ZEvent(name:  "OPEN_PlotMgr", arg:  System.Object[].__il2cppRuntimeField_namespaze);
        label_33:
        // 0x00B221A4: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B221A8: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B221AC: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B221B0: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B221B4: TBZ w8, #0, #0xb221c4      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_49;
        // 0x00B221B8: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B221BC: CBNZ w8, #0xb221c4         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_49;
        // 0x00B221C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_49:
        // 0x00B221C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B221C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B221CC: MOV x1, x21                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B221D0: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        // 0x00B221D4: B #0xb22640                |  goto label_86;                         
        goto label_86;
        // 0x00B221D8: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B221DC: LDR x8, [x8, #0x430]       | X8 = 1152921504887730176;               
        // 0x00B221E0: LDR w22, [x21, #0x18]      | W22 = CEvent.ZEvent.__il2cppRuntimeField_namespaze;
        // 0x00B221E4: LDR x0, [x8]               | X0 = typeof(CameraHelper);              
        val_48 = null;
        // 0x00B221E8: ADD x8, x0, #0x109         | X8 = (val_48 + 265) = 1152921504887730441 (0x1000000010BDF109);
        // 0x00B221EC: LDRH w8, [x8]              | W8 = CameraHelper.__il2cppRuntimeField_109;
        // 0x00B221F0: AND w8, w8, #0x100         | W8 = (CameraHelper.__il2cppRuntimeField_109 & 256);
        // 0x00B221F4: AND w8, w8, #0xffff        | W8 = ((CameraHelper.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00B221F8: CBZ w22, #0xb22648         | if (CEvent == null) goto label_51;      
        if(CEvent == null)
        {
            goto label_51;
        }
        // 0x00B221FC: CBZ w8, #0xb2221c          | if (((CameraHelper.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_53;
        // 0x00B22200: LDR w8, [x0, #0xbc]        | W8 = CameraHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00B22204: CBNZ w8, #0xb2221c         | if (CameraHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_53;
        // 0x00B22208: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraHelper), ????);
        // 0x00B2220C: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B22210: LDR x8, [x8, #0x430]       | X8 = 1152921504887730176;               
        // 0x00B22214: LDR w22, [x21, #0x18]      | W22 = CEvent.ZEvent.__il2cppRuntimeField_namespaze;
        // 0x00B22218: LDR x0, [x8]               | X0 = typeof(CameraHelper);              
        val_49 = null;
        label_53:
        // 0x00B2221C: LDR x8, [x0, #0xa0]        | X8 = CameraHelper.__il2cppRuntimeField_static_fields;
        // 0x00B22220: LDR w21, [x21, #0x10]      | W21 = CEvent.ZEvent.__il2cppRuntimeField_name;
        // 0x00B22224: LDR x23, [x8]              | X23 = CameraHelper.instance;            
        // 0x00B22228: CBNZ x23, #0xb22230        | if (CameraHelper.instance != null) goto label_54;
        if(CameraHelper.instance != null)
        {
            goto label_54;
        }
        // 0x00B2222C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraHelper), ????);
        label_54:
        // 0x00B22230: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B22234: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B22238: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B2223C: MOV x0, x23                | X0 = CameraHelper.instance;//m1         
        // 0x00B22240: MOV w2, w22                | W2 = 1152921508010578928 (0x10000000CAE0D3F0);//ML01
        // 0x00B22244: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x00B22248: MOV w4, w21                | W4 = 1152921508010574832 (0x10000000CAE0C3F0);//ML01
        // 0x00B2224C: BL #0xbabac8               | CameraHelper.instance.MoveCamera(isHero:  false, id:  -891235344, isMove:  false, time:  0f, AIid:  -891239440);
        CameraHelper.instance.MoveCamera(isHero:  false, id:  -891235344, isMove:  false, time:  0f, AIid:  -891239440);
        // 0x00B22250: B #0xb22640                |  goto label_86;                         
        goto label_86;
        // 0x00B22254: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_50 = 0;
        // 0x00B22258: B #0xb22260                |  goto label_56;                         
        goto label_56;
        label_63:
        // 0x00B2225C: ADD w22, w22, #1           | W22 = (val_50 + 1) = val_50 (0x00000001);
        val_50 = 1;
        label_56:
        // 0x00B22260: LDR x23, [x20, #0x10]      | X23 = this.entity; //P2                 
        // 0x00B22264: CBNZ x23, #0xb2226c        | if (this.entity != null) goto label_57; 
        if(this.entity != null)
        {
            goto label_57;
        }
        // 0x00B22268: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? CameraHelper.instance, ????);
        label_57:
        // 0x00B2226C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22270: MOV x0, x23                | X0 = this.entity;//m1                   
        // 0x00B22274: BL #0xd89bd8               | X0 = this.entity.get_dropRwards();      
        System.Collections.Generic.List<EnemyDropData> val_20 = this.entity.dropRwards;
        // 0x00B22278: MOV x23, x0                | X23 = val_20;//m1                       
        // 0x00B2227C: CBNZ x23, #0xb22284        | if (val_20 != null) goto label_58;      
        if(val_20 != null)
        {
            goto label_58;
        }
        // 0x00B22280: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_58:
        // 0x00B22284: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00B22288: LDR x8, [x8, #0x310]       | X8 = 1152921514604987072;               
        // 0x00B2228C: MOV x0, x23                | X0 = val_20;//m1                        
        // 0x00B22290: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<EnemyDropData>::get_Count();
        // 0x00B22294: BL #0x25ed72c              | X0 = val_20.get_Count();                
        int val_21 = val_20.Count;
        // 0x00B22298: CMP w22, w0                | STATE = COMPARE(0x1, val_21)            
        // 0x00B2229C: B.GE #0xb21c70             | if (val_50 >= val_21) goto label_105;   
        if(val_50 >= val_21)
        {
            goto label_105;
        }
        // 0x00B222A0: LDR x23, [x20, #0x10]      | X23 = this.entity; //P2                 
        // 0x00B222A4: CBNZ x23, #0xb222ac        | if (this.entity != null) goto label_60; 
        if(this.entity != null)
        {
            goto label_60;
        }
        // 0x00B222A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_60:
        // 0x00B222AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B222B0: MOV x0, x23                | X0 = this.entity;//m1                   
        // 0x00B222B4: BL #0xd89bd8               | X0 = this.entity.get_dropRwards();      
        System.Collections.Generic.List<EnemyDropData> val_22 = this.entity.dropRwards;
        // 0x00B222B8: MOV x23, x0                | X23 = val_22;//m1                       
        // 0x00B222BC: CBNZ x23, #0xb222c4        | if (val_22 != null) goto label_61;      
        if(val_22 != null)
        {
            goto label_61;
        }
        // 0x00B222C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_61:
        // 0x00B222C4: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00B222C8: LDR x8, [x8, #0x558]       | X8 = 1152921514604996288;               
        // 0x00B222CC: MOV x0, x23                | X0 = val_22;//m1                        
        // 0x00B222D0: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00B222D4: LDR x2, [x8]               | X2 = public EnemyDropData System.Collections.Generic.List<EnemyDropData>::get_Item(int index);
        // 0x00B222D8: BL #0x25ed734              | X0 = val_22.get_Item(index:  1);        
        EnemyDropData val_23 = val_22.Item[1];
        // 0x00B222DC: MOV x23, x0                | X23 = val_23;//m1                       
        // 0x00B222E0: CBNZ x23, #0xb222e8        | if (val_23 != null) goto label_62;      
        if(val_23 != null)
        {
            goto label_62;
        }
        // 0x00B222E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_62:
        // 0x00B222E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B222EC: MOV x0, x23                | X0 = val_23;//m1                        
        // 0x00B222F0: BL #0xb65a58               | X0 = val_23.get_dropId();               
        int val_24 = val_23.dropId;
        // 0x00B222F4: LDR w8, [x21, #0x18]       | W8 = ZEvent.__il2cppRuntimeField_18;    
        // 0x00B222F8: CMP w0, w8                 | STATE = COMPARE(val_24, ZEvent.__il2cppRuntimeField_18)
        // 0x00B222FC: B.NE #0xb2225c             | if (val_24 != ZEvent.__il2cppRuntimeField_18) goto label_63;
        // 0x00B22300: CMN w22, #1                | STATE = COMPARE(0x1, 0x1)               
        // 0x00B22304: B.EQ #0xb21c70             | if (val_50 == 0x1) goto label_105;      
        if(val_50 == 1)
        {
            goto label_105;
        }
        // 0x00B22308: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2230C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22310: BL #0xb66dec               | X0 = EnemyDropMgr.get_Instance();       
        EnemyDropMgr val_25 = EnemyDropMgr.Instance;
        // 0x00B22314: LDR x23, [x20, #0x10]      | X23 = this.entity; //P2                 
        // 0x00B22318: MOV x21, x0                | X21 = val_25;//m1                       
        // 0x00B2231C: CBNZ x23, #0xb22324        | if (this.entity != null) goto label_65; 
        if(this.entity != null)
        {
            goto label_65;
        }
        // 0x00B22320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_65:
        // 0x00B22324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22328: MOV x0, x23                | X0 = this.entity;//m1                   
        // 0x00B2232C: BL #0xd89bd8               | X0 = this.entity.get_dropRwards();      
        System.Collections.Generic.List<EnemyDropData> val_26 = this.entity.dropRwards;
        // 0x00B22330: MOV x23, x0                | X23 = val_26;//m1                       
        // 0x00B22334: CBNZ x23, #0xb2233c        | if (val_26 != null) goto label_66;      
        if(val_26 != null)
        {
            goto label_66;
        }
        // 0x00B22338: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_66:
        // 0x00B2233C: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00B22340: LDR x8, [x8, #0x558]       | X8 = 1152921514604996288;               
        // 0x00B22344: MOV x0, x23                | X0 = val_26;//m1                        
        // 0x00B22348: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00B2234C: LDR x2, [x8]               | X2 = public EnemyDropData System.Collections.Generic.List<EnemyDropData>::get_Item(int index);
        // 0x00B22350: BL #0x25ed734              | X0 = val_26.get_Item(index:  1);        
        EnemyDropData val_27 = val_26.Item[1];
        // 0x00B22354: LDR x22, [x20, #0x10]      | X22 = this.entity; //P2                 
        // 0x00B22358: MOV x23, x0                | X23 = val_27;//m1                       
        // 0x00B2235C: CBNZ x21, #0xb22364        | if (val_25 != null) goto label_67;      
        if(val_25 != null)
        {
            goto label_67;
        }
        // 0x00B22360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_67:
        // 0x00B22364: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B22368: MOV x0, x21                | X0 = val_25;//m1                        
        // 0x00B2236C: MOV x1, x23                | X1 = val_27;//m1                        
        // 0x00B22370: MOV x2, x22                | X2 = this.entity;//m1                   
        // 0x00B22374: BL #0xb67120               | val_25.AddDrop(data:  val_27, entity:  this.entity);
        val_25.AddDrop(data:  val_27, entity:  this.entity);
        // 0x00B22378: B #0xb22640                |  goto label_86;                         
        goto label_86;
        // 0x00B2237C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_51 = 0;
        // 0x00B22380: B #0xb22388                |  goto label_69;                         
        goto label_69;
        label_74:
        // 0x00B22384: ADD w22, w22, #1           | W22 = (val_51 + 1) = val_51 (0x00000001);
        val_51 = 1;
        label_69:
        // 0x00B22388: LDR x23, [x20, #0x18]      | X23 = this.aiList; //P2                 
        // 0x00B2238C: CBNZ x23, #0xb22394        | if (this.aiList != null) goto label_70; 
        if(this.aiList != null)
        {
            goto label_70;
        }
        // 0x00B22390: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_70:
        // 0x00B22394: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x00B22398: LDR x8, [x8, #0x128]       | X8 = 1152921514699459456;               
        // 0x00B2239C: MOV x0, x23                | X0 = this.aiList;//m1                   
        // 0x00B223A0: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<AIObject>::get_Count();
        // 0x00B223A4: BL #0x25ed72c              | X0 = this.aiList.get_Count();           
        int val_28 = this.aiList.Count;
        // 0x00B223A8: CMP w22, w0                | STATE = COMPARE(0x1, val_28)            
        // 0x00B223AC: B.GE #0xb21c70             | if (val_51 >= val_28) goto label_105;   
        if(val_51 >= val_28)
        {
            goto label_105;
        }
        // 0x00B223B0: LDR x23, [x20, #0x18]      | X23 = this.aiList; //P2                 
        // 0x00B223B4: CBNZ x23, #0xb223bc        | if (this.aiList != null) goto label_72; 
        if(this.aiList != null)
        {
            goto label_72;
        }
        // 0x00B223B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_72:
        // 0x00B223BC: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B223C0: LDR x8, [x8, #0x168]       | X8 = 1152921514699460480;               
        // 0x00B223C4: MOV x0, x23                | X0 = this.aiList;//m1                   
        // 0x00B223C8: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00B223CC: LDR x2, [x8]               | X2 = public AIObject System.Collections.Generic.List<AIObject>::get_Item(int index);
        // 0x00B223D0: BL #0x25ed734              | X0 = this.aiList.get_Item(index:  1);   
        AIObject val_29 = this.aiList.Item[1];
        // 0x00B223D4: MOV x23, x0                | X23 = val_29;//m1                       
        // 0x00B223D8: CBNZ x23, #0xb223e0        | if (val_29 != null) goto label_73;      
        if(val_29 != null)
        {
            goto label_73;
        }
        // 0x00B223DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
        label_73:
        // 0x00B223E0: LDR w8, [x23, #0x18]       | W8 = val_29.id; //P2                    
        // 0x00B223E4: LDR w9, [x21, #0x18]       | W9 = val_25._dropList; //P2             
        // 0x00B223E8: CMP w8, w9                 | STATE = COMPARE(val_29.id, val_25._dropList)
        // 0x00B223EC: B.NE #0xb22384             | if (val_29.id != val_25._dropList) goto label_74;
        if(val_29.id != val_25._dropList)
        {
            goto label_74;
        }
        // 0x00B223F0: LDR x23, [x20, #0x18]      | X23 = this.aiList; //P2                 
        // 0x00B223F4: CBNZ x23, #0xb223fc        | if (this.aiList != null) goto label_75; 
        if(this.aiList != null)
        {
            goto label_75;
        }
        // 0x00B223F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
        label_75:
        // 0x00B223FC: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B22400: LDR x8, [x8, #0x168]       | X8 = 1152921514699460480;               
        // 0x00B22404: MOV x0, x23                | X0 = this.aiList;//m1                   
        // 0x00B22408: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00B2240C: LDR x2, [x8]               | X2 = public AIObject System.Collections.Generic.List<AIObject>::get_Item(int index);
        // 0x00B22410: BL #0x25ed734              | X0 = this.aiList.get_Item(index:  1);   
        AIObject val_30 = this.aiList.Item[1];
        // 0x00B22414: MOV x23, x0                | X23 = val_30;//m1                       
        // 0x00B22418: CBNZ x19, #0xb22420        | if (aiObj != null) goto label_76;       
        if(aiObj != null)
        {
            goto label_76;
        }
        // 0x00B2241C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_76:
        // 0x00B22420: LDR w24, [x19, #0x18]      | W24 = aiObj.id; //P2                    
        // 0x00B22424: CBNZ x23, #0xb2242c        | if (val_30 != null) goto label_77;      
        if(val_30 != null)
        {
            goto label_77;
        }
        // 0x00B22428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_77:
        // 0x00B2242C: STR w24, [x23, #0x38]      | val_30.delayID = aiObj.id;               //  dest_result_addr=0
        val_30.delayID = aiObj.id;
        // 0x00B22430: LDR x23, [x20, #0x18]      | X23 = this.aiList; //P2                 
        // 0x00B22434: CBNZ x23, #0xb2243c        | if (this.aiList != null) goto label_78; 
        if(this.aiList != null)
        {
            goto label_78;
        }
        // 0x00B22438: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_78:
        // 0x00B2243C: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B22440: LDR x8, [x8, #0x168]       | X8 = 1152921514699460480;               
        // 0x00B22444: MOV x0, x23                | X0 = this.aiList;//m1                   
        // 0x00B22448: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00B2244C: LDR x2, [x8]               | X2 = public AIObject System.Collections.Generic.List<AIObject>::get_Item(int index);
        // 0x00B22450: BL #0x25ed734              | X0 = this.aiList.get_Item(index:  1);   
        AIObject val_31 = this.aiList.Item[1];
        // 0x00B22454: MOV x23, x0                | X23 = val_31;//m1                       
        // 0x00B22458: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2245C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22460: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_32 = UnityEngine.Time.time;
        // 0x00B22464: MOV v9.16b, v0.16b         | V9 = val_32;//m1                        
        // 0x00B22468: CBNZ x23, #0xb22470        | if (val_31 != null) goto label_79;      
        if(val_31 != null)
        {
            goto label_79;
        }
        // 0x00B2246C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_79:
        // 0x00B22470: STR s9, [x23, #0x30]       | val_31.delayStartTime = val_32;          //  dest_result_addr=0
        val_31.delayStartTime = val_32;
        // 0x00B22474: LDR x23, [x20, #0x18]      | X23 = this.aiList; //P2                 
        // 0x00B22478: CBNZ x23, #0xb22480        | if (this.aiList != null) goto label_80; 
        if(this.aiList != null)
        {
            goto label_80;
        }
        // 0x00B2247C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_80:
        // 0x00B22480: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B22484: LDR x8, [x8, #0x168]       | X8 = 1152921514699460480;               
        // 0x00B22488: MOV x0, x23                | X0 = this.aiList;//m1                   
        // 0x00B2248C: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00B22490: LDR x2, [x8]               | X2 = public AIObject System.Collections.Generic.List<AIObject>::get_Item(int index);
        // 0x00B22494: BL #0x25ed734              | X0 = this.aiList.get_Item(index:  1);   
        AIObject val_33 = this.aiList.Item[1];
        // 0x00B22498: LDR w23, [x21, #0x1c]      | 
        // 0x00B2249C: MOV x21, x0                | X21 = val_33;//m1                       
        // 0x00B224A0: CBNZ x21, #0xb224a8        | if (val_33 != null) goto label_81;      
        if(val_33 != null)
        {
            goto label_81;
        }
        // 0x00B224A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
        label_81:
        // 0x00B224A8: SCVTF s0, w23              | S0 = (float)(this.aiList);              
        // 0x00B224AC: STR s0, [x21, #0x34]       | val_33.delayTime = this.aiList;          //  dest_result_addr=0
        val_33.delayTime = (float)this.aiList;
        // 0x00B224B0: CMN w22, #1                | STATE = COMPARE(0x1, 0x1)               
        // 0x00B224B4: B.EQ #0xb22640             | if (val_51 == 0x1) goto label_86;       
        if(val_51 == 1)
        {
            goto label_86;
        }
        // 0x00B224B8: LDR x21, [x20, #0x10]      | X21 = this.entity; //P2                 
        // 0x00B224BC: CBNZ x21, #0xb224c4        | if (this.entity != null) goto label_83; 
        if(this.entity != null)
        {
            goto label_83;
        }
        // 0x00B224C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
        label_83:
        // 0x00B224C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B224C8: MOV x0, x21                | X0 = this.entity;//m1                   
        // 0x00B224CC: BL #0xd89e90               | X0 = this.entity.get_AIDelayList();     
        System.Collections.Generic.List<AIObject> val_34 = this.entity.AIDelayList;
        // 0x00B224D0: LDR x23, [x20, #0x18]      | X23 = this.aiList; //P2                 
        // 0x00B224D4: MOV x21, x0                | X21 = val_34;//m1                       
        // 0x00B224D8: CBNZ x23, #0xb224e0        | if (this.aiList != null) goto label_84; 
        if(this.aiList != null)
        {
            goto label_84;
        }
        // 0x00B224DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_84:
        // 0x00B224E0: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B224E4: LDR x8, [x8, #0x168]       | X8 = 1152921514699460480;               
        // 0x00B224E8: MOV x0, x23                | X0 = this.aiList;//m1                   
        // 0x00B224EC: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00B224F0: LDR x2, [x8]               | X2 = public AIObject System.Collections.Generic.List<AIObject>::get_Item(int index);
        // 0x00B224F4: BL #0x25ed734              | X0 = this.aiList.get_Item(index:  1);   
        AIObject val_35 = this.aiList.Item[1];
        // 0x00B224F8: MOV x22, x0                | X22 = val_35;//m1                       
        // 0x00B224FC: CBNZ x21, #0xb22504        | if (val_34 != null) goto label_85;      
        if(val_34 != null)
        {
            goto label_85;
        }
        // 0x00B22500: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_85:
        // 0x00B22504: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B22508: LDR x8, [x8, #0xae0]       | X8 = 1152921514723592704;               
        // 0x00B2250C: MOV x0, x21                | X0 = val_34;//m1                        
        // 0x00B22510: MOV x1, x22                | X1 = val_35;//m1                        
        // 0x00B22514: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<AIObject>::Add(AIObject item);
        // 0x00B22518: BL #0x25ea480              | val_34.Add(item:  val_35);              
        val_34.Add(item:  val_35);
        // 0x00B2251C: B #0xb22640                |  goto label_86;                         
        goto label_86;
        // 0x00B22520: LDR x21, [x20, #0x10]      | X21 = this.entity; //P2                 
        // 0x00B22524: CBNZ x21, #0xb2252c        | if (this.entity != null) goto label_87; 
        if(this.entity != null)
        {
            goto label_87;
        }
        // 0x00B22528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_87:
        // 0x00B2252C: LDR x21, [x21, #0x488]     | X21 = this.entity.hatredCtrl; //P2      
        // 0x00B22530: CBNZ x21, #0xb22538        | if (this.entity.hatredCtrl != null) goto label_88;
        if(this.entity.hatredCtrl != null)
        {
            goto label_88;
        }
        // 0x00B22534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_88:
        // 0x00B22538: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2253C: MOV x0, x21                | X0 = this.entity.hatredCtrl;//m1        
        // 0x00B22540: BL #0x2888ef4              | this.entity.hatredCtrl.Clear();         
        this.entity.hatredCtrl.Clear();
        // 0x00B22544: B #0xb21c70                |  goto label_105;                        
        goto label_105;
        label_34:
        // 0x00B22548: CBZ w8, #0xb22558          | if (((ZMG.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_91;
        // 0x00B2254C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B22550: CBNZ w8, #0xb22558         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_91;
        // 0x00B22554: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_91:
        // 0x00B22558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2255C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22560: BL #0x26a8450              | X0 = ZMG.get_FloatTextMgr();            
        FloatTextMgr val_36 = ZMG.FloatTextMgr;
        // 0x00B22564: LDR x23, [x25]             | X23 = typeof(System.Object[]);          
        // 0x00B22568: MOV x22, x0                | X22 = val_36;//m1                       
        // 0x00B2256C: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B22570: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B22574: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B22578: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2257C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B22580: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B22584: LDR x8, [x8, #0xa90]       | X8 = 1152921504911745024;               
        // 0x00B22588: LDR w23, [x21, #0x18]      | W23 = CEvent.ZEvent.__il2cppRuntimeField_namespaze;
        // 0x00B2258C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B22590: LDR x8, [x8]               | X8 = typeof(Util);                      
        // 0x00B22594: LDRB w9, [x8, #0x10a]      | W9 = Util.__il2cppRuntimeField_10A;     
        // 0x00B22598: TBZ w9, #0, #0xb225ac      | if (Util.__il2cppRuntimeField_has_cctor == 0) goto label_93;
        // 0x00B2259C: LDR w9, [x8, #0xbc]        | W9 = Util.__il2cppRuntimeField_cctor_finished;
        // 0x00B225A0: CBNZ w9, #0xb225ac         | if (Util.__il2cppRuntimeField_cctor_finished != 0) goto label_93;
        // 0x00B225A4: MOV x0, x8                 | X0 = 1152921504911745024 (0x10000000122C6000);//ML01
        // 0x00B225A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Util), ????);
        label_93:
        // 0x00B225AC: LDR x24, [x25]             | X24 = typeof(System.Object[]);          
        // 0x00B225B0: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B225B4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B225B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B225BC: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B225C0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B225C4: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B225C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B225CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B225D0: MOV w1, w23                | W1 = 1152921508010578928 (0x10000000CAE0D3F0);//ML01
        // 0x00B225D4: BL #0xe17610               | X0 = Util.FormatUIString(key:  0, datas:  CEvent.ZEvent.__il2cppRuntimeField_namespaze);
        string val_37 = Util.FormatUIString(key:  0, datas:  CEvent.ZEvent.__il2cppRuntimeField_namespaze);
        // 0x00B225D8: MOV x23, x0                | X23 = val_37;//m1                       
        // 0x00B225DC: CBNZ x21, #0xb225e4        | if ( != null) goto label_94;            
        if(null != null)
        {
            goto label_94;
        }
        // 0x00B225E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_94:
        // 0x00B225E4: CBZ x23, #0xb22608         | if (val_37 == null) goto label_96;      
        if(val_37 == null)
        {
            goto label_96;
        }
        // 0x00B225E8: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B225EC: MOV x0, x23                | X0 = val_37;//m1                        
        // 0x00B225F0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B225F4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_37, ????);     
        // 0x00B225F8: CBNZ x0, #0xb22608         | if (val_37 != null) goto label_96;      
        if(val_37 != null)
        {
            goto label_96;
        }
        // 0x00B225FC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_37, ????);     
        // 0x00B22600: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22604: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_37, ????);     
        label_96:
        // 0x00B22608: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2260C: CBNZ w8, #0xb2261c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_97;
        // 0x00B22610: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_37, ????);     
        // 0x00B22614: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22618: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_37, ????);     
        label_97:
        // 0x00B2261C: STR x23, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_37;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_37;
        // 0x00B22620: CBNZ x22, #0xb22628        | if (val_36 != null) goto label_98;      
        if(val_36 != null)
        {
            goto label_98;
        }
        // 0x00B22624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_98:
        // 0x00B22628: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B2262C: MOVZ w1, #0x16             | W1 = 22 (0x16);//ML01                   
        val_44 = 22;
        // 0x00B22630: ORR w2, wzr, #0xf0         | W2 = 240(0xF0);                         
        val_45 = 240;
        // 0x00B22634: MOV x0, x22                | X0 = val_36;//m1                        
        // 0x00B22638: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_46 = null;
        label_47:
        // 0x00B2263C: BL #0xbfb2c4               | val_36.FloatText(textId:  22, offsetY:  240, args:  val_46 = null);
        val_36.FloatText(textId:  22, offsetY:  240, args:  val_46);
        label_86:
        // 0x00B22640: ORR w24, wzr, #1           | W24 = 1(0x1);                           
        // 0x00B22644: B #0xb21c70                |  goto label_105;                        
        goto label_105;
        label_51:
        // 0x00B22648: CBZ w8, #0xb22664          | if (((CameraHelper.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_101;
        // 0x00B2264C: LDR w8, [x0, #0xbc]        | W8 = CameraHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00B22650: CBNZ w8, #0xb22664         | if (CameraHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_101;
        // 0x00B22654: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraHelper), ????);
        // 0x00B22658: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B2265C: LDR x8, [x8, #0x430]       | X8 = 1152921504887730176;               
        // 0x00B22660: LDR x0, [x8]               | X0 = typeof(CameraHelper);              
        val_52 = null;
        label_101:
        // 0x00B22664: LDR x8, [x0, #0xa0]        | X8 = CameraHelper.__il2cppRuntimeField_static_fields;
        // 0x00B22668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2266C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22670: LDR x22, [x8]              | X22 = CameraHelper.instance;            
        // 0x00B22674: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_38 = HeroMgr.instance;
        // 0x00B22678: MOV x23, x0                | X23 = val_38;//m1                       
        // 0x00B2267C: CBNZ x23, #0xb22684        | if (val_38 != null) goto label_102;     
        if(val_38 != null)
        {
            goto label_102;
        }
        // 0x00B22680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
        label_102:
        // 0x00B22684: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22688: MOV x0, x23                | X0 = val_38;//m1                        
        // 0x00B2268C: BL #0x287fff4              | X0 = val_38.get_captain();              
        Hero val_39 = val_38.captain;
        // 0x00B22690: MOV x23, x0                | X23 = val_39;//m1                       
        // 0x00B22694: CBNZ x23, #0xb2269c        | if (val_39 != null) goto label_103;     
        if(val_39 != null)
        {
            goto label_103;
        }
        // 0x00B22698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_103:
        // 0x00B2269C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B226A0: MOV x0, x23                | X0 = val_39;//m1                        
        // 0x00B226A4: BL #0xd89a7c               | X0 = val_39.get_id();                   
        int val_40 = val_39.id;
        // 0x00B226A8: LDR w21, [x21, #0x10]      | W21 = CEvent.ZEvent.__il2cppRuntimeField_name;
        // 0x00B226AC: MOV w23, w0                | W23 = val_40;//m1                       
        // 0x00B226B0: CBNZ x22, #0xb226b8        | if (CameraHelper.instance != null) goto label_104;
        if(CameraHelper.instance != null)
        {
            goto label_104;
        }
        // 0x00B226B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_104:
        // 0x00B226B8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B226BC: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x00B226C0: MOV x0, x22                | X0 = CameraHelper.instance;//m1         
        // 0x00B226C4: MOV w2, w23                | W2 = val_40;//m1                        
        // 0x00B226C8: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x00B226CC: MOV w4, w21                | W4 = 1152921508010574832 (0x10000000CAE0C3F0);//ML01
        // 0x00B226D0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B226D4: ORR w24, wzr, #1           | W24 = 1(0x1);                           
        // 0x00B226D8: BL #0xbabac8               | CameraHelper.instance.MoveCamera(isHero:  true, id:  val_40, isMove:  true, time:  0f, AIid:  -891239440);
        CameraHelper.instance.MoveCamera(isHero:  true, id:  val_40, isMove:  true, time:  0f, AIid:  -891239440);
        // 0x00B226DC: B #0xb21c70                |  goto label_105;                        
        goto label_105;
        label_12:
        // 0x00B226E0: AND w0, w24, #1            | W0 = (0 & 1);                           
        var val_41 = val_45 & 1;
        // 0x00B226E4: SUB sp, x29, #0x60         | SP = (1152921514724716880 - 96) = 1152921514724716784 (0x100000025B1270F0);
        // 0x00B226E8: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B226EC: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B226F0: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B226F4: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B226F8: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B226FC: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00B22700: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00B22704: RET                        |  return (System.Boolean)(0 & 1);        
        return (bool)val_41;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B22708 (11675400), len: 1872  VirtAddr: 0x00B22708 RVA: 0x00B22708 token: 100691854 methodIndex: 24715 delegateWrapperIndex: 0 methodInvoker: 0
    private bool ChangeAtkTarget(int tParam1, int tParam2, int tParam3)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Object val_60;
        //  | 
        HatredCtrl val_61;
        //  | 
        var val_62;
        //  | 
        var val_63;
        //  | 
        var val_64;
        //  | 
        UnityEngine.Object val_65;
        //  | 
        CombatEntity val_66;
        // 0x00B22708: STP x24, x23, [sp, #-0x40]! | stack[1152921514725365408] = ???;  stack[1152921514725365416] = ???;  //  dest_result_addr=1152921514725365408 |  dest_result_addr=1152921514725365416
        // 0x00B2270C: STP x22, x21, [sp, #0x10]  | stack[1152921514725365424] = ???;  stack[1152921514725365432] = ???;  //  dest_result_addr=1152921514725365424 |  dest_result_addr=1152921514725365432
        // 0x00B22710: STP x20, x19, [sp, #0x20]  | stack[1152921514725365440] = ???;  stack[1152921514725365448] = ???;  //  dest_result_addr=1152921514725365440 |  dest_result_addr=1152921514725365448
        // 0x00B22714: STP x29, x30, [sp, #0x30]  | stack[1152921514725365456] = ???;  stack[1152921514725365464] = ???;  //  dest_result_addr=1152921514725365456 |  dest_result_addr=1152921514725365464
        // 0x00B22718: ADD x29, sp, #0x30         | X29 = (1152921514725365408 + 48) = 1152921514725365456 (0x100000025B1C56D0);
        // 0x00B2271C: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
        // 0x00B22720: LDRB w8, [x23, #0x725]     | W8 = (bool)static_value_03733725;       
        // 0x00B22724: MOV w21, w3                | W21 = tParam3;//m1                      
        val_60 = tParam3;
        // 0x00B22728: MOV w20, w2                | W20 = tParam2;//m1                      
        // 0x00B2272C: MOV w22, w1                | W22 = tParam1;//m1                      
        // 0x00B22730: MOV x19, x0                | X19 = 1152921514725377472 (0x100000025B1C85C0);//ML01
        val_61 = this;
        // 0x00B22734: TBNZ w8, #0, #0xb22750     | if (static_value_03733725 == true) goto label_0;
        // 0x00B22738: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B2273C: LDR x8, [x8, #0x168]       | X8 = 0x2B8AAD0;                         
        // 0x00B22740: LDR w0, [x8]               | W0 = 0x172;                             
        // 0x00B22744: BL #0x2782188              | X0 = sub_2782188( ?? 0x172, ????);      
        // 0x00B22748: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2274C: STRB w8, [x23, #0x725]     | static_value_03733725 = true;            //  dest_result_addr=57882405
        label_0:
        // 0x00B22750: LDR x23, [x19, #0x10]      | X23 = this.entity; //P2                 
        // 0x00B22754: CBNZ x23, #0xb2275c        | if (this.entity != null) goto label_1;  
        if(this.entity != null)
        {
            goto label_1;
        }
        // 0x00B22758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x172, ????);      
        label_1:
        // 0x00B2275C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22760: MOV x0, x23                | X0 = this.entity;//m1                   
        // 0x00B22764: BL #0xd89a3c               | X0 = this.entity.get_unitCamp();        
        EntityEnum.UnitCamp val_1 = this.entity.unitCamp;
        // 0x00B22768: CMP w21, #0                | STATE = COMPARE(tParam3, 0x0)           
        // 0x00B2276C: AND w9, w22, #0xff         | W9 = (tParam1 & 255);                   
        int val_2 = tParam1 & 255;
        // 0x00B22770: CSEL w10, w0, w21, eq      | W10 = val_60 == 0 ? val_1 : tParam3;    
        var val_3 = (val_60 == 0) ? (val_1) : (val_60);
        // 0x00B22774: SUB w8, w9, #1             | W8 = ((tParam1 & 255) - 1);             
        val_62 = val_2 - 1;
        // 0x00B22778: CMP w10, #1                | STATE = COMPARE(val_60 == 0 ? val_1 : tParam3, 0x1)
        // 0x00B2277C: B.NE #0xb227d4             | if (val_3 != 0x1) goto label_2;         
        if(val_3 != 1)
        {
            goto label_2;
        }
        // 0x00B22780: ADD w9, w9, #4             | W9 = ((tParam1 & 255) + 4);             
        val_2 = val_2 + 4;
        // 0x00B22784: CMP w8, #0xc               | STATE = COMPARE(((tParam1 & 255) - 1), 0xC)
        // 0x00B22788: CSEL w9, w9, wzr, lo       | W9 = val_62 < 12 ? ((tParam1 & 255) + 4) : 0;
        var val_4 = (val_62 < 12) ? (val_2) : 0;
        // 0x00B2278C: CMP w9, #0x10              | STATE = COMPARE(val_62 < 12 ? ((tParam1 & 255) + 4) : 0, 0x10)
        // 0x00B22790: B.HI #0xb22e40             | if (val_4 > 0x10) goto label_89;        
        if(val_4 > 16)
        {
            goto label_89;
        }
        // 0x00B22794: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B22798: ADD x8, x8, #0xa7c         | X8 = (44638208 + 2684) = 44640892 (0x02A92A7C);
        // 0x00B2279C: LDRSW x9, [x8, x9, lsl #2] | X9 = 44640892 + (val_62 < 12 ? ((tParam1 & 255) + 4) : 0) << 2;
        var val_60 = 44640892 + (val_62 < 12 ? ((tParam1 & 255) + 4) : 0) << 2;
        // 0x00B227A0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        // 0x00B227A4: ADD x9, x9, x8             | X9 = (44640892 + (val_62 < 12 ? ((tParam1 & 255) + 4) : 0) << 2 + 44640892);
        val_60 = val_60 + 44640892;
        // 0x00B227A8: BR x9                      | goto (44640892 + (val_62 < 12 ? ((tParam1 & 255) + 4) : 0) << 2 + 44640892);
        goto (44640892 + (val_62 < 12 ? ((tParam1 & 255) + 4) : 0) << 2 + 44640892);
        // 0x00B227AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B227B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B227B4: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_5 = NpcMgr.instance;
        // 0x00B227B8: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B227BC: CBNZ x20, #0xb227c4        | if (val_5 != null) goto label_4;        
        if(val_5 != null)
        {
            goto label_4;
        }
        // 0x00B227C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_4:
        // 0x00B227C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B227C8: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00B227CC: BL #0xd154dc               | X0 = val_5.GetHurtMaxNpc();             
        CombatEntity val_6 = val_5.GetHurtMaxNpc();
        // 0x00B227D0: B #0xb22a9c                |  goto label_27;                         
        goto label_27;
        label_2:
        // 0x00B227D4: ADD w9, w9, #0x1f          | W9 = ((tParam1 & 255) + 31);            
        val_2 = val_2 + 31;
        // 0x00B227D8: CMP w8, #0xc               | STATE = COMPARE(((tParam1 & 255) - 1), 0xC)
        // 0x00B227DC: CSEL w9, w9, wzr, lo       | W9 = val_62 < 12 ? ((tParam1 & 255) + 31) : 0;
        var val_7 = (val_62 < 12) ? (val_2) : 0;
        // 0x00B227E0: SUB w8, w9, #0x20          | W8 = (val_62 < 12 ? ((tParam1 & 255) + 31) : 0 - 32);
        val_62 = val_7 - 32;
        // 0x00B227E4: CMP w8, #0xb               | STATE = COMPARE((val_62 < 12 ? ((tParam1 & 255) + 31) : 0 - 32), 0xB)
        // 0x00B227E8: B.HI #0xb22828             | if (val_62 > 0xB) goto label_6;         
        if(val_62 > 11)
        {
            goto label_6;
        }
        // 0x00B227EC: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x00B227F0: ADD x9, x9, #0xa4c         | X9 = (44638208 + 2636) = 44640844 (0x02A92A4C);
        // 0x00B227F4: LDRSW x8, [x9, x8, lsl #2] | X8 = 44640844 + ((val_62 < 12 ? ((tParam1 & 255) + 31) : 0 - 32)) << 2;
        var val_61 = 44640844 + ((val_62 < 12 ? ((tParam1 & 255) + 31) : 0 - 32)) << 2;
        // 0x00B227F8: ADD x8, x8, x9             | X8 = (44640844 + ((val_62 < 12 ? ((tParam1 & 255) + 31) : 0 - 32)) << 2 + 44640844);
        val_61 = val_61 + 44640844;
        // 0x00B227FC: BR x8                      | goto (44640844 + ((val_62 < 12 ? ((tParam1 & 255) + 31) : 0 - 32)) << 2 + 44640844);
        goto (44640844 + ((val_62 < 12 ? ((tParam1 & 255) + 31) : 0 - 32)) << 2 + 44640844);
        // 0x00B22800: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22808: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_8 = HeroMgr.instance;
        // 0x00B2280C: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B22810: CBNZ x20, #0xb22818        | if (val_8 != null) goto label_7;        
        if(val_8 != null)
        {
            goto label_7;
        }
        // 0x00B22814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_7:
        // 0x00B22818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2281C: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00B22820: BL #0x2899f18              | X0 = val_8.GetHurtMaxHero();            
        Hero val_9 = val_8.GetHurtMaxHero();
        // 0x00B22824: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        label_6:
        // 0x00B22828: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        val_65 = 0;
        // 0x00B2282C: CBZ w9, #0xb22d98          | if (val_62 < 12 ? ((tParam1 & 255) + 31) : 0 == 0) goto label_76;
        if(val_7 == 0)
        {
            goto label_76;
        }
        // 0x00B22830: B #0xb22e40                |  goto label_89;                         
        goto label_89;
        // 0x00B22834: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2283C: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_10 = NpcMgr.instance;
        // 0x00B22840: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B22844: CBNZ x20, #0xb2284c        | if (val_10 != null) goto label_11;      
        if(val_10 != null)
        {
            goto label_11;
        }
        // 0x00B22848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_11:
        // 0x00B2284C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22850: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B22854: BL #0xd1560c               | X0 = val_10.GetCureNpc();               
        CombatEntity val_11 = val_10.GetCureNpc();
        // 0x00B22858: B #0xb22a9c                |  goto label_27;                         
        goto label_27;
        // 0x00B2285C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22864: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_12 = NpcMgr.instance;
        // 0x00B22868: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00B2286C: CBNZ x20, #0xb22874        | if (val_12 != null) goto label_13;      
        if(val_12 != null)
        {
            goto label_13;
        }
        // 0x00B22870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_13:
        // 0x00B22874: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22878: MOV x0, x20                | X0 = val_12;//m1                        
        // 0x00B2287C: BL #0xd15a24               | X0 = val_12.GetHPMinNpc();              
        CombatEntity val_13 = val_12.GetHPMinNpc();
        // 0x00B22880: B #0xb22a9c                |  goto label_27;                         
        goto label_27;
        // 0x00B22884: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22888: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2288C: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_14 = NpcMgr.instance;
        // 0x00B22890: MOV x20, x0                | X20 = val_14;//m1                       
        // 0x00B22894: CBNZ x20, #0xb2289c        | if (val_14 != null) goto label_15;      
        if(val_14 != null)
        {
            goto label_15;
        }
        // 0x00B22898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_15:
        // 0x00B2289C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B228A0: MOV x0, x20                | X0 = val_14;//m1                        
        // 0x00B228A4: BL #0xd15928               | X0 = val_14.GetRemoteNpc();             
        CombatEntity val_15 = val_14.GetRemoteNpc();
        // 0x00B228A8: B #0xb22a9c                |  goto label_27;                         
        goto label_27;
        // 0x00B228AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B228B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B228B4: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_16 = NpcMgr.instance;
        // 0x00B228B8: LDR x20, [x19, #0x10]      | X20 = this.entity; //P2                 
        // 0x00B228BC: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x00B228C0: CBNZ x21, #0xb228c8        | if (val_16 != null) goto label_17;      
        if(val_16 != null)
        {
            goto label_17;
        }
        // 0x00B228C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_17:
        // 0x00B228C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B228CC: MOV x0, x21                | X0 = val_16;//m1                        
        // 0x00B228D0: MOV x1, x20                | X1 = this.entity;//m1                   
        // 0x00B228D4: BL #0xd15b54               | X0 = val_16.GetNearestNpc(entity:  this.entity);
        CombatEntity val_17 = val_16.GetNearestNpc(entity:  this.entity);
        // 0x00B228D8: B #0xb22a9c                |  goto label_27;                         
        goto label_27;
        // 0x00B228DC: LDR x20, [x19, #0x10]      | X20 = this.entity; //P2                 
        // 0x00B228E0: CBNZ x20, #0xb228e8        | if (this.entity != null) goto label_19; 
        if(this.entity != null)
        {
            goto label_19;
        }
        // 0x00B228E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_19:
        // 0x00B228E8: LDR x20, [x20, #0x488]     | X20 = this.entity.hatredCtrl; //P2      
        // 0x00B228EC: CBNZ x20, #0xb228f4        | if (this.entity.hatredCtrl != null) goto label_20;
        if(this.entity.hatredCtrl != null)
        {
            goto label_20;
        }
        // 0x00B228F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_20:
        // 0x00B228F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B228F8: MOV x0, x20                | X0 = this.entity.hatredCtrl;//m1        
        // 0x00B228FC: BL #0x2887f04              | X0 = this.entity.hatredCtrl.GetMaxHatredEntity();
        CombatEntity val_18 = this.entity.hatredCtrl.GetMaxHatredEntity();
        // 0x00B22900: B #0xb22a9c                |  goto label_27;                         
        goto label_27;
        // 0x00B22904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22908: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2290C: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_19 = NpcMgr.instance;
        // 0x00B22910: MOV x21, x0                | X21 = val_19;//m1                       
        // 0x00B22914: CBNZ x21, #0xb2291c        | if (val_19 != null) goto label_22;      
        if(val_19 != null)
        {
            goto label_22;
        }
        // 0x00B22918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_22:
        // 0x00B2291C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22920: MOV x0, x21                | X0 = val_19;//m1                        
        // 0x00B22924: MOV w1, w20                | W1 = this.entity.hatredCtrl;//m1        
        // 0x00B22928: BL #0xd15708               | X0 = val_19.GetHostilNpcById(id:  this.entity.hatredCtrl);
        CombatEntity val_20 = val_19.GetHostilNpcById(id:  this.entity.hatredCtrl);
        // 0x00B2292C: B #0xb22a9c                |  goto label_27;                         
        goto label_27;
        // 0x00B22930: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22938: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_21 = NpcMgr.instance;
        // 0x00B2293C: MOV x21, x0                | X21 = val_21;//m1                       
        // 0x00B22940: CBNZ x21, #0xb22948        | if (val_21 != null) goto label_24;      
        if(val_21 != null)
        {
            goto label_24;
        }
        // 0x00B22944: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_24:
        // 0x00B22948: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2294C: MOV x0, x21                | X0 = val_21;//m1                        
        // 0x00B22950: MOV w1, w20                | W1 = this.entity.hatredCtrl;//m1        
        // 0x00B22954: BL #0xd15d9c               | X0 = val_21.GetSexNpc(sexType:  this.entity.hatredCtrl);
        CombatEntity val_22 = val_21.GetSexNpc(sexType:  this.entity.hatredCtrl);
        // 0x00B22958: B #0xb22a9c                |  goto label_27;                         
        goto label_27;
        // 0x00B2295C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22964: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_23 = NpcMgr.instance;
        // 0x00B22968: MOV x21, x0                | X21 = val_23;//m1                       
        // 0x00B2296C: CBNZ x21, #0xb22974        | if (val_23 != null) goto label_26;      
        if(val_23 != null)
        {
            goto label_26;
        }
        // 0x00B22970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_26:
        // 0x00B22974: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22978: MOV x0, x21                | X0 = val_23;//m1                        
        // 0x00B2297C: MOV w1, w20                | W1 = this.entity.hatredCtrl;//m1        
        // 0x00B22980: BL #0xd15808               | X0 = val_23.GetNeutralNpcById(id:  this.entity.hatredCtrl);
        CombatEntity val_24 = val_23.GetNeutralNpcById(id:  this.entity.hatredCtrl);
        // 0x00B22984: B #0xb22a9c                |  goto label_27;                         
        goto label_27;
        // 0x00B22988: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B2298C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B22990: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B22994: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B22998: TBZ w8, #0, #0xb229a8      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_29;
        // 0x00B2299C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B229A0: CBNZ w8, #0xb229a8         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
        // 0x00B229A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_29:
        // 0x00B229A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B229AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B229B0: BL #0x26a87d0              | X0 = ZMG.get_CameraShotMgr();           
        CameraShotMgr val_25 = ZMG.CameraShotMgr;
        // 0x00B229B4: MOV x20, x0                | X20 = val_25;//m1                       
        // 0x00B229B8: CBNZ x20, #0xb229c0        | if (val_25 != null) goto label_30;      
        if(val_25 != null)
        {
            goto label_30;
        }
        // 0x00B229BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_30:
        // 0x00B229C0: LDRB w8, [x20, #0x44]      | W8 = val_25.isCameraShotRunning; //P2   
        // 0x00B229C4: CBZ w8, #0xb22a78          | if (val_25.isCameraShotRunning == false) goto label_31;
        if(val_25.isCameraShotRunning == false)
        {
            goto label_31;
        }
        // 0x00B229C8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_60 = 0;
        // 0x00B229CC: B #0xb22aa0                |  goto label_40;                         
        goto label_40;
        // 0x00B229D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B229D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B229D8: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_26 = HeroMgr.instance;
        // 0x00B229DC: MOV x21, x0                | X21 = val_26;//m1                       
        // 0x00B229E0: CBNZ x21, #0xb229e8        | if (val_26 != null) goto label_33;      
        if(val_26 != null)
        {
            goto label_33;
        }
        // 0x00B229E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_33:
        // 0x00B229E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B229EC: MOV x0, x21                | X0 = val_26;//m1                        
        // 0x00B229F0: MOV w1, w20                | W1 = val_25;//m1                        
        // 0x00B229F4: BL #0x289a9dc              | X0 = val_26.GetHeroByID(id:  val_25);   
        Hero val_27 = val_26.GetHeroByID(id:  val_25);
        // 0x00B229F8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B229FC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B22A00: MOV x21, x0                | X21 = val_27;//m1                       
        val_60 = val_27;
        // 0x00B22A04: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00B22A08: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B22A0C: TBZ w9, #0, #0xb22a20      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_35;
        // 0x00B22A10: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B22A14: CBNZ w9, #0xb22a20         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
        // 0x00B22A18: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B22A1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_35:
        // 0x00B22A20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22A24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22A28: MOV x1, x21                | X1 = val_27;//m1                        
        // 0x00B22A2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B22A30: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_60);
        bool val_28 = UnityEngine.Object.op_Equality(x:  0, y:  val_60);
        // 0x00B22A34: TBZ w0, #0, #0xb22aa0      | if (val_28 == false) goto label_40;     
        if(val_28 == false)
        {
            goto label_40;
        }
        // 0x00B22A38: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B22A3C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B22A40: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B22A44: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B22A48: TBZ w8, #0, #0xb22a58      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_38;
        // 0x00B22A4C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B22A50: CBNZ w8, #0xb22a58         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
        // 0x00B22A54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_38:
        // 0x00B22A58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22A5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22A60: BL #0x26a87d0              | X0 = ZMG.get_CameraShotMgr();           
        CameraShotMgr val_29 = ZMG.CameraShotMgr;
        // 0x00B22A64: MOV x20, x0                | X20 = val_29;//m1                       
        // 0x00B22A68: CBNZ x20, #0xb22a70        | if (val_29 != null) goto label_39;      
        if(val_29 != null)
        {
            goto label_39;
        }
        // 0x00B22A6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
        label_39:
        // 0x00B22A70: LDRB w8, [x20, #0x44]      | W8 = val_29.isCameraShotRunning; //P2   
        // 0x00B22A74: CBNZ w8, #0xb22aa0         | if (val_29.isCameraShotRunning == true) goto label_40;
        if(val_29.isCameraShotRunning == true)
        {
            goto label_40;
        }
        label_31:
        // 0x00B22A78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22A7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22A80: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_30 = HeroMgr.instance;
        // 0x00B22A84: MOV x20, x0                | X20 = val_30;//m1                       
        // 0x00B22A88: CBNZ x20, #0xb22a90        | if (val_30 != null) goto label_41;      
        if(val_30 != null)
        {
            goto label_41;
        }
        // 0x00B22A8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_41:
        // 0x00B22A90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22A94: MOV x0, x20                | X0 = val_30;//m1                        
        // 0x00B22A98: BL #0x287fff4              | X0 = val_30.get_captain();              
        Hero val_31 = val_30.captain;
        label_27:
        // 0x00B22A9C: MOV x21, x0                | X21 = val_31;//m1                       
        val_60 = val_31;
        label_40:
        // 0x00B22AA0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B22AA4: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B22AA8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B22AAC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B22AB0: TBZ w8, #0, #0xb22ac0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_43;
        // 0x00B22AB4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B22AB8: CBNZ w8, #0xb22ac0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
        // 0x00B22ABC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_43:
        // 0x00B22AC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22AC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22AC8: MOV x1, x21                | X1 = val_31;//m1                        
        // 0x00B22ACC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B22AD0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_60);
        bool val_32 = UnityEngine.Object.op_Inequality(x:  0, y:  val_60);
        // 0x00B22AD4: TBZ w0, #0, #0xb22e3c      | if (val_32 == false) goto label_82;     
        if(val_32 == false)
        {
            goto label_82;
        }
        // 0x00B22AD8: CBNZ x21, #0xb22ae0        | if (val_31 != null) goto label_45;      
        if(val_60 != null)
        {
            goto label_45;
        }
        // 0x00B22ADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_45:
        // 0x00B22AE0: LDR x8, [x21, #0x488]      | 
        // 0x00B22AE4: CBZ x8, #0xb22e34          | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished == 0) goto label_84;
        // 0x00B22AE8: LDR x20, [x19, #0x10]      | X20 = this.entity; //P2                 
        // 0x00B22AEC: CBNZ x20, #0xb22af4        | if (this.entity != null) goto label_47; 
        if(this.entity != null)
        {
            goto label_47;
        }
        // 0x00B22AF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_47:
        // 0x00B22AF4: LDR x20, [x20, #0x488]     | X20 = this.entity.hatredCtrl; //P2      
        // 0x00B22AF8: CBNZ x20, #0xb22b00        | if (this.entity.hatredCtrl != null) goto label_48;
        if(this.entity.hatredCtrl != null)
        {
            goto label_48;
        }
        // 0x00B22AFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_48:
        // 0x00B22B00: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B22B04: LDR s0, [x8, #0x92c]       | S0 = 100000;                            
        // 0x00B22B08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22B0C: MOV x0, x20                | X0 = this.entity.hatredCtrl;//m1        
        // 0x00B22B10: MOV x1, x21                | X1 = val_31;//m1                        
        val_66 = val_60;
        // 0x00B22B14: B #0xb22e0c                |  goto label_49;                         
        goto label_49;
        // 0x00B22B18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22B1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22B20: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_33 = HeroMgr.instance;
        // 0x00B22B24: MOV x20, x0                | X20 = val_33;//m1                       
        // 0x00B22B28: CBNZ x20, #0xb22b30        | if (val_33 != null) goto label_50;      
        if(val_33 != null)
        {
            goto label_50;
        }
        // 0x00B22B2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
        label_50:
        // 0x00B22B30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22B34: MOV x0, x20                | X0 = val_33;//m1                        
        // 0x00B22B38: BL #0x289a06c              | X0 = val_33.GetCureHero();              
        Hero val_34 = val_33.GetCureHero();
        // 0x00B22B3C: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        // 0x00B22B40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22B44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22B48: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_35 = HeroMgr.instance;
        // 0x00B22B4C: MOV x20, x0                | X20 = val_35;//m1                       
        // 0x00B22B50: CBNZ x20, #0xb22b58        | if (val_35 != null) goto label_52;      
        if(val_35 != null)
        {
            goto label_52;
        }
        // 0x00B22B54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_52:
        // 0x00B22B58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22B5C: MOV x0, x20                | X0 = val_35;//m1                        
        // 0x00B22B60: BL #0x289a244              | X0 = val_35.GetHPMinHero();             
        Hero val_36 = val_35.GetHPMinHero();
        // 0x00B22B64: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        // 0x00B22B68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22B6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22B70: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_37 = HeroMgr.instance;
        // 0x00B22B74: MOV x20, x0                | X20 = val_37;//m1                       
        // 0x00B22B78: CBNZ x20, #0xb22b80        | if (val_37 != null) goto label_54;      
        if(val_37 != null)
        {
            goto label_54;
        }
        // 0x00B22B7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_54:
        // 0x00B22B80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22B84: MOV x0, x20                | X0 = val_37;//m1                        
        // 0x00B22B88: BL #0x289a158              | X0 = val_37.GetRemoteHero();            
        Hero val_38 = val_37.GetRemoteHero();
        // 0x00B22B8C: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        // 0x00B22B90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22B98: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_39 = HeroMgr.instance;
        // 0x00B22B9C: LDR x20, [x19, #0x10]      | X20 = this.entity; //P2                 
        // 0x00B22BA0: MOV x21, x0                | X21 = val_39;//m1                       
        val_60 = val_39;
        // 0x00B22BA4: CBNZ x21, #0xb22bac        | if (val_39 != null) goto label_56;      
        if(val_60 != null)
        {
            goto label_56;
        }
        // 0x00B22BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_56:
        // 0x00B22BAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22BB0: MOV x0, x21                | X0 = val_39;//m1                        
        // 0x00B22BB4: MOV x1, x20                | X1 = this.entity;//m1                   
        // 0x00B22BB8: BL #0x289a398              | X0 = val_39.GetNearestHero(entity:  this.entity);
        Hero val_40 = val_60.GetNearestHero(entity:  this.entity);
        // 0x00B22BBC: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        // 0x00B22BC0: LDR x20, [x19, #0x10]      | X20 = this.entity; //P2                 
        // 0x00B22BC4: CBNZ x20, #0xb22bcc        | if (this.entity != null) goto label_58; 
        if(this.entity != null)
        {
            goto label_58;
        }
        // 0x00B22BC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_58:
        // 0x00B22BCC: LDR x20, [x20, #0x488]     | X20 = this.entity.hatredCtrl; //P2      
        // 0x00B22BD0: CBNZ x20, #0xb22bd8        | if (this.entity.hatredCtrl != null) goto label_59;
        if(this.entity.hatredCtrl != null)
        {
            goto label_59;
        }
        // 0x00B22BD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_59:
        // 0x00B22BD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22BDC: MOV x0, x20                | X0 = this.entity.hatredCtrl;//m1        
        // 0x00B22BE0: BL #0x2887f04              | X0 = this.entity.hatredCtrl.GetMaxHatredEntity();
        CombatEntity val_41 = this.entity.hatredCtrl.GetMaxHatredEntity();
        // 0x00B22BE4: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        // 0x00B22BE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22BEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22BF0: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_42 = HeroMgr.instance;
        // 0x00B22BF4: LDR x20, [x19, #0x10]      | X20 = this.entity; //P2                 
        // 0x00B22BF8: MOV x21, x0                | X21 = val_42;//m1                       
        val_60 = val_42;
        // 0x00B22BFC: CBNZ x21, #0xb22c04        | if (val_42 != null) goto label_61;      
        if(val_60 != null)
        {
            goto label_61;
        }
        // 0x00B22C00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
        label_61:
        // 0x00B22C04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22C08: MOV x0, x21                | X0 = val_42;//m1                        
        // 0x00B22C0C: MOV x1, x20                | X1 = this.entity;//m1                   
        // 0x00B22C10: BL #0x289a7f0              | X0 = val_42.GetDefenseHero(entity:  this.entity);
        Hero val_43 = val_60.GetDefenseHero(entity:  this.entity);
        // 0x00B22C14: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        // 0x00B22C18: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B22C1C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B22C20: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B22C24: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B22C28: TBZ w8, #0, #0xb22c38      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_64;
        // 0x00B22C2C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B22C30: CBNZ w8, #0xb22c38         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_64;
        // 0x00B22C34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_64:
        // 0x00B22C38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22C3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22C40: BL #0x26a87d0              | X0 = ZMG.get_CameraShotMgr();           
        CameraShotMgr val_44 = ZMG.CameraShotMgr;
        // 0x00B22C44: MOV x21, x0                | X21 = val_44;//m1                       
        // 0x00B22C48: CBNZ x21, #0xb22c50        | if (val_44 != null) goto label_65;      
        if(val_44 != null)
        {
            goto label_65;
        }
        // 0x00B22C4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
        label_65:
        // 0x00B22C50: LDRB w8, [x21, #0x44]      | W8 = val_44.isCameraShotRunning; //P2   
        // 0x00B22C54: CBZ w8, #0xb22d6c          | if (val_44.isCameraShotRunning == false) goto label_66;
        if(val_44.isCameraShotRunning == false)
        {
            goto label_66;
        }
        // 0x00B22C58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22C5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22C60: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_45 = NpcMgr.instance;
        // 0x00B22C64: MOV x21, x0                | X21 = val_45;//m1                       
        val_60 = val_45;
        // 0x00B22C68: CBNZ x21, #0xb22c70        | if (val_45 != null) goto label_67;      
        if(val_60 != null)
        {
            goto label_67;
        }
        // 0x00B22C6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_67:
        // 0x00B22C70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22C74: MOV x0, x21                | X0 = val_45;//m1                        
        // 0x00B22C78: MOV w1, w20                | W1 = this.entity;//m1                   
        // 0x00B22C7C: BL #0xd14100               | X0 = val_45.GetAniShowNpc(id:  this.entity);
        CombatEntity val_46 = val_60.GetAniShowNpc(id:  this.entity);
        // 0x00B22C80: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        // 0x00B22C84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22C88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22C8C: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_47 = HeroMgr.instance;
        // 0x00B22C90: MOV x21, x0                | X21 = val_47;//m1                       
        val_60 = val_47;
        // 0x00B22C94: CBNZ x21, #0xb22c9c        | if (val_47 != null) goto label_69;      
        if(val_60 != null)
        {
            goto label_69;
        }
        // 0x00B22C98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_69:
        // 0x00B22C9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22CA0: MOV x0, x21                | X0 = val_47;//m1                        
        // 0x00B22CA4: MOV w1, w20                | W1 = this.entity;//m1                   
        // 0x00B22CA8: BL #0x289aacc              | X0 = val_47.GetHeroBySex(sexType:  this.entity);
        Hero val_48 = val_60.GetHeroBySex(sexType:  this.entity);
        // 0x00B22CAC: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        // 0x00B22CB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22CB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22CB8: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_49 = NpcMgr.instance;
        // 0x00B22CBC: MOV x21, x0                | X21 = val_49;//m1                       
        val_60 = val_49;
        // 0x00B22CC0: CBNZ x21, #0xb22cc8        | if (val_49 != null) goto label_71;      
        if(val_60 != null)
        {
            goto label_71;
        }
        // 0x00B22CC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
        label_71:
        // 0x00B22CC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22CCC: MOV x0, x21                | X0 = val_49;//m1                        
        // 0x00B22CD0: MOV w1, w20                | W1 = this.entity;//m1                   
        // 0x00B22CD4: BL #0xd15808               | X0 = val_49.GetNeutralNpcById(id:  this.entity);
        CombatEntity val_50 = val_60.GetNeutralNpcById(id:  this.entity);
        // 0x00B22CD8: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        // 0x00B22CDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22CE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22CE4: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_51 = HeroMgr.instance;
        // 0x00B22CE8: MOV x21, x0                | X21 = val_51;//m1                       
        val_60 = val_51;
        // 0x00B22CEC: CBNZ x21, #0xb22cf4        | if (val_51 != null) goto label_73;      
        if(val_60 != null)
        {
            goto label_73;
        }
        // 0x00B22CF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
        label_73:
        // 0x00B22CF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22CF8: MOV x0, x21                | X0 = val_51;//m1                        
        // 0x00B22CFC: MOV w1, w20                | W1 = this.entity;//m1                   
        // 0x00B22D00: BL #0x289a9dc              | X0 = val_51.GetHeroByID(id:  this.entity);
        Hero val_52 = val_60.GetHeroByID(id:  this.entity);
        // 0x00B22D04: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B22D08: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B22D0C: MOV x20, x0                | X20 = val_52;//m1                       
        val_65 = val_52;
        // 0x00B22D10: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00B22D14: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B22D18: TBZ w9, #0, #0xb22d2c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_75;
        // 0x00B22D1C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B22D20: CBNZ w9, #0xb22d2c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_75;
        // 0x00B22D24: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B22D28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_75:
        // 0x00B22D2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22D30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22D34: MOV x1, x20                | X1 = val_52;//m1                        
        // 0x00B22D38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B22D3C: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_65);
        bool val_53 = UnityEngine.Object.op_Equality(x:  0, y:  val_65);
        // 0x00B22D40: TBZ w0, #0, #0xb22d98      | if (val_53 == false) goto label_76;     
        if(val_53 == false)
        {
            goto label_76;
        }
        // 0x00B22D44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22D48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22D4C: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_54 = HeroMgr.instance;
        // 0x00B22D50: MOV x20, x0                | X20 = val_54;//m1                       
        // 0x00B22D54: CBNZ x20, #0xb22d5c        | if (val_54 != null) goto label_77;      
        if(val_54 != null)
        {
            goto label_77;
        }
        // 0x00B22D58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_54, ????);     
        label_77:
        // 0x00B22D5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22D60: MOV x0, x20                | X0 = val_54;//m1                        
        // 0x00B22D64: BL #0x287fff4              | X0 = val_54.get_captain();              
        Hero val_55 = val_54.captain;
        // 0x00B22D68: B #0xb22d94                |  goto label_78;                         
        goto label_78;
        label_66:
        // 0x00B22D6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22D70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22D74: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_56 = HeroMgr.instance;
        // 0x00B22D78: MOV x21, x0                | X21 = val_56;//m1                       
        val_60 = val_56;
        // 0x00B22D7C: CBNZ x21, #0xb22d84        | if (val_56 != null) goto label_79;      
        if(val_60 != null)
        {
            goto label_79;
        }
        // 0x00B22D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
        label_79:
        // 0x00B22D84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22D88: MOV x0, x21                | X0 = val_56;//m1                        
        // 0x00B22D8C: MOV w1, w20                | W1 = this.entity;//m1                   
        // 0x00B22D90: BL #0x289a9dc              | X0 = val_56.GetHeroByID(id:  this.entity);
        Hero val_57 = val_60.GetHeroByID(id:  this.entity);
        label_78:
        // 0x00B22D94: MOV x20, x0                | X20 = val_57;//m1                       
        val_65 = val_57;
        label_76:
        // 0x00B22D98: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B22D9C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B22DA0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B22DA4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B22DA8: TBZ w8, #0, #0xb22db8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_81;
        // 0x00B22DAC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B22DB0: CBNZ w8, #0xb22db8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_81;
        // 0x00B22DB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_81:
        // 0x00B22DB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B22DBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22DC0: MOV x1, x20                | X1 = val_57;//m1                        
        // 0x00B22DC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B22DC8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_65);
        bool val_58 = UnityEngine.Object.op_Inequality(x:  0, y:  val_65);
        // 0x00B22DCC: TBZ w0, #0, #0xb22e3c      | if (val_58 == false) goto label_82;     
        if(val_58 == false)
        {
            goto label_82;
        }
        // 0x00B22DD0: CBNZ x20, #0xb22dd8        | if (val_57 != null) goto label_83;      
        if(val_65 != null)
        {
            goto label_83;
        }
        // 0x00B22DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_83:
        // 0x00B22DD8: LDR x8, [x20, #0x488]      | 
        // 0x00B22DDC: CBZ x8, #0xb22e34          | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished == 0) goto label_84;
        // 0x00B22DE0: LDR x21, [x19, #0x10]      | X21 = this.entity; //P2                 
        // 0x00B22DE4: CBNZ x21, #0xb22dec        | if (this.entity != null) goto label_85; 
        if(this.entity != null)
        {
            goto label_85;
        }
        // 0x00B22DE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_85:
        // 0x00B22DEC: LDR x21, [x21, #0x488]     | X21 = this.entity.hatredCtrl; //P2      
        val_60 = this.entity.hatredCtrl;
        // 0x00B22DF0: CBNZ x21, #0xb22df8        | if (this.entity.hatredCtrl != null) goto label_86;
        if(val_60 != null)
        {
            goto label_86;
        }
        // 0x00B22DF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_86:
        // 0x00B22DF8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B22DFC: LDR s0, [x8, #0x92c]       | S0 = 100000;                            
        // 0x00B22E00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B22E04: MOV x0, x21                | X0 = this.entity.hatredCtrl;//m1        
        // 0x00B22E08: MOV x1, x20                | X1 = val_57;//m1                        
        val_66 = val_65;
        label_49:
        // 0x00B22E0C: BL #0x28875f4              | this.entity.hatredCtrl.AddHatred(entity:  val_66 = val_65, hatred:  100000f);
        val_60.AddHatred(entity:  val_66, hatred:  100000f);
        // 0x00B22E10: LDR x19, [x19, #0x10]      | X19 = this.entity; //P2                 
        // 0x00B22E14: CBNZ x19, #0xb22e1c        | if (this.entity != null) goto label_87; 
        if(this.entity != null)
        {
            goto label_87;
        }
        // 0x00B22E18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.entity.hatredCtrl, ????);
        label_87:
        // 0x00B22E1C: LDR x19, [x19, #0x488]     | X19 = this.entity.hatredCtrl; //P2      
        val_61 = this.entity.hatredCtrl;
        // 0x00B22E20: CBNZ x19, #0xb22e28        | if (this.entity.hatredCtrl != null) goto label_88;
        if(val_61 != null)
        {
            goto label_88;
        }
        // 0x00B22E24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.entity.hatredCtrl, ????);
        label_88:
        // 0x00B22E28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22E2C: MOV x0, x19                | X0 = this.entity.hatredCtrl;//m1        
        // 0x00B22E30: BL #0x288776c              | this.entity.hatredCtrl.ChangeAttackTarge();
        val_61.ChangeAttackTarge();
        label_84:
        // 0x00B22E34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        val_62 = 1;
        // 0x00B22E38: B #0xb22e40                |  goto label_89;                         
        goto label_89;
        label_82:
        // 0x00B22E3C: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
        val_62 = 0;
        label_89:
        // 0x00B22E40: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B22E44: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B22E48: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B22E4C: AND w0, w8, #1             | W0 = (val_62 & 1);                      
        var val_59 = val_62 & 1;
        // 0x00B22E50: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B22E54: RET                        |  return (System.Boolean)(val_62 & 1);   
        return (bool)val_59;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B215D8 (11671000), len: 1168  VirtAddr: 0x00B215D8 RVA: 0x00B215D8 token: 100691855 methodIndex: 24716 delegateWrapperIndex: 0 methodInvoker: 0
    private bool CheckCondition(npcAIConditionCfg condition, int tParam1, int tParam2)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00B215D8: STP x24, x23, [sp, #-0x40]! | stack[1152921514725747744] = ???;  stack[1152921514725747752] = ???;  //  dest_result_addr=1152921514725747744 |  dest_result_addr=1152921514725747752
        // 0x00B215DC: STP x22, x21, [sp, #0x10]  | stack[1152921514725747760] = ???;  stack[1152921514725747768] = ???;  //  dest_result_addr=1152921514725747760 |  dest_result_addr=1152921514725747768
        // 0x00B215E0: STP x20, x19, [sp, #0x20]  | stack[1152921514725747776] = ???;  stack[1152921514725747784] = ???;  //  dest_result_addr=1152921514725747776 |  dest_result_addr=1152921514725747784
        // 0x00B215E4: STP x29, x30, [sp, #0x30]  | stack[1152921514725747792] = ???;  stack[1152921514725747800] = ???;  //  dest_result_addr=1152921514725747792 |  dest_result_addr=1152921514725747800
        // 0x00B215E8: ADD x29, sp, #0x30         | X29 = (1152921514725747744 + 48) = 1152921514725747792 (0x100000025B222C50);
        // 0x00B215EC: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B215F0: LDRB w8, [x22, #0x726]     | W8 = (bool)static_value_03733726;       
        // 0x00B215F4: MOV w21, w3                | W21 = tParam2;//m1                      
        // 0x00B215F8: MOV w20, w2                | W20 = tParam1;//m1                      
        // 0x00B215FC: MOV x19, x1                | X19 = condition;//m1                    
        // 0x00B21600: MOV x23, x0                | X23 = 1152921514725759808 (0x100000025B225B40);//ML01
        // 0x00B21604: TBNZ w8, #0, #0xb21620     | if (static_value_03733726 == true) goto label_0;
        // 0x00B21608: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
        // 0x00B2160C: LDR x8, [x8, #0xda8]       | X8 = 0x2B8AAD4;                         
        // 0x00B21610: LDR w0, [x8]               | W0 = 0x173;                             
        // 0x00B21614: BL #0x2782188              | X0 = sub_2782188( ?? 0x173, ????);      
        // 0x00B21618: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2161C: STRB w8, [x22, #0x726]     | static_value_03733726 = true;            //  dest_result_addr=57882406
        label_0:
        // 0x00B21620: LDR x22, [x23, #0x10]      | X22 = this.entity; //P2                 
        // 0x00B21624: CBNZ x19, #0xb2162c        | if (condition != null) goto label_1;    
        if(condition != null)
        {
            goto label_1;
        }
        // 0x00B21628: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x173, ????);      
        label_1:
        // 0x00B2162C: LDRB w8, [x19, #0x1c]      | W8 = condition.type; //P2               
        int val_4 = condition.type;
        // 0x00B21630: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_4 = 0;
        // 0x00B21634: SUB w9, w8, #1             | W9 = (condition.type - 1);              
        int val_1 = val_4 - 1;
        // 0x00B21638: ADD w8, w8, #2             | W8 = (condition.type + 2);              
        val_4 = val_4 + 2;
        // 0x00B2163C: CMP w9, #0xf               | STATE = COMPARE((condition.type - 1), 0xF)
        // 0x00B21640: CSEL w8, w8, wzr, lo       | W8 = val_1 < 15 ? (condition.type + 2) : 0;
        var val_2 = (val_1 < 15) ? (val_4) : 0;
        // 0x00B21644: SUB w8, w8, #3             | W8 = (val_1 < 15 ? (condition.type + 2) : 0 - 3);
        val_2 = val_2 - 3;
        // 0x00B21648: CMP w8, #0xe               | STATE = COMPARE((val_1 < 15 ? (condition.type + 2) : 0 - 3), 0xE)
        // 0x00B2164C: B.HI #0xb21670             | if (val_2 > 0xE) goto label_2;          
        if(val_2 > 14)
        {
            goto label_2;
        }
        // 0x00B21650: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x00B21654: ADD x9, x9, #0x968         | X9 = (44638208 + 2408) = 44640616 (0x02A92968);
        // 0x00B21658: LDRSW x8, [x9, x8, lsl #2] | X8 = 44640616 + ((val_1 < 15 ? (condition.type + 2) : 0 - 3)) << 2;
        var val_5 = 44640616 + ((val_1 < 15 ? (condition.type + 2) : 0 - 3)) << 2;
        // 0x00B2165C: ADD x8, x8, x9             | X8 = (44640616 + ((val_1 < 15 ? (condition.type + 2) : 0 - 3)) << 2 + 44640616);
        val_5 = val_5 + 44640616;
        // 0x00B21660: BR x8                      | goto (44640616 + ((val_1 < 15 ? (condition.type + 2) : 0 - 3)) << 2 + 44640616);
        goto (44640616 + ((val_1 < 15 ? (condition.type + 2) : 0 - 3)) << 2 + 44640616);
        // 0x00B21664: LDR w8, [x19, #0x20]       | W8 = condition.param1; //P2             
        // 0x00B21668: CMP w8, w20                | STATE = COMPARE(condition.param1, tParam1)
        // 0x00B2166C: CSET w0, eq                | W0 = condition.param1 == tParam1 ? 1 : 0;
        var val_3 = (condition.param1 == tParam1) ? 1 : 0;
        label_2:
        // 0x00B21670: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B21674: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B21678: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2167C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B21680: RET                        |  return (System.Boolean)condition.param1 == tParam1 ? 1 : 0;
        return (bool)val_3;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B22E58 (11677272), len: 148  VirtAddr: 0x00B22E58 RVA: 0x00B22E58 token: 100691856 methodIndex: 24717 delegateWrapperIndex: 0 methodInvoker: 0
    private bool CheckRelation(int nRelation, int nParam1, int nParam2, int nParam3)
    {
        //
        // Disasemble & Code
        //  | 
        var val_13;
        // 0x00B22E58: SUB w8, w1, #1             | W8 = (nRelation - 1);                   
        int val_1 = nRelation - 1;
        // 0x00B22E5C: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_13 = 0;
        // 0x00B22E60: ADD w9, w1, #2             | W9 = (nRelation + 2);                   
        int val_2 = nRelation + 2;
        // 0x00B22E64: CMP w8, #7                 | STATE = COMPARE((nRelation - 1), 0x7)   
        // 0x00B22E68: CSEL w8, w9, wzr, lo       | W8 = val_1 < 7 ? (nRelation + 2) : 0;   
        var val_3 = (val_1 < 7) ? (val_2) : 0;
        // 0x00B22E6C: SUB w8, w8, #3             | W8 = (val_1 < 7 ? (nRelation + 2) : 0 - 3);
        val_3 = val_3 - 3;
        // 0x00B22E70: CMP w8, #6                 | STATE = COMPARE((val_1 < 7 ? (nRelation + 2) : 0 - 3), 0x6)
        // 0x00B22E74: B.HI #0xb22ee8             | if (val_3 > 0x6) goto label_0;          
        if(val_3 > 6)
        {
            goto label_0;
        }
        // 0x00B22E78: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x00B22E7C: ADD x9, x9, #0xac0         | X9 = (44638208 + 2752) = 44640960 (0x02A92AC0);
        // 0x00B22E80: LDRSW x8, [x9, x8, lsl #2] | X8 = 44640960 + ((val_1 < 7 ? (nRelation + 2) : 0 - 3)) << 2;
        var val_12 = 44640960 + ((val_1 < 7 ? (nRelation + 2) : 0 - 3)) << 2;
        // 0x00B22E84: ADD x8, x8, x9             | X8 = (44640960 + ((val_1 < 7 ? (nRelation + 2) : 0 - 3)) << 2 + 44640960);
        val_12 = val_12 + 44640960;
        // 0x00B22E88: BR x8                      | goto (44640960 + ((val_1 < 7 ? (nRelation + 2) : 0 - 3)) << 2 + 44640960);
        goto (44640960 + ((val_1 < 7 ? (nRelation + 2) : 0 - 3)) << 2 + 44640960);
        // 0x00B22E8C: CMP w2, w3                 | STATE = COMPARE(nParam1, nParam2)       
        // 0x00B22E90: CSET w0, lt                | W0 = nParam1 < nParam2 ? 1 : 0;         
        var val_4 = (nParam1 < nParam2) ? 1 : 0;
        // 0x00B22E94: RET                        |  return (System.Boolean)nParam1 < nParam2 ? 1 : 0;
        return (bool)val_4;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        // 0x00B22E98: CMP w2, w3                 | STATE = COMPARE(nParam1, nParam2)       
        // 0x00B22E9C: CSET w0, gt                | W0 = nParam1 > nParam2 ? 1 : 0;         
        var val_5 = (nParam1 > nParam2) ? 1 : 0;
        // 0x00B22EA0: RET                        |  return (System.Boolean)nParam1 > nParam2 ? 1 : 0;
        return (bool)val_5;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        // 0x00B22EA4: CMP w2, w3                 | STATE = COMPARE(nParam1, nParam2)       
        // 0x00B22EA8: CSET w0, eq                | W0 = nParam1 == nParam2 ? 1 : 0;        
        var val_6 = (nParam1 == nParam2) ? 1 : 0;
        // 0x00B22EAC: RET                        |  return (System.Boolean)nParam1 == nParam2 ? 1 : 0;
        return (bool)val_6;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        // 0x00B22EB0: CMP w2, w3                 | STATE = COMPARE(nParam1, nParam2)       
        // 0x00B22EB4: CSET w0, ge                | W0 = nParam1 >= nParam2 ? 1 : 0;        
        var val_7 = (nParam1 >= nParam2) ? 1 : 0;
        // 0x00B22EB8: RET                        |  return (System.Boolean)nParam1 >= nParam2 ? 1 : 0;
        return (bool)val_7;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        // 0x00B22EBC: CMP w2, w3                 | STATE = COMPARE(nParam1, nParam2)       
        // 0x00B22EC0: CSET w0, le                | W0 = nParam1 <= nParam2 ? 1 : 0;        
        var val_8 = (nParam1 <= nParam2) ? 1 : 0;
        // 0x00B22EC4: RET                        |  return (System.Boolean)nParam1 <= nParam2 ? 1 : 0;
        return (bool)val_8;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        // 0x00B22EC8: CMP w2, w3                 | STATE = COMPARE(nParam1, nParam2)       
        // 0x00B22ECC: CSET w0, ne                | W0 = nParam1 != nParam2 ? 1 : 0;        
        var val_9 = (nParam1 != nParam2) ? 1 : 0;
        // 0x00B22ED0: RET                        |  return (System.Boolean)nParam1 != nParam2 ? 1 : 0;
        return (bool)val_9;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        // 0x00B22ED4: CMP w2, w4                 | STATE = COMPARE(nParam1, nParam3)       
        // 0x00B22ED8: CSET w8, lt                | W8 = nParam1 < nParam3 ? 1 : 0;         
        var val_10 = (nParam1 < nParam3) ? 1 : 0;
        // 0x00B22EDC: CMP w2, w3                 | STATE = COMPARE(nParam1, nParam2)       
        // 0x00B22EE0: CSET w9, ge                | W9 = nParam1 >= nParam2 ? 1 : 0;        
        var val_11 = (nParam1 >= nParam2) ? 1 : 0;
        // 0x00B22EE4: AND w0, w9, w8             | W0 = (nParam1 >= nParam2 ? 1 : 0 & nParam1 < nParam3 ? 1 : 0);
        val_13 = val_11 & val_10;
        label_0:
        // 0x00B22EE8: RET                        |  return (System.Boolean)(nParam1 >= nParam2 ? 1 : 0 & nParam1 < nParam3 ? 1 : 0);
        return (bool)val_13;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }

}
