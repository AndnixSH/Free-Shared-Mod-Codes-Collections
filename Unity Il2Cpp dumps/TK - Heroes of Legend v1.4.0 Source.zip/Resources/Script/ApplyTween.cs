using UnityEngine;
private sealed class iTween.ApplyTween : MulticastDelegate
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D9D180 (14274944), len: 16  VirtAddr: 0x00D9D180 RVA: 0x00D9D180 token: 100684694 methodIndex: 46278 delegateWrapperIndex: 0 methodInvoker: 0
    public iTween.ApplyTween(object object, IntPtr method)
    {
        //
        // Disasemble & Code
        // 0x00D9D180: LDR x8, [x2]               | X8 = method;                            
        // 0x00D9D184: STP x1, x2, [x0, #0x20]    | mem[1152921513707538080] = object;  mem[1152921513707538088] = method;  //  dest_result_addr=1152921513707538080 |  dest_result_addr=1152921513707538088
        mem[1152921513707538080] = object;
        mem[1152921513707538088] = method;
        // 0x00D9D188: STR x8, [x0, #0x10]        | mem[1152921513707538064] = method;       //  dest_result_addr=1152921513707538064
        mem[1152921513707538064] = method;
        // 0x00D9D18C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D9D190 (14274960), len: 504  VirtAddr: 0x00D9D190 RVA: 0x00D9D190 token: 100684695 methodIndex: 46279 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void Invoke()
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        label_1:
        // 0x00D9D190: STP x22, x21, [sp, #-0x30]! | stack[1152921513707650288] = ???;  stack[1152921513707650296] = ???;  //  dest_result_addr=1152921513707650288 |  dest_result_addr=1152921513707650296
        // 0x00D9D194: STP x20, x19, [sp, #0x10]  | stack[1152921513707650304] = ???;  stack[1152921513707650312] = ???;  //  dest_result_addr=1152921513707650304 |  dest_result_addr=1152921513707650312
        // 0x00D9D198: STP x29, x30, [sp, #0x20]  | stack[1152921513707650320] = ???;  stack[1152921513707650328] = ???;  //  dest_result_addr=1152921513707650320 |  dest_result_addr=1152921513707650328
        // 0x00D9D19C: ADD x29, sp, #0x20         | X29 = (1152921513707650288 + 32) = 1152921513707650320 (0x100000021E733D10);
        // 0x00D9D1A0: SUB sp, sp, #0x10          | SP = (1152921513707650288 - 16) = 1152921513707650272 (0x100000021E733CE0);
        // 0x00D9D1A4: MOV x21, x0                | X21 = 1152921513707662336 (0x100000021E736C00);//ML01
        // 0x00D9D1A8: LDR x0, [x21, #0x58]       | 
        // 0x00D9D1AC: CBZ x0, #0xd9d1b4          | if (this == null) goto label_0;         
        if(this == null)
        {
            goto label_0;
        }
        // 0x00D9D1B0: BL #0xd9d190               |  R0 = label_1();                        
        label_0:
        // 0x00D9D1B4: LDR x0, [x21, #0x10]       | 
        // 0x00D9D1B8: STR x0, [sp, #8]           | stack[1152921513707650280] = this;       //  dest_result_addr=1152921513707650280
        // 0x00D9D1BC: LDP x19, x20, [x21, #0x20] |                                          //  | 
        // 0x00D9D1C0: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00D9D1C4: BL #0x2796f94              | X0 = sub_2796F94( ?? X20, ????);        
        // 0x00D9D1C8: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00D9D1CC: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X20, ????);        
        // 0x00D9D1D0: AND w8, w0, #1             | W8 = (X20 & 1);                         
        var val_1 = X20 & 1;
        // 0x00D9D1D4: TBZ w8, #0, #0xd9d264      | if (((X20 & 1) & 0x1) == 0) goto label_2;
        if((val_1 & 1) == 0)
        {
            goto label_2;
        }
        // 0x00D9D1D8: LDRSH w8, [x20, #0x4c]     | W8 = X20 + 76;                          
        // 0x00D9D1DC: CMN w8, #1                 | STATE = COMPARE(X20 + 76, 0x1)          
        // 0x00D9D1E0: B.EQ #0xd9d290             | if (X20 + 76 == 0x1) goto label_6;      
        if((X20 + 76) == 1)
        {
            goto label_6;
        }
        // 0x00D9D1E4: CBZ x19, #0xd9d1f4         | if (X19 == 0) goto label_4;             
        if(X19 == 0)
        {
            goto label_4;
        }
        // 0x00D9D1E8: LDR x8, [x19]              | X8 = X19;                               
        // 0x00D9D1EC: LDRB w8, [x8, #0xed]       | W8 = X19 + 237;                         
        // 0x00D9D1F0: TBNZ w8, #0, #0xd9d290     | if ((X19 + 237 & 0x1) != 0) goto label_6;
        if(((X19 + 237) & 1) != 0)
        {
            goto label_6;
        }
        label_4:
        // 0x00D9D1F4: LDR x8, [x21, #0x18]       | 
        // 0x00D9D1F8: CBZ x8, #0xd9d290          | if (X19 + 237 == 0) goto label_6;       
        if((X19 + 237) == 0)
        {
            goto label_6;
        }
        // 0x00D9D1FC: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00D9D200: BL #0x27c0990              | X0 = sub_27C0990( ?? X20, ????);        
        // 0x00D9D204: MOV w21, w0                | W21 = X20;//m1                          
        // 0x00D9D208: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00D9D20C: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
        UnityEngine.Sprite val_2 = X20.pressedSprite;
        // 0x00D9D210: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
        // 0x00D9D214: TBZ w21, #0, #0xd9d2b8     | if ((X20 & 0x1) == 0) goto label_7;     
        if((X20 & 1) == 0)
        {
            goto label_7;
        }
        // 0x00D9D218: TBZ w0, #0, #0xd9d314      | if ((val_2 & 0x1) == 0) goto label_8;   
        if((val_2 & 1) == 0)
        {
            goto label_8;
        }
        // 0x00D9D21C: LDR x8, [x19]              | X8 = X19;                               
        var val_11 = X19;
        // 0x00D9D220: LDR x1, [x20, #0x18]       | X1 = X20 + 24;                          
        // 0x00D9D224: LDRH w2, [x20, #0x4c]      | W2 = X20 + 76;                          
        // 0x00D9D228: LDRH w9, [x8, #0x102]      | W9 = X19 + 258;                         
        // 0x00D9D22C: CBZ x9, #0xd9d258          | if (X19 + 258 == 0) goto label_9;       
        if((X19 + 258) == 0)
        {
            goto label_9;
        }
        // 0x00D9D230: LDR x10, [x8, #0x98]       | X10 = X19 + 152;                        
        var val_5 = X19 + 152;
        // 0x00D9D234: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_6 = 0;
        // 0x00D9D238: ADD x10, x10, #8           | X10 = (X19 + 152 + 8);                  
        val_5 = val_5 + 8;
        label_11:
        // 0x00D9D23C: LDUR x12, [x10, #-8]       | X12 = (X19 + 152 + 8) + -8;             
        // 0x00D9D240: CMP x12, x1                | STATE = COMPARE((X19 + 152 + 8) + -8, X20 + 24)
        // 0x00D9D244: B.EQ #0xd9d33c             | if ((X19 + 152 + 8) + -8 == X20 + 24) goto label_10;
        if(((X19 + 152 + 8) + -8) == (X20 + 24))
        {
            goto label_10;
        }
        // 0x00D9D248: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_6 = val_6 + 1;
        // 0x00D9D24C: ADD x10, x10, #0x10        | X10 = ((X19 + 152 + 8) + 16);           
        val_5 = val_5 + 16;
        // 0x00D9D250: CMP x11, x9                | STATE = COMPARE((0 + 1), X19 + 258)     
        // 0x00D9D254: B.LO #0xd9d23c             | if (0 < X19 + 258) goto label_11;       
        if(val_6 < (X19 + 258))
        {
            goto label_11;
        }
        label_9:
        // 0x00D9D258: MOV x0, x19                | X0 = X19;//m1                           
        val_7 = X19;
        // 0x00D9D25C: BL #0x2776c24              | X0 = sub_2776C24( ?? X19, ????);        
        // 0x00D9D260: B #0xd9d34c                |  goto label_12;                         
        goto label_12;
        label_2:
        // 0x00D9D264: LDRB w8, [x20, #0x4e]      | W8 = X20 + 78;                          
        // 0x00D9D268: CBZ w8, #0xd9d298          | if (X20 + 78 == 0) goto label_13;       
        if((X20 + 78) == 0)
        {
            goto label_13;
        }
        // 0x00D9D26C: LDR x3, [sp, #8]           | X3 = this;                              
        // 0x00D9D270: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D274: MOV x1, x19                | X1 = X19;//m1                           
        // 0x00D9D278: MOV x2, x20                | X2 = X20;//m1                           
        // 0x00D9D27C: SUB sp, x29, #0x20         | SP = (1152921513707650320 - 32) = 1152921513707650288 (0x100000021E733CF0);
        // 0x00D9D280: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D9D284: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D9D288: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D9D28C: BR x3                      | X0 = this( ?? 0x0, ????);               
        label_6:
        // 0x00D9D290: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00D9D294: B #0xd9d29c                |  goto label_14;                         
        goto label_14;
        label_13:
        // 0x00D9D298: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        label_14:
        // 0x00D9D29C: LDR x2, [sp, #8]           | X2 = this;                              
        // 0x00D9D2A0: MOV x1, x20                | X1 = X20;//m1                           
        label_23:
        // 0x00D9D2A4: SUB sp, x29, #0x20         | SP = (1152921513707650320 - 32) = 1152921513707650288 (0x100000021E733CF0);
        // 0x00D9D2A8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D9D2AC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D9D2B0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D9D2B4: BR x2                      | X0 = this( ?? 0x0, ????);               
        label_7:
        // 0x00D9D2B8: LDRH w21, [x20, #0x4c]     | W21 = X20 + 76;                         
        // 0x00D9D2BC: TBZ w0, #0, #0xd9d328      | if ((val_2 & 0x1) == 0) goto label_15;  
        if((val_2 & 1) == 0)
        {
            goto label_15;
        }
        // 0x00D9D2C0: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00D9D2C4: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
        UnityEngine.Sprite val_3 = X20.pressedSprite;
        // 0x00D9D2C8: LDR x9, [x19]              | X9 = X19;                               
        // 0x00D9D2CC: MOV x8, x0                 | X8 = val_3;//m1                         
        // 0x00D9D2D0: LDRH w10, [x9, #0x102]     | W10 = X19 + 258;                        
        // 0x00D9D2D4: CBZ x10, #0xd9d300         | if (X19 + 258 == 0) goto label_16;      
        if((X19 + 258) == 0)
        {
            goto label_16;
        }
        // 0x00D9D2D8: LDR x11, [x9, #0x98]       | X11 = X19 + 152;                        
        var val_7 = X19 + 152;
        // 0x00D9D2DC: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
        var val_8 = 0;
        // 0x00D9D2E0: ADD x11, x11, #8           | X11 = (X19 + 152 + 8);                  
        val_7 = val_7 + 8;
        label_18:
        // 0x00D9D2E4: LDUR x13, [x11, #-8]       | X13 = (X19 + 152 + 8) + -8;             
        // 0x00D9D2E8: CMP x13, x8                | STATE = COMPARE((X19 + 152 + 8) + -8, val_3)
        // 0x00D9D2EC: B.EQ #0xd9d36c             | if ((X19 + 152 + 8) + -8 == val_3) goto label_17;
        if(((X19 + 152 + 8) + -8) == val_3)
        {
            goto label_17;
        }
        // 0x00D9D2F0: ADD x12, x12, #1           | X12 = (0 + 1);                          
        val_8 = val_8 + 1;
        // 0x00D9D2F4: ADD x11, x11, #0x10        | X11 = ((X19 + 152 + 8) + 16);           
        val_7 = val_7 + 16;
        // 0x00D9D2F8: CMP x12, x10               | STATE = COMPARE((0 + 1), X19 + 258)     
        // 0x00D9D2FC: B.LO #0xd9d2e4             | if (0 < X19 + 258) goto label_18;       
        if(val_8 < (X19 + 258))
        {
            goto label_18;
        }
        label_16:
        // 0x00D9D300: MOV x0, x19                | X0 = X19;//m1                           
        val_8 = X19;
        // 0x00D9D304: MOV x1, x8                 | X1 = val_3;//m1                         
        // 0x00D9D308: MOV w2, w21                | W2 = X20 + 76;//m1                      
        // 0x00D9D30C: BL #0x2776c24              | X0 = sub_2776C24( ?? X19, ????);        
        // 0x00D9D310: B #0xd9d37c                |  goto label_19;                         
        goto label_19;
        label_8:
        // 0x00D9D314: LDRH w8, [x20, #0x4c]      | W8 = X20 + 76;                          
        // 0x00D9D318: LDR x9, [x19]              | X9 = X19;                               
        // 0x00D9D31C: ADD x8, x9, x8, lsl #4     | X8 = (X19 + (X20 + 76) << 4);           
        var val_4 = X19 + ((X20 + 76) << 4);
        // 0x00D9D320: LDR x0, [x8, #0x118]       | X0 = (X19 + (X20 + 76) << 4) + 280;     
        val_9 = mem[(X19 + (X20 + 76) << 4) + 280];
        val_9 = (X19 + (X20 + 76) << 4) + 280;
        // 0x00D9D324: B #0xd9d350                |  goto label_20;                         
        goto label_20;
        label_15:
        // 0x00D9D328: LDR x8, [x19]              | X8 = X19;                               
        var val_9 = X19;
        // 0x00D9D32C: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00D9D330: ADD x8, x8, w21, uxtw #4   | X8 = (X19 + X20 + 76);                  
        val_9 = val_9 + (X20 + 76);
        // 0x00D9D334: LDP x2, x1, [x8, #0x110]   | X2 = (X19 + X20 + 76) + 272; X1 = (X19 + X20 + 76) + 272 + 8; //  | 
        // 0x00D9D338: B #0xd9d2a4                |  goto label_23;                         
        goto label_23;
        label_10:
        // 0x00D9D33C: LDR w9, [x10]              | W9 = (X19 + 152 + 8);                   
        var val_10 = val_5;
        // 0x00D9D340: ADD w9, w9, w2             | W9 = ((X19 + 152 + 8) + X20 + 76);      
        val_10 = val_10 + (X20 + 76);
        // 0x00D9D344: ADD x8, x8, w9, uxtw #4    | X8 = (X19 + ((X19 + 152 + 8) + X20 + 76));
        val_11 = val_11 + val_10;
        // 0x00D9D348: ADD x0, x8, #0x110         | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272);
        val_7 = val_11 + 272;
        label_12:
        // 0x00D9D34C: LDR x0, [x0, #8]           | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
        val_9 = mem[((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8];
        val_9 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
        label_20:
        // 0x00D9D350: MOV x1, x20                | X1 = X20;//m1                           
        // 0x00D9D354: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8, ????);
        // 0x00D9D358: MOV x8, x0                 | X8 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
        // 0x00D9D35C: LDR x2, [x8]               | X2 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
        // 0x00D9D360: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00D9D364: MOV x1, x8                 | X1 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
        // 0x00D9D368: B #0xd9d2a4                |  goto label_23;                         
        goto label_23;
        label_17:
        // 0x00D9D36C: LDR w8, [x11]              | W8 = (X19 + 152 + 8);                   
        var val_12 = val_7;
        // 0x00D9D370: ADD w8, w8, w21            | W8 = ((X19 + 152 + 8) + X20 + 76);      
        val_12 = val_12 + (X20 + 76);
        // 0x00D9D374: ADD x8, x9, w8, uxtw #4    | X8 = (X19 + ((X19 + 152 + 8) + X20 + 76));
        val_12 = X19 + val_12;
        // 0x00D9D378: ADD x0, x8, #0x110         | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272);
        val_8 = val_12 + 272;
        label_19:
        // 0x00D9D37C: LDP x2, x1, [x0]           | X2 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272); X1 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8; //  | 
        // 0x00D9D380: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00D9D384: B #0xd9d2a4                |  goto label_23;                         
        goto label_23;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D9D388 (14275464), len: 52  VirtAddr: 0x00D9D388 RVA: 0x00D9D388 token: 100684696 methodIndex: 46280 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual System.IAsyncResult BeginInvoke(System.AsyncCallback callback, object object)
    {
        //
        // Disasemble & Code
        // 0x00D9D388: STP x29, x30, [sp, #-0x10]! | stack[1152921513707778704] = ???;  stack[1152921513707778712] = ???;  //  dest_result_addr=1152921513707778704 |  dest_result_addr=1152921513707778712
        // 0x00D9D38C: MOV x29, sp                | X29 = 1152921513707778704 (0x100000021E753290);//ML01
        // 0x00D9D390: SUB sp, sp, #0x10          | SP = (1152921513707778704 - 16) = 1152921513707778688 (0x100000021E753280);
        // 0x00D9D394: MOV x8, x2                 | X8 = object;//m1                        
        // 0x00D9D398: MOV x9, x1                 | X9 = callback;//m1                      
        // 0x00D9D39C: ADD x1, sp, #8             | X1 = (1152921513707778688 + 8) = 1152921513707778696 (0x100000021E753288);
        // 0x00D9D3A0: MOV x2, x9                 | X2 = callback;//m1                      
        // 0x00D9D3A4: MOV x3, x8                 | X3 = object;//m1                        
        // 0x00D9D3A8: STR xzr, [sp, #8]          | stack[1152921513707778696] = 0x0;        //  dest_result_addr=1152921513707778696
        // 0x00D9D3AC: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
        // 0x00D9D3B0: MOV sp, x29                | SP = 1152921513707778704 (0x100000021E753290);//ML01
        // 0x00D9D3B4: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00D9D3B8: RET                        |  return (System.IAsyncResult)this;      
        return (System.IAsyncResult)this;
        //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D9D3BC (14275516), len: 16  VirtAddr: 0x00D9D3BC RVA: 0x00D9D3BC token: 100684697 methodIndex: 46281 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void EndInvoke(System.IAsyncResult result)
    {
        //
        // Disasemble & Code
        // 0x00D9D3BC: MOV x8, x1                 | X8 = result;//m1                        
        // 0x00D9D3C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D3C4: MOV x0, x8                 | X0 = result;//m1                        
        // 0x00D9D3C8: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
    
    }

}
