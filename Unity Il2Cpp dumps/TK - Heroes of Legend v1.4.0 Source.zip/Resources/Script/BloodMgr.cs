using UnityEngine;
public class BloodMgr : Singleton<BloodMgr>
{
    // Fields
    public static System.Collections.Generic.Dictionary<string, System.WeakReference> debugList; // static_offset: 0x00000000
    private System.Collections.Generic.List<Blood> bloodList; //  0x00000010
    private UnityEngine.GameObject _parentGO; //  0x00000018
    
    // Properties
    private UnityEngine.GameObject parentGO { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B913D8 (12129240), len: 280  VirtAddr: 0x00B913D8 RVA: 0x00B913D8 token: 100692734 methodIndex: 25159 delegateWrapperIndex: 0 methodInvoker: 0
    public BloodMgr()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00B913D8: STP x22, x21, [sp, #-0x30]! | stack[1152921514876377360] = ???;  stack[1152921514876377368] = ???;  //  dest_result_addr=1152921514876377360 |  dest_result_addr=1152921514876377368
        // 0x00B913DC: STP x20, x19, [sp, #0x10]  | stack[1152921514876377376] = ???;  stack[1152921514876377384] = ???;  //  dest_result_addr=1152921514876377376 |  dest_result_addr=1152921514876377384
        // 0x00B913E0: STP x29, x30, [sp, #0x20]  | stack[1152921514876377392] = ???;  stack[1152921514876377400] = ???;  //  dest_result_addr=1152921514876377392 |  dest_result_addr=1152921514876377400
        // 0x00B913E4: ADD x29, sp, #0x20         | X29 = (1152921514876377360 + 32) = 1152921514876377392 (0x10000002641C9930);
        // 0x00B913E8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B913EC: LDRB w8, [x20, #0xa3f]     | W8 = (bool)static_value_03733A3F;       
        // 0x00B913F0: MOV x19, x0                | X19 = 1152921514876389408 (0x10000002641CC820);//ML01
        // 0x00B913F4: TBNZ w8, #0, #0xb91410     | if (static_value_03733A3F == true) goto label_0;
        // 0x00B913F8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
        // 0x00B913FC: LDR x8, [x8, #0xd20]       | X8 = 0x2B8F680;                         
        // 0x00B91400: LDR w0, [x8]               | W0 = 0x1464;                            
        // 0x00B91404: BL #0x2782188              | X0 = sub_2782188( ?? 0x1464, ????);     
        // 0x00B91408: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B9140C: STRB w8, [x20, #0xa3f]     | static_value_03733A3F = true;            //  dest_result_addr=57883199
        label_0:
        // 0x00B91410: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00B91414: LDR x8, [x8, #0x6c8]       | X8 = 1152921514876362336;               
        // 0x00B91418: MOV x0, x19                | X0 = 1152921514876389408 (0x10000002641CC820);//ML01
        // 0x00B9141C: LDR x1, [x8]               | X1 = public System.Void Singleton<BloodMgr>::.ctor();
        // 0x00B91420: BL #0x1a0440c              | this..ctor();                           
        // 0x00B91424: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B91428: LDR x8, [x8, #0x80]        | X8 = 1152921504616644608;               
        // 0x00B9142C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<Blood> val_1 = null;
        // 0x00B91430: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B91434: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B91438: LDR x8, [x8, #0x410]       | X8 = 1152921514876363360;               
        // 0x00B9143C: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B91440: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Blood>::.ctor();
        // 0x00B91444: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<Blood>();
        // 0x00B91448: STR x20, [x19, #0x10]      | this.bloodList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514876389424
        this.bloodList = val_1;
        // 0x00B9144C: ADRP x20, #0x35f6000       | X20 = 56582144 (0x35F6000);             
        // 0x00B91450: LDR x20, [x20, #0x7e8]     | X20 = 1152921504909295616;              
        // 0x00B91454: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_3 = null;
        // 0x00B91458: LDRB w8, [x0, #0x10a]      | W8 = SceneMgr.__il2cppRuntimeField_10A; 
        // 0x00B9145C: TBZ w8, #0, #0xb91470      | if (SceneMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B91460: LDR w8, [x0, #0xbc]        | W8 = SceneMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B91464: CBNZ w8, #0xb91470         | if (SceneMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B91468: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SceneMgr), ????);
        // 0x00B9146C: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_3 = null;
        label_2:
        // 0x00B91470: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
        // 0x00B91474: ADRP x10, #0x3658000       | X10 = 56983552 (0x3658000);             
        // 0x00B91478: LDR x8, [x0, #0xa0]        | X8 = SceneMgr.__il2cppRuntimeField_static_fields;
        // 0x00B9147C: LDR x9, [x9, #0x378]       | X9 = 1152921514876364384;               
        // 0x00B91480: LDR x10, [x10, #0x980]     | X10 = 1152921504898113536;              
        // 0x00B91484: LDR x20, [x8, #0x10]       | X20 = SceneMgr.SCENE_START_LOAD;        
        // 0x00B91488: LDR x22, [x9]              | X22 = System.Void BloodMgr::OnStartLoadScene(CEvent.ZEvent ev);
        // 0x00B9148C: LDR x0, [x10]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_2 = null;
        // 0x00B91490: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B91494: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00B91498: LDR x8, [x8, #0xc38]       | X8 = 1152921512949758048;               
        // 0x00B9149C: MOV x1, x19                | X1 = 1152921514876389408 (0x10000002641CC820);//ML01
        // 0x00B914A0: MOV x2, x22                | X2 = 1152921514876364384 (0x10000002641C6660);//ML01
        // 0x00B914A4: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B914A8: LDR x3, [x8]               | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B914AC: BL #0x19cc774              | .ctor(object:  this, method:  System.Void BloodMgr::OnStartLoadScene(CEvent.ZEvent ev));
        val_2 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void BloodMgr::OnStartLoadScene(CEvent.ZEvent ev));
        // 0x00B914B0: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B914B4: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B914B8: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B914BC: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B914C0: TBZ w8, #0, #0xb914d0      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B914C4: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B914C8: CBNZ w8, #0xb914d0         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B914CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_4:
        // 0x00B914D0: MOV x1, x20                | X1 = SceneMgr.SCENE_START_LOAD;//m1     
        // 0x00B914D4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B914D8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B914DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B914E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B914E4: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B914E8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B914EC: B #0xd775dc                | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  SceneMgr.SCENE_START_LOAD); return;
        CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  SceneMgr.SCENE_START_LOAD);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B914F0 (12129520), len: 236  VirtAddr: 0x00B914F0 RVA: 0x00B914F0 token: 100692735 methodIndex: 25160 delegateWrapperIndex: 0 methodInvoker: 0
    private UnityEngine.GameObject get_parentGO()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        UnityEngine.GameObject val_5;
        // 0x00B914F0: STP x20, x19, [sp, #-0x20]! | stack[1152921514876502800] = ???;  stack[1152921514876502808] = ???;  //  dest_result_addr=1152921514876502800 |  dest_result_addr=1152921514876502808
        // 0x00B914F4: STP x29, x30, [sp, #0x10]  | stack[1152921514876502816] = ???;  stack[1152921514876502824] = ???;  //  dest_result_addr=1152921514876502816 |  dest_result_addr=1152921514876502824
        // 0x00B914F8: ADD x29, sp, #0x10         | X29 = (1152921514876502800 + 16) = 1152921514876502816 (0x10000002641E8320);
        // 0x00B914FC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B91500: LDRB w8, [x20, #0xa40]     | W8 = (bool)static_value_03733A40;       
        // 0x00B91504: MOV x19, x0                | X19 = 1152921514876514832 (0x10000002641EB210);//ML01
        // 0x00B91508: TBNZ w8, #0, #0xb91524     | if (static_value_03733A40 == true) goto label_0;
        // 0x00B9150C: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
        // 0x00B91510: LDR x8, [x8, #0x6f8]       | X8 = 0x2B8F688;                         
        // 0x00B91514: LDR w0, [x8]               | W0 = 0x1466;                            
        // 0x00B91518: BL #0x2782188              | X0 = sub_2782188( ?? 0x1466, ????);     
        // 0x00B9151C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B91520: STRB w8, [x20, #0xa40]     | static_value_03733A40 = true;            //  dest_result_addr=57883200
        label_0:
        // 0x00B91524: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B91528: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B9152C: LDR x20, [x19, #0x18]      | X20 = this._parentGO; //P2              
        // 0x00B91530: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B91534: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B91538: TBZ w8, #0, #0xb91548      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B9153C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B91540: CBNZ w8, #0xb91548         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B91544: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B91548: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9154C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91550: MOV x1, x20                | X1 = this._parentGO;//m1                
        // 0x00B91554: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B91558: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this._parentGO);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this._parentGO);
        // 0x00B9155C: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B91560: TBZ w8, #0, #0xb915cc      | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00B91564: ADRP x20, #0x35cb000       | X20 = 56406016 (0x35CB000);             
        // 0x00B91568: LDR x20, [x20, #0xd98]     | X20 = 1152921504901361664;              
        // 0x00B9156C: LDR x0, [x20]              | X0 = typeof(BloodMgr);                  
        val_4 = null;
        // 0x00B91570: LDRB w8, [x0, #0x10a]      | W8 = BloodMgr.__il2cppRuntimeField_10A; 
        // 0x00B91574: TBZ w8, #0, #0xb91588      | if (BloodMgr.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B91578: LDR w8, [x0, #0xbc]        | W8 = BloodMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B9157C: CBNZ w8, #0xb91588         | if (BloodMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B91580: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BloodMgr), ????);
        // 0x00B91584: LDR x0, [x20]              | X0 = typeof(BloodMgr);                  
        val_4 = null;
        label_5:
        // 0x00B91588: LDR x8, [x0, #0xa0]        | X8 = BloodMgr.__il2cppRuntimeField_static_fields;
        // 0x00B9158C: LDR x20, [x8]              | X20 = BloodMgr.debugList;               
        // 0x00B91590: CBNZ x20, #0xb91598        | if (BloodMgr.debugList != null) goto label_6;
        if(BloodMgr.debugList != null)
        {
            goto label_6;
        }
        // 0x00B91594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BloodMgr), ????);
        label_6:
        // 0x00B91598: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
        // 0x00B9159C: LDR x8, [x8, #0x7c0]       | X8 = 1152921514876481504;               
        // 0x00B915A0: MOV x0, x20                | X0 = BloodMgr.debugList;//m1            
        // 0x00B915A4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.WeakReference>::Clear();
        // 0x00B915A8: BL #0x23fd92c              | BloodMgr.debugList.Clear();             
        BloodMgr.debugList.Clear();
        // 0x00B915AC: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
        // 0x00B915B0: LDR x8, [x8, #0xca0]       | X8 = (string**)(1152921514876482528)("UI Root/UIBY3D/Blood");
        // 0x00B915B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B915B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B915BC: LDR x1, [x8]               | X1 = "UI Root/UIBY3D/Blood";            
        // 0x00B915C0: BL #0x1a634b4              | X0 = UnityEngine.GameObject.Find(name:  0);
        UnityEngine.GameObject val_3 = UnityEngine.GameObject.Find(name:  0);
        // 0x00B915C4: STR x0, [x19, #0x18]       | this._parentGO = val_3;                  //  dest_result_addr=1152921514876514856
        this._parentGO = val_3;
        // 0x00B915C8: B #0xb915d0                |  goto label_7;                          
        goto label_7;
        label_3:
        // 0x00B915CC: LDR x0, [x19, #0x18]       | X0 = this._parentGO; //P2               
        val_5 = this._parentGO;
        label_7:
        // 0x00B915D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B915D4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B915D8: RET                        |  return (UnityEngine.GameObject)this._parentGO;
        return val_5;
        //  |  // // {name=val_0, type=UnityEngine.GameObject, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B915DC (12129756), len: 220  VirtAddr: 0x00B915DC RVA: 0x00B915DC token: 100692736 methodIndex: 25161 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnStartLoadScene(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00B915DC: STP x24, x23, [sp, #-0x40]! | stack[1152921514876646512] = ???;  stack[1152921514876646520] = ???;  //  dest_result_addr=1152921514876646512 |  dest_result_addr=1152921514876646520
        // 0x00B915E0: STP x22, x21, [sp, #0x10]  | stack[1152921514876646528] = ???;  stack[1152921514876646536] = ???;  //  dest_result_addr=1152921514876646528 |  dest_result_addr=1152921514876646536
        // 0x00B915E4: STP x20, x19, [sp, #0x20]  | stack[1152921514876646544] = ???;  stack[1152921514876646552] = ???;  //  dest_result_addr=1152921514876646544 |  dest_result_addr=1152921514876646552
        // 0x00B915E8: STP x29, x30, [sp, #0x30]  | stack[1152921514876646560] = ???;  stack[1152921514876646568] = ???;  //  dest_result_addr=1152921514876646560 |  dest_result_addr=1152921514876646568
        // 0x00B915EC: ADD x29, sp, #0x30         | X29 = (1152921514876646512 + 48) = 1152921514876646560 (0x100000026420B4A0);
        // 0x00B915F0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B915F4: LDRB w8, [x20, #0xa41]     | W8 = (bool)static_value_03733A41;       
        // 0x00B915F8: MOV x19, x0                | X19 = 1152921514876658576 (0x100000026420E390);//ML01
        // 0x00B915FC: TBNZ w8, #0, #0xb91618     | if (static_value_03733A41 == true) goto label_0;
        // 0x00B91600: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00B91604: LDR x8, [x8, #0x268]       | X8 = 0x2B8F68C;                         
        // 0x00B91608: LDR w0, [x8]               | W0 = 0x1467;                            
        // 0x00B9160C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1467, ????);     
        // 0x00B91610: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B91614: STRB w8, [x20, #0xa41]     | static_value_03733A41 = true;            //  dest_result_addr=57883201
        label_0:
        // 0x00B91618: ADRP x23, #0x367a000       | X23 = 57122816 (0x367A000);             
        // 0x00B9161C: ADRP x24, #0x3601000       | X24 = 56627200 (0x3601000);             
        // 0x00B91620: LDR x23, [x23, #0x840]     | X23 = 1152921514876619216;              
        // 0x00B91624: LDR x24, [x24, #0x930]     | X24 = 1152921514876620240;              
        // 0x00B91628: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_3 = 0;
        // 0x00B9162C: B #0xb9163c                |  goto label_1;                          
        goto label_1;
        label_6:
        // 0x00B91630: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B91634: BL #0xb9126c               | X21.Clear();                            
        X21.Clear();
        // 0x00B91638: ADD w20, w20, #1           | W20 = (val_3 + 1) = val_3 (0x00000001); 
        val_3 = 1;
        label_1:
        // 0x00B9163C: LDR x21, [x19, #0x10]      | X21 = this.bloodList; //P2              
        // 0x00B91640: CBNZ x21, #0xb91648        | if (this.bloodList != null) goto label_2;
        if(this.bloodList != null)
        {
            goto label_2;
        }
        // 0x00B91644: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X21, ????);        
        label_2:
        // 0x00B91648: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<Blood>::get_Count();
        // 0x00B9164C: MOV x0, x21                | X0 = this.bloodList;//m1                
        // 0x00B91650: BL #0x25ed72c              | X0 = this.bloodList.get_Count();        
        int val_1 = this.bloodList.Count;
        // 0x00B91654: LDR x21, [x19, #0x10]      | X21 = this.bloodList; //P2              
        // 0x00B91658: MOV w22, w0                | W22 = val_1;//m1                        
        // 0x00B9165C: CBNZ x21, #0xb91664        | if (this.bloodList != null) goto label_3;
        if(this.bloodList != null)
        {
            goto label_3;
        }
        // 0x00B91660: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B91664: CMP w20, w22               | STATE = COMPARE(0x1, val_1)             
        // 0x00B91668: B.GE #0xb9168c             | if (val_3 >= val_1) goto label_4;       
        if(val_3 >= val_1)
        {
            goto label_4;
        }
        // 0x00B9166C: LDR x2, [x24]              | X2 = public Blood System.Collections.Generic.List<Blood>::get_Item(int index);
        // 0x00B91670: MOV x0, x21                | X0 = this.bloodList;//m1                
        // 0x00B91674: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B91678: BL #0x25ed734              | X0 = this.bloodList.get_Item(index:  1);
        Blood val_2 = this.bloodList.Item[1];
        // 0x00B9167C: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00B91680: CBNZ x21, #0xb91630        | if (val_2 != null) goto label_6;        
        if(val_2 != null)
        {
            goto label_6;
        }
        // 0x00B91684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B91688: B #0xb91630                |  goto label_6;                          
        goto label_6;
        label_4:
        // 0x00B9168C: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
        // 0x00B91690: LDR x8, [x8, #0xd60]       | X8 = 1152921514876633552;               
        // 0x00B91694: MOV x0, x21                | X0 = this.bloodList;//m1                
        // 0x00B91698: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Blood>::Clear();
        // 0x00B9169C: BL #0x25ead28              | this.bloodList.Clear();                 
        this.bloodList.Clear();
        // 0x00B916A0: STR xzr, [x19, #0x18]      | this._parentGO = null;                   //  dest_result_addr=1152921514876658600
        this._parentGO = 0;
        // 0x00B916A4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B916A8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B916AC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B916B0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B916B4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B916B8 (12129976), len: 1104  VirtAddr: 0x00B916B8 RVA: 0x00B916B8 token: 100692737 methodIndex: 25162 delegateWrapperIndex: 0 methodInvoker: 0
    public Blood AddBlood(CombatEntity unit)
    {
        //
        // Disasemble & Code
        //  | 
        CombatEntity val_22;
        //  | 
        var val_23;
        //  | 
        var val_24;
        //  | 
        var val_25;
        //  | 
        object val_26;
        // 0x00B916B8: STP x26, x25, [sp, #-0x50]! | stack[1152921514876860560] = ???;  stack[1152921514876860568] = ???;  //  dest_result_addr=1152921514876860560 |  dest_result_addr=1152921514876860568
        // 0x00B916BC: STP x24, x23, [sp, #0x10]  | stack[1152921514876860576] = ???;  stack[1152921514876860584] = ???;  //  dest_result_addr=1152921514876860576 |  dest_result_addr=1152921514876860584
        // 0x00B916C0: STP x22, x21, [sp, #0x20]  | stack[1152921514876860592] = ???;  stack[1152921514876860600] = ???;  //  dest_result_addr=1152921514876860592 |  dest_result_addr=1152921514876860600
        // 0x00B916C4: STP x20, x19, [sp, #0x30]  | stack[1152921514876860608] = ???;  stack[1152921514876860616] = ???;  //  dest_result_addr=1152921514876860608 |  dest_result_addr=1152921514876860616
        // 0x00B916C8: STP x29, x30, [sp, #0x40]  | stack[1152921514876860624] = ???;  stack[1152921514876860632] = ???;  //  dest_result_addr=1152921514876860624 |  dest_result_addr=1152921514876860632
        // 0x00B916CC: ADD x29, sp, #0x40         | X29 = (1152921514876860560 + 64) = 1152921514876860624 (0x100000026423F8D0);
        // 0x00B916D0: SUB sp, sp, #0x10          | SP = (1152921514876860560 - 16) = 1152921514876860544 (0x100000026423F880);
        // 0x00B916D4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B916D8: LDRB w8, [x20, #0xa42]     | W8 = (bool)static_value_03733A42;       
        // 0x00B916DC: MOV x19, x1                | X19 = unit;//m1                         
        val_22 = unit;
        // 0x00B916E0: MOV x22, x0                | X22 = 1152921514876872640 (0x10000002642427C0);//ML01
        // 0x00B916E4: TBNZ w8, #0, #0xb91700     | if (static_value_03733A42 == true) goto label_0;
        // 0x00B916E8: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B916EC: LDR x8, [x8, #0xad8]       | X8 = 0x2B8F684;                         
        // 0x00B916F0: LDR w0, [x8]               | W0 = 0x1465;                            
        // 0x00B916F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1465, ????);     
        // 0x00B916F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B916FC: STRB w8, [x20, #0xa42]     | static_value_03733A42 = true;            //  dest_result_addr=57883202
        label_0:
        // 0x00B91700: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
        // 0x00B91704: LDR x8, [x8, #0x4d0]       | X8 = (string**)(1152921514876767056)("Misc/abmisc_3dui/hpbar/{0}.prefab");
        // 0x00B91708: LDR x20, [x8]              | X20 = "Misc/abmisc_3dui/hpbar/{0}.prefab";
        // 0x00B9170C: CBZ x19, #0xb91728         | if (unit == null) goto label_1;         
        if(val_22 == null)
        {
            goto label_1;
        }
        // 0x00B91710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91714: MOV x0, x19                | X0 = unit;//m1                          
        // 0x00B91718: BL #0xd89a3c               | X0 = unit.get_unitCamp();               
        EntityEnum.UnitCamp val_1 = val_22.unitCamp;
        // 0x00B9171C: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x00B91720: B.EQ #0xb91748             | if (val_1 == 0x1) goto label_2;         
        if(val_1 == 1)
        {
            goto label_2;
        }
        // 0x00B91724: B #0xb91770                |  goto label_4;                          
        goto label_4;
        label_1:
        // 0x00B91728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1465, ????);     
        // 0x00B9172C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91730: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91734: BL #0xd89a3c               | X0 = 0.get_unitCamp();                  
        EntityEnum.UnitCamp val_2 = 0.unitCamp;
        // 0x00B91738: MOV w21, w0                | W21 = val_2;//m1                        
        // 0x00B9173C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B91740: CMP w21, #1                | STATE = COMPARE(val_2, 0x1)             
        // 0x00B91744: B.NE #0xb91770             | if (val_2 != 0x1) goto label_4;         
        if(val_2 != 1)
        {
            goto label_4;
        }
        label_2:
        // 0x00B91748: LDR x8, [x19]              | X8 = typeof(CombatEntity);              
        // 0x00B9174C: MOV x0, x19                | X0 = unit;//m1                          
        // 0x00B91750: LDR x9, [x8, #0x220]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_220;
        // 0x00B91754: LDR x1, [x8, #0x228]       | X1 = typeof(CombatEntity).__il2cppRuntimeField_228;
        // 0x00B91758: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_220();
        // 0x00B9175C: CMP w0, #8                 | STATE = COMPARE(unit, 0x8)              
        // 0x00B91760: B.NE #0xb9178c             | if (val_22 != 0x8) goto label_5;        
        if(val_22 != 8)
        {
            goto label_5;
        }
        // 0x00B91764: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00B91768: LDR x8, [x8, #0x198]       | X8 = (string**)(1152921514876775392)("FriendHPBar");
        val_23 = "FriendHPBar";
        // 0x00B9176C: B #0xb917a0                |  goto label_9;                          
        goto label_9;
        label_4:
        // 0x00B91770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91774: MOV x0, x19                | X0 = unit;//m1                          
        // 0x00B91778: BL #0xd89b94               | X0 = unit.get_elite();                  
        bool val_3 = val_22.elite;
        // 0x00B9177C: TBZ w0, #0, #0xb91798      | if (val_3 == false) goto label_7;       
        if(val_3 == false)
        {
            goto label_7;
        }
        // 0x00B91780: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B91784: LDR x8, [x8, #0x750]       | X8 = (string**)(1152921514876775488)("JingyingMonsterHPBar");
        val_23 = "JingyingMonsterHPBar";
        // 0x00B91788: B #0xb917a0                |  goto label_9;                          
        goto label_9;
        label_5:
        // 0x00B9178C: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
        // 0x00B91790: LDR x8, [x8, #0x108]       | X8 = (string**)(1152921514876775600)("HeroHPBar");
        val_23 = "HeroHPBar";
        // 0x00B91794: B #0xb917a0                |  goto label_9;                          
        goto label_9;
        label_7:
        // 0x00B91798: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00B9179C: LDR x8, [x8, #0xa70]       | X8 = (string**)(1152921514876775696)("MonsterHPBar");
        val_23 = "MonsterHPBar";
        label_9:
        // 0x00B917A0: LDR x2, [x8]               | X2 = "MonsterHPBar";                    
        // 0x00B917A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B917A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B917AC: MOV x1, x20                | X1 = 1152921514876767056 (0x1000000264228B50);//ML01
        // 0x00B917B0: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "Misc/abmisc_3dui/hpbar/{0}.prefab");
        string val_4 = EString.EFormat(format:  0, arg0:  "Misc/abmisc_3dui/hpbar/{0}.prefab");
        // 0x00B917B4: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B917B8: CBNZ x19, #0xb917c0        | if (unit != null) goto label_10;        
        if(val_22 != null)
        {
            goto label_10;
        }
        // 0x00B917BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_10:
        // 0x00B917C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B917C4: MOV x0, x19                | X0 = unit;//m1                          
        // 0x00B917C8: BL #0x20d50fc              | X0 = unit.get_gameObject();             
        UnityEngine.GameObject val_5 = val_22.gameObject;
        // 0x00B917CC: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B917D0: CBNZ x21, #0xb917d8        | if (val_5 != null) goto label_11;       
        if(val_5 != null)
        {
            goto label_11;
        }
        // 0x00B917D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_11:
        // 0x00B917D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B917DC: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B917E0: BL #0x1a62c1c              | X0 = val_5.get_transform();             
        UnityEngine.Transform val_6 = val_5.transform;
        // 0x00B917E4: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00B917E8: CBNZ x21, #0xb917f0        | if (val_6 != null) goto label_12;       
        if(val_6 != null)
        {
            goto label_12;
        }
        // 0x00B917EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_12:
        // 0x00B917F0: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
        // 0x00B917F4: LDR x8, [x8, #0x8b0]       | X8 = (string**)(1152921514727926128)("headpoint");
        // 0x00B917F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B917FC: MOV x0, x21                | X0 = val_6;//m1                         
        // 0x00B91800: LDR x1, [x8]               | X1 = "headpoint";                       
        // 0x00B91804: BL #0x2695ac0              | X0 = val_6.Find(name:  "headpoint");    
        UnityEngine.Transform val_7 = val_6.Find(name:  "headpoint");
        // 0x00B91808: ADRP x26, #0x35c8000       | X26 = 56393728 (0x35C8000);             
        // 0x00B9180C: LDR x26, [x26, #0x270]     | X26 = 1152921504903331840;              
        // 0x00B91810: MOV x23, x0                | X23 = val_7;//m1                        
        // 0x00B91814: LDR x8, [x26]              | X8 = typeof(Mihua.Asset.AssetMgr);      
        // 0x00B91818: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
        // 0x00B9181C: TBZ w9, #0, #0xb91830      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B91820: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B91824: CBNZ w9, #0xb91830         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B91828: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
        // 0x00B9182C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
        label_14:
        // 0x00B91830: ADRP x25, #0x35d0000       | X25 = 56426496 (0x35D0000);             
        // 0x00B91834: LDR x25, [x25, #0xff8]     | X25 = 1152921510507425072;              
        // 0x00B91838: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9183C: MOV x1, x20                | X1 = val_4;//m1                         
        // 0x00B91840: LDR x2, [x25]              | X2 = public static UnityEngine.GameObject Mihua.Asset.AssetMgr::GetLoadedAsset<UnityEngine.GameObject>(string assetName);
        // 0x00B91844: BL #0xfd8bec               | X0 = Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
        UnityEngine.Object val_8 = Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
        // 0x00B91848: MOV x1, x0                 | X1 = val_8;//m1                         
        // 0x00B9184C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91850: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91854: BL #0xbf74bc               | X0 = GameObject_Instantiate.Instantiate(_this:  0);
        UnityEngine.GameObject val_9 = GameObject_Instantiate.Instantiate(_this:  0);
        // 0x00B91858: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00B9185C: MOV x0, x22                | X0 = 1152921514876872640 (0x10000002642427C0);//ML01
        // 0x00B91860: BL #0xb914f0               | X0 = this.get_parentGO();               
        UnityEngine.GameObject val_10 = this.parentGO;
        // 0x00B91864: MOV x2, x0                 | X2 = val_10;//m1                        
        // 0x00B91868: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9186C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B91870: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x00B91874: MOV x1, x20                | X1 = val_9;//m1                         
        // 0x00B91878: BL #0xbf7570               | GameObject_Hierarchy.ChangeParent(_this:  0, parent:  val_9, resetMat:  val_10);
        GameObject_Hierarchy.ChangeParent(_this:  0, parent:  val_9, resetMat:  val_10);
        // 0x00B9187C: CBNZ x20, #0xb91884        | if (val_9 != null) goto label_15;       
        if(val_9 != null)
        {
            goto label_15;
        }
        // 0x00B91880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_15:
        // 0x00B91884: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
        // 0x00B91888: LDR x8, [x8, #0xdf8]       | X8 = 1152921514876804464;               
        // 0x00B9188C: MOV x0, x20                | X0 = val_9;//m1                         
        // 0x00B91890: LDR x1, [x8]               | X1 = public Blood UnityEngine.GameObject::GetComponent<Blood>();
        // 0x00B91894: BL #0x23d5abc              | X0 = val_9.GetComponent<Blood>();       
        Blood val_11 = val_9.GetComponent<Blood>();
        // 0x00B91898: MOV x21, x0                | X21 = val_11;//m1                       
        // 0x00B9189C: CBNZ x19, #0xb918a4        | if (unit != null) goto label_16;        
        if(val_22 != null)
        {
            goto label_16;
        }
        // 0x00B918A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_16:
        // 0x00B918A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B918A8: MOV x0, x19                | X0 = unit;//m1                          
        // 0x00B918AC: BL #0x1b759fc              | X0 = unit.get_name();                   
        string val_12 = val_22.name;
        // 0x00B918B0: MOV x24, x0                | X24 = val_12;//m1                       
        // 0x00B918B4: CBZ x21, #0xb918d4         | if (val_11 == null) goto label_17;      
        if(val_11 == null)
        {
            goto label_17;
        }
        // 0x00B918B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B918BC: MOV x0, x21                | X0 = val_11;//m1                        
        // 0x00B918C0: MOV x1, x24                | X1 = val_12;//m1                        
        // 0x00B918C4: BL #0x1b78c7c              | val_11.set_name(value:  val_12);        
        val_11.name = val_12;
        // 0x00B918C8: STR x23, [x21, #0x20]      | val_11.targetTf = val_7;                 //  dest_result_addr=0
        val_11.targetTf = val_7;
        // 0x00B918CC: MOV x23, x21               | X23 = val_11;//m1                       
        val_24 = val_11;
        // 0x00B918D0: B #0xb918fc                |  goto label_18;                         
        goto label_18;
        label_17:
        // 0x00B918D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        // 0x00B918D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B918DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B918E0: MOV x1, x24                | X1 = val_12;//m1                        
        // 0x00B918E4: BL #0x1b78c7c              | 0.set_name(value:  val_12);             
        0.name = val_12;
        // 0x00B918E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00B918EC: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
        // 0x00B918F0: STR x23, [x8]              | mem[32] = val_7;                         //  dest_result_addr=32
        mem[32] = val_7;
        // 0x00B918F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00B918F8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_24 = 0;
        label_18:
        // 0x00B918FC: MOV x0, x21                | X0 = val_11;//m1                        
        // 0x00B91900: MOV x1, x19                | X1 = unit;//m1                          
        // 0x00B91904: BL #0xb90b00               | val_11.setDutyType(unit:  val_22);      
        val_11.setDutyType(unit:  val_22);
        // 0x00B91908: LDR x22, [x22, #0x10]      | X22 = this.bloodList; //P2              
        // 0x00B9190C: CBNZ x22, #0xb91914        | if (this.bloodList != null) goto label_19;
        if(this.bloodList != null)
        {
            goto label_19;
        }
        // 0x00B91910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_19:
        // 0x00B91914: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00B91918: LDR x8, [x8, #0x1a8]       | X8 = 1152921514876817776;               
        // 0x00B9191C: MOV x0, x22                | X0 = this.bloodList;//m1                
        // 0x00B91920: MOV x1, x21                | X1 = val_11;//m1                        
        // 0x00B91924: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Blood>::Add(Blood item);
        // 0x00B91928: BL #0x25ea480              | this.bloodList.Add(item:  val_11);      
        this.bloodList.Add(item:  val_11);
        // 0x00B9192C: ADRP x22, #0x35cb000       | X22 = 56406016 (0x35CB000);             
        // 0x00B91930: LDR x22, [x22, #0xd98]     | X22 = 1152921504901361664;              
        // 0x00B91934: LDR x0, [x22]              | X0 = typeof(BloodMgr);                  
        val_25 = null;
        // 0x00B91938: LDRB w8, [x0, #0x10a]      | W8 = BloodMgr.__il2cppRuntimeField_10A; 
        // 0x00B9193C: TBZ w8, #0, #0xb91950      | if (BloodMgr.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x00B91940: LDR w8, [x0, #0xbc]        | W8 = BloodMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B91944: CBNZ w8, #0xb91950         | if (BloodMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x00B91948: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BloodMgr), ????);
        // 0x00B9194C: LDR x0, [x22]              | X0 = typeof(BloodMgr);                  
        val_25 = null;
        label_21:
        // 0x00B91950: LDR x8, [x0, #0xa0]        | X8 = BloodMgr.__il2cppRuntimeField_static_fields;
        // 0x00B91954: LDR x22, [x8]              | X22 = BloodMgr.debugList;               
        // 0x00B91958: CBZ x21, #0xb91970         | if (val_11 == null) goto label_22;      
        if(val_11 == null)
        {
            goto label_22;
        }
        // 0x00B9195C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91960: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B91964: BL #0x1b759fc              | X0 = val_24.get_name();                 
        string val_13 = val_24.name;
        // 0x00B91968: MOV x24, x0                | X24 = val_13;//m1                       
        val_26 = val_13;
        // 0x00B9196C: B #0xb91988                |  goto label_23;                         
        goto label_23;
        label_22:
        // 0x00B91970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BloodMgr), ????);
        // 0x00B91974: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91978: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B9197C: BL #0x1b759fc              | X0 = val_24.get_name();                 
        string val_14 = val_24.name;
        // 0x00B91980: MOV x24, x0                | X24 = val_14;//m1                       
        val_26 = val_14;
        // 0x00B91984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_23:
        // 0x00B91988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9198C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B91990: BL #0x1b78f0c              | X0 = val_24.GetInstanceID();            
        int val_15 = val_24.GetInstanceID();
        // 0x00B91994: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00B91998: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00B9199C: STR w0, [sp, #0xc]         | stack[1152921514876860556] = val_15;     //  dest_result_addr=1152921514876860556
        // 0x00B919A0: ADD x1, sp, #0xc           | X1 = (1152921514876860544 + 12) = 1152921514876860556 (0x100000026423F88C);
        // 0x00B919A4: LDR x8, [x8]               | X8 = typeof(System.Int32);              
        // 0x00B919A8: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00B919AC: BL #0x27bc028              | X0 = 1152921514876966080 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_15);
        // 0x00B919B0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B919B4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B919B8: MOV x23, x0                | X23 = 1152921514876966080 (0x10000002642594C0);//ML01
        // 0x00B919BC: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B919C0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B919C4: TBZ w9, #0, #0xb919d8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x00B919C8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B919CC: CBNZ w9, #0xb919d8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x00B919D0: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B919D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_25:
        // 0x00B919D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B919DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B919E0: MOV x1, x24                | X1 = val_14;//m1                        
        // 0x00B919E4: MOV x2, x23                | X2 = 1152921514876966080 (0x10000002642594C0);//ML01
        // 0x00B919E8: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  val_26);
        string val_16 = System.String.Concat(arg0:  0, arg1:  val_26);
        // 0x00B919EC: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
        // 0x00B919F0: LDR x8, [x8, #0x820]       | X8 = 1152921504657326080;               
        // 0x00B919F4: MOV x23, x0                | X23 = val_16;//m1                       
        // 0x00B919F8: LDR x8, [x8]               | X8 = typeof(System.WeakReference);      
        // 0x00B919FC: MOV x0, x8                 | X0 = 1152921504657326080 (0x1000000003024000);//ML01
        System.WeakReference val_17 = null;
        // 0x00B91A00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.WeakReference), ????);
        // 0x00B91A04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91A08: MOV x1, x21                | X1 = val_11;//m1                        
        // 0x00B91A0C: MOV x24, x0                | X24 = 1152921504657326080 (0x1000000003024000);//ML01
        // 0x00B91A10: BL #0x273c840              | .ctor(target:  val_11);                 
        val_17 = new System.WeakReference(target:  val_11);
        // 0x00B91A14: CBNZ x22, #0xb91a1c        | if (BloodMgr.debugList != null) goto label_26;
        if(BloodMgr.debugList != null)
        {
            goto label_26;
        }
        // 0x00B91A18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(target:  val_11), ????);
        label_26:
        // 0x00B91A1C: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
        // 0x00B91A20: LDR x8, [x8, #0x138]       | X8 = 1152921514876835184;               
        // 0x00B91A24: MOV x0, x22                | X0 = BloodMgr.debugList;//m1            
        // 0x00B91A28: MOV x1, x23                | X1 = val_16;//m1                        
        // 0x00B91A2C: MOV x2, x24                | X2 = 1152921504657326080 (0x1000000003024000);//ML01
        // 0x00B91A30: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.WeakReference>::Add(System.String key, System.WeakReference value);
        // 0x00B91A34: BL #0x23fd44c              | BloodMgr.debugList.Add(key:  val_16, value:  val_17);
        BloodMgr.debugList.Add(key:  val_16, value:  val_17);
        // 0x00B91A38: CBNZ x20, #0xb91a40        | if (val_9 != null) goto label_27;       
        if(val_9 != null)
        {
            goto label_27;
        }
        // 0x00B91A3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? BloodMgr.debugList, ????);
        label_27:
        // 0x00B91A40: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B91A44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91A48: MOV x0, x20                | X0 = val_9;//m1                         
        // 0x00B91A4C: BL #0x1a62d64              | val_9.SetActive(value:  false);         
        val_9.SetActive(value:  false);
        // 0x00B91A50: CBNZ x19, #0xb91a58        | if (unit != null) goto label_28;        
        if(val_22 != null)
        {
            goto label_28;
        }
        // 0x00B91A54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_28:
        // 0x00B91A58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91A5C: MOV x0, x19                | X0 = unit;//m1                          
        // 0x00B91A60: BL #0xd89ba8               | X0 = unit.get_isAim();                  
        bool val_18 = val_22.isAim;
        // 0x00B91A64: TBZ w0, #0, #0xb91ae8      | if (val_18 == false) goto label_29;     
        if(val_18 == false)
        {
            goto label_29;
        }
        // 0x00B91A68: LDR x0, [x26]              | X0 = typeof(Mihua.Asset.AssetMgr);      
        // 0x00B91A6C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
        // 0x00B91A70: TBZ w8, #0, #0xb91a80      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_31;
        // 0x00B91A74: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B91A78: CBNZ w8, #0xb91a80         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
        // 0x00B91A7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
        label_31:
        // 0x00B91A80: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
        // 0x00B91A84: LDR x8, [x8, #0x340]       | X8 = (string**)(1152921514876836208)("Misc/abmisc_3dui/hpbar/Focus.prefab");
        // 0x00B91A88: LDR x2, [x25]              | X2 = public static UnityEngine.GameObject Mihua.Asset.AssetMgr::GetLoadedAsset<UnityEngine.GameObject>(string assetName);
        // 0x00B91A8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91A90: LDR x1, [x8]               | X1 = "Misc/abmisc_3dui/hpbar/Focus.prefab";
        // 0x00B91A94: BL #0xfd8bec               | X0 = Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
        UnityEngine.Object val_19 = Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
        // 0x00B91A98: MOV x1, x0                 | X1 = val_19;//m1                        
        // 0x00B91A9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91AA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91AA4: BL #0xbf74bc               | X0 = GameObject_Instantiate.Instantiate(_this:  0);
        UnityEngine.GameObject val_20 = GameObject_Instantiate.Instantiate(_this:  0);
        // 0x00B91AA8: MOV x19, x0                | X19 = val_20;//m1                       
        // 0x00B91AAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91AB0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B91AB4: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x00B91AB8: MOV x1, x19                | X1 = val_20;//m1                        
        // 0x00B91ABC: MOV x2, x20                | X2 = val_9;//m1                         
        // 0x00B91AC0: BL #0xbf7570               | GameObject_Hierarchy.ChangeParent(_this:  0, parent:  val_20, resetMat:  val_9);
        GameObject_Hierarchy.ChangeParent(_this:  0, parent:  val_20, resetMat:  val_9);
        // 0x00B91AC4: CBNZ x19, #0xb91acc        | if (val_20 != null) goto label_32;      
        if(val_20 != null)
        {
            goto label_32;
        }
        // 0x00B91AC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_32:
        // 0x00B91ACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91AD0: MOV x0, x19                | X0 = val_20;//m1                        
        // 0x00B91AD4: BL #0x1a62c1c              | X0 = val_20.get_transform();            
        UnityEngine.Transform val_21 = val_20.transform;
        // 0x00B91AD8: MOV x19, x0                | X19 = val_21;//m1                       
        val_22 = val_21;
        // 0x00B91ADC: CBNZ x21, #0xb91ae4        | if (val_11 != null) goto label_33;      
        if(val_11 != null)
        {
            goto label_33;
        }
        // 0x00B91AE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_33:
        // 0x00B91AE4: STR x19, [x21, #0x58]      | val_11.focusTr = val_21;                 //  dest_result_addr=0
        val_11.focusTr = val_22;
        label_29:
        // 0x00B91AE8: MOV x0, x21                | X0 = val_11;//m1                        
        // 0x00B91AEC: SUB sp, x29, #0x40         | SP = (1152921514876860624 - 64) = 1152921514876860560 (0x100000026423F890);
        // 0x00B91AF0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91AF4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B91AF8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B91AFC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B91B00: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B91B04: RET                        |  return (Blood)val_11;                  
        return (Blood)val_11;
        //  |  // // {name=val_0, type=Blood, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B91B08 (12131080), len: 204  VirtAddr: 0x00B91B08 RVA: 0x00B91B08 token: 100692738 methodIndex: 25163 delegateWrapperIndex: 0 methodInvoker: 0
    public void RemoveBlood(Blood blood)
    {
        //
        // Disasemble & Code
        // 0x00B91B08: STP x22, x21, [sp, #-0x30]! | stack[1152921514877067824] = ???;  stack[1152921514877067832] = ???;  //  dest_result_addr=1152921514877067824 |  dest_result_addr=1152921514877067832
        // 0x00B91B0C: STP x20, x19, [sp, #0x10]  | stack[1152921514877067840] = ???;  stack[1152921514877067848] = ???;  //  dest_result_addr=1152921514877067840 |  dest_result_addr=1152921514877067848
        // 0x00B91B10: STP x29, x30, [sp, #0x20]  | stack[1152921514877067856] = ???;  stack[1152921514877067864] = ???;  //  dest_result_addr=1152921514877067856 |  dest_result_addr=1152921514877067864
        // 0x00B91B14: ADD x29, sp, #0x20         | X29 = (1152921514877067824 + 32) = 1152921514877067856 (0x1000000264272250);
        // 0x00B91B18: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B91B1C: LDRB w8, [x21, #0xa43]     | W8 = (bool)static_value_03733A43;       
        // 0x00B91B20: MOV x19, x1                | X19 = blood;//m1                        
        // 0x00B91B24: MOV x20, x0                | X20 = 1152921514877079872 (0x1000000264275140);//ML01
        // 0x00B91B28: TBNZ w8, #0, #0xb91b44     | if (static_value_03733A43 == true) goto label_0;
        // 0x00B91B2C: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00B91B30: LDR x8, [x8, #0x578]       | X8 = 0x2B8F690;                         
        // 0x00B91B34: LDR w0, [x8]               | W0 = 0x1468;                            
        // 0x00B91B38: BL #0x2782188              | X0 = sub_2782188( ?? 0x1468, ????);     
        // 0x00B91B3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B91B40: STRB w8, [x21, #0xa43]     | static_value_03733A43 = true;            //  dest_result_addr=57883203
        label_0:
        // 0x00B91B44: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B91B48: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B91B4C: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B91B50: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B91B54: TBZ w8, #0, #0xb91b64      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B91B58: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B91B5C: CBNZ w8, #0xb91b64         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B91B60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00B91B64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91B68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91B6C: BL #0x26a87d0              | X0 = ZMG.get_CameraShotMgr();           
        CameraShotMgr val_1 = ZMG.CameraShotMgr;
        // 0x00B91B70: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B91B74: CBNZ x21, #0xb91b7c        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B91B78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B91B7C: LDRB w8, [x21, #0x44]      | W8 = val_1.isCameraShotRunning; //P2    
        // 0x00B91B80: CBZ w8, #0xb91b94          | if (val_1.isCameraShotRunning == false) goto label_4;
        if(val_1.isCameraShotRunning == false)
        {
            goto label_4;
        }
        // 0x00B91B84: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91B88: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B91B8C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B91B90: RET                        |  return;                                
        return;
        label_4:
        // 0x00B91B94: LDR x20, [x20, #0x10]      | X20 = this.bloodList; //P2              
        // 0x00B91B98: CBNZ x20, #0xb91ba0        | if (this.bloodList != null) goto label_5;
        if(this.bloodList != null)
        {
            goto label_5;
        }
        // 0x00B91B9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00B91BA0: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B91BA4: LDR x8, [x8, #0xa90]       | X8 = 1152921514877054848;               
        // 0x00B91BA8: MOV x0, x20                | X0 = this.bloodList;//m1                
        // 0x00B91BAC: MOV x1, x19                | X1 = blood;//m1                         
        // 0x00B91BB0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<Blood>::Remove(Blood item);
        // 0x00B91BB4: BL #0x25ecd20              | X0 = this.bloodList.Remove(item:  blood);
        bool val_2 = this.bloodList.Remove(item:  blood);
        // 0x00B91BB8: CBNZ x19, #0xb91bc0        | if (blood != null) goto label_6;        
        if(blood != null)
        {
            goto label_6;
        }
        // 0x00B91BBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B91BC0: MOV x0, x19                | X0 = blood;//m1                         
        // 0x00B91BC4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91BC8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B91BCC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B91BD0: B #0xb9126c                | blood.Clear(); return;                  
        blood.Clear();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B91BD4 (12131284), len: 116  VirtAddr: 0x00B91BD4 RVA: 0x00B91BD4 token: 100692739 methodIndex: 25164 delegateWrapperIndex: 0 methodInvoker: 0
    private static BloodMgr()
    {
        //
        // Disasemble & Code
        // 0x00B91BD4: STP x20, x19, [sp, #-0x20]! | stack[1152921514877193152] = ???;  stack[1152921514877193160] = ???;  //  dest_result_addr=1152921514877193152 |  dest_result_addr=1152921514877193160
        // 0x00B91BD8: STP x29, x30, [sp, #0x10]  | stack[1152921514877193168] = ???;  stack[1152921514877193176] = ???;  //  dest_result_addr=1152921514877193168 |  dest_result_addr=1152921514877193176
        // 0x00B91BDC: ADD x29, sp, #0x10         | X29 = (1152921514877193152 + 16) = 1152921514877193168 (0x1000000264290BD0);
        // 0x00B91BE0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B91BE4: LDRB w8, [x19, #0xa44]     | W8 = (bool)static_value_03733A44;       
        // 0x00B91BE8: TBNZ w8, #0, #0xb91c04     | if (static_value_03733A44 == true) goto label_0;
        // 0x00B91BEC: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00B91BF0: LDR x8, [x8, #0xdc0]       | X8 = 0x2B8F67C;                         
        // 0x00B91BF4: LDR w0, [x8]               | W0 = 0x1463;                            
        // 0x00B91BF8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1463, ????);     
        // 0x00B91BFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B91C00: STRB w8, [x19, #0xa44]     | static_value_03733A44 = true;            //  dest_result_addr=57883204
        label_0:
        // 0x00B91C04: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00B91C08: LDR x8, [x8, #0x800]       | X8 = 1152921504615792640;               
        // 0x00B91C0C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.WeakReference> val_1 = null;
        // 0x00B91C10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B91C14: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
        // 0x00B91C18: LDR x8, [x8, #0x890]       | X8 = 1152921514877180160;               
        // 0x00B91C1C: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B91C20: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.WeakReference>::.ctor();
        // 0x00B91C24: BL #0x23fb0c4              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.String, System.WeakReference>();
        // 0x00B91C28: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B91C2C: LDR x8, [x8, #0xd98]       | X8 = 1152921504901361664;               
        // 0x00B91C30: LDR x8, [x8]               | X8 = typeof(BloodMgr);                  
        // 0x00B91C34: LDR x8, [x8, #0xa0]        | X8 = BloodMgr.__il2cppRuntimeField_static_fields;
        // 0x00B91C38: STR x19, [x8]              | BloodMgr.debugList = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504901365760
        BloodMgr.debugList = val_1;
        // 0x00B91C3C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91C40: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B91C44: RET                        |  return;                                
        return;
    
    }

}
