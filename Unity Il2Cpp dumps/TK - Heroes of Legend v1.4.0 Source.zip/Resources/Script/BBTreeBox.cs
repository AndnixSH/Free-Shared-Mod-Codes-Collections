using UnityEngine;
private struct BBTree.BBTreeBox
{
    // Fields
    public UnityEngine.Rect rect; //  0x00000000
    public Pathfinding.MeshNode node; //  0x00000010
    public int left; //  0x00000018
    public int right; //  0x0000001C
    
    // Properties
    public bool IsLeaf { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x01688AE8 (23628520), len: 8  VirtAddr: 0x01688AE8 RVA: 0x01688AE8 token: 100683187 methodIndex: 49909 delegateWrapperIndex: 0 methodInvoker: 0
    public BBTree.BBTreeBox(Pathfinding.BBTree tree, Pathfinding.MeshNode node)
    {
        //
        // Disasemble & Code
        // 0x01688AE8: ADD x0, x0, #0x10          | X0 = this.node;//AP2 res_addr=1152921513415481824
        // 0x01688AEC: B #0x1686d68               | goto label_Pathfinding_BBTree_GetBox_GL01686D68;
    
    }
    //
    // Offset in libil2cpp.so: 0x01688AF0 (23628528), len: 92  VirtAddr: 0x01688AF0 RVA: 0x01688AF0 token: 100683188 methodIndex: 49910 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_IsLeaf()
    {
        //
        // Disasemble & Code
        // 0x01688AF0: LDR x8, [x0, #0x20]        | 
        // 0x01688AF4: CMP x8, #0                 | STATE = COMPARE(X8, 0x0)                
        // 0x01688AF8: CSET w0, ne                | W0 = X8 != 0x0 ? 1 : 0;                 
        var val_1 = (X8 != 0) ? 1 : 0;
        // 0x01688AFC: RET                        |  return (System.Boolean)X8 != 0x0 ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        // 0x01688B00: STP x20, x19, [sp, #-0x20]! | 
        // 0x01688B04: STP x29, x30, [sp, #0x10]  | 
        // 0x01688B08: ADD x29, sp, #0x10         | 
        // 0x01688B0C: SUB sp, sp, #0x10          | 
        // 0x01688B10: MOV x19, x0                | 
        // 0x01688B14: MOV x1, xzr                | 
        // 0x01688B18: ADD x0, sp, #8             | 
        // 0x01688B1C: MOV v1.16b, v2.16b         | 
        // 0x01688B20: STR xzr, [sp, #8]          | 
        // 0x01688B24: BL #0x2697148              | 
        // 0x01688B28: LDP s0, s1, [sp, #8]       | 
        // 0x01688B2C: MOV x1, xzr                | 
        // 0x01688B30: MOV x0, x19                | 
        // 0x01688B34: BL #0x1b81aec              | 
        // 0x01688B38: AND w0, w0, #1             | 
        // 0x01688B3C: SUB sp, x29, #0x10         | 
        // 0x01688B40: LDP x29, x30, [sp, #0x10]  | 
        // 0x01688B44: LDP x20, x19, [sp], #0x20  | 
        // 0x01688B48: RET                        | 
    
    }
    //
    // Offset in libil2cpp.so: 0x01688B4C (23628620), len: 8  VirtAddr: 0x01688B4C RVA: 0x01688B4C token: 100683189 methodIndex: 49911 delegateWrapperIndex: 0 methodInvoker: 0
    public bool Contains(UnityEngine.Vector3 p)
    {
        //
        // Disasemble & Code
        // 0x01688B4C: ADD x0, x0, #0x10          | X0 = this.node;//AP2 res_addr=1152921513415714016
        // 0x01688B50: B #0x1688b00               | goto label_BBTree_BBTreeBox_get_IsLeaf_GL01688B00;
    
    }

}
