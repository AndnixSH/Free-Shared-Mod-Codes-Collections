using UnityEngine;

namespace ProtoBuf
{
    internal sealed class BufferPool
    {
        // Fields
        private const int PoolSize = 20;
        internal const int BufferLength = 1024;
        private static readonly object[] pool; // static_offset: 0x00000000
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00C7C484 (13091972), len: 8  VirtAddr: 0x00C7C484 RVA: 0x00C7C484 token: 100689134 methodIndex: 53365 delegateWrapperIndex: 0 methodInvoker: 0
        private BufferPool()
        {
            //
            // Disasemble & Code
            // 0x00C7C484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7C488: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C48C (13091980), len: 252  VirtAddr: 0x00C7C48C RVA: 0x00C7C48C token: 100689135 methodIndex: 53366 delegateWrapperIndex: 0 methodInvoker: 0
        internal static void Flush()
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x00C7C48C: STP x22, x21, [sp, #-0x30]! | stack[1152921514335801888] = ???;  stack[1152921514335801896] = ???;  //  dest_result_addr=1152921514335801888 |  dest_result_addr=1152921514335801896
            // 0x00C7C490: STP x20, x19, [sp, #0x10]  | stack[1152921514335801904] = ???;  stack[1152921514335801912] = ???;  //  dest_result_addr=1152921514335801904 |  dest_result_addr=1152921514335801912
            // 0x00C7C494: STP x29, x30, [sp, #0x20]  | stack[1152921514335801920] = ???;  stack[1152921514335801928] = ???;  //  dest_result_addr=1152921514335801920 |  dest_result_addr=1152921514335801928
            // 0x00C7C498: ADD x29, sp, #0x20         | X29 = (1152921514335801888 + 32) = 1152921514335801920 (0x1000000243E41240);
            // 0x00C7C49C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7C4A0: LDRB w8, [x20, #0xf87]     | W8 = (bool)static_value_03733F87;       
            // 0x00C7C4A4: TBZ w8, #0, #0xc7c4b0      | if (static_value_03733F87 == false) goto label_0;
            // 0x00C7C4A8: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x00C7C4AC: B #0xc7c4ec                |  goto label_2;                          
            goto label_2;
            label_0:
            // 0x00C7C4B0: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00C7C4B4: LDR x8, [x8, #0x280]       | X8 = 0x2B8FDC4;                         
            // 0x00C7C4B8: LDR w0, [x8]               | W0 = 0x1635;                            
            // 0x00C7C4BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1635, ????);     
            // 0x00C7C4C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7C4C4: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x00C7C4C8: STRB w8, [x20, #0xf87]     | static_value_03733F87 = true;            //  dest_result_addr=57884551
            // 0x00C7C4CC: B #0xc7c4ec                |  goto label_2;                          
            goto label_2;
            label_11:
            // 0x00C7C4D0: ADD x8, x20, x21, lsl #3   | X8 = (57880576 + (X21) << 3);           
            var val_1 = 57880576 + ((X21) << 3);
            // 0x00C7C4D4: ADD x1, x8, #0x20          | X1 = ((57880576 + (X21) << 3) + 32);    
            object val_2 = val_1 + 32;
            // 0x00C7C4D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            object val_3 = 0;
            // 0x00C7C4DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7C4E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7C4E4: BL #0x1b65ad0              | X0 = System.Threading.Interlocked.Exchange(location1: ref  object val_3 = 0, value:  object val_2 = val_1 + 32);
            object val_4 = System.Threading.Interlocked.Exchange(location1: ref  val_3, value:  val_2);
            // 0x00C7C4E8: ADD w19, w19, #1           | W19 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            label_2:
            // 0x00C7C4EC: ADRP x20, #0x35db000       | X20 = 56471552 (0x35DB000);             
            // 0x00C7C4F0: LDR x20, [x20, #0x1c8]     | X20 = 1152921504881446912;              
            // 0x00C7C4F4: LDR x0, [x20]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_6 = null;
            // 0x00C7C4F8: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_10A;
            // 0x00C7C4FC: TBZ w8, #0, #0xc7c510      | if (ProtoBuf.BufferPool.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00C7C500: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C504: CBNZ w8, #0xc7c510         | if (ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00C7C508: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C50C: LDR x0, [x20]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_6 = null;
            label_4:
            // 0x00C7C510: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.BufferPool.__il2cppRuntimeField_static_fields;
            // 0x00C7C514: LDR x21, [x8]              | X21 = ProtoBuf.BufferPool.pool;         
            // 0x00C7C518: CBNZ x21, #0xc7c520        | if (ProtoBuf.BufferPool.pool != null) goto label_5;
            if(ProtoBuf.BufferPool.pool != null)
            {
                goto label_5;
            }
            // 0x00C7C51C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.BufferPool), ????);
            label_5:
            // 0x00C7C520: LDR w8, [x21, #0x18]       | W8 = ProtoBuf.BufferPool.pool.Length;   
            // 0x00C7C524: CMP w19, w8                | STATE = COMPARE(0x1, ProtoBuf.BufferPool.pool.Length)
            // 0x00C7C528: B.GE #0xc7c578             | if (val_5 >= ProtoBuf.BufferPool.pool.Length) goto label_6;
            if(val_5 >= ProtoBuf.BufferPool.pool.Length)
            {
                goto label_6;
            }
            // 0x00C7C52C: LDR x0, [x20]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_7 = null;
            // 0x00C7C530: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_10A;
            // 0x00C7C534: TBZ w8, #0, #0xc7c548      | if (ProtoBuf.BufferPool.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00C7C538: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C53C: CBNZ w8, #0xc7c548         | if (ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00C7C540: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C544: LDR x0, [x20]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_7 = null;
            label_8:
            // 0x00C7C548: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.BufferPool.__il2cppRuntimeField_static_fields;
            // 0x00C7C54C: LDR x20, [x8]              | X20 = ProtoBuf.BufferPool.pool;         
            // 0x00C7C550: CBNZ x20, #0xc7c558        | if (ProtoBuf.BufferPool.pool != null) goto label_9;
            if(ProtoBuf.BufferPool.pool != null)
            {
                goto label_9;
            }
            // 0x00C7C554: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.BufferPool), ????);
            label_9:
            // 0x00C7C558: LDR w8, [x20, #0x18]       | W8 = ProtoBuf.BufferPool.pool.Length;   
            // 0x00C7C55C: SXTW x21, w19              | X21 = 1 (0x00000001);                   
            // 0x00C7C560: CMP w19, w8                | STATE = COMPARE(0x1, ProtoBuf.BufferPool.pool.Length)
            // 0x00C7C564: B.LO #0xc7c4d0             | if (val_5 < ProtoBuf.BufferPool.pool.Length) goto label_11;
            if(val_5 < ProtoBuf.BufferPool.pool.Length)
            {
                goto label_11;
            }
            // 0x00C7C568: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C56C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7C570: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C574: B #0xc7c4d0                |  goto label_11;                         
            goto label_11;
            label_6:
            // 0x00C7C578: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C57C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C580: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C7C584: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C588 (13092232), len: 392  VirtAddr: 0x00C7C588 RVA: 0x00C7C588 token: 100689136 methodIndex: 53367 delegateWrapperIndex: 0 methodInvoker: 0
        internal static byte[] GetBuffer()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            System.Object[] val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00C7C588: STP x22, x21, [sp, #-0x30]! | stack[1152921514335922080] = ???;  stack[1152921514335922088] = ???;  //  dest_result_addr=1152921514335922080 |  dest_result_addr=1152921514335922088
            // 0x00C7C58C: STP x20, x19, [sp, #0x10]  | stack[1152921514335922096] = ???;  stack[1152921514335922104] = ???;  //  dest_result_addr=1152921514335922096 |  dest_result_addr=1152921514335922104
            // 0x00C7C590: STP x29, x30, [sp, #0x20]  | stack[1152921514335922112] = ???;  stack[1152921514335922120] = ???;  //  dest_result_addr=1152921514335922112 |  dest_result_addr=1152921514335922120
            // 0x00C7C594: ADD x29, sp, #0x20         | X29 = (1152921514335922080 + 32) = 1152921514335922112 (0x1000000243E5E7C0);
            // 0x00C7C598: SUB sp, sp, #0x10          | SP = (1152921514335922080 - 16) = 1152921514335922064 (0x1000000243E5E790);
            // 0x00C7C59C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00C7C5A0: LDRB w8, [x19, #0xf88]     | W8 = (bool)static_value_03733F88;       
            // 0x00C7C5A4: TBZ w8, #0, #0xc7c5b0      | if (static_value_03733F88 == false) goto label_0;
            // 0x00C7C5A8: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x00C7C5AC: B #0xc7c5cc                |  goto label_10;                         
            goto label_10;
            label_0:
            // 0x00C7C5B0: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x00C7C5B4: LDR x8, [x8, #0x9d8]       | X8 = 0x2B8FDC8;                         
            // 0x00C7C5B8: LDR w0, [x8]               | W0 = 0x1636;                            
            // 0x00C7C5BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1636, ????);     
            // 0x00C7C5C0: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x00C7C5C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7C5C8: STRB w8, [x19, #0xf88]     | static_value_03733F88 = true;            //  dest_result_addr=57884552
            label_10:
            // 0x00C7C5CC: ADRP x19, #0x35db000       | X19 = 56471552 (0x35DB000);             
            // 0x00C7C5D0: LDR x19, [x19, #0x1c8]     | X19 = 1152921504881446912;              
            // 0x00C7C5D4: LDR x0, [x19]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_6 = null;
            // 0x00C7C5D8: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_10A;
            // 0x00C7C5DC: TBZ w8, #0, #0xc7c5f0      | if (ProtoBuf.BufferPool.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00C7C5E0: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C5E4: CBNZ w8, #0xc7c5f0         | if (ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00C7C5E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C5EC: LDR x0, [x19]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_6 = null;
            label_3:
            // 0x00C7C5F0: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.BufferPool.__il2cppRuntimeField_static_fields;
            // 0x00C7C5F4: LDR x21, [x8]              | X21 = ProtoBuf.BufferPool.pool;         
            val_7 = ProtoBuf.BufferPool.pool;
            // 0x00C7C5F8: CBNZ x21, #0xc7c600        | if (ProtoBuf.BufferPool.pool != null) goto label_4;
            if(val_7 != null)
            {
                goto label_4;
            }
            // 0x00C7C5FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.BufferPool), ????);
            label_4:
            // 0x00C7C600: LDR w8, [x21, #0x18]       | W8 = ProtoBuf.BufferPool.pool.Length;   
            // 0x00C7C604: CMP w20, w8                | STATE = COMPARE(0x0, ProtoBuf.BufferPool.pool.Length)
            // 0x00C7C608: B.GE #0xc7c6c8             | if (val_5 >= ProtoBuf.BufferPool.pool.Length) goto label_5;
            if(val_5 >= ProtoBuf.BufferPool.pool.Length)
            {
                goto label_5;
            }
            // 0x00C7C60C: LDR x0, [x19]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_8 = null;
            // 0x00C7C610: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_10A;
            // 0x00C7C614: TBZ w8, #0, #0xc7c628      | if (ProtoBuf.BufferPool.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00C7C618: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C61C: CBNZ w8, #0xc7c628         | if (ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00C7C620: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C624: LDR x0, [x19]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_8 = null;
            label_7:
            // 0x00C7C628: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.BufferPool.__il2cppRuntimeField_static_fields;
            // 0x00C7C62C: LDR x19, [x8]              | X19 = ProtoBuf.BufferPool.pool;         
            // 0x00C7C630: CBNZ x19, #0xc7c638        | if (ProtoBuf.BufferPool.pool != null) goto label_8;
            if(ProtoBuf.BufferPool.pool != null)
            {
                goto label_8;
            }
            // 0x00C7C634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.BufferPool), ????);
            label_8:
            // 0x00C7C638: LDR w8, [x19, #0x18]       | W8 = ProtoBuf.BufferPool.pool.Length;   
            // 0x00C7C63C: SXTW x21, w20              | X21 = 0 (0x00000000);                   
            val_7 = 0;
            // 0x00C7C640: CMP w20, w8                | STATE = COMPARE(0x0, ProtoBuf.BufferPool.pool.Length)
            // 0x00C7C644: B.LO #0xc7c654             | if (val_5 < ProtoBuf.BufferPool.pool.Length) goto label_9;
            if(val_5 < ProtoBuf.BufferPool.pool.Length)
            {
                goto label_9;
            }
            // 0x00C7C648: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C64C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7C650: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ProtoBuf.BufferPool), ????);
            label_9:
            // 0x00C7C654: ADD x8, x19, x21, lsl #3   |  //  not_find_field:ProtoBuf.BufferPool.pool.0
            // 0x00C7C658: ADD x1, x8, #0x20          | X1 = (ProtoBuf.BufferPool.pool.Length + 32);
            int val_1 = ProtoBuf.BufferPool.pool.Length + 32;
            // 0x00C7C65C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            object val_2 = 0;
            // 0x00C7C660: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7C664: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7C668: BL #0x1b65ad0              | X0 = System.Threading.Interlocked.Exchange(location1: ref  object val_2 = 0, value:  int val_1 = ProtoBuf.BufferPool.pool.Length + 32);
            object val_3 = System.Threading.Interlocked.Exchange(location1: ref  val_2, value:  val_1);
            // 0x00C7C66C: MOV x19, x0                | X19 = val_3;//m1                        
            val_9 = val_3;
            // 0x00C7C670: ADD w20, w20, #1           | W20 = (val_5 + 1);                      
            val_5 = val_5 + 1;
            // 0x00C7C674: CBZ x19, #0xc7c5cc         | if (val_3 == null) goto label_10;       
            if(val_9 == null)
            {
                goto label_10;
            }
            // 0x00C7C678: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00C7C67C: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00C7C680: MOV x0, x19                | X0 = val_3;//m1                         
            val_10 = val_9;
            // 0x00C7C684: LDR x20, [x8]              | X20 = typeof(System.Byte[]);            
            // 0x00C7C688: MOV x1, x20                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C68C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x00C7C690: CBNZ x0, #0xc7c6e8         | if (val_3 != null) goto label_12;       
            if(val_10 != null)
            {
                goto label_12;
            }
            // 0x00C7C694: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x00C7C698: MOV x1, x20                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C69C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00C7C6A0: ADD x8, sp, #8             | X8 = (1152921514335922064 + 8) = 1152921514335922072 (0x1000000243E5E798);
            // 0x00C7C6A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00C7C6A8: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921514335910128]
            // 0x00C7C6AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00C7C6B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7C6B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00C7C6B8: ADD x0, sp, #8             | X0 = (1152921514335922064 + 8) = 1152921514335922072 (0x1000000243E5E798);
            // 0x00C7C6BC: BL #0x299a140              | 
            // 0x00C7C6C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x00C7C6C4: B #0xc7c6e8                |  goto label_12;                         
            goto label_12;
            label_5:
            // 0x00C7C6C8: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00C7C6CC: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00C7C6D0: LDR x19, [x8]              | X19 = typeof(System.Byte[]);            
            val_9 = null;
            // 0x00C7C6D4: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C6D8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00C7C6DC: ORR w1, wzr, #0x400        | W1 = 1024(0x400);                       
            // 0x00C7C6E0: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            val_10 = val_9;
            // 0x00C7C6E4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            label_12:
            // 0x00C7C6E8: SUB sp, x29, #0x20         | SP = (1152921514335922112 - 32) = 1152921514335922080 (0x1000000243E5E7A0);
            // 0x00C7C6EC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C6F0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C6F4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C7C6F8: RET                        |  return (System.Byte[])typeof(System.Byte[]);
            return (System.Byte[])val_10;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
            // 0x00C7C6FC: MOV x19, x0                | 
            // 0x00C7C700: ADD x0, sp, #8             | 
            // 0x00C7C704: BL #0x299a140              | 
            // 0x00C7C708: MOV x0, x19                | 
            // 0x00C7C70C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C710 (13092624), len: 300  VirtAddr: 0x00C7C710 RVA: 0x00C7C710 token: 100689137 methodIndex: 53368 delegateWrapperIndex: 0 methodInvoker: 0
        internal static void ResizeAndFlushLeft(ref byte[] buffer, int toFitAtLeastBytes, int copyFromIndex, int copyBytes)
        {
            //
            // Disasemble & Code
            //  | 
            int val_3;
            // 0x00C7C710: STP x24, x23, [sp, #-0x40]! | stack[1152921514336042192] = ???;  stack[1152921514336042200] = ???;  //  dest_result_addr=1152921514336042192 |  dest_result_addr=1152921514336042200
            // 0x00C7C714: STP x22, x21, [sp, #0x10]  | stack[1152921514336042208] = ???;  stack[1152921514336042216] = ???;  //  dest_result_addr=1152921514336042208 |  dest_result_addr=1152921514336042216
            // 0x00C7C718: STP x20, x19, [sp, #0x20]  | stack[1152921514336042224] = ???;  stack[1152921514336042232] = ???;  //  dest_result_addr=1152921514336042224 |  dest_result_addr=1152921514336042232
            // 0x00C7C71C: STP x29, x30, [sp, #0x30]  | stack[1152921514336042240] = ???;  stack[1152921514336042248] = ???;  //  dest_result_addr=1152921514336042240 |  dest_result_addr=1152921514336042248
            // 0x00C7C720: ADD x29, sp, #0x30         | X29 = (1152921514336042192 + 48) = 1152921514336042240 (0x1000000243E7BD00);
            // 0x00C7C724: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
            // 0x00C7C728: LDRB w8, [x23, #0xf89]     | W8 = (bool)static_value_03733F89;       
            // 0x00C7C72C: MOV w20, w4                | W20 = W4;//m1                           
            // 0x00C7C730: MOV w22, w3                | W22 = copyBytes;//m1                    
            // 0x00C7C734: MOV w21, w2                | W21 = copyFromIndex;//m1                
            // 0x00C7C738: MOV x19, x1                | X19 = toFitAtLeastBytes;//m1            
            // 0x00C7C73C: TBNZ w8, #0, #0xc7c758     | if (static_value_03733F89 == true) goto label_0;
            // 0x00C7C740: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x00C7C744: LDR x8, [x8, #0x6e0]       | X8 = 0x2B8FDD0;                         
            // 0x00C7C748: LDR w0, [x8]               | W0 = 0x1638;                            
            // 0x00C7C74C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1638, ????);     
            // 0x00C7C750: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7C754: STRB w8, [x23, #0xf89]     | static_value_03733F89 = true;            //  dest_result_addr=57884553
            label_0:
            // 0x00C7C758: LDR x23, [x19]             | X23 = toFitAtLeastBytes;                
            // 0x00C7C75C: CBNZ x23, #0xc7c764        | if (toFitAtLeastBytes != 0) goto label_1;
            if(toFitAtLeastBytes != 0)
            {
                goto label_1;
            }
            // 0x00C7C760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1638, ????);     
            label_1:
            // 0x00C7C764: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x00C7C768: LDR w8, [x23, #0x18]       | W8 = toFitAtLeastBytes + 24;            
            var val_3 = toFitAtLeastBytes + 24;
            // 0x00C7C76C: LDR x9, [x9, #0xf00]       | X9 = 1152921504996170800;               
            // 0x00C7C770: LSL w8, w8, #1             | W8 = (toFitAtLeastBytes + 24 << 1);     
            val_3 = val_3 << 1;
            // 0x00C7C774: LDR x23, [x9]              | X23 = typeof(System.Byte[]);            
            val_3 = null;
            // 0x00C7C778: CMP w8, w21                | STATE = COMPARE((toFitAtLeastBytes + 24 << 1), copyFromIndex)
            // 0x00C7C77C: CSEL w21, w21, w8, lt      | W21 = toFitAtLeastBytes + 24 < copyFromIndex ? copyFromIndex : (toFitAtLeastBytes + 24 << 1);
            var val_1 = (val_3 < copyFromIndex) ? (copyFromIndex) : (val_3);
            // 0x00C7C780: MOV x0, x23                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C784: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00C7C788: MOV x0, x23                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C78C: MOV x1, x21                | X1 = toFitAtLeastBytes + 24 < copyFromIndex ? copyFromIndex : (toFitAtLeastBytes + 24 << 1);//m1
            // 0x00C7C790: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00C7C794: MOV x21, x0                | X21 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C798: CMP w20, #1                | STATE = COMPARE(W4, 0x1)                
            // 0x00C7C79C: B.LT #0xc7c7e4             | if (W4 < 0x1) goto label_2;             
            if(W4 < 1)
            {
                goto label_2;
            }
            // 0x00C7C7A0: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00C7C7A4: LDR x8, [x8, #0x2e8]       | X8 = 1152921504881979392;               
            // 0x00C7C7A8: LDR x23, [x19]             | X23 = toFitAtLeastBytes;                
            val_3 = mem[toFitAtLeastBytes];
            val_3 = toFitAtLeastBytes;
            // 0x00C7C7AC: LDR x0, [x8]               | X0 = typeof(ProtoBuf.Helpers);          
            // 0x00C7C7B0: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Helpers.__il2cppRuntimeField_10A;
            // 0x00C7C7B4: TBZ w8, #0, #0xc7c7c4      | if (ProtoBuf.Helpers.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00C7C7B8: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Helpers.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C7BC: CBNZ w8, #0xc7c7c4         | if (ProtoBuf.Helpers.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00C7C7C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Helpers), ????);
            label_4:
            // 0x00C7C7C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7C7C8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00C7C7CC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00C7C7D0: MOV x1, x23                | X1 = toFitAtLeastBytes;//m1             
            // 0x00C7C7D4: MOV w2, w22                | W2 = copyBytes;//m1                     
            // 0x00C7C7D8: MOV x3, x21                | X3 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C7DC: MOV w5, w20                | W5 = W4;//m1                            
            // 0x00C7C7E0: BL #0x18b30e0              | System.Buffer.BlockCopy(src:  0, srcOffset:  val_3, dst:  copyBytes, dstOffset:  389323824, count:  0);
            System.Buffer.BlockCopy(src:  0, srcOffset:  val_3, dst:  copyBytes, dstOffset:  389323824, count:  0);
            label_2:
            // 0x00C7C7E4: LDR x20, [x19]             | X20 = toFitAtLeastBytes;                
            // 0x00C7C7E8: CBNZ x20, #0xc7c7f0        | if (toFitAtLeastBytes != 0) goto label_5;
            if(toFitAtLeastBytes != 0)
            {
                goto label_5;
            }
            // 0x00C7C7EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_5:
            // 0x00C7C7F0: LDR w8, [x20, #0x18]       | W8 = toFitAtLeastBytes + 24;            
            // 0x00C7C7F4: CMP w8, #0x400             | STATE = COMPARE(toFitAtLeastBytes + 24, 0x400)
            // 0x00C7C7F8: B.NE #0xc7c824             | if (toFitAtLeastBytes + 24 != 0x400) goto label_6;
            if((toFitAtLeastBytes + 24) != 1024)
            {
                goto label_6;
            }
            // 0x00C7C7FC: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00C7C800: LDR x8, [x8, #0x1c8]       | X8 = 1152921504881446912;               
            // 0x00C7C804: LDR x0, [x8]               | X0 = typeof(ProtoBuf.BufferPool);       
            System.Byte[] val_2 = null;
            // 0x00C7C808: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_10A;
            // 0x00C7C80C: TBZ w8, #0, #0xc7c81c      | if (ProtoBuf.BufferPool.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00C7C810: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C814: CBNZ w8, #0xc7c81c         | if (ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00C7C818: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BufferPool), ????);
            label_8:
            // 0x00C7C81C: MOV x1, x19                | X1 = toFitAtLeastBytes;//m1             
            // 0x00C7C820: BL #0xc7c83c               | ProtoBuf.BufferPool.ReleaseBufferToPool(buffer: ref  System.Byte[] val_2 = null);
            ProtoBuf.BufferPool.ReleaseBufferToPool(buffer: ref  val_2);
            label_6:
            // 0x00C7C824: STR x21, [x19]             | mem2[0] = typeof(System.Byte[]);         //  dest_result_addr=0
            mem2[0] = val_3;
            // 0x00C7C828: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C82C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C830: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7C834: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00C7C838: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C83C (13092924), len: 284  VirtAddr: 0x00C7C83C RVA: 0x00C7C83C token: 100689138 methodIndex: 53369 delegateWrapperIndex: 0 methodInvoker: 0
        internal static void ReleaseBufferToPool(ref byte[] buffer)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x00C7C83C: STP x24, x23, [sp, #-0x40]! | stack[1152921514336166336] = ???;  stack[1152921514336166344] = ???;  //  dest_result_addr=1152921514336166336 |  dest_result_addr=1152921514336166344
            // 0x00C7C840: STP x22, x21, [sp, #0x10]  | stack[1152921514336166352] = ???;  stack[1152921514336166360] = ???;  //  dest_result_addr=1152921514336166352 |  dest_result_addr=1152921514336166360
            // 0x00C7C844: STP x20, x19, [sp, #0x20]  | stack[1152921514336166368] = ???;  stack[1152921514336166376] = ???;  //  dest_result_addr=1152921514336166368 |  dest_result_addr=1152921514336166376
            // 0x00C7C848: STP x29, x30, [sp, #0x30]  | stack[1152921514336166384] = ???;  stack[1152921514336166392] = ???;  //  dest_result_addr=1152921514336166384 |  dest_result_addr=1152921514336166392
            // 0x00C7C84C: ADD x29, sp, #0x30         | X29 = (1152921514336166336 + 48) = 1152921514336166384 (0x1000000243E9A1F0);
            // 0x00C7C850: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7C854: LDRB w8, [x20, #0xf8a]     | W8 = (bool)static_value_03733F8A;       
            // 0x00C7C858: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00C7C85C: TBNZ w8, #0, #0xc7c878     | if (static_value_03733F8A == true) goto label_0;
            // 0x00C7C860: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x00C7C864: LDR x8, [x8, #0x318]       | X8 = 0x2B8FDCC;                         
            // 0x00C7C868: LDR w0, [x8]               | W0 = 0x1637;                            
            // 0x00C7C86C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1637, ????);     
            // 0x00C7C870: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7C874: STRB w8, [x20, #0xf8a]     | static_value_03733F8A = true;            //  dest_result_addr=57884554
            label_0:
            // 0x00C7C878: LDR x8, [x19]              | X8 = X1;                                
            // 0x00C7C87C: CBZ x8, #0xc7c944          | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00C7C880: LDR w8, [x8, #0x18]        | W8 = X1 + 24;                           
            // 0x00C7C884: CMP w8, #0x400             | STATE = COMPARE(X1 + 24, 0x400)         
            // 0x00C7C888: B.NE #0xc7c940             | if (X1 + 24 != 0x400) goto label_6;     
            if((X1 + 24) != 1024)
            {
                goto label_6;
            }
            // 0x00C7C88C: ADRP x22, #0x35db000       | X22 = 56471552 (0x35DB000);             
            // 0x00C7C890: LDR x22, [x22, #0x1c8]     | X22 = 1152921504881446912;              
            // 0x00C7C894: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_4 = 0;
            label_11:
            // 0x00C7C898: LDR x0, [x22]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_5 = null;
            // 0x00C7C89C: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_10A;
            // 0x00C7C8A0: TBZ w8, #0, #0xc7c8b4      | if (ProtoBuf.BufferPool.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00C7C8A4: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C8A8: CBNZ w8, #0xc7c8b4         | if (ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00C7C8AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C8B0: LDR x0, [x22]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_5 = null;
            label_4:
            // 0x00C7C8B4: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.BufferPool.__il2cppRuntimeField_static_fields;
            // 0x00C7C8B8: LDR x20, [x8]              | X20 = ProtoBuf.BufferPool.pool;         
            // 0x00C7C8BC: CBNZ x20, #0xc7c8c4        | if (ProtoBuf.BufferPool.pool != null) goto label_5;
            if(ProtoBuf.BufferPool.pool != null)
            {
                goto label_5;
            }
            // 0x00C7C8C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.BufferPool), ????);
            label_5:
            // 0x00C7C8C4: LDR w8, [x20, #0x18]       | W8 = ProtoBuf.BufferPool.pool.Length;   
            // 0x00C7C8C8: CMP w21, w8                | STATE = COMPARE(0x0, ProtoBuf.BufferPool.pool.Length)
            // 0x00C7C8CC: B.GE #0xc7c940             | if (val_4 >= ProtoBuf.BufferPool.pool.Length) goto label_6;
            if(val_4 >= ProtoBuf.BufferPool.pool.Length)
            {
                goto label_6;
            }
            // 0x00C7C8D0: LDR x0, [x22]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_6 = null;
            // 0x00C7C8D4: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_10A;
            // 0x00C7C8D8: TBZ w8, #0, #0xc7c8ec      | if (ProtoBuf.BufferPool.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00C7C8DC: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C8E0: CBNZ w8, #0xc7c8ec         | if (ProtoBuf.BufferPool.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00C7C8E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C8E8: LDR x0, [x22]              | X0 = typeof(ProtoBuf.BufferPool);       
            val_6 = null;
            label_8:
            // 0x00C7C8EC: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.BufferPool.__il2cppRuntimeField_static_fields;
            // 0x00C7C8F0: LDR x23, [x8]              | X23 = ProtoBuf.BufferPool.pool;         
            // 0x00C7C8F4: CBNZ x23, #0xc7c8fc        | if (ProtoBuf.BufferPool.pool != null) goto label_9;
            if(ProtoBuf.BufferPool.pool != null)
            {
                goto label_9;
            }
            // 0x00C7C8F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.BufferPool), ????);
            label_9:
            // 0x00C7C8FC: LDR w8, [x23, #0x18]       | W8 = ProtoBuf.BufferPool.pool.Length;   
            // 0x00C7C900: LDR x20, [x19]             | X20 = X1;                               
            // 0x00C7C904: SXTW x24, w21              | X24 = 0 (0x00000000);                   
            // 0x00C7C908: CMP w21, w8                | STATE = COMPARE(0x0, ProtoBuf.BufferPool.pool.Length)
            // 0x00C7C90C: B.LO #0xc7c91c             | if (val_4 < ProtoBuf.BufferPool.pool.Length) goto label_10;
            if(val_4 < ProtoBuf.BufferPool.pool.Length)
            {
                goto label_10;
            }
            // 0x00C7C910: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ProtoBuf.BufferPool), ????);
            // 0x00C7C914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7C918: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ProtoBuf.BufferPool), ????);
            label_10:
            // 0x00C7C91C: ADD x8, x23, x24, lsl #3   |  //  not_find_field:ProtoBuf.BufferPool.pool.0
            // 0x00C7C920: ADD x1, x8, #0x20          | X1 = (ProtoBuf.BufferPool.pool.Length + 32);
            int val_1 = ProtoBuf.BufferPool.pool.Length + 32;
            // 0x00C7C924: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            object val_2 = 0;
            // 0x00C7C928: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7C92C: MOV x2, x20                | X2 = X1;//m1                            
            // 0x00C7C930: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7C934: BL #0x1b65ab0              | X0 = System.Threading.Interlocked.CompareExchange(location1: ref  object val_2 = 0, value:  int val_1 = ProtoBuf.BufferPool.pool.Length + 32, comparand:  X1);
            object val_3 = System.Threading.Interlocked.CompareExchange(location1: ref  val_2, value:  val_1, comparand:  X1);
            // 0x00C7C938: ADD w21, w21, #1           | W21 = (val_4 + 1);                      
            val_4 = val_4 + 1;
            // 0x00C7C93C: CBNZ x0, #0xc7c898         | if (val_3 != null) goto label_11;       
            if(val_3 != null)
            {
                goto label_11;
            }
            label_6:
            // 0x00C7C940: STR xzr, [x19]             | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            label_1:
            // 0x00C7C944: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C948: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C94C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7C950: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00C7C954: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C958 (13093208), len: 112  VirtAddr: 0x00C7C958 RVA: 0x00C7C958 token: 100689139 methodIndex: 53370 delegateWrapperIndex: 0 methodInvoker: 0
        private static BufferPool()
        {
            //
            // Disasemble & Code
            // 0x00C7C958: STP x20, x19, [sp, #-0x20]! | stack[1152921514336286480] = ???;  stack[1152921514336286488] = ???;  //  dest_result_addr=1152921514336286480 |  dest_result_addr=1152921514336286488
            // 0x00C7C95C: STP x29, x30, [sp, #0x10]  | stack[1152921514336286496] = ???;  stack[1152921514336286504] = ???;  //  dest_result_addr=1152921514336286496 |  dest_result_addr=1152921514336286504
            // 0x00C7C960: ADD x29, sp, #0x10         | X29 = (1152921514336286480 + 16) = 1152921514336286496 (0x1000000243EB7720);
            // 0x00C7C964: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00C7C968: LDRB w8, [x19, #0xf8b]     | W8 = (bool)static_value_03733F8B;       
            // 0x00C7C96C: TBNZ w8, #0, #0xc7c988     | if (static_value_03733F8B == true) goto label_0;
            // 0x00C7C970: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00C7C974: LDR x8, [x8, #0xa60]       | X8 = 0x2B8FDC0;                         
            // 0x00C7C978: LDR w0, [x8]               | W0 = 0x1634;                            
            // 0x00C7C97C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1634, ????);     
            // 0x00C7C980: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7C984: STRB w8, [x19, #0xf8b]     | static_value_03733F8B = true;            //  dest_result_addr=57884555
            label_0:
            // 0x00C7C988: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00C7C98C: LDR x8, [x8, #0x1c8]       | X8 = 1152921504881446912;               
            // 0x00C7C990: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x00C7C994: LDR x8, [x8]               | X8 = typeof(ProtoBuf.BufferPool);       
            // 0x00C7C998: LDR x9, [x9, #0x3d0]       | X9 = 1152921504954501264;               
            // 0x00C7C99C: LDR x20, [x8, #0xa0]       | X20 = ProtoBuf.BufferPool.__il2cppRuntimeField_static_fields;
            // 0x00C7C9A0: LDR x19, [x9]              | X19 = typeof(System.Object[]);          
            // 0x00C7C9A4: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00C7C9A8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00C7C9AC: MOVZ w1, #0x14             | W1 = 20 (0x14);//ML01                   
            // 0x00C7C9B0: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00C7C9B4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00C7C9B8: STR x0, [x20]              | ProtoBuf.BufferPool.pool = typeof(System.Object[]);  //  dest_result_addr=1152921504881451008
            ProtoBuf.BufferPool.pool = null;
            // 0x00C7C9BC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C9C0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C9C4: RET                        |  return;                                
            return;
        
        }
    
    }

}
