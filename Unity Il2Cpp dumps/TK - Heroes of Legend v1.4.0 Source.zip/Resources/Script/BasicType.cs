using UnityEngine;
private sealed class RuntimeTypeModel.BasicType
{
    // Fields
    private readonly System.Type type; //  0x00000010
    private readonly ProtoBuf.Serializers.IProtoSerializer serializer; //  0x00000018
    
    // Properties
    public System.Type Type { get; }
    public ProtoBuf.Serializers.IProtoSerializer Serializer { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02973A8C (43465356), len: 56  VirtAddr: 0x02973A8C RVA: 0x02973A8C token: 100689409 methodIndex: 53630 delegateWrapperIndex: 0 methodInvoker: 0
    public RuntimeTypeModel.BasicType(System.Type type, ProtoBuf.Serializers.IProtoSerializer serializer)
    {
        //
        // Disasemble & Code
        // 0x02973A8C: STP x22, x21, [sp, #-0x30]! | stack[1152921514379995648] = ???;  stack[1152921514379995656] = ???;  //  dest_result_addr=1152921514379995648 |  dest_result_addr=1152921514379995656
        // 0x02973A90: STP x20, x19, [sp, #0x10]  | stack[1152921514379995664] = ???;  stack[1152921514379995672] = ???;  //  dest_result_addr=1152921514379995664 |  dest_result_addr=1152921514379995672
        // 0x02973A94: STP x29, x30, [sp, #0x20]  | stack[1152921514379995680] = ???;  stack[1152921514379995688] = ???;  //  dest_result_addr=1152921514379995680 |  dest_result_addr=1152921514379995688
        // 0x02973A98: ADD x29, sp, #0x20         | X29 = (1152921514379995648 + 32) = 1152921514379995680 (0x1000000246866A20);
        // 0x02973A9C: MOV x20, x1                | X20 = type;//m1                         
        // 0x02973AA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02973AA4: MOV x19, x2                | X19 = serializer;//m1                   
        // 0x02973AA8: MOV x21, x0                | X21 = 1152921514380007696 (0x1000000246869910);//ML01
        // 0x02973AAC: BL #0x16f59f0              | this..ctor();                           
        // 0x02973AB0: STP x20, x19, [x21, #0x10] | this.type = type;  this.serializer = serializer;  //  dest_result_addr=1152921514380007712 |  dest_result_addr=1152921514380007720
        this.type = type;
        this.serializer = serializer;
        // 0x02973AB4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02973AB8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02973ABC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02973AC0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02973460 (43463776), len: 8  VirtAddr: 0x02973460 RVA: 0x02973460 token: 100689410 methodIndex: 53631 delegateWrapperIndex: 0 methodInvoker: 0
    public System.Type get_Type()
    {
        //
        // Disasemble & Code
        // 0x02973460: LDR x0, [x0, #0x10]        | X0 = this.type; //P2                    
        // 0x02973464: RET                        |  return (System.Type)this.type;         
        return this.type;
        //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02973A84 (43465348), len: 8  VirtAddr: 0x02973A84 RVA: 0x02973A84 token: 100689411 methodIndex: 53632 delegateWrapperIndex: 0 methodInvoker: 0
    public ProtoBuf.Serializers.IProtoSerializer get_Serializer()
    {
        //
        // Disasemble & Code
        // 0x02973A84: LDR x0, [x0, #0x18]        | X0 = this.serializer; //P2              
        // 0x02973A88: RET                        |  return (ProtoBuf.Serializers.IProtoSerializer)this.serializer;
        return this.serializer;
        //  |  // // {name=val_0, type=ProtoBuf.Serializers.IProtoSerializer, size=8, nGRN=0 }
    
    }

}
