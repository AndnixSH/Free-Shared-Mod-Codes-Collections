using UnityEngine;

namespace Pathfinding
{
    public enum ColliderType
    {
        // Fields
        Sphere = 0
        ,Capsule = 1
        ,Ray = 2
        
    
    }

}
