using UnityEngine;

namespace SevenZip.CommandLineParser
{
    public class CommandForm
    {
        // Fields
        public string IDString; //  0x00000010
        public bool PostStringMode; //  0x00000018
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00CA77E0 (13268960), len: 152  VirtAddr: 0x00CA77E0 RVA: 0x00CA77E0 token: 100681421 methodIndex: 54572 delegateWrapperIndex: 0 methodInvoker: 0
        public CommandForm(string idString, bool postStringMode)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x00CA77E0: STP x22, x21, [sp, #-0x30]! | stack[1152921513058857472] = ???;  stack[1152921513058857480] = ???;  //  dest_result_addr=1152921513058857472 |  dest_result_addr=1152921513058857480
            // 0x00CA77E4: STP x20, x19, [sp, #0x10]  | stack[1152921513058857488] = ???;  stack[1152921513058857496] = ???;  //  dest_result_addr=1152921513058857488 |  dest_result_addr=1152921513058857496
            // 0x00CA77E8: STP x29, x30, [sp, #0x20]  | stack[1152921513058857504] = ???;  stack[1152921513058857512] = ???;  //  dest_result_addr=1152921513058857504 |  dest_result_addr=1152921513058857512
            // 0x00CA77EC: ADD x29, sp, #0x20         | X29 = (1152921513058857472 + 32) = 1152921513058857504 (0x10000001F7C77220);
            // 0x00CA77F0: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00CA77F4: LDRB w8, [x22, #0xa8]      | W8 = (bool)static_value_037340A8;       
            // 0x00CA77F8: MOV w19, w2                | W19 = postStringMode;//m1               
            // 0x00CA77FC: MOV x20, x1                | X20 = idString;//m1                     
            // 0x00CA7800: MOV x21, x0                | X21 = 1152921513058869520 (0x10000001F7C7A110);//ML01
            // 0x00CA7804: TBNZ w8, #0, #0xca7820     | if (static_value_037340A8 == true) goto label_0;
            // 0x00CA7808: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x00CA780C: LDR x8, [x8, #0xc60]       | X8 = 0x2B9235C;                         
            // 0x00CA7810: LDR w0, [x8]               | W0 = 0x1F9C;                            
            // 0x00CA7814: BL #0x2782188              | X0 = sub_2782188( ?? 0x1F9C, ????);     
            // 0x00CA7818: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA781C: STRB w8, [x22, #0xa8]      | static_value_037340A8 = true;            //  dest_result_addr=57884840
            label_0:
            // 0x00CA7820: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
            // 0x00CA7824: LDR x22, [x22, #0xe38]     | X22 = 1152921504608284672;              
            // 0x00CA7828: LDR x0, [x22]              | X0 = typeof(System.String);             
            val_2 = null;
            // 0x00CA782C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00CA7830: TBZ w8, #0, #0xca7844      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00CA7834: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00CA7838: CBNZ w8, #0xca7844         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00CA783C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00CA7840: LDR x0, [x22]              | X0 = typeof(System.String);             
            val_2 = null;
            label_2:
            // 0x00CA7844: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00CA7848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA784C: MOV x0, x21                | X0 = 1152921513058869520 (0x10000001F7C7A110);//ML01
            // 0x00CA7850: LDR x8, [x8]               | X8 = System.String.Empty;               
            // 0x00CA7854: STR x8, [x21, #0x10]       | this.IDString = System.String.Empty;     //  dest_result_addr=1152921513058869536
            this.IDString = System.String.Empty;
            // 0x00CA7858: BL #0x16f59f0              | this..ctor();                           
            // 0x00CA785C: AND w8, w19, #1            | W8 = (postStringMode & 1);              
            bool val_1 = postStringMode;
            // 0x00CA7860: STRB w8, [x21, #0x18]      | this.PostStringMode = (postStringMode & 1);  //  dest_result_addr=1152921513058869544
            this.PostStringMode = val_1;
            // 0x00CA7864: STR x20, [x21, #0x10]      | this.IDString = idString;                //  dest_result_addr=1152921513058869536
            this.IDString = idString;
            // 0x00CA7868: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA786C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00CA7870: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00CA7874: RET                        |  return;                                
            return;
        
        }
    
    }

}
