using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286D600
[Serializable]
public class CameraShotActionCfg : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private int _heroOrNpcId; //  0x00000014
    private int _isHero; //  0x00000018
    private string _actionName; //  0x00000020
    private float _actionTime; //  0x00000028
    private int _isLoop; //  0x0000002C
    private ProtoBuf.IExtension extensionObject; //  0x00000030
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286D644
    [System.ComponentModel.DefaultValueAttribute] // 0x286D644
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D6C4
    [System.ComponentModel.DefaultValueAttribute] // 0x286D6C4
    public int heroOrNpcId { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D744
    [System.ComponentModel.DefaultValueAttribute] // 0x286D744
    public int isHero { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D7C4
    [System.ComponentModel.DefaultValueAttribute] // 0x286D7C4
    public string actionName { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D854
    [System.ComponentModel.DefaultValueAttribute] // 0x286D854
    public float actionTime { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D8D4
    [System.ComponentModel.DefaultValueAttribute] // 0x286D8D4
    public int isLoop { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BAD698 (12244632), len: 120  VirtAddr: 0x00BAD698 RVA: 0x00BAD698 token: 100690420 methodIndex: 25709 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotActionCfg()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00BAD698: STP x20, x19, [sp, #-0x20]! | stack[1152921514519153312] = ???;  stack[1152921514519153320] = ???;  //  dest_result_addr=1152921514519153312 |  dest_result_addr=1152921514519153320
        // 0x00BAD69C: STP x29, x30, [sp, #0x10]  | stack[1152921514519153328] = ???;  stack[1152921514519153336] = ???;  //  dest_result_addr=1152921514519153328 |  dest_result_addr=1152921514519153336
        // 0x00BAD6A0: ADD x29, sp, #0x10         | X29 = (1152921514519153312 + 16) = 1152921514519153328 (0x100000024ED1CAB0);
        // 0x00BAD6A4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAD6A8: LDRB w8, [x20, #0xb08]     | W8 = (bool)static_value_03733B08;       
        // 0x00BAD6AC: MOV x19, x0                | X19 = 1152921514519165344 (0x100000024ED1F9A0);//ML01
        // 0x00BAD6B0: TBNZ w8, #0, #0xbad6cc     | if (static_value_03733B08 == true) goto label_0;
        // 0x00BAD6B4: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x00BAD6B8: LDR x8, [x8, #0x570]       | X8 = 0x2B90260;                         
        // 0x00BAD6BC: LDR w0, [x8]               | W0 = 0x175C;                            
        // 0x00BAD6C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x175C, ????);     
        // 0x00BAD6C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAD6C8: STRB w8, [x20, #0xb08]     | static_value_03733B08 = true;            //  dest_result_addr=57883400
        label_0:
        // 0x00BAD6CC: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x00BAD6D0: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x00BAD6D4: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_1 = null;
        // 0x00BAD6D8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00BAD6DC: TBZ w8, #0, #0xbad6f0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BAD6E0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00BAD6E4: CBNZ w8, #0xbad6f0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BAD6E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00BAD6EC: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_1 = null;
        label_2:
        // 0x00BAD6F0: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00BAD6F4: MOV x0, x19                | X0 = 1152921514519165344 (0x100000024ED1F9A0);//ML01
        // 0x00BAD6F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD6FC: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x00BAD700: STR x8, [x19, #0x20]       | this._actionName = System.String.Empty;  //  dest_result_addr=1152921514519165376
        this._actionName = System.String.Empty;
        // 0x00BAD704: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAD708: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BAD70C: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD710 (12244752), len: 8  VirtAddr: 0x00BAD710 RVA: 0x00BAD710 token: 100690421 methodIndex: 25710 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00BAD710: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00BAD714: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD718 (12244760), len: 8  VirtAddr: 0x00BAD718 RVA: 0x00BAD718 token: 100690422 methodIndex: 25711 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00BAD718: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514519389360
        this._id = value;
        // 0x00BAD71C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD720 (12244768), len: 8  VirtAddr: 0x00BAD720 RVA: 0x00BAD720 token: 100690423 methodIndex: 25712 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_heroOrNpcId()
    {
        //
        // Disasemble & Code
        // 0x00BAD720: LDR w0, [x0, #0x14]        | W0 = this._heroOrNpcId; //P2            
        // 0x00BAD724: RET                        |  return (System.Int32)this._heroOrNpcId;
        return this._heroOrNpcId;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD728 (12244776), len: 8  VirtAddr: 0x00BAD728 RVA: 0x00BAD728 token: 100690424 methodIndex: 25713 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_heroOrNpcId(int value)
    {
        //
        // Disasemble & Code
        // 0x00BAD728: STR w1, [x0, #0x14]        | this._heroOrNpcId = value;               //  dest_result_addr=1152921514519613364
        this._heroOrNpcId = value;
        // 0x00BAD72C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD730 (12244784), len: 8  VirtAddr: 0x00BAD730 RVA: 0x00BAD730 token: 100690425 methodIndex: 25714 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isHero()
    {
        //
        // Disasemble & Code
        // 0x00BAD730: LDR w0, [x0, #0x18]        | W0 = this._isHero; //P2                 
        // 0x00BAD734: RET                        |  return (System.Int32)this._isHero;     
        return this._isHero;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD738 (12244792), len: 8  VirtAddr: 0x00BAD738 RVA: 0x00BAD738 token: 100690426 methodIndex: 25715 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isHero(int value)
    {
        //
        // Disasemble & Code
        // 0x00BAD738: STR w1, [x0, #0x18]        | this._isHero = value;                    //  dest_result_addr=1152921514519837368
        this._isHero = value;
        // 0x00BAD73C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD740 (12244800), len: 8  VirtAddr: 0x00BAD740 RVA: 0x00BAD740 token: 100690427 methodIndex: 25716 delegateWrapperIndex: 0 methodInvoker: 0
    public string get_actionName()
    {
        //
        // Disasemble & Code
        // 0x00BAD740: LDR x0, [x0, #0x20]        | X0 = this._actionName; //P2             
        // 0x00BAD744: RET                        |  return (System.String)this._actionName;
        return this._actionName;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD748 (12244808), len: 8  VirtAddr: 0x00BAD748 RVA: 0x00BAD748 token: 100690428 methodIndex: 25717 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_actionName(string value)
    {
        //
        // Disasemble & Code
        // 0x00BAD748: STR x1, [x0, #0x20]        | this._actionName = value;                //  dest_result_addr=1152921514520073664
        this._actionName = value;
        // 0x00BAD74C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD750 (12244816), len: 8  VirtAddr: 0x00BAD750 RVA: 0x00BAD750 token: 100690429 methodIndex: 25718 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_actionTime()
    {
        //
        // Disasemble & Code
        // 0x00BAD750: LDR s0, [x0, #0x28]        | S0 = this._actionTime; //P2             
        // 0x00BAD754: RET                        |  return (System.Single)this._actionTime;
        return this._actionTime;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD758 (12244824), len: 8  VirtAddr: 0x00BAD758 RVA: 0x00BAD758 token: 100690430 methodIndex: 25719 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_actionTime(float value)
    {
        //
        // Disasemble & Code
        // 0x00BAD758: STR s0, [x0, #0x28]        | this._actionTime = value;                //  dest_result_addr=1152921514520301768
        this._actionTime = value;
        // 0x00BAD75C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD760 (12244832), len: 8  VirtAddr: 0x00BAD760 RVA: 0x00BAD760 token: 100690431 methodIndex: 25720 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isLoop()
    {
        //
        // Disasemble & Code
        // 0x00BAD760: LDR w0, [x0, #0x2c]        | W0 = this._isLoop; //P2                 
        // 0x00BAD764: RET                        |  return (System.Int32)this._isLoop;     
        return this._isLoop;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD768 (12244840), len: 8  VirtAddr: 0x00BAD768 RVA: 0x00BAD768 token: 100690432 methodIndex: 25721 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isLoop(int value)
    {
        //
        // Disasemble & Code
        // 0x00BAD768: STR w1, [x0, #0x2c]        | this._isLoop = value;                    //  dest_result_addr=1152921514520525772
        this._isLoop = value;
        // 0x00BAD76C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD770 (12244848), len: 24  VirtAddr: 0x00BAD770 RVA: 0x00BAD770 token: 100690433 methodIndex: 25722 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00BAD770: ADD x8, x0, #0x30          | X8 = this.extensionObject;//AP2 res_addr=1152921514520637776
        // 0x00BAD774: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00BAD778: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00BAD77C: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00BAD780: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAD784: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
