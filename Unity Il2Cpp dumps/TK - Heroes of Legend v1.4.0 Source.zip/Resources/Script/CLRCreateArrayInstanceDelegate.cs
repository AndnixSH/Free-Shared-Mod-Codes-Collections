using UnityEngine;

namespace ILRuntime.Runtime.Enviorment
{
    public sealed class CLRCreateArrayInstanceDelegate : MulticastDelegate
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x028E8AC8 (42896072), len: 16  VirtAddr: 0x028E8AC8 RVA: 0x028E8AC8 token: 100680204 methodIndex: 29531 delegateWrapperIndex: 0 methodInvoker: 0
        public CLRCreateArrayInstanceDelegate(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x028E8AC8: LDR x8, [x2]               | X8 = method;                            
            // 0x028E8ACC: STP x1, x2, [x0, #0x20]    | mem[1152921512877672288] = object;  mem[1152921512877672296] = method;  //  dest_result_addr=1152921512877672288 |  dest_result_addr=1152921512877672296
            mem[1152921512877672288] = object;
            mem[1152921512877672296] = method;
            // 0x028E8AD0: STR x8, [x0, #0x10]        | mem[1152921512877672272] = method;       //  dest_result_addr=1152921512877672272
            mem[1152921512877672272] = method;
            // 0x028E8AD4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E8AD8 (42896088), len: 528  VirtAddr: 0x028E8AD8 RVA: 0x028E8AD8 token: 100680205 methodIndex: 29532 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual object Invoke(int size)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            label_1:
            // 0x028E8AD8: STP x22, x21, [sp, #-0x30]! | stack[1152921512877784496] = ???;  stack[1152921512877784504] = ???;  //  dest_result_addr=1152921512877784496 |  dest_result_addr=1152921512877784504
            // 0x028E8ADC: STP x20, x19, [sp, #0x10]  | stack[1152921512877784512] = ???;  stack[1152921512877784520] = ???;  //  dest_result_addr=1152921512877784512 |  dest_result_addr=1152921512877784520
            // 0x028E8AE0: STP x29, x30, [sp, #0x20]  | stack[1152921512877784528] = ???;  stack[1152921512877784536] = ???;  //  dest_result_addr=1152921512877784528 |  dest_result_addr=1152921512877784536
            // 0x028E8AE4: ADD x29, sp, #0x20         | X29 = (1152921512877784496 + 32) = 1152921512877784528 (0x10000001ECFC7DD0);
            // 0x028E8AE8: SUB sp, sp, #0x10          | SP = (1152921512877784496 - 16) = 1152921512877784480 (0x10000001ECFC7DA0);
            // 0x028E8AEC: MOV x22, x0                | X22 = 1152921512877796544 (0x10000001ECFCACC0);//ML01
            // 0x028E8AF0: LDR x0, [x22, #0x58]       | 
            // 0x028E8AF4: MOV w19, w1                | W19 = size;//m1                         
            // 0x028E8AF8: CBZ x0, #0x28e8b04         | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x028E8AFC: MOV w1, w19                | W1 = size;//m1                          
            // 0x028E8B00: BL #0x28e8ad8              |  R0 = label_1();                        
            label_0:
            // 0x028E8B04: LDR x0, [x22, #0x10]       | 
            // 0x028E8B08: STR x0, [sp, #8]           | stack[1152921512877784488] = this;       //  dest_result_addr=1152921512877784488
            // 0x028E8B0C: LDP x20, x21, [x22, #0x20] |                                          //  | 
            // 0x028E8B10: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E8B14: BL #0x2796f94              | X0 = sub_2796F94( ?? X21, ????);        
            // 0x028E8B18: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E8B1C: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X21, ????);        
            // 0x028E8B20: AND w8, w0, #1             | W8 = (X21 & 1);                         
            var val_1 = X21 & 1;
            // 0x028E8B24: TBZ w8, #0, #0x28e8bb4     | if (((X21 & 1) & 0x1) == 0) goto label_2;
            if((val_1 & 1) == 0)
            {
                goto label_2;
            }
            // 0x028E8B28: LDRSH w8, [x21, #0x4c]     | W8 = X21 + 76;                          
            // 0x028E8B2C: CMN w8, #1                 | STATE = COMPARE(X21 + 76, 0x1)          
            // 0x028E8B30: B.EQ #0x28e8bc8            | if (X21 + 76 == 0x1) goto label_6;      
            if((X21 + 76) == 1)
            {
                goto label_6;
            }
            // 0x028E8B34: CBZ x20, #0x28e8b44        | if (X20 == 0) goto label_4;             
            if(X20 == 0)
            {
                goto label_4;
            }
            // 0x028E8B38: LDR x8, [x20]              | X8 = X20;                               
            // 0x028E8B3C: LDRB w8, [x8, #0xed]       | W8 = X20 + 237;                         
            // 0x028E8B40: TBNZ w8, #0, #0x28e8bc8    | if ((X20 + 237 & 0x1) != 0) goto label_6;
            if(((X20 + 237) & 1) != 0)
            {
                goto label_6;
            }
            label_4:
            // 0x028E8B44: LDR x8, [x22, #0x18]       | 
            // 0x028E8B48: CBZ x8, #0x28e8bc8         | if (X20 + 237 == 0) goto label_6;       
            if((X20 + 237) == 0)
            {
                goto label_6;
            }
            // 0x028E8B4C: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E8B50: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
            // 0x028E8B54: MOV w22, w0                | W22 = X21;//m1                          
            // 0x028E8B58: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E8B5C: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_2 = X21.pressedSprite;
            // 0x028E8B60: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
            // 0x028E8B64: TBZ w22, #0, #0x28e8c14    | if ((X21 & 0x1) == 0) goto label_7;     
            if((X21 & 1) == 0)
            {
                goto label_7;
            }
            // 0x028E8B68: TBZ w0, #0, #0x28e8c70     | if ((val_2 & 0x1) == 0) goto label_8;   
            if((val_2 & 1) == 0)
            {
                goto label_8;
            }
            // 0x028E8B6C: LDR x8, [x20]              | X8 = X20;                               
            var val_11 = X20;
            // 0x028E8B70: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
            // 0x028E8B74: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
            // 0x028E8B78: LDRH w9, [x8, #0x102]      | W9 = X20 + 258;                         
            // 0x028E8B7C: CBZ x9, #0x28e8ba8         | if (X20 + 258 == 0) goto label_9;       
            if((X20 + 258) == 0)
            {
                goto label_9;
            }
            // 0x028E8B80: LDR x10, [x8, #0x98]       | X10 = X20 + 152;                        
            var val_5 = X20 + 152;
            // 0x028E8B84: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x028E8B88: ADD x10, x10, #8           | X10 = (X20 + 152 + 8);                  
            val_5 = val_5 + 8;
            label_11:
            // 0x028E8B8C: LDUR x12, [x10, #-8]       | X12 = (X20 + 152 + 8) + -8;             
            // 0x028E8B90: CMP x12, x1                | STATE = COMPARE((X20 + 152 + 8) + -8, X21 + 24)
            // 0x028E8B94: B.EQ #0x28e8c94            | if ((X20 + 152 + 8) + -8 == X21 + 24) goto label_10;
            if(((X20 + 152 + 8) + -8) == (X21 + 24))
            {
                goto label_10;
            }
            // 0x028E8B98: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x028E8B9C: ADD x10, x10, #0x10        | X10 = ((X20 + 152 + 8) + 16);           
            val_5 = val_5 + 16;
            // 0x028E8BA0: CMP x11, x9                | STATE = COMPARE((0 + 1), X20 + 258)     
            // 0x028E8BA4: B.LO #0x28e8b8c            | if (0 < X20 + 258) goto label_11;       
            if(val_6 < (X20 + 258))
            {
                goto label_11;
            }
            label_9:
            // 0x028E8BA8: MOV x0, x20                | X0 = X20;//m1                           
            val_7 = X20;
            // 0x028E8BAC: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
            // 0x028E8BB0: B #0x28e8ca4               |  goto label_12;                         
            goto label_12;
            label_2:
            // 0x028E8BB4: LDRB w8, [x21, #0x4e]      | W8 = X21 + 78;                          
            // 0x028E8BB8: CMP w8, #1                 | STATE = COMPARE(X21 + 78, 0x1)          
            // 0x028E8BBC: B.NE #0x28e8bec            | if (X21 + 78 != 0x1) goto label_13;     
            if((X21 + 78) != 1)
            {
                goto label_13;
            }
            // 0x028E8BC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E8BC4: B #0x28e8bcc               |  goto label_14;                         
            goto label_14;
            label_6:
            // 0x028E8BC8: MOV x0, x20                | X0 = X20;//m1                           
            label_14:
            // 0x028E8BCC: LDR x3, [sp, #8]           | X3 = this;                              
            // 0x028E8BD0: MOV w1, w19                | W1 = size;//m1                          
            // 0x028E8BD4: MOV x2, x21                | X2 = X21;//m1                           
            label_23:
            // 0x028E8BD8: SUB sp, x29, #0x20         | SP = (1152921512877784528 - 32) = 1152921512877784496 (0x10000001ECFC7DB0);
            // 0x028E8BDC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E8BE0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E8BE4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E8BE8: BR x3                      | X0 = this( ?? X20, ????);               
            label_13:
            // 0x028E8BEC: LDR x4, [sp, #8]           | X4 = this;                              
            // 0x028E8BF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E8BF4: MOV x1, x20                | X1 = X20;//m1                           
            // 0x028E8BF8: MOV w2, w19                | W2 = size;//m1                          
            // 0x028E8BFC: MOV x3, x21                | X3 = X21;//m1                           
            // 0x028E8C00: SUB sp, x29, #0x20         | SP = (1152921512877784528 - 32) = 1152921512877784496 (0x10000001ECFC7DB0);
            // 0x028E8C04: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E8C08: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E8C0C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E8C10: BR x4                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x028E8C14: LDRH w22, [x21, #0x4c]     | W22 = X21 + 76;                         
            // 0x028E8C18: TBZ w0, #0, #0x28e8c84     | if ((val_2 & 0x1) == 0) goto label_15;  
            if((val_2 & 1) == 0)
            {
                goto label_15;
            }
            // 0x028E8C1C: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E8C20: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X21.pressedSprite;
            // 0x028E8C24: LDR x9, [x20]              | X9 = X20;                               
            // 0x028E8C28: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x028E8C2C: LDRH w10, [x9, #0x102]     | W10 = X20 + 258;                        
            // 0x028E8C30: CBZ x10, #0x28e8c5c        | if (X20 + 258 == 0) goto label_16;      
            if((X20 + 258) == 0)
            {
                goto label_16;
            }
            // 0x028E8C34: LDR x11, [x9, #0x98]       | X11 = X20 + 152;                        
            var val_7 = X20 + 152;
            // 0x028E8C38: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x028E8C3C: ADD x11, x11, #8           | X11 = (X20 + 152 + 8);                  
            val_7 = val_7 + 8;
            label_18:
            // 0x028E8C40: LDUR x13, [x11, #-8]       | X13 = (X20 + 152 + 8) + -8;             
            // 0x028E8C44: CMP x13, x8                | STATE = COMPARE((X20 + 152 + 8) + -8, val_3)
            // 0x028E8C48: B.EQ #0x28e8cc8            | if ((X20 + 152 + 8) + -8 == val_3) goto label_17;
            if(((X20 + 152 + 8) + -8) == val_3)
            {
                goto label_17;
            }
            // 0x028E8C4C: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x028E8C50: ADD x11, x11, #0x10        | X11 = ((X20 + 152 + 8) + 16);           
            val_7 = val_7 + 16;
            // 0x028E8C54: CMP x12, x10               | STATE = COMPARE((0 + 1), X20 + 258)     
            // 0x028E8C58: B.LO #0x28e8c40            | if (0 < X20 + 258) goto label_18;       
            if(val_8 < (X20 + 258))
            {
                goto label_18;
            }
            label_16:
            // 0x028E8C5C: MOV x0, x20                | X0 = X20;//m1                           
            val_8 = X20;
            // 0x028E8C60: MOV x1, x8                 | X1 = val_3;//m1                         
            // 0x028E8C64: MOV w2, w22                | W2 = X21 + 76;//m1                      
            // 0x028E8C68: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
            // 0x028E8C6C: B #0x28e8cd8               |  goto label_19;                         
            goto label_19;
            label_8:
            // 0x028E8C70: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x028E8C74: LDR x9, [x20]              | X9 = X20;                               
            // 0x028E8C78: ADD x8, x9, x8, lsl #4     | X8 = (X20 + (X21 + 76) << 4);           
            var val_4 = X20 + ((X21 + 76) << 4);
            // 0x028E8C7C: LDR x0, [x8, #0x118]       | X0 = (X20 + (X21 + 76) << 4) + 280;     
            val_9 = mem[(X20 + (X21 + 76) << 4) + 280];
            val_9 = (X20 + (X21 + 76) << 4) + 280;
            // 0x028E8C80: B #0x28e8ca8               |  goto label_20;                         
            goto label_20;
            label_15:
            // 0x028E8C84: LDR x8, [x20]              | X8 = X20;                               
            var val_9 = X20;
            // 0x028E8C88: ADD x8, x8, w22, uxtw #4   | X8 = (X20 + X21 + 76);                  
            val_9 = val_9 + (X21 + 76);
            // 0x028E8C8C: LDP x3, x2, [x8, #0x110]   | X3 = (X20 + X21 + 76) + 272; X2 = (X20 + X21 + 76) + 272 + 8; //  | 
            // 0x028E8C90: B #0x28e8cdc               |  goto label_21;                         
            goto label_21;
            label_10:
            // 0x028E8C94: LDR w9, [x10]              | W9 = (X20 + 152 + 8);                   
            var val_10 = val_5;
            // 0x028E8C98: ADD w9, w9, w2             | W9 = ((X20 + 152 + 8) + X21 + 76);      
            val_10 = val_10 + (X21 + 76);
            // 0x028E8C9C: ADD x8, x8, w9, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + X21 + 76));
            val_11 = val_11 + val_10;
            // 0x028E8CA0: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272);
            val_7 = val_11 + 272;
            label_12:
            // 0x028E8CA4: LDR x0, [x0, #8]           | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
            val_9 = mem[((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8];
            val_9 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
            label_20:
            // 0x028E8CA8: MOV x1, x21                | X1 = X21;//m1                           
            // 0x028E8CAC: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8, ????);
            // 0x028E8CB0: MOV x8, x0                 | X8 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x028E8CB4: LDR x3, [x8]               | X3 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
            // 0x028E8CB8: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E8CBC: MOV w1, w19                | W1 = size;//m1                          
            // 0x028E8CC0: MOV x2, x8                 | X2 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x028E8CC4: B #0x28e8bd8               |  goto label_23;                         
            goto label_23;
            label_17:
            // 0x028E8CC8: LDR w8, [x11]              | W8 = (X20 + 152 + 8);                   
            var val_12 = val_7;
            // 0x028E8CCC: ADD w8, w8, w22            | W8 = ((X20 + 152 + 8) + X21 + 76);      
            val_12 = val_12 + (X21 + 76);
            // 0x028E8CD0: ADD x8, x9, w8, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + X21 + 76));
            val_12 = X20 + val_12;
            // 0x028E8CD4: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272);
            val_8 = val_12 + 272;
            label_19:
            // 0x028E8CD8: LDP x3, x2, [x0]           | X3 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272); X2 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8; //  | 
            label_21:
            // 0x028E8CDC: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E8CE0: MOV w1, w19                | W1 = size;//m1                          
            // 0x028E8CE4: B #0x28e8bd8               |  goto label_23;                         
            goto label_23;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E8CE8 (42896616), len: 140  VirtAddr: 0x028E8CE8 RVA: 0x028E8CE8 token: 100680206 methodIndex: 29533 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(int size, System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x028E8CE8: STP x22, x21, [sp, #-0x30]! | stack[1152921512877916976] = ???;  stack[1152921512877916984] = ???;  //  dest_result_addr=1152921512877916976 |  dest_result_addr=1152921512877916984
            // 0x028E8CEC: STP x20, x19, [sp, #0x10]  | stack[1152921512877916992] = ???;  stack[1152921512877917000] = ???;  //  dest_result_addr=1152921512877916992 |  dest_result_addr=1152921512877917000
            // 0x028E8CF0: STP x29, x30, [sp, #0x20]  | stack[1152921512877917008] = ???;  stack[1152921512877917016] = ???;  //  dest_result_addr=1152921512877917008 |  dest_result_addr=1152921512877917016
            // 0x028E8CF4: ADD x29, sp, #0x20         | X29 = (1152921512877916976 + 32) = 1152921512877917008 (0x10000001ECFE8350);
            // 0x028E8CF8: SUB sp, sp, #0x20          | SP = (1152921512877916976 - 32) = 1152921512877916944 (0x10000001ECFE8310);
            // 0x028E8CFC: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x028E8D00: LDRB w8, [x22, #0x9f9]     | W8 = (bool)static_value_037B89F9;       
            // 0x028E8D04: MOV x19, x3                | X19 = object;//m1                       
            // 0x028E8D08: MOV x20, x2                | X20 = callback;//m1                     
            // 0x028E8D0C: MOV x21, x0                | X21 = 1152921512877929024 (0x10000001ECFEB240);//ML01
            // 0x028E8D10: STR w1, [sp, #0x1c]        | stack[1152921512877916972] = size;       //  dest_result_addr=1152921512877916972
            // 0x028E8D14: TBNZ w8, #0, #0x28e8d30    | if (static_value_037B89F9 == true) goto label_0;
            // 0x028E8D18: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x028E8D1C: LDR x8, [x8, #0xe20]       | X8 = 0x2B90C88;                         
            // 0x028E8D20: LDR w0, [x8]               | W0 = 0x19E6;                            
            // 0x028E8D24: BL #0x2782188              | X0 = sub_2782188( ?? 0x19E6, ????);     
            // 0x028E8D28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028E8D2C: STRB w8, [x22, #0x9f9]     | static_value_037B89F9 = true;            //  dest_result_addr=58427897
            label_0:
            // 0x028E8D30: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028E8D34: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028E8D38: ADD x1, sp, #0x1c          | X1 = (1152921512877916944 + 28) = 1152921512877916972 (0x10000001ECFE832C);
            // 0x028E8D3C: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x028E8D40: STP xzr, xzr, [sp, #8]     | stack[1152921512877916952] = 0x0;  stack[1152921512877916960] = 0x0;  //  dest_result_addr=1152921512877916952 |  dest_result_addr=1152921512877916960
            // 0x028E8D44: BL #0x27bc028              | X0 = 1152921512877969216 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), size);
            // 0x028E8D48: STR x0, [sp, #8]           | stack[1152921512877916952] = size; stack[1152921512877916956] = 0x10000001;  //  dest_result_addr=1152921512877916952 dest_result_addr=1152921512877916956
            // 0x028E8D4C: ADD x1, sp, #8             | X1 = (1152921512877916944 + 8) = 1152921512877916952 (0x10000001ECFE8318);
            // 0x028E8D50: MOV x0, x21                | X0 = 1152921512877929024 (0x10000001ECFEB240);//ML01
            // 0x028E8D54: MOV x2, x20                | X2 = callback;//m1                      
            // 0x028E8D58: MOV x3, x19                | X3 = object;//m1                        
            // 0x028E8D5C: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x028E8D60: SUB sp, x29, #0x20         | SP = (1152921512877917008 - 32) = 1152921512877916976 (0x10000001ECFE8330);
            // 0x028E8D64: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E8D68: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E8D6C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E8D70: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028E8D74 (42896756), len: 16  VirtAddr: 0x028E8D74 RVA: 0x028E8D74 token: 100680207 methodIndex: 29534 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual object EndInvoke(System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x028E8D74: MOV x8, x1                 | X8 = result;//m1                        
            // 0x028E8D78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028E8D7C: MOV x0, x8                 | X0 = result;//m1                        
            // 0x028E8D80: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
        
        }
    
    }

}
