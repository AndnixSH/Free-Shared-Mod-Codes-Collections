using UnityEngine;
public class CameraHelper : MonoBehaviour
{
    // Fields
    public const string MOVE_COMPLETE = "Camera_MOVE_COMPLETE";
    public const string CHANGE_TARGET_COMPLETE = "CHANGE_TARGET_COMPLETE";
    public float fieldMin; //  0x00000018
    public float timeScale; //  0x0000001C
    private UnityEngine.Vector3 initOffset; //  0x00000020
    private float zoomInDamping; //  0x0000002C
    private float zoomOutDamping; //  0x00000030
    private float zoomInTime; //  0x00000034
    private float mZoomInTime; //  0x00000038
    private float mZoomOutTime; //  0x0000003C
    private float waitTime; //  0x00000040
    private bool bInScaler; //  0x00000044
    private bool bZoomIn; //  0x00000045
    private float curFieldView; //  0x00000048
    private float fieldMax; //  0x0000004C
    private float baseTime; //  0x00000050
    private ScreenShake ss; //  0x00000058
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x286B7B4
    private CameraSmoothFollow <csf>k__BackingField; //  0x00000060
    private UnityEngine.Transform tf; //  0x00000068
    public UnityEngine.Camera effectCamera; //  0x00000070
    public static CameraHelper instance; // static_offset: 0x00000000
    public bool motionBluring; //  0x00000078
    private bool isTeamSkillCamera; //  0x00000079
    private float ry; //  0x0000007C
    private float rx; //  0x00000080
    private float distance; //  0x00000084
    private int effid; //  0x00000088
    private UnityEngine.Vector3 lastPos; //  0x0000008C
    private float lastFov; //  0x00000098
    
    // Properties
    public CameraSmoothFollow csf { get; set; }
    public bool inScaler { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA9A64 (12229220), len: 136  VirtAddr: 0x00BA9A64 RVA: 0x00BA9A64 token: 100690216 methodIndex: 25674 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraHelper()
    {
        //
        // Disasemble & Code
        // 0x00BA9A64: STP x20, x19, [sp, #-0x20]! | stack[1152921514488155968] = ???;  stack[1152921514488155976] = ???;  //  dest_result_addr=1152921514488155968 |  dest_result_addr=1152921514488155976
        // 0x00BA9A68: STP x29, x30, [sp, #0x10]  | stack[1152921514488155984] = ???;  stack[1152921514488155992] = ???;  //  dest_result_addr=1152921514488155984 |  dest_result_addr=1152921514488155992
        // 0x00BA9A6C: ADD x29, sp, #0x10         | X29 = (1152921514488155968 + 16) = 1152921514488155984 (0x100000024CF8CF50);
        // 0x00BA9A70: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA9A74: LDRB w8, [x20, #0xaf2]     | W8 = (bool)static_value_03733AF2;       
        // 0x00BA9A78: MOV x19, x0                | X19 = 1152921514488168000 (0x100000024CF8FE40);//ML01
        // 0x00BA9A7C: TBNZ w8, #0, #0xba9a98     | if (static_value_03733AF2 == true) goto label_0;
        // 0x00BA9A80: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x00BA9A84: LDR x8, [x8, #0xe60]       | X8 = 0x2B9017C;                         
        // 0x00BA9A88: LDR w0, [x8]               | W0 = 0x1723;                            
        // 0x00BA9A8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1723, ????);     
        // 0x00BA9A90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA9A94: STRB w8, [x20, #0xaf2]     | static_value_03733AF2 = true;            //  dest_result_addr=57883378
        label_0:
        // 0x00BA9A98: ORR x8, xzr, #0x3f0000003f000000 | X8 = 4539628425446424576(0x3F0000003F000000);
        // 0x00BA9A9C: MOVK x8, #0x41f0, lsl #16  | X8 = 4539628426535895040 (0x3F0000007FF00000);
        // 0x00BA9AA0: STR x8, [x19, #0x18]       | this.fieldMin = NaN; this.timeScale = 0.5;  //  dest_result_addr=1152921514488168024 dest_result_addr=1152921514488168028
        this.fieldMin = 0f;
        this.timeScale = 0.5f;
        // 0x00BA9AA4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BA9AA8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BA9AAC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BA9AB0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BA9AB4: TBZ w8, #0, #0xba9ac4      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA9AB8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BA9ABC: CBNZ w8, #0xba9ac4         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA9AC0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_2:
        // 0x00BA9AC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9AC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9ACC: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_1 = UnityEngine.Vector3.zero;
        // 0x00BA9AD0: STP s0, s1, [x19, #0x20]   | this.initOffset = val_1;  mem[1152921514488168036] = val_1.y;  //  dest_result_addr=1152921514488168032 |  dest_result_addr=1152921514488168036
        this.initOffset = val_1;
        mem[1152921514488168036] = val_1.y;
        // 0x00BA9AD4: STR s2, [x19, #0x28]       | mem[1152921514488168040] = val_1.z;      //  dest_result_addr=1152921514488168040
        mem[1152921514488168040] = val_1.z;
        // 0x00BA9AD8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA9ADC: MOV x0, x19                | X0 = 1152921514488168000 (0x100000024CF8FE40);//ML01
        // 0x00BA9AE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9AE4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA9AE8: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA9AEC (12229356), len: 8  VirtAddr: 0x00BA9AEC RVA: 0x00BA9AEC token: 100690217 methodIndex: 25675 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_csf(CameraSmoothFollow value)
    {
        //
        // Disasemble & Code
        // 0x00BA9AEC: STR x1, [x0, #0x60]        | this.<csf>k__BackingField = value;       //  dest_result_addr=1152921514488284192
        this.<csf>k__BackingField = value;
        // 0x00BA9AF0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA9AF4 (12229364), len: 8  VirtAddr: 0x00BA9AF4 RVA: 0x00BA9AF4 token: 100690218 methodIndex: 25676 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraSmoothFollow get_csf()
    {
        //
        // Disasemble & Code
        // 0x00BA9AF4: LDR x0, [x0, #0x60]        | X0 = this.<csf>k__BackingField; //P2    
        // 0x00BA9AF8: RET                        |  return (CameraSmoothFollow)this.<csf>k__BackingField;
        return this.<csf>k__BackingField;
        //  |  // // {name=val_0, type=CameraSmoothFollow, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA9AFC (12229372), len: 8  VirtAddr: 0x00BA9AFC RVA: 0x00BA9AFC token: 100690219 methodIndex: 25677 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_inScaler()
    {
        //
        // Disasemble & Code
        // 0x00BA9AFC: LDRB w0, [x0, #0x44]       | W0 = this.bInScaler; //P2               
        // 0x00BA9B00: RET                        |  return (System.Boolean)this.bInScaler; 
        return this.bInScaler;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA9B04 (12229380), len: 760  VirtAddr: 0x00BA9B04 RVA: 0x00BA9B04 token: 100690220 methodIndex: 25678 delegateWrapperIndex: 0 methodInvoker: 0
    private void Start()
    {
        //
        // Disasemble & Code
        //  | 
        var val_16;
        // 0x00BA9B04: STP d9, d8, [sp, #-0x60]!  | stack[1152921514488653232] = ???;  stack[1152921514488653240] = ???;  //  dest_result_addr=1152921514488653232 |  dest_result_addr=1152921514488653240
        // 0x00BA9B08: STP x26, x25, [sp, #0x10]  | stack[1152921514488653248] = ???;  stack[1152921514488653256] = ???;  //  dest_result_addr=1152921514488653248 |  dest_result_addr=1152921514488653256
        // 0x00BA9B0C: STP x24, x23, [sp, #0x20]  | stack[1152921514488653264] = ???;  stack[1152921514488653272] = ???;  //  dest_result_addr=1152921514488653264 |  dest_result_addr=1152921514488653272
        // 0x00BA9B10: STP x22, x21, [sp, #0x30]  | stack[1152921514488653280] = ???;  stack[1152921514488653288] = ???;  //  dest_result_addr=1152921514488653280 |  dest_result_addr=1152921514488653288
        // 0x00BA9B14: STP x20, x19, [sp, #0x40]  | stack[1152921514488653296] = ???;  stack[1152921514488653304] = ???;  //  dest_result_addr=1152921514488653296 |  dest_result_addr=1152921514488653304
        // 0x00BA9B18: STP x29, x30, [sp, #0x50]  | stack[1152921514488653312] = ???;  stack[1152921514488653320] = ???;  //  dest_result_addr=1152921514488653312 |  dest_result_addr=1152921514488653320
        // 0x00BA9B1C: ADD x29, sp, #0x50         | X29 = (1152921514488653232 + 80) = 1152921514488653312 (0x100000024D006600);
        // 0x00BA9B20: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA9B24: LDRB w8, [x20, #0xaf3]     | W8 = (bool)static_value_03733AF3;       
        // 0x00BA9B28: MOV x19, x0                | X19 = 1152921514488665328 (0x100000024D0094F0);//ML01
        // 0x00BA9B2C: TBNZ w8, #0, #0xba9b48     | if (static_value_03733AF3 == true) goto label_0;
        // 0x00BA9B30: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00BA9B34: LDR x8, [x8, #0xab0]       | X8 = 0x2B90218;                         
        // 0x00BA9B38: LDR w0, [x8]               | W0 = 0x174A;                            
        // 0x00BA9B3C: BL #0x2782188              | X0 = sub_2782188( ?? 0x174A, ????);     
        // 0x00BA9B40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA9B44: STRB w8, [x20, #0xaf3]     | static_value_03733AF3 = true;            //  dest_result_addr=57883379
        label_0:
        // 0x00BA9B48: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
        // 0x00BA9B4C: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
        // 0x00BA9B50: LDR x0, [x20]              | X0 = typeof(CameraHelper);              
        val_16 = null;
        // 0x00BA9B54: LDRB w8, [x0, #0x10a]      | W8 = CameraHelper.__il2cppRuntimeField_10A;
        // 0x00BA9B58: TBZ w8, #0, #0xba9b6c      | if (CameraHelper.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA9B5C: LDR w8, [x0, #0xbc]        | W8 = CameraHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00BA9B60: CBNZ w8, #0xba9b6c         | if (CameraHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA9B64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraHelper), ????);
        // 0x00BA9B68: LDR x0, [x20]              | X0 = typeof(CameraHelper);              
        val_16 = null;
        label_2:
        // 0x00BA9B6C: LDR x8, [x0, #0xa0]        | X8 = CameraHelper.__il2cppRuntimeField_static_fields;
        // 0x00BA9B70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9B74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9B78: STR x19, [x8]              | CameraHelper.instance = this;            //  dest_result_addr=1152921504887734272
        CameraHelper.instance = this;
        // 0x00BA9B7C: STRB wzr, [x19, #0x44]     | this.bInScaler = false;                  //  dest_result_addr=1152921514488665396
        this.bInScaler = false;
        // 0x00BA9B80: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_1 = UnityEngine.Camera.main;
        // 0x00BA9B84: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00BA9B88: CBNZ x20, #0xba9b90        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00BA9B8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00BA9B90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9B94: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00BA9B98: BL #0x20ce7bc              | X0 = val_1.get_fieldOfView();           
        float val_2 = val_1.fieldOfView;
        // 0x00BA9B9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9BA0: MOV x0, x19                | X0 = 1152921514488665328 (0x100000024D0094F0);//ML01
        // 0x00BA9BA4: STR s0, [x19, #0x4c]       | this.fieldMax = val_2;                   //  dest_result_addr=1152921514488665404
        this.fieldMax = val_2;
        // 0x00BA9BA8: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_3 = this.transform;
        // 0x00BA9BAC: STR x0, [x19, #0x68]       | this.tf = val_3;                         //  dest_result_addr=1152921514488665432
        this.tf = val_3;
        // 0x00BA9BB0: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00BA9BB4: LDR x8, [x8, #0x948]       | X8 = 1152921511729347664;               
        // 0x00BA9BB8: MOV x0, x19                | X0 = 1152921514488665328 (0x100000024D0094F0);//ML01
        // 0x00BA9BBC: LDR x1, [x8]               | X1 = public CameraSmoothFollow UnityEngine.Component::GetComponent<CameraSmoothFollow>();
        // 0x00BA9BC0: BL #0x23d5410              | X0 = this.GetComponent<CameraSmoothFollow>();
        CameraSmoothFollow val_4 = this.GetComponent<CameraSmoothFollow>();
        // 0x00BA9BC4: STR x0, [x19, #0x60]       | this.<csf>k__BackingField = val_4;       //  dest_result_addr=1152921514488665424
        this.<csf>k__BackingField = val_4;
        // 0x00BA9BC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9BCC: MOV x0, x19                | X0 = 1152921514488665328 (0x100000024D0094F0);//ML01
        // 0x00BA9BD0: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_5 = this.gameObject;
        // 0x00BA9BD4: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
        // 0x00BA9BD8: LDR x8, [x8, #0xfe8]       | X8 = (string**)(1152921514488624768)("EffectCamera");
        // 0x00BA9BDC: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x00BA9BE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9BE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA9BE8: LDR x2, [x8]               | X2 = "EffectCamera";                    
        // 0x00BA9BEC: BL #0xc1cff0               | X0 = GameObjectVisitor.FindChild(_this:  0, name:  val_5);
        UnityEngine.GameObject val_6 = GameObjectVisitor.FindChild(_this:  0, name:  val_5);
        // 0x00BA9BF0: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00BA9BF4: CBNZ x20, #0xba9bfc        | if (val_6 != null) goto label_4;        
        if(val_6 != null)
        {
            goto label_4;
        }
        // 0x00BA9BF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_4:
        // 0x00BA9BFC: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x00BA9C00: LDR x8, [x8, #0x6e8]       | X8 = 1152921509950535376;               
        // 0x00BA9C04: MOV x0, x20                | X0 = val_6;//m1                         
        // 0x00BA9C08: LDR x1, [x8]               | X1 = public UnityEngine.Camera UnityEngine.GameObject::GetComponent<UnityEngine.Camera>();
        // 0x00BA9C0C: BL #0x23d5abc              | X0 = val_6.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_7 = val_6.GetComponent<UnityEngine.Camera>();
        // 0x00BA9C10: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00BA9C14: STR x20, [x19, #0x70]      | this.effectCamera = val_7;               //  dest_result_addr=1152921514488665440
        this.effectCamera = val_7;
        // 0x00BA9C18: CBNZ x20, #0xba9c20        | if (val_7 != null) goto label_5;        
        if(val_7 != null)
        {
            goto label_5;
        }
        // 0x00BA9C1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_5:
        // 0x00BA9C20: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA9C24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA9C28: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00BA9C2C: BL #0x20cb458              | val_7.set_enabled(value:  false);       
        val_7.enabled = false;
        // 0x00BA9C30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9C34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9C38: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_8 = UnityEngine.Camera.main;
        // 0x00BA9C3C: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00BA9C40: CBNZ x20, #0xba9c48        | if (val_8 != null) goto label_6;        
        if(val_8 != null)
        {
            goto label_6;
        }
        // 0x00BA9C44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_6:
        // 0x00BA9C48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9C4C: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00BA9C50: BL #0x20cf610              | X0 = val_8.get_cullingMask();           
        int val_9 = val_8.cullingMask;
        // 0x00BA9C54: ADRP x24, #0x3680000       | X24 = 57147392 (0x3680000);             
        // 0x00BA9C58: LDR x24, [x24, #0x2d0]     | X24 = 1152921504948897168;              
        // 0x00BA9C5C: MOV w21, w0                | W21 = val_9;//m1                        
        // 0x00BA9C60: LDR x22, [x24]             | X22 = typeof(System.String[]);          
        // 0x00BA9C64: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BA9C68: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
        // 0x00BA9C6C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA9C70: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BA9C74: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
        // 0x00BA9C78: MOV x22, x0                | X22 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BA9C7C: CBNZ x22, #0xba9c84        | if ( != null) goto label_7;             
        if(null != null)
        {
            goto label_7;
        }
        // 0x00BA9C80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
        label_7:
        // 0x00BA9C84: ADRP x23, #0x362d000       | X23 = 56807424 (0x362D000);             
        // 0x00BA9C88: LDR x23, [x23, #0x358]     | X23 = (string**)(1152921514488637152)("heroRt");
        // 0x00BA9C8C: LDR x0, [x23]              | X0 = "heroRt";                          
        // 0x00BA9C90: CBZ x0, #0xba9cb0          | if ("heroRt" == null) goto label_9;     
        // 0x00BA9C94: LDR x8, [x22]              | X8 = ;                                  
        // 0x00BA9C98: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA9C9C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "heroRt", ????);   
        // 0x00BA9CA0: CBNZ x0, #0xba9cb0         | if ("heroRt" != null) goto label_9;     
        if("heroRt" != null)
        {
            goto label_9;
        }
        // 0x00BA9CA4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "heroRt", ????);   
        // 0x00BA9CA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9CAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "heroRt", ????);   
        label_9:
        // 0x00BA9CB0: LDR x25, [x23]             | X25 = "heroRt";                         
        // 0x00BA9CB4: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00BA9CB8: CBNZ w8, #0xba9cc8         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_10;
        // 0x00BA9CBC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "heroRt", ????);   
        // 0x00BA9CC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9CC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "heroRt", ????);   
        label_10:
        // 0x00BA9CC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9CCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA9CD0: MOV x1, x22                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BA9CD4: STR x25, [x22, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "heroRt";  //  dest_result_addr=1152921504948897200
        typeof(System.String[]).__il2cppRuntimeField_20 = "heroRt";
        // 0x00BA9CD8: BL #0x1a73324              | X0 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        int val_10 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        // 0x00BA9CDC: MOV w22, w0                | W22 = val_10;//m1                       
        // 0x00BA9CE0: CBNZ x20, #0xba9ce8        | if (val_8 != null) goto label_11;       
        if(val_8 != null)
        {
            goto label_11;
        }
        // 0x00BA9CE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_11:
        // 0x00BA9CE8: BIC w1, w21, w22           | W1 = (val_9 & (~val_10));               
        int val_11 = val_9 & (~val_10);
        // 0x00BA9CEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA9CF0: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00BA9CF4: BL #0x20cf678              | val_8.set_cullingMask(value:  int val_11 = val_9 & (~val_10));
        val_8.cullingMask = val_11;
        // 0x00BA9CF8: LDR x20, [x19, #0x70]      | X20 = this.effectCamera; //P2           
        // 0x00BA9CFC: CBNZ x20, #0xba9d04        | if (this.effectCamera != null) goto label_12;
        if(this.effectCamera != null)
        {
            goto label_12;
        }
        // 0x00BA9D00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_12:
        // 0x00BA9D04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9D08: MOV x0, x20                | X0 = this.effectCamera;//m1             
        // 0x00BA9D0C: BL #0x20cf610              | X0 = this.effectCamera.get_cullingMask();
        int val_12 = this.effectCamera.cullingMask;
        // 0x00BA9D10: LDR x22, [x24]             | X22 = typeof(System.String[]);          
        // 0x00BA9D14: MOV w21, w0                | W21 = val_12;//m1                       
        // 0x00BA9D18: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BA9D1C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
        // 0x00BA9D20: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA9D24: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BA9D28: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
        // 0x00BA9D2C: MOV x22, x0                | X22 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BA9D30: CBNZ x22, #0xba9d38        | if ( != null) goto label_13;            
        if(null != null)
        {
            goto label_13;
        }
        // 0x00BA9D34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
        label_13:
        // 0x00BA9D38: LDR x0, [x23]              | X0 = "heroRt";                          
        // 0x00BA9D3C: CBZ x0, #0xba9d5c          | if ("heroRt" == null) goto label_15;    
        // 0x00BA9D40: LDR x8, [x22]              | X8 = ;                                  
        // 0x00BA9D44: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA9D48: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "heroRt", ????);   
        // 0x00BA9D4C: CBNZ x0, #0xba9d5c         | if ("heroRt" != null) goto label_15;    
        if("heroRt" != null)
        {
            goto label_15;
        }
        // 0x00BA9D50: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "heroRt", ????);   
        // 0x00BA9D54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9D58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "heroRt", ????);   
        label_15:
        // 0x00BA9D5C: LDR x23, [x23]             | X23 = "heroRt";                         
        // 0x00BA9D60: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00BA9D64: CBNZ w8, #0xba9d74         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_16;
        // 0x00BA9D68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "heroRt", ????);   
        // 0x00BA9D6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9D70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "heroRt", ????);   
        label_16:
        // 0x00BA9D74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9D78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA9D7C: MOV x1, x22                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BA9D80: STR x23, [x22, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "heroRt";  //  dest_result_addr=1152921504948897200
        typeof(System.String[]).__il2cppRuntimeField_20 = "heroRt";
        // 0x00BA9D84: BL #0x1a73324              | X0 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        int val_13 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        // 0x00BA9D88: MOV w22, w0                | W22 = val_13;//m1                       
        // 0x00BA9D8C: CBNZ x20, #0xba9d94        | if (this.effectCamera != null) goto label_17;
        if(this.effectCamera != null)
        {
            goto label_17;
        }
        // 0x00BA9D90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_17:
        // 0x00BA9D94: BIC w1, w21, w22           | W1 = (val_12 & (~val_13));              
        int val_14 = val_12 & (~val_13);
        // 0x00BA9D98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA9D9C: MOV x0, x20                | X0 = this.effectCamera;//m1             
        // 0x00BA9DA0: BL #0x20cf678              | this.effectCamera.set_cullingMask(value:  int val_14 = val_12 & (~val_13));
        this.effectCamera.cullingMask = val_14;
        // 0x00BA9DA4: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00BA9DA8: LDR x8, [x8, #0xd20]       | X8 = 1152921504901627904;               
        // 0x00BA9DAC: LDR s8, [x19, #0x4c]       | S8 = this.fieldMax; //P2                
        // 0x00BA9DB0: LDR s9, [x19, #0x18]       | S9 = this.fieldMin; //P2                
        // 0x00BA9DB4: LDR x8, [x8]               | X8 = typeof(GesturesMgr);               
        // 0x00BA9DB8: LDR x8, [x8, #0xa0]        | X8 = GesturesMgr.__il2cppRuntimeField_static_fields;
        // 0x00BA9DBC: LDR x20, [x8]              | X20 = GesturesMgr.instance;             
        // 0x00BA9DC0: CBNZ x20, #0xba9dc8        | if (GesturesMgr.instance != null) goto label_18;
        if(GesturesMgr.instance != null)
        {
            goto label_18;
        }
        // 0x00BA9DC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.effectCamera, ????);
        label_18:
        // 0x00BA9DC8: FSUB s1, s8, s9            | S1 = (this.fieldMax - this.fieldMin);   
        float val_15 = this.fieldMax - this.fieldMin;
        // 0x00BA9DCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9DD0: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00BA9DD4: MOV x0, x20                | X0 = GesturesMgr.instance;//m1          
        // 0x00BA9DD8: BL #0x2880b68              | GesturesMgr.instance.SetZoomAmount(min:  0f, max:  float val_15 = this.fieldMax - this.fieldMin);
        GesturesMgr.instance.SetZoomAmount(min:  0f, max:  val_15);
        // 0x00BA9DDC: STRB wzr, [x19, #0x78]     | this.motionBluring = false;              //  dest_result_addr=1152921514488665448
        this.motionBluring = false;
        // 0x00BA9DE0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA9DE4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA9DE8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA9DEC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA9DF0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00BA9DF4: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00BA9DF8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA9DFC (12230140), len: 1412  VirtAddr: 0x00BA9DFC RVA: 0x00BA9DFC token: 100690221 methodIndex: 25679 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        //  | 
        float val_33;
        //  | 
        float val_34;
        //  | 
        float val_35;
        //  | 
        var val_36;
        // 0x00BA9DFC: STP d15, d14, [sp, #-0x80]! | stack[1152921514488868800] = ???;  stack[1152921514488868808] = ???;  //  dest_result_addr=1152921514488868800 |  dest_result_addr=1152921514488868808
        // 0x00BA9E00: STP d13, d12, [sp, #0x10]  | stack[1152921514488868816] = ???;  stack[1152921514488868824] = ???;  //  dest_result_addr=1152921514488868816 |  dest_result_addr=1152921514488868824
        // 0x00BA9E04: STP d11, d10, [sp, #0x20]  | stack[1152921514488868832] = ???;  stack[1152921514488868840] = ???;  //  dest_result_addr=1152921514488868832 |  dest_result_addr=1152921514488868840
        // 0x00BA9E08: STP d9, d8, [sp, #0x30]    | stack[1152921514488868848] = ???;  stack[1152921514488868856] = ???;  //  dest_result_addr=1152921514488868848 |  dest_result_addr=1152921514488868856
        // 0x00BA9E0C: STP x24, x23, [sp, #0x40]  | stack[1152921514488868864] = ???;  stack[1152921514488868872] = ???;  //  dest_result_addr=1152921514488868864 |  dest_result_addr=1152921514488868872
        // 0x00BA9E10: STP x22, x21, [sp, #0x50]  | stack[1152921514488868880] = ???;  stack[1152921514488868888] = ???;  //  dest_result_addr=1152921514488868880 |  dest_result_addr=1152921514488868888
        // 0x00BA9E14: STP x20, x19, [sp, #0x60]  | stack[1152921514488868896] = ???;  stack[1152921514488868904] = ???;  //  dest_result_addr=1152921514488868896 |  dest_result_addr=1152921514488868904
        // 0x00BA9E18: STP x29, x30, [sp, #0x70]  | stack[1152921514488868912] = ???;  stack[1152921514488868920] = ???;  //  dest_result_addr=1152921514488868912 |  dest_result_addr=1152921514488868920
        // 0x00BA9E1C: ADD x29, sp, #0x70         | X29 = (1152921514488868800 + 112) = 1152921514488868912 (0x100000024D03B030);
        // 0x00BA9E20: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA9E24: LDRB w8, [x20, #0xaf4]     | W8 = (bool)static_value_03733AF4;       
        // 0x00BA9E28: MOV x19, x0                | X19 = 1152921514488880928 (0x100000024D03DF20);//ML01
        // 0x00BA9E2C: TBNZ w8, #0, #0xba9e48     | if (static_value_03733AF4 == true) goto label_0;
        // 0x00BA9E30: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
        // 0x00BA9E34: LDR x8, [x8, #0xe30]       | X8 = 0x2B90220;                         
        // 0x00BA9E38: LDR w0, [x8]               | W0 = 0x174C;                            
        // 0x00BA9E3C: BL #0x2782188              | X0 = sub_2782188( ?? 0x174C, ????);     
        // 0x00BA9E40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA9E44: STRB w8, [x20, #0xaf4]     | static_value_03733AF4 = true;            //  dest_result_addr=57883380
        label_0:
        // 0x00BA9E48: LDRB w8, [x19, #0x44]      | W8 = this.bInScaler; //P2               
        // 0x00BA9E4C: CBZ w8, #0xbaa254          | if (this.bInScaler == false) goto label_1;
        if(this.bInScaler == false)
        {
            goto label_1;
        }
        // 0x00BA9E50: LDR s8, [x19, #0x50]       | S8 = this.baseTime; //P2                
        // 0x00BA9E54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9E58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9E5C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_1 = UnityEngine.Time.deltaTime;
        // 0x00BA9E60: LDR s11, [x19, #0x48]      | S11 = this.curFieldView; //P2           
        // 0x00BA9E64: LDRB w8, [x19, #0x45]      | W8 = this.bZoomIn; //P2                 
        // 0x00BA9E68: FADD s0, s8, s0            | S0 = (this.baseTime + val_1);           
        val_1 = this.baseTime + val_1;
        // 0x00BA9E6C: STR s0, [x19, #0x50]       | this.baseTime = (this.baseTime + val_1);  //  dest_result_addr=1152921514488881008
        this.baseTime = val_1;
        // 0x00BA9E70: CBZ w8, #0xbaa278          | if (this.bZoomIn == false) goto label_2;
        if(this.bZoomIn == false)
        {
            goto label_2;
        }
        // 0x00BA9E74: LDR s12, [x19, #0x2c]      | S12 = this.zoomInDamping; //P2          
        val_33 = this.zoomInDamping;
        // 0x00BA9E78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9E7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9E80: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_2 = UnityEngine.Time.deltaTime;
        // 0x00BA9E84: LDR s13, [x19, #0x2c]      | S13 = this.zoomInDamping; //P2          
        // 0x00BA9E88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9E8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9E90: MOV v8.16b, v0.16b         | V8 = val_2;//m1                         
        // 0x00BA9E94: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_3 = UnityEngine.Time.deltaTime;
        // 0x00BA9E98: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BA9E9C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BA9EA0: LDR s10, [x19, #0x50]      | S10 = this.baseTime; //P2               
        // 0x00BA9EA4: LDR s14, [x19, #0x38]      | S14 = this.mZoomInTime; //P2            
        val_34 = this.mZoomInTime;
        // 0x00BA9EA8: MOV v9.16b, v0.16b         | V9 = val_3;//m1                         
        // 0x00BA9EAC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BA9EB0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BA9EB4: TBZ w8, #0, #0xba9ec4      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00BA9EB8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BA9EBC: CBNZ w8, #0xba9ec4         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00BA9EC0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_4:
        // 0x00BA9EC4: FDIV s0, s10, s14          | S0 = (this.baseTime / this.mZoomInTime);
        float val_4 = this.baseTime / val_34;
        // 0x00BA9EC8: FMOV s10, #1.00000000      | S10 = 1;                                
        val_35 = 1f;
        // 0x00BA9ECC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9ED0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9ED4: MOV v1.16b, v10.16b        | V1 = 1;//m1                             
        // 0x00BA9ED8: BL #0x1a7d7bc              | X0 = UnityEngine.Mathf.Min(a:  float val_4 = this.baseTime / val_34, b:  val_35);
        float val_5 = UnityEngine.Mathf.Min(a:  val_4, b:  val_35);
        // 0x00BA9EDC: LDR s1, [x19, #0x18]       | S1 = this.fieldMin; //P2                
        // 0x00BA9EE0: FMUL s3, s13, s9           | S3 = (this.zoomInDamping * val_3);      
        float val_6 = this.zoomInDamping * val_3;
        // 0x00BA9EE4: FSUB s0, s10, s0           | S0 = (val_35 - val_5);                  
        val_5 = val_35 - val_5;
        // 0x00BA9EE8: FMUL s2, s12, s8           | S2 = (this.zoomInDamping * val_2);      
        float val_7 = val_33 * val_2;
        // 0x00BA9EEC: FMUL s0, s3, s0            | S0 = ((this.zoomInDamping * val_3) * (val_35 - val_5));
        val_5 = val_6 * val_5;
        // 0x00BA9EF0: FADD s0, s2, s0            | S0 = ((this.zoomInDamping * val_2) + ((this.zoomInDamping * val_3) * (val_35 - val_5)));
        val_5 = val_7 + val_5;
        // 0x00BA9EF4: FSUB s0, s11, s0           | S0 = (this.curFieldView - ((this.zoomInDamping * val_2) + ((this.zoomInDamping * val_3) * (val_35 - val_5))));
        val_5 = this.curFieldView - val_5;
        // 0x00BA9EF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9EFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9F00: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  val_5 = this.curFieldView - val_5, b:  this.fieldMin);
        float val_8 = UnityEngine.Mathf.Max(a:  val_5, b:  this.fieldMin);
        // 0x00BA9F04: LDR s1, [x19, #0x34]       | S1 = this.zoomInTime; //P2              
        // 0x00BA9F08: LDR s2, [x19, #0x40]       | S2 = this.waitTime; //P2                
        // 0x00BA9F0C: LDR s3, [x19, #0x50]       | S3 = this.baseTime; //P2                
        // 0x00BA9F10: STR s0, [x19, #0x48]       | this.curFieldView = val_8;               //  dest_result_addr=1152921514488881000
        this.curFieldView = val_8;
        // 0x00BA9F14: FADD s0, s1, s2            | S0 = (this.zoomInTime + this.waitTime); 
        float val_9 = this.zoomInTime + this.waitTime;
        // 0x00BA9F18: FCMP s3, s0                | STATE = COMPARE(this.baseTime, (this.zoomInTime + this.waitTime))
        // 0x00BA9F1C: B.LT #0xbaa314             | if (this.baseTime < val_9) goto label_34;
        if(this.baseTime < val_9)
        {
            goto label_34;
        }
        // 0x00BA9F20: LDR w8, [x19, #0x18]       | W8 = this.fieldMin; //P2                
        // 0x00BA9F24: STR wzr, [x19, #0x50]      | this.baseTime = 0;                       //  dest_result_addr=1152921514488881008
        this.baseTime = 0f;
        // 0x00BA9F28: STR w8, [x19, #0x48]       | this.curFieldView = this.fieldMin;       //  dest_result_addr=1152921514488881000
        this.curFieldView = this.fieldMin;
        // 0x00BA9F2C: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BA9F30: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BA9F34: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BA9F38: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BA9F3C: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BA9F40: CBNZ x20, #0xba9f48        | if (GameMgr.UPDATEOnOffEffect != null) goto label_6;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_6;
        }
        // 0x00BA9F44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x00BA9F48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA9F4C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA9F50: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BA9F54: BL #0xc181f8               | GameMgr.UPDATEOnOffEffect.ReActiveGameSpeedBtn(_IsActive:  true);
        GameMgr.UPDATEOnOffEffect.ReActiveGameSpeedBtn(_IsActive:  true);
        // 0x00BA9F58: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BA9F5C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00BA9F60: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00BA9F64: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BA9F68: TBZ w8, #0, #0xba9f78      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00BA9F6C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BA9F70: CBNZ w8, #0xba9f78         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00BA9F74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_8:
        // 0x00BA9F78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9F7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9F80: BL #0x26a81b0              | X0 = ZMG.get_TimeMgr();                 
        TimeMgr val_10 = ZMG.TimeMgr;
        // 0x00BA9F84: LDR s8, [x19, #0x1c]       | S8 = this.timeScale; //P2               
        // 0x00BA9F88: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00BA9F8C: CBNZ x20, #0xba9f94        | if (val_10 != null) goto label_9;       
        if(val_10 != null)
        {
            goto label_9;
        }
        // 0x00BA9F90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_9:
        // 0x00BA9F94: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00BA9F98: LDR x8, [x8, #0xe78]       | X8 = (string**)(1152921511103233552)("CAMERAHELPER");
        // 0x00BA9F9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA9FA0: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00BA9FA4: MOV v0.16b, v8.16b         | V0 = this.timeScale;//m1                
        // 0x00BA9FA8: LDR x1, [x8]               | X1 = "CAMERAHELPER";                    
        // 0x00BA9FAC: BL #0xdf13f0               | val_10.DelTimeScale(timeScale:  this.timeScale, timeKey:  "CAMERAHELPER");
        val_10.DelTimeScale(timeScale:  this.timeScale, timeKey:  "CAMERAHELPER");
        // 0x00BA9FB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9FB4: MOV x0, x19                | X0 = 1152921514488880928 (0x100000024D03DF20);//ML01
        // 0x00BA9FB8: STRB wzr, [x19, #0x45]     | this.bZoomIn = false;                    //  dest_result_addr=1152921514488880997
        this.bZoomIn = false;
        // 0x00BA9FBC: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_11 = this.gameObject;
        // 0x00BA9FC0: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x00BA9FC4: CBNZ x20, #0xba9fcc        | if (val_11 != null) goto label_10;      
        if(val_11 != null)
        {
            goto label_10;
        }
        // 0x00BA9FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_10:
        // 0x00BA9FCC: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00BA9FD0: LDR x8, [x8, #0x50]        | X8 = 1152921514488794288;               
        // 0x00BA9FD4: MOV x0, x20                | X0 = val_11;//m1                        
        // 0x00BA9FD8: LDR x1, [x8]               | X1 = public CameraMove UnityEngine.GameObject::GetComponent<CameraMove>();
        // 0x00BA9FDC: BL #0x23d5abc              | X0 = val_11.GetComponent<CameraMove>(); 
        CameraMove val_12 = val_11.GetComponent<CameraMove>();
        // 0x00BA9FE0: LDR x21, [x19, #0x70]      | X21 = this.effectCamera; //P2           
        // 0x00BA9FE4: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00BA9FE8: CBNZ x21, #0xba9ff0        | if (this.effectCamera != null) goto label_11;
        if(this.effectCamera != null)
        {
            goto label_11;
        }
        // 0x00BA9FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_11:
        // 0x00BA9FF0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA9FF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA9FF8: MOV x0, x21                | X0 = this.effectCamera;//m1             
        // 0x00BA9FFC: BL #0x20cb458              | this.effectCamera.set_enabled(value:  false);
        this.effectCamera.enabled = false;
        // 0x00BAA000: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA008: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_13 = ZMG.GlobalGOMgr;
        // 0x00BAA00C: MOV x21, x0                | X21 = val_13;//m1                       
        // 0x00BAA010: CBNZ x21, #0xbaa018        | if (val_13 != null) goto label_12;      
        if(val_13 != null)
        {
            goto label_12;
        }
        // 0x00BAA014: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_12:
        // 0x00BAA018: LDR x21, [x21, #0x38]      | X21 = val_13.uiBy3dCamera; //P2         
        // 0x00BAA01C: CBNZ x21, #0xbaa024        | if (val_13.uiBy3dCamera != null) goto label_13;
        if(val_13.uiBy3dCamera != null)
        {
            goto label_13;
        }
        // 0x00BAA020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_13:
        // 0x00BAA024: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAA028: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA02C: MOV x0, x21                | X0 = val_13.uiBy3dCamera;//m1           
        // 0x00BAA030: BL #0x20cb458              | val_13.uiBy3dCamera.set_enabled(value:  false);
        val_13.uiBy3dCamera.enabled = false;
        // 0x00BAA034: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA038: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA03C: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_14 = ZMG.GlobalGOMgr;
        // 0x00BAA040: MOV x21, x0                | X21 = val_14;//m1                       
        // 0x00BAA044: CBNZ x21, #0xbaa04c        | if (val_14 != null) goto label_14;      
        if(val_14 != null)
        {
            goto label_14;
        }
        // 0x00BAA048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_14:
        // 0x00BAA04C: LDR x21, [x21, #0x20]      | X21 = val_14.uiCamera; //P2             
        // 0x00BAA050: CBNZ x21, #0xbaa058        | if (val_14.uiCamera != null) goto label_15;
        if(val_14.uiCamera != null)
        {
            goto label_15;
        }
        // 0x00BAA054: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_15:
        // 0x00BAA058: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA05C: MOV x0, x21                | X0 = val_14.uiCamera;//m1               
        // 0x00BAA060: BL #0x20cf610              | X0 = val_14.uiCamera.get_cullingMask(); 
        int val_15 = val_14.uiCamera.cullingMask;
        // 0x00BAA064: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00BAA068: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
        // 0x00BAA06C: MOV w22, w0                | W22 = val_15;//m1                       
        // 0x00BAA070: LDR x23, [x8]              | X23 = typeof(System.String[]);          
        // 0x00BAA074: MOV x0, x23                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAA078: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
        // 0x00BAA07C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAA080: MOV x0, x23                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAA084: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
        // 0x00BAA088: MOV x23, x0                | X23 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAA08C: CBNZ x23, #0xbaa094        | if ( != null) goto label_16;            
        if(null != null)
        {
            goto label_16;
        }
        // 0x00BAA090: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
        label_16:
        // 0x00BAA094: ADRP x24, #0x35d1000       | X24 = 56430592 (0x35D1000);             
        // 0x00BAA098: LDR x24, [x24, #0x450]     | X24 = (string**)(1152921514488819888)("UIBY3D");
        // 0x00BAA09C: LDR x0, [x24]              | X0 = "UIBY3D";                          
        // 0x00BAA0A0: CBZ x0, #0xbaa0c0          | if ("UIBY3D" == null) goto label_18;    
        // 0x00BAA0A4: LDR x8, [x23]              | X8 = ;                                  
        // 0x00BAA0A8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BAA0AC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "UIBY3D", ????);   
        // 0x00BAA0B0: CBNZ x0, #0xbaa0c0         | if ("UIBY3D" != null) goto label_18;    
        if("UIBY3D" != null)
        {
            goto label_18;
        }
        // 0x00BAA0B4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "UIBY3D", ????);   
        // 0x00BAA0B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA0BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UIBY3D", ????);   
        label_18:
        // 0x00BAA0C0: LDR x24, [x24]             | X24 = "UIBY3D";                         
        // 0x00BAA0C4: LDR w8, [x23, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00BAA0C8: CBNZ w8, #0xbaa0d8         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_19;
        // 0x00BAA0CC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "UIBY3D", ????);   
        // 0x00BAA0D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA0D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UIBY3D", ????);   
        label_19:
        // 0x00BAA0D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA0DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA0E0: MOV x1, x23                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAA0E4: STR x24, [x23, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "UIBY3D";  //  dest_result_addr=1152921504948897200
        typeof(System.String[]).__il2cppRuntimeField_20 = "UIBY3D";
        // 0x00BAA0E8: BL #0x1a73324              | X0 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        int val_16 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        // 0x00BAA0EC: MOV w23, w0                | W23 = val_16;//m1                       
        // 0x00BAA0F0: CBNZ x21, #0xbaa0f8        | if (val_14.uiCamera != null) goto label_20;
        if(val_14.uiCamera != null)
        {
            goto label_20;
        }
        // 0x00BAA0F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_20:
        // 0x00BAA0F8: ORR w1, w23, w22           | W1 = (val_16 | val_15);                 
        int val_17 = val_16 | val_15;
        // 0x00BAA0FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA100: MOV x0, x21                | X0 = val_14.uiCamera;//m1               
        // 0x00BAA104: BL #0x20cf678              | val_14.uiCamera.set_cullingMask(value:  int val_17 = val_16 | val_15);
        val_14.uiCamera.cullingMask = val_17;
        // 0x00BAA108: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA10C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA110: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_18 = ZMG.GlobalGOMgr;
        // 0x00BAA114: MOV x21, x0                | X21 = val_18;//m1                       
        // 0x00BAA118: CBNZ x21, #0xbaa120        | if (val_18 != null) goto label_21;      
        if(val_18 != null)
        {
            goto label_21;
        }
        // 0x00BAA11C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_21:
        // 0x00BAA120: LDR x21, [x21, #0x40]      | X21 = val_18.maskGO; //P2               
        // 0x00BAA124: CBNZ x21, #0xbaa12c        | if (val_18.maskGO != null) goto label_22;
        if(val_18.maskGO != null)
        {
            goto label_22;
        }
        // 0x00BAA128: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_22:
        // 0x00BAA12C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAA130: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA134: MOV x0, x21                | X0 = val_18.maskGO;//m1                 
        // 0x00BAA138: BL #0x1a62d64              | val_18.maskGO.SetActive(value:  false); 
        val_18.maskGO.SetActive(value:  false);
        // 0x00BAA13C: CBNZ x20, #0xbaa144        | if (val_12 != null) goto label_23;      
        if(val_12 != null)
        {
            goto label_23;
        }
        // 0x00BAA140: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18.maskGO, ????);
        label_23:
        // 0x00BAA144: LDR x21, [x20, #0x18]      | X21 = val_12.target; //P2               
        // 0x00BAA148: CBNZ x21, #0xbaa150        | if (val_12.target != null) goto label_24;
        if(val_12.target != null)
        {
            goto label_24;
        }
        // 0x00BAA14C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18.maskGO, ????);
        label_24:
        // 0x00BAA150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA154: MOV x0, x21                | X0 = val_12.target;//m1                 
        // 0x00BAA158: BL #0x20d50fc              | X0 = val_12.target.get_gameObject();    
        UnityEngine.GameObject val_19 = val_12.target.gameObject;
        // 0x00BAA15C: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00BAA160: LDR x8, [x8, #0xa10]       | X8 = (string**)(1152921513542678400)("Player");
        // 0x00BAA164: MOV x21, x0                | X21 = val_19;//m1                       
        // 0x00BAA168: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA16C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA170: LDR x1, [x8]               | X1 = "Player";                          
        // 0x00BAA174: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_20 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00BAA178: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00BAA17C: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x00BAA180: MOV w22, w0                | W22 = val_20;//m1                       
        // 0x00BAA184: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x00BAA188: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00BAA18C: TBZ w9, #0, #0xbaa1a0      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_26;
        // 0x00BAA190: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00BAA194: CBNZ w9, #0xbaa1a0         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
        // 0x00BAA198: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00BAA19C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_26:
        // 0x00BAA1A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA1A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAA1A8: MOV x1, x21                | X1 = val_19;//m1                        
        // 0x00BAA1AC: MOV w2, w22                | W2 = val_20;//m1                        
        // 0x00BAA1B0: BL #0xd0b554               | NGUITools.SetLayer(go:  0, layer:  val_19);
        NGUITools.SetLayer(go:  0, layer:  val_19);
        // 0x00BAA1B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA1B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA1BC: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_21 = ZMG.EffectMgr;
        // 0x00BAA1C0: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00BAA1C4: LDR x8, [x8, #0xa0]        | X8 = (string**)(1152921514488840448)("SkillEffect");
        // 0x00BAA1C8: MOV x21, x0                | X21 = val_21;//m1                       
        // 0x00BAA1CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA1D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA1D4: LDR x1, [x8]               | X1 = "SkillEffect";                     
        // 0x00BAA1D8: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_22 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00BAA1DC: MOV w22, w0                | W22 = val_22;//m1                       
        // 0x00BAA1E0: CBNZ x21, #0xbaa1e8        | if (val_21 != null) goto label_27;      
        if(val_21 != null)
        {
            goto label_27;
        }
        // 0x00BAA1E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_27:
        // 0x00BAA1E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA1EC: MOV x0, x21                | X0 = val_21;//m1                        
        // 0x00BAA1F0: MOV w1, w22                | W1 = val_22;//m1                        
        // 0x00BAA1F4: BL #0xb60654               | val_21.SetEffectLayer(layer:  val_22);  
        val_21.SetEffectLayer(layer:  val_22);
        // 0x00BAA1F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA1FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA200: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_23 = ZMG.EffectMgr;
        // 0x00BAA204: MOV x21, x0                | X21 = val_23;//m1                       
        // 0x00BAA208: CBNZ x21, #0xbaa210        | if (val_23 != null) goto label_28;      
        if(val_23 != null)
        {
            goto label_28;
        }
        // 0x00BAA20C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_28:
        // 0x00BAA210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA214: MOV x0, x21                | X0 = val_23;//m1                        
        // 0x00BAA218: BL #0xb62f34               | val_23.SetEffectCancelPause();          
        val_23.SetEffectCancelPause();
        // 0x00BAA21C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA220: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA224: BL #0x26a8300              | X0 = ZMG.get_SoundMgr();                
        SoundMgr val_24 = ZMG.SoundMgr;
        // 0x00BAA228: MOV x21, x0                | X21 = val_24;//m1                       
        // 0x00BAA22C: CBNZ x21, #0xbaa234        | if (val_24 != null) goto label_29;      
        if(val_24 != null)
        {
            goto label_29;
        }
        // 0x00BAA230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_29:
        // 0x00BAA234: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA238: MOV x0, x21                | X0 = val_24;//m1                        
        // 0x00BAA23C: BL #0xae8538               | val_24.SetBlackCancelPause();           
        val_24.SetBlackCancelPause();
        // 0x00BAA240: CBNZ x20, #0xbaa248        | if (val_12 != null) goto label_30;      
        if(val_12 != null)
        {
            goto label_30;
        }
        // 0x00BAA244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_30:
        // 0x00BAA248: MOV x0, x20                | X0 = val_12;//m1                        
        // 0x00BAA24C: BL #0xbaa380               | val_12.FarAway();                       
        val_12.FarAway();
        // 0x00BAA250: B #0xbaa314                |  goto label_34;                         
        goto label_34;
        label_1:
        // 0x00BAA254: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAA258: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAA25C: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAA260: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAA264: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAA268: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAA26C: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAA270: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00BAA274: RET                        |  return;                                
        return;
        label_2:
        // 0x00BAA278: LDR s12, [x19, #0x30]      | S12 = this.zoomOutDamping; //P2         
        val_33 = this.zoomOutDamping;
        // 0x00BAA27C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA280: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA284: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_25 = UnityEngine.Time.deltaTime;
        // 0x00BAA288: LDR s13, [x19, #0x30]      | S13 = this.zoomOutDamping; //P2         
        // 0x00BAA28C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA290: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA294: MOV v8.16b, v0.16b         | V8 = val_25;//m1                        
        // 0x00BAA298: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_26 = UnityEngine.Time.deltaTime;
        // 0x00BAA29C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BAA2A0: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BAA2A4: LDR s10, [x19, #0x50]      | S10 = this.baseTime; //P2               
        // 0x00BAA2A8: LDR s14, [x19, #0x3c]      | S14 = this.mZoomOutTime; //P2           
        val_34 = this.mZoomOutTime;
        // 0x00BAA2AC: MOV v9.16b, v0.16b         | V9 = val_26;//m1                        
        // 0x00BAA2B0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BAA2B4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BAA2B8: TBZ w8, #0, #0xbaa2c8      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_33;
        // 0x00BAA2BC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BAA2C0: CBNZ w8, #0xbaa2c8         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
        // 0x00BAA2C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_33:
        // 0x00BAA2C8: FDIV s0, s10, s14          | S0 = (this.baseTime / this.mZoomOutTime);
        float val_27 = this.baseTime / val_34;
        // 0x00BAA2CC: FMOV s10, #1.00000000      | S10 = 1;                                
        val_35 = 1f;
        // 0x00BAA2D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA2D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA2D8: MOV v1.16b, v10.16b        | V1 = 1;//m1                             
        // 0x00BAA2DC: BL #0x1a7d7bc              | X0 = UnityEngine.Mathf.Min(a:  float val_27 = this.baseTime / val_34, b:  val_35);
        float val_28 = UnityEngine.Mathf.Min(a:  val_27, b:  val_35);
        // 0x00BAA2E0: FMUL s2, s13, s9           | S2 = (this.zoomOutDamping * val_26);    
        float val_29 = this.zoomOutDamping * val_26;
        // 0x00BAA2E4: FSUB s3, s10, s0           | S3 = (val_35 - val_28);                 
        float val_30 = val_35 - val_28;
        // 0x00BAA2E8: LDR s0, [x19, #0x4c]       | S0 = this.fieldMax; //P2                
        // 0x00BAA2EC: FMUL s1, s12, s8           | S1 = (this.zoomOutDamping * val_25);    
        float val_31 = val_33 * val_25;
        // 0x00BAA2F0: FMUL s2, s2, s3            | S2 = ((this.zoomOutDamping * val_26) * (val_35 - val_28));
        val_29 = val_29 * val_30;
        // 0x00BAA2F4: FADD s1, s1, s2            | S1 = ((this.zoomOutDamping * val_25) + ((this.zoomOutDamping * val_26) * (val_35 - val_28)));
        val_31 = val_31 + val_29;
        // 0x00BAA2F8: FADD s1, s11, s1           | S1 = (this.curFieldView + ((this.zoomOutDamping * val_25) + ((this.zoomOutDamping * val_26) * (val_35 - val_28))));
        val_31 = this.curFieldView + val_31;
        // 0x00BAA2FC: STR s1, [x19, #0x48]       | this.curFieldView = (this.curFieldView + ((this.zoomOutDamping * val_25) + ((this.zoomOutDamping * val_26) * (val_35 - val_28))));  //  dest_result_addr=1152921514488881000
        this.curFieldView = val_31;
        // 0x00BAA300: FCMP s1, s0                | STATE = COMPARE((this.curFieldView + ((this.zoomOutDamping * val_25) + ((this.zoomOutDamping * val_26) * (val_35 - val_28)))), this.fieldMax)
        // 0x00BAA304: B.LT #0xbaa314             | if (val_31 < this.fieldMax) goto label_34;
        if(val_31 < this.fieldMax)
        {
            goto label_34;
        }
        // 0x00BAA308: STR wzr, [x19, #0x50]      | this.baseTime = 0;                       //  dest_result_addr=1152921514488881008
        this.baseTime = 0f;
        // 0x00BAA30C: STR s0, [x19, #0x48]       | this.curFieldView = this.fieldMax;       //  dest_result_addr=1152921514488881000
        this.curFieldView = this.fieldMax;
        // 0x00BAA310: STRB wzr, [x19, #0x44]     | this.bInScaler = false;                  //  dest_result_addr=1152921514488880996
        this.bInScaler = false;
        label_34:
        // 0x00BAA314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA318: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA31C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_32 = UnityEngine.Camera.main;
        // 0x00BAA320: LDR s8, [x19, #0x48]       | S8 = this.curFieldView; //P2            
        // 0x00BAA324: MOV x20, x0                | X20 = val_32;//m1                       
        // 0x00BAA328: CBNZ x20, #0xbaa330        | if (val_32 != null) goto label_35;      
        if(val_32 != null)
        {
            goto label_35;
        }
        // 0x00BAA32C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_35:
        // 0x00BAA330: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA334: MOV x0, x20                | X0 = val_32;//m1                        
        // 0x00BAA338: MOV v0.16b, v8.16b         | V0 = this.curFieldView;//m1             
        // 0x00BAA33C: BL #0x20ce824              | val_32.set_fieldOfView(value:  this.curFieldView);
        val_32.fieldOfView = this.curFieldView;
        // 0x00BAA340: LDR x20, [x19, #0x70]      | X20 = this.effectCamera; //P2           
        // 0x00BAA344: LDR s8, [x19, #0x48]       | S8 = this.curFieldView; //P2            
        // 0x00BAA348: CBNZ x20, #0xbaa350        | if (this.effectCamera != null) goto label_36;
        if(this.effectCamera != null)
        {
            goto label_36;
        }
        // 0x00BAA34C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_36:
        // 0x00BAA350: MOV x0, x20                | X0 = this.effectCamera;//m1             
        // 0x00BAA354: MOV v0.16b, v8.16b         | V0 = this.curFieldView;//m1             
        // 0x00BAA358: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAA35C: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAA360: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAA364: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAA368: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAA36C: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAA370: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAA374: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA378: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00BAA37C: B #0x20ce824               | this.effectCamera.set_fieldOfView(value:  this.curFieldView); return;
        this.effectCamera.fieldOfView = this.curFieldView;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAA4F8 (12231928), len: 932  VirtAddr: 0x00BAA4F8 RVA: 0x00BAA4F8 token: 100690222 methodIndex: 25680 delegateWrapperIndex: 0 methodInvoker: 0
    public void ScalerClear()
    {
        //
        // Disasemble & Code
        // 0x00BAA4F8: STP d9, d8, [sp, #-0x50]!  | stack[1152921514489111920] = ???;  stack[1152921514489111928] = ???;  //  dest_result_addr=1152921514489111920 |  dest_result_addr=1152921514489111928
        // 0x00BAA4FC: STP x24, x23, [sp, #0x10]  | stack[1152921514489111936] = ???;  stack[1152921514489111944] = ???;  //  dest_result_addr=1152921514489111936 |  dest_result_addr=1152921514489111944
        // 0x00BAA500: STP x22, x21, [sp, #0x20]  | stack[1152921514489111952] = ???;  stack[1152921514489111960] = ???;  //  dest_result_addr=1152921514489111952 |  dest_result_addr=1152921514489111960
        // 0x00BAA504: STP x20, x19, [sp, #0x30]  | stack[1152921514489111968] = ???;  stack[1152921514489111976] = ???;  //  dest_result_addr=1152921514489111968 |  dest_result_addr=1152921514489111976
        // 0x00BAA508: STP x29, x30, [sp, #0x40]  | stack[1152921514489111984] = ???;  stack[1152921514489111992] = ???;  //  dest_result_addr=1152921514489111984 |  dest_result_addr=1152921514489111992
        // 0x00BAA50C: ADD x29, sp, #0x40         | X29 = (1152921514489111920 + 64) = 1152921514489111984 (0x100000024D0765B0);
        // 0x00BAA510: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAA514: LDRB w8, [x20, #0xaf5]     | W8 = (bool)static_value_03733AF5;       
        // 0x00BAA518: MOV x19, x0                | X19 = 1152921514489124000 (0x100000024D0794A0);//ML01
        // 0x00BAA51C: TBNZ w8, #0, #0xbaa538     | if (static_value_03733AF5 == true) goto label_0;
        // 0x00BAA520: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00BAA524: LDR x8, [x8, #0x58]        | X8 = 0x2B9020C;                         
        // 0x00BAA528: LDR w0, [x8]               | W0 = 0x1747;                            
        // 0x00BAA52C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1747, ????);     
        // 0x00BAA530: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAA534: STRB w8, [x20, #0xaf5]     | static_value_03733AF5 = true;            //  dest_result_addr=57883381
        label_0:
        // 0x00BAA538: LDRB w8, [x19, #0x45]      | W8 = this.bZoomIn; //P2                 
        // 0x00BAA53C: CBZ w8, #0xbaa884          | if (this.bZoomIn == false) goto label_1;
        if(this.bZoomIn == false)
        {
            goto label_1;
        }
        // 0x00BAA540: LDR w8, [x19, #0x18]       | W8 = this.fieldMin; //P2                
        // 0x00BAA544: STR wzr, [x19, #0x50]      | this.baseTime = 0;                       //  dest_result_addr=1152921514489124080
        this.baseTime = 0f;
        // 0x00BAA548: STR w8, [x19, #0x48]       | this.curFieldView = this.fieldMin;       //  dest_result_addr=1152921514489124072
        this.curFieldView = this.fieldMin;
        // 0x00BAA54C: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BAA550: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BAA554: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BAA558: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BAA55C: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BAA560: CBNZ x20, #0xbaa568        | if (GameMgr.UPDATEOnOffEffect != null) goto label_2;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_2;
        }
        // 0x00BAA564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1747, ????);     
        label_2:
        // 0x00BAA568: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA56C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAA570: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BAA574: BL #0xc181f8               | GameMgr.UPDATEOnOffEffect.ReActiveGameSpeedBtn(_IsActive:  true);
        GameMgr.UPDATEOnOffEffect.ReActiveGameSpeedBtn(_IsActive:  true);
        // 0x00BAA578: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BAA57C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00BAA580: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00BAA584: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BAA588: TBZ w8, #0, #0xbaa598      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00BAA58C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BAA590: CBNZ w8, #0xbaa598         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00BAA594: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_4:
        // 0x00BAA598: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA59C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA5A0: BL #0x26a81b0              | X0 = ZMG.get_TimeMgr();                 
        TimeMgr val_1 = ZMG.TimeMgr;
        // 0x00BAA5A4: LDR s8, [x19, #0x1c]       | S8 = this.timeScale; //P2               
        // 0x00BAA5A8: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00BAA5AC: CBNZ x20, #0xbaa5b4        | if (val_1 != null) goto label_5;        
        if(val_1 != null)
        {
            goto label_5;
        }
        // 0x00BAA5B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00BAA5B4: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00BAA5B8: LDR x8, [x8, #0xe78]       | X8 = (string**)(1152921511103233552)("CAMERAHELPER");
        // 0x00BAA5BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA5C0: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00BAA5C4: MOV v0.16b, v8.16b         | V0 = this.timeScale;//m1                
        // 0x00BAA5C8: LDR x1, [x8]               | X1 = "CAMERAHELPER";                    
        // 0x00BAA5CC: BL #0xdf13f0               | val_1.DelTimeScale(timeScale:  this.timeScale, timeKey:  "CAMERAHELPER");
        val_1.DelTimeScale(timeScale:  this.timeScale, timeKey:  "CAMERAHELPER");
        // 0x00BAA5D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA5D4: MOV x0, x19                | X0 = 1152921514489124000 (0x100000024D0794A0);//ML01
        // 0x00BAA5D8: STRB wzr, [x19, #0x45]     | this.bZoomIn = false;                    //  dest_result_addr=1152921514489124069
        this.bZoomIn = false;
        // 0x00BAA5DC: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_2 = this.gameObject;
        // 0x00BAA5E0: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00BAA5E4: CBNZ x20, #0xbaa5ec        | if (val_2 != null) goto label_6;        
        if(val_2 != null)
        {
            goto label_6;
        }
        // 0x00BAA5E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00BAA5EC: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00BAA5F0: LDR x8, [x8, #0x50]        | X8 = 1152921514488794288;               
        // 0x00BAA5F4: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00BAA5F8: LDR x1, [x8]               | X1 = public CameraMove UnityEngine.GameObject::GetComponent<CameraMove>();
        // 0x00BAA5FC: BL #0x23d5abc              | X0 = val_2.GetComponent<CameraMove>();  
        CameraMove val_3 = val_2.GetComponent<CameraMove>();
        // 0x00BAA600: LDR x20, [x19, #0x70]      | X20 = this.effectCamera; //P2           
        // 0x00BAA604: MOV x19, x0                | X19 = val_3;//m1                        
        // 0x00BAA608: CBNZ x20, #0xbaa610        | if (this.effectCamera != null) goto label_7;
        if(this.effectCamera != null)
        {
            goto label_7;
        }
        // 0x00BAA60C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00BAA610: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAA614: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA618: MOV x0, x20                | X0 = this.effectCamera;//m1             
        // 0x00BAA61C: BL #0x20cb458              | this.effectCamera.set_enabled(value:  false);
        this.effectCamera.enabled = false;
        // 0x00BAA620: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA628: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_4 = ZMG.GlobalGOMgr;
        // 0x00BAA62C: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00BAA630: CBNZ x20, #0xbaa638        | if (val_4 != null) goto label_8;        
        if(val_4 != null)
        {
            goto label_8;
        }
        // 0x00BAA634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x00BAA638: LDR x20, [x20, #0x38]      | X20 = val_4.uiBy3dCamera; //P2          
        // 0x00BAA63C: CBNZ x20, #0xbaa644        | if (val_4.uiBy3dCamera != null) goto label_9;
        if(val_4.uiBy3dCamera != null)
        {
            goto label_9;
        }
        // 0x00BAA640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00BAA644: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAA648: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA64C: MOV x0, x20                | X0 = val_4.uiBy3dCamera;//m1            
        // 0x00BAA650: BL #0x20cb458              | val_4.uiBy3dCamera.set_enabled(value:  false);
        val_4.uiBy3dCamera.enabled = false;
        // 0x00BAA654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA65C: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_5 = ZMG.GlobalGOMgr;
        // 0x00BAA660: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00BAA664: CBNZ x20, #0xbaa66c        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00BAA668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00BAA66C: LDR x20, [x20, #0x20]      | X20 = val_5.uiCamera; //P2              
        // 0x00BAA670: CBNZ x20, #0xbaa678        | if (val_5.uiCamera != null) goto label_11;
        if(val_5.uiCamera != null)
        {
            goto label_11;
        }
        // 0x00BAA674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_11:
        // 0x00BAA678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA67C: MOV x0, x20                | X0 = val_5.uiCamera;//m1                
        // 0x00BAA680: BL #0x20cf610              | X0 = val_5.uiCamera.get_cullingMask();  
        int val_6 = val_5.uiCamera.cullingMask;
        // 0x00BAA684: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00BAA688: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
        // 0x00BAA68C: MOV w21, w0                | W21 = val_6;//m1                        
        // 0x00BAA690: LDR x22, [x8]              | X22 = typeof(System.String[]);          
        // 0x00BAA694: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAA698: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
        // 0x00BAA69C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAA6A0: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAA6A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
        // 0x00BAA6A8: MOV x22, x0                | X22 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAA6AC: CBNZ x22, #0xbaa6b4        | if ( != null) goto label_12;            
        if(null != null)
        {
            goto label_12;
        }
        // 0x00BAA6B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
        label_12:
        // 0x00BAA6B4: ADRP x23, #0x35d1000       | X23 = 56430592 (0x35D1000);             
        // 0x00BAA6B8: LDR x23, [x23, #0x450]     | X23 = (string**)(1152921514488819888)("UIBY3D");
        // 0x00BAA6BC: LDR x0, [x23]              | X0 = "UIBY3D";                          
        // 0x00BAA6C0: CBZ x0, #0xbaa6e0          | if ("UIBY3D" == null) goto label_14;    
        // 0x00BAA6C4: LDR x8, [x22]              | X8 = ;                                  
        // 0x00BAA6C8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BAA6CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "UIBY3D", ????);   
        // 0x00BAA6D0: CBNZ x0, #0xbaa6e0         | if ("UIBY3D" != null) goto label_14;    
        if("UIBY3D" != null)
        {
            goto label_14;
        }
        // 0x00BAA6D4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "UIBY3D", ????);   
        // 0x00BAA6D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA6DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UIBY3D", ????);   
        label_14:
        // 0x00BAA6E0: LDR x23, [x23]             | X23 = "UIBY3D";                         
        // 0x00BAA6E4: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00BAA6E8: CBNZ w8, #0xbaa6f8         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_15;
        // 0x00BAA6EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "UIBY3D", ????);   
        // 0x00BAA6F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA6F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UIBY3D", ????);   
        label_15:
        // 0x00BAA6F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA6FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA700: MOV x1, x22                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAA704: STR x23, [x22, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "UIBY3D";  //  dest_result_addr=1152921504948897200
        typeof(System.String[]).__il2cppRuntimeField_20 = "UIBY3D";
        // 0x00BAA708: BL #0x1a73324              | X0 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        int val_7 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        // 0x00BAA70C: MOV w22, w0                | W22 = val_7;//m1                        
        // 0x00BAA710: CBNZ x20, #0xbaa718        | if (val_5.uiCamera != null) goto label_16;
        if(val_5.uiCamera != null)
        {
            goto label_16;
        }
        // 0x00BAA714: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_16:
        // 0x00BAA718: ORR w1, w22, w21           | W1 = (val_7 | val_6);                   
        int val_8 = val_7 | val_6;
        // 0x00BAA71C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA720: MOV x0, x20                | X0 = val_5.uiCamera;//m1                
        // 0x00BAA724: BL #0x20cf678              | val_5.uiCamera.set_cullingMask(value:  int val_8 = val_7 | val_6);
        val_5.uiCamera.cullingMask = val_8;
        // 0x00BAA728: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA72C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA730: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_9 = ZMG.GlobalGOMgr;
        // 0x00BAA734: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00BAA738: CBNZ x20, #0xbaa740        | if (val_9 != null) goto label_17;       
        if(val_9 != null)
        {
            goto label_17;
        }
        // 0x00BAA73C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_17:
        // 0x00BAA740: LDR x20, [x20, #0x40]      | X20 = val_9.maskGO; //P2                
        // 0x00BAA744: CBNZ x20, #0xbaa74c        | if (val_9.maskGO != null) goto label_18;
        if(val_9.maskGO != null)
        {
            goto label_18;
        }
        // 0x00BAA748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_18:
        // 0x00BAA74C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAA750: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA754: MOV x0, x20                | X0 = val_9.maskGO;//m1                  
        // 0x00BAA758: BL #0x1a62d64              | val_9.maskGO.SetActive(value:  false);  
        val_9.maskGO.SetActive(value:  false);
        // 0x00BAA75C: CBNZ x19, #0xbaa764        | if (val_3 != null) goto label_19;       
        if(val_3 != null)
        {
            goto label_19;
        }
        // 0x00BAA760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9.maskGO, ????);
        label_19:
        // 0x00BAA764: LDR x20, [x19, #0x18]      | X20 = val_3.target; //P2                
        // 0x00BAA768: CBNZ x20, #0xbaa770        | if (val_3.target != null) goto label_20;
        if(val_3.target != null)
        {
            goto label_20;
        }
        // 0x00BAA76C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9.maskGO, ????);
        label_20:
        // 0x00BAA770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA774: MOV x0, x20                | X0 = val_3.target;//m1                  
        // 0x00BAA778: BL #0x20d50fc              | X0 = val_3.target.get_gameObject();     
        UnityEngine.GameObject val_10 = val_3.target.gameObject;
        // 0x00BAA77C: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00BAA780: LDR x8, [x8, #0xa10]       | X8 = (string**)(1152921513542678400)("Player");
        // 0x00BAA784: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00BAA788: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA78C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA790: LDR x1, [x8]               | X1 = "Player";                          
        // 0x00BAA794: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_11 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00BAA798: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00BAA79C: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x00BAA7A0: MOV w21, w0                | W21 = val_11;//m1                       
        // 0x00BAA7A4: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x00BAA7A8: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00BAA7AC: TBZ w9, #0, #0xbaa7c0      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_22;
        // 0x00BAA7B0: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00BAA7B4: CBNZ w9, #0xbaa7c0         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
        // 0x00BAA7B8: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00BAA7BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_22:
        // 0x00BAA7C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA7C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAA7C8: MOV x1, x20                | X1 = val_10;//m1                        
        // 0x00BAA7CC: MOV w2, w21                | W2 = val_11;//m1                        
        // 0x00BAA7D0: BL #0xd0b554               | NGUITools.SetLayer(go:  0, layer:  val_10);
        NGUITools.SetLayer(go:  0, layer:  val_10);
        // 0x00BAA7D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA7D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA7DC: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_12 = ZMG.EffectMgr;
        // 0x00BAA7E0: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00BAA7E4: LDR x8, [x8, #0xa0]        | X8 = (string**)(1152921514488840448)("SkillEffect");
        // 0x00BAA7E8: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00BAA7EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA7F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA7F4: LDR x1, [x8]               | X1 = "SkillEffect";                     
        // 0x00BAA7F8: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_13 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00BAA7FC: MOV w21, w0                | W21 = val_13;//m1                       
        // 0x00BAA800: CBNZ x20, #0xbaa808        | if (val_12 != null) goto label_23;      
        if(val_12 != null)
        {
            goto label_23;
        }
        // 0x00BAA804: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_23:
        // 0x00BAA808: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA80C: MOV x0, x20                | X0 = val_12;//m1                        
        // 0x00BAA810: MOV w1, w21                | W1 = val_13;//m1                        
        // 0x00BAA814: BL #0xb60654               | val_12.SetEffectLayer(layer:  val_13);  
        val_12.SetEffectLayer(layer:  val_13);
        // 0x00BAA818: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA81C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA820: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_14 = ZMG.EffectMgr;
        // 0x00BAA824: MOV x20, x0                | X20 = val_14;//m1                       
        // 0x00BAA828: CBNZ x20, #0xbaa830        | if (val_14 != null) goto label_24;      
        if(val_14 != null)
        {
            goto label_24;
        }
        // 0x00BAA82C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_24:
        // 0x00BAA830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA834: MOV x0, x20                | X0 = val_14;//m1                        
        // 0x00BAA838: BL #0xb62f34               | val_14.SetEffectCancelPause();          
        val_14.SetEffectCancelPause();
        // 0x00BAA83C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA840: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA844: BL #0x26a8300              | X0 = ZMG.get_SoundMgr();                
        SoundMgr val_15 = ZMG.SoundMgr;
        // 0x00BAA848: MOV x20, x0                | X20 = val_15;//m1                       
        // 0x00BAA84C: CBNZ x20, #0xbaa854        | if (val_15 != null) goto label_25;      
        if(val_15 != null)
        {
            goto label_25;
        }
        // 0x00BAA850: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_25:
        // 0x00BAA854: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA858: MOV x0, x20                | X0 = val_15;//m1                        
        // 0x00BAA85C: BL #0xae8538               | val_15.SetBlackCancelPause();           
        val_15.SetBlackCancelPause();
        // 0x00BAA860: CBNZ x19, #0xbaa868        | if (val_3 != null) goto label_26;       
        if(val_3 != null)
        {
            goto label_26;
        }
        // 0x00BAA864: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_26:
        // 0x00BAA868: MOV x0, x19                | X0 = val_3;//m1                         
        // 0x00BAA86C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAA870: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAA874: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAA878: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAA87C: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00BAA880: B #0xbaa380                | val_3.FarAway(); return;                
        val_3.FarAway();
        return;
        label_1:
        // 0x00BAA884: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAA888: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAA88C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAA890: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAA894: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00BAA898: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAA89C (12232860), len: 1508  VirtAddr: 0x00BAA89C RVA: 0x00BAA89C token: 100690223 methodIndex: 25681 delegateWrapperIndex: 0 methodInvoker: 0
    public void Scaler(UnityEngine.Transform target, float zoomInTime, float waitTime, float zoomOutTime, UnityEngine.Vector3 zoominoffset)
    {
        //
        // Disasemble & Code
        //  | 
        int val_29;
        //  | 
        var val_30;
        //  | 
        var val_31;
        //  | 
        var val_32;
        //  | 
        UnityEngine.Vector3 val_33;
        //  | 
        var val_34;
        // 0x00BAA89C: STP d15, d14, [sp, #-0x90]! | stack[1152921514489376528] = ???;  stack[1152921514489376536] = ???;  //  dest_result_addr=1152921514489376528 |  dest_result_addr=1152921514489376536
        // 0x00BAA8A0: STP d13, d12, [sp, #0x10]  | stack[1152921514489376544] = ???;  stack[1152921514489376552] = ???;  //  dest_result_addr=1152921514489376544 |  dest_result_addr=1152921514489376552
        // 0x00BAA8A4: STP d11, d10, [sp, #0x20]  | stack[1152921514489376560] = ???;  stack[1152921514489376568] = ???;  //  dest_result_addr=1152921514489376560 |  dest_result_addr=1152921514489376568
        // 0x00BAA8A8: STP d9, d8, [sp, #0x30]    | stack[1152921514489376576] = ???;  stack[1152921514489376584] = ???;  //  dest_result_addr=1152921514489376576 |  dest_result_addr=1152921514489376584
        // 0x00BAA8AC: STP x26, x25, [sp, #0x40]  | stack[1152921514489376592] = ???;  stack[1152921514489376600] = ???;  //  dest_result_addr=1152921514489376592 |  dest_result_addr=1152921514489376600
        // 0x00BAA8B0: STP x24, x23, [sp, #0x50]  | stack[1152921514489376608] = ???;  stack[1152921514489376616] = ???;  //  dest_result_addr=1152921514489376608 |  dest_result_addr=1152921514489376616
        // 0x00BAA8B4: STP x22, x21, [sp, #0x60]  | stack[1152921514489376624] = ???;  stack[1152921514489376632] = ???;  //  dest_result_addr=1152921514489376624 |  dest_result_addr=1152921514489376632
        // 0x00BAA8B8: STP x20, x19, [sp, #0x70]  | stack[1152921514489376640] = ???;  stack[1152921514489376648] = ???;  //  dest_result_addr=1152921514489376640 |  dest_result_addr=1152921514489376648
        // 0x00BAA8BC: STP x29, x30, [sp, #0x80]  | stack[1152921514489376656] = ???;  stack[1152921514489376664] = ???;  //  dest_result_addr=1152921514489376656 |  dest_result_addr=1152921514489376664
        // 0x00BAA8C0: ADD x29, sp, #0x80         | X29 = (1152921514489376528 + 128) = 1152921514489376656 (0x100000024D0B6F90);
        // 0x00BAA8C4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BAA8C8: LDRB w8, [x21, #0xaf6]     | W8 = (bool)static_value_03733AF6;       
        // 0x00BAA8CC: MOV v8.16b, v5.16b         | V8 = zoominoffset.z;//m1                
        // 0x00BAA8D0: MOV v9.16b, v4.16b         | V9 = zoominoffset.y;//m1                
        // 0x00BAA8D4: MOV v10.16b, v3.16b        | V10 = zoominoffset.x;//m1               
        // 0x00BAA8D8: MOV v12.16b, v2.16b        | V12 = zoomOutTime;//m1                  
        float val_29 = zoomOutTime;
        // 0x00BAA8DC: MOV v13.16b, v1.16b        | V13 = waitTime;//m1                     
        // 0x00BAA8E0: MOV v11.16b, v0.16b        | V11 = zoomInTime;//m1                   
        // 0x00BAA8E4: MOV x20, x1                | X20 = target;//m1                       
        // 0x00BAA8E8: MOV x19, x0                | X19 = 1152921514489388672 (0x100000024D0B9E80);//ML01
        // 0x00BAA8EC: TBNZ w8, #0, #0xbaa908     | if (static_value_03733AF6 == true) goto label_0;
        // 0x00BAA8F0: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x00BAA8F4: LDR x8, [x8, #0xe08]       | X8 = 0x2B90208;                         
        // 0x00BAA8F8: LDR w0, [x8]               | W0 = 0x1746;                            
        // 0x00BAA8FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1746, ????);     
        // 0x00BAA900: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAA904: STRB w8, [x21, #0xaf6]     | static_value_03733AF6 = true;            //  dest_result_addr=57883382
        label_0:
        // 0x00BAA908: FMOV s0, #0.50000000       | S0 = 0.5;                               
        float val_30 = 0.5f;
        // 0x00BAA90C: FMUL s2, s11, s0           | S2 = (zoomInTime * 0.5f);               
        float val_1 = zoomInTime * val_30;
        // 0x00BAA910: LDR s1, [x19, #0x4c]       | S1 = this.fieldMax; //P2                
        float val_31 = this.fieldMax;
        // 0x00BAA914: STP s11, s2, [x19, #0x34]  | this.zoomInTime = zoomInTime;  this.mZoomInTime = (zoomInTime * 0.5f);  //  dest_result_addr=1152921514489388724 |  dest_result_addr=1152921514489388728
        this.zoomInTime = zoomInTime;
        this.mZoomInTime = val_1;
        // 0x00BAA918: LDR s2, [x19, #0x18]       | S2 = this.fieldMin; //P2                
        // 0x00BAA91C: FADD s12, s12, s12         | S12 = (zoomOutTime + zoomOutTime);      
        val_29 = val_29 + val_29;
        // 0x00BAA920: FMUL s0, s12, s0           | S0 = ((zoomOutTime + zoomOutTime) * 0.5f);
        val_30 = val_29 * val_30;
        // 0x00BAA924: STP s0, s13, [x19, #0x3c]  | this.mZoomOutTime = ((zoomOutTime + zoomOutTime) * 0.5f);  this.waitTime = waitTime;  //  dest_result_addr=1152921514489388732 |  dest_result_addr=1152921514489388736
        this.mZoomOutTime = val_30;
        this.waitTime = waitTime;
        // 0x00BAA928: FSUB s0, s1, s2            | S0 = (this.fieldMax - this.fieldMin);   
        float val_2 = val_31 - this.fieldMin;
        // 0x00BAA92C: FDIV s1, s0, s11           | S1 = ((this.fieldMax - this.fieldMin) / zoomInTime);
        val_31 = val_2 / zoomInTime;
        // 0x00BAA930: FDIV s0, s0, s12           | S0 = ((this.fieldMax - this.fieldMin) / (zoomOutTime + zoomOutTime));
        val_2 = val_2 / val_29;
        // 0x00BAA934: STP s1, s0, [x19, #0x2c]   | this.zoomInDamping = ((this.fieldMax - this.fieldMin) / zoomInTime);  this.zoomOutDamping = ((this.fieldMax - this.fieldMin) / (zoomOutTime + zoomOutTime));  //  dest_result_addr=1152921514489388716 |  dest_result_addr=1152921514489388720
        this.zoomInDamping = val_31;
        this.zoomOutDamping = val_2;
        // 0x00BAA938: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BAA93C: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BAA940: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BAA944: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BAA948: LDR x21, [x8]              | X21 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BAA94C: CBNZ x21, #0xbaa954        | if (GameMgr.UPDATEOnOffEffect != null) goto label_1;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_1;
        }
        // 0x00BAA950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1746, ????);     
        label_1:
        // 0x00BAA954: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAA958: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA95C: MOV x0, x21                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BAA960: BL #0xc181f8               | GameMgr.UPDATEOnOffEffect.ReActiveGameSpeedBtn(_IsActive:  false);
        GameMgr.UPDATEOnOffEffect.ReActiveGameSpeedBtn(_IsActive:  false);
        // 0x00BAA964: ADRP x24, #0x3668000       | X24 = 57049088 (0x3668000);             
        // 0x00BAA968: LDR x24, [x24, #0x960]     | X24 = 1152921504911851520;              
        // 0x00BAA96C: LDR x0, [x24]              | X0 = typeof(ZMG);                       
        // 0x00BAA970: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BAA974: TBZ w8, #0, #0xbaa984      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00BAA978: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BAA97C: CBNZ w8, #0xbaa984         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00BAA980: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_3:
        // 0x00BAA984: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA98C: BL #0x26a81b0              | X0 = ZMG.get_TimeMgr();                 
        TimeMgr val_3 = ZMG.TimeMgr;
        // 0x00BAA990: LDR s13, [x19, #0x1c]      | S13 = this.timeScale; //P2              
        // 0x00BAA994: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00BAA998: CBNZ x21, #0xbaa9a0        | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00BAA99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00BAA9A0: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00BAA9A4: LDR x8, [x8, #0xe78]       | X8 = (string**)(1152921511103233552)("CAMERAHELPER");
        // 0x00BAA9A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA9AC: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00BAA9B0: MOV v0.16b, v13.16b        | V0 = this.timeScale;//m1                
        // 0x00BAA9B4: LDR x1, [x8]               | X1 = "CAMERAHELPER";                    
        // 0x00BAA9B8: BL #0xdf12f0               | val_3.AddTimeScale(timeScale:  this.timeScale, timeKey:  "CAMERAHELPER");
        val_3.AddTimeScale(timeScale:  this.timeScale, timeKey:  "CAMERAHELPER");
        // 0x00BAA9BC: LDR w8, [x19, #0x4c]       | W8 = this.fieldMax; //P2                
        // 0x00BAA9C0: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00BAA9C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA9C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA9CC: STRB w9, [x19, #0x45]      | this.bZoomIn = true;                     //  dest_result_addr=1152921514489388741
        this.bZoomIn = true;
        // 0x00BAA9D0: STR wzr, [x19, #0x50]      | this.baseTime = 0;                       //  dest_result_addr=1152921514489388752
        this.baseTime = 0f;
        // 0x00BAA9D4: STR w8, [x19, #0x48]       | this.curFieldView = this.fieldMax;       //  dest_result_addr=1152921514489388744
        this.curFieldView = this.fieldMax;
        // 0x00BAA9D8: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_4 = UnityEngine.Camera.main;
        // 0x00BAA9DC: LDR s13, [x19, #0x4c]      | S13 = this.fieldMax; //P2               
        // 0x00BAA9E0: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00BAA9E4: CBNZ x21, #0xbaa9ec        | if (val_4 != null) goto label_5;        
        if(val_4 != null)
        {
            goto label_5;
        }
        // 0x00BAA9E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_5:
        // 0x00BAA9EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA9F0: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00BAA9F4: MOV v0.16b, v13.16b        | V0 = this.fieldMax;//m1                 
        // 0x00BAA9F8: BL #0x20ce824              | val_4.set_fieldOfView(value:  this.fieldMax);
        val_4.fieldOfView = this.fieldMax;
        // 0x00BAA9FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAA00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAA04: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_5 = ZMG.GlobalGOMgr;
        // 0x00BAAA08: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00BAAA0C: CBNZ x21, #0xbaaa14        | if (val_5 != null) goto label_6;        
        if(val_5 != null)
        {
            goto label_6;
        }
        // 0x00BAAA10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x00BAAA14: LDR x21, [x21, #0x38]      | X21 = val_5.uiBy3dCamera; //P2          
        // 0x00BAAA18: CBNZ x21, #0xbaaa20        | if (val_5.uiBy3dCamera != null) goto label_7;
        if(val_5.uiBy3dCamera != null)
        {
            goto label_7;
        }
        // 0x00BAAA1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00BAAA20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAAA24: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAAA28: MOV x0, x21                | X0 = val_5.uiBy3dCamera;//m1            
        // 0x00BAAA2C: BL #0x20cb458              | val_5.uiBy3dCamera.set_enabled(value:  true);
        val_5.uiBy3dCamera.enabled = true;
        // 0x00BAAA30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAA34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAA38: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_6 = ZMG.GlobalGOMgr;
        // 0x00BAAA3C: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00BAAA40: CBNZ x21, #0xbaaa48        | if (val_6 != null) goto label_8;        
        if(val_6 != null)
        {
            goto label_8;
        }
        // 0x00BAAA44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_8:
        // 0x00BAAA48: LDR x21, [x21, #0x20]      | X21 = val_6.uiCamera; //P2              
        // 0x00BAAA4C: CBNZ x21, #0xbaaa54        | if (val_6.uiCamera != null) goto label_9;
        if(val_6.uiCamera != null)
        {
            goto label_9;
        }
        // 0x00BAAA50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_9:
        // 0x00BAAA54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAA58: MOV x0, x21                | X0 = val_6.uiCamera;//m1                
        // 0x00BAAA5C: BL #0x20cf610              | X0 = val_6.uiCamera.get_cullingMask();  
        int val_7 = val_6.uiCamera.cullingMask;
        // 0x00BAAA60: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00BAAA64: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
        // 0x00BAAA68: MOV w22, w0                | W22 = val_7;//m1                        
        // 0x00BAAA6C: LDR x23, [x8]              | X23 = typeof(System.String[]);          
        // 0x00BAAA70: MOV x0, x23                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAAA74: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
        // 0x00BAAA78: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAAA7C: MOV x0, x23                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAAA80: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
        // 0x00BAAA84: MOV x23, x0                | X23 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAAA88: CBNZ x23, #0xbaaa90        | if ( != null) goto label_10;            
        if(null != null)
        {
            goto label_10;
        }
        // 0x00BAAA8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
        label_10:
        // 0x00BAAA90: ADRP x25, #0x35d1000       | X25 = 56430592 (0x35D1000);             
        // 0x00BAAA94: LDR x25, [x25, #0x450]     | X25 = (string**)(1152921514488819888)("UIBY3D");
        // 0x00BAAA98: LDR x0, [x25]              | X0 = "UIBY3D";                          
        // 0x00BAAA9C: CBZ x0, #0xbaaabc          | if ("UIBY3D" == null) goto label_12;    
        // 0x00BAAAA0: LDR x8, [x23]              | X8 = ;                                  
        // 0x00BAAAA4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BAAAA8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "UIBY3D", ????);   
        // 0x00BAAAAC: CBNZ x0, #0xbaaabc         | if ("UIBY3D" != null) goto label_12;    
        if("UIBY3D" != null)
        {
            goto label_12;
        }
        // 0x00BAAAB0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "UIBY3D", ????);   
        // 0x00BAAAB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAAB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UIBY3D", ????);   
        label_12:
        // 0x00BAAABC: LDR x26, [x25]             | X26 = "UIBY3D";                         
        // 0x00BAAAC0: LDR w8, [x23, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00BAAAC4: CBNZ w8, #0xbaaad4         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_13;
        // 0x00BAAAC8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "UIBY3D", ????);   
        // 0x00BAAACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAAD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UIBY3D", ????);   
        label_13:
        // 0x00BAAAD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAAD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAAADC: MOV x1, x23                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAAAE0: STR x26, [x23, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "UIBY3D";  //  dest_result_addr=1152921504948897200
        typeof(System.String[]).__il2cppRuntimeField_20 = "UIBY3D";
        // 0x00BAAAE4: BL #0x1a73324              | X0 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        int val_8 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        // 0x00BAAAE8: MOV w23, w0                | W23 = val_8;//m1                        
        val_29 = val_8;
        // 0x00BAAAEC: CBNZ x21, #0xbaaaf4        | if (val_6.uiCamera != null) goto label_14;
        if(val_6.uiCamera != null)
        {
            goto label_14;
        }
        // 0x00BAAAF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_14:
        // 0x00BAAAF4: BIC w1, w22, w23           | W1 = (val_7 & (~val_8));                
        int val_9 = val_7 & (~val_29);
        // 0x00BAAAF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAAAFC: MOV x0, x21                | X0 = val_6.uiCamera;//m1                
        // 0x00BAAB00: BL #0x20cf678              | val_6.uiCamera.set_cullingMask(value:  int val_9 = val_7 & (~val_29));
        val_6.uiCamera.cullingMask = val_9;
        // 0x00BAAB04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAB08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAB0C: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_10 = ZMG.GlobalGOMgr;
        // 0x00BAAB10: MOV x21, x0                | X21 = val_10;//m1                       
        // 0x00BAAB14: CBNZ x21, #0xbaab1c        | if (val_10 != null) goto label_15;      
        if(val_10 != null)
        {
            goto label_15;
        }
        // 0x00BAAB18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_15:
        // 0x00BAAB1C: LDR x21, [x21, #0x40]      | X21 = val_10.maskGO; //P2               
        // 0x00BAAB20: CBNZ x21, #0xbaab28        | if (val_10.maskGO != null) goto label_16;
        if(val_10.maskGO != null)
        {
            goto label_16;
        }
        // 0x00BAAB24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_16:
        // 0x00BAAB28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAAB2C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAAB30: MOV x0, x21                | X0 = val_10.maskGO;//m1                 
        // 0x00BAAB34: BL #0x1a62d64              | val_10.maskGO.SetActive(value:  true);  
        val_10.maskGO.SetActive(value:  true);
        // 0x00BAAB38: LDR x21, [x19, #0x70]      | X21 = this.effectCamera; //P2           
        // 0x00BAAB3C: CBNZ x21, #0xbaab44        | if (this.effectCamera != null) goto label_17;
        if(this.effectCamera != null)
        {
            goto label_17;
        }
        // 0x00BAAB40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10.maskGO, ????);
        label_17:
        // 0x00BAAB44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAAB48: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAAB4C: MOV x0, x21                | X0 = this.effectCamera;//m1             
        // 0x00BAAB50: BL #0x20cb458              | this.effectCamera.set_enabled(value:  true);
        this.effectCamera.enabled = true;
        // 0x00BAAB54: LDR x21, [x19, #0x70]      | X21 = this.effectCamera; //P2           
        // 0x00BAAB58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAB5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAB60: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_11 = UnityEngine.Camera.main;
        // 0x00BAAB64: MOV x22, x0                | X22 = val_11;//m1                       
        // 0x00BAAB68: CBNZ x22, #0xbaab70        | if (val_11 != null) goto label_18;      
        if(val_11 != null)
        {
            goto label_18;
        }
        // 0x00BAAB6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_18:
        // 0x00BAAB70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAB74: MOV x0, x22                | X0 = val_11;//m1                        
        // 0x00BAAB78: BL #0x20ce7bc              | X0 = val_11.get_fieldOfView();          
        float val_12 = val_11.fieldOfView;
        // 0x00BAAB7C: MOV v13.16b, v0.16b        | V13 = val_12;//m1                       
        // 0x00BAAB80: CBNZ x21, #0xbaab88        | if (this.effectCamera != null) goto label_19;
        if(this.effectCamera != null)
        {
            goto label_19;
        }
        // 0x00BAAB84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_19:
        // 0x00BAAB88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAB8C: MOV x0, x21                | X0 = this.effectCamera;//m1             
        // 0x00BAAB90: MOV v0.16b, v13.16b        | V0 = val_12;//m1                        
        // 0x00BAAB94: BL #0x20ce824              | this.effectCamera.set_fieldOfView(value:  val_12);
        this.effectCamera.fieldOfView = val_12;
        // 0x00BAAB98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAB9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAABA0: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_13 = ZMG.GlobalGOMgr;
        // 0x00BAABA4: MOV x21, x0                | X21 = val_13;//m1                       
        // 0x00BAABA8: CBNZ x21, #0xbaabb0        | if (val_13 != null) goto label_20;      
        if(val_13 != null)
        {
            goto label_20;
        }
        // 0x00BAABAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_20:
        // 0x00BAABB0: LDR x21, [x21, #0x48]      | X21 = val_13.uiby3d; //P2               
        // 0x00BAABB4: CBNZ x21, #0xbaabbc        | if (val_13.uiby3d != null) goto label_21;
        if(val_13.uiby3d != null)
        {
            goto label_21;
        }
        // 0x00BAABB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_21:
        // 0x00BAABBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAABC0: MOV x0, x21                | X0 = val_13.uiby3d;//m1                 
        // 0x00BAABC4: BL #0x1a62c84              | X0 = val_13.uiby3d.get_layer();         
        int val_14 = val_13.uiby3d.layer;
        // 0x00BAABC8: LDR x1, [x25]              | X1 = "UIBY3D";                          
        // 0x00BAABCC: MOV w21, w0                | W21 = val_14;//m1                       
        // 0x00BAABD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAABD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAABD8: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_15 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00BAABDC: CMP w21, w0                | STATE = COMPARE(val_14, val_15)         
        // 0x00BAABE0: B.EQ #0xbaac64             | if (val_14 == val_15) goto label_22;    
        if(val_14 == val_15)
        {
            goto label_22;
        }
        // 0x00BAABE4: LDR x0, [x24]              | X0 = typeof(ZMG);                       
        // 0x00BAABE8: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BAABEC: TBZ w8, #0, #0xbaabfc      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_24;
        // 0x00BAABF0: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BAABF4: CBNZ w8, #0xbaabfc         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
        // 0x00BAABF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_24:
        // 0x00BAABFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAC00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAC04: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_16 = ZMG.GlobalGOMgr;
        // 0x00BAAC08: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x00BAAC0C: CBNZ x21, #0xbaac14        | if (val_16 != null) goto label_25;      
        if(val_16 != null)
        {
            goto label_25;
        }
        // 0x00BAAC10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_25:
        // 0x00BAAC14: LDR x1, [x25]              | X1 = "UIBY3D";                          
        // 0x00BAAC18: LDR x21, [x21, #0x48]      | X21 = val_16.uiby3d; //P2               
        // 0x00BAAC1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAC20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAAC24: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_17 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00BAAC28: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00BAAC2C: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x00BAAC30: MOV w22, w0                | W22 = val_17;//m1                       
        // 0x00BAAC34: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x00BAAC38: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00BAAC3C: TBZ w9, #0, #0xbaac50      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x00BAAC40: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00BAAC44: CBNZ w9, #0xbaac50         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x00BAAC48: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00BAAC4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_27:
        // 0x00BAAC50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAC54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAAC58: MOV x1, x21                | X1 = val_16.uiby3d;//m1                 
        // 0x00BAAC5C: MOV w2, w22                | W2 = val_17;//m1                        
        // 0x00BAAC60: BL #0xd0b554               | NGUITools.SetLayer(go:  0, layer:  val_16.uiby3d);
        NGUITools.SetLayer(go:  0, layer:  val_16.uiby3d);
        label_22:
        // 0x00BAAC64: CBNZ x20, #0xbaac6c        | if (target != null) goto label_28;      
        if(target != null)
        {
            goto label_28;
        }
        // 0x00BAAC68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_28:
        // 0x00BAAC6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAC70: MOV x0, x20                | X0 = target;//m1                        
        // 0x00BAAC74: BL #0x20d50fc              | X0 = target.get_gameObject();           
        UnityEngine.GameObject val_18 = target.gameObject;
        // 0x00BAAC78: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
        // 0x00BAAC7C: LDR x8, [x8, #0xe10]       | X8 = (string**)(1152921514489343072)("CameraEffect");
        // 0x00BAAC80: MOV x21, x0                | X21 = val_18;//m1                       
        // 0x00BAAC84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAC88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAAC8C: LDR x1, [x8]               | X1 = "CameraEffect";                    
        // 0x00BAAC90: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_19 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00BAAC94: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00BAAC98: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x00BAAC9C: MOV w22, w0                | W22 = val_19;//m1                       
        // 0x00BAACA0: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x00BAACA4: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00BAACA8: TBZ w9, #0, #0xbaacbc      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_30;
        // 0x00BAACAC: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00BAACB0: CBNZ w9, #0xbaacbc         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
        // 0x00BAACB4: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00BAACB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_30:
        // 0x00BAACBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAACC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAACC4: MOV x1, x21                | X1 = val_18;//m1                        
        // 0x00BAACC8: MOV w2, w22                | W2 = val_19;//m1                        
        // 0x00BAACCC: BL #0xd0b554               | NGUITools.SetLayer(go:  0, layer:  val_18);
        NGUITools.SetLayer(go:  0, layer:  val_18);
        // 0x00BAACD0: LDR x0, [x24]              | X0 = typeof(ZMG);                       
        // 0x00BAACD4: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BAACD8: TBZ w8, #0, #0xbaace8      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_32;
        // 0x00BAACDC: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BAACE0: CBNZ w8, #0xbaace8         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
        // 0x00BAACE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_32:
        // 0x00BAACE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAACEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAACF0: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_20 = ZMG.EffectMgr;
        // 0x00BAACF4: MOV x21, x0                | X21 = val_20;//m1                       
        // 0x00BAACF8: CBNZ x20, #0xbaad00        | if (target != null) goto label_33;      
        if(target != null)
        {
            goto label_33;
        }
        // 0x00BAACFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_33:
        // 0x00BAAD00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAD04: MOV x0, x20                | X0 = target;//m1                        
        // 0x00BAAD08: BL #0x1b78f0c              | X0 = target.GetInstanceID();            
        int val_21 = target.GetInstanceID();
        // 0x00BAAD0C: MOV w22, w0                | W22 = val_21;//m1                       
        // 0x00BAAD10: CBNZ x21, #0xbaad18        | if (val_20 != null) goto label_34;      
        if(val_20 != null)
        {
            goto label_34;
        }
        // 0x00BAAD14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_34:
        // 0x00BAAD18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAAD1C: MOV x0, x21                | X0 = val_20;//m1                        
        // 0x00BAAD20: MOV w1, w22                | W1 = val_21;//m1                        
        // 0x00BAAD24: BL #0xb62d80               | val_20.SetEffectPause(scrID:  val_21);  
        val_20.SetEffectPause(scrID:  val_21);
        // 0x00BAAD28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAD2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAD30: BL #0x26a8300              | X0 = ZMG.get_SoundMgr();                
        SoundMgr val_22 = ZMG.SoundMgr;
        // 0x00BAAD34: MOV x21, x0                | X21 = val_22;//m1                       
        // 0x00BAAD38: CBNZ x21, #0xbaad40        | if (val_22 != null) goto label_35;      
        if(val_22 != null)
        {
            goto label_35;
        }
        // 0x00BAAD3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_35:
        // 0x00BAAD40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAD44: MOV x0, x21                | X0 = val_22;//m1                        
        // 0x00BAAD48: BL #0xae840c               | val_22.SetBlackPause();                 
        val_22.SetBlackPause();
        // 0x00BAAD4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAD50: MOV x0, x19                | X0 = 1152921514489388672 (0x100000024D0B9E80);//ML01
        // 0x00BAAD54: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_23 = this.gameObject;
        // 0x00BAAD58: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
        // 0x00BAAD5C: LDR x8, [x8, #0xe20]       | X8 = 1152921514489355456;               
        // 0x00BAAD60: MOV x1, x0                 | X1 = val_23;//m1                        
        // 0x00BAAD64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAD68: LDR x2, [x8]               | X2 = public static CameraMove GameObject_MonoBehaviour::GetOrCreateComponent<CameraMove>(UnityEngine.GameObject _this);
        // 0x00BAAD6C: BL #0xfd7798               | X0 = GameObject_MonoBehaviour.GetOrCreateComponent<ScreenShake>(_this:  0);
        ScreenShake val_24 = GameObject_MonoBehaviour.GetOrCreateComponent<ScreenShake>(_this:  0);
        // 0x00BAAD70: LDRB w8, [x19, #0x44]      | W8 = this.bInScaler; //P2               
        // 0x00BAAD74: MOV x21, x0                | X21 = val_24;//m1                       
        // 0x00BAAD78: CBZ w8, #0xbaad88          | if (this.bInScaler == false) goto label_36;
        if(this.bInScaler == false)
        {
            goto label_36;
        }
        // 0x00BAAD7C: CBNZ x21, #0xbaae30        | if (val_24 != null) goto label_38;      
        if(val_24 != null)
        {
            goto label_38;
        }
        // 0x00BAAD80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        // 0x00BAAD84: B #0xbaae30                |  goto label_38;                         
        goto label_38;
        label_36:
        // 0x00BAAD88: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAAD8C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAAD90: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAAD94: LDP s15, s14, [x19, #0x20] | S15 = this.initOffset; //P2              //  | 
        // 0x00BAAD98: LDR s13, [x19, #0x28]      | 
        // 0x00BAAD9C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAADA0: TBZ w8, #0, #0xbaadb0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_40;
        // 0x00BAADA4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAADA8: CBNZ w8, #0xbaadb0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
        // 0x00BAADAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_40:
        // 0x00BAADB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAADB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAADB8: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_25 = UnityEngine.Vector3.zero;
        // 0x00BAADBC: MOV v3.16b, v0.16b         | V3 = val_25.x;//m1                      
        // 0x00BAADC0: MOV v4.16b, v1.16b         | V4 = val_25.y;//m1                      
        // 0x00BAADC4: MOV v5.16b, v2.16b         | V5 = val_25.z;//m1                      
        // 0x00BAADC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAADCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAADD0: MOV v0.16b, v15.16b        | V0 = this.initOffset;//m1               
        // 0x00BAADD4: MOV v1.16b, v14.16b        | V1 = V14.16B;//m1                       
        // 0x00BAADD8: MOV v2.16b, v13.16b        | V2 = val_12;//m1                        
        // 0x00BAADDC: BL #0x269a824              | X0 = UnityEngine.Vector3.op_Equality(lhs:  new UnityEngine.Vector3() {x = this.initOffset, y = V14.16B, z = val_12}, rhs:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z});
        bool val_26 = UnityEngine.Vector3.op_Equality(lhs:  new UnityEngine.Vector3() {x = this.initOffset, y = V14.16B, z = val_12}, rhs:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z});
        // 0x00BAADE0: AND w8, w0, #1             | W8 = (val_26 & 1);                      
        bool val_27 = val_26;
        // 0x00BAADE4: TBZ w8, #0, #0xbaae18      | if ((val_26 & 1) == false) goto label_41;
        if(val_27 == false)
        {
            goto label_41;
        }
        // 0x00BAADE8: LDR x22, [x19, #0x60]      | X22 = this.<csf>k__BackingField; //P2   
        // 0x00BAADEC: CBNZ x22, #0xbaadf4        | if (this.<csf>k__BackingField != null) goto label_42;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_42;
        }
        // 0x00BAADF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_42:
        // 0x00BAADF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAADF8: MOV x0, x22                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAADFC: BL #0xd80d14               | X0 = this.<csf>k__BackingField.OffsetPos();
        UnityEngine.Vector3 val_28 = this.<csf>k__BackingField.OffsetPos();
        // 0x00BAAE00: FMOV w22, s0               | W22 = (val_28.x);                       
        val_33 = val_28.x;
        // 0x00BAAE04: FMOV w23, s1               | W23 = (val_28.y);                       
        val_29 = val_28.y;
        // 0x00BAAE08: FMOV w24, s2               | W24 = (val_28.z);                       
        val_34 = val_28.z;
        // 0x00BAAE0C: STP s0, s1, [x19, #0x20]   | this.initOffset = val_28;  mem[1152921514489388708] = val_28.y;  //  dest_result_addr=1152921514489388704 |  dest_result_addr=1152921514489388708
        this.initOffset = val_28;
        mem[1152921514489388708] = val_28.y;
        // 0x00BAAE10: STR s2, [x19, #0x28]       | mem[1152921514489388712] = val_28.z;     //  dest_result_addr=1152921514489388712
        mem[1152921514489388712] = val_28.z;
        // 0x00BAAE14: B #0xbaae20                |  goto label_43;                         
        goto label_43;
        label_41:
        // 0x00BAAE18: LDP w22, w23, [x19, #0x20] | W22 = this.initOffset; //P2              //  | 
        val_33 = this.initOffset;
        // 0x00BAAE1C: LDR w24, [x19, #0x28]      | 
        label_43:
        // 0x00BAAE20: CBNZ x21, #0xbaae28        | if (val_24 != null) goto label_44;      
        if(val_24 != null)
        {
            goto label_44;
        }
        // 0x00BAAE24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_44:
        // 0x00BAAE28: STP w22, w23, [x21, #0x5c] | mem2[0] = this.initOffset;  mem2[0] = val_8;  //  dest_result_addr=0 |  dest_result_addr=0
        mem2[0] = val_33;
        mem2[0] = val_29;
        // 0x00BAAE2C: STR w24, [x21, #0x64]      | mem2[0] = 1152921504911851520;           //  dest_result_addr=0
        mem2[0] = 1152921504911851520;
        label_38:
        // 0x00BAAE30: MOV x0, x21                | X0 = val_24;//m1                        
        // 0x00BAAE34: MOV x1, x20                | X1 = target;//m1                        
        // 0x00BAAE38: MOV v0.16b, v11.16b        | V0 = zoomInTime;//m1                    
        // 0x00BAAE3C: MOV v1.16b, v12.16b        | V1 = (zoomOutTime + zoomOutTime);//m1   
        // 0x00BAAE40: MOV v2.16b, v10.16b        | V2 = zoominoffset.x;//m1                
        // 0x00BAAE44: MOV v3.16b, v9.16b         | V3 = zoominoffset.y;//m1                
        // 0x00BAAE48: MOV v4.16b, v8.16b         | V4 = zoominoffset.z;//m1                
        // 0x00BAAE4C: BL #0xbaae80               | val_24.NearBy(target:  target, nearTime:  zoomInTime, farTime:  zoomOutTime, zoominoffset:  new UnityEngine.Vector3() {x = zoominoffset.x, y = zoominoffset.y, z = zoominoffset.z});
        val_24.NearBy(target:  target, nearTime:  zoomInTime, farTime:  val_29, zoominoffset:  new UnityEngine.Vector3() {x = zoominoffset.x, y = zoominoffset.y, z = zoominoffset.z});
        // 0x00BAAE50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAAE54: STRB w8, [x19, #0x44]      | this.bInScaler = true;                   //  dest_result_addr=1152921514489388740
        this.bInScaler = true;
        // 0x00BAAE58: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAAE5C: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAAE60: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAAE64: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAAE68: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x00BAAE6C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAAE70: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAAE74: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAAE78: LDP d15, d14, [sp], #0x90  | D15 = ; D14 = ;                          //  | 
        // 0x00BAAE7C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAB070 (12234864), len: 276  VirtAddr: 0x00BAB070 RVA: 0x00BAB070 token: 100690224 methodIndex: 25682 delegateWrapperIndex: 0 methodInvoker: 0
    public void MotionBlur(UnityEngine.Transform target, float distance)
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        // 0x00BAB070: STP x22, x21, [sp, #-0x30]! | stack[1152921514489601264] = ???;  stack[1152921514489601272] = ???;  //  dest_result_addr=1152921514489601264 |  dest_result_addr=1152921514489601272
        // 0x00BAB074: STP x20, x19, [sp, #0x10]  | stack[1152921514489601280] = ???;  stack[1152921514489601288] = ???;  //  dest_result_addr=1152921514489601280 |  dest_result_addr=1152921514489601288
        // 0x00BAB078: STP x29, x30, [sp, #0x20]  | stack[1152921514489601296] = ???;  stack[1152921514489601304] = ???;  //  dest_result_addr=1152921514489601296 |  dest_result_addr=1152921514489601304
        // 0x00BAB07C: ADD x29, sp, #0x20         | X29 = (1152921514489601264 + 32) = 1152921514489601296 (0x100000024D0EDD10);
        // 0x00BAB080: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BAB084: LDRB w8, [x21, #0xaf7]     | W8 = (bool)static_value_03733AF7;       
        // 0x00BAB088: MOV x20, x1                | X20 = target;//m1                       
        // 0x00BAB08C: MOV x19, x0                | X19 = 1152921514489613312 (0x100000024D0F0C00);//ML01
        // 0x00BAB090: TBNZ w8, #0, #0xbab0ac     | if (static_value_03733AF7 == true) goto label_0;
        // 0x00BAB094: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
        // 0x00BAB098: LDR x8, [x8, #0xf50]       | X8 = 0x2B901F8;                         
        // 0x00BAB09C: LDR w0, [x8]               | W0 = 0x1742;                            
        // 0x00BAB0A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1742, ????);     
        // 0x00BAB0A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAB0A8: STRB w8, [x21, #0xaf7]     | static_value_03733AF7 = true;            //  dest_result_addr=57883383
        label_0:
        // 0x00BAB0AC: LDRB w8, [x19, #0x79]      | W8 = this.isTeamSkillCamera; //P2       
        // 0x00BAB0B0: CBNZ w8, #0xbab174         | if (this.isTeamSkillCamera == true) goto label_1;
        if(this.isTeamSkillCamera == true)
        {
            goto label_1;
        }
        // 0x00BAB0B4: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        // 0x00BAB0B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAB0BC: STRB w8, [x19, #0x78]      | this.motionBluring = true;               //  dest_result_addr=1152921514489613432
        this.motionBluring = true;
        // 0x00BAB0C0: CBNZ x21, #0xbab0c8        | if (this.<csf>k__BackingField != null) goto label_2;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_2;
        }
        // 0x00BAB0C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1742, ????);     
        label_2:
        // 0x00BAB0C8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAB0CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB0D0: MOV x0, x21                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAB0D4: BL #0x20cb458              | this.<csf>k__BackingField.set_enabled(value:  false);
        this.<csf>k__BackingField.enabled = false;
        // 0x00BAB0D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB0DC: MOV x0, x19                | X0 = 1152921514489613312 (0x100000024D0F0C00);//ML01
        // 0x00BAB0E0: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00BAB0E4: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
        // 0x00BAB0E8: LDR x8, [x8, #0x208]       | X8 = 1152921514489579072;               
        // 0x00BAB0EC: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00BAB0F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB0F4: LDR x2, [x8]               | X2 = public static TargetMotionBlur GameObject_MonoBehaviour::GetOrCreateComponent<TargetMotionBlur>(UnityEngine.GameObject _this);
        // 0x00BAB0F8: BL #0xfd7798               | X0 = GameObject_MonoBehaviour.GetOrCreateComponent<ScreenShake>(_this:  0);
        ScreenShake val_2 = GameObject_MonoBehaviour.GetOrCreateComponent<ScreenShake>(_this:  0);
        // 0x00BAB0FC: MOV x21, x0                | X21 = val_2;//m1                        
        val_5 = val_2;
        // 0x00BAB100: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB104: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB108: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_3 = UnityEngine.Camera.main;
        // 0x00BAB10C: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00BAB110: CBNZ x21, #0xbab118        | if (val_2 != null) goto label_3;        
        if(val_5 != null)
        {
            goto label_3;
        }
        // 0x00BAB114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x00BAB118: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAB11C: FMOV s0, #8.00000000       | S0 = 8;                                 
        // 0x00BAB120: FMOV s1, #20.00000000      | S1 = 20;                                
        // 0x00BAB124: FMOV s2, #10.00000000      | S2 = 10;                                
        // 0x00BAB128: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00BAB12C: MOV x1, x20                | X1 = target;//m1                        
        // 0x00BAB130: MOV x2, x22                | X2 = val_3;//m1                         
        // 0x00BAB134: BL #0xaf8b9c               | val_2.Init(target:  target, camera:  val_3, minDistance:  8f, startVelocity:  20f, endVelocity:  10f);
        val_5.Init(target:  target, camera:  val_3, minDistance:  8f, startVelocity:  20f, endVelocity:  10f);
        // 0x00BAB138: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x00BAB13C: ADRP x9, #0x35fe000        | X9 = 56614912 (0x35FE000);              
        // 0x00BAB140: LDR x8, [x8, #0x130]       | X8 = 1152921514489588288;               
        // 0x00BAB144: LDR x9, [x9, #0xb70]       | X9 = 1152921504888315904;               
        // 0x00BAB148: LDR x22, [x8]              | X22 = System.Void CameraHelper::<MotionBlur>m__0();
        // 0x00BAB14C: LDR x0, [x9]               | X0 = typeof(TargetMotionBlur.OnFinish); 
        TargetMotionBlur.OnFinish val_4 = null;
        // 0x00BAB150: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(TargetMotionBlur.OnFinish), ????);
        // 0x00BAB154: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAB158: MOV x1, x19                | X1 = 1152921514489613312 (0x100000024D0F0C00);//ML01
        // 0x00BAB15C: MOV x2, x22                | X2 = 1152921514489588288 (0x100000024D0EAA40);//ML01
        // 0x00BAB160: MOV x20, x0                | X20 = 1152921504888315904 (0x1000000010C6E000);//ML01
        // 0x00BAB164: BL #0xaf9434               | .ctor(object:  this, method:  System.Void CameraHelper::<MotionBlur>m__0());
        val_4 = new TargetMotionBlur.OnFinish(object:  this, method:  System.Void CameraHelper::<MotionBlur>m__0());
        // 0x00BAB168: CBNZ x21, #0xbab170        | if (val_2 != null) goto label_4;        
        if(val_5 != null)
        {
            goto label_4;
        }
        // 0x00BAB16C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void CameraHelper::<MotionBlur>m__0()), ????);
        label_4:
        // 0x00BAB170: STR x20, [x21, #0x48]      | mem2[0] = typeof(TargetMotionBlur.OnFinish);  //  dest_result_addr=0
        mem2[0] = val_4;
        label_1:
        // 0x00BAB174: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAB178: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAB17C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BAB180: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAB184 (12235140), len: 1320  VirtAddr: 0x00BAB184 RVA: 0x00BAB184 token: 100690225 methodIndex: 25683 delegateWrapperIndex: 0 methodInvoker: 0
    public void PlayTeamSkillCamera()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Object val_23;
        //  | 
        CameraSmoothFollow val_24;
        //  | 
        CameraSmoothFollow val_25;
        //  | 
        float val_26;
        // 0x00BAB184: STP d11, d10, [sp, #-0x50]! | stack[1152921514489828016] = ???;  stack[1152921514489828024] = ???;  //  dest_result_addr=1152921514489828016 |  dest_result_addr=1152921514489828024
        // 0x00BAB188: STP d9, d8, [sp, #0x10]    | stack[1152921514489828032] = ???;  stack[1152921514489828040] = ???;  //  dest_result_addr=1152921514489828032 |  dest_result_addr=1152921514489828040
        // 0x00BAB18C: STP x22, x21, [sp, #0x20]  | stack[1152921514489828048] = ???;  stack[1152921514489828056] = ???;  //  dest_result_addr=1152921514489828048 |  dest_result_addr=1152921514489828056
        // 0x00BAB190: STP x20, x19, [sp, #0x30]  | stack[1152921514489828064] = ???;  stack[1152921514489828072] = ???;  //  dest_result_addr=1152921514489828064 |  dest_result_addr=1152921514489828072
        // 0x00BAB194: STP x29, x30, [sp, #0x40]  | stack[1152921514489828080] = ???;  stack[1152921514489828088] = ???;  //  dest_result_addr=1152921514489828080 |  dest_result_addr=1152921514489828088
        // 0x00BAB198: ADD x29, sp, #0x40         | X29 = (1152921514489828016 + 64) = 1152921514489828080 (0x100000024D1252F0);
        // 0x00BAB19C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAB1A0: LDRB w8, [x20, #0xaf8]     | W8 = (bool)static_value_03733AF8;       
        // 0x00BAB1A4: MOV x19, x0                | X19 = 1152921514489840096 (0x100000024D1281E0);//ML01
        // 0x00BAB1A8: TBNZ w8, #0, #0xbab1c4     | if (static_value_03733AF8 == true) goto label_0;
        // 0x00BAB1AC: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
        // 0x00BAB1B0: LDR x8, [x8, #0x648]       | X8 = 0x2B90204;                         
        // 0x00BAB1B4: LDR w0, [x8]               | W0 = 0x1745;                            
        // 0x00BAB1B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1745, ????);     
        // 0x00BAB1BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAB1C0: STRB w8, [x20, #0xaf8]     | static_value_03733AF8 = true;            //  dest_result_addr=57883384
        label_0:
        // 0x00BAB1C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAB1C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB1CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB1D0: STRB w8, [x19, #0x79]      | this.isTeamSkillCamera = true;           //  dest_result_addr=1152921514489840217
        this.isTeamSkillCamera = true;
        // 0x00BAB1D4: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_1 = UnityEngine.Camera.main;
        // 0x00BAB1D8: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00BAB1DC: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
        // 0x00BAB1E0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00BAB1E4: LDR x21, [x8]              | X21 = typeof(System.String[]);          
        // 0x00BAB1E8: MOV x0, x21                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAB1EC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
        // 0x00BAB1F0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00BAB1F4: MOV x0, x21                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAB1F8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
        // 0x00BAB1FC: MOV x21, x0                | X21 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAB200: CBNZ x21, #0xbab208        | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x00BAB204: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
        label_1:
        // 0x00BAB208: ADRP x22, #0x35e0000       | X22 = 56492032 (0x35E0000);             
        // 0x00BAB20C: LDR x22, [x22, #0xa10]     | X22 = (string**)(1152921513542678400)("Player");
        // 0x00BAB210: LDR x0, [x22]              | X0 = "Player";                          
        // 0x00BAB214: CBZ x0, #0xbab234          | if ("Player" == null) goto label_3;     
        // 0x00BAB218: LDR x8, [x21]              | X8 = ;                                  
        // 0x00BAB21C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BAB220: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "Player", ????);   
        // 0x00BAB224: CBNZ x0, #0xbab234         | if ("Player" != null) goto label_3;     
        if("Player" != null)
        {
            goto label_3;
        }
        // 0x00BAB228: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "Player", ????);   
        // 0x00BAB22C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB230: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Player", ????);   
        label_3:
        // 0x00BAB234: LDR x22, [x22]             | X22 = "Player";                         
        // 0x00BAB238: LDR w8, [x21, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00BAB23C: CBNZ w8, #0xbab24c         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_4;
        // 0x00BAB240: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "Player", ????);   
        // 0x00BAB244: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB248: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Player", ????);   
        label_4:
        // 0x00BAB24C: STR x22, [x21, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "Player";  //  dest_result_addr=1152921504948897200
        typeof(System.String[]).__il2cppRuntimeField_20 = "Player";
        // 0x00BAB250: ADRP x22, #0x3682000       | X22 = 57155584 (0x3682000);             
        // 0x00BAB254: LDR x22, [x22, #0xa0]      | X22 = (string**)(1152921514488840448)("SkillEffect");
        // 0x00BAB258: LDR x0, [x22]              | X0 = "SkillEffect";                     
        // 0x00BAB25C: CBZ x0, #0xbab27c          | if ("SkillEffect" == null) goto label_6;
        // 0x00BAB260: LDR x8, [x21]              | X8 = ;                                  
        // 0x00BAB264: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BAB268: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "SkillEffect", ????);
        // 0x00BAB26C: CBNZ x0, #0xbab27c         | if ("SkillEffect" != null) goto label_6;
        if("SkillEffect" != null)
        {
            goto label_6;
        }
        // 0x00BAB270: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "SkillEffect", ????);
        // 0x00BAB274: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB278: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "SkillEffect", ????);
        label_6:
        // 0x00BAB27C: LDR w8, [x21, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00BAB280: LDR x22, [x22]             | X22 = "SkillEffect";                    
        // 0x00BAB284: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00BAB288: B.HI #0xbab298             | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_7;
        // 0x00BAB28C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "SkillEffect", ????);
        // 0x00BAB290: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB294: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "SkillEffect", ????);
        label_7:
        // 0x00BAB298: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB29C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB2A0: MOV x1, x21                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAB2A4: STR x22, [x21, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = "SkillEffect";  //  dest_result_addr=1152921504948897208
        typeof(System.String[]).__il2cppRuntimeField_28 = "SkillEffect";
        // 0x00BAB2A8: BL #0x1a73324              | X0 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        int val_2 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        // 0x00BAB2AC: MOV w21, w0                | W21 = val_2;//m1                        
        // 0x00BAB2B0: CBNZ x20, #0xbab2b8        | if (val_1 != null) goto label_8;        
        if(val_1 != null)
        {
            goto label_8;
        }
        // 0x00BAB2B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00BAB2B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB2BC: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00BAB2C0: MOV w1, w21                | W1 = val_2;//m1                         
        // 0x00BAB2C4: BL #0x20cf678              | val_1.set_cullingMask(value:  val_2);   
        val_1.cullingMask = val_2;
        // 0x00BAB2C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB2CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB2D0: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_3 = UnityEngine.Camera.main;
        // 0x00BAB2D4: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00BAB2D8: CBNZ x20, #0xbab2e0        | if (val_3 != null) goto label_9;        
        if(val_3 != null)
        {
            goto label_9;
        }
        // 0x00BAB2DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00BAB2E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB2E4: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00BAB2E8: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00BAB2EC: BL #0x20d097c              | val_3.set_clearFlags(value:  2);        
        val_3.clearFlags = 2;
        // 0x00BAB2F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB2F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB2F8: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_4 = UnityEngine.Camera.main;
        // 0x00BAB2FC: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00BAB300: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB304: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB308: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
        UnityEngine.Color val_5 = UnityEngine.Color.black;
        // 0x00BAB30C: MOV v8.16b, v0.16b         | V8 = val_5.r;//m1                       
        // 0x00BAB310: MOV v9.16b, v1.16b         | V9 = val_5.g;//m1                       
        // 0x00BAB314: MOV v10.16b, v2.16b        | V10 = val_5.b;//m1                      
        // 0x00BAB318: MOV v11.16b, v3.16b        | V11 = val_5.a;//m1                      
        // 0x00BAB31C: CBNZ x20, #0xbab324        | if (val_4 != null) goto label_10;       
        if(val_4 != null)
        {
            goto label_10;
        }
        // 0x00BAB320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_10:
        // 0x00BAB324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB328: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00BAB32C: MOV v0.16b, v8.16b         | V0 = val_5.r;//m1                       
        // 0x00BAB330: MOV v1.16b, v9.16b         | V1 = val_5.g;//m1                       
        // 0x00BAB334: MOV v2.16b, v10.16b        | V2 = val_5.b;//m1                       
        // 0x00BAB338: MOV v3.16b, v11.16b        | V3 = val_5.a;//m1                       
        // 0x00BAB33C: BL #0x20cf9ac              | val_4.set_backgroundColor(value:  new UnityEngine.Color() {r = val_5.r, g = val_5.g, b = val_5.b, a = val_5.a});
        val_4.backgroundColor = new UnityEngine.Color() {r = val_5.r, g = val_5.g, b = val_5.b, a = val_5.a};
        // 0x00BAB340: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BAB344: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00BAB348: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00BAB34C: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BAB350: TBZ w8, #0, #0xbab360      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00BAB354: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BAB358: CBNZ w8, #0xbab360         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00BAB35C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_12:
        // 0x00BAB360: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB364: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB368: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_6 = ZMG.EffectMgr;
        // 0x00BAB36C: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00BAB370: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB374: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB378: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_7 = HeroMgr.instance;
        // 0x00BAB37C: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x00BAB380: CBNZ x21, #0xbab388        | if (val_7 != null) goto label_13;       
        if(val_7 != null)
        {
            goto label_13;
        }
        // 0x00BAB384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_13:
        // 0x00BAB388: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB38C: MOV x0, x21                | X0 = val_7;//m1                         
        // 0x00BAB390: BL #0x287fff4              | X0 = val_7.get_captain();               
        Hero val_8 = val_7.captain;
        // 0x00BAB394: MOV x21, x0                | X21 = val_8;//m1                        
        // 0x00BAB398: CBNZ x20, #0xbab3a0        | if (val_6 != null) goto label_14;       
        if(val_6 != null)
        {
            goto label_14;
        }
        // 0x00BAB39C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_14:
        // 0x00BAB3A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAB3A4: MOVZ w1, #0x259            | W1 = 601 (0x259);//ML01                 
        // 0x00BAB3A8: MOV x0, x20                | X0 = val_6;//m1                         
        // 0x00BAB3AC: MOV x2, x21                | X2 = val_8;//m1                         
        // 0x00BAB3B0: BL #0xb617dc               | val_6.PlayEffect(id:  89, srcTf:  val_8);
        val_6.PlayEffect(id:  89, srcTf:  val_8);
        // 0x00BAB3B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB3B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB3BC: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_9 = HeroMgr.instance;
        // 0x00BAB3C0: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00BAB3C4: CBNZ x20, #0xbab3cc        | if (val_9 != null) goto label_15;       
        if(val_9 != null)
        {
            goto label_15;
        }
        // 0x00BAB3C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_15:
        // 0x00BAB3CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB3D0: MOV x0, x20                | X0 = val_9;//m1                         
        // 0x00BAB3D4: BL #0x287fff4              | X0 = val_9.get_captain();               
        Hero val_10 = val_9.captain;
        // 0x00BAB3D8: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00BAB3DC: CBNZ x20, #0xbab3e4        | if (val_10 != null) goto label_16;      
        if(val_10 != null)
        {
            goto label_16;
        }
        // 0x00BAB3E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_16:
        // 0x00BAB3E4: LDR x20, [x20, #0x58]      | 
        // 0x00BAB3E8: CBNZ x20, #0xbab3f0        | if (val_10 != null) goto label_17;      
        if(val_10 != null)
        {
            goto label_17;
        }
        // 0x00BAB3EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_17:
        // 0x00BAB3F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB3F4: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00BAB3F8: BL #0x1b78f0c              | X0 = val_10.GetInstanceID();            
        int val_11 = val_10.GetInstanceID();
        // 0x00BAB3FC: STR w0, [x19, #0x88]       | this.effid = val_11;                     //  dest_result_addr=1152921514489840232
        this.effid = val_11;
        // 0x00BAB400: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB408: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_12 = HeroMgr.instance;
        // 0x00BAB40C: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00BAB410: CBNZ x20, #0xbab418        | if (val_12 != null) goto label_18;      
        if(val_12 != null)
        {
            goto label_18;
        }
        // 0x00BAB414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_18:
        // 0x00BAB418: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB41C: MOV x0, x20                | X0 = val_12;//m1                        
        // 0x00BAB420: BL #0x2895980              | X0 = val_12.GetCameraTarger();          
        UnityEngine.Transform val_13 = val_12.GetCameraTarger();
        // 0x00BAB424: ADRP x21, #0x3622000       | X21 = 56762368 (0x3622000);             
        // 0x00BAB428: LDR x21, [x21, #0x560]     | X21 = (string**)(1152921514489762752)("viewPos");
        // 0x00BAB42C: MOV x22, x0                | X22 = val_13;//m1                       
        // 0x00BAB430: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB434: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB438: LDR x1, [x21]              | X1 = "viewPos";                         
        // 0x00BAB43C: BL #0x1a634b4              | X0 = UnityEngine.GameObject.Find(name:  0);
        UnityEngine.GameObject val_14 = UnityEngine.GameObject.Find(name:  0);
        // 0x00BAB440: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BAB444: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BAB448: MOV x20, x0                | X20 = val_14;//m1                       
        val_23 = val_14;
        // 0x00BAB44C: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00BAB450: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BAB454: TBZ w9, #0, #0xbab468      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00BAB458: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BAB45C: CBNZ w9, #0xbab468         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00BAB460: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00BAB464: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_20:
        // 0x00BAB468: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB46C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB470: MOV x1, x20                | X1 = val_14;//m1                        
        // 0x00BAB474: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAB478: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_23);
        bool val_15 = UnityEngine.Object.op_Equality(x:  0, y:  val_23);
        // 0x00BAB47C: TBZ w0, #0, #0xbab4a0      | if (val_15 == false) goto label_21;     
        if(val_15 == false)
        {
            goto label_21;
        }
        // 0x00BAB480: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BAB484: LDR x8, [x8, #0x30]        | X8 = 1152921504692629504;               
        // 0x00BAB488: LDR x0, [x8]               | X0 = typeof(UnityEngine.GameObject);    
        UnityEngine.GameObject val_16 = null;
        // 0x00BAB48C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.GameObject), ????);
        // 0x00BAB490: LDR x1, [x21]              | X1 = "viewPos";                         
        // 0x00BAB494: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB498: MOV x20, x0                | X20 = 1152921504692629504 (0x10000000051CF000);//ML01
        val_23 = val_16;
        // 0x00BAB49C: BL #0x1a62378              | .ctor(name:  "viewPos");                
        val_16 = new UnityEngine.GameObject(name:  "viewPos");
        label_21:
        // 0x00BAB4A0: CBNZ x20, #0xbab4a8        | if ( != 0) goto label_22;               
        if(null != 0)
        {
            goto label_22;
        }
        // 0x00BAB4A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(name:  "viewPos"), ????);
        label_22:
        // 0x00BAB4A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB4AC: MOV x0, x20                | X0 = 1152921504692629504 (0x10000000051CF000);//ML01
        // 0x00BAB4B0: BL #0x1a62c1c              | X0 = get_transform();                   
        UnityEngine.Transform val_17 = transform;
        // 0x00BAB4B4: MOV x21, x0                | X21 = val_17;//m1                       
        // 0x00BAB4B8: CBNZ x22, #0xbab4c0        | if (val_13 != null) goto label_23;      
        if(val_13 != null)
        {
            goto label_23;
        }
        // 0x00BAB4BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_23:
        // 0x00BAB4C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB4C4: MOV x0, x22                | X0 = val_13;//m1                        
        // 0x00BAB4C8: BL #0x2693510              | X0 = val_13.get_position();             
        UnityEngine.Vector3 val_18 = val_13.position;
        // 0x00BAB4CC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAB4D0: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAB4D4: MOV v8.16b, v0.16b         | V8 = val_18.x;//m1                      
        // 0x00BAB4D8: MOV v9.16b, v1.16b         | V9 = val_18.y;//m1                      
        // 0x00BAB4DC: MOV v10.16b, v2.16b        | V10 = val_18.z;//m1                     
        // 0x00BAB4E0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAB4E4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAB4E8: TBZ w8, #0, #0xbab4f8      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x00BAB4EC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAB4F0: CBNZ w8, #0xbab4f8         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x00BAB4F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_25:
        // 0x00BAB4F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB4FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB500: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_19 = UnityEngine.Vector3.up;
        // 0x00BAB504: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAB508: LDR s3, [x8, #0x95c]       | S3 = 0.7;                               
        // 0x00BAB50C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB510: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB514: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z}, d:  0.7f);
        UnityEngine.Vector3 val_20 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z}, d:  0.7f);
        // 0x00BAB518: MOV v3.16b, v0.16b         | V3 = val_20.x;//m1                      
        // 0x00BAB51C: MOV v4.16b, v1.16b         | V4 = val_20.y;//m1                      
        // 0x00BAB520: MOV v5.16b, v2.16b         | V5 = val_20.z;//m1                      
        // 0x00BAB524: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB528: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB52C: MOV v0.16b, v8.16b         | V0 = val_18.x;//m1                      
        // 0x00BAB530: MOV v1.16b, v9.16b         | V1 = val_18.y;//m1                      
        // 0x00BAB534: MOV v2.16b, v10.16b        | V2 = val_18.z;//m1                      
        // 0x00BAB538: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = val_20.x, y = val_20.y, z = val_20.z});
        UnityEngine.Vector3 val_21 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = val_20.x, y = val_20.y, z = val_20.z});
        // 0x00BAB53C: MOV v8.16b, v0.16b         | V8 = val_21.x;//m1                      
        // 0x00BAB540: MOV v9.16b, v1.16b         | V9 = val_21.y;//m1                      
        // 0x00BAB544: MOV v10.16b, v2.16b        | V10 = val_21.z;//m1                     
        // 0x00BAB548: CBNZ x21, #0xbab550        | if (val_17 != null) goto label_26;      
        if(val_17 != null)
        {
            goto label_26;
        }
        // 0x00BAB54C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_26:
        // 0x00BAB550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB554: MOV x0, x21                | X0 = val_17;//m1                        
        // 0x00BAB558: MOV v0.16b, v8.16b         | V0 = val_21.x;//m1                      
        // 0x00BAB55C: MOV v1.16b, v9.16b         | V1 = val_21.y;//m1                      
        // 0x00BAB560: MOV v2.16b, v10.16b        | V2 = val_21.z;//m1                      
        // 0x00BAB564: BL #0x26935b8              | val_17.set_position(value:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        val_17.position = new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z};
        // 0x00BAB568: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        val_24 = this.<csf>k__BackingField;
        // 0x00BAB56C: CBZ x21, #0xbab57c         | if (this.<csf>k__BackingField == null) goto label_27;
        if(val_24 == null)
        {
            goto label_27;
        }
        // 0x00BAB570: LDR w8, [x21, #0x6c]       | W8 = this.<csf>k__BackingField.ry; //P2 
        // 0x00BAB574: STR w8, [x19, #0x7c]       | this.ry = this.<csf>k__BackingField.ry;  //  dest_result_addr=1152921514489840220
        this.ry = this.<csf>k__BackingField.ry;
        // 0x00BAB578: B #0xbab590                |  goto label_28;                         
        goto label_28;
        label_27:
        // 0x00BAB57C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        // 0x00BAB580: LDR w8, [x21, #0x6c]       | W8 = this.<csf>k__BackingField.ry; //P2 
        // 0x00BAB584: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        val_24 = this.<csf>k__BackingField;
        // 0x00BAB588: STR w8, [x19, #0x7c]       | this.ry = this.<csf>k__BackingField.ry;  //  dest_result_addr=1152921514489840220
        this.ry = this.<csf>k__BackingField.ry;
        // 0x00BAB58C: CBZ x21, #0xbab674         | if (this.<csf>k__BackingField == null) goto label_29;
        if(val_24 == null)
        {
            goto label_29;
        }
        label_28:
        // 0x00BAB590: LDR w8, [x21, #0x68]       | W8 = this.<csf>k__BackingField.rx; //P2 
        // 0x00BAB594: STR w8, [x19, #0x80]       | this.rx = this.<csf>k__BackingField.rx;  //  dest_result_addr=1152921514489840224
        this.rx = this.<csf>k__BackingField.rx;
        label_38:
        // 0x00BAB598: LDR w8, [x21, #0x60]       | W8 = this.<csf>k__BackingField.distance; //P2 
        // 0x00BAB59C: STR w8, [x19, #0x84]       | this.distance = this.<csf>k__BackingField.distance;  //  dest_result_addr=1152921514489840228
        this.distance = this.<csf>k__BackingField.distance;
        label_40:
        // 0x00BAB5A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB5A4: MOV x0, x21                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAB5A8: BL #0xd80e98               | this.<csf>k__BackingField.InitDamping();
        val_24.InitDamping();
        // 0x00BAB5AC: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        val_25 = this.<csf>k__BackingField;
        // 0x00BAB5B0: CBZ x21, #0xbab5bc         | if (this.<csf>k__BackingField == null) goto label_30;
        if(val_25 == null)
        {
            goto label_30;
        }
        // 0x00BAB5B4: LDR s8, [x21, #0x6c]!      | S8 = this.<csf>k__BackingField.ry; //P2 
        val_26 = this.<csf>k__BackingField.ry;
        // 0x00BAB5B8: B #0xbab5cc                |  goto label_31;                         
        goto label_31;
        label_30:
        // 0x00BAB5BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        // 0x00BAB5C0: MOVZ w21, #0x6c            | W21 = 108 (0x6C);//ML01                 
        val_25 = 108;
        // 0x00BAB5C4: LDR s8, [x21]              | S8 = 0;                                 
        val_26 = 0f;
        // 0x00BAB5C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_31:
        // 0x00BAB5CC: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAB5D0: LDR s0, [x8, #0x780]       | S0 = 50;                                
        float val_23 = 50f;
        // 0x00BAB5D4: FADD s0, s8, s0            | S0 = (val_26 + 50f);                    
        val_23 = val_26 + val_23;
        // 0x00BAB5D8: STR s0, [x21]              | mem[108] = (val_26 + 50f);               //  dest_result_addr=108
        mem[108] = val_23;
        // 0x00BAB5DC: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        // 0x00BAB5E0: CBNZ x21, #0xbab5e8        | if (this.<csf>k__BackingField != null) goto label_32;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_32;
        }
        // 0x00BAB5E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_32:
        // 0x00BAB5E8: MOVZ w8, #0x4170, lsl #16  | W8 = 1097859072 (0x41700000);//ML01     
        // 0x00BAB5EC: STR w8, [x21, #0x68]       | this.<csf>k__BackingField.rx = 15;       //  dest_result_addr=0
        this.<csf>k__BackingField.rx = 15f;
        // 0x00BAB5F0: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        // 0x00BAB5F4: CBNZ x21, #0xbab5fc        | if (this.<csf>k__BackingField != null) goto label_33;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_33;
        }
        // 0x00BAB5F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_33:
        // 0x00BAB5FC: MOVZ w8, #0x40e0, lsl #16  | W8 = 1088421888 (0x40E00000);//ML01     
        // 0x00BAB600: STR w8, [x21, #0x60]       | this.<csf>k__BackingField.distance = 7;  //  dest_result_addr=0
        this.<csf>k__BackingField.distance = 7f;
        // 0x00BAB604: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        // 0x00BAB608: CBNZ x21, #0xbab610        | if (this.<csf>k__BackingField != null) goto label_34;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_34;
        }
        // 0x00BAB60C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_34:
        // 0x00BAB610: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAB614: STRB w8, [x21, #0x5c]      | this.<csf>k__BackingField.isLockTarget = true;  //  dest_result_addr=0
        this.<csf>k__BackingField.isLockTarget = true;
        // 0x00BAB618: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        // 0x00BAB61C: CBNZ x20, #0xbab624        | if ( != 0) goto label_35;               
        if(null != 0)
        {
            goto label_35;
        }
        // 0x00BAB620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_35:
        // 0x00BAB624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB628: MOV x0, x20                | X0 = 1152921504692629504 (0x10000000051CF000);//ML01
        // 0x00BAB62C: BL #0x1a62c1c              | X0 = get_transform();                   
        UnityEngine.Transform val_22 = transform;
        // 0x00BAB630: MOV x20, x0                | X20 = val_22;//m1                       
        // 0x00BAB634: CBNZ x21, #0xbab63c        | if (this.<csf>k__BackingField != null) goto label_36;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_36;
        }
        // 0x00BAB638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_36:
        // 0x00BAB63C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB640: MOV x0, x21                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAB644: MOV x1, x20                | X1 = val_22;//m1                        
        // 0x00BAB648: BL #0xd7f374               | this.<csf>k__BackingField.set_target(value:  val_22);
        this.<csf>k__BackingField.target = val_22;
        // 0x00BAB64C: LDR x19, [x19, #0x60]      | X19 = this.<csf>k__BackingField; //P2   
        // 0x00BAB650: CBNZ x19, #0xbab658        | if (this.<csf>k__BackingField != null) goto label_37;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_37;
        }
        // 0x00BAB654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_37:
        // 0x00BAB658: STRB wzr, [x19, #0x5d]     | this.<csf>k__BackingField.isDamping = false;  //  dest_result_addr=0
        this.<csf>k__BackingField.isDamping = false;
        // 0x00BAB65C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAB660: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAB664: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAB668: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAB66C: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00BAB670: RET                        |  return;                                
        return;
        label_29:
        // 0x00BAB674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        // 0x00BAB678: LDR w8, [x21, #0x68]       | W8 = this.<csf>k__BackingField.rx; //P2 
        // 0x00BAB67C: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        // 0x00BAB680: STR w8, [x19, #0x80]       | this.rx = this.<csf>k__BackingField.rx;  //  dest_result_addr=1152921514489840224
        this.rx = this.<csf>k__BackingField.rx;
        // 0x00BAB684: CBNZ x21, #0xbab598        | if (this.<csf>k__BackingField != null) goto label_38;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_38;
        }
        // 0x00BAB688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        // 0x00BAB68C: LDR x8, [x19, #0x60]       | X8 = this.<csf>k__BackingField; //P2    
        // 0x00BAB690: LDR w9, [x21, #0x60]       | W9 = this.<csf>k__BackingField.distance; //P2 
        // 0x00BAB694: MOV x21, x8                | X21 = this.<csf>k__BackingField;//m1    
        // 0x00BAB698: STR w9, [x19, #0x84]       | this.distance = this.<csf>k__BackingField.distance;  //  dest_result_addr=1152921514489840228
        this.distance = this.<csf>k__BackingField.distance;
        // 0x00BAB69C: CBNZ x8, #0xbab5a0         | if (this.<csf>k__BackingField != null) goto label_40;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_40;
        }
        // 0x00BAB6A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        // 0x00BAB6A4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        // 0x00BAB6A8: B #0xbab5a0                |  goto label_40;                         
        goto label_40;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAB6AC (12236460), len: 540  VirtAddr: 0x00BAB6AC RVA: 0x00BAB6AC token: 100690226 methodIndex: 25684 delegateWrapperIndex: 0 methodInvoker: 0
    public void StopTeamSkillCamera()
    {
        //
        // Disasemble & Code
        // 0x00BAB6AC: STP d9, d8, [sp, #-0x40]!  | stack[1152921514490084528] = ???;  stack[1152921514490084536] = ???;  //  dest_result_addr=1152921514490084528 |  dest_result_addr=1152921514490084536
        // 0x00BAB6B0: STP x22, x21, [sp, #0x10]  | stack[1152921514490084544] = ???;  stack[1152921514490084552] = ???;  //  dest_result_addr=1152921514490084544 |  dest_result_addr=1152921514490084552
        // 0x00BAB6B4: STP x20, x19, [sp, #0x20]  | stack[1152921514490084560] = ???;  stack[1152921514490084568] = ???;  //  dest_result_addr=1152921514490084560 |  dest_result_addr=1152921514490084568
        // 0x00BAB6B8: STP x29, x30, [sp, #0x30]  | stack[1152921514490084576] = ???;  stack[1152921514490084584] = ???;  //  dest_result_addr=1152921514490084576 |  dest_result_addr=1152921514490084584
        // 0x00BAB6BC: ADD x29, sp, #0x30         | X29 = (1152921514490084528 + 48) = 1152921514490084576 (0x100000024D163CE0);
        // 0x00BAB6C0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAB6C4: LDRB w8, [x20, #0xaf9]     | W8 = (bool)static_value_03733AF9;       
        // 0x00BAB6C8: MOV x19, x0                | X19 = 1152921514490096592 (0x100000024D166BD0);//ML01
        // 0x00BAB6CC: TBNZ w8, #0, #0xbab6e8     | if (static_value_03733AF9 == true) goto label_0;
        // 0x00BAB6D0: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x00BAB6D4: LDR x8, [x8, #0xd8]        | X8 = 0x2B9021C;                         
        // 0x00BAB6D8: LDR w0, [x8]               | W0 = 0x174B;                            
        // 0x00BAB6DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x174B, ????);     
        // 0x00BAB6E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAB6E4: STRB w8, [x20, #0xaf9]     | static_value_03733AF9 = true;            //  dest_result_addr=57883385
        label_0:
        // 0x00BAB6E8: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BAB6EC: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00BAB6F0: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00BAB6F4: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BAB6F8: TBZ w8, #0, #0xbab708      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BAB6FC: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BAB700: CBNZ w8, #0xbab708         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BAB704: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00BAB708: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB70C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB710: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_1 = ZMG.CSGameDataMgr;
        // 0x00BAB714: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00BAB718: CBNZ x20, #0xbab720        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00BAB71C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00BAB720: LDR x20, [x20, #0x10]      | X20 = val_1.levelData; //P2             
        // 0x00BAB724: CBNZ x20, #0xbab72c        | if (val_1.levelData != null) goto label_4;
        if(val_1.levelData != null)
        {
            goto label_4;
        }
        // 0x00BAB728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00BAB72C: LDR x20, [x20, #0x10]      | X20 = val_1.levelData.checkpointUnit; //P2 
        // 0x00BAB730: CBNZ x20, #0xbab738        | if (val_1.levelData.checkpointUnit != null) goto label_5;
        if(val_1.levelData.checkpointUnit != null)
        {
            goto label_5;
        }
        // 0x00BAB734: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00BAB738: LDR x20, [x20, #0x10]      | X20 = val_1.levelData.checkpointUnit.cfg; //P2 
        // 0x00BAB73C: CBNZ x20, #0xbab744        | if (val_1.levelData.checkpointUnit.cfg != null) goto label_6;
        if(val_1.levelData.checkpointUnit.cfg != null)
        {
            goto label_6;
        }
        // 0x00BAB740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00BAB744: LDRB w8, [x20, #0x1a0]     | W8 = val_1.levelData.checkpointUnit.cfg.Camera_disMove; //P2 
        // 0x00BAB748: CBZ w8, #0xbab764          | if (val_1.levelData.checkpointUnit.cfg.Camera_disMove == false) goto label_7;
        if(val_1.levelData.checkpointUnit.cfg.Camera_disMove == false)
        {
            goto label_7;
        }
        // 0x00BAB74C: MOV x0, x19                | X0 = 1152921514490096592 (0x100000024D166BD0);//ML01
        // 0x00BAB750: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAB754: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAB758: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAB75C: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00BAB760: B #0xbab8c8                | this.OnCameraRXFixed(ev:  0); return;   
        this.OnCameraRXFixed(ev:  0);
        return;
        label_7:
        // 0x00BAB764: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BAB768: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BAB76C: LDR x20, [x19, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BAB770: LDR s8, [x19, #0x80]       | S8 = this.rx; //P2                      
        // 0x00BAB774: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BAB778: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BAB77C: TBZ w8, #0, #0xbab78c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00BAB780: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BAB784: CBNZ w8, #0xbab78c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00BAB788: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_9:
        // 0x00BAB78C: FMOV s0, #15.00000000      | S0 = 15;                                
        float val_5 = 15f;
        // 0x00BAB790: FSUB s0, s0, s8            | S0 = (15f - this.rx);                   
        val_5 = val_5 - this.rx;
        // 0x00BAB794: FABS s8, s0                | S8 = System.Math.Abs((15f - this.rx));  
        float val_6 = System.Math.Abs(val_5);
        // 0x00BAB798: CBNZ x20, #0xbab7a0        | if (this.<csf>k__BackingField != null) goto label_10;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_10;
        }
        // 0x00BAB79C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_10:
        // 0x00BAB7A0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAB7A4: LDR s0, [x8, #0x4b4]       | S0 = 0.1;                               
        float val_7 = 0.1f;
        // 0x00BAB7A8: FMUL s0, s8, s0            | S0 = ((15f - this.rx) * 0.1f);          
        val_7 = val_6 * val_7;
        // 0x00BAB7AC: STR s0, [x20, #0x58]       | this.<csf>k__BackingField.rxError = ((15f - this.rx) * 0.1f);  //  dest_result_addr=0
        this.<csf>k__BackingField.rxError = val_7;
        // 0x00BAB7B0: LDR x20, [x19, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BAB7B4: LDR w21, [x19, #0x7c]      | W21 = this.ry; //P2                     
        // 0x00BAB7B8: CBNZ x20, #0xbab7c0        | if (this.<csf>k__BackingField != null) goto label_11;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_11;
        }
        // 0x00BAB7BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_11:
        // 0x00BAB7C0: STR w21, [x20, #0x6c]      | this.<csf>k__BackingField.ry = this.ry;  //  dest_result_addr=0
        this.<csf>k__BackingField.ry = this.ry;
        // 0x00BAB7C4: LDR x20, [x19, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BAB7C8: LDR w21, [x19, #0x80]      | W21 = this.rx; //P2                     
        // 0x00BAB7CC: CBNZ x20, #0xbab7d4        | if (this.<csf>k__BackingField != null) goto label_12;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_12;
        }
        // 0x00BAB7D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_12:
        // 0x00BAB7D4: STR w21, [x20, #0x68]      | this.<csf>k__BackingField.rx = this.rx;  //  dest_result_addr=0
        this.<csf>k__BackingField.rx = this.rx;
        // 0x00BAB7D8: LDR x20, [x19, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BAB7DC: LDR w21, [x19, #0x84]      | W21 = this.distance; //P2               
        // 0x00BAB7E0: CBNZ x20, #0xbab7e8        | if (this.<csf>k__BackingField != null) goto label_13;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_13;
        }
        // 0x00BAB7E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_13:
        // 0x00BAB7E8: STR w21, [x20, #0x60]      | this.<csf>k__BackingField.distance = this.distance;  //  dest_result_addr=0
        this.<csf>k__BackingField.distance = this.distance;
        // 0x00BAB7EC: LDR x20, [x19, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BAB7F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB7F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB7F8: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_2 = HeroMgr.instance;
        // 0x00BAB7FC: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00BAB800: CBNZ x21, #0xbab808        | if (val_2 != null) goto label_14;       
        if(val_2 != null)
        {
            goto label_14;
        }
        // 0x00BAB804: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_14:
        // 0x00BAB808: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB80C: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00BAB810: BL #0x2895980              | X0 = val_2.GetCameraTarger();           
        UnityEngine.Transform val_3 = val_2.GetCameraTarger();
        // 0x00BAB814: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00BAB818: CBNZ x20, #0xbab820        | if (this.<csf>k__BackingField != null) goto label_15;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_15;
        }
        // 0x00BAB81C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_15:
        // 0x00BAB820: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB824: MOV x0, x20                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAB828: MOV x1, x21                | X1 = val_3;//m1                         
        // 0x00BAB82C: BL #0xd7f374               | this.<csf>k__BackingField.set_target(value:  val_3);
        this.<csf>k__BackingField.target = val_3;
        // 0x00BAB830: LDR x20, [x19, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BAB834: CBNZ x20, #0xbab83c        | if (this.<csf>k__BackingField != null) goto label_16;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_16;
        }
        // 0x00BAB838: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_16:
        // 0x00BAB83C: ADRP x9, #0x35d8000        | X9 = 56459264 (0x35D8000);              
        // 0x00BAB840: ADRP x10, #0x3658000       | X10 = 56983552 (0x3658000);             
        // 0x00BAB844: LDR x9, [x9, #0x88]        | X9 = 1152921514490071456;               
        // 0x00BAB848: LDR x10, [x10, #0x980]     | X10 = 1152921504898113536;              
        // 0x00BAB84C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAB850: STRB w8, [x20, #0x54]      | this.<csf>k__BackingField.isNeedRXEvent = true;  //  dest_result_addr=0
        this.<csf>k__BackingField.isNeedRXEvent = true;
        // 0x00BAB854: LDR x21, [x9]              | X21 = System.Void CameraHelper::OnCameraRXFixed(CEvent.ZEvent ev);
        // 0x00BAB858: LDR x0, [x10]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_4 = null;
        // 0x00BAB85C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00BAB860: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00BAB864: LDR x8, [x8, #0xc38]       | X8 = 1152921512949758048;               
        // 0x00BAB868: MOV x1, x19                | X1 = 1152921514490096592 (0x100000024D166BD0);//ML01
        // 0x00BAB86C: MOV x2, x21                | X2 = 1152921514490071456 (0x100000024D1609A0);//ML01
        // 0x00BAB870: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00BAB874: LDR x3, [x8]               | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00BAB878: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraHelper::OnCameraRXFixed(CEvent.ZEvent ev));
        val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraHelper::OnCameraRXFixed(CEvent.ZEvent ev));
        // 0x00BAB87C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00BAB880: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00BAB884: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00BAB888: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00BAB88C: TBZ w8, #0, #0xbab89c      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00BAB890: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00BAB894: CBNZ w8, #0xbab89c         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00BAB898: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_18:
        // 0x00BAB89C: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00BAB8A0: LDR x8, [x8, #0xd98]       | X8 = (string**)(1152921514490072480)("Camera_RX_FIXED");
        // 0x00BAB8A4: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00BAB8A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB8AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAB8B0: LDR x1, [x8]               | X1 = "Camera_RX_FIXED";                 
        // 0x00BAB8B4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAB8B8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAB8BC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAB8C0: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00BAB8C4: B #0xd775dc                | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "Camera_RX_FIXED"); return;
        CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "Camera_RX_FIXED");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAB8C8 (12237000), len: 508  VirtAddr: 0x00BAB8C8 RVA: 0x00BAB8C8 token: 100690227 methodIndex: 25685 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnCameraRXFixed(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        // 0x00BAB8C8: STP x22, x21, [sp, #-0x30]! | stack[1152921514490266288] = ???;  stack[1152921514490266296] = ???;  //  dest_result_addr=1152921514490266288 |  dest_result_addr=1152921514490266296
        // 0x00BAB8CC: STP x20, x19, [sp, #0x10]  | stack[1152921514490266304] = ???;  stack[1152921514490266312] = ???;  //  dest_result_addr=1152921514490266304 |  dest_result_addr=1152921514490266312
        // 0x00BAB8D0: STP x29, x30, [sp, #0x20]  | stack[1152921514490266320] = ???;  stack[1152921514490266328] = ???;  //  dest_result_addr=1152921514490266320 |  dest_result_addr=1152921514490266328
        // 0x00BAB8D4: ADD x29, sp, #0x20         | X29 = (1152921514490266288 + 32) = 1152921514490266320 (0x100000024D1902D0);
        // 0x00BAB8D8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAB8DC: LDRB w8, [x20, #0xafa]     | W8 = (bool)static_value_03733AFA;       
        // 0x00BAB8E0: MOV x19, x0                | X19 = 1152921514490278336 (0x100000024D1931C0);//ML01
        // 0x00BAB8E4: TBNZ w8, #0, #0xbab900     | if (static_value_03733AFA == true) goto label_0;
        // 0x00BAB8E8: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00BAB8EC: LDR x8, [x8, #0x1d8]       | X8 = 0x2B90200;                         
        // 0x00BAB8F0: LDR w0, [x8]               | W0 = 0x1744;                            
        // 0x00BAB8F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1744, ????);     
        // 0x00BAB8F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAB8FC: STRB w8, [x20, #0xafa]     | static_value_03733AFA = true;            //  dest_result_addr=57883386
        label_0:
        // 0x00BAB900: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
        // 0x00BAB904: ADRP x9, #0x3658000        | X9 = 56983552 (0x3658000);              
        // 0x00BAB908: LDR x8, [x8, #0x88]        | X8 = 1152921514490071456;               
        // 0x00BAB90C: LDR x9, [x9, #0x980]       | X9 = 1152921504898113536;               
        // 0x00BAB910: LDR x21, [x8]              | X21 = System.Void CameraHelper::OnCameraRXFixed(CEvent.ZEvent ev);
        // 0x00BAB914: LDR x0, [x9]               | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_1 = null;
        // 0x00BAB918: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00BAB91C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00BAB920: LDR x8, [x8, #0xc38]       | X8 = 1152921512949758048;               
        // 0x00BAB924: MOV x1, x19                | X1 = 1152921514490278336 (0x100000024D1931C0);//ML01
        // 0x00BAB928: MOV x2, x21                | X2 = 1152921514490071456 (0x100000024D1609A0);//ML01
        // 0x00BAB92C: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00BAB930: LDR x3, [x8]               | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00BAB934: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraHelper::OnCameraRXFixed(CEvent.ZEvent ev));
        val_1 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraHelper::OnCameraRXFixed(CEvent.ZEvent ev));
        // 0x00BAB938: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00BAB93C: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00BAB940: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00BAB944: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00BAB948: TBZ w8, #0, #0xbab958      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BAB94C: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00BAB950: CBNZ w8, #0xbab958         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BAB954: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00BAB958: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00BAB95C: LDR x8, [x8, #0xd98]       | X8 = (string**)(1152921514490072480)("Camera_RX_FIXED");
        // 0x00BAB960: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB964: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAB968: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00BAB96C: LDR x1, [x8]               | X1 = "Camera_RX_FIXED";                 
        // 0x00BAB970: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "Camera_RX_FIXED");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "Camera_RX_FIXED");
        // 0x00BAB974: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00BAB978: LDR w20, [x19, #0x88]      | W20 = this.effid; //P2                  
        // 0x00BAB97C: LDR x8, [x8, #0xc88]       | X8 = 1152921504898273280;               
        // 0x00BAB980: LDR x0, [x8]               | X0 = typeof(RemoveEffect);              
        RemoveEffect val_2 = null;
        // 0x00BAB984: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(RemoveEffect), ????);
        // 0x00BAB988: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00BAB98C: LDR x8, [x8, #0x128]       | X8 = (string**)(1152921514490237840)("REMOVE_LOOP_EFF");
        // 0x00BAB990: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BAB994: MOVZ w2, #0x259            | W2 = 601 (0x259);//ML01                 
        // 0x00BAB998: MOV w3, w20                | W3 = this.effid;//m1                    
        // 0x00BAB99C: LDR x1, [x8]               | X1 = "REMOVE_LOOP_EFF";                 
        // 0x00BAB9A0: MOV x21, x0                | X21 = 1152921504898273280 (0x10000000115ED000);//ML01
        // 0x00BAB9A4: BL #0xc94dac               | .ctor(type:  "REMOVE_LOOP_EFF", id:  89, instanceID:  this.effid);
        val_2 = new RemoveEffect(type:  "REMOVE_LOOP_EFF", id:  89, instanceID:  this.effid);
        // 0x00BAB9A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB9AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB9B0: MOV x1, x21                | X1 = 1152921504898273280 (0x10000000115ED000);//ML01
        // 0x00BAB9B4: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        // 0x00BAB9B8: LDR x20, [x19, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BAB9BC: CBNZ x20, #0xbab9c4        | if (this.<csf>k__BackingField != null) goto label_3;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_3;
        }
        // 0x00BAB9C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00BAB9C4: STRB wzr, [x20, #0x54]     | this.<csf>k__BackingField.isNeedRXEvent = false;  //  dest_result_addr=0
        this.<csf>k__BackingField.isNeedRXEvent = false;
        // 0x00BAB9C8: LDR x20, [x19, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BAB9CC: CBNZ x20, #0xbab9d4        | if (this.<csf>k__BackingField != null) goto label_4;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_4;
        }
        // 0x00BAB9D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_4:
        // 0x00BAB9D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAB9D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB9DC: STRB wzr, [x20, #0x5c]     | this.<csf>k__BackingField.isLockTarget = false;  //  dest_result_addr=0
        this.<csf>k__BackingField.isLockTarget = false;
        // 0x00BAB9E0: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_3 = UnityEngine.Camera.main;
        // 0x00BAB9E4: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00BAB9E8: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
        // 0x00BAB9EC: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00BAB9F0: LDR x21, [x8]              | X21 = typeof(System.String[]);          
        // 0x00BAB9F4: MOV x0, x21                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BAB9F8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
        // 0x00BAB9FC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BABA00: MOV x0, x21                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BABA04: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
        // 0x00BABA08: MOV x21, x0                | X21 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BABA0C: CBNZ x21, #0xbaba14        | if ( != null) goto label_5;             
        if(null != null)
        {
            goto label_5;
        }
        // 0x00BABA10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
        label_5:
        // 0x00BABA14: ADRP x22, #0x362d000       | X22 = 56807424 (0x362D000);             
        // 0x00BABA18: LDR x22, [x22, #0x358]     | X22 = (string**)(1152921514488637152)("heroRt");
        // 0x00BABA1C: LDR x0, [x22]              | X0 = "heroRt";                          
        // 0x00BABA20: CBZ x0, #0xbaba40          | if ("heroRt" == null) goto label_7;     
        // 0x00BABA24: LDR x8, [x21]              | X8 = ;                                  
        // 0x00BABA28: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BABA2C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "heroRt", ????);   
        // 0x00BABA30: CBNZ x0, #0xbaba40         | if ("heroRt" != null) goto label_7;     
        if("heroRt" != null)
        {
            goto label_7;
        }
        // 0x00BABA34: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "heroRt", ????);   
        // 0x00BABA38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABA3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "heroRt", ????);   
        label_7:
        // 0x00BABA40: LDR x22, [x22]             | X22 = "heroRt";                         
        // 0x00BABA44: LDR w8, [x21, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00BABA48: CBNZ w8, #0xbaba58         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x00BABA4C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "heroRt", ????);   
        // 0x00BABA50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABA54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "heroRt", ????);   
        label_8:
        // 0x00BABA58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BABA5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BABA60: MOV x1, x21                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00BABA64: STR x22, [x21, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "heroRt";  //  dest_result_addr=1152921504948897200
        typeof(System.String[]).__il2cppRuntimeField_20 = "heroRt";
        // 0x00BABA68: BL #0x1a73324              | X0 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        int val_4 = UnityEngine.LayerMask.GetMask(layerNames:  0);
        // 0x00BABA6C: MOV w21, w0                | W21 = val_4;//m1                        
        // 0x00BABA70: CBNZ x20, #0xbaba78        | if (val_3 != null) goto label_9;        
        if(val_3 != null)
        {
            goto label_9;
        }
        // 0x00BABA74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00BABA78: MVN w1, w21                | W1 = ~(val_4);                          
        // 0x00BABA7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BABA80: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00BABA84: BL #0x20cf678              | val_3.set_cullingMask(value:  ~val_4);  
        val_3.cullingMask = ~val_4;
        // 0x00BABA88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BABA8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABA90: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_5 = UnityEngine.Camera.main;
        // 0x00BABA94: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00BABA98: CBNZ x20, #0xbabaa0        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00BABA9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00BABAA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BABAA4: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00BABAA8: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BABAAC: BL #0x20d097c              | val_5.set_clearFlags(value:  3);        
        val_5.clearFlags = 3;
        // 0x00BABAB0: STRB wzr, [x19, #0x79]     | this.isTeamSkillCamera = false;          //  dest_result_addr=1152921514490278457
        this.isTeamSkillCamera = false;
        // 0x00BABAB4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BABAB8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BABABC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BABAC0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BABAC4 (12237508), len: 4  VirtAddr: 0x00BABAC4 RVA: 0x00BABAC4 token: 100690228 methodIndex: 25686 delegateWrapperIndex: 0 methodInvoker: 0
    public void BreakTeamSkillCamera()
    {
        //
        // Disasemble & Code
        // 0x00BABAC4: B #0xbab6ac                | this.StopTeamSkillCamera(); return;     
        this.StopTeamSkillCamera();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BABAC8 (12237512), len: 1024  VirtAddr: 0x00BABAC8 RVA: 0x00BABAC8 token: 100690229 methodIndex: 25687 delegateWrapperIndex: 0 methodInvoker: 0
    public void MoveCamera(bool isHero, int id, bool isMove, float time, int AIid = 0)
    {
        //
        // Disasemble & Code
        //  | 
        int val_20;
        //  | 
        var val_21;
        //  | 
        IntPtr val_22;
        //  | 
        CameraSmoothFollow val_23;
        // 0x00BABAC8: STP d13, d12, [sp, #-0x90]! | stack[1152921514490560848] = ???;  stack[1152921514490560856] = ???;  //  dest_result_addr=1152921514490560848 |  dest_result_addr=1152921514490560856
        // 0x00BABACC: STP d11, d10, [sp, #0x10]  | stack[1152921514490560864] = ???;  stack[1152921514490560872] = ???;  //  dest_result_addr=1152921514490560864 |  dest_result_addr=1152921514490560872
        // 0x00BABAD0: STP d9, d8, [sp, #0x20]    | stack[1152921514490560880] = ???;  stack[1152921514490560888] = ???;  //  dest_result_addr=1152921514490560880 |  dest_result_addr=1152921514490560888
        // 0x00BABAD4: STP x28, x27, [sp, #0x30]  | stack[1152921514490560896] = ???;  stack[1152921514490560904] = ???;  //  dest_result_addr=1152921514490560896 |  dest_result_addr=1152921514490560904
        // 0x00BABAD8: STP x26, x25, [sp, #0x40]  | stack[1152921514490560912] = ???;  stack[1152921514490560920] = ???;  //  dest_result_addr=1152921514490560912 |  dest_result_addr=1152921514490560920
        // 0x00BABADC: STP x24, x23, [sp, #0x50]  | stack[1152921514490560928] = ???;  stack[1152921514490560936] = ???;  //  dest_result_addr=1152921514490560928 |  dest_result_addr=1152921514490560936
        // 0x00BABAE0: STP x22, x21, [sp, #0x60]  | stack[1152921514490560944] = ???;  stack[1152921514490560952] = ???;  //  dest_result_addr=1152921514490560944 |  dest_result_addr=1152921514490560952
        // 0x00BABAE4: STP x20, x19, [sp, #0x70]  | stack[1152921514490560960] = ???;  stack[1152921514490560968] = ???;  //  dest_result_addr=1152921514490560960 |  dest_result_addr=1152921514490560968
        // 0x00BABAE8: STP x29, x30, [sp, #0x80]  | stack[1152921514490560976] = ???;  stack[1152921514490560984] = ???;  //  dest_result_addr=1152921514490560976 |  dest_result_addr=1152921514490560984
        // 0x00BABAEC: ADD x29, sp, #0x80         | X29 = (1152921514490560848 + 128) = 1152921514490560976 (0x100000024D1D81D0);
        // 0x00BABAF0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BABAF4: LDRB w8, [x20, #0xafb]     | W8 = (bool)static_value_03733AFB;       
        // 0x00BABAF8: MOV w21, w4                | W21 = AIid;//m1                         
        val_20 = AIid;
        // 0x00BABAFC: MOV v8.16b, v0.16b         | V8 = time;//m1                          
        // 0x00BABB00: MOV w24, w3                | W24 = isMove;//m1                       
        // 0x00BABB04: MOV w22, w2                | W22 = id;//m1                           
        // 0x00BABB08: MOV w23, w1                | W23 = isHero;//m1                       
        // 0x00BABB0C: MOV x19, x0                | X19 = 1152921514490572992 (0x100000024D1DB0C0);//ML01
        // 0x00BABB10: TBNZ w8, #0, #0xbabb2c     | if (static_value_03733AFB == true) goto label_0;
        // 0x00BABB14: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
        // 0x00BABB18: LDR x8, [x8, #0xe20]       | X8 = 0x2B901FC;                         
        // 0x00BABB1C: LDR w0, [x8]               | W0 = 0x1743;                            
        // 0x00BABB20: BL #0x2782188              | X0 = sub_2782188( ?? 0x1743, ????);     
        // 0x00BABB24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BABB28: STRB w8, [x20, #0xafb]     | static_value_03733AFB = true;            //  dest_result_addr=57883387
        label_0:
        // 0x00BABB2C: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00BABB30: LDR x8, [x8, #0xb78]       | X8 = 1152921504887783424;               
        // 0x00BABB34: LDR x0, [x8]               | X0 = typeof(CameraHelper.<MoveCamera>c__AnonStorey0);
        object val_1 = null;
        // 0x00BABB38: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CameraHelper.<MoveCamera>c__AnonStorey0), ????);
        // 0x00BABB3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABB40: MOV x20, x0                | X20 = 1152921504887783424 (0x1000000010BEC000);//ML01
        // 0x00BABB44: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00BABB48: CBZ x20, #0xbabb58         | if ( == 0) goto label_1;                
        if(null == 0)
        {
            goto label_1;
        }
        // 0x00BABB4C: AND w8, w24, #1            | W8 = (isMove & 1);                      
        bool val_2 = isMove;
        // 0x00BABB50: STRB w8, [x20, #0x10]      | typeof(CameraHelper.<MoveCamera>c__AnonStorey0).__il2cppRuntimeField_10 = (isMove & 1);  //  dest_result_addr=1152921504887783440
        typeof(CameraHelper.<MoveCamera>c__AnonStorey0).__il2cppRuntimeField_10 = val_2;
        // 0x00BABB54: B #0xbabb6c                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00BABB58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BABB5C: AND w8, w24, #1            | W8 = (isMove & 1);                      
        bool val_3 = isMove;
        // 0x00BABB60: ORR w9, wzr, #0x10         | W9 = 16(0x10);                          
        // 0x00BABB64: STRB w8, [x9]              | mem[16] = (isMove & 1);                  //  dest_result_addr=16
        mem[16] = val_3;
        // 0x00BABB68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00BABB6C: STR x19, [x20, #0x18]      | typeof(CameraHelper.<MoveCamera>c__AnonStorey0).__il2cppRuntimeField_18 = this;  //  dest_result_addr=1152921504887783448
        typeof(CameraHelper.<MoveCamera>c__AnonStorey0).__il2cppRuntimeField_18 = this;
        // 0x00BABB70: AND w8, w23, #1            | W8 = (isHero & 1);                      
        bool val_4 = isHero;
        // 0x00BABB74: TBNZ w8, #0, #0xbabc98     | if ((isHero & 1) == true) goto label_14;
        if(val_4 == true)
        {
            goto label_14;
        }
        // 0x00BABB78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BABB7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABB80: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_5 = NpcMgr.instance;
        // 0x00BABB84: MOV x24, x0                | X24 = val_5;//m1                        
        // 0x00BABB88: CBNZ x24, #0xbabb90        | if (val_5 != null) goto label_4;        
        if(val_5 != null)
        {
            goto label_4;
        }
        // 0x00BABB8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_4:
        // 0x00BABB90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABB94: MOV x0, x24                | X0 = val_5;//m1                         
        // 0x00BABB98: BL #0xd14bbc               | X0 = val_5.GetCurRoundMonster();        
        System.Collections.Generic.List<CombatEntity> val_6 = val_5.GetCurRoundMonster();
        // 0x00BABB9C: ADRP x27, #0x3646000       | X27 = 56909824 (0x3646000);             
        // 0x00BABBA0: ADRP x28, #0x35cf000       | X28 = 56422400 (0x35CF000);             
        // 0x00BABBA4: LDR x27, [x27, #0xa00]     | X27 = 1152921510857364848;              
        // 0x00BABBA8: LDR x28, [x28, #0x628]     | X28 = 1152921510857186288;              
        // 0x00BABBAC: MOV x24, x0                | X24 = val_6;//m1                        
        // 0x00BABBB0: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        val_21 = 0;
        // 0x00BABBB4: B #0xbabbcc                |  goto label_5;                          
        goto label_5;
        label_10:
        // 0x00BABBB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BABBBC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BABBC0: MOV x0, x26                | X0 = X26;//m1                           
        // 0x00BABBC4: BL #0xd8bf54               | X26.SetViewModel(isShow:  true);        
        X26.SetViewModel(isShow:  true);
        // 0x00BABBC8: ADD w25, w25, #1           | W25 = (val_21 + 1) = val_21 (0x00000001);
        val_21 = 1;
        label_5:
        // 0x00BABBCC: CBNZ x24, #0xbabbd4        | if (val_6 != null) goto label_6;        
        if(val_6 != null)
        {
            goto label_6;
        }
        // 0x00BABBD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X26, ????);        
        label_6:
        // 0x00BABBD4: LDR x1, [x27]              | X1 = public System.Int32 System.Collections.Generic.List<CombatEntity>::get_Count();
        // 0x00BABBD8: MOV x0, x24                | X0 = val_6;//m1                         
        // 0x00BABBDC: BL #0x25ed72c              | X0 = val_6.get_Count();                 
        int val_7 = val_6.Count;
        // 0x00BABBE0: CMP w25, w0                | STATE = COMPARE(0x1, val_7)             
        // 0x00BABBE4: B.GE #0xbabc10             | if (val_21 >= val_7) goto label_7;      
        if(val_21 >= val_7)
        {
            goto label_7;
        }
        // 0x00BABBE8: CBNZ x24, #0xbabbf0        | if (val_6 != null) goto label_8;        
        if(val_6 != null)
        {
            goto label_8;
        }
        // 0x00BABBEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_8:
        // 0x00BABBF0: LDR x2, [x28]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
        // 0x00BABBF4: MOV x0, x24                | X0 = val_6;//m1                         
        // 0x00BABBF8: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
        // 0x00BABBFC: BL #0x25ed734              | X0 = val_6.get_Item(index:  1);         
        CombatEntity val_8 = val_6.Item[1];
        // 0x00BABC00: MOV x26, x0                | X26 = val_8;//m1                        
        // 0x00BABC04: CBNZ x26, #0xbabbb8        | if (val_8 != null) goto label_10;       
        if(val_8 != null)
        {
            goto label_10;
        }
        // 0x00BABC08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        // 0x00BABC0C: B #0xbabbb8                |  goto label_10;                         
        goto label_10;
        label_7:
        // 0x00BABC10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BABC14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABC18: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_9 = NpcMgr.instance;
        // 0x00BABC1C: MOV x24, x0                | X24 = val_9;//m1                        
        // 0x00BABC20: CBNZ x24, #0xbabc28        | if (val_9 != null) goto label_11;       
        if(val_9 != null)
        {
            goto label_11;
        }
        // 0x00BABC24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_11:
        // 0x00BABC28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABC2C: MOV x0, x24                | X0 = val_9;//m1                         
        // 0x00BABC30: BL #0xd14bc4               | X0 = val_9.GetCurRoundOther();          
        System.Collections.Generic.List<CombatEntity> val_10 = val_9.GetCurRoundOther();
        // 0x00BABC34: MOV x24, x0                | X24 = val_10;//m1                       
        // 0x00BABC38: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        val_22 = 0;
        // 0x00BABC3C: B #0xbabc54                |  goto label_12;                         
        goto label_12;
        label_17:
        // 0x00BABC40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BABC44: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BABC48: MOV x0, x26                | X0 = X26;//m1                           
        // 0x00BABC4C: BL #0xd8bf54               | X26.SetViewModel(isShow:  true);        
        X26.SetViewModel(isShow:  true);
        // 0x00BABC50: ADD w25, w25, #1           | W25 = (val_22 + 1) = val_22 (0x00000001);
        val_22 = 1;
        label_12:
        // 0x00BABC54: CBNZ x24, #0xbabc5c        | if (val_10 != null) goto label_13;      
        if(val_10 != null)
        {
            goto label_13;
        }
        // 0x00BABC58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X26, ????);        
        label_13:
        // 0x00BABC5C: LDR x1, [x27]              | X1 = public System.Int32 System.Collections.Generic.List<CombatEntity>::get_Count();
        // 0x00BABC60: MOV x0, x24                | X0 = val_10;//m1                        
        // 0x00BABC64: BL #0x25ed72c              | X0 = val_10.get_Count();                
        int val_11 = val_10.Count;
        // 0x00BABC68: CMP w25, w0                | STATE = COMPARE(0x1, val_11)            
        // 0x00BABC6C: B.GE #0xbabc98             | if (val_22 >= val_11) goto label_14;    
        if(val_22 >= val_11)
        {
            goto label_14;
        }
        // 0x00BABC70: CBNZ x24, #0xbabc78        | if (val_10 != null) goto label_15;      
        if(val_10 != null)
        {
            goto label_15;
        }
        // 0x00BABC74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_15:
        // 0x00BABC78: LDR x2, [x28]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
        // 0x00BABC7C: MOV x0, x24                | X0 = val_10;//m1                        
        // 0x00BABC80: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
        // 0x00BABC84: BL #0x25ed734              | X0 = val_10.get_Item(index:  1);        
        CombatEntity val_12 = val_10.Item[1];
        // 0x00BABC88: MOV x26, x0                | X26 = val_12;//m1                       
        // 0x00BABC8C: CBNZ x26, #0xbabc40        | if (val_12 != null) goto label_17;      
        if(val_12 != null)
        {
            goto label_17;
        }
        // 0x00BABC90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        // 0x00BABC94: B #0xbabc40                |  goto label_17;                         
        goto label_17;
        label_14:
        // 0x00BABC98: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BABC9C: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BABCA0: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BABCA4: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BABCA8: LDR x24, [x8]              | X24 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BABCAC: CBNZ x24, #0xbabcb4        | if (GameMgr.UPDATEOnOffEffect != null) goto label_18;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_18;
        }
        // 0x00BABCB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_18:
        // 0x00BABCB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BABCB8: AND w1, w23, #1            | W1 = (isHero & 1);                      
        bool val_13 = isHero;
        // 0x00BABCBC: MOV x0, x24                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BABCC0: MOV w2, w22                | W2 = id;//m1                            
        // 0x00BABCC4: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_13 = isHero, id:  id);
        CombatEntity val_14 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_13, id:  id);
        // 0x00BABCC8: LDR x23, [x19, #0x60]      | X23 = this.<csf>k__BackingField; //P2   
        val_23 = this.<csf>k__BackingField;
        // 0x00BABCCC: MOV x22, x0                | X22 = val_14;//m1                       
        // 0x00BABCD0: CBNZ x23, #0xbabcd8        | if (this.<csf>k__BackingField != null) goto label_19;
        if(val_23 != null)
        {
            goto label_19;
        }
        // 0x00BABCD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_19:
        // 0x00BABCD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BABCDC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BABCE0: MOV x0, x23                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BABCE4: BL #0x20cb458              | this.<csf>k__BackingField.set_enabled(value:  true);
        val_23.enabled = true;
        // 0x00BABCE8: CBNZ x20, #0xbabcf0        | if ( != 0) goto label_20;               
        if(null != 0)
        {
            goto label_20;
        }
        // 0x00BABCEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_20:
        // 0x00BABCF0: STR w21, [x20, #0x14]      | typeof(CameraHelper.<MoveCamera>c__AnonStorey0).__il2cppRuntimeField_14 = AIid;  //  dest_result_addr=1152921504887783444
        typeof(CameraHelper.<MoveCamera>c__AnonStorey0).__il2cppRuntimeField_14 = val_20;
        // 0x00BABCF4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BABCF8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BABCFC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BABD00: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BABD04: TBZ w8, #0, #0xbabd14      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_22;
        // 0x00BABD08: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BABD0C: CBNZ w8, #0xbabd14         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
        // 0x00BABD10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_22:
        // 0x00BABD14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BABD18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BABD1C: MOV x1, x22                | X1 = val_14;//m1                        
        // 0x00BABD20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BABD24: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_14);
        bool val_15 = UnityEngine.Object.op_Inequality(x:  0, y:  val_14);
        // 0x00BABD28: TBZ w0, #0, #0xbabd88      | if (val_15 == false) goto label_23;     
        if(val_15 == false)
        {
            goto label_23;
        }
        // 0x00BABD2C: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        val_20 = this.<csf>k__BackingField;
        // 0x00BABD30: CBNZ x22, #0xbabd38        | if (val_14 != null) goto label_24;      
        if(val_14 != null)
        {
            goto label_24;
        }
        // 0x00BABD34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_24:
        // 0x00BABD38: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
        // 0x00BABD3C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00BABD40: LDR x23, [x22, #0x58]      | 
        // 0x00BABD44: LDR x8, [x8, #0xa58]       | X8 = 1152921514490535680;               
        // 0x00BABD48: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00BABD4C: LDR x25, [x8]              | X25 = System.Void CameraHelper.<MoveCamera>c__AnonStorey0::<>m__0();
        val_22 = System.Void CameraHelper.<MoveCamera>c__AnonStorey0::<>m__0();
        // 0x00BABD50: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_16 = null;
        // 0x00BABD54: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00BABD58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BABD5C: MOV x1, x20                | X1 = 1152921504887783424 (0x1000000010BEC000);//ML01
        // 0x00BABD60: MOV x2, x25                | X2 = 1152921514490535680 (0x100000024D1D1F00);//ML01
        // 0x00BABD64: MOV x24, x0                | X24 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00BABD68: BL #0x26e30f0              | .ctor(object:  val_1, method:  val_22); 
        val_16 = new System.Action(object:  val_1, method:  val_22);
        // 0x00BABD6C: CBNZ x21, #0xbabd74        | if (this.<csf>k__BackingField != null) goto label_25;
        if(val_20 != null)
        {
            goto label_25;
        }
        // 0x00BABD70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_1, method:  val_22), ????);
        label_25:
        // 0x00BABD74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BABD78: MOV x0, x21                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BABD7C: MOV x1, x23                | X1 = this.<csf>k__BackingField;//m1     
        // 0x00BABD80: MOV x2, x24                | X2 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00BABD84: BL #0xd80334               | this.<csf>k__BackingField.PlayMove(_target:  val_23, _onFinished:  val_16);
        val_20.PlayMove(_target:  val_23, _onFinished:  val_16);
        label_23:
        // 0x00BABD88: FMOV s0, #-1.00000000      | S0 = -1;                                
        // 0x00BABD8C: FCMP s8, s0                | STATE = COMPARE(time, -1)               
        // 0x00BABD90: B.NE #0xbabea0             | if (time != -1f) goto label_26;         
        if(time != (-1f))
        {
            goto label_26;
        }
        // 0x00BABD94: LDP x21, x20, [x19, #0x60] | X21 = this.<csf>k__BackingField; //P2  X20 = this.tf; //P2  //  | 
        // 0x00BABD98: CBNZ x21, #0xbabda0        | if (this.<csf>k__BackingField != null) goto label_27;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_27;
        }
        // 0x00BABD9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_27:
        // 0x00BABDA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABDA4: MOV x0, x21                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BABDA8: BL #0xd80d14               | X0 = this.<csf>k__BackingField.OffsetPos();
        UnityEngine.Vector3 val_17 = this.<csf>k__BackingField.OffsetPos();
        // 0x00BABDAC: MOV v8.16b, v0.16b         | V8 = val_17.x;//m1                      
        // 0x00BABDB0: MOV v9.16b, v1.16b         | V9 = val_17.y;//m1                      
        // 0x00BABDB4: MOV v10.16b, v2.16b        | V10 = val_17.z;//m1                     
        // 0x00BABDB8: CBNZ x22, #0xbabdc0        | if (val_14 != null) goto label_28;      
        if(val_14 != null)
        {
            goto label_28;
        }
        // 0x00BABDBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_28:
        // 0x00BABDC0: LDR x21, [x22, #0x58]      | 
        // 0x00BABDC4: CBNZ x21, #0xbabdcc        | if (this.<csf>k__BackingField != null) goto label_29;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_29;
        }
        // 0x00BABDC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_29:
        // 0x00BABDCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABDD0: MOV x0, x21                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BABDD4: BL #0x2693510              | X0 = this.<csf>k__BackingField.get_position();
        UnityEngine.Vector3 val_18 = this.<csf>k__BackingField.position;
        // 0x00BABDD8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BABDDC: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BABDE0: MOV v11.16b, v0.16b        | V11 = val_18.x;//m1                     
        // 0x00BABDE4: MOV v12.16b, v1.16b        | V12 = val_18.y;//m1                     
        // 0x00BABDE8: MOV v13.16b, v2.16b        | V13 = val_18.z;//m1                     
        // 0x00BABDEC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BABDF0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BABDF4: TBZ w8, #0, #0xbabe04      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_31;
        // 0x00BABDF8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BABDFC: CBNZ w8, #0xbabe04         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
        // 0x00BABE00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_31:
        // 0x00BABE04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BABE08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABE0C: MOV v0.16b, v8.16b         | V0 = val_17.x;//m1                      
        // 0x00BABE10: MOV v1.16b, v9.16b         | V1 = val_17.y;//m1                      
        // 0x00BABE14: MOV v2.16b, v10.16b        | V2 = val_17.z;//m1                      
        // 0x00BABE18: MOV v3.16b, v11.16b        | V3 = val_18.x;//m1                      
        // 0x00BABE1C: MOV v4.16b, v12.16b        | V4 = val_18.y;//m1                      
        // 0x00BABE20: MOV v5.16b, v13.16b        | V5 = val_18.z;//m1                      
        // 0x00BABE24: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z}, b:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z});
        UnityEngine.Vector3 val_19 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z}, b:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z});
        // 0x00BABE28: MOV v8.16b, v0.16b         | V8 = val_19.x;//m1                      
        // 0x00BABE2C: MOV v9.16b, v1.16b         | V9 = val_19.y;//m1                      
        // 0x00BABE30: MOV v10.16b, v2.16b        | V10 = val_19.z;//m1                     
        // 0x00BABE34: CBNZ x20, #0xbabe3c        | if (this.tf != null) goto label_32;     
        if(this.tf != null)
        {
            goto label_32;
        }
        // 0x00BABE38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_32:
        // 0x00BABE3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABE40: MOV x0, x20                | X0 = this.tf;//m1                       
        // 0x00BABE44: MOV v0.16b, v8.16b         | V0 = val_19.x;//m1                      
        // 0x00BABE48: MOV v1.16b, v9.16b         | V1 = val_19.y;//m1                      
        // 0x00BABE4C: MOV v2.16b, v10.16b        | V2 = val_19.z;//m1                      
        // 0x00BABE50: BL #0x26936fc              | this.tf.set_localPosition(value:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z});
        this.tf.localPosition = new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z};
        // 0x00BABE54: LDR x19, [x19, #0x68]      | X19 = this.tf; //P2                     
        // 0x00BABE58: CBNZ x22, #0xbabe60        | if (val_14 != null) goto label_33;      
        if(val_14 != null)
        {
            goto label_33;
        }
        // 0x00BABE5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.tf, ????);    
        label_33:
        // 0x00BABE60: LDR x20, [x22, #0x58]      | 
        // 0x00BABE64: CBNZ x19, #0xbabe6c        | if (this.tf != null) goto label_34;     
        if(this.tf != null)
        {
            goto label_34;
        }
        // 0x00BABE68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.tf, ????);    
        label_34:
        // 0x00BABE6C: MOV x0, x19                | X0 = this.tf;//m1                       
        // 0x00BABE70: MOV x1, x20                | X1 = this.tf;//m1                       
        // 0x00BABE74: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x00BABE78: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x00BABE7C: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x00BABE80: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x00BABE84: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x00BABE88: LDP x28, x27, [sp, #0x30]  | X28 = ; X27 = ;                          //  | 
        // 0x00BABE8C: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00BABE90: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00BABE94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BABE98: LDP d13, d12, [sp], #0x90  | D13 = ; D12 = ;                          //  | 
        // 0x00BABE9C: B #0x26950d4               | this.tf.LookAt(target:  this.tf); return;
        this.tf.LookAt(target:  this.tf);
        return;
        label_26:
        // 0x00BABEA0: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x00BABEA4: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x00BABEA8: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x00BABEAC: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x00BABEB0: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x00BABEB4: LDP x28, x27, [sp, #0x30]  | X28 = ; X27 = ;                          //  | 
        // 0x00BABEB8: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00BABEBC: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00BABEC0: LDP d13, d12, [sp], #0x90  | D13 = ; D12 = ;                          //  | 
        // 0x00BABEC4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BABED0 (12238544), len: 388  VirtAddr: 0x00BABED0 RVA: 0x00BABED0 token: 100690230 methodIndex: 25688 delegateWrapperIndex: 0 methodInvoker: 0
    public void ChangeCameraTarget(bool isHero, int id, bool isMove, float time, string objName)
    {
        //
        // Disasemble & Code
        // 0x00BABED0: STP d9, d8, [sp, #-0x50]!  | stack[1152921514490747664] = ???;  stack[1152921514490747672] = ???;  //  dest_result_addr=1152921514490747664 |  dest_result_addr=1152921514490747672
        // 0x00BABED4: STP x24, x23, [sp, #0x10]  | stack[1152921514490747680] = ???;  stack[1152921514490747688] = ???;  //  dest_result_addr=1152921514490747680 |  dest_result_addr=1152921514490747688
        // 0x00BABED8: STP x22, x21, [sp, #0x20]  | stack[1152921514490747696] = ???;  stack[1152921514490747704] = ???;  //  dest_result_addr=1152921514490747696 |  dest_result_addr=1152921514490747704
        // 0x00BABEDC: STP x20, x19, [sp, #0x30]  | stack[1152921514490747712] = ???;  stack[1152921514490747720] = ???;  //  dest_result_addr=1152921514490747712 |  dest_result_addr=1152921514490747720
        // 0x00BABEE0: STP x29, x30, [sp, #0x40]  | stack[1152921514490747728] = ???;  stack[1152921514490747736] = ???;  //  dest_result_addr=1152921514490747728 |  dest_result_addr=1152921514490747736
        // 0x00BABEE4: ADD x29, sp, #0x40         | X29 = (1152921514490747664 + 64) = 1152921514490747728 (0x100000024D205B50);
        // 0x00BABEE8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BABEEC: LDRB w8, [x19, #0xafc]     | W8 = (bool)static_value_03733AFC;       
        // 0x00BABEF0: MOV x20, x4                | X20 = objName;//m1                      
        // 0x00BABEF4: MOV v8.16b, v0.16b         | V8 = time;//m1                          
        // 0x00BABEF8: MOV w24, w3                | W24 = isMove;//m1                       
        // 0x00BABEFC: MOV w22, w2                | W22 = id;//m1                           
        // 0x00BABF00: MOV w23, w1                | W23 = isHero;//m1                       
        // 0x00BABF04: MOV x21, x0                | X21 = 1152921514490759744 (0x100000024D208A40);//ML01
        // 0x00BABF08: TBNZ w8, #0, #0xbabf24     | if (static_value_03733AFC == true) goto label_0;
        // 0x00BABF0C: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
        // 0x00BABF10: LDR x8, [x8, #0x7a8]       | X8 = 0x2B901F0;                         
        // 0x00BABF14: LDR w0, [x8]               | W0 = 0x1740;                            
        // 0x00BABF18: BL #0x2782188              | X0 = sub_2782188( ?? 0x1740, ????);     
        // 0x00BABF1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BABF20: STRB w8, [x19, #0xafc]     | static_value_03733AFC = true;            //  dest_result_addr=57883388
        label_0:
        // 0x00BABF24: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00BABF28: LDR x8, [x8, #0xc20]       | X8 = 1152921504887836672;               
        // 0x00BABF2C: LDR x0, [x8]               | X0 = typeof(CameraHelper.<ChangeCameraTarget>c__AnonStorey1);
        object val_1 = null;
        // 0x00BABF30: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CameraHelper.<ChangeCameraTarget>c__AnonStorey1), ????);
        // 0x00BABF34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABF38: MOV x19, x0                | X19 = 1152921504887836672 (0x1000000010BF9000);//ML01
        // 0x00BABF3C: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00BABF40: CBZ x19, #0xbabf50         | if ( == 0) goto label_1;                
        if(null == 0)
        {
            goto label_1;
        }
        // 0x00BABF44: AND w8, w24, #1            | W8 = (isMove & 1);                      
        bool val_2 = isMove;
        // 0x00BABF48: STRB w8, [x19, #0x10]      | typeof(CameraHelper.<ChangeCameraTarget>c__AnonStorey1).__il2cppRuntimeField_10 = (isMove & 1);  //  dest_result_addr=1152921504887836688
        typeof(CameraHelper.<ChangeCameraTarget>c__AnonStorey1).__il2cppRuntimeField_10 = val_2;
        // 0x00BABF4C: B #0xbabf64                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00BABF50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BABF54: AND w8, w24, #1            | W8 = (isMove & 1);                      
        bool val_3 = isMove;
        // 0x00BABF58: ORR w9, wzr, #0x10         | W9 = 16(0x10);                          
        // 0x00BABF5C: STRB w8, [x9]              | mem[16] = (isMove & 1);                  //  dest_result_addr=16
        mem[16] = val_3;
        // 0x00BABF60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00BABF64: STR x21, [x19, #0x18]      | typeof(CameraHelper.<ChangeCameraTarget>c__AnonStorey1).__il2cppRuntimeField_18 = this;  //  dest_result_addr=1152921504887836696
        typeof(CameraHelper.<ChangeCameraTarget>c__AnonStorey1).__il2cppRuntimeField_18 = this;
        // 0x00BABF68: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BABF6C: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BABF70: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BABF74: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BABF78: LDR x24, [x8]              | X24 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BABF7C: CBNZ x24, #0xbabf84        | if (GameMgr.UPDATEOnOffEffect != null) goto label_3;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_3;
        }
        // 0x00BABF80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_3:
        // 0x00BABF84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BABF88: AND w1, w23, #1            | W1 = (isHero & 1);                      
        bool val_4 = isHero;
        // 0x00BABF8C: MOV x0, x24                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BABF90: MOV w2, w22                | W2 = id;//m1                            
        // 0x00BABF94: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_4 = isHero, id:  id);
        CombatEntity val_5 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_4, id:  id);
        // 0x00BABF98: LDR x23, [x21, #0x60]      | X23 = this.<csf>k__BackingField; //P2   
        // 0x00BABF9C: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00BABFA0: CBNZ x23, #0xbabfa8        | if (this.<csf>k__BackingField != null) goto label_4;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_4;
        }
        // 0x00BABFA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_4:
        // 0x00BABFA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BABFAC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BABFB0: MOV x0, x23                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BABFB4: BL #0x20cb458              | this.<csf>k__BackingField.set_enabled(value:  true);
        this.<csf>k__BackingField.enabled = true;
        // 0x00BABFB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BABFBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BABFC0: MOV x1, x22                | X1 = val_5;//m1                         
        // 0x00BABFC4: MOV x2, x20                | X2 = objName;//m1                       
        // 0x00BABFC8: BL #0xac489c               | X0 = MonoBehaviourVisitor.FindChild(_this:  0, name:  val_5);
        UnityEngine.GameObject val_6 = MonoBehaviourVisitor.FindChild(_this:  0, name:  val_5);
        // 0x00BABFCC: LDR x20, [x21, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BABFD0: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00BABFD4: CBNZ x21, #0xbabfdc        | if (val_6 != null) goto label_5;        
        if(val_6 != null)
        {
            goto label_5;
        }
        // 0x00BABFD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_5:
        // 0x00BABFDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BABFE0: MOV x0, x21                | X0 = val_6;//m1                         
        // 0x00BABFE4: BL #0x1a62c1c              | X0 = val_6.get_transform();             
        UnityEngine.Transform val_7 = val_6.transform;
        // 0x00BABFE8: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00BABFEC: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00BABFF0: LDR x8, [x8, #0x640]       | X8 = 1152921514490734720;               
        // 0x00BABFF4: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00BABFF8: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x00BABFFC: LDR x23, [x8]              | X23 = System.Void CameraHelper.<ChangeCameraTarget>c__AnonStorey1::<>m__0();
        // 0x00BAC000: LDR x8, [x9]               | X8 = typeof(System.Action);             
        // 0x00BAC004: MOV x0, x8                 | X0 = 1152921504687837184 (0x1000000004D3D000);//ML01
        System.Action val_8 = null;
        // 0x00BAC008: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00BAC00C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAC010: MOV x1, x19                | X1 = 1152921504887836672 (0x1000000010BF9000);//ML01
        // 0x00BAC014: MOV x2, x23                | X2 = 1152921514490734720 (0x100000024D202880);//ML01
        // 0x00BAC018: MOV x22, x0                | X22 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00BAC01C: BL #0x26e30f0              | .ctor(object:  val_1, method:  System.Void CameraHelper.<ChangeCameraTarget>c__AnonStorey1::<>m__0());
        val_8 = new System.Action(object:  val_1, method:  System.Void CameraHelper.<ChangeCameraTarget>c__AnonStorey1::<>m__0());
        // 0x00BAC020: CBNZ x20, #0xbac028        | if (this.<csf>k__BackingField != null) goto label_6;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_6;
        }
        // 0x00BAC024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_1, method:  System.Void CameraHelper.<ChangeCameraTarget>c__AnonStorey1::<>m__0()), ????);
        label_6:
        // 0x00BAC028: MOV x0, x20                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAC02C: MOV x1, x21                | X1 = val_7;//m1                         
        // 0x00BAC030: MOV x2, x22                | X2 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00BAC034: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAC038: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAC03C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAC040: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAC044: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAC048: MOV v0.16b, v8.16b         | V0 = time;//m1                          
        // 0x00BAC04C: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00BAC050: B #0xd802e4                | this.<csf>k__BackingField.ChangeTarget(_target:  val_7, time:  time, _onFinished:  val_8); return;
        this.<csf>k__BackingField.ChangeTarget(_target:  val_7, time:  time, _onFinished:  val_8);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B939CC (12138956), len: 4  VirtAddr: 0x00B939CC RVA: 0x00B939CC token: 100690231 methodIndex: 25689 delegateWrapperIndex: 0 methodInvoker: 0
    public void MotionBlur(UnityEngine.Transform target)
    {
        //
        // Disasemble & Code
        // 0x00B939CC: B #0xbab070                | this.MotionBlur(target:  target, distance:  null); return;
        this.MotionBlur(target:  target, distance:  null);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAC05C (12238940), len: 240  VirtAddr: 0x00BAC05C RVA: 0x00BAC05C token: 100690232 methodIndex: 25690 delegateWrapperIndex: 0 methodInvoker: 0
    public void ScreenShake(float _fps, float _shakeTime)
    {
        //
        // Disasemble & Code
        //  | 
        ScreenShake val_6;
        // 0x00BAC05C: STP d9, d8, [sp, #-0x30]!  | stack[1152921514491025968] = ???;  stack[1152921514491025976] = ???;  //  dest_result_addr=1152921514491025968 |  dest_result_addr=1152921514491025976
        // 0x00BAC060: STP x20, x19, [sp, #0x10]  | stack[1152921514491025984] = ???;  stack[1152921514491025992] = ???;  //  dest_result_addr=1152921514491025984 |  dest_result_addr=1152921514491025992
        // 0x00BAC064: STP x29, x30, [sp, #0x20]  | stack[1152921514491026000] = ???;  stack[1152921514491026008] = ???;  //  dest_result_addr=1152921514491026000 |  dest_result_addr=1152921514491026008
        // 0x00BAC068: ADD x29, sp, #0x20         | X29 = (1152921514491025968 + 32) = 1152921514491026000 (0x100000024D249A50);
        // 0x00BAC06C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAC070: LDRB w8, [x20, #0xafd]     | W8 = (bool)static_value_03733AFD;       
        // 0x00BAC074: MOV v8.16b, v1.16b         | V8 = _shakeTime;//m1                    
        // 0x00BAC078: MOV v9.16b, v0.16b         | V9 = _fps;//m1                          
        // 0x00BAC07C: MOV x19, x0                | X19 = 1152921514491038016 (0x100000024D24C940);//ML01
        // 0x00BAC080: TBNZ w8, #0, #0xbac09c     | if (static_value_03733AFD == true) goto label_0;
        // 0x00BAC084: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x00BAC088: LDR x8, [x8, #0x9b0]       | X8 = 0x2B90214;                         
        // 0x00BAC08C: LDR w0, [x8]               | W0 = 0x1749;                            
        // 0x00BAC090: BL #0x2782188              | X0 = sub_2782188( ?? 0x1749, ????);     
        // 0x00BAC094: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAC098: STRB w8, [x20, #0xafd]     | static_value_03733AFD = true;            //  dest_result_addr=57883389
        label_0:
        // 0x00BAC09C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BAC0A0: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BAC0A4: LDR x20, [x19, #0x58]      | X20 = this.ss; //P2                     
        // 0x00BAC0A8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BAC0AC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BAC0B0: TBZ w8, #0, #0xbac0c0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BAC0B4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BAC0B8: CBNZ w8, #0xbac0c0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BAC0BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00BAC0C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC0C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC0C8: MOV x1, x20                | X1 = this.ss;//m1                       
        // 0x00BAC0CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAC0D0: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.ss);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.ss);
        // 0x00BAC0D4: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00BAC0D8: TBZ w8, #0, #0xbac10c      | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00BAC0DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC0E0: MOV x0, x19                | X0 = 1152921514491038016 (0x100000024D24C940);//ML01
        // 0x00BAC0E4: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_3 = this.gameObject;
        // 0x00BAC0E8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAC0EC: LDR x8, [x8, #0xa80]       | X8 = 1152921514491000704;               
        // 0x00BAC0F0: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00BAC0F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC0F8: LDR x2, [x8]               | X2 = public static ScreenShake GameObject_MonoBehaviour::GetOrCreateComponent<ScreenShake>(UnityEngine.GameObject _this);
        // 0x00BAC0FC: BL #0xfd7798               | X0 = GameObject_MonoBehaviour.GetOrCreateComponent<ScreenShake>(_this:  0);
        ScreenShake val_4 = GameObject_MonoBehaviour.GetOrCreateComponent<ScreenShake>(_this:  0);
        // 0x00BAC100: MOV x20, x0                | X20 = val_4;//m1                        
        val_6 = val_4;
        // 0x00BAC104: STR x20, [x19, #0x58]      | this.ss = val_4;                         //  dest_result_addr=1152921514491038104
        this.ss = val_6;
        // 0x00BAC108: B #0xbac110                |  goto label_4;                          
        goto label_4;
        label_3:
        // 0x00BAC10C: LDR x20, [x19, #0x58]      | X20 = this.ss; //P2                     
        val_6 = this.ss;
        label_4:
        // 0x00BAC110: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC114: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC118: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_5 = UnityEngine.Camera.main;
        // 0x00BAC11C: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00BAC120: CBNZ x20, #0xbac128        | if (this.ss != null) goto label_5;      
        if(val_6 != null)
        {
            goto label_5;
        }
        // 0x00BAC124: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_5:
        // 0x00BAC128: MOV x0, x20                | X0 = this.ss;//m1                       
        // 0x00BAC12C: MOV x1, x19                | X1 = val_5;//m1                         
        // 0x00BAC130: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAC134: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAC138: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC13C: MOV v0.16b, v9.16b         | V0 = _fps;//m1                          
        // 0x00BAC140: MOV v1.16b, v8.16b         | V1 = _shakeTime;//m1                    
        // 0x00BAC144: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00BAC148: B #0xca4888                | this.ss.StartShake(_fps:  _fps, _shakeTime:  _shakeTime, _cam:  val_5); return;
        val_6.StartShake(_fps:  _fps, _shakeTime:  _shakeTime, _cam:  val_5);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAC14C (12239180), len: 256  VirtAddr: 0x00BAC14C RVA: 0x00BAC14C token: 100690233 methodIndex: 25691 delegateWrapperIndex: 0 methodInvoker: 0
    public void ScreenShake(float _fps, float _shakeTime, float _shakeDelta)
    {
        //
        // Disasemble & Code
        //  | 
        ScreenShake val_6;
        // 0x00BAC14C: STP d11, d10, [sp, #-0x40]! | stack[1152921514491178912] = ???;  stack[1152921514491178920] = ???;  //  dest_result_addr=1152921514491178912 |  dest_result_addr=1152921514491178920
        // 0x00BAC150: STP d9, d8, [sp, #0x10]    | stack[1152921514491178928] = ???;  stack[1152921514491178936] = ???;  //  dest_result_addr=1152921514491178928 |  dest_result_addr=1152921514491178936
        // 0x00BAC154: STP x20, x19, [sp, #0x20]  | stack[1152921514491178944] = ???;  stack[1152921514491178952] = ???;  //  dest_result_addr=1152921514491178944 |  dest_result_addr=1152921514491178952
        // 0x00BAC158: STP x29, x30, [sp, #0x30]  | stack[1152921514491178960] = ???;  stack[1152921514491178968] = ???;  //  dest_result_addr=1152921514491178960 |  dest_result_addr=1152921514491178968
        // 0x00BAC15C: ADD x29, sp, #0x30         | X29 = (1152921514491178912 + 48) = 1152921514491178960 (0x100000024D26EFD0);
        // 0x00BAC160: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAC164: LDRB w8, [x20, #0xafe]     | W8 = (bool)static_value_03733AFE;       
        // 0x00BAC168: MOV v8.16b, v2.16b         | V8 = _shakeDelta;//m1                   
        // 0x00BAC16C: MOV v9.16b, v1.16b         | V9 = _shakeTime;//m1                    
        // 0x00BAC170: MOV v10.16b, v0.16b        | V10 = _fps;//m1                         
        // 0x00BAC174: MOV x19, x0                | X19 = 1152921514491190976 (0x100000024D271EC0);//ML01
        // 0x00BAC178: TBNZ w8, #0, #0xbac194     | if (static_value_03733AFE == true) goto label_0;
        // 0x00BAC17C: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00BAC180: LDR x8, [x8, #0x368]       | X8 = 0x2B90210;                         
        // 0x00BAC184: LDR w0, [x8]               | W0 = 0x1748;                            
        // 0x00BAC188: BL #0x2782188              | X0 = sub_2782188( ?? 0x1748, ????);     
        // 0x00BAC18C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAC190: STRB w8, [x20, #0xafe]     | static_value_03733AFE = true;            //  dest_result_addr=57883390
        label_0:
        // 0x00BAC194: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BAC198: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BAC19C: LDR x20, [x19, #0x58]      | X20 = this.ss; //P2                     
        // 0x00BAC1A0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BAC1A4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BAC1A8: TBZ w8, #0, #0xbac1b8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BAC1AC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BAC1B0: CBNZ w8, #0xbac1b8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BAC1B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00BAC1B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC1BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC1C0: MOV x1, x20                | X1 = this.ss;//m1                       
        // 0x00BAC1C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAC1C8: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.ss);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.ss);
        // 0x00BAC1CC: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00BAC1D0: TBZ w8, #0, #0xbac204      | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00BAC1D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC1D8: MOV x0, x19                | X0 = 1152921514491190976 (0x100000024D271EC0);//ML01
        // 0x00BAC1DC: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_3 = this.gameObject;
        // 0x00BAC1E0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAC1E4: LDR x8, [x8, #0xa80]       | X8 = 1152921514491000704;               
        // 0x00BAC1E8: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00BAC1EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC1F0: LDR x2, [x8]               | X2 = public static ScreenShake GameObject_MonoBehaviour::GetOrCreateComponent<ScreenShake>(UnityEngine.GameObject _this);
        // 0x00BAC1F4: BL #0xfd7798               | X0 = GameObject_MonoBehaviour.GetOrCreateComponent<ScreenShake>(_this:  0);
        ScreenShake val_4 = GameObject_MonoBehaviour.GetOrCreateComponent<ScreenShake>(_this:  0);
        // 0x00BAC1F8: MOV x20, x0                | X20 = val_4;//m1                        
        val_6 = val_4;
        // 0x00BAC1FC: STR x20, [x19, #0x58]      | this.ss = val_4;                         //  dest_result_addr=1152921514491191064
        this.ss = val_6;
        // 0x00BAC200: B #0xbac208                |  goto label_4;                          
        goto label_4;
        label_3:
        // 0x00BAC204: LDR x20, [x19, #0x58]      | X20 = this.ss; //P2                     
        val_6 = this.ss;
        label_4:
        // 0x00BAC208: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC20C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC210: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_5 = UnityEngine.Camera.main;
        // 0x00BAC214: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00BAC218: CBNZ x20, #0xbac220        | if (this.ss != null) goto label_5;      
        if(val_6 != null)
        {
            goto label_5;
        }
        // 0x00BAC21C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_5:
        // 0x00BAC220: MOV x0, x20                | X0 = this.ss;//m1                       
        // 0x00BAC224: MOV v1.16b, v9.16b         | V1 = _shakeTime;//m1                    
        // 0x00BAC228: MOV x1, x19                | X1 = val_5;//m1                         
        // 0x00BAC22C: MOV v2.16b, v8.16b         | V2 = _shakeDelta;//m1                   
        // 0x00BAC230: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAC234: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAC238: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAC23C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC240: MOV v0.16b, v10.16b        | V0 = _fps;//m1                          
        // 0x00BAC244: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
        // 0x00BAC248: B #0xca48a8                | this.ss.StartShake(_fps:  _fps, _shakeTime:  _shakeTime, _cam:  val_5, _shakeDelta:  _shakeDelta); return;
        val_6.StartShake(_fps:  _fps, _shakeTime:  _shakeTime, _cam:  val_5, _shakeDelta:  _shakeDelta);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAC24C (12239436), len: 1056  VirtAddr: 0x00BAC24C RVA: 0x00BAC24C token: 100690234 methodIndex: 25692 delegateWrapperIndex: 0 methodInvoker: 0
    public void LockView(bool isHero, int id, float fov, float dis, float rx, float ry, string objName)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Object val_23;
        // 0x00BAC24C: STP d15, d14, [sp, #-0x80]! | stack[1152921514491368672] = ???;  stack[1152921514491368680] = ???;  //  dest_result_addr=1152921514491368672 |  dest_result_addr=1152921514491368680
        // 0x00BAC250: STP d13, d12, [sp, #0x10]  | stack[1152921514491368688] = ???;  stack[1152921514491368696] = ???;  //  dest_result_addr=1152921514491368688 |  dest_result_addr=1152921514491368696
        // 0x00BAC254: STP d11, d10, [sp, #0x20]  | stack[1152921514491368704] = ???;  stack[1152921514491368712] = ???;  //  dest_result_addr=1152921514491368704 |  dest_result_addr=1152921514491368712
        // 0x00BAC258: STP d9, d8, [sp, #0x30]    | stack[1152921514491368720] = ???;  stack[1152921514491368728] = ???;  //  dest_result_addr=1152921514491368720 |  dest_result_addr=1152921514491368728
        // 0x00BAC25C: STP x24, x23, [sp, #0x40]  | stack[1152921514491368736] = ???;  stack[1152921514491368744] = ???;  //  dest_result_addr=1152921514491368736 |  dest_result_addr=1152921514491368744
        // 0x00BAC260: STP x22, x21, [sp, #0x50]  | stack[1152921514491368752] = ???;  stack[1152921514491368760] = ???;  //  dest_result_addr=1152921514491368752 |  dest_result_addr=1152921514491368760
        // 0x00BAC264: STP x20, x19, [sp, #0x60]  | stack[1152921514491368768] = ???;  stack[1152921514491368776] = ???;  //  dest_result_addr=1152921514491368768 |  dest_result_addr=1152921514491368776
        // 0x00BAC268: STP x29, x30, [sp, #0x70]  | stack[1152921514491368784] = ???;  stack[1152921514491368792] = ???;  //  dest_result_addr=1152921514491368784 |  dest_result_addr=1152921514491368792
        // 0x00BAC26C: ADD x29, sp, #0x70         | X29 = (1152921514491368672 + 112) = 1152921514491368784 (0x100000024D29D550);
        // 0x00BAC270: SUB sp, sp, #0x10          | SP = (1152921514491368672 - 16) = 1152921514491368656 (0x100000024D29D4D0);
        // 0x00BAC274: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
        // 0x00BAC278: LDRB w8, [x23, #0xaff]     | W8 = (bool)static_value_03733AFF;       
        // 0x00BAC27C: MOV x21, x3                | X21 = objName;//m1                      
        // 0x00BAC280: MOV v10.16b, v3.16b        | V10 = ry;//m1                           
        // 0x00BAC284: MOV v11.16b, v2.16b        | V11 = rx;//m1                           
        // 0x00BAC288: MOV v9.16b, v1.16b         | V9 = dis;//m1                           
        // 0x00BAC28C: MOV w20, w2                | W20 = id;//m1                           
        // 0x00BAC290: MOV w22, w1                | W22 = isHero;//m1                       
        // 0x00BAC294: MOV x19, x0                | X19 = 1152921514491380800 (0x100000024D2A0440);//ML01
        // 0x00BAC298: STR s0, [sp, #0xc]         | stack[1152921514491368668] = fov;        //  dest_result_addr=1152921514491368668
        // 0x00BAC29C: TBNZ w8, #0, #0xbac2b8     | if (static_value_03733AFF == true) goto label_0;
        // 0x00BAC2A0: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00BAC2A4: LDR x8, [x8, #0x4d8]       | X8 = 0x2B901F4;                         
        // 0x00BAC2A8: LDR w0, [x8]               | W0 = 0x1741;                            
        // 0x00BAC2AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1741, ????);     
        // 0x00BAC2B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAC2B4: STRB w8, [x23, #0xaff]     | static_value_03733AFF = true;            //  dest_result_addr=57883391
        label_0:
        // 0x00BAC2B8: LDR x23, [x19, #0x60]      | X23 = this.<csf>k__BackingField; //P2   
        // 0x00BAC2BC: CBNZ x23, #0xbac2c4        | if (this.<csf>k__BackingField != null) goto label_1;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_1;
        }
        // 0x00BAC2C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1741, ????);     
        label_1:
        // 0x00BAC2C4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAC2C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC2CC: MOV x0, x23                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAC2D0: BL #0x20cb458              | this.<csf>k__BackingField.set_enabled(value:  false);
        this.<csf>k__BackingField.enabled = false;
        // 0x00BAC2D4: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BAC2D8: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BAC2DC: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BAC2E0: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BAC2E4: LDR x23, [x8]              | X23 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BAC2E8: CBNZ x23, #0xbac2f0        | if (GameMgr.UPDATEOnOffEffect != null) goto label_2;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_2;
        }
        // 0x00BAC2EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_2:
        // 0x00BAC2F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAC2F4: AND w1, w22, #1            | W1 = (isHero & 1);                      
        bool val_1 = isHero;
        // 0x00BAC2F8: MOV x0, x23                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BAC2FC: MOV w2, w20                | W2 = id;//m1                            
        // 0x00BAC300: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_1 = isHero, id:  id);
        CombatEntity val_2 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_1, id:  id);
        // 0x00BAC304: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00BAC308: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC30C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAC310: MOV x1, x22                | X1 = val_2;//m1                         
        // 0x00BAC314: MOV x2, x21                | X2 = objName;//m1                       
        // 0x00BAC318: BL #0xac489c               | X0 = MonoBehaviourVisitor.FindChild(_this:  0, name:  val_2);
        UnityEngine.GameObject val_3 = MonoBehaviourVisitor.FindChild(_this:  0, name:  val_2);
        // 0x00BAC31C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BAC320: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BAC324: MOV x20, x0                | X20 = val_3;//m1                        
        val_23 = val_3;
        // 0x00BAC328: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00BAC32C: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BAC330: TBZ w9, #0, #0xbac344      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00BAC334: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BAC338: CBNZ w9, #0xbac344         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00BAC33C: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00BAC340: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x00BAC344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC348: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC34C: MOV x1, x20                | X1 = val_3;//m1                         
        // 0x00BAC350: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAC354: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_23);
        bool val_4 = UnityEngine.Object.op_Equality(x:  0, y:  val_23);
        // 0x00BAC358: TBZ w0, #0, #0xbac450      | if (val_4 == false) goto label_5;       
        if(val_4 == false)
        {
            goto label_5;
        }
        // 0x00BAC35C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC360: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC364: MOV x1, x21                | X1 = objName;//m1                       
        // 0x00BAC368: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_5 = System.Single.Parse(s:  0);
        // 0x00BAC36C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BAC370: LDR x8, [x8, #0x30]        | X8 = 1152921504692629504;               
        // 0x00BAC374: MOV v12.16b, v0.16b        | V12 = val_5;//m1                        
        // 0x00BAC378: LDR x0, [x8]               | X0 = typeof(UnityEngine.GameObject);    
        UnityEngine.GameObject val_6 = null;
        // 0x00BAC37C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.GameObject), ????);
        // 0x00BAC380: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC384: MOV x1, x21                | X1 = objName;//m1                       
        // 0x00BAC388: MOV x20, x0                | X20 = 1152921504692629504 (0x10000000051CF000);//ML01
        val_23 = val_6;
        // 0x00BAC38C: BL #0x1a62378              | .ctor(name:  objName);                  
        val_6 = new UnityEngine.GameObject(name:  objName);
        // 0x00BAC390: CBNZ x20, #0xbac398        | if ( != 0) goto label_6;                
        if(null != 0)
        {
            goto label_6;
        }
        // 0x00BAC394: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(name:  objName), ????);
        label_6:
        // 0x00BAC398: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC39C: MOV x0, x20                | X0 = 1152921504692629504 (0x10000000051CF000);//ML01
        // 0x00BAC3A0: BL #0x1a62c1c              | X0 = get_transform();                   
        UnityEngine.Transform val_7 = transform;
        // 0x00BAC3A4: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x00BAC3A8: CBNZ x22, #0xbac3b0        | if (val_2 != null) goto label_7;        
        if(val_2 != null)
        {
            goto label_7;
        }
        // 0x00BAC3AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_7:
        // 0x00BAC3B0: LDR x22, [x22, #0x58]      | 
        // 0x00BAC3B4: CBNZ x21, #0xbac3bc        | if (val_7 != null) goto label_8;        
        if(val_7 != null)
        {
            goto label_8;
        }
        // 0x00BAC3B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_8:
        // 0x00BAC3BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC3C0: MOV x0, x21                | X0 = val_7;//m1                         
        // 0x00BAC3C4: MOV x1, x22                | X1 = val_2;//m1                         
        // 0x00BAC3C8: BL #0x2694464              | val_7.set_parent(value:  val_2);        
        val_7.parent = val_2;
        // 0x00BAC3CC: CBNZ x20, #0xbac3d4        | if ( != 0) goto label_9;                
        if(null != 0)
        {
            goto label_9;
        }
        // 0x00BAC3D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00BAC3D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC3D8: MOV x0, x20                | X0 = 1152921504692629504 (0x10000000051CF000);//ML01
        // 0x00BAC3DC: BL #0x1a62c1c              | X0 = get_transform();                   
        UnityEngine.Transform val_8 = transform;
        // 0x00BAC3E0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAC3E4: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAC3E8: MOV x21, x0                | X21 = val_8;//m1                        
        // 0x00BAC3EC: LDR x8, [x8]               | X8 = typeof(UnityEngine.Vector3);       
        // 0x00BAC3F0: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAC3F4: TBZ w9, #0, #0xbac408      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00BAC3F8: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAC3FC: CBNZ w9, #0xbac408         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00BAC400: MOV x0, x8                 | X0 = 1152921504695078912 (0x1000000005425000);//ML01
        // 0x00BAC404: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_11:
        // 0x00BAC408: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC40C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC410: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_9 = UnityEngine.Vector3.up;
        // 0x00BAC414: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC418: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC41C: MOV v3.16b, v12.16b        | V3 = val_5;//m1                         
        // 0x00BAC420: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, d:  val_5);
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, d:  val_5);
        // 0x00BAC424: MOV v8.16b, v0.16b         | V8 = val_10.x;//m1                      
        // 0x00BAC428: MOV v12.16b, v1.16b        | V12 = val_10.y;//m1                     
        // 0x00BAC42C: MOV v13.16b, v2.16b        | V13 = val_10.z;//m1                     
        // 0x00BAC430: CBNZ x21, #0xbac438        | if (val_8 != null) goto label_12;       
        if(val_8 != null)
        {
            goto label_12;
        }
        // 0x00BAC434: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_12:
        // 0x00BAC438: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC43C: MOV x0, x21                | X0 = val_8;//m1                         
        // 0x00BAC440: MOV v0.16b, v8.16b         | V0 = val_10.x;//m1                      
        // 0x00BAC444: MOV v1.16b, v12.16b        | V1 = val_10.y;//m1                      
        // 0x00BAC448: MOV v2.16b, v13.16b        | V2 = val_10.z;//m1                      
        // 0x00BAC44C: BL #0x26936fc              | val_8.set_localPosition(value:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z});
        val_8.localPosition = new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z};
        label_5:
        // 0x00BAC450: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00BAC454: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00BAC458: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00BAC45C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00BAC460: TBZ w8, #0, #0xbac470      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00BAC464: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00BAC468: CBNZ w8, #0xbac470         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00BAC46C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_14:
        // 0x00BAC470: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC474: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC478: FMOV s2, wzr               | S2 = 0f;                                
        // 0x00BAC47C: MOV v0.16b, v11.16b        | V0 = rx;//m1                            
        // 0x00BAC480: MOV v1.16b, v10.16b        | V1 = ry;//m1                            
        // 0x00BAC484: BL #0x1b7f530              | X0 = UnityEngine.Quaternion.Euler(x:  rx, y:  ry, z:  0f);
        UnityEngine.Quaternion val_11 = UnityEngine.Quaternion.Euler(x:  rx, y:  ry, z:  0f);
        // 0x00BAC488: MOV v10.16b, v0.16b        | V10 = val_11.x;//m1                     
        // 0x00BAC48C: MOV v11.16b, v1.16b        | V11 = val_11.y;//m1                     
        // 0x00BAC490: MOV v12.16b, v2.16b        | V12 = val_11.z;//m1                     
        // 0x00BAC494: MOV v13.16b, v3.16b        | V13 = val_11.w;//m1                     
        // 0x00BAC498: CBNZ x20, #0xbac4a0        | if ( != 0) goto label_15;               
        if(null != 0)
        {
            goto label_15;
        }
        // 0x00BAC49C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_15:
        // 0x00BAC4A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC4A4: MOV x0, x20                | X0 = 1152921504692629504 (0x10000000051CF000);//ML01
        // 0x00BAC4A8: BL #0x1a62c1c              | X0 = get_transform();                   
        UnityEngine.Transform val_12 = transform;
        // 0x00BAC4AC: MOV x21, x0                | X21 = val_12;//m1                       
        // 0x00BAC4B0: CBNZ x21, #0xbac4b8        | if (val_12 != null) goto label_16;      
        if(val_12 != null)
        {
            goto label_16;
        }
        // 0x00BAC4B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_16:
        // 0x00BAC4B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC4BC: MOV x0, x21                | X0 = val_12;//m1                        
        // 0x00BAC4C0: BL #0x2693510              | X0 = val_12.get_position();             
        UnityEngine.Vector3 val_13 = val_12.position;
        // 0x00BAC4C4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAC4C8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAC4CC: MOV v14.16b, v0.16b        | V14 = val_13.x;//m1                     
        // 0x00BAC4D0: MOV v15.16b, v1.16b        | V15 = val_13.y;//m1                     
        // 0x00BAC4D4: MOV v8.16b, v2.16b         | V8 = val_13.z;//m1                      
        // 0x00BAC4D8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAC4DC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAC4E0: TBZ w8, #0, #0xbac4f0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00BAC4E4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAC4E8: CBNZ w8, #0xbac4f0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00BAC4EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_18:
        // 0x00BAC4F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC4F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC4F8: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
        UnityEngine.Vector3 val_14 = UnityEngine.Vector3.forward;
        // 0x00BAC4FC: MOV v4.16b, v0.16b         | V4 = val_14.x;//m1                      
        // 0x00BAC500: MOV v5.16b, v1.16b         | V5 = val_14.y;//m1                      
        // 0x00BAC504: MOV v6.16b, v2.16b         | V6 = val_14.z;//m1                      
        // 0x00BAC508: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC50C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC510: MOV v0.16b, v10.16b        | V0 = val_11.x;//m1                      
        // 0x00BAC514: MOV v1.16b, v11.16b        | V1 = val_11.y;//m1                      
        // 0x00BAC518: MOV v2.16b, v12.16b        | V2 = val_11.z;//m1                      
        // 0x00BAC51C: MOV v3.16b, v13.16b        | V3 = val_11.w;//m1                      
        // 0x00BAC520: BL #0x1b7fc00              | X0 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = val_11.x, y = val_11.y, z = val_11.z, w = val_11.w}, point:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z});
        UnityEngine.Vector3 val_15 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = val_11.x, y = val_11.y, z = val_11.z, w = val_11.w}, point:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z});
        // 0x00BAC524: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC528: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC52C: MOV v3.16b, v9.16b         | V3 = dis;//m1                           
        // 0x00BAC530: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z}, d:  dis);
        UnityEngine.Vector3 val_16 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z}, d:  dis);
        // 0x00BAC534: MOV v3.16b, v0.16b         | V3 = val_16.x;//m1                      
        // 0x00BAC538: MOV v4.16b, v1.16b         | V4 = val_16.y;//m1                      
        // 0x00BAC53C: MOV v5.16b, v2.16b         | V5 = val_16.z;//m1                      
        // 0x00BAC540: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC548: MOV v0.16b, v14.16b        | V0 = val_13.x;//m1                      
        // 0x00BAC54C: MOV v1.16b, v15.16b        | V1 = val_13.y;//m1                      
        // 0x00BAC550: MOV v2.16b, v8.16b         | V2 = val_13.z;//m1                      
        // 0x00BAC554: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, b:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z});
        UnityEngine.Vector3 val_17 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, b:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z});
        // 0x00BAC558: LDR x21, [x19, #0x60]      | X21 = this.<csf>k__BackingField; //P2   
        // 0x00BAC55C: MOV v9.16b, v0.16b         | V9 = val_17.x;//m1                      
        // 0x00BAC560: MOV v10.16b, v1.16b        | V10 = val_17.y;//m1                     
        // 0x00BAC564: MOV v11.16b, v2.16b        | V11 = val_17.z;//m1                     
        // 0x00BAC568: CBNZ x21, #0xbac570        | if (this.<csf>k__BackingField != null) goto label_19;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_19;
        }
        // 0x00BAC56C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_19:
        // 0x00BAC570: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAC574: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC578: MOV x0, x21                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAC57C: BL #0x20cb458              | this.<csf>k__BackingField.set_enabled(value:  false);
        this.<csf>k__BackingField.enabled = false;
        // 0x00BAC580: LDR x21, [x19, #0x68]      | X21 = this.tf; //P2                     
        // 0x00BAC584: CBNZ x21, #0xbac58c        | if (this.tf != null) goto label_20;     
        if(this.tf != null)
        {
            goto label_20;
        }
        // 0x00BAC588: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<csf>k__BackingField, ????);
        label_20:
        // 0x00BAC58C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC590: MOV x0, x21                | X0 = this.tf;//m1                       
        // 0x00BAC594: BL #0x2693654              | X0 = this.tf.get_localPosition();       
        UnityEngine.Vector3 val_18 = this.tf.localPosition;
        // 0x00BAC598: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC59C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC5A0: STP s0, s1, [x19, #0x8c]   | this.lastPos = val_18;  mem[1152921514491380944] = val_18.y;  //  dest_result_addr=1152921514491380940 |  dest_result_addr=1152921514491380944
        this.lastPos = val_18;
        mem[1152921514491380944] = val_18.y;
        // 0x00BAC5A4: STR s2, [x19, #0x94]       | mem[1152921514491380948] = val_18.z;     //  dest_result_addr=1152921514491380948
        mem[1152921514491380948] = val_18.z;
        // 0x00BAC5A8: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_19 = UnityEngine.Camera.main;
        // 0x00BAC5AC: MOV x21, x0                | X21 = val_19;//m1                       
        // 0x00BAC5B0: CBNZ x21, #0xbac5b8        | if (val_19 != null) goto label_21;      
        if(val_19 != null)
        {
            goto label_21;
        }
        // 0x00BAC5B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_21:
        // 0x00BAC5B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC5BC: MOV x0, x21                | X0 = val_19;//m1                        
        // 0x00BAC5C0: BL #0x20ce7bc              | X0 = val_19.get_fieldOfView();          
        float val_20 = val_19.fieldOfView;
        // 0x00BAC5C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC5C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC5CC: STR s0, [x19, #0x98]       | this.lastFov = val_20;                   //  dest_result_addr=1152921514491380952
        this.lastFov = val_20;
        // 0x00BAC5D0: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_21 = UnityEngine.Camera.main;
        // 0x00BAC5D4: MOV x21, x0                | X21 = val_21;//m1                       
        // 0x00BAC5D8: CBNZ x21, #0xbac5e0        | if (val_21 != null) goto label_22;      
        if(val_21 != null)
        {
            goto label_22;
        }
        // 0x00BAC5DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_22:
        // 0x00BAC5E0: LDR s0, [sp, #0xc]         | S0 = fov;                               
        // 0x00BAC5E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC5E8: MOV x0, x21                | X0 = val_21;//m1                        
        // 0x00BAC5EC: BL #0x20ce824              | val_21.set_fieldOfView(value:  fov);    
        val_21.fieldOfView = fov;
        // 0x00BAC5F0: LDR x21, [x19, #0x68]      | X21 = this.tf; //P2                     
        // 0x00BAC5F4: CBNZ x21, #0xbac5fc        | if (this.tf != null) goto label_23;     
        if(this.tf != null)
        {
            goto label_23;
        }
        // 0x00BAC5F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_23:
        // 0x00BAC5FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC600: MOV x0, x21                | X0 = this.tf;//m1                       
        // 0x00BAC604: MOV v0.16b, v9.16b         | V0 = val_17.x;//m1                      
        // 0x00BAC608: MOV v1.16b, v10.16b        | V1 = val_17.y;//m1                      
        // 0x00BAC60C: MOV v2.16b, v11.16b        | V2 = val_17.z;//m1                      
        // 0x00BAC610: BL #0x26936fc              | this.tf.set_localPosition(value:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z});
        this.tf.localPosition = new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z};
        // 0x00BAC614: LDR x19, [x19, #0x68]      | X19 = this.tf; //P2                     
        // 0x00BAC618: CBNZ x20, #0xbac620        | if ( != 0) goto label_24;               
        if(null != 0)
        {
            goto label_24;
        }
        // 0x00BAC61C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.tf, ????);    
        label_24:
        // 0x00BAC620: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC624: MOV x0, x20                | X0 = 1152921504692629504 (0x10000000051CF000);//ML01
        // 0x00BAC628: BL #0x1a62c1c              | X0 = get_transform();                   
        UnityEngine.Transform val_22 = transform;
        // 0x00BAC62C: MOV x20, x0                | X20 = val_22;//m1                       
        // 0x00BAC630: CBNZ x19, #0xbac638        | if (this.tf != null) goto label_25;     
        if(this.tf != null)
        {
            goto label_25;
        }
        // 0x00BAC634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_25:
        // 0x00BAC638: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC63C: MOV x0, x19                | X0 = this.tf;//m1                       
        // 0x00BAC640: MOV x1, x20                | X1 = val_22;//m1                        
        // 0x00BAC644: SUB sp, x29, #0x70         | SP = (1152921514491368784 - 112) = 1152921514491368672 (0x100000024D29D4E0);
        // 0x00BAC648: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAC64C: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAC650: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAC654: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAC658: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAC65C: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAC660: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAC664: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00BAC668: B #0x26950d4               | this.tf.LookAt(target:  val_22); return;
        this.tf.LookAt(target:  val_22);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAC66C (12240492), len: 156  VirtAddr: 0x00BAC66C RVA: 0x00BAC66C token: 100690235 methodIndex: 25693 delegateWrapperIndex: 0 methodInvoker: 0
    public void UnLockView()
    {
        //
        // Disasemble & Code
        // 0x00BAC66C: STP d11, d10, [sp, #-0x40]! | stack[1152921514491550368] = ???;  stack[1152921514491550376] = ???;  //  dest_result_addr=1152921514491550368 |  dest_result_addr=1152921514491550376
        // 0x00BAC670: STP d9, d8, [sp, #0x10]    | stack[1152921514491550384] = ???;  stack[1152921514491550392] = ???;  //  dest_result_addr=1152921514491550384 |  dest_result_addr=1152921514491550392
        // 0x00BAC674: STP x20, x19, [sp, #0x20]  | stack[1152921514491550400] = ???;  stack[1152921514491550408] = ???;  //  dest_result_addr=1152921514491550400 |  dest_result_addr=1152921514491550408
        // 0x00BAC678: STP x29, x30, [sp, #0x30]  | stack[1152921514491550416] = ???;  stack[1152921514491550424] = ???;  //  dest_result_addr=1152921514491550416 |  dest_result_addr=1152921514491550424
        // 0x00BAC67C: ADD x29, sp, #0x30         | X29 = (1152921514491550368 + 48) = 1152921514491550416 (0x100000024D2C9AD0);
        // 0x00BAC680: MOV x19, x0                | X19 = 1152921514491562432 (0x100000024D2CC9C0);//ML01
        // 0x00BAC684: LDR x20, [x19, #0x68]      | X20 = this.tf; //P2                     
        // 0x00BAC688: LDP s8, s9, [x19, #0x8c]   | S8 = this.lastPos; //P2                  //  | 
        // 0x00BAC68C: LDR s10, [x19, #0x94]      | 
        // 0x00BAC690: CBNZ x20, #0xbac698        | if (this.tf != null) goto label_0;      
        if(this.tf != null)
        {
            goto label_0;
        }
        // 0x00BAC694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BAC698: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC69C: MOV x0, x20                | X0 = this.tf;//m1                       
        // 0x00BAC6A0: MOV v0.16b, v8.16b         | V0 = this.lastPos;//m1                  
        // 0x00BAC6A4: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00BAC6A8: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00BAC6AC: BL #0x26936fc              | this.tf.set_localPosition(value:  new UnityEngine.Vector3() {x = this.lastPos, y = V9.16B, z = V10.16B});
        this.tf.localPosition = new UnityEngine.Vector3() {x = this.lastPos, y = V9.16B, z = V10.16B};
        // 0x00BAC6B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAC6B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC6B8: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_1 = UnityEngine.Camera.main;
        // 0x00BAC6BC: LDR s8, [x19, #0x98]       | S8 = this.lastFov; //P2                 
        // 0x00BAC6C0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00BAC6C4: CBNZ x20, #0xbac6cc        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00BAC6C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00BAC6CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC6D0: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00BAC6D4: MOV v0.16b, v8.16b         | V0 = this.lastFov;//m1                  
        // 0x00BAC6D8: BL #0x20ce824              | val_1.set_fieldOfView(value:  this.lastFov);
        val_1.fieldOfView = this.lastFov;
        // 0x00BAC6DC: LDR x19, [x19, #0x60]      | X19 = this.<csf>k__BackingField; //P2   
        // 0x00BAC6E0: CBNZ x19, #0xbac6e8        | if (this.<csf>k__BackingField != null) goto label_2;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_2;
        }
        // 0x00BAC6E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00BAC6E8: MOV x0, x19                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAC6EC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAC6F0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAC6F4: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAC6F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC6FC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAC700: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
        // 0x00BAC704: B #0x20cb458               | this.<csf>k__BackingField.set_enabled(value:  true); return;
        this.<csf>k__BackingField.enabled = true;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAC708 (12240648), len: 4  VirtAddr: 0x00BAC708 RVA: 0x00BAC708 token: 100690236 methodIndex: 25694 delegateWrapperIndex: 0 methodInvoker: 0
    private static CameraHelper()
    {
        //
        // Disasemble & Code
        // 0x00BAC708: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAC70C (12240652), len: 60  VirtAddr: 0x00BAC70C RVA: 0x00BAC70C token: 100690237 methodIndex: 25695 delegateWrapperIndex: 0 methodInvoker: 0
    private void <MotionBlur>m__0()
    {
        //
        // Disasemble & Code
        // 0x00BAC70C: STP x20, x19, [sp, #-0x20]! | stack[1152921514491790784] = ???;  stack[1152921514491790792] = ???;  //  dest_result_addr=1152921514491790784 |  dest_result_addr=1152921514491790792
        // 0x00BAC710: STP x29, x30, [sp, #0x10]  | stack[1152921514491790800] = ???;  stack[1152921514491790808] = ???;  //  dest_result_addr=1152921514491790800 |  dest_result_addr=1152921514491790808
        // 0x00BAC714: ADD x29, sp, #0x10         | X29 = (1152921514491790784 + 16) = 1152921514491790800 (0x100000024D3045D0);
        // 0x00BAC718: MOV x19, x0                | X19 = 1152921514491802816 (0x100000024D3074C0);//ML01
        // 0x00BAC71C: LDR x20, [x19, #0x60]      | X20 = this.<csf>k__BackingField; //P2   
        // 0x00BAC720: CBNZ x20, #0xbac728        | if (this.<csf>k__BackingField != null) goto label_0;
        if((this.<csf>k__BackingField) != null)
        {
            goto label_0;
        }
        // 0x00BAC724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BAC728: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAC72C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAC730: MOV x0, x20                | X0 = this.<csf>k__BackingField;//m1     
        // 0x00BAC734: BL #0x20cb458              | this.<csf>k__BackingField.set_enabled(value:  true);
        this.<csf>k__BackingField.enabled = true;
        // 0x00BAC738: STRB wzr, [x19, #0x78]     | this.motionBluring = false;              //  dest_result_addr=1152921514491802936
        this.motionBluring = false;
        // 0x00BAC73C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAC740: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BAC744: RET                        |  return;                                
        return;
    
    }

}
