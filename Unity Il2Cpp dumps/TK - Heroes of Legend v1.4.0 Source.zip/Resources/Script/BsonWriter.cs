using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    public class BsonWriter : JsonWriter
    {
        // Fields
        private readonly Newtonsoft.Json.Bson.BsonBinaryWriter _writer; //  0x00000030
        private Newtonsoft.Json.Bson.BsonToken _root; //  0x00000038
        private Newtonsoft.Json.Bson.BsonToken _parent; //  0x00000040
        private string _propertyName; //  0x00000048
        
        // Properties
        public System.DateTimeKind DateTimeKindHandling { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD47EC (11356140), len: 180  VirtAddr: 0x00AD47EC RVA: 0x00AD47EC token: 100684795 methodIndex: 47439 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonWriter(System.IO.Stream stream)
        {
            //
            // Disasemble & Code
            // 0x00AD47EC: STP x22, x21, [sp, #-0x30]! | stack[1152921513725886880] = ???;  stack[1152921513725886888] = ???;  //  dest_result_addr=1152921513725886880 |  dest_result_addr=1152921513725886888
            // 0x00AD47F0: STP x20, x19, [sp, #0x10]  | stack[1152921513725886896] = ???;  stack[1152921513725886904] = ???;  //  dest_result_addr=1152921513725886896 |  dest_result_addr=1152921513725886904
            // 0x00AD47F4: STP x29, x30, [sp, #0x20]  | stack[1152921513725886912] = ???;  stack[1152921513725886920] = ???;  //  dest_result_addr=1152921513725886912 |  dest_result_addr=1152921513725886920
            // 0x00AD47F8: ADD x29, sp, #0x20         | X29 = (1152921513725886880 + 32) = 1152921513725886912 (0x100000021F8981C0);
            // 0x00AD47FC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD4800: LDRB w8, [x21, #0x4e0]     | W8 = (bool)static_value_037334E0;       
            // 0x00AD4804: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00AD4808: MOV x20, x0                | X20 = 1152921513725898928 (0x100000021F89B0B0);//ML01
            // 0x00AD480C: TBNZ w8, #0, #0xad4828     | if (static_value_037334E0 == true) goto label_0;
            // 0x00AD4810: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00AD4814: LDR x8, [x8, #0x708]       | X8 = 0x2B8F9D8;                         
            // 0x00AD4818: LDR w0, [x8]               | W0 = 0x153A;                            
            // 0x00AD481C: BL #0x2782188              | X0 = sub_2782188( ?? 0x153A, ????);     
            // 0x00AD4820: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4824: STRB w8, [x21, #0x4e0]     | static_value_037334E0 = true;            //  dest_result_addr=57881824
            label_0:
            // 0x00AD4828: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00AD482C: LDR x8, [x8, #0xe08]       | X8 = 1152921504860733440;               
            // 0x00AD4830: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonWriter);
            // 0x00AD4834: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_10A;
            // 0x00AD4838: TBZ w8, #0, #0xad4848      | if (Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AD483C: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00AD4840: CBNZ w8, #0xad4848         | if (Newtonsoft.Json.JsonWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AD4844: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.JsonWriter), ????);
            label_2:
            // 0x00AD4848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD484C: MOV x0, x20                | X0 = 1152921513725898928 (0x100000021F89B0B0);//ML01
            // 0x00AD4850: BL #0x131a1a4              | this..ctor();                           
            // 0x00AD4854: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00AD4858: LDR x8, [x8, #0x248]       | X8 = (string**)(1152921513715922032)("stream");
            // 0x00AD485C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD4860: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD4864: MOV x1, x19                | X1 = stream;//m1                        
            // 0x00AD4868: LDR x2, [x8]               | X2 = "stream";                          
            // 0x00AD486C: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  stream);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  stream);
            // 0x00AD4870: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00AD4874: LDR x8, [x8, #0x380]       | X8 = 1152921504857432064;               
            // 0x00AD4878: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            Newtonsoft.Json.Bson.BsonBinaryWriter val_1 = null;
            // 0x00AD487C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            // 0x00AD4880: MOV x1, x19                | X1 = stream;//m1                        
            // 0x00AD4884: MOV x21, x0                | X21 = 1152921504857432064 (0x100000000EEFA000);//ML01
            // 0x00AD4888: BL #0xacf90c               | .ctor(stream:  stream);                 
            val_1 = new Newtonsoft.Json.Bson.BsonBinaryWriter(stream:  stream);
            // 0x00AD488C: STR x21, [x20, #0x30]      | this._writer = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);  //  dest_result_addr=1152921513725898976
            this._writer = val_1;
            // 0x00AD4890: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4894: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD4898: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD489C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD48A0 (11356320), len: 40  VirtAddr: 0x00AD48A0 RVA: 0x00AD48A0 token: 100684796 methodIndex: 47440 delegateWrapperIndex: 0 methodInvoker: 0
        public System.DateTimeKind get_DateTimeKindHandling()
        {
            //
            // Disasemble & Code
            // 0x00AD48A0: STP x20, x19, [sp, #-0x20]! | stack[1152921513726011184] = ???;  stack[1152921513726011192] = ???;  //  dest_result_addr=1152921513726011184 |  dest_result_addr=1152921513726011192
            // 0x00AD48A4: STP x29, x30, [sp, #0x10]  | stack[1152921513726011200] = ???;  stack[1152921513726011208] = ???;  //  dest_result_addr=1152921513726011200 |  dest_result_addr=1152921513726011208
            // 0x00AD48A8: ADD x29, sp, #0x10         | X29 = (1152921513726011184 + 16) = 1152921513726011200 (0x100000021F8B6740);
            // 0x00AD48AC: LDR x19, [x0, #0x30]       | X19 = this._writer; //P2                
            // 0x00AD48B0: CBNZ x19, #0xad48b8        | if (this._writer != null) goto label_0; 
            if(this._writer != null)
            {
                goto label_0;
            }
            // 0x00AD48B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD48B8: LDR w0, [x19, #0x24]       | W0 = this._writer.<DateTimeKindHandling>k__BackingField; //P2 
            // 0x00AD48BC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD48C0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD48C4: RET                        |  return (System.DateTimeKind)this._writer.<DateTimeKindHandling>k__BackingField;
            return this._writer.<DateTimeKindHandling>k__BackingField;
            //  |  // // {name=val_0, type=System.DateTimeKind, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD48C8 (11356360), len: 44  VirtAddr: 0x00AD48C8 RVA: 0x00AD48C8 token: 100684797 methodIndex: 47441 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_DateTimeKindHandling(System.DateTimeKind value)
        {
            //
            // Disasemble & Code
            // 0x00AD48C8: STP x20, x19, [sp, #-0x20]! | stack[1152921513726139568] = ???;  stack[1152921513726139576] = ???;  //  dest_result_addr=1152921513726139568 |  dest_result_addr=1152921513726139576
            // 0x00AD48CC: STP x29, x30, [sp, #0x10]  | stack[1152921513726139584] = ???;  stack[1152921513726139592] = ???;  //  dest_result_addr=1152921513726139584 |  dest_result_addr=1152921513726139592
            // 0x00AD48D0: ADD x29, sp, #0x10         | X29 = (1152921513726139568 + 16) = 1152921513726139584 (0x100000021F8D5CC0);
            // 0x00AD48D4: LDR x20, [x0, #0x30]       | X20 = this._writer; //P2                
            // 0x00AD48D8: MOV w19, w1                | W19 = value;//m1                        
            // 0x00AD48DC: CBNZ x20, #0xad48e4        | if (this._writer != null) goto label_0; 
            if(this._writer != null)
            {
                goto label_0;
            }
            // 0x00AD48E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD48E4: STR w19, [x20, #0x24]      | this._writer.<DateTimeKindHandling>k__BackingField = value;  //  dest_result_addr=0
            this._writer.<DateTimeKindHandling>k__BackingField = value;
            // 0x00AD48E8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD48EC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD48F0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD48F4 (11356404), len: 60  VirtAddr: 0x00AD48F4 RVA: 0x00AD48F4 token: 100684798 methodIndex: 47442 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Flush()
        {
            //
            // Disasemble & Code
            // 0x00AD48F4: STP x20, x19, [sp, #-0x20]! | stack[1152921513726267952] = ???;  stack[1152921513726267960] = ???;  //  dest_result_addr=1152921513726267952 |  dest_result_addr=1152921513726267960
            // 0x00AD48F8: STP x29, x30, [sp, #0x10]  | stack[1152921513726267968] = ???;  stack[1152921513726267976] = ???;  //  dest_result_addr=1152921513726267968 |  dest_result_addr=1152921513726267976
            // 0x00AD48FC: ADD x29, sp, #0x10         | X29 = (1152921513726267952 + 16) = 1152921513726267968 (0x100000021F8F5240);
            // 0x00AD4900: LDR x19, [x0, #0x30]       | X19 = this._writer; //P2                
            // 0x00AD4904: CBNZ x19, #0xad490c        | if (this._writer != null) goto label_0; 
            if(this._writer != null)
            {
                goto label_0;
            }
            // 0x00AD4908: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD490C: LDR x19, [x19, #0x10]      | X19 = this._writer._writer; //P2        
            // 0x00AD4910: CBNZ x19, #0xad4918        | if (this._writer._writer != null) goto label_1;
            if(this._writer._writer != null)
            {
                goto label_1;
            }
            // 0x00AD4914: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00AD4918: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryWriter);    
            // 0x00AD491C: MOV x0, x19                | X0 = this._writer._writer;//m1          
            // 0x00AD4920: LDP x2, x1, [x8, #0x190]   | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_190; X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_198; //  | 
            // 0x00AD4924: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4928: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD492C: BR x2                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_190;
            goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_190;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4930 (11356464), len: 116  VirtAddr: 0x00AD4930 RVA: 0x00AD4930 token: 100684799 methodIndex: 47443 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void WriteEnd(Newtonsoft.Json.JsonToken token)
        {
            //
            // Disasemble & Code
            // 0x00AD4930: STP x20, x19, [sp, #-0x20]! | stack[1152921513726408624] = ???;  stack[1152921513726408632] = ???;  //  dest_result_addr=1152921513726408624 |  dest_result_addr=1152921513726408632
            // 0x00AD4934: STP x29, x30, [sp, #0x10]  | stack[1152921513726408640] = ???;  stack[1152921513726408648] = ???;  //  dest_result_addr=1152921513726408640 |  dest_result_addr=1152921513726408648
            // 0x00AD4938: ADD x29, sp, #0x10         | X29 = (1152921513726408624 + 16) = 1152921513726408640 (0x100000021F9177C0);
            // 0x00AD493C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD4940: MOV x19, x0                | X19 = 1152921513726420656 (0x100000021F91A6B0);//ML01
            // 0x00AD4944: BL #0x1324268              | this.WriteEnd(token:  token);           
            this.WriteEnd(token:  token);
            // 0x00AD4948: LDR x20, [x19, #0x40]      | X20 = this._parent; //P2                
            // 0x00AD494C: CBNZ x20, #0xad4954        | if (this._parent != null) goto label_0; 
            if(this._parent != null)
            {
                goto label_0;
            }
            // 0x00AD4950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD4954: LDR x8, [x20, #0x10]       | X8 = this._parent.<Parent>k__BackingField; //P2 
            // 0x00AD4958: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD495C: MOV x0, x19                | X0 = 1152921513726420656 (0x100000021F91A6B0);//ML01
            // 0x00AD4960: STR x8, [x19, #0x40]       | this._parent = this._parent.<Parent>k__BackingField;  //  dest_result_addr=1152921513726420720
            this._parent = this._parent.<Parent>k__BackingField;
            // 0x00AD4964: BL #0x131aa04              | X0 = this.get_Top();                    
            int val_1 = this.Top;
            // 0x00AD4968: CBZ w0, #0xad4978          | if (val_1 == 0) goto label_1;           
            if(val_1 == 0)
            {
                goto label_1;
            }
            // 0x00AD496C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4970: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD4974: RET                        |  return;                                
            return;
            label_1:
            // 0x00AD4978: LDP x20, x19, [x19, #0x30] | X20 = this._writer; //P2  X19 = this._root; //P2  //  | 
            // 0x00AD497C: CBNZ x20, #0xad4984        | if (this._writer != null) goto label_2; 
            if(this._writer != null)
            {
                goto label_2;
            }
            // 0x00AD4980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x00AD4984: MOV x0, x20                | X0 = this._writer;//m1                  
            // 0x00AD4988: MOV x1, x19                | X1 = this._root;//m1                    
            // 0x00AD498C: BL #0xacfa2c               | X0 = this._writer.CalculateSize(t:  this._root);
            int val_2 = this._writer.CalculateSize(t:  this._root);
            // 0x00AD4990: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4994: MOV x0, x20                | X0 = this._writer;//m1                  
            // 0x00AD4998: MOV x1, x19                | X1 = this._root;//m1                    
            // 0x00AD499C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD49A0: B #0xad0484                | this._writer.WriteTokenInternal(t:  this._root); return;
            this._writer.WriteTokenInternal(t:  this._root);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD49D4 (11356628), len: 112  VirtAddr: 0x00AD49D4 RVA: 0x00AD49D4 token: 100684800 methodIndex: 47444 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteComment(string text)
        {
            //
            // Disasemble & Code
            // 0x00AD49D4: STP x20, x19, [sp, #-0x20]! | stack[1152921513726546368] = ???;  stack[1152921513726546376] = ???;  //  dest_result_addr=1152921513726546368 |  dest_result_addr=1152921513726546376
            // 0x00AD49D8: STP x29, x30, [sp, #0x10]  | stack[1152921513726546384] = ???;  stack[1152921513726546392] = ???;  //  dest_result_addr=1152921513726546384 |  dest_result_addr=1152921513726546392
            // 0x00AD49DC: ADD x29, sp, #0x10         | X29 = (1152921513726546368 + 16) = 1152921513726546384 (0x100000021F9391D0);
            // 0x00AD49E0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AD49E4: LDRB w8, [x19, #0x4e1]     | W8 = (bool)static_value_037334E1;       
            // 0x00AD49E8: TBNZ w8, #0, #0xad4a04     | if (static_value_037334E1 == true) goto label_0;
            // 0x00AD49EC: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00AD49F0: LDR x8, [x8, #0xb98]       | X8 = 0x2B8F9E4;                         
            // 0x00AD49F4: LDR w0, [x8]               | W0 = 0x153D;                            
            // 0x00AD49F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x153D, ????);     
            // 0x00AD49FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4A00: STRB w8, [x19, #0x4e1]     | static_value_037334E1 = true;            //  dest_result_addr=57881825
            label_0:
            // 0x00AD4A04: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00AD4A08: LDR x8, [x8, #0x468]       | X8 = 1152921504860839936;               
            // 0x00AD4A0C: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonWriterException);
            Newtonsoft.Json.JsonWriterException val_1 = null;
            // 0x00AD4A10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD4A14: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x00AD4A18: LDR x8, [x8, #0xb38]       | X8 = (string**)(1152921513726533232)("Cannot write JSON comment as BSON.");
            // 0x00AD4A1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD4A20: MOV x19, x0                | X19 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD4A24: LDR x1, [x8]               | X1 = "Cannot write JSON comment as BSON.";
            // 0x00AD4A28: BL #0x131a8e4              | .ctor(message:  "Cannot write JSON comment as BSON.");
            val_1 = new Newtonsoft.Json.JsonWriterException(message:  "Cannot write JSON comment as BSON.");
            // 0x00AD4A2C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x00AD4A30: LDR x8, [x8, #0x8a8]       | X8 = 1152921513726533376;               
            // 0x00AD4A34: MOV x0, x19                | X0 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD4A38: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Bson.BsonWriter::WriteComment(string text);
            // 0x00AD4A3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD4A40: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4A44 (11356740), len: 112  VirtAddr: 0x00AD4A44 RVA: 0x00AD4A44 token: 100684801 methodIndex: 47445 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteStartConstructor(string name)
        {
            //
            // Disasemble & Code
            // 0x00AD4A44: STP x20, x19, [sp, #-0x20]! | stack[1152921513726667728] = ???;  stack[1152921513726667736] = ???;  //  dest_result_addr=1152921513726667728 |  dest_result_addr=1152921513726667736
            // 0x00AD4A48: STP x29, x30, [sp, #0x10]  | stack[1152921513726667744] = ???;  stack[1152921513726667752] = ???;  //  dest_result_addr=1152921513726667744 |  dest_result_addr=1152921513726667752
            // 0x00AD4A4C: ADD x29, sp, #0x10         | X29 = (1152921513726667728 + 16) = 1152921513726667744 (0x100000021F956BE0);
            // 0x00AD4A50: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AD4A54: LDRB w8, [x19, #0x4e2]     | W8 = (bool)static_value_037334E2;       
            // 0x00AD4A58: TBNZ w8, #0, #0xad4a74     | if (static_value_037334E2 == true) goto label_0;
            // 0x00AD4A5C: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x00AD4A60: LDR x8, [x8, #0x318]       | X8 = 0x2B8F9FC;                         
            // 0x00AD4A64: LDR w0, [x8]               | W0 = 0x1543;                            
            // 0x00AD4A68: BL #0x2782188              | X0 = sub_2782188( ?? 0x1543, ????);     
            // 0x00AD4A6C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4A70: STRB w8, [x19, #0x4e2]     | static_value_037334E2 = true;            //  dest_result_addr=57881826
            label_0:
            // 0x00AD4A74: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00AD4A78: LDR x8, [x8, #0x468]       | X8 = 1152921504860839936;               
            // 0x00AD4A7C: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonWriterException);
            Newtonsoft.Json.JsonWriterException val_1 = null;
            // 0x00AD4A80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD4A84: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x00AD4A88: LDR x8, [x8, #0xc78]       | X8 = (string**)(1152921513726654592)("Cannot write JSON constructor as BSON.");
            // 0x00AD4A8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD4A90: MOV x19, x0                | X19 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD4A94: LDR x1, [x8]               | X1 = "Cannot write JSON constructor as BSON.";
            // 0x00AD4A98: BL #0x131a8e4              | .ctor(message:  "Cannot write JSON constructor as BSON.");
            val_1 = new Newtonsoft.Json.JsonWriterException(message:  "Cannot write JSON constructor as BSON.");
            // 0x00AD4A9C: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00AD4AA0: LDR x8, [x8, #0xc50]       | X8 = 1152921513726654736;               
            // 0x00AD4AA4: MOV x0, x19                | X0 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD4AA8: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Bson.BsonWriter::WriteStartConstructor(string name);
            // 0x00AD4AAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD4AB0: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4AB4 (11356852), len: 112  VirtAddr: 0x00AD4AB4 RVA: 0x00AD4AB4 token: 100684802 methodIndex: 47446 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteRaw(string json)
        {
            //
            // Disasemble & Code
            // 0x00AD4AB4: STP x20, x19, [sp, #-0x20]! | stack[1152921513726789072] = ???;  stack[1152921513726789080] = ???;  //  dest_result_addr=1152921513726789072 |  dest_result_addr=1152921513726789080
            // 0x00AD4AB8: STP x29, x30, [sp, #0x10]  | stack[1152921513726789088] = ???;  stack[1152921513726789096] = ???;  //  dest_result_addr=1152921513726789088 |  dest_result_addr=1152921513726789096
            // 0x00AD4ABC: ADD x29, sp, #0x10         | X29 = (1152921513726789072 + 16) = 1152921513726789088 (0x100000021F9745E0);
            // 0x00AD4AC0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AD4AC4: LDRB w8, [x19, #0x4e3]     | W8 = (bool)static_value_037334E3;       
            // 0x00AD4AC8: TBNZ w8, #0, #0xad4ae4     | if (static_value_037334E3 == true) goto label_0;
            // 0x00AD4ACC: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x00AD4AD0: LDR x8, [x8, #0x210]       | X8 = 0x2B8F9EC;                         
            // 0x00AD4AD4: LDR w0, [x8]               | W0 = 0x153F;                            
            // 0x00AD4AD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x153F, ????);     
            // 0x00AD4ADC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4AE0: STRB w8, [x19, #0x4e3]     | static_value_037334E3 = true;            //  dest_result_addr=57881827
            label_0:
            // 0x00AD4AE4: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00AD4AE8: LDR x8, [x8, #0x468]       | X8 = 1152921504860839936;               
            // 0x00AD4AEC: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonWriterException);
            Newtonsoft.Json.JsonWriterException val_1 = null;
            // 0x00AD4AF0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD4AF4: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x00AD4AF8: LDR x8, [x8, #0xc58]       | X8 = (string**)(1152921513726775952)("Cannot write raw JSON as BSON.");
            // 0x00AD4AFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD4B00: MOV x19, x0                | X19 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD4B04: LDR x1, [x8]               | X1 = "Cannot write raw JSON as BSON.";  
            // 0x00AD4B08: BL #0x131a8e4              | .ctor(message:  "Cannot write raw JSON as BSON.");
            val_1 = new Newtonsoft.Json.JsonWriterException(message:  "Cannot write raw JSON as BSON.");
            // 0x00AD4B0C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x00AD4B10: LDR x8, [x8, #0x9e0]       | X8 = 1152921513726776080;               
            // 0x00AD4B14: MOV x0, x19                | X0 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD4B18: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Bson.BsonWriter::WriteRaw(string json);
            // 0x00AD4B1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD4B20: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4B24 (11356964), len: 112  VirtAddr: 0x00AD4B24 RVA: 0x00AD4B24 token: 100684803 methodIndex: 47447 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteRawValue(string json)
        {
            //
            // Disasemble & Code
            // 0x00AD4B24: STP x20, x19, [sp, #-0x20]! | stack[1152921513726910288] = ???;  stack[1152921513726910296] = ???;  //  dest_result_addr=1152921513726910288 |  dest_result_addr=1152921513726910296
            // 0x00AD4B28: STP x29, x30, [sp, #0x10]  | stack[1152921513726910304] = ???;  stack[1152921513726910312] = ???;  //  dest_result_addr=1152921513726910304 |  dest_result_addr=1152921513726910312
            // 0x00AD4B2C: ADD x29, sp, #0x10         | X29 = (1152921513726910288 + 16) = 1152921513726910304 (0x100000021F991F60);
            // 0x00AD4B30: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AD4B34: LDRB w8, [x19, #0x4e4]     | W8 = (bool)static_value_037334E4;       
            // 0x00AD4B38: TBNZ w8, #0, #0xad4b54     | if (static_value_037334E4 == true) goto label_0;
            // 0x00AD4B3C: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00AD4B40: LDR x8, [x8, #0x228]       | X8 = 0x2B8F9F0;                         
            // 0x00AD4B44: LDR w0, [x8]               | W0 = 0x1540;                            
            // 0x00AD4B48: BL #0x2782188              | X0 = sub_2782188( ?? 0x1540, ????);     
            // 0x00AD4B4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4B50: STRB w8, [x19, #0x4e4]     | static_value_037334E4 = true;            //  dest_result_addr=57881828
            label_0:
            // 0x00AD4B54: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00AD4B58: LDR x8, [x8, #0x468]       | X8 = 1152921504860839936;               
            // 0x00AD4B5C: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonWriterException);
            Newtonsoft.Json.JsonWriterException val_1 = null;
            // 0x00AD4B60: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD4B64: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x00AD4B68: LDR x8, [x8, #0xc58]       | X8 = (string**)(1152921513726775952)("Cannot write raw JSON as BSON.");
            // 0x00AD4B6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD4B70: MOV x19, x0                | X19 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD4B74: LDR x1, [x8]               | X1 = "Cannot write raw JSON as BSON.";  
            // 0x00AD4B78: BL #0x131a8e4              | .ctor(message:  "Cannot write raw JSON as BSON.");
            val_1 = new Newtonsoft.Json.JsonWriterException(message:  "Cannot write raw JSON as BSON.");
            // 0x00AD4B7C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AD4B80: LDR x8, [x8, #0x718]       | X8 = 1152921513726897296;               
            // 0x00AD4B84: MOV x0, x19                | X0 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD4B88: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Bson.BsonWriter::WriteRawValue(string json);
            // 0x00AD4B8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD4B90: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4B94 (11357076), len: 116  VirtAddr: 0x00AD4B94 RVA: 0x00AD4B94 token: 100684804 methodIndex: 47448 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteStartArray()
        {
            //
            // Disasemble & Code
            // 0x00AD4B94: STP x20, x19, [sp, #-0x20]! | stack[1152921513727026384] = ???;  stack[1152921513727026392] = ???;  //  dest_result_addr=1152921513727026384 |  dest_result_addr=1152921513727026392
            // 0x00AD4B98: STP x29, x30, [sp, #0x10]  | stack[1152921513727026400] = ???;  stack[1152921513727026408] = ???;  //  dest_result_addr=1152921513727026400 |  dest_result_addr=1152921513727026408
            // 0x00AD4B9C: ADD x29, sp, #0x10         | X29 = (1152921513727026384 + 16) = 1152921513727026400 (0x100000021F9AE4E0);
            // 0x00AD4BA0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD4BA4: LDRB w8, [x20, #0x4e5]     | W8 = (bool)static_value_037334E5;       
            // 0x00AD4BA8: MOV x19, x0                | X19 = 1152921513727038416 (0x100000021F9B13D0);//ML01
            // 0x00AD4BAC: TBNZ w8, #0, #0xad4bc8     | if (static_value_037334E5 == true) goto label_0;
            // 0x00AD4BB0: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x00AD4BB4: LDR x8, [x8, #0xf18]       | X8 = 0x2B8F9F8;                         
            // 0x00AD4BB8: LDR w0, [x8]               | W0 = 0x1542;                            
            // 0x00AD4BBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1542, ????);     
            // 0x00AD4BC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4BC4: STRB w8, [x20, #0x4e5]     | static_value_037334E5 = true;            //  dest_result_addr=57881829
            label_0:
            // 0x00AD4BC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4BCC: MOV x0, x19                | X0 = 1152921513727038416 (0x100000021F9B13D0);//ML01
            // 0x00AD4BD0: BL #0x131a640              | this.WriteStartArray();                 
            this.WriteStartArray();
            // 0x00AD4BD4: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x00AD4BD8: LDR x8, [x8, #0x6c8]       | X8 = 1152921504857804800;               
            // 0x00AD4BDC: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonArray);
            Newtonsoft.Json.Bson.BsonArray val_1 = null;
            // 0x00AD4BE0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonArray), ????);
            // 0x00AD4BE4: MOV x20, x0                | X20 = 1152921504857804800 (0x100000000EF55000);//ML01
            // 0x00AD4BE8: BL #0xacf774               | .ctor();                                
            val_1 = new Newtonsoft.Json.Bson.BsonArray();
            // 0x00AD4BEC: MOV x0, x19                | X0 = 1152921513727038416 (0x100000021F9B13D0);//ML01
            // 0x00AD4BF0: MOV x1, x20                | X1 = 1152921504857804800 (0x100000000EF55000);//ML01
            // 0x00AD4BF4: BL #0xad4d30               | this.AddToken(token:  val_1);           
            this.AddToken(token:  val_1);
            // 0x00AD4BF8: STR x20, [x19, #0x40]      | this._parent = typeof(Newtonsoft.Json.Bson.BsonArray);  //  dest_result_addr=1152921513727038480
            this._parent = val_1;
            // 0x00AD4BFC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4C00: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD4C04: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4C30 (11357232), len: 116  VirtAddr: 0x00AD4C30 RVA: 0x00AD4C30 token: 100684805 methodIndex: 47449 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteStartObject()
        {
            //
            // Disasemble & Code
            // 0x00AD4C30: STP x20, x19, [sp, #-0x20]! | stack[1152921513727138384] = ???;  stack[1152921513727138392] = ???;  //  dest_result_addr=1152921513727138384 |  dest_result_addr=1152921513727138392
            // 0x00AD4C34: STP x29, x30, [sp, #0x10]  | stack[1152921513727138400] = ???;  stack[1152921513727138408] = ???;  //  dest_result_addr=1152921513727138400 |  dest_result_addr=1152921513727138408
            // 0x00AD4C38: ADD x29, sp, #0x10         | X29 = (1152921513727138384 + 16) = 1152921513727138400 (0x100000021F9C9A60);
            // 0x00AD4C3C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD4C40: LDRB w8, [x20, #0x4e6]     | W8 = (bool)static_value_037334E6;       
            // 0x00AD4C44: MOV x19, x0                | X19 = 1152921513727150416 (0x100000021F9CC950);//ML01
            // 0x00AD4C48: TBNZ w8, #0, #0xad4c64     | if (static_value_037334E6 == true) goto label_0;
            // 0x00AD4C4C: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x00AD4C50: LDR x8, [x8, #0x380]       | X8 = 0x2B8FA00;                         
            // 0x00AD4C54: LDR w0, [x8]               | W0 = 0x1544;                            
            // 0x00AD4C58: BL #0x2782188              | X0 = sub_2782188( ?? 0x1544, ????);     
            // 0x00AD4C5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4C60: STRB w8, [x20, #0x4e6]     | static_value_037334E6 = true;            //  dest_result_addr=57881830
            label_0:
            // 0x00AD4C64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4C68: MOV x0, x19                | X0 = 1152921513727150416 (0x100000021F9CC950);//ML01
            // 0x00AD4C6C: BL #0x131a594              | this.WriteStartObject();                
            this.WriteStartObject();
            // 0x00AD4C70: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00AD4C74: LDR x8, [x8, #0xcd8]       | X8 = 1152921504857751552;               
            // 0x00AD4C78: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonObject);
            Newtonsoft.Json.Bson.BsonObject val_1 = null;
            // 0x00AD4C7C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonObject), ????);
            // 0x00AD4C80: MOV x20, x0                | X20 = 1152921504857751552 (0x100000000EF48000);//ML01
            // 0x00AD4C84: BL #0xad1bdc               | .ctor();                                
            val_1 = new Newtonsoft.Json.Bson.BsonObject();
            // 0x00AD4C88: MOV x0, x19                | X0 = 1152921513727150416 (0x100000021F9CC950);//ML01
            // 0x00AD4C8C: MOV x1, x20                | X1 = 1152921504857751552 (0x100000000EF48000);//ML01
            // 0x00AD4C90: BL #0xad4d30               | this.AddToken(token:  val_1);           
            this.AddToken(token:  val_1);
            // 0x00AD4C94: STR x20, [x19, #0x40]      | this._parent = typeof(Newtonsoft.Json.Bson.BsonObject);  //  dest_result_addr=1152921513727150480
            this._parent = val_1;
            // 0x00AD4C98: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4C9C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD4CA0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4CA4 (11357348), len: 44  VirtAddr: 0x00AD4CA4 RVA: 0x00AD4CA4 token: 100684806 methodIndex: 47450 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WritePropertyName(string name)
        {
            //
            // Disasemble & Code
            // 0x00AD4CA4: STP x20, x19, [sp, #-0x20]! | stack[1152921513727254480] = ???;  stack[1152921513727254488] = ???;  //  dest_result_addr=1152921513727254480 |  dest_result_addr=1152921513727254488
            // 0x00AD4CA8: STP x29, x30, [sp, #0x10]  | stack[1152921513727254496] = ???;  stack[1152921513727254504] = ???;  //  dest_result_addr=1152921513727254496 |  dest_result_addr=1152921513727254504
            // 0x00AD4CAC: ADD x29, sp, #0x10         | X29 = (1152921513727254480 + 16) = 1152921513727254496 (0x100000021F9E5FE0);
            // 0x00AD4CB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD4CB4: MOV x19, x1                | X19 = name;//m1                         
            // 0x00AD4CB8: MOV x20, x0                | X20 = 1152921513727266512 (0x100000021F9E8ED0);//ML01
            // 0x00AD4CBC: BL #0x131a950              | this.WritePropertyName(name:  name);    
            this.WritePropertyName(name:  name);
            // 0x00AD4CC0: STR x19, [x20, #0x48]      | this._propertyName = name;               //  dest_result_addr=1152921513727266584
            this._propertyName = name;
            // 0x00AD4CC4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4CC8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD4CCC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4CD0 (11357392), len: 96  VirtAddr: 0x00AD4CD0 RVA: 0x00AD4CD0 token: 100684807 methodIndex: 47451 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Close()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x00AD4CD0: STP x20, x19, [sp, #-0x20]! | stack[1152921513727378768] = ???;  stack[1152921513727378776] = ???;  //  dest_result_addr=1152921513727378768 |  dest_result_addr=1152921513727378776
            // 0x00AD4CD4: STP x29, x30, [sp, #0x10]  | stack[1152921513727378784] = ???;  stack[1152921513727378792] = ???;  //  dest_result_addr=1152921513727378784 |  dest_result_addr=1152921513727378792
            // 0x00AD4CD8: ADD x29, sp, #0x10         | X29 = (1152921513727378768 + 16) = 1152921513727378784 (0x100000021FA04560);
            // 0x00AD4CDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4CE0: MOV x19, x0                | X19 = 1152921513727390800 (0x100000021FA07450);//ML01
            val_6 = this;
            // 0x00AD4CE4: BL #0x131a4c8              | this.Close();                           
            this.Close();
            // 0x00AD4CE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4CEC: MOV x0, x19                | X0 = 1152921513727390800 (0x100000021FA07450);//ML01
            // 0x00AD4CF0: BL #0x131a50c              | X0 = this.get_CloseOutput();            
            bool val_1 = this.CloseOutput;
            // 0x00AD4CF4: TBZ w0, #0, #0xad4d24      | if (val_1 == false) goto label_1;       
            if(val_1 == false)
            {
                goto label_1;
            }
            // 0x00AD4CF8: LDR x8, [x19, #0x30]       | X8 = this._writer; //P2                 
            // 0x00AD4CFC: CBZ x8, #0xad4d24          | if (this._writer == null) goto label_1; 
            if(this._writer == null)
            {
                goto label_1;
            }
            // 0x00AD4D00: LDR x19, [x8, #0x10]       | X19 = this._writer._writer; //P2        
            // 0x00AD4D04: CBNZ x19, #0xad4d0c        | if (this._writer._writer != null) goto label_2;
            if(this._writer._writer != null)
            {
                goto label_2;
            }
            // 0x00AD4D08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x00AD4D0C: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryWriter);    
            // 0x00AD4D10: MOV x0, x19                | X0 = this._writer._writer;//m1          
            // 0x00AD4D14: LDP x2, x1, [x8, #0x170]   | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_170; X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_178; //  | 
            // 0x00AD4D18: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4D1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            val_6 = ???;
            // 0x00AD4D20: BR x2                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_170;
            goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_170;
            label_1:
            // 0x00AD4D24: LDP x29, x30, [sp, #0x10]  | X29 = val_2; X30 = val_3;                //  find_add[1152921513727366800] |  find_add[1152921513727366800]
            // 0x00AD4D28: LDP x20, x19, [sp], #0x20  | X20 = val_4; X19 = val_5;                //  find_add[1152921513727366800] |  find_add[1152921513727366800]
            // 0x00AD4D2C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4C08 (11357192), len: 40  VirtAddr: 0x00AD4C08 RVA: 0x00AD4C08 token: 100684808 methodIndex: 47452 delegateWrapperIndex: 0 methodInvoker: 0
        private void AddParent(Newtonsoft.Json.Bson.BsonToken container)
        {
            //
            // Disasemble & Code
            // 0x00AD4C08: STP x20, x19, [sp, #-0x20]! | stack[1152921513727503056] = ???;  stack[1152921513727503064] = ???;  //  dest_result_addr=1152921513727503056 |  dest_result_addr=1152921513727503064
            // 0x00AD4C0C: STP x29, x30, [sp, #0x10]  | stack[1152921513727503072] = ???;  stack[1152921513727503080] = ???;  //  dest_result_addr=1152921513727503072 |  dest_result_addr=1152921513727503080
            // 0x00AD4C10: ADD x29, sp, #0x10         | X29 = (1152921513727503056 + 16) = 1152921513727503072 (0x100000021FA22AE0);
            // 0x00AD4C14: MOV x19, x1                | X19 = container;//m1                    
            // 0x00AD4C18: MOV x20, x0                | X20 = 1152921513727515088 (0x100000021FA259D0);//ML01
            // 0x00AD4C1C: BL #0xad4d30               | this.AddToken(token:  container);       
            this.AddToken(token:  container);
            // 0x00AD4C20: STR x19, [x20, #0x40]      | this._parent = container;                //  dest_result_addr=1152921513727515152
            this._parent = container;
            // 0x00AD4C24: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4C28: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD4C2C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD49A4 (11356580), len: 48  VirtAddr: 0x00AD49A4 RVA: 0x00AD49A4 token: 100684809 methodIndex: 47453 delegateWrapperIndex: 0 methodInvoker: 0
        private void RemoveParent()
        {
            //
            // Disasemble & Code
            // 0x00AD49A4: STP x20, x19, [sp, #-0x20]! | stack[1152921513727627344] = ???;  stack[1152921513727627352] = ???;  //  dest_result_addr=1152921513727627344 |  dest_result_addr=1152921513727627352
            // 0x00AD49A8: STP x29, x30, [sp, #0x10]  | stack[1152921513727627360] = ???;  stack[1152921513727627368] = ???;  //  dest_result_addr=1152921513727627360 |  dest_result_addr=1152921513727627368
            // 0x00AD49AC: ADD x29, sp, #0x10         | X29 = (1152921513727627344 + 16) = 1152921513727627360 (0x100000021FA41060);
            // 0x00AD49B0: MOV x19, x0                | X19 = 1152921513727639376 (0x100000021FA43F50);//ML01
            // 0x00AD49B4: LDR x20, [x19, #0x40]      | X20 = this._parent; //P2                
            // 0x00AD49B8: CBNZ x20, #0xad49c0        | if (this._parent != null) goto label_0; 
            if(this._parent != null)
            {
                goto label_0;
            }
            // 0x00AD49BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD49C0: LDR x8, [x20, #0x10]       | X8 = this._parent.<Parent>k__BackingField; //P2 
            // 0x00AD49C4: STR x8, [x19, #0x40]       | this._parent = this._parent.<Parent>k__BackingField;  //  dest_result_addr=1152921513727639440
            this._parent = this._parent.<Parent>k__BackingField;
            // 0x00AD49C8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD49CC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD49D0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5084 (11358340), len: 124  VirtAddr: 0x00AD5084 RVA: 0x00AD5084 token: 100684810 methodIndex: 47454 delegateWrapperIndex: 0 methodInvoker: 0
        private void AddValue(object value, Newtonsoft.Json.Bson.BsonType type)
        {
            //
            // Disasemble & Code
            // 0x00AD5084: STP x22, x21, [sp, #-0x30]! | stack[1152921513727755712] = ???;  stack[1152921513727755720] = ???;  //  dest_result_addr=1152921513727755712 |  dest_result_addr=1152921513727755720
            // 0x00AD5088: STP x20, x19, [sp, #0x10]  | stack[1152921513727755728] = ???;  stack[1152921513727755736] = ???;  //  dest_result_addr=1152921513727755728 |  dest_result_addr=1152921513727755736
            // 0x00AD508C: STP x29, x30, [sp, #0x20]  | stack[1152921513727755744] = ???;  stack[1152921513727755752] = ???;  //  dest_result_addr=1152921513727755744 |  dest_result_addr=1152921513727755752
            // 0x00AD5090: ADD x29, sp, #0x20         | X29 = (1152921513727755712 + 32) = 1152921513727755744 (0x100000021FA605E0);
            // 0x00AD5094: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00AD5098: LDRB w8, [x22, #0x4e7]     | W8 = (bool)static_value_037334E7;       
            // 0x00AD509C: MOV w19, w2                | W19 = type;//m1                         
            // 0x00AD50A0: MOV x20, x1                | X20 = value;//m1                        
            // 0x00AD50A4: MOV x21, x0                | X21 = 1152921513727767760 (0x100000021FA634D0);//ML01
            // 0x00AD50A8: TBNZ w8, #0, #0xad50c4     | if (static_value_037334E7 == true) goto label_0;
            // 0x00AD50AC: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00AD50B0: LDR x8, [x8, #0xb38]       | X8 = 0x2B8F9E0;                         
            // 0x00AD50B4: LDR w0, [x8]               | W0 = 0x153C;                            
            // 0x00AD50B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x153C, ????);     
            // 0x00AD50BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD50C0: STRB w8, [x22, #0x4e7]     | static_value_037334E7 = true;            //  dest_result_addr=57881831
            label_0:
            // 0x00AD50C4: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00AD50C8: LDR x8, [x8, #0x818]       | X8 = 1152921504857858048;               
            // 0x00AD50CC: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonValue);
            object val_1 = null;
            // 0x00AD50D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonValue), ????);
            // 0x00AD50D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD50D8: MOV x22, x0                | X22 = 1152921504857858048 (0x100000000EF62000);//ML01
            // 0x00AD50DC: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AD50E0: STRB w19, [x22, #0x28]     | typeof(Newtonsoft.Json.Bson.BsonValue).__il2cppRuntimeField_28 = type;  //  dest_result_addr=1152921504857858088
            typeof(Newtonsoft.Json.Bson.BsonValue).__il2cppRuntimeField_28 = type;
            // 0x00AD50E4: STR x20, [x22, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonValue).__il2cppRuntimeField_20 = value;  //  dest_result_addr=1152921504857858080
            typeof(Newtonsoft.Json.Bson.BsonValue).__il2cppRuntimeField_20 = value;
            // 0x00AD50E8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD50EC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD50F0: MOV x0, x21                | X0 = 1152921513727767760 (0x100000021FA634D0);//ML01
            // 0x00AD50F4: MOV x1, x22                | X1 = 1152921504857858048 (0x100000000EF62000);//ML01
            // 0x00AD50F8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD50FC: B #0xad4d30                | this.AddToken(token:  val_1); return;   
            this.AddToken(token:  val_1);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4D30 (11357488), len: 852  VirtAddr: 0x00AD4D30 RVA: 0x00AD4D30 token: 100684811 methodIndex: 47455 delegateWrapperIndex: 0 methodInvoker: 0
        internal void AddToken(Newtonsoft.Json.Bson.BsonToken token)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_8;
            //  | 
            Newtonsoft.Json.Bson.BsonToken val_12;
            //  | 
            Newtonsoft.Json.Bson.BsonToken val_13;
            //  | 
            var val_14;
            // 0x00AD4D30: STP x22, x21, [sp, #-0x30]! | stack[1152921513727901712] = ???;  stack[1152921513727901720] = ???;  //  dest_result_addr=1152921513727901712 |  dest_result_addr=1152921513727901720
            // 0x00AD4D34: STP x20, x19, [sp, #0x10]  | stack[1152921513727901728] = ???;  stack[1152921513727901736] = ???;  //  dest_result_addr=1152921513727901728 |  dest_result_addr=1152921513727901736
            // 0x00AD4D38: STP x29, x30, [sp, #0x20]  | stack[1152921513727901744] = ???;  stack[1152921513727901752] = ???;  //  dest_result_addr=1152921513727901744 |  dest_result_addr=1152921513727901752
            // 0x00AD4D3C: ADD x29, sp, #0x20         | X29 = (1152921513727901712 + 32) = 1152921513727901744 (0x100000021FA84030);
            // 0x00AD4D40: SUB sp, sp, #0x20          | SP = (1152921513727901712 - 32) = 1152921513727901680 (0x100000021FA83FF0);
            // 0x00AD4D44: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD4D48: LDRB w8, [x21, #0x4e8]     | W8 = (bool)static_value_037334E8;       
            // 0x00AD4D4C: MOV x19, x1                | X19 = token;//m1                        
            val_12 = token;
            // 0x00AD4D50: MOV x20, x0                | X20 = 1152921513727913760 (0x100000021FA86F20);//ML01
            // 0x00AD4D54: TBNZ w8, #0, #0xad4d70     | if (static_value_037334E8 == true) goto label_0;
            // 0x00AD4D58: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x00AD4D5C: LDR x8, [x8, #0x758]       | X8 = 0x2B8F9DC;                         
            // 0x00AD4D60: LDR w0, [x8]               | W0 = 0x153B;                            
            // 0x00AD4D64: BL #0x2782188              | X0 = sub_2782188( ?? 0x153B, ????);     
            // 0x00AD4D68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4D6C: STRB w8, [x21, #0x4e8]     | static_value_037334E8 = true;            //  dest_result_addr=57881832
            label_0:
            // 0x00AD4D70: LDR x21, [x20, #0x40]      | X21 = this._parent; //P2                
            val_13 = this._parent;
            // 0x00AD4D74: CBZ x21, #0xad4e64         | if (this._parent == null) goto label_1; 
            if(val_13 == null)
            {
                goto label_1;
            }
            // 0x00AD4D78: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00AD4D7C: LDR x9, [x9, #0xcd8]       | X9 = 1152921504857751552;               
            // 0x00AD4D80: LDR x8, [x21]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD4D84: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonObject);
            // 0x00AD4D88: LDRB w9, [x8, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD4D8C: LDRB w10, [x1, #0x104]     | W10 = Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD4D90: CMP w9, w10                | STATE = COMPARE(Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD4D94: B.LO #0xad4dac             | if (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00AD4D98: LDR x11, [x8, #0xb0]       | X11 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy;
            // 0x00AD4D9C: ADD x10, x11, x10, lsl #3  | X10 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.Bso
            // 0x00AD4DA0: LDUR x10, [x10, #-8]       | X10 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD4DA4: CMP x10, x1                | STATE = COMPARE((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonObject))
            // 0x00AD4DA8: B.EQ #0xad4eac             | if ((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00AD4DAC: ADRP x20, #0x366a000       | X20 = 57057280 (0x366A000);             
            // 0x00AD4DB0: LDR x20, [x20, #0x6c8]     | X20 = 1152921504857804800;              
            // 0x00AD4DB4: LDR x1, [x20]              | X1 = typeof(Newtonsoft.Json.Bson.BsonArray);
            // 0x00AD4DB8: LDRB w10, [x1, #0x104]     | W10 = Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD4DBC: CMP w9, w10                | STATE = COMPARE(Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD4DC0: B.LO #0xad4dd8             | if (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00AD4DC4: LDR x9, [x8, #0xb0]        | X9 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy;
            // 0x00AD4DC8: ADD x9, x9, x10, lsl #3    | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.Bson
            // 0x00AD4DCC: LDUR x9, [x9, #-8]         | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD4DD0: CMP x9, x1                 | STATE = COMPARE((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonArray))
            // 0x00AD4DD4: B.EQ #0xad4f28             | if ((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00AD4DD8: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_element_class;
            // 0x00AD4DDC: ADD x8, sp, #0x10          | X8 = (1152921513727901680 + 16) = 1152921513727901696 (0x100000021FA84000);
            // 0x00AD4DE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_element_class, ????);
            // 0x00AD4DE4: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921513727889760]
            // 0x00AD4DE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00AD4DEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4DF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00AD4DF4: ADD x0, sp, #0x10          | X0 = (1152921513727901680 + 16) = 1152921513727901696 (0x100000021FA84000);
            // 0x00AD4DF8: BL #0x299a140              | 
            label_16:
            // 0x00AD4DFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021FA84000, ????);
            label_15:
            // 0x00AD4E00: LDR x8, [x21]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD4E04: LDR x1, [x20]              | X1 = typeof(Newtonsoft.Json.Bson.BsonArray);
            // 0x00AD4E08: LDRB w10, [x8, #0x104]     | W10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD4E0C: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD4E10: CMP w10, w9                | STATE = COMPARE(Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD4E14: B.LO #0xad4e2c             | if (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) goto label_6;
            // 0x00AD4E18: LDR x10, [x8, #0xb0]       | X10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy;
            // 0x00AD4E1C: ADD x9, x10, x9, lsl #3    | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.Bson
            // 0x00AD4E20: LDUR x9, [x9, #-8]         | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD4E24: CMP x9, x1                 | STATE = COMPARE((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonArray))
            // 0x00AD4E28: B.EQ #0xad4e54             | if ((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_7;
            label_6:
            // 0x00AD4E2C: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_element_class;
            // 0x00AD4E30: ADD x8, sp, #0x18          | X8 = (1152921513727901680 + 24) = 1152921513727901704 (0x100000021FA84008);
            // 0x00AD4E34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_element_class, ????);
            // 0x00AD4E38: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921513727889760]
            // 0x00AD4E3C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00AD4E40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4E44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00AD4E48: ADD x0, sp, #0x18          | X0 = (1152921513727901680 + 24) = 1152921513727901704 (0x100000021FA84008);
            // 0x00AD4E4C: BL #0x299a140              | 
            // 0x00AD4E50: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_7:
            // 0x00AD4E54: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00AD4E58: MOV x1, x19                | X1 = token;//m1                         
            // 0x00AD4E5C: BL #0xacf7ec               | val_13.Add(token:  val_12);             
            val_13.Add(token:  val_12);
            // 0x00AD4E60: B #0xad4f14                |  goto label_12;                         
            goto label_12;
            label_1:
            // 0x00AD4E64: CBNZ x19, #0xad4e6c        | if (token != null) goto label_9;        
            if(val_12 != null)
            {
                goto label_9;
            }
            // 0x00AD4E68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x153B, ????);     
            label_9:
            // 0x00AD4E6C: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD4E70: MOV x0, x19                | X0 = token;//m1                         
            // 0x00AD4E74: LDP x9, x1, [x8, #0x150]   | X9 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150; X1 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_158; //  | 
            // 0x00AD4E78: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150();
            // 0x00AD4E7C: AND w8, w0, #0xff          | W8 = (token & 255);                     
            Newtonsoft.Json.Bson.BsonToken val_5 = val_12 & 255;
            // 0x00AD4E80: CMP w8, #3                 | STATE = COMPARE((token & 255), 0x3)     
            // 0x00AD4E84: B.EQ #0xad4ea4             | if (val_5 == 0x3) goto label_10;        
            if(val_5 == 3)
            {
                goto label_10;
            }
            // 0x00AD4E88: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD4E8C: MOV x0, x19                | X0 = token;//m1                         
            // 0x00AD4E90: LDP x9, x1, [x8, #0x150]   | X9 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150; X1 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_158; //  | 
            // 0x00AD4E94: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150();
            // 0x00AD4E98: AND w8, w0, #0xff          | W8 = (token & 255);                     
            Newtonsoft.Json.Bson.BsonToken val_6 = val_12 & 255;
            // 0x00AD4E9C: CMP w8, #4                 | STATE = COMPARE((token & 255), 0x4)     
            // 0x00AD4EA0: B.NE #0xad4f5c             | if (val_6 != 0x4) goto label_11;        
            if(val_6 != 4)
            {
                goto label_11;
            }
            label_10:
            // 0x00AD4EA4: STP x19, x19, [x20, #0x38] | this._root = token;  this._parent = token;  //  dest_result_addr=1152921513727913816 |  dest_result_addr=1152921513727913824
            this._root = val_12;
            this._parent = val_12;
            // 0x00AD4EA8: B #0xad4f14                |  goto label_12;                         
            goto label_12;
            label_3:
            // 0x00AD4EAC: LDR x8, [x21]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD4EB0: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD4EB4: LDR x22, [x20, #0x48]      | X22 = this._propertyName; //P2          
            // 0x00AD4EB8: LDRB w10, [x8, #0x104]     | W10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD4EBC: CMP w10, w9                | STATE = COMPARE(Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD4EC0: B.LO #0xad4ed8             | if (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00AD4EC4: LDR x10, [x8, #0xb0]       | X10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy;
            // 0x00AD4EC8: ADD x9, x10, x9, lsl #3    | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.Bson
            // 0x00AD4ECC: LDUR x9, [x9, #-8]         | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD4ED0: CMP x9, x1                 | STATE = COMPARE((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonObject))
            // 0x00AD4ED4: B.EQ #0xad4f00             | if ((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x00AD4ED8: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_element_class;
            // 0x00AD4EDC: ADD x8, sp, #8             | X8 = (1152921513727901680 + 8) = 1152921513727901688 (0x100000021FA83FF8);
            // 0x00AD4EE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_element_class, ????);
            // 0x00AD4EE4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921513727889760]
            // 0x00AD4EE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00AD4EEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4EF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00AD4EF4: ADD x0, sp, #8             | X0 = (1152921513727901680 + 8) = 1152921513727901688 (0x100000021FA83FF8);
            // 0x00AD4EF8: BL #0x299a140              | 
            // 0x00AD4EFC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_14:
            // 0x00AD4F00: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00AD4F04: MOV x1, x22                | X1 = this._propertyName;//m1            
            // 0x00AD4F08: MOV x2, x19                | X2 = token;//m1                         
            // 0x00AD4F0C: BL #0xad1c4c               | val_13.Add(name:  this._propertyName, token:  val_12);
            val_13.Add(name:  this._propertyName, token:  val_12);
            // 0x00AD4F10: STR xzr, [x20, #0x48]      | this._propertyName = null;               //  dest_result_addr=1152921513727913832
            this._propertyName = 0;
            label_12:
            // 0x00AD4F14: SUB sp, x29, #0x20         | SP = (1152921513727901744 - 32) = 1152921513727901712 (0x100000021FA84010);
            // 0x00AD4F18: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD4F1C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD4F20: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD4F24: RET                        |  return;                                
            return;
            label_5:
            // 0x00AD4F28: CBNZ x21, #0xad4e00        | if (this._parent != null) goto label_15;
            if(val_13 != null)
            {
                goto label_15;
            }
            // 0x00AD4F2C: B #0xad4dfc                |  goto label_16;                         
            goto label_16;
            // 0x00AD4F30: MOV x19, x0                | X19 = 5435 (0x153B);//ML01              
            val_12 = 5435;
            // 0x00AD4F34: ADD x0, sp, #0x10          | X0 = (1152921513727901680 + 16) = 1152921513727901696 (0x100000021FA84000);
            // 0x00AD4F38: B #0xad4f50                |  goto label_18;                         
            goto label_18;
            // 0x00AD4F3C: MOV x19, x0                | X19 = 1152921513727901696 (0x100000021FA84000);//ML01
            val_12;
            // 0x00AD4F40: ADD x0, sp, #0x18          | X0 = (1152921513727901680 + 24) = 1152921513727901704 (0x100000021FA84008);
            // 0x00AD4F44: B #0xad4f50                |  goto label_18;                         
            goto label_18;
            // 0x00AD4F48: MOV x19, x0                | X19 = 1152921513727901704 (0x100000021FA84008);//ML01
            val_12;
            // 0x00AD4F4C: ADD x0, sp, #8             | X0 = (1152921513727901680 + 8) = 1152921513727901688 (0x100000021FA83FF8);
            label_18:
            // 0x00AD4F50: BL #0x299a140              | 
            // 0x00AD4F54: MOV x0, x19                | X0 = 1152921513727901704 (0x100000021FA84008);//ML01
            // 0x00AD4F58: BL #0x980800               | X0 = sub_980800( ?? 0x100000021FA84008, ????);
            label_11:
            // 0x00AD4F5C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD4F60: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD4F64: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD4F68: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD4F6C: TBZ w8, #0, #0xad4f7c      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00AD4F70: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD4F74: CBNZ w8, #0xad4f7c         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00AD4F78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_20:
            // 0x00AD4F7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD4F80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4F84: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_9 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD4F88: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AD4F8C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AD4F90: MOV x20, x0                | X20 = val_9;//m1                        
            // 0x00AD4F94: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00AD4F98: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD4F9C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AD4FA0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD4FA4: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD4FA8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AD4FAC: LDR x8, [x19]              | X8 = val_4;                              //  find_add[1152921513727889760]
            // 0x00AD4FB0: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD4FB4: MOV x0, x19                | X0 = 1152921513727901704 (0x100000021FA84008);//ML01
            // 0x00AD4FB8: LDP x9, x1, [x8, #0x150]   | X9 = val_4 + 336; X1 = val_4 + 336 + 8;  //  | 
            // 0x00AD4FBC: BLR x9                     | X0 = val_4 + 336();                     
            // 0x00AD4FC0: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00AD4FC4: LDR x8, [x8, #0xc00]       | X8 = 1152921504858071040;               
            // 0x00AD4FC8: STRB w0, [sp, #7]          | stack[1152921513727901687] = 0x100000021FA84008;  //  dest_result_addr=1152921513727901687
            // 0x00AD4FCC: ADD x1, sp, #7             | X1 = (1152921513727901680 + 7) = 1152921513727901687 (0x100000021FA83FF7);
            // 0x00AD4FD0: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonType);
            // 0x00AD4FD4: MOV x0, x8                 | X0 = 1152921504858071040 (0x100000000EF96000);//ML01
            // 0x00AD4FD8: BL #0x27bc028              | X0 = 1152921513727962144 = (Il2CppObject*)Box((RuntimeClass*)typeof(Newtonsoft.Json.Bson.BsonType), 0x100000021FA84008);
            // 0x00AD4FDC: MOV x19, x0                | X19 = 1152921513727962144 (0x100000021FA92C20);//ML01
            // 0x00AD4FE0: CBNZ x21, #0xad4fe8        | if ( != null) goto label_21;            
            if(null != null)
            {
                goto label_21;
            }
            // 0x00AD4FE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021FA84008, ????);
            label_21:
            // 0x00AD4FE8: CBZ x19, #0xad500c         | if (0x100000021FA84008 == 0) goto label_23;
            if(val_12 == 0)
            {
                goto label_23;
            }
            // 0x00AD4FEC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AD4FF0: MOV x0, x19                | X0 = 1152921513727962144 (0x100000021FA92C20);//ML01
            // 0x00AD4FF4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AD4FF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x100000021FA84008, ????);
            // 0x00AD4FFC: CBNZ x0, #0xad500c         | if (0x100000021FA84008 != 0) goto label_23;
            if(val_12 != 0)
            {
                goto label_23;
            }
            // 0x00AD5000: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x100000021FA84008, ????);
            // 0x00AD5004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5008: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x100000021FA84008, ????);
            label_23:
            // 0x00AD500C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AD5010: CBNZ w8, #0xad5020         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_24;
            // 0x00AD5014: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x100000021FA84008, ????);
            // 0x00AD5018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD501C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x100000021FA84008, ????);
            label_24:
            // 0x00AD5020: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 0x100000021FA84008;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_12;
            // 0x00AD5024: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x00AD5028: LDR x8, [x8, #0xc20]       | X8 = (string**)(1152921513727884432)("Error writing {0} value. BSON must start with an Object or Array.");
            // 0x00AD502C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD5030: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD5034: MOV x2, x20                | X2 = val_9;//m1                         
            // 0x00AD5038: LDR x1, [x8]               | X1 = "Error writing {0} value. BSON must start with an Object or Array.";
            // 0x00AD503C: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD5040: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Error writing {0} value. BSON must start with an Object or Array.", args:  val_9);
            string val_10 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Error writing {0} value. BSON must start with an Object or Array.", args:  val_9);
            // 0x00AD5044: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00AD5048: LDR x8, [x8, #0x468]       | X8 = 1152921504860839936;               
            // 0x00AD504C: MOV x19, x0                | X19 = val_10;//m1                       
            // 0x00AD5050: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonWriterException);
            // 0x00AD5054: MOV x0, x8                 | X0 = 1152921504860839936 (0x100000000F23A000);//ML01
            Newtonsoft.Json.JsonWriterException val_11 = null;
            // 0x00AD5058: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD505C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5060: MOV x1, x19                | X1 = val_10;//m1                        
            // 0x00AD5064: MOV x20, x0                | X20 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD5068: BL #0x131a8e4              | .ctor(message:  val_10);                
            val_11 = new Newtonsoft.Json.JsonWriterException(message:  val_10);
            // 0x00AD506C: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00AD5070: LDR x8, [x8, #0x798]       | X8 = 1152921513727888736;               
            // 0x00AD5074: MOV x0, x20                | X0 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD5078: LDR x1, [x8]               | X1 = System.Void Newtonsoft.Json.Bson.BsonWriter::AddToken(Newtonsoft.Json.Bson.BsonToken token);
            // 0x00AD507C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD5080: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5100 (11358464), len: 48  VirtAddr: 0x00AD5100 RVA: 0x00AD5100 token: 100684812 methodIndex: 47456 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteNull()
        {
            //
            // Disasemble & Code
            // 0x00AD5100: STP x20, x19, [sp, #-0x20]! | stack[1152921513728038304] = ???;  stack[1152921513728038312] = ???;  //  dest_result_addr=1152921513728038304 |  dest_result_addr=1152921513728038312
            // 0x00AD5104: STP x29, x30, [sp, #0x10]  | stack[1152921513728038320] = ???;  stack[1152921513728038328] = ???;  //  dest_result_addr=1152921513728038320 |  dest_result_addr=1152921513728038328
            // 0x00AD5108: ADD x29, sp, #0x10         | X29 = (1152921513728038304 + 16) = 1152921513728038320 (0x100000021FAA55B0);
            // 0x00AD510C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5110: MOV x19, x0                | X19 = 1152921513728050336 (0x100000021FAA84A0);//ML01
            // 0x00AD5114: BL #0x131ab48              | this.WriteNull();                       
            this.WriteNull();
            // 0x00AD5118: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD511C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5120: MOVZ w2, #0xa              | W2 = 10 (0xA);//ML01                    
            // 0x00AD5124: MOV x0, x19                | X0 = 1152921513728050336 (0x100000021FAA84A0);//ML01
            // 0x00AD5128: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD512C: B #0xad5084                | this.AddValue(value:  0, type:  10); return;
            this.AddValue(value:  0, type:  10);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5130 (11358512), len: 48  VirtAddr: 0x00AD5130 RVA: 0x00AD5130 token: 100684813 methodIndex: 47457 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteUndefined()
        {
            //
            // Disasemble & Code
            // 0x00AD5130: STP x20, x19, [sp, #-0x20]! | stack[1152921513728150304] = ???;  stack[1152921513728150312] = ???;  //  dest_result_addr=1152921513728150304 |  dest_result_addr=1152921513728150312
            // 0x00AD5134: STP x29, x30, [sp, #0x10]  | stack[1152921513728150320] = ???;  stack[1152921513728150328] = ???;  //  dest_result_addr=1152921513728150320 |  dest_result_addr=1152921513728150328
            // 0x00AD5138: ADD x29, sp, #0x10         | X29 = (1152921513728150304 + 16) = 1152921513728150320 (0x100000021FAC0B30);
            // 0x00AD513C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5140: MOV x19, x0                | X19 = 1152921513728162336 (0x100000021FAC3A20);//ML01
            // 0x00AD5144: BL #0x131abe8              | this.WriteUndefined();                  
            this.WriteUndefined();
            // 0x00AD5148: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD514C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5150: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x00AD5154: MOV x0, x19                | X0 = 1152921513728162336 (0x100000021FAC3A20);//ML01
            // 0x00AD5158: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD515C: B #0xad5084                | this.AddValue(value:  0, type:  6); return;
            this.AddValue(value:  0, type:  6);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5160 (11358560), len: 180  VirtAddr: 0x00AD5160 RVA: 0x00AD5160 token: 100684814 methodIndex: 47458 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(string value)
        {
            //
            // Disasemble & Code
            // 0x00AD5160: STP x22, x21, [sp, #-0x30]! | stack[1152921513728266384] = ???;  stack[1152921513728266392] = ???;  //  dest_result_addr=1152921513728266384 |  dest_result_addr=1152921513728266392
            // 0x00AD5164: STP x20, x19, [sp, #0x10]  | stack[1152921513728266400] = ???;  stack[1152921513728266408] = ???;  //  dest_result_addr=1152921513728266400 |  dest_result_addr=1152921513728266408
            // 0x00AD5168: STP x29, x30, [sp, #0x20]  | stack[1152921513728266416] = ???;  stack[1152921513728266424] = ???;  //  dest_result_addr=1152921513728266416 |  dest_result_addr=1152921513728266424
            // 0x00AD516C: ADD x29, sp, #0x20         | X29 = (1152921513728266384 + 32) = 1152921513728266416 (0x100000021FADD0B0);
            // 0x00AD5170: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD5174: LDRB w8, [x21, #0x4e9]     | W8 = (bool)static_value_037334E9;       
            // 0x00AD5178: MOV x20, x1                | X20 = value;//m1                        
            // 0x00AD517C: MOV x19, x0                | X19 = 1152921513728278432 (0x100000021FADFFA0);//ML01
            // 0x00AD5180: TBNZ w8, #0, #0xad519c     | if (static_value_037334E9 == true) goto label_0;
            // 0x00AD5184: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00AD5188: LDR x8, [x8, #0xc68]       | X8 = 0x2B8FA20;                         
            // 0x00AD518C: LDR w0, [x8]               | W0 = 0x154C;                            
            // 0x00AD5190: BL #0x2782188              | X0 = sub_2782188( ?? 0x154C, ????);     
            // 0x00AD5194: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5198: STRB w8, [x21, #0x4e9]     | static_value_037334E9 = true;            //  dest_result_addr=57881833
            label_0:
            // 0x00AD519C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD51A0: MOV x0, x19                | X0 = 1152921513728278432 (0x100000021FADFFA0);//ML01
            // 0x00AD51A4: MOV x1, x20                | X1 = value;//m1                         
            // 0x00AD51A8: BL #0x131ad00              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD51AC: CBZ x20, #0xad51f8         | if (value == null) goto label_1;        
            if(value == null)
            {
                goto label_1;
            }
            // 0x00AD51B0: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00AD51B4: LDR x8, [x8, #0x188]       | X8 = 1152921504857911296;               
            // 0x00AD51B8: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonString);
            object val_1 = null;
            // 0x00AD51BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonString), ????);
            // 0x00AD51C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD51C4: MOV x21, x0                | X21 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD51C8: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AD51CC: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00AD51D0: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00AD51D4: STRB w9, [x21, #0x30]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0x1;  //  dest_result_addr=1152921504857911344
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 1;
            // 0x00AD51D8: STR x20, [x21, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = value;  //  dest_result_addr=1152921504857911328
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = value;
            // 0x00AD51DC: STRB w8, [x21, #0x28]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 0x2;  //  dest_result_addr=1152921504857911336
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 2;
            // 0x00AD51E0: MOV x0, x19                | X0 = 1152921513728278432 (0x100000021FADFFA0);//ML01
            // 0x00AD51E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD51E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD51EC: MOV x1, x21                | X1 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD51F0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD51F4: B #0xad4d30                | this.AddToken(token:  val_1); return;   
            this.AddToken(token:  val_1);
            return;
            label_1:
            // 0x00AD51F8: MOV x0, x19                | X0 = 1152921513728278432 (0x100000021FADFFA0);//ML01
            // 0x00AD51FC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5200: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5204: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5208: MOVZ w2, #0xa              | W2 = 10 (0xA);//ML01                    
            // 0x00AD520C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5210: B #0xad5084                | this.AddValue(value:  0, type:  10); return;
            this.AddValue(value:  0, type:  10);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5214 (11358740), len: 140  VirtAddr: 0x00AD5214 RVA: 0x00AD5214 token: 100684815 methodIndex: 47459 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(int value)
        {
            //
            // Disasemble & Code
            // 0x00AD5214: STP x22, x21, [sp, #-0x30]! | stack[1152921513728386576] = ???;  stack[1152921513728386584] = ???;  //  dest_result_addr=1152921513728386576 |  dest_result_addr=1152921513728386584
            // 0x00AD5218: STP x20, x19, [sp, #0x10]  | stack[1152921513728386592] = ???;  stack[1152921513728386600] = ???;  //  dest_result_addr=1152921513728386592 |  dest_result_addr=1152921513728386600
            // 0x00AD521C: STP x29, x30, [sp, #0x20]  | stack[1152921513728386608] = ???;  stack[1152921513728386616] = ???;  //  dest_result_addr=1152921513728386608 |  dest_result_addr=1152921513728386616
            // 0x00AD5220: ADD x29, sp, #0x20         | X29 = (1152921513728386576 + 32) = 1152921513728386608 (0x100000021FAFA630);
            // 0x00AD5224: SUB sp, sp, #0x10          | SP = (1152921513728386576 - 16) = 1152921513728386560 (0x100000021FAFA600);
            // 0x00AD5228: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD522C: LDRB w8, [x21, #0x4ea]     | W8 = (bool)static_value_037334EA;       
            // 0x00AD5230: MOV w20, w1                | W20 = value;//m1                        
            // 0x00AD5234: MOV x19, x0                | X19 = 1152921513728398624 (0x100000021FAFD520);//ML01
            // 0x00AD5238: TBNZ w8, #0, #0xad5254     | if (static_value_037334EA == true) goto label_0;
            // 0x00AD523C: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00AD5240: LDR x8, [x8, #0xef0]       | X8 = 0x2B8FA38;                         
            // 0x00AD5244: LDR w0, [x8]               | W0 = 0x1552;                            
            // 0x00AD5248: BL #0x2782188              | X0 = sub_2782188( ?? 0x1552, ????);     
            // 0x00AD524C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5250: STRB w8, [x21, #0x4ea]     | static_value_037334EA = true;            //  dest_result_addr=57881834
            label_0:
            // 0x00AD5254: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5258: MOV x0, x19                | X0 = 1152921513728398624 (0x100000021FAFD520);//ML01
            // 0x00AD525C: MOV w1, w20                | W1 = value;//m1                         
            // 0x00AD5260: BL #0x131adac              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD5264: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00AD5268: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00AD526C: ADD x1, sp, #0xc           | X1 = (1152921513728386560 + 12) = 1152921513728386572 (0x100000021FAFA60C);
            // 0x00AD5270: STR w20, [sp, #0xc]        | stack[1152921513728386572] = value;      //  dest_result_addr=1152921513728386572
            // 0x00AD5274: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x00AD5278: BL #0x27bc028              | X0 = 1152921513728430624 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), value);
            // 0x00AD527C: MOV x1, x0                 | X1 = 1152921513728430624 (0x100000021FB05220);//ML01
            // 0x00AD5280: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
            // 0x00AD5284: MOV x0, x19                | X0 = 1152921513728398624 (0x100000021FAFD520);//ML01
            // 0x00AD5288: BL #0xad5084               | this.AddValue(value:  value, type:  16);
            this.AddValue(value:  value, type:  16);
            // 0x00AD528C: SUB sp, x29, #0x20         | SP = (1152921513728386608 - 32) = 1152921513728386576 (0x100000021FAFA610);
            // 0x00AD5290: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5294: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5298: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD529C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD52A0 (11358880), len: 208  VirtAddr: 0x00AD52A0 RVA: 0x00AD52A0 token: 100684816 methodIndex: 47460 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(uint value)
        {
            //
            // Disasemble & Code
            // 0x00AD52A0: STP x22, x21, [sp, #-0x30]! | stack[1152921513728508048] = ???;  stack[1152921513728508056] = ???;  //  dest_result_addr=1152921513728508048 |  dest_result_addr=1152921513728508056
            // 0x00AD52A4: STP x20, x19, [sp, #0x10]  | stack[1152921513728508064] = ???;  stack[1152921513728508072] = ???;  //  dest_result_addr=1152921513728508064 |  dest_result_addr=1152921513728508072
            // 0x00AD52A8: STP x29, x30, [sp, #0x20]  | stack[1152921513728508080] = ???;  stack[1152921513728508088] = ???;  //  dest_result_addr=1152921513728508080 |  dest_result_addr=1152921513728508088
            // 0x00AD52AC: ADD x29, sp, #0x20         | X29 = (1152921513728508048 + 32) = 1152921513728508080 (0x100000021FB180B0);
            // 0x00AD52B0: SUB sp, sp, #0x10          | SP = (1152921513728508048 - 16) = 1152921513728508032 (0x100000021FB18080);
            // 0x00AD52B4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD52B8: LDRB w8, [x21, #0x4eb]     | W8 = (bool)static_value_037334EB;       
            // 0x00AD52BC: MOV w20, w1                | W20 = value;//m1                        
            // 0x00AD52C0: MOV x19, x0                | X19 = 1152921513728520096 (0x100000021FB1AFA0);//ML01
            // 0x00AD52C4: TBNZ w8, #0, #0xad52e0     | if (static_value_037334EB == true) goto label_0;
            // 0x00AD52C8: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00AD52CC: LDR x8, [x8, #0xc18]       | X8 = 0x2B8FA0C;                         
            // 0x00AD52D0: LDR w0, [x8]               | W0 = 0x1547;                            
            // 0x00AD52D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1547, ????);     
            // 0x00AD52D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD52DC: STRB w8, [x21, #0x4eb]     | static_value_037334EB = true;            //  dest_result_addr=57881835
            label_0:
            // 0x00AD52E0: TBNZ w20, #0x1f, #0xad5330 | if ((value & 0x80000000) != 0) goto label_1;
            if((value & 2147483648) != 0)
            {
                goto label_1;
            }
            // 0x00AD52E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD52E8: MOV x0, x19                | X0 = 1152921513728520096 (0x100000021FB1AFA0);//ML01
            // 0x00AD52EC: MOV w1, w20                | W1 = value;//m1                         
            // 0x00AD52F0: BL #0x131ae58              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD52F4: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x00AD52F8: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x00AD52FC: ADD x1, sp, #0xc           | X1 = (1152921513728508032 + 12) = 1152921513728508044 (0x100000021FB1808C);
            // 0x00AD5300: STR w20, [sp, #0xc]        | stack[1152921513728508044] = value;      //  dest_result_addr=1152921513728508044
            // 0x00AD5304: LDR x0, [x8]               | X0 = typeof(System.UInt32);             
            // 0x00AD5308: BL #0x27bc028              | X0 = 1152921513728552096 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), value);
            // 0x00AD530C: MOV x1, x0                 | X1 = 1152921513728552096 (0x100000021FB22CA0);//ML01
            // 0x00AD5310: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
            // 0x00AD5314: MOV x0, x19                | X0 = 1152921513728520096 (0x100000021FB1AFA0);//ML01
            // 0x00AD5318: BL #0xad5084               | this.AddValue(value:  value, type:  16);
            this.AddValue(value:  value, type:  16);
            // 0x00AD531C: SUB sp, x29, #0x20         | SP = (1152921513728508080 - 32) = 1152921513728508048 (0x100000021FB18090);
            // 0x00AD5320: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5324: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5328: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD532C: RET                        |  return;                                
            return;
            label_1:
            // 0x00AD5330: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00AD5334: LDR x8, [x8, #0x468]       | X8 = 1152921504860839936;               
            // 0x00AD5338: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonWriterException);
            Newtonsoft.Json.JsonWriterException val_1 = null;
            // 0x00AD533C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD5340: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00AD5344: LDR x8, [x8, #0x5b8]       | X8 = (string**)(1152921513728494816)("Value is too large to fit in a signed 32 bit integer. BSON does not support unsigned values.");
            // 0x00AD5348: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD534C: MOV x19, x0                | X19 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD5350: LDR x1, [x8]               | X1 = "Value is too large to fit in a signed 32 bit integer. BSON does not support unsigned values.";
            // 0x00AD5354: BL #0x131a8e4              | .ctor(message:  "Value is too large to fit in a signed 32 bit integer. BSON does not support unsigned values.");
            val_1 = new Newtonsoft.Json.JsonWriterException(message:  "Value is too large to fit in a signed 32 bit integer. BSON does not support unsigned values.");
            // 0x00AD5358: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x00AD535C: LDR x8, [x8, #0xd00]       | X8 = 1152921513728495072;               
            // 0x00AD5360: MOV x0, x19                | X0 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD5364: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Bson.BsonWriter::WriteValue(uint value);
            // 0x00AD5368: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD536C: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5370 (11359088), len: 140  VirtAddr: 0x00AD5370 RVA: 0x00AD5370 token: 100684817 methodIndex: 47461 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(long value)
        {
            //
            // Disasemble & Code
            // 0x00AD5370: STP x22, x21, [sp, #-0x30]! | stack[1152921513728628240] = ???;  stack[1152921513728628248] = ???;  //  dest_result_addr=1152921513728628240 |  dest_result_addr=1152921513728628248
            // 0x00AD5374: STP x20, x19, [sp, #0x10]  | stack[1152921513728628256] = ???;  stack[1152921513728628264] = ???;  //  dest_result_addr=1152921513728628256 |  dest_result_addr=1152921513728628264
            // 0x00AD5378: STP x29, x30, [sp, #0x20]  | stack[1152921513728628272] = ???;  stack[1152921513728628280] = ???;  //  dest_result_addr=1152921513728628272 |  dest_result_addr=1152921513728628280
            // 0x00AD537C: ADD x29, sp, #0x20         | X29 = (1152921513728628240 + 32) = 1152921513728628272 (0x100000021FB35630);
            // 0x00AD5380: SUB sp, sp, #0x10          | SP = (1152921513728628240 - 16) = 1152921513728628224 (0x100000021FB35600);
            // 0x00AD5384: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD5388: LDRB w8, [x21, #0x4ec]     | W8 = (bool)static_value_037334EC;       
            // 0x00AD538C: MOV x20, x1                | X20 = value;//m1                        
            // 0x00AD5390: MOV x19, x0                | X19 = 1152921513728640288 (0x100000021FB38520);//ML01
            // 0x00AD5394: TBNZ w8, #0, #0xad53b0     | if (static_value_037334EC == true) goto label_0;
            // 0x00AD5398: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x00AD539C: LDR x8, [x8, #0xb18]       | X8 = 0x2B8FA3C;                         
            // 0x00AD53A0: LDR w0, [x8]               | W0 = 0x1553;                            
            // 0x00AD53A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1553, ????);     
            // 0x00AD53A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD53AC: STRB w8, [x21, #0x4ec]     | static_value_037334EC = true;            //  dest_result_addr=57881836
            label_0:
            // 0x00AD53B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD53B4: MOV x0, x19                | X0 = 1152921513728640288 (0x100000021FB38520);//ML01
            // 0x00AD53B8: MOV x1, x20                | X1 = value;//m1                         
            // 0x00AD53BC: BL #0x131af04              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD53C0: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x00AD53C4: LDR x8, [x8, #0x4b0]       | X8 = 1152921504607592448;               
            // 0x00AD53C8: ADD x1, sp, #8             | X1 = (1152921513728628224 + 8) = 1152921513728628232 (0x100000021FB35608);
            // 0x00AD53CC: STR x20, [sp, #8]          | stack[1152921513728628232] = value;      //  dest_result_addr=1152921513728628232
            // 0x00AD53D0: LDR x0, [x8]               | X0 = typeof(System.Int64);              
            // 0x00AD53D4: BL #0x27bc028              | X0 = 1152921513728672288 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), value);
            // 0x00AD53D8: MOV x1, x0                 | X1 = 1152921513728672288 (0x100000021FB40220);//ML01
            // 0x00AD53DC: MOVZ w2, #0x12             | W2 = 18 (0x12);//ML01                   
            // 0x00AD53E0: MOV x0, x19                | X0 = 1152921513728640288 (0x100000021FB38520);//ML01
            // 0x00AD53E4: BL #0xad5084               | this.AddValue(value:  value, type:  18);
            this.AddValue(value:  value, type:  18);
            // 0x00AD53E8: SUB sp, x29, #0x20         | SP = (1152921513728628272 - 32) = 1152921513728628240 (0x100000021FB35610);
            // 0x00AD53EC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD53F0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD53F4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD53F8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD53FC (11359228), len: 208  VirtAddr: 0x00AD53FC RVA: 0x00AD53FC token: 100684818 methodIndex: 47462 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(ulong value)
        {
            //
            // Disasemble & Code
            // 0x00AD53FC: STP x22, x21, [sp, #-0x30]! | stack[1152921513728749712] = ???;  stack[1152921513728749720] = ???;  //  dest_result_addr=1152921513728749712 |  dest_result_addr=1152921513728749720
            // 0x00AD5400: STP x20, x19, [sp, #0x10]  | stack[1152921513728749728] = ???;  stack[1152921513728749736] = ???;  //  dest_result_addr=1152921513728749728 |  dest_result_addr=1152921513728749736
            // 0x00AD5404: STP x29, x30, [sp, #0x20]  | stack[1152921513728749744] = ???;  stack[1152921513728749752] = ???;  //  dest_result_addr=1152921513728749744 |  dest_result_addr=1152921513728749752
            // 0x00AD5408: ADD x29, sp, #0x20         | X29 = (1152921513728749712 + 32) = 1152921513728749744 (0x100000021FB530B0);
            // 0x00AD540C: SUB sp, sp, #0x10          | SP = (1152921513728749712 - 16) = 1152921513728749696 (0x100000021FB53080);
            // 0x00AD5410: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD5414: LDRB w8, [x21, #0x4ed]     | W8 = (bool)static_value_037334ED;       
            // 0x00AD5418: MOV x20, x1                | X20 = value;//m1                        
            // 0x00AD541C: MOV x19, x0                | X19 = 1152921513728761760 (0x100000021FB55FA0);//ML01
            // 0x00AD5420: TBNZ w8, #0, #0xad543c     | if (static_value_037334ED == true) goto label_0;
            // 0x00AD5424: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x00AD5428: LDR x8, [x8, #0x850]       | X8 = 0x2B8FA48;                         
            // 0x00AD542C: LDR w0, [x8]               | W0 = 0x1556;                            
            // 0x00AD5430: BL #0x2782188              | X0 = sub_2782188( ?? 0x1556, ????);     
            // 0x00AD5434: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5438: STRB w8, [x21, #0x4ed]     | static_value_037334ED = true;            //  dest_result_addr=57881837
            label_0:
            // 0x00AD543C: TBNZ x20, #0x3f, #0xad548c | if ((value & 0x8000000000000000) != 0) goto label_1;
            if((value & 9223372036854775808) != 0)
            {
                goto label_1;
            }
            // 0x00AD5440: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5444: MOV x0, x19                | X0 = 1152921513728761760 (0x100000021FB55FA0);//ML01
            // 0x00AD5448: MOV x1, x20                | X1 = value;//m1                         
            // 0x00AD544C: BL #0x131afb0              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD5450: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00AD5454: LDR x8, [x8, #0xf28]       | X8 = 1152921504607752192;               
            // 0x00AD5458: ADD x1, sp, #8             | X1 = (1152921513728749696 + 8) = 1152921513728749704 (0x100000021FB53088);
            // 0x00AD545C: STR x20, [sp, #8]          | stack[1152921513728749704] = value;      //  dest_result_addr=1152921513728749704
            // 0x00AD5460: LDR x0, [x8]               | X0 = typeof(System.UInt64);             
            // 0x00AD5464: BL #0x27bc028              | X0 = 1152921513728793760 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt64), value);
            // 0x00AD5468: MOV x1, x0                 | X1 = 1152921513728793760 (0x100000021FB5DCA0);//ML01
            // 0x00AD546C: MOVZ w2, #0x12             | W2 = 18 (0x12);//ML01                   
            // 0x00AD5470: MOV x0, x19                | X0 = 1152921513728761760 (0x100000021FB55FA0);//ML01
            // 0x00AD5474: BL #0xad5084               | this.AddValue(value:  value, type:  18);
            this.AddValue(value:  value, type:  18);
            // 0x00AD5478: SUB sp, x29, #0x20         | SP = (1152921513728749744 - 32) = 1152921513728749712 (0x100000021FB53090);
            // 0x00AD547C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5480: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5484: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5488: RET                        |  return;                                
            return;
            label_1:
            // 0x00AD548C: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00AD5490: LDR x8, [x8, #0x468]       | X8 = 1152921504860839936;               
            // 0x00AD5494: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonWriterException);
            Newtonsoft.Json.JsonWriterException val_1 = null;
            // 0x00AD5498: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD549C: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00AD54A0: LDR x8, [x8, #0x3c8]       | X8 = (string**)(1152921513728736480)("Value is too large to fit in a signed 64 bit integer. BSON does not support unsigned values.");
            // 0x00AD54A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD54A8: MOV x19, x0                | X19 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD54AC: LDR x1, [x8]               | X1 = "Value is too large to fit in a signed 64 bit integer. BSON does not support unsigned values.";
            // 0x00AD54B0: BL #0x131a8e4              | .ctor(message:  "Value is too large to fit in a signed 64 bit integer. BSON does not support unsigned values.");
            val_1 = new Newtonsoft.Json.JsonWriterException(message:  "Value is too large to fit in a signed 64 bit integer. BSON does not support unsigned values.");
            // 0x00AD54B4: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00AD54B8: LDR x8, [x8, #0x1b8]       | X8 = 1152921513728736736;               
            // 0x00AD54BC: MOV x0, x19                | X0 = 1152921504860839936 (0x100000000F23A000);//ML01
            // 0x00AD54C0: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Bson.BsonWriter::WriteValue(ulong value);
            // 0x00AD54C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonWriterException), ????);
            // 0x00AD54C8: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD54CC (11359436), len: 140  VirtAddr: 0x00AD54CC RVA: 0x00AD54CC token: 100684819 methodIndex: 47463 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(float value)
        {
            //
            // Disasemble & Code
            // 0x00AD54CC: STP d9, d8, [sp, #-0x30]!  | stack[1152921513728869904] = ???;  stack[1152921513728869912] = ???;  //  dest_result_addr=1152921513728869904 |  dest_result_addr=1152921513728869912
            // 0x00AD54D0: STP x20, x19, [sp, #0x10]  | stack[1152921513728869920] = ???;  stack[1152921513728869928] = ???;  //  dest_result_addr=1152921513728869920 |  dest_result_addr=1152921513728869928
            // 0x00AD54D4: STP x29, x30, [sp, #0x20]  | stack[1152921513728869936] = ???;  stack[1152921513728869944] = ???;  //  dest_result_addr=1152921513728869936 |  dest_result_addr=1152921513728869944
            // 0x00AD54D8: ADD x29, sp, #0x20         | X29 = (1152921513728869904 + 32) = 1152921513728869936 (0x100000021FB70630);
            // 0x00AD54DC: SUB sp, sp, #0x10          | SP = (1152921513728869904 - 16) = 1152921513728869888 (0x100000021FB70600);
            // 0x00AD54E0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD54E4: LDRB w8, [x20, #0x4ee]     | W8 = (bool)static_value_037334EE;       
            // 0x00AD54E8: MOV v8.16b, v0.16b         | V8 = value;//m1                         
            // 0x00AD54EC: MOV x19, x0                | X19 = 1152921513728881952 (0x100000021FB73520);//ML01
            // 0x00AD54F0: TBNZ w8, #0, #0xad550c     | if (static_value_037334EE == true) goto label_0;
            // 0x00AD54F4: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00AD54F8: LDR x8, [x8, #0xcb8]       | X8 = 0x2B8FA28;                         
            // 0x00AD54FC: LDR w0, [x8]               | W0 = 0x154E;                            
            // 0x00AD5500: BL #0x2782188              | X0 = sub_2782188( ?? 0x154E, ????);     
            // 0x00AD5504: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5508: STRB w8, [x20, #0x4ee]     | static_value_037334EE = true;            //  dest_result_addr=57881838
            label_0:
            // 0x00AD550C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5510: MOV x0, x19                | X0 = 1152921513728881952 (0x100000021FB73520);//ML01
            // 0x00AD5514: MOV v0.16b, v8.16b         | V0 = value;//m1                         
            // 0x00AD5518: BL #0x131b05c              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD551C: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AD5520: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00AD5524: ADD x1, sp, #0xc           | X1 = (1152921513728869888 + 12) = 1152921513728869900 (0x100000021FB7060C);
            // 0x00AD5528: STR s8, [sp, #0xc]         | stack[1152921513728869900] = value;      //  dest_result_addr=1152921513728869900
            // 0x00AD552C: LDR x0, [x8]               | X0 = typeof(System.Single);             
            // 0x00AD5530: BL #0x27bc028              | X0 = 1152921513728913952 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), value);
            // 0x00AD5534: MOV x1, x0                 | X1 = 1152921513728913952 (0x100000021FB7B220);//ML01
            // 0x00AD5538: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AD553C: MOV x0, x19                | X0 = 1152921513728881952 (0x100000021FB73520);//ML01
            // 0x00AD5540: BL #0xad5084               | this.AddValue(value:  value, type:  1); 
            this.AddValue(value:  value, type:  1);
            // 0x00AD5544: SUB sp, x29, #0x20         | SP = (1152921513728869936 - 32) = 1152921513728869904 (0x100000021FB70610);
            // 0x00AD5548: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD554C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5550: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
            // 0x00AD5554: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5558 (11359576), len: 140  VirtAddr: 0x00AD5558 RVA: 0x00AD5558 token: 100684820 methodIndex: 47464 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(double value)
        {
            //
            // Disasemble & Code
            // 0x00AD5558: STP d9, d8, [sp, #-0x30]!  | stack[1152921513728990096] = ???;  stack[1152921513728990104] = ???;  //  dest_result_addr=1152921513728990096 |  dest_result_addr=1152921513728990104
            // 0x00AD555C: STP x20, x19, [sp, #0x10]  | stack[1152921513728990112] = ???;  stack[1152921513728990120] = ???;  //  dest_result_addr=1152921513728990112 |  dest_result_addr=1152921513728990120
            // 0x00AD5560: STP x29, x30, [sp, #0x20]  | stack[1152921513728990128] = ???;  stack[1152921513728990136] = ???;  //  dest_result_addr=1152921513728990128 |  dest_result_addr=1152921513728990136
            // 0x00AD5564: ADD x29, sp, #0x20         | X29 = (1152921513728990096 + 32) = 1152921513728990128 (0x100000021FB8DBB0);
            // 0x00AD5568: SUB sp, sp, #0x10          | SP = (1152921513728990096 - 16) = 1152921513728990080 (0x100000021FB8DB80);
            // 0x00AD556C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD5570: LDRB w8, [x20, #0x4ef]     | W8 = (bool)static_value_037334EF;       
            // 0x00AD5574: MOV v8.16b, v0.16b         | V8 = value;//m1                         
            // 0x00AD5578: MOV x19, x0                | X19 = 1152921513729002144 (0x100000021FB90AA0);//ML01
            // 0x00AD557C: TBNZ w8, #0, #0xad5598     | if (static_value_037334EF == true) goto label_0;
            // 0x00AD5580: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x00AD5584: LDR x8, [x8, #0x1d8]       | X8 = 0x2B8FA34;                         
            // 0x00AD5588: LDR w0, [x8]               | W0 = 0x1551;                            
            // 0x00AD558C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1551, ????);     
            // 0x00AD5590: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5594: STRB w8, [x20, #0x4ef]     | static_value_037334EF = true;            //  dest_result_addr=57881839
            label_0:
            // 0x00AD5598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD559C: MOV x0, x19                | X0 = 1152921513729002144 (0x100000021FB90AA0);//ML01
            // 0x00AD55A0: MOV v0.16b, v8.16b         | V0 = value;//m1                         
            // 0x00AD55A4: BL #0x131b108              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD55A8: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00AD55AC: LDR x8, [x8, #0x900]       | X8 = 1152921504608497664;               
            // 0x00AD55B0: ADD x1, sp, #8             | X1 = (1152921513728990080 + 8) = 1152921513728990088 (0x100000021FB8DB88);
            // 0x00AD55B4: STR d8, [sp, #8]           | stack[1152921513728990088] = value;      //  dest_result_addr=1152921513728990088
            // 0x00AD55B8: LDR x0, [x8]               | X0 = typeof(System.Double);             
            // 0x00AD55BC: BL #0x27bc028              | X0 = 1152921513729034144 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Double), value);
            // 0x00AD55C0: MOV x1, x0                 | X1 = 1152921513729034144 (0x100000021FB987A0);//ML01
            // 0x00AD55C4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AD55C8: MOV x0, x19                | X0 = 1152921513729002144 (0x100000021FB90AA0);//ML01
            // 0x00AD55CC: BL #0xad5084               | this.AddValue(value:  value, type:  1); 
            this.AddValue(value:  value, type:  1);
            // 0x00AD55D0: SUB sp, x29, #0x20         | SP = (1152921513728990128 - 32) = 1152921513728990096 (0x100000021FB8DB90);
            // 0x00AD55D4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD55D8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD55DC: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
            // 0x00AD55E0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD55E4 (11359716), len: 144  VirtAddr: 0x00AD55E4 RVA: 0x00AD55E4 token: 100684821 methodIndex: 47465 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(bool value)
        {
            //
            // Disasemble & Code
            // 0x00AD55E4: STP x22, x21, [sp, #-0x30]! | stack[1152921513729110288] = ???;  stack[1152921513729110296] = ???;  //  dest_result_addr=1152921513729110288 |  dest_result_addr=1152921513729110296
            // 0x00AD55E8: STP x20, x19, [sp, #0x10]  | stack[1152921513729110304] = ???;  stack[1152921513729110312] = ???;  //  dest_result_addr=1152921513729110304 |  dest_result_addr=1152921513729110312
            // 0x00AD55EC: STP x29, x30, [sp, #0x20]  | stack[1152921513729110320] = ???;  stack[1152921513729110328] = ???;  //  dest_result_addr=1152921513729110320 |  dest_result_addr=1152921513729110328
            // 0x00AD55F0: ADD x29, sp, #0x20         | X29 = (1152921513729110288 + 32) = 1152921513729110320 (0x100000021FBAB130);
            // 0x00AD55F4: SUB sp, sp, #0x10          | SP = (1152921513729110288 - 16) = 1152921513729110272 (0x100000021FBAB100);
            // 0x00AD55F8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD55FC: LDRB w8, [x21, #0x4f0]     | W8 = (bool)static_value_037334F0;       
            // 0x00AD5600: MOV w20, w1                | W20 = value;//m1                        
            // 0x00AD5604: MOV x19, x0                | X19 = 1152921513729122336 (0x100000021FBAE020);//ML01
            // 0x00AD5608: TBNZ w8, #0, #0xad5624     | if (static_value_037334F0 == true) goto label_0;
            // 0x00AD560C: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00AD5610: LDR x8, [x8, #0x240]       | X8 = 0x2B8FA04;                         
            // 0x00AD5614: LDR w0, [x8]               | W0 = 0x1545;                            
            // 0x00AD5618: BL #0x2782188              | X0 = sub_2782188( ?? 0x1545, ????);     
            // 0x00AD561C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5620: STRB w8, [x21, #0x4f0]     | static_value_037334F0 = true;            //  dest_result_addr=57881840
            label_0:
            // 0x00AD5624: AND w20, w20, #1           | W20 = (value & 1);                      
            bool val_1 = value;
            // 0x00AD5628: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD562C: MOV x0, x19                | X0 = 1152921513729122336 (0x100000021FBAE020);//ML01
            // 0x00AD5630: MOV w1, w20                | W1 = (value & 1);//m1                   
            // 0x00AD5634: BL #0x131b1b4              | this.WriteValue(value:  val_1);         
            this.WriteValue(value:  val_1);
            // 0x00AD5638: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00AD563C: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00AD5640: ADD x1, sp, #0xf           | X1 = (1152921513729110272 + 15) = 1152921513729110287 (0x100000021FBAB10F);
            // 0x00AD5644: STRB w20, [sp, #0xf]       | stack[1152921513729110287] = (value & 1);  //  dest_result_addr=1152921513729110287
            // 0x00AD5648: LDR x0, [x8]               | X0 = typeof(System.Boolean);            
            // 0x00AD564C: BL #0x27bc028              | X0 = 1152921513729154336 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), (value & 1));
            // 0x00AD5650: MOV x1, x0                 | X1 = 1152921513729154336 (0x100000021FBB5D20);//ML01
            // 0x00AD5654: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            // 0x00AD5658: MOV x0, x19                | X0 = 1152921513729122336 (0x100000021FBAE020);//ML01
            // 0x00AD565C: BL #0xad5084               | this.AddValue(value:  val_1, type:  8); 
            this.AddValue(value:  val_1, type:  8);
            // 0x00AD5660: SUB sp, x29, #0x20         | SP = (1152921513729110320 - 32) = 1152921513729110288 (0x100000021FBAB110);
            // 0x00AD5664: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5668: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD566C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5670: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5674 (11359860), len: 140  VirtAddr: 0x00AD5674 RVA: 0x00AD5674 token: 100684822 methodIndex: 47466 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(short value)
        {
            //
            // Disasemble & Code
            // 0x00AD5674: STP x22, x21, [sp, #-0x30]! | stack[1152921513729230480] = ???;  stack[1152921513729230488] = ???;  //  dest_result_addr=1152921513729230480 |  dest_result_addr=1152921513729230488
            // 0x00AD5678: STP x20, x19, [sp, #0x10]  | stack[1152921513729230496] = ???;  stack[1152921513729230504] = ???;  //  dest_result_addr=1152921513729230496 |  dest_result_addr=1152921513729230504
            // 0x00AD567C: STP x29, x30, [sp, #0x20]  | stack[1152921513729230512] = ???;  stack[1152921513729230520] = ???;  //  dest_result_addr=1152921513729230512 |  dest_result_addr=1152921513729230520
            // 0x00AD5680: ADD x29, sp, #0x20         | X29 = (1152921513729230480 + 32) = 1152921513729230512 (0x100000021FBC86B0);
            // 0x00AD5684: SUB sp, sp, #0x10          | SP = (1152921513729230480 - 16) = 1152921513729230464 (0x100000021FBC8680);
            // 0x00AD5688: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD568C: LDRB w8, [x21, #0x4f1]     | W8 = (bool)static_value_037334F1;       
            // 0x00AD5690: MOV w20, w1                | W20 = value;//m1                        
            // 0x00AD5694: MOV x19, x0                | X19 = 1152921513729242528 (0x100000021FBCB5A0);//ML01
            // 0x00AD5698: TBNZ w8, #0, #0xad56b4     | if (static_value_037334F1 == true) goto label_0;
            // 0x00AD569C: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x00AD56A0: LDR x8, [x8, #0xe00]       | X8 = 0x2B8FA40;                         
            // 0x00AD56A4: LDR w0, [x8]               | W0 = 0x1554;                            
            // 0x00AD56A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1554, ????);     
            // 0x00AD56AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD56B0: STRB w8, [x21, #0x4f1]     | static_value_037334F1 = true;            //  dest_result_addr=57881841
            label_0:
            // 0x00AD56B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD56B8: MOV x0, x19                | X0 = 1152921513729242528 (0x100000021FBCB5A0);//ML01
            // 0x00AD56BC: MOV w1, w20                | W1 = value;//m1                         
            // 0x00AD56C0: BL #0x131b260              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD56C4: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x00AD56C8: LDR x8, [x8, #0x770]       | X8 = 1152921504607911936;               
            // 0x00AD56CC: ADD x1, sp, #0xe           | X1 = (1152921513729230464 + 14) = 1152921513729230478 (0x100000021FBC868E);
            // 0x00AD56D0: STRH w20, [sp, #0xe]       | stack[1152921513729230478] = value;      //  dest_result_addr=1152921513729230478
            // 0x00AD56D4: LDR x0, [x8]               | X0 = typeof(System.Int16);              
            // 0x00AD56D8: BL #0x27bc028              | X0 = 1152921513729274528 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int16), value);
            // 0x00AD56DC: MOV x1, x0                 | X1 = 1152921513729274528 (0x100000021FBD32A0);//ML01
            // 0x00AD56E0: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
            // 0x00AD56E4: MOV x0, x19                | X0 = 1152921513729242528 (0x100000021FBCB5A0);//ML01
            // 0x00AD56E8: BL #0xad5084               | this.AddValue(value:  value, type:  16);
            this.AddValue(value:  value, type:  16);
            // 0x00AD56EC: SUB sp, x29, #0x20         | SP = (1152921513729230512 - 32) = 1152921513729230480 (0x100000021FBC8690);
            // 0x00AD56F0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD56F4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD56F8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD56FC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5700 (11360000), len: 140  VirtAddr: 0x00AD5700 RVA: 0x00AD5700 token: 100684823 methodIndex: 47467 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(ushort value)
        {
            //
            // Disasemble & Code
            // 0x00AD5700: STP x22, x21, [sp, #-0x30]! | stack[1152921513729350672] = ???;  stack[1152921513729350680] = ???;  //  dest_result_addr=1152921513729350672 |  dest_result_addr=1152921513729350680
            // 0x00AD5704: STP x20, x19, [sp, #0x10]  | stack[1152921513729350688] = ???;  stack[1152921513729350696] = ???;  //  dest_result_addr=1152921513729350688 |  dest_result_addr=1152921513729350696
            // 0x00AD5708: STP x29, x30, [sp, #0x20]  | stack[1152921513729350704] = ???;  stack[1152921513729350712] = ???;  //  dest_result_addr=1152921513729350704 |  dest_result_addr=1152921513729350712
            // 0x00AD570C: ADD x29, sp, #0x20         | X29 = (1152921513729350672 + 32) = 1152921513729350704 (0x100000021FBE5C30);
            // 0x00AD5710: SUB sp, sp, #0x10          | SP = (1152921513729350672 - 16) = 1152921513729350656 (0x100000021FBE5C00);
            // 0x00AD5714: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD5718: LDRB w8, [x21, #0x4f2]     | W8 = (bool)static_value_037334F2;       
            // 0x00AD571C: MOV w20, w1                | W20 = value;//m1                        
            // 0x00AD5720: MOV x19, x0                | X19 = 1152921513729362720 (0x100000021FBE8B20);//ML01
            // 0x00AD5724: TBNZ w8, #0, #0xad5740     | if (static_value_037334F2 == true) goto label_0;
            // 0x00AD5728: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x00AD572C: LDR x8, [x8, #0xd10]       | X8 = 0x2B8FA10;                         
            // 0x00AD5730: LDR w0, [x8]               | W0 = 0x1548;                            
            // 0x00AD5734: BL #0x2782188              | X0 = sub_2782188( ?? 0x1548, ????);     
            // 0x00AD5738: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD573C: STRB w8, [x21, #0x4f2]     | static_value_037334F2 = true;            //  dest_result_addr=57881842
            label_0:
            // 0x00AD5740: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5744: MOV x0, x19                | X0 = 1152921513729362720 (0x100000021FBE8B20);//ML01
            // 0x00AD5748: MOV w1, w20                | W1 = value;//m1                         
            // 0x00AD574C: BL #0x131b30c              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD5750: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00AD5754: LDR x8, [x8, #0x148]       | X8 = 1152921504607965184;               
            // 0x00AD5758: ADD x1, sp, #0xe           | X1 = (1152921513729350656 + 14) = 1152921513729350670 (0x100000021FBE5C0E);
            // 0x00AD575C: STRH w20, [sp, #0xe]       | stack[1152921513729350670] = value;      //  dest_result_addr=1152921513729350670
            // 0x00AD5760: LDR x0, [x8]               | X0 = typeof(System.UInt16);             
            // 0x00AD5764: BL #0x27bc028              | X0 = 1152921513729394720 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt16), value);
            // 0x00AD5768: MOV x1, x0                 | X1 = 1152921513729394720 (0x100000021FBF0820);//ML01
            // 0x00AD576C: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
            // 0x00AD5770: MOV x0, x19                | X0 = 1152921513729362720 (0x100000021FBE8B20);//ML01
            // 0x00AD5774: BL #0xad5084               | this.AddValue(value:  value, type:  16);
            this.AddValue(value:  value, type:  16);
            // 0x00AD5778: SUB sp, x29, #0x20         | SP = (1152921513729350704 - 32) = 1152921513729350672 (0x100000021FBE5C10);
            // 0x00AD577C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5780: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5784: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5788: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD578C (11360140), len: 184  VirtAddr: 0x00AD578C RVA: 0x00AD578C token: 100684824 methodIndex: 47468 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(char value)
        {
            //
            // Disasemble & Code
            // 0x00AD578C: STP x22, x21, [sp, #-0x30]! | stack[1152921513729470864] = ???;  stack[1152921513729470872] = ???;  //  dest_result_addr=1152921513729470864 |  dest_result_addr=1152921513729470872
            // 0x00AD5790: STP x20, x19, [sp, #0x10]  | stack[1152921513729470880] = ???;  stack[1152921513729470888] = ???;  //  dest_result_addr=1152921513729470880 |  dest_result_addr=1152921513729470888
            // 0x00AD5794: STP x29, x30, [sp, #0x20]  | stack[1152921513729470896] = ???;  stack[1152921513729470904] = ???;  //  dest_result_addr=1152921513729470896 |  dest_result_addr=1152921513729470904
            // 0x00AD5798: ADD x29, sp, #0x20         | X29 = (1152921513729470864 + 32) = 1152921513729470896 (0x100000021FC031B0);
            // 0x00AD579C: SUB sp, sp, #0x10          | SP = (1152921513729470864 - 16) = 1152921513729470848 (0x100000021FC03180);
            // 0x00AD57A0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD57A4: LDRB w8, [x21, #0x4f3]     | W8 = (bool)static_value_037334F3;       
            // 0x00AD57A8: MOV w20, w1                | W20 = value;//m1                        
            // 0x00AD57AC: MOV x19, x0                | X19 = 1152921513729482912 (0x100000021FC060A0);//ML01
            // 0x00AD57B0: STRH w20, [sp, #0xe]       | stack[1152921513729470862] = value;      //  dest_result_addr=1152921513729470862
            // 0x00AD57B4: TBNZ w8, #0, #0xad57d0     | if (static_value_037334F3 == true) goto label_0;
            // 0x00AD57B8: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x00AD57BC: LDR x8, [x8, #0x6b8]       | X8 = 0x2B8FA14;                         
            // 0x00AD57C0: LDR w0, [x8]               | W0 = 0x1549;                            
            // 0x00AD57C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1549, ????);     
            // 0x00AD57C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD57CC: STRB w8, [x21, #0x4f3]     | static_value_037334F3 = true;            //  dest_result_addr=57881843
            label_0:
            // 0x00AD57D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD57D4: MOV x0, x19                | X0 = 1152921513729482912 (0x100000021FC060A0);//ML01
            // 0x00AD57D8: MOV w1, w20                | W1 = value;//m1                         
            // 0x00AD57DC: BL #0x131b3b8              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD57E0: ADD x0, sp, #0xe           | X0 = (1152921513729470848 + 14) = 1152921513729470862 (0x100000021FC0318E);
            // 0x00AD57E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD57E8: BL #0x18b72b0              | X0 = value.ToString();                  
            string val_1 = value.ToString();
            // 0x00AD57EC: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00AD57F0: LDR x8, [x8, #0x188]       | X8 = 1152921504857911296;               
            // 0x00AD57F4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00AD57F8: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonString);
            // 0x00AD57FC: MOV x0, x8                 | X0 = 1152921504857911296 (0x100000000EF6F000);//ML01
            object val_2 = null;
            // 0x00AD5800: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonString), ????);
            // 0x00AD5804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5808: MOV x21, x0                | X21 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD580C: BL #0x16f59f0              | .ctor();                                
            val_2 = new System.Object();
            // 0x00AD5810: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00AD5814: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00AD5818: MOV x0, x19                | X0 = 1152921513729482912 (0x100000021FC060A0);//ML01
            // 0x00AD581C: MOV x1, x21                | X1 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD5820: STR x20, [x21, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = val_1;  //  dest_result_addr=1152921504857911328
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = val_1;
            // 0x00AD5824: STRB w8, [x21, #0x28]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 0x2;  //  dest_result_addr=1152921504857911336
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 2;
            // 0x00AD5828: STRB w9, [x21, #0x30]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0x1;  //  dest_result_addr=1152921504857911344
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 1;
            // 0x00AD582C: BL #0xad4d30               | this.AddToken(token:  val_2);           
            this.AddToken(token:  val_2);
            // 0x00AD5830: SUB sp, x29, #0x20         | SP = (1152921513729470896 - 32) = 1152921513729470864 (0x100000021FC03190);
            // 0x00AD5834: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5838: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD583C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5840: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5844 (11360324), len: 140  VirtAddr: 0x00AD5844 RVA: 0x00AD5844 token: 100684825 methodIndex: 47469 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(byte value)
        {
            //
            // Disasemble & Code
            // 0x00AD5844: STP x22, x21, [sp, #-0x30]! | stack[1152921513729591056] = ???;  stack[1152921513729591064] = ???;  //  dest_result_addr=1152921513729591056 |  dest_result_addr=1152921513729591064
            // 0x00AD5848: STP x20, x19, [sp, #0x10]  | stack[1152921513729591072] = ???;  stack[1152921513729591080] = ???;  //  dest_result_addr=1152921513729591072 |  dest_result_addr=1152921513729591080
            // 0x00AD584C: STP x29, x30, [sp, #0x20]  | stack[1152921513729591088] = ???;  stack[1152921513729591096] = ???;  //  dest_result_addr=1152921513729591088 |  dest_result_addr=1152921513729591096
            // 0x00AD5850: ADD x29, sp, #0x20         | X29 = (1152921513729591056 + 32) = 1152921513729591088 (0x100000021FC20730);
            // 0x00AD5854: SUB sp, sp, #0x10          | SP = (1152921513729591056 - 16) = 1152921513729591040 (0x100000021FC20700);
            // 0x00AD5858: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD585C: LDRB w8, [x21, #0x4f4]     | W8 = (bool)static_value_037334F4;       
            // 0x00AD5860: MOV w20, w1                | W20 = value;//m1                        
            // 0x00AD5864: MOV x19, x0                | X19 = 1152921513729603104 (0x100000021FC23620);//ML01
            // 0x00AD5868: TBNZ w8, #0, #0xad5884     | if (static_value_037334F4 == true) goto label_0;
            // 0x00AD586C: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00AD5870: LDR x8, [x8, #0x2d8]       | X8 = 0x2B8FA30;                         
            // 0x00AD5874: LDR w0, [x8]               | W0 = 0x1550;                            
            // 0x00AD5878: BL #0x2782188              | X0 = sub_2782188( ?? 0x1550, ????);     
            // 0x00AD587C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5880: STRB w8, [x21, #0x4f4]     | static_value_037334F4 = true;            //  dest_result_addr=57881844
            label_0:
            // 0x00AD5884: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5888: MOV x0, x19                | X0 = 1152921513729603104 (0x100000021FC23620);//ML01
            // 0x00AD588C: MOV w1, w20                | W1 = value;//m1                         
            // 0x00AD5890: BL #0x131b464              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD5894: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00AD5898: LDR x8, [x8, #0xf90]       | X8 = 1152921504607805440;               
            // 0x00AD589C: ADD x1, sp, #0xf           | X1 = (1152921513729591040 + 15) = 1152921513729591055 (0x100000021FC2070F);
            // 0x00AD58A0: STRB w20, [sp, #0xf]       | stack[1152921513729591055] = value;      //  dest_result_addr=1152921513729591055
            // 0x00AD58A4: LDR x0, [x8]               | X0 = typeof(System.Byte);               
            // 0x00AD58A8: BL #0x27bc028              | X0 = 1152921513729635104 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Byte), value);
            // 0x00AD58AC: MOV x1, x0                 | X1 = 1152921513729635104 (0x100000021FC2B320);//ML01
            // 0x00AD58B0: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
            // 0x00AD58B4: MOV x0, x19                | X0 = 1152921513729603104 (0x100000021FC23620);//ML01
            // 0x00AD58B8: BL #0xad5084               | this.AddValue(value:  value, type:  16);
            this.AddValue(value:  value, type:  16);
            // 0x00AD58BC: SUB sp, x29, #0x20         | SP = (1152921513729591088 - 32) = 1152921513729591056 (0x100000021FC20710);
            // 0x00AD58C0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD58C4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD58C8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD58CC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD58D0 (11360464), len: 140  VirtAddr: 0x00AD58D0 RVA: 0x00AD58D0 token: 100684826 methodIndex: 47470 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(sbyte value)
        {
            //
            // Disasemble & Code
            // 0x00AD58D0: STP x22, x21, [sp, #-0x30]! | stack[1152921513729711248] = ???;  stack[1152921513729711256] = ???;  //  dest_result_addr=1152921513729711248 |  dest_result_addr=1152921513729711256
            // 0x00AD58D4: STP x20, x19, [sp, #0x10]  | stack[1152921513729711264] = ???;  stack[1152921513729711272] = ???;  //  dest_result_addr=1152921513729711264 |  dest_result_addr=1152921513729711272
            // 0x00AD58D8: STP x29, x30, [sp, #0x20]  | stack[1152921513729711280] = ???;  stack[1152921513729711288] = ???;  //  dest_result_addr=1152921513729711280 |  dest_result_addr=1152921513729711288
            // 0x00AD58DC: ADD x29, sp, #0x20         | X29 = (1152921513729711248 + 32) = 1152921513729711280 (0x100000021FC3DCB0);
            // 0x00AD58E0: SUB sp, sp, #0x10          | SP = (1152921513729711248 - 16) = 1152921513729711232 (0x100000021FC3DC80);
            // 0x00AD58E4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD58E8: LDRB w8, [x21, #0x4f5]     | W8 = (bool)static_value_037334F5;       
            // 0x00AD58EC: MOV w20, w1                | W20 = value;//m1                        
            // 0x00AD58F0: MOV x19, x0                | X19 = 1152921513729723296 (0x100000021FC40BA0);//ML01
            // 0x00AD58F4: TBNZ w8, #0, #0xad5910     | if (static_value_037334F5 == true) goto label_0;
            // 0x00AD58F8: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x00AD58FC: LDR x8, [x8, #0x278]       | X8 = 0x2B8FA08;                         
            // 0x00AD5900: LDR w0, [x8]               | W0 = 0x1546;                            
            // 0x00AD5904: BL #0x2782188              | X0 = sub_2782188( ?? 0x1546, ????);     
            // 0x00AD5908: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD590C: STRB w8, [x21, #0x4f5]     | static_value_037334F5 = true;            //  dest_result_addr=57881845
            label_0:
            // 0x00AD5910: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5914: MOV x0, x19                | X0 = 1152921513729723296 (0x100000021FC40BA0);//ML01
            // 0x00AD5918: MOV w1, w20                | W1 = value;//m1                         
            // 0x00AD591C: BL #0x131b510              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD5920: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x00AD5924: LDR x8, [x8, #0x100]       | X8 = 1152921504607858688;               
            // 0x00AD5928: ADD x1, sp, #0xf           | X1 = (1152921513729711232 + 15) = 1152921513729711247 (0x100000021FC3DC8F);
            // 0x00AD592C: STRB w20, [sp, #0xf]       | stack[1152921513729711247] = value;      //  dest_result_addr=1152921513729711247
            // 0x00AD5930: LDR x0, [x8]               | X0 = typeof(System.SByte);              
            // 0x00AD5934: BL #0x27bc028              | X0 = 1152921513729755296 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.SByte), value);
            // 0x00AD5938: MOV x1, x0                 | X1 = 1152921513729755296 (0x100000021FC488A0);//ML01
            // 0x00AD593C: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
            // 0x00AD5940: MOV x0, x19                | X0 = 1152921513729723296 (0x100000021FC40BA0);//ML01
            // 0x00AD5944: BL #0xad5084               | this.AddValue(value:  value, type:  16);
            this.AddValue(value:  value, type:  16);
            // 0x00AD5948: SUB sp, x29, #0x20         | SP = (1152921513729711280 - 32) = 1152921513729711248 (0x100000021FC3DC90);
            // 0x00AD594C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5950: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5954: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5958: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD595C (11360604), len: 148  VirtAddr: 0x00AD595C RVA: 0x00AD595C token: 100684827 methodIndex: 47471 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(decimal value)
        {
            //
            // Disasemble & Code
            // 0x00AD595C: STP x22, x21, [sp, #-0x30]! | stack[1152921513729832464] = ???;  stack[1152921513729832472] = ???;  //  dest_result_addr=1152921513729832464 |  dest_result_addr=1152921513729832472
            // 0x00AD5960: STP x20, x19, [sp, #0x10]  | stack[1152921513729832480] = ???;  stack[1152921513729832488] = ???;  //  dest_result_addr=1152921513729832480 |  dest_result_addr=1152921513729832488
            // 0x00AD5964: STP x29, x30, [sp, #0x20]  | stack[1152921513729832496] = ???;  stack[1152921513729832504] = ???;  //  dest_result_addr=1152921513729832496 |  dest_result_addr=1152921513729832504
            // 0x00AD5968: ADD x29, sp, #0x20         | X29 = (1152921513729832464 + 32) = 1152921513729832496 (0x100000021FC5B630);
            // 0x00AD596C: SUB sp, sp, #0x10          | SP = (1152921513729832464 - 16) = 1152921513729832448 (0x100000021FC5B600);
            // 0x00AD5970: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00AD5974: LDRB w8, [x22, #0x4f6]     | W8 = (bool)static_value_037334F6;       
            // 0x00AD5978: MOV x20, x2                | X20 = value.lo;//m1                     
            // 0x00AD597C: MOV x21, x1                | X21 = value.flags;//m1                  
            // 0x00AD5980: MOV x19, x0                | X19 = 1152921513729844512 (0x100000021FC5E520);//ML01
            // 0x00AD5984: TBNZ w8, #0, #0xad59a0     | if (static_value_037334F6 == true) goto label_0;
            // 0x00AD5988: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x00AD598C: LDR x8, [x8, #0x4a8]       | X8 = 0x2B8FA44;                         
            // 0x00AD5990: LDR w0, [x8]               | W0 = 0x1555;                            
            // 0x00AD5994: BL #0x2782188              | X0 = sub_2782188( ?? 0x1555, ????);     
            // 0x00AD5998: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD599C: STRB w8, [x22, #0x4f6]     | static_value_037334F6 = true;            //  dest_result_addr=57881846
            label_0:
            // 0x00AD59A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD59A4: MOV x0, x19                | X0 = 1152921513729844512 (0x100000021FC5E520);//ML01
            // 0x00AD59A8: MOV x1, x21                | X1 = value.flags;//m1                   
            // 0x00AD59AC: MOV x2, x20                | X2 = value.lo;//m1                      
            // 0x00AD59B0: BL #0x131b5c4              | this.WriteValue(value:  new System.Decimal() {flags = value.flags, hi = value.hi, lo = value.lo, mid = value.mid});
            this.WriteValue(value:  new System.Decimal() {flags = value.flags, hi = value.hi, lo = value.lo, mid = value.mid});
            // 0x00AD59B4: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AD59B8: LDR x8, [x8, #0x480]       | X8 = 1152921504608550912;               
            // 0x00AD59BC: MOV x1, sp                 | X1 = 1152921513729832448 (0x100000021FC5B600);//ML01
            // 0x00AD59C0: LDR x0, [x8]               | X0 = typeof(System.Decimal);            
            // 0x00AD59C4: STP x21, x20, [sp]         | stack[1152921513729832448] = value.flags; stack[1152921513729832452] = value.hi;  stack[1152921513729832456] = value.lo; stack[1152921513729832460] = value.mid;  //  dest_result_addr=1152921513729832448 dest_result_addr=1152921513729832452 |  dest_result_addr=1152921513729832456 dest_result_addr=1152921513729832460
            // 0x00AD59C8: BL #0x27bc028              | X0 = 1152921513729877536 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Decimal), value);
            // 0x00AD59CC: MOV x1, x0                 | X1 = 1152921513729877536 (0x100000021FC66620);//ML01
            // 0x00AD59D0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AD59D4: MOV x0, x19                | X0 = 1152921513729844512 (0x100000021FC5E520);//ML01
            // 0x00AD59D8: BL #0xad5084               | this.AddValue(value:  value, type:  1); 
            this.AddValue(value:  value, type:  1);
            // 0x00AD59DC: SUB sp, x29, #0x20         | SP = (1152921513729832496 - 32) = 1152921513729832464 (0x100000021FC5B610);
            // 0x00AD59E0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD59E4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD59E8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD59EC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD59F0 (11360752), len: 148  VirtAddr: 0x00AD59F0 RVA: 0x00AD59F0 token: 100684828 methodIndex: 47472 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(System.DateTime value)
        {
            //
            // Disasemble & Code
            // 0x00AD59F0: STP x22, x21, [sp, #-0x30]! | stack[1152921513729954704] = ???;  stack[1152921513729954712] = ???;  //  dest_result_addr=1152921513729954704 |  dest_result_addr=1152921513729954712
            // 0x00AD59F4: STP x20, x19, [sp, #0x10]  | stack[1152921513729954720] = ???;  stack[1152921513729954728] = ???;  //  dest_result_addr=1152921513729954720 |  dest_result_addr=1152921513729954728
            // 0x00AD59F8: STP x29, x30, [sp, #0x20]  | stack[1152921513729954736] = ???;  stack[1152921513729954744] = ???;  //  dest_result_addr=1152921513729954736 |  dest_result_addr=1152921513729954744
            // 0x00AD59FC: ADD x29, sp, #0x20         | X29 = (1152921513729954704 + 32) = 1152921513729954736 (0x100000021FC793B0);
            // 0x00AD5A00: SUB sp, sp, #0x10          | SP = (1152921513729954704 - 16) = 1152921513729954688 (0x100000021FC79380);
            // 0x00AD5A04: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00AD5A08: LDRB w8, [x22, #0x4f7]     | W8 = (bool)static_value_037334F7;       
            // 0x00AD5A0C: MOV x20, x2                | X20 = value.kind;//m1                   
            // 0x00AD5A10: MOV x21, x1                | X21 = value.ticks._ticks;//m1           
            // 0x00AD5A14: MOV x19, x0                | X19 = 1152921513729966752 (0x100000021FC7C2A0);//ML01
            // 0x00AD5A18: TBNZ w8, #0, #0xad5a34     | if (static_value_037334F7 == true) goto label_0;
            // 0x00AD5A1C: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x00AD5A20: LDR x8, [x8, #0xa60]       | X8 = 0x2B8FA4C;                         
            // 0x00AD5A24: LDR w0, [x8]               | W0 = 0x1557;                            
            // 0x00AD5A28: BL #0x2782188              | X0 = sub_2782188( ?? 0x1557, ????);     
            // 0x00AD5A2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5A30: STRB w8, [x22, #0x4f7]     | static_value_037334F7 = true;            //  dest_result_addr=57881847
            label_0:
            // 0x00AD5A34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD5A38: MOV x0, x19                | X0 = 1152921513729966752 (0x100000021FC7C2A0);//ML01
            // 0x00AD5A3C: MOV x1, x21                | X1 = value.ticks._ticks;//m1            
            // 0x00AD5A40: MOV x2, x20                | X2 = value.kind;//m1                    
            // 0x00AD5A44: BL #0x131b658              | this.WriteValue(value:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = value.ticks._ticks}, kind = value.kind});
            this.WriteValue(value:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = value.ticks._ticks}, kind = value.kind});
            // 0x00AD5A48: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00AD5A4C: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
            // 0x00AD5A50: MOV x1, sp                 | X1 = 1152921513729954688 (0x100000021FC79380);//ML01
            // 0x00AD5A54: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
            // 0x00AD5A58: STP x21, x20, [sp]         | stack[1152921513729954688] = value.ticks._ticks;  stack[1152921513729954696] = value.kind;  //  dest_result_addr=1152921513729954688 |  dest_result_addr=1152921513729954696
            // 0x00AD5A5C: BL #0x27bc028              | X0 = 1152921513729999776 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.DateTime), value);
            // 0x00AD5A60: MOV x1, x0                 | X1 = 1152921513729999776 (0x100000021FC843A0);//ML01
            // 0x00AD5A64: MOVZ w2, #0x9              | W2 = 9 (0x9);//ML01                     
            // 0x00AD5A68: MOV x0, x19                | X0 = 1152921513729966752 (0x100000021FC7C2A0);//ML01
            // 0x00AD5A6C: BL #0xad5084               | this.AddValue(value:  value, type:  9); 
            this.AddValue(value:  value, type:  9);
            // 0x00AD5A70: SUB sp, x29, #0x20         | SP = (1152921513729954736 - 32) = 1152921513729954704 (0x100000021FC79390);
            // 0x00AD5A74: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5A78: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5A7C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5A80: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5A84 (11360900), len: 168  VirtAddr: 0x00AD5A84 RVA: 0x00AD5A84 token: 100684829 methodIndex: 47473 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(System.DateTimeOffset value)
        {
            //
            // Disasemble & Code
            // 0x00AD5A84: STP x22, x21, [sp, #-0x30]! | stack[1152921513730084048] = ???;  stack[1152921513730084056] = ???;  //  dest_result_addr=1152921513730084048 |  dest_result_addr=1152921513730084056
            // 0x00AD5A88: STP x20, x19, [sp, #0x10]  | stack[1152921513730084064] = ???;  stack[1152921513730084072] = ???;  //  dest_result_addr=1152921513730084064 |  dest_result_addr=1152921513730084072
            // 0x00AD5A8C: STP x29, x30, [sp, #0x20]  | stack[1152921513730084080] = ???;  stack[1152921513730084088] = ???;  //  dest_result_addr=1152921513730084080 |  dest_result_addr=1152921513730084088
            // 0x00AD5A90: ADD x29, sp, #0x20         | X29 = (1152921513730084048 + 32) = 1152921513730084080 (0x100000021FC98CF0);
            // 0x00AD5A94: SUB sp, sp, #0x40          | SP = (1152921513730084048 - 64) = 1152921513730083984 (0x100000021FC98C90);
            // 0x00AD5A98: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD5A9C: LDRB w8, [x21, #0x4f8]     | W8 = (bool)static_value_037334F8;       
            // 0x00AD5AA0: MOV x20, x1                | X20 = 1152921513730128096 (0x100000021FCA38E0);//ML01
            // 0x00AD5AA4: MOV x19, x0                | X19 = 1152921513730096096 (0x100000021FC9BBE0);//ML01
            // 0x00AD5AA8: TBNZ w8, #0, #0xad5ac4     | if (static_value_037334F8 == true) goto label_0;
            // 0x00AD5AAC: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x00AD5AB0: LDR x8, [x8, #0x108]       | X8 = 0x2B8FA50;                         
            // 0x00AD5AB4: LDR w0, [x8]               | W0 = 0x1558;                            
            // 0x00AD5AB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1558, ????);     
            // 0x00AD5ABC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5AC0: STRB w8, [x21, #0x4f8]     | static_value_037334F8 = true;            //  dest_result_addr=57881848
            label_0:
            // 0x00AD5AC4: LDR x8, [x20, #0x10]       | X8 = value.utc_offset._ticks;           
            // 0x00AD5AC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5ACC: ADD x1, sp, #0x20          | X1 = (1152921513730083984 + 32) = 1152921513730084016 (0x100000021FC98CB0);
            // 0x00AD5AD0: MOV x0, x19                | X0 = 1152921513730096096 (0x100000021FC9BBE0);//ML01
            // 0x00AD5AD4: STR x8, [sp, #0x30]        | stack[1152921513730084032] = value.utc_offset._ticks;  //  dest_result_addr=1152921513730084032
            // 0x00AD5AD8: LDR q0, [x20]              | Q0 = value.dt.ticks._ticks;             
            // 0x00AD5ADC: STR q0, [sp, #0x20]        | stack[1152921513730084016] = value.dt.ticks._ticks;  //  dest_result_addr=1152921513730084016
            // 0x00AD5AE0: BL #0x131b834              | this.WriteValue(value:  new System.DateTimeOffset() {dt = new System.DateTime() {ticks = new System.TimeSpan() {_ticks = value.dt.ticks._ticks}}, utc_offset = new System.TimeSpan() {_ticks = value.utc_offset._ticks}});
            this.WriteValue(value:  new System.DateTimeOffset() {dt = new System.DateTime() {ticks = new System.TimeSpan() {_ticks = value.dt.ticks._ticks}}, utc_offset = new System.TimeSpan() {_ticks = value.utc_offset._ticks}});
            // 0x00AD5AE4: LDR x8, [x20, #0x10]       | X8 = value.utc_offset._ticks;           
            // 0x00AD5AE8: MOV x1, sp                 | X1 = 1152921513730083984 (0x100000021FC98C90);//ML01
            // 0x00AD5AEC: STR x8, [sp, #0x10]        | stack[1152921513730084000] = value.utc_offset._ticks;  //  dest_result_addr=1152921513730084000
            // 0x00AD5AF0: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00AD5AF4: LDR q0, [x20]              | Q0 = value.dt.ticks._ticks;             
            // 0x00AD5AF8: LDR x8, [x8, #0x6a8]       | X8 = 1152921504652853248;               
            // 0x00AD5AFC: STR q0, [sp]               | stack[1152921513730083984] = value.dt.ticks._ticks;  //  dest_result_addr=1152921513730083984
            // 0x00AD5B00: LDR x0, [x8]               | X0 = typeof(System.DateTimeOffset);     
            // 0x00AD5B04: BL #0x27bc028              | X0 = 1152921513730136224 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.DateTimeOffset), value.dt.ticks._ticks);
            // 0x00AD5B08: MOV x1, x0                 | X1 = 1152921513730136224 (0x100000021FCA58A0);//ML01
            // 0x00AD5B0C: MOVZ w2, #0x9              | W2 = 9 (0x9);//ML01                     
            // 0x00AD5B10: MOV x0, x19                | X0 = 1152921513730096096 (0x100000021FC9BBE0);//ML01
            // 0x00AD5B14: BL #0xad5084               | this.AddValue(value:  value.dt.ticks._ticks, type:  9);
            this.AddValue(value:  value.dt.ticks._ticks, type:  9);
            // 0x00AD5B18: SUB sp, x29, #0x20         | SP = (1152921513730084080 - 32) = 1152921513730084048 (0x100000021FC98CD0);
            // 0x00AD5B1C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5B20: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5B24: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5B28: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5B2C (11361068), len: 52  VirtAddr: 0x00AD5B2C RVA: 0x00AD5B2C token: 100684830 methodIndex: 47474 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(byte[] value)
        {
            //
            // Disasemble & Code
            // 0x00AD5B2C: STP x20, x19, [sp, #-0x20]! | stack[1152921513730245152] = ???;  stack[1152921513730245160] = ???;  //  dest_result_addr=1152921513730245152 |  dest_result_addr=1152921513730245160
            // 0x00AD5B30: STP x29, x30, [sp, #0x10]  | stack[1152921513730245168] = ???;  stack[1152921513730245176] = ???;  //  dest_result_addr=1152921513730245168 |  dest_result_addr=1152921513730245176
            // 0x00AD5B34: ADD x29, sp, #0x10         | X29 = (1152921513730245152 + 16) = 1152921513730245168 (0x100000021FCC0230);
            // 0x00AD5B38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5B3C: MOV x19, x1                | X19 = value;//m1                        
            // 0x00AD5B40: MOV x20, x0                | X20 = 1152921513730257184 (0x100000021FCC3120);//ML01
            // 0x00AD5B44: BL #0x131b748              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD5B48: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5B4C: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00AD5B50: MOV x0, x20                | X0 = 1152921513730257184 (0x100000021FCC3120);//ML01
            // 0x00AD5B54: MOV x1, x19                | X1 = value;//m1                         
            // 0x00AD5B58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5B5C: B #0xad5084                | this.AddValue(value:  value, type:  5); return;
            this.AddValue(value:  value, type:  5);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5B60 (11361120), len: 188  VirtAddr: 0x00AD5B60 RVA: 0x00AD5B60 token: 100684831 methodIndex: 47475 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(System.Guid value)
        {
            //
            // Disasemble & Code
            // 0x00AD5B60: STP x22, x21, [sp, #-0x30]! | stack[1152921513730394000] = ???;  stack[1152921513730394008] = ???;  //  dest_result_addr=1152921513730394000 |  dest_result_addr=1152921513730394008
            // 0x00AD5B64: STP x20, x19, [sp, #0x10]  | stack[1152921513730394016] = ???;  stack[1152921513730394024] = ???;  //  dest_result_addr=1152921513730394016 |  dest_result_addr=1152921513730394024
            // 0x00AD5B68: STP x29, x30, [sp, #0x20]  | stack[1152921513730394032] = ???;  stack[1152921513730394040] = ???;  //  dest_result_addr=1152921513730394032 |  dest_result_addr=1152921513730394040
            // 0x00AD5B6C: ADD x29, sp, #0x20         | X29 = (1152921513730394000 + 32) = 1152921513730394032 (0x100000021FCE47B0);
            // 0x00AD5B70: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00AD5B74: LDRB w8, [x22, #0x4f9]     | W8 = (bool)static_value_037334F9;       
            // 0x00AD5B78: MOV x20, x2                | X20 = value._d;//m1                     
            // 0x00AD5B7C: MOV x21, x1                | X21 = value._a;//m1                     
            // 0x00AD5B80: MOV x19, x0                | X19 = 1152921513730406048 (0x100000021FCE76A0);//ML01
            // 0x00AD5B84: STP x21, x20, [sp, #-0x10]! | stack[1152921513730393984] = value._a; stack[1152921513730393988] = value._b; stack[1152921513730393990] = value._c;  stack[1152921513730393992] = value._d; stack[1152921513730393993] = value._e; stack[1152921513730393994] = value._f; stack[1152921513730393995] = value._g; stack[1152921513730393996] = value._h; stack[1152921513730393997] = value._i; stack[1152921513730393998] = value._j; stack[1152921513730393999] = value._k;  //  dest_result_addr=1152921513730393984 dest_result_addr=1152921513730393988 dest_result_addr=1152921513730393990 |  dest_result_addr=1152921513730393992 dest_result_addr=1152921513730393993 dest_result_addr=1152921513730393994 dest_result_addr=1152921513730393995 dest_result_addr=1152921513730393996 dest_result_addr=1152921513730393997 dest_result_addr=1152921513730393998 dest_result_addr=1152921513730393999
            // 0x00AD5B88: TBNZ w8, #0, #0xad5ba4     | if (static_value_037334F9 == true) goto label_0;
            // 0x00AD5B8C: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
            // 0x00AD5B90: LDR x8, [x8, #0x570]       | X8 = 0x2B8FA1C;                         
            // 0x00AD5B94: LDR w0, [x8]               | W0 = 0x154B;                            
            // 0x00AD5B98: BL #0x2782188              | X0 = sub_2782188( ?? 0x154B, ????);     
            // 0x00AD5B9C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5BA0: STRB w8, [x22, #0x4f9]     | static_value_037334F9 = true;            //  dest_result_addr=57881849
            label_0:
            // 0x00AD5BA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD5BA8: MOV x0, x19                | X0 = 1152921513730406048 (0x100000021FCE76A0);//ML01
            // 0x00AD5BAC: MOV x1, x21                | X1 = value._a;//m1                      
            // 0x00AD5BB0: MOV x2, x20                | X2 = value._d;//m1                      
            // 0x00AD5BB4: BL #0x131b8e8              | this.WriteValue(value:  new System.Guid() {_a = value._a, _b = value._b, _c = value._c, _d = value._d, _e = value._e, _f = value._f, _g = value._g, _h = value._h, _i = value._i, _j = value._j, _k = value._k});
            this.WriteValue(value:  new System.Guid() {_a = value._a, _b = value._b, _c = value._c, _d = value._d, _e = value._e, _f = value._f, _g = value._g, _h = value._h, _i = value._i, _j = value._j, _k = value._k});
            // 0x00AD5BB8: MOV x0, sp                 | X0 = 1152921513730393984 (0x100000021FCE4780);//ML01
            // 0x00AD5BBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5BC0: BL #0x1c4a2c8              | X0 = label_System_Guid_BaseToString_GL01C4A2C8();
            // 0x00AD5BC4: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00AD5BC8: LDR x8, [x8, #0x188]       | X8 = 1152921504857911296;               
            // 0x00AD5BCC: MOV x20, x0                | X20 = 1152921513730393984 (0x100000021FCE4780);//ML01
            // 0x00AD5BD0: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonString);
            // 0x00AD5BD4: MOV x0, x8                 | X0 = 1152921504857911296 (0x100000000EF6F000);//ML01
            object val_1 = null;
            // 0x00AD5BD8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonString), ????);
            // 0x00AD5BDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5BE0: MOV x21, x0                | X21 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD5BE4: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AD5BE8: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00AD5BEC: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00AD5BF0: MOV x0, x19                | X0 = 1152921513730406048 (0x100000021FCE76A0);//ML01
            // 0x00AD5BF4: MOV x1, x21                | X1 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD5BF8: STR x20, [x21, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = 0x100000021FCE4780;  //  dest_result_addr=1152921504857911328
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = ;
            // 0x00AD5BFC: STRB w8, [x21, #0x28]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 0x2;  //  dest_result_addr=1152921504857911336
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 2;
            // 0x00AD5C00: STRB w9, [x21, #0x30]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0x1;  //  dest_result_addr=1152921504857911344
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 1;
            // 0x00AD5C04: BL #0xad4d30               | this.AddToken(token:  val_1);           
            this.AddToken(token:  val_1);
            // 0x00AD5C08: SUB sp, x29, #0x20         | SP = (1152921513730394032 - 32) = 1152921513730394000 (0x100000021FCE4790);
            // 0x00AD5C0C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5C10: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5C14: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5C18: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5C1C (11361308), len: 180  VirtAddr: 0x00AD5C1C RVA: 0x00AD5C1C token: 100684832 methodIndex: 47476 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(SerializableGuid value)
        {
            //
            // Disasemble & Code
            // 0x00AD5C1C: STP x22, x21, [sp, #-0x30]! | stack[1152921513730510096] = ???;  stack[1152921513730510104] = ???;  //  dest_result_addr=1152921513730510096 |  dest_result_addr=1152921513730510104
            // 0x00AD5C20: STP x20, x19, [sp, #0x10]  | stack[1152921513730510112] = ???;  stack[1152921513730510120] = ???;  //  dest_result_addr=1152921513730510112 |  dest_result_addr=1152921513730510120
            // 0x00AD5C24: STP x29, x30, [sp, #0x20]  | stack[1152921513730510128] = ???;  stack[1152921513730510136] = ???;  //  dest_result_addr=1152921513730510128 |  dest_result_addr=1152921513730510136
            // 0x00AD5C28: ADD x29, sp, #0x20         | X29 = (1152921513730510096 + 32) = 1152921513730510128 (0x100000021FD00D30);
            // 0x00AD5C2C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD5C30: LDRB w8, [x21, #0x4fa]     | W8 = (bool)static_value_037334FA;       
            // 0x00AD5C34: MOV x20, x1                | X20 = value;//m1                        
            // 0x00AD5C38: MOV x19, x0                | X19 = 1152921513730522144 (0x100000021FD03C20);//ML01
            // 0x00AD5C3C: TBNZ w8, #0, #0xad5c58     | if (static_value_037334FA == true) goto label_0;
            // 0x00AD5C40: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x00AD5C44: LDR x8, [x8, #0x788]       | X8 = 0x2B8FA2C;                         
            // 0x00AD5C48: LDR w0, [x8]               | W0 = 0x154F;                            
            // 0x00AD5C4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x154F, ????);     
            // 0x00AD5C50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5C54: STRB w8, [x21, #0x4fa]     | static_value_037334FA = true;            //  dest_result_addr=57881850
            label_0:
            // 0x00AD5C58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5C5C: MOV x0, x19                | X0 = 1152921513730522144 (0x100000021FD03C20);//ML01
            // 0x00AD5C60: MOV x1, x20                | X1 = value;//m1                         
            // 0x00AD5C64: BL #0x131b994              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD5C68: CBNZ x20, #0xad5c70        | if (value != null) goto label_1;        
            if(value != null)
            {
                goto label_1;
            }
            // 0x00AD5C6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00AD5C70: LDR x8, [x20]              | X8 = typeof(SerializableGuid);          
            // 0x00AD5C74: MOV x0, x20                | X0 = value;//m1                         
            // 0x00AD5C78: LDP x9, x1, [x8, #0x140]   | X9 = typeof(SerializableGuid).__il2cppRuntimeField_140; X1 = typeof(SerializableGuid).__il2cppRuntimeField_148; //  | 
            // 0x00AD5C7C: BLR x9                     | X0 = typeof(SerializableGuid).__il2cppRuntimeField_140();
            // 0x00AD5C80: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00AD5C84: LDR x8, [x8, #0x188]       | X8 = 1152921504857911296;               
            // 0x00AD5C88: MOV x20, x0                | X20 = value;//m1                        
            // 0x00AD5C8C: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonString);
            // 0x00AD5C90: MOV x0, x8                 | X0 = 1152921504857911296 (0x100000000EF6F000);//ML01
            object val_1 = null;
            // 0x00AD5C94: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonString), ????);
            // 0x00AD5C98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5C9C: MOV x21, x0                | X21 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD5CA0: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AD5CA4: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00AD5CA8: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00AD5CAC: STRB w9, [x21, #0x30]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0x1;  //  dest_result_addr=1152921504857911344
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 1;
            // 0x00AD5CB0: STR x20, [x21, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = value;  //  dest_result_addr=1152921504857911328
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = value;
            // 0x00AD5CB4: STRB w8, [x21, #0x28]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 0x2;  //  dest_result_addr=1152921504857911336
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 2;
            // 0x00AD5CB8: MOV x0, x19                | X0 = 1152921513730522144 (0x100000021FD03C20);//ML01
            // 0x00AD5CBC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5CC0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5CC4: MOV x1, x21                | X1 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD5CC8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5CCC: B #0xad4d30                | this.AddToken(token:  val_1); return;   
            this.AddToken(token:  val_1);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5CD0 (11361488), len: 184  VirtAddr: 0x00AD5CD0 RVA: 0x00AD5CD0 token: 100684833 methodIndex: 47477 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(System.TimeSpan value)
        {
            //
            // Disasemble & Code
            // 0x00AD5CD0: STP x22, x21, [sp, #-0x30]! | stack[1152921513730626192] = ???;  stack[1152921513730626200] = ???;  //  dest_result_addr=1152921513730626192 |  dest_result_addr=1152921513730626200
            // 0x00AD5CD4: STP x20, x19, [sp, #0x10]  | stack[1152921513730626208] = ???;  stack[1152921513730626216] = ???;  //  dest_result_addr=1152921513730626208 |  dest_result_addr=1152921513730626216
            // 0x00AD5CD8: STP x29, x30, [sp, #0x20]  | stack[1152921513730626224] = ???;  stack[1152921513730626232] = ???;  //  dest_result_addr=1152921513730626224 |  dest_result_addr=1152921513730626232
            // 0x00AD5CDC: ADD x29, sp, #0x20         | X29 = (1152921513730626192 + 32) = 1152921513730626224 (0x100000021FD1D2B0);
            // 0x00AD5CE0: SUB sp, sp, #0x10          | SP = (1152921513730626192 - 16) = 1152921513730626176 (0x100000021FD1D280);
            // 0x00AD5CE4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD5CE8: LDRB w8, [x21, #0x4fb]     | W8 = (bool)static_value_037334FB;       
            // 0x00AD5CEC: MOV x20, x1                | X20 = value._ticks;//m1                 
            // 0x00AD5CF0: MOV x19, x0                | X19 = 1152921513730638240 (0x100000021FD201A0);//ML01
            // 0x00AD5CF4: STR x20, [sp, #8]          | stack[1152921513730626184] = value._ticks;  //  dest_result_addr=1152921513730626184
            // 0x00AD5CF8: TBNZ w8, #0, #0xad5d14     | if (static_value_037334FB == true) goto label_0;
            // 0x00AD5CFC: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x00AD5D00: LDR x8, [x8, #0x5f8]       | X8 = 0x2B8FA24;                         
            // 0x00AD5D04: LDR w0, [x8]               | W0 = 0x154D;                            
            // 0x00AD5D08: BL #0x2782188              | X0 = sub_2782188( ?? 0x154D, ????);     
            // 0x00AD5D0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5D10: STRB w8, [x21, #0x4fb]     | static_value_037334FB = true;            //  dest_result_addr=57881851
            label_0:
            // 0x00AD5D14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5D18: MOV x0, x19                | X0 = 1152921513730638240 (0x100000021FD201A0);//ML01
            // 0x00AD5D1C: MOV x1, x20                | X1 = value._ticks;//m1                  
            // 0x00AD5D20: BL #0x131ba40              | this.WriteValue(value:  new System.TimeSpan() {_ticks = value._ticks});
            this.WriteValue(value:  new System.TimeSpan() {_ticks = value._ticks});
            // 0x00AD5D24: ADD x0, sp, #8             | X0 = (1152921513730626176 + 8) = 1152921513730626184 (0x100000021FD1D288);
            // 0x00AD5D28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5D2C: BL #0x1b6b1c4              | X0 = label_System_TimeSpan_Subtract_GL01B6B1C4();
            // 0x00AD5D30: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00AD5D34: LDR x8, [x8, #0x188]       | X8 = 1152921504857911296;               
            // 0x00AD5D38: MOV x20, x0                | X20 = 1152921513730626184 (0x100000021FD1D288);//ML01
            // 0x00AD5D3C: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonString);
            // 0x00AD5D40: MOV x0, x8                 | X0 = 1152921504857911296 (0x100000000EF6F000);//ML01
            object val_1 = null;
            // 0x00AD5D44: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonString), ????);
            // 0x00AD5D48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5D4C: MOV x21, x0                | X21 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD5D50: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AD5D54: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00AD5D58: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00AD5D5C: MOV x0, x19                | X0 = 1152921513730638240 (0x100000021FD201A0);//ML01
            // 0x00AD5D60: MOV x1, x21                | X1 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD5D64: STR x20, [x21, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = 0x100000021FD1D288;  //  dest_result_addr=1152921504857911328
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = ;
            // 0x00AD5D68: STRB w8, [x21, #0x28]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 0x2;  //  dest_result_addr=1152921504857911336
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 2;
            // 0x00AD5D6C: STRB w9, [x21, #0x30]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0x1;  //  dest_result_addr=1152921504857911344
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 1;
            // 0x00AD5D70: BL #0xad4d30               | this.AddToken(token:  val_1);           
            this.AddToken(token:  val_1);
            // 0x00AD5D74: SUB sp, x29, #0x20         | SP = (1152921513730626224 - 32) = 1152921513730626192 (0x100000021FD1D290);
            // 0x00AD5D78: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5D7C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5D80: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5D84: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5D88 (11361672), len: 180  VirtAddr: 0x00AD5D88 RVA: 0x00AD5D88 token: 100684834 methodIndex: 47478 delegateWrapperIndex: 0 methodInvoker: 0
        public override void WriteValue(System.Uri value)
        {
            //
            // Disasemble & Code
            // 0x00AD5D88: STP x22, x21, [sp, #-0x30]! | stack[1152921513730742288] = ???;  stack[1152921513730742296] = ???;  //  dest_result_addr=1152921513730742288 |  dest_result_addr=1152921513730742296
            // 0x00AD5D8C: STP x20, x19, [sp, #0x10]  | stack[1152921513730742304] = ???;  stack[1152921513730742312] = ???;  //  dest_result_addr=1152921513730742304 |  dest_result_addr=1152921513730742312
            // 0x00AD5D90: STP x29, x30, [sp, #0x20]  | stack[1152921513730742320] = ???;  stack[1152921513730742328] = ???;  //  dest_result_addr=1152921513730742320 |  dest_result_addr=1152921513730742328
            // 0x00AD5D94: ADD x29, sp, #0x20         | X29 = (1152921513730742288 + 32) = 1152921513730742320 (0x100000021FD39830);
            // 0x00AD5D98: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD5D9C: LDRB w8, [x21, #0x4fc]     | W8 = (bool)static_value_037334FC;       
            // 0x00AD5DA0: MOV x20, x1                | X20 = value;//m1                        
            // 0x00AD5DA4: MOV x19, x0                | X19 = 1152921513730754336 (0x100000021FD3C720);//ML01
            // 0x00AD5DA8: TBNZ w8, #0, #0xad5dc4     | if (static_value_037334FC == true) goto label_0;
            // 0x00AD5DAC: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x00AD5DB0: LDR x8, [x8, #0x6e8]       | X8 = 0x2B8FA18;                         
            // 0x00AD5DB4: LDR w0, [x8]               | W0 = 0x154A;                            
            // 0x00AD5DB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x154A, ????);     
            // 0x00AD5DBC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5DC0: STRB w8, [x21, #0x4fc]     | static_value_037334FC = true;            //  dest_result_addr=57881852
            label_0:
            // 0x00AD5DC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5DC8: MOV x0, x19                | X0 = 1152921513730754336 (0x100000021FD3C720);//ML01
            // 0x00AD5DCC: MOV x1, x20                | X1 = value;//m1                         
            // 0x00AD5DD0: BL #0x131baec              | this.WriteValue(value:  value);         
            this.WriteValue(value:  value);
            // 0x00AD5DD4: CBNZ x20, #0xad5ddc        | if (value != null) goto label_1;        
            if(value != null)
            {
                goto label_1;
            }
            // 0x00AD5DD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00AD5DDC: LDR x8, [x20]              | X8 = typeof(System.Uri);                
            // 0x00AD5DE0: MOV x0, x20                | X0 = value;//m1                         
            // 0x00AD5DE4: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Uri).__il2cppRuntimeField_140; X1 = typeof(System.Uri).__il2cppRuntimeField_148; //  | 
            // 0x00AD5DE8: BLR x9                     | X0 = typeof(System.Uri).__il2cppRuntimeField_140();
            // 0x00AD5DEC: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00AD5DF0: LDR x8, [x8, #0x188]       | X8 = 1152921504857911296;               
            // 0x00AD5DF4: MOV x20, x0                | X20 = value;//m1                        
            // 0x00AD5DF8: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonString);
            // 0x00AD5DFC: MOV x0, x8                 | X0 = 1152921504857911296 (0x100000000EF6F000);//ML01
            object val_1 = null;
            // 0x00AD5E00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonString), ????);
            // 0x00AD5E04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD5E08: MOV x21, x0                | X21 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD5E0C: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AD5E10: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00AD5E14: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00AD5E18: STRB w9, [x21, #0x30]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0x1;  //  dest_result_addr=1152921504857911344
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 1;
            // 0x00AD5E1C: STR x20, [x21, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = value;  //  dest_result_addr=1152921504857911328
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = value;
            // 0x00AD5E20: STRB w8, [x21, #0x28]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 0x2;  //  dest_result_addr=1152921504857911336
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 2;
            // 0x00AD5E24: MOV x0, x19                | X0 = 1152921513730754336 (0x100000021FD3C720);//ML01
            // 0x00AD5E28: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5E2C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5E30: MOV x1, x21                | X1 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD5E34: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5E38: B #0xad4d30                | this.AddToken(token:  val_1); return;   
            this.AddToken(token:  val_1);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5E3C (11361852), len: 216  VirtAddr: 0x00AD5E3C RVA: 0x00AD5E3C token: 100684835 methodIndex: 47479 delegateWrapperIndex: 0 methodInvoker: 0
        public void WriteObjectId(byte[] value)
        {
            //
            // Disasemble & Code
            // 0x00AD5E3C: STP x22, x21, [sp, #-0x30]! | stack[1152921513730896400] = ???;  stack[1152921513730896408] = ???;  //  dest_result_addr=1152921513730896400 |  dest_result_addr=1152921513730896408
            // 0x00AD5E40: STP x20, x19, [sp, #0x10]  | stack[1152921513730896416] = ???;  stack[1152921513730896424] = ???;  //  dest_result_addr=1152921513730896416 |  dest_result_addr=1152921513730896424
            // 0x00AD5E44: STP x29, x30, [sp, #0x20]  | stack[1152921513730896432] = ???;  stack[1152921513730896440] = ???;  //  dest_result_addr=1152921513730896432 |  dest_result_addr=1152921513730896440
            // 0x00AD5E48: ADD x29, sp, #0x20         | X29 = (1152921513730896400 + 32) = 1152921513730896432 (0x100000021FD5F230);
            // 0x00AD5E4C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD5E50: LDRB w8, [x21, #0x4fd]     | W8 = (bool)static_value_037334FD;       
            // 0x00AD5E54: MOV x19, x1                | X19 = value;//m1                        
            // 0x00AD5E58: MOV x20, x0                | X20 = 1152921513730908448 (0x100000021FD62120);//ML01
            // 0x00AD5E5C: TBNZ w8, #0, #0xad5e78     | if (static_value_037334FD == true) goto label_0;
            // 0x00AD5E60: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00AD5E64: LDR x8, [x8, #0x450]       | X8 = 0x2B8F9E8;                         
            // 0x00AD5E68: LDR w0, [x8]               | W0 = 0x153E;                            
            // 0x00AD5E6C: BL #0x2782188              | X0 = sub_2782188( ?? 0x153E, ????);     
            // 0x00AD5E70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5E74: STRB w8, [x21, #0x4fd]     | static_value_037334FD = true;            //  dest_result_addr=57881853
            label_0:
            // 0x00AD5E78: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00AD5E7C: LDR x8, [x8, #0x400]       | X8 = (string**)(1152921511191786896)("value");
            // 0x00AD5E80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD5E84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD5E88: MOV x1, x19                | X1 = value;//m1                         
            // 0x00AD5E8C: LDR x2, [x8]               | X2 = "value";                           
            // 0x00AD5E90: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  value);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  value);
            // 0x00AD5E94: CBNZ x19, #0xad5e9c        | if (value != null) goto label_1;        
            if(value != null)
            {
                goto label_1;
            }
            // 0x00AD5E98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_1:
            // 0x00AD5E9C: LDR w8, [x19, #0x18]       | W8 = value.Length; //P2                 
            // 0x00AD5EA0: CMP w8, #0xc               | STATE = COMPARE(value.Length, 0xC)      
            // 0x00AD5EA4: B.NE #0xad5ed4             | if (value.Length != 12) goto label_2;   
            if(value.Length != 12)
            {
                goto label_2;
            }
            // 0x00AD5EA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5EAC: ORR w1, wzr, #0xc          | W1 = 12(0xC);                           
            // 0x00AD5EB0: MOV x0, x20                | X0 = 1152921513730908448 (0x100000021FD62120);//ML01
            // 0x00AD5EB4: BL #0x1322e48              | this.AutoComplete(tokenBeingWritten:  12);
            this.AutoComplete(tokenBeingWritten:  12);
            // 0x00AD5EB8: MOV x0, x20                | X0 = 1152921513730908448 (0x100000021FD62120);//ML01
            // 0x00AD5EBC: MOV x1, x19                | X1 = value;//m1                         
            // 0x00AD5EC0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5EC4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5EC8: ORR w2, wzr, #7            | W2 = 7(0x7);                            
            // 0x00AD5ECC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5ED0: B #0xad5084                | this.AddValue(value:  value, type:  7); return;
            this.AddValue(value:  value, type:  7);
            return;
            label_2:
            // 0x00AD5ED4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00AD5ED8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x00AD5EDC: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_1 = null;
            // 0x00AD5EE0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x00AD5EE4: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
            // 0x00AD5EE8: LDR x8, [x8, #0x5e0]       | X8 = (string**)(1152921513730883296)("An object id must be 12 bytes");
            // 0x00AD5EEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5EF0: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00AD5EF4: LDR x1, [x8]               | X1 = "An object id must be 12 bytes";   
            // 0x00AD5EF8: BL #0x1c32b48              | .ctor(message:  "An object id must be 12 bytes");
            val_1 = new System.Exception(message:  "An object id must be 12 bytes");
            // 0x00AD5EFC: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00AD5F00: LDR x8, [x8, #0xd60]       | X8 = 1152921513730883424;               
            // 0x00AD5F04: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00AD5F08: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Bson.BsonWriter::WriteObjectId(byte[] value);
            // 0x00AD5F0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x00AD5F10: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD5F14 (11362068), len: 164  VirtAddr: 0x00AD5F14 RVA: 0x00AD5F14 token: 100684836 methodIndex: 47480 delegateWrapperIndex: 0 methodInvoker: 0
        public void WriteRegex(string pattern, string options)
        {
            //
            // Disasemble & Code
            // 0x00AD5F14: STP x22, x21, [sp, #-0x30]! | stack[1152921513731053552] = ???;  stack[1152921513731053560] = ???;  //  dest_result_addr=1152921513731053552 |  dest_result_addr=1152921513731053560
            // 0x00AD5F18: STP x20, x19, [sp, #0x10]  | stack[1152921513731053568] = ???;  stack[1152921513731053576] = ???;  //  dest_result_addr=1152921513731053568 |  dest_result_addr=1152921513731053576
            // 0x00AD5F1C: STP x29, x30, [sp, #0x20]  | stack[1152921513731053584] = ???;  stack[1152921513731053592] = ???;  //  dest_result_addr=1152921513731053584 |  dest_result_addr=1152921513731053592
            // 0x00AD5F20: ADD x29, sp, #0x20         | X29 = (1152921513731053552 + 32) = 1152921513731053584 (0x100000021FD85810);
            // 0x00AD5F24: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00AD5F28: LDRB w8, [x22, #0x4fe]     | W8 = (bool)static_value_037334FE;       
            // 0x00AD5F2C: MOV x19, x2                | X19 = options;//m1                      
            // 0x00AD5F30: MOV x21, x1                | X21 = pattern;//m1                      
            // 0x00AD5F34: MOV x20, x0                | X20 = 1152921513731065600 (0x100000021FD88700);//ML01
            // 0x00AD5F38: TBNZ w8, #0, #0xad5f54     | if (static_value_037334FE == true) goto label_0;
            // 0x00AD5F3C: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x00AD5F40: LDR x8, [x8, #0xc50]       | X8 = 0x2B8F9F4;                         
            // 0x00AD5F44: LDR w0, [x8]               | W0 = 0x1541;                            
            // 0x00AD5F48: BL #0x2782188              | X0 = sub_2782188( ?? 0x1541, ????);     
            // 0x00AD5F4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD5F50: STRB w8, [x22, #0x4fe]     | static_value_037334FE = true;            //  dest_result_addr=57881854
            label_0:
            // 0x00AD5F54: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00AD5F58: LDR x8, [x8, #0x968]       | X8 = (string**)(1152921513731041504)("pattern");
            // 0x00AD5F5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD5F60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD5F64: MOV x1, x21                | X1 = pattern;//m1                       
            // 0x00AD5F68: LDR x2, [x8]               | X2 = "pattern";                         
            // 0x00AD5F6C: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  pattern);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  pattern);
            // 0x00AD5F70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD5F74: ORR w1, wzr, #0xc          | W1 = 12(0xC);                           
            // 0x00AD5F78: MOV x0, x20                | X0 = 1152921513731065600 (0x100000021FD88700);//ML01
            // 0x00AD5F7C: BL #0x1322e48              | this.AutoComplete(tokenBeingWritten:  12);
            this.AutoComplete(tokenBeingWritten:  12);
            // 0x00AD5F80: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x00AD5F84: LDR x8, [x8, #0x98]        | X8 = 1152921504857964544;               
            // 0x00AD5F88: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonRegex);
            Newtonsoft.Json.Bson.BsonRegex val_1 = null;
            // 0x00AD5F8C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonRegex), ????);
            // 0x00AD5F90: MOV x1, x21                | X1 = pattern;//m1                       
            // 0x00AD5F94: MOV x2, x19                | X2 = options;//m1                       
            // 0x00AD5F98: MOV x22, x0                | X22 = 1152921504857964544 (0x100000000EF7C000);//ML01
            // 0x00AD5F9C: BL #0xad46c4               | .ctor(pattern:  pattern, options:  options);
            val_1 = new Newtonsoft.Json.Bson.BsonRegex(pattern:  pattern, options:  options);
            // 0x00AD5FA0: MOV x0, x20                | X0 = 1152921513731065600 (0x100000021FD88700);//ML01
            // 0x00AD5FA4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD5FA8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD5FAC: MOV x1, x22                | X1 = 1152921504857964544 (0x100000000EF7C000);//ML01
            // 0x00AD5FB0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD5FB4: B #0xad4d30                | this.AddToken(token:  val_1); return;   
            this.AddToken(token:  val_1);
            return;
        
        }
    
    }

}
