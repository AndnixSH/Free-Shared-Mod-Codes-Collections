using UnityEngine;

namespace Entity.Behavior
{
    public class CheckTargetBvr : IBehavior
    {
        // Fields
        private System.Collections.Generic.List<CombatEntity> targetMonsters; //  0x00000020
        private CombatEntity targetMonster; //  0x00000028
        
        // Properties
        public override Entity.Behavior.EBehaviorID id { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00EB3A4C (15415884), len: 8  VirtAddr: 0x00EB3A4C RVA: 0x00EB3A4C token: 100691433 methodIndex: 27239 delegateWrapperIndex: 0 methodInvoker: 0
        public CheckTargetBvr()
        {
            //
            // Disasemble & Code
            // 0x00EB3A4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3A50: B #0x16f59f0               | this..ctor(); return;                   
            val_1 = new System.Object();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00EB3A5C (15415900), len: 8  VirtAddr: 0x00EB3A5C RVA: 0x00EB3A5C token: 100691434 methodIndex: 27240 delegateWrapperIndex: 0 methodInvoker: 0
        public override Entity.Behavior.EBehaviorID get_id()
        {
            //
            // Disasemble & Code
            // 0x00EB3A5C: ORR w0, wzr, #0xe          | W0 = 14(0xE);                           
            // 0x00EB3A60: RET                        |  return (Entity.Behavior.EBehaviorID)0xE;
            return (Entity.Behavior.EBehaviorID)14;
            //  |  // // {name=val_0, type=Entity.Behavior.EBehaviorID, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00EB3A64 (15415908), len: 4  VirtAddr: 0x00EB3A64 RVA: 0x00EB3A64 token: 100691435 methodIndex: 27241 delegateWrapperIndex: 0 methodInvoker: 0
        public override void SetParams(object[] args)
        {
            //
            // Disasemble & Code
            // 0x00EB3A64: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00EB3A68 (15415912), len: 12  VirtAddr: 0x00EB3A68 RVA: 0x00EB3A68 token: 100691436 methodIndex: 27242 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Reason()
        {
            //
            // Disasemble & Code
            // 0x00EB3A68: LDR x8, [x0]               | X8 = typeof(Entity.Behavior.CheckTargetBvr);
            // 0x00EB3A6C: LDP x2, x1, [x8, #0x180]   | X2 = typeof(Entity.Behavior.CheckTargetBvr).__il2cppRuntimeField_180; X1 = typeof(Entity.Behavior.CheckTargetBvr).__il2cppRuntimeField_188; //  | 
            // 0x00EB3A70: BR x2                      | goto typeof(Entity.Behavior.CheckTargetBvr).__il2cppRuntimeField_180;
            goto typeof(Entity.Behavior.CheckTargetBvr).__il2cppRuntimeField_180;
        
        }
        //
        // Offset in libil2cpp.so: 0x00EB3A74 (15415924), len: 4  VirtAddr: 0x00EB3A74 RVA: 0x00EB3A74 token: 100691437 methodIndex: 27243 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Action()
        {
            //
            // Disasemble & Code
            // 0x00EB3A74: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00EB3A78 (15415928), len: 916  VirtAddr: 0x00EB3A78 RVA: 0x00EB3A78 token: 100691438 methodIndex: 27244 delegateWrapperIndex: 0 methodInvoker: 0
        public override void DoEntering()
        {
            //
            // Disasemble & Code
            //  | 
            var val_16;
            //  | 
            float val_17;
            //  | 
            CombatEntity val_18;
            // 0x00EB3A78: STP d13, d12, [sp, #-0x60]! | stack[1152921514660310784] = ???;  stack[1152921514660310792] = ???;  //  dest_result_addr=1152921514660310784 |  dest_result_addr=1152921514660310792
            // 0x00EB3A7C: STP d11, d10, [sp, #0x10]  | stack[1152921514660310800] = ???;  stack[1152921514660310808] = ???;  //  dest_result_addr=1152921514660310800 |  dest_result_addr=1152921514660310808
            // 0x00EB3A80: STP d9, d8, [sp, #0x20]    | stack[1152921514660310816] = ???;  stack[1152921514660310824] = ???;  //  dest_result_addr=1152921514660310816 |  dest_result_addr=1152921514660310824
            // 0x00EB3A84: STP x22, x21, [sp, #0x30]  | stack[1152921514660310832] = ???;  stack[1152921514660310840] = ???;  //  dest_result_addr=1152921514660310832 |  dest_result_addr=1152921514660310840
            // 0x00EB3A88: STP x20, x19, [sp, #0x40]  | stack[1152921514660310848] = ???;  stack[1152921514660310856] = ???;  //  dest_result_addr=1152921514660310848 |  dest_result_addr=1152921514660310856
            // 0x00EB3A8C: STP x29, x30, [sp, #0x50]  | stack[1152921514660310864] = ???;  stack[1152921514660310872] = ???;  //  dest_result_addr=1152921514660310864 |  dest_result_addr=1152921514660310872
            // 0x00EB3A90: ADD x29, sp, #0x50         | X29 = (1152921514660310784 + 80) = 1152921514660310864 (0x10000002573BAF50);
            // 0x00EB3A94: SUB sp, sp, #0x10          | SP = (1152921514660310784 - 16) = 1152921514660310768 (0x10000002573BAEF0);
            // 0x00EB3A98: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00EB3A9C: LDRB w8, [x20, #0xdac]     | W8 = (bool)static_value_03734DAC;       
            // 0x00EB3AA0: MOV x19, x0                | X19 = 1152921514660322880 (0x10000002573BDE40);//ML01
            val_16 = this;
            // 0x00EB3AA4: TBNZ w8, #0, #0xeb3ac0     | if (static_value_03734DAC == true) goto label_0;
            // 0x00EB3AA8: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x00EB3AAC: LDR x8, [x8, #0xf60]       | X8 = 0x2B90A7C;                         
            // 0x00EB3AB0: LDR w0, [x8]               | W0 = 0x1963;                            
            // 0x00EB3AB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1963, ????);     
            // 0x00EB3AB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00EB3ABC: STRB w8, [x20, #0xdac]     | static_value_03734DAC = true;            //  dest_result_addr=57888172
            label_0:
            // 0x00EB3AC0: ADRP x22, #0x35fe000       | X22 = 56614912 (0x35FE000);             
            // 0x00EB3AC4: LDR x22, [x22, #0x810]     | X22 = 1152921504697475072;              
            // 0x00EB3AC8: LDR x20, [x19, #0x28]      | X20 = this.targetMonster; //P2          
            // 0x00EB3ACC: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
            // 0x00EB3AD0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x00EB3AD4: TBZ w8, #0, #0xeb3ae4      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00EB3AD8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x00EB3ADC: CBNZ w8, #0xeb3ae4         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00EB3AE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_2:
            // 0x00EB3AE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00EB3AE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3AEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00EB3AF0: MOV x2, x20                | X2 = this.targetMonster;//m1            
            // 0x00EB3AF4: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  0);
            bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  0);
            // 0x00EB3AF8: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x00EB3AFC: TBZ w8, #0, #0xeb3b3c      | if ((val_1 & 1) == false) goto label_3; 
            if(val_2 == false)
            {
                goto label_3;
            }
            // 0x00EB3B00: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00EB3B04: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
            // 0x00EB3B08: LDR x21, [x19, #0x10]      | 
            // 0x00EB3B0C: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
            // 0x00EB3B10: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
            // 0x00EB3B14: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
            // 0x00EB3B18: CBNZ x20, #0xeb3b20        | if (GameMgr.UPDATEOnOffEffect != null) goto label_4;
            if(GameMgr.UPDATEOnOffEffect != null)
            {
                goto label_4;
            }
            // 0x00EB3B1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00EB3B20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00EB3B24: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
            // 0x00EB3B28: MOV x1, x21                | X1 = X21;//m1                           
            // 0x00EB3B2C: BL #0xc1876c               | X0 = GameMgr.UPDATEOnOffEffect.GetNearestEnemy(unit:  X21);
            CombatEntity val_3 = GameMgr.UPDATEOnOffEffect.GetNearestEnemy(unit:  X21);
            // 0x00EB3B30: MOV x20, x0                | X20 = val_3;//m1                        
            val_18 = val_3;
            // 0x00EB3B34: STR x20, [x19, #0x28]      | this.targetMonster = val_3;              //  dest_result_addr=1152921514660322920
            this.targetMonster = val_18;
            // 0x00EB3B38: B #0xeb3b40                |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x00EB3B3C: LDR x20, [x19, #0x28]      | X20 = this.targetMonster; //P2          
            val_18 = this.targetMonster;
            label_5:
            // 0x00EB3B40: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
            // 0x00EB3B44: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x00EB3B48: TBZ w8, #0, #0xeb3b58      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00EB3B4C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x00EB3B50: CBNZ w8, #0xeb3b58         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00EB3B54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_7:
            // 0x00EB3B58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00EB3B5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00EB3B60: MOV x1, x20                | X1 = this.targetMonster;//m1            
            // 0x00EB3B64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00EB3B68: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_18);
            bool val_4 = UnityEngine.Object.op_Inequality(x:  0, y:  val_18);
            // 0x00EB3B6C: TBZ w0, #0, #0xeb3d90      | if (val_4 == false) goto label_8;       
            if(val_4 == false)
            {
                goto label_8;
            }
            // 0x00EB3B70: LDR x20, [x19, #0x10]      | 
            // 0x00EB3B74: LDR x21, [x19, #0x28]      | X21 = this.targetMonster; //P2          
            // 0x00EB3B78: CBNZ x20, #0xeb3b80        | if (this.targetMonster != null) goto label_9;
            if(val_18 != null)
            {
                goto label_9;
            }
            // 0x00EB3B7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_9:
            // 0x00EB3B80: LDR x8, [x20]              | X8 = typeof(CombatEntity);              
            // 0x00EB3B84: MOV x0, x20                | X0 = this.targetMonster;//m1            
            // 0x00EB3B88: MOV x1, x21                | X1 = this.targetMonster;//m1            
            // 0x00EB3B8C: LDR x9, [x8, #0x230]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_230;
            // 0x00EB3B90: LDR x2, [x8, #0x238]       | X2 = typeof(CombatEntity).__il2cppRuntimeField_238;
            // 0x00EB3B94: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_230();
            // 0x00EB3B98: LDR x20, [x19, #0x10]      | 
            // 0x00EB3B9C: CBNZ x20, #0xeb3ba4        | if (this.targetMonster != null) goto label_10;
            if(val_18 != null)
            {
                goto label_10;
            }
            // 0x00EB3BA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.targetMonster, ????);
            label_10:
            // 0x00EB3BA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3BA8: MOV x0, x20                | X0 = this.targetMonster;//m1            
            // 0x00EB3BAC: BL #0x20d5094              | X0 = this.targetMonster.get_transform();
            UnityEngine.Transform val_5 = val_18.transform;
            // 0x00EB3BB0: MOV x20, x0                | X20 = val_5;//m1                        
            // 0x00EB3BB4: CBNZ x20, #0xeb3bbc        | if (val_5 != null) goto label_11;       
            if(val_5 != null)
            {
                goto label_11;
            }
            // 0x00EB3BB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_11:
            // 0x00EB3BBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3BC0: MOV x0, x20                | X0 = val_5;//m1                         
            // 0x00EB3BC4: BL #0x2693510              | X0 = val_5.get_position();              
            UnityEngine.Vector3 val_6 = val_5.position;
            // 0x00EB3BC8: LDR x20, [x19, #0x28]      | X20 = this.targetMonster; //P2          
            // 0x00EB3BCC: MOV v8.16b, v0.16b         | V8 = val_6.x;//m1                       
            // 0x00EB3BD0: MOV v9.16b, v1.16b         | V9 = val_6.y;//m1                       
            // 0x00EB3BD4: MOV v10.16b, v2.16b        | V10 = val_6.z;//m1                      
            // 0x00EB3BD8: CBNZ x20, #0xeb3be0        | if (this.targetMonster != null) goto label_12;
            if(this.targetMonster != null)
            {
                goto label_12;
            }
            // 0x00EB3BDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x00EB3BE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3BE4: MOV x0, x20                | X0 = this.targetMonster;//m1            
            // 0x00EB3BE8: BL #0x20d5094              | X0 = this.targetMonster.get_transform();
            UnityEngine.Transform val_7 = this.targetMonster.transform;
            // 0x00EB3BEC: MOV x20, x0                | X20 = val_7;//m1                        
            // 0x00EB3BF0: CBNZ x20, #0xeb3bf8        | if (val_7 != null) goto label_13;       
            if(val_7 != null)
            {
                goto label_13;
            }
            // 0x00EB3BF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_13:
            // 0x00EB3BF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3BFC: MOV x0, x20                | X0 = val_7;//m1                         
            // 0x00EB3C00: BL #0x2693510              | X0 = val_7.get_position();              
            UnityEngine.Vector3 val_8 = val_7.position;
            // 0x00EB3C04: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x00EB3C08: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x00EB3C0C: MOV v11.16b, v0.16b        | V11 = val_8.x;//m1                      
            // 0x00EB3C10: MOV v12.16b, v1.16b        | V12 = val_8.y;//m1                      
            // 0x00EB3C14: MOV v13.16b, v2.16b        | V13 = val_8.z;//m1                      
            // 0x00EB3C18: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x00EB3C1C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x00EB3C20: TBZ w8, #0, #0xeb3c30      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00EB3C24: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x00EB3C28: CBNZ w8, #0xeb3c30         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00EB3C2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_15:
            // 0x00EB3C30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00EB3C34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3C38: MOV v0.16b, v8.16b         | V0 = val_6.x;//m1                       
            // 0x00EB3C3C: MOV v1.16b, v9.16b         | V1 = val_6.y;//m1                       
            // 0x00EB3C40: MOV v2.16b, v10.16b        | V2 = val_6.z;//m1                       
            // 0x00EB3C44: MOV v3.16b, v11.16b        | V3 = val_8.x;//m1                       
            // 0x00EB3C48: MOV v4.16b, v12.16b        | V4 = val_8.y;//m1                       
            // 0x00EB3C4C: MOV v5.16b, v13.16b        | V5 = val_8.z;//m1                       
            // 0x00EB3C50: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
            float val_9 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
            // 0x00EB3C54: LDR x20, [x19, #0x10]      | 
            // 0x00EB3C58: MOV v8.16b, v0.16b         | V8 = val_9;//m1                         
            // 0x00EB3C5C: CBNZ x20, #0xeb3c64        | if (val_7 != null) goto label_16;       
            if(val_7 != null)
            {
                goto label_16;
            }
            // 0x00EB3C60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_16:
            // 0x00EB3C64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3C68: MOV x0, x20                | X0 = val_7;//m1                         
            // 0x00EB3C6C: BL #0xd8ae48               | X0 = val_7.get_atkRange();              
            float val_10 = val_7.atkRange;
            // 0x00EB3C70: LDR x20, [x19, #0x10]      | 
            // 0x00EB3C74: MOV v9.16b, v0.16b         | V9 = val_10;//m1                        
            float val_16 = val_10;
            // 0x00EB3C78: CBNZ x20, #0xeb3c80        | if (val_7 != null) goto label_17;       
            if(val_7 != null)
            {
                goto label_17;
            }
            // 0x00EB3C7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_17:
            // 0x00EB3C80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3C84: MOV x0, x20                | X0 = val_7;//m1                         
            // 0x00EB3C88: BL #0xd89b00               | X0 = val_7.get_halfwidth();             
            float val_11 = val_7.halfwidth;
            // 0x00EB3C8C: LDR x20, [x19, #0x28]      | X20 = this.targetMonster; //P2          
            // 0x00EB3C90: MOV v10.16b, v0.16b        | V10 = val_11;//m1                       
            // 0x00EB3C94: CBNZ x20, #0xeb3c9c        | if (this.targetMonster != null) goto label_18;
            if(this.targetMonster != null)
            {
                goto label_18;
            }
            // 0x00EB3C98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_18:
            // 0x00EB3C9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3CA0: MOV x0, x20                | X0 = this.targetMonster;//m1            
            // 0x00EB3CA4: BL #0xd89b00               | X0 = this.targetMonster.get_halfwidth();
            float val_12 = this.targetMonster.halfwidth;
            // 0x00EB3CA8: LDR x20, [x19, #0x10]      | 
            // 0x00EB3CAC: FADD s1, s9, s10           | S1 = (val_10 + val_11);                 
            float val_13 = val_16 + val_11;
            // 0x00EB3CB0: FADD s9, s1, s0            | S9 = ((val_10 + val_11) + val_12);      
            val_16 = val_13 + val_12;
            // 0x00EB3CB4: CBNZ x20, #0xeb3cbc        | if (this.targetMonster != null) goto label_19;
            if(this.targetMonster != null)
            {
                goto label_19;
            }
            // 0x00EB3CB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.targetMonster, ????);
            label_19:
            // 0x00EB3CBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3CC0: MOV x0, x20                | X0 = this.targetMonster;//m1            
            // 0x00EB3CC4: BL #0xd7dd80               | X0 = this.targetMonster.get_bvrCtrl();  
            Entity.Behavior.IBehaviorCtrl val_14 = this.targetMonster.bvrCtrl;
            // 0x00EB3CC8: MOV x20, x0                | X20 = val_14;//m1                       
            // 0x00EB3CCC: FCMP s8, s9                | STATE = COMPARE(val_9, ((val_10 + val_11) + val_12))
            // 0x00EB3CD0: B.LS #0xeb3db0             | if (val_9 <= val_10) goto label_20;     
            if(val_9 <= val_16)
            {
                goto label_20;
            }
            // 0x00EB3CD4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00EB3CD8: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00EB3CDC: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00EB3CE0: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00EB3CE4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00EB3CE8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00EB3CEC: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00EB3CF0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00EB3CF4: LDR x21, [x19, #0x10]      | 
            // 0x00EB3CF8: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_16 = null;
            // 0x00EB3CFC: CBNZ x21, #0xeb3d04        | if ( != null) goto label_21;            
            if(null != null)
            {
                goto label_21;
            }
            // 0x00EB3D00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_21:
            // 0x00EB3D04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3D08: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00EB3D0C: BL #0xd8ae48               | X0 = get_atkRange();                    
            float val_15 = atkRange;
            // 0x00EB3D10: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00EB3D14: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00EB3D18: ADD x1, sp, #0xc           | X1 = (1152921514660310768 + 12) = 1152921514660310780 (0x10000002573BAEFC);
            // 0x00EB3D1C: STR s0, [sp, #0xc]         | stack[1152921514660310780] = val_15;     //  dest_result_addr=1152921514660310780
            // 0x00EB3D20: LDR x0, [x8]               | X0 = typeof(System.Single);             
            // 0x00EB3D24: BL #0x27bc028              | X0 = 1152921514660391744 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_15);
            // 0x00EB3D28: MOV x21, x0                | X21 = 1152921514660391744 (0x10000002573CEB40);//ML01
            val_17 = val_15;
            // 0x00EB3D2C: CBNZ x19, #0xeb3d34        | if ( != null) goto label_22;            
            if(null != null)
            {
                goto label_22;
            }
            // 0x00EB3D30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_22:
            // 0x00EB3D34: CBZ x21, #0xeb3d58         | if (val_15 == 0) goto label_24;         
            if(val_15 == 0)
            {
                goto label_24;
            }
            // 0x00EB3D38: LDR x8, [x19]              | X8 = ;                                  
            // 0x00EB3D3C: MOV x0, x21                | X0 = 1152921514660391744 (0x10000002573CEB40);//ML01
            // 0x00EB3D40: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00EB3D44: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x00EB3D48: CBNZ x0, #0xeb3d58         | if (val_15 != 0) goto label_24;         
            if(val_15 != 0)
            {
                goto label_24;
            }
            // 0x00EB3D4C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
            // 0x00EB3D50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3D54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_24:
            // 0x00EB3D58: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00EB3D5C: CBNZ w8, #0xeb3d6c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_25;
            // 0x00EB3D60: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x00EB3D64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3D68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_25:
            // 0x00EB3D6C: STR x21, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_15; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_17;
            typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
            // 0x00EB3D70: CBNZ x20, #0xeb3d78        | if (val_14 != null) goto label_26;      
            if(val_14 != null)
            {
                goto label_26;
            }
            // 0x00EB3D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_26:
            // 0x00EB3D78: LDR x8, [x20]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
            // 0x00EB3D7C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00EB3D80: MOV x0, x20                | X0 = val_14;//m1                        
            // 0x00EB3D84: MOV x2, x19                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00EB3D88: LDP x9, x3, [x8, #0x180]   | X9 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
            // 0x00EB3D8C: BLR x9                     | X0 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180();
            label_8:
            // 0x00EB3D90: SUB sp, x29, #0x50         | SP = (1152921514660310864 - 80) = 1152921514660310784 (0x10000002573BAF00);
            // 0x00EB3D94: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00EB3D98: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00EB3D9C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00EB3DA0: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x00EB3DA4: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x00EB3DA8: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
            // 0x00EB3DAC: RET                        |  return;                                
            return;
            label_20:
            // 0x00EB3DB0: CBNZ x20, #0xeb3db8        | if (val_14 != null) goto label_27;      
            if(val_14 != null)
            {
                goto label_27;
            }
            // 0x00EB3DB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_27:
            // 0x00EB3DB8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00EB3DBC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00EB3DC0: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
            // 0x00EB3DC4: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00EB3DC8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00EB3DCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3DD0: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00EB3DD4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00EB3DD8: LDR x8, [x20]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
            // 0x00EB3DDC: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00EB3DE0: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x00EB3DE4: MOV x0, x20                | X0 = val_14;//m1                        
            // 0x00EB3DE8: LDP x4, x3, [x8, #0x180]   | X4 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
            // 0x00EB3DEC: SUB sp, x29, #0x50         | SP = (1152921514660310864 - 80) = 1152921514660310784 (0x10000002573BAF00);
            // 0x00EB3DF0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00EB3DF4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00EB3DF8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00EB3DFC: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x00EB3E00: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x00EB3E04: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
            // 0x00EB3E08: BR x4                      | goto typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180;
            goto typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180;
        
        }
        //
        // Offset in libil2cpp.so: 0x00EB3E14 (15416852), len: 884  VirtAddr: 0x00EB3E14 RVA: 0x00EB3E14 token: 100691439 methodIndex: 27245 delegateWrapperIndex: 0 methodInvoker: 0
        private CombatEntity GetTargetComatEntity()
        {
            //
            // Disasemble & Code
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            // 0x00EB3E14: STP d15, d14, [sp, #-0x90]! | stack[1152921514660529232] = ???;  stack[1152921514660529240] = ???;  //  dest_result_addr=1152921514660529232 |  dest_result_addr=1152921514660529240
            // 0x00EB3E18: STP d13, d12, [sp, #0x10]  | stack[1152921514660529248] = ???;  stack[1152921514660529256] = ???;  //  dest_result_addr=1152921514660529248 |  dest_result_addr=1152921514660529256
            // 0x00EB3E1C: STP d11, d10, [sp, #0x20]  | stack[1152921514660529264] = ???;  stack[1152921514660529272] = ???;  //  dest_result_addr=1152921514660529264 |  dest_result_addr=1152921514660529272
            // 0x00EB3E20: STP d9, d8, [sp, #0x30]    | stack[1152921514660529280] = ???;  stack[1152921514660529288] = ???;  //  dest_result_addr=1152921514660529280 |  dest_result_addr=1152921514660529288
            // 0x00EB3E24: STP x26, x25, [sp, #0x40]  | stack[1152921514660529296] = ???;  stack[1152921514660529304] = ???;  //  dest_result_addr=1152921514660529296 |  dest_result_addr=1152921514660529304
            // 0x00EB3E28: STP x24, x23, [sp, #0x50]  | stack[1152921514660529312] = ???;  stack[1152921514660529320] = ???;  //  dest_result_addr=1152921514660529312 |  dest_result_addr=1152921514660529320
            // 0x00EB3E2C: STP x22, x21, [sp, #0x60]  | stack[1152921514660529328] = ???;  stack[1152921514660529336] = ???;  //  dest_result_addr=1152921514660529328 |  dest_result_addr=1152921514660529336
            // 0x00EB3E30: STP x20, x19, [sp, #0x70]  | stack[1152921514660529344] = ???;  stack[1152921514660529352] = ???;  //  dest_result_addr=1152921514660529344 |  dest_result_addr=1152921514660529352
            // 0x00EB3E34: STP x29, x30, [sp, #0x80]  | stack[1152921514660529360] = ???;  stack[1152921514660529368] = ???;  //  dest_result_addr=1152921514660529360 |  dest_result_addr=1152921514660529368
            // 0x00EB3E38: ADD x29, sp, #0x80         | X29 = (1152921514660529232 + 128) = 1152921514660529360 (0x10000002573F04D0);
            // 0x00EB3E3C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00EB3E40: LDRB w8, [x20, #0xdad]     | W8 = (bool)static_value_03734DAD;       
            // 0x00EB3E44: MOV x19, x0                | X19 = 1152921514660541376 (0x10000002573F33C0);//ML01
            // 0x00EB3E48: TBNZ w8, #0, #0xeb3e64     | if (static_value_03734DAD == true) goto label_0;
            // 0x00EB3E4C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00EB3E50: LDR x8, [x8, #0x7d0]       | X8 = 0x2B90A80;                         
            // 0x00EB3E54: LDR w0, [x8]               | W0 = 0x1964;                            
            // 0x00EB3E58: BL #0x2782188              | X0 = sub_2782188( ?? 0x1964, ????);     
            // 0x00EB3E5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00EB3E60: STRB w8, [x20, #0xdad]     | static_value_03734DAD = true;            //  dest_result_addr=57888173
            label_0:
            // 0x00EB3E64: LDR x8, [x19, #0x10]       | 
            // 0x00EB3E68: CBZ x8, #0xeb3f24          | if (0x1 == 0) goto label_5;             
            if(true == 0)
            {
                goto label_5;
            }
            // 0x00EB3E6C: ADRP x9, #0x366c000        | X9 = 57065472 (0x366C000);              
            // 0x00EB3E70: LDR x9, [x9, #0x410]       | X9 = 1152921504894705664;               
            // 0x00EB3E74: LDR x10, [x8]              | X10 = 0x10102464C45;                    
            // 0x00EB3E78: LDR x9, [x9]               | X9 = typeof(Hero);                      
            // 0x00EB3E7C: LDRB w12, [x10, #0x104]    | W12 = (bool)mem[1103844756809];         
            // 0x00EB3E80: LDRB w11, [x9, #0x104]     | W11 = Hero.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00EB3E84: CMP w12, w11               | STATE = COMPARE(mem[1103844756809], Hero.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00EB3E88: B.LO #0xeb3ea0             | if (mem[1103844756809] < Hero.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00EB3E8C: LDR x10, [x10, #0xb0]      | X10 = mem[1103844756725];               
            // 0x00EB3E90: ADD x10, x10, x11, lsl #3  | X10 = (mem[1103844756725] + (Hero.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00EB3E94: LDUR x10, [x10, #-8]       | X10 = (mem[1103844756725] + (Hero.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00EB3E98: CMP x10, x9                | STATE = COMPARE((mem[1103844756725] + (Hero.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Hero))
            // 0x00EB3E9C: B.EQ #0xeb3efc             | if ((mem[1103844756725] + (Hero.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00EB3EA0: ADRP x10, #0x35e7000       | X10 = 56520704 (0x35E7000);             
            // 0x00EB3EA4: LDR x10, [x10, #0x18]      | X10 = 1152921504894918656;              
            // 0x00EB3EA8: LDR x9, [x8]               | X9 = 0x10102464C45;                     
            // 0x00EB3EAC: LDR x8, [x10]              | X8 = typeof(Monster);                   
            // 0x00EB3EB0: LDRB w11, [x9, #0x104]     | W11 = (bool)mem[1103844756809];         
            // 0x00EB3EB4: LDRB w10, [x8, #0x104]     | W10 = Monster.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00EB3EB8: CMP w11, w10               | STATE = COMPARE(mem[1103844756809], Monster.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00EB3EBC: B.LO #0xeb3f24             | if (mem[1103844756809] < Monster.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00EB3EC0: LDR x9, [x9, #0xb0]        | X9 = mem[1103844756725];                
            // 0x00EB3EC4: ADD x9, x9, x10, lsl #3    | X9 = (mem[1103844756725] + (Monster.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00EB3EC8: LDUR x9, [x9, #-8]         | X9 = (mem[1103844756725] + (Monster.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00EB3ECC: CMP x9, x8                 | STATE = COMPARE((mem[1103844756725] + (Monster.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Monster))
            // 0x00EB3ED0: B.NE #0xeb3f24             | if ((mem[1103844756725] + (Monster.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00EB3ED4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00EB3ED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3EDC: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
            HeroMgr val_1 = HeroMgr.instance;
            // 0x00EB3EE0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00EB3EE4: CBNZ x20, #0xeb3eec        | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x00EB3EE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x00EB3EEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3EF0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00EB3EF4: BL #0x289a8dc              | X0 = val_1.GetAllHero();                
            System.Collections.Generic.List<CombatEntity> val_2 = val_1.GetAllHero();
            // 0x00EB3EF8: B #0xeb3f20                |  goto label_7;                          
            goto label_7;
            label_3:
            // 0x00EB3EFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00EB3F00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3F04: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
            NpcMgr val_3 = NpcMgr.instance;
            // 0x00EB3F08: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00EB3F0C: CBNZ x20, #0xeb3f14        | if (val_3 != null) goto label_8;        
            if(val_3 != null)
            {
                goto label_8;
            }
            // 0x00EB3F10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_8:
            // 0x00EB3F14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3F18: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00EB3F1C: BL #0xd14cf8               | X0 = val_3.GetAllMonsters();            
            System.Collections.Generic.List<CombatEntity> val_4 = val_3.GetAllMonsters();
            label_7:
            // 0x00EB3F20: STR x0, [x19, #0x20]       | this.targetMonsters = val_4;             //  dest_result_addr=1152921514660541408
            this.targetMonsters = val_4;
            label_5:
            // 0x00EB3F24: LDR x0, [x19, #0x20]       | X0 = this.targetMonsters; //P2          
            // 0x00EB3F28: CBZ x0, #0xeb4158          | if (this.targetMonsters == null) goto label_9;
            if(this.targetMonsters == null)
            {
                goto label_9;
            }
            // 0x00EB3F2C: ADRP x23, #0x3646000       | X23 = 56909824 (0x3646000);             
            // 0x00EB3F30: LDR x23, [x23, #0xa00]     | X23 = 1152921510857364848;              
            // 0x00EB3F34: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<CombatEntity>::get_Count();
            // 0x00EB3F38: BL #0x25ed72c              | X0 = this.targetMonsters.get_Count();   
            int val_5 = this.targetMonsters.Count;
            // 0x00EB3F3C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00EB3F40: CBZ w0, #0xeb415c          | if (val_5 == 0) goto label_13;          
            if(val_5 == 0)
            {
                goto label_13;
            }
            // 0x00EB3F44: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x00EB3F48: ADRP x24, #0x35cf000       | X24 = 56422400 (0x35CF000);             
            // 0x00EB3F4C: ADRP x25, #0x3673000       | X25 = 57094144 (0x3673000);             
            // 0x00EB3F50: LDR s8, [x8, #0x4b0]       | S8 = 100;                               
            // 0x00EB3F54: LDR x24, [x24, #0x628]     | X24 = 1152921510857186288;              
            // 0x00EB3F58: LDR x25, [x25, #0x488]     | X25 = 1152921504695078912;              
            // 0x00EB3F5C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00EB3F60: B #0xeb3f68                |  goto label_11;                         
            goto label_11;
            label_30:
            // 0x00EB3F64: ADD w20, w20, #1           | W20 = (val_22 + 1) = val_22 (0x00000001);
            val_22 = 1;
            label_11:
            // 0x00EB3F68: LDR x22, [x19, #0x20]      | X22 = this.targetMonsters; //P2         
            // 0x00EB3F6C: CBNZ x22, #0xeb3f74        | if (this.targetMonsters != null) goto label_12;
            if(this.targetMonsters != null)
            {
                goto label_12;
            }
            // 0x00EB3F70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x00EB3F74: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<CombatEntity>::get_Count();
            // 0x00EB3F78: MOV x0, x22                | X0 = this.targetMonsters;//m1           
            // 0x00EB3F7C: BL #0x25ed72c              | X0 = this.targetMonsters.get_Count();   
            int val_6 = this.targetMonsters.Count;
            // 0x00EB3F80: CMP w20, w0                | STATE = COMPARE(0x1, val_6)             
            // 0x00EB3F84: B.GE #0xeb415c             | if (val_22 >= val_6) goto label_13;     
            if(val_22 >= val_6)
            {
                goto label_13;
            }
            // 0x00EB3F88: LDR x22, [x19, #0x10]      | 
            // 0x00EB3F8C: CBNZ x22, #0xeb3f94        | if (this.targetMonsters != null) goto label_14;
            if(this.targetMonsters != null)
            {
                goto label_14;
            }
            // 0x00EB3F90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_14:
            // 0x00EB3F94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3F98: MOV x0, x22                | X0 = this.targetMonsters;//m1           
            // 0x00EB3F9C: BL #0x20d5094              | X0 = this.targetMonsters.get_transform();
            UnityEngine.Transform val_7 = this.targetMonsters.transform;
            // 0x00EB3FA0: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00EB3FA4: CBNZ x22, #0xeb3fac        | if (val_7 != null) goto label_15;       
            if(val_7 != null)
            {
                goto label_15;
            }
            // 0x00EB3FA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_15:
            // 0x00EB3FAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3FB0: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x00EB3FB4: BL #0x2693510              | X0 = val_7.get_position();              
            UnityEngine.Vector3 val_8 = val_7.position;
            // 0x00EB3FB8: LDR x22, [x19, #0x20]      | X22 = this.targetMonsters; //P2         
            // 0x00EB3FBC: MOV v9.16b, v0.16b         | V9 = val_8.x;//m1                       
            // 0x00EB3FC0: MOV v10.16b, v1.16b        | V10 = val_8.y;//m1                      
            // 0x00EB3FC4: MOV v11.16b, v2.16b        | V11 = val_8.z;//m1                      
            // 0x00EB3FC8: CBNZ x22, #0xeb3fd0        | if (this.targetMonsters != null) goto label_16;
            if(this.targetMonsters != null)
            {
                goto label_16;
            }
            // 0x00EB3FCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_16:
            // 0x00EB3FD0: LDR x2, [x24]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
            // 0x00EB3FD4: MOV x0, x22                | X0 = this.targetMonsters;//m1           
            // 0x00EB3FD8: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00EB3FDC: BL #0x25ed734              | X0 = this.targetMonsters.get_Item(index:  1);
            CombatEntity val_9 = this.targetMonsters.Item[1];
            // 0x00EB3FE0: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00EB3FE4: CBNZ x22, #0xeb3fec        | if (val_9 != null) goto label_17;       
            if(val_9 != null)
            {
                goto label_17;
            }
            // 0x00EB3FE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_17:
            // 0x00EB3FEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB3FF0: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x00EB3FF4: BL #0x20d5094              | X0 = val_9.get_transform();             
            UnityEngine.Transform val_10 = val_9.transform;
            // 0x00EB3FF8: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x00EB3FFC: CBNZ x22, #0xeb4004        | if (val_10 != null) goto label_18;      
            if(val_10 != null)
            {
                goto label_18;
            }
            // 0x00EB4000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_18:
            // 0x00EB4004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB4008: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x00EB400C: BL #0x2693510              | X0 = val_10.get_position();             
            UnityEngine.Vector3 val_11 = val_10.position;
            // 0x00EB4010: LDR x0, [x25]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x00EB4014: MOV v12.16b, v0.16b        | V12 = val_11.x;//m1                     
            // 0x00EB4018: MOV v13.16b, v1.16b        | V13 = val_11.y;//m1                     
            // 0x00EB401C: MOV v14.16b, v2.16b        | V14 = val_11.z;//m1                     
            // 0x00EB4020: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x00EB4024: TBZ w8, #0, #0xeb4034      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00EB4028: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x00EB402C: CBNZ w8, #0xeb4034         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00EB4030: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_20:
            // 0x00EB4034: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00EB4038: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB403C: MOV v0.16b, v9.16b         | V0 = val_8.x;//m1                       
            // 0x00EB4040: MOV v1.16b, v10.16b        | V1 = val_8.y;//m1                       
            // 0x00EB4044: MOV v2.16b, v11.16b        | V2 = val_8.z;//m1                       
            // 0x00EB4048: MOV v3.16b, v12.16b        | V3 = val_11.x;//m1                      
            // 0x00EB404C: MOV v4.16b, v13.16b        | V4 = val_11.y;//m1                      
            // 0x00EB4050: MOV v5.16b, v14.16b        | V5 = val_11.z;//m1                      
            // 0x00EB4054: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
            float val_12 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
            // 0x00EB4058: FCMP s0, s8                | STATE = COMPARE(val_12, 100)            
            // 0x00EB405C: B.PL #0xeb3f64             | if (val_12 >= 0) goto label_30;         
            if(val_12 >= 0)
            {
                goto label_30;
            }
            // 0x00EB4060: LDR x21, [x19, #0x10]      | 
            // 0x00EB4064: CBNZ x21, #0xeb406c        | if (0x0 != 0) goto label_22;            
            if(val_21 != 0)
            {
                goto label_22;
            }
            // 0x00EB4068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_22:
            // 0x00EB406C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB4070: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00EB4074: BL #0x20d5094              | X0 = val_21.get_transform();            
            UnityEngine.Transform val_13 = val_21.transform;
            // 0x00EB4078: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x00EB407C: CBNZ x21, #0xeb4084        | if (val_13 != null) goto label_23;      
            if(val_13 != null)
            {
                goto label_23;
            }
            // 0x00EB4080: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_23:
            // 0x00EB4084: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB4088: MOV x0, x21                | X0 = val_13;//m1                        
            // 0x00EB408C: BL #0x2693510              | X0 = val_13.get_position();             
            UnityEngine.Vector3 val_14 = val_13.position;
            // 0x00EB4090: LDR x21, [x19, #0x20]      | X21 = this.targetMonsters; //P2         
            // 0x00EB4094: MOV v8.16b, v0.16b         | V8 = val_14.x;//m1                      
            // 0x00EB4098: MOV v9.16b, v1.16b         | V9 = val_14.y;//m1                      
            // 0x00EB409C: MOV v10.16b, v2.16b        | V10 = val_14.z;//m1                     
            // 0x00EB40A0: CBNZ x21, #0xeb40a8        | if (this.targetMonsters != null) goto label_24;
            if(this.targetMonsters != null)
            {
                goto label_24;
            }
            // 0x00EB40A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_24:
            // 0x00EB40A8: LDR x2, [x24]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
            // 0x00EB40AC: MOV x0, x21                | X0 = this.targetMonsters;//m1           
            // 0x00EB40B0: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00EB40B4: BL #0x25ed734              | X0 = this.targetMonsters.get_Item(index:  1);
            CombatEntity val_15 = this.targetMonsters.Item[1];
            // 0x00EB40B8: MOV x21, x0                | X21 = val_15;//m1                       
            // 0x00EB40BC: CBNZ x21, #0xeb40c4        | if (val_15 != null) goto label_25;      
            if(val_15 != null)
            {
                goto label_25;
            }
            // 0x00EB40C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_25:
            // 0x00EB40C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB40C8: MOV x0, x21                | X0 = val_15;//m1                        
            // 0x00EB40CC: BL #0x20d5094              | X0 = val_15.get_transform();            
            UnityEngine.Transform val_16 = val_15.transform;
            // 0x00EB40D0: MOV x21, x0                | X21 = val_16;//m1                       
            // 0x00EB40D4: CBNZ x21, #0xeb40dc        | if (val_16 != null) goto label_26;      
            if(val_16 != null)
            {
                goto label_26;
            }
            // 0x00EB40D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_26:
            // 0x00EB40DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB40E0: MOV x0, x21                | X0 = val_16;//m1                        
            // 0x00EB40E4: BL #0x2693510              | X0 = val_16.get_position();             
            UnityEngine.Vector3 val_17 = val_16.position;
            // 0x00EB40E8: LDR x0, [x25]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x00EB40EC: MOV v11.16b, v0.16b        | V11 = val_17.x;//m1                     
            // 0x00EB40F0: MOV v12.16b, v1.16b        | V12 = val_17.y;//m1                     
            // 0x00EB40F4: MOV v13.16b, v2.16b        | V13 = val_17.z;//m1                     
            // 0x00EB40F8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x00EB40FC: TBZ w8, #0, #0xeb410c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x00EB4100: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x00EB4104: CBNZ w8, #0xeb410c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x00EB4108: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_28:
            // 0x00EB410C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00EB4110: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00EB4114: MOV v0.16b, v8.16b         | V0 = val_14.x;//m1                      
            // 0x00EB4118: MOV v1.16b, v9.16b         | V1 = val_14.y;//m1                      
            // 0x00EB411C: MOV v2.16b, v10.16b        | V2 = val_14.z;//m1                      
            // 0x00EB4120: MOV v3.16b, v11.16b        | V3 = val_17.x;//m1                      
            // 0x00EB4124: MOV v4.16b, v12.16b        | V4 = val_17.y;//m1                      
            // 0x00EB4128: MOV v5.16b, v13.16b        | V5 = val_17.z;//m1                      
            // 0x00EB412C: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z});
            float val_18 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z});
            // 0x00EB4130: LDR x21, [x19, #0x20]      | X21 = this.targetMonsters; //P2         
            // 0x00EB4134: MOV v8.16b, v0.16b         | V8 = val_18;//m1                        
            // 0x00EB4138: CBNZ x21, #0xeb4140        | if (this.targetMonsters != null) goto label_29;
            if(this.targetMonsters != null)
            {
                goto label_29;
            }
            // 0x00EB413C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_29:
            // 0x00EB4140: LDR x2, [x24]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
            // 0x00EB4144: MOV x0, x21                | X0 = this.targetMonsters;//m1           
            // 0x00EB4148: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00EB414C: BL #0x25ed734              | X0 = this.targetMonsters.get_Item(index:  1);
            CombatEntity val_19 = this.targetMonsters.Item[1];
            // 0x00EB4150: MOV x21, x0                | X21 = val_19;//m1                       
            // 0x00EB4154: B #0xeb3f64                |  goto label_30;                         
            goto label_30;
            label_9:
            // 0x00EB4158: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_13:
            // 0x00EB415C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00EB4160: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
            // 0x00EB4164: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
            // 0x00EB4168: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
            // 0x00EB416C: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
            // 0x00EB4170: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
            // 0x00EB4174: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x00EB4178: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x00EB417C: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x00EB4180: LDP d15, d14, [sp], #0x90  | D15 = ; D14 = ;                          //  | 
            // 0x00EB4184: RET                        |  return (CombatEntity)null;             
            return (CombatEntity)val_21;
            //  |  // // {name=val_0, type=CombatEntity, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00EB4188 (15417736), len: 4  VirtAddr: 0x00EB4188 RVA: 0x00EB4188 token: 100691440 methodIndex: 27246 delegateWrapperIndex: 0 methodInvoker: 0
        public override void DoLeaving()
        {
            //
            // Disasemble & Code
            // 0x00EB4188: RET                        |  return;                                
            return;
        
        }
    
    }

}
