using UnityEngine;

namespace ProtoBuf.Serializers
{
    internal sealed class ArrayDecorator : ProtoDecoratorBase
    {
        // Fields
        private readonly int fieldNumber; //  0x00000018
        private const byte OPTIONS_WritePacked = 1;
        private const byte OPTIONS_OverwriteList = 2;
        private const byte OPTIONS_SupportNull = 4;
        private readonly byte options; //  0x0000001C
        private readonly ProtoBuf.WireType packedWireType; //  0x00000020
        private readonly System.Type arrayType; //  0x00000028
        private readonly System.Type itemType; //  0x00000030
        
        // Properties
        public override System.Type ExpectedType { get; }
        public override bool RequiresOldValue { get; }
        public override bool ReturnsValue { get; }
        private bool AppendToCollection { get; }
        private bool SupportNull { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x02982A54 (43526740), len: 512  VirtAddr: 0x02982A54 RVA: 0x02982A54 token: 100689792 methodIndex: 53991 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayDecorator(ProtoBuf.Meta.TypeModel model, ProtoBuf.Serializers.IProtoSerializer tail, int fieldNumber, bool writePacked, ProtoBuf.WireType packedWireType, System.Type arrayType, bool overwriteList, bool supportNull)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x02982A54: STP x26, x25, [sp, #-0x50]! | stack[1152921514432444880] = ???;  stack[1152921514432444888] = ???;  //  dest_result_addr=1152921514432444880 |  dest_result_addr=1152921514432444888
            // 0x02982A58: STP x24, x23, [sp, #0x10]  | stack[1152921514432444896] = ???;  stack[1152921514432444904] = ???;  //  dest_result_addr=1152921514432444896 |  dest_result_addr=1152921514432444904
            // 0x02982A5C: STP x22, x21, [sp, #0x20]  | stack[1152921514432444912] = ???;  stack[1152921514432444920] = ???;  //  dest_result_addr=1152921514432444912 |  dest_result_addr=1152921514432444920
            // 0x02982A60: STP x20, x19, [sp, #0x30]  | stack[1152921514432444928] = ???;  stack[1152921514432444936] = ???;  //  dest_result_addr=1152921514432444928 |  dest_result_addr=1152921514432444936
            // 0x02982A64: STP x29, x30, [sp, #0x40]  | stack[1152921514432444944] = ???;  stack[1152921514432444952] = ???;  //  dest_result_addr=1152921514432444944 |  dest_result_addr=1152921514432444952
            // 0x02982A68: ADD x29, sp, #0x40         | X29 = (1152921514432444880 + 64) = 1152921514432444944 (0x1000000249A6BA10);
            // 0x02982A6C: ADRP x26, #0x37b8000       | X26 = 58425344 (0x37B8000);             
            // 0x02982A70: LDRB w8, [x26, #0xf10]     | W8 = (bool)static_value_037B8F10;       
            // 0x02982A74: MOV w21, w7                | W21 = overwriteList;//m1                
            // 0x02982A78: MOV x19, x6                | X19 = arrayType;//m1                    
            // 0x02982A7C: MOV w24, w5                | W24 = packedWireType;//m1               
            val_13 = packedWireType;
            // 0x02982A80: MOV w22, w4                | W22 = writePacked;//m1                  
            // 0x02982A84: MOV w23, w3                | W23 = fieldNumber;//m1                  
            // 0x02982A88: MOV x25, x2                | X25 = tail;//m1                         
            // 0x02982A8C: MOV x20, x0                | X20 = 1152921514432456960 (0x1000000249A6E900);//ML01
            // 0x02982A90: TBNZ w8, #0, #0x2982aac    | if (static_value_037B8F10 == true) goto label_0;
            // 0x02982A94: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x02982A98: LDR x8, [x8, #0x290]       | X8 = 0x2B8E720;                         
            // 0x02982A9C: LDR w0, [x8]               | W0 = 0x1086;                            
            // 0x02982AA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1086, ????);     
            // 0x02982AA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02982AA8: STRB w8, [x26, #0xf10]     | static_value_037B8F10 = true;            //  dest_result_addr=58429200
            label_0:
            // 0x02982AAC: LDRB w26, [x29, #0x10]     | W26 = supportNull;                      
            // 0x02982AB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02982AB4: MOV x0, x20                | X0 = 1152921514432456960 (0x1000000249A6E900);//ML01
            // 0x02982AB8: BL #0x16f59f0              | arrayType..ctor();                      
            val_1 = new System.Object();
            // 0x02982ABC: STR x25, [x20, #0x10]      | mem[1152921514432456976] = tail;         //  dest_result_addr=1152921514432456976
            mem[1152921514432456976] = tail;
            // 0x02982AC0: CBNZ x19, #0x2982ac8       | if (arrayType != null) goto label_1;    
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x02982AC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arrayType..ctor(), ????);
            label_1:
            // 0x02982AC8: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x02982ACC: MOV x0, x19                | X0 = arrayType;//m1                     
            // 0x02982AD0: LDR x9, [x8, #0x410]       | X9 = typeof(System.Type).__il2cppRuntimeField_410;
            // 0x02982AD4: LDR x1, [x8, #0x418]       | X1 = typeof(System.Type).__il2cppRuntimeField_418;
            // 0x02982AD8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_410();
            // 0x02982ADC: MOV x25, x0                | X25 = arrayType;//m1                    
            // 0x02982AE0: STR x25, [x20, #0x30]      | this.itemType = arrayType;               //  dest_result_addr=1152921514432457008
            this.itemType = val_1;
            // 0x02982AE4: AND w8, w26, #1            | W8 = (supportNull & 1);                 
            bool val_2 = supportNull;
            // 0x02982AE8: TBNZ w8, #0, #0x2982b1c    | if ((supportNull & 1) == true) goto label_2;
            if(val_2 == true)
            {
                goto label_2;
            }
            // 0x02982AEC: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x02982AF0: LDR x8, [x8, #0x2e8]       | X8 = 1152921504881979392;               
            // 0x02982AF4: LDR x0, [x8]               | X0 = typeof(ProtoBuf.Helpers);          
            // 0x02982AF8: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Helpers.__il2cppRuntimeField_10A;
            // 0x02982AFC: TBZ w8, #0, #0x2982b0c     | if (ProtoBuf.Helpers.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x02982B00: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Helpers.__il2cppRuntimeField_cctor_finished;
            // 0x02982B04: CBNZ w8, #0x2982b0c        | if (ProtoBuf.Helpers.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x02982B08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Helpers), ????);
            label_4:
            // 0x02982B0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02982B10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02982B14: MOV x1, x25                | X1 = arrayType;//m1                     
            // 0x02982B18: BL #0xc7de68               | X0 = ProtoBuf.Helpers.GetUnderlyingType(type:  0);
            System.Type val_3 = ProtoBuf.Helpers.GetUnderlyingType(type:  0);
            label_2:
            // 0x02982B1C: CMN w24, #1                | STATE = COMPARE(packedWireType, 0x1)    
            // 0x02982B20: EOR w25, w22, #1           | W25 = (writePacked ^ 1);                
            bool val_4 = writePacked ^ 1;
            // 0x02982B24: CSET w8, eq                | W8 = val_13 == 0x1 ? 1 : 0;             
            var val_5 = (val_13 == 1) ? 1 : 0;
            // 0x02982B28: CMP w23, #0                | STATE = COMPARE(fieldNumber, 0x0)       
            // 0x02982B2C: B.GT #0x2982b38            | if (fieldNumber > 0) goto label_5;      
            if(fieldNumber > 0)
            {
                goto label_5;
            }
            // 0x02982B30: AND w8, w8, w25            | W8 = (val_13 == 0x1 ? 1 : 0 & (writePacked ^ 1));
            val_5 = val_5 & val_4;
            // 0x02982B34: TBZ w8, #0, #0x2982be8     | if ((val_13 == 0x1 ? 1 : 0 & (writePacked ^ 1)) == false) goto label_6;
            if(val_5 == false)
            {
                goto label_6;
            }
            label_5:
            // 0x02982B38: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x02982B3C: LDR x8, [x8, #0xca8]       | X8 = 1152921504885813248;               
            // 0x02982B40: LDR x0, [x8]               | X0 = typeof(ProtoBuf.Serializers.ListDecorator);
            // 0x02982B44: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Serializers.ListDecorator.__il2cppRuntimeField_10A;
            // 0x02982B48: TBZ w8, #0, #0x2982b58     | if (ProtoBuf.Serializers.ListDecorator.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x02982B4C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Serializers.ListDecorator.__il2cppRuntimeField_cctor_finished;
            // 0x02982B50: CBNZ w8, #0x2982b58        | if (ProtoBuf.Serializers.ListDecorator.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x02982B54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Serializers.ListDecorator), ????);
            label_8:
            // 0x02982B58: CMP w24, #5                | STATE = COMPARE(packedWireType, 0x5)    
            // 0x02982B5C: B.HI #0x2982b74            | if (val_13 > 0x5) goto label_9;         
            if(val_13 > 5)
            {
                goto label_9;
            }
            // 0x02982B60: AND w8, w24, #0x3f         | W8 = (packedWireType & 63);             
            ProtoBuf.WireType val_6 = val_13 & 63;
            // 0x02982B64: MOVZ w9, #0x23             | W9 = 35 (0x23);//ML01                   
            // 0x02982B68: LSR w8, w9, w8             | W8 = (35 >> (packedWireType & 63));     
            val_6 = 35 >> val_6;
            // 0x02982B6C: AND w8, w8, #1             | W8 = ((35 >> (packedWireType & 63)) & 1);
            val_6 = val_6 & 1;
            // 0x02982B70: CBNZ w8, #0x2982b94        | if (((35 >> (packedWireType & 63)) & 1) != 0) goto label_10;
            if(val_6 != 0)
            {
                goto label_10;
            }
            label_9:
            // 0x02982B74: CMP w24, #8                | STATE = COMPARE(packedWireType, 0x8)    
            // 0x02982B78: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x02982B7C: ORR w9, wzr, #8            | W9 = 8(0x8);                            
            // 0x02982B80: CSET w10, eq               | W10 = val_13 == 0x8 ? 1 : 0;            
            var val_7 = (val_13 == 8) ? 1 : 0;
            // 0x02982B84: ORR w10, w10, w25          | W10 = (val_13 == 0x8 ? 1 : 0 | (writePacked ^ 1));
            val_7 = val_7 | val_4;
            // 0x02982B88: CSEL w24, w9, w8, eq       | W24 = val_13 == 0x8 ? 8 : 0;            
            ProtoBuf.WireType val_8 = (val_13 == 8) ? (8) : (0);
            // 0x02982B8C: AND w10, w10, #1           | W10 = ((val_13 == 0x8 ? 1 : 0 | (writePacked ^ 1)) & 1);
            bool val_9 = val_7;
            // 0x02982B90: TBZ w10, #0, #0x2982c14    | if (((val_13 == 0x8 ? 1 : 0 | (writePacked ^ 1)) & 1) == false) goto label_11;
            if(val_9 == false)
            {
                goto label_11;
            }
            label_10:
            // 0x02982B94: STR w23, [x20, #0x18]      | this.fieldNumber = fieldNumber;          //  dest_result_addr=1152921514432456984
            this.fieldNumber = fieldNumber;
            // 0x02982B98: STR w24, [x20, #0x20]      | this.packedWireType = val_13 == 0x8 ? 8 : 0;  //  dest_result_addr=1152921514432456992
            this.packedWireType = val_8;
            // 0x02982B9C: TBZ w22, #0, #0x2982bac    | if (writePacked == false) goto label_12;
            if(writePacked == false)
            {
                goto label_12;
            }
            // 0x02982BA0: LDRB w8, [x20, #0x1c]      | W8 = this.options; //P2                 
            byte val_13 = this.options;
            // 0x02982BA4: ORR w8, w8, #1             | W8 = (this.options | 1);                
            val_13 = val_13 | 1;
            // 0x02982BA8: STRB w8, [x20, #0x1c]      | this.options = (this.options | 1);       //  dest_result_addr=1152921514432456988
            this.options = val_13;
            label_12:
            // 0x02982BAC: TBZ w21, #0, #0x2982bbc    | if (overwriteList == false) goto label_13;
            if(overwriteList == false)
            {
                goto label_13;
            }
            // 0x02982BB0: LDRB w8, [x20, #0x1c]      | W8 = this.options; //P2                 
            byte val_14 = this.options;
            // 0x02982BB4: ORR w8, w8, #2             | W8 = (this.options | 2);                
            val_14 = val_14 | 2;
            // 0x02982BB8: STRB w8, [x20, #0x1c]      | this.options = (this.options | 2);       //  dest_result_addr=1152921514432456988
            this.options = val_14;
            label_13:
            // 0x02982BBC: TBZ w26, #0, #0x2982bcc    | if (supportNull == false) goto label_14;
            if(supportNull == false)
            {
                goto label_14;
            }
            // 0x02982BC0: LDRB w8, [x20, #0x1c]      | W8 = this.options; //P2                 
            byte val_15 = this.options;
            // 0x02982BC4: ORR w8, w8, #4             | W8 = (this.options | 4);                
            val_15 = val_15 | 4;
            // 0x02982BC8: STRB w8, [x20, #0x1c]      | this.options = (this.options | 4);       //  dest_result_addr=1152921514432456988
            this.options = val_15;
            label_14:
            // 0x02982BCC: STR x19, [x20, #0x28]      | this.arrayType = arrayType;              //  dest_result_addr=1152921514432457000
            this.arrayType = val_1;
            // 0x02982BD0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x02982BD4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x02982BD8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x02982BDC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x02982BE0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x02982BE4: RET                        |  return;                                
            return;
            label_6:
            // 0x02982BE8: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x02982BEC: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x02982BF0: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            System.ArgumentOutOfRangeException val_10 = null;
            // 0x02982BF4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x02982BF8: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x02982BFC: LDR x8, [x8, #0xc68]       | X8 = (string**)(1152921514357322240)("fieldNumber");
            // 0x02982C00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02982C04: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            val_14 = val_10;
            // 0x02982C08: LDR x1, [x8]               | X1 = "fieldNumber";                     
            // 0x02982C0C: BL #0x18b81ac              | .ctor(paramName:  "fieldNumber");       
            val_10 = new System.ArgumentOutOfRangeException(paramName:  "fieldNumber");
            // 0x02982C10: B #0x2982c3c               |  goto label_15;                         
            goto label_15;
            label_11:
            // 0x02982C14: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x02982C18: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x02982C1C: LDR x0, [x8]               | X0 = typeof(System.InvalidOperationException);
            System.InvalidOperationException val_11 = null;
            // 0x02982C20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x02982C24: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x02982C28: LDR x8, [x8, #0x748]       | X8 = (string**)(1152921514432431776)("Only simple data-types can use packed encoding");
            // 0x02982C2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02982C30: MOV x19, x0                | X19 = 1152921504654397440 (0x1000000002D59000);//ML01
            val_14 = val_11;
            // 0x02982C34: LDR x1, [x8]               | X1 = "Only simple data-types can use packed encoding";
            // 0x02982C38: BL #0x1e6648c              | .ctor(message:  "Only simple data-types can use packed encoding");
            val_11 = new System.InvalidOperationException(message:  "Only simple data-types can use packed encoding");
            label_15:
            // 0x02982C3C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x02982C40: LDR x8, [x8, #0xfc0]       | X8 = 1152921514432431936;               
            // 0x02982C44: MOV x0, x19                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x02982C48: LDR x1, [x8]               | X1 = public System.Void ProtoBuf.Serializers.ArrayDecorator::.ctor(ProtoBuf.Meta.TypeModel model, ProtoBuf.Serializers.IProtoSerializer tail, int fieldNumber, bool writePacked, ProtoBuf.WireType packedWireType, System.Type arrayType, bool overwriteList, bool supportNull);
            // 0x02982C4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x02982C50: BL #0x296f794              | X0 = get_AllowParseableTypes();         
            bool val_12 = AllowParseableTypes;
        
        }
        //
        // Offset in libil2cpp.so: 0x0298AADC (43559644), len: 8  VirtAddr: 0x0298AADC RVA: 0x0298AADC token: 100689793 methodIndex: 53992 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type get_ExpectedType()
        {
            //
            // Disasemble & Code
            // 0x0298AADC: LDR x0, [x0, #0x28]        | X0 = this.arrayType; //P2               
            // 0x0298AAE0: RET                        |  return (System.Type)this.arrayType;    
            return this.arrayType;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298AAE4 (43559652), len: 16  VirtAddr: 0x0298AAE4 RVA: 0x0298AAE4 token: 100689794 methodIndex: 53993 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_RequiresOldValue()
        {
            //
            // Disasemble & Code
            // 0x0298AAE4: LDRB w8, [x0, #0x1c]       | W8 = this.options; //P2                 
            // 0x0298AAE8: TST w8, #2                 | STATE = COMPARE(this.options, 0x2)      
            // 0x0298AAEC: CSET w0, eq                | W0 = (this.options & 2)!=0 ? 1 : 0;     
            var val_1 = ((this.options & 2) != 0) ? 1 : 0;
            // 0x0298AAF0: RET                        |  return (System.Boolean)(this.options & 2)!=0 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298AB04 (43559684), len: 8  VirtAddr: 0x0298AB04 RVA: 0x0298AB04 token: 100689795 methodIndex: 53994 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_ReturnsValue()
        {
            //
            // Disasemble & Code
            // 0x0298AB04: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x0298AB08: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298AAF4 (43559668), len: 16  VirtAddr: 0x0298AAF4 RVA: 0x0298AAF4 token: 100689796 methodIndex: 53995 delegateWrapperIndex: 0 methodInvoker: 0
        private bool get_AppendToCollection()
        {
            //
            // Disasemble & Code
            // 0x0298AAF4: LDRB w8, [x0, #0x1c]       | W8 = this.options; //P2                 
            // 0x0298AAF8: TST w8, #2                 | STATE = COMPARE(this.options, 0x2)      
            // 0x0298AAFC: CSET w0, eq                | W0 = (this.options & 2)!=0 ? 1 : 0;     
            var val_1 = ((this.options & 2) != 0) ? 1 : 0;
            // 0x0298AB00: RET                        |  return (System.Boolean)(this.options & 2)!=0 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298AB0C (43559692), len: 12  VirtAddr: 0x0298AB0C RVA: 0x0298AB0C token: 100689797 methodIndex: 53996 delegateWrapperIndex: 0 methodInvoker: 0
        private bool get_SupportNull()
        {
            //
            // Disasemble & Code
            // 0x0298AB0C: LDRB w8, [x0, #0x1c]       | W8 = this.options; //P2                 
            // 0x0298AB10: UBFX w0, w8, #2, #1        | W0 = (uint)((this.options>>2) & 0x1);   
            // 0x0298AB14: RET                        |  return (System.Boolean)(uint)((this.options>>2) & 0x1);
            return (bool)(uint)(this.options >> 2) & 1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298AB18 (43559704), len: 868  VirtAddr: 0x0298AB18 RVA: 0x0298AB18 token: 100689798 methodIndex: 53997 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Write(object value, ProtoBuf.ProtoWriter dest)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            ProtoBuf.ProtoWriter val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            int val_16;
            //  | 
            ProtoBuf.ProtoWriter val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            // 0x0298AB18: STP x28, x27, [sp, #-0x60]! | stack[1152921514433154752] = ???;  stack[1152921514433154760] = ???;  //  dest_result_addr=1152921514433154752 |  dest_result_addr=1152921514433154760
            // 0x0298AB1C: STP x26, x25, [sp, #0x10]  | stack[1152921514433154768] = ???;  stack[1152921514433154776] = ???;  //  dest_result_addr=1152921514433154768 |  dest_result_addr=1152921514433154776
            // 0x0298AB20: STP x24, x23, [sp, #0x20]  | stack[1152921514433154784] = ???;  stack[1152921514433154792] = ???;  //  dest_result_addr=1152921514433154784 |  dest_result_addr=1152921514433154792
            // 0x0298AB24: STP x22, x21, [sp, #0x30]  | stack[1152921514433154800] = ???;  stack[1152921514433154808] = ???;  //  dest_result_addr=1152921514433154800 |  dest_result_addr=1152921514433154808
            // 0x0298AB28: STP x20, x19, [sp, #0x40]  | stack[1152921514433154816] = ???;  stack[1152921514433154824] = ???;  //  dest_result_addr=1152921514433154816 |  dest_result_addr=1152921514433154824
            // 0x0298AB2C: STP x29, x30, [sp, #0x50]  | stack[1152921514433154832] = ???;  stack[1152921514433154840] = ???;  //  dest_result_addr=1152921514433154832 |  dest_result_addr=1152921514433154840
            // 0x0298AB30: ADD x29, sp, #0x50         | X29 = (1152921514433154752 + 80) = 1152921514433154832 (0x1000000249B18F10);
            // 0x0298AB34: SUB sp, sp, #0x20          | SP = (1152921514433154752 - 32) = 1152921514433154720 (0x1000000249B18EA0);
            // 0x0298AB38: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298AB3C: LDRB w8, [x19, #0xf11]     | W8 = (bool)static_value_037B8F11;       
            // 0x0298AB40: MOV x24, x1                | X24 = value;//m1                        
            // 0x0298AB44: MOV x20, x0                | X20 = 1152921514433166848 (0x1000000249B1BE00);//ML01
            // 0x0298AB48: STR x2, [sp, #0x10]        | stack[1152921514433154736] = dest;       //  dest_result_addr=1152921514433154736
            // 0x0298AB4C: TBNZ w8, #0, #0x298ab68    | if (static_value_037B8F11 == true) goto label_0;
            // 0x0298AB50: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x0298AB54: LDR x8, [x8, #0xf18]       | X8 = 0x2B8E728;                         
            // 0x0298AB58: LDR w0, [x8]               | W0 = 0x1088;                            
            // 0x0298AB5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1088, ????);     
            // 0x0298AB60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298AB64: STRB w8, [x19, #0xf11]     | static_value_037B8F11 = true;            //  dest_result_addr=58429201
            label_0:
            // 0x0298AB68: CBZ x24, #0x298abc4        | if (value == null) goto label_1;        
            if(value == null)
            {
                goto label_1;
            }
            // 0x0298AB6C: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x0298AB70: LDR x8, [x8, #0x308]       | X8 = 1152921504609349632;               
            // 0x0298AB74: MOV x0, x24                | X0 = value;//m1                         
            // 0x0298AB78: LDR x22, [x8]              | X22 = typeof(System.Collections.IList); 
            // 0x0298AB7C: MOV x1, x22                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x0298AB80: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x0298AB84: MOV x21, x0                | X21 = value;//m1                        
            val_11 = value;
            // 0x0298AB88: CBZ x21, #0x298ab98        | if (value == null) goto label_2;        
            if(val_11 == null)
            {
                goto label_2;
            }
            // 0x0298AB8C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x0298AB90: MOV x22, x21               | X22 = value;//m1                        
            val_13 = val_11;
            // 0x0298AB94: B #0x298abd4               |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x0298AB98: LDR x8, [x24]              | X8 = typeof(System.Object);             
            // 0x0298AB9C: MOV x1, x22                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x0298ABA0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298ABA4: ADD x8, sp, #0x18          | X8 = (1152921514433154720 + 24) = 1152921514433154744 (0x1000000249B18EB8);
            // 0x0298ABA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298ABAC: LDR x0, [sp, #0x18]        | X0 = val_1;                              //  find_add[1152921514433142848]
            // 0x0298ABB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x0298ABB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298ABB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x0298ABBC: ADD x0, sp, #0x18          | X0 = (1152921514433154720 + 24) = 1152921514433154744 (0x1000000249B18EB8);
            // 0x0298ABC0: BL #0x299a140              | 
            label_1:
            // 0x0298ABC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000249B18EB8, ????);
            // 0x0298ABC8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x0298ABCC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x0298ABD0: ORR w28, wzr, #1           | W28 = 1(0x1);                           
            val_12 = 1;
            label_3:
            // 0x0298ABD4: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x0298ABD8: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x0298ABDC: LDR x9, [x9, #0xd0]        | X9 = 1152921504609296384;               
            // 0x0298ABE0: LDR x1, [x9]               | X1 = typeof(System.Collections.ICollection);
            // 0x0298ABE4: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x0298ABE8: CBZ x9, #0x298ac14         | if (mem[282584257676929] == 0) goto label_4;
            if(mem[282584257676929] == 0)
            {
                goto label_4;
            }
            // 0x0298ABEC: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_6 = mem[282584257676823];
            // 0x0298ABF0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x0298ABF4: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_6 = val_6 + 8;
            label_6:
            // 0x0298ABF8: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x0298ABFC: CMP x12, x1                | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(System.Collections.ICollection))
            // 0x0298AC00: B.EQ #0x298ac24            | if ((mem[282584257676823] + 8) + -8 == null) goto label_5;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_5;
            }
            // 0x0298AC04: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x0298AC08: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_6 = val_6 + 16;
            // 0x0298AC0C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x0298AC10: B.LO #0x298abf8            | if (0 < mem[282584257676929]) goto label_6;
            if(val_7 < mem[282584257676929])
            {
                goto label_6;
            }
            label_4:
            // 0x0298AC14: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_14 = 0;
            // 0x0298AC18: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            val_15 = val_13;
            // 0x0298AC1C: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x0298AC20: B #0x298ac30               |  goto label_7;                          
            goto label_7;
            label_5:
            // 0x0298AC24: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x0298AC28: ADD x8, x8, x9, lsl #4     | X8 = (val_13 + ((mem[282584257676823] + 8)) << 4);
            val_13 = val_13 + (((mem[282584257676823] + 8)) << 4);
            // 0x0298AC2C: ADD x0, x8, #0x110         | X0 = ((val_13 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_15 = val_13 + 272;
            label_7:
            // 0x0298AC30: LDP x8, x1, [x0]           | X8 = ((val_13 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_13 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x0298AC34: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x0298AC38: BLR x8                     | X0 = ((val_13 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x0298AC3C: LDRB w8, [x20, #0x1c]      | W8 = this.options; //P2                 
            // 0x0298AC40: MOV w23, w0                | W23 = 0 (0x0);//ML01                    
            // 0x0298AC44: TBZ w8, #0, #0x298aca8     | if ((this.options & 0x1) == 0) goto label_8;
            if((this.options & 1) == 0)
            {
                goto label_8;
            }
            // 0x0298AC48: STR w8, [sp, #0xc]         | stack[1152921514433154732] = this.options;  //  dest_result_addr=1152921514433154732
            // 0x0298AC4C: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x0298AC50: LDR x8, [x8, #0x778]       | X8 = 1152921504884428800;               
            // 0x0298AC54: LDR w25, [x20, #0x18]      | W25 = this.fieldNumber; //P2            
            val_16 = this.fieldNumber;
            // 0x0298AC58: LDR x0, [x8]               | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x0298AC5C: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x0298AC60: TBZ w8, #0, #0x298ac70     | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x0298AC64: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x0298AC68: CBNZ w8, #0x298ac70        | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x0298AC6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_10:
            // 0x0298AC70: LDR x19, [sp, #0x10]       | X19 = dest;                             
            val_10 = dest;
            // 0x0298AC74: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0298AC78: MOV w1, w25                | W1 = this.fieldNumber;//m1              
            // 0x0298AC7C: MOV x3, x19                | X3 = dest;//m1                          
            // 0x0298AC80: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  277581824, wireType:  val_16, writer:  2);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  277581824, wireType:  val_16, writer:  2);
            // 0x0298AC84: MOV x1, x24                | X1 = value;//m1                         
            // 0x0298AC88: MOV x2, x19                | X2 = dest;//m1                          
            // 0x0298AC8C: BL #0x2977f50              | X0 = ProtoBuf.ProtoWriter.StartSubItem(instance:  null, writer:  value);
            ProtoBuf.SubItemToken val_2 = ProtoBuf.ProtoWriter.StartSubItem(instance:  null, writer:  value);
            // 0x0298AC90: LDR w1, [x20, #0x18]       | W1 = this.fieldNumber; //P2             
            // 0x0298AC94: MOV x2, x19                | X2 = dest;//m1                          
            val_14 = val_10;
            // 0x0298AC98: MOV x24, x0                | X24 = val_2.value;//m1                  
            // 0x0298AC9C: BL #0x2989d9c              | ProtoBuf.ProtoWriter.SetPackedField(fieldNumber:  val_2.value, writer:  this.fieldNumber);
            ProtoBuf.ProtoWriter.SetPackedField(fieldNumber:  val_2.value, writer:  this.fieldNumber);
            // 0x0298ACA0: AND x8, x24, #0xffffffff   | X8 = (val_2.value & 4294967295);        
            val_17 = val_2.value & 4294967295;
            // 0x0298ACA4: B #0x298acb0               |  goto label_11;                         
            goto label_11;
            label_8:
            // 0x0298ACA8: STR w8, [sp, #0xc]         | stack[1152921514433154732] = this.options;  //  dest_result_addr=1152921514433154732
            // 0x0298ACAC: MOV x8, xzr                | X8 = 0 (0x0);//ML01                     
            val_17 = 0;
            label_11:
            // 0x0298ACB0: STR x8, [sp]               | stack[1152921514433154720] = 0x0;        //  dest_result_addr=1152921514433154720
            // 0x0298ACB4: CMP w23, #1                | STATE = COMPARE(0x0, 0x1)               
            // 0x0298ACB8: B.LT #0x298addc            | if (val_11 < 0x1) goto label_12;        
            if(val_11 < 1)
            {
                goto label_12;
            }
            // 0x0298ACBC: LDRB w8, [x20, #0x1c]      | W8 = this.options; //P2                 
            byte val_8 = this.options;
            // 0x0298ACC0: ADRP x19, #0x35e1000       | X19 = 56496128 (0x35E1000);             
            // 0x0298ACC4: LDR x19, [x19, #0xbd0]     | X19 = 1152921504885653504;              
            val_10 = 1152921504885653504;
            // 0x0298ACC8: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            // 0x0298ACCC: AND w8, w8, #4             | W8 = (this.options & 4);                
            val_8 = val_8 & 4;
            // 0x0298ACD0: AND w24, w8, #0xff         | W24 = ((this.options & 4) & 255);       
            byte val_3 = val_8 & 255;
            label_25:
            // 0x0298ACD4: CBZ w28, #0x298acdc        | if (0x1 == 0) goto label_13;            
            if(val_12 == 0)
            {
                goto label_13;
            }
            // 0x0298ACD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_13:
            // 0x0298ACDC: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x0298ACE0: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            var val_12 = 1179403647;
            // 0x0298ACE4: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x0298ACE8: LDR x1, [x9]               | X1 = typeof(System.Collections.IList);  
            // 0x0298ACEC: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x0298ACF0: CBZ x9, #0x298ad1c         | if (mem[282584257676929] == 0) goto label_14;
            if(mem[282584257676929] == 0)
            {
                goto label_14;
            }
            // 0x0298ACF4: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_9 = mem[282584257676823];
            // 0x0298ACF8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x0298ACFC: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_9 = val_9 + 8;
            label_16:
            // 0x0298AD00: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x0298AD04: CMP x12, x1                | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(System.Collections.IList))
            // 0x0298AD08: B.EQ #0x298ad2c            | if ((mem[282584257676823] + 8) + -8 == null) goto label_15;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_15;
            }
            // 0x0298AD0C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x0298AD10: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_9 = val_9 + 16;
            // 0x0298AD14: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x0298AD18: B.LO #0x298ad00            | if (0 < mem[282584257676929]) goto label_16;
            if(val_10 < mem[282584257676929])
            {
                goto label_16;
            }
            label_14:
            // 0x0298AD1C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            val_14 = 2;
            // 0x0298AD20: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            val_18 = val_13;
            // 0x0298AD24: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x0298AD28: B #0x298ad3c               |  goto label_17;                         
            goto label_17;
            label_15:
            // 0x0298AD2C: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_11 = val_9;
            // 0x0298AD30: ADD w9, w9, #2             | W9 = ((mem[282584257676823] + 8) + 2);  
            val_11 = val_11 + 2;
            // 0x0298AD34: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 2));
            val_12 = val_12 + val_11;
            // 0x0298AD38: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 2)) + 272);
            val_18 = val_12 + 272;
            label_17:
            // 0x0298AD3C: LDP x8, x2, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 2)) + 272); X2 = ((1179403647 + ((mem[282584257676823] + 8) + 2)) + 272) + 8; //  | 
            // 0x0298AD40: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x0298AD44: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
            // 0x0298AD48: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 2)) + 272)();
            // 0x0298AD4C: MOV x26, x0                | X26 = 0 (0x0);//ML01                    
            // 0x0298AD50: CBNZ w24, #0x298ad58       | if (((this.options & 4) & 255) != 0) goto label_18;
            if(val_3 != 0)
            {
                goto label_18;
            }
            // 0x0298AD54: CBZ x26, #0x298ae34        | if (0x0 == 0) goto label_19;            
            if(val_11 == 0)
            {
                goto label_19;
            }
            label_18:
            // 0x0298AD58: LDR x27, [x20, #0x10]      | 
            // 0x0298AD5C: CBNZ x27, #0x298ad64       | if (X27 != 0) goto label_20;            
            if(X27 != 0)
            {
                goto label_20;
            }
            // 0x0298AD60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_20:
            // 0x0298AD64: LDR x8, [x27]              | X8 = X27;                               
            var val_16 = X27;
            // 0x0298AD68: LDR x1, [x19]              | X1 = typeof(ProtoBuf.Serializers.IProtoSerializer);
            // 0x0298AD6C: LDRH w9, [x8, #0x102]      | W9 = X27 + 258;                         
            // 0x0298AD70: CBZ x9, #0x298ad9c         | if (X27 + 258 == 0) goto label_21;      
            if((X27 + 258) == 0)
            {
                goto label_21;
            }
            // 0x0298AD74: LDR x10, [x8, #0x98]       | X10 = X27 + 152;                        
            var val_13 = X27 + 152;
            // 0x0298AD78: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_14 = 0;
            // 0x0298AD7C: ADD x10, x10, #8           | X10 = (X27 + 152 + 8);                  
            val_13 = val_13 + 8;
            label_23:
            // 0x0298AD80: LDUR x12, [x10, #-8]       | X12 = (X27 + 152 + 8) + -8;             
            // 0x0298AD84: CMP x12, x1                | STATE = COMPARE((X27 + 152 + 8) + -8, typeof(ProtoBuf.Serializers.IProtoSerializer))
            // 0x0298AD88: B.EQ #0x298adac            | if ((X27 + 152 + 8) + -8 == null) goto label_22;
            if(((X27 + 152 + 8) + -8) == null)
            {
                goto label_22;
            }
            // 0x0298AD8C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_14 = val_14 + 1;
            // 0x0298AD90: ADD x10, x10, #0x10        | X10 = ((X27 + 152 + 8) + 16);           
            val_13 = val_13 + 16;
            // 0x0298AD94: CMP x11, x9                | STATE = COMPARE((0 + 1), X27 + 258)     
            // 0x0298AD98: B.LO #0x298ad80            | if (0 < X27 + 258) goto label_23;       
            if(val_14 < (X27 + 258))
            {
                goto label_23;
            }
            label_21:
            // 0x0298AD9C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0298ADA0: MOV x0, x27                | X0 = X27;//m1                           
            val_19 = X27;
            // 0x0298ADA4: BL #0x2776c24              | X0 = sub_2776C24( ?? X27, ????);        
            // 0x0298ADA8: B #0x298adbc               |  goto label_24;                         
            goto label_24;
            label_22:
            // 0x0298ADAC: LDR w9, [x10]              | W9 = (X27 + 152 + 8);                   
            var val_15 = val_13;
            // 0x0298ADB0: ADD w9, w9, #1             | W9 = ((X27 + 152 + 8) + 1);             
            val_15 = val_15 + 1;
            // 0x0298ADB4: ADD x8, x8, w9, uxtw #4    | X8 = (X27 + ((X27 + 152 + 8) + 1));     
            val_16 = val_16 + val_15;
            // 0x0298ADB8: ADD x0, x8, #0x110         | X0 = ((X27 + ((X27 + 152 + 8) + 1)) + 272);
            val_19 = val_16 + 272;
            label_24:
            // 0x0298ADBC: LDP x8, x3, [x0]           | X8 = ((X27 + ((X27 + 152 + 8) + 1)) + 272); X3 = ((X27 + ((X27 + 152 + 8) + 1)) + 272) + 8; //  | 
            // 0x0298ADC0: LDR x2, [sp, #0x10]        | X2 = dest;                              
            // 0x0298ADC4: MOV x0, x27                | X0 = X27;//m1                           
            // 0x0298ADC8: MOV x1, x26                | X1 = 0 (0x0);//ML01                     
            // 0x0298ADCC: BLR x8                     | X0 = ((X27 + ((X27 + 152 + 8) + 1)) + 272)();
            // 0x0298ADD0: ADD w25, w25, #1           | W25 = (0 + 1);                          
            val_16 = 0 + 1;
            // 0x0298ADD4: CMP w25, w23               | STATE = COMPARE((0 + 1), 0x0)           
            // 0x0298ADD8: B.LT #0x298acd4            | if (val_16 < val_11) goto label_25;     
            if(val_16 < val_11)
            {
                goto label_25;
            }
            label_12:
            // 0x0298ADDC: LDR w8, [sp, #0xc]         | W8 = this.options;                      
            byte val_17 = this.options;
            // 0x0298ADE0: AND w8, w8, #1             | W8 = (this.options & 1);                
            val_17 = val_17 & 1;
            // 0x0298ADE4: CBZ w8, #0x298ae14         | if ((this.options & 1) == 0) goto label_26;
            if(val_17 == 0)
            {
                goto label_26;
            }
            // 0x0298ADE8: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x0298ADEC: LDR x8, [x8, #0x778]       | X8 = 1152921504884428800;               
            // 0x0298ADF0: LDR x0, [x8]               | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x0298ADF4: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x0298ADF8: TBZ w8, #0, #0x298ae08     | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x0298ADFC: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x0298AE00: CBNZ w8, #0x298ae08        | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x0298AE04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_28:
            // 0x0298AE08: LDR x1, [sp]               | X1 = 0x0;                               
            // 0x0298AE0C: LDR x2, [sp, #0x10]        | X2 = dest;                              
            // 0x0298AE10: BL #0x2977fd0              | ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken() {value = 277581824}, writer:  val_17);
            ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken() {value = 277581824}, writer:  val_17);
            label_26:
            // 0x0298AE14: SUB sp, x29, #0x50         | SP = (1152921514433154832 - 80) = 1152921514433154752 (0x1000000249B18EC0);
            // 0x0298AE18: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0298AE1C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0298AE20: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0298AE24: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0298AE28: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0298AE2C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0298AE30: RET                        |  return;                                
            return;
            label_19:
            // 0x0298AE34: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x0298AE38: LDR x8, [x8, #0x688]       | X8 = 1152921504655462400;               
            // 0x0298AE3C: LDR x0, [x8]               | X0 = typeof(System.NullReferenceException);
            System.NullReferenceException val_4 = null;
            // 0x0298AE40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NullReferenceException), ????);
            // 0x0298AE44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298AE48: MOV x19, x0                | X19 = 1152921504655462400 (0x1000000002E5D000);//ML01
            // 0x0298AE4C: BL #0x1701740              | .ctor();                                
            val_4 = new System.NullReferenceException();
            // 0x0298AE50: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x0298AE54: LDR x8, [x8, #0x478]       | X8 = 1152921514433141824;               
            // 0x0298AE58: MOV x0, x19                | X0 = 1152921504655462400 (0x1000000002E5D000);//ML01
            // 0x0298AE5C: LDR x1, [x8]               | X1 = public System.Void ProtoBuf.Serializers.ArrayDecorator::Write(object value, ProtoBuf.ProtoWriter dest);
            // 0x0298AE60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NullReferenceException), ????);
            // 0x0298AE64: BL #0x296f794              | X0 = get_AllowParseableTypes();         
            bool val_5 = AllowParseableTypes;
            // 0x0298AE68: MOV x19, x0                | X19 = val_5;//m1                        
            // 0x0298AE6C: ADD x0, sp, #0x18          | X0 = (1152921514433154720 + 24) = 1152921514433154744 (0x1000000249B18EB8);
            // 0x0298AE70: BL #0x299a140              | 
            // 0x0298AE74: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x0298AE78: BL #0x980800               | X0 = sub_980800( ?? val_5, ????);       
        
        }
        //
        // Offset in libil2cpp.so: 0x0298AE7C (43560572), len: 1212  VirtAddr: 0x0298AE7C RVA: 0x0298AE7C token: 100689799 methodIndex: 53998 delegateWrapperIndex: 0 methodInvoker: 0
        public override object Read(object value, ProtoBuf.ProtoReader source)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_14;
            //  | 
            var val_20;
            //  | 
            var val_22;
            //  | 
            var val_24;
            //  | 
            int val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            int val_28;
            //  | 
            var val_29;
            // 0x0298AE7C: STP x26, x25, [sp, #-0x50]! | stack[1152921514433303632] = ???;  stack[1152921514433303640] = ???;  //  dest_result_addr=1152921514433303632 |  dest_result_addr=1152921514433303640
            // 0x0298AE80: STP x24, x23, [sp, #0x10]  | stack[1152921514433303648] = ???;  stack[1152921514433303656] = ???;  //  dest_result_addr=1152921514433303648 |  dest_result_addr=1152921514433303656
            // 0x0298AE84: STP x22, x21, [sp, #0x20]  | stack[1152921514433303664] = ???;  stack[1152921514433303672] = ???;  //  dest_result_addr=1152921514433303664 |  dest_result_addr=1152921514433303672
            // 0x0298AE88: STP x20, x19, [sp, #0x30]  | stack[1152921514433303680] = ???;  stack[1152921514433303688] = ???;  //  dest_result_addr=1152921514433303680 |  dest_result_addr=1152921514433303688
            // 0x0298AE8C: STP x29, x30, [sp, #0x40]  | stack[1152921514433303696] = ???;  stack[1152921514433303704] = ???;  //  dest_result_addr=1152921514433303696 |  dest_result_addr=1152921514433303704
            // 0x0298AE90: ADD x29, sp, #0x40         | X29 = (1152921514433303632 + 64) = 1152921514433303696 (0x1000000249B3D490);
            // 0x0298AE94: SUB sp, sp, #0x20          | SP = (1152921514433303632 - 32) = 1152921514433303600 (0x1000000249B3D430);
            // 0x0298AE98: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298AE9C: LDRB w8, [x19, #0xf12]     | W8 = (bool)static_value_037B8F12;       
            // 0x0298AEA0: MOV x22, x2                | X22 = source;//m1                       
            // 0x0298AEA4: MOV x20, x1                | X20 = value;//m1                        
            val_24 = value;
            // 0x0298AEA8: MOV x21, x0                | X21 = 1152921514433315712 (0x1000000249B40380);//ML01
            // 0x0298AEAC: TBNZ w8, #0, #0x298aec8    | if (static_value_037B8F12 == true) goto label_0;
            // 0x0298AEB0: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x0298AEB4: LDR x8, [x8, #0x310]       | X8 = 0x2B8E724;                         
            // 0x0298AEB8: LDR w0, [x8]               | W0 = 0x1087;                            
            // 0x0298AEBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1087, ????);     
            // 0x0298AEC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298AEC4: STRB w8, [x19, #0xf12]     | static_value_037B8F12 = true;            //  dest_result_addr=58429202
            label_0:
            // 0x0298AEC8: CBNZ x22, #0x298aed0       | if (source != null) goto label_1;       
            if(source != null)
            {
                goto label_1;
            }
            // 0x0298AECC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1087, ????);     
            label_1:
            // 0x0298AED0: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x0298AED4: LDR w23, [x22, #0x28]      | W23 = source.fieldNumber; //P2          
            val_25 = source.fieldNumber;
            // 0x0298AED8: LDR x8, [x8, #0x8f0]       | X8 = 1152921504882405376;               
            // 0x0298AEDC: LDR x0, [x8]               | X0 = typeof(ProtoBuf.Meta.BasicList);   
            ProtoBuf.Meta.BasicList val_1 = null;
            // 0x0298AEE0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ProtoBuf.Meta.BasicList), ????);
            // 0x0298AEE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298AEE8: MOV x19, x0                | X19 = 1152921504882405376 (0x10000000106CB000);//ML01
            // 0x0298AEEC: BL #0xc7ee20               | .ctor();                                
            val_1 = new ProtoBuf.Meta.BasicList();
            // 0x0298AEF0: LDR w8, [x21, #0x20]       | W8 = this.packedWireType; //P2          
            // 0x0298AEF4: CMN w8, #1                 | STATE = COMPARE(this.packedWireType, 0x1)
            // 0x0298AEF8: B.EQ #0x298af40            | if (this.packedWireType == 0x1) goto label_14;
            if(this.packedWireType == 1)
            {
                goto label_14;
            }
            // 0x0298AEFC: LDR w8, [x22, #0x44]       | W8 = source.wireType; //P2              
            // 0x0298AF00: CMP w8, #2                 | STATE = COMPARE(source.wireType, 0x2)   
            // 0x0298AF04: B.NE #0x298af40            | if (source.wireType != 0x2) goto label_14;
            if(source.wireType != 2)
            {
                goto label_14;
            }
            // 0x0298AF08: ADRP x25, #0x367b000       | X25 = 57126912 (0x367B000);             
            // 0x0298AF0C: LDR x25, [x25, #0x668]     | X25 = 1152921504884375552;              
            // 0x0298AF10: LDR x0, [x25]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x0298AF14: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x0298AF18: TBZ w8, #0, #0x298af28     | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0298AF1C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x0298AF20: CBNZ w8, #0x298af28        | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0298AF24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_5:
            // 0x0298AF28: MOV x1, x22                | X1 = source;//m1                        
            // 0x0298AF2C: BL #0x297e198              | X0 = ProtoBuf.ProtoReader.StartSubItem(reader:  null);
            ProtoBuf.SubItemToken val_2 = ProtoBuf.ProtoReader.StartSubItem(reader:  null);
            // 0x0298AF30: ADRP x26, #0x35e1000       | X26 = 56496128 (0x35E1000);             
            // 0x0298AF34: LDR x26, [x26, #0xbd0]     | X26 = 1152921504885653504;              
            // 0x0298AF38: MOV x23, x0                | X23 = val_2.value;//m1                  
            val_25 = val_2.value;
            // 0x0298AF3C: B #0x298b00c               |  goto label_6;                          
            goto label_6;
            label_14:
            // 0x0298AF40: LDR x24, [x21, #0x10]      | 
            // 0x0298AF44: CBNZ x24, #0x298af4c       | if (X24 != 0) goto label_7;             
            if(X24 != 0)
            {
                goto label_7;
            }
            // 0x0298AF48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_7:
            // 0x0298AF4C: ADRP x9, #0x35e1000        | X9 = 56496128 (0x35E1000);              
            // 0x0298AF50: LDR x8, [x24]              | X8 = X24;                               
            var val_26 = X24;
            // 0x0298AF54: LDR x9, [x9, #0xbd0]       | X9 = 1152921504885653504;               
            // 0x0298AF58: LDR x1, [x9]               | X1 = typeof(ProtoBuf.Serializers.IProtoSerializer);
            // 0x0298AF5C: LDRH w9, [x8, #0x102]      | W9 = X24 + 258;                         
            // 0x0298AF60: CBZ x9, #0x298af8c         | if (X24 + 258 == 0) goto label_8;       
            if((X24 + 258) == 0)
            {
                goto label_8;
            }
            // 0x0298AF64: LDR x10, [x8, #0x98]       | X10 = X24 + 152;                        
            var val_23 = X24 + 152;
            // 0x0298AF68: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_24 = 0;
            // 0x0298AF6C: ADD x10, x10, #8           | X10 = (X24 + 152 + 8);                  
            val_23 = val_23 + 8;
            label_10:
            // 0x0298AF70: LDUR x12, [x10, #-8]       | X12 = (X24 + 152 + 8) + -8;             
            // 0x0298AF74: CMP x12, x1                | STATE = COMPARE((X24 + 152 + 8) + -8, typeof(ProtoBuf.Serializers.IProtoSerializer))
            // 0x0298AF78: B.EQ #0x298af9c            | if ((X24 + 152 + 8) + -8 == null) goto label_9;
            if(((X24 + 152 + 8) + -8) == null)
            {
                goto label_9;
            }
            // 0x0298AF7C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_24 = val_24 + 1;
            // 0x0298AF80: ADD x10, x10, #0x10        | X10 = ((X24 + 152 + 8) + 16);           
            val_23 = val_23 + 16;
            // 0x0298AF84: CMP x11, x9                | STATE = COMPARE((0 + 1), X24 + 258)     
            // 0x0298AF88: B.LO #0x298af70            | if (0 < X24 + 258) goto label_10;       
            if(val_24 < (X24 + 258))
            {
                goto label_10;
            }
            label_8:
            // 0x0298AF8C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0298AF90: MOV x0, x24                | X0 = X24;//m1                           
            val_26 = X24;
            // 0x0298AF94: BL #0x2776c24              | X0 = sub_2776C24( ?? X24, ????);        
            // 0x0298AF98: B #0x298afac               |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x0298AF9C: LDR w9, [x10]              | W9 = (X24 + 152 + 8);                   
            var val_25 = val_23;
            // 0x0298AFA0: ADD w9, w9, #2             | W9 = ((X24 + 152 + 8) + 2);             
            val_25 = val_25 + 2;
            // 0x0298AFA4: ADD x8, x8, w9, uxtw #4    | X8 = (X24 + ((X24 + 152 + 8) + 2));     
            val_26 = val_26 + val_25;
            // 0x0298AFA8: ADD x0, x8, #0x110         | X0 = ((X24 + ((X24 + 152 + 8) + 2)) + 272);
            val_26 = val_26 + 272;
            label_11:
            // 0x0298AFAC: LDP x8, x3, [x0]           | X8 = ((X24 + ((X24 + 152 + 8) + 2)) + 272); X3 = ((X24 + ((X24 + 152 + 8) + 2)) + 272) + 8; //  | 
            // 0x0298AFB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298AFB4: MOV x0, x24                | X0 = X24;//m1                           
            // 0x0298AFB8: MOV x2, x22                | X2 = source;//m1                        
            // 0x0298AFBC: BLR x8                     | X0 = ((X24 + ((X24 + 152 + 8) + 2)) + 272)();
            // 0x0298AFC0: MOV x24, x0                | X24 = X24;//m1                          
            // 0x0298AFC4: CBNZ x19, #0x298afcc       | if ( != 0) goto label_12;               
            if(null != 0)
            {
                goto label_12;
            }
            // 0x0298AFC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X24, ????);        
            label_12:
            // 0x0298AFCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0298AFD0: MOV x0, x19                | X0 = 1152921504882405376 (0x10000000106CB000);//ML01
            // 0x0298AFD4: MOV x1, x24                | X1 = X24;//m1                           
            // 0x0298AFD8: BL #0xc7ef38               | X0 = Add(value:  X24);                  
            int val_3 = Add(value:  X24);
            // 0x0298AFDC: CBNZ x22, #0x298afe4       | if (source != null) goto label_13;      
            if(source != null)
            {
                goto label_13;
            }
            // 0x0298AFE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_13:
            // 0x0298AFE4: MOV x0, x22                | X0 = source;//m1                        
            // 0x0298AFE8: MOV w1, w23                | W1 = source.fieldNumber;//m1            
            // 0x0298AFEC: BL #0x2986a48              | X0 = source.TryReadFieldHeader(field:  val_25);
            bool val_4 = source.TryReadFieldHeader(field:  val_25);
            // 0x0298AFF0: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x0298AFF4: TBNZ w8, #0, #0x298af40    | if ((val_4 & 1) == true) goto label_14; 
            if(val_5 == true)
            {
                goto label_14;
            }
            // 0x0298AFF8: B #0x298b0e8               |  goto label_15;                         
            goto label_15;
            label_25:
            // 0x0298AFFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0298B000: MOV x0, x19                | X0 = 1152921504882405376 (0x10000000106CB000);//ML01
            // 0x0298B004: MOV x1, x24                | X1 = X24;//m1                           
            // 0x0298B008: BL #0xc7ef38               | X0 = Add(value:  X24);                  
            int val_6 = Add(value:  X24);
            label_6:
            // 0x0298B00C: LDR x0, [x25]              | X0 = X25;                               
            // 0x0298B010: LDR w24, [x21, #0x20]      | W24 = this.packedWireType; //P2         
            // 0x0298B014: LDRB w8, [x0, #0x10a]      | W8 = X25 + 266;                         
            // 0x0298B018: TBZ w8, #0, #0x298b028     | if ((X25 + 266 & 0x1) == 0) goto label_17;
            if(((X25 + 266) & 1) == 0)
            {
                goto label_17;
            }
            // 0x0298B01C: LDR w8, [x0, #0xbc]        | W8 = X25 + 188;                         
            // 0x0298B020: CBNZ w8, #0x298b028        | if (X25 + 188 != 0) goto label_17;      
            if((X25 + 188) != 0)
            {
                goto label_17;
            }
            // 0x0298B024: BL #0x27977a4              | X0 = sub_27977A4( ?? X25, ????);        
            label_17:
            // 0x0298B028: MOV w1, w24                | W1 = this.packedWireType;//m1           
            // 0x0298B02C: MOV x2, x22                | X2 = source;//m1                        
            // 0x0298B030: BL #0x2987954              | X0 = ProtoBuf.ProtoReader.HasSubValue(wireType:  X25, source:  this.packedWireType);
            bool val_7 = ProtoBuf.ProtoReader.HasSubValue(wireType:  X25, source:  this.packedWireType);
            // 0x0298B034: AND w8, w0, #1             | W8 = (val_7 & 1);                       
            bool val_8 = val_7;
            // 0x0298B038: TBZ w8, #0, #0x298b0c4     | if ((val_7 & 1) == false) goto label_18;
            if(val_8 == false)
            {
                goto label_18;
            }
            // 0x0298B03C: LDR x24, [x21, #0x10]      | 
            // 0x0298B040: CBNZ x24, #0x298b048       | if (this.packedWireType != 0) goto label_19;
            if(this.packedWireType != 0)
            {
                goto label_19;
            }
            // 0x0298B044: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_19:
            // 0x0298B048: LDR x8, [x24]              | X8 = typeof(ProtoBuf.WireType);         
            // 0x0298B04C: LDR x1, [x26]              | X1 = X26;                               
            // 0x0298B050: LDRH w9, [x8, #0x102]      | W9 = ProtoBuf.WireType.__il2cppRuntimeField_interface_offsets_count;
            // 0x0298B054: CBZ x9, #0x298b080         | if (ProtoBuf.WireType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_20;
            // 0x0298B058: LDR x10, [x8, #0x98]       | X10 = ProtoBuf.WireType.__il2cppRuntimeField_interfaceOffsets;
            // 0x0298B05C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_27 = 0;
            // 0x0298B060: ADD x10, x10, #8           | X10 = (ProtoBuf.WireType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504887021576 (0x1000000010B32008);
            label_22:
            // 0x0298B064: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x0298B068: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X26)
            // 0x0298B06C: B.EQ #0x298b090            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X26) goto label_21;
            // 0x0298B070: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_27 = val_27 + 1;
            // 0x0298B074: ADD x10, x10, #0x10        | X10 = (1152921504887021576 + 16) = 1152921504887021592 (0x1000000010B32018);
            // 0x0298B078: CMP x11, x9                | STATE = COMPARE((0 + 1), ProtoBuf.WireType.__il2cppRuntimeField_interface_offsets_count)
            // 0x0298B07C: B.LO #0x298b064            | if (0 < ProtoBuf.WireType.__il2cppRuntimeField_interface_offsets_count) goto label_22;
            label_20:
            // 0x0298B080: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0298B084: MOV x0, x24                | X0 = this.packedWireType;//m1           
            val_27 = this.packedWireType;
            // 0x0298B088: BL #0x2776c24              | X0 = sub_2776C24( ?? this.packedWireType, ????);
            // 0x0298B08C: B #0x298b0a0               |  goto label_23;                         
            goto label_23;
            label_21:
            // 0x0298B090: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x0298B094: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x0298B098: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504886984704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x0298B09C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504886984704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_23:
            // 0x0298B0A0: LDP x8, x3, [x0]           | X8 = val_7; X3 = val_7 + 8;              //  | 
            // 0x0298B0A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B0A8: MOV x0, x24                | X0 = this.packedWireType;//m1           
            // 0x0298B0AC: MOV x2, x22                | X2 = source;//m1                        
            // 0x0298B0B0: BLR x8                     | X0 = val_7();                           
            // 0x0298B0B4: MOV x24, x0                | X24 = this.packedWireType;//m1          
            // 0x0298B0B8: CBNZ x19, #0x298affc       | if ( != 0) goto label_25;               
            if(null != 0)
            {
                goto label_25;
            }
            // 0x0298B0BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.packedWireType, ????);
            // 0x0298B0C0: B #0x298affc               |  goto label_25;                         
            goto label_25;
            label_18:
            // 0x0298B0C4: LDR x0, [x25]              | X0 = X25;                               
            // 0x0298B0C8: LDRB w8, [x0, #0x10a]      | W8 = X25 + 266;                         
            // 0x0298B0CC: TBZ w8, #0, #0x298b0dc     | if ((X25 + 266 & 0x1) == 0) goto label_27;
            if(((X25 + 266) & 1) == 0)
            {
                goto label_27;
            }
            // 0x0298B0D0: LDR w8, [x0, #0xbc]        | W8 = X25 + 188;                         
            // 0x0298B0D4: CBNZ w8, #0x298b0dc        | if (X25 + 188 != 0) goto label_27;      
            if((X25 + 188) != 0)
            {
                goto label_27;
            }
            // 0x0298B0D8: BL #0x27977a4              | X0 = sub_27977A4( ?? X25, ????);        
            label_27:
            // 0x0298B0DC: AND x1, x23, #0xffffffff   | X1 = (source.fieldNumber & 4294967295); 
            int val_10 = val_25 & 4294967295;
            // 0x0298B0E0: MOV x2, x22                | X2 = source;//m1                        
            // 0x0298B0E4: BL #0x297e2fc              | ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken() {value = X25}, reader:  int val_10 = val_25 & 4294967295);
            ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken() {value = X25}, reader:  val_10);
            label_15:
            // 0x0298B0E8: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_28 = 0;
            // 0x0298B0EC: CBZ x20, #0x298b1c0        | if (value == null) goto label_29;       
            if(val_24 == null)
            {
                goto label_29;
            }
            // 0x0298B0F0: LDRB w8, [x21, #0x1c]      | W8 = this.options; //P2                 
            byte val_28 = this.options;
            // 0x0298B0F4: AND w8, w8, #2             | W8 = (this.options & 2);                
            val_28 = val_28 & 2;
            // 0x0298B0F8: AND w8, w8, #0xff          | W8 = ((this.options & 2) & 255);        
            val_28 = val_28 & 255;
            // 0x0298B0FC: CBNZ w8, #0x298b1c0        | if (((this.options & 2) & 255) != 0) goto label_29;
            if(val_28 != 0)
            {
                goto label_29;
            }
            // 0x0298B100: ADRP x22, #0x35f1000       | X22 = 56561664 (0x35F1000);             
            // 0x0298B104: LDR x22, [x22, #0xcc0]     | X22 = 1152921504608976896;              
            // 0x0298B108: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0298B10C: LDR x1, [x22]              | X1 = typeof(System.Array);              
            // 0x0298B110: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0298B114: LDRB w9, [x1, #0x104]      | W9 = System.Array.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0298B118: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Array.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0298B11C: B.LO #0x298b134            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Array.__il2cppRuntimeField_typeHierarchyDepth) goto label_30;
            // 0x0298B120: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0298B124: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHier
            // 0x0298B128: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0298B12C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Array))
            // 0x0298B130: B.EQ #0x298b15c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_31;
            label_30:
            // 0x0298B134: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298B138: ADD x8, sp, #8             | X8 = (1152921514433303600 + 8) = 1152921514433303608 (0x1000000249B3D438);
            // 0x0298B13C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298B140: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921514433291712]
            // 0x0298B144: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x0298B148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B14C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x0298B150: ADD x0, sp, #8             | X0 = (1152921514433303600 + 8) = 1152921514433303608 (0x1000000249B3D438);
            // 0x0298B154: BL #0x299a140              | 
            // 0x0298B158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000249B3D438, ????);
            label_31:
            // 0x0298B15C: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0298B160: LDR x1, [x22]              | X1 = typeof(System.Array);              
            // 0x0298B164: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0298B168: LDRB w9, [x1, #0x104]      | W9 = System.Array.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0298B16C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Array.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0298B170: B.LO #0x298b18c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Array.__il2cppRuntimeField_typeHierarchyDepth) goto label_32;
            // 0x0298B174: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0298B178: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHier
            // 0x0298B17C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0298B180: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Array))
            // 0x0298B184: MOV x0, x20                | X0 = value;//m1                         
            val_29 = val_24;
            // 0x0298B188: B.EQ #0x298b1b4            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_33;
            label_32:
            // 0x0298B18C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298B190: ADD x8, sp, #0x10          | X8 = (1152921514433303600 + 16) = 1152921514433303616 (0x1000000249B3D440);
            // 0x0298B194: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298B198: LDR x0, [sp, #0x10]        | X0 = val_14;                             //  find_add[1152921514433291712]
            // 0x0298B19C: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x0298B1A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B1A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x0298B1A8: ADD x0, sp, #0x10          | X0 = (1152921514433303600 + 16) = 1152921514433303616 (0x1000000249B3D440);
            // 0x0298B1AC: BL #0x299a140              | 
            // 0x0298B1B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_29 = 0;
            label_33:
            // 0x0298B1B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B1B8: BL #0x18cbcf0              | X0 = val_29.get_Length();               
            int val_15 = val_29.Length;
            // 0x0298B1BC: MOV w22, w0                | W22 = val_15;//m1                       
            val_28 = val_15;
            label_29:
            // 0x0298B1C0: LDR x21, [x21, #0x30]      | X21 = this.itemType; //P2               
            // 0x0298B1C4: CBNZ x19, #0x298b1cc       | if ( != 0) goto label_34;               
            if(null != 0)
            {
                goto label_34;
            }
            // 0x0298B1C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_34:
            // 0x0298B1CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B1D0: MOV x0, x19                | X0 = 1152921504882405376 (0x10000000106CB000);//ML01
            // 0x0298B1D4: BL #0xc7f2f8               | X0 = get_Count();                       
            int val_16 = Count;
            // 0x0298B1D8: ADD w2, w0, w22            | W2 = (val_16 + val_15);                 
            int val_17 = val_16 + val_28;
            // 0x0298B1DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0298B1E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0298B1E4: MOV x1, x21                | X1 = this.itemType;//m1                 
            // 0x0298B1E8: BL #0x18cd230              | X0 = System.Array.CreateInstance(elementType:  0, length:  this.itemType);
            System.Array val_18 = System.Array.CreateInstance(elementType:  0, length:  this.itemType);
            // 0x0298B1EC: MOV x21, x0                | X21 = val_18;//m1                       
            // 0x0298B1F0: CBZ w22, #0x298b2c4        | if (val_15 == 0) goto label_35;         
            if(val_28 == 0)
            {
                goto label_35;
            }
            // 0x0298B1F4: CBZ x20, #0x298b2a8        | if (value == null) goto label_36;       
            if(val_24 == null)
            {
                goto label_36;
            }
            // 0x0298B1F8: ADRP x23, #0x35f1000       | X23 = 56561664 (0x35F1000);             
            // 0x0298B1FC: LDR x23, [x23, #0xcc0]     | X23 = 1152921504608976896;              
            val_25 = 1152921504608976896;
            // 0x0298B200: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0298B204: LDR x1, [x23]              | X1 = typeof(System.Array);              
            // 0x0298B208: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0298B20C: LDRB w9, [x1, #0x104]      | W9 = System.Array.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0298B210: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Array.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0298B214: B.LO #0x298b22c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Array.__il2cppRuntimeField_typeHierarchyDepth) goto label_37;
            // 0x0298B218: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0298B21C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHier
            // 0x0298B220: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0298B224: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Array))
            // 0x0298B228: B.EQ #0x298b254            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_38;
            label_37:
            // 0x0298B22C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298B230: ADD x8, sp, #0x18          | X8 = (1152921514433303600 + 24) = 1152921514433303624 (0x1000000249B3D448);
            // 0x0298B234: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298B238: LDR x0, [sp, #0x18]        | X0 = val_20;                             //  find_add[1152921514433291712]
            // 0x0298B23C: BL #0x27af090              | X0 = sub_27AF090( ?? val_20, ????);     
            // 0x0298B240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B244: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            // 0x0298B248: ADD x0, sp, #0x18          | X0 = (1152921514433303600 + 24) = 1152921514433303624 (0x1000000249B3D448);
            // 0x0298B24C: BL #0x299a140              | 
            // 0x0298B250: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000249B3D448, ????);
            label_38:
            // 0x0298B254: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0298B258: LDR x1, [x23]              | X1 = typeof(System.Array);              
            // 0x0298B25C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0298B260: LDRB w9, [x1, #0x104]      | W9 = System.Array.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0298B264: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Array.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0298B268: B.LO #0x298b280            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Array.__il2cppRuntimeField_typeHierarchyDepth) goto label_39;
            // 0x0298B26C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0298B270: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHier
            // 0x0298B274: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0298B278: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Array))
            // 0x0298B27C: B.EQ #0x298b2b0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_40;
            label_39:
            // 0x0298B280: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298B284: MOV x8, sp                 | X8 = 1152921514433303600 (0x1000000249B3D430);//ML01
            // 0x0298B288: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298B28C: LDR x0, [sp]               | X0 = val_22;                             //  find_add[1152921514433291712]
            // 0x0298B290: BL #0x27af090              | X0 = sub_27AF090( ?? val_22, ????);     
            // 0x0298B294: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B298: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            // 0x0298B29C: MOV x0, sp                 | X0 = 1152921514433303600 (0x1000000249B3D430);//ML01
            // 0x0298B2A0: BL #0x299a140              | 
            // 0x0298B2A4: B #0x298b2ac               |  goto label_41;                         
            goto label_41;
            label_36:
            // 0x0298B2A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_41:
            // 0x0298B2AC: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_24 = 0;
            label_40:
            // 0x0298B2B0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0298B2B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0298B2B8: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x0298B2BC: MOV x1, x21                | X1 = val_18;//m1                        
            // 0x0298B2C0: BL #0x18d10c0              | val_24.CopyTo(array:  val_18, index:  0);
            val_24.CopyTo(array:  val_18, index:  0);
            label_35:
            // 0x0298B2C4: CBNZ x19, #0x298b2cc       | if ( != 0) goto label_42;               
            if(null != 0)
            {
                goto label_42;
            }
            // 0x0298B2C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_42:
            // 0x0298B2CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0298B2D0: MOV x0, x19                | X0 = 1152921504882405376 (0x10000000106CB000);//ML01
            // 0x0298B2D4: MOV x1, x21                | X1 = val_18;//m1                        
            // 0x0298B2D8: MOV w2, w22                | W2 = val_15;//m1                        
            // 0x0298B2DC: BL #0xc7ee98               | CopyTo(array:  val_18, offset:  val_28);
            CopyTo(array:  val_18, offset:  val_28);
            // 0x0298B2E0: MOV x0, x21                | X0 = val_18;//m1                        
            // 0x0298B2E4: SUB sp, x29, #0x40         | SP = (1152921514433303696 - 64) = 1152921514433303632 (0x1000000249B3D450);
            // 0x0298B2E8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B2EC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0298B2F0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0298B2F4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0298B2F8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0298B2FC: RET                        |  return (System.Object)val_18;          
            return (object)val_18;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            // 0x0298B300: MOV x19, x0                | 
            // 0x0298B304: ADD x0, sp, #8             | 
            // 0x0298B308: B #0x298b32c               | 
            // 0x0298B30C: MOV x19, x0                | 
            // 0x0298B310: ADD x0, sp, #0x10          | 
            // 0x0298B314: B #0x298b32c               | 
            // 0x0298B318: MOV x19, x0                | 
            // 0x0298B31C: ADD x0, sp, #0x18          | 
            // 0x0298B320: B #0x298b32c               | 
            // 0x0298B324: MOV x19, x0                | 
            // 0x0298B328: MOV x0, sp                 | 
            label_45:
            // 0x0298B32C: BL #0x299a140              | 
            // 0x0298B330: MOV x0, x19                | 
            // 0x0298B334: BL #0x980800               | 
        
        }
    
    }

}
