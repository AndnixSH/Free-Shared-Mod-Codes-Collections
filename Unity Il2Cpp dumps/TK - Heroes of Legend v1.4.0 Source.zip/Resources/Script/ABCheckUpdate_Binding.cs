using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class ABCheckUpdate_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache12; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache13; // static_offset: 0x00000098
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache14; // static_offset: 0x000000A0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache15; // static_offset: 0x000000A8
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache16; // static_offset: 0x000000B0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache17; // static_offset: 0x000000B8
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache18; // static_offset: 0x000000C0
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache19; // static_offset: 0x000000C8
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache1A; // static_offset: 0x000000D0
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1B; // static_offset: 0x000000D8
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache1C; // static_offset: 0x000000E0
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1D; // static_offset: 0x000000E8
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache1E; // static_offset: 0x000000F0
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1F; // static_offset: 0x000000F8
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x028F4CA8 (42945704), len: 8  VirtAddr: 0x028F4CA8 RVA: 0x028F4CA8 token: 100663631 methodIndex: 29676 delegateWrapperIndex: 0 methodInvoker: 0
        public ABCheckUpdate_Binding()
        {
            //
            // Disasemble & Code
            // 0x028F4CA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F4CAC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028F4CB0 (42945712), len: 6072  VirtAddr: 0x028F4CB0 RVA: 0x028F4CB0 token: 100663632 methodIndex: 29677 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_27;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_28;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_29;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_30;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_31;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_32;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_33;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_34;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_35;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_36;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_37;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_38;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_40;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_41;
            // 0x028F4CB0: STP x26, x25, [sp, #-0x50]! | stack[1152921510024663680] = ???;  stack[1152921510024663688] = ???;  //  dest_result_addr=1152921510024663680 |  dest_result_addr=1152921510024663688
            // 0x028F4CB4: STP x24, x23, [sp, #0x10]  | stack[1152921510024663696] = ???;  stack[1152921510024663704] = ???;  //  dest_result_addr=1152921510024663696 |  dest_result_addr=1152921510024663704
            // 0x028F4CB8: STP x22, x21, [sp, #0x20]  | stack[1152921510024663712] = ???;  stack[1152921510024663720] = ???;  //  dest_result_addr=1152921510024663712 |  dest_result_addr=1152921510024663720
            // 0x028F4CBC: STP x20, x19, [sp, #0x30]  | stack[1152921510024663728] = ???;  stack[1152921510024663736] = ???;  //  dest_result_addr=1152921510024663728 |  dest_result_addr=1152921510024663736
            // 0x028F4CC0: STP x29, x30, [sp, #0x40]  | stack[1152921510024663744] = ???;  stack[1152921510024663752] = ???;  //  dest_result_addr=1152921510024663744 |  dest_result_addr=1152921510024663752
            // 0x028F4CC4: ADD x29, sp, #0x40         | X29 = (1152921510024663680 + 64) = 1152921510024663744 (0x1000000142ED52C0);
            // 0x028F4CC8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F4CCC: LDRB w8, [x20, #0xa43]     | W8 = (bool)static_value_037B8A43;       
            // 0x028F4CD0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F4CD4: TBNZ w8, #0, #0x28f4cf0    | if (static_value_037B8A43 == true) goto label_0;
            // 0x028F4CD8: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x028F4CDC: LDR x8, [x8, #0xec0]       | X8 = 0x2B8A664;                         
            // 0x028F4CE0: LDR w0, [x8]               | W0 = 0x57;                              
            // 0x028F4CE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x57, ????);       
            // 0x028F4CE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F4CEC: STRB w8, [x20, #0xa43]     | static_value_037B8A43 = true;            //  dest_result_addr=58427971
            label_0:
            // 0x028F4CF0: ADRP x24, #0x3620000       | X24 = 56754176 (0x3620000);             
            // 0x028F4CF4: LDR x24, [x24, #0x340]     | X24 = 1152921504609562624;              
            // 0x028F4CF8: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x028F4CFC: LDR x0, [x24]              | X0 = typeof(System.Type);               
            // 0x028F4D00: LDR x8, [x8, #0x120]       | X8 = 1152921504910680064;               
            // 0x028F4D04: LDR x20, [x8]              | X20 = typeof(ABCheckUpdate);            
            // 0x028F4D08: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F4D0C: TBZ w8, #0, #0x28f4d1c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028F4D10: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F4D14: CBNZ w8, #0x28f4d1c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028F4D18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x028F4D1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F4D20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F4D24: MOV x1, x20                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F4D28: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F4D2C: ADRP x25, #0x35ef000       | X25 = 56553472 (0x35EF000);             
            // 0x028F4D30: LDR x25, [x25, #0xff0]     | X25 = 1152921504987155056;              
            // 0x028F4D34: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x028F4D38: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F4D3C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4D40: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F4D44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F4D48: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4D4C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F4D50: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4D54: CBNZ x20, #0x28f4d5c       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x028F4D58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x028F4D5C: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028F4D60: LDR x8, [x8, #0xb0]        | X8 = (string**)(1152921510024513712)("get_GetUpdateTargetVS");
            // 0x028F4D64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F4D68: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F4D6C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F4D70: LDR x1, [x8]               | X1 = "get_GetUpdateTargetVS";           
            // 0x028F4D74: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F4D78: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4D7C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F4D80: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_GetUpdateTargetVS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "get_GetUpdateTargetVS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F4D84: ADRP x23, #0x3656000       | X23 = 56975360 (0x3656000);             
            // 0x028F4D88: LDR x23, [x23, #0x860]     | X23 = 1152921504782458880;              
            // 0x028F4D8C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028F4D90: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F4D94: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F4D98: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache0;
            // 0x028F4D9C: CBNZ x22, #0x28f4de0       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache0 != null) goto label_4;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache0) != null)
            {
                goto label_4;
            }
            // 0x028F4DA0: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x028F4DA4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F4DA8: LDR x8, [x8, #0x848]       | X8 = 1152921510024517920;               
            // 0x028F4DAC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F4DB0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_GetUpdateTargetVS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4DB4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F4DB8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F4DBC: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_GetUpdateTargetVS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4DC0: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_GetUpdateTargetVS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_GetUpdateTargetVS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4DC4: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_GetUpdateTargetVS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_GetUpdateTargetVS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4DC8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F4DCC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F4DD0: STR x0, [x8]               | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782462976
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache0 = null;
            // 0x028F4DD4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F4DD8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F4DDC: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_4:
            // 0x028F4DE0: CBNZ x19, #0x28f4de8       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x028F4DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_5:
            // 0x028F4DE8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F4DEC: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028F4DF0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F4DF4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache0);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache0);
            // 0x028F4DF8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F4DFC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4E00: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F4E04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F4E08: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4E0C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F4E10: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4E14: CBNZ x20, #0x28f4e1c       | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x028F4E18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_6:
            // 0x028F4E1C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028F4E20: LDR x8, [x8, #0x760]       | X8 = (string**)(1152921510024518944)("get_Instance");
            // 0x028F4E24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F4E28: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F4E2C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F4E30: LDR x1, [x8]               | X1 = "get_Instance";                    
            // 0x028F4E34: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F4E38: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4E3C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F4E40: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_Instance", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_3 = val_1.GetMethod(name:  "get_Instance", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F4E44: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F4E48: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F4E4C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F4E50: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1;
            // 0x028F4E54: CBNZ x22, #0x28f4e98       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1 != null) goto label_7;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1) != null)
            {
                goto label_7;
            }
            // 0x028F4E58: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028F4E5C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F4E60: LDR x8, [x8, #0xc58]       | X8 = 1152921510024523136;               
            // 0x028F4E64: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F4E68: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Instance_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4E6C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F4E70: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F4E74: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Instance_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4E78: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Instance_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Instance_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4E7C: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Instance_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Instance_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4E80: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F4E84: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F4E88: STR x0, [x8, #8]           | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782462984
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1 = null;
            // 0x028F4E8C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F4E90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F4E94: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_7:
            // 0x028F4E98: CBNZ x19, #0x28f4ea0       | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x028F4E9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_8:
            // 0x028F4EA0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F4EA4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F4EA8: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F4EAC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_3, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1);
            X1.RegisterCLRMethodRedirection(mi:  val_3, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1);
            // 0x028F4EB0: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F4EB4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4EB8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F4EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F4EC0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4EC4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F4EC8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4ECC: CBNZ x20, #0x28f4ed4       | if (val_1 != null) goto label_9;        
            if(val_1 != null)
            {
                goto label_9;
            }
            // 0x028F4ED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_9:
            // 0x028F4ED4: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
            // 0x028F4ED8: LDR x8, [x8, #0x578]       | X8 = (string**)(1152921510024524160)("get_Version");
            // 0x028F4EDC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F4EE0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F4EE4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F4EE8: LDR x1, [x8]               | X1 = "get_Version";                     
            // 0x028F4EEC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F4EF0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4EF4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F4EF8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_Version", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_4 = val_1.GetMethod(name:  "get_Version", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F4EFC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F4F00: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x028F4F04: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F4F08: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache2;
            // 0x028F4F0C: CBNZ x22, #0x28f4f50       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache2 != null) goto label_10;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache2) != null)
            {
                goto label_10;
            }
            // 0x028F4F10: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x028F4F14: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F4F18: LDR x8, [x8, #0x430]       | X8 = 1152921510024528352;               
            // 0x028F4F1C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F4F20: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Version_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4F24: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F4F28: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F4F2C: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Version_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4F30: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Version_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Version_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4F34: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Version_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Version_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F4F38: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F4F3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F4F40: STR x0, [x8, #0x10]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782462992
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache2 = null;
            // 0x028F4F44: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F4F48: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F4F4C: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_10:
            // 0x028F4F50: CBNZ x19, #0x28f4f58       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F4F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_11:
            // 0x028F4F58: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F4F5C: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x028F4F60: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F4F64: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_4, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache2);
            X1.RegisterCLRMethodRedirection(mi:  val_4, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache2);
            // 0x028F4F68: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F4F6C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4F70: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F4F74: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x028F4F78: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4F7C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F4F80: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x028F4F84: LDR x8, [x24]              | X8 = typeof(System.Type);               
            // 0x028F4F88: LDR x9, [x9, #0xb28]       | X9 = 1152921504911372288;               
            // 0x028F4F8C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F4F90: LDR x22, [x9]              | X22 = typeof(VersionInfo);              
            // 0x028F4F94: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F4F98: TBZ w9, #0, #0x28f4fac     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x028F4F9C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F4FA0: CBNZ w9, #0x28f4fac        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x028F4FA4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F4FA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_13:
            // 0x028F4FAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F4FB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F4FB4: MOV x1, x22                | X1 = 1152921504911372288 (0x100000001226B000);//ML01
            // 0x028F4FB8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F4FBC: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F4FC0: CBNZ x21, #0x28f4fc8       | if ( != null) goto label_14;            
            if(null != null)
            {
                goto label_14;
            }
            // 0x028F4FC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_14:
            // 0x028F4FC8: CBZ x22, #0x28f4fec        | if (val_5 == null) goto label_16;       
            if(val_5 == null)
            {
                goto label_16;
            }
            // 0x028F4FCC: LDR x8, [x21]              | X8 = ;                                  
            // 0x028F4FD0: MOV x0, x22                | X0 = val_5;//m1                         
            // 0x028F4FD4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F4FD8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
            // 0x028F4FDC: CBNZ x0, #0x28f4fec        | if (val_5 != null) goto label_16;       
            if(val_5 != null)
            {
                goto label_16;
            }
            // 0x028F4FE0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
            // 0x028F4FE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F4FE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_16:
            // 0x028F4FEC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028F4FF0: CBNZ w8, #0x28f5000        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_17;
            // 0x028F4FF4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x028F4FF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F4FFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_17:
            // 0x028F5000: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_5;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_5;
            // 0x028F5004: CBNZ x20, #0x28f500c       | if (val_1 != null) goto label_18;       
            if(val_1 != null)
            {
                goto label_18;
            }
            // 0x028F5008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_18:
            // 0x028F500C: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x028F5010: LDR x8, [x8, #0x5c0]       | X8 = (string**)(1152921510024533472)("UpdateVersion");
            // 0x028F5014: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5018: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F501C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5020: LDR x1, [x8]               | X1 = "UpdateVersion";                   
            // 0x028F5024: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5028: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F502C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F5030: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "UpdateVersion", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_6 = val_1.GetMethod(name:  "UpdateVersion", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5034: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5038: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x028F503C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5040: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache3;
            // 0x028F5044: CBNZ x22, #0x28f5088       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache3 != null) goto label_19;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache3) != null)
            {
                goto label_19;
            }
            // 0x028F5048: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x028F504C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5050: LDR x8, [x8, #0xae0]       | X8 = 1152921510024537664;               
            // 0x028F5054: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5058: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::UpdateVersion_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F505C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5060: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5064: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::UpdateVersion_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5068: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::UpdateVersion_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::UpdateVersion_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F506C: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::UpdateVersion_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::UpdateVersion_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5070: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5074: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5078: STR x0, [x8, #0x18]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463000
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache3 = null;
            // 0x028F507C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5080: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5084: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_19:
            // 0x028F5088: CBNZ x19, #0x28f5090       | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x028F508C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_20:
            // 0x028F5090: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5094: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x028F5098: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F509C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache3);
            X1.RegisterCLRMethodRedirection(mi:  val_6, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache3);
            // 0x028F50A0: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F50A4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F50A8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F50AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F50B0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F50B4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F50B8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F50BC: CBNZ x20, #0x28f50c4       | if (val_1 != null) goto label_21;       
            if(val_1 != null)
            {
                goto label_21;
            }
            // 0x028F50C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_21:
            // 0x028F50C4: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x028F50C8: LDR x8, [x8, #0x7f0]       | X8 = (string**)(1152921510024538688)("Start");
            // 0x028F50CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F50D0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F50D4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F50D8: LDR x1, [x8]               | X1 = "Start";                           
            // 0x028F50DC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F50E0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F50E4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F50E8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Start", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_7 = val_1.GetMethod(name:  "Start", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F50EC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F50F0: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x028F50F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F50F8: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache4;
            // 0x028F50FC: CBNZ x22, #0x28f5140       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache4 != null) goto label_22;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache4) != null)
            {
                goto label_22;
            }
            // 0x028F5100: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x028F5104: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5108: LDR x8, [x8, #0xa00]       | X8 = 1152921510024542864;               
            // 0x028F510C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5110: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::Start_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5114: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5118: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F511C: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::Start_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5120: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::Start_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::Start_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5124: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::Start_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::Start_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5128: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F512C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5130: STR x0, [x8, #0x20]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463008
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache4 = null;
            // 0x028F5134: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5138: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F513C: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_22:
            // 0x028F5140: CBNZ x19, #0x28f5148       | if (X1 != 0) goto label_23;             
            if(X1 != 0)
            {
                goto label_23;
            }
            // 0x028F5144: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_23:
            // 0x028F5148: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F514C: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x028F5150: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5154: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_7, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache4);
            X1.RegisterCLRMethodRedirection(mi:  val_7, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache4);
            // 0x028F5158: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F515C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5160: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5164: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5168: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F516C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F5170: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5174: CBNZ x20, #0x28f517c       | if (val_1 != null) goto label_24;       
            if(val_1 != null)
            {
                goto label_24;
            }
            // 0x028F5178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_24:
            // 0x028F517C: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x028F5180: LDR x8, [x8, #0xaf0]       | X8 = (string**)(1152921510024543888)("RequestCheckUpdate");
            // 0x028F5184: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5188: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F518C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5190: LDR x1, [x8]               | X1 = "RequestCheckUpdate";              
            // 0x028F5194: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5198: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F519C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F51A0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "RequestCheckUpdate", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_8 = val_1.GetMethod(name:  "RequestCheckUpdate", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F51A4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F51A8: MOV x21, x0                | X21 = val_8;//m1                        
            // 0x028F51AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F51B0: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache5;
            // 0x028F51B4: CBNZ x22, #0x28f51f8       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache5 != null) goto label_25;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache5) != null)
            {
                goto label_25;
            }
            // 0x028F51B8: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x028F51BC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F51C0: LDR x8, [x8, #0x430]       | X8 = 1152921510024548096;               
            // 0x028F51C4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F51C8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RequestCheckUpdate_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F51CC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F51D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F51D4: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RequestCheckUpdate_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F51D8: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RequestCheckUpdate_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RequestCheckUpdate_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F51DC: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RequestCheckUpdate_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RequestCheckUpdate_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F51E0: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F51E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F51E8: STR x0, [x8, #0x28]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463016
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache5 = null;
            // 0x028F51EC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F51F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F51F4: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_25:
            // 0x028F51F8: CBNZ x19, #0x28f5200       | if (X1 != 0) goto label_26;             
            if(X1 != 0)
            {
                goto label_26;
            }
            // 0x028F51FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_26:
            // 0x028F5200: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5204: MOV x1, x21                | X1 = val_8;//m1                         
            // 0x028F5208: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F520C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_8, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache5);
            X1.RegisterCLRMethodRedirection(mi:  val_8, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache5);
            // 0x028F5210: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5214: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5218: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F521C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5220: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5224: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F5228: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F522C: CBNZ x20, #0x28f5234       | if (val_1 != null) goto label_27;       
            if(val_1 != null)
            {
                goto label_27;
            }
            // 0x028F5230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_27:
            // 0x028F5234: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x028F5238: LDR x8, [x8, #0x858]       | X8 = (string**)(1152921510024549120)("StartDown");
            // 0x028F523C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5240: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5244: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5248: LDR x1, [x8]               | X1 = "StartDown";                       
            // 0x028F524C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5250: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5254: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F5258: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "StartDown", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_9 = val_1.GetMethod(name:  "StartDown", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F525C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5260: MOV x21, x0                | X21 = val_9;//m1                        
            // 0x028F5264: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5268: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache6;
            // 0x028F526C: CBNZ x22, #0x28f52b0       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache6 != null) goto label_28;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache6) != null)
            {
                goto label_28;
            }
            // 0x028F5270: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x028F5274: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5278: LDR x8, [x8, #0xcc8]       | X8 = 1152921510024553312;               
            // 0x028F527C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5280: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartDown_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5284: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5288: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F528C: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartDown_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5290: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartDown_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartDown_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5294: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartDown_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartDown_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5298: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F529C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F52A0: STR x0, [x8, #0x30]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463024
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache6 = null;
            // 0x028F52A4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F52A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F52AC: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_28:
            // 0x028F52B0: CBNZ x19, #0x28f52b8       | if (X1 != 0) goto label_29;             
            if(X1 != 0)
            {
                goto label_29;
            }
            // 0x028F52B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_29:
            // 0x028F52B8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F52BC: MOV x1, x21                | X1 = val_9;//m1                         
            // 0x028F52C0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F52C4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_9, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache6);
            X1.RegisterCLRMethodRedirection(mi:  val_9, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache6);
            // 0x028F52C8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F52CC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F52D0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F52D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F52D8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F52DC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F52E0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F52E4: CBNZ x20, #0x28f52ec       | if (val_1 != null) goto label_30;       
            if(val_1 != null)
            {
                goto label_30;
            }
            // 0x028F52E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_30:
            // 0x028F52EC: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x028F52F0: LDR x8, [x8, #0x548]       | X8 = (string**)(1152921510024554336)("StartCsDown");
            // 0x028F52F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F52F8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F52FC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5300: LDR x1, [x8]               | X1 = "StartCsDown";                     
            // 0x028F5304: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5308: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F530C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F5310: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "StartCsDown", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_10 = val_1.GetMethod(name:  "StartCsDown", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5314: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5318: MOV x21, x0                | X21 = val_10;//m1                       
            // 0x028F531C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5320: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache7;
            // 0x028F5324: CBNZ x22, #0x28f5368       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache7 != null) goto label_31;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache7) != null)
            {
                goto label_31;
            }
            // 0x028F5328: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x028F532C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5330: LDR x8, [x8, #0x110]       | X8 = 1152921510024558528;               
            // 0x028F5334: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5338: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartCsDown_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F533C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5340: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5344: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartCsDown_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5348: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartCsDown_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartCsDown_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F534C: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartCsDown_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::StartCsDown_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5350: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5354: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5358: STR x0, [x8, #0x38]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463032
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache7 = null;
            // 0x028F535C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5360: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5364: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_31:
            // 0x028F5368: CBNZ x19, #0x28f5370       | if (X1 != 0) goto label_32;             
            if(X1 != 0)
            {
                goto label_32;
            }
            // 0x028F536C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_32:
            // 0x028F5370: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5374: MOV x1, x21                | X1 = val_10;//m1                        
            // 0x028F5378: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F537C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_10, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache7);
            X1.RegisterCLRMethodRedirection(mi:  val_10, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache7);
            // 0x028F5380: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5384: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5388: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F538C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x028F5390: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5394: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F5398: ADRP x9, #0x3616000        | X9 = 56713216 (0x3616000);              
            // 0x028F539C: LDR x8, [x24]              | X8 = typeof(System.Type);               
            // 0x028F53A0: LDR x9, [x9, #0x888]       | X9 = 1152921504996170800;               
            // 0x028F53A4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F53A8: LDR x22, [x9]              | X22 = typeof(System.Byte[]);            
            // 0x028F53AC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F53B0: TBZ w9, #0, #0x28f53c4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x028F53B4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F53B8: CBNZ w9, #0x28f53c4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x028F53BC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F53C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x028F53C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F53C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F53CC: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028F53D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F53D4: MOV x22, x0                | X22 = val_11;//m1                       
            // 0x028F53D8: CBNZ x21, #0x28f53e0       | if ( != null) goto label_35;            
            if(null != null)
            {
                goto label_35;
            }
            // 0x028F53DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_35:
            // 0x028F53E0: CBZ x22, #0x28f5404        | if (val_11 == null) goto label_37;      
            if(val_11 == null)
            {
                goto label_37;
            }
            // 0x028F53E4: LDR x8, [x21]              | X8 = ;                                  
            // 0x028F53E8: MOV x0, x22                | X0 = val_11;//m1                        
            // 0x028F53EC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F53F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
            // 0x028F53F4: CBNZ x0, #0x28f5404        | if (val_11 != null) goto label_37;      
            if(val_11 != null)
            {
                goto label_37;
            }
            // 0x028F53F8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
            // 0x028F53FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5400: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_37:
            // 0x028F5404: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028F5408: CBNZ w8, #0x28f5418        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_38;
            // 0x028F540C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
            // 0x028F5410: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5414: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_38:
            // 0x028F5418: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;
            // 0x028F541C: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x028F5420: LDR x8, [x8, #0xe38]       | X8 = 1152921504649285632;               
            // 0x028F5424: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F5428: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F542C: LDR x1, [x8]               | X1 = typeof(System.Text.Encoding);      
            // 0x028F5430: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F5434: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x028F5438: CBZ x22, #0x28f545c        | if (val_12 == null) goto label_40;      
            if(val_12 == null)
            {
                goto label_40;
            }
            // 0x028F543C: LDR x8, [x21]              | X8 = ;                                  
            // 0x028F5440: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x028F5444: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F5448: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x028F544C: CBNZ x0, #0x28f545c        | if (val_12 != null) goto label_40;      
            if(val_12 != null)
            {
                goto label_40;
            }
            // 0x028F5450: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
            // 0x028F5454: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5458: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_40:
            // 0x028F545C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028F5460: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x028F5464: B.HI #0x28f5474            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_41;
            // 0x028F5468: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
            // 0x028F546C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5470: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_41:
            // 0x028F5474: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_12;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_12;
            // 0x028F5478: CBNZ x20, #0x28f5480       | if (val_1 != null) goto label_42;       
            if(val_1 != null)
            {
                goto label_42;
            }
            // 0x028F547C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_42:
            // 0x028F5480: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x028F5484: LDR x8, [x8, #0x660]       | X8 = (string**)(1152921510024567744)("BytesToString");
            // 0x028F5488: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F548C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5490: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5494: LDR x1, [x8]               | X1 = "BytesToString";                   
            // 0x028F5498: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F549C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F54A0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F54A4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "BytesToString", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_13 = val_1.GetMethod(name:  "BytesToString", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F54A8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F54AC: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x028F54B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F54B4: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache8;
            // 0x028F54B8: CBNZ x22, #0x28f54fc       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache8 != null) goto label_43;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache8) != null)
            {
                goto label_43;
            }
            // 0x028F54BC: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x028F54C0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F54C4: LDR x8, [x8, #0x1d0]       | X8 = 1152921510024571936;               
            // 0x028F54C8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F54CC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::BytesToString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F54D0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F54D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F54D8: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::BytesToString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F54DC: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::BytesToString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::BytesToString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F54E0: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::BytesToString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::BytesToString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F54E4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F54E8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F54EC: STR x0, [x8, #0x40]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463040
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache8 = null;
            // 0x028F54F0: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F54F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F54F8: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_43:
            // 0x028F54FC: CBNZ x19, #0x28f5504       | if (X1 != 0) goto label_44;             
            if(X1 != 0)
            {
                goto label_44;
            }
            // 0x028F5500: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_44:
            // 0x028F5504: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5508: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x028F550C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5510: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache8);
            X1.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache8);
            // 0x028F5514: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5518: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F551C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5524: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5528: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F552C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5530: CBNZ x20, #0x28f5538       | if (val_1 != null) goto label_45;       
            if(val_1 != null)
            {
                goto label_45;
            }
            // 0x028F5534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_45:
            // 0x028F5538: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x028F553C: LDR x8, [x8, #0x930]       | X8 = (string**)(1152921510024572960)("get_IsDownSuccess");
            // 0x028F5540: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5544: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5548: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F554C: LDR x1, [x8]               | X1 = "get_IsDownSuccess";               
            // 0x028F5550: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5554: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5558: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F555C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_IsDownSuccess", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_14 = val_1.GetMethod(name:  "get_IsDownSuccess", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5560: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5564: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x028F5568: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F556C: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache9;
            // 0x028F5570: CBNZ x22, #0x28f55b4       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache9 != null) goto label_46;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache9) != null)
            {
                goto label_46;
            }
            // 0x028F5574: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x028F5578: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F557C: LDR x8, [x8, #0x8f0]       | X8 = 1152921510024577168;               
            // 0x028F5580: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5584: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IsDownSuccess_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5588: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F558C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5590: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IsDownSuccess_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5594: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IsDownSuccess_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IsDownSuccess_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5598: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IsDownSuccess_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IsDownSuccess_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F559C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F55A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F55A4: STR x0, [x8, #0x48]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463048
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache9 = null;
            // 0x028F55A8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F55AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F55B0: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_46:
            // 0x028F55B4: CBNZ x19, #0x28f55bc       | if (X1 != 0) goto label_47;             
            if(X1 != 0)
            {
                goto label_47;
            }
            // 0x028F55B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_47:
            // 0x028F55BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F55C0: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x028F55C4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F55C8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_14, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache9);
            X1.RegisterCLRMethodRedirection(mi:  val_14, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache9);
            // 0x028F55CC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F55D0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F55D4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F55D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F55DC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F55E0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F55E4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F55E8: CBNZ x20, #0x28f55f0       | if (val_1 != null) goto label_48;       
            if(val_1 != null)
            {
                goto label_48;
            }
            // 0x028F55EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_48:
            // 0x028F55F0: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x028F55F4: LDR x8, [x8, #0x258]       | X8 = (string**)(1152921510024578192)("get_WriteProgress");
            // 0x028F55F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F55FC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5600: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5604: LDR x1, [x8]               | X1 = "get_WriteProgress";               
            // 0x028F5608: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F560C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5610: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F5614: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_WriteProgress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_15 = val_1.GetMethod(name:  "get_WriteProgress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5618: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F561C: MOV x21, x0                | X21 = val_15;//m1                       
            // 0x028F5620: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5624: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheA;
            // 0x028F5628: CBNZ x22, #0x28f566c       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheA != null) goto label_49;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheA) != null)
            {
                goto label_49;
            }
            // 0x028F562C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x028F5630: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5634: LDR x8, [x8, #0x758]       | X8 = 1152921510024582400;               
            // 0x028F5638: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F563C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_WriteProgress_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5640: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5644: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5648: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_WriteProgress_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F564C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_WriteProgress_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_WriteProgress_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5650: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_WriteProgress_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_WriteProgress_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5654: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5658: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F565C: STR x0, [x8, #0x50]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463056
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheA = null;
            // 0x028F5660: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5664: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5668: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_49:
            // 0x028F566C: CBNZ x19, #0x28f5674       | if (X1 != 0) goto label_50;             
            if(X1 != 0)
            {
                goto label_50;
            }
            // 0x028F5670: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_50:
            // 0x028F5674: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5678: MOV x1, x21                | X1 = val_15;//m1                        
            // 0x028F567C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5680: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_15, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheA);
            X1.RegisterCLRMethodRedirection(mi:  val_15, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheA);
            // 0x028F5684: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5688: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F568C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5690: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5694: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5698: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F569C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F56A0: CBNZ x20, #0x28f56a8       | if (val_1 != null) goto label_51;       
            if(val_1 != null)
            {
                goto label_51;
            }
            // 0x028F56A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_51:
            // 0x028F56A8: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x028F56AC: LDR x8, [x8, #0x4f8]       | X8 = (string**)(1152921510024583424)("get_isPkged");
            // 0x028F56B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F56B4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F56B8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F56BC: LDR x1, [x8]               | X1 = "get_isPkged";                     
            // 0x028F56C0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F56C4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F56C8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F56CC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_isPkged", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_16 = val_1.GetMethod(name:  "get_isPkged", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F56D0: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F56D4: MOV x21, x0                | X21 = val_16;//m1                       
            // 0x028F56D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F56DC: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheB;
            // 0x028F56E0: CBNZ x22, #0x28f5724       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheB != null) goto label_52;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheB) != null)
            {
                goto label_52;
            }
            // 0x028F56E4: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x028F56E8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F56EC: LDR x8, [x8, #0x600]       | X8 = 1152921510024587616;               
            // 0x028F56F0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F56F4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isPkged_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F56F8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F56FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5700: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isPkged_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5704: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isPkged_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isPkged_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5708: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isPkged_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isPkged_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F570C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5710: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5714: STR x0, [x8, #0x58]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463064
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheB = null;
            // 0x028F5718: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F571C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5720: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_52:
            // 0x028F5724: CBNZ x19, #0x28f572c       | if (X1 != 0) goto label_53;             
            if(X1 != 0)
            {
                goto label_53;
            }
            // 0x028F5728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_53:
            // 0x028F572C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5730: MOV x1, x21                | X1 = val_16;//m1                        
            // 0x028F5734: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5738: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_16, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheB);
            X1.RegisterCLRMethodRedirection(mi:  val_16, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheB);
            // 0x028F573C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5740: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5744: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F574C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5750: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F5754: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5758: CBNZ x20, #0x28f5760       | if (val_1 != null) goto label_54;       
            if(val_1 != null)
            {
                goto label_54;
            }
            // 0x028F575C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_54:
            // 0x028F5760: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x028F5764: LDR x8, [x8, #0x320]       | X8 = (string**)(1152921510024588640)("get_PkgProgress");
            // 0x028F5768: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F576C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5770: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5774: LDR x1, [x8]               | X1 = "get_PkgProgress";                 
            // 0x028F5778: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F577C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5780: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F5784: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_PkgProgress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_17 = val_1.GetMethod(name:  "get_PkgProgress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5788: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F578C: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x028F5790: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5794: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheC;
            // 0x028F5798: CBNZ x22, #0x28f57dc       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheC != null) goto label_55;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheC) != null)
            {
                goto label_55;
            }
            // 0x028F579C: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x028F57A0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F57A4: LDR x8, [x8, #0xc60]       | X8 = 1152921510024592848;               
            // 0x028F57A8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F57AC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_PkgProgress_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F57B0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F57B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F57B8: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_PkgProgress_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F57BC: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_PkgProgress_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_PkgProgress_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F57C0: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_PkgProgress_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_PkgProgress_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F57C4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F57C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F57CC: STR x0, [x8, #0x60]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463072
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheC = null;
            // 0x028F57D0: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F57D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F57D8: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_55:
            // 0x028F57DC: CBNZ x19, #0x28f57e4       | if (X1 != 0) goto label_56;             
            if(X1 != 0)
            {
                goto label_56;
            }
            // 0x028F57E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_56:
            // 0x028F57E4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F57E8: MOV x1, x21                | X1 = val_17;//m1                        
            // 0x028F57EC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F57F0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_17, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheC);
            X1.RegisterCLRMethodRedirection(mi:  val_17, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheC);
            // 0x028F57F4: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F57F8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F57FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5800: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5804: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5808: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F580C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5810: CBNZ x20, #0x28f5818       | if (val_1 != null) goto label_57;       
            if(val_1 != null)
            {
                goto label_57;
            }
            // 0x028F5814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_57:
            // 0x028F5818: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x028F581C: LDR x8, [x8, #0x458]       | X8 = (string**)(1152921510024593872)("get_isVerifyed");
            // 0x028F5820: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5824: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5828: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F582C: LDR x1, [x8]               | X1 = "get_isVerifyed";                  
            // 0x028F5830: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5834: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5838: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F583C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_isVerifyed", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_18 = val_1.GetMethod(name:  "get_isVerifyed", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5840: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5844: MOV x21, x0                | X21 = val_18;//m1                       
            // 0x028F5848: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F584C: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheD;
            // 0x028F5850: CBNZ x22, #0x28f5894       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheD != null) goto label_58;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheD) != null)
            {
                goto label_58;
            }
            // 0x028F5854: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x028F5858: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F585C: LDR x8, [x8, #0x1a8]       | X8 = 1152921510024598064;               
            // 0x028F5860: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5864: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isVerifyed_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5868: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F586C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5870: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isVerifyed_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5874: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isVerifyed_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isVerifyed_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5878: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isVerifyed_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isVerifyed_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F587C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5880: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5884: STR x0, [x8, #0x68]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463080
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheD = null;
            // 0x028F5888: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F588C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5890: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_58:
            // 0x028F5894: CBNZ x19, #0x28f589c       | if (X1 != 0) goto label_59;             
            if(X1 != 0)
            {
                goto label_59;
            }
            // 0x028F5898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_59:
            // 0x028F589C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F58A0: MOV x1, x21                | X1 = val_18;//m1                        
            // 0x028F58A4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F58A8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_18, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheD);
            X1.RegisterCLRMethodRedirection(mi:  val_18, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheD);
            // 0x028F58AC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F58B0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F58B4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F58B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F58BC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F58C0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F58C4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F58C8: CBNZ x20, #0x28f58d0       | if (val_1 != null) goto label_60;       
            if(val_1 != null)
            {
                goto label_60;
            }
            // 0x028F58CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_60:
            // 0x028F58D0: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x028F58D4: LDR x8, [x8, #0xd38]       | X8 = (string**)(1152921510024599088)("get_VerifyProgress");
            // 0x028F58D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F58DC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F58E0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F58E4: LDR x1, [x8]               | X1 = "get_VerifyProgress";              
            // 0x028F58E8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F58EC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F58F0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F58F4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_VerifyProgress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_19 = val_1.GetMethod(name:  "get_VerifyProgress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F58F8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F58FC: MOV x21, x0                | X21 = val_19;//m1                       
            // 0x028F5900: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5904: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheE;
            // 0x028F5908: CBNZ x22, #0x28f594c       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheE != null) goto label_61;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheE) != null)
            {
                goto label_61;
            }
            // 0x028F590C: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x028F5910: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5914: LDR x8, [x8, #0x960]       | X8 = 1152921510024603296;               
            // 0x028F5918: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F591C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_VerifyProgress_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5920: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5924: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5928: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_VerifyProgress_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F592C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_VerifyProgress_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_VerifyProgress_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5930: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_VerifyProgress_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_VerifyProgress_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5934: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5938: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F593C: STR x0, [x8, #0x70]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463088
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheE = null;
            // 0x028F5940: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5944: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5948: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_61:
            // 0x028F594C: CBNZ x19, #0x28f5954       | if (X1 != 0) goto label_62;             
            if(X1 != 0)
            {
                goto label_62;
            }
            // 0x028F5950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_62:
            // 0x028F5954: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5958: MOV x1, x21                | X1 = val_19;//m1                        
            // 0x028F595C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5960: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_19, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheE);
            X1.RegisterCLRMethodRedirection(mi:  val_19, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheE);
            // 0x028F5964: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5968: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F596C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5970: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5974: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5978: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F597C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5980: CBNZ x20, #0x28f5988       | if (val_1 != null) goto label_63;       
            if(val_1 != null)
            {
                goto label_63;
            }
            // 0x028F5984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_63:
            // 0x028F5988: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x028F598C: LDR x8, [x8, #0x818]       | X8 = (string**)(1152921510024604320)("get_isStartDown");
            // 0x028F5990: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5994: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5998: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F599C: LDR x1, [x8]               | X1 = "get_isStartDown";                 
            // 0x028F59A0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F59A4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F59A8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F59AC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_isStartDown", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_20 = val_1.GetMethod(name:  "get_isStartDown", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F59B0: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F59B4: MOV x21, x0                | X21 = val_20;//m1                       
            // 0x028F59B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F59BC: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheF;
            // 0x028F59C0: CBNZ x22, #0x28f5a04       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheF != null) goto label_64;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheF) != null)
            {
                goto label_64;
            }
            // 0x028F59C4: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x028F59C8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F59CC: LDR x8, [x8, #0x908]       | X8 = 1152921510024608528;               
            // 0x028F59D0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F59D4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isStartDown_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F59D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F59DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F59E0: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isStartDown_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F59E4: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isStartDown_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isStartDown_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F59E8: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isStartDown_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isStartDown_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F59EC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F59F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F59F4: STR x0, [x8, #0x78]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463096
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheF = null;
            // 0x028F59F8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F59FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5A00: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_64:
            // 0x028F5A04: CBNZ x19, #0x28f5a0c       | if (X1 != 0) goto label_65;             
            if(X1 != 0)
            {
                goto label_65;
            }
            // 0x028F5A08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_65:
            // 0x028F5A0C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5A10: MOV x1, x21                | X1 = val_20;//m1                        
            // 0x028F5A14: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5A18: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_20, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheF);
            X1.RegisterCLRMethodRedirection(mi:  val_20, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cacheF);
            // 0x028F5A1C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5A20: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5A24: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5A28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5A2C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5A30: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F5A34: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5A38: CBNZ x20, #0x28f5a40       | if (val_1 != null) goto label_66;       
            if(val_1 != null)
            {
                goto label_66;
            }
            // 0x028F5A3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_66:
            // 0x028F5A40: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x028F5A44: LDR x8, [x8, #0xfa0]       | X8 = (string**)(1152921510024609552)("get_Progress");
            // 0x028F5A48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5A4C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5A50: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5A54: LDR x1, [x8]               | X1 = "get_Progress";                    
            // 0x028F5A58: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5A5C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5A60: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F5A64: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_Progress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_21 = val_1.GetMethod(name:  "get_Progress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5A68: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5A6C: MOV x21, x0                | X21 = val_21;//m1                       
            // 0x028F5A70: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5A74: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache10;
            // 0x028F5A78: CBNZ x22, #0x28f5abc       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache10 != null) goto label_67;
            if((ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache10) != null)
            {
                goto label_67;
            }
            // 0x028F5A7C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F5A80: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5A84: LDR x8, [x8, #0xe80]       | X8 = 1152921510024613744;               
            // 0x028F5A88: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5A8C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Progress_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5A90: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5A94: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5A98: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Progress_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5A9C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Progress_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Progress_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5AA0: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Progress_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_Progress_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5AA4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5AA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5AAC: STR x0, [x8, #0x80]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463104
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache10 = null;
            // 0x028F5AB0: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5AB4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5AB8: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_67:
            // 0x028F5ABC: CBNZ x19, #0x28f5ac4       | if (X1 != 0) goto label_68;             
            if(X1 != 0)
            {
                goto label_68;
            }
            // 0x028F5AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_68:
            // 0x028F5AC4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5AC8: MOV x1, x21                | X1 = val_21;//m1                        
            // 0x028F5ACC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5AD0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_21, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache10);
            X1.RegisterCLRMethodRedirection(mi:  val_21, func:  ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache10);
            // 0x028F5AD4: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5AD8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5ADC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5AE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5AE4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5AE8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F5AEC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5AF0: CBNZ x20, #0x28f5af8       | if (val_1 != null) goto label_69;       
            if(val_1 != null)
            {
                goto label_69;
            }
            // 0x028F5AF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_69:
            // 0x028F5AF8: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x028F5AFC: LDR x8, [x8, #0x978]       | X8 = (string**)(1152921510024614768)("get_ProgressMsg");
            // 0x028F5B00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5B04: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5B08: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5B0C: LDR x1, [x8]               | X1 = "get_ProgressMsg";                 
            // 0x028F5B10: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5B14: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5B18: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F5B1C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_ProgressMsg", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_22 = val_1.GetMethod(name:  "get_ProgressMsg", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5B20: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5B24: MOV x21, x0                | X21 = val_22;//m1                       
            // 0x028F5B28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5B2C: LDR x22, [x8, #0x88]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache11;
            val_27 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache11;
            // 0x028F5B30: CBNZ x22, #0x28f5b74       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache11 != null) goto label_70;
            if(val_27 != null)
            {
                goto label_70;
            }
            // 0x028F5B34: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x028F5B38: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5B3C: LDR x8, [x8, #0x3a0]       | X8 = 1152921510024618976;               
            // 0x028F5B40: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5B44: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_ProgressMsg_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5B48: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5B4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5B50: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_ProgressMsg_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5B54: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_ProgressMsg_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_ProgressMsg_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5B58: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_ProgressMsg_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_ProgressMsg_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5B5C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5B60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5B64: STR x0, [x8, #0x88]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463112
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache11 = null;
            // 0x028F5B68: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5B6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5B70: LDR x22, [x8, #0x88]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_27 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache11;
            label_70:
            // 0x028F5B74: CBNZ x19, #0x28f5b7c       | if (X1 != 0) goto label_71;             
            if(X1 != 0)
            {
                goto label_71;
            }
            // 0x028F5B78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_71:
            // 0x028F5B7C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5B80: MOV x1, x21                | X1 = val_22;//m1                        
            // 0x028F5B84: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5B88: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_27);
            X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_27);
            // 0x028F5B8C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5B90: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5B94: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5B98: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x028F5B9C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5BA0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F5BA4: ADRP x26, #0x3615000       | X26 = 56709120 (0x3615000);             
            // 0x028F5BA8: LDR x8, [x24]              | X8 = typeof(System.Type);               
            // 0x028F5BAC: LDR x26, [x26, #0x668]     | X26 = 1152921504898326528;              
            // 0x028F5BB0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5BB4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F5BB8: LDR x22, [x26]             | X22 = typeof(CEvent.ZEvent);            
            // 0x028F5BBC: TBZ w9, #0, #0x28f5bd0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_73;
            // 0x028F5BC0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F5BC4: CBNZ w9, #0x28f5bd0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_73;
            // 0x028F5BC8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F5BCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_73:
            // 0x028F5BD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F5BD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F5BD8: MOV x1, x22                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x028F5BDC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_23 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F5BE0: MOV x22, x0                | X22 = val_23;//m1                       
            // 0x028F5BE4: CBNZ x21, #0x28f5bec       | if ( != null) goto label_74;            
            if(null != null)
            {
                goto label_74;
            }
            // 0x028F5BE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_74:
            // 0x028F5BEC: CBZ x22, #0x28f5c10        | if (val_23 == null) goto label_76;      
            if(val_23 == null)
            {
                goto label_76;
            }
            // 0x028F5BF0: LDR x8, [x21]              | X8 = ;                                  
            // 0x028F5BF4: MOV x0, x22                | X0 = val_23;//m1                        
            // 0x028F5BF8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F5BFC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_23, ????);     
            // 0x028F5C00: CBNZ x0, #0x28f5c10        | if (val_23 != null) goto label_76;      
            if(val_23 != null)
            {
                goto label_76;
            }
            // 0x028F5C04: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_23, ????);     
            // 0x028F5C08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5C0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_76:
            // 0x028F5C10: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028F5C14: CBNZ w8, #0x28f5c24        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_77;
            // 0x028F5C18: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x028F5C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5C20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_77:
            // 0x028F5C24: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_23;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_23;
            // 0x028F5C28: CBNZ x20, #0x28f5c30       | if (val_1 != null) goto label_78;       
            if(val_1 != null)
            {
                goto label_78;
            }
            // 0x028F5C2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_78:
            // 0x028F5C30: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x028F5C34: LDR x8, [x8, #0xcb8]       | X8 = (string**)(1152921510024624096)("IsOpenRepairAsset");
            // 0x028F5C38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5C3C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5C40: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5C44: LDR x1, [x8]               | X1 = "IsOpenRepairAsset";               
            // 0x028F5C48: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5C4C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5C50: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F5C54: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "IsOpenRepairAsset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_24 = val_1.GetMethod(name:  "IsOpenRepairAsset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5C58: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5C5C: MOV x21, x0                | X21 = val_24;//m1                       
            // 0x028F5C60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5C64: LDR x22, [x8, #0x90]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache12;
            val_28 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache12;
            // 0x028F5C68: CBNZ x22, #0x28f5cac       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache12 != null) goto label_79;
            if(val_28 != null)
            {
                goto label_79;
            }
            // 0x028F5C6C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x028F5C70: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5C74: LDR x8, [x8, #0xf20]       | X8 = 1152921510024628304;               
            // 0x028F5C78: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5C7C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::IsOpenRepairAsset_18(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5C80: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5C84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5C88: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::IsOpenRepairAsset_18(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5C8C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::IsOpenRepairAsset_18(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::IsOpenRepairAsset_18(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5C90: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::IsOpenRepairAsset_18(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::IsOpenRepairAsset_18(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5C94: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5C98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5C9C: STR x0, [x8, #0x90]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache12 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463120
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache12 = null;
            // 0x028F5CA0: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5CA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5CA8: LDR x22, [x8, #0x90]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_28 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache12;
            label_79:
            // 0x028F5CAC: CBNZ x19, #0x28f5cb4       | if (X1 != 0) goto label_80;             
            if(X1 != 0)
            {
                goto label_80;
            }
            // 0x028F5CB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_80:
            // 0x028F5CB4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5CB8: MOV x1, x21                | X1 = val_24;//m1                        
            // 0x028F5CBC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5CC0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_28);
            X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_28);
            // 0x028F5CC4: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x028F5CC8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5CCC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F5CD0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x028F5CD4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5CD8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F5CDC: LDR x8, [x24]              | X8 = typeof(System.Type);               
            // 0x028F5CE0: LDR x22, [x26]             | X22 = typeof(CEvent.ZEvent);            
            // 0x028F5CE4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5CE8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F5CEC: TBZ w9, #0, #0x28f5d00     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_82;
            // 0x028F5CF0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F5CF4: CBNZ w9, #0x28f5d00        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_82;
            // 0x028F5CF8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F5CFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_82:
            // 0x028F5D00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F5D04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F5D08: MOV x1, x22                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x028F5D0C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_25 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F5D10: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x028F5D14: CBNZ x21, #0x28f5d1c       | if ( != null) goto label_83;            
            if(null != null)
            {
                goto label_83;
            }
            // 0x028F5D18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_83:
            // 0x028F5D1C: CBZ x22, #0x28f5d40        | if (val_25 == null) goto label_85;      
            if(val_25 == null)
            {
                goto label_85;
            }
            // 0x028F5D20: LDR x8, [x21]              | X8 = ;                                  
            // 0x028F5D24: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x028F5D28: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F5D2C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x028F5D30: CBNZ x0, #0x28f5d40        | if (val_25 != null) goto label_85;      
            if(val_25 != null)
            {
                goto label_85;
            }
            // 0x028F5D34: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_25, ????);     
            // 0x028F5D38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5D3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_85:
            // 0x028F5D40: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028F5D44: CBNZ w8, #0x28f5d54        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_86;
            // 0x028F5D48: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_25, ????);     
            // 0x028F5D4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F5D50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_86:
            // 0x028F5D54: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_25;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_25;
            // 0x028F5D58: CBNZ x20, #0x28f5d60       | if (val_1 != null) goto label_87;       
            if(val_1 != null)
            {
                goto label_87;
            }
            // 0x028F5D5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_87:
            // 0x028F5D60: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x028F5D64: LDR x8, [x8, #0xf90]       | X8 = (string**)(1152921510024633424)("RepairAsset");
            // 0x028F5D68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F5D6C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F5D70: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5D74: LDR x1, [x8]               | X1 = "RepairAsset";                     
            // 0x028F5D78: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5D7C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F5D80: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F5D84: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "RepairAsset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_26 = val_1.GetMethod(name:  "RepairAsset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F5D88: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5D8C: MOV x21, x0                | X21 = val_26;//m1                       
            // 0x028F5D90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5D94: LDR x22, [x8, #0x98]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache13;
            val_29 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache13;
            // 0x028F5D98: CBNZ x22, #0x28f5ddc       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache13 != null) goto label_88;
            if(val_29 != null)
            {
                goto label_88;
            }
            // 0x028F5D9C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x028F5DA0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F5DA4: LDR x8, [x8, #0xde8]       | X8 = 1152921510024637616;               
            // 0x028F5DA8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F5DAC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RepairAsset_19(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5DB0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F5DB4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F5DB8: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RepairAsset_19(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5DBC: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RepairAsset_19(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RepairAsset_19(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5DC0: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RepairAsset_19(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::RepairAsset_19(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F5DC4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5DC8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5DCC: STR x0, [x8, #0x98]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache13 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782463128
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache13 = null;
            // 0x028F5DD0: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5DD4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5DD8: LDR x22, [x8, #0x98]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_29 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache13;
            label_88:
            // 0x028F5DDC: CBNZ x19, #0x28f5de4       | if (X1 != 0) goto label_89;             
            if(X1 != 0)
            {
                goto label_89;
            }
            // 0x028F5DE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_89:
            // 0x028F5DE4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5DE8: MOV x1, x21                | X1 = val_26;//m1                        
            // 0x028F5DEC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F5DF0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_29);
            X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_29);
            // 0x028F5DF4: CBNZ x20, #0x28f5dfc       | if (val_1 != null) goto label_90;       
            if(val_1 != null)
            {
                goto label_90;
            }
            // 0x028F5DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_90:
            // 0x028F5DFC: ADRP x9, #0x35be000        | X9 = 56352768 (0x35BE000);              
            // 0x028F5E00: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028F5E04: LDR x9, [x9, #0xb00]       | X9 = (string**)(1152921510024638640)("FLOW_CHECK_UPDATE");
            // 0x028F5E08: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5E0C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5E10: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028F5E14: LDR x1, [x9]               | X1 = "FLOW_CHECK_UPDATE";               
            // 0x028F5E18: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028F5E1C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028F5E20: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5E24: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028F5E28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5E2C: LDR x22, [x8, #0xa0]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache14;
            val_30 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache14;
            // 0x028F5E30: CBNZ x22, #0x28f5e74       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache14 != null) goto label_91;
            if(val_30 != null)
            {
                goto label_91;
            }
            // 0x028F5E34: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x028F5E38: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028F5E3C: LDR x8, [x8, #0x278]       | X8 = 1152921510024638752;               
            // 0x028F5E40: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028F5E44: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_FLOW_CHECK_UPDATE_0(ref object o);
            // 0x028F5E48: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028F5E4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028F5E50: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_FLOW_CHECK_UPDATE_0(ref object o);
            // 0x028F5E54: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_FLOW_CHECK_UPDATE_0(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_FLOW_CHECK_UPDATE_0(ref object o);
            // 0x028F5E58: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_FLOW_CHECK_UPDATE_0(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_FLOW_CHECK_UPDATE_0(ref object o);
            // 0x028F5E5C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5E60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5E64: STR x0, [x8, #0xa0]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache14 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782463136
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache14 = null;
            // 0x028F5E68: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5E6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5E70: LDR x22, [x8, #0xa0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_30 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache14;
            label_91:
            // 0x028F5E74: CBNZ x19, #0x28f5e7c       | if (X1 != 0) goto label_92;             
            if(X1 != 0)
            {
                goto label_92;
            }
            // 0x028F5E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_92:
            // 0x028F5E7C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5E80: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F5E84: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028F5E88: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_30);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_30);
            // 0x028F5E8C: CBNZ x20, #0x28f5e94       | if (val_1 != null) goto label_93;       
            if(val_1 != null)
            {
                goto label_93;
            }
            // 0x028F5E90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_93:
            // 0x028F5E94: ADRP x9, #0x3609000        | X9 = 56659968 (0x3609000);              
            // 0x028F5E98: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028F5E9C: LDR x9, [x9, #0x9b0]       | X9 = (string**)(1152921510024639776)("REPAIR_ASSET");
            // 0x028F5EA0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5EA4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5EA8: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028F5EAC: LDR x1, [x9]               | X1 = "REPAIR_ASSET";                    
            // 0x028F5EB0: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028F5EB4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028F5EB8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5EBC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028F5EC0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5EC4: LDR x22, [x8, #0xa8]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache15;
            val_31 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache15;
            // 0x028F5EC8: CBNZ x22, #0x28f5f0c       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache15 != null) goto label_94;
            if(val_31 != null)
            {
                goto label_94;
            }
            // 0x028F5ECC: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x028F5ED0: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028F5ED4: LDR x8, [x8, #0x7e8]       | X8 = 1152921510024639872;               
            // 0x028F5ED8: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028F5EDC: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_REPAIR_ASSET_1(ref object o);
            // 0x028F5EE0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028F5EE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028F5EE8: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_REPAIR_ASSET_1(ref object o);
            // 0x028F5EEC: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_REPAIR_ASSET_1(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_REPAIR_ASSET_1(ref object o);
            // 0x028F5EF0: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_REPAIR_ASSET_1(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_REPAIR_ASSET_1(ref object o);
            // 0x028F5EF4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5EF8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5EFC: STR x0, [x8, #0xa8]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache15 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782463144
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache15 = null;
            // 0x028F5F00: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5F04: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5F08: LDR x22, [x8, #0xa8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_31 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache15;
            label_94:
            // 0x028F5F0C: CBNZ x19, #0x28f5f14       | if (X1 != 0) goto label_95;             
            if(X1 != 0)
            {
                goto label_95;
            }
            // 0x028F5F10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_95:
            // 0x028F5F14: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5F18: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F5F1C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028F5F20: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_31);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_31);
            // 0x028F5F24: CBNZ x20, #0x28f5f2c       | if (val_1 != null) goto label_96;       
            if(val_1 != null)
            {
                goto label_96;
            }
            // 0x028F5F28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_96:
            // 0x028F5F2C: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x028F5F30: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028F5F34: LDR x9, [x9, #0x28]        | X9 = (string**)(1152921510024640896)("IF_OPEN_REPAIR_ASSET");
            // 0x028F5F38: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5F3C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5F40: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028F5F44: LDR x1, [x9]               | X1 = "IF_OPEN_REPAIR_ASSET";            
            // 0x028F5F48: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028F5F4C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028F5F50: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5F54: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028F5F58: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5F5C: LDR x22, [x8, #0xb0]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache16;
            val_32 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache16;
            // 0x028F5F60: CBNZ x22, #0x28f5fa4       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache16 != null) goto label_97;
            if(val_32 != null)
            {
                goto label_97;
            }
            // 0x028F5F64: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x028F5F68: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028F5F6C: LDR x8, [x8, #0xad8]       | X8 = 1152921510024641008;               
            // 0x028F5F70: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028F5F74: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_2(ref object o);
            // 0x028F5F78: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028F5F7C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028F5F80: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_2(ref object o);
            // 0x028F5F84: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_2(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_2(ref object o);
            // 0x028F5F88: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_2(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_2(ref object o);
            // 0x028F5F8C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5F90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5F94: STR x0, [x8, #0xb0]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache16 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782463152
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache16 = null;
            // 0x028F5F98: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5F9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5FA0: LDR x22, [x8, #0xb0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_32 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache16;
            label_97:
            // 0x028F5FA4: CBNZ x19, #0x28f5fac       | if (X1 != 0) goto label_98;             
            if(X1 != 0)
            {
                goto label_98;
            }
            // 0x028F5FA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_98:
            // 0x028F5FAC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F5FB0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F5FB4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028F5FB8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_32);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_32);
            // 0x028F5FBC: CBNZ x20, #0x28f5fc4       | if (val_1 != null) goto label_99;       
            if(val_1 != null)
            {
                goto label_99;
            }
            // 0x028F5FC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_99:
            // 0x028F5FC4: ADRP x9, #0x361e000        | X9 = 56745984 (0x361E000);              
            // 0x028F5FC8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028F5FCC: LDR x9, [x9, #0x4d0]       | X9 = (string**)(1152921510024642032)("IF_OPEN_REPAIR_ASSET_BACK");
            // 0x028F5FD0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F5FD4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F5FD8: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028F5FDC: LDR x1, [x9]               | X1 = "IF_OPEN_REPAIR_ASSET_BACK";       
            // 0x028F5FE0: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028F5FE4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028F5FE8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F5FEC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028F5FF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F5FF4: LDR x22, [x8, #0xb8]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache17;
            val_33 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache17;
            // 0x028F5FF8: CBNZ x22, #0x28f603c       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache17 != null) goto label_100;
            if(val_33 != null)
            {
                goto label_100;
            }
            // 0x028F5FFC: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x028F6000: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028F6004: LDR x8, [x8, #0x2c8]       | X8 = 1152921510024642160;               
            // 0x028F6008: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028F600C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_BACK_3(ref object o);
            // 0x028F6010: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028F6014: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028F6018: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_BACK_3(ref object o);
            // 0x028F601C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_BACK_3(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_BACK_3(ref object o);
            // 0x028F6020: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_BACK_3(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_IF_OPEN_REPAIR_ASSET_BACK_3(ref object o);
            // 0x028F6024: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6028: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F602C: STR x0, [x8, #0xb8]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache17 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782463160
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache17 = null;
            // 0x028F6030: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6034: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F6038: LDR x22, [x8, #0xb8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_33 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache17;
            label_100:
            // 0x028F603C: CBNZ x19, #0x28f6044       | if (X1 != 0) goto label_101;            
            if(X1 != 0)
            {
                goto label_101;
            }
            // 0x028F6040: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_101:
            // 0x028F6044: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6048: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F604C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028F6050: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_33);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_33);
            // 0x028F6054: CBNZ x20, #0x28f605c       | if (val_1 != null) goto label_102;      
            if(val_1 != null)
            {
                goto label_102;
            }
            // 0x028F6058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_102:
            // 0x028F605C: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x028F6060: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028F6064: LDR x9, [x9, #0xcd8]       | X9 = (string**)(1152921510024643184)("clientVer");
            // 0x028F6068: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F606C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F6070: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028F6074: LDR x1, [x9]               | X1 = "clientVer";                       
            // 0x028F6078: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028F607C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028F6080: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6084: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028F6088: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F608C: LDR x22, [x8, #0xc0]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache18;
            val_34 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache18;
            // 0x028F6090: CBNZ x22, #0x28f60d4       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache18 != null) goto label_103;
            if(val_34 != null)
            {
                goto label_103;
            }
            // 0x028F6094: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x028F6098: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028F609C: LDR x8, [x8, #0x5a0]       | X8 = 1152921510024643280;               
            // 0x028F60A0: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028F60A4: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_clientVer_4(ref object o);
            // 0x028F60A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028F60AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028F60B0: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_clientVer_4(ref object o);
            // 0x028F60B4: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_clientVer_4(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_clientVer_4(ref object o);
            // 0x028F60B8: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_clientVer_4(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_clientVer_4(ref object o);
            // 0x028F60BC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F60C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F60C4: STR x0, [x8, #0xc0]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache18 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782463168
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache18 = null;
            // 0x028F60C8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F60CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F60D0: LDR x22, [x8, #0xc0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_34 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache18;
            label_103:
            // 0x028F60D4: CBNZ x19, #0x28f60dc       | if (X1 != 0) goto label_104;            
            if(X1 != 0)
            {
                goto label_104;
            }
            // 0x028F60D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_104:
            // 0x028F60DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F60E0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F60E4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028F60E8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_34);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_34);
            // 0x028F60EC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F60F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F60F4: LDR x22, [x8, #0xc8]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache19;
            val_35 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache19;
            // 0x028F60F8: CBNZ x22, #0x28f613c       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache19 != null) goto label_105;
            if(val_35 != null)
            {
                goto label_105;
            }
            // 0x028F60FC: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x028F6100: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x028F6104: LDR x8, [x8, #0x658]       | X8 = 1152921510024644304;               
            // 0x028F6108: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x028F610C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_clientVer_4(ref object o, object v);
            // 0x028F6110: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            // 0x028F6114: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x028F6118: LDR x8, [x22]              | X8 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_clientVer_4(ref object o, object v);
            // 0x028F611C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_clientVer_4(ref object o, object v);  //  dest_result_addr=1152921504824045600 |  dest_result_addr=1152921504824045608
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_clientVer_4(ref object o, object v);
            // 0x028F6120: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_clientVer_4(ref object o, object v);  //  dest_result_addr=1152921504824045584
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_clientVer_4(ref object o, object v);
            // 0x028F6124: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6128: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F612C: STR x0, [x8, #0xc8]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache19 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782463176
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache19 = null;
            // 0x028F6130: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6134: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F6138: LDR x22, [x8, #0xc8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_35 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache19;
            label_105:
            // 0x028F613C: CBNZ x19, #0x28f6144       | if (X1 != 0) goto label_106;            
            if(X1 != 0)
            {
                goto label_106;
            }
            // 0x028F6140: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            label_106:
            // 0x028F6144: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6148: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F614C: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x028F6150: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_35);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_35);
            // 0x028F6154: CBNZ x20, #0x28f615c       | if (val_1 != null) goto label_107;      
            if(val_1 != null)
            {
                goto label_107;
            }
            // 0x028F6158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_107:
            // 0x028F615C: ADRP x9, #0x35ed000        | X9 = 56545280 (0x35ED000);              
            // 0x028F6160: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028F6164: LDR x9, [x9, #0xf30]       | X9 = (string**)(1152921510024645328)("serverVer");
            // 0x028F6168: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F616C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F6170: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028F6174: LDR x1, [x9]               | X1 = "serverVer";                       
            // 0x028F6178: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028F617C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028F6180: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6184: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028F6188: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F618C: LDR x22, [x8, #0xd0]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1A;
            val_36 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1A;
            // 0x028F6190: CBNZ x22, #0x28f61d4       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1A != null) goto label_108;
            if(val_36 != null)
            {
                goto label_108;
            }
            // 0x028F6194: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x028F6198: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028F619C: LDR x8, [x8, #0xc30]       | X8 = 1152921510024645424;               
            // 0x028F61A0: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028F61A4: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_serverVer_5(ref object o);
            // 0x028F61A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028F61AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028F61B0: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_serverVer_5(ref object o);
            // 0x028F61B4: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_serverVer_5(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_serverVer_5(ref object o);
            // 0x028F61B8: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_serverVer_5(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_serverVer_5(ref object o);
            // 0x028F61BC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F61C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F61C4: STR x0, [x8, #0xd0]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1A = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782463184
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1A = null;
            // 0x028F61C8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F61CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F61D0: LDR x22, [x8, #0xd0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_36 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1A;
            label_108:
            // 0x028F61D4: CBNZ x19, #0x28f61dc       | if (X1 != 0) goto label_109;            
            if(X1 != 0)
            {
                goto label_109;
            }
            // 0x028F61D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_109:
            // 0x028F61DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F61E0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F61E4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028F61E8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_36);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_36);
            // 0x028F61EC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F61F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F61F4: LDR x22, [x8, #0xd8]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1B;
            val_37 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1B;
            // 0x028F61F8: CBNZ x22, #0x28f623c       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1B != null) goto label_110;
            if(val_37 != null)
            {
                goto label_110;
            }
            // 0x028F61FC: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x028F6200: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x028F6204: LDR x8, [x8, #0xf38]       | X8 = 1152921510024646448;               
            // 0x028F6208: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x028F620C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_serverVer_5(ref object o, object v);
            // 0x028F6210: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            // 0x028F6214: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x028F6218: LDR x8, [x22]              | X8 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_serverVer_5(ref object o, object v);
            // 0x028F621C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_serverVer_5(ref object o, object v);  //  dest_result_addr=1152921504824045600 |  dest_result_addr=1152921504824045608
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_serverVer_5(ref object o, object v);
            // 0x028F6220: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_serverVer_5(ref object o, object v);  //  dest_result_addr=1152921504824045584
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_serverVer_5(ref object o, object v);
            // 0x028F6224: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6228: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F622C: STR x0, [x8, #0xd8]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1B = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782463192
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1B = null;
            // 0x028F6230: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6234: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F6238: LDR x22, [x8, #0xd8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_37 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1B;
            label_110:
            // 0x028F623C: CBNZ x19, #0x28f6244       | if (X1 != 0) goto label_111;            
            if(X1 != 0)
            {
                goto label_111;
            }
            // 0x028F6240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            label_111:
            // 0x028F6244: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6248: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F624C: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x028F6250: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_37);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_37);
            // 0x028F6254: CBNZ x20, #0x28f625c       | if (val_1 != null) goto label_112;      
            if(val_1 != null)
            {
                goto label_112;
            }
            // 0x028F6258: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_112:
            // 0x028F625C: ADRP x9, #0x3662000        | X9 = 57024512 (0x3662000);              
            // 0x028F6260: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028F6264: LDR x9, [x9, #0x9f8]       | X9 = (string**)(1152921510024647472)("DOWNLOAD_URL");
            // 0x028F6268: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F626C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F6270: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028F6274: LDR x1, [x9]               | X1 = "DOWNLOAD_URL";                    
            // 0x028F6278: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028F627C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028F6280: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6284: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028F6288: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F628C: LDR x22, [x8, #0xe0]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1C;
            val_38 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1C;
            // 0x028F6290: CBNZ x22, #0x28f62d4       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1C != null) goto label_113;
            if(val_38 != null)
            {
                goto label_113;
            }
            // 0x028F6294: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x028F6298: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028F629C: LDR x8, [x8, #0x3f8]       | X8 = 1152921510024647568;               
            // 0x028F62A0: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028F62A4: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_DOWNLOAD_URL_6(ref object o);
            // 0x028F62A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028F62AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028F62B0: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_DOWNLOAD_URL_6(ref object o);
            // 0x028F62B4: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_DOWNLOAD_URL_6(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_DOWNLOAD_URL_6(ref object o);
            // 0x028F62B8: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_DOWNLOAD_URL_6(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_DOWNLOAD_URL_6(ref object o);
            // 0x028F62BC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F62C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F62C4: STR x0, [x8, #0xe0]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1C = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782463200
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1C = null;
            // 0x028F62C8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F62CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F62D0: LDR x22, [x8, #0xe0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_38 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1C;
            label_113:
            // 0x028F62D4: CBNZ x19, #0x28f62dc       | if (X1 != 0) goto label_114;            
            if(X1 != 0)
            {
                goto label_114;
            }
            // 0x028F62D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_114:
            // 0x028F62DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F62E0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F62E4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028F62E8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_38);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_38);
            // 0x028F62EC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F62F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F62F4: LDR x22, [x8, #0xe8]       | X22 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1D;
            val_39 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1D;
            // 0x028F62F8: CBNZ x22, #0x28f633c       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1D != null) goto label_115;
            if(val_39 != null)
            {
                goto label_115;
            }
            // 0x028F62FC: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x028F6300: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x028F6304: LDR x8, [x8, #0x560]       | X8 = 1152921510024648592;               
            // 0x028F6308: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x028F630C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_DOWNLOAD_URL_6(ref object o, object v);
            // 0x028F6310: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            // 0x028F6314: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x028F6318: LDR x8, [x22]              | X8 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_DOWNLOAD_URL_6(ref object o, object v);
            // 0x028F631C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_DOWNLOAD_URL_6(ref object o, object v);  //  dest_result_addr=1152921504824045600 |  dest_result_addr=1152921504824045608
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_DOWNLOAD_URL_6(ref object o, object v);
            // 0x028F6320: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_DOWNLOAD_URL_6(ref object o, object v);  //  dest_result_addr=1152921504824045584
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_DOWNLOAD_URL_6(ref object o, object v);
            // 0x028F6324: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6328: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F632C: STR x0, [x8, #0xe8]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1D = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782463208
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1D = null;
            // 0x028F6330: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6334: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F6338: LDR x22, [x8, #0xe8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_39 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1D;
            label_115:
            // 0x028F633C: CBNZ x19, #0x28f6344       | if (X1 != 0) goto label_116;            
            if(X1 != 0)
            {
                goto label_116;
            }
            // 0x028F6340: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            label_116:
            // 0x028F6344: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6348: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028F634C: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x028F6350: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_39);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_39);
            // 0x028F6354: CBNZ x20, #0x28f635c       | if (val_1 != null) goto label_117;      
            if(val_1 != null)
            {
                goto label_117;
            }
            // 0x028F6358: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_117:
            // 0x028F635C: ADRP x9, #0x35e0000        | X9 = 56492032 (0x35E0000);              
            // 0x028F6360: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028F6364: LDR x9, [x9, #0xc8]        | X9 = (string**)(1152921510024649616)("isloadServer");
            // 0x028F6368: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F636C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F6370: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028F6374: LDR x1, [x9]               | X1 = "isloadServer";                    
            // 0x028F6378: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028F637C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028F6380: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6384: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x028F6388: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F638C: LDR x21, [x8, #0xf0]       | X21 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1E;
            val_40 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1E;
            // 0x028F6390: CBNZ x21, #0x28f63d4       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1E != null) goto label_118;
            if(val_40 != null)
            {
                goto label_118;
            }
            // 0x028F6394: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x028F6398: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028F639C: LDR x8, [x8, #0x550]       | X8 = 1152921510024649712;               
            // 0x028F63A0: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028F63A4: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isloadServer_7(ref object o);
            // 0x028F63A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028F63AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028F63B0: LDR x8, [x21]              | X8 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isloadServer_7(ref object o);
            // 0x028F63B4: STP xzr, x21, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isloadServer_7(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isloadServer_7(ref object o);
            // 0x028F63B8: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isloadServer_7(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::get_isloadServer_7(ref object o);
            // 0x028F63BC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F63C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F63C4: STR x0, [x8, #0xf0]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1E = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782463216
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1E = null;
            // 0x028F63C8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F63CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F63D0: LDR x21, [x8, #0xf0]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_40 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1E;
            label_118:
            // 0x028F63D4: CBNZ x19, #0x28f63dc       | if (X1 != 0) goto label_119;            
            if(X1 != 0)
            {
                goto label_119;
            }
            // 0x028F63D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_119:
            // 0x028F63DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F63E0: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x028F63E4: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028F63E8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_40);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_40);
            // 0x028F63EC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F63F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F63F4: LDR x21, [x8, #0xf8]       | X21 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1F;
            val_41 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1F;
            // 0x028F63F8: CBNZ x21, #0x28f643c       | if (ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1F != null) goto label_120;
            if(val_41 != null)
            {
                goto label_120;
            }
            // 0x028F63FC: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x028F6400: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x028F6404: LDR x8, [x8, #0xc78]       | X8 = 1152921510024650736;               
            // 0x028F6408: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x028F640C: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_isloadServer_7(ref object o, object v);
            // 0x028F6410: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            // 0x028F6414: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x028F6418: LDR x8, [x21]              | X8 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_isloadServer_7(ref object o, object v);
            // 0x028F641C: STP xzr, x21, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_isloadServer_7(ref object o, object v);  //  dest_result_addr=1152921504824045600 |  dest_result_addr=1152921504824045608
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_isloadServer_7(ref object o, object v);
            // 0x028F6420: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_isloadServer_7(ref object o, object v);  //  dest_result_addr=1152921504824045584
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ABCheckUpdate_Binding::set_isloadServer_7(ref object o, object v);
            // 0x028F6424: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6428: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F642C: STR x0, [x8, #0xf8]        | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1F = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782463224
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1F = null;
            // 0x028F6430: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ABCheckUpdate_Binding);
            // 0x028F6434: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F6438: LDR x21, [x8, #0xf8]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_41 = ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.<>f__mg$cache1F;
            label_120:
            // 0x028F643C: CBNZ x19, #0x28f6444       | if (X1 != 0) goto label_121;            
            if(X1 != 0)
            {
                goto label_121;
            }
            // 0x028F6440: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            label_121:
            // 0x028F6444: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6448: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x028F644C: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x028F6450: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F6454: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F6458: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F645C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F6460: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F6464: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_41); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_41);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028F6468 (42951784), len: 552  VirtAddr: 0x028F6468 RVA: 0x028F6468 token: 100663633 methodIndex: 29678 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_GetUpdateTargetVS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            // 0x028F6468: STP x24, x23, [sp, #-0x40]! | stack[1152921510024919056] = ???;  stack[1152921510024919064] = ???;  //  dest_result_addr=1152921510024919056 |  dest_result_addr=1152921510024919064
            // 0x028F646C: STP x22, x21, [sp, #0x10]  | stack[1152921510024919072] = ???;  stack[1152921510024919080] = ???;  //  dest_result_addr=1152921510024919072 |  dest_result_addr=1152921510024919080
            // 0x028F6470: STP x20, x19, [sp, #0x20]  | stack[1152921510024919088] = ???;  stack[1152921510024919096] = ???;  //  dest_result_addr=1152921510024919088 |  dest_result_addr=1152921510024919096
            // 0x028F6474: STP x29, x30, [sp, #0x30]  | stack[1152921510024919104] = ???;  stack[1152921510024919112] = ???;  //  dest_result_addr=1152921510024919104 |  dest_result_addr=1152921510024919112
            // 0x028F6478: ADD x29, sp, #0x30         | X29 = (1152921510024919056 + 48) = 1152921510024919104 (0x1000000142F13840);
            // 0x028F647C: SUB sp, sp, #0x10          | SP = (1152921510024919056 - 16) = 1152921510024919040 (0x1000000142F13800);
            // 0x028F6480: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F6484: LDRB w8, [x21, #0xa44]     | W8 = (bool)static_value_037B8A44;       
            // 0x028F6488: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028F648C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028F6490: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F6494: TBNZ w8, #0, #0x28f64b0    | if (static_value_037B8A44 == true) goto label_0;
            // 0x028F6498: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x028F649C: LDR x8, [x8, #0xb20]       | X8 = 0x2B8A620;                         
            // 0x028F64A0: LDR w0, [x8]               | W0 = 0x46;                              
            // 0x028F64A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x46, ????);       
            // 0x028F64A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F64AC: STRB w8, [x21, #0xa44]     | static_value_037B8A44 = true;            //  dest_result_addr=58427972
            label_0:
            // 0x028F64B0: CBNZ x20, #0x28f64b8       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F64B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x46, ????);       
            label_1:
            // 0x028F64B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F64BC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F64C0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F64C4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F64C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F64CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F64D0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F64D4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F64D8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F64DC: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028F64E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F64E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F64E8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F64EC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F64F0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F64F4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F64F8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F64FC: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F6500: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x028F6504: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F6508: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F650C: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F6510: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F6514: TBZ w9, #0, #0x28f6528     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F6518: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F651C: CBNZ w9, #0x28f6528        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F6520: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F6524: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F6528: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F652C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6530: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F6534: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F6538: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F653C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F6540: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F6544: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F6548: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F654C: TBZ w9, #0, #0x28f6560     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F6550: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F6554: CBNZ w9, #0x28f6560        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F6558: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F655C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F6560: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6564: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F6568: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x028F656C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F6570: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028F6574: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F6578: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F657C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F6580: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x028F6584: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F6588: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F658C: TBZ w9, #0, #0x28f65a0     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F6590: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F6594: CBNZ w9, #0x28f65a0        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F6598: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F659C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F65A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F65A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F65A8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F65AC: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x028F65B0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F65B4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x028F65B8: CBZ x0, #0x28f661c         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F65BC: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F65C0: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F65C4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F65C8: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F65CC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F65D0: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F65D4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F65D8: B.LO #0x28f65f4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F65DC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F65E0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F65E4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F65E8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F65EC: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x028F65F0: B.EQ #0x28f661c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F65F4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F65F8: ADD x8, sp, #8             | X8 = (1152921510024919040 + 8) = 1152921510024919048 (0x1000000142F13808);
            // 0x028F65FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F6600: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510024907120]
            // 0x028F6604: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F6608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F660C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F6610: ADD x0, sp, #8             | X0 = (1152921510024919040 + 8) = 1152921510024919048 (0x1000000142F13808);
            // 0x028F6614: BL #0x299a140              | 
            // 0x028F6618: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x028F661C: CBNZ x20, #0x28f6624       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F6620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000142F13808, ????);
            label_11:
            // 0x028F6624: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6628: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F662C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x028F6630: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F6634: CBNZ x23, #0x28f663c       | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x028F6638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F663C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F6640: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028F6644: BL #0xb145d0               | X0 = val_11.get_GetUpdateTargetVS();    
            string val_9 = val_11.GetUpdateTargetVS;
            // 0x028F6648: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x028F664C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6650: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028F6654: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028F6658: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028F665C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F6660: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x028F6664: SUB sp, x29, #0x30         | SP = (1152921510024919104 - 48) = 1152921510024919056 (0x1000000142F13810);
            // 0x028F6668: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028F666C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028F6670: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028F6674: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028F6678: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F667C: MOV x19, x0                | 
            // 0x028F6680: ADD x0, sp, #8             | 
            // 0x028F6684: BL #0x299a140              | 
            // 0x028F6688: MOV x0, x19                | 
            // 0x028F668C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F6690 (42952336), len: 124  VirtAddr: 0x028F6690 RVA: 0x028F6690 token: 100663634 methodIndex: 29679 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_Instance_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x028F6690: STP x22, x21, [sp, #-0x30]! | stack[1152921510025084320] = ???;  stack[1152921510025084328] = ???;  //  dest_result_addr=1152921510025084320 |  dest_result_addr=1152921510025084328
            // 0x028F6694: STP x20, x19, [sp, #0x10]  | stack[1152921510025084336] = ???;  stack[1152921510025084344] = ???;  //  dest_result_addr=1152921510025084336 |  dest_result_addr=1152921510025084344
            // 0x028F6698: STP x29, x30, [sp, #0x20]  | stack[1152921510025084352] = ???;  stack[1152921510025084360] = ???;  //  dest_result_addr=1152921510025084352 |  dest_result_addr=1152921510025084360
            // 0x028F669C: ADD x29, sp, #0x20         | X29 = (1152921510025084320 + 32) = 1152921510025084352 (0x1000000142F3BDC0);
            // 0x028F66A0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028F66A4: MOV x20, x2                | X20 = X2;//m1                           
            // 0x028F66A8: MOV x21, x1                | X21 = X1;//m1                           
            // 0x028F66AC: CBNZ x21, #0x28f66b4       | if (X1 != 0) goto label_0;              
            if(X1 != 0)
            {
                goto label_0;
            }
            // 0x028F66B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? __intp, ????);     
            label_0:
            // 0x028F66B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F66B8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028F66BC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F66C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F66C4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028F66C8: MOV x1, x20                | X1 = X2;//m1                            
            // 0x028F66CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F66D0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x028F66D4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028F66D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F66DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F66E0: BL #0xb145d8               | X0 = ABCheckUpdate.get_Instance();      
            ABCheckUpdate val_3 = ABCheckUpdate.Instance;
            // 0x028F66E4: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028F66E8: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028F66EC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F66F0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F66F4: MOV x3, x0                 | X3 = val_3;//m1                         
            // 0x028F66F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F66FC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028F6700: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F6704: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F6708: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F670C (42952460), len: 552  VirtAddr: 0x028F670C RVA: 0x028F670C token: 100663635 methodIndex: 29680 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_Version_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            // 0x028F670C: STP x24, x23, [sp, #-0x40]! | stack[1152921510025249552] = ???;  stack[1152921510025249560] = ???;  //  dest_result_addr=1152921510025249552 |  dest_result_addr=1152921510025249560
            // 0x028F6710: STP x22, x21, [sp, #0x10]  | stack[1152921510025249568] = ???;  stack[1152921510025249576] = ???;  //  dest_result_addr=1152921510025249568 |  dest_result_addr=1152921510025249576
            // 0x028F6714: STP x20, x19, [sp, #0x20]  | stack[1152921510025249584] = ???;  stack[1152921510025249592] = ???;  //  dest_result_addr=1152921510025249584 |  dest_result_addr=1152921510025249592
            // 0x028F6718: STP x29, x30, [sp, #0x30]  | stack[1152921510025249600] = ???;  stack[1152921510025249608] = ???;  //  dest_result_addr=1152921510025249600 |  dest_result_addr=1152921510025249608
            // 0x028F671C: ADD x29, sp, #0x30         | X29 = (1152921510025249552 + 48) = 1152921510025249600 (0x1000000142F64340);
            // 0x028F6720: SUB sp, sp, #0x10          | SP = (1152921510025249552 - 16) = 1152921510025249536 (0x1000000142F64300);
            // 0x028F6724: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F6728: LDRB w8, [x21, #0xa45]     | W8 = (bool)static_value_037B8A45;       
            // 0x028F672C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028F6730: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028F6734: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F6738: TBNZ w8, #0, #0x28f6754    | if (static_value_037B8A45 == true) goto label_0;
            // 0x028F673C: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x028F6740: LDR x8, [x8, #0x7e0]       | X8 = 0x2B8A658;                         
            // 0x028F6744: LDR w0, [x8]               | W0 = 0x54;                              
            // 0x028F6748: BL #0x2782188              | X0 = sub_2782188( ?? 0x54, ????);       
            // 0x028F674C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F6750: STRB w8, [x21, #0xa45]     | static_value_037B8A45 = true;            //  dest_result_addr=58427973
            label_0:
            // 0x028F6754: CBNZ x20, #0x28f675c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F6758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x54, ????);       
            label_1:
            // 0x028F675C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F6760: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F6764: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F6768: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F676C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6770: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6774: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F6778: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F677C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F6780: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028F6784: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6788: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F678C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F6790: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F6794: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F6798: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F679C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F67A0: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F67A4: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x028F67A8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F67AC: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F67B0: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F67B4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F67B8: TBZ w9, #0, #0x28f67cc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F67BC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F67C0: CBNZ w9, #0x28f67cc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F67C4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F67C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F67CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F67D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F67D4: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F67D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F67DC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F67E0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F67E4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F67E8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F67EC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F67F0: TBZ w9, #0, #0x28f6804     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F67F4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F67F8: CBNZ w9, #0x28f6804        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F67FC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F6800: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F6804: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6808: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F680C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x028F6810: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F6814: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028F6818: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F681C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F6820: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F6824: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x028F6828: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F682C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F6830: TBZ w9, #0, #0x28f6844     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F6834: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F6838: CBNZ w9, #0x28f6844        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F683C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F6840: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F6844: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6848: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F684C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F6850: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x028F6854: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F6858: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x028F685C: CBZ x0, #0x28f68c0         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F6860: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F6864: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F6868: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F686C: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F6870: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6874: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6878: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F687C: B.LO #0x28f6898            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F6880: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F6884: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F6888: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F688C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F6890: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x028F6894: B.EQ #0x28f68c0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F6898: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F689C: ADD x8, sp, #8             | X8 = (1152921510025249536 + 8) = 1152921510025249544 (0x1000000142F64308);
            // 0x028F68A0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F68A4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510025237616]
            // 0x028F68A8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F68AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F68B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F68B4: ADD x0, sp, #8             | X0 = (1152921510025249536 + 8) = 1152921510025249544 (0x1000000142F64308);
            // 0x028F68B8: BL #0x299a140              | 
            // 0x028F68BC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x028F68C0: CBNZ x20, #0x28f68c8       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F68C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000142F64308, ????);
            label_11:
            // 0x028F68C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F68CC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F68D0: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x028F68D4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F68D8: CBNZ x23, #0x28f68e0       | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x028F68DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F68E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F68E4: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028F68E8: BL #0xb14658               | X0 = val_11.get_Version();              
            string val_9 = val_11.Version;
            // 0x028F68EC: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x028F68F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F68F4: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028F68F8: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028F68FC: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028F6900: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F6904: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x028F6908: SUB sp, x29, #0x30         | SP = (1152921510025249600 - 48) = 1152921510025249552 (0x1000000142F64310);
            // 0x028F690C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028F6910: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028F6914: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028F6918: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028F691C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F6920: MOV x19, x0                | 
            // 0x028F6924: ADD x0, sp, #8             | 
            // 0x028F6928: BL #0x299a140              | 
            // 0x028F692C: MOV x0, x19                | 
            // 0x028F6930: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F6934 (42953012), len: 776  VirtAddr: 0x028F6934 RVA: 0x028F6934 token: 100663636 methodIndex: 29681 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* UpdateVersion_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            VersionInfo val_15;
            //  | 
            var val_16;
            // 0x028F6934: STP x26, x25, [sp, #-0x50]! | stack[1152921510025435264] = ???;  stack[1152921510025435272] = ???;  //  dest_result_addr=1152921510025435264 |  dest_result_addr=1152921510025435272
            // 0x028F6938: STP x24, x23, [sp, #0x10]  | stack[1152921510025435280] = ???;  stack[1152921510025435288] = ???;  //  dest_result_addr=1152921510025435280 |  dest_result_addr=1152921510025435288
            // 0x028F693C: STP x22, x21, [sp, #0x20]  | stack[1152921510025435296] = ???;  stack[1152921510025435304] = ???;  //  dest_result_addr=1152921510025435296 |  dest_result_addr=1152921510025435304
            // 0x028F6940: STP x20, x19, [sp, #0x30]  | stack[1152921510025435312] = ???;  stack[1152921510025435320] = ???;  //  dest_result_addr=1152921510025435312 |  dest_result_addr=1152921510025435320
            // 0x028F6944: STP x29, x30, [sp, #0x40]  | stack[1152921510025435328] = ???;  stack[1152921510025435336] = ???;  //  dest_result_addr=1152921510025435328 |  dest_result_addr=1152921510025435336
            // 0x028F6948: ADD x29, sp, #0x40         | X29 = (1152921510025435264 + 64) = 1152921510025435328 (0x1000000142F918C0);
            // 0x028F694C: SUB sp, sp, #0x10          | SP = (1152921510025435264 - 16) = 1152921510025435248 (0x1000000142F91870);
            // 0x028F6950: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F6954: LDRB w8, [x20, #0xa46]     | W8 = (bool)static_value_037B8A46;       
            // 0x028F6958: MOV x21, x3                | X21 = X3;//m1                           
            // 0x028F695C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028F6960: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F6964: TBNZ w8, #0, #0x28f6980    | if (static_value_037B8A46 == true) goto label_0;
            // 0x028F6968: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x028F696C: LDR x8, [x8, #0xc30]       | X8 = 0x2B8A68C;                         
            // 0x028F6970: LDR w0, [x8]               | W0 = 0x61;                              
            // 0x028F6974: BL #0x2782188              | X0 = sub_2782188( ?? 0x61, ????);       
            // 0x028F6978: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F697C: STRB w8, [x20, #0xa46]     | static_value_037B8A46 = true;            //  dest_result_addr=58427974
            label_0:
            // 0x028F6980: CBNZ x19, #0x28f6988       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F6984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x61, ????);       
            label_1:
            // 0x028F6988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F698C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6990: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F6994: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F6998: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F699C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F69A0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028F69A4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F69A8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F69AC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028F69B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F69B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F69B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F69BC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F69C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F69C4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F69C8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F69CC: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x028F69D0: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x028F69D4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F69D8: LDR x9, [x9, #0xb28]       | X9 = 1152921504911372288;               
            // 0x028F69DC: LDR x25, [x9]              | X25 = typeof(VersionInfo);              
            // 0x028F69E0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F69E4: TBZ w9, #0, #0x28f69f8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F69E8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F69EC: CBNZ w9, #0x28f69f8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F69F0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F69F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F69F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F69FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6A00: MOV x1, x25                | X1 = 1152921504911372288 (0x100000001226B000);//ML01
            // 0x028F6A04: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F6A08: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F6A0C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F6A10: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x028F6A14: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F6A18: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F6A1C: TBZ w9, #0, #0x28f6a30     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F6A20: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F6A24: CBNZ w9, #0x28f6a30        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F6A28: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F6A2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F6A30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6A34: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F6A38: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x028F6A3C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F6A40: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028F6A44: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F6A48: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F6A4C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F6A50: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x028F6A54: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F6A58: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F6A5C: TBZ w9, #0, #0x28f6a70     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F6A60: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F6A64: CBNZ w9, #0x28f6a70        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F6A68: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F6A6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F6A70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6A74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6A78: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x028F6A7C: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x028F6A80: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F6A84: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x028F6A88: CBZ x0, #0x28f6aec         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F6A8C: ADRP x9, #0x35f3000        | X9 = 56569856 (0x35F3000);              
            // 0x028F6A90: LDR x9, [x9, #0xac0]       | X9 = 1152921504911372288;               
            // 0x028F6A94: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F6A98: LDR x1, [x9]               | X1 = typeof(VersionInfo);               
            // 0x028F6A9C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6AA0: LDRB w9, [x1, #0x104]      | W9 = VersionInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6AA4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, VersionInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F6AA8: B.LO #0x28f6ac4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < VersionInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F6AAC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F6AB0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (VersionInfo.__il2cppRuntimeField_typeHiera
            // 0x028F6AB4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (VersionInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F6AB8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (VersionInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(VersionInfo))
            // 0x028F6ABC: MOV x25, x0                | X25 = val_6;//m1                        
            val_15 = val_6;
            // 0x028F6AC0: B.EQ #0x28f6aec            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (VersionInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F6AC4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F6AC8: MOV x8, sp                 | X8 = 1152921510025435248 (0x1000000142F91870);//ML01
            // 0x028F6ACC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F6AD0: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510025423344]
            // 0x028F6AD4: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F6AD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F6ADC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F6AE0: MOV x0, sp                 | X0 = 1152921510025435248 (0x1000000142F91870);//ML01
            // 0x028F6AE4: BL #0x299a140              | 
            // 0x028F6AE8: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x028F6AEC: CBNZ x19, #0x28f6af4       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F6AF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000142F91870, ????);
            label_11:
            // 0x028F6AF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6AF8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6AFC: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x028F6B00: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F6B04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6B08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6B0C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028F6B10: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F6B14: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F6B18: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x028F6B1C: LDR x8, [x8, #0x120]       | X8 = 1152921504910680064;               
            // 0x028F6B20: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x028F6B24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6B28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6B2C: LDR x1, [x8]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F6B30: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F6B34: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x028F6B38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6B3C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F6B40: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x028F6B44: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F6B48: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028F6B4C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F6B50: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x028F6B54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6B58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6B5C: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x028F6B60: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x028F6B64: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x028F6B68: CBZ x0, #0x28f6bcc         | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x028F6B6C: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F6B70: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F6B74: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F6B78: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F6B7C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6B80: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6B84: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F6B88: B.LO #0x28f6ba4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x028F6B8C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F6B90: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F6B94: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F6B98: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F6B9C: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x028F6BA0: B.EQ #0x28f6bcc            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x028F6BA4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F6BA8: ADD x8, sp, #8             | X8 = (1152921510025435248 + 8) = 1152921510025435256 (0x1000000142F91878);
            // 0x028F6BAC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F6BB0: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510025423344]
            // 0x028F6BB4: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x028F6BB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F6BBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x028F6BC0: ADD x0, sp, #8             | X0 = (1152921510025435248 + 8) = 1152921510025435256 (0x1000000142F91878);
            // 0x028F6BC4: BL #0x299a140              | 
            // 0x028F6BC8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_14:
            // 0x028F6BCC: CBNZ x19, #0x28f6bd4       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x028F6BD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000142F91878, ????);
            label_15:
            // 0x028F6BD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6BD8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6BDC: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x028F6BE0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F6BE4: CBNZ x21, #0x28f6bec       | if (0x0 != 0) goto label_16;            
            if(val_16 != 0)
            {
                goto label_16;
            }
            // 0x028F6BE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x028F6BEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6BF0: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x028F6BF4: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x028F6BF8: BL #0xb14c48               | val_16.UpdateVersion(vsInfo:  val_15);  
            val_16.UpdateVersion(vsInfo:  val_15);
            // 0x028F6BFC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x028F6C00: SUB sp, x29, #0x40         | SP = (1152921510025435328 - 64) = 1152921510025435264 (0x1000000142F91880);
            // 0x028F6C04: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F6C08: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F6C0C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F6C10: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F6C14: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F6C18: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F6C1C: MOV x19, x0                | 
            // 0x028F6C20: MOV x0, sp                 | 
            // 0x028F6C24: B #0x28f6c30               | 
            // 0x028F6C28: MOV x19, x0                | 
            // 0x028F6C2C: ADD x0, sp, #8             | 
            label_17:
            // 0x028F6C30: BL #0x299a140              | 
            // 0x028F6C34: MOV x0, x19                | 
            // 0x028F6C38: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F6C3C (42953788), len: 528  VirtAddr: 0x028F6C3C RVA: 0x028F6C3C token: 100663637 methodIndex: 29682 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Start_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x028F6C3C: STP x24, x23, [sp, #-0x40]! | stack[1152921510025616912] = ???;  stack[1152921510025616920] = ???;  //  dest_result_addr=1152921510025616912 |  dest_result_addr=1152921510025616920
            // 0x028F6C40: STP x22, x21, [sp, #0x10]  | stack[1152921510025616928] = ???;  stack[1152921510025616936] = ???;  //  dest_result_addr=1152921510025616928 |  dest_result_addr=1152921510025616936
            // 0x028F6C44: STP x20, x19, [sp, #0x20]  | stack[1152921510025616944] = ???;  stack[1152921510025616952] = ???;  //  dest_result_addr=1152921510025616944 |  dest_result_addr=1152921510025616952
            // 0x028F6C48: STP x29, x30, [sp, #0x30]  | stack[1152921510025616960] = ???;  stack[1152921510025616968] = ???;  //  dest_result_addr=1152921510025616960 |  dest_result_addr=1152921510025616968
            // 0x028F6C4C: ADD x29, sp, #0x30         | X29 = (1152921510025616912 + 48) = 1152921510025616960 (0x1000000142FBDE40);
            // 0x028F6C50: SUB sp, sp, #0x10          | SP = (1152921510025616912 - 16) = 1152921510025616896 (0x1000000142FBDE00);
            // 0x028F6C54: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F6C58: LDRB w8, [x20, #0xa47]     | W8 = (bool)static_value_037B8A47;       
            // 0x028F6C5C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F6C60: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F6C64: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F6C68: TBNZ w8, #0, #0x28f6c84    | if (static_value_037B8A47 == true) goto label_0;
            // 0x028F6C6C: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x028F6C70: LDR x8, [x8, #0x4c0]       | X8 = 0x2B8A680;                         
            // 0x028F6C74: LDR w0, [x8]               | W0 = 0x5E;                              
            // 0x028F6C78: BL #0x2782188              | X0 = sub_2782188( ?? 0x5E, ????);       
            // 0x028F6C7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F6C80: STRB w8, [x20, #0xa47]     | static_value_037B8A47 = true;            //  dest_result_addr=58427975
            label_0:
            // 0x028F6C84: CBNZ x19, #0x28f6c8c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F6C88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x5E, ????);       
            label_1:
            // 0x028F6C8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F6C90: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6C94: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F6C98: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F6C9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6CA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6CA4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F6CA8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F6CAC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F6CB0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028F6CB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6CB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6CBC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F6CC0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F6CC4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F6CC8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F6CCC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F6CD0: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F6CD4: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F6CD8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F6CDC: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F6CE0: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F6CE4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F6CE8: TBZ w9, #0, #0x28f6cfc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F6CEC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F6CF0: CBNZ w9, #0x28f6cfc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F6CF4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F6CF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F6CFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6D00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6D04: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F6D08: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F6D0C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F6D10: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F6D14: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F6D18: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F6D1C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F6D20: TBZ w9, #0, #0x28f6d34     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F6D24: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F6D28: CBNZ w9, #0x28f6d34        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F6D2C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F6D30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F6D34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6D38: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F6D3C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F6D40: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F6D44: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F6D48: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F6D4C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F6D50: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F6D54: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F6D58: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F6D5C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F6D60: TBZ w9, #0, #0x28f6d74     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F6D64: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F6D68: CBNZ w9, #0x28f6d74        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F6D6C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F6D70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F6D74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6D78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6D7C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F6D80: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F6D84: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F6D88: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x028F6D8C: CBZ x0, #0x28f6df0         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F6D90: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F6D94: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F6D98: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F6D9C: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F6DA0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6DA4: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6DA8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F6DAC: B.LO #0x28f6dc8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F6DB0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F6DB4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F6DB8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F6DBC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F6DC0: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x028F6DC4: B.EQ #0x28f6df0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F6DC8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F6DCC: ADD x8, sp, #8             | X8 = (1152921510025616896 + 8) = 1152921510025616904 (0x1000000142FBDE08);
            // 0x028F6DD0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F6DD4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510025604976]
            // 0x028F6DD8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F6DDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F6DE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F6DE4: ADD x0, sp, #8             | X0 = (1152921510025616896 + 8) = 1152921510025616904 (0x1000000142FBDE08);
            // 0x028F6DE8: BL #0x299a140              | 
            // 0x028F6DEC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x028F6DF0: CBNZ x19, #0x28f6df8       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F6DF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000142FBDE08, ????);
            label_11:
            // 0x028F6DF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6DFC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6E00: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F6E04: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F6E08: CBNZ x22, #0x28f6e10       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x028F6E0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F6E10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F6E14: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F6E18: BL #0xb14dfc               | val_9.Start();                          
            val_9.Start();
            // 0x028F6E1C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x028F6E20: SUB sp, x29, #0x30         | SP = (1152921510025616960 - 48) = 1152921510025616912 (0x1000000142FBDE10);
            // 0x028F6E24: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028F6E28: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028F6E2C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028F6E30: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028F6E34: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F6E38: MOV x19, x0                | 
            // 0x028F6E3C: ADD x0, sp, #8             | 
            // 0x028F6E40: BL #0x299a140              | 
            // 0x028F6E44: MOV x0, x19                | 
            // 0x028F6E48: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F6E4C (42954316), len: 528  VirtAddr: 0x028F6E4C RVA: 0x028F6E4C token: 100663638 methodIndex: 29683 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* RequestCheckUpdate_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x028F6E4C: STP x24, x23, [sp, #-0x40]! | stack[1152921510025786256] = ???;  stack[1152921510025786264] = ???;  //  dest_result_addr=1152921510025786256 |  dest_result_addr=1152921510025786264
            // 0x028F6E50: STP x22, x21, [sp, #0x10]  | stack[1152921510025786272] = ???;  stack[1152921510025786280] = ???;  //  dest_result_addr=1152921510025786272 |  dest_result_addr=1152921510025786280
            // 0x028F6E54: STP x20, x19, [sp, #0x20]  | stack[1152921510025786288] = ???;  stack[1152921510025786296] = ???;  //  dest_result_addr=1152921510025786288 |  dest_result_addr=1152921510025786296
            // 0x028F6E58: STP x29, x30, [sp, #0x30]  | stack[1152921510025786304] = ???;  stack[1152921510025786312] = ???;  //  dest_result_addr=1152921510025786304 |  dest_result_addr=1152921510025786312
            // 0x028F6E5C: ADD x29, sp, #0x30         | X29 = (1152921510025786256 + 48) = 1152921510025786304 (0x1000000142FE73C0);
            // 0x028F6E60: SUB sp, sp, #0x10          | SP = (1152921510025786256 - 16) = 1152921510025786240 (0x1000000142FE7380);
            // 0x028F6E64: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F6E68: LDRB w8, [x20, #0xa48]     | W8 = (bool)static_value_037B8A48;       
            // 0x028F6E6C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F6E70: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F6E74: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F6E78: TBNZ w8, #0, #0x28f6e94    | if (static_value_037B8A48 == true) goto label_0;
            // 0x028F6E7C: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x028F6E80: LDR x8, [x8, #0xf0]        | X8 = 0x2B8A66C;                         
            // 0x028F6E84: LDR w0, [x8]               | W0 = 0x59;                              
            // 0x028F6E88: BL #0x2782188              | X0 = sub_2782188( ?? 0x59, ????);       
            // 0x028F6E8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F6E90: STRB w8, [x20, #0xa48]     | static_value_037B8A48 = true;            //  dest_result_addr=58427976
            label_0:
            // 0x028F6E94: CBNZ x19, #0x28f6e9c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F6E98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x59, ????);       
            label_1:
            // 0x028F6E9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F6EA0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F6EA4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F6EA8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F6EAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6EB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6EB4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F6EB8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F6EBC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F6EC0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028F6EC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6EC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6ECC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F6ED0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F6ED4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F6ED8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F6EDC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F6EE0: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F6EE4: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F6EE8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F6EEC: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F6EF0: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F6EF4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F6EF8: TBZ w9, #0, #0x28f6f0c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F6EFC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F6F00: CBNZ w9, #0x28f6f0c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F6F04: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F6F08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F6F0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6F10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F6F14: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F6F18: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F6F1C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F6F20: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F6F24: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F6F28: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F6F2C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F6F30: TBZ w9, #0, #0x28f6f44     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F6F34: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F6F38: CBNZ w9, #0x28f6f44        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F6F3C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F6F40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F6F44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6F48: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F6F4C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F6F50: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F6F54: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F6F58: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F6F5C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F6F60: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F6F64: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F6F68: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F6F6C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F6F70: TBZ w9, #0, #0x28f6f84     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F6F74: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F6F78: CBNZ w9, #0x28f6f84        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F6F7C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F6F80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F6F84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F6F88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F6F8C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F6F90: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F6F94: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F6F98: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x028F6F9C: CBZ x0, #0x28f7000         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F6FA0: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F6FA4: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F6FA8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F6FAC: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F6FB0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6FB4: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F6FB8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F6FBC: B.LO #0x28f6fd8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F6FC0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F6FC4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F6FC8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F6FCC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F6FD0: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x028F6FD4: B.EQ #0x28f7000            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F6FD8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F6FDC: ADD x8, sp, #8             | X8 = (1152921510025786240 + 8) = 1152921510025786248 (0x1000000142FE7388);
            // 0x028F6FE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F6FE4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510025774320]
            // 0x028F6FE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F6FEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F6FF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F6FF4: ADD x0, sp, #8             | X0 = (1152921510025786240 + 8) = 1152921510025786248 (0x1000000142FE7388);
            // 0x028F6FF8: BL #0x299a140              | 
            // 0x028F6FFC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x028F7000: CBNZ x19, #0x28f7008       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F7004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000142FE7388, ????);
            label_11:
            // 0x028F7008: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F700C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F7010: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7014: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F7018: CBNZ x22, #0x28f7020       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x028F701C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F7020: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7024: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F7028: BL #0xb15254               | val_9.RequestCheckUpdate();             
            val_9.RequestCheckUpdate();
            // 0x028F702C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x028F7030: SUB sp, x29, #0x30         | SP = (1152921510025786304 - 48) = 1152921510025786256 (0x1000000142FE7390);
            // 0x028F7034: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028F7038: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028F703C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028F7040: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028F7044: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F7048: MOV x19, x0                | 
            // 0x028F704C: ADD x0, sp, #8             | 
            // 0x028F7050: BL #0x299a140              | 
            // 0x028F7054: MOV x0, x19                | 
            // 0x028F7058: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F705C (42954844), len: 528  VirtAddr: 0x028F705C RVA: 0x028F705C token: 100663639 methodIndex: 29684 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* StartDown_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x028F705C: STP x24, x23, [sp, #-0x40]! | stack[1152921510025955600] = ???;  stack[1152921510025955608] = ???;  //  dest_result_addr=1152921510025955600 |  dest_result_addr=1152921510025955608
            // 0x028F7060: STP x22, x21, [sp, #0x10]  | stack[1152921510025955616] = ???;  stack[1152921510025955624] = ???;  //  dest_result_addr=1152921510025955616 |  dest_result_addr=1152921510025955624
            // 0x028F7064: STP x20, x19, [sp, #0x20]  | stack[1152921510025955632] = ???;  stack[1152921510025955640] = ???;  //  dest_result_addr=1152921510025955632 |  dest_result_addr=1152921510025955640
            // 0x028F7068: STP x29, x30, [sp, #0x30]  | stack[1152921510025955648] = ???;  stack[1152921510025955656] = ???;  //  dest_result_addr=1152921510025955648 |  dest_result_addr=1152921510025955656
            // 0x028F706C: ADD x29, sp, #0x30         | X29 = (1152921510025955600 + 48) = 1152921510025955648 (0x1000000143010940);
            // 0x028F7070: SUB sp, sp, #0x10          | SP = (1152921510025955600 - 16) = 1152921510025955584 (0x1000000143010900);
            // 0x028F7074: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F7078: LDRB w8, [x20, #0xa49]     | W8 = (bool)static_value_037B8A49;       
            // 0x028F707C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F7080: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F7084: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F7088: TBNZ w8, #0, #0x28f70a4    | if (static_value_037B8A49 == true) goto label_0;
            // 0x028F708C: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x028F7090: LDR x8, [x8, #0xd20]       | X8 = 0x2B8A688;                         
            // 0x028F7094: LDR w0, [x8]               | W0 = 0x60;                              
            // 0x028F7098: BL #0x2782188              | X0 = sub_2782188( ?? 0x60, ????);       
            // 0x028F709C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F70A0: STRB w8, [x20, #0xa49]     | static_value_037B8A49 = true;            //  dest_result_addr=58427977
            label_0:
            // 0x028F70A4: CBNZ x19, #0x28f70ac       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F70A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x60, ????);       
            label_1:
            // 0x028F70AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F70B0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F70B4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F70B8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F70BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F70C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F70C4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F70C8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F70CC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F70D0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028F70D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F70D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F70DC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F70E0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F70E4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F70E8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F70EC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F70F0: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F70F4: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F70F8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F70FC: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F7100: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F7104: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F7108: TBZ w9, #0, #0x28f711c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F710C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F7110: CBNZ w9, #0x28f711c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F7114: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F7118: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F711C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7120: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7124: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F7128: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F712C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F7130: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F7134: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F7138: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F713C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F7140: TBZ w9, #0, #0x28f7154     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F7144: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F7148: CBNZ w9, #0x28f7154        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F714C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F7150: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F7154: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7158: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F715C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7160: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F7164: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F7168: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F716C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F7170: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F7174: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F7178: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F717C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F7180: TBZ w9, #0, #0x28f7194     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F7184: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F7188: CBNZ w9, #0x28f7194        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F718C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F7190: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F7194: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7198: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F719C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F71A0: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F71A4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F71A8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x028F71AC: CBZ x0, #0x28f7210         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F71B0: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F71B4: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F71B8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F71BC: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F71C0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F71C4: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F71C8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F71CC: B.LO #0x28f71e8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F71D0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F71D4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F71D8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F71DC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F71E0: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x028F71E4: B.EQ #0x28f7210            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F71E8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F71EC: ADD x8, sp, #8             | X8 = (1152921510025955584 + 8) = 1152921510025955592 (0x1000000143010908);
            // 0x028F71F0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F71F4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510025943664]
            // 0x028F71F8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F71FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7200: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F7204: ADD x0, sp, #8             | X0 = (1152921510025955584 + 8) = 1152921510025955592 (0x1000000143010908);
            // 0x028F7208: BL #0x299a140              | 
            // 0x028F720C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x028F7210: CBNZ x19, #0x28f7218       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F7214: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143010908, ????);
            label_11:
            // 0x028F7218: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F721C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F7220: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7224: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F7228: CBNZ x22, #0x28f7230       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x028F722C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F7230: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7234: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F7238: BL #0xb189dc               | val_9.StartDown();                      
            val_9.StartDown();
            // 0x028F723C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x028F7240: SUB sp, x29, #0x30         | SP = (1152921510025955648 - 48) = 1152921510025955600 (0x1000000143010910);
            // 0x028F7244: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028F7248: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028F724C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028F7250: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028F7254: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F7258: MOV x19, x0                | 
            // 0x028F725C: ADD x0, sp, #8             | 
            // 0x028F7260: BL #0x299a140              | 
            // 0x028F7264: MOV x0, x19                | 
            // 0x028F7268: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F726C (42955372), len: 528  VirtAddr: 0x028F726C RVA: 0x028F726C token: 100663640 methodIndex: 29685 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* StartCsDown_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x028F726C: STP x24, x23, [sp, #-0x40]! | stack[1152921510026124944] = ???;  stack[1152921510026124952] = ???;  //  dest_result_addr=1152921510026124944 |  dest_result_addr=1152921510026124952
            // 0x028F7270: STP x22, x21, [sp, #0x10]  | stack[1152921510026124960] = ???;  stack[1152921510026124968] = ???;  //  dest_result_addr=1152921510026124960 |  dest_result_addr=1152921510026124968
            // 0x028F7274: STP x20, x19, [sp, #0x20]  | stack[1152921510026124976] = ???;  stack[1152921510026124984] = ???;  //  dest_result_addr=1152921510026124976 |  dest_result_addr=1152921510026124984
            // 0x028F7278: STP x29, x30, [sp, #0x30]  | stack[1152921510026124992] = ???;  stack[1152921510026125000] = ???;  //  dest_result_addr=1152921510026124992 |  dest_result_addr=1152921510026125000
            // 0x028F727C: ADD x29, sp, #0x30         | X29 = (1152921510026124944 + 48) = 1152921510026124992 (0x1000000143039EC0);
            // 0x028F7280: SUB sp, sp, #0x10          | SP = (1152921510026124944 - 16) = 1152921510026124928 (0x1000000143039E80);
            // 0x028F7284: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F7288: LDRB w8, [x20, #0xa4a]     | W8 = (bool)static_value_037B8A4A;       
            // 0x028F728C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F7290: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F7294: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F7298: TBNZ w8, #0, #0x28f72b4    | if (static_value_037B8A4A == true) goto label_0;
            // 0x028F729C: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x028F72A0: LDR x8, [x8, #0x508]       | X8 = 0x2B8A684;                         
            // 0x028F72A4: LDR w0, [x8]               | W0 = 0x5F;                              
            // 0x028F72A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x5F, ????);       
            // 0x028F72AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F72B0: STRB w8, [x20, #0xa4a]     | static_value_037B8A4A = true;            //  dest_result_addr=58427978
            label_0:
            // 0x028F72B4: CBNZ x19, #0x28f72bc       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F72B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x5F, ????);       
            label_1:
            // 0x028F72BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F72C0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F72C4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F72C8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F72CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F72D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F72D4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F72D8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F72DC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F72E0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028F72E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F72E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F72EC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F72F0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F72F4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F72F8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F72FC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F7300: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F7304: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F7308: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F730C: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F7310: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F7314: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F7318: TBZ w9, #0, #0x28f732c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F731C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F7320: CBNZ w9, #0x28f732c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F7324: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F7328: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F732C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7330: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7334: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F7338: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F733C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F7340: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F7344: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F7348: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F734C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F7350: TBZ w9, #0, #0x28f7364     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F7354: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F7358: CBNZ w9, #0x28f7364        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F735C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F7360: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F7364: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7368: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F736C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7370: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F7374: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F7378: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F737C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F7380: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F7384: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F7388: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F738C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F7390: TBZ w9, #0, #0x28f73a4     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F7394: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F7398: CBNZ w9, #0x28f73a4        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F739C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F73A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F73A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F73A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F73AC: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F73B0: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F73B4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F73B8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x028F73BC: CBZ x0, #0x28f7420         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F73C0: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F73C4: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F73C8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F73CC: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F73D0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F73D4: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F73D8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F73DC: B.LO #0x28f73f8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F73E0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F73E4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F73E8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F73EC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F73F0: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x028F73F4: B.EQ #0x28f7420            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F73F8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F73FC: ADD x8, sp, #8             | X8 = (1152921510026124928 + 8) = 1152921510026124936 (0x1000000143039E88);
            // 0x028F7400: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F7404: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510026113008]
            // 0x028F7408: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F740C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7410: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F7414: ADD x0, sp, #8             | X0 = (1152921510026124928 + 8) = 1152921510026124936 (0x1000000143039E88);
            // 0x028F7418: BL #0x299a140              | 
            // 0x028F741C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x028F7420: CBNZ x19, #0x28f7428       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F7424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143039E88, ????);
            label_11:
            // 0x028F7428: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F742C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F7430: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7434: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F7438: CBNZ x22, #0x28f7440       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x028F743C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F7440: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7444: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F7448: BL #0xb19498               | val_9.StartCsDown();                    
            val_9.StartCsDown();
            // 0x028F744C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x028F7450: SUB sp, x29, #0x30         | SP = (1152921510026124992 - 48) = 1152921510026124944 (0x1000000143039E90);
            // 0x028F7454: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028F7458: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028F745C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028F7460: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028F7464: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F7468: MOV x19, x0                | 
            // 0x028F746C: ADD x0, sp, #8             | 
            // 0x028F7470: BL #0x299a140              | 
            // 0x028F7474: MOV x0, x19                | 
            // 0x028F7478: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F747C (42955900), len: 784  VirtAddr: 0x028F747C RVA: 0x028F747C token: 100663641 methodIndex: 29686 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* BytesToString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            var val_16;
            //  | 
            System.Text.Encoding val_17;
            // 0x028F747C: STP x26, x25, [sp, #-0x50]! | stack[1152921510026310656] = ???;  stack[1152921510026310664] = ???;  //  dest_result_addr=1152921510026310656 |  dest_result_addr=1152921510026310664
            // 0x028F7480: STP x24, x23, [sp, #0x10]  | stack[1152921510026310672] = ???;  stack[1152921510026310680] = ???;  //  dest_result_addr=1152921510026310672 |  dest_result_addr=1152921510026310680
            // 0x028F7484: STP x22, x21, [sp, #0x20]  | stack[1152921510026310688] = ???;  stack[1152921510026310696] = ???;  //  dest_result_addr=1152921510026310688 |  dest_result_addr=1152921510026310696
            // 0x028F7488: STP x20, x19, [sp, #0x30]  | stack[1152921510026310704] = ???;  stack[1152921510026310712] = ???;  //  dest_result_addr=1152921510026310704 |  dest_result_addr=1152921510026310712
            // 0x028F748C: STP x29, x30, [sp, #0x40]  | stack[1152921510026310720] = ???;  stack[1152921510026310728] = ???;  //  dest_result_addr=1152921510026310720 |  dest_result_addr=1152921510026310728
            // 0x028F7490: ADD x29, sp, #0x40         | X29 = (1152921510026310656 + 64) = 1152921510026310720 (0x1000000143067440);
            // 0x028F7494: SUB sp, sp, #0x10          | SP = (1152921510026310656 - 16) = 1152921510026310640 (0x10000001430673F0);
            // 0x028F7498: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F749C: LDRB w8, [x21, #0xa4b]     | W8 = (bool)static_value_037B8A4B;       
            // 0x028F74A0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028F74A4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028F74A8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F74AC: TBNZ w8, #0, #0x28f74c8    | if (static_value_037B8A4B == true) goto label_0;
            // 0x028F74B0: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x028F74B4: LDR x8, [x8, #0xe40]       | X8 = 0x2B8A610;                         
            // 0x028F74B8: LDR w0, [x8]               | W0 = 0x42;                              
            // 0x028F74BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x42, ????);       
            // 0x028F74C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F74C4: STRB w8, [x21, #0xa4b]     | static_value_037B8A4B = true;            //  dest_result_addr=58427979
            label_0:
            // 0x028F74C8: CBNZ x20, #0x28f74d0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F74CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x42, ????);       
            label_1:
            // 0x028F74D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F74D4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F74D8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F74DC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F74E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F74E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F74E8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028F74EC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F74F0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F74F4: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028F74F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F74FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7500: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F7504: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F7508: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F750C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F7510: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F7514: ADRP x9, #0x35d8000        | X9 = 56459264 (0x35D8000);              
            // 0x028F7518: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x028F751C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F7520: LDR x9, [x9, #0xe38]       | X9 = 1152921504649285632;               
            // 0x028F7524: LDR x25, [x9]              | X25 = typeof(System.Text.Encoding);     
            // 0x028F7528: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F752C: TBZ w9, #0, #0x28f7540     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F7530: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F7534: CBNZ w9, #0x28f7540        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F7538: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F753C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F7540: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7544: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7548: MOV x1, x25                | X1 = 1152921504649285632 (0x1000000002879000);//ML01
            // 0x028F754C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F7550: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F7554: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F7558: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x028F755C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F7560: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F7564: TBZ w9, #0, #0x28f7578     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F7568: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F756C: CBNZ w9, #0x28f7578        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F7570: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F7574: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F7578: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F757C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F7580: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x028F7584: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F7588: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028F758C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F7590: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F7594: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F7598: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x028F759C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F75A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F75A4: TBZ w9, #0, #0x28f75b8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F75A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F75AC: CBNZ w9, #0x28f75b8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F75B0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F75B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F75B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F75BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F75C0: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x028F75C4: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x028F75C8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F75CC: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x028F75D0: CBZ x0, #0x28f7634         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F75D4: ADRP x9, #0x365a000        | X9 = 56991744 (0x365A000);              
            // 0x028F75D8: LDR x9, [x9, #0xd48]       | X9 = 1152921504649285632;               
            // 0x028F75DC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F75E0: LDR x1, [x9]               | X1 = typeof(System.Text.Encoding);      
            // 0x028F75E4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F75E8: LDRB w9, [x1, #0x104]      | W9 = System.Text.Encoding.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F75EC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Text.Encoding.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F75F0: B.LO #0x28f760c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Text.Encoding.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F75F4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F75F8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Text.Encoding.__il2cppRuntimeField_
            // 0x028F75FC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Text.Encoding.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F7600: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Text.Encoding.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Text.Encoding))
            // 0x028F7604: MOV x25, x0                | X25 = val_6;//m1                        
            val_16 = val_6;
            // 0x028F7608: B.EQ #0x28f7634            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Text.Encoding.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F760C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F7610: MOV x8, sp                 | X8 = 1152921510026310640 (0x10000001430673F0);//ML01
            // 0x028F7614: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F7618: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510026298736]
            // 0x028F761C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F7620: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7624: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F7628: MOV x0, sp                 | X0 = 1152921510026310640 (0x10000001430673F0);//ML01
            // 0x028F762C: BL #0x299a140              | 
            // 0x028F7630: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_10:
            // 0x028F7634: CBNZ x20, #0x28f763c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F7638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001430673F0, ????);
            label_11:
            // 0x028F763C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7640: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F7644: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x028F7648: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F764C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7650: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7654: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028F7658: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F765C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F7660: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x028F7664: LDR x8, [x8, #0x888]       | X8 = 1152921504996170800;               
            // 0x028F7668: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x028F766C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7670: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7674: LDR x1, [x8]               | X1 = typeof(System.Byte[]);             
            // 0x028F7678: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F767C: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x028F7680: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7684: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F7688: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x028F768C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F7690: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028F7694: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F7698: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x028F769C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F76A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F76A4: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x028F76A8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x028F76AC: MOV x24, x0                | X24 = val_12;//m1                       
            // 0x028F76B0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x028F76B4: CBZ x24, #0x28f7708        | if (val_12 == null) goto label_13;      
            if(val_12 == null)
            {
                goto label_13;
            }
            // 0x028F76B8: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x028F76BC: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x028F76C0: MOV x0, x24                | X0 = val_12;//m1                        
            // 0x028F76C4: LDR x26, [x8]              | X26 = typeof(System.Byte[]);            
            // 0x028F76C8: MOV x1, x26                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028F76CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x028F76D0: MOV x23, x0                | X23 = val_12;//m1                       
            val_17 = val_12;
            // 0x028F76D4: CBNZ x23, #0x28f7708       | if (val_12 != null) goto label_13;      
            if(val_17 != null)
            {
                goto label_13;
            }
            // 0x028F76D8: LDR x8, [x24]              | X8 = typeof(System.Object);             
            // 0x028F76DC: MOV x1, x26                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028F76E0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F76E4: ADD x8, sp, #8             | X8 = (1152921510026310640 + 8) = 1152921510026310648 (0x10000001430673F8);
            // 0x028F76E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F76EC: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510026298736]
            // 0x028F76F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x028F76F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F76F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x028F76FC: ADD x0, sp, #8             | X0 = (1152921510026310640 + 8) = 1152921510026310648 (0x10000001430673F8);
            // 0x028F7700: BL #0x299a140              | 
            // 0x028F7704: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_13:
            // 0x028F7708: CBNZ x20, #0x28f7710       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x028F770C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001430673F8, ????);
            label_14:
            // 0x028F7710: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7714: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F7718: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x028F771C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F7720: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7724: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7728: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x028F772C: MOV x2, x25                | X2 = 0 (0x0);//ML01                     
            // 0x028F7730: BL #0xb19978               | X0 = ABCheckUpdate.BytesToString(bytes:  0, encoding:  val_17);
            string val_14 = ABCheckUpdate.BytesToString(bytes:  0, encoding:  val_17);
            // 0x028F7734: MOV x3, x0                 | X3 = val_14;//m1                        
            // 0x028F7738: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F773C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028F7740: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028F7744: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028F7748: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F774C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x028F7750: SUB sp, x29, #0x40         | SP = (1152921510026310720 - 64) = 1152921510026310656 (0x1000000143067400);
            // 0x028F7754: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F7758: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F775C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F7760: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F7764: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F7768: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_15;
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F776C: MOV x19, x0                | 
            // 0x028F7770: MOV x0, sp                 | 
            // 0x028F7774: B #0x28f7780               | 
            // 0x028F7778: MOV x19, x0                | 
            // 0x028F777C: ADD x0, sp, #8             | 
            label_15:
            // 0x028F7780: BL #0x299a140              | 
            // 0x028F7784: MOV x0, x19                | 
            // 0x028F7788: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F778C (42956684), len: 612  VirtAddr: 0x028F778C RVA: 0x028F778C token: 100663642 methodIndex: 29687 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_IsDownSuccess_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x028F778C: STP x26, x25, [sp, #-0x50]! | stack[1152921510026496384] = ???;  stack[1152921510026496392] = ???;  //  dest_result_addr=1152921510026496384 |  dest_result_addr=1152921510026496392
            // 0x028F7790: STP x24, x23, [sp, #0x10]  | stack[1152921510026496400] = ???;  stack[1152921510026496408] = ???;  //  dest_result_addr=1152921510026496400 |  dest_result_addr=1152921510026496408
            // 0x028F7794: STP x22, x21, [sp, #0x20]  | stack[1152921510026496416] = ???;  stack[1152921510026496424] = ???;  //  dest_result_addr=1152921510026496416 |  dest_result_addr=1152921510026496424
            // 0x028F7798: STP x20, x19, [sp, #0x30]  | stack[1152921510026496432] = ???;  stack[1152921510026496440] = ???;  //  dest_result_addr=1152921510026496432 |  dest_result_addr=1152921510026496440
            // 0x028F779C: STP x29, x30, [sp, #0x40]  | stack[1152921510026496448] = ???;  stack[1152921510026496456] = ???;  //  dest_result_addr=1152921510026496448 |  dest_result_addr=1152921510026496456
            // 0x028F77A0: ADD x29, sp, #0x40         | X29 = (1152921510026496384 + 64) = 1152921510026496448 (0x10000001430949C0);
            // 0x028F77A4: SUB sp, sp, #0x10          | SP = (1152921510026496384 - 16) = 1152921510026496368 (0x1000000143094970);
            // 0x028F77A8: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F77AC: LDRB w8, [x19, #0xa4c]     | W8 = (bool)static_value_037B8A4C;       
            // 0x028F77B0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F77B4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F77B8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F77BC: TBNZ w8, #0, #0x28f77d8    | if (static_value_037B8A4C == true) goto label_0;
            // 0x028F77C0: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x028F77C4: LDR x8, [x8, #0x530]       | X8 = 0x2B8A62C;                         
            // 0x028F77C8: LDR w0, [x8]               | W0 = 0x49;                              
            // 0x028F77CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x49, ????);       
            // 0x028F77D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F77D4: STRB w8, [x19, #0xa4c]     | static_value_037B8A4C = true;            //  dest_result_addr=58427980
            label_0:
            // 0x028F77D8: CBNZ x20, #0x28f77e0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F77DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x49, ????);       
            label_1:
            // 0x028F77E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F77E4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F77E8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F77EC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F77F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F77F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F77F8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F77FC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F7800: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F7804: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x028F7808: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F780C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7810: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F7814: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F7818: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F781C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F7820: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F7824: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F7828: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F782C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F7830: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F7834: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F7838: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F783C: TBZ w9, #0, #0x28f7850     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F7840: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F7844: CBNZ w9, #0x28f7850        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F7848: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F784C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F7850: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7854: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7858: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F785C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F7860: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x028F7864: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x028F7868: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F786C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F7870: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F7874: TBZ w9, #0, #0x28f7888     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F7878: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F787C: CBNZ w9, #0x28f7888        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F7880: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F7884: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F7888: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F788C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F7890: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7894: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F7898: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F789C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F78A0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F78A4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F78A8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F78AC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F78B0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F78B4: TBZ w9, #0, #0x28f78c8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F78B8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F78BC: CBNZ w9, #0x28f78c8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F78C0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F78C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F78C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F78CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F78D0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F78D4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F78D8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F78DC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x028F78E0: CBZ x0, #0x28f7944         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F78E4: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F78E8: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F78EC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F78F0: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F78F4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F78F8: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F78FC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F7900: B.LO #0x28f791c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F7904: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F7908: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F790C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F7910: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F7914: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x028F7918: B.EQ #0x28f7944            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F791C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F7920: ADD x8, sp, #8             | X8 = (1152921510026496368 + 8) = 1152921510026496376 (0x1000000143094978);
            // 0x028F7924: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F7928: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510026484464]
            // 0x028F792C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F7930: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7934: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F7938: ADD x0, sp, #8             | X0 = (1152921510026496368 + 8) = 1152921510026496376 (0x1000000143094978);
            // 0x028F793C: BL #0x299a140              | 
            // 0x028F7940: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x028F7944: CBNZ x20, #0x28f794c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F7948: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143094978, ????);
            label_11:
            // 0x028F794C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7950: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F7954: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7958: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F795C: CBNZ x22, #0x28f7964       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x028F7960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F7964: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7968: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F796C: BL #0xb19ad4               | X0 = val_13.get_IsDownSuccess();        
            bool val_9 = val_13.IsDownSuccess;
            // 0x028F7970: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x028F7974: CBZ x19, #0x28f7988        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x028F7978: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F797C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028F7980: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028F7984: B #0x28f799c               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028F7988: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x028F798C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F7990: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028F7994: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028F7998: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x028F799C: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x028F79A0: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F79A4: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x028F79A8: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028F79AC: TBZ w9, #0, #0x28f79bc     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x028F79B0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028F79B4: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028F79B8: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x028F79BC: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x028F79C0: SUB sp, x29, #0x40         | SP = (1152921510026496448 - 64) = 1152921510026496384 (0x1000000143094980);
            // 0x028F79C4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F79C8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F79CC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F79D0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F79D4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F79D8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F79DC: MOV x19, x0                | 
            // 0x028F79E0: ADD x0, sp, #8             | 
            // 0x028F79E4: BL #0x299a140              | 
            // 0x028F79E8: MOV x0, x19                | 
            // 0x028F79EC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F79F0 (42957296), len: 588  VirtAddr: 0x028F79F0 RVA: 0x028F79F0 token: 100663643 methodIndex: 29688 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_WriteProgress_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x028F79F0: STP x26, x25, [sp, #-0x50]! | stack[1152921510026665728] = ???;  stack[1152921510026665736] = ???;  //  dest_result_addr=1152921510026665728 |  dest_result_addr=1152921510026665736
            // 0x028F79F4: STP x24, x23, [sp, #0x10]  | stack[1152921510026665744] = ???;  stack[1152921510026665752] = ???;  //  dest_result_addr=1152921510026665744 |  dest_result_addr=1152921510026665752
            // 0x028F79F8: STP x22, x21, [sp, #0x20]  | stack[1152921510026665760] = ???;  stack[1152921510026665768] = ???;  //  dest_result_addr=1152921510026665760 |  dest_result_addr=1152921510026665768
            // 0x028F79FC: STP x20, x19, [sp, #0x30]  | stack[1152921510026665776] = ???;  stack[1152921510026665784] = ???;  //  dest_result_addr=1152921510026665776 |  dest_result_addr=1152921510026665784
            // 0x028F7A00: STP x29, x30, [sp, #0x40]  | stack[1152921510026665792] = ???;  stack[1152921510026665800] = ???;  //  dest_result_addr=1152921510026665792 |  dest_result_addr=1152921510026665800
            // 0x028F7A04: ADD x29, sp, #0x40         | X29 = (1152921510026665728 + 64) = 1152921510026665792 (0x10000001430BDF40);
            // 0x028F7A08: SUB sp, sp, #0x10          | SP = (1152921510026665728 - 16) = 1152921510026665712 (0x10000001430BDEF0);
            // 0x028F7A0C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F7A10: LDRB w8, [x19, #0xa4d]     | W8 = (bool)static_value_037B8A4D;       
            // 0x028F7A14: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F7A18: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F7A1C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F7A20: TBNZ w8, #0, #0x28f7a3c    | if (static_value_037B8A4D == true) goto label_0;
            // 0x028F7A24: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x028F7A28: LDR x8, [x8, #0x598]       | X8 = 0x2B8A65C;                         
            // 0x028F7A2C: LDR w0, [x8]               | W0 = 0x55;                              
            // 0x028F7A30: BL #0x2782188              | X0 = sub_2782188( ?? 0x55, ????);       
            // 0x028F7A34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F7A38: STRB w8, [x19, #0xa4d]     | static_value_037B8A4D = true;            //  dest_result_addr=58427981
            label_0:
            // 0x028F7A3C: CBNZ x20, #0x28f7a44       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F7A40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x55, ????);       
            label_1:
            // 0x028F7A44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7A48: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F7A4C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F7A50: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F7A54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7A58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7A5C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F7A60: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F7A64: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F7A68: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x028F7A6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7A70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7A74: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F7A78: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F7A7C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F7A80: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F7A84: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F7A88: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F7A8C: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F7A90: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F7A94: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F7A98: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F7A9C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F7AA0: TBZ w9, #0, #0x28f7ab4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F7AA4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F7AA8: CBNZ w9, #0x28f7ab4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F7AAC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F7AB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F7AB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7AB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7ABC: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F7AC0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F7AC4: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x028F7AC8: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x028F7ACC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F7AD0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F7AD4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F7AD8: TBZ w9, #0, #0x28f7aec     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F7ADC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F7AE0: CBNZ w9, #0x28f7aec        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F7AE4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F7AE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F7AEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7AF0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F7AF4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7AF8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F7AFC: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F7B00: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F7B04: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F7B08: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F7B0C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F7B10: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F7B14: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F7B18: TBZ w9, #0, #0x28f7b2c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F7B1C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F7B20: CBNZ w9, #0x28f7b2c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F7B24: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F7B28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F7B2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7B30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7B34: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F7B38: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F7B3C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F7B40: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x028F7B44: CBZ x0, #0x28f7ba8         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F7B48: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F7B4C: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F7B50: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F7B54: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F7B58: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F7B5C: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F7B60: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F7B64: B.LO #0x28f7b80            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F7B68: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F7B6C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F7B70: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F7B74: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F7B78: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x028F7B7C: B.EQ #0x28f7ba8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F7B80: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F7B84: ADD x8, sp, #8             | X8 = (1152921510026665712 + 8) = 1152921510026665720 (0x10000001430BDEF8);
            // 0x028F7B88: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F7B8C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510026653808]
            // 0x028F7B90: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F7B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7B98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F7B9C: ADD x0, sp, #8             | X0 = (1152921510026665712 + 8) = 1152921510026665720 (0x10000001430BDEF8);
            // 0x028F7BA0: BL #0x299a140              | 
            // 0x028F7BA4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x028F7BA8: CBNZ x20, #0x28f7bb0       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F7BAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001430BDEF8, ????);
            label_11:
            // 0x028F7BB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7BB4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F7BB8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7BBC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F7BC0: CBNZ x22, #0x28f7bc8       | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x028F7BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F7BC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7BCC: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F7BD0: BL #0xb19b00               | X0 = val_11.get_WriteProgress();        
            float val_9 = val_11.WriteProgress;
            // 0x028F7BD4: CBZ x19, #0x28f7c34        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x028F7BD8: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x028F7BDC: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x028F7BE0: STR s0, [x19, #4]          | mem2[0] = val_9;                         //  dest_result_addr=0
            mem2[0] = val_9;
            // 0x028F7BE4: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F7BE8: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x028F7BEC: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028F7BF0: TBZ w9, #0, #0x28f7c00     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x028F7BF4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028F7BF8: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028F7BFC: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x028F7C00: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x028F7C04: SUB sp, x29, #0x40         | SP = (1152921510026665792 - 64) = 1152921510026665728 (0x10000001430BDF00);
            // 0x028F7C08: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F7C0C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F7C10: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F7C14: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F7C18: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F7C1C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F7C20: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x028F7C24: ADD x0, sp, #8             | X0 = (1152921510026665808 + 8) = 1152921510026665816 (0x10000001430BDF58);
            // 0x028F7C28: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001430BDF58); //ERROR_TYPE
            // 0x028F7C2C: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x028F7C30: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x028F7C34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x028F7C38: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F7C3C (42957884), len: 612  VirtAddr: 0x028F7C3C RVA: 0x028F7C3C token: 100663644 methodIndex: 29689 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_isPkged_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x028F7C3C: STP x26, x25, [sp, #-0x50]! | stack[1152921510026835072] = ???;  stack[1152921510026835080] = ???;  //  dest_result_addr=1152921510026835072 |  dest_result_addr=1152921510026835080
            // 0x028F7C40: STP x24, x23, [sp, #0x10]  | stack[1152921510026835088] = ???;  stack[1152921510026835096] = ???;  //  dest_result_addr=1152921510026835088 |  dest_result_addr=1152921510026835096
            // 0x028F7C44: STP x22, x21, [sp, #0x20]  | stack[1152921510026835104] = ???;  stack[1152921510026835112] = ???;  //  dest_result_addr=1152921510026835104 |  dest_result_addr=1152921510026835112
            // 0x028F7C48: STP x20, x19, [sp, #0x30]  | stack[1152921510026835120] = ???;  stack[1152921510026835128] = ???;  //  dest_result_addr=1152921510026835120 |  dest_result_addr=1152921510026835128
            // 0x028F7C4C: STP x29, x30, [sp, #0x40]  | stack[1152921510026835136] = ???;  stack[1152921510026835144] = ???;  //  dest_result_addr=1152921510026835136 |  dest_result_addr=1152921510026835144
            // 0x028F7C50: ADD x29, sp, #0x40         | X29 = (1152921510026835072 + 64) = 1152921510026835136 (0x10000001430E74C0);
            // 0x028F7C54: SUB sp, sp, #0x10          | SP = (1152921510026835072 - 16) = 1152921510026835056 (0x10000001430E7470);
            // 0x028F7C58: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F7C5C: LDRB w8, [x19, #0xa4e]     | W8 = (bool)static_value_037B8A4E;       
            // 0x028F7C60: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F7C64: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F7C68: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F7C6C: TBNZ w8, #0, #0x28f7c88    | if (static_value_037B8A4E == true) goto label_0;
            // 0x028F7C70: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x028F7C74: LDR x8, [x8, #0x8f0]       | X8 = 0x2B8A634;                         
            // 0x028F7C78: LDR w0, [x8]               | W0 = 0x4B;                              
            // 0x028F7C7C: BL #0x2782188              | X0 = sub_2782188( ?? 0x4B, ????);       
            // 0x028F7C80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F7C84: STRB w8, [x19, #0xa4e]     | static_value_037B8A4E = true;            //  dest_result_addr=58427982
            label_0:
            // 0x028F7C88: CBNZ x20, #0x28f7c90       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F7C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x4B, ????);       
            label_1:
            // 0x028F7C90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7C94: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F7C98: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F7C9C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F7CA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7CA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7CA8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F7CAC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F7CB0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F7CB4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x028F7CB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7CBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7CC0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F7CC4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F7CC8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F7CCC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F7CD0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F7CD4: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F7CD8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F7CDC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F7CE0: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F7CE4: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F7CE8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F7CEC: TBZ w9, #0, #0x28f7d00     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F7CF0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F7CF4: CBNZ w9, #0x28f7d00        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F7CF8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F7CFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F7D00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7D04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7D08: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F7D0C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F7D10: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x028F7D14: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x028F7D18: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F7D1C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F7D20: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F7D24: TBZ w9, #0, #0x28f7d38     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F7D28: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F7D2C: CBNZ w9, #0x28f7d38        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F7D30: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F7D34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F7D38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7D3C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F7D40: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7D44: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F7D48: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F7D4C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F7D50: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F7D54: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F7D58: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F7D5C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F7D60: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F7D64: TBZ w9, #0, #0x28f7d78     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F7D68: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F7D6C: CBNZ w9, #0x28f7d78        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F7D70: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F7D74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F7D78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7D7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7D80: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F7D84: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F7D88: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F7D8C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x028F7D90: CBZ x0, #0x28f7df4         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F7D94: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F7D98: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F7D9C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F7DA0: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F7DA4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F7DA8: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F7DAC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F7DB0: B.LO #0x28f7dcc            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F7DB4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F7DB8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F7DBC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F7DC0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F7DC4: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x028F7DC8: B.EQ #0x28f7df4            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F7DCC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F7DD0: ADD x8, sp, #8             | X8 = (1152921510026835056 + 8) = 1152921510026835064 (0x10000001430E7478);
            // 0x028F7DD4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F7DD8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510026823152]
            // 0x028F7DDC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F7DE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7DE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F7DE8: ADD x0, sp, #8             | X0 = (1152921510026835056 + 8) = 1152921510026835064 (0x10000001430E7478);
            // 0x028F7DEC: BL #0x299a140              | 
            // 0x028F7DF0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x028F7DF4: CBNZ x20, #0x28f7dfc       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F7DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001430E7478, ????);
            label_11:
            // 0x028F7DFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7E00: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F7E04: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7E08: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F7E0C: CBNZ x22, #0x28f7e14       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x028F7E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F7E14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7E18: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F7E1C: BL #0xb19b6c               | X0 = val_13.get_isPkged();              
            bool val_9 = val_13.isPkged;
            // 0x028F7E20: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x028F7E24: CBZ x19, #0x28f7e38        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x028F7E28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F7E2C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028F7E30: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028F7E34: B #0x28f7e4c               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028F7E38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x028F7E3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F7E40: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028F7E44: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028F7E48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x028F7E4C: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x028F7E50: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F7E54: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x028F7E58: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028F7E5C: TBZ w9, #0, #0x28f7e6c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x028F7E60: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028F7E64: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028F7E68: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x028F7E6C: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x028F7E70: SUB sp, x29, #0x40         | SP = (1152921510026835136 - 64) = 1152921510026835072 (0x10000001430E7480);
            // 0x028F7E74: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F7E78: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F7E7C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F7E80: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F7E84: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F7E88: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F7E8C: MOV x19, x0                | 
            // 0x028F7E90: ADD x0, sp, #8             | 
            // 0x028F7E94: BL #0x299a140              | 
            // 0x028F7E98: MOV x0, x19                | 
            // 0x028F7E9C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F7EA0 (42958496), len: 588  VirtAddr: 0x028F7EA0 RVA: 0x028F7EA0 token: 100663645 methodIndex: 29690 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_PkgProgress_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x028F7EA0: STP x26, x25, [sp, #-0x50]! | stack[1152921510027004416] = ???;  stack[1152921510027004424] = ???;  //  dest_result_addr=1152921510027004416 |  dest_result_addr=1152921510027004424
            // 0x028F7EA4: STP x24, x23, [sp, #0x10]  | stack[1152921510027004432] = ???;  stack[1152921510027004440] = ???;  //  dest_result_addr=1152921510027004432 |  dest_result_addr=1152921510027004440
            // 0x028F7EA8: STP x22, x21, [sp, #0x20]  | stack[1152921510027004448] = ???;  stack[1152921510027004456] = ???;  //  dest_result_addr=1152921510027004448 |  dest_result_addr=1152921510027004456
            // 0x028F7EAC: STP x20, x19, [sp, #0x30]  | stack[1152921510027004464] = ???;  stack[1152921510027004472] = ???;  //  dest_result_addr=1152921510027004464 |  dest_result_addr=1152921510027004472
            // 0x028F7EB0: STP x29, x30, [sp, #0x40]  | stack[1152921510027004480] = ???;  stack[1152921510027004488] = ???;  //  dest_result_addr=1152921510027004480 |  dest_result_addr=1152921510027004488
            // 0x028F7EB4: ADD x29, sp, #0x40         | X29 = (1152921510027004416 + 64) = 1152921510027004480 (0x1000000143110A40);
            // 0x028F7EB8: SUB sp, sp, #0x10          | SP = (1152921510027004416 - 16) = 1152921510027004400 (0x10000001431109F0);
            // 0x028F7EBC: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F7EC0: LDRB w8, [x19, #0xa4f]     | W8 = (bool)static_value_037B8A4F;       
            // 0x028F7EC4: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F7EC8: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F7ECC: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F7ED0: TBNZ w8, #0, #0x28f7eec    | if (static_value_037B8A4F == true) goto label_0;
            // 0x028F7ED4: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x028F7ED8: LDR x8, [x8, #0x80]        | X8 = 0x2B8A640;                         
            // 0x028F7EDC: LDR w0, [x8]               | W0 = 0x4E;                              
            // 0x028F7EE0: BL #0x2782188              | X0 = sub_2782188( ?? 0x4E, ????);       
            // 0x028F7EE4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F7EE8: STRB w8, [x19, #0xa4f]     | static_value_037B8A4F = true;            //  dest_result_addr=58427983
            label_0:
            // 0x028F7EEC: CBNZ x20, #0x28f7ef4       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F7EF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x4E, ????);       
            label_1:
            // 0x028F7EF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F7EF8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F7EFC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F7F00: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F7F04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7F08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7F0C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F7F10: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F7F14: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F7F18: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x028F7F1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7F20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7F24: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F7F28: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F7F2C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F7F30: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F7F34: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F7F38: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F7F3C: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F7F40: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F7F44: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F7F48: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F7F4C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F7F50: TBZ w9, #0, #0x28f7f64     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F7F54: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F7F58: CBNZ w9, #0x28f7f64        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F7F5C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F7F60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F7F64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7F68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F7F6C: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F7F70: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F7F74: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x028F7F78: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x028F7F7C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F7F80: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F7F84: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F7F88: TBZ w9, #0, #0x28f7f9c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F7F8C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F7F90: CBNZ w9, #0x28f7f9c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F7F94: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F7F98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F7F9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7FA0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F7FA4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F7FA8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F7FAC: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F7FB0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F7FB4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F7FB8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F7FBC: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F7FC0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F7FC4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F7FC8: TBZ w9, #0, #0x28f7fdc     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F7FCC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F7FD0: CBNZ w9, #0x28f7fdc        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F7FD4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F7FD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F7FDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F7FE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F7FE4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F7FE8: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F7FEC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F7FF0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x028F7FF4: CBZ x0, #0x28f8058         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F7FF8: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F7FFC: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F8000: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F8004: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F8008: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F800C: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8010: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F8014: B.LO #0x28f8030            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F8018: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F801C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F8020: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F8024: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F8028: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x028F802C: B.EQ #0x28f8058            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F8030: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F8034: ADD x8, sp, #8             | X8 = (1152921510027004400 + 8) = 1152921510027004408 (0x10000001431109F8);
            // 0x028F8038: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F803C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510026992496]
            // 0x028F8040: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F8044: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8048: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F804C: ADD x0, sp, #8             | X0 = (1152921510027004400 + 8) = 1152921510027004408 (0x10000001431109F8);
            // 0x028F8050: BL #0x299a140              | 
            // 0x028F8054: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x028F8058: CBNZ x20, #0x28f8060       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F805C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001431109F8, ????);
            label_11:
            // 0x028F8060: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8064: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F8068: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F806C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F8070: CBNZ x22, #0x28f8078       | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x028F8074: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F8078: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F807C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F8080: BL #0xb19b74               | X0 = val_11.get_PkgProgress();          
            float val_9 = val_11.PkgProgress;
            // 0x028F8084: CBZ x19, #0x28f80e4        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x028F8088: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x028F808C: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x028F8090: STR s0, [x19, #4]          | mem2[0] = val_9;                         //  dest_result_addr=0
            mem2[0] = val_9;
            // 0x028F8094: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F8098: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x028F809C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028F80A0: TBZ w9, #0, #0x28f80b0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x028F80A4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028F80A8: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028F80AC: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x028F80B0: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x028F80B4: SUB sp, x29, #0x40         | SP = (1152921510027004480 - 64) = 1152921510027004416 (0x1000000143110A00);
            // 0x028F80B8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F80BC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F80C0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F80C4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F80C8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F80CC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F80D0: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x028F80D4: ADD x0, sp, #8             | X0 = (1152921510027004496 + 8) = 1152921510027004504 (0x1000000143110A58);
            // 0x028F80D8: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000143110A58); //ERROR_TYPE
            // 0x028F80DC: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x028F80E0: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x028F80E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x028F80E8: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F80EC (42959084), len: 612  VirtAddr: 0x028F80EC RVA: 0x028F80EC token: 100663646 methodIndex: 29691 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_isVerifyed_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x028F80EC: STP x26, x25, [sp, #-0x50]! | stack[1152921510027173760] = ???;  stack[1152921510027173768] = ???;  //  dest_result_addr=1152921510027173760 |  dest_result_addr=1152921510027173768
            // 0x028F80F0: STP x24, x23, [sp, #0x10]  | stack[1152921510027173776] = ???;  stack[1152921510027173784] = ???;  //  dest_result_addr=1152921510027173776 |  dest_result_addr=1152921510027173784
            // 0x028F80F4: STP x22, x21, [sp, #0x20]  | stack[1152921510027173792] = ???;  stack[1152921510027173800] = ???;  //  dest_result_addr=1152921510027173792 |  dest_result_addr=1152921510027173800
            // 0x028F80F8: STP x20, x19, [sp, #0x30]  | stack[1152921510027173808] = ???;  stack[1152921510027173816] = ???;  //  dest_result_addr=1152921510027173808 |  dest_result_addr=1152921510027173816
            // 0x028F80FC: STP x29, x30, [sp, #0x40]  | stack[1152921510027173824] = ???;  stack[1152921510027173832] = ???;  //  dest_result_addr=1152921510027173824 |  dest_result_addr=1152921510027173832
            // 0x028F8100: ADD x29, sp, #0x40         | X29 = (1152921510027173760 + 64) = 1152921510027173824 (0x1000000143139FC0);
            // 0x028F8104: SUB sp, sp, #0x10          | SP = (1152921510027173760 - 16) = 1152921510027173744 (0x1000000143139F70);
            // 0x028F8108: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F810C: LDRB w8, [x19, #0xa50]     | W8 = (bool)static_value_037B8A50;       
            // 0x028F8110: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F8114: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F8118: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F811C: TBNZ w8, #0, #0x28f8138    | if (static_value_037B8A50 == true) goto label_0;
            // 0x028F8120: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x028F8124: LDR x8, [x8, #0xbd8]       | X8 = 0x2B8A63C;                         
            // 0x028F8128: LDR w0, [x8]               | W0 = 0x4D;                              
            // 0x028F812C: BL #0x2782188              | X0 = sub_2782188( ?? 0x4D, ????);       
            // 0x028F8130: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F8134: STRB w8, [x19, #0xa50]     | static_value_037B8A50 = true;            //  dest_result_addr=58427984
            label_0:
            // 0x028F8138: CBNZ x20, #0x28f8140       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F813C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x4D, ????);       
            label_1:
            // 0x028F8140: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8144: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F8148: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F814C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F8150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8154: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8158: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F815C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F8160: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8164: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x028F8168: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F816C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8170: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F8174: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F8178: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F817C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F8180: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F8184: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F8188: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F818C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F8190: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F8194: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F8198: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F819C: TBZ w9, #0, #0x28f81b0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F81A0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F81A4: CBNZ w9, #0x28f81b0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F81A8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F81AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F81B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F81B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F81B8: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F81BC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F81C0: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x028F81C4: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x028F81C8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F81CC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F81D0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F81D4: TBZ w9, #0, #0x28f81e8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F81D8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F81DC: CBNZ w9, #0x28f81e8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F81E0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F81E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F81E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F81EC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F81F0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F81F4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F81F8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F81FC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F8200: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F8204: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F8208: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F820C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F8210: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F8214: TBZ w9, #0, #0x28f8228     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F8218: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F821C: CBNZ w9, #0x28f8228        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F8220: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F8224: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F8228: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F822C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8230: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F8234: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F8238: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F823C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x028F8240: CBZ x0, #0x28f82a4         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F8244: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F8248: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F824C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F8250: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F8254: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8258: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F825C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F8260: B.LO #0x28f827c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F8264: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F8268: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F826C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F8270: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F8274: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x028F8278: B.EQ #0x28f82a4            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F827C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F8280: ADD x8, sp, #8             | X8 = (1152921510027173744 + 8) = 1152921510027173752 (0x1000000143139F78);
            // 0x028F8284: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F8288: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510027161840]
            // 0x028F828C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F8290: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8294: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F8298: ADD x0, sp, #8             | X0 = (1152921510027173744 + 8) = 1152921510027173752 (0x1000000143139F78);
            // 0x028F829C: BL #0x299a140              | 
            // 0x028F82A0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x028F82A4: CBNZ x20, #0x28f82ac       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F82A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143139F78, ????);
            label_11:
            // 0x028F82AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F82B0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F82B4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F82B8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F82BC: CBNZ x22, #0x28f82c4       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x028F82C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F82C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F82C8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F82CC: BL #0xb19b8c               | X0 = val_13.get_isVerifyed();           
            bool val_9 = val_13.isVerifyed;
            // 0x028F82D0: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x028F82D4: CBZ x19, #0x28f82e8        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x028F82D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F82DC: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028F82E0: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028F82E4: B #0x28f82fc               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028F82E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x028F82EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F82F0: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028F82F4: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028F82F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x028F82FC: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x028F8300: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F8304: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x028F8308: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028F830C: TBZ w9, #0, #0x28f831c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x028F8310: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028F8314: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028F8318: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x028F831C: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x028F8320: SUB sp, x29, #0x40         | SP = (1152921510027173824 - 64) = 1152921510027173760 (0x1000000143139F80);
            // 0x028F8324: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F8328: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F832C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F8330: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F8334: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F8338: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F833C: MOV x19, x0                | 
            // 0x028F8340: ADD x0, sp, #8             | 
            // 0x028F8344: BL #0x299a140              | 
            // 0x028F8348: MOV x0, x19                | 
            // 0x028F834C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F8350 (42959696), len: 588  VirtAddr: 0x028F8350 RVA: 0x028F8350 token: 100663647 methodIndex: 29692 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_VerifyProgress_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x028F8350: STP x26, x25, [sp, #-0x50]! | stack[1152921510027343104] = ???;  stack[1152921510027343112] = ???;  //  dest_result_addr=1152921510027343104 |  dest_result_addr=1152921510027343112
            // 0x028F8354: STP x24, x23, [sp, #0x10]  | stack[1152921510027343120] = ???;  stack[1152921510027343128] = ???;  //  dest_result_addr=1152921510027343120 |  dest_result_addr=1152921510027343128
            // 0x028F8358: STP x22, x21, [sp, #0x20]  | stack[1152921510027343136] = ???;  stack[1152921510027343144] = ???;  //  dest_result_addr=1152921510027343136 |  dest_result_addr=1152921510027343144
            // 0x028F835C: STP x20, x19, [sp, #0x30]  | stack[1152921510027343152] = ???;  stack[1152921510027343160] = ???;  //  dest_result_addr=1152921510027343152 |  dest_result_addr=1152921510027343160
            // 0x028F8360: STP x29, x30, [sp, #0x40]  | stack[1152921510027343168] = ???;  stack[1152921510027343176] = ???;  //  dest_result_addr=1152921510027343168 |  dest_result_addr=1152921510027343176
            // 0x028F8364: ADD x29, sp, #0x40         | X29 = (1152921510027343104 + 64) = 1152921510027343168 (0x1000000143163540);
            // 0x028F8368: SUB sp, sp, #0x10          | SP = (1152921510027343104 - 16) = 1152921510027343088 (0x10000001431634F0);
            // 0x028F836C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F8370: LDRB w8, [x19, #0xa51]     | W8 = (bool)static_value_037B8A51;       
            // 0x028F8374: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F8378: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F837C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F8380: TBNZ w8, #0, #0x28f839c    | if (static_value_037B8A51 == true) goto label_0;
            // 0x028F8384: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x028F8388: LDR x8, [x8, #0xc28]       | X8 = 0x2B8A654;                         
            // 0x028F838C: LDR w0, [x8]               | W0 = 0x53;                              
            // 0x028F8390: BL #0x2782188              | X0 = sub_2782188( ?? 0x53, ????);       
            // 0x028F8394: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F8398: STRB w8, [x19, #0xa51]     | static_value_037B8A51 = true;            //  dest_result_addr=58427985
            label_0:
            // 0x028F839C: CBNZ x20, #0x28f83a4       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F83A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x53, ????);       
            label_1:
            // 0x028F83A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F83A8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F83AC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F83B0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F83B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F83B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F83BC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F83C0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F83C4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F83C8: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x028F83CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F83D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F83D4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F83D8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F83DC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F83E0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F83E4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F83E8: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F83EC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F83F0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F83F4: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F83F8: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F83FC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F8400: TBZ w9, #0, #0x28f8414     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F8404: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F8408: CBNZ w9, #0x28f8414        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F840C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F8410: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F8414: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8418: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F841C: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F8420: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F8424: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x028F8428: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x028F842C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F8430: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F8434: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F8438: TBZ w9, #0, #0x28f844c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F843C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F8440: CBNZ w9, #0x28f844c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F8444: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F8448: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F844C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8450: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F8454: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F8458: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F845C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F8460: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F8464: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F8468: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F846C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F8470: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F8474: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F8478: TBZ w9, #0, #0x28f848c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F847C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F8480: CBNZ w9, #0x28f848c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F8484: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F8488: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F848C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8490: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8494: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F8498: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F849C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F84A0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x028F84A4: CBZ x0, #0x28f8508         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F84A8: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F84AC: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F84B0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F84B4: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F84B8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F84BC: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F84C0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F84C4: B.LO #0x28f84e0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F84C8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F84CC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F84D0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F84D4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F84D8: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x028F84DC: B.EQ #0x28f8508            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F84E0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F84E4: ADD x8, sp, #8             | X8 = (1152921510027343088 + 8) = 1152921510027343096 (0x10000001431634F8);
            // 0x028F84E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F84EC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510027331184]
            // 0x028F84F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F84F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F84F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F84FC: ADD x0, sp, #8             | X0 = (1152921510027343088 + 8) = 1152921510027343096 (0x10000001431634F8);
            // 0x028F8500: BL #0x299a140              | 
            // 0x028F8504: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x028F8508: CBNZ x20, #0x28f8510       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F850C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001431634F8, ????);
            label_11:
            // 0x028F8510: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8514: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F8518: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F851C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F8520: CBNZ x22, #0x28f8528       | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x028F8524: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F8528: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F852C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F8530: BL #0xb19b94               | X0 = val_11.get_VerifyProgress();       
            float val_9 = val_11.VerifyProgress;
            // 0x028F8534: CBZ x19, #0x28f8594        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x028F8538: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x028F853C: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x028F8540: STR s0, [x19, #4]          | mem2[0] = val_9;                         //  dest_result_addr=0
            mem2[0] = val_9;
            // 0x028F8544: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F8548: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x028F854C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028F8550: TBZ w9, #0, #0x28f8560     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x028F8554: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028F8558: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028F855C: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x028F8560: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x028F8564: SUB sp, x29, #0x40         | SP = (1152921510027343168 - 64) = 1152921510027343104 (0x1000000143163500);
            // 0x028F8568: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F856C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F8570: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F8574: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F8578: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F857C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F8580: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x028F8584: ADD x0, sp, #8             | X0 = (1152921510027343184 + 8) = 1152921510027343192 (0x1000000143163558);
            // 0x028F8588: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000143163558); //ERROR_TYPE
            // 0x028F858C: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x028F8590: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x028F8594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x028F8598: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F859C (42960284), len: 612  VirtAddr: 0x028F859C RVA: 0x028F859C token: 100663648 methodIndex: 29693 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_isStartDown_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x028F859C: STP x26, x25, [sp, #-0x50]! | stack[1152921510027512448] = ???;  stack[1152921510027512456] = ???;  //  dest_result_addr=1152921510027512448 |  dest_result_addr=1152921510027512456
            // 0x028F85A0: STP x24, x23, [sp, #0x10]  | stack[1152921510027512464] = ???;  stack[1152921510027512472] = ???;  //  dest_result_addr=1152921510027512464 |  dest_result_addr=1152921510027512472
            // 0x028F85A4: STP x22, x21, [sp, #0x20]  | stack[1152921510027512480] = ???;  stack[1152921510027512488] = ???;  //  dest_result_addr=1152921510027512480 |  dest_result_addr=1152921510027512488
            // 0x028F85A8: STP x20, x19, [sp, #0x30]  | stack[1152921510027512496] = ???;  stack[1152921510027512504] = ???;  //  dest_result_addr=1152921510027512496 |  dest_result_addr=1152921510027512504
            // 0x028F85AC: STP x29, x30, [sp, #0x40]  | stack[1152921510027512512] = ???;  stack[1152921510027512520] = ???;  //  dest_result_addr=1152921510027512512 |  dest_result_addr=1152921510027512520
            // 0x028F85B0: ADD x29, sp, #0x40         | X29 = (1152921510027512448 + 64) = 1152921510027512512 (0x100000014318CAC0);
            // 0x028F85B4: SUB sp, sp, #0x10          | SP = (1152921510027512448 - 16) = 1152921510027512432 (0x100000014318CA70);
            // 0x028F85B8: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F85BC: LDRB w8, [x19, #0xa52]     | W8 = (bool)static_value_037B8A52;       
            // 0x028F85C0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F85C4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F85C8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F85CC: TBNZ w8, #0, #0x28f85e8    | if (static_value_037B8A52 == true) goto label_0;
            // 0x028F85D0: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x028F85D4: LDR x8, [x8, #0x180]       | X8 = 0x2B8A638;                         
            // 0x028F85D8: LDR w0, [x8]               | W0 = 0x4C;                              
            // 0x028F85DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x4C, ????);       
            // 0x028F85E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F85E4: STRB w8, [x19, #0xa52]     | static_value_037B8A52 = true;            //  dest_result_addr=58427986
            label_0:
            // 0x028F85E8: CBNZ x20, #0x28f85f0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F85EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x4C, ????);       
            label_1:
            // 0x028F85F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F85F4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F85F8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F85FC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F8600: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8604: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8608: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F860C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F8610: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8614: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x028F8618: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F861C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8620: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F8624: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F8628: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F862C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F8630: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F8634: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F8638: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F863C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F8640: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F8644: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F8648: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F864C: TBZ w9, #0, #0x28f8660     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F8650: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F8654: CBNZ w9, #0x28f8660        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F8658: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F865C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F8660: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8664: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8668: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F866C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F8670: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x028F8674: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x028F8678: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F867C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F8680: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F8684: TBZ w9, #0, #0x28f8698     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F8688: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F868C: CBNZ w9, #0x28f8698        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F8690: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F8694: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F8698: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F869C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F86A0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F86A4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F86A8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F86AC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F86B0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F86B4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F86B8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F86BC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F86C0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F86C4: TBZ w9, #0, #0x28f86d8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F86C8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F86CC: CBNZ w9, #0x28f86d8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F86D0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F86D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F86D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F86DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F86E0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F86E4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F86E8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F86EC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x028F86F0: CBZ x0, #0x28f8754         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F86F4: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F86F8: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F86FC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F8700: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F8704: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8708: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F870C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F8710: B.LO #0x28f872c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F8714: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F8718: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F871C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F8720: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F8724: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x028F8728: B.EQ #0x28f8754            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F872C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F8730: ADD x8, sp, #8             | X8 = (1152921510027512432 + 8) = 1152921510027512440 (0x100000014318CA78);
            // 0x028F8734: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F8738: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510027500528]
            // 0x028F873C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F8740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8744: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F8748: ADD x0, sp, #8             | X0 = (1152921510027512432 + 8) = 1152921510027512440 (0x100000014318CA78);
            // 0x028F874C: BL #0x299a140              | 
            // 0x028F8750: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x028F8754: CBNZ x20, #0x28f875c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F8758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014318CA78, ????);
            label_11:
            // 0x028F875C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8760: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F8764: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F8768: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F876C: CBNZ x22, #0x28f8774       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x028F8770: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F8774: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8778: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F877C: BL #0xb19b9c               | X0 = val_13.get_isStartDown();          
            bool val_9 = val_13.isStartDown;
            // 0x028F8780: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x028F8784: CBZ x19, #0x28f8798        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x028F8788: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F878C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028F8790: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028F8794: B #0x28f87ac               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028F8798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x028F879C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F87A0: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028F87A4: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028F87A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x028F87AC: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x028F87B0: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F87B4: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x028F87B8: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028F87BC: TBZ w9, #0, #0x28f87cc     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x028F87C0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028F87C4: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028F87C8: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x028F87CC: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x028F87D0: SUB sp, x29, #0x40         | SP = (1152921510027512512 - 64) = 1152921510027512448 (0x100000014318CA80);
            // 0x028F87D4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F87D8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F87DC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F87E0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F87E4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F87E8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F87EC: MOV x19, x0                | 
            // 0x028F87F0: ADD x0, sp, #8             | 
            // 0x028F87F4: BL #0x299a140              | 
            // 0x028F87F8: MOV x0, x19                | 
            // 0x028F87FC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F8800 (42960896), len: 588  VirtAddr: 0x028F8800 RVA: 0x028F8800 token: 100663649 methodIndex: 29694 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_Progress_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x028F8800: STP x26, x25, [sp, #-0x50]! | stack[1152921510027681792] = ???;  stack[1152921510027681800] = ???;  //  dest_result_addr=1152921510027681792 |  dest_result_addr=1152921510027681800
            // 0x028F8804: STP x24, x23, [sp, #0x10]  | stack[1152921510027681808] = ???;  stack[1152921510027681816] = ???;  //  dest_result_addr=1152921510027681808 |  dest_result_addr=1152921510027681816
            // 0x028F8808: STP x22, x21, [sp, #0x20]  | stack[1152921510027681824] = ???;  stack[1152921510027681832] = ???;  //  dest_result_addr=1152921510027681824 |  dest_result_addr=1152921510027681832
            // 0x028F880C: STP x20, x19, [sp, #0x30]  | stack[1152921510027681840] = ???;  stack[1152921510027681848] = ???;  //  dest_result_addr=1152921510027681840 |  dest_result_addr=1152921510027681848
            // 0x028F8810: STP x29, x30, [sp, #0x40]  | stack[1152921510027681856] = ???;  stack[1152921510027681864] = ???;  //  dest_result_addr=1152921510027681856 |  dest_result_addr=1152921510027681864
            // 0x028F8814: ADD x29, sp, #0x40         | X29 = (1152921510027681792 + 64) = 1152921510027681856 (0x10000001431B6040);
            // 0x028F8818: SUB sp, sp, #0x10          | SP = (1152921510027681792 - 16) = 1152921510027681776 (0x10000001431B5FF0);
            // 0x028F881C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F8820: LDRB w8, [x19, #0xa53]     | W8 = (bool)static_value_037B8A53;       
            // 0x028F8824: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028F8828: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028F882C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F8830: TBNZ w8, #0, #0x28f884c    | if (static_value_037B8A53 == true) goto label_0;
            // 0x028F8834: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x028F8838: LDR x8, [x8, #0xa8]        | X8 = 0x2B8A644;                         
            // 0x028F883C: LDR w0, [x8]               | W0 = 0x4F;                              
            // 0x028F8840: BL #0x2782188              | X0 = sub_2782188( ?? 0x4F, ????);       
            // 0x028F8844: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F8848: STRB w8, [x19, #0xa53]     | static_value_037B8A53 = true;            //  dest_result_addr=58427987
            label_0:
            // 0x028F884C: CBNZ x20, #0x28f8854       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F8850: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x4F, ????);       
            label_1:
            // 0x028F8854: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8858: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F885C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F8860: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F8864: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8868: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F886C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F8870: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F8874: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8878: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x028F887C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8880: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8884: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F8888: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028F888C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8890: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F8894: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F8898: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F889C: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028F88A0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F88A4: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F88A8: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F88AC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F88B0: TBZ w9, #0, #0x28f88c4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F88B4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F88B8: CBNZ w9, #0x28f88c4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F88BC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F88C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F88C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F88C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F88CC: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F88D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F88D4: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x028F88D8: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x028F88DC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F88E0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F88E4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F88E8: TBZ w9, #0, #0x28f88fc     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F88EC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F88F0: CBNZ w9, #0x28f88fc        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F88F4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F88F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F88FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8900: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F8904: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F8908: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F890C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028F8910: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F8914: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F8918: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F891C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028F8920: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F8924: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F8928: TBZ w9, #0, #0x28f893c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F892C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F8930: CBNZ w9, #0x28f893c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F8934: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F8938: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F893C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8940: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8944: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F8948: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028F894C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F8950: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x028F8954: CBZ x0, #0x28f89b8         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F8958: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F895C: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F8960: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F8964: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F8968: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F896C: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8970: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F8974: B.LO #0x28f8990            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F8978: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F897C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F8980: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F8984: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F8988: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x028F898C: B.EQ #0x28f89b8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F8990: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F8994: ADD x8, sp, #8             | X8 = (1152921510027681776 + 8) = 1152921510027681784 (0x10000001431B5FF8);
            // 0x028F8998: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F899C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510027669872]
            // 0x028F89A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F89A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F89A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F89AC: ADD x0, sp, #8             | X0 = (1152921510027681776 + 8) = 1152921510027681784 (0x10000001431B5FF8);
            // 0x028F89B0: BL #0x299a140              | 
            // 0x028F89B4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x028F89B8: CBNZ x20, #0x28f89c0       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F89BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001431B5FF8, ????);
            label_11:
            // 0x028F89C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F89C4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F89C8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028F89CC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F89D0: CBNZ x22, #0x28f89d8       | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x028F89D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F89D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F89DC: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028F89E0: BL #0xb19ba4               | X0 = val_11.get_Progress();             
            float val_9 = val_11.Progress;
            // 0x028F89E4: CBZ x19, #0x28f8a44        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x028F89E8: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x028F89EC: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x028F89F0: STR s0, [x19, #4]          | mem2[0] = val_9;                         //  dest_result_addr=0
            mem2[0] = val_9;
            // 0x028F89F4: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F89F8: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x028F89FC: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028F8A00: TBZ w9, #0, #0x28f8a10     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x028F8A04: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028F8A08: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028F8A0C: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x028F8A10: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x028F8A14: SUB sp, x29, #0x40         | SP = (1152921510027681856 - 64) = 1152921510027681792 (0x10000001431B6000);
            // 0x028F8A18: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F8A1C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F8A20: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F8A24: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F8A28: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F8A2C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F8A30: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x028F8A34: ADD x0, sp, #8             | X0 = (1152921510027681872 + 8) = 1152921510027681880 (0x10000001431B6058);
            // 0x028F8A38: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001431B6058); //ERROR_TYPE
            // 0x028F8A3C: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x028F8A40: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x028F8A44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x028F8A48: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F8A4C (42961484), len: 552  VirtAddr: 0x028F8A4C RVA: 0x028F8A4C token: 100663650 methodIndex: 29695 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_ProgressMsg_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            // 0x028F8A4C: STP x24, x23, [sp, #-0x40]! | stack[1152921510027855248] = ???;  stack[1152921510027855256] = ???;  //  dest_result_addr=1152921510027855248 |  dest_result_addr=1152921510027855256
            // 0x028F8A50: STP x22, x21, [sp, #0x10]  | stack[1152921510027855264] = ???;  stack[1152921510027855272] = ???;  //  dest_result_addr=1152921510027855264 |  dest_result_addr=1152921510027855272
            // 0x028F8A54: STP x20, x19, [sp, #0x20]  | stack[1152921510027855280] = ???;  stack[1152921510027855288] = ???;  //  dest_result_addr=1152921510027855280 |  dest_result_addr=1152921510027855288
            // 0x028F8A58: STP x29, x30, [sp, #0x30]  | stack[1152921510027855296] = ???;  stack[1152921510027855304] = ???;  //  dest_result_addr=1152921510027855296 |  dest_result_addr=1152921510027855304
            // 0x028F8A5C: ADD x29, sp, #0x30         | X29 = (1152921510027855248 + 48) = 1152921510027855296 (0x10000001431E05C0);
            // 0x028F8A60: SUB sp, sp, #0x10          | SP = (1152921510027855248 - 16) = 1152921510027855232 (0x10000001431E0580);
            // 0x028F8A64: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F8A68: LDRB w8, [x21, #0xa54]     | W8 = (bool)static_value_037B8A54;       
            // 0x028F8A6C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028F8A70: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028F8A74: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028F8A78: TBNZ w8, #0, #0x28f8a94    | if (static_value_037B8A54 == true) goto label_0;
            // 0x028F8A7C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x028F8A80: LDR x8, [x8, #0x850]       | X8 = 0x2B8A648;                         
            // 0x028F8A84: LDR w0, [x8]               | W0 = 0x50;                              
            // 0x028F8A88: BL #0x2782188              | X0 = sub_2782188( ?? 0x50, ????);       
            // 0x028F8A8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F8A90: STRB w8, [x21, #0xa54]     | static_value_037B8A54 = true;            //  dest_result_addr=58427988
            label_0:
            // 0x028F8A94: CBNZ x20, #0x28f8a9c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F8A98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x50, ????);       
            label_1:
            // 0x028F8A9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8AA0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F8AA4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F8AA8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F8AAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8AB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8AB4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F8AB8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F8ABC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8AC0: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028F8AC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8AC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8ACC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F8AD0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F8AD4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8AD8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F8ADC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F8AE0: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x028F8AE4: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x028F8AE8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F8AEC: LDR x9, [x9, #0x120]       | X9 = 1152921504910680064;               
            // 0x028F8AF0: LDR x24, [x9]              | X24 = typeof(ABCheckUpdate);            
            // 0x028F8AF4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F8AF8: TBZ w9, #0, #0x28f8b0c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F8AFC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F8B00: CBNZ w9, #0x28f8b0c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F8B04: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F8B08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F8B0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8B10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8B14: MOV x1, x24                | X1 = 1152921504910680064 (0x10000000121C2000);//ML01
            // 0x028F8B18: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F8B1C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F8B20: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F8B24: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028F8B28: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F8B2C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F8B30: TBZ w9, #0, #0x28f8b44     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F8B34: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F8B38: CBNZ w9, #0x28f8b44        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F8B3C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F8B40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F8B44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8B48: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F8B4C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x028F8B50: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F8B54: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028F8B58: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F8B5C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F8B60: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F8B64: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x028F8B68: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F8B6C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F8B70: TBZ w9, #0, #0x28f8b84     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F8B74: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F8B78: CBNZ w9, #0x28f8b84        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F8B7C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F8B80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F8B84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8B88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8B8C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028F8B90: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x028F8B94: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F8B98: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x028F8B9C: CBZ x0, #0x28f8c00         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F8BA0: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F8BA4: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F8BA8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F8BAC: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F8BB0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8BB4: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8BB8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F8BBC: B.LO #0x28f8bd8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F8BC0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F8BC4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F8BC8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F8BCC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F8BD0: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x028F8BD4: B.EQ #0x28f8c00            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F8BD8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F8BDC: ADD x8, sp, #8             | X8 = (1152921510027855232 + 8) = 1152921510027855240 (0x10000001431E0588);
            // 0x028F8BE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F8BE4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510027843312]
            // 0x028F8BE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F8BEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8BF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F8BF4: ADD x0, sp, #8             | X0 = (1152921510027855232 + 8) = 1152921510027855240 (0x10000001431E0588);
            // 0x028F8BF8: BL #0x299a140              | 
            // 0x028F8BFC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x028F8C00: CBNZ x20, #0x28f8c08       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F8C04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001431E0588, ????);
            label_11:
            // 0x028F8C08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8C0C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028F8C10: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x028F8C14: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F8C18: CBNZ x23, #0x28f8c20       | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x028F8C1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028F8C20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8C24: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028F8C28: BL #0xb19c20               | X0 = val_11.get_ProgressMsg();          
            string val_9 = val_11.ProgressMsg;
            // 0x028F8C2C: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x028F8C30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8C34: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028F8C38: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028F8C3C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028F8C40: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F8C44: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x028F8C48: SUB sp, x29, #0x30         | SP = (1152921510027855296 - 48) = 1152921510027855248 (0x10000001431E0590);
            // 0x028F8C4C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028F8C50: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028F8C54: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028F8C58: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028F8C5C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F8C60: MOV x19, x0                | 
            // 0x028F8C64: ADD x0, sp, #8             | 
            // 0x028F8C68: BL #0x299a140              | 
            // 0x028F8C6C: MOV x0, x19                | 
            // 0x028F8C70: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F8C74 (42962036), len: 776  VirtAddr: 0x028F8C74 RVA: 0x028F8C74 token: 100663651 methodIndex: 29696 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* IsOpenRepairAsset_18(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            CEvent.ZEvent val_15;
            //  | 
            var val_16;
            // 0x028F8C74: STP x26, x25, [sp, #-0x50]! | stack[1152921510028040960] = ???;  stack[1152921510028040968] = ???;  //  dest_result_addr=1152921510028040960 |  dest_result_addr=1152921510028040968
            // 0x028F8C78: STP x24, x23, [sp, #0x10]  | stack[1152921510028040976] = ???;  stack[1152921510028040984] = ???;  //  dest_result_addr=1152921510028040976 |  dest_result_addr=1152921510028040984
            // 0x028F8C7C: STP x22, x21, [sp, #0x20]  | stack[1152921510028040992] = ???;  stack[1152921510028041000] = ???;  //  dest_result_addr=1152921510028040992 |  dest_result_addr=1152921510028041000
            // 0x028F8C80: STP x20, x19, [sp, #0x30]  | stack[1152921510028041008] = ???;  stack[1152921510028041016] = ???;  //  dest_result_addr=1152921510028041008 |  dest_result_addr=1152921510028041016
            // 0x028F8C84: STP x29, x30, [sp, #0x40]  | stack[1152921510028041024] = ???;  stack[1152921510028041032] = ???;  //  dest_result_addr=1152921510028041024 |  dest_result_addr=1152921510028041032
            // 0x028F8C88: ADD x29, sp, #0x40         | X29 = (1152921510028040960 + 64) = 1152921510028041024 (0x100000014320DB40);
            // 0x028F8C8C: SUB sp, sp, #0x10          | SP = (1152921510028040960 - 16) = 1152921510028040944 (0x100000014320DAF0);
            // 0x028F8C90: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F8C94: LDRB w8, [x20, #0xa55]     | W8 = (bool)static_value_037B8A55;       
            // 0x028F8C98: MOV x21, x3                | X21 = X3;//m1                           
            // 0x028F8C9C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028F8CA0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F8CA4: TBNZ w8, #0, #0x28f8cc0    | if (static_value_037B8A55 == true) goto label_0;
            // 0x028F8CA8: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x028F8CAC: LDR x8, [x8, #0x40]        | X8 = 0x2B8A660;                         
            // 0x028F8CB0: LDR w0, [x8]               | W0 = 0x56;                              
            // 0x028F8CB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x56, ????);       
            // 0x028F8CB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F8CBC: STRB w8, [x20, #0xa55]     | static_value_037B8A55 = true;            //  dest_result_addr=58427989
            label_0:
            // 0x028F8CC0: CBNZ x19, #0x28f8cc8       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F8CC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x56, ????);       
            label_1:
            // 0x028F8CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8CCC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F8CD0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F8CD4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F8CD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8CDC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8CE0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028F8CE4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F8CE8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8CEC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028F8CF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8CF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8CF8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F8CFC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F8D00: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8D04: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F8D08: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F8D0C: ADRP x9, #0x3615000        | X9 = 56709120 (0x3615000);              
            // 0x028F8D10: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x028F8D14: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F8D18: LDR x9, [x9, #0x668]       | X9 = 1152921504898326528;               
            // 0x028F8D1C: LDR x25, [x9]              | X25 = typeof(CEvent.ZEvent);            
            // 0x028F8D20: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F8D24: TBZ w9, #0, #0x28f8d38     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F8D28: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F8D2C: CBNZ w9, #0x28f8d38        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F8D30: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F8D34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F8D38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8D3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8D40: MOV x1, x25                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x028F8D44: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F8D48: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F8D4C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F8D50: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x028F8D54: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F8D58: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F8D5C: TBZ w9, #0, #0x28f8d70     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F8D60: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F8D64: CBNZ w9, #0x28f8d70        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F8D68: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F8D6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F8D70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8D74: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F8D78: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x028F8D7C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F8D80: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028F8D84: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F8D88: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F8D8C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F8D90: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x028F8D94: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F8D98: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F8D9C: TBZ w9, #0, #0x28f8db0     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F8DA0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F8DA4: CBNZ w9, #0x28f8db0        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F8DA8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F8DAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F8DB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8DB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8DB8: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x028F8DBC: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x028F8DC0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F8DC4: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x028F8DC8: CBZ x0, #0x28f8e2c         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F8DCC: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x028F8DD0: LDR x9, [x9, #0x440]       | X9 = 1152921504898326528;               
            // 0x028F8DD4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F8DD8: LDR x1, [x9]               | X1 = typeof(CEvent.ZEvent);             
            // 0x028F8DDC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8DE0: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8DE4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F8DE8: B.LO #0x28f8e04            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F8DEC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F8DF0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHie
            // 0x028F8DF4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F8DF8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x028F8DFC: MOV x25, x0                | X25 = val_6;//m1                        
            val_15 = val_6;
            // 0x028F8E00: B.EQ #0x28f8e2c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F8E04: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F8E08: MOV x8, sp                 | X8 = 1152921510028040944 (0x100000014320DAF0);//ML01
            // 0x028F8E0C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F8E10: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510028029040]
            // 0x028F8E14: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F8E18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8E1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F8E20: MOV x0, sp                 | X0 = 1152921510028040944 (0x100000014320DAF0);//ML01
            // 0x028F8E24: BL #0x299a140              | 
            // 0x028F8E28: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x028F8E2C: CBNZ x19, #0x28f8e34       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F8E30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014320DAF0, ????);
            label_11:
            // 0x028F8E34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8E38: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F8E3C: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x028F8E40: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F8E44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8E48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8E4C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028F8E50: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F8E54: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8E58: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x028F8E5C: LDR x8, [x8, #0x120]       | X8 = 1152921504910680064;               
            // 0x028F8E60: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x028F8E64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8E68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8E6C: LDR x1, [x8]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F8E70: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F8E74: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x028F8E78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8E7C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F8E80: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x028F8E84: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F8E88: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028F8E8C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F8E90: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x028F8E94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8E98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8E9C: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x028F8EA0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x028F8EA4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x028F8EA8: CBZ x0, #0x28f8f0c         | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x028F8EAC: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F8EB0: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F8EB4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F8EB8: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F8EBC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8EC0: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F8EC4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F8EC8: B.LO #0x28f8ee4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x028F8ECC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F8ED0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F8ED4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F8ED8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F8EDC: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x028F8EE0: B.EQ #0x28f8f0c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x028F8EE4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F8EE8: ADD x8, sp, #8             | X8 = (1152921510028040944 + 8) = 1152921510028040952 (0x100000014320DAF8);
            // 0x028F8EEC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F8EF0: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510028029040]
            // 0x028F8EF4: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x028F8EF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8EFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x028F8F00: ADD x0, sp, #8             | X0 = (1152921510028040944 + 8) = 1152921510028040952 (0x100000014320DAF8);
            // 0x028F8F04: BL #0x299a140              | 
            // 0x028F8F08: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_14:
            // 0x028F8F0C: CBNZ x19, #0x28f8f14       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x028F8F10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014320DAF8, ????);
            label_15:
            // 0x028F8F14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8F18: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F8F1C: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x028F8F20: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F8F24: CBNZ x21, #0x28f8f2c       | if (0x0 != 0) goto label_16;            
            if(val_16 != 0)
            {
                goto label_16;
            }
            // 0x028F8F28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x028F8F2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F8F30: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x028F8F34: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x028F8F38: BL #0xb19d24               | val_16.IsOpenRepairAsset(e:  val_15);   
            val_16.IsOpenRepairAsset(e:  val_15);
            // 0x028F8F3C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x028F8F40: SUB sp, x29, #0x40         | SP = (1152921510028041024 - 64) = 1152921510028040960 (0x100000014320DB00);
            // 0x028F8F44: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F8F48: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F8F4C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F8F50: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F8F54: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F8F58: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F8F5C: MOV x19, x0                | 
            // 0x028F8F60: MOV x0, sp                 | 
            // 0x028F8F64: B #0x28f8f70               | 
            // 0x028F8F68: MOV x19, x0                | 
            // 0x028F8F6C: ADD x0, sp, #8             | 
            label_17:
            // 0x028F8F70: BL #0x299a140              | 
            // 0x028F8F74: MOV x0, x19                | 
            // 0x028F8F78: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F8F7C (42962812), len: 776  VirtAddr: 0x028F8F7C RVA: 0x028F8F7C token: 100663652 methodIndex: 29697 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* RepairAsset_19(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            CEvent.ZEvent val_15;
            //  | 
            var val_16;
            // 0x028F8F7C: STP x26, x25, [sp, #-0x50]! | stack[1152921510028234880] = ???;  stack[1152921510028234888] = ???;  //  dest_result_addr=1152921510028234880 |  dest_result_addr=1152921510028234888
            // 0x028F8F80: STP x24, x23, [sp, #0x10]  | stack[1152921510028234896] = ???;  stack[1152921510028234904] = ???;  //  dest_result_addr=1152921510028234896 |  dest_result_addr=1152921510028234904
            // 0x028F8F84: STP x22, x21, [sp, #0x20]  | stack[1152921510028234912] = ???;  stack[1152921510028234920] = ???;  //  dest_result_addr=1152921510028234912 |  dest_result_addr=1152921510028234920
            // 0x028F8F88: STP x20, x19, [sp, #0x30]  | stack[1152921510028234928] = ???;  stack[1152921510028234936] = ???;  //  dest_result_addr=1152921510028234928 |  dest_result_addr=1152921510028234936
            // 0x028F8F8C: STP x29, x30, [sp, #0x40]  | stack[1152921510028234944] = ???;  stack[1152921510028234952] = ???;  //  dest_result_addr=1152921510028234944 |  dest_result_addr=1152921510028234952
            // 0x028F8F90: ADD x29, sp, #0x40         | X29 = (1152921510028234880 + 64) = 1152921510028234944 (0x100000014323D0C0);
            // 0x028F8F94: SUB sp, sp, #0x10          | SP = (1152921510028234880 - 16) = 1152921510028234864 (0x100000014323D070);
            // 0x028F8F98: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F8F9C: LDRB w8, [x20, #0xa56]     | W8 = (bool)static_value_037B8A56;       
            // 0x028F8FA0: MOV x21, x3                | X21 = X3;//m1                           
            // 0x028F8FA4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028F8FA8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F8FAC: TBNZ w8, #0, #0x28f8fc8    | if (static_value_037B8A56 == true) goto label_0;
            // 0x028F8FB0: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x028F8FB4: LDR x8, [x8, #0xe38]       | X8 = 0x2B8A668;                         
            // 0x028F8FB8: LDR w0, [x8]               | W0 = 0x58;                              
            // 0x028F8FBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x58, ????);       
            // 0x028F8FC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F8FC4: STRB w8, [x20, #0xa56]     | static_value_037B8A56 = true;            //  dest_result_addr=58427990
            label_0:
            // 0x028F8FC8: CBNZ x19, #0x28f8fd0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028F8FCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x58, ????);       
            label_1:
            // 0x028F8FD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F8FD4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F8FD8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028F8FDC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028F8FE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8FE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F8FE8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028F8FEC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F8FF0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F8FF4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028F8FF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F8FFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F9000: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F9004: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F9008: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F900C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028F9010: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028F9014: ADRP x9, #0x3615000        | X9 = 56709120 (0x3615000);              
            // 0x028F9018: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x028F901C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028F9020: LDR x9, [x9, #0x668]       | X9 = 1152921504898326528;               
            // 0x028F9024: LDR x25, [x9]              | X25 = typeof(CEvent.ZEvent);            
            // 0x028F9028: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F902C: TBZ w9, #0, #0x28f9040     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028F9030: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F9034: CBNZ w9, #0x28f9040        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028F9038: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028F903C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028F9040: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F9044: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F9048: MOV x1, x25                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x028F904C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F9050: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F9054: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028F9058: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x028F905C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028F9060: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028F9064: TBZ w9, #0, #0x28f9078     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028F9068: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028F906C: CBNZ w9, #0x28f9078        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028F9070: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028F9074: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028F9078: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F907C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F9080: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x028F9084: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F9088: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028F908C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F9090: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028F9094: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028F9098: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x028F909C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028F90A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028F90A4: TBZ w9, #0, #0x28f90b8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028F90A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028F90AC: CBNZ w9, #0x28f90b8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028F90B0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028F90B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028F90B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F90BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F90C0: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x028F90C4: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x028F90C8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028F90CC: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x028F90D0: CBZ x0, #0x28f9134         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028F90D4: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x028F90D8: LDR x9, [x9, #0x440]       | X9 = 1152921504898326528;               
            // 0x028F90DC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F90E0: LDR x1, [x9]               | X1 = typeof(CEvent.ZEvent);             
            // 0x028F90E4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F90E8: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F90EC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F90F0: B.LO #0x28f910c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028F90F4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F90F8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHie
            // 0x028F90FC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9100: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x028F9104: MOV x25, x0                | X25 = val_6;//m1                        
            val_15 = val_6;
            // 0x028F9108: B.EQ #0x28f9134            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028F910C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F9110: MOV x8, sp                 | X8 = 1152921510028234864 (0x100000014323D070);//ML01
            // 0x028F9114: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F9118: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510028222960]
            // 0x028F911C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028F9120: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9124: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028F9128: MOV x0, sp                 | X0 = 1152921510028234864 (0x100000014323D070);//ML01
            // 0x028F912C: BL #0x299a140              | 
            // 0x028F9130: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x028F9134: CBNZ x19, #0x28f913c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028F9138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014323D070, ????);
            label_11:
            // 0x028F913C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F9140: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F9144: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x028F9148: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F914C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F9150: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F9154: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028F9158: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028F915C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028F9160: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x028F9164: LDR x8, [x8, #0x120]       | X8 = 1152921504910680064;               
            // 0x028F9168: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x028F916C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F9170: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F9174: LDR x1, [x8]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F9178: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F917C: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x028F9180: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F9184: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028F9188: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x028F918C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028F9190: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028F9194: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028F9198: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x028F919C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F91A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F91A4: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x028F91A8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x028F91AC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x028F91B0: CBZ x0, #0x28f9214         | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x028F91B4: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x028F91B8: LDR x9, [x9, #0xd68]       | X9 = 1152921504910680064;               
            // 0x028F91BC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028F91C0: LDR x1, [x9]               | X1 = typeof(ABCheckUpdate);             
            // 0x028F91C4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F91C8: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F91CC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F91D0: B.LO #0x28f91ec            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x028F91D4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028F91D8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHie
            // 0x028F91DC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F91E0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F91E4: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x028F91E8: B.EQ #0x28f9214            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x028F91EC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028F91F0: ADD x8, sp, #8             | X8 = (1152921510028234864 + 8) = 1152921510028234872 (0x100000014323D078);
            // 0x028F91F4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028F91F8: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510028222960]
            // 0x028F91FC: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x028F9200: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9204: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x028F9208: ADD x0, sp, #8             | X0 = (1152921510028234864 + 8) = 1152921510028234872 (0x100000014323D078);
            // 0x028F920C: BL #0x299a140              | 
            // 0x028F9210: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_14:
            // 0x028F9214: CBNZ x19, #0x28f921c       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x028F9218: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014323D078, ????);
            label_15:
            // 0x028F921C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F9220: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F9224: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x028F9228: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028F922C: CBNZ x21, #0x28f9234       | if (0x0 != 0) goto label_16;            
            if(val_16 != 0)
            {
                goto label_16;
            }
            // 0x028F9230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x028F9234: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F9238: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x028F923C: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x028F9240: BL #0xb19db4               | val_16.RepairAsset(e:  val_15);         
            val_16.RepairAsset(e:  val_15);
            // 0x028F9244: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x028F9248: SUB sp, x29, #0x40         | SP = (1152921510028234944 - 64) = 1152921510028234880 (0x100000014323D080);
            // 0x028F924C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028F9250: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028F9254: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028F9258: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028F925C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028F9260: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028F9264: MOV x19, x0                | 
            // 0x028F9268: MOV x0, sp                 | 
            // 0x028F926C: B #0x28f9278               | 
            // 0x028F9270: MOV x19, x0                | 
            // 0x028F9274: ADD x0, sp, #8             | 
            label_17:
            // 0x028F9278: BL #0x299a140              | 
            // 0x028F927C: MOV x0, x19                | 
            // 0x028F9280: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F9284 (42963588), len: 72  VirtAddr: 0x028F9284 RVA: 0x028F9284 token: 100663653 methodIndex: 29698 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_FLOW_CHECK_UPDATE_0(ref object o)
        {
            //
            // Disasemble & Code
            // 0x028F9284: STP x20, x19, [sp, #-0x20]! | stack[1152921510028391904] = ???;  stack[1152921510028391912] = ???;  //  dest_result_addr=1152921510028391904 |  dest_result_addr=1152921510028391912
            // 0x028F9288: STP x29, x30, [sp, #0x10]  | stack[1152921510028391920] = ???;  stack[1152921510028391928] = ???;  //  dest_result_addr=1152921510028391920 |  dest_result_addr=1152921510028391928
            // 0x028F928C: ADD x29, sp, #0x10         | X29 = (1152921510028391904 + 16) = 1152921510028391920 (0x10000001432635F0);
            // 0x028F9290: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F9294: LDRB w8, [x19, #0xa57]     | W8 = (bool)static_value_037B8A57;       
            // 0x028F9298: TBNZ w8, #0, #0x28f92b4    | if (static_value_037B8A57 == true) goto label_0;
            // 0x028F929C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x028F92A0: LDR x8, [x8, #0x18]        | X8 = 0x2B8A61C;                         
            // 0x028F92A4: LDR w0, [x8]               | W0 = 0x45;                              
            // 0x028F92A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x45, ????);       
            // 0x028F92AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F92B0: STRB w8, [x19, #0xa57]     | static_value_037B8A57 = true;            //  dest_result_addr=58427991
            label_0:
            // 0x028F92B4: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x028F92B8: LDR x8, [x8, #0xb00]       | X8 = (string**)(1152921510024638640)("FLOW_CHECK_UPDATE");
            // 0x028F92BC: LDR x0, [x8]               | X0 = "FLOW_CHECK_UPDATE";               
            // 0x028F92C0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F92C4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F92C8: RET                        |  return (System.Object)"FLOW_CHECK_UPDATE";
            return (object)"FLOW_CHECK_UPDATE";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028F92CC (42963660), len: 72  VirtAddr: 0x028F92CC RVA: 0x028F92CC token: 100663654 methodIndex: 29699 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_REPAIR_ASSET_1(ref object o)
        {
            //
            // Disasemble & Code
            // 0x028F92CC: STP x20, x19, [sp, #-0x20]! | stack[1152921510028511936] = ???;  stack[1152921510028511944] = ???;  //  dest_result_addr=1152921510028511936 |  dest_result_addr=1152921510028511944
            // 0x028F92D0: STP x29, x30, [sp, #0x10]  | stack[1152921510028511952] = ???;  stack[1152921510028511960] = ???;  //  dest_result_addr=1152921510028511952 |  dest_result_addr=1152921510028511960
            // 0x028F92D4: ADD x29, sp, #0x10         | X29 = (1152921510028511936 + 16) = 1152921510028511952 (0x1000000143280AD0);
            // 0x028F92D8: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F92DC: LDRB w8, [x19, #0xa58]     | W8 = (bool)static_value_037B8A58;       
            // 0x028F92E0: TBNZ w8, #0, #0x28f92fc    | if (static_value_037B8A58 == true) goto label_0;
            // 0x028F92E4: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x028F92E8: LDR x8, [x8, #0xd00]       | X8 = 0x2B8A64C;                         
            // 0x028F92EC: LDR w0, [x8]               | W0 = 0x51;                              
            // 0x028F92F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x51, ????);       
            // 0x028F92F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F92F8: STRB w8, [x19, #0xa58]     | static_value_037B8A58 = true;            //  dest_result_addr=58427992
            label_0:
            // 0x028F92FC: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x028F9300: LDR x8, [x8, #0x9b0]       | X8 = (string**)(1152921510024639776)("REPAIR_ASSET");
            // 0x028F9304: LDR x0, [x8]               | X0 = "REPAIR_ASSET";                    
            // 0x028F9308: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F930C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F9310: RET                        |  return (System.Object)"REPAIR_ASSET";  
            return (object)"REPAIR_ASSET";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028F9314 (42963732), len: 72  VirtAddr: 0x028F9314 RVA: 0x028F9314 token: 100663655 methodIndex: 29700 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_IF_OPEN_REPAIR_ASSET_2(ref object o)
        {
            //
            // Disasemble & Code
            // 0x028F9314: STP x20, x19, [sp, #-0x20]! | stack[1152921510028631968] = ???;  stack[1152921510028631976] = ???;  //  dest_result_addr=1152921510028631968 |  dest_result_addr=1152921510028631976
            // 0x028F9318: STP x29, x30, [sp, #0x10]  | stack[1152921510028631984] = ???;  stack[1152921510028631992] = ???;  //  dest_result_addr=1152921510028631984 |  dest_result_addr=1152921510028631992
            // 0x028F931C: ADD x29, sp, #0x10         | X29 = (1152921510028631968 + 16) = 1152921510028631984 (0x100000014329DFB0);
            // 0x028F9320: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F9324: LDRB w8, [x19, #0xa59]     | W8 = (bool)static_value_037B8A59;       
            // 0x028F9328: TBNZ w8, #0, #0x28f9344    | if (static_value_037B8A59 == true) goto label_0;
            // 0x028F932C: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x028F9330: LDR x8, [x8, #0xa50]       | X8 = 0x2B8A624;                         
            // 0x028F9334: LDR w0, [x8]               | W0 = 0x47;                              
            // 0x028F9338: BL #0x2782188              | X0 = sub_2782188( ?? 0x47, ????);       
            // 0x028F933C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F9340: STRB w8, [x19, #0xa59]     | static_value_037B8A59 = true;            //  dest_result_addr=58427993
            label_0:
            // 0x028F9344: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x028F9348: LDR x8, [x8, #0x28]        | X8 = (string**)(1152921510024640896)("IF_OPEN_REPAIR_ASSET");
            // 0x028F934C: LDR x0, [x8]               | X0 = "IF_OPEN_REPAIR_ASSET";            
            // 0x028F9350: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F9354: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F9358: RET                        |  return (System.Object)"IF_OPEN_REPAIR_ASSET";
            return (object)"IF_OPEN_REPAIR_ASSET";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028F935C (42963804), len: 72  VirtAddr: 0x028F935C RVA: 0x028F935C token: 100663656 methodIndex: 29701 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_IF_OPEN_REPAIR_ASSET_BACK_3(ref object o)
        {
            //
            // Disasemble & Code
            // 0x028F935C: STP x20, x19, [sp, #-0x20]! | stack[1152921510028752000] = ???;  stack[1152921510028752008] = ???;  //  dest_result_addr=1152921510028752000 |  dest_result_addr=1152921510028752008
            // 0x028F9360: STP x29, x30, [sp, #0x10]  | stack[1152921510028752016] = ???;  stack[1152921510028752024] = ???;  //  dest_result_addr=1152921510028752016 |  dest_result_addr=1152921510028752024
            // 0x028F9364: ADD x29, sp, #0x10         | X29 = (1152921510028752000 + 16) = 1152921510028752016 (0x10000001432BB490);
            // 0x028F9368: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028F936C: LDRB w8, [x19, #0xa5a]     | W8 = (bool)static_value_037B8A5A;       
            // 0x028F9370: TBNZ w8, #0, #0x28f938c    | if (static_value_037B8A5A == true) goto label_0;
            // 0x028F9374: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x028F9378: LDR x8, [x8, #0x548]       | X8 = 0x2B8A628;                         
            // 0x028F937C: LDR w0, [x8]               | W0 = 0x48;                              
            // 0x028F9380: BL #0x2782188              | X0 = sub_2782188( ?? 0x48, ????);       
            // 0x028F9384: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F9388: STRB w8, [x19, #0xa5a]     | static_value_037B8A5A = true;            //  dest_result_addr=58427994
            label_0:
            // 0x028F938C: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x028F9390: LDR x8, [x8, #0x4d0]       | X8 = (string**)(1152921510024642032)("IF_OPEN_REPAIR_ASSET_BACK");
            // 0x028F9394: LDR x0, [x8]               | X0 = "IF_OPEN_REPAIR_ASSET_BACK";       
            // 0x028F9398: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F939C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F93A0: RET                        |  return (System.Object)"IF_OPEN_REPAIR_ASSET_BACK";
            return (object)"IF_OPEN_REPAIR_ASSET_BACK";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028F93A4 (42963876), len: 288  VirtAddr: 0x028F93A4 RVA: 0x028F93A4 token: 100663657 methodIndex: 29702 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_clientVer_4(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x028F93A4: STP x20, x19, [sp, #-0x20]! | stack[1152921510028872032] = ???;  stack[1152921510028872040] = ???;  //  dest_result_addr=1152921510028872032 |  dest_result_addr=1152921510028872040
            // 0x028F93A8: STP x29, x30, [sp, #0x10]  | stack[1152921510028872048] = ???;  stack[1152921510028872056] = ???;  //  dest_result_addr=1152921510028872048 |  dest_result_addr=1152921510028872056
            // 0x028F93AC: ADD x29, sp, #0x10         | X29 = (1152921510028872032 + 16) = 1152921510028872048 (0x10000001432D8970);
            // 0x028F93B0: SUB sp, sp, #0x10          | SP = (1152921510028872032 - 16) = 1152921510028872016 (0x10000001432D8950);
            // 0x028F93B4: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F93B8: LDRB w8, [x20, #0xa5b]     | W8 = (bool)static_value_037B8A5B;       
            // 0x028F93BC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F93C0: TBNZ w8, #0, #0x28f93dc    | if (static_value_037B8A5B == true) goto label_0;
            // 0x028F93C4: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x028F93C8: LDR x8, [x8, #0x400]       | X8 = 0x2B8A614;                         
            // 0x028F93CC: LDR w0, [x8]               | W0 = 0x43;                              
            // 0x028F93D0: BL #0x2782188              | X0 = sub_2782188( ?? 0x43, ????);       
            // 0x028F93D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F93D8: STRB w8, [x20, #0xa5b]     | static_value_037B8A5B = true;            //  dest_result_addr=58427995
            label_0:
            // 0x028F93DC: ADRP x20, #0x365c000       | X20 = 56999936 (0x365C000);             
            // 0x028F93E0: LDR x19, [x19]             | X19 = X1;                               
            // 0x028F93E4: LDR x20, [x20, #0xd68]     | X20 = 1152921504910680064;              
            // 0x028F93E8: CBZ x19, #0x28f943c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x028F93EC: LDR x8, [x19]              | X8 = X1;                                
            // 0x028F93F0: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F93F4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028F93F8: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F93FC: CMP w10, w9                | STATE = COMPARE(X1 + 260, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9400: B.LO #0x28f9418            | if (X1 + 260 < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028F9404: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028F9408: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F940C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9410: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9414: B.EQ #0x28f9440            | if ((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028F9418: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028F941C: MOV x8, sp                 | X8 = 1152921510028872016 (0x10000001432D8950);//ML01
            // 0x028F9420: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028F9424: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510028860064]
            // 0x028F9428: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028F942C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9430: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028F9434: MOV x0, sp                 | X0 = 1152921510028872016 (0x10000001432D8950);//ML01
            // 0x028F9438: BL #0x299a140              | 
            label_1:
            // 0x028F943C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001432D8950, ????);
            label_3:
            // 0x028F9440: LDR x8, [x19]              | X8 = X1;                                
            // 0x028F9444: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9448: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028F944C: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9450: CMP w10, w9                | STATE = COMPARE(X1 + 260, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9454: B.LO #0x28f9480            | if (X1 + 260 < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x028F9458: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028F945C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9460: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9464: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9468: B.NE #0x28f9480            | if ((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x028F946C: LDR x0, [x19, #0x58]       | X0 = X1 + 88;                           
            // 0x028F9470: SUB sp, x29, #0x10         | SP = (1152921510028872048 - 16) = 1152921510028872032 (0x10000001432D8960);
            // 0x028F9474: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F9478: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F947C: RET                        |  return (System.Object)X1 + 88;         
            return (object)X1 + 88;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x028F9480: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028F9484: ADD x8, sp, #8             | X8 = (1152921510028872016 + 8) = 1152921510028872024 (0x10000001432D8958);
            // 0x028F9488: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028F948C: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510028860064]
            // 0x028F9490: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028F9494: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9498: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028F949C: ADD x0, sp, #8             | X0 = (1152921510028872016 + 8) = 1152921510028872024 (0x10000001432D8958);
            // 0x028F94A0: BL #0x299a140              | 
            // 0x028F94A4: MOV x19, x0                | X19 = 1152921510028872024 (0x10000001432D8958);//ML01
            // 0x028F94A8: MOV x0, sp                 | X0 = 1152921510028872016 (0x10000001432D8950);//ML01
            label_6:
            // 0x028F94AC: BL #0x299a140              | 
            // 0x028F94B0: MOV x0, x19                | X0 = 1152921510028872024 (0x10000001432D8958);//ML01
            // 0x028F94B4: BL #0x980800               | X0 = sub_980800( ?? 0x10000001432D8958, ????);
            // 0x028F94B8: MOV x19, x0                | X19 = 1152921510028872024 (0x10000001432D8958);//ML01
            // 0x028F94BC: ADD x0, sp, #8             | X0 = (1152921510028872016 + 8) = 1152921510028872024 (0x10000001432D8958);
            // 0x028F94C0: B #0x28f94ac               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x028F94C4 (42964164), len: 392  VirtAddr: 0x028F94C4 RVA: 0x028F94C4 token: 100663658 methodIndex: 29703 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_clientVer_4(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x028F94C4: STP x22, x21, [sp, #-0x30]! | stack[1152921510028996144] = ???;  stack[1152921510028996152] = ???;  //  dest_result_addr=1152921510028996144 |  dest_result_addr=1152921510028996152
            // 0x028F94C8: STP x20, x19, [sp, #0x10]  | stack[1152921510028996160] = ???;  stack[1152921510028996168] = ???;  //  dest_result_addr=1152921510028996160 |  dest_result_addr=1152921510028996168
            // 0x028F94CC: STP x29, x30, [sp, #0x20]  | stack[1152921510028996176] = ???;  stack[1152921510028996184] = ???;  //  dest_result_addr=1152921510028996176 |  dest_result_addr=1152921510028996184
            // 0x028F94D0: ADD x29, sp, #0x20         | X29 = (1152921510028996144 + 32) = 1152921510028996176 (0x10000001432F6E50);
            // 0x028F94D4: SUB sp, sp, #0x20          | SP = (1152921510028996144 - 32) = 1152921510028996112 (0x10000001432F6E10);
            // 0x028F94D8: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F94DC: LDRB w8, [x21, #0xa5c]     | W8 = (bool)static_value_037B8A5C;       
            // 0x028F94E0: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x028F94E4: MOV x20, x1                | X20 = v;//m1                            
            // 0x028F94E8: TBNZ w8, #0, #0x28f9504    | if (static_value_037B8A5C == true) goto label_0;
            // 0x028F94EC: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x028F94F0: LDR x8, [x8, #0xcd0]       | X8 = 0x2B8A670;                         
            // 0x028F94F4: LDR w0, [x8]               | W0 = 0x5A;                              
            // 0x028F94F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x5A, ????);       
            // 0x028F94FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F9500: STRB w8, [x21, #0xa5c]     | static_value_037B8A5C = true;            //  dest_result_addr=58427996
            label_0:
            // 0x028F9504: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x028F9508: CBZ x20, #0x28f95bc        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x028F950C: ADRP x21, #0x365c000       | X21 = 56999936 (0x365C000);             
            // 0x028F9510: LDR x21, [x21, #0xd68]     | X21 = 1152921504910680064;              
            val_6 = 1152921504910680064;
            // 0x028F9514: LDR x8, [x20]              | X8 = ;                                  
            // 0x028F9518: LDR x1, [x21]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F951C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028F9520: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9524: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9528: B.LO #0x28f9540            | if (mem[null + 260] < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028F952C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028F9530: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9534: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9538: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F953C: B.EQ #0x28f9568            | if ((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028F9540: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F9544: ADD x8, sp, #8             | X8 = (1152921510028996112 + 8) = 1152921510028996120 (0x10000001432F6E18);
            // 0x028F9548: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028F954C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510028984192]
            // 0x028F9550: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028F9554: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9558: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028F955C: ADD x0, sp, #8             | X0 = (1152921510028996112 + 8) = 1152921510028996120 (0x10000001432F6E18);
            // 0x028F9560: BL #0x299a140              | 
            // 0x028F9564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001432F6E18, ????);
            label_3:
            // 0x028F9568: LDR x8, [x20]              | X8 = ;                                  
            // 0x028F956C: LDR x1, [x21]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9570: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028F9574: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9578: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F957C: B.LO #0x28f9594            | if (mem[null + 260] < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x028F9580: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028F9584: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9588: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F958C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9590: B.EQ #0x28f95c4            | if ((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x028F9594: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F9598: ADD x8, sp, #0x10          | X8 = (1152921510028996112 + 16) = 1152921510028996128 (0x10000001432F6E20);
            // 0x028F959C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028F95A0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510028984192]
            // 0x028F95A4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028F95A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F95AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028F95B0: ADD x0, sp, #0x10          | X0 = (1152921510028996112 + 16) = 1152921510028996128 (0x10000001432F6E20);
            // 0x028F95B4: BL #0x299a140              | 
            // 0x028F95B8: B #0x28f95c0               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x028F95BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x5A, ????);       
            label_6:
            // 0x028F95C0: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x028F95C4: CBZ x19, #0x28f9604        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x028F95C8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028F95CC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028F95D0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028F95D4: LDR x8, [x19]              | X8 = X2;                                
            // 0x028F95D8: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x028F95DC: B.EQ #0x28f9608            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x028F95E0: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x028F95E4: ADD x8, sp, #0x18          | X8 = (1152921510028996112 + 24) = 1152921510028996136 (0x10000001432F6E28);
            // 0x028F95E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x028F95EC: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510028984192]
            // 0x028F95F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x028F95F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F95F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x028F95FC: ADD x0, sp, #0x18          | X0 = (1152921510028996112 + 24) = 1152921510028996136 (0x10000001432F6E28);
            // 0x028F9600: BL #0x299a140              | 
            label_7:
            // 0x028F9604: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x028F9608: STR x19, [x20, #0x58]      | mem[88] = 0x0;                           //  dest_result_addr=88
            mem[88] = val_7;
            // 0x028F960C: SUB sp, x29, #0x20         | SP = (1152921510028996176 - 32) = 1152921510028996144 (0x10000001432F6E30);
            // 0x028F9610: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F9614: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F9618: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F961C: RET                        |  return;                                
            return;
            // 0x028F9620: MOV x19, x0                | 
            // 0x028F9624: ADD x0, sp, #8             | 
            // 0x028F9628: B #0x28f9640               | 
            // 0x028F962C: MOV x19, x0                | 
            // 0x028F9630: ADD x0, sp, #0x10          | 
            // 0x028F9634: B #0x28f9640               | 
            // 0x028F9638: MOV x19, x0                | 
            // 0x028F963C: ADD x0, sp, #0x18          | 
            label_10:
            // 0x028F9640: BL #0x299a140              | 
            // 0x028F9644: MOV x0, x19                | 
            // 0x028F9648: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F964C (42964556), len: 288  VirtAddr: 0x028F964C RVA: 0x028F964C token: 100663659 methodIndex: 29704 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_serverVer_5(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x028F964C: STP x20, x19, [sp, #-0x20]! | stack[1152921510029120288] = ???;  stack[1152921510029120296] = ???;  //  dest_result_addr=1152921510029120288 |  dest_result_addr=1152921510029120296
            // 0x028F9650: STP x29, x30, [sp, #0x10]  | stack[1152921510029120304] = ???;  stack[1152921510029120312] = ???;  //  dest_result_addr=1152921510029120304 |  dest_result_addr=1152921510029120312
            // 0x028F9654: ADD x29, sp, #0x10         | X29 = (1152921510029120288 + 16) = 1152921510029120304 (0x1000000143315330);
            // 0x028F9658: SUB sp, sp, #0x10          | SP = (1152921510029120288 - 16) = 1152921510029120272 (0x1000000143315310);
            // 0x028F965C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F9660: LDRB w8, [x20, #0xa5d]     | W8 = (bool)static_value_037B8A5D;       
            // 0x028F9664: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F9668: TBNZ w8, #0, #0x28f9684    | if (static_value_037B8A5D == true) goto label_0;
            // 0x028F966C: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x028F9670: LDR x8, [x8, #0xf30]       | X8 = 0x2B8A650;                         
            // 0x028F9674: LDR w0, [x8]               | W0 = 0x52;                              
            // 0x028F9678: BL #0x2782188              | X0 = sub_2782188( ?? 0x52, ????);       
            // 0x028F967C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F9680: STRB w8, [x20, #0xa5d]     | static_value_037B8A5D = true;            //  dest_result_addr=58427997
            label_0:
            // 0x028F9684: ADRP x20, #0x365c000       | X20 = 56999936 (0x365C000);             
            // 0x028F9688: LDR x19, [x19]             | X19 = X1;                               
            // 0x028F968C: LDR x20, [x20, #0xd68]     | X20 = 1152921504910680064;              
            // 0x028F9690: CBZ x19, #0x28f96e4        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x028F9694: LDR x8, [x19]              | X8 = X1;                                
            // 0x028F9698: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F969C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028F96A0: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F96A4: CMP w10, w9                | STATE = COMPARE(X1 + 260, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F96A8: B.LO #0x28f96c0            | if (X1 + 260 < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028F96AC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028F96B0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F96B4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F96B8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F96BC: B.EQ #0x28f96e8            | if ((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028F96C0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028F96C4: MOV x8, sp                 | X8 = 1152921510029120272 (0x1000000143315310);//ML01
            // 0x028F96C8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028F96CC: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510029108320]
            // 0x028F96D0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028F96D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F96D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028F96DC: MOV x0, sp                 | X0 = 1152921510029120272 (0x1000000143315310);//ML01
            // 0x028F96E0: BL #0x299a140              | 
            label_1:
            // 0x028F96E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143315310, ????);
            label_3:
            // 0x028F96E8: LDR x8, [x19]              | X8 = X1;                                
            // 0x028F96EC: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F96F0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028F96F4: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F96F8: CMP w10, w9                | STATE = COMPARE(X1 + 260, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F96FC: B.LO #0x28f9728            | if (X1 + 260 < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x028F9700: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028F9704: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9708: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F970C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9710: B.NE #0x28f9728            | if ((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x028F9714: LDR x0, [x19, #0x78]       | X0 = X1 + 120;                          
            // 0x028F9718: SUB sp, x29, #0x10         | SP = (1152921510029120304 - 16) = 1152921510029120288 (0x1000000143315320);
            // 0x028F971C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F9720: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F9724: RET                        |  return (System.Object)X1 + 120;        
            return (object)X1 + 120;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x028F9728: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028F972C: ADD x8, sp, #8             | X8 = (1152921510029120272 + 8) = 1152921510029120280 (0x1000000143315318);
            // 0x028F9730: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028F9734: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510029108320]
            // 0x028F9738: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028F973C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9740: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028F9744: ADD x0, sp, #8             | X0 = (1152921510029120272 + 8) = 1152921510029120280 (0x1000000143315318);
            // 0x028F9748: BL #0x299a140              | 
            // 0x028F974C: MOV x19, x0                | X19 = 1152921510029120280 (0x1000000143315318);//ML01
            // 0x028F9750: MOV x0, sp                 | X0 = 1152921510029120272 (0x1000000143315310);//ML01
            label_6:
            // 0x028F9754: BL #0x299a140              | 
            // 0x028F9758: MOV x0, x19                | X0 = 1152921510029120280 (0x1000000143315318);//ML01
            // 0x028F975C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143315318, ????);
            // 0x028F9760: MOV x19, x0                | X19 = 1152921510029120280 (0x1000000143315318);//ML01
            // 0x028F9764: ADD x0, sp, #8             | X0 = (1152921510029120272 + 8) = 1152921510029120280 (0x1000000143315318);
            // 0x028F9768: B #0x28f9754               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x028F976C (42964844), len: 392  VirtAddr: 0x028F976C RVA: 0x028F976C token: 100663660 methodIndex: 29705 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_serverVer_5(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x028F976C: STP x22, x21, [sp, #-0x30]! | stack[1152921510029244400] = ???;  stack[1152921510029244408] = ???;  //  dest_result_addr=1152921510029244400 |  dest_result_addr=1152921510029244408
            // 0x028F9770: STP x20, x19, [sp, #0x10]  | stack[1152921510029244416] = ???;  stack[1152921510029244424] = ???;  //  dest_result_addr=1152921510029244416 |  dest_result_addr=1152921510029244424
            // 0x028F9774: STP x29, x30, [sp, #0x20]  | stack[1152921510029244432] = ???;  stack[1152921510029244440] = ???;  //  dest_result_addr=1152921510029244432 |  dest_result_addr=1152921510029244440
            // 0x028F9778: ADD x29, sp, #0x20         | X29 = (1152921510029244400 + 32) = 1152921510029244432 (0x1000000143333810);
            // 0x028F977C: SUB sp, sp, #0x20          | SP = (1152921510029244400 - 32) = 1152921510029244368 (0x10000001433337D0);
            // 0x028F9780: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F9784: LDRB w8, [x21, #0xa5e]     | W8 = (bool)static_value_037B8A5E;       
            // 0x028F9788: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x028F978C: MOV x20, x1                | X20 = v;//m1                            
            // 0x028F9790: TBNZ w8, #0, #0x28f97ac    | if (static_value_037B8A5E == true) goto label_0;
            // 0x028F9794: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x028F9798: LDR x8, [x8, #0xbb8]       | X8 = 0x2B8A67C;                         
            // 0x028F979C: LDR w0, [x8]               | W0 = 0x5D;                              
            // 0x028F97A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x5D, ????);       
            // 0x028F97A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F97A8: STRB w8, [x21, #0xa5e]     | static_value_037B8A5E = true;            //  dest_result_addr=58427998
            label_0:
            // 0x028F97AC: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x028F97B0: CBZ x20, #0x28f9864        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x028F97B4: ADRP x21, #0x365c000       | X21 = 56999936 (0x365C000);             
            // 0x028F97B8: LDR x21, [x21, #0xd68]     | X21 = 1152921504910680064;              
            val_6 = 1152921504910680064;
            // 0x028F97BC: LDR x8, [x20]              | X8 = ;                                  
            // 0x028F97C0: LDR x1, [x21]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F97C4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028F97C8: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F97CC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F97D0: B.LO #0x28f97e8            | if (mem[null + 260] < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028F97D4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028F97D8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F97DC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F97E0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F97E4: B.EQ #0x28f9810            | if ((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028F97E8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F97EC: ADD x8, sp, #8             | X8 = (1152921510029244368 + 8) = 1152921510029244376 (0x10000001433337D8);
            // 0x028F97F0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028F97F4: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510029232448]
            // 0x028F97F8: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028F97FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9800: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028F9804: ADD x0, sp, #8             | X0 = (1152921510029244368 + 8) = 1152921510029244376 (0x10000001433337D8);
            // 0x028F9808: BL #0x299a140              | 
            // 0x028F980C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001433337D8, ????);
            label_3:
            // 0x028F9810: LDR x8, [x20]              | X8 = ;                                  
            // 0x028F9814: LDR x1, [x21]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9818: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028F981C: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9820: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9824: B.LO #0x28f983c            | if (mem[null + 260] < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x028F9828: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028F982C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9830: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9834: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9838: B.EQ #0x28f986c            | if ((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x028F983C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F9840: ADD x8, sp, #0x10          | X8 = (1152921510029244368 + 16) = 1152921510029244384 (0x10000001433337E0);
            // 0x028F9844: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028F9848: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510029232448]
            // 0x028F984C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028F9850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9854: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028F9858: ADD x0, sp, #0x10          | X0 = (1152921510029244368 + 16) = 1152921510029244384 (0x10000001433337E0);
            // 0x028F985C: BL #0x299a140              | 
            // 0x028F9860: B #0x28f9868               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x028F9864: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x5D, ????);       
            label_6:
            // 0x028F9868: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x028F986C: CBZ x19, #0x28f98ac        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x028F9870: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028F9874: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028F9878: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028F987C: LDR x8, [x19]              | X8 = X2;                                
            // 0x028F9880: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x028F9884: B.EQ #0x28f98b0            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x028F9888: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x028F988C: ADD x8, sp, #0x18          | X8 = (1152921510029244368 + 24) = 1152921510029244392 (0x10000001433337E8);
            // 0x028F9890: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x028F9894: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510029232448]
            // 0x028F9898: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x028F989C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F98A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x028F98A4: ADD x0, sp, #0x18          | X0 = (1152921510029244368 + 24) = 1152921510029244392 (0x10000001433337E8);
            // 0x028F98A8: BL #0x299a140              | 
            label_7:
            // 0x028F98AC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x028F98B0: STR x19, [x20, #0x78]      | mem[120] = 0x0;                          //  dest_result_addr=120
            mem[120] = val_7;
            // 0x028F98B4: SUB sp, x29, #0x20         | SP = (1152921510029244432 - 32) = 1152921510029244400 (0x10000001433337F0);
            // 0x028F98B8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F98BC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F98C0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F98C4: RET                        |  return;                                
            return;
            // 0x028F98C8: MOV x19, x0                | 
            // 0x028F98CC: ADD x0, sp, #8             | 
            // 0x028F98D0: B #0x28f98e8               | 
            // 0x028F98D4: MOV x19, x0                | 
            // 0x028F98D8: ADD x0, sp, #0x10          | 
            // 0x028F98DC: B #0x28f98e8               | 
            // 0x028F98E0: MOV x19, x0                | 
            // 0x028F98E4: ADD x0, sp, #0x18          | 
            label_10:
            // 0x028F98E8: BL #0x299a140              | 
            // 0x028F98EC: MOV x0, x19                | 
            // 0x028F98F0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F98F4 (42965236), len: 288  VirtAddr: 0x028F98F4 RVA: 0x028F98F4 token: 100663661 methodIndex: 29706 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_DOWNLOAD_URL_6(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x028F98F4: STP x20, x19, [sp, #-0x20]! | stack[1152921510029368544] = ???;  stack[1152921510029368552] = ???;  //  dest_result_addr=1152921510029368544 |  dest_result_addr=1152921510029368552
            // 0x028F98F8: STP x29, x30, [sp, #0x10]  | stack[1152921510029368560] = ???;  stack[1152921510029368568] = ???;  //  dest_result_addr=1152921510029368560 |  dest_result_addr=1152921510029368568
            // 0x028F98FC: ADD x29, sp, #0x10         | X29 = (1152921510029368544 + 16) = 1152921510029368560 (0x1000000143351CF0);
            // 0x028F9900: SUB sp, sp, #0x10          | SP = (1152921510029368544 - 16) = 1152921510029368528 (0x1000000143351CD0);
            // 0x028F9904: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F9908: LDRB w8, [x20, #0xa5f]     | W8 = (bool)static_value_037B8A5F;       
            // 0x028F990C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F9910: TBNZ w8, #0, #0x28f992c    | if (static_value_037B8A5F == true) goto label_0;
            // 0x028F9914: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x028F9918: LDR x8, [x8, #0x7e0]       | X8 = 0x2B8A618;                         
            // 0x028F991C: LDR w0, [x8]               | W0 = 0x44;                              
            // 0x028F9920: BL #0x2782188              | X0 = sub_2782188( ?? 0x44, ????);       
            // 0x028F9924: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F9928: STRB w8, [x20, #0xa5f]     | static_value_037B8A5F = true;            //  dest_result_addr=58427999
            label_0:
            // 0x028F992C: ADRP x20, #0x365c000       | X20 = 56999936 (0x365C000);             
            // 0x028F9930: LDR x19, [x19]             | X19 = X1;                               
            // 0x028F9934: LDR x20, [x20, #0xd68]     | X20 = 1152921504910680064;              
            // 0x028F9938: CBZ x19, #0x28f998c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x028F993C: LDR x8, [x19]              | X8 = X1;                                
            // 0x028F9940: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9944: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028F9948: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F994C: CMP w10, w9                | STATE = COMPARE(X1 + 260, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9950: B.LO #0x28f9968            | if (X1 + 260 < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028F9954: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028F9958: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F995C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9960: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9964: B.EQ #0x28f9990            | if ((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028F9968: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028F996C: MOV x8, sp                 | X8 = 1152921510029368528 (0x1000000143351CD0);//ML01
            // 0x028F9970: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028F9974: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510029356576]
            // 0x028F9978: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028F997C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9980: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028F9984: MOV x0, sp                 | X0 = 1152921510029368528 (0x1000000143351CD0);//ML01
            // 0x028F9988: BL #0x299a140              | 
            label_1:
            // 0x028F998C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143351CD0, ????);
            label_3:
            // 0x028F9990: LDR x8, [x19]              | X8 = X1;                                
            // 0x028F9994: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9998: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028F999C: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F99A0: CMP w10, w9                | STATE = COMPARE(X1 + 260, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F99A4: B.LO #0x28f99d0            | if (X1 + 260 < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x028F99A8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028F99AC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F99B0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F99B4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F99B8: B.NE #0x28f99d0            | if ((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x028F99BC: LDR x0, [x19, #0xa0]       | X0 = X1 + 160;                          
            // 0x028F99C0: SUB sp, x29, #0x10         | SP = (1152921510029368560 - 16) = 1152921510029368544 (0x1000000143351CE0);
            // 0x028F99C4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F99C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F99CC: RET                        |  return (System.Object)X1 + 160;        
            return (object)X1 + 160;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x028F99D0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028F99D4: ADD x8, sp, #8             | X8 = (1152921510029368528 + 8) = 1152921510029368536 (0x1000000143351CD8);
            // 0x028F99D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028F99DC: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510029356576]
            // 0x028F99E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028F99E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F99E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028F99EC: ADD x0, sp, #8             | X0 = (1152921510029368528 + 8) = 1152921510029368536 (0x1000000143351CD8);
            // 0x028F99F0: BL #0x299a140              | 
            // 0x028F99F4: MOV x19, x0                | X19 = 1152921510029368536 (0x1000000143351CD8);//ML01
            // 0x028F99F8: MOV x0, sp                 | X0 = 1152921510029368528 (0x1000000143351CD0);//ML01
            label_6:
            // 0x028F99FC: BL #0x299a140              | 
            // 0x028F9A00: MOV x0, x19                | X0 = 1152921510029368536 (0x1000000143351CD8);//ML01
            // 0x028F9A04: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143351CD8, ????);
            // 0x028F9A08: MOV x19, x0                | X19 = 1152921510029368536 (0x1000000143351CD8);//ML01
            // 0x028F9A0C: ADD x0, sp, #8             | X0 = (1152921510029368528 + 8) = 1152921510029368536 (0x1000000143351CD8);
            // 0x028F9A10: B #0x28f99fc               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x028F9A14 (42965524), len: 392  VirtAddr: 0x028F9A14 RVA: 0x028F9A14 token: 100663662 methodIndex: 29707 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_DOWNLOAD_URL_6(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x028F9A14: STP x22, x21, [sp, #-0x30]! | stack[1152921510029492656] = ???;  stack[1152921510029492664] = ???;  //  dest_result_addr=1152921510029492656 |  dest_result_addr=1152921510029492664
            // 0x028F9A18: STP x20, x19, [sp, #0x10]  | stack[1152921510029492672] = ???;  stack[1152921510029492680] = ???;  //  dest_result_addr=1152921510029492672 |  dest_result_addr=1152921510029492680
            // 0x028F9A1C: STP x29, x30, [sp, #0x20]  | stack[1152921510029492688] = ???;  stack[1152921510029492696] = ???;  //  dest_result_addr=1152921510029492688 |  dest_result_addr=1152921510029492696
            // 0x028F9A20: ADD x29, sp, #0x20         | X29 = (1152921510029492656 + 32) = 1152921510029492688 (0x10000001433701D0);
            // 0x028F9A24: SUB sp, sp, #0x20          | SP = (1152921510029492656 - 32) = 1152921510029492624 (0x1000000143370190);
            // 0x028F9A28: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F9A2C: LDRB w8, [x21, #0xa60]     | W8 = (bool)static_value_037B8A60;       
            // 0x028F9A30: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x028F9A34: MOV x20, x1                | X20 = v;//m1                            
            // 0x028F9A38: TBNZ w8, #0, #0x28f9a54    | if (static_value_037B8A60 == true) goto label_0;
            // 0x028F9A3C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x028F9A40: LDR x8, [x8, #0xf18]       | X8 = 0x2B8A674;                         
            // 0x028F9A44: LDR w0, [x8]               | W0 = 0x5B;                              
            // 0x028F9A48: BL #0x2782188              | X0 = sub_2782188( ?? 0x5B, ????);       
            // 0x028F9A4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F9A50: STRB w8, [x21, #0xa60]     | static_value_037B8A60 = true;            //  dest_result_addr=58428000
            label_0:
            // 0x028F9A54: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x028F9A58: CBZ x20, #0x28f9b0c        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x028F9A5C: ADRP x21, #0x365c000       | X21 = 56999936 (0x365C000);             
            // 0x028F9A60: LDR x21, [x21, #0xd68]     | X21 = 1152921504910680064;              
            val_6 = 1152921504910680064;
            // 0x028F9A64: LDR x8, [x20]              | X8 = ;                                  
            // 0x028F9A68: LDR x1, [x21]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9A6C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028F9A70: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9A74: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9A78: B.LO #0x28f9a90            | if (mem[null + 260] < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028F9A7C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028F9A80: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9A84: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9A88: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9A8C: B.EQ #0x28f9ab8            | if ((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028F9A90: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F9A94: ADD x8, sp, #8             | X8 = (1152921510029492624 + 8) = 1152921510029492632 (0x1000000143370198);
            // 0x028F9A98: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028F9A9C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510029480704]
            // 0x028F9AA0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028F9AA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9AA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028F9AAC: ADD x0, sp, #8             | X0 = (1152921510029492624 + 8) = 1152921510029492632 (0x1000000143370198);
            // 0x028F9AB0: BL #0x299a140              | 
            // 0x028F9AB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143370198, ????);
            label_3:
            // 0x028F9AB8: LDR x8, [x20]              | X8 = ;                                  
            // 0x028F9ABC: LDR x1, [x21]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9AC0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028F9AC4: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9AC8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9ACC: B.LO #0x28f9ae4            | if (mem[null + 260] < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x028F9AD0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028F9AD4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9AD8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9ADC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9AE0: B.EQ #0x28f9b14            | if ((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x028F9AE4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F9AE8: ADD x8, sp, #0x10          | X8 = (1152921510029492624 + 16) = 1152921510029492640 (0x10000001433701A0);
            // 0x028F9AEC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028F9AF0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510029480704]
            // 0x028F9AF4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028F9AF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9AFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028F9B00: ADD x0, sp, #0x10          | X0 = (1152921510029492624 + 16) = 1152921510029492640 (0x10000001433701A0);
            // 0x028F9B04: BL #0x299a140              | 
            // 0x028F9B08: B #0x28f9b10               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x028F9B0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x5B, ????);       
            label_6:
            // 0x028F9B10: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x028F9B14: CBZ x19, #0x28f9b54        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x028F9B18: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028F9B1C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028F9B20: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028F9B24: LDR x8, [x19]              | X8 = X2;                                
            // 0x028F9B28: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x028F9B2C: B.EQ #0x28f9b58            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x028F9B30: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x028F9B34: ADD x8, sp, #0x18          | X8 = (1152921510029492624 + 24) = 1152921510029492648 (0x10000001433701A8);
            // 0x028F9B38: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x028F9B3C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510029480704]
            // 0x028F9B40: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x028F9B44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9B48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x028F9B4C: ADD x0, sp, #0x18          | X0 = (1152921510029492624 + 24) = 1152921510029492648 (0x10000001433701A8);
            // 0x028F9B50: BL #0x299a140              | 
            label_7:
            // 0x028F9B54: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x028F9B58: STR x19, [x20, #0xa0]      | mem[160] = 0x0;                          //  dest_result_addr=160
            mem[160] = val_7;
            // 0x028F9B5C: SUB sp, x29, #0x20         | SP = (1152921510029492688 - 32) = 1152921510029492656 (0x10000001433701B0);
            // 0x028F9B60: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F9B64: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F9B68: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F9B6C: RET                        |  return;                                
            return;
            // 0x028F9B70: MOV x19, x0                | 
            // 0x028F9B74: ADD x0, sp, #8             | 
            // 0x028F9B78: B #0x28f9b90               | 
            // 0x028F9B7C: MOV x19, x0                | 
            // 0x028F9B80: ADD x0, sp, #0x10          | 
            // 0x028F9B84: B #0x28f9b90               | 
            // 0x028F9B88: MOV x19, x0                | 
            // 0x028F9B8C: ADD x0, sp, #0x18          | 
            label_10:
            // 0x028F9B90: BL #0x299a140              | 
            // 0x028F9B94: MOV x0, x19                | 
            // 0x028F9B98: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028F9B9C (42965916), len: 312  VirtAddr: 0x028F9B9C RVA: 0x028F9B9C token: 100663663 methodIndex: 29708 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_isloadServer_7(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x028F9B9C: STP x20, x19, [sp, #-0x20]! | stack[1152921510029620896] = ???;  stack[1152921510029620904] = ???;  //  dest_result_addr=1152921510029620896 |  dest_result_addr=1152921510029620904
            // 0x028F9BA0: STP x29, x30, [sp, #0x10]  | stack[1152921510029620912] = ???;  stack[1152921510029620920] = ???;  //  dest_result_addr=1152921510029620912 |  dest_result_addr=1152921510029620920
            // 0x028F9BA4: ADD x29, sp, #0x10         | X29 = (1152921510029620896 + 16) = 1152921510029620912 (0x100000014338F6B0);
            // 0x028F9BA8: SUB sp, sp, #0x20          | SP = (1152921510029620896 - 32) = 1152921510029620864 (0x100000014338F680);
            // 0x028F9BAC: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F9BB0: LDRB w8, [x20, #0xa61]     | W8 = (bool)static_value_037B8A61;       
            // 0x028F9BB4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F9BB8: TBNZ w8, #0, #0x28f9bd4    | if (static_value_037B8A61 == true) goto label_0;
            // 0x028F9BBC: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x028F9BC0: LDR x8, [x8, #0x310]       | X8 = 0x2B8A630;                         
            // 0x028F9BC4: LDR w0, [x8]               | W0 = 0x4A;                              
            // 0x028F9BC8: BL #0x2782188              | X0 = sub_2782188( ?? 0x4A, ????);       
            // 0x028F9BCC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F9BD0: STRB w8, [x20, #0xa61]     | static_value_037B8A61 = true;            //  dest_result_addr=58428001
            label_0:
            // 0x028F9BD4: ADRP x20, #0x365c000       | X20 = 56999936 (0x365C000);             
            // 0x028F9BD8: LDR x19, [x19]             | X19 = X1;                               
            // 0x028F9BDC: LDR x20, [x20, #0xd68]     | X20 = 1152921504910680064;              
            // 0x028F9BE0: CBZ x19, #0x28f9c34        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x028F9BE4: LDR x8, [x19]              | X8 = X1;                                
            // 0x028F9BE8: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9BEC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028F9BF0: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9BF4: CMP w10, w9                | STATE = COMPARE(X1 + 260, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9BF8: B.LO #0x28f9c10            | if (X1 + 260 < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028F9BFC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028F9C00: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9C04: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9C08: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9C0C: B.EQ #0x28f9c38            | if ((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028F9C10: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028F9C14: ADD x8, sp, #0x10          | X8 = (1152921510029620864 + 16) = 1152921510029620880 (0x100000014338F690);
            // 0x028F9C18: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028F9C1C: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510029608928]
            // 0x028F9C20: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028F9C24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9C28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028F9C2C: ADD x0, sp, #0x10          | X0 = (1152921510029620864 + 16) = 1152921510029620880 (0x100000014338F690);
            // 0x028F9C30: BL #0x299a140              | 
            label_1:
            // 0x028F9C34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014338F690, ????);
            label_3:
            // 0x028F9C38: LDR x8, [x19]              | X8 = X1;                                
            // 0x028F9C3C: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9C40: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028F9C44: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9C48: CMP w10, w9                | STATE = COMPARE(X1 + 260, ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9C4C: B.LO #0x28f9c90            | if (X1 + 260 < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x028F9C50: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028F9C54: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9C58: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9C5C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9C60: B.NE #0x28f9c90            | if ((X1 + 176 + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x028F9C64: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x028F9C68: LDRB w8, [x19, #0xa8]      | W8 = X1 + 168;                          
            // 0x028F9C6C: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x028F9C70: ADD x1, sp, #0xf           | X1 = (1152921510029620864 + 15) = 1152921510029620879 (0x100000014338F68F);
            // 0x028F9C74: STRB w8, [sp, #0xf]        | stack[1152921510029620879] = X1 + 168;   //  dest_result_addr=1152921510029620879
            // 0x028F9C78: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x028F9C7C: BL #0x27bc028              | X0 = 1152921510029668944 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 168);
            // 0x028F9C80: SUB sp, x29, #0x10         | SP = (1152921510029620912 - 16) = 1152921510029620896 (0x100000014338F6A0);
            // 0x028F9C84: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F9C88: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F9C8C: RET                        |  return (System.Object)X1 + 168;        
            return (object)X1 + 168;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x028F9C90: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028F9C94: ADD x8, sp, #0x18          | X8 = (1152921510029620864 + 24) = 1152921510029620888 (0x100000014338F698);
            // 0x028F9C98: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028F9C9C: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510029608928]
            // 0x028F9CA0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028F9CA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9CA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028F9CAC: ADD x0, sp, #0x18          | X0 = (1152921510029620864 + 24) = 1152921510029620888 (0x100000014338F698);
            // 0x028F9CB0: BL #0x299a140              | 
            // 0x028F9CB4: MOV x19, x0                | X19 = 1152921510029620888 (0x100000014338F698);//ML01
            // 0x028F9CB8: ADD x0, sp, #0x10          | X0 = (1152921510029620864 + 16) = 1152921510029620880 (0x100000014338F690);
            label_6:
            // 0x028F9CBC: BL #0x299a140              | 
            // 0x028F9CC0: MOV x0, x19                | X0 = 1152921510029620888 (0x100000014338F698);//ML01
            // 0x028F9CC4: BL #0x980800               | X0 = sub_980800( ?? 0x100000014338F698, ????);
            // 0x028F9CC8: MOV x19, x0                | X19 = 1152921510029620888 (0x100000014338F698);//ML01
            // 0x028F9CCC: ADD x0, sp, #0x18          | X0 = (1152921510029620864 + 24) = 1152921510029620888 (0x100000014338F698);
            // 0x028F9CD0: B #0x28f9cbc               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x028F9CD4 (42966228), len: 412  VirtAddr: 0x028F9CD4 RVA: 0x028F9CD4 token: 100663664 methodIndex: 29709 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_isloadServer_7(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x028F9CD4: STP x22, x21, [sp, #-0x30]! | stack[1152921510029749104] = ???;  stack[1152921510029749112] = ???;  //  dest_result_addr=1152921510029749104 |  dest_result_addr=1152921510029749112
            // 0x028F9CD8: STP x20, x19, [sp, #0x10]  | stack[1152921510029749120] = ???;  stack[1152921510029749128] = ???;  //  dest_result_addr=1152921510029749120 |  dest_result_addr=1152921510029749128
            // 0x028F9CDC: STP x29, x30, [sp, #0x20]  | stack[1152921510029749136] = ???;  stack[1152921510029749144] = ???;  //  dest_result_addr=1152921510029749136 |  dest_result_addr=1152921510029749144
            // 0x028F9CE0: ADD x29, sp, #0x20         | X29 = (1152921510029749104 + 32) = 1152921510029749136 (0x10000001433AEB90);
            // 0x028F9CE4: SUB sp, sp, #0x20          | SP = (1152921510029749104 - 32) = 1152921510029749072 (0x10000001433AEB50);
            // 0x028F9CE8: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F9CEC: LDRB w8, [x21, #0xa62]     | W8 = (bool)static_value_037B8A62;       
            // 0x028F9CF0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x028F9CF4: MOV x20, x1                | X20 = v;//m1                            
            // 0x028F9CF8: TBNZ w8, #0, #0x28f9d14    | if (static_value_037B8A62 == true) goto label_0;
            // 0x028F9CFC: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x028F9D00: LDR x8, [x8, #0xa78]       | X8 = 0x2B8A678;                         
            // 0x028F9D04: LDR w0, [x8]               | W0 = 0x5C;                              
            // 0x028F9D08: BL #0x2782188              | X0 = sub_2782188( ?? 0x5C, ????);       
            // 0x028F9D0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F9D10: STRB w8, [x21, #0xa62]     | static_value_037B8A62 = true;            //  dest_result_addr=58428002
            label_0:
            // 0x028F9D14: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x028F9D18: CBZ x21, #0x28f9dcc        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x028F9D1C: ADRP x20, #0x365c000       | X20 = 56999936 (0x365C000);             
            // 0x028F9D20: LDR x20, [x20, #0xd68]     | X20 = 1152921504910680064;              
            // 0x028F9D24: LDR x8, [x21]              | X8 = ;                                  
            // 0x028F9D28: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9D2C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028F9D30: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9D34: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9D38: B.LO #0x28f9d50            | if (mem[null + 260] < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028F9D3C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028F9D40: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9D44: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9D48: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9D4C: B.EQ #0x28f9d78            | if ((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028F9D50: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F9D54: ADD x8, sp, #8             | X8 = (1152921510029749072 + 8) = 1152921510029749080 (0x10000001433AEB58);
            // 0x028F9D58: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028F9D5C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510029737152]
            // 0x028F9D60: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028F9D64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9D68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028F9D6C: ADD x0, sp, #8             | X0 = (1152921510029749072 + 8) = 1152921510029749080 (0x10000001433AEB58);
            // 0x028F9D70: BL #0x299a140              | 
            // 0x028F9D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001433AEB58, ????);
            label_3:
            // 0x028F9D78: LDR x8, [x21]              | X8 = ;                                  
            // 0x028F9D7C: LDR x1, [x20]              | X1 = typeof(ABCheckUpdate);             
            // 0x028F9D80: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028F9D84: LDRB w9, [x1, #0x104]      | W9 = ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028F9D88: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028F9D8C: B.LO #0x28f9da4            | if (mem[null + 260] < ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x028F9D90: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028F9D94: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028F9D98: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028F9D9C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ABCheckUpdate))
            // 0x028F9DA0: B.EQ #0x28f9dd4            | if ((mem[null + 176] + (ABCheckUpdate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x028F9DA4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028F9DA8: ADD x8, sp, #0x10          | X8 = (1152921510029749072 + 16) = 1152921510029749088 (0x10000001433AEB60);
            // 0x028F9DAC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028F9DB0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510029737152]
            // 0x028F9DB4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028F9DB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9DBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028F9DC0: ADD x0, sp, #0x10          | X0 = (1152921510029749072 + 16) = 1152921510029749088 (0x10000001433AEB60);
            // 0x028F9DC4: BL #0x299a140              | 
            // 0x028F9DC8: B #0x28f9dd0               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x028F9DCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x5C, ????);       
            label_6:
            // 0x028F9DD0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x028F9DD4: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028F9DD8: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x028F9DDC: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x028F9DE0: CBNZ x19, #0x28f9de8       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x028F9DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x5C, ????);       
            label_7:
            // 0x028F9DE8: LDR x8, [x19]              | X8 = X2;                                
            // 0x028F9DEC: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x028F9DF0: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x028F9DF4: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x028F9DF8: B.NE #0x28f9e40            | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x028F9DFC: MOV x0, x19                | X0 = X2;//m1                            
            // 0x028F9E00: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x028F9E04: LDRB w8, [x0]              | W8 = X2;                                
            // 0x028F9E08: STRB w8, [x21, #0xa8]      | mem[168] = X2;                           //  dest_result_addr=168
            mem[168] = X2;
            // 0x028F9E0C: SUB sp, x29, #0x20         | SP = (1152921510029749136 - 32) = 1152921510029749104 (0x10000001433AEB70);
            // 0x028F9E10: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F9E14: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F9E18: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F9E1C: RET                        |  return;                                
            return;
            // 0x028F9E20: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x028F9E24: ADD x0, sp, #8             | X0 = (1152921510029749152 + 8) = 1152921510029749160 (0x10000001433AEBA8);
            // 0x028F9E28: B #0x28f9e34               |  goto label_10;                         
            goto label_10;
            // 0x028F9E2C: MOV x19, x0                | X19 = 1152921510029749160 (0x10000001433AEBA8);//ML01
            val_7;
            // 0x028F9E30: ADD x0, sp, #0x10          | X0 = (1152921510029749152 + 16) = 1152921510029749168 (0x10000001433AEBB0);
            label_10:
            // 0x028F9E34: BL #0x299a140              | 
            // 0x028F9E38: MOV x0, x19                | X0 = 1152921510029749160 (0x10000001433AEBA8);//ML01
            // 0x028F9E3C: BL #0x980800               | X0 = sub_980800( ?? 0x10000001433AEBA8, ????);
            label_8:
            // 0x028F9E40: ADD x8, sp, #0x18          | X8 = (1152921510029749152 + 24) = 1152921510029749176 (0x10000001433AEBB8);
            // 0x028F9E44: MOV x1, x20                | X1 = X20;//m1                           
            // 0x028F9E48: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001433AEBA8, ????);
            // 0x028F9E4C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510029737152]
            // 0x028F9E50: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x028F9E54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9E58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x028F9E5C: ADD x0, sp, #0x18          | X0 = (1152921510029749152 + 24) = 1152921510029749176 (0x10000001433AEBB8);
            // 0x028F9E60: BL #0x299a140              | 
            // 0x028F9E64: MOV x19, x0                | X19 = 1152921510029749176 (0x10000001433AEBB8);//ML01
            // 0x028F9E68: ADD x0, sp, #0x18          | X0 = (1152921510029749152 + 24) = 1152921510029749176 (0x10000001433AEBB8);
            // 0x028F9E6C: B #0x28f9e34               |  goto label_10;                         
            goto label_10;
        
        }
    
    }

}
