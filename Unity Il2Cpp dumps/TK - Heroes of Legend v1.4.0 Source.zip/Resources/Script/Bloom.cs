using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x281A4D8
[UnityEngine.RequireComponent] // 0x281A4D8
[UnityEngine.AddComponentMenu] // 0x281A4D8
[Serializable]
public class Bloom : PostEffectsBase
{
    // Fields
    public Bloom.TweakMode tweakMode; //  0x0000001C
    public Bloom.BloomScreenBlendMode screenBlendMode; //  0x00000020
    public Bloom.HDRBloomMode hdr; //  0x00000024
    private bool doHdr; //  0x00000028
    public float sepBlurSpread; //  0x0000002C
    public Bloom.BloomQuality quality; //  0x00000030
    public float bloomIntensity; //  0x00000034
    public float bloomThreshhold; //  0x00000038
    public UnityEngine.Color bloomThreshholdColor; //  0x0000003C
    public int bloomBlurIterations; //  0x0000004C
    public int hollywoodFlareBlurIterations; //  0x00000050
    public float flareRotation; //  0x00000054
    public Bloom.LensFlareStyle lensflareMode; //  0x00000058
    public float hollyStretchWidth; //  0x0000005C
    public float lensflareIntensity; //  0x00000060
    public float lensflareThreshhold; //  0x00000064
    public float lensFlareSaturation; //  0x00000068
    public UnityEngine.Color flareColorA; //  0x0000006C
    public UnityEngine.Color flareColorB; //  0x0000007C
    public UnityEngine.Color flareColorC; //  0x0000008C
    public UnityEngine.Color flareColorD; //  0x0000009C
    public float blurWidth; //  0x000000AC
    public UnityEngine.Texture2D lensFlareVignetteMask; //  0x000000B0
    public UnityEngine.Shader lensFlareShader; //  0x000000B8
    private UnityEngine.Material lensFlareMaterial; //  0x000000C0
    public UnityEngine.Shader screenBlendShader; //  0x000000C8
    private UnityEngine.Material screenBlend; //  0x000000D0
    public UnityEngine.Shader blurAndFlaresShader; //  0x000000D8
    private UnityEngine.Material blurAndFlaresMaterial; //  0x000000E0
    public UnityEngine.Shader brightPassFilterShader; //  0x000000E8
    private UnityEngine.Material brightPassFilterMaterial; //  0x000000F0
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x026724DC (40314076), len: 344  VirtAddr: 0x026724DC RVA: 0x026724DC token: 100663307 methodIndex: 24391 delegateWrapperIndex: 0 methodInvoker: 0
    public Bloom()
    {
        //
        // Disasemble & Code
        // 0x026724DC: STP d11, d10, [sp, #-0x50]! | stack[1152921509944600832] = ???;  stack[1152921509944600840] = ???;  //  dest_result_addr=1152921509944600832 |  dest_result_addr=1152921509944600840
        // 0x026724E0: STP d9, d8, [sp, #0x10]    | stack[1152921509944600848] = ???;  stack[1152921509944600856] = ???;  //  dest_result_addr=1152921509944600848 |  dest_result_addr=1152921509944600856
        // 0x026724E4: STP x22, x21, [sp, #0x20]  | stack[1152921509944600864] = ???;  stack[1152921509944600872] = ???;  //  dest_result_addr=1152921509944600864 |  dest_result_addr=1152921509944600872
        // 0x026724E8: STP x20, x19, [sp, #0x30]  | stack[1152921509944600880] = ???;  stack[1152921509944600888] = ???;  //  dest_result_addr=1152921509944600880 |  dest_result_addr=1152921509944600888
        // 0x026724EC: STP x29, x30, [sp, #0x40]  | stack[1152921509944600896] = ???;  stack[1152921509944600904] = ???;  //  dest_result_addr=1152921509944600896 |  dest_result_addr=1152921509944600904
        // 0x026724F0: ADD x29, sp, #0x40         | X29 = (1152921509944600832 + 64) = 1152921509944600896 (0x100000013E27A940);
        // 0x026724F4: SUB sp, sp, #0x40          | SP = (1152921509944600832 - 64) = 1152921509944600768 (0x100000013E27A8C0);
        // 0x026724F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026724FC: MOV x19, x0                | X19 = 1152921509944612912 (0x100000013E27D830);//ML01
        // 0x02672500: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x02672504: ORR w20, wzr, #1           | W20 = 1(0x1);                           
        // 0x02672508: MOVZ w21, #0x4020, lsl #16 | W21 = 1075838976 (0x40200000);//ML01    
        // 0x0267250C: ORR x8, xzr, #0x3f0000003f000000 | X8 = 4539628425446424576(0x3F0000003F000000);
        // 0x02672510: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672514: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672518: STP w20, wzr, [x19, #0x20] | this.screenBlendMode = 0x1;  this.hdr = null;  //  dest_result_addr=1152921509944612944 |  dest_result_addr=1152921509944612948
        this.screenBlendMode = 1;
        this.hdr = 0;
        // 0x0267251C: STRB w20, [x19, #0x18]     | mem[1152921509944612936] = 0x1;          //  dest_result_addr=1152921509944612936
        mem[1152921509944612936] = 1;
        // 0x02672520: STRB w20, [x19, #0x1a]     | mem[1152921509944612938] = 0x1;          //  dest_result_addr=1152921509944612938
        mem[1152921509944612938] = 1;
        // 0x02672524: STP w21, w20, [x19, #0x2c] | this.sepBlurSpread = 2.5;  this.quality = 0x1;  //  dest_result_addr=1152921509944612956 |  dest_result_addr=1152921509944612960
        this.sepBlurSpread = 2.5f;
        this.quality = 1;
        // 0x02672528: STUR x8, [x19, #0x34]      | this.bloomIntensity = 0.5; this.bloomThreshhold = 0.5;  //  dest_result_addr=1152921509944612964 dest_result_addr=1152921509944612968
        this.bloomIntensity = 0.5f;
        this.bloomThreshhold = 0.5f;
        // 0x0267252C: BL #0x20d3be4              | X0 = UnityEngine.Color.get_white();     
        UnityEngine.Color val_2 = UnityEngine.Color.white;
        // 0x02672530: MOVZ x9, #0x3f40, lsl #48  | X9 = 4557642822898941952 (0x3F40000000000000);//ML01
        // 0x02672534: MOVK x9, #0x3e99, lsl #16  | X9 = 4557642823949156352 (0x3F4000003E990000);
        // 0x02672538: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x0267253C: MOVK x9, #0x999a           | X9 = 4557642823949195674 (0x3F4000003E99999A);
        // 0x02672540: STP s0, s1, [x19, #0x3c]   | this.bloomThreshholdColor = val_2;  mem[1152921509944612976] = val_2.g;  //  dest_result_addr=1152921509944612972 |  dest_result_addr=1152921509944612976
        this.bloomThreshholdColor = val_2;
        mem[1152921509944612976] = val_2.g;
        // 0x02672544: STP s2, s3, [x19, #0x44]   | mem[1152921509944612980] = val_2.b;  mem[1152921509944612984] = val_2.a;  //  dest_result_addr=1152921509944612980 |  dest_result_addr=1152921509944612984
        mem[1152921509944612980] = val_2.b;
        mem[1152921509944612984] = val_2.a;
        // 0x02672548: STP w20, w21, [x19, #0x58] | this.lensflareMode = 0x1;  this.hollyStretchWidth = 2.5;  //  dest_result_addr=1152921509944613000 |  dest_result_addr=1152921509944613004
        this.lensflareMode = 1;
        this.hollyStretchWidth = 2.5f;
        // 0x0267254C: STP w8, w8, [x19, #0x4c]   | this.bloomBlurIterations = 2;  this.hollywoodFlareBlurIterations = 2;  //  dest_result_addr=1152921509944612988 |  dest_result_addr=1152921509944612992
        this.bloomBlurIterations = 2;
        this.hollywoodFlareBlurIterations = 2;
        // 0x02672550: STUR x9, [x19, #0x64]      | this.lensflareThreshhold = 0.3; this.lensFlareSaturation = 0.75;  //  dest_result_addr=1152921509944613012 dest_result_addr=1152921509944613016
        this.lensflareThreshhold = 0.3f;
        this.lensFlareSaturation = 0.75f;
        // 0x02672554: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x02672558: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x0267255C: LDR s8, [x8, #0x790]       | S8 = 0.4;                               
        // 0x02672560: LDR s9, [x9, #0x918]       | S9 = 0.8;                               
        // 0x02672564: FMOV s10, #0.75000000      | S10 = 0.75;                             
        // 0x02672568: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267256C: ADD x0, sp, #0x30          | X0 = (1152921509944600768 + 48) = 1152921509944600816 (0x100000013E27A8F0);
        // 0x02672570: MOV v0.16b, v8.16b         | V0 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x02672574: MOV v1.16b, v8.16b         | V1 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x02672578: MOV v2.16b, v9.16b         | V2 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x0267257C: MOV v3.16b, v10.16b        | V3 = 0.75;//m1                          
        // 0x02672580: STP xzr, xzr, [sp, #0x30]  | stack[1152921509944600816] = 0x0;  stack[1152921509944600824] = 0x0;  //  dest_result_addr=1152921509944600816 |  dest_result_addr=1152921509944600824
        // 0x02672584: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
        // 0x02672588: LDR q0, [sp, #0x30]        | Q0 = 0x0;                               
        // 0x0267258C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672590: ADD x0, sp, #0x20          | X0 = (1152921509944600768 + 32) = 1152921509944600800 (0x100000013E27A8E0);
        // 0x02672594: MOV v1.16b, v9.16b         | V1 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x02672598: STUR q0, [x19, #0x6c]      | this.flareColorA = new UnityEngine.Color();  //  dest_result_addr=1152921509944613020
        this.flareColorA = 0;
        // 0x0267259C: MOV v0.16b, v8.16b         | V0 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x026725A0: MOV v2.16b, v9.16b         | V2 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x026725A4: MOV v3.16b, v10.16b        | V3 = 0.75;//m1                          
        // 0x026725A8: STP xzr, xzr, [sp, #0x20]  | stack[1152921509944600800] = 0x0;  stack[1152921509944600808] = 0x0;  //  dest_result_addr=1152921509944600800 |  dest_result_addr=1152921509944600808
        // 0x026725AC: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
        // 0x026725B0: LDR q0, [sp, #0x20]        | Q0 = 0x0;                               
        // 0x026725B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026725B8: ADD x0, sp, #0x10          | X0 = (1152921509944600768 + 16) = 1152921509944600784 (0x100000013E27A8D0);
        // 0x026725BC: MOV v1.16b, v8.16b         | V1 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x026725C0: STUR q0, [x19, #0x7c]      | this.flareColorB = new UnityEngine.Color();  //  dest_result_addr=1152921509944613036
        this.flareColorB = 0;
        // 0x026725C4: MOV v0.16b, v9.16b         | V0 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x026725C8: MOV v2.16b, v9.16b         | V2 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x026725CC: MOV v3.16b, v10.16b        | V3 = 0.75;//m1                          
        // 0x026725D0: STP xzr, xzr, [sp, #0x10]  | stack[1152921509944600784] = 0x0;  stack[1152921509944600792] = 0x0;  //  dest_result_addr=1152921509944600784 |  dest_result_addr=1152921509944600792
        // 0x026725D4: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
        // 0x026725D8: LDR q0, [sp, #0x10]        | Q0 = 0x0;                               
        // 0x026725DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026725E0: FMOV s2, wzr               | S2 = 0f;                                
        // 0x026725E4: MOV x0, sp                 | X0 = 1152921509944600768 (0x100000013E27A8C0);//ML01
        // 0x026725E8: STUR q0, [x19, #0x8c]      | this.flareColorC = new UnityEngine.Color();  //  dest_result_addr=1152921509944613052
        this.flareColorC = 0;
        // 0x026725EC: MOV v0.16b, v9.16b         | V0 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x026725F0: MOV v1.16b, v8.16b         | V1 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x026725F4: MOV v3.16b, v10.16b        | V3 = 0.75;//m1                          
        // 0x026725F8: STP xzr, xzr, [sp]         | stack[1152921509944600768] = 0x0;  stack[1152921509944600776] = 0x0;  //  dest_result_addr=1152921509944600768 |  dest_result_addr=1152921509944600776
        // 0x026725FC: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
        // 0x02672600: LDP w8, w9, [sp]           | W8 = 0x0; W9 = 0x0;                      //  | 
        // 0x02672604: LDP w10, w11, [sp, #8]     | W10 = 0x0; W11 = 0x0;                    //  | 
        // 0x02672608: ORR w12, wzr, #0x3f800000  | W12 = 1065353216(0x3F800000);           
        // 0x0267260C: STP w8, w9, [x19, #0x9c]   | this.flareColorD = new UnityEngine.Color();  mem[1152921509944613072] = 0x0;  //  dest_result_addr=1152921509944613068 |  dest_result_addr=1152921509944613072
        this.flareColorD = 0;
        mem[1152921509944613072] = 0;
        // 0x02672610: STP w10, w11, [x19, #0xa4] | mem[1152921509944613076] = 0x0;  mem[1152921509944613080] = 0x0;  //  dest_result_addr=1152921509944613076 |  dest_result_addr=1152921509944613080
        mem[1152921509944613076] = 0;
        mem[1152921509944613080] = 0;
        // 0x02672614: STR w12, [x19, #0xac]      | this.blurWidth = 1;                      //  dest_result_addr=1152921509944613084
        this.blurWidth = 1f;
        // 0x02672618: SUB sp, x29, #0x40         | SP = (1152921509944600896 - 64) = 1152921509944600832 (0x100000013E27A900);
        // 0x0267261C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x02672620: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02672624: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x02672628: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x0267262C: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x02672630: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02672634 (40314420), len: 176  VirtAddr: 0x02672634 RVA: 0x02672634 token: 100663308 methodIndex: 24392 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x02672634: STP x20, x19, [sp, #-0x20]! | stack[1152921509944745648] = ???;  stack[1152921509944745656] = ???;  //  dest_result_addr=1152921509944745648 |  dest_result_addr=1152921509944745656
        // 0x02672638: STP x29, x30, [sp, #0x10]  | stack[1152921509944745664] = ???;  stack[1152921509944745672] = ???;  //  dest_result_addr=1152921509944745664 |  dest_result_addr=1152921509944745672
        // 0x0267263C: ADD x29, sp, #0x10         | X29 = (1152921509944745648 + 16) = 1152921509944745664 (0x100000013E29DEC0);
        // 0x02672640: MOV x19, x0                | X19 = 1152921509944757680 (0x100000013E2A0DB0);//ML01
        // 0x02672644: LDR x8, [x19]              | X8 = typeof(Bloom);                     
        // 0x02672648: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x0267264C: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(Bloom).__il2cppRuntimeField_1B0; X2 = typeof(Bloom).__il2cppRuntimeField_1B8; //  | 
        // 0x02672650: BLR x9                     | X0 = typeof(Bloom).__il2cppRuntimeField_1B0();
        // 0x02672654: LDR x8, [x19]              | X8 = typeof(Bloom);                     
        // 0x02672658: LDP x1, x2, [x19, #0xc8]   | X1 = this.screenBlendShader; //P2  X2 = this.screenBlend; //P2  //  | 
        // 0x0267265C: MOV x0, x19                | X0 = 1152921509944757680 (0x100000013E2A0DB0);//ML01
        // 0x02672660: LDP x9, x3, [x8, #0x150]   | X9 = typeof(Bloom).__il2cppRuntimeField_150; X3 = typeof(Bloom).__il2cppRuntimeField_158; //  | 
        // 0x02672664: BLR x9                     | X0 = typeof(Bloom).__il2cppRuntimeField_150();
        // 0x02672668: LDR x8, [x19]              | X8 = typeof(Bloom);                     
        // 0x0267266C: STR x0, [x19, #0xd0]       | this.screenBlend = this;                 //  dest_result_addr=1152921509944757888
        this.screenBlend = this;
        // 0x02672670: LDP x1, x2, [x19, #0xb8]   | X1 = this.lensFlareShader; //P2  X2 = this.lensFlareMaterial; //P2  //  | 
        // 0x02672674: MOV x0, x19                | X0 = 1152921509944757680 (0x100000013E2A0DB0);//ML01
        // 0x02672678: LDP x9, x3, [x8, #0x150]   | X9 = typeof(Bloom).__il2cppRuntimeField_150; X3 = typeof(Bloom).__il2cppRuntimeField_158; //  | 
        // 0x0267267C: BLR x9                     | X0 = typeof(Bloom).__il2cppRuntimeField_150();
        // 0x02672680: LDR x8, [x19]              | X8 = typeof(Bloom);                     
        // 0x02672684: STR x0, [x19, #0xc0]       | this.lensFlareMaterial = this;           //  dest_result_addr=1152921509944757872
        this.lensFlareMaterial = this;
        // 0x02672688: LDP x1, x2, [x19, #0xd8]   | X1 = this.blurAndFlaresShader; //P2  X2 = this.blurAndFlaresMaterial; //P2  //  | 
        // 0x0267268C: MOV x0, x19                | X0 = 1152921509944757680 (0x100000013E2A0DB0);//ML01
        // 0x02672690: LDP x9, x3, [x8, #0x150]   | X9 = typeof(Bloom).__il2cppRuntimeField_150; X3 = typeof(Bloom).__il2cppRuntimeField_158; //  | 
        // 0x02672694: BLR x9                     | X0 = typeof(Bloom).__il2cppRuntimeField_150();
        // 0x02672698: LDR x8, [x19]              | X8 = typeof(Bloom);                     
        // 0x0267269C: STR x0, [x19, #0xe0]       | this.blurAndFlaresMaterial = this;       //  dest_result_addr=1152921509944757904
        this.blurAndFlaresMaterial = this;
        // 0x026726A0: LDP x1, x2, [x19, #0xe8]   | X1 = this.brightPassFilterShader; //P2  X2 = this.brightPassFilterMaterial; //P2  //  | 
        // 0x026726A4: MOV x0, x19                | X0 = 1152921509944757680 (0x100000013E2A0DB0);//ML01
        // 0x026726A8: LDP x9, x3, [x8, #0x150]   | X9 = typeof(Bloom).__il2cppRuntimeField_150; X3 = typeof(Bloom).__il2cppRuntimeField_158; //  | 
        // 0x026726AC: BLR x9                     | X0 = typeof(Bloom).__il2cppRuntimeField_150();
        // 0x026726B0: LDRB w8, [x19, #0x1a]      | 
        // 0x026726B4: STR x0, [x19, #0xf0]       | this.brightPassFilterMaterial = this;    //  dest_result_addr=1152921509944757920
        this.brightPassFilterMaterial = this;
        // 0x026726B8: CBNZ w8, #0x26726d0        | if (typeof(Bloom) != null) goto label_0;
        if(null != null)
        {
            goto label_0;
        }
        // 0x026726BC: LDR x8, [x19]              | X8 = typeof(Bloom);                     
        // 0x026726C0: MOV x0, x19                | X0 = 1152921509944757680 (0x100000013E2A0DB0);//ML01
        // 0x026726C4: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(Bloom).__il2cppRuntimeField_1E0; X1 = typeof(Bloom).__il2cppRuntimeField_1E8; //  | 
        // 0x026726C8: BLR x9                     | X0 = typeof(Bloom).__il2cppRuntimeField_1E0();
        // 0x026726CC: LDRB w8, [x19, #0x1a]      | 
        label_0:
        // 0x026726D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x026726D4: CMP w8, #0                 | STATE = COMPARE(typeof(Bloom), 0x0)     
        // 0x026726D8: CSET w0, ne                | W0 = typeof(Bloom) != null ? 1 : 0;     
        var val_1 = (null != 0) ? 1 : 0;
        // 0x026726DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x026726E0: RET                        |  return (System.Boolean)typeof(Bloom) != null ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x026726E4 (40314596), len: 4092  VirtAddr: 0x026726E4 RVA: 0x026726E4 token: 100663309 methodIndex: 24393 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        var val_43;
        //  | 
        var val_44;
        //  | 
        var val_45;
        //  | 
        var val_46;
        //  | 
        float val_47;
        //  | 
        UnityEngine.RenderTexture val_48;
        //  | 
        float val_49;
        //  | 
        UnityEngine.Material val_50;
        // 0x026726E4: STP d15, d14, [sp, #-0xa0]! | stack[1152921509945120240] = ???;  stack[1152921509945120248] = ???;  //  dest_result_addr=1152921509945120240 |  dest_result_addr=1152921509945120248
        // 0x026726E8: STP d13, d12, [sp, #0x10]  | stack[1152921509945120256] = ???;  stack[1152921509945120264] = ???;  //  dest_result_addr=1152921509945120256 |  dest_result_addr=1152921509945120264
        // 0x026726EC: STP d11, d10, [sp, #0x20]  | stack[1152921509945120272] = ???;  stack[1152921509945120280] = ???;  //  dest_result_addr=1152921509945120272 |  dest_result_addr=1152921509945120280
        // 0x026726F0: STP d9, d8, [sp, #0x30]    | stack[1152921509945120288] = ???;  stack[1152921509945120296] = ???;  //  dest_result_addr=1152921509945120288 |  dest_result_addr=1152921509945120296
        // 0x026726F4: STP x28, x27, [sp, #0x40]  | stack[1152921509945120304] = ???;  stack[1152921509945120312] = ???;  //  dest_result_addr=1152921509945120304 |  dest_result_addr=1152921509945120312
        // 0x026726F8: STP x26, x25, [sp, #0x50]  | stack[1152921509945120320] = ???;  stack[1152921509945120328] = ???;  //  dest_result_addr=1152921509945120320 |  dest_result_addr=1152921509945120328
        // 0x026726FC: STP x24, x23, [sp, #0x60]  | stack[1152921509945120336] = ???;  stack[1152921509945120344] = ???;  //  dest_result_addr=1152921509945120336 |  dest_result_addr=1152921509945120344
        // 0x02672700: STP x22, x21, [sp, #0x70]  | stack[1152921509945120352] = ???;  stack[1152921509945120360] = ???;  //  dest_result_addr=1152921509945120352 |  dest_result_addr=1152921509945120360
        // 0x02672704: STP x20, x19, [sp, #0x80]  | stack[1152921509945120368] = ???;  stack[1152921509945120376] = ???;  //  dest_result_addr=1152921509945120368 |  dest_result_addr=1152921509945120376
        // 0x02672708: STP x29, x30, [sp, #0x90]  | stack[1152921509945120384] = ???;  stack[1152921509945120392] = ???;  //  dest_result_addr=1152921509945120384 |  dest_result_addr=1152921509945120392
        // 0x0267270C: ADD x29, sp, #0x90         | X29 = (1152921509945120240 + 144) = 1152921509945120384 (0x100000013E2F9680);
        // 0x02672710: SUB sp, sp, #0x70          | SP = (1152921509945120240 - 112) = 1152921509945120128 (0x100000013E2F9580);
        // 0x02672714: ADRP x19, #0x3740000       | X19 = 57933824 (0x3740000);             
        // 0x02672718: LDRB w8, [x19, #0xe46]     | W8 = (bool)static_value_03740E46;       
        // 0x0267271C: MOV x21, x2                | X21 = destination;//m1                  
        // 0x02672720: MOV x24, x1                | X24 = source;//m1                       
        // 0x02672724: MOV x20, x0                | X20 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x02672728: TBNZ w8, #0, #0x2672744    | if (static_value_03740E46 == true) goto label_0;
        // 0x0267272C: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x02672730: LDR x8, [x8, #0x60]        | X8 = 0x2B8F6A4;                         
        // 0x02672734: LDR w0, [x8]               | W0 = 0x146D;                            
        // 0x02672738: BL #0x2782188              | X0 = sub_2782188( ?? 0x146D, ????);     
        // 0x0267273C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02672740: STRB w8, [x19, #0xe46]     | static_value_03740E46 = true;            //  dest_result_addr=57937478
        label_0:
        // 0x02672744: LDR x8, [x20]              | X8 = typeof(Bloom);                     
        // 0x02672748: MOV x0, x20                | X0 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x0267274C: LDP x9, x1, [x8, #0x190]   | X9 = typeof(Bloom).__il2cppRuntimeField_190; X1 = typeof(Bloom).__il2cppRuntimeField_198; //  | 
        // 0x02672750: BLR x9                     | X0 = typeof(Bloom).__il2cppRuntimeField_190();
        // 0x02672754: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
        // 0x02672758: TBZ w8, #0, #0x2672774     | if (((Bloom)[1152921509945132400] & 0x1) == 0) goto label_1;
        if((0 & 1) == 0)
        {
            goto label_1;
        }
        // 0x0267275C: LDR w8, [x20, #0x24]       | W8 = this.hdr; //P2                     
        // 0x02672760: STRB wzr, [x20, #0x28]     | this.doHdr = false;                      //  dest_result_addr=1152921509945132440
        this.doHdr = false;
        // 0x02672764: CBZ w8, #0x26727d4         | if (this.hdr == 0) goto label_2;        
        if(this.hdr == 0)
        {
            goto label_2;
        }
        // 0x02672768: CMP w8, #1                 | STATE = COMPARE(this.hdr, 0x1)          
        // 0x0267276C: CSET w19, eq               | W19 = this.hdr == 0x1 ? 1 : 0;          
        var val_1 = (this.hdr == 1) ? 1 : 0;
        // 0x02672770: B #0x267282c               |  goto label_9;                          
        goto label_9;
        label_1:
        // 0x02672774: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02672778: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x0267277C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02672780: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02672784: TBZ w8, #0, #0x2672794     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x02672788: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267278C: CBNZ w8, #0x2672794        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x02672790: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_5:
        // 0x02672794: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672798: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267279C: MOV x1, x24                | X1 = source;//m1                        
        // 0x026727A0: MOV x2, x21                | X2 = destination;//m1                   
        // 0x026727A4: SUB sp, x29, #0x90         | SP = (1152921509945120384 - 144) = 1152921509945120240 (0x100000013E2F95F0);
        // 0x026727A8: LDP x29, x30, [sp, #0x90]  | X29 = ; X30 = ;                          //  | 
        // 0x026727AC: LDP x20, x19, [sp, #0x80]  | X20 = ; X19 = ;                          //  | 
        // 0x026727B0: LDP x22, x21, [sp, #0x70]  | X22 = ; X21 = ;                          //  | 
        // 0x026727B4: LDP x24, x23, [sp, #0x60]  | X24 = ; X23 = ;                          //  | 
        // 0x026727B8: LDP x26, x25, [sp, #0x50]  | X26 = ; X25 = ;                          //  | 
        // 0x026727BC: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
        // 0x026727C0: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x026727C4: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x026727C8: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x026727CC: LDP d15, d14, [sp], #0xa0  | D15 = ; D14 = ;                          //  | 
        // 0x026727D0: B #0x1a6ba68               | UnityEngine.Graphics.Blit(source:  0, dest:  source); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        return;
        label_2:
        // 0x026727D4: CBNZ x24, #0x26727dc       | if (source != null) goto label_6;       
        if(source != null)
        {
            goto label_6;
        }
        // 0x026727D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_6:
        // 0x026727DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026727E0: MOV x0, x24                | X0 = source;//m1                        
        // 0x026727E4: BL #0x1b89830              | X0 = source.get_format();               
        UnityEngine.RenderTextureFormat val_2 = source.format;
        // 0x026727E8: CMP w0, #2                 | STATE = COMPARE(val_2, 0x2)             
        // 0x026727EC: CSET w19, eq               | W19 = val_2 == 0x2 ? 1 : 0;             
        var val_3 = (val_2 == 2) ? 1 : 0;
        // 0x026727F0: B.NE #0x2672824            | if (val_2 != 0x2) goto label_7;         
        if(val_2 != 2)
        {
            goto label_7;
        }
        // 0x026727F4: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x026727F8: LDR x8, [x8, #0x338]       | X8 = 1152921509941328016;               
        // 0x026727FC: MOV x0, x20                | X0 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x02672800: LDR x1, [x8]               | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02672804: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_4 = this.GetComponent<UnityEngine.Camera>();
        // 0x02672808: MOV x19, x0                | X19 = val_4;//m1                        
        bool val_42 = val_4;
        // 0x0267280C: CBNZ x19, #0x2672814       | if (val_4 != null) goto label_8;        
        if(val_42 != null)
        {
            goto label_8;
        }
        // 0x02672810: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x02672814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672818: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x0267281C: BL #0x20cec84              | X0 = val_4.get_hdr();                   
        bool val_5 = val_42.hdr;
        // 0x02672820: AND w19, w0, #1            | W19 = (val_5 & 1);                      
        val_42 = val_5;
        label_7:
        // 0x02672824: CBNZ x20, #0x267282c       | if (this != null) goto label_9;         
        if(this != null)
        {
            goto label_9;
        }
        // 0x02672828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x0267282C: STRB w19, [x20, #0x28]     | this.doHdr = (val_5 & 1);                //  dest_result_addr=1152921509945132440
        this.doHdr = val_42;
        // 0x02672830: CBZ w19, #0x2672848        | if ((val_5 & 1) == false) goto label_10;
        if(val_42 == false)
        {
            goto label_10;
        }
        // 0x02672834: STR x21, [sp, #0x18]       | stack[1152921509945120152] = destination;  //  dest_result_addr=1152921509945120152
        // 0x02672838: LDRB w8, [x20, #0x18]      | 
        // 0x0267283C: CMP w8, #0                 | STATE = COMPARE(1152921509941328016, 0x0)
        // 0x02672840: CSET w8, ne                | W8 = 1152921509941328016 != 0x0 ? 1 : 0;
        var val_6 = (1152921509941328016 != 0) ? 1 : 0;
        // 0x02672844: B #0x2672850               |  goto label_11;                         
        goto label_11;
        label_10:
        // 0x02672848: STR x21, [sp, #0x18]       | stack[1152921509945120152] = destination;  //  dest_result_addr=1152921509945120152
        // 0x0267284C: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
        label_11:
        // 0x02672850: LDR w9, [x20, #0x20]       | W9 = this.screenBlendMode; //P2         
        // 0x02672854: CMP w8, #0                 | STATE = COMPARE(0x0, 0x0)               
        // 0x02672858: STRB w8, [x20, #0x28]      | this.doHdr = false;                      //  dest_result_addr=1152921509945132440
        this.doHdr = false;
        // 0x0267285C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02672860: ORR w10, wzr, #7           | W10 = 7(0x7);                           
        // 0x02672864: ORR w11, wzr, #2           | W11 = 2(0x2);                           
        // 0x02672868: CSEL w8, w8, w9, ne        | W8 = false != 0x0 ? 1 : this.screenBlendMode;
        var val_7 = (false != 0) ? (1) : (this.screenBlendMode);
        // 0x0267286C: CSEL w23, w11, w10, ne     | W23 = false != 0x0 ? 2 : 7;             
        var val_8 = (false != 0) ? (2) : (7);
        // 0x02672870: STR w8, [sp, #0x20]        | stack[1152921509945120160] = false != 0x0 ? 1 : this.screenBlendMode;  //  dest_result_addr=1152921509945120160
        // 0x02672874: CBNZ x24, #0x267287c       | if (source != null) goto label_12;      
        if(source != null)
        {
            goto label_12;
        }
        // 0x02672878: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_12:
        // 0x0267287C: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02672880: MOV x0, x24                | X0 = source;//m1                        
        // 0x02672884: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02672888: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x0267288C: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x02672890: CINC w19, w0, lt           | W19 = source < null ? (source + 1) : source;
        var val_9 = (source < 0) ? (source + 1) : (source);
        // 0x02672894: CBNZ x24, #0x267289c       | if (source != null) goto label_13;      
        if(source != null)
        {
            goto label_13;
        }
        // 0x02672898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_13:
        // 0x0267289C: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026728A0: MOV x0, x24                | X0 = source;//m1                        
        // 0x026728A4: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x026728A8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x026728AC: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x026728B0: CINC w21, w0, lt           | W21 = source < null ? (source + 1) : source;
        var val_10 = (source < 0) ? (source + 1) : (source);
        // 0x026728B4: CBNZ x24, #0x26728bc       | if (source != null) goto label_14;      
        if(source != null)
        {
            goto label_14;
        }
        // 0x026728B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_14:
        // 0x026728BC: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026728C0: MOV x0, x24                | X0 = source;//m1                        
        // 0x026728C4: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x026728C8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x026728CC: ADD w8, w0, #3             | W8 = (source + 3);                      
        UnityEngine.RenderTexture val_11 = source + 3;
        // 0x026728D0: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x026728D4: CSEL w22, w8, w0, lt       | W22 = source < null ? (source + 3) : source;
        var val_12 = (source < 0) ? (val_11) : (source);
        // 0x026728D8: CBNZ x24, #0x26728e0       | if (source != null) goto label_15;      
        if(source != null)
        {
            goto label_15;
        }
        // 0x026728DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_15:
        // 0x026728E0: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026728E4: MOV x0, x24                | X0 = source;//m1                        
        // 0x026728E8: ASR w26, w19, #1           | W26 = (source < null ? (source + 1) : source >> 1);
        int val_13 = val_9 >> 1;
        // 0x026728EC: ASR w19, w21, #1           | W19 = (source < null ? (source + 1) : source >> 1);
        int val_14 = val_10 >> 1;
        // 0x026728F0: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x026728F4: ASR w28, w22, #2           | W28 = (source < null ? (source + 3) : source >> 2);
        int val_15 = val_12 >> 2;
        // 0x026728F8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x026728FC: ADD w8, w0, #3             | W8 = (source + 3);                      
        UnityEngine.RenderTexture val_16 = source + 3;
        // 0x02672900: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x02672904: CSEL w8, w8, w0, lt        | W8 = source < null ? (source + 3) : source;
        var val_17 = (source < 0) ? (val_16) : (source);
        // 0x02672908: ASR w22, w8, #2            | W22 = (source < null ? (source + 3) : source >> 2);
        int val_18 = val_17 >> 2;
        // 0x0267290C: CBNZ x24, #0x2672914       | if (source != null) goto label_16;      
        if(source != null)
        {
            goto label_16;
        }
        // 0x02672910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_16:
        // 0x02672914: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02672918: MOV x0, x24                | X0 = source;//m1                        
        // 0x0267291C: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02672920: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02672924: MOV w27, w0                | W27 = source;//m1                       
        // 0x02672928: CBNZ x24, #0x2672930       | if (source != null) goto label_17;      
        if(source != null)
        {
            goto label_17;
        }
        // 0x0267292C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_17:
        // 0x02672930: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02672934: MOV x0, x24                | X0 = source;//m1                        
        // 0x02672938: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x0267293C: STR x24, [sp, #0x28]       | stack[1152921509945120168] = source;     //  dest_result_addr=1152921509945120168
        // 0x02672940: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02672944: MOV w25, w0                | W25 = source;//m1                       
        // 0x02672948: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267294C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02672950: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672954: MOV w1, w28                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02672958: MOV w2, w22                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x0267295C: MOV w4, w23                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x02672960: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        UnityEngine.RenderTexture val_19 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        // 0x02672964: MOV x24, x0                | X24 = val_19;//m1                       
        // 0x02672968: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267296C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02672970: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672974: MOV w1, w26                | W1 = (source < null ? (source + 1) : source >> 1);//m1
        // 0x02672978: MOV w2, w19                | W2 = (source < null ? (source + 1) : source >> 1);//m1
        // 0x0267297C: MOV w4, w23                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x02672980: STR w26, [sp, #0x24]       | stack[1152921509945120164] = (source < null ? (source + 1) : source >> 1);  //  dest_result_addr=1152921509945120164
        // 0x02672984: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_13, depthBuffer:  val_14, format:  0);
        UnityEngine.RenderTexture val_20 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_13, depthBuffer:  val_14, format:  0);
        // 0x02672988: LDR w8, [x20, #0x30]       | W8 = this.quality; //P2                 
        // 0x0267298C: MOV x26, x0                | X26 = val_20;//m1                       
        // 0x02672990: CMP w8, #1                 | STATE = COMPARE(this.quality, 0x1)      
        // 0x02672994: B.LT #0x2672a48            | if (this.quality < 0x1) goto label_18;  
        if(this.quality < 1)
        {
            goto label_18;
        }
        // 0x02672998: STR w19, [sp, #0x14]       | stack[1152921509945120148] = (source < null ? (source + 1) : source >> 1);  //  dest_result_addr=1152921509945120148
        // 0x0267299C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x026729A0: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026729A4: LDR x19, [x20, #0xd0]      | X19 = this.screenBlend; //P2            
        // 0x026729A8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x026729AC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026729B0: TBZ w8, #0, #0x26729c0     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x026729B4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026729B8: CBNZ w8, #0x26729c0        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x026729BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_20:
        // 0x026729C0: LDR x1, [sp, #0x28]        | X1 = source;                            
        // 0x026729C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026729C8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026729CC: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x026729D0: MOV x2, x26                | X2 = val_20;//m1                        
        // 0x026729D4: MOV x3, x19                | X3 = this.screenBlend;//m1              
        // 0x026729D8: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_20, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_20, pass:  this.screenBlend);
        // 0x026729DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026729E0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x026729E4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026729E8: MOV w1, w28                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x026729EC: MOV w2, w22                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x026729F0: MOV w4, w23                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x026729F4: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        UnityEngine.RenderTexture val_21 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        // 0x026729F8: LDR x3, [x20, #0xd0]       | X3 = this.screenBlend; //P2             
        // 0x026729FC: MOV x19, x0                | X19 = val_21;//m1                       
        // 0x02672A00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672A04: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672A08: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x02672A0C: MOV x1, x26                | X1 = val_20;//m1                        
        // 0x02672A10: MOV x2, x19                | X2 = val_21;//m1                        
        // 0x02672A14: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_20, mat:  val_21, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_20, mat:  val_21, pass:  this.screenBlend);
        // 0x02672A18: LDR x3, [x20, #0xd0]       | X3 = this.screenBlend; //P2             
        // 0x02672A1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672A20: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672A24: ORR w4, wzr, #6            | W4 = 6(0x6);                            
        // 0x02672A28: MOV x1, x19                | X1 = val_21;//m1                        
        // 0x02672A2C: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x02672A30: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_21, mat:  val_19, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_21, mat:  val_19, pass:  this.screenBlend);
        // 0x02672A34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672A38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672A3C: MOV x1, x19                | X1 = val_21;//m1                        
        // 0x02672A40: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02672A44: B #0x2672a9c               |  goto label_21;                         
        goto label_21;
        label_18:
        // 0x02672A48: STR w19, [sp, #0x14]       | stack[1152921509945120148] = (source < null ? (source + 1) : source >> 1);  //  dest_result_addr=1152921509945120148
        // 0x02672A4C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02672A50: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02672A54: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02672A58: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02672A5C: TBZ w8, #0, #0x2672a6c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_23;
        // 0x02672A60: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02672A64: CBNZ w8, #0x2672a6c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
        // 0x02672A68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_23:
        // 0x02672A6C: LDR x1, [sp, #0x28]        | X1 = source;                            
        // 0x02672A70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672A74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02672A78: MOV x2, x26                | X2 = val_20;//m1                        
        // 0x02672A7C: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  source);
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        // 0x02672A80: LDR x3, [x20, #0xd0]       | X3 = this.screenBlend; //P2             
        // 0x02672A84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672A88: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672A8C: ORR w4, wzr, #6            | W4 = 6(0x6);                            
        // 0x02672A90: MOV x1, x26                | X1 = val_20;//m1                        
        // 0x02672A94: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x02672A98: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_20, mat:  val_19, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_20, mat:  val_19, pass:  this.screenBlend);
        label_21:
        // 0x02672A9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672AA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672AA4: MOV x1, x26                | X1 = val_20;//m1                        
        // 0x02672AA8: SCVTF s8, w27              | S8 = (float)(source);                   
        // 0x02672AAC: SCVTF s9, w25              | S9 = (float)(source);                   
        // 0x02672AB0: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02672AB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672AB8: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02672ABC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672AC0: MOV w1, w28                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02672AC4: MOV w2, w22                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02672AC8: MOV w4, w23                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x02672ACC: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        UnityEngine.RenderTexture val_22 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        // 0x02672AD0: LDP s0, s1, [x20, #0x38]   | S0 = this.bloomThreshhold; //P2  S1 = this.bloomThreshholdColor; //P2  //  | 
        // 0x02672AD4: LDP s2, s3, [x20, #0x40]   |                                          //  | 
        // 0x02672AD8: LDR s4, [x20, #0x48]       | 
        // 0x02672ADC: MOV x27, x0                | X27 = val_22;//m1                       
        // 0x02672AE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672AE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672AE8: BL #0x20d3930              | X0 = UnityEngine.Color.op_Multiply(b:  this.bloomThreshhold, a:  new UnityEngine.Color() {r = this.bloomThreshholdColor});
        UnityEngine.Color val_23 = UnityEngine.Color.op_Multiply(b:  this.bloomThreshhold, a:  new UnityEngine.Color() {r = this.bloomThreshholdColor});
        // 0x02672AEC: MOV x0, x20                | X0 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x02672AF0: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x02672AF4: MOV x2, x27                | X2 = val_22;//m1                        
        // 0x02672AF8: BL #0x26736e0              | this.BrightFilter(threshColor:  new UnityEngine.Color() {r = val_23.r, g = val_23.g, b = val_23.b, a = val_23.a}, from:  val_19, to:  val_22);
        this.BrightFilter(threshColor:  new UnityEngine.Color() {r = val_23.r, g = val_23.g, b = val_23.b, a = val_23.a}, from:  val_19, to:  val_22);
        // 0x02672AFC: LDR w8, [x20, #0x4c]       | W8 = this.bloomBlurIterations; //P2     
        // 0x02672B00: CMP w8, #0                 | STATE = COMPARE(this.bloomBlurIterations, 0x0)
        // 0x02672B04: B.LE #0x2672b18            | if (this.bloomBlurIterations <= 0) goto label_24;
        if(this.bloomBlurIterations <= 0)
        {
            goto label_24;
        }
        // 0x02672B08: CMP w8, #0xb               | STATE = COMPARE(this.bloomBlurIterations, 0xB)
        // 0x02672B0C: B.LT #0x2672b20            | if (this.bloomBlurIterations < 11) goto label_25;
        if(this.bloomBlurIterations < 11)
        {
            goto label_25;
        }
        // 0x02672B10: MOVZ w8, #0xa              | W8 = 10 (0xA);//ML01                    
        // 0x02672B14: B #0x2672b1c               |  goto label_26;                         
        goto label_26;
        label_24:
        // 0x02672B18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        label_26:
        // 0x02672B1C: STR w8, [x20, #0x4c]       | this.bloomBlurIterations = 1;            //  dest_result_addr=1152921509945132476
        this.bloomBlurIterations = 1;
        label_25:
        // 0x02672B20: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x02672B24: LDR s15, [x8, #0xd1c]      | S15 = 0.001953125;                      
        // 0x02672B28: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        // 0x02672B2C: FDIV s14, s8, s9           | S14 = (source / source);                
        float val_24 = (float)source / (float)source;
        // 0x02672B30: FMOV s9, #0.25000000       | S9 = 0.25;                              
        // 0x02672B34: FMOV s10, #1.00000000      | S10 = 1;                                
        val_47 = 1f;
        // 0x02672B38: FMOV s8, wzr               | S8 = 0f;                                
        label_39:
        // 0x02672B3C: LDR s0, [x20, #0x2c]       | S0 = this.sepBlurSpread; //P2           
        // 0x02672B40: SCVTF s1, w21              | S1 = 0;                                 
        float val_43 = 0f;
        // 0x02672B44: FMUL s1, s1, s9            | S1 = (0f * 0.25f);                      
        val_43 = val_43 * 0.25f;
        // 0x02672B48: FADD s1, s1, s10           | S1 = ((0f * 0.25f) + val_47);           
        val_43 = val_43 + val_47;
        // 0x02672B4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672B50: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02672B54: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672B58: MOV w1, w28                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02672B5C: MOV w2, w22                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02672B60: MOV w4, w23                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x02672B64: FMUL s11, s1, s0           | S11 = (((0f * 0.25f) + val_47) * this.sepBlurSpread);
        float val_25 = val_43 * this.sepBlurSpread;
        // 0x02672B68: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        UnityEngine.RenderTexture val_26 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        // 0x02672B6C: LDR x26, [x20, #0xe0]      | X26 = this.blurAndFlaresMaterial; //P2  
        // 0x02672B70: MOV x25, x0                | X25 = val_26;//m1                       
        // 0x02672B74: FMUL s1, s11, s15          | S1 = ((((0f * 0.25f) + val_47) * this.sepBlurSpread) * 0.001953125f);
        val_43 = val_25 * 0.001953125f;
        // 0x02672B78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672B7C: ADD x0, sp, #0x60          | X0 = (1152921509945120128 + 96) = 1152921509945120224 (0x100000013E2F95E0);
        // 0x02672B80: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x02672B84: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x02672B88: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x02672B8C: STP xzr, xzr, [sp, #0x60]  | stack[1152921509945120224] = 0x0;  stack[1152921509945120232] = 0x0;  //  dest_result_addr=1152921509945120224 |  dest_result_addr=1152921509945120232
        // 0x02672B90: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02672B94: CBNZ x26, #0x2672b9c       | if (this.blurAndFlaresMaterial != null) goto label_27;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_27;
        }
        // 0x02672B98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E2F95E0, ????);
        label_27:
        // 0x02672B9C: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x02672BA0: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921509944948080)("_Offsets");
        // 0x02672BA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672BA8: MOV x0, x26                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02672BAC: LDR x1, [x8]               | X1 = "_Offsets";                        
        // 0x02672BB0: LDP s0, s1, [sp, #0x60]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02672BB4: LDP s2, s3, [sp, #0x68]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02672BB8: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02672BBC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02672BC0: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02672BC4: LDR x19, [x20, #0xe0]      | X19 = this.blurAndFlaresMaterial; //P2  
        // 0x02672BC8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02672BCC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02672BD0: TBZ w8, #0, #0x2672be0     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_29;
        // 0x02672BD4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02672BD8: CBNZ w8, #0x2672be0        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
        // 0x02672BDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_29:
        // 0x02672BE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672BE4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672BE8: ORR w4, wzr, #4            | W4 = 4(0x4);                            
        // 0x02672BEC: MOV x1, x27                | X1 = val_22;//m1                        
        // 0x02672BF0: MOV x2, x25                | X2 = val_26;//m1                        
        // 0x02672BF4: MOV x3, x19                | X3 = this.blurAndFlaresMaterial;//m1    
        // 0x02672BF8: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_22, mat:  val_26, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_22, mat:  val_26, pass:  this.blurAndFlaresMaterial);
        // 0x02672BFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672C00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672C04: MOV x1, x27                | X1 = val_22;//m1                        
        // 0x02672C08: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02672C0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672C10: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02672C14: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672C18: MOV w1, w28                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02672C1C: MOV w2, w22                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02672C20: MOV w4, w23                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x02672C24: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        UnityEngine.RenderTexture val_27 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        // 0x02672C28: LDR x26, [x20, #0xe0]      | X26 = this.blurAndFlaresMaterial; //P2  
        // 0x02672C2C: FDIV s0, s11, s14          | S0 = ((((0f * 0.25f) + val_47) * this.sepBlurSpread) / (source / source));
        float val_28 = val_25 / val_24;
        // 0x02672C30: MOV x27, x0                | X27 = val_27;//m1                       
        // 0x02672C34: FMUL s0, s0, s15           | S0 = (((((0f * 0.25f) + val_47) * this.sepBlurSpread) / (source / source)) * 0.001953125f);
        val_28 = val_28 * 0.001953125f;
        // 0x02672C38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672C3C: ADD x0, sp, #0x50          | X0 = (1152921509945120128 + 80) = 1152921509945120208 (0x100000013E2F95D0);
        // 0x02672C40: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x02672C44: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x02672C48: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x02672C4C: STP xzr, xzr, [sp, #0x50]  | stack[1152921509945120208] = 0x0;  stack[1152921509945120216] = 0x0;  //  dest_result_addr=1152921509945120208 |  dest_result_addr=1152921509945120216
        // 0x02672C50: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02672C54: CBNZ x26, #0x2672c5c       | if (this.blurAndFlaresMaterial != null) goto label_30;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_30;
        }
        // 0x02672C58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E2F95D0, ????);
        label_30:
        // 0x02672C5C: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x02672C60: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921509944948080)("_Offsets");
        // 0x02672C64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672C68: MOV x0, x26                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02672C6C: LDR x1, [x8]               | X1 = "_Offsets";                        
        // 0x02672C70: LDP s0, s1, [sp, #0x50]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02672C74: LDP s2, s3, [sp, #0x58]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02672C78: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02672C7C: LDR x3, [x20, #0xe0]       | X3 = this.blurAndFlaresMaterial; //P2   
        // 0x02672C80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672C84: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672C88: ORR w4, wzr, #4            | W4 = 4(0x4);                            
        // 0x02672C8C: MOV x1, x25                | X1 = val_26;//m1                        
        // 0x02672C90: MOV x2, x27                | X2 = val_27;//m1                        
        // 0x02672C94: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_26, mat:  val_27, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_26, mat:  val_27, pass:  this.blurAndFlaresMaterial);
        // 0x02672C98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672C9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672CA0: MOV x1, x25                | X1 = val_26;//m1                        
        // 0x02672CA4: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02672CA8: LDR w8, [x20, #0x30]       | W8 = this.quality; //P2                 
        // 0x02672CAC: CMP w8, #1                 | STATE = COMPARE(this.quality, 0x1)      
        // 0x02672CB0: B.LT #0x2672d74            | if (this.quality < 0x1) goto label_36;  
        if(this.quality < 1)
        {
            goto label_36;
        }
        // 0x02672CB4: CBZ w21, #0x2672d10        | if (0x0 == 0) goto label_32;            
        if(0 == 0)
        {
            goto label_32;
        }
        // 0x02672CB8: CBNZ x24, #0x2672cc0       | if (val_19 != null) goto label_33;      
        if(val_19 != null)
        {
            goto label_33;
        }
        // 0x02672CBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_33:
        // 0x02672CC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672CC4: MOV x0, x24                | X0 = val_19;//m1                        
        // 0x02672CC8: BL #0x1b8a2d0              | val_19.MarkRestoreExpected();           
        val_19.MarkRestoreExpected();
        // 0x02672CCC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02672CD0: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02672CD4: LDR x19, [x20, #0xd0]      | X19 = this.screenBlend; //P2            
        // 0x02672CD8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02672CDC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02672CE0: TBZ w8, #0, #0x2672cf0     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_35;
        // 0x02672CE4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02672CE8: CBNZ w8, #0x2672cf0        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
        // 0x02672CEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_35:
        // 0x02672CF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672CF4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672CF8: MOVZ w4, #0xa              | W4 = 10 (0xA);//ML01                    
        // 0x02672CFC: MOV x1, x27                | X1 = val_27;//m1                        
        // 0x02672D00: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x02672D04: MOV x3, x19                | X3 = this.screenBlend;//m1              
        // 0x02672D08: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_27, mat:  val_19, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_27, mat:  val_19, pass:  this.screenBlend);
        // 0x02672D0C: B #0x2672d74               |  goto label_36;                         
        goto label_36;
        label_32:
        // 0x02672D10: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02672D14: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02672D18: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02672D1C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02672D20: TBZ w8, #0, #0x2672d30     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_38;
        // 0x02672D24: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02672D28: CBNZ w8, #0x2672d30        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
        // 0x02672D2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_38:
        // 0x02672D30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672D34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672D38: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x02672D3C: BL #0x1a6d524              | UnityEngine.Graphics.SetRenderTarget(rt:  0);
        UnityEngine.Graphics.SetRenderTarget(rt:  0);
        // 0x02672D40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672D44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672D48: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
        UnityEngine.Color val_29 = UnityEngine.Color.black;
        // 0x02672D4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672D50: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02672D54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02672D58: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02672D5C: BL #0x1a66470              | UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_29.r, g = val_29.g, b = val_29.b, a = val_29.a});
        UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_29.r, g = val_29.g, b = val_29.b, a = val_29.a});
        // 0x02672D60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672D64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02672D68: MOV x1, x27                | X1 = val_27;//m1                        
        // 0x02672D6C: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x02672D70: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  val_27);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_27);
        label_36:
        // 0x02672D74: LDR w8, [x20, #0x4c]       | W8 = this.bloomBlurIterations; //P2     
        // 0x02672D78: ADD w21, w21, #1           | W21 = (0 + 1) = val_48 (0x00000001);    
        val_48 = 1;
        // 0x02672D7C: CMP w21, w8                | STATE = COMPARE(0x1, this.bloomBlurIterations)
        // 0x02672D80: B.LT #0x2672b3c            | if (val_48 < this.bloomBlurIterations) goto label_39;
        if(val_48 < this.bloomBlurIterations)
        {
            goto label_39;
        }
        // 0x02672D84: LDR w8, [x20, #0x30]       | W8 = this.quality; //P2                 
        // 0x02672D88: LDR w25, [sp, #0x24]       | W25 = (source < null ? (source + 1) : source >> 1);
        // 0x02672D8C: CMP w8, #1                 | STATE = COMPARE(this.quality, 0x1)      
        // 0x02672D90: B.LT #0x2672e00            | if (this.quality < 0x1) goto label_40;  
        if(this.quality < 1)
        {
            goto label_40;
        }
        // 0x02672D94: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02672D98: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02672D9C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02672DA0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02672DA4: TBZ w8, #0, #0x2672db4     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_42;
        // 0x02672DA8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02672DAC: CBNZ w8, #0x2672db4        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_42;
        // 0x02672DB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_42:
        // 0x02672DB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672DB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672DBC: MOV x1, x27                | X1 = val_27;//m1                        
        // 0x02672DC0: BL #0x1a6d524              | UnityEngine.Graphics.SetRenderTarget(rt:  0);
        UnityEngine.Graphics.SetRenderTarget(rt:  0);
        // 0x02672DC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672DC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672DCC: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
        UnityEngine.Color val_30 = UnityEngine.Color.black;
        // 0x02672DD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672DD4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02672DD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02672DDC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02672DE0: BL #0x1a66470              | UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_30.r, g = val_30.g, b = val_30.b, a = val_30.a});
        UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_30.r, g = val_30.g, b = val_30.b, a = val_30.a});
        // 0x02672DE4: LDR x3, [x20, #0xd0]       | X3 = this.screenBlend; //P2             
        // 0x02672DE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672DEC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672DF0: ORR w4, wzr, #6            | W4 = 6(0x6);                            
        // 0x02672DF4: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x02672DF8: MOV x2, x27                | X2 = val_27;//m1                        
        // 0x02672DFC: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_27, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_27, pass:  this.screenBlend);
        label_40:
        // 0x02672E00: ADRP x19, #0x363f000       | X19 = 56881152 (0x363F000);             
        // 0x02672E04: LDR x19, [x19, #0x3b0]     | X19 = 1152921504695345152;              
        // 0x02672E08: LDR s8, [x20, #0x60]       | S8 = this.lensflareIntensity; //P2      
        // 0x02672E0C: LDR x0, [x19]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x02672E10: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x02672E14: TBZ w8, #0, #0x2672e28     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_44;
        // 0x02672E18: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x02672E1C: CBNZ w8, #0x2672e28        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
        // 0x02672E20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        // 0x02672E24: LDR x0, [x19]              | X0 = typeof(UnityEngine.Mathf);         
        label_44:
        // 0x02672E28: LDR x8, [x0, #0xa0]        | X8 = UnityEngine.Mathf.__il2cppRuntimeField_static_fields;
        // 0x02672E2C: LDR s0, [x8]               | S0 = UnityEngine.Mathf.Epsilon;         
        // 0x02672E30: FCMP s8, s0                | STATE = COMPARE(this.lensflareIntensity, UnityEngine.Mathf.Epsilon)
        // 0x02672E34: B.LS #0x2673568            | if (this.lensflareIntensity <= UnityEngine.Mathf.Epsilon) goto label_45;
        if(this.lensflareIntensity <= UnityEngine.Mathf.Epsilon)
        {
            goto label_45;
        }
        // 0x02672E38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672E3C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02672E40: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672E44: MOV w1, w28                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02672E48: MOV w2, w22                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02672E4C: MOV w4, w23                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x02672E50: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        UnityEngine.RenderTexture val_31 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_15, depthBuffer:  val_18, format:  0);
        // 0x02672E54: LDR w8, [x20, #0x58]       | W8 = this.lensflareMode; //P2           
        // 0x02672E58: MOV x28, x0                | X28 = val_31;//m1                       
        // 0x02672E5C: CBZ w8, #0x267338c         | if (this.lensflareMode == 0) goto label_46;
        if(this.lensflareMode == 0)
        {
            goto label_46;
        }
        // 0x02672E60: LDR x0, [x19]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x02672E64: LDR s8, [x20, #0x54]       | S8 = this.flareRotation; //P2           
        // 0x02672E68: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x02672E6C: TBZ w8, #0, #0x2672e7c     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_48;
        // 0x02672E70: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x02672E74: CBNZ w8, #0x2672e7c        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_48;
        // 0x02672E78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_48:
        // 0x02672E7C: MOV v0.16b, v8.16b         | V0 = this.flareRotation;//m1            
        // 0x02672E80: BL #0x981480               | X0 = sub_981480( ?? typeof(UnityEngine.Mathf), ????);
        // 0x02672E84: LDR s1, [x20, #0x54]       | S1 = this.flareRotation; //P2           
        // 0x02672E88: MOV v8.16b, v0.16b         | V8 = this.flareRotation;//m1            
        // 0x02672E8C: MOV v0.16b, v1.16b         | V0 = this.flareRotation;//m1            
        // 0x02672E90: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
        // 0x02672E94: LDR s1, [x20, #0x5c]       | S1 = this.hollyStretchWidth; //P2       
        // 0x02672E98: MOV v9.16b, v0.16b         | V9 = this.flareRotation;//m1            
        // 0x02672E9C: FMOV s2, wzr               | S2 = 0f;                                
        // 0x02672EA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672EA4: STR s1, [sp, #0x10]        | stack[1152921509945120144] = this.hollyStretchWidth;  //  dest_result_addr=1152921509945120144
        // 0x02672EA8: LDR x22, [x20, #0xe0]      | X22 = this.blurAndFlaresMaterial; //P2  
        // 0x02672EAC: ADD x0, sp, #0x60          | X0 = (1152921509945120128 + 96) = 1152921509945120224 (0x100000013E2F95E0);
        // 0x02672EB0: MOV v0.16b, v8.16b         | V0 = this.flareRotation;//m1            
        // 0x02672EB4: MOV v1.16b, v9.16b         | V1 = this.flareRotation;//m1            
        // 0x02672EB8: MOV v3.16b, v2.16b         | V3 = 0;//m1                             
        // 0x02672EBC: STP xzr, xzr, [sp, #0x60]  | stack[1152921509945120224] = 0x0;  stack[1152921509945120232] = 0x0;  //  dest_result_addr=1152921509945120224 |  dest_result_addr=1152921509945120232
        // 0x02672EC0: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02672EC4: CBNZ x22, #0x2672ecc       | if (this.blurAndFlaresMaterial != null) goto label_49;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_49;
        }
        // 0x02672EC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E2F95E0, ????);
        label_49:
        // 0x02672ECC: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x02672ED0: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921509944948080)("_Offsets");
        // 0x02672ED4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672ED8: MOV x0, x22                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02672EDC: LDR x1, [x8]               | X1 = "_Offsets";                        
        // 0x02672EE0: LDP s0, s1, [sp, #0x60]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02672EE4: LDP s2, s3, [sp, #0x68]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02672EE8: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02672EEC: LDR s0, [x20, #0x64]       | S0 = this.lensflareThreshhold; //P2     
        // 0x02672EF0: LDR x22, [x20, #0xe0]      | X22 = this.blurAndFlaresMaterial; //P2  
        // 0x02672EF4: FMOV s2, wzr               | S2 = 0f;                                
        // 0x02672EF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672EFC: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x02672F00: ADD x0, sp, #0x50          | X0 = (1152921509945120128 + 80) = 1152921509945120208 (0x100000013E2F95D0);
        // 0x02672F04: MOV v3.16b, v2.16b         | V3 = 0;//m1                             
        // 0x02672F08: STP xzr, xzr, [sp, #0x50]  | stack[1152921509945120208] = 0x0;  stack[1152921509945120216] = 0x0;  //  dest_result_addr=1152921509945120208 |  dest_result_addr=1152921509945120216
        // 0x02672F0C: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02672F10: CBNZ x22, #0x2672f18       | if (this.blurAndFlaresMaterial != null) goto label_50;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_50;
        }
        // 0x02672F14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E2F95D0, ????);
        label_50:
        // 0x02672F18: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
        // 0x02672F1C: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509944997328)("_Threshhold");
        // 0x02672F20: LDP s0, s1, [sp, #0x50]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02672F24: LDP s2, s3, [sp, #0x58]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02672F28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672F2C: LDR x1, [x8]               | X1 = "_Threshhold";                     
        // 0x02672F30: MOV x0, x22                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02672F34: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_Threshhold", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurAndFlaresMaterial.SetVector(name:  "_Threshhold", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02672F38: LDR x22, [x20, #0xe0]      | X22 = this.blurAndFlaresMaterial; //P2  
        // 0x02672F3C: LDP s0, s1, [x20, #0x6c]   | S0 = this.flareColorA; //P2              //  | 
        // 0x02672F40: LDP s2, s3, [x20, #0x74]   |                                          //  | 
        // 0x02672F44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672F48: ADD x0, sp, #0x40          | X0 = (1152921509945120128 + 64) = 1152921509945120192 (0x100000013E2F95C0);
        // 0x02672F4C: STP xzr, xzr, [sp, #0x40]  | stack[1152921509945120192] = 0x0;  stack[1152921509945120200] = 0x0;  //  dest_result_addr=1152921509945120192 |  dest_result_addr=1152921509945120200
        // 0x02672F50: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02672F54: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x02672F58: LDR x8, [x8, #0xb10]       | X8 = 1152921504708763648;               
        // 0x02672F5C: LDR s10, [x20, #0x78]      | 
        // 0x02672F60: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector4);       
        // 0x02672F64: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector4.__il2cppRuntimeField_10A;
        // 0x02672F68: TBZ w8, #0, #0x2672f78     | if (UnityEngine.Vector4.__il2cppRuntimeField_has_cctor == 0) goto label_52;
        // 0x02672F6C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished;
        // 0x02672F70: CBNZ w8, #0x2672f78        | if (UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished != 0) goto label_52;
        // 0x02672F74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector4), ????);
        label_52:
        // 0x02672F78: LDP s0, s1, [sp, #0x40]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02672F7C: LDP s2, s3, [sp, #0x48]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02672F80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672F84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672F88: MOV v4.16b, v10.16b        | V4 = 1;//m1                             
        // 0x02672F8C: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  val_47);
        UnityEngine.Vector4 val_32 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  val_47);
        // 0x02672F90: LDR s4, [x20, #0x60]       | S4 = this.lensflareIntensity; //P2      
        // 0x02672F94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672F98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02672F9C: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = val_32.x, y = val_32.y, z = val_32.z, w = val_32.w}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_33 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = val_32.x, y = val_32.y, z = val_32.z, w = val_32.w}, d:  this.lensflareIntensity);
        // 0x02672FA0: MOV v10.16b, v0.16b        | V10 = val_33.x;//m1                     
        // 0x02672FA4: MOV v11.16b, v1.16b        | V11 = val_33.y;//m1                     
        // 0x02672FA8: MOV v12.16b, v2.16b        | V12 = val_33.z;//m1                     
        val_49 = val_33.z;
        // 0x02672FAC: MOV v13.16b, v3.16b        | V13 = val_33.w;//m1                     
        // 0x02672FB0: CBNZ x22, #0x2672fb8       | if (this.blurAndFlaresMaterial != null) goto label_53;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_53;
        }
        // 0x02672FB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_53:
        // 0x02672FB8: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
        // 0x02672FBC: LDR x8, [x8, #0x7a8]       | X8 = (string**)(1152921509945001520)("_TintColor");
        // 0x02672FC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672FC4: MOV x0, x22                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02672FC8: MOV v0.16b, v10.16b        | V0 = val_33.x;//m1                      
        // 0x02672FCC: LDR x1, [x8]               | X1 = "_TintColor";                      
        // 0x02672FD0: MOV v1.16b, v11.16b        | V1 = val_33.y;//m1                      
        // 0x02672FD4: MOV v2.16b, v12.16b        | V2 = val_33.z;//m1                      
        // 0x02672FD8: MOV v3.16b, v13.16b        | V3 = val_33.w;//m1                      
        // 0x02672FDC: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_TintColor", value:  new UnityEngine.Vector4() {x = val_33.x, y = val_33.y, z = val_49, w = val_33.w});
        this.blurAndFlaresMaterial.SetVector(name:  "_TintColor", value:  new UnityEngine.Vector4() {x = val_33.x, y = val_33.y, z = val_49, w = val_33.w});
        // 0x02672FE0: LDR x19, [x20, #0xe0]      | X19 = this.blurAndFlaresMaterial; //P2  
        // 0x02672FE4: LDR s10, [x20, #0x68]      | S10 = this.lensFlareSaturation; //P2    
        // 0x02672FE8: CBNZ x19, #0x2672ff0       | if (this.blurAndFlaresMaterial != null) goto label_54;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_54;
        }
        // 0x02672FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurAndFlaresMaterial, ????);
        label_54:
        // 0x02672FF0: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x02672FF4: LDR x8, [x8, #0xfa0]       | X8 = (string**)(1152921509945005712)("_Saturation");
        // 0x02672FF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672FFC: MOV x0, x19                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02673000: MOV v0.16b, v10.16b        | V0 = this.lensFlareSaturation;//m1      
        // 0x02673004: LDR x1, [x8]               | X1 = "_Saturation";                     
        // 0x02673008: BL #0x1a79ef8              | this.blurAndFlaresMaterial.SetFloat(name:  "_Saturation", value:  this.lensFlareSaturation);
        this.blurAndFlaresMaterial.SetFloat(name:  "_Saturation", value:  this.lensFlareSaturation);
        // 0x0267300C: CBNZ x24, #0x2673014       | if (val_19 != null) goto label_55;      
        if(val_19 != null)
        {
            goto label_55;
        }
        // 0x02673010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurAndFlaresMaterial, ????);
        label_55:
        // 0x02673014: LDR s0, [sp, #0x10]        | S0 = this.hollyStretchWidth;            
        float val_44 = this.hollyStretchWidth;
        // 0x02673018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267301C: MOV x0, x24                | X0 = val_19;//m1                        
        // 0x02673020: FDIV s10, s0, s14          | S10 = (this.hollyStretchWidth / (source / source));
        float val_34 = val_44 / val_24;
        // 0x02673024: BL #0x1b8a1e0              | val_19.DiscardContents();               
        val_19.DiscardContents();
        // 0x02673028: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0267302C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02673030: LDR x22, [x20, #0xe0]      | X22 = this.blurAndFlaresMaterial; //P2  
        // 0x02673034: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02673038: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0267303C: TBZ w8, #0, #0x267304c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_57;
        // 0x02673040: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02673044: CBNZ w8, #0x267304c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_57;
        // 0x02673048: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_57:
        // 0x0267304C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673050: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673054: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x02673058: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x0267305C: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x02673060: MOV x3, x22                | X3 = this.blurAndFlaresMaterial;//m1    
        // 0x02673064: FMUL s10, s10, s15         | S10 = ((this.hollyStretchWidth / (source / source)) * 0.001953125f);
        val_34 = val_34 * 0.001953125f;
        // 0x02673068: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        // 0x0267306C: CBNZ x28, #0x2673074       | if (val_31 != null) goto label_58;      
        if(val_31 != null)
        {
            goto label_58;
        }
        // 0x02673070: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_58:
        // 0x02673074: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673078: MOV x0, x28                | X0 = val_31;//m1                        
        // 0x0267307C: BL #0x1b8a1e0              | val_31.DiscardContents();               
        val_31.DiscardContents();
        // 0x02673080: LDR x3, [x20, #0xe0]       | X3 = this.blurAndFlaresMaterial; //P2   
        // 0x02673084: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673088: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x0267308C: ORR w4, wzr, #3            | W4 = 3(0x3);                            
        // 0x02673090: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x02673094: MOV x2, x28                | X2 = val_31;//m1                        
        // 0x02673098: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_31, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_31, pass:  this.blurAndFlaresMaterial);
        // 0x0267309C: LDR x22, [x20, #0xe0]      | X22 = this.blurAndFlaresMaterial; //P2  
        // 0x026730A0: FMOV s2, wzr               | S2 = 0f;                                
        // 0x026730A4: FMUL s0, s8, s10           | S0 = (this.flareRotation * ((this.hollyStretchWidth / (source / source)) * 0.001953125f));
        val_44 = this.flareRotation * val_34;
        // 0x026730A8: FMUL s1, s9, s10           | S1 = (this.flareRotation * ((this.hollyStretchWidth / (source / source)) * 0.001953125f));
        float val_35 = this.flareRotation * val_34;
        // 0x026730AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026730B0: ADD x0, sp, #0x30          | X0 = (1152921509945120128 + 48) = 1152921509945120176 (0x100000013E2F95B0);
        // 0x026730B4: MOV v3.16b, v2.16b         | V3 = 0;//m1                             
        // 0x026730B8: STP xzr, xzr, [sp, #0x30]  | stack[1152921509945120176] = 0x0;  stack[1152921509945120184] = 0x0;  //  dest_result_addr=1152921509945120176 |  dest_result_addr=1152921509945120184
        // 0x026730BC: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026730C0: CBNZ x22, #0x26730c8       | if (this.blurAndFlaresMaterial != null) goto label_59;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_59;
        }
        // 0x026730C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E2F95B0, ????);
        label_59:
        // 0x026730C8: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x026730CC: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921509944948080)("_Offsets");
        // 0x026730D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026730D4: MOV x0, x22                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x026730D8: LDR x1, [x8]               | X1 = "_Offsets";                        
        // 0x026730DC: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x026730E0: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x026730E4: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x026730E8: LDR x19, [x20, #0xe0]      | X19 = this.blurAndFlaresMaterial; //P2  
        // 0x026730EC: LDR s10, [x20, #0x5c]      | S10 = this.hollyStretchWidth; //P2      
        // 0x026730F0: CBNZ x19, #0x26730f8       | if (this.blurAndFlaresMaterial != null) goto label_60;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_60;
        }
        // 0x026730F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurAndFlaresMaterial, ????);
        label_60:
        // 0x026730F8: ADRP x21, #0x360f000       | X21 = 56684544 (0x360F000);             
        // 0x026730FC: LDR x21, [x21, #0x180]     | X21 = (string**)(1152921509945022192)("_StretchWidth");
        val_48 = "_StretchWidth";
        // 0x02673100: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673104: MOV x0, x19                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02673108: MOV v0.16b, v10.16b        | V0 = this.hollyStretchWidth;//m1        
        // 0x0267310C: LDR x1, [x21]              | X1 = "_StretchWidth";                   
        // 0x02673110: BL #0x1a79ef8              | this.blurAndFlaresMaterial.SetFloat(name:  "_StretchWidth", value:  this.hollyStretchWidth);
        this.blurAndFlaresMaterial.SetFloat(name:  "_StretchWidth", value:  this.hollyStretchWidth);
        // 0x02673114: CBNZ x24, #0x267311c       | if (val_19 != null) goto label_61;      
        if(val_19 != null)
        {
            goto label_61;
        }
        // 0x02673118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurAndFlaresMaterial, ????);
        label_61:
        // 0x0267311C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673120: MOV x0, x24                | X0 = val_19;//m1                        
        // 0x02673124: BL #0x1b8a1e0              | val_19.DiscardContents();               
        val_19.DiscardContents();
        // 0x02673128: LDR x3, [x20, #0xe0]       | X3 = this.blurAndFlaresMaterial; //P2   
        // 0x0267312C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673130: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673134: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x02673138: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x0267313C: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x02673140: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        // 0x02673144: LDR x19, [x20, #0xe0]      | X19 = this.blurAndFlaresMaterial; //P2  
        // 0x02673148: LDR s10, [x20, #0x5c]      | S10 = this.hollyStretchWidth; //P2      
        // 0x0267314C: CBNZ x19, #0x2673154       | if (this.blurAndFlaresMaterial != null) goto label_62;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_62;
        }
        // 0x02673150: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_62:
        // 0x02673154: LDR x1, [x21]              | X1 = "_StretchWidth";                   
        // 0x02673158: FADD s0, s10, s10          | S0 = (this.hollyStretchWidth + this.hollyStretchWidth);
        float val_36 = this.hollyStretchWidth + this.hollyStretchWidth;
        // 0x0267315C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673160: MOV x0, x19                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02673164: BL #0x1a79ef8              | this.blurAndFlaresMaterial.SetFloat(name:  "_StretchWidth", value:  float val_36 = this.hollyStretchWidth + this.hollyStretchWidth);
        this.blurAndFlaresMaterial.SetFloat(name:  "_StretchWidth", value:  val_36);
        // 0x02673168: CBNZ x28, #0x2673170       | if (val_31 != null) goto label_63;      
        if(val_31 != null)
        {
            goto label_63;
        }
        // 0x0267316C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurAndFlaresMaterial, ????);
        label_63:
        // 0x02673170: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673174: MOV x0, x28                | X0 = val_31;//m1                        
        // 0x02673178: BL #0x1b8a1e0              | val_31.DiscardContents();               
        val_31.DiscardContents();
        // 0x0267317C: LDR x3, [x20, #0xe0]       | X3 = this.blurAndFlaresMaterial; //P2   
        // 0x02673180: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673184: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673188: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x0267318C: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x02673190: MOV x2, x28                | X2 = val_31;//m1                        
        // 0x02673194: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_31, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_31, pass:  this.blurAndFlaresMaterial);
        // 0x02673198: LDR x19, [x20, #0xe0]      | X19 = this.blurAndFlaresMaterial; //P2  
        // 0x0267319C: LDR s10, [x20, #0x5c]      | S10 = this.hollyStretchWidth; //P2      
        val_47 = this.hollyStretchWidth;
        // 0x026731A0: CBNZ x19, #0x26731a8       | if (this.blurAndFlaresMaterial != null) goto label_64;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_64;
        }
        // 0x026731A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_64:
        // 0x026731A8: LDR x1, [x21]              | X1 = "_StretchWidth";                   
        // 0x026731AC: FMOV s0, #4.00000000       | S0 = 4;                                 
        float val_45 = 4f;
        // 0x026731B0: FMUL s0, s10, s0           | S0 = (this.hollyStretchWidth * 4f);     
        val_45 = val_47 * val_45;
        // 0x026731B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026731B8: MOV x0, x19                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x026731BC: BL #0x1a79ef8              | this.blurAndFlaresMaterial.SetFloat(name:  "_StretchWidth", value:  4f = val_47 * 4f);
        this.blurAndFlaresMaterial.SetFloat(name:  "_StretchWidth", value:  val_45);
        // 0x026731C0: CBNZ x24, #0x26731c8       | if (val_19 != null) goto label_65;      
        if(val_19 != null)
        {
            goto label_65;
        }
        // 0x026731C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurAndFlaresMaterial, ????);
        label_65:
        // 0x026731C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026731CC: MOV x0, x24                | X0 = val_19;//m1                        
        // 0x026731D0: BL #0x1b8a1e0              | val_19.DiscardContents();               
        val_19.DiscardContents();
        // 0x026731D4: LDR x3, [x20, #0xe0]       | X3 = this.blurAndFlaresMaterial; //P2   
        // 0x026731D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026731DC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026731E0: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x026731E4: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x026731E8: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x026731EC: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        // 0x026731F0: LDR w8, [x20, #0x50]       | W8 = this.hollywoodFlareBlurIterations; //P2 
        // 0x026731F4: CMP w8, #1                 | STATE = COMPARE(this.hollywoodFlareBlurIterations, 0x1)
        // 0x026731F8: B.LT #0x2673348            | if (this.hollywoodFlareBlurIterations < 1) goto label_66;
        if(this.hollywoodFlareBlurIterations < 1)
        {
            goto label_66;
        }
        // 0x026731FC: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        // 0x02673200: FMOV s10, wzr              | S10 = 0f;                               
        val_47 = 0f;
        label_73:
        // 0x02673204: LDR s0, [x20, #0x5c]       | S0 = this.hollyStretchWidth; //P2       
        float val_46 = this.hollyStretchWidth;
        // 0x02673208: LDR x22, [x20, #0xe0]      | X22 = this.blurAndFlaresMaterial; //P2  
        // 0x0267320C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673210: ADD x0, sp, #0x60          | X0 = (1152921509945120128 + 96) = 1152921509945120224 (0x100000013E2F95E0);
        // 0x02673214: FADD s0, s0, s0            | S0 = (this.hollyStretchWidth + this.hollyStretchWidth);
        val_46 = val_46 + val_46;
        // 0x02673218: FDIV s0, s0, s14           | S0 = ((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source));
        val_46 = val_46 / val_24;
        // 0x0267321C: FMUL s0, s0, s15           | S0 = (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f);
        val_46 = val_46 * 0.001953125f;
        // 0x02673220: FMUL s12, s8, s0           | S12 = (this.flareRotation * (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f));
        val_49 = this.flareRotation * val_46;
        // 0x02673224: FMUL s11, s9, s0           | S11 = (this.flareRotation * (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f));
        float val_37 = this.flareRotation * val_46;
        // 0x02673228: MOV v0.16b, v12.16b        | V0 = (this.flareRotation * (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f));//m1
        // 0x0267322C: MOV v1.16b, v11.16b        | V1 = (this.flareRotation * (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f));//m1
        // 0x02673230: MOV v2.16b, v10.16b        | V2 = 0;//m1                             
        // 0x02673234: MOV v3.16b, v10.16b        | V3 = 0;//m1                             
        // 0x02673238: STP xzr, xzr, [sp, #0x60]  | stack[1152921509945120224] = 0x0;  stack[1152921509945120232] = 0x0;  //  dest_result_addr=1152921509945120224 |  dest_result_addr=1152921509945120232
        // 0x0267323C: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02673240: CBNZ x22, #0x2673248       | if (this.blurAndFlaresMaterial != null) goto label_67;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_67;
        }
        // 0x02673244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E2F95E0, ????);
        label_67:
        // 0x02673248: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x0267324C: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921509944948080)("_Offsets");
        // 0x02673250: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673254: MOV x0, x22                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02673258: LDR x1, [x8]               | X1 = "_Offsets";                        
        // 0x0267325C: LDP s0, s1, [sp, #0x60]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02673260: LDP s2, s3, [sp, #0x68]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02673264: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02673268: CBNZ x28, #0x2673270       | if (val_31 != null) goto label_68;      
        if(val_31 != null)
        {
            goto label_68;
        }
        // 0x0267326C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurAndFlaresMaterial, ????);
        label_68:
        // 0x02673270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673274: MOV x0, x28                | X0 = val_31;//m1                        
        // 0x02673278: BL #0x1b8a1e0              | val_31.DiscardContents();               
        val_31.DiscardContents();
        // 0x0267327C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02673280: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02673284: LDR x19, [x20, #0xe0]      | X19 = this.blurAndFlaresMaterial; //P2  
        // 0x02673288: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x0267328C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02673290: TBZ w8, #0, #0x26732a0     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_70;
        // 0x02673294: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02673298: CBNZ w8, #0x26732a0        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_70;
        // 0x0267329C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_70:
        // 0x026732A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026732A4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026732A8: ORR w4, wzr, #4            | W4 = 4(0x4);                            
        // 0x026732AC: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x026732B0: MOV x2, x28                | X2 = val_31;//m1                        
        // 0x026732B4: MOV x3, x19                | X3 = this.blurAndFlaresMaterial;//m1    
        // 0x026732B8: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_31, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_31, pass:  this.blurAndFlaresMaterial);
        // 0x026732BC: LDR x22, [x20, #0xe0]      | X22 = this.blurAndFlaresMaterial; //P2  
        // 0x026732C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026732C4: ADD x0, sp, #0x50          | X0 = (1152921509945120128 + 80) = 1152921509945120208 (0x100000013E2F95D0);
        // 0x026732C8: MOV v0.16b, v12.16b        | V0 = (this.flareRotation * (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f));//m1
        // 0x026732CC: MOV v1.16b, v11.16b        | V1 = (this.flareRotation * (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f));//m1
        // 0x026732D0: MOV v2.16b, v10.16b        | V2 = 0;//m1                             
        // 0x026732D4: MOV v3.16b, v10.16b        | V3 = 0;//m1                             
        // 0x026732D8: STP xzr, xzr, [sp, #0x50]  | stack[1152921509945120208] = 0x0;  stack[1152921509945120216] = 0x0;  //  dest_result_addr=1152921509945120208 |  dest_result_addr=1152921509945120216
        // 0x026732DC: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026732E0: CBNZ x22, #0x26732e8       | if (this.blurAndFlaresMaterial != null) goto label_71;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_71;
        }
        // 0x026732E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E2F95D0, ????);
        label_71:
        // 0x026732E8: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x026732EC: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921509944948080)("_Offsets");
        // 0x026732F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026732F4: MOV x0, x22                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x026732F8: LDR x1, [x8]               | X1 = "_Offsets";                        
        // 0x026732FC: LDP s0, s1, [sp, #0x50]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02673300: LDP s2, s3, [sp, #0x58]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02673304: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02673308: CBNZ x24, #0x2673310       | if (val_19 != null) goto label_72;      
        if(val_19 != null)
        {
            goto label_72;
        }
        // 0x0267330C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurAndFlaresMaterial, ????);
        label_72:
        // 0x02673310: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673314: MOV x0, x24                | X0 = val_19;//m1                        
        // 0x02673318: BL #0x1b8a1e0              | val_19.DiscardContents();               
        val_19.DiscardContents();
        // 0x0267331C: LDR x3, [x20, #0xe0]       | X3 = this.blurAndFlaresMaterial; //P2   
        // 0x02673320: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673324: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673328: ORR w4, wzr, #4            | W4 = 4(0x4);                            
        // 0x0267332C: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x02673330: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x02673334: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        // 0x02673338: LDR w8, [x20, #0x50]       | W8 = this.hollywoodFlareBlurIterations; //P2 
        // 0x0267333C: ADD w21, w21, #1           | W21 = (0 + 1);                          
        val_48 = 0 + 1;
        // 0x02673340: CMP w21, w8                | STATE = COMPARE((0 + 1), this.hollywoodFlareBlurIterations)
        // 0x02673344: B.LT #0x2673204            | if (val_48 < this.hollywoodFlareBlurIterations) goto label_73;
        if(val_48 < this.hollywoodFlareBlurIterations)
        {
            goto label_73;
        }
        label_66:
        // 0x02673348: LDR w8, [x20, #0x58]       | W8 = this.lensflareMode; //P2           
        // 0x0267334C: CMP w8, #1                 | STATE = COMPARE(this.lensflareMode, 0x1)
        // 0x02673350: B.EQ #0x2673374            | if (this.lensflareMode == 0x1) goto label_74;
        if(this.lensflareMode == 1)
        {
            goto label_74;
        }
        // 0x02673354: MOV x0, x20                | X0 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x02673358: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x0267335C: MOV x2, x28                | X2 = val_31;//m1                        
        // 0x02673360: BL #0x26738dc              | this.Vignette(amount:  0f, from:  val_19, to:  val_31);
        this.Vignette(amount:  0f, from:  val_19, to:  val_31);
        // 0x02673364: MOV x0, x20                | X0 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x02673368: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x0267336C: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x02673370: BL #0x2673b18              | this.BlendFlares(from:  val_31, to:  val_19);
        this.BlendFlares(from:  val_31, to:  val_19);
        label_74:
        // 0x02673374: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x02673378: MOV x0, x20                | X0 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x0267337C: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x02673380: MOV x2, x27                | X2 = val_27;//m1                        
        // 0x02673384: BL #0x2673dc4              | this.AddTo(intensity_:  1f, from:  val_19, to:  val_27);
        this.AddTo(intensity_:  1f, from:  val_19, to:  val_27);
        // 0x02673388: B #0x2673558               |  goto label_75;                         
        goto label_75;
        label_46:
        // 0x0267338C: LDR s0, [x20, #0x64]       | S0 = this.lensflareThreshhold; //P2     
        // 0x02673390: MOV x0, x20                | X0 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x02673394: MOV x1, x27                | X1 = val_27;//m1                        
        // 0x02673398: MOV x2, x28                | X2 = val_31;//m1                        
        // 0x0267339C: BL #0x26737ec              | this.BrightFilter(thresh:  this.lensflareThreshhold, from:  val_27, to:  val_31);
        this.BrightFilter(thresh:  this.lensflareThreshhold, from:  val_27, to:  val_31);
        // 0x026733A0: LDR w8, [x20, #0x30]       | W8 = this.quality; //P2                 
        // 0x026733A4: CMP w8, #1                 | STATE = COMPARE(this.quality, 0x1)      
        // 0x026733A8: B.LT #0x2673538            | if (this.quality < 0x1) goto label_76;  
        if(this.quality < 1)
        {
            goto label_76;
        }
        // 0x026733AC: LDR x22, [x20, #0xe0]      | X22 = this.blurAndFlaresMaterial; //P2  
        // 0x026733B0: CBNZ x24, #0x26733b8       | if (val_19 != null) goto label_77;      
        if(val_19 != null)
        {
            goto label_77;
        }
        // 0x026733B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_77:
        // 0x026733B8: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026733BC: MOV x0, x24                | X0 = val_19;//m1                        
        // 0x026733C0: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x026733C4: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x026733C8: SCVTF s0, w0               | S0 = (float)(val_19);                   
        // 0x026733CC: FMOV s8, #1.50000000       | S8 = 1.5;                               
        // 0x026733D0: FDIV s1, s8, s0            | S1 = (1.5f / val_19);                   
        float val_38 = 1.5f / (float)val_19;
        // 0x026733D4: FMOV s0, wzr               | S0 = 0f;                                
        // 0x026733D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026733DC: ADD x0, sp, #0x60          | X0 = (1152921509945120128 + 96) = 1152921509945120224 (0x100000013E2F95E0);
        // 0x026733E0: MOV v2.16b, v0.16b         | V2 = 0;//m1                             
        // 0x026733E4: MOV v3.16b, v0.16b         | V3 = 0;//m1                             
        // 0x026733E8: STP xzr, xzr, [sp, #0x60]  | stack[1152921509945120224] = 0x0;  stack[1152921509945120232] = 0x0;  //  dest_result_addr=1152921509945120224 |  dest_result_addr=1152921509945120232
        // 0x026733EC: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026733F0: CBNZ x22, #0x26733f8       | if (this.blurAndFlaresMaterial != null) goto label_78;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_78;
        }
        // 0x026733F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E2F95E0, ????);
        label_78:
        // 0x026733F8: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x026733FC: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921509944948080)("_Offsets");
        // 0x02673400: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673404: MOV x0, x22                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x02673408: LDR x1, [x8]               | X1 = "_Offsets";                        
        // 0x0267340C: LDP s0, s1, [sp, #0x60]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02673410: LDP s2, s3, [sp, #0x68]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02673414: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02673418: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0267341C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02673420: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02673424: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02673428: TBZ w8, #0, #0x2673438     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_80;
        // 0x0267342C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02673430: CBNZ w8, #0x2673438        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_80;
        // 0x02673434: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_80:
        // 0x02673438: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267343C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673440: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x02673444: BL #0x1a6d524              | UnityEngine.Graphics.SetRenderTarget(rt:  0);
        UnityEngine.Graphics.SetRenderTarget(rt:  0);
        // 0x02673448: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267344C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673450: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
        UnityEngine.Color val_39 = UnityEngine.Color.black;
        // 0x02673454: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673458: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x0267345C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02673460: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02673464: BL #0x1a66470              | UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_39.r, g = val_39.g, b = val_39.b, a = val_39.a});
        UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_39.r, g = val_39.g, b = val_39.b, a = val_39.a});
        // 0x02673468: LDR x3, [x20, #0xe0]       | X3 = this.blurAndFlaresMaterial; //P2   
        // 0x0267346C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673470: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673474: ORR w4, wzr, #4            | W4 = 4(0x4);                            
        // 0x02673478: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x0267347C: MOV x2, x24                | X2 = val_19;//m1                        
        // 0x02673480: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_31, mat:  val_19, pass:  this.blurAndFlaresMaterial);
        // 0x02673484: LDR x22, [x20, #0xe0]      | X22 = this.blurAndFlaresMaterial; //P2  
        // 0x02673488: CBNZ x24, #0x2673490       | if (val_19 != null) goto label_81;      
        if(val_19 != null)
        {
            goto label_81;
        }
        // 0x0267348C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_81:
        // 0x02673490: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02673494: MOV x0, x24                | X0 = val_19;//m1                        
        // 0x02673498: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x0267349C: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x026734A0: SCVTF s0, w0               | S0 = (float)(val_19);                   
        float val_47 = (float)val_19;
        // 0x026734A4: FMOV s1, wzr               | S1 = 0f;                                
        // 0x026734A8: FDIV s0, s8, s0            | S0 = (1.5f / val_19);                   
        val_47 = 1.5f / val_47;
        // 0x026734AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026734B0: ADD x0, sp, #0x50          | X0 = (1152921509945120128 + 80) = 1152921509945120208 (0x100000013E2F95D0);
        // 0x026734B4: MOV v2.16b, v1.16b         | V2 = 0;//m1                             
        // 0x026734B8: MOV v3.16b, v1.16b         | V3 = 0;//m1                             
        // 0x026734BC: STP xzr, xzr, [sp, #0x50]  | stack[1152921509945120208] = 0x0;  stack[1152921509945120216] = 0x0;  //  dest_result_addr=1152921509945120208 |  dest_result_addr=1152921509945120216
        // 0x026734C0: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026734C4: CBNZ x22, #0x26734cc       | if (this.blurAndFlaresMaterial != null) goto label_82;
        if(this.blurAndFlaresMaterial != null)
        {
            goto label_82;
        }
        // 0x026734C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E2F95D0, ????);
        label_82:
        // 0x026734CC: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x026734D0: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921509944948080)("_Offsets");
        // 0x026734D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026734D8: MOV x0, x22                | X0 = this.blurAndFlaresMaterial;//m1    
        // 0x026734DC: LDR x1, [x8]               | X1 = "_Offsets";                        
        // 0x026734E0: LDP s0, s1, [sp, #0x50]    | S0 = 0; S1 = 0;                          //  | 
        // 0x026734E4: LDP s2, s3, [sp, #0x58]    | S2 = 0; S3 = 0;                          //  | 
        // 0x026734E8: BL #0x1a79fa8              | this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurAndFlaresMaterial.SetVector(name:  "_Offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x026734EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026734F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026734F4: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x026734F8: BL #0x1a6d524              | UnityEngine.Graphics.SetRenderTarget(rt:  0);
        UnityEngine.Graphics.SetRenderTarget(rt:  0);
        // 0x026734FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673504: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
        UnityEngine.Color val_40 = UnityEngine.Color.black;
        // 0x02673508: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267350C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02673510: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02673514: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02673518: BL #0x1a66470              | UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_40.r, g = val_40.g, b = val_40.b, a = val_40.a});
        UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_40.r, g = val_40.g, b = val_40.b, a = val_40.a});
        // 0x0267351C: LDR x3, [x20, #0xe0]       | X3 = this.blurAndFlaresMaterial; //P2   
        // 0x02673520: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673524: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673528: ORR w4, wzr, #4            | W4 = 4(0x4);                            
        // 0x0267352C: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x02673530: MOV x2, x28                | X2 = val_31;//m1                        
        // 0x02673534: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_31, pass:  this.blurAndFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_31, pass:  this.blurAndFlaresMaterial);
        label_76:
        // 0x02673538: MOV x0, x20                | X0 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x0267353C: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x02673540: MOV x2, x28                | X2 = val_31;//m1                        
        // 0x02673544: BL #0x26738dc              | this.Vignette(amount:  val_40.r, from:  val_31, to:  val_31);
        this.Vignette(amount:  val_40.r, from:  val_31, to:  val_31);
        // 0x02673548: MOV x0, x20                | X0 = 1152921509945132400 (0x100000013E2FC570);//ML01
        // 0x0267354C: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x02673550: MOV x2, x27                | X2 = val_27;//m1                        
        // 0x02673554: BL #0x2673b18              | this.BlendFlares(from:  val_31, to:  val_27);
        this.BlendFlares(from:  val_31, to:  val_27);
        label_75:
        // 0x02673558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267355C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673560: MOV x1, x28                | X1 = val_31;//m1                        
        // 0x02673564: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        label_45:
        // 0x02673568: LDR x19, [x20, #0xd0]      | X19 = this.screenBlend; //P2            
        // 0x0267356C: LDR s8, [x20, #0x34]       | S8 = this.bloomIntensity; //P2          
        // 0x02673570: CBNZ x19, #0x2673578       | if (this.screenBlend != null) goto label_83;
        if(this.screenBlend != null)
        {
            goto label_83;
        }
        // 0x02673574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_83:
        // 0x02673578: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x0267357C: LDR x8, [x8, #0x720]       | X8 = (string**)(1152921509940329520)("_Intensity");
        // 0x02673580: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673584: MOV x0, x19                | X0 = this.screenBlend;//m1              
        // 0x02673588: MOV v0.16b, v8.16b         | V0 = this.bloomIntensity;//m1           
        // 0x0267358C: LDR x1, [x8]               | X1 = "_Intensity";                      
        // 0x02673590: BL #0x1a79ef8              | this.screenBlend.SetFloat(name:  "_Intensity", value:  this.bloomIntensity);
        this.screenBlend.SetFloat(name:  "_Intensity", value:  this.bloomIntensity);
        // 0x02673594: LDR x19, [x20, #0xd0]      | X19 = this.screenBlend; //P2            
        val_50 = this.screenBlend;
        // 0x02673598: CBNZ x19, #0x26735a0       | if (this.screenBlend != null) goto label_84;
        if(val_50 != null)
        {
            goto label_84;
        }
        // 0x0267359C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.screenBlend, ????);
        label_84:
        // 0x026735A0: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
        // 0x026735A4: LDR x8, [x8, #0xca0]       | X8 = (string**)(1152921509945091920)("_ColorBuffer");
        // 0x026735A8: LDR x2, [sp, #0x28]        | X2 = source;                            
        // 0x026735AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026735B0: MOV x0, x19                | X0 = this.screenBlend;//m1              
        // 0x026735B4: LDR x1, [x8]               | X1 = "_ColorBuffer";                    
        // 0x026735B8: BL #0x1a780c4              | this.screenBlend.SetTexture(name:  "_ColorBuffer", value:  source);
        val_50.SetTexture(name:  "_ColorBuffer", value:  source);
        // 0x026735BC: LDR w8, [x20, #0x30]       | W8 = this.quality; //P2                 
        // 0x026735C0: CMP w8, #1                 | STATE = COMPARE(this.quality, 0x1)      
        // 0x026735C4: B.LT #0x2673650            | if (this.quality < 0x1) goto label_85;  
        if(this.quality < 1)
        {
            goto label_85;
        }
        // 0x026735C8: LDR w2, [sp, #0x14]        | W2 = (source < null ? (source + 1) : source >> 1);
        // 0x026735CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026735D0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x026735D4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026735D8: MOV w1, w25                | W1 = (source < null ? (source + 1) : source >> 1);//m1
        // 0x026735DC: MOV w4, w23                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x026735E0: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_13, depthBuffer:  val_14, format:  0);
        UnityEngine.RenderTexture val_41 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_13, depthBuffer:  val_14, format:  0);
        // 0x026735E4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x026735E8: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026735EC: MOV x21, x0                | X21 = val_41;//m1                       
        val_48 = val_41;
        // 0x026735F0: LDR x8, [x8]               | X8 = typeof(UnityEngine.Graphics);      
        // 0x026735F4: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026735F8: TBZ w9, #0, #0x267360c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_87;
        // 0x026735FC: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02673600: CBNZ w9, #0x267360c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_87;
        // 0x02673604: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02673608: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_87:
        // 0x0267360C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673610: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02673614: MOV x1, x27                | X1 = val_27;//m1                        
        // 0x02673618: MOV x2, x21                | X2 = val_41;//m1                        
        // 0x0267361C: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  val_27);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_27);
        // 0x02673620: LDR x3, [x20, #0xd0]       | X3 = this.screenBlend; //P2             
        // 0x02673624: LDR x2, [sp, #0x18]        | X2 = destination;                       
        // 0x02673628: LDR w4, [sp, #0x20]        | W4 = false != 0x0 ? 1 : this.screenBlendMode;
        // 0x0267362C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673630: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673634: MOV x1, x21                | X1 = val_41;//m1                        
        // 0x02673638: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_48, mat:  destination, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_48, mat:  destination, pass:  this.screenBlend);
        // 0x0267363C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673640: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673644: MOV x1, x21                | X1 = val_41;//m1                        
        // 0x02673648: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x0267364C: B #0x2673690               |  goto label_88;                         
        goto label_88;
        label_85:
        // 0x02673650: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02673654: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02673658: LDR x19, [x20, #0xd0]      | X19 = this.screenBlend; //P2            
        val_50 = this.screenBlend;
        // 0x0267365C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02673660: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02673664: TBZ w8, #0, #0x2673674     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_90;
        // 0x02673668: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267366C: CBNZ w8, #0x2673674        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_90;
        // 0x02673670: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_90:
        // 0x02673674: LDR x2, [sp, #0x18]        | X2 = destination;                       
        // 0x02673678: LDR w4, [sp, #0x20]        | W4 = false != 0x0 ? 1 : this.screenBlendMode;
        // 0x0267367C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673680: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673684: MOV x1, x27                | X1 = val_27;//m1                        
        // 0x02673688: MOV x3, x19                | X3 = this.screenBlend;//m1              
        // 0x0267368C: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_27, mat:  destination, pass:  val_50);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_27, mat:  destination, pass:  val_50);
        label_88:
        // 0x02673690: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673694: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673698: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x0267369C: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x026736A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026736A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026736A8: MOV x1, x27                | X1 = val_27;//m1                        
        // 0x026736AC: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x026736B0: SUB sp, x29, #0x90         | SP = (1152921509945120384 - 144) = 1152921509945120240 (0x100000013E2F95F0);
        // 0x026736B4: LDP x29, x30, [sp, #0x90]  | X29 = ; X30 = ;                          //  | 
        // 0x026736B8: LDP x20, x19, [sp, #0x80]  | X20 = ; X19 = ;                          //  | 
        // 0x026736BC: LDP x22, x21, [sp, #0x70]  | X22 = ; X21 = ;                          //  | 
        // 0x026736C0: LDP x24, x23, [sp, #0x60]  | X24 = ; X23 = ;                          //  | 
        // 0x026736C4: LDP x26, x25, [sp, #0x50]  | X26 = ; X25 = ;                          //  | 
        // 0x026736C8: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
        // 0x026736CC: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x026736D0: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x026736D4: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x026736D8: LDP d15, d14, [sp], #0xa0  | D15 = ; D14 = ;                          //  | 
        // 0x026736DC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02673DC4 (40320452), len: 212  VirtAddr: 0x02673DC4 RVA: 0x02673DC4 token: 100663310 methodIndex: 24394 delegateWrapperIndex: 0 methodInvoker: 0
    private void AddTo(float intensity_, UnityEngine.RenderTexture from, UnityEngine.RenderTexture to)
    {
        //
        // Disasemble & Code
        // 0x02673DC4: STP d9, d8, [sp, #-0x40]!  | stack[1152921509945478096] = ???;  stack[1152921509945478104] = ???;  //  dest_result_addr=1152921509945478096 |  dest_result_addr=1152921509945478104
        // 0x02673DC8: STP x22, x21, [sp, #0x10]  | stack[1152921509945478112] = ???;  stack[1152921509945478120] = ???;  //  dest_result_addr=1152921509945478112 |  dest_result_addr=1152921509945478120
        // 0x02673DCC: STP x20, x19, [sp, #0x20]  | stack[1152921509945478128] = ???;  stack[1152921509945478136] = ???;  //  dest_result_addr=1152921509945478128 |  dest_result_addr=1152921509945478136
        // 0x02673DD0: STP x29, x30, [sp, #0x30]  | stack[1152921509945478144] = ???;  stack[1152921509945478152] = ???;  //  dest_result_addr=1152921509945478144 |  dest_result_addr=1152921509945478152
        // 0x02673DD4: ADD x29, sp, #0x30         | X29 = (1152921509945478096 + 48) = 1152921509945478144 (0x100000013E350C00);
        // 0x02673DD8: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x02673DDC: LDRB w8, [x22, #0xe47]     | W8 = (bool)static_value_03740E47;       
        // 0x02673DE0: MOV x19, x2                | X19 = to;//m1                           
        // 0x02673DE4: MOV x20, x1                | X20 = from;//m1                         
        // 0x02673DE8: MOV v8.16b, v0.16b         | V8 = intensity_;//m1                    
        // 0x02673DEC: MOV x21, x0                | X21 = 1152921509945490160 (0x100000013E353AF0);//ML01
        // 0x02673DF0: TBNZ w8, #0, #0x2673e0c    | if (static_value_03740E47 == true) goto label_0;
        // 0x02673DF4: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x02673DF8: LDR x8, [x8, #0x340]       | X8 = 0x2B8F694;                         
        // 0x02673DFC: LDR w0, [x8]               | W0 = 0x1469;                            
        // 0x02673E00: BL #0x2782188              | X0 = sub_2782188( ?? 0x1469, ????);     
        // 0x02673E04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02673E08: STRB w8, [x22, #0xe47]     | static_value_03740E47 = true;            //  dest_result_addr=57937479
        label_0:
        // 0x02673E0C: LDR x22, [x21, #0xd0]      | X22 = this.screenBlend; //P2            
        // 0x02673E10: CBNZ x22, #0x2673e18       | if (this.screenBlend != null) goto label_1;
        if(this.screenBlend != null)
        {
            goto label_1;
        }
        // 0x02673E14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1469, ????);     
        label_1:
        // 0x02673E18: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x02673E1C: LDR x8, [x8, #0x720]       | X8 = (string**)(1152921509940329520)("_Intensity");
        // 0x02673E20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673E24: MOV x0, x22                | X0 = this.screenBlend;//m1              
        // 0x02673E28: MOV v0.16b, v8.16b         | V0 = intensity_;//m1                    
        // 0x02673E2C: LDR x1, [x8]               | X1 = "_Intensity";                      
        // 0x02673E30: BL #0x1a79ef8              | this.screenBlend.SetFloat(name:  "_Intensity", value:  intensity_);
        this.screenBlend.SetFloat(name:  "_Intensity", value:  intensity_);
        // 0x02673E34: CBNZ x19, #0x2673e3c       | if (to != null) goto label_2;           
        if(to != null)
        {
            goto label_2;
        }
        // 0x02673E38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.screenBlend, ????);
        label_2:
        // 0x02673E3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673E40: MOV x0, x19                | X0 = to;//m1                            
        // 0x02673E44: BL #0x1b8a2d0              | to.MarkRestoreExpected();               
        to.MarkRestoreExpected();
        // 0x02673E48: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02673E4C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02673E50: LDR x21, [x21, #0xd0]      | X21 = this.screenBlend; //P2            
        // 0x02673E54: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02673E58: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02673E5C: TBZ w8, #0, #0x2673e6c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x02673E60: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02673E64: CBNZ w8, #0x2673e6c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x02673E68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_4:
        // 0x02673E6C: MOV x1, x20                | X1 = from;//m1                          
        // 0x02673E70: MOV x2, x19                | X2 = to;//m1                            
        // 0x02673E74: MOV x3, x21                | X3 = this.screenBlend;//m1              
        // 0x02673E78: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x02673E7C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02673E80: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x02673E84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673E88: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673E8C: MOVZ w4, #0x9              | W4 = 9 (0x9);//ML01                     
        // 0x02673E90: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x02673E94: B #0x1a6bc84               | UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to, pass:  this.screenBlend); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to, pass:  this.screenBlend);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02673B18 (40319768), len: 684  VirtAddr: 0x02673B18 RVA: 0x02673B18 token: 100663311 methodIndex: 24395 delegateWrapperIndex: 0 methodInvoker: 0
    private void BlendFlares(UnityEngine.RenderTexture from, UnityEngine.RenderTexture to)
    {
        //
        // Disasemble & Code
        // 0x02673B18: STP d11, d10, [sp, #-0x50]! | stack[1152921509945635456] = ???;  stack[1152921509945635464] = ???;  //  dest_result_addr=1152921509945635456 |  dest_result_addr=1152921509945635464
        // 0x02673B1C: STP d9, d8, [sp, #0x10]    | stack[1152921509945635472] = ???;  stack[1152921509945635480] = ???;  //  dest_result_addr=1152921509945635472 |  dest_result_addr=1152921509945635480
        // 0x02673B20: STP x22, x21, [sp, #0x20]  | stack[1152921509945635488] = ???;  stack[1152921509945635496] = ???;  //  dest_result_addr=1152921509945635488 |  dest_result_addr=1152921509945635496
        // 0x02673B24: STP x20, x19, [sp, #0x30]  | stack[1152921509945635504] = ???;  stack[1152921509945635512] = ???;  //  dest_result_addr=1152921509945635504 |  dest_result_addr=1152921509945635512
        // 0x02673B28: STP x29, x30, [sp, #0x40]  | stack[1152921509945635520] = ???;  stack[1152921509945635528] = ???;  //  dest_result_addr=1152921509945635520 |  dest_result_addr=1152921509945635528
        // 0x02673B2C: ADD x29, sp, #0x40         | X29 = (1152921509945635456 + 64) = 1152921509945635520 (0x100000013E3772C0);
        // 0x02673B30: SUB sp, sp, #0x40          | SP = (1152921509945635456 - 64) = 1152921509945635392 (0x100000013E377240);
        // 0x02673B34: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x02673B38: LDRB w8, [x22, #0xe48]     | W8 = (bool)static_value_03740E48;       
        // 0x02673B3C: MOV x19, x2                | X19 = to;//m1                           
        // 0x02673B40: MOV x20, x1                | X20 = from;//m1                         
        // 0x02673B44: MOV x21, x0                | X21 = 1152921509945647536 (0x100000013E37A1B0);//ML01
        // 0x02673B48: TBNZ w8, #0, #0x2673b64    | if (static_value_03740E48 == true) goto label_0;
        // 0x02673B4C: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x02673B50: LDR x8, [x8, #0x620]       | X8 = 0x2B8F698;                         
        // 0x02673B54: LDR w0, [x8]               | W0 = 0x146A;                            
        // 0x02673B58: BL #0x2782188              | X0 = sub_2782188( ?? 0x146A, ????);     
        // 0x02673B5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02673B60: STRB w8, [x22, #0xe48]     | static_value_03740E48 = true;            //  dest_result_addr=57937480
        label_0:
        // 0x02673B64: LDR x22, [x21, #0xc0]      | X22 = this.lensFlareMaterial; //P2      
        // 0x02673B68: LDP s0, s1, [x21, #0x6c]   | S0 = this.flareColorA; //P2              //  | 
        // 0x02673B6C: LDP s2, s3, [x21, #0x74]   |                                          //  | 
        // 0x02673B70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673B74: ADD x0, sp, #0x30          | X0 = (1152921509945635392 + 48) = 1152921509945635440 (0x100000013E377270);
        // 0x02673B78: STP xzr, xzr, [sp, #0x30]  | stack[1152921509945635440] = 0x0;  stack[1152921509945635448] = 0x0;  //  dest_result_addr=1152921509945635440 |  dest_result_addr=1152921509945635448
        // 0x02673B7C: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02673B80: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x02673B84: LDR x8, [x8, #0xb10]       | X8 = 1152921504708763648;               
        // 0x02673B88: LDR s8, [x21, #0x60]       | S8 = this.lensflareIntensity; //P2      
        // 0x02673B8C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector4);       
        // 0x02673B90: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector4.__il2cppRuntimeField_10A;
        // 0x02673B94: TBZ w8, #0, #0x2673ba4     | if (UnityEngine.Vector4.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02673B98: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished;
        // 0x02673B9C: CBNZ w8, #0x2673ba4        | if (UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02673BA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector4), ????);
        label_2:
        // 0x02673BA4: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02673BA8: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02673BAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673BB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673BB4: MOV v4.16b, v8.16b         | V4 = this.lensflareIntensity;//m1       
        // 0x02673BB8: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_1 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        // 0x02673BBC: MOV v8.16b, v0.16b         | V8 = val_1.x;//m1                       
        // 0x02673BC0: MOV v9.16b, v1.16b         | V9 = val_1.y;//m1                       
        // 0x02673BC4: MOV v10.16b, v2.16b        | V10 = val_1.z;//m1                      
        // 0x02673BC8: MOV v11.16b, v3.16b        | V11 = val_1.w;//m1                      
        // 0x02673BCC: CBNZ x22, #0x2673bd4       | if (this.lensFlareMaterial != null) goto label_3;
        if(this.lensFlareMaterial != null)
        {
            goto label_3;
        }
        // 0x02673BD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x02673BD4: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x02673BD8: LDR x8, [x8, #0x778]       | X8 = (string**)(1152921509945606832)("colorA");
        // 0x02673BDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673BE0: MOV x0, x22                | X0 = this.lensFlareMaterial;//m1        
        // 0x02673BE4: MOV v0.16b, v8.16b         | V0 = val_1.x;//m1                       
        // 0x02673BE8: LDR x1, [x8]               | X1 = "colorA";                          
        // 0x02673BEC: MOV v1.16b, v9.16b         | V1 = val_1.y;//m1                       
        // 0x02673BF0: MOV v2.16b, v10.16b        | V2 = val_1.z;//m1                       
        // 0x02673BF4: MOV v3.16b, v11.16b        | V3 = val_1.w;//m1                       
        // 0x02673BF8: BL #0x1a79fa8              | this.lensFlareMaterial.SetVector(name:  "colorA", value:  new UnityEngine.Vector4() {x = val_1.x, y = val_1.y, z = val_1.z, w = val_1.w});
        this.lensFlareMaterial.SetVector(name:  "colorA", value:  new UnityEngine.Vector4() {x = val_1.x, y = val_1.y, z = val_1.z, w = val_1.w});
        // 0x02673BFC: LDR x22, [x21, #0xc0]      | X22 = this.lensFlareMaterial; //P2      
        // 0x02673C00: LDP s0, s1, [x21, #0x7c]   | S0 = this.flareColorB; //P2              //  | 
        // 0x02673C04: LDP s2, s3, [x21, #0x84]   |                                          //  | 
        // 0x02673C08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673C0C: ADD x0, sp, #0x20          | X0 = (1152921509945635392 + 32) = 1152921509945635424 (0x100000013E377260);
        // 0x02673C10: STP xzr, xzr, [sp, #0x20]  | stack[1152921509945635424] = 0x0;  stack[1152921509945635432] = 0x0;  //  dest_result_addr=1152921509945635424 |  dest_result_addr=1152921509945635432
        // 0x02673C14: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02673C18: LDR s4, [x21, #0x60]       | S4 = this.lensflareIntensity; //P2      
        // 0x02673C1C: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02673C20: LDP s2, s3, [sp, #0x28]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02673C24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673C2C: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_2 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        // 0x02673C30: MOV v8.16b, v0.16b         | V8 = val_2.x;//m1                       
        // 0x02673C34: MOV v9.16b, v1.16b         | V9 = val_2.y;//m1                       
        // 0x02673C38: MOV v10.16b, v2.16b        | V10 = val_2.z;//m1                      
        // 0x02673C3C: MOV v11.16b, v3.16b        | V11 = val_2.w;//m1                      
        // 0x02673C40: CBNZ x22, #0x2673c48       | if (this.lensFlareMaterial != null) goto label_4;
        if(this.lensFlareMaterial != null)
        {
            goto label_4;
        }
        // 0x02673C44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_4:
        // 0x02673C48: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
        // 0x02673C4C: LDR x8, [x8, #0xe0]        | X8 = (string**)(1152921509945611008)("colorB");
        // 0x02673C50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673C54: MOV x0, x22                | X0 = this.lensFlareMaterial;//m1        
        // 0x02673C58: MOV v0.16b, v8.16b         | V0 = val_2.x;//m1                       
        // 0x02673C5C: LDR x1, [x8]               | X1 = "colorB";                          
        // 0x02673C60: MOV v1.16b, v9.16b         | V1 = val_2.y;//m1                       
        // 0x02673C64: MOV v2.16b, v10.16b        | V2 = val_2.z;//m1                       
        // 0x02673C68: MOV v3.16b, v11.16b        | V3 = val_2.w;//m1                       
        // 0x02673C6C: BL #0x1a79fa8              | this.lensFlareMaterial.SetVector(name:  "colorB", value:  new UnityEngine.Vector4() {x = val_2.x, y = val_2.y, z = val_2.z, w = val_2.w});
        this.lensFlareMaterial.SetVector(name:  "colorB", value:  new UnityEngine.Vector4() {x = val_2.x, y = val_2.y, z = val_2.z, w = val_2.w});
        // 0x02673C70: LDR x22, [x21, #0xc0]      | X22 = this.lensFlareMaterial; //P2      
        // 0x02673C74: LDP s0, s1, [x21, #0x8c]   | S0 = this.flareColorC; //P2              //  | 
        // 0x02673C78: LDP s2, s3, [x21, #0x94]   |                                          //  | 
        // 0x02673C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673C80: ADD x0, sp, #0x10          | X0 = (1152921509945635392 + 16) = 1152921509945635408 (0x100000013E377250);
        // 0x02673C84: STP xzr, xzr, [sp, #0x10]  | stack[1152921509945635408] = 0x0;  stack[1152921509945635416] = 0x0;  //  dest_result_addr=1152921509945635408 |  dest_result_addr=1152921509945635416
        // 0x02673C88: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02673C8C: LDR s4, [x21, #0x60]       | S4 = this.lensflareIntensity; //P2      
        // 0x02673C90: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02673C94: LDP s2, s3, [sp, #0x18]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02673C98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673C9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673CA0: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_3 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        // 0x02673CA4: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        // 0x02673CA8: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x02673CAC: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
        // 0x02673CB0: MOV v11.16b, v3.16b        | V11 = val_3.w;//m1                      
        // 0x02673CB4: CBNZ x22, #0x2673cbc       | if (this.lensFlareMaterial != null) goto label_5;
        if(this.lensFlareMaterial != null)
        {
            goto label_5;
        }
        // 0x02673CB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_5:
        // 0x02673CBC: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x02673CC0: LDR x8, [x8, #0xbc8]       | X8 = (string**)(1152921509945615184)("colorC");
        // 0x02673CC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673CC8: MOV x0, x22                | X0 = this.lensFlareMaterial;//m1        
        // 0x02673CCC: MOV v0.16b, v8.16b         | V0 = val_3.x;//m1                       
        // 0x02673CD0: LDR x1, [x8]               | X1 = "colorC";                          
        // 0x02673CD4: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x02673CD8: MOV v2.16b, v10.16b        | V2 = val_3.z;//m1                       
        // 0x02673CDC: MOV v3.16b, v11.16b        | V3 = val_3.w;//m1                       
        // 0x02673CE0: BL #0x1a79fa8              | this.lensFlareMaterial.SetVector(name:  "colorC", value:  new UnityEngine.Vector4() {x = val_3.x, y = val_3.y, z = val_3.z, w = val_3.w});
        this.lensFlareMaterial.SetVector(name:  "colorC", value:  new UnityEngine.Vector4() {x = val_3.x, y = val_3.y, z = val_3.z, w = val_3.w});
        // 0x02673CE4: LDR x22, [x21, #0xc0]      | X22 = this.lensFlareMaterial; //P2      
        // 0x02673CE8: LDP s0, s1, [x21, #0x9c]   | S0 = this.flareColorD; //P2              //  | 
        // 0x02673CEC: LDP s2, s3, [x21, #0xa4]   |                                          //  | 
        // 0x02673CF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673CF4: MOV x0, sp                 | X0 = 1152921509945635392 (0x100000013E377240);//ML01
        // 0x02673CF8: STP xzr, xzr, [sp]         | stack[1152921509945635392] = 0x0;  stack[1152921509945635400] = 0x0;  //  dest_result_addr=1152921509945635392 |  dest_result_addr=1152921509945635400
        // 0x02673CFC: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02673D00: LDR s4, [x21, #0x60]       | S4 = this.lensflareIntensity; //P2      
        // 0x02673D04: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x02673D08: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
        // 0x02673D0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673D10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673D14: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_4 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        // 0x02673D18: MOV v8.16b, v0.16b         | V8 = val_4.x;//m1                       
        // 0x02673D1C: MOV v9.16b, v1.16b         | V9 = val_4.y;//m1                       
        // 0x02673D20: MOV v10.16b, v2.16b        | V10 = val_4.z;//m1                      
        // 0x02673D24: MOV v11.16b, v3.16b        | V11 = val_4.w;//m1                      
        // 0x02673D28: CBNZ x22, #0x2673d30       | if (this.lensFlareMaterial != null) goto label_6;
        if(this.lensFlareMaterial != null)
        {
            goto label_6;
        }
        // 0x02673D2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x02673D30: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x02673D34: LDR x8, [x8, #0x230]       | X8 = (string**)(1152921509945619360)("colorD");
        // 0x02673D38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673D3C: MOV x0, x22                | X0 = this.lensFlareMaterial;//m1        
        // 0x02673D40: MOV v0.16b, v8.16b         | V0 = val_4.x;//m1                       
        // 0x02673D44: LDR x1, [x8]               | X1 = "colorD";                          
        // 0x02673D48: MOV v1.16b, v9.16b         | V1 = val_4.y;//m1                       
        // 0x02673D4C: MOV v2.16b, v10.16b        | V2 = val_4.z;//m1                       
        // 0x02673D50: MOV v3.16b, v11.16b        | V3 = val_4.w;//m1                       
        // 0x02673D54: BL #0x1a79fa8              | this.lensFlareMaterial.SetVector(name:  "colorD", value:  new UnityEngine.Vector4() {x = val_4.x, y = val_4.y, z = val_4.z, w = val_4.w});
        this.lensFlareMaterial.SetVector(name:  "colorD", value:  new UnityEngine.Vector4() {x = val_4.x, y = val_4.y, z = val_4.z, w = val_4.w});
        // 0x02673D58: CBNZ x19, #0x2673d60       | if (to != null) goto label_7;           
        if(to != null)
        {
            goto label_7;
        }
        // 0x02673D5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.lensFlareMaterial, ????);
        label_7:
        // 0x02673D60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673D64: MOV x0, x19                | X0 = to;//m1                            
        // 0x02673D68: BL #0x1b8a2d0              | to.MarkRestoreExpected();               
        to.MarkRestoreExpected();
        // 0x02673D6C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02673D70: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02673D74: LDR x21, [x21, #0xc0]      | X21 = this.lensFlareMaterial; //P2      
        // 0x02673D78: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02673D7C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02673D80: TBZ w8, #0, #0x2673d90     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x02673D84: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02673D88: CBNZ w8, #0x2673d90        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x02673D8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_9:
        // 0x02673D90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673D94: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02673D98: MOV x1, x20                | X1 = from;//m1                          
        // 0x02673D9C: MOV x2, x19                | X2 = to;//m1                            
        // 0x02673DA0: MOV x3, x21                | X3 = this.lensFlareMaterial;//m1        
        // 0x02673DA4: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to);
        UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to);
        // 0x02673DA8: SUB sp, x29, #0x40         | SP = (1152921509945635520 - 64) = 1152921509945635456 (0x100000013E377280);
        // 0x02673DAC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x02673DB0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02673DB4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x02673DB8: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x02673DBC: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x02673DC0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026737EC (40318956), len: 240  VirtAddr: 0x026737EC RVA: 0x026737EC token: 100663312 methodIndex: 24396 delegateWrapperIndex: 0 methodInvoker: 0
    private void BrightFilter(float thresh, UnityEngine.RenderTexture from, UnityEngine.RenderTexture to)
    {
        //
        // Disasemble & Code
        // 0x026737EC: STP d9, d8, [sp, #-0x40]!  | stack[1152921509945792528] = ???;  stack[1152921509945792536] = ???;  //  dest_result_addr=1152921509945792528 |  dest_result_addr=1152921509945792536
        // 0x026737F0: STP x22, x21, [sp, #0x10]  | stack[1152921509945792544] = ???;  stack[1152921509945792552] = ???;  //  dest_result_addr=1152921509945792544 |  dest_result_addr=1152921509945792552
        // 0x026737F4: STP x20, x19, [sp, #0x20]  | stack[1152921509945792560] = ???;  stack[1152921509945792568] = ???;  //  dest_result_addr=1152921509945792560 |  dest_result_addr=1152921509945792568
        // 0x026737F8: STP x29, x30, [sp, #0x30]  | stack[1152921509945792576] = ???;  stack[1152921509945792584] = ???;  //  dest_result_addr=1152921509945792576 |  dest_result_addr=1152921509945792584
        // 0x026737FC: ADD x29, sp, #0x30         | X29 = (1152921509945792528 + 48) = 1152921509945792576 (0x100000013E39D840);
        // 0x02673800: SUB sp, sp, #0x10          | SP = (1152921509945792528 - 16) = 1152921509945792512 (0x100000013E39D800);
        // 0x02673804: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x02673808: LDRB w8, [x22, #0xe49]     | W8 = (bool)static_value_03740E49;       
        // 0x0267380C: MOV x19, x2                | X19 = to;//m1                           
        // 0x02673810: MOV x20, x1                | X20 = from;//m1                         
        // 0x02673814: MOV v8.16b, v0.16b         | V8 = thresh;//m1                        
        // 0x02673818: MOV x21, x0                | X21 = 1152921509945804592 (0x100000013E3A0730);//ML01
        // 0x0267381C: TBNZ w8, #0, #0x2673838    | if (static_value_03740E49 == true) goto label_0;
        // 0x02673820: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x02673824: LDR x8, [x8, #0x658]       | X8 = 0x2B8F6A0;                         
        // 0x02673828: LDR w0, [x8]               | W0 = 0x146C;                            
        // 0x0267382C: BL #0x2782188              | X0 = sub_2782188( ?? 0x146C, ????);     
        // 0x02673830: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02673834: STRB w8, [x22, #0xe49]     | static_value_03740E49 = true;            //  dest_result_addr=57937481
        label_0:
        // 0x02673838: LDR x22, [x21, #0xf0]      | X22 = this.brightPassFilterMaterial; //P2 
        // 0x0267383C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673840: MOV x0, sp                 | X0 = 1152921509945792512 (0x100000013E39D800);//ML01
        // 0x02673844: MOV v0.16b, v8.16b         | V0 = thresh;//m1                        
        // 0x02673848: MOV v1.16b, v8.16b         | V1 = thresh;//m1                        
        // 0x0267384C: MOV v2.16b, v8.16b         | V2 = thresh;//m1                        
        // 0x02673850: MOV v3.16b, v8.16b         | V3 = thresh;//m1                        
        // 0x02673854: STP xzr, xzr, [sp]         | stack[1152921509945792512] = 0x0;  stack[1152921509945792520] = 0x0;  //  dest_result_addr=1152921509945792512 |  dest_result_addr=1152921509945792520
        // 0x02673858: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x0267385C: CBNZ x22, #0x2673864       | if (this.brightPassFilterMaterial != null) goto label_1;
        if(this.brightPassFilterMaterial != null)
        {
            goto label_1;
        }
        // 0x02673860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E39D800, ????);
        label_1:
        // 0x02673864: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
        // 0x02673868: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509944997328)("_Threshhold");
        // 0x0267386C: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x02673870: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
        // 0x02673874: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673878: LDR x1, [x8]               | X1 = "_Threshhold";                     
        // 0x0267387C: MOV x0, x22                | X0 = this.brightPassFilterMaterial;//m1 
        // 0x02673880: BL #0x1a79fa8              | this.brightPassFilterMaterial.SetVector(name:  "_Threshhold", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.brightPassFilterMaterial.SetVector(name:  "_Threshhold", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02673884: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02673888: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x0267388C: LDR x21, [x21, #0xf0]      | X21 = this.brightPassFilterMaterial; //P2 
        // 0x02673890: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02673894: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02673898: TBZ w8, #0, #0x26738a8     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x0267389C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026738A0: CBNZ w8, #0x26738a8        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x026738A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_3:
        // 0x026738A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026738AC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x026738B0: MOV x1, x20                | X1 = from;//m1                          
        // 0x026738B4: MOV x2, x19                | X2 = to;//m1                            
        // 0x026738B8: MOV x3, x21                | X3 = this.brightPassFilterMaterial;//m1 
        // 0x026738BC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026738C0: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to, pass:  this.brightPassFilterMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to, pass:  this.brightPassFilterMaterial);
        // 0x026738C4: SUB sp, x29, #0x30         | SP = (1152921509945792576 - 48) = 1152921509945792528 (0x100000013E39D810);
        // 0x026738C8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x026738CC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x026738D0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x026738D4: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x026738D8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026736E0 (40318688), len: 268  VirtAddr: 0x026736E0 RVA: 0x026736E0 token: 100663313 methodIndex: 24397 delegateWrapperIndex: 0 methodInvoker: 0
    private void BrightFilter(UnityEngine.Color threshColor, UnityEngine.RenderTexture from, UnityEngine.RenderTexture to)
    {
        //
        // Disasemble & Code
        // 0x026736E0: STP d11, d10, [sp, #-0x50]! | stack[1152921509945937280] = ???;  stack[1152921509945937288] = ???;  //  dest_result_addr=1152921509945937280 |  dest_result_addr=1152921509945937288
        // 0x026736E4: STP d9, d8, [sp, #0x10]    | stack[1152921509945937296] = ???;  stack[1152921509945937304] = ???;  //  dest_result_addr=1152921509945937296 |  dest_result_addr=1152921509945937304
        // 0x026736E8: STP x22, x21, [sp, #0x20]  | stack[1152921509945937312] = ???;  stack[1152921509945937320] = ???;  //  dest_result_addr=1152921509945937312 |  dest_result_addr=1152921509945937320
        // 0x026736EC: STP x20, x19, [sp, #0x30]  | stack[1152921509945937328] = ???;  stack[1152921509945937336] = ???;  //  dest_result_addr=1152921509945937328 |  dest_result_addr=1152921509945937336
        // 0x026736F0: STP x29, x30, [sp, #0x40]  | stack[1152921509945937344] = ???;  stack[1152921509945937352] = ???;  //  dest_result_addr=1152921509945937344 |  dest_result_addr=1152921509945937352
        // 0x026736F4: ADD x29, sp, #0x40         | X29 = (1152921509945937280 + 64) = 1152921509945937344 (0x100000013E3C0DC0);
        // 0x026736F8: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x026736FC: LDRB w8, [x22, #0xe4a]     | W8 = (bool)static_value_03740E4A;       
        // 0x02673700: MOV x19, x2                | X19 = to;//m1                           
        // 0x02673704: MOV x20, x1                | X20 = from;//m1                         
        // 0x02673708: MOV v8.16b, v3.16b         | V8 = threshColor.a;//m1                 
        // 0x0267370C: MOV v9.16b, v2.16b         | V9 = threshColor.b;//m1                 
        // 0x02673710: MOV v10.16b, v1.16b        | V10 = threshColor.g;//m1                
        // 0x02673714: MOV v11.16b, v0.16b        | V11 = threshColor.r;//m1                
        // 0x02673718: MOV x21, x0                | X21 = 1152921509945949360 (0x100000013E3C3CB0);//ML01
        // 0x0267371C: TBNZ w8, #0, #0x2673738    | if (static_value_03740E4A == true) goto label_0;
        // 0x02673720: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
        // 0x02673724: LDR x8, [x8, #0x708]       | X8 = 0x2B8F69C;                         
        // 0x02673728: LDR w0, [x8]               | W0 = 0x146B;                            
        // 0x0267372C: BL #0x2782188              | X0 = sub_2782188( ?? 0x146B, ????);     
        // 0x02673730: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02673734: STRB w8, [x22, #0xe4a]     | static_value_03740E4A = true;            //  dest_result_addr=57937482
        label_0:
        // 0x02673738: LDR x22, [x21, #0xf0]      | X22 = this.brightPassFilterMaterial; //P2 
        // 0x0267373C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673744: MOV v0.16b, v11.16b        | V0 = threshColor.r;//m1                 
        // 0x02673748: MOV v1.16b, v10.16b        | V1 = threshColor.g;//m1                 
        // 0x0267374C: MOV v2.16b, v9.16b         | V2 = threshColor.b;//m1                 
        // 0x02673750: MOV v3.16b, v8.16b         | V3 = threshColor.a;//m1                 
        // 0x02673754: BL #0x20d37bc              | X0 = UnityEngine.Color.op_Implicit(c:  new UnityEngine.Color() {r = threshColor.r, g = threshColor.g, b = threshColor.b, a = threshColor.a});
        UnityEngine.Vector4 val_1 = UnityEngine.Color.op_Implicit(c:  new UnityEngine.Color() {r = threshColor.r, g = threshColor.g, b = threshColor.b, a = threshColor.a});
        // 0x02673758: MOV v8.16b, v0.16b         | V8 = val_1.x;//m1                       
        // 0x0267375C: MOV v9.16b, v1.16b         | V9 = val_1.y;//m1                       
        // 0x02673760: MOV v10.16b, v2.16b        | V10 = val_1.z;//m1                      
        // 0x02673764: MOV v11.16b, v3.16b        | V11 = val_1.w;//m1                      
        // 0x02673768: CBNZ x22, #0x2673770       | if (this.brightPassFilterMaterial != null) goto label_1;
        if(this.brightPassFilterMaterial != null)
        {
            goto label_1;
        }
        // 0x0267376C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_1:
        // 0x02673770: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
        // 0x02673774: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509944997328)("_Threshhold");
        // 0x02673778: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267377C: MOV x0, x22                | X0 = this.brightPassFilterMaterial;//m1 
        // 0x02673780: MOV v0.16b, v8.16b         | V0 = val_1.x;//m1                       
        // 0x02673784: LDR x1, [x8]               | X1 = "_Threshhold";                     
        // 0x02673788: MOV v1.16b, v9.16b         | V1 = val_1.y;//m1                       
        // 0x0267378C: MOV v2.16b, v10.16b        | V2 = val_1.z;//m1                       
        // 0x02673790: MOV v3.16b, v11.16b        | V3 = val_1.w;//m1                       
        // 0x02673794: BL #0x1a79fa8              | this.brightPassFilterMaterial.SetVector(name:  "_Threshhold", value:  new UnityEngine.Vector4() {x = val_1.x, y = val_1.y, z = val_1.z, w = val_1.w});
        this.brightPassFilterMaterial.SetVector(name:  "_Threshhold", value:  new UnityEngine.Vector4() {x = val_1.x, y = val_1.y, z = val_1.z, w = val_1.w});
        // 0x02673798: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0267379C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026737A0: LDR x21, [x21, #0xf0]      | X21 = this.brightPassFilterMaterial; //P2 
        // 0x026737A4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x026737A8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026737AC: TBZ w8, #0, #0x26737bc     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x026737B0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026737B4: CBNZ w8, #0x26737bc        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x026737B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_3:
        // 0x026737BC: MOV x1, x20                | X1 = from;//m1                          
        // 0x026737C0: MOV x2, x19                | X2 = to;//m1                            
        // 0x026737C4: MOV x3, x21                | X3 = this.brightPassFilterMaterial;//m1 
        // 0x026737C8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x026737CC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x026737D0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x026737D4: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x026737D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026737DC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026737E0: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x026737E4: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x026737E8: B #0x1a6bc84               | UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to, pass:  this.brightPassFilterMaterial); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to, pass:  this.brightPassFilterMaterial);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026738DC (40319196), len: 572  VirtAddr: 0x026738DC RVA: 0x026738DC token: 100663314 methodIndex: 24398 delegateWrapperIndex: 0 methodInvoker: 0
    private void Vignette(float amount, UnityEngine.RenderTexture from, UnityEngine.RenderTexture to)
    {
        //
        // Disasemble & Code
        // 0x026738DC: STP x24, x23, [sp, #-0x40]! | stack[1152921509946090256] = ???;  stack[1152921509946090264] = ???;  //  dest_result_addr=1152921509946090256 |  dest_result_addr=1152921509946090264
        // 0x026738E0: STP x22, x21, [sp, #0x10]  | stack[1152921509946090272] = ???;  stack[1152921509946090280] = ???;  //  dest_result_addr=1152921509946090272 |  dest_result_addr=1152921509946090280
        // 0x026738E4: STP x20, x19, [sp, #0x20]  | stack[1152921509946090288] = ???;  stack[1152921509946090296] = ???;  //  dest_result_addr=1152921509946090288 |  dest_result_addr=1152921509946090296
        // 0x026738E8: STP x29, x30, [sp, #0x30]  | stack[1152921509946090304] = ???;  stack[1152921509946090312] = ???;  //  dest_result_addr=1152921509946090304 |  dest_result_addr=1152921509946090312
        // 0x026738EC: ADD x29, sp, #0x30         | X29 = (1152921509946090256 + 48) = 1152921509946090304 (0x100000013E3E6340);
        // 0x026738F0: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x026738F4: LDRB w8, [x22, #0xe4b]     | W8 = (bool)static_value_03740E4B;       
        // 0x026738F8: MOV x19, x2                | X19 = to;//m1                           
        // 0x026738FC: MOV x20, x1                | X20 = from;//m1                         
        // 0x02673900: MOV x21, x0                | X21 = 1152921509946102320 (0x100000013E3E9230);//ML01
        // 0x02673904: TBNZ w8, #0, #0x2673920    | if (static_value_03740E4B == true) goto label_0;
        // 0x02673908: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x0267390C: LDR x8, [x8, #0x888]       | X8 = 0x2B8F6AC;                         
        // 0x02673910: LDR w0, [x8]               | W0 = 0x146F;                            
        // 0x02673914: BL #0x2782188              | X0 = sub_2782188( ?? 0x146F, ????);     
        // 0x02673918: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0267391C: STRB w8, [x22, #0xe4b]     | static_value_03740E4B = true;            //  dest_result_addr=57937483
        label_0:
        // 0x02673920: ADRP x24, #0x35fe000       | X24 = 56614912 (0x35FE000);             
        // 0x02673924: LDR x24, [x24, #0x810]     | X24 = 1152921504697475072;              
        // 0x02673928: LDR x22, [x21, #0xb0]      | X22 = this.lensFlareVignetteMask; //P2  
        // 0x0267392C: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x02673930: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02673934: TBZ w8, #0, #0x2673944     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02673938: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x0267393C: CBNZ w8, #0x2673944        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02673940: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x02673944: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673948: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267394C: MOV x1, x22                | X1 = this.lensFlareVignetteMask;//m1    
        // 0x02673950: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02673954: TBZ w0, #0, #0x2673a60     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x02673958: LDR x22, [x21, #0xd0]      | X22 = this.screenBlend; //P2            
        // 0x0267395C: LDR x23, [x21, #0xb0]      | X23 = this.lensFlareVignetteMask; //P2  
        // 0x02673960: CBNZ x22, #0x2673968       | if (this.screenBlend != null) goto label_4;
        if(this.screenBlend != null)
        {
            goto label_4;
        }
        // 0x02673964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x02673968: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
        // 0x0267396C: LDR x8, [x8, #0xca0]       | X8 = (string**)(1152921509945091920)("_ColorBuffer");
        // 0x02673970: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02673974: MOV x0, x22                | X0 = this.screenBlend;//m1              
        // 0x02673978: MOV x2, x23                | X2 = this.lensFlareVignetteMask;//m1    
        // 0x0267397C: LDR x1, [x8]               | X1 = "_ColorBuffer";                    
        // 0x02673980: BL #0x1a780c4              | this.screenBlend.SetTexture(name:  "_ColorBuffer", value:  this.lensFlareVignetteMask);
        this.screenBlend.SetTexture(name:  "_ColorBuffer", value:  this.lensFlareVignetteMask);
        // 0x02673984: CBNZ x19, #0x267398c       | if (to != null) goto label_5;           
        if(to != null)
        {
            goto label_5;
        }
        // 0x02673988: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.screenBlend, ????);
        label_5:
        // 0x0267398C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673990: MOV x0, x19                | X0 = to;//m1                            
        // 0x02673994: BL #0x1b8a2d0              | to.MarkRestoreExpected();               
        to.MarkRestoreExpected();
        // 0x02673998: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x0267399C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x026739A0: TBZ w8, #0, #0x26739b0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x026739A4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x026739A8: CBNZ w8, #0x26739b0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x026739AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_7:
        // 0x026739B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026739B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026739B8: MOV x1, x20                | X1 = from;//m1                          
        // 0x026739BC: MOV x2, x19                | X2 = to;//m1                            
        // 0x026739C0: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  from);
        bool val_2 = UnityEngine.Object.op_Equality(x:  0, y:  from);
        // 0x026739C4: LDR x8, [x24]              | X8 = typeof(UnityEngine.Object);        
        // 0x026739C8: LDR x21, [x21, #0xd0]      | X21 = this.screenBlend; //P2            
        // 0x026739CC: TST w0, #1                 | STATE = COMPARE(val_2, 0x1)             
        // 0x026739D0: CSEL x22, xzr, x20, ne     | X22 = val_2 != true ? 0 : from;         
        UnityEngine.RenderTexture val_3 = (val_2 != true) ? 0 : (from);
        // 0x026739D4: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x026739D8: TBZ w9, #0, #0x26739ec     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x026739DC: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x026739E0: CBNZ w9, #0x26739ec        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x026739E4: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x026739E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_9:
        // 0x026739EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026739F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026739F4: MOV x1, x20                | X1 = from;//m1                          
        // 0x026739F8: MOV x2, x19                | X2 = to;//m1                            
        // 0x026739FC: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  from);
        bool val_4 = UnityEngine.Object.op_Equality(x:  0, y:  from);
        // 0x02673A00: ADRP x9, #0x3641000        | X9 = 56889344 (0x3641000);              
        // 0x02673A04: LDR x9, [x9, #0x800]       | X9 = 1152921504693481472;               
        // 0x02673A08: MOV w8, w0                 | W8 = val_4;//m1                         
        // 0x02673A0C: TST w8, #1                 | STATE = COMPARE(val_4, 0x1)             
        // 0x02673A10: ORR w10, wzr, #7           | W10 = 7(0x7);                           
        // 0x02673A14: LDR x0, [x9]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02673A18: ORR w9, wzr, #3            | W9 = 3(0x3);                            
        // 0x02673A1C: CSEL w20, w10, w9, ne      | W20 = val_4 != true ? 7 : 3;            
        var val_5 = (val_4 != true) ? (7) : (3);
        // 0x02673A20: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02673A24: TBZ w8, #0, #0x2673a34     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x02673A28: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02673A2C: CBNZ w8, #0x2673a34        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x02673A30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_11:
        // 0x02673A34: MOV x1, x22                | X1 = val_2 != true ? 0 : from;//m1      
        // 0x02673A38: MOV x2, x19                | X2 = to;//m1                            
        // 0x02673A3C: MOV x3, x21                | X3 = this.screenBlend;//m1              
        // 0x02673A40: MOV w4, w20                | W4 = val_4 != true ? 7 : 3;//m1         
        // 0x02673A44: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x02673A48: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02673A4C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x02673A50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673A54: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02673A58: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x02673A5C: B #0x1a6bc84               | UnityEngine.Graphics.Blit(source:  0, dest:  val_3, mat:  to, pass:  this.screenBlend); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  val_3, mat:  to, pass:  this.screenBlend);
        return;
        label_3:
        // 0x02673A60: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x02673A64: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02673A68: TBZ w8, #0, #0x2673a78     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x02673A6C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02673A70: CBNZ w8, #0x2673a78        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x02673A74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_13:
        // 0x02673A78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673A7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02673A80: MOV x1, x20                | X1 = from;//m1                          
        // 0x02673A84: MOV x2, x19                | X2 = to;//m1                            
        // 0x02673A88: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  from);
        bool val_6 = UnityEngine.Object.op_Inequality(x:  0, y:  from);
        // 0x02673A8C: TBZ w0, #0, #0x2673b04     | if (val_6 == false) goto label_14;      
        if(val_6 == false)
        {
            goto label_14;
        }
        // 0x02673A90: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02673A94: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02673A98: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02673A9C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02673AA0: TBZ w8, #0, #0x2673ab0     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x02673AA4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02673AA8: CBNZ w8, #0x2673ab0        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x02673AAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_16:
        // 0x02673AB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673AB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02673AB8: MOV x1, x19                | X1 = to;//m1                            
        // 0x02673ABC: BL #0x1a6d524              | UnityEngine.Graphics.SetRenderTarget(rt:  0);
        UnityEngine.Graphics.SetRenderTarget(rt:  0);
        // 0x02673AC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673AC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673AC8: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
        UnityEngine.Color val_7 = UnityEngine.Color.black;
        // 0x02673ACC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673AD0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02673AD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02673AD8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02673ADC: BL #0x1a66470              | UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_7.r, g = val_7.g, b = val_7.b, a = val_7.a});
        UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_7.r, g = val_7.g, b = val_7.b, a = val_7.a});
        // 0x02673AE0: MOV x1, x20                | X1 = from;//m1                          
        // 0x02673AE4: MOV x2, x19                | X2 = to;//m1                            
        // 0x02673AE8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x02673AEC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02673AF0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x02673AF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02673AF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02673AFC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x02673B00: B #0x1a6ba68               | UnityEngine.Graphics.Blit(source:  0, dest:  from); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  from);
        return;
        label_14:
        // 0x02673B04: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x02673B08: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02673B0C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x02673B10: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x02673B14: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02673E98 (40320664), len: 4  VirtAddr: 0x02673E98 RVA: 0x02673E98 token: 100663315 methodIndex: 24399 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x02673E98: RET                        |  return;                                
        return;
    
    }

}
