using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public enum AssemblyHashAlgorithm
    {
        // Fields
        None = 0
        ,Reserved = 32771
        ,SHA1 = 32772
        
    
    }

}
