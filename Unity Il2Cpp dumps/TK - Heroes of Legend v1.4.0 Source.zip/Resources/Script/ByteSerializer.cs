using UnityEngine;

namespace ProtoBuf.Serializers
{
    internal sealed class ByteSerializer : IProtoSerializer
    {
        // Fields
        private static readonly System.Type expectedType; // static_offset: 0x00000000
        
        // Properties
        private bool ProtoBuf.Serializers.IProtoSerializer.RequiresOldValue { get; }
        private bool ProtoBuf.Serializers.IProtoSerializer.ReturnsValue { get; }
        public System.Type ExpectedType { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x02983818 (43530264), len: 8  VirtAddr: 0x02983818 RVA: 0x02983818 token: 100689814 methodIndex: 54013 delegateWrapperIndex: 0 methodInvoker: 0
        public ByteSerializer(ProtoBuf.Meta.TypeModel model)
        {
            //
            // Disasemble & Code
            // 0x02983818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298381C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B87C (43563132), len: 104  VirtAddr: 0x0298B87C RVA: 0x0298B87C token: 100689815 methodIndex: 54014 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type get_ExpectedType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0298B87C: STP x20, x19, [sp, #-0x20]! | stack[1152921514435312768] = ???;  stack[1152921514435312776] = ???;  //  dest_result_addr=1152921514435312768 |  dest_result_addr=1152921514435312776
            // 0x0298B880: STP x29, x30, [sp, #0x10]  | stack[1152921514435312784] = ???;  stack[1152921514435312792] = ???;  //  dest_result_addr=1152921514435312784 |  dest_result_addr=1152921514435312792
            // 0x0298B884: ADD x29, sp, #0x10         | X29 = (1152921514435312768 + 16) = 1152921514435312784 (0x1000000249D27C90);
            // 0x0298B888: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298B88C: LDRB w8, [x19, #0xf1b]     | W8 = (bool)static_value_037B8F1B;       
            // 0x0298B890: TBNZ w8, #0, #0x298b8ac    | if (static_value_037B8F1B == true) goto label_0;
            // 0x0298B894: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0298B898: LDR x8, [x8, #0xd70]       | X8 = 0x2B9000C;                         
            // 0x0298B89C: LDR w0, [x8]               | W0 = 0x16C7;                            
            // 0x0298B8A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C7, ????);     
            // 0x0298B8A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B8A8: STRB w8, [x19, #0xf1b]     | static_value_037B8F1B = true;            //  dest_result_addr=58429211
            label_0:
            // 0x0298B8AC: ADRP x19, #0x367f000       | X19 = 57143296 (0x367F000);             
            // 0x0298B8B0: LDR x19, [x19, #0xb68]     | X19 = 1152921504884908032;              
            // 0x0298B8B4: LDR x0, [x19]              | X0 = typeof(ProtoBuf.Serializers.ByteSerializer);
            val_1 = null;
            // 0x0298B8B8: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Serializers.ByteSerializer.__il2cppRuntimeField_10A;
            // 0x0298B8BC: TBZ w8, #0, #0x298b8d0     | if (ProtoBuf.Serializers.ByteSerializer.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298B8C0: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Serializers.ByteSerializer.__il2cppRuntimeField_cctor_finished;
            // 0x0298B8C4: CBNZ w8, #0x298b8d0        | if (ProtoBuf.Serializers.ByteSerializer.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298B8C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Serializers.ByteSerializer), ????);
            // 0x0298B8CC: LDR x0, [x19]              | X0 = typeof(ProtoBuf.Serializers.ByteSerializer);
            val_1 = null;
            label_2:
            // 0x0298B8D0: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.Serializers.ByteSerializer.__il2cppRuntimeField_static_fields;
            // 0x0298B8D4: LDR x0, [x8]               | X0 = ProtoBuf.Serializers.ByteSerializer.expectedType;
            // 0x0298B8D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B8DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298B8E0: RET                        |  return (System.Type)ProtoBuf.Serializers.ByteSerializer.expectedType;
            return ProtoBuf.Serializers.ByteSerializer.expectedType;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B8E4 (43563236), len: 8  VirtAddr: 0x0298B8E4 RVA: 0x0298B8E4 token: 100689816 methodIndex: 54015 delegateWrapperIndex: 0 methodInvoker: 0
        private bool ProtoBuf.Serializers.IProtoSerializer.get_RequiresOldValue()
        {
            //
            // Disasemble & Code
            // 0x0298B8E4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x0298B8E8: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B8EC (43563244), len: 8  VirtAddr: 0x0298B8EC RVA: 0x0298B8EC token: 100689817 methodIndex: 54016 delegateWrapperIndex: 0 methodInvoker: 0
        private bool ProtoBuf.Serializers.IProtoSerializer.get_ReturnsValue()
        {
            //
            // Disasemble & Code
            // 0x0298B8EC: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x0298B8F0: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B8F4 (43563252), len: 228  VirtAddr: 0x0298B8F4 RVA: 0x0298B8F4 token: 100689818 methodIndex: 54017 delegateWrapperIndex: 0 methodInvoker: 0
        public void Write(object value, ProtoBuf.ProtoWriter dest)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0298B8F4: STP x22, x21, [sp, #-0x30]! | stack[1152921514435656944] = ???;  stack[1152921514435656952] = ???;  //  dest_result_addr=1152921514435656944 |  dest_result_addr=1152921514435656952
            // 0x0298B8F8: STP x20, x19, [sp, #0x10]  | stack[1152921514435656960] = ???;  stack[1152921514435656968] = ???;  //  dest_result_addr=1152921514435656960 |  dest_result_addr=1152921514435656968
            // 0x0298B8FC: STP x29, x30, [sp, #0x20]  | stack[1152921514435656976] = ???;  stack[1152921514435656984] = ???;  //  dest_result_addr=1152921514435656976 |  dest_result_addr=1152921514435656984
            // 0x0298B900: ADD x29, sp, #0x20         | X29 = (1152921514435656944 + 32) = 1152921514435656976 (0x1000000249D7BD10);
            // 0x0298B904: SUB sp, sp, #0x10          | SP = (1152921514435656944 - 16) = 1152921514435656928 (0x1000000249D7BCE0);
            // 0x0298B908: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x0298B90C: LDRB w8, [x21, #0xf1c]     | W8 = (bool)static_value_037B8F1C;       
            // 0x0298B910: MOV x19, x2                | X19 = dest;//m1                         
            // 0x0298B914: MOV x20, x1                | X20 = value;//m1                        
            // 0x0298B918: TBNZ w8, #0, #0x298b934    | if (static_value_037B8F1C == true) goto label_0;
            // 0x0298B91C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x0298B920: LDR x8, [x8, #0x7d8]       | X8 = 0x2B90014;                         
            // 0x0298B924: LDR w0, [x8]               | W0 = 0x16C9;                            
            // 0x0298B928: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C9, ????);     
            // 0x0298B92C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B930: STRB w8, [x21, #0xf1c]     | static_value_037B8F1C = true;            //  dest_result_addr=58429212
            label_0:
            // 0x0298B934: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x0298B938: LDR x8, [x8, #0x778]       | X8 = 1152921504884428800;               
            // 0x0298B93C: LDR x0, [x8]               | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x0298B940: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x0298B944: TBZ w8, #0, #0x298b954     | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298B948: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x0298B94C: CBNZ w8, #0x298b954        | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298B950: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_2:
            // 0x0298B954: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x0298B958: LDR x8, [x8, #0xf90]       | X8 = 1152921504607805440;               
            // 0x0298B95C: LDR x21, [x8]              | X21 = typeof(System.Byte);              
            // 0x0298B960: CBNZ x20, #0x298b968       | if (value != null) goto label_3;        
            if(value != null)
            {
                goto label_3;
            }
            // 0x0298B964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_3:
            // 0x0298B968: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0298B96C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298B970: LDR x8, [x21, #0x30]       | X8 = System.Byte.__il2cppRuntimeField_element_class;
            // 0x0298B974: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Byte.__il2cppRuntimeField_element_class)
            // 0x0298B978: B.NE #0x298b9a0            | if (System.Object.__il2cppRuntimeField_element_class != System.Byte.__il2cppRuntimeField_element_class) goto label_4;
            // 0x0298B97C: MOV x0, x20                | X0 = value;//m1                         
            // 0x0298B980: BL #0x27bc4e8              | value.System.IDisposable.Dispose();     
            value.System.IDisposable.Dispose();
            // 0x0298B984: LDRB w1, [x0]              | W1 = typeof(System.Object);             
            // 0x0298B988: MOV x2, x19                | X2 = dest;//m1                          
            // 0x0298B98C: SUB sp, x29, #0x20         | SP = (1152921514435656976 - 32) = 1152921514435656944 (0x1000000249D7BCF0);
            // 0x0298B990: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B994: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0298B998: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0298B99C: B #0x2979080               | ProtoBuf.ProtoWriter.WriteByte(value:  value, writer:  null); return;
            ProtoBuf.ProtoWriter.WriteByte(value:  value, writer:  null);
            return;
            label_4:
            // 0x0298B9A0: ADD x8, sp, #8             | X8 = (1152921514435656928 + 8) = 1152921514435656936 (0x1000000249D7BCE8);
            // 0x0298B9A4: MOV x1, x21                | X1 = 1152921504607805440 (0x10000000000EA000);//ML01
            // 0x0298B9A8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298B9AC: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921514435644992]
            // 0x0298B9B0: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x0298B9B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B9B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x0298B9BC: ADD x0, sp, #8             | X0 = (1152921514435656928 + 8) = 1152921514435656936 (0x1000000249D7BCE8);
            // 0x0298B9C0: BL #0x299a140              | 
            // 0x0298B9C4: MOV x19, x0                | X19 = 1152921514435656936 (0x1000000249D7BCE8);//ML01
            // 0x0298B9C8: ADD x0, sp, #8             | X0 = (1152921514435656928 + 8) = 1152921514435656936 (0x1000000249D7BCE8);
            // 0x0298B9CC: BL #0x299a140              | 
            // 0x0298B9D0: MOV x0, x19                | X0 = 1152921514435656936 (0x1000000249D7BCE8);//ML01
            // 0x0298B9D4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000249D7BCE8, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B9D8 (43563480), len: 116  VirtAddr: 0x0298B9D8 RVA: 0x0298B9D8 token: 100689819 methodIndex: 54018 delegateWrapperIndex: 0 methodInvoker: 0
        public object Read(object value, ProtoBuf.ProtoReader source)
        {
            //
            // Disasemble & Code
            // 0x0298B9D8: STP x20, x19, [sp, #-0x20]! | stack[1152921514435789440] = ???;  stack[1152921514435789448] = ???;  //  dest_result_addr=1152921514435789440 |  dest_result_addr=1152921514435789448
            // 0x0298B9DC: STP x29, x30, [sp, #0x10]  | stack[1152921514435789456] = ???;  stack[1152921514435789464] = ???;  //  dest_result_addr=1152921514435789456 |  dest_result_addr=1152921514435789464
            // 0x0298B9E0: ADD x29, sp, #0x10         | X29 = (1152921514435789440 + 16) = 1152921514435789456 (0x1000000249D9C290);
            // 0x0298B9E4: SUB sp, sp, #0x10          | SP = (1152921514435789440 - 16) = 1152921514435789424 (0x1000000249D9C270);
            // 0x0298B9E8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x0298B9EC: LDRB w8, [x20, #0xf1d]     | W8 = (bool)static_value_037B8F1D;       
            // 0x0298B9F0: MOV x19, x2                | X19 = source;//m1                       
            // 0x0298B9F4: TBNZ w8, #0, #0x298ba10    | if (static_value_037B8F1D == true) goto label_0;
            // 0x0298B9F8: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x0298B9FC: LDR x8, [x8, #0x420]       | X8 = 0x2B90010;                         
            // 0x0298BA00: LDR w0, [x8]               | W0 = 0x16C8;                            
            // 0x0298BA04: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C8, ????);     
            // 0x0298BA08: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298BA0C: STRB w8, [x20, #0xf1d]     | static_value_037B8F1D = true;            //  dest_result_addr=58429213
            label_0:
            // 0x0298BA10: CBNZ x19, #0x298ba18       | if (source != null) goto label_1;       
            if(source != null)
            {
                goto label_1;
            }
            // 0x0298BA14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16C8, ????);     
            label_1:
            // 0x0298BA18: MOV x0, x19                | X0 = source;//m1                        
            // 0x0298BA1C: BL #0x297f0c0              | X0 = source.ReadByte();                 
            byte val_1 = source.ReadByte();
            // 0x0298BA20: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x0298BA24: LDR x8, [x8, #0xf90]       | X8 = 1152921504607805440;               
            // 0x0298BA28: STRB w0, [sp, #0xf]        | stack[1152921514435789439] = val_1;      //  dest_result_addr=1152921514435789439
            // 0x0298BA2C: ADD x1, sp, #0xf           | X1 = (1152921514435789424 + 15) = 1152921514435789439 (0x1000000249D9C27F);
            // 0x0298BA30: LDR x8, [x8]               | X8 = typeof(System.Byte);               
            // 0x0298BA34: MOV x0, x8                 | X0 = 1152921504607805440 (0x10000000000EA000);//ML01
            // 0x0298BA38: BL #0x27bc028              | X0 = 1152921514435841664 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Byte), val_1);
            // 0x0298BA3C: SUB sp, x29, #0x10         | SP = (1152921514435789456 - 16) = 1152921514435789440 (0x1000000249D9C280);
            // 0x0298BA40: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298BA44: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298BA48: RET                        |  return (System.Object)val_1;           
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298BA4C (43563596), len: 140  VirtAddr: 0x0298BA4C RVA: 0x0298BA4C token: 100689820 methodIndex: 54019 delegateWrapperIndex: 0 methodInvoker: 0
        private static ByteSerializer()
        {
            //
            // Disasemble & Code
            // 0x0298BA4C: STP x20, x19, [sp, #-0x20]! | stack[1152921514435917824] = ???;  stack[1152921514435917832] = ???;  //  dest_result_addr=1152921514435917824 |  dest_result_addr=1152921514435917832
            // 0x0298BA50: STP x29, x30, [sp, #0x10]  | stack[1152921514435917840] = ???;  stack[1152921514435917848] = ???;  //  dest_result_addr=1152921514435917840 |  dest_result_addr=1152921514435917848
            // 0x0298BA54: ADD x29, sp, #0x10         | X29 = (1152921514435917824 + 16) = 1152921514435917840 (0x1000000249DBB810);
            // 0x0298BA58: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298BA5C: LDRB w8, [x19, #0xf1e]     | W8 = (bool)static_value_037B8F1E;       
            // 0x0298BA60: TBNZ w8, #0, #0x298ba7c    | if (static_value_037B8F1E == true) goto label_0;
            // 0x0298BA64: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x0298BA68: LDR x8, [x8, #0x3b0]       | X8 = 0x2B90008;                         
            // 0x0298BA6C: LDR w0, [x8]               | W0 = 0x16C6;                            
            // 0x0298BA70: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C6, ????);     
            // 0x0298BA74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298BA78: STRB w8, [x19, #0xf1e]     | static_value_037B8F1E = true;            //  dest_result_addr=58429214
            label_0:
            // 0x0298BA7C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0298BA80: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0298BA84: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0298BA88: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x0298BA8C: LDR x8, [x8, #0x468]       | X8 = 1152921504607805440;               
            // 0x0298BA90: LDR x19, [x8]              | X19 = typeof(System.Byte);              
            // 0x0298BA94: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0298BA98: TBZ w8, #0, #0x298baa8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298BA9C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0298BAA0: CBNZ w8, #0x298baa8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298BAA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0298BAA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0298BAAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0298BAB0: MOV x1, x19                | X1 = 1152921504607805440 (0x10000000000EA000);//ML01
            // 0x0298BAB4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0298BAB8: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x0298BABC: LDR x8, [x8, #0xb68]       | X8 = 1152921504884908032;               
            // 0x0298BAC0: LDR x8, [x8]               | X8 = typeof(ProtoBuf.Serializers.ByteSerializer);
            // 0x0298BAC4: LDR x8, [x8, #0xa0]        | X8 = ProtoBuf.Serializers.ByteSerializer.__il2cppRuntimeField_static_fields;
            // 0x0298BAC8: STR x0, [x8]               | ProtoBuf.Serializers.ByteSerializer.expectedType = val_1;  //  dest_result_addr=1152921504884912128
            ProtoBuf.Serializers.ByteSerializer.expectedType = val_1;
            // 0x0298BACC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298BAD0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298BAD4: RET                        |  return;                                
            return;
        
        }
    
    }

}
