using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public class AssemblyNameReference : IMetadataScope, IMetadataTokenProvider
    {
        // Fields
        private string name; //  0x00000010
        private string culture; //  0x00000018
        private System.Version version; //  0x00000020
        private uint attributes; //  0x00000028
        private byte[] public_key; //  0x00000030
        private byte[] public_key_token; //  0x00000038
        private ILRuntime.Mono.Cecil.AssemblyHashAlgorithm hash_algorithm; //  0x00000040
        private byte[] hash; //  0x00000048
        internal ILRuntime.Mono.Cecil.MetadataToken token; //  0x00000050
        private string full_name; //  0x00000058
        
        // Properties
        public string Name { get; set; }
        public string Culture { get; set; }
        public System.Version Version { get; set; }
        public ILRuntime.Mono.Cecil.AssemblyAttributes Attributes { set; }
        public bool HasPublicKey { get; set; }
        public bool IsRetargetable { get; }
        public bool IsWindowsRuntime { get; }
        public byte[] PublicKey { get; set; }
        public byte[] PublicKeyToken { get; set; }
        public virtual ILRuntime.Mono.Cecil.MetadataScopeType MetadataScopeType { get; }
        public string FullName { get; }
        public ILRuntime.Mono.Cecil.AssemblyHashAlgorithm HashAlgorithm { set; }
        public virtual byte[] Hash { set; }
        public ILRuntime.Mono.Cecil.MetadataToken MetadataToken { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E55400 (15029248), len: 8  VirtAddr: 0x00E55400 RVA: 0x00E55400 token: 100663464 methodIndex: 19292 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_Name()
        {
            //
            // Disasemble & Code
            // 0x00E55400: LDR x0, [x0, #0x10]        | X0 = this.name; //P2                    
            // 0x00E55404: RET                        |  return (System.String)this.name;       
            return this.name;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55408 (15029256), len: 12  VirtAddr: 0x00E55408 RVA: 0x00E55408 token: 100663465 methodIndex: 19293 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Name(string value)
        {
            //
            // Disasemble & Code
            // 0x00E55408: STR x1, [x0, #0x10]        | this.name = value;                       //  dest_result_addr=1152921509422270736
            this.name = value;
            // 0x00E5540C: STR xzr, [x0, #0x58]       | this.full_name = null;                   //  dest_result_addr=1152921509422270808
            this.full_name = 0;
            // 0x00E55410: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55414 (15029268), len: 8  VirtAddr: 0x00E55414 RVA: 0x00E55414 token: 100663466 methodIndex: 19294 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_Culture()
        {
            //
            // Disasemble & Code
            // 0x00E55414: LDR x0, [x0, #0x18]        | X0 = this.culture; //P2                 
            // 0x00E55418: RET                        |  return (System.String)this.culture;    
            return this.culture;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5541C (15029276), len: 12  VirtAddr: 0x00E5541C RVA: 0x00E5541C token: 100663467 methodIndex: 19295 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Culture(string value)
        {
            //
            // Disasemble & Code
            // 0x00E5541C: STR x1, [x0, #0x18]        | this.culture = value;                    //  dest_result_addr=1152921509422511128
            this.culture = value;
            // 0x00E55420: STR xzr, [x0, #0x58]       | this.full_name = null;                   //  dest_result_addr=1152921509422511192
            this.full_name = 0;
            // 0x00E55424: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55428 (15029288), len: 8  VirtAddr: 0x00E55428 RVA: 0x00E55428 token: 100663468 methodIndex: 19296 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Version get_Version()
        {
            //
            // Disasemble & Code
            // 0x00E55428: LDR x0, [x0, #0x20]        | X0 = this.version; //P2                 
            // 0x00E5542C: RET                        |  return (System.Version)this.version;   
            return this.version;
            //  |  // // {name=val_0, type=System.Version, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55430 (15029296), len: 132  VirtAddr: 0x00E55430 RVA: 0x00E55430 token: 100663469 methodIndex: 19297 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Version(System.Version value)
        {
            //
            // Disasemble & Code
            // 0x00E55430: STP x22, x21, [sp, #-0x30]! | stack[1152921509422743536] = ???;  stack[1152921509422743544] = ???;  //  dest_result_addr=1152921509422743536 |  dest_result_addr=1152921509422743544
            // 0x00E55434: STP x20, x19, [sp, #0x10]  | stack[1152921509422743552] = ???;  stack[1152921509422743560] = ???;  //  dest_result_addr=1152921509422743552 |  dest_result_addr=1152921509422743560
            // 0x00E55438: STP x29, x30, [sp, #0x20]  | stack[1152921509422743568] = ???;  stack[1152921509422743576] = ???;  //  dest_result_addr=1152921509422743568 |  dest_result_addr=1152921509422743576
            // 0x00E5543C: ADD x29, sp, #0x20         | X29 = (1152921509422743536 + 32) = 1152921509422743568 (0x100000011F0CC010);
            // 0x00E55440: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E55444: LDRB w8, [x21, #0xab8]     | W8 = (bool)static_value_03734AB8;       
            // 0x00E55448: MOV x20, x1                | X20 = value;//m1                        
            // 0x00E5544C: MOV x19, x0                | X19 = 1152921509422755584 (0x100000011F0CEF00);//ML01
            // 0x00E55450: TBNZ w8, #0, #0xe5546c     | if (static_value_03734AB8 == true) goto label_0;
            // 0x00E55454: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00E55458: LDR x8, [x8, #0x718]       | X8 = 0x2B8EA50;                         
            // 0x00E5545C: LDR w0, [x8]               | W0 = 0x1152;                            
            // 0x00E55460: BL #0x2782188              | X0 = sub_2782188( ?? 0x1152, ????);     
            // 0x00E55464: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E55468: STRB w8, [x21, #0xab8]     | static_value_03734AB8 = true;            //  dest_result_addr=57887416
            label_0:
            // 0x00E5546C: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E55470: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E55474: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E55478: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E5547C: TBZ w8, #0, #0xe5548c      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E55480: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E55484: CBNZ w8, #0xe5548c         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E55488: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E5548C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55490: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E55494: MOV x1, x20                | X1 = value;//m1                         
            // 0x00E55498: BL #0x11d8b84              | X0 = ILRuntime.Mono.Cecil.Mixin.CheckVersion(version:  0);
            System.Version val_1 = ILRuntime.Mono.Cecil.Mixin.CheckVersion(version:  0);
            // 0x00E5549C: STR xzr, [x19, #0x58]      | this.full_name = null;                   //  dest_result_addr=1152921509422755672
            this.full_name = 0;
            // 0x00E554A0: STR x0, [x19, #0x20]       | this.version = val_1;                    //  dest_result_addr=1152921509422755616
            this.version = val_1;
            // 0x00E554A4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E554A8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E554AC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E554B0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E554B4 (15029428), len: 8  VirtAddr: 0x00E554B4 RVA: 0x00E554B4 token: 100663470 methodIndex: 19298 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Attributes(ILRuntime.Mono.Cecil.AssemblyAttributes value)
        {
            //
            // Disasemble & Code
            // 0x00E554B4: STR w1, [x0, #0x28]        | this.attributes = value;                 //  dest_result_addr=1152921509422879912
            this.attributes = value;
            // 0x00E554B8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E554BC (15029436), len: 116  VirtAddr: 0x00E554BC RVA: 0x00E554BC token: 100663471 methodIndex: 19299 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_HasPublicKey()
        {
            //
            // Disasemble & Code
            // 0x00E554BC: STP x20, x19, [sp, #-0x20]! | stack[1152921509422983936] = ???;  stack[1152921509422983944] = ???;  //  dest_result_addr=1152921509422983936 |  dest_result_addr=1152921509422983944
            // 0x00E554C0: STP x29, x30, [sp, #0x10]  | stack[1152921509422983952] = ???;  stack[1152921509422983960] = ???;  //  dest_result_addr=1152921509422983952 |  dest_result_addr=1152921509422983960
            // 0x00E554C4: ADD x29, sp, #0x10         | X29 = (1152921509422983936 + 16) = 1152921509422983952 (0x100000011F106B10);
            // 0x00E554C8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E554CC: LDRB w8, [x20, #0xab9]     | W8 = (bool)static_value_03734AB9;       
            // 0x00E554D0: MOV x19, x0                | X19 = 1152921509422995968 (0x100000011F109A00);//ML01
            // 0x00E554D4: TBNZ w8, #0, #0xe554f0     | if (static_value_03734AB9 == true) goto label_0;
            // 0x00E554D8: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x00E554DC: LDR x8, [x8, #0x290]       | X8 = 0x2B8EA2C;                         
            // 0x00E554E0: LDR w0, [x8]               | W0 = 0x1149;                            
            // 0x00E554E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1149, ????);     
            // 0x00E554E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E554EC: STRB w8, [x20, #0xab9]     | static_value_03734AB9 = true;            //  dest_result_addr=57887417
            label_0:
            // 0x00E554F0: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E554F4: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E554F8: LDR w19, [x19, #0x28]      | W19 = this.attributes; //P2             
            // 0x00E554FC: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E55500: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E55504: TBZ w8, #0, #0xe55514      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E55508: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5550C: CBNZ w8, #0xe55514         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E55510: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E55514: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E55518: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5551C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55520: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00E55524: MOV w1, w19                | W1 = this.attributes;//m1               
            // 0x00E55528: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E5552C: B #0x11d954c               | return ILRuntime.Mono.Cecil.Mixin.GetAttributes(self:  0, attributes:  this.attributes);
            return ILRuntime.Mono.Cecil.Mixin.GetAttributes(self:  0, attributes:  this.attributes);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55530 (15029552), len: 140  VirtAddr: 0x00E55530 RVA: 0x00E55530 token: 100663472 methodIndex: 19300 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_HasPublicKey(bool value)
        {
            //
            // Disasemble & Code
            // 0x00E55530: STP x22, x21, [sp, #-0x30]! | stack[1152921509423095920] = ???;  stack[1152921509423095928] = ???;  //  dest_result_addr=1152921509423095920 |  dest_result_addr=1152921509423095928
            // 0x00E55534: STP x20, x19, [sp, #0x10]  | stack[1152921509423095936] = ???;  stack[1152921509423095944] = ???;  //  dest_result_addr=1152921509423095936 |  dest_result_addr=1152921509423095944
            // 0x00E55538: STP x29, x30, [sp, #0x20]  | stack[1152921509423095952] = ???;  stack[1152921509423095960] = ???;  //  dest_result_addr=1152921509423095952 |  dest_result_addr=1152921509423095960
            // 0x00E5553C: ADD x29, sp, #0x20         | X29 = (1152921509423095920 + 32) = 1152921509423095952 (0x100000011F122090);
            // 0x00E55540: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E55544: LDRB w8, [x21, #0xaba]     | W8 = (bool)static_value_03734ABA;       
            // 0x00E55548: MOV w20, w1                | W20 = value;//m1                        
            // 0x00E5554C: MOV x19, x0                | X19 = 1152921509423107968 (0x100000011F124F80);//ML01
            // 0x00E55550: TBNZ w8, #0, #0xe5556c     | if (static_value_03734ABA == true) goto label_0;
            // 0x00E55554: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00E55558: LDR x8, [x8, #0xa38]       | X8 = 0x2B8EA48;                         
            // 0x00E5555C: LDR w0, [x8]               | W0 = 0x1150;                            
            // 0x00E55560: BL #0x2782188              | X0 = sub_2782188( ?? 0x1150, ????);     
            // 0x00E55564: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E55568: STRB w8, [x21, #0xaba]     | static_value_03734ABA = true;            //  dest_result_addr=57887418
            label_0:
            // 0x00E5556C: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E55570: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E55574: LDR w21, [x19, #0x28]      | W21 = this.attributes; //P2             
            // 0x00E55578: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E5557C: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E55580: TBZ w8, #0, #0xe55590      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E55584: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E55588: CBNZ w8, #0xe55590         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E5558C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E55590: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55594: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00E55598: AND w3, w20, #1            | W3 = (value & 1);                       
            bool val_1 = value;
            // 0x00E5559C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00E555A0: MOV w1, w21                | W1 = this.attributes;//m1               
            // 0x00E555A4: BL #0x11d9558              | X0 = ILRuntime.Mono.Cecil.Mixin.SetAttributes(self:  0, attributes:  this.attributes, value:  true);
            uint val_2 = ILRuntime.Mono.Cecil.Mixin.SetAttributes(self:  0, attributes:  this.attributes, value:  true);
            // 0x00E555A8: STR w0, [x19, #0x28]       | this.attributes = val_2;                 //  dest_result_addr=1152921509423108008
            this.attributes = val_2;
            // 0x00E555AC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E555B0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E555B4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E555B8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E555BC (15029692), len: 116  VirtAddr: 0x00E555BC RVA: 0x00E555BC token: 100663473 methodIndex: 19301 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsRetargetable()
        {
            //
            // Disasemble & Code
            // 0x00E555BC: STP x20, x19, [sp, #-0x20]! | stack[1152921509423207936] = ???;  stack[1152921509423207944] = ???;  //  dest_result_addr=1152921509423207936 |  dest_result_addr=1152921509423207944
            // 0x00E555C0: STP x29, x30, [sp, #0x10]  | stack[1152921509423207952] = ???;  stack[1152921509423207960] = ???;  //  dest_result_addr=1152921509423207952 |  dest_result_addr=1152921509423207960
            // 0x00E555C4: ADD x29, sp, #0x10         | X29 = (1152921509423207936 + 16) = 1152921509423207952 (0x100000011F13D610);
            // 0x00E555C8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E555CC: LDRB w8, [x20, #0xabb]     | W8 = (bool)static_value_03734ABB;       
            // 0x00E555D0: MOV x19, x0                | X19 = 1152921509423219968 (0x100000011F140500);//ML01
            // 0x00E555D4: TBNZ w8, #0, #0xe555f0     | if (static_value_03734ABB == true) goto label_0;
            // 0x00E555D8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00E555DC: LDR x8, [x8, #0x260]       | X8 = 0x2B8EA30;                         
            // 0x00E555E0: LDR w0, [x8]               | W0 = 0x114A;                            
            // 0x00E555E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x114A, ????);     
            // 0x00E555E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E555EC: STRB w8, [x20, #0xabb]     | static_value_03734ABB = true;            //  dest_result_addr=57887419
            label_0:
            // 0x00E555F0: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E555F4: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E555F8: LDR w19, [x19, #0x28]      | W19 = this.attributes; //P2             
            // 0x00E555FC: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E55600: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E55604: TBZ w8, #0, #0xe55614      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E55608: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5560C: CBNZ w8, #0xe55614         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E55610: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E55614: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E55618: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5561C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55620: ORR w2, wzr, #0x100        | W2 = 256(0x100);                        
            // 0x00E55624: MOV w1, w19                | W1 = this.attributes;//m1               
            // 0x00E55628: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E5562C: B #0x11d954c               | return ILRuntime.Mono.Cecil.Mixin.GetAttributes(self:  0, attributes:  this.attributes);
            return ILRuntime.Mono.Cecil.Mixin.GetAttributes(self:  0, attributes:  this.attributes);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55630 (15029808), len: 116  VirtAddr: 0x00E55630 RVA: 0x00E55630 token: 100663474 methodIndex: 19302 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsWindowsRuntime()
        {
            //
            // Disasemble & Code
            // 0x00E55630: STP x20, x19, [sp, #-0x20]! | stack[1152921509423319936] = ???;  stack[1152921509423319944] = ???;  //  dest_result_addr=1152921509423319936 |  dest_result_addr=1152921509423319944
            // 0x00E55634: STP x29, x30, [sp, #0x10]  | stack[1152921509423319952] = ???;  stack[1152921509423319960] = ???;  //  dest_result_addr=1152921509423319952 |  dest_result_addr=1152921509423319960
            // 0x00E55638: ADD x29, sp, #0x10         | X29 = (1152921509423319936 + 16) = 1152921509423319952 (0x100000011F158B90);
            // 0x00E5563C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E55640: LDRB w8, [x20, #0xabc]     | W8 = (bool)static_value_03734ABC;       
            // 0x00E55644: MOV x19, x0                | X19 = 1152921509423331968 (0x100000011F15BA80);//ML01
            // 0x00E55648: TBNZ w8, #0, #0xe55664     | if (static_value_03734ABC == true) goto label_0;
            // 0x00E5564C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00E55650: LDR x8, [x8, #0xe88]       | X8 = 0x2B8EA34;                         
            // 0x00E55654: LDR w0, [x8]               | W0 = 0x114B;                            
            // 0x00E55658: BL #0x2782188              | X0 = sub_2782188( ?? 0x114B, ????);     
            // 0x00E5565C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E55660: STRB w8, [x20, #0xabc]     | static_value_03734ABC = true;            //  dest_result_addr=57887420
            label_0:
            // 0x00E55664: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E55668: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E5566C: LDR w19, [x19, #0x28]      | W19 = this.attributes; //P2             
            // 0x00E55670: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E55674: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E55678: TBZ w8, #0, #0xe55688      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E5567C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E55680: CBNZ w8, #0xe55688         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E55684: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E55688: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5568C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55690: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55694: ORR w2, wzr, #0x200        | W2 = 512(0x200);                        
            // 0x00E55698: MOV w1, w19                | W1 = this.attributes;//m1               
            // 0x00E5569C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E556A0: B #0x11d954c               | return ILRuntime.Mono.Cecil.Mixin.GetAttributes(self:  0, attributes:  this.attributes);
            return ILRuntime.Mono.Cecil.Mixin.GetAttributes(self:  0, attributes:  this.attributes);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E556A4 (15029924), len: 116  VirtAddr: 0x00E556A4 RVA: 0x00E556A4 token: 100663475 methodIndex: 19303 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] get_PublicKey()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            System.Byte[] val_2;
            //  | 
            var val_3;
            // 0x00E556A4: STP x20, x19, [sp, #-0x20]! | stack[1152921509423468800] = ???;  stack[1152921509423468808] = ???;  //  dest_result_addr=1152921509423468800 |  dest_result_addr=1152921509423468808
            // 0x00E556A8: STP x29, x30, [sp, #0x10]  | stack[1152921509423468816] = ???;  stack[1152921509423468824] = ???;  //  dest_result_addr=1152921509423468816 |  dest_result_addr=1152921509423468824
            // 0x00E556AC: ADD x29, sp, #0x10         | X29 = (1152921509423468800 + 16) = 1152921509423468816 (0x100000011F17D110);
            // 0x00E556B0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E556B4: LDRB w8, [x20, #0xabd]     | W8 = (bool)static_value_03734ABD;       
            // 0x00E556B8: MOV x19, x0                | X19 = 1152921509423480832 (0x100000011F180000);//ML01
            val_1 = this;
            // 0x00E556BC: TBNZ w8, #0, #0xe556d8     | if (static_value_03734ABD == true) goto label_0;
            // 0x00E556C0: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x00E556C4: LDR x8, [x8, #0x9c8]       | X8 = 0x2B8EA38;                         
            // 0x00E556C8: LDR w0, [x8]               | W0 = 0x114C;                            
            // 0x00E556CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x114C, ????);     
            // 0x00E556D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E556D4: STRB w8, [x20, #0xabd]     | static_value_03734ABD = true;            //  dest_result_addr=57887421
            label_0:
            // 0x00E556D8: LDR x0, [x19, #0x30]       | X0 = this.public_key; //P2              
            val_2 = this.public_key;
            // 0x00E556DC: CBNZ x0, #0xe5570c         | if (this.public_key != null) goto label_1;
            if(val_2 != null)
            {
                goto label_1;
            }
            // 0x00E556E0: ADRP x19, #0x365b000       | X19 = 56995840 (0x365B000);             
            // 0x00E556E4: LDR x19, [x19, #0x618]     | X19 = 1152921504736825344;              
            val_1 = 1152921504736825344;
            // 0x00E556E8: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_3 = null;
            // 0x00E556EC: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_10A;
            // 0x00E556F0: TBZ w8, #0, #0xe55704      | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E556F4: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished;
            // 0x00E556F8: CBNZ w8, #0xe55704         | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E556FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Empty<T>), ????);
            // 0x00E55700: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_3 = null;
            label_3:
            // 0x00E55704: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_static_fields;
            // 0x00E55708: LDR x0, [x8]               | X0 = ILRuntime.Mono.Empty<T>.Array;     
            val_2 = ILRuntime.Mono.Empty<T>.Array;
            label_1:
            // 0x00E5570C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E55710: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E55714: RET                        |  return (System.Byte[])ILRuntime.Mono.Empty<T>.Array;
            return (System.Byte[])val_2;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55718 (15030040), len: 204  VirtAddr: 0x00E55718 RVA: 0x00E55718 token: 100663476 methodIndex: 19304 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_PublicKey(byte[] value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x00E55718: STP x22, x21, [sp, #-0x30]! | stack[1152921509423655536] = ???;  stack[1152921509423655544] = ???;  //  dest_result_addr=1152921509423655536 |  dest_result_addr=1152921509423655544
            // 0x00E5571C: STP x20, x19, [sp, #0x10]  | stack[1152921509423655552] = ???;  stack[1152921509423655560] = ???;  //  dest_result_addr=1152921509423655552 |  dest_result_addr=1152921509423655560
            // 0x00E55720: STP x29, x30, [sp, #0x20]  | stack[1152921509423655568] = ???;  stack[1152921509423655576] = ???;  //  dest_result_addr=1152921509423655568 |  dest_result_addr=1152921509423655576
            // 0x00E55724: ADD x29, sp, #0x20         | X29 = (1152921509423655536 + 32) = 1152921509423655568 (0x100000011F1AAA90);
            // 0x00E55728: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5572C: LDRB w8, [x21, #0xabe]     | W8 = (bool)static_value_03734ABE;       
            // 0x00E55730: MOV x20, x1                | X20 = value;//m1                        
            // 0x00E55734: MOV x19, x0                | X19 = 1152921509423667584 (0x100000011F1AD980);//ML01
            // 0x00E55738: TBNZ w8, #0, #0xe55754     | if (static_value_03734ABE == true) goto label_0;
            // 0x00E5573C: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x00E55740: LDR x8, [x8, #0x238]       | X8 = 0x2B8EA4C;                         
            // 0x00E55744: LDR w0, [x8]               | W0 = 0x1151;                            
            // 0x00E55748: BL #0x2782188              | X0 = sub_2782188( ?? 0x1151, ????);     
            // 0x00E5574C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E55750: STRB w8, [x21, #0xabe]     | static_value_03734ABE = true;            //  dest_result_addr=57887422
            label_0:
            // 0x00E55754: STR x20, [x19, #0x30]      | this.public_key = value;                 //  dest_result_addr=1152921509423667632
            this.public_key = value;
            // 0x00E55758: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E5575C: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E55760: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E55764: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E55768: TBZ w8, #0, #0xe55778      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E5576C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E55770: CBNZ w8, #0xe55778         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E55774: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E55778: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00E5577C: LDR x8, [x8, #0xb40]       | X8 = 1152921509423642560;               
            // 0x00E55780: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55784: MOV x1, x20                | X1 = value;//m1                         
            // 0x00E55788: LDR x2, [x8]               | X2 = public static System.Boolean ILRuntime.Mono.Cecil.Mixin::IsNullOrEmpty<System.Byte>(T[] self);
            // 0x00E5578C: BL #0x12f94f8              | X0 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<System.Byte>(self:  0);
            bool val_1 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<System.Byte>(self:  0);
            // 0x00E55790: MVN w8, w0                 | W8 = ~(val_1);                          
            // 0x00E55794: AND w1, w8, #1             | W1 = (~(val_1) & 1);                    
            bool val_2 = (~val_1) & 1;
            // 0x00E55798: MOV x0, x19                | X0 = 1152921509423667584 (0x100000011F1AD980);//ML01
            // 0x00E5579C: BL #0xe55530               | this.set_HasPublicKey(value:  bool val_2 = (~val_1) & 1);
            this.HasPublicKey = val_2;
            // 0x00E557A0: ADRP x20, #0x365b000       | X20 = 56995840 (0x365B000);             
            // 0x00E557A4: LDR x20, [x20, #0x618]     | X20 = 1152921504736825344;              
            // 0x00E557A8: LDR x0, [x20]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_3 = null;
            // 0x00E557AC: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_10A;
            // 0x00E557B0: TBZ w8, #0, #0xe557c4      | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00E557B4: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished;
            // 0x00E557B8: CBNZ w8, #0xe557c4         | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00E557BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Empty<T>), ????);
            // 0x00E557C0: LDR x0, [x20]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_3 = null;
            label_4:
            // 0x00E557C4: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_static_fields;
            // 0x00E557C8: LDR x8, [x8]               | X8 = ILRuntime.Mono.Empty<T>.Array;     
            // 0x00E557CC: STR xzr, [x19, #0x58]      | this.full_name = null;                   //  dest_result_addr=1152921509423667672
            this.full_name = 0;
            // 0x00E557D0: STR x8, [x19, #0x38]       | this.public_key_token = ILRuntime.Mono.Empty<T>.Array;  //  dest_result_addr=1152921509423667640
            this.public_key_token = ILRuntime.Mono.Empty<T>.Array;
            // 0x00E557D4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E557D8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E557DC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E557E0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E557E4 (15030244), len: 368  VirtAddr: 0x00E557E4 RVA: 0x00E557E4 token: 100663477 methodIndex: 19305 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] get_PublicKeyToken()
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            int val_7;
            //  | 
            System.Byte[] val_8;
            //  | 
            System.Byte[] val_9;
            //  | 
            var val_10;
            //  | 
            T[] val_11;
            // 0x00E557E4: STP x22, x21, [sp, #-0x30]! | stack[1152921509423951856] = ???;  stack[1152921509423951864] = ???;  //  dest_result_addr=1152921509423951856 |  dest_result_addr=1152921509423951864
            // 0x00E557E8: STP x20, x19, [sp, #0x10]  | stack[1152921509423951872] = ???;  stack[1152921509423951880] = ???;  //  dest_result_addr=1152921509423951872 |  dest_result_addr=1152921509423951880
            // 0x00E557EC: STP x29, x30, [sp, #0x20]  | stack[1152921509423951888] = ???;  stack[1152921509423951896] = ???;  //  dest_result_addr=1152921509423951888 |  dest_result_addr=1152921509423951896
            // 0x00E557F0: ADD x29, sp, #0x20         | X29 = (1152921509423951856 + 32) = 1152921509423951888 (0x100000011F1F3010);
            // 0x00E557F4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E557F8: LDRB w8, [x20, #0xabf]     | W8 = (bool)static_value_03734ABF;       
            // 0x00E557FC: MOV x19, x0                | X19 = 1152921509423963904 (0x100000011F1F5F00);//ML01
            val_6 = this;
            // 0x00E55800: TBNZ w8, #0, #0xe5581c     | if (static_value_03734ABF == true) goto label_0;
            // 0x00E55804: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00E55808: LDR x8, [x8, #0xb30]       | X8 = 0x2B8EA3C;                         
            // 0x00E5580C: LDR w0, [x8]               | W0 = 0x114D;                            
            // 0x00E55810: BL #0x2782188              | X0 = sub_2782188( ?? 0x114D, ????);     
            // 0x00E55814: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E55818: STRB w8, [x20, #0xabf]     | static_value_03734ABF = true;            //  dest_result_addr=57887423
            label_0:
            // 0x00E5581C: ADRP x21, #0x362e000       | X21 = 56811520 (0x362E000);             
            // 0x00E55820: LDR x21, [x21, #0xa48]     | X21 = 1152921504737091584;              
            val_7 = 1152921504737091584;
            // 0x00E55824: LDR x20, [x19, #0x38]      | X20 = this.public_key_token; //P2       
            // 0x00E55828: LDR x0, [x21]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E5582C: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E55830: TBZ w8, #0, #0xe55840      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E55834: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E55838: CBNZ w8, #0xe55840         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E5583C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E55840: ADRP x22, #0x35ea000       | X22 = 56532992 (0x35EA000);             
            // 0x00E55844: LDR x22, [x22, #0xb40]     | X22 = 1152921509423642560;              
            // 0x00E55848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5584C: MOV x1, x20                | X1 = this.public_key_token;//m1         
            // 0x00E55850: LDR x2, [x22]              | X2 = public static System.Boolean ILRuntime.Mono.Cecil.Mixin::IsNullOrEmpty<System.Byte>(T[] self);
            // 0x00E55854: BL #0x12f94f8              | X0 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<System.Byte>(self:  0);
            bool val_1 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<System.Byte>(self:  0);
            // 0x00E55858: TBZ w0, #0, #0xe55890      | if (val_1 == false) goto label_3;       
            if(val_1 == false)
            {
                goto label_3;
            }
            // 0x00E5585C: LDR x0, [x21]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E55860: LDR x20, [x19, #0x30]      | X20 = this.public_key; //P2             
            // 0x00E55864: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E55868: TBZ w8, #0, #0xe55878      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00E5586C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E55870: CBNZ w8, #0xe55878         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00E55874: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_5:
            // 0x00E55878: LDR x2, [x22]              | X2 = public static System.Boolean ILRuntime.Mono.Cecil.Mixin::IsNullOrEmpty<System.Byte>(T[] self);
            // 0x00E5587C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55880: MOV x1, x20                | X1 = this.public_key;//m1               
            // 0x00E55884: BL #0x12f94f8              | X0 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<System.Byte>(self:  0);
            bool val_2 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<System.Byte>(self:  0);
            // 0x00E55888: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x00E5588C: TBZ w8, #0, #0xe55898      | if ((val_2 & 1) == false) goto label_6; 
            if(val_3 == false)
            {
                goto label_6;
            }
            label_3:
            // 0x00E55890: LDR x20, [x19, #0x38]      | X20 = this.public_key_token; //P2       
            val_8 = this.public_key_token;
            // 0x00E55894: B #0xe55910                |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x00E55898: MOV x0, x19                | X0 = 1152921509423963904 (0x100000011F1F5F00);//ML01
            // 0x00E5589C: BL #0xe55954               | X0 = this.HashPublicKey();              
            System.Byte[] val_4 = this.HashPublicKey();
            // 0x00E558A0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00E558A4: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00E558A8: MOV x21, x0                | X21 = val_4;//m1                        
            val_7 = val_4;
            // 0x00E558AC: LDR x20, [x8]              | X20 = typeof(System.Byte[]);            
            // 0x00E558B0: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E558B4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00E558B8: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x00E558BC: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E558C0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00E558C4: MOV x20, x0                | X20 = 1152921504996170800 (0x1000000017349C30);//ML01
            val_9 = null;
            // 0x00E558C8: CBNZ x21, #0xe558d0        | if (val_4 != null) goto label_8;        
            if(val_7 != null)
            {
                goto label_8;
            }
            // 0x00E558CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_8:
            // 0x00E558D0: LDR w8, [x21, #0x18]       | W8 = val_4.Length; //P2                 
            // 0x00E558D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E558D8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00E558DC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00E558E0: SUB w2, w8, #8             | W2 = (val_4.Length - 8);                
            int val_5 = val_4.Length - 8;
            // 0x00E558E4: ORR w5, wzr, #8            | W5 = 8(0x8);                            
            // 0x00E558E8: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x00E558EC: MOV x3, x20                | X3 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E558F0: BL #0x18ce87c              | System.Array.Copy(sourceArray:  0, sourceIndex:  val_7, destinationArray:  int val_5 = val_4.Length - 8, destinationIndex:  389323824, length:  0);
            System.Array.Copy(sourceArray:  0, sourceIndex:  val_7, destinationArray:  val_5, destinationIndex:  389323824, length:  0);
            // 0x00E558F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E558F8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00E558FC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00E55900: ORR w3, wzr, #8            | W3 = 8(0x8);                            
            // 0x00E55904: MOV x1, x20                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E55908: BL #0x18b6540              | System.Array.Reverse(array:  0, index:  389323824, length:  0);
            System.Array.Reverse(array:  0, index:  389323824, length:  0);
            // 0x00E5590C: STR x20, [x19, #0x38]      | this.public_key_token = typeof(System.Byte[]);  //  dest_result_addr=1152921509423963960
            this.public_key_token = val_9;
            label_7:
            // 0x00E55910: CBNZ x20, #0xe55940        | if ( != null) goto label_9;             
            if(null != null)
            {
                goto label_9;
            }
            // 0x00E55914: ADRP x19, #0x365b000       | X19 = 56995840 (0x365B000);             
            // 0x00E55918: LDR x19, [x19, #0x618]     | X19 = 1152921504736825344;              
            val_6 = 1152921504736825344;
            // 0x00E5591C: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_10 = null;
            // 0x00E55920: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_10A;
            // 0x00E55924: TBZ w8, #0, #0xe55938      | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00E55928: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished;
            // 0x00E5592C: CBNZ w8, #0xe55938         | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00E55930: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Empty<T>), ????);
            // 0x00E55934: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_10 = null;
            label_11:
            // 0x00E55938: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_static_fields;
            // 0x00E5593C: LDR x20, [x8]              | X20 = ILRuntime.Mono.Empty<T>.Array;    
            val_11 = ILRuntime.Mono.Empty<T>.Array;
            label_9:
            // 0x00E55940: MOV x0, x20                | X0 = ILRuntime.Mono.Empty<T>.Array;//m1 
            // 0x00E55944: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E55948: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5594C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E55950: RET                        |  return (System.Byte[])ILRuntime.Mono.Empty<T>.Array;
            return (System.Byte[])val_11;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55A94 (15030932), len: 12  VirtAddr: 0x00E55A94 RVA: 0x00E55A94 token: 100663478 methodIndex: 19306 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_PublicKeyToken(byte[] value)
        {
            //
            // Disasemble & Code
            // 0x00E55A94: STR x1, [x0, #0x38]        | this.public_key_token = value;           //  dest_result_addr=1152921509424260280
            this.public_key_token = value;
            // 0x00E55A98: STR xzr, [x0, #0x58]       | this.full_name = null;                   //  dest_result_addr=1152921509424260312
            this.full_name = 0;
            // 0x00E55A9C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55954 (15030612), len: 320  VirtAddr: 0x00E55954 RVA: 0x00E55954 token: 100663479 methodIndex: 19307 delegateWrapperIndex: 0 methodInvoker: 0
        private byte[] HashPublicKey()
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x00E55954: STP x22, x21, [sp, #-0x30]! | stack[1152921509424483056] = ???;  stack[1152921509424483064] = ???;  //  dest_result_addr=1152921509424483056 |  dest_result_addr=1152921509424483064
            // 0x00E55958: STP x20, x19, [sp, #0x10]  | stack[1152921509424483072] = ???;  stack[1152921509424483080] = ???;  //  dest_result_addr=1152921509424483072 |  dest_result_addr=1152921509424483080
            // 0x00E5595C: STP x29, x30, [sp, #0x20]  | stack[1152921509424483088] = ???;  stack[1152921509424483096] = ???;  //  dest_result_addr=1152921509424483088 |  dest_result_addr=1152921509424483096
            // 0x00E55960: ADD x29, sp, #0x20         | X29 = (1152921509424483056 + 32) = 1152921509424483088 (0x100000011F274B10);
            // 0x00E55964: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E55968: LDRB w8, [x19, #0xac0]     | W8 = (bool)static_value_03734AC0;       
            // 0x00E5596C: MOV x20, x0                | X20 = 1152921509424495104 (0x100000011F277A00);//ML01
            // 0x00E55970: TBNZ w8, #0, #0xe5598c     | if (static_value_03734AC0 == true) goto label_0;
            // 0x00E55974: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00E55978: LDR x8, [x8, #0xf68]       | X8 = 0x2B8EA40;                         
            // 0x00E5597C: LDR w0, [x8]               | W0 = 0x114E;                            
            // 0x00E55980: BL #0x2782188              | X0 = sub_2782188( ?? 0x114E, ????);     
            // 0x00E55984: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E55988: STRB w8, [x19, #0xac0]     | static_value_03734AC0 = true;            //  dest_result_addr=57887424
            label_0:
            // 0x00E5598C: LDR w8, [x20, #0x40]       | W8 = this.hash_algorithm; //P2          
            // 0x00E55990: MOVZ w9, #0x8003           | W9 = 32771 (0x8003);//ML01              
            // 0x00E55994: CMP w8, w9                 | STATE = COMPARE(this.hash_algorithm, 0x8003)
            // 0x00E55998: B.NE #0xe559ac             | if (this.hash_algorithm != 0x8003) goto label_1;
            if(this.hash_algorithm != 32771)
            {
                goto label_1;
            }
            // 0x00E5599C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E559A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E559A4: BL #0x112843c              | X0 = System.Security.Cryptography.MD5.Create();
            System.Security.Cryptography.MD5 val_1 = System.Security.Cryptography.MD5.Create();
            // 0x00E559A8: B #0xe559b8                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00E559AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E559B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E559B4: BL #0x18959d8              | X0 = System.Security.Cryptography.SHA1.Create();
            System.Security.Cryptography.SHA1 val_2 = System.Security.Cryptography.SHA1.Create();
            label_2:
            // 0x00E559B8: LDR x20, [x20, #0x30]      | X20 = this.public_key; //P2             
            // 0x00E559BC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00E559C0: CBNZ x19, #0xe559c8        | if (val_2 != null) goto label_3;        
            if(val_2 != null)
            {
                goto label_3;
            }
            // 0x00E559C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x00E559C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E559CC: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00E559D0: MOV x1, x20                | X1 = this.public_key;//m1               
            // 0x00E559D4: BL #0x1126134              | X0 = val_2.ComputeHash(buffer:  this.public_key);
            System.Byte[] val_3 = val_2.ComputeHash(buffer:  this.public_key);
            // 0x00E559D8: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00E559DC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x00E559E0: ORR w22, wzr, #0x38        | W22 = 56(0x38);                         
            label_11:
            // 0x00E559E4: CBZ x19, #0xe55a50         | if (val_2 == null) goto label_4;        
            if(val_2 == null)
            {
                goto label_4;
            }
            // 0x00E559E8: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00E559EC: LDR x8, [x19]              | X8 = typeof(System.Security.Cryptography.SHA1);
            // 0x00E559F0: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00E559F4: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00E559F8: LDRH w9, [x8, #0x102]      | W9 = System.Security.Cryptography.SHA1.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E559FC: CBZ x9, #0xe55a28          | if (System.Security.Cryptography.SHA1.__il2cppRuntimeField_interface_offsets_count == 0) goto label_5;
            // 0x00E55A00: LDR x10, [x8, #0x98]       | X10 = System.Security.Cryptography.SHA1.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E55A04: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_5 = 0;
            // 0x00E55A08: ADD x10, x10, #8           | X10 = (System.Security.Cryptography.SHA1.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504644902920 (0x100000000244B008);
            label_7:
            // 0x00E55A0C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E55A10: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00E55A14: B.EQ #0xe55a38             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_6;
            // 0x00E55A18: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_5 = val_5 + 1;
            // 0x00E55A1C: ADD x10, x10, #0x10        | X10 = (1152921504644902920 + 16) = 1152921504644902936 (0x100000000244B018);
            // 0x00E55A20: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Security.Cryptography.SHA1.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E55A24: B.LO #0xe55a0c             | if (0 < System.Security.Cryptography.SHA1.__il2cppRuntimeField_interface_offsets_count) goto label_7;
            label_5:
            // 0x00E55A28: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00E55A2C: MOV x0, x19                | X0 = val_2;//m1                         
            val_6 = val_2;
            // 0x00E55A30: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
            // 0x00E55A34: B #0xe55a44                |  goto label_8;                          
            goto label_8;
            label_6:
            // 0x00E55A38: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E55A3C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504644866048 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00E55A40: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504644866048 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_8:
            // 0x00E55A44: LDP x8, x1, [x0]           | X8 = typeof(System.Byte[]);              //  | 
            // 0x00E55A48: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00E55A4C: BLR x8                     | X0 = sub_1000000017349C30( ?? val_2, ????);
            label_4:
            // 0x00E55A50: CMP w22, #0x38             | STATE = COMPARE(0x38, 0x38)             
            // 0x00E55A54: B.EQ #0xe55a68             | if (56 == 0x38) goto label_10;          
            if(56 == 56)
            {
                goto label_10;
            }
            // 0x00E55A58: CBZ x21, #0xe55a68         | if (0x0 == 0) goto label_10;            
            if(0 == 0)
            {
                goto label_10;
            }
            // 0x00E55A5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55A60: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00E55A64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_10:
            // 0x00E55A68: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00E55A6C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E55A70: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E55A74: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E55A78: RET                        |  return (System.Byte[])val_3;           
            return (System.Byte[])val_3;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
            // 0x00E55A7C: BL #0x981060               | 
            // 0x00E55A80: LDR x21, [x0]              | 
            // 0x00E55A84: BL #0x980920               | 
            // 0x00E55A88: MOV w22, wzr               | 
            // 0x00E55A8C: MOV x20, xzr               | 
            // 0x00E55A90: B #0xe559e4                | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55AA0 (15030944), len: 8  VirtAddr: 0x00E55AA0 RVA: 0x00E55AA0 token: 100663480 methodIndex: 19308 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual ILRuntime.Mono.Cecil.MetadataScopeType get_MetadataScopeType()
        {
            //
            // Disasemble & Code
            // 0x00E55AA0: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00E55AA4: RET                        |  return (ILRuntime.Mono.Cecil.MetadataScopeType)null;
            return (ILRuntime.Mono.Cecil.MetadataScopeType)0;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.MetadataScopeType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54774 (15026036), len: 972  VirtAddr: 0x00E54774 RVA: 0x00E54774 token: 100663481 methodIndex: 19309 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_FullName()
        {
            //
            // Disasemble & Code
            //  | 
            string val_29;
            //  | 
            string val_30;
            //  | 
            var val_31;
            // 0x00E54774: STP x24, x23, [sp, #-0x40]! | stack[1152921509424933072] = ???;  stack[1152921509424933080] = ???;  //  dest_result_addr=1152921509424933072 |  dest_result_addr=1152921509424933080
            // 0x00E54778: STP x22, x21, [sp, #0x10]  | stack[1152921509424933088] = ???;  stack[1152921509424933096] = ???;  //  dest_result_addr=1152921509424933088 |  dest_result_addr=1152921509424933096
            // 0x00E5477C: STP x20, x19, [sp, #0x20]  | stack[1152921509424933104] = ???;  stack[1152921509424933112] = ???;  //  dest_result_addr=1152921509424933104 |  dest_result_addr=1152921509424933112
            // 0x00E54780: STP x29, x30, [sp, #0x30]  | stack[1152921509424933120] = ???;  stack[1152921509424933128] = ???;  //  dest_result_addr=1152921509424933120 |  dest_result_addr=1152921509424933128
            // 0x00E54784: ADD x29, sp, #0x30         | X29 = (1152921509424933072 + 48) = 1152921509424933120 (0x100000011F2E2900);
            // 0x00E54788: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E5478C: LDRB w8, [x20, #0xac1]     | W8 = (bool)static_value_03734AC1;       
            // 0x00E54790: MOV x19, x0                | X19 = 1152921509424945136 (0x100000011F2E57F0);//ML01
            // 0x00E54794: TBNZ w8, #0, #0xe547b0     | if (static_value_03734AC1 == true) goto label_0;
            // 0x00E54798: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00E5479C: LDR x8, [x8, #0xad0]       | X8 = 0x2B8EA28;                         
            // 0x00E547A0: LDR w0, [x8]               | W0 = 0x1148;                            
            // 0x00E547A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1148, ????);     
            // 0x00E547A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E547AC: STRB w8, [x20, #0xac1]     | static_value_03734AC1 = true;            //  dest_result_addr=57887425
            label_0:
            // 0x00E547B0: LDR x0, [x19, #0x58]       | X0 = this.full_name; //P2               
            val_29 = this.full_name;
            // 0x00E547B4: CBNZ x0, #0xe54b2c         | if (this.full_name != null) goto label_1;
            if(val_29 != null)
            {
                goto label_1;
            }
            // 0x00E547B8: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00E547BC: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x00E547C0: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_1 = null;
            // 0x00E547C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x00E547C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E547CC: MOV x20, x0                | X20 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E547D0: BL #0x1b5a30c              | .ctor();                                
            val_1 = new System.Text.StringBuilder();
            // 0x00E547D4: LDR x21, [x19, #0x10]      | X21 = this.name; //P2                   
            // 0x00E547D8: CBZ x20, #0xe54808         | if ( == 0) goto label_2;                
            if(null == 0)
            {
                goto label_2;
            }
            // 0x00E547DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E547E0: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E547E4: MOV x1, x21                | X1 = this.name;//m1                     
            // 0x00E547E8: BL #0x1b5b818              | X0 = Append(value:  this.name);         
            System.Text.StringBuilder val_2 = Append(value:  this.name);
            // 0x00E547EC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E547F0: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
            // 0x00E547F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E547F8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E547FC: LDR x1, [x8]               | X1 = ", ";                              
            // 0x00E54800: BL #0x1b5b818              | X0 = Append(value:  ", ");              
            System.Text.StringBuilder val_3 = Append(value:  ", ");
            // 0x00E54804: B #0xe5483c                |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x00E54808: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x00E5480C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54810: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54814: MOV x1, x21                | X1 = this.name;//m1                     
            // 0x00E54818: BL #0x1b5b818              | X0 = Append(value:  this.name);         
            System.Text.StringBuilder val_4 = Append(value:  this.name);
            // 0x00E5481C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00E54820: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E54824: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
            // 0x00E54828: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5482C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54830: LDR x1, [x8]               | X1 = ", ";                              
            // 0x00E54834: BL #0x1b5b818              | X0 = Append(value:  ", ");              
            System.Text.StringBuilder val_5 = Append(value:  ", ");
            // 0x00E54838: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_3:
            // 0x00E5483C: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00E54840: LDR x8, [x8, #0x9b0]       | X8 = (string**)(1152921509424805776)("Version=");
            // 0x00E54844: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54848: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E5484C: LDR x1, [x8]               | X1 = "Version=";                        
            // 0x00E54850: BL #0x1b5b818              | X0 = Append(value:  "Version=");        
            System.Text.StringBuilder val_6 = Append(value:  "Version=");
            // 0x00E54854: LDR x21, [x19, #0x20]      | X21 = this.version; //P2                
            // 0x00E54858: CBNZ x21, #0xe54860        | if (this.version != null) goto label_4; 
            if(this.version != null)
            {
                goto label_4;
            }
            // 0x00E5485C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_4:
            // 0x00E54860: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54864: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00E54868: MOV x0, x21                | X0 = this.version;//m1                  
            // 0x00E5486C: BL #0x273bf10              | X0 = this.version.ToString(fieldCount:  4);
            string val_7 = this.version.ToString(fieldCount:  4);
            // 0x00E54870: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x00E54874: CBZ x20, #0xe548a4         | if ( == 0) goto label_5;                
            if(null == 0)
            {
                goto label_5;
            }
            // 0x00E54878: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5487C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54880: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x00E54884: BL #0x1b5b818              | X0 = Append(value:  val_7);             
            System.Text.StringBuilder val_8 = Append(value:  val_7);
            // 0x00E54888: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E5488C: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
            // 0x00E54890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54894: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54898: LDR x1, [x8]               | X1 = ", ";                              
            // 0x00E5489C: BL #0x1b5b818              | X0 = Append(value:  ", ");              
            System.Text.StringBuilder val_9 = Append(value:  ", ");
            // 0x00E548A0: B #0xe548d8                |  goto label_6;                          
            goto label_6;
            label_5:
            // 0x00E548A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            // 0x00E548A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E548AC: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E548B0: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x00E548B4: BL #0x1b5b818              | X0 = Append(value:  val_7);             
            System.Text.StringBuilder val_10 = Append(value:  val_7);
            // 0x00E548B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            // 0x00E548BC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E548C0: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
            // 0x00E548C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E548C8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E548CC: LDR x1, [x8]               | X1 = ", ";                              
            // 0x00E548D0: BL #0x1b5b818              | X0 = Append(value:  ", ");              
            System.Text.StringBuilder val_11 = Append(value:  ", ");
            // 0x00E548D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_6:
            // 0x00E548D8: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x00E548DC: LDR x8, [x8, #0xf90]       | X8 = (string**)(1152921509424834544)("Culture=");
            // 0x00E548E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E548E4: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E548E8: LDR x1, [x8]               | X1 = "Culture=";                        
            // 0x00E548EC: BL #0x1b5b818              | X0 = Append(value:  "Culture=");        
            System.Text.StringBuilder val_12 = Append(value:  "Culture=");
            // 0x00E548F0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E548F4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00E548F8: MOV x22, x19               | X22 = 1152921509424945136 (0x100000011F2E57F0);//ML01
            // 0x00E548FC: LDR x21, [x22, #0x18]!     | X21 = this.culture; //P2                
            // 0x00E54900: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00E54904: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E54908: TBZ w8, #0, #0xe54918      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E5490C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E54910: CBNZ w8, #0xe54918         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E54914: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_8:
            // 0x00E54918: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5491C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54920: MOV x1, x21                | X1 = this.culture;//m1                  
            // 0x00E54924: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
            bool val_13 = System.String.IsNullOrEmpty(value:  0);
            // 0x00E54928: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x00E5492C: LDR x8, [x8, #0xba0]       | X8 = (string**)(1152921509424842832)("neutral");
            // 0x00E54930: TST w0, #1                 | STATE = COMPARE(val_13, 0x1)            
            // 0x00E54934: CSEL x8, x8, x22, ne       | X8 = val_13 != true ? "neutral" : 1152921509424945160;
            string val_14 = (val_13 != true) ? ("neutral") : (this.culture);
            // 0x00E54938: LDR x21, [x8]              | X21 = val_13 != true ? "neutral" : 1152921509424945160;
            // 0x00E5493C: CBZ x20, #0xe5496c         | if ( == 0) goto label_9;                
            if(null == 0)
            {
                goto label_9;
            }
            // 0x00E54940: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54944: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54948: MOV x1, x21                | X1 = val_13 != true ? "neutral" : 1152921509424945160;//m1
            // 0x00E5494C: BL #0x1b5b818              | X0 = Append(value:  val_14);            
            System.Text.StringBuilder val_15 = Append(value:  val_14);
            // 0x00E54950: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E54954: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
            // 0x00E54958: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5495C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54960: LDR x1, [x8]               | X1 = ", ";                              
            // 0x00E54964: BL #0x1b5b818              | X0 = Append(value:  ", ");              
            System.Text.StringBuilder val_16 = Append(value:  ", ");
            // 0x00E54968: B #0xe549a0                |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x00E5496C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            // 0x00E54970: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54974: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54978: MOV x1, x21                | X1 = val_13 != true ? "neutral" : 1152921509424945160;//m1
            // 0x00E5497C: BL #0x1b5b818              | X0 = Append(value:  val_14);            
            System.Text.StringBuilder val_17 = Append(value:  val_14);
            // 0x00E54980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            // 0x00E54984: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E54988: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
            // 0x00E5498C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54990: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54994: LDR x1, [x8]               | X1 = ", ";                              
            // 0x00E54998: BL #0x1b5b818              | X0 = Append(value:  ", ");              
            System.Text.StringBuilder val_18 = Append(value:  ", ");
            // 0x00E5499C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_10:
            // 0x00E549A0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00E549A4: LDR x8, [x8, #0xfd8]       | X8 = (string**)(1152921509424859312)("PublicKeyToken=");
            // 0x00E549A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E549AC: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E549B0: LDR x1, [x8]               | X1 = "PublicKeyToken=";                 
            // 0x00E549B4: BL #0x1b5b818              | X0 = Append(value:  "PublicKeyToken="); 
            System.Text.StringBuilder val_19 = Append(value:  "PublicKeyToken=");
            // 0x00E549B8: MOV x0, x19                | X0 = 1152921509424945136 (0x100000011F2E57F0);//ML01
            // 0x00E549BC: BL #0xe557e4               | X0 = this.get_PublicKeyToken();         
            System.Byte[] val_20 = this.PublicKeyToken;
            // 0x00E549C0: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E549C4: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E549C8: MOV x21, x0                | X21 = val_20;//m1                       
            // 0x00E549CC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E549D0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E549D4: TBZ w9, #0, #0xe549e8      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00E549D8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E549DC: CBNZ w9, #0xe549e8         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00E549E0: MOV x0, x8                 | X0 = 1152921504737091584 (0x1000000007C36000);//ML01
            // 0x00E549E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_12:
            // 0x00E549E8: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00E549EC: LDR x8, [x8, #0xb40]       | X8 = 1152921509423642560;               
            // 0x00E549F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E549F4: MOV x1, x21                | X1 = val_20;//m1                        
            val_30 = val_20;
            // 0x00E549F8: LDR x2, [x8]               | X2 = public static System.Boolean ILRuntime.Mono.Cecil.Mixin::IsNullOrEmpty<System.Byte>(T[] self);
            // 0x00E549FC: BL #0x12f94f8              | X0 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<System.Byte>(self:  0);
            bool val_21 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<System.Byte>(self:  0);
            // 0x00E54A00: AND w8, w0, #1             | W8 = (val_21 & 1);                      
            bool val_22 = val_21;
            // 0x00E54A04: TBNZ w8, #0, #0xe54a8c     | if ((val_21 & 1) == true) goto label_15;
            if(val_22 == true)
            {
                goto label_15;
            }
            // 0x00E54A08: CBNZ x21, #0xe54a10        | if (val_20 != null) goto label_14;      
            if(val_20 != null)
            {
                goto label_14;
            }
            // 0x00E54A0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_14:
            // 0x00E54A10: LDR x8, [x21, #0x18]       | X8 = val_20.Length; //P2                
            // 0x00E54A14: CBZ x8, #0xe54a8c          | if (val_20.Length == 0) goto label_15;  
            if(val_20.Length == 0)
            {
                goto label_15;
            }
            // 0x00E54A18: ADRP x24, #0x3655000       | X24 = 56971264 (0x3655000);             
            // 0x00E54A1C: LDR x24, [x24, #0xda0]     | X24 = (string**)(1152921509424900384)("x2");
            // 0x00E54A20: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_31 = 0;
            // 0x00E54A24: B #0xe54a3c                |  goto label_16;                         
            goto label_16;
            label_21:
            // 0x00E54A28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54A2C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54A30: MOV x1, x22                | X1 = 1152921509424945160 (0x100000011F2E5808);//ML01
            val_30 = 1152921509424945160;
            // 0x00E54A34: BL #0x1b5b818              | X0 = Append(value:  this.culture);      
            System.Text.StringBuilder val_23 = Append(value:  this.culture);
            // 0x00E54A38: ADD w23, w23, #1           | W23 = (val_31 + 1) = val_31 (0x00000001);
            val_31 = 1;
            label_16:
            // 0x00E54A3C: CBNZ x21, #0xe54a44        | if (val_20 != null) goto label_17;      
            if(val_20 != null)
            {
                goto label_17;
            }
            // 0x00E54A40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_17:
            // 0x00E54A44: LDR w8, [x21, #0x18]       | W8 = val_20.Length; //P2                
            // 0x00E54A48: CMP w23, w8                | STATE = COMPARE(0x1, val_20.Length)     
            // 0x00E54A4C: B.GE #0xe54aac             | if (val_31 >= val_20.Length) goto label_18;
            if(val_31 >= val_20.Length)
            {
                goto label_18;
            }
            // 0x00E54A50: SXTW x22, w23              | X22 = 1 (0x00000001);                   
            // 0x00E54A54: CMP w23, w8                | STATE = COMPARE(0x1, val_20.Length)     
            // 0x00E54A58: B.LO #0xe54a68             | if (val_31 < val_20.Length) goto label_19;
            if(val_31 < val_20.Length)
            {
                goto label_19;
            }
            // 0x00E54A5C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00E54A60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E54A64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_19:
            // 0x00E54A68: LDR x1, [x24]              | X1 = "x2";                              
            // 0x00E54A6C: ADD x8, x21, x22           | X8 = val_20[0x1]; //PARR1               
            // 0x00E54A70: ADD x0, x8, #0x20          | X0 = val_20[0x1][0x20]; //PARR1         
            // 0x00E54A74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54A78: BL #0x18d5968              | X0 = label_System_Byte_ToString_GL018D5968();
            // 0x00E54A7C: MOV x22, x0                | X22 = val_20[0x1][0x20];//m1            
            var val_29 = val_20[1][32];
            // 0x00E54A80: CBNZ x20, #0xe54a28        | if ( != 0) goto label_21;               
            if(null != 0)
            {
                goto label_21;
            }
            // 0x00E54A84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20[0x1][0x20], ????);
            // 0x00E54A88: B #0xe54a28                |  goto label_21;                         
            goto label_21;
            label_15:
            // 0x00E54A8C: CBNZ x20, #0xe54a94        | if ( != 0) goto label_22;               
            if(null != 0)
            {
                goto label_22;
            }
            // 0x00E54A90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_22:
            // 0x00E54A94: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00E54A98: LDR x8, [x8, #0xf80]       | X8 = (string**)(1152921509424904560)("null");
            // 0x00E54A9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54AA0: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54AA4: LDR x1, [x8]               | X1 = "null";                            
            val_30 = "null";
            // 0x00E54AA8: BL #0x1b5b818              | X0 = Append(value:  val_30 = "null");   
            System.Text.StringBuilder val_24 = Append(value:  val_30);
            label_18:
            // 0x00E54AAC: MOV x0, x19                | X0 = 1152921509424945136 (0x100000011F2E57F0);//ML01
            // 0x00E54AB0: BL #0xe555bc               | X0 = this.get_IsRetargetable();         
            bool val_25 = this.IsRetargetable;
            // 0x00E54AB4: TBZ w0, #0, #0xe54b10      | if (val_25 == false) goto label_23;     
            if(val_25 == false)
            {
                goto label_23;
            }
            // 0x00E54AB8: CBZ x20, #0xe54ad8         | if ( == 0) goto label_24;               
            if(null == 0)
            {
                goto label_24;
            }
            // 0x00E54ABC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E54AC0: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
            // 0x00E54AC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54AC8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54ACC: LDR x1, [x8]               | X1 = ", ";                              
            // 0x00E54AD0: BL #0x1b5b818              | X0 = Append(value:  ", ");              
            System.Text.StringBuilder val_26 = Append(value:  ", ");
            // 0x00E54AD4: B #0xe54af8                |  goto label_25;                         
            goto label_25;
            label_24:
            // 0x00E54AD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            // 0x00E54ADC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E54AE0: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
            // 0x00E54AE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54AE8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54AEC: LDR x1, [x8]               | X1 = ", ";                              
            // 0x00E54AF0: BL #0x1b5b818              | X0 = Append(value:  ", ");              
            System.Text.StringBuilder val_27 = Append(value:  ", ");
            // 0x00E54AF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_25:
            // 0x00E54AF8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00E54AFC: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424916928)("Retargetable=Yes");
            // 0x00E54B00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54B04: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54B08: LDR x1, [x8]               | X1 = "Retargetable=Yes";                
            val_30 = "Retargetable=Yes";
            // 0x00E54B0C: BL #0x1b5b818              | X0 = Append(value:  val_30 = "Retargetable=Yes");
            System.Text.StringBuilder val_28 = Append(value:  val_30);
            label_23:
            // 0x00E54B10: CBNZ x20, #0xe54b18        | if ( != 0) goto label_26;               
            if(null != 0)
            {
                goto label_26;
            }
            // 0x00E54B14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_26:
            // 0x00E54B18: LDR x8, [x20]              | X8 = ;                                  
            // 0x00E54B1C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            val_29 = val_1;
            // 0x00E54B20: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x00E54B24: BLR x9                     | X0 = mem[null + 320]();                 
            // 0x00E54B28: STR x0, [x19, #0x58]       | this.full_name = typeof(System.Text.StringBuilder);  //  dest_result_addr=1152921509424945224
            this.full_name = val_29;
            label_1:
            // 0x00E54B2C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54B30: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E54B34: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E54B38: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E54B3C: RET                        |  return (System.String)typeof(System.Text.StringBuilder);
            return val_29;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55AA8 (15030952), len: 1444  VirtAddr: 0x00E55AA8 RVA: 0x00E55AA8 token: 100663482 methodIndex: 19310 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Mono.Cecil.AssemblyNameReference Parse(string fullName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            // 0x00E55AA8: STP x28, x27, [sp, #-0x60]! | stack[1152921509425370320] = ???;  stack[1152921509425370328] = ???;  //  dest_result_addr=1152921509425370320 |  dest_result_addr=1152921509425370328
            // 0x00E55AAC: STP x26, x25, [sp, #0x10]  | stack[1152921509425370336] = ???;  stack[1152921509425370344] = ???;  //  dest_result_addr=1152921509425370336 |  dest_result_addr=1152921509425370344
            // 0x00E55AB0: STP x24, x23, [sp, #0x20]  | stack[1152921509425370352] = ???;  stack[1152921509425370360] = ???;  //  dest_result_addr=1152921509425370352 |  dest_result_addr=1152921509425370360
            // 0x00E55AB4: STP x22, x21, [sp, #0x30]  | stack[1152921509425370368] = ???;  stack[1152921509425370376] = ???;  //  dest_result_addr=1152921509425370368 |  dest_result_addr=1152921509425370376
            // 0x00E55AB8: STP x20, x19, [sp, #0x40]  | stack[1152921509425370384] = ???;  stack[1152921509425370392] = ???;  //  dest_result_addr=1152921509425370384 |  dest_result_addr=1152921509425370392
            // 0x00E55ABC: STP x29, x30, [sp, #0x50]  | stack[1152921509425370400] = ???;  stack[1152921509425370408] = ???;  //  dest_result_addr=1152921509425370400 |  dest_result_addr=1152921509425370408
            // 0x00E55AC0: ADD x29, sp, #0x50         | X29 = (1152921509425370320 + 80) = 1152921509425370400 (0x100000011F34D520);
            // 0x00E55AC4: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E55AC8: LDRB w8, [x19, #0xac2]     | W8 = (bool)static_value_03734AC2;       
            // 0x00E55ACC: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00E55AD0: TBNZ w8, #0, #0xe55aec     | if (static_value_03734AC2 == true) goto label_0;
            // 0x00E55AD4: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00E55AD8: LDR x8, [x8, #0x9a0]       | X8 = 0x2B8EA44;                         
            // 0x00E55ADC: LDR w0, [x8]               | W0 = 0x114F;                            
            // 0x00E55AE0: BL #0x2782188              | X0 = sub_2782188( ?? 0x114F, ????);     
            // 0x00E55AE4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E55AE8: STRB w8, [x19, #0xac2]     | static_value_03734AC2 = true;            //  dest_result_addr=57887426
            label_0:
            // 0x00E55AEC: CBZ x20, #0xe56004         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00E55AF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55AF4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00E55AF8: BL #0x18a4460              | X0 = X1.get_Length();                   
            int val_1 = X1.Length;
            // 0x00E55AFC: CBZ w0, #0xe56030          | if (val_1 == 0) goto label_2;           
            if(val_1 == 0)
            {
                goto label_2;
            }
            // 0x00E55B00: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x00E55B04: LDR x8, [x8, #0xc88]       | X8 = 1152921504737677312;               
            // 0x00E55B08: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.AssemblyNameReference);
            ILRuntime.Mono.Cecil.AssemblyNameReference val_2 = null;
            // 0x00E55B0C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.AssemblyNameReference), ????);
            // 0x00E55B10: MOV x19, x0                | X19 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E55B14: BL #0xe55360               | .ctor();                                
            val_2 = new ILRuntime.Mono.Cecil.AssemblyNameReference();
            // 0x00E55B18: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00E55B1C: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
            // 0x00E55B20: LDR x21, [x8]              | X21 = typeof(System.Char[]);            
            // 0x00E55B24: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E55B28: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
            // 0x00E55B2C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00E55B30: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E55B34: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
            // 0x00E55B38: MOV x21, x0                | X21 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E55B3C: CBNZ x21, #0xe55b44        | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x00E55B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
            label_3:
            // 0x00E55B44: LDR w8, [x21, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
            // 0x00E55B48: CBNZ w8, #0xe55b58         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_4;
            // 0x00E55B4C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
            // 0x00E55B50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55B54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
            label_4:
            // 0x00E55B58: MOVZ w8, #0x2c             | W8 = 44 (0x2C);//ML01                   
            // 0x00E55B5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E55B60: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00E55B64: MOV x1, x21                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E55B68: STRH w8, [x21, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x2C;  //  dest_result_addr=1152921504947213104
            typeof(System.Char[]).__il2cppRuntimeField_20 = 44;
            // 0x00E55B6C: BL #0x18a881c              | X0 = X1.Split(separator:  null);        
            System.String[] val_3 = X1.Split(separator:  null);
            // 0x00E55B70: ADRP x28, #0x35d6000       | X28 = 56451072 (0x35D6000);             
            // 0x00E55B74: LDR x28, [x28, #0xe38]     | X28 = 1152921504608284672;              
            // 0x00E55B78: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00E55B7C: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_27 = 0;
            // 0x00E55B80: B #0xe55b88                |  goto label_5;                          
            goto label_5;
            label_51:
            // 0x00E55B84: ADD w26, w26, #1           | W26 = (val_27 + 1) = val_27 (0x00000001);
            val_27 = 1;
            label_5:
            // 0x00E55B88: CBNZ x20, #0xe55b90        | if (val_3 != null) goto label_6;        
            if(val_3 != null)
            {
                goto label_6;
            }
            // 0x00E55B8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_6:
            // 0x00E55B90: LDR w8, [x20, #0x18]       | W8 = val_3.Length; //P2                 
            // 0x00E55B94: CMP w26, w8                | STATE = COMPARE(0x1, val_3.Length)      
            // 0x00E55B98: B.GE #0xe55fa4             | if (val_27 >= val_3.Length) goto label_7;
            if(val_27 >= val_3.Length)
            {
                goto label_7;
            }
            // 0x00E55B9C: SXTW x21, w26              | X21 = 1 (0x00000001);                   
            // 0x00E55BA0: CMP w26, w8                | STATE = COMPARE(0x1, val_3.Length)      
            // 0x00E55BA4: B.LO #0xe55bb4             | if (val_27 < val_3.Length) goto label_8;
            if(val_27 < val_3.Length)
            {
                goto label_8;
            }
            // 0x00E55BA8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x00E55BAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55BB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_8:
            // 0x00E55BB4: ADD x8, x20, x21, lsl #3   | X8 = val_3[0x1]; //PARR1                
            // 0x00E55BB8: LDR x21, [x8, #0x20]       | X21 = val_3[0x1][0]                     
            string val_27 = val_3[1];
            // 0x00E55BBC: CBNZ x21, #0xe55bc4        | if (val_3[0x1][0] != null) goto label_9;
            if(val_27 != null)
            {
                goto label_9;
            }
            // 0x00E55BC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x00E55BC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55BC8: MOV x0, x21                | X0 = val_3[0x1][0];//m1                 
            // 0x00E55BCC: BL #0x18a946c              | X0 = val_3[0x1][0].Trim();              
            string val_4 = val_27.Trim();
            // 0x00E55BD0: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x00E55BD4: CBZ w26, #0xe55d08         | if (0x1 == 0) goto label_10;            
            if(val_27 == 0)
            {
                goto label_10;
            }
            // 0x00E55BD8: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00E55BDC: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
            // 0x00E55BE0: LDR x22, [x8]              | X22 = typeof(System.Char[]);            
            // 0x00E55BE4: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E55BE8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
            // 0x00E55BEC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00E55BF0: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E55BF4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
            // 0x00E55BF8: MOV x22, x0                | X22 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E55BFC: CBNZ x22, #0xe55c04        | if ( != null) goto label_11;            
            if(null != null)
            {
                goto label_11;
            }
            // 0x00E55C00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
            label_11:
            // 0x00E55C04: LDR w8, [x22, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
            // 0x00E55C08: CBNZ w8, #0xe55c18         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_12;
            // 0x00E55C0C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
            // 0x00E55C10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55C14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
            label_12:
            // 0x00E55C18: MOVZ w8, #0x3d             | W8 = 61 (0x3D);//ML01                   
            // 0x00E55C1C: STRH w8, [x22, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x3D;  //  dest_result_addr=1152921504947213104
            typeof(System.Char[]).__il2cppRuntimeField_20 = 61;
            // 0x00E55C20: CBNZ x21, #0xe55c28        | if (val_4 != null) goto label_13;       
            if(val_4 != null)
            {
                goto label_13;
            }
            // 0x00E55C24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
            label_13:
            // 0x00E55C28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E55C2C: MOV x0, x21                | X0 = val_4;//m1                         
            // 0x00E55C30: MOV x1, x22                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E55C34: BL #0x18a881c              | X0 = val_4.Split(separator:  null);     
            System.String[] val_5 = val_4.Split(separator:  null);
            // 0x00E55C38: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x00E55C3C: CBNZ x21, #0xe55c44        | if (val_5 != null) goto label_14;       
            if(val_5 != null)
            {
                goto label_14;
            }
            // 0x00E55C40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_14:
            // 0x00E55C44: LDR w8, [x21, #0x18]       | W8 = val_5.Length; //P2                 
            // 0x00E55C48: CMP w8, #2                 | STATE = COMPARE(val_5.Length, 0x2)      
            // 0x00E55C4C: B.NE #0xe55fc4             | if (val_5.Length != 2) goto label_15;   
            if(val_5.Length != 2)
            {
                goto label_15;
            }
            // 0x00E55C50: LDR x22, [x21, #0x20]      | X22 = val_5[0]                          
            string val_28 = val_5[0];
            // 0x00E55C54: CBNZ x22, #0xe55c5c        | if (val_5[0] != null) goto label_16;    
            if(val_28 != null)
            {
                goto label_16;
            }
            // 0x00E55C58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_16:
            // 0x00E55C5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55C60: MOV x0, x22                | X0 = val_5[0];//m1                      
            // 0x00E55C64: BL #0x18aef14              | X0 = val_5[0].ToLowerInvariant();       
            string val_6 = val_28.ToLowerInvariant();
            // 0x00E55C68: LDR x8, [x28]              | X8 = typeof(System.String);             
            // 0x00E55C6C: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x00E55C70: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00E55C74: TBZ w9, #0, #0xe55c88      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x00E55C78: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E55C7C: CBNZ w9, #0xe55c88         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x00E55C80: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00E55C84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_18:
            // 0x00E55C88: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x00E55C8C: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921509425266608)("version");
            // 0x00E55C90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55C94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55C98: MOV x1, x22                | X1 = val_6;//m1                         
            // 0x00E55C9C: LDR x2, [x8]               | X2 = "version";                         
            // 0x00E55CA0: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_6);
            bool val_7 = System.String.op_Equality(a:  0, b:  val_6);
            // 0x00E55CA4: AND w8, w0, #1             | W8 = (val_7 & 1);                       
            bool val_8 = val_7;
            // 0x00E55CA8: TBZ w8, #0, #0xe55d1c      | if ((val_7 & 1) == false) goto label_19;
            if(val_8 == false)
            {
                goto label_19;
            }
            // 0x00E55CAC: CBNZ x21, #0xe55cb4        | if (val_5 != null) goto label_20;       
            if(val_5 != null)
            {
                goto label_20;
            }
            // 0x00E55CB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_20:
            // 0x00E55CB4: LDR w8, [x21, #0x18]       | W8 = val_5.Length; //P2                 
            // 0x00E55CB8: CMP w8, #1                 | STATE = COMPARE(val_5.Length, 0x1)      
            // 0x00E55CBC: B.HI #0xe55ccc             | if (val_5.Length > 1) goto label_21;    
            if(val_5.Length > 1)
            {
                goto label_21;
            }
            // 0x00E55CC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x00E55CC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55CC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_21:
            // 0x00E55CCC: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x00E55CD0: LDR x22, [x21, #0x28]      | X22 = val_5[1]                          
            string val_29 = val_5[1];
            // 0x00E55CD4: LDR x8, [x8, #0x958]       | X8 = 1152921504657272832;               
            // 0x00E55CD8: LDR x0, [x8]               | X0 = typeof(System.Version);            
            System.Version val_9 = null;
            // 0x00E55CDC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Version), ????);
            // 0x00E55CE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E55CE4: MOV x1, x22                | X1 = val_5[1];//m1                      
            // 0x00E55CE8: MOV x21, x0                | X21 = 1152921504657272832 (0x1000000003017000);//ML01
            // 0x00E55CEC: BL #0x273b668              | .ctor(version:  val_5[1]);              
            val_9 = new System.Version(version:  val_29);
            // 0x00E55CF0: CBNZ x19, #0xe55cf8        | if ( != 0) goto label_22;               
            if(null != 0)
            {
                goto label_22;
            }
            // 0x00E55CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(version:  val_5[1]), ????);
            label_22:
            // 0x00E55CF8: MOV x0, x19                | X0 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E55CFC: MOV x1, x21                | X1 = 1152921504657272832 (0x1000000003017000);//ML01
            // 0x00E55D00: BL #0xe55430               | set_Version(value:  val_9);             
            Version = val_9;
            // 0x00E55D04: B #0xe55b84                |  goto label_51;                         
            goto label_51;
            label_10:
            // 0x00E55D08: CBNZ x19, #0xe55d10        | if ( != 0) goto label_24;               
            if(null != 0)
            {
                goto label_24;
            }
            // 0x00E55D0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_24:
            // 0x00E55D10: STR x21, [x19, #0x10]      | typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_10 = val_4;  //  dest_result_addr=1152921504737677328
            typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_10 = val_4;
            // 0x00E55D14: STR xzr, [x19, #0x58]      | typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_58 = 0x0;  //  dest_result_addr=1152921504737677400
            typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_58 = 0;
            // 0x00E55D18: B #0xe55b84                |  goto label_51;                         
            goto label_51;
            label_19:
            // 0x00E55D1C: LDR x0, [x28]              | X0 = typeof(System.String);             
            // 0x00E55D20: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E55D24: TBZ w8, #0, #0xe55d34      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_27;
            // 0x00E55D28: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E55D2C: CBNZ w8, #0xe55d34         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x00E55D30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_27:
            // 0x00E55D34: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x00E55D38: LDR x8, [x8, #0xf00]       | X8 = (string**)(1152921509425270800)("culture");
            // 0x00E55D3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55D40: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55D44: MOV x1, x22                | X1 = val_6;//m1                         
            // 0x00E55D48: LDR x2, [x8]               | X2 = "culture";                         
            // 0x00E55D4C: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_6);
            bool val_10 = System.String.op_Equality(a:  0, b:  val_6);
            // 0x00E55D50: AND w8, w0, #1             | W8 = (val_10 & 1);                      
            bool val_11 = val_10;
            // 0x00E55D54: TBZ w8, #0, #0xe55e00      | if ((val_10 & 1) == false) goto label_28;
            if(val_11 == false)
            {
                goto label_28;
            }
            // 0x00E55D58: CBNZ x21, #0xe55d60        | if (val_5 != null) goto label_29;       
            if(val_5 != null)
            {
                goto label_29;
            }
            // 0x00E55D5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_29:
            // 0x00E55D60: LDR w8, [x21, #0x18]       | W8 = val_5.Length; //P2                 
            // 0x00E55D64: CMP w8, #1                 | STATE = COMPARE(val_5.Length, 0x1)      
            // 0x00E55D68: B.HI #0xe55d78             | if (val_5.Length > 1) goto label_30;    
            if(val_5.Length > 1)
            {
                goto label_30;
            }
            // 0x00E55D6C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x00E55D70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55D74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_30:
            // 0x00E55D78: MOV x23, x21               | X23 = val_5;//m1                        
            // 0x00E55D7C: LDR x22, [x23, #0x28]!     | X22 = val_5[1]                          
            string val_30 = val_5[1];
            // 0x00E55D80: LDR x0, [x28]              | X0 = typeof(System.String);             
            // 0x00E55D84: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E55D88: TBZ w8, #0, #0xe55d98      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x00E55D8C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E55D90: CBNZ w8, #0xe55d98         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x00E55D94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_32:
            // 0x00E55D98: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x00E55D9C: LDR x8, [x8, #0xba0]       | X8 = (string**)(1152921509424842832)("neutral");
            // 0x00E55DA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55DA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55DA8: MOV x1, x22                | X1 = val_5[1];//m1                      
            // 0x00E55DAC: LDR x2, [x8]               | X2 = "neutral";                         
            // 0x00E55DB0: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_5[1]);
            bool val_12 = System.String.op_Equality(a:  0, b:  val_30);
            // 0x00E55DB4: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00E55DB8: LDR x8, [x8, #0x7c0]       | X8 = (string**)(1152921509425274992)("");
            val_28 = "";
            // 0x00E55DBC: AND w9, w0, #1             | W9 = (val_12 & 1);                      
            bool val_13 = val_12;
            // 0x00E55DC0: TBNZ w9, #0, #0xe55de8     | if ((val_12 & 1) == true) goto label_33;
            if(val_13 == true)
            {
                goto label_33;
            }
            // 0x00E55DC4: CBNZ x21, #0xe55dcc        | if (val_5 != null) goto label_34;       
            if(val_5 != null)
            {
                goto label_34;
            }
            // 0x00E55DC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_34:
            // 0x00E55DCC: LDR w8, [x21, #0x18]       | W8 = val_5.Length; //P2                 
            // 0x00E55DD0: CMP w8, #1                 | STATE = COMPARE(val_5.Length, 0x1)      
            // 0x00E55DD4: B.HI #0xe55de4             | if (val_5.Length > 1) goto label_35;    
            if(val_5.Length > 1)
            {
                goto label_35;
            }
            // 0x00E55DD8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
            // 0x00E55DDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55DE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_35:
            // 0x00E55DE4: MOV x8, x23                | X8 = val_5 + 40;//m1                    
            val_28 = val_5 + 40;
            label_33:
            // 0x00E55DE8: LDR x21, [x8]              | X21 = val_5 + 40;                       
            // 0x00E55DEC: CBNZ x19, #0xe55df4        | if ( != 0) goto label_36;               
            if(null != 0)
            {
                goto label_36;
            }
            // 0x00E55DF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_36:
            // 0x00E55DF4: STR x21, [x19, #0x18]      | typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_18 = val_5 + 40;  //  dest_result_addr=1152921504737677336
            typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_18 = val_28;
            // 0x00E55DF8: STR xzr, [x19, #0x58]      | typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_58 = 0x0;  //  dest_result_addr=1152921504737677400
            typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_58 = 0;
            // 0x00E55DFC: B #0xe55b84                |  goto label_51;                         
            goto label_51;
            label_28:
            // 0x00E55E00: LDR x0, [x28]              | X0 = typeof(System.String);             
            // 0x00E55E04: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E55E08: TBZ w8, #0, #0xe55e18      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_39;
            // 0x00E55E0C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E55E10: CBNZ w8, #0xe55e18         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_39;
            // 0x00E55E14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_39:
            // 0x00E55E18: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00E55E1C: LDR x8, [x8, #0xe58]       | X8 = (string**)(1152921509425275072)("publickeytoken");
            // 0x00E55E20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55E24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55E28: MOV x1, x22                | X1 = val_6;//m1                         
            // 0x00E55E2C: LDR x2, [x8]               | X2 = "publickeytoken";                  
            // 0x00E55E30: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_6);
            bool val_14 = System.String.op_Equality(a:  0, b:  val_6);
            // 0x00E55E34: AND w8, w0, #1             | W8 = (val_14 & 1);                      
            bool val_15 = val_14;
            // 0x00E55E38: TBZ w8, #0, #0xe55b84      | if ((val_14 & 1) == false) goto label_51;
            if(val_15 == false)
            {
                goto label_51;
            }
            // 0x00E55E3C: CBNZ x21, #0xe55e44        | if (val_5 != null) goto label_41;       
            if(val_5 != null)
            {
                goto label_41;
            }
            // 0x00E55E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_41:
            // 0x00E55E44: LDR w8, [x21, #0x18]       | W8 = val_5.Length; //P2                 
            // 0x00E55E48: CMP w8, #1                 | STATE = COMPARE(val_5.Length, 0x1)      
            // 0x00E55E4C: B.HI #0xe55e5c             | if (val_5.Length > 1) goto label_42;    
            if(val_5.Length > 1)
            {
                goto label_42;
            }
            // 0x00E55E50: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
            // 0x00E55E54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55E58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_42:
            // 0x00E55E5C: LDR x0, [x28]              | X0 = typeof(System.String);             
            // 0x00E55E60: LDR x21, [x21, #0x28]      | X21 = val_5[1]                          
            string val_31 = val_5[1];
            // 0x00E55E64: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E55E68: TBZ w8, #0, #0xe55e78      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_44;
            // 0x00E55E6C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E55E70: CBNZ w8, #0xe55e78         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
            // 0x00E55E74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_44:
            // 0x00E55E78: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00E55E7C: LDR x8, [x8, #0xf80]       | X8 = (string**)(1152921509424904560)("null");
            // 0x00E55E80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55E84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55E88: MOV x1, x21                | X1 = val_5[1];//m1                      
            // 0x00E55E8C: LDR x2, [x8]               | X2 = "null";                            
            // 0x00E55E90: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_5[1]);
            bool val_16 = System.String.op_Equality(a:  0, b:  val_31);
            // 0x00E55E94: AND w8, w0, #1             | W8 = (val_16 & 1);                      
            bool val_17 = val_16;
            // 0x00E55E98: TBNZ w8, #0, #0xe55b84     | if ((val_16 & 1) == true) goto label_51;
            if(val_17 == true)
            {
                goto label_51;
            }
            // 0x00E55E9C: CBNZ x21, #0xe55ea4        | if (val_5[1] != null) goto label_46;    
            if(val_31 != null)
            {
                goto label_46;
            }
            // 0x00E55EA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_46:
            // 0x00E55EA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55EA8: MOV x0, x21                | X0 = val_5[1];//m1                      
            // 0x00E55EAC: BL #0x18a4460              | X0 = val_5[1].get_Length();             
            int val_18 = val_31.Length;
            // 0x00E55EB0: MOV w22, w0                | W22 = val_18;//m1                       
            var val_32 = val_18;
            // 0x00E55EB4: CBNZ x19, #0xe55ebc        | if ( != 0) goto label_47;               
            if(null != 0)
            {
                goto label_47;
            }
            // 0x00E55EB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_47:
            // 0x00E55EBC: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00E55EC0: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00E55EC4: CMP w22, #0                | STATE = COMPARE(val_18, 0x0)            
            // 0x00E55EC8: LDR x23, [x8]              | X23 = typeof(System.Byte[]);            
            // 0x00E55ECC: CINC w8, w22, lt           | W8 = val_18 < 0 ? (val_18 + 1) : val_18;
            var val_19 = (val_32 < 0) ? (val_32 + 1) : (val_32);
            // 0x00E55ED0: ASR w22, w8, #1            | W22 = (val_18 < 0 ? (val_18 + 1) : val_18 >> 1);
            val_32 = val_19 >> 1;
            // 0x00E55ED4: MOV x0, x23                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E55ED8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00E55EDC: MOV x0, x23                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E55EE0: MOV x1, x22                | X1 = (val_18 < 0 ? (val_18 + 1) : val_18 >> 1);//m1
            // 0x00E55EE4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00E55EE8: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_29 = 0;
            // 0x00E55EEC: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_30 = 0;
            // 0x00E55EF0: STR x0, [x19, #0x38]       | typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_38 = typeof(System.Byte[]);  //  dest_result_addr=1152921504737677368
            typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_38 = null;
            // 0x00E55EF4: STR xzr, [x19, #0x58]      | typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_58 = 0x0;  //  dest_result_addr=1152921504737677400
            typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_58 = 0;
            // 0x00E55EF8: B #0xe55f0c                |  goto label_48;                         
            goto label_48;
            label_56:
            // 0x00E55EFC: ADD x8, x23, x25           | X8 = (null + X25);                      
            var val_20 = null + X25;
            // 0x00E55F00: ADD w27, w27, #1           | W27 = (val_30 + 1) = val_30 (0x00000001);
            val_30 = 1;
            // 0x00E55F04: ADD w22, w22, #2           | W22 = (val_29 + 2) = val_29 (0x00000002);
            val_29 = 2;
            // 0x00E55F08: STRB w24, [x8, #0x20]      | mem2[0] = ???;                           //  dest_result_addr=0
            mem2[0] = ???;
            label_48:
            // 0x00E55F0C: CBNZ x19, #0xe55f14        | if ( != 0) goto label_49;               
            if(null != 0)
            {
                goto label_49;
            }
            // 0x00E55F10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_49:
            // 0x00E55F14: MOV x0, x19                | X0 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E55F18: BL #0xe557e4               | X0 = get_PublicKeyToken();              
            System.Byte[] val_21 = PublicKeyToken;
            // 0x00E55F1C: MOV x23, x0                | X23 = val_21;//m1                       
            // 0x00E55F20: CBNZ x23, #0xe55f28        | if (val_21 != null) goto label_50;      
            if(val_21 != null)
            {
                goto label_50;
            }
            // 0x00E55F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_50:
            // 0x00E55F28: LDR w8, [x23, #0x18]       | W8 = val_21.Length; //P2                
            // 0x00E55F2C: CMP w27, w8                | STATE = COMPARE(0x1, val_21.Length)     
            // 0x00E55F30: B.GE #0xe55b84             | if (val_30 >= val_21.Length) goto label_51;
            if(val_30 >= val_21.Length)
            {
                goto label_51;
            }
            // 0x00E55F34: CBNZ x19, #0xe55f3c        | if ( != 0) goto label_52;               
            if(null != 0)
            {
                goto label_52;
            }
            // 0x00E55F38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_52:
            // 0x00E55F3C: MOV x0, x19                | X0 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E55F40: BL #0xe557e4               | X0 = get_PublicKeyToken();              
            System.Byte[] val_22 = PublicKeyToken;
            // 0x00E55F44: MOV x23, x0                | X23 = val_22;//m1                       
            // 0x00E55F48: CBNZ x21, #0xe55f50        | if (val_5[1] != null) goto label_53;    
            if(val_31 != null)
            {
                goto label_53;
            }
            // 0x00E55F4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_53:
            // 0x00E55F50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55F54: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00E55F58: MOV x0, x21                | X0 = val_5[1];//m1                      
            // 0x00E55F5C: MOV w1, w22                | W1 = 2 (0x2);//ML01                     
            // 0x00E55F60: BL #0x18a920c              | X0 = val_5[1].Substring(startIndex:  2, length:  2);
            string val_23 = val_31.Substring(startIndex:  2, length:  2);
            // 0x00E55F64: MOV x1, x0                 | X1 = val_23;//m1                        
            // 0x00E55F68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E55F6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55F70: MOVZ w2, #0x203            | W2 = 515 (0x203);//ML01                 
            // 0x00E55F74: BL #0x18d580c              | X0 = System.Byte.Parse(s:  0, style:  val_23);
            byte val_24 = System.Byte.Parse(s:  0, style:  val_23);
            // 0x00E55F78: MOV w24, w0                | W24 = val_24;//m1                       
            // 0x00E55F7C: CBNZ x23, #0xe55f84        | if (val_22 != null) goto label_54;      
            if(val_22 != null)
            {
                goto label_54;
            }
            // 0x00E55F80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_54:
            // 0x00E55F84: LDR w8, [x23, #0x18]       | W8 = val_22.Length; //P2                
            // 0x00E55F88: SXTW x25, w27              | X25 = 1 (0x00000001);                   
            // 0x00E55F8C: CMP w27, w8                | STATE = COMPARE(0x1, val_22.Length)     
            // 0x00E55F90: B.LO #0xe55efc             | if (val_30 < val_22.Length) goto label_56;
            if(val_30 < val_22.Length)
            {
                goto label_56;
            }
            // 0x00E55F94: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_24, ????);     
            // 0x00E55F98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55F9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            // 0x00E55FA0: B #0xe55efc                |  goto label_56;                         
            goto label_56;
            label_7:
            // 0x00E55FA4: MOV x0, x19                | X0 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E55FA8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E55FAC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E55FB0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E55FB4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E55FB8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E55FBC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E55FC0: RET                        |  return (ILRuntime.Mono.Cecil.AssemblyNameReference)typeof(ILRuntime.Mono.Cecil.AssemblyNameReference);
            return (ILRuntime.Mono.Cecil.AssemblyNameReference)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.AssemblyNameReference, size=8, nGRN=0 }
            label_15:
            // 0x00E55FC4: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00E55FC8: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x00E55FCC: LDR x0, [x8]               | X0 = typeof(System.ArgumentException);  
            System.ArgumentException val_25 = null;
            // 0x00E55FD0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x00E55FD4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00E55FD8: LDR x8, [x8, #0xf30]       | X8 = (string**)(1152921509425357088)("Malformed name");
            label_58:
            // 0x00E55FDC: LDR x1, [x8]               | X1 = "Malformed name";                  
            // 0x00E55FE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E55FE4: MOV x19, x0                | X19 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x00E55FE8: BL #0x18b5590              | .ctor(message:  "Malformed name");      
            val_25 = new System.ArgumentException(message:  "Malformed name");
            label_57:
            // 0x00E55FEC: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00E55FF0: LDR x8, [x8, #0xb40]       | X8 = 1152921509425357184;               
            // 0x00E55FF4: MOV x0, x19                | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x00E55FF8: LDR x1, [x8]               | X1 = public static ILRuntime.Mono.Cecil.AssemblyNameReference ILRuntime.Mono.Cecil.AssemblyNameReference::Parse(string fullName);
            // 0x00E55FFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentException), ????);
            // 0x00E56000: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(System.ArgumentException), ????);
            label_1:
            // 0x00E56004: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E56008: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00E5600C: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_26 = null;
            // 0x00E56010: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00E56014: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00E56018: LDR x8, [x8, #0xb28]       | X8 = (string**)(1152921509425358208)("fullName");
            // 0x00E5601C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56020: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00E56024: LDR x1, [x8]               | X1 = "fullName";                        
            // 0x00E56028: BL #0x18b3df0              | .ctor(paramName:  "fullName");          
            val_26 = new System.ArgumentNullException(paramName:  "fullName");
            // 0x00E5602C: B #0xe55fec                |  goto label_57;                         
            goto label_57;
            label_2:
            // 0x00E56030: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00E56034: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x00E56038: LDR x0, [x8]               | X0 = typeof(System.ArgumentException);  
            // 0x00E5603C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x00E56040: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00E56044: LDR x8, [x8, #0x9f8]       | X8 = (string**)(1152921509425358304)("Name can not be empty");
            // 0x00E56048: B #0xe55fdc                |  goto label_58;                         
            goto label_58;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5604C (15032396), len: 8  VirtAddr: 0x00E5604C RVA: 0x00E5604C token: 100663483 methodIndex: 19311 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_HashAlgorithm(ILRuntime.Mono.Cecil.AssemblyHashAlgorithm value)
        {
            //
            // Disasemble & Code
            // 0x00E5604C: STR w1, [x0, #0x40]        | this.hash_algorithm = value;             //  dest_result_addr=1152921509425682896
            this.hash_algorithm = value;
            // 0x00E56050: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E56054 (15032404), len: 8  VirtAddr: 0x00E56054 RVA: 0x00E56054 token: 100663484 methodIndex: 19312 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void set_Hash(byte[] value)
        {
            //
            // Disasemble & Code
            // 0x00E56054: STR x1, [x0, #0x48]        | this.hash = value;                       //  dest_result_addr=1152921509425835864
            this.hash = value;
            // 0x00E56058: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5605C (15032412), len: 8  VirtAddr: 0x00E5605C RVA: 0x00E5605C token: 100663485 methodIndex: 19313 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.MetadataToken get_MetadataToken()
        {
            //
            // Disasemble & Code
            // 0x00E5605C: LDR w0, [x0, #0x50]        | W0 = this.token; //P2                   
            // 0x00E56060: RET                        |  return (ILRuntime.Mono.Cecil.MetadataToken)this.token;
            return this.token;
            //  |  // // {name=val_0.token, type=System.UInt32, size=4, nGRN=0 offset=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55360 (15029088), len: 160  VirtAddr: 0x00E55360 RVA: 0x00E55360 token: 100663486 methodIndex: 19314 delegateWrapperIndex: 0 methodInvoker: 0
        internal AssemblyNameReference()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x00E55360: STP x20, x19, [sp, #-0x20]! | stack[1152921509426084624] = ???;  stack[1152921509426084632] = ???;  //  dest_result_addr=1152921509426084624 |  dest_result_addr=1152921509426084632
            // 0x00E55364: STP x29, x30, [sp, #0x10]  | stack[1152921509426084640] = ???;  stack[1152921509426084648] = ???;  //  dest_result_addr=1152921509426084640 |  dest_result_addr=1152921509426084648
            // 0x00E55368: ADD x29, sp, #0x10         | X29 = (1152921509426084624 + 16) = 1152921509426084640 (0x100000011F3FBB20);
            // 0x00E5536C: SUB sp, sp, #0x10          | SP = (1152921509426084624 - 16) = 1152921509426084608 (0x100000011F3FBB00);
            // 0x00E55370: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E55374: LDRB w8, [x20, #0xac3]     | W8 = (bool)static_value_03734AC3;       
            // 0x00E55378: MOV x19, x0                | X19 = 1152921509426096656 (0x100000011F3FEA10);//ML01
            // 0x00E5537C: TBNZ w8, #0, #0xe55398     | if (static_value_03734AC3 == true) goto label_0;
            // 0x00E55380: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00E55384: LDR x8, [x8, #0x3f0]       | X8 = 0x2B8EA20;                         
            // 0x00E55388: LDR w0, [x8]               | W0 = 0x1146;                            
            // 0x00E5538C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1146, ????);     
            // 0x00E55390: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E55394: STRB w8, [x20, #0xac3]     | static_value_03734AC3 = true;            //  dest_result_addr=57887427
            label_0:
            // 0x00E55398: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5539C: MOV x0, x19                | X0 = 1152921509426096656 (0x100000011F3FEA10);//ML01
            // 0x00E553A0: BL #0x16f59f0              | this..ctor();                           
            // 0x00E553A4: ADRP x20, #0x362e000       | X20 = 56811520 (0x362E000);             
            // 0x00E553A8: LDR x20, [x20, #0xa48]     | X20 = 1152921504737091584;              
            // 0x00E553AC: LDR x0, [x20]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            val_2 = null;
            // 0x00E553B0: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E553B4: TBZ w8, #0, #0xe553c8      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E553B8: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E553BC: CBNZ w8, #0xe553c8         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E553C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            // 0x00E553C4: LDR x0, [x20]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            val_2 = null;
            label_2:
            // 0x00E553C8: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_static_fields;
            // 0x00E553CC: ADD x0, sp, #8             | X0 = (1152921509426084608 + 8) = 1152921509426084616 (0x100000011F3FBB08);
            // 0x00E553D0: MOVZ w1, #0x2300, lsl #16  | W1 = 587202560 (0x23000000);//ML01      
            // 0x00E553D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E553D8: LDR x8, [x8]               | X8 = ILRuntime.Mono.Cecil.Mixin.ZeroVersion;
            // 0x00E553DC: STR x8, [x19, #0x20]       | this.version = ILRuntime.Mono.Cecil.Mixin.ZeroVersion;  //  dest_result_addr=1152921509426096688
            this.version = ILRuntime.Mono.Cecil.Mixin.ZeroVersion;
            // 0x00E553E0: STR wzr, [sp, #8]          | stack[1152921509426084616] = 0x0;        //  dest_result_addr=1152921509426084616
            // 0x00E553E4: BL #0x11d58e4              | null..ctor(value:  0);                  
            ProtoBuf.SubItemToken val_1 = new ProtoBuf.SubItemToken(value:  0);
            // 0x00E553E8: LDR w8, [sp, #8]           | W8 = val_1.value;                       
            // 0x00E553EC: STR w8, [x19, #0x50]       | this.token = val_1.value;                //  dest_result_addr=1152921509426096736
            this.token = val_1.value;
            // 0x00E553F0: SUB sp, x29, #0x10         | SP = (1152921509426084640 - 16) = 1152921509426084624 (0x100000011F3FBB10);
            // 0x00E553F4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E553F8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E553FC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E56064 (15032420), len: 204  VirtAddr: 0x00E56064 RVA: 0x00E56064 token: 100663487 methodIndex: 19315 delegateWrapperIndex: 0 methodInvoker: 0
        public AssemblyNameReference(string name, System.Version version)
        {
            //
            // Disasemble & Code
            // 0x00E56064: STP x22, x21, [sp, #-0x30]! | stack[1152921509426208896] = ???;  stack[1152921509426208904] = ???;  //  dest_result_addr=1152921509426208896 |  dest_result_addr=1152921509426208904
            // 0x00E56068: STP x20, x19, [sp, #0x10]  | stack[1152921509426208912] = ???;  stack[1152921509426208920] = ???;  //  dest_result_addr=1152921509426208912 |  dest_result_addr=1152921509426208920
            // 0x00E5606C: STP x29, x30, [sp, #0x20]  | stack[1152921509426208928] = ???;  stack[1152921509426208936] = ???;  //  dest_result_addr=1152921509426208928 |  dest_result_addr=1152921509426208936
            // 0x00E56070: ADD x29, sp, #0x20         | X29 = (1152921509426208896 + 32) = 1152921509426208928 (0x100000011F41A0A0);
            // 0x00E56074: SUB sp, sp, #0x10          | SP = (1152921509426208896 - 16) = 1152921509426208880 (0x100000011F41A070);
            // 0x00E56078: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E5607C: LDRB w8, [x22, #0xac4]     | W8 = (bool)static_value_03734AC4;       
            // 0x00E56080: MOV x20, x2                | X20 = version;//m1                      
            // 0x00E56084: MOV x21, x1                | X21 = name;//m1                         
            // 0x00E56088: MOV x19, x0                | X19 = 1152921509426220944 (0x100000011F41CF90);//ML01
            // 0x00E5608C: TBNZ w8, #0, #0xe560a8     | if (static_value_03734AC4 == true) goto label_0;
            // 0x00E56090: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x00E56094: LDR x8, [x8, #0x108]       | X8 = 0x2B8EA24;                         
            // 0x00E56098: LDR w0, [x8]               | W0 = 0x1147;                            
            // 0x00E5609C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1147, ????);     
            // 0x00E560A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E560A4: STRB w8, [x22, #0xac4]     | static_value_03734AC4 = true;            //  dest_result_addr=57887428
            label_0:
            // 0x00E560A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E560AC: MOV x0, x19                | X0 = 1152921509426220944 (0x100000011F41CF90);//ML01
            // 0x00E560B0: BL #0x16f59f0              | version..ctor();                        
            val_1 = new System.Object();
            // 0x00E560B4: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E560B8: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E560BC: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E560C0: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E560C4: TBZ w8, #0, #0xe560d4      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E560C8: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E560CC: CBNZ w8, #0xe560d4         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E560D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E560D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E560D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E560DC: MOV x1, x21                | X1 = name;//m1                          
            // 0x00E560E0: BL #0x11d9e04              | ILRuntime.Mono.Cecil.Mixin.CheckName(name:  0);
            ILRuntime.Mono.Cecil.Mixin.CheckName(name:  0);
            // 0x00E560E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E560E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E560EC: MOV x1, x20                | X1 = version;//m1                       
            // 0x00E560F0: STR x21, [x19, #0x10]      | this.name = name;                        //  dest_result_addr=1152921509426220960
            this.name = name;
            // 0x00E560F4: BL #0x11d8b84              | X0 = ILRuntime.Mono.Cecil.Mixin.CheckVersion(version:  0);
            System.Version val_2 = ILRuntime.Mono.Cecil.Mixin.CheckVersion(version:  0);
            // 0x00E560F8: STR x0, [x19, #0x20]       | this.version = val_2;                    //  dest_result_addr=1152921509426220976
            this.version = val_2;
            // 0x00E560FC: ADD x0, sp, #8             | X0 = (1152921509426208880 + 8) = 1152921509426208888 (0x100000011F41A078);
            // 0x00E56100: MOVZ w1, #0x2300, lsl #16  | W1 = 587202560 (0x23000000);//ML01      
            // 0x00E56104: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56108: STR wzr, [x19, #0x40]      | this.hash_algorithm = null;              //  dest_result_addr=1152921509426221008
            this.hash_algorithm = 0;
            // 0x00E5610C: STR wzr, [sp, #8]          | stack[1152921509426208888] = 0x0;        //  dest_result_addr=1152921509426208888
            // 0x00E56110: BL #0x11d58e4              | null..ctor(value:  0);                  
            ProtoBuf.SubItemToken val_3 = new ProtoBuf.SubItemToken(value:  0);
            // 0x00E56114: LDR w8, [sp, #8]           | W8 = val_3.value;                       
            // 0x00E56118: STR w8, [x19, #0x50]       | this.token = val_3.value;                //  dest_result_addr=1152921509426221024
            this.token = val_3.value;
            // 0x00E5611C: SUB sp, x29, #0x20         | SP = (1152921509426208928 - 32) = 1152921509426208896 (0x100000011F41A080);
            // 0x00E56120: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E56124: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E56128: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E5612C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E56130 (15032624), len: 4  VirtAddr: 0x00E56130 RVA: 0x00E56130 token: 100663488 methodIndex: 19316 delegateWrapperIndex: 0 methodInvoker: 0
        public override string ToString()
        {
            //
            // Disasemble & Code
            // 0x00E56130: B #0xe54774                | return this.get_FullName();             
            return this.FullName;
        
        }
    
    }

}
