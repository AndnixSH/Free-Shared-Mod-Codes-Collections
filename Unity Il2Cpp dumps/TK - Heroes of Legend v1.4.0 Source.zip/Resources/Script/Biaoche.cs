using UnityEngine;
public class Biaoche : Monster
{
    // Fields
    public const string MOVE_TO_END = "MOVE_TO_END";
    private friendNpcCfg _friendNpcCfg; //  0x00000638
    private UnityEngine.Vector3[] targetPointArr; //  0x00000640
    private float _curTime; //  0x00000648
    private float _waitTime; //  0x0000064C
    private bool _isStartMove; //  0x00000650
    private float _maxDis; //  0x00000654
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x28739EC
    private float <MoveJindu>k__BackingField; //  0x00000658
    private int _aimCount; //  0x0000065C
    private float[] _sumWay; //  0x00000660
    
    // Properties
    public float MoveJindu { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B8F944 (12122436), len: 8  VirtAddr: 0x00B8F944 RVA: 0x00B8F944 token: 100691620 methodIndex: 25131 delegateWrapperIndex: 0 methodInvoker: 0
    public Biaoche()
    {
        //
        // Disasemble & Code
        // 0x00B8F944: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F948: B #0xac4934                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F94C (12122444), len: 8  VirtAddr: 0x00B8F94C RVA: 0x00B8F94C token: 100691621 methodIndex: 25132 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_MoveJindu(float value)
    {
        //
        // Disasemble & Code
        // 0x00B8F94C: STR s0, [x0, #0x658]       | this.<MoveJindu>k__BackingField = value;  //  dest_result_addr=1152921514683514024
        this.<MoveJindu>k__BackingField = value;
        // 0x00B8F950: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F954 (12122452), len: 8  VirtAddr: 0x00B8F954 RVA: 0x00B8F954 token: 100691622 methodIndex: 25133 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_MoveJindu()
    {
        //
        // Disasemble & Code
        // 0x00B8F954: LDR s0, [x0, #0x658]       | S0 = this.<MoveJindu>k__BackingField; //P2 
        // 0x00B8F958: RET                        |  return (System.Single)this.<MoveJindu>k__BackingField;
        return this.<MoveJindu>k__BackingField;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F95C (12122460), len: 4  VirtAddr: 0x00B8F95C RVA: 0x00B8F95C token: 100691623 methodIndex: 25134 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void OnTriggerBehaivir(CombatEntity main)
    {
        //
        // Disasemble & Code
        // 0x00B8F95C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F960 (12122464), len: 8  VirtAddr: 0x00B8F960 RVA: 0x00B8F960 token: 100691624 methodIndex: 25135 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnTriggerFun(int effectId = 366)
    {
        //
        // Disasemble & Code
        // 0x00B8F960: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F964: B #0xac49b0                | this.OnTriggerFun(effectId:  effectId); return;
        this.OnTriggerFun(effectId:  effectId);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F968 (12122472), len: 488  VirtAddr: 0x00B8F968 RVA: 0x00B8F968 token: 100691625 methodIndex: 25136 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void Init()
    {
        //
        // Disasemble & Code
        // 0x00B8F968: STP x24, x23, [sp, #-0x40]! | stack[1152921514683967792] = ???;  stack[1152921514683967800] = ???;  //  dest_result_addr=1152921514683967792 |  dest_result_addr=1152921514683967800
        // 0x00B8F96C: STP x22, x21, [sp, #0x10]  | stack[1152921514683967808] = ???;  stack[1152921514683967816] = ???;  //  dest_result_addr=1152921514683967808 |  dest_result_addr=1152921514683967816
        // 0x00B8F970: STP x20, x19, [sp, #0x20]  | stack[1152921514683967824] = ???;  stack[1152921514683967832] = ???;  //  dest_result_addr=1152921514683967824 |  dest_result_addr=1152921514683967832
        // 0x00B8F974: STP x29, x30, [sp, #0x30]  | stack[1152921514683967840] = ???;  stack[1152921514683967848] = ???;  //  dest_result_addr=1152921514683967840 |  dest_result_addr=1152921514683967848
        // 0x00B8F978: ADD x29, sp, #0x30         | X29 = (1152921514683967792 + 48) = 1152921514683967840 (0x1000000258A4A960);
        // 0x00B8F97C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8F980: LDRB w8, [x20, #0xa31]     | W8 = (bool)static_value_03733A31;       
        // 0x00B8F984: MOV x19, x0                | X19 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8F988: TBNZ w8, #0, #0xb8f9a4     | if (static_value_03733A31 == true) goto label_0;
        // 0x00B8F98C: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
        // 0x00B8F990: LDR x8, [x8, #0x428]       | X8 = 0x2B8F3B0;                         
        // 0x00B8F994: LDR w0, [x8]               | W0 = 0x13AE;                            
        // 0x00B8F998: BL #0x2782188              | X0 = sub_2782188( ?? 0x13AE, ????);     
        // 0x00B8F99C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8F9A0: STRB w8, [x20, #0xa31]     | static_value_03733A31 = true;            //  dest_result_addr=57883185
        label_0:
        // 0x00B8F9A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F9A8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B8F9AC: MOV x0, x19                | X0 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8F9B0: BL #0xd89a34               | this.set_unitCamp(value:  1);           
        this.unitCamp = 1;
        // 0x00B8F9B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F9B8: MOV x0, x19                | X0 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8F9BC: BL #0xd8aff0               | this.Init();                            
        this.Init();
        // 0x00B8F9C0: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B8F9C4: LDR x8, [x8, #0x620]       | X8 = 1152921504893480960;               
        // 0x00B8F9C8: LDR x0, [x8]               | X0 = typeof(Entity.Behavior.BiaocheBehaviorCtrl);
        Entity.Behavior.BiaocheBehaviorCtrl val_1 = null;
        // 0x00B8F9CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Entity.Behavior.BiaocheBehaviorCtrl), ????);
        // 0x00B8F9D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F9D4: MOV x1, x19                | X1 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8F9D8: MOV x20, x0                | X20 = 1152921504893480960 (0x100000001115B000);//ML01
        // 0x00B8F9DC: BL #0xb68ba8               | .ctor(entity:  this);                   
        val_1 = new Entity.Behavior.BiaocheBehaviorCtrl(entity:  this);
        // 0x00B8F9E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F9E4: MOV x0, x19                | X0 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8F9E8: MOV x1, x20                | X1 = 1152921504893480960 (0x100000001115B000);//ML01
        // 0x00B8F9EC: BL #0xd8a1a4               | this.set_bvrCtrl(value:  val_1);        
        this.bvrCtrl = val_1;
        // 0x00B8F9F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F9F4: MOV x0, x19                | X0 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8F9F8: BL #0xd7dd80               | X0 = this.get_bvrCtrl();                
        Entity.Behavior.IBehaviorCtrl val_2 = this.bvrCtrl;
        // 0x00B8F9FC: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B8FA00: CBNZ x20, #0xb8fa08        | if (val_2 != null) goto label_1;        
        if(val_2 != null)
        {
            goto label_1;
        }
        // 0x00B8FA04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_1:
        // 0x00B8FA08: LDR x8, [x20]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
        // 0x00B8FA0C: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B8FA10: LDP x9, x1, [x8, #0x150]   | X9 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_150; X1 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_158; //  | 
        // 0x00B8FA14: BLR x9                     | X0 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_150();
        // 0x00B8FA18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FA1C: MOV x0, x19                | X0 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8FA20: BL #0xd7dd70               | X0 = this.get_characterAnim();          
        AnimationRunner val_3 = this.characterAnim;
        // 0x00B8FA24: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B8FA28: CBNZ x20, #0xb8fa30        | if (val_3 != null) goto label_2;        
        if(val_3 != null)
        {
            goto label_2;
        }
        // 0x00B8FA2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_2:
        // 0x00B8FA30: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B8FA34: LDR s0, [x8, #0x938]       | S0 = 1.1;                               
        // 0x00B8FA38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FA3C: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B8FA40: BL #0xb28578               | val_3.SetRunSpeed(runSpeed:  1.1f);     
        val_3.SetRunSpeed(runSpeed:  1.1f);
        // 0x00B8FA44: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00B8FA48: ADRP x22, #0x3658000       | X22 = 56983552 (0x3658000);             
        // 0x00B8FA4C: LDR x8, [x8, #0x9a0]       | X8 = 1152921514683952784;               
        // 0x00B8FA50: LDR x22, [x22, #0x980]     | X22 = 1152921504898113536;              
        // 0x00B8FA54: LDR x21, [x8]              | X21 = System.Void Biaoche::MoveCallback(CEvent.ZEvent ev);
        // 0x00B8FA58: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_4 = null;
        // 0x00B8FA5C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B8FA60: ADRP x23, #0x367a000       | X23 = 57122816 (0x367A000);             
        // 0x00B8FA64: LDR x23, [x23, #0xc38]     | X23 = 1152921512949758048;              
        // 0x00B8FA68: MOV x1, x19                | X1 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8FA6C: MOV x2, x21                | X2 = 1152921514683952784 (0x1000000258A46E90);//ML01
        // 0x00B8FA70: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8FA74: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B8FA78: BL #0x19cc774              | .ctor(object:  this, method:  System.Void Biaoche::MoveCallback(CEvent.ZEvent ev));
        val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void Biaoche::MoveCallback(CEvent.ZEvent ev));
        // 0x00B8FA7C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B8FA80: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B8FA84: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B8FA88: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B8FA8C: TBZ w8, #0, #0xb8fa9c      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B8FA90: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B8FA94: CBNZ w8, #0xb8fa9c         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B8FA98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_4:
        // 0x00B8FA9C: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00B8FAA0: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921510058805600)("MOVE_TO_END");
        // 0x00B8FAA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8FAA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8FAAC: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8FAB0: LDR x1, [x8]               | X1 = "MOVE_TO_END";                     
        // 0x00B8FAB4: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "MOVE_TO_END");
        CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "MOVE_TO_END");
        // 0x00B8FAB8: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00B8FABC: LDR x8, [x8, #0xcc8]       | X8 = 1152921514683953808;               
        // 0x00B8FAC0: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_5 = null;
        // 0x00B8FAC4: LDR x20, [x8]              | X20 = public System.Void Biaoche::BattleWin(CEvent.ZEvent ev);
        // 0x00B8FAC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B8FACC: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B8FAD0: MOV x1, x19                | X1 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8FAD4: MOV x2, x20                | X2 = 1152921514683953808 (0x1000000258A47290);//ML01
        // 0x00B8FAD8: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8FADC: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void Biaoche::BattleWin(CEvent.ZEvent ev));
        val_5 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void Biaoche::BattleWin(CEvent.ZEvent ev));
        // 0x00B8FAE0: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00B8FAE4: LDR x8, [x8, #0x550]       | X8 = (string**)(1152921510361990080)("BATTLE_ENDED");
        // 0x00B8FAE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8FAEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8FAF0: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8FAF4: LDR x1, [x8]               | X1 = "BATTLE_ENDED";                    
        // 0x00B8FAF8: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "BATTLE_ENDED");
        CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "BATTLE_ENDED");
        // 0x00B8FAFC: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00B8FB00: LDR x8, [x8, #0x1f8]       | X8 = 1152921514683954832;               
        // 0x00B8FB04: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_6 = null;
        // 0x00B8FB08: LDR x20, [x8]              | X20 = public System.Void Biaoche::BattleStart(CEvent.ZEvent ev);
        // 0x00B8FB0C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B8FB10: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B8FB14: MOV x1, x19                | X1 = 1152921514683979856 (0x1000000258A4D850);//ML01
        // 0x00B8FB18: MOV x2, x20                | X2 = 1152921514683954832 (0x1000000258A47690);//ML01
        // 0x00B8FB1C: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8FB20: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void Biaoche::BattleStart(CEvent.ZEvent ev));
        val_6 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void Biaoche::BattleStart(CEvent.ZEvent ev));
        // 0x00B8FB24: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B8FB28: LDR x8, [x8, #0x9c0]       | X8 = (string**)(1152921510361988960)("BATTLE_START");
        // 0x00B8FB2C: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8FB30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8FB34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8FB38: LDR x1, [x8]               | X1 = "BATTLE_START";                    
        // 0x00B8FB3C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8FB40: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8FB44: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8FB48: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B8FB4C: B #0xd775dc                | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "BATTLE_START"); return;
        CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "BATTLE_START");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8FB50 (12122960), len: 720  VirtAddr: 0x00B8FB50 RVA: 0x00B8FB50 token: 100691626 methodIndex: 25137 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Create(monstersCfg mcfg, JSCLevelMonsterConfig lmcfg)
    {
        //
        // Disasemble & Code
        //  | 
        float val_7;
        //  | 
        float val_8;
        //  | 
        float val_9;
        //  | 
        var val_10;
        // 0x00B8FB50: STP d11, d10, [sp, #-0x70]! | stack[1152921514684333696] = ???;  stack[1152921514684333704] = ???;  //  dest_result_addr=1152921514684333696 |  dest_result_addr=1152921514684333704
        // 0x00B8FB54: STP d9, d8, [sp, #0x10]    | stack[1152921514684333712] = ???;  stack[1152921514684333720] = ???;  //  dest_result_addr=1152921514684333712 |  dest_result_addr=1152921514684333720
        // 0x00B8FB58: STP x26, x25, [sp, #0x20]  | stack[1152921514684333728] = ???;  stack[1152921514684333736] = ???;  //  dest_result_addr=1152921514684333728 |  dest_result_addr=1152921514684333736
        // 0x00B8FB5C: STP x24, x23, [sp, #0x30]  | stack[1152921514684333744] = ???;  stack[1152921514684333752] = ???;  //  dest_result_addr=1152921514684333744 |  dest_result_addr=1152921514684333752
        // 0x00B8FB60: STP x22, x21, [sp, #0x40]  | stack[1152921514684333760] = ???;  stack[1152921514684333768] = ???;  //  dest_result_addr=1152921514684333760 |  dest_result_addr=1152921514684333768
        // 0x00B8FB64: STP x20, x19, [sp, #0x50]  | stack[1152921514684333776] = ???;  stack[1152921514684333784] = ???;  //  dest_result_addr=1152921514684333776 |  dest_result_addr=1152921514684333784
        // 0x00B8FB68: STP x29, x30, [sp, #0x60]  | stack[1152921514684333792] = ???;  stack[1152921514684333800] = ???;  //  dest_result_addr=1152921514684333792 |  dest_result_addr=1152921514684333800
        // 0x00B8FB6C: ADD x29, sp, #0x60         | X29 = (1152921514684333696 + 96) = 1152921514684333792 (0x1000000258AA3EE0);
        // 0x00B8FB70: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B8FB74: LDRB w8, [x22, #0xa32]     | W8 = (bool)static_value_03733A32;       
        // 0x00B8FB78: MOV x21, x2                | X21 = lmcfg;//m1                        
        // 0x00B8FB7C: MOV x20, x1                | X20 = mcfg;//m1                         
        // 0x00B8FB80: MOV x19, x0                | X19 = 1152921514684345808 (0x1000000258AA6DD0);//ML01
        // 0x00B8FB84: TBNZ w8, #0, #0xb8fba0     | if (static_value_03733A32 == true) goto label_0;
        // 0x00B8FB88: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00B8FB8C: LDR x8, [x8, #0xea8]       | X8 = 0x2B8F3AC;                         
        // 0x00B8FB90: LDR w0, [x8]               | W0 = 0x13AD;                            
        // 0x00B8FB94: BL #0x2782188              | X0 = sub_2782188( ?? 0x13AD, ????);     
        // 0x00B8FB98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8FB9C: STRB w8, [x22, #0xa32]     | static_value_03733A32 = true;            //  dest_result_addr=57883186
        label_0:
        // 0x00B8FBA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8FBA4: MOV x0, x19                | X0 = 1152921514684345808 (0x1000000258AA6DD0);//ML01
        // 0x00B8FBA8: MOV x1, x20                | X1 = mcfg;//m1                          
        // 0x00B8FBAC: MOV x2, x21                | X2 = lmcfg;//m1                         
        // 0x00B8FBB0: BL #0xac53d4               | this.Create(mcfg:  mcfg, lmcfg:  lmcfg);
        this.Create(mcfg:  mcfg, lmcfg:  lmcfg);
        // 0x00B8FBB4: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B8FBB8: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B8FBBC: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B8FBC0: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B8FBC4: TBZ w8, #0, #0xb8fbd4      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8FBC8: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B8FBCC: CBNZ w8, #0xb8fbd4         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8FBD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00B8FBD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8FBD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FBDC: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
        CSDatacfgManager val_1 = ZMG.CfgDataMgr;
        // 0x00B8FBE0: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B8FBE4: CBNZ x20, #0xb8fbec        | if (mcfg != null) goto label_3;         
        if(mcfg != null)
        {
            goto label_3;
        }
        // 0x00B8FBE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B8FBEC: LDR w20, [x20, #0x10]      | W20 = mcfg.id; //P2                     
        // 0x00B8FBF0: CBNZ x21, #0xb8fbf8        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00B8FBF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B8FBF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8FBFC: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B8FC00: MOV w1, w20                | W1 = mcfg.id;//m1                       
        // 0x00B8FC04: BL #0xb47f58               | X0 = val_1.GetfriendNpcCfg(id:  mcfg.id);
        friendNpcCfg val_2 = val_1.GetfriendNpcCfg(id:  mcfg.id);
        // 0x00B8FC08: LDR x20, [x19, #0x58]      | 
        // 0x00B8FC0C: STR x0, [x19, #0x638]      | this._friendNpcCfg = val_2;              //  dest_result_addr=1152921514684347400
        this._friendNpcCfg = val_2;
        // 0x00B8FC10: STR wzr, [x19, #0x65c]     | this._aimCount = 0;                      //  dest_result_addr=1152921514684347436
        this._aimCount = 0;
        // 0x00B8FC14: CBNZ x20, #0xb8fc1c        | if (mcfg.id != 0) goto label_5;         
        if(mcfg.id != 0)
        {
            goto label_5;
        }
        // 0x00B8FC18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B8FC1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FC20: MOV x0, x20                | X0 = mcfg.id;//m1                       
        // 0x00B8FC24: BL #0x2693510              | X0 = mcfg.id.get_position();            
        UnityEngine.Vector3 val_3 = mcfg.id.position;
        // 0x00B8FC28: LDR x20, [x19, #0x638]     | X20 = this._friendNpcCfg; //P2          
        // 0x00B8FC2C: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        val_7 = val_3.x;
        // 0x00B8FC30: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        val_8 = val_3.y;
        // 0x00B8FC34: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
        val_9 = val_3.z;
        // 0x00B8FC38: CBNZ x20, #0xb8fc40        | if (this._friendNpcCfg != null) goto label_6;
        if(this._friendNpcCfg != null)
        {
            goto label_6;
        }
        // 0x00B8FC3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? mcfg.id, ????);    
        label_6:
        // 0x00B8FC40: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B8FC44: LDR x8, [x8, #0xa90]       | X8 = 1152921504911745024;               
        // 0x00B8FC48: LDR x20, [x20, #0x20]      | X20 = this._friendNpcCfg.targetPoin; //P2 
        // 0x00B8FC4C: LDR x0, [x8]               | X0 = typeof(Util);                      
        // 0x00B8FC50: LDRB w8, [x0, #0x10a]      | W8 = Util.__il2cppRuntimeField_10A;     
        // 0x00B8FC54: TBZ w8, #0, #0xb8fc64      | if (Util.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B8FC58: LDR w8, [x0, #0xbc]        | W8 = Util.__il2cppRuntimeField_cctor_finished;
        // 0x00B8FC5C: CBNZ w8, #0xb8fc64         | if (Util.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B8FC60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Util), ????);
        label_8:
        // 0x00B8FC64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8FC68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8FC6C: MOV x1, x20                | X1 = this._friendNpcCfg.targetPoin;//m1 
        // 0x00B8FC70: BL #0xe16950               | X0 = Util.GetVector3_Arr(str:  0);      
        UnityEngine.Vector3[] val_4 = Util.GetVector3_Arr(str:  0);
        // 0x00B8FC74: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B8FC78: STR x20, [x19, #0x640]     | this.targetPointArr = val_4;             //  dest_result_addr=1152921514684347408
        this.targetPointArr = val_4;
        // 0x00B8FC7C: CBNZ x20, #0xb8fc84        | if (val_4 != null) goto label_9;        
        if(val_4 != null)
        {
            goto label_9;
        }
        // 0x00B8FC80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00B8FC84: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x00B8FC88: LDR x8, [x8, #0x4a0]       | X8 = 1152921505550193520;               
        // 0x00B8FC8C: LDR w20, [x20, #0x18]      | W20 = val_4.Length; //P2                
        // 0x00B8FC90: LDR x21, [x8]              | X21 = typeof(System.Single[]);          
        // 0x00B8FC94: MOV x0, x21                | X0 = 1152921505550193520 (0x10000000383A5370);//ML01
        // 0x00B8FC98: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Single[]), ????);
        // 0x00B8FC9C: MOV x0, x21                | X0 = 1152921505550193520 (0x10000000383A5370);//ML01
        // 0x00B8FCA0: MOV x1, x20                | X1 = val_4.Length;//m1                  
        // 0x00B8FCA4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Single[]), ????);
        // 0x00B8FCA8: STR x0, [x19, #0x660]      | this._sumWay = typeof(System.Single[]);  //  dest_result_addr=1152921514684347440
        this._sumWay = null;
        // 0x00B8FCAC: ADRP x21, #0x3673000       | X21 = 57094144 (0x3673000);             
        // 0x00B8FCB0: LDR x21, [x21, #0x488]     | X21 = 1152921504695078912;              
        // 0x00B8FCB4: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_10 = 0;
        // 0x00B8FCB8: ORR w22, wzr, #0xc         | W22 = 12(0xC);                          
        // 0x00B8FCBC: B #0xb8fcd0                |  goto label_10;                         
        goto label_10;
        label_23:
        // 0x00B8FCC0: MADD x8, x23, x22, x24     | X8 = (X23 * 12) + X24;                  
        var val_5 = X24 + (X23 * 12);
        // 0x00B8FCC4: LDP s8, s9, [x8, #0x20]    | S8 = (X23 * 12) + X24 + 32; S9 = (X23 * 12) + X24 + 32 + 4; //  | 
        val_7 = mem[(X23 * 12) + X24 + 32];
        val_7 = (X23 * 12) + X24 + 32;
        val_8 = mem[(X23 * 12) + X24 + 32 + 4];
        val_8 = (X23 * 12) + X24 + 32 + 4;
        // 0x00B8FCC8: LDR s10, [x8, #0x28]       | S10 = (X23 * 12) + X24 + 40;            
        val_9 = mem[(X23 * 12) + X24 + 40];
        val_9 = (X23 * 12) + X24 + 40;
        // 0x00B8FCCC: ADD w20, w20, #1           | W20 = (val_10 + 1) = val_10 (0x00000001);
        val_10 = 1;
        label_10:
        // 0x00B8FCD0: LDR x23, [x19, #0x640]     | X23 = this.targetPointArr; //P2         
        // 0x00B8FCD4: CBNZ x23, #0xb8fcdc        | if (this.targetPointArr != null) goto label_11;
        if(this.targetPointArr != null)
        {
            goto label_11;
        }
        // 0x00B8FCD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Single[]), ????);
        label_11:
        // 0x00B8FCDC: LDR w8, [x23, #0x18]       | W8 = this.targetPointArr.Length; //P2   
        // 0x00B8FCE0: CMP w20, w8                | STATE = COMPARE(0x1, this.targetPointArr.Length)
        // 0x00B8FCE4: B.GE #0xb8fddc             | if (val_10 >= this.targetPointArr.Length) goto label_12;
        if(val_10 >= this.targetPointArr.Length)
        {
            goto label_12;
        }
        // 0x00B8FCE8: LDR x24, [x19, #0x660]     | X24 = this._sumWay; //P2                
        // 0x00B8FCEC: LDR x25, [x19, #0x640]     | X25 = this.targetPointArr; //P2         
        // 0x00B8FCF0: CBNZ x25, #0xb8fcf8        | if (this.targetPointArr != null) goto label_13;
        if(this.targetPointArr != null)
        {
            goto label_13;
        }
        // 0x00B8FCF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Single[]), ????);
        label_13:
        // 0x00B8FCF8: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B8FCFC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B8FD00: TBZ w8, #0, #0xb8fd10      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00B8FD04: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B8FD08: CBNZ w8, #0xb8fd10         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00B8FD0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_15:
        // 0x00B8FD10: LDR w8, [x25, #0x18]       | W8 = this.targetPointArr.Length; //P2   
        // 0x00B8FD14: SXTW x23, w20              | X23 = 1 (0x00000001);                   
        // 0x00B8FD18: CMP w20, w8                | STATE = COMPARE(0x1, this.targetPointArr.Length)
        // 0x00B8FD1C: B.LO #0xb8fd2c             | if (val_10 < this.targetPointArr.Length) goto label_16;
        if(val_10 < this.targetPointArr.Length)
        {
            goto label_16;
        }
        // 0x00B8FD20: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.Vector3), ????);
        // 0x00B8FD24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FD28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.Vector3), ????);
        label_16:
        // 0x00B8FD2C: MADD x8, x23, x22, x25     | X8 = (1 * 12) + this.targetPointArr;    
        var val_6 = this.targetPointArr + (1 * 12);
        // 0x00B8FD30: LDP s3, s4, [x8, #0x20]    | S3 = (1 * 12) + this.targetPointArr + 32; S4 = (1 * 12) + this.targetPointArr + 32 + 4; //  | 
        // 0x00B8FD34: LDR s5, [x8, #0x28]        | S5 = (1 * 12) + this.targetPointArr + 40;
        // 0x00B8FD38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8FD3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FD40: MOV v0.16b, v8.16b         | V0 = (X23 * 12) + X24 + 32;//m1         
        // 0x00B8FD44: MOV v1.16b, v9.16b         | V1 = (X23 * 12) + X24 + 32 + 4;//m1     
        // 0x00B8FD48: MOV v2.16b, v10.16b        | V2 = (X23 * 12) + X24 + 40;//m1         
        // 0x00B8FD4C: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_7, y = val_8, z = val_9}, b:  new UnityEngine.Vector3() {x = (1 * 12) + this.targetPointArr + 32, y = (1 * 12) + this.targetPointArr + 32 + 4, z = (1 * 12) + this.targetPointArr + 40});
        float val_7 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_7, y = val_8, z = val_9}, b:  new UnityEngine.Vector3() {x = (1 * 12) + this.targetPointArr + 32, y = (1 * 12) + this.targetPointArr + 32 + 4, z = (1 * 12) + this.targetPointArr + 40});
        // 0x00B8FD50: MOV v8.16b, v0.16b         | V8 = val_7;//m1                         
        // 0x00B8FD54: CBNZ x24, #0xb8fd5c        | if (this._sumWay != null) goto label_17;
        if(this._sumWay != null)
        {
            goto label_17;
        }
        // 0x00B8FD58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_17:
        // 0x00B8FD5C: LDR w8, [x24, #0x18]       | W8 = this._sumWay.Length; //P2          
        // 0x00B8FD60: CMP w20, w8                | STATE = COMPARE(0x1, this._sumWay.Length)
        // 0x00B8FD64: B.LO #0xb8fd74             | if (val_10 < this._sumWay.Length) goto label_18;
        if(val_10 < this._sumWay.Length)
        {
            goto label_18;
        }
        // 0x00B8FD68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B8FD6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FD70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_18:
        // 0x00B8FD74: ADD x8, x24, x23, lsl #2   | X8 = this._sumWay[0x1]; //PARR1         
        // 0x00B8FD78: STR s8, [x8, #0x20]        | this._sumWay[0x1][0] = val_7;            //  dest_result_addr=0
        this._sumWay[1] = val_7;
        // 0x00B8FD7C: LDR s8, [x19, #0x654]      | S8 = this._maxDis; //P2                 
        // 0x00B8FD80: LDR x24, [x19, #0x660]     | X24 = this._sumWay; //P2                
        // 0x00B8FD84: CBNZ x24, #0xb8fd8c        | if (this._sumWay != null) goto label_19;
        if(this._sumWay != null)
        {
            goto label_19;
        }
        // 0x00B8FD88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_19:
        // 0x00B8FD8C: LDR w8, [x24, #0x18]       | W8 = this._sumWay.Length; //P2          
        // 0x00B8FD90: CMP w20, w8                | STATE = COMPARE(0x1, this._sumWay.Length)
        // 0x00B8FD94: B.LO #0xb8fda4             | if (val_10 < this._sumWay.Length) goto label_20;
        if(val_10 < this._sumWay.Length)
        {
            goto label_20;
        }
        // 0x00B8FD98: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B8FD9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FDA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_20:
        // 0x00B8FDA4: ADD x8, x24, x23, lsl #2   | X8 = this._sumWay[0x1]; //PARR1         
        // 0x00B8FDA8: LDR s0, [x8, #0x20]        | S0 = this._sumWay[0x1][0]               
        float val_8 = this._sumWay[1];
        // 0x00B8FDAC: LDR x24, [x19, #0x640]     | X24 = this.targetPointArr; //P2         
        // 0x00B8FDB0: FADD s0, s8, s0            | S0 = (this._maxDis + this._sumWay[0x1][0]);
        val_8 = this._maxDis + val_8;
        // 0x00B8FDB4: STR s0, [x19, #0x654]      | this._maxDis = (this._maxDis + this._sumWay[0x1][0]);  //  dest_result_addr=1152921514684347428
        this._maxDis = val_8;
        // 0x00B8FDB8: CBNZ x24, #0xb8fdc0        | if (this.targetPointArr != null) goto label_21;
        if(this.targetPointArr != null)
        {
            goto label_21;
        }
        // 0x00B8FDBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_21:
        // 0x00B8FDC0: LDR w8, [x24, #0x18]       | W8 = this.targetPointArr.Length; //P2   
        // 0x00B8FDC4: CMP w20, w8                | STATE = COMPARE(0x1, this.targetPointArr.Length)
        // 0x00B8FDC8: B.LO #0xb8fcc0             | if (val_10 < this.targetPointArr.Length) goto label_23;
        if(val_10 < this.targetPointArr.Length)
        {
            goto label_23;
        }
        // 0x00B8FDCC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B8FDD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FDD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B8FDD8: B #0xb8fcc0                |  goto label_23;                         
        goto label_23;
        label_12:
        // 0x00B8FDDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8FDE0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B8FDE4: MOV x0, x19                | X0 = 1152921514684345808 (0x1000000258AA6DD0);//ML01
        // 0x00B8FDE8: BL #0xd89e00               | this.set_isAttack(value:  true);        
        this.isAttack = true;
        // 0x00B8FDEC: LDR x8, [x19]              | X8 = typeof(Biaoche);                   
        // 0x00B8FDF0: MOV x0, x19                | X0 = 1152921514684345808 (0x1000000258AA6DD0);//ML01
        // 0x00B8FDF4: MOVZ w1, #0x16e            | W1 = 366 (0x16E);//ML01                 
        // 0x00B8FDF8: LDR x3, [x8, #0x260]       | X3 = typeof(Biaoche).__il2cppRuntimeField_260;
        // 0x00B8FDFC: LDR x2, [x8, #0x268]       | X2 = typeof(Biaoche).__il2cppRuntimeField_268;
        // 0x00B8FE00: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8FE04: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8FE08: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8FE0C: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B8FE10: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B8FE14: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B8FE18: LDP d11, d10, [sp], #0x70  | D11 = ; D10 = ;                          //  | 
        // 0x00B8FE1C: BR x3                      | goto typeof(Biaoche).__il2cppRuntimeField_260;
        goto typeof(Biaoche).__il2cppRuntimeField_260;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8FE20 (12123680), len: 968  VirtAddr: 0x00B8FE20 RVA: 0x00B8FE20 token: 100691627 methodIndex: 25138 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Update()
    {
        //
        // Disasemble & Code
        //  | 
        CombatEntity val_11;
        //  | 
        var val_12;
        //  | 
        UnityEngine.Vector3 val_13;
        //  | 
        System.Single[] val_14;
        //  | 
        int val_15;
        //  | 
        float val_16;
        //  | 
        var val_17;
        // 0x00B8FE20: STP d13, d12, [sp, #-0x70]! | stack[1152921514684855296] = ???;  stack[1152921514684855304] = ???;  //  dest_result_addr=1152921514684855296 |  dest_result_addr=1152921514684855304
        // 0x00B8FE24: STP d11, d10, [sp, #0x10]  | stack[1152921514684855312] = ???;  stack[1152921514684855320] = ???;  //  dest_result_addr=1152921514684855312 |  dest_result_addr=1152921514684855320
        // 0x00B8FE28: STP d9, d8, [sp, #0x20]    | stack[1152921514684855328] = ???;  stack[1152921514684855336] = ???;  //  dest_result_addr=1152921514684855328 |  dest_result_addr=1152921514684855336
        // 0x00B8FE2C: STP x24, x23, [sp, #0x30]  | stack[1152921514684855344] = ???;  stack[1152921514684855352] = ???;  //  dest_result_addr=1152921514684855344 |  dest_result_addr=1152921514684855352
        // 0x00B8FE30: STP x22, x21, [sp, #0x40]  | stack[1152921514684855360] = ???;  stack[1152921514684855368] = ???;  //  dest_result_addr=1152921514684855360 |  dest_result_addr=1152921514684855368
        // 0x00B8FE34: STP x20, x19, [sp, #0x50]  | stack[1152921514684855376] = ???;  stack[1152921514684855384] = ???;  //  dest_result_addr=1152921514684855376 |  dest_result_addr=1152921514684855384
        // 0x00B8FE38: STP x29, x30, [sp, #0x60]  | stack[1152921514684855392] = ???;  stack[1152921514684855400] = ???;  //  dest_result_addr=1152921514684855392 |  dest_result_addr=1152921514684855400
        // 0x00B8FE3C: ADD x29, sp, #0x60         | X29 = (1152921514684855296 + 96) = 1152921514684855392 (0x1000000258B23460);
        // 0x00B8FE40: SUB sp, sp, #0x10          | SP = (1152921514684855296 - 16) = 1152921514684855280 (0x1000000258B233F0);
        // 0x00B8FE44: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8FE48: LDRB w8, [x20, #0xa33]     | W8 = (bool)static_value_03733A33;       
        // 0x00B8FE4C: MOV x19, x0                | X19 = 1152921514684867408 (0x1000000258B26350);//ML01
        val_11 = this;
        // 0x00B8FE50: TBNZ w8, #0, #0xb8fe6c     | if (static_value_03733A33 == true) goto label_0;
        // 0x00B8FE54: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00B8FE58: LDR x8, [x8, #0x998]       | X8 = 0x2B8F3B8;                         
        // 0x00B8FE5C: LDR w0, [x8]               | W0 = 0x13B0;                            
        // 0x00B8FE60: BL #0x2782188              | X0 = sub_2782188( ?? 0x13B0, ????);     
        // 0x00B8FE64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8FE68: STRB w8, [x20, #0xa33]     | static_value_03733A33 = true;            //  dest_result_addr=57883187
        label_0:
        // 0x00B8FE6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FE70: MOV x0, x19                | X0 = 1152921514684867408 (0x1000000258B26350);//ML01
        // 0x00B8FE74: BL #0xac7598               | this.Update();                          
        this.Update();
        // 0x00B8FE78: LDRB w8, [x19, #0x650]     | W8 = this._isStartMove; //P2            
        // 0x00B8FE7C: CBZ w8, #0xb900a4          | if (this._isStartMove == false) goto label_1;
        if(this._isStartMove == false)
        {
            goto label_1;
        }
        // 0x00B8FE80: ADRP x22, #0x35f7000       | X22 = 56586240 (0x35F7000);             
        // 0x00B8FE84: LDR x22, [x22, #0xb20]     | X22 = 1152921504901574656;              
        // 0x00B8FE88: LDR x8, [x22]              | X8 = typeof(GameMgr);                   
        // 0x00B8FE8C: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B8FE90: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B8FE94: CBNZ x20, #0xb8fe9c        | if (GameMgr.UPDATEOnOffEffect != null) goto label_2;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_2;
        }
        // 0x00B8FE98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x00B8FE9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_12 = 0;
        // 0x00B8FEA0: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00B8FEA4: BL #0xc148b8               | X0 = GameMgr.UPDATEOnOffEffect.get_isBattleStart();
        bool val_1 = GameMgr.UPDATEOnOffEffect.isBattleStart;
        // 0x00B8FEA8: TBZ w0, #0, #0xb8ff0c      | if (val_1 == false) goto label_4;       
        if(val_1 == false)
        {
            goto label_4;
        }
        // 0x00B8FEAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_12 = 0;
        // 0x00B8FEB0: MOV x0, x19                | X0 = 1152921514684867408 (0x1000000258B26350);//ML01
        // 0x00B8FEB4: BL #0xd7dd80               | X0 = this.get_bvrCtrl();                
        Entity.Behavior.IBehaviorCtrl val_2 = this.bvrCtrl;
        // 0x00B8FEB8: CBZ x0, #0xb8ff0c          | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00B8FEBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FEC0: MOV x0, x19                | X0 = 1152921514684867408 (0x1000000258B26350);//ML01
        // 0x00B8FEC4: BL #0xd7dd80               | X0 = this.get_bvrCtrl();                
        Entity.Behavior.IBehaviorCtrl val_3 = this.bvrCtrl;
        // 0x00B8FEC8: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B8FECC: CBNZ x20, #0xb8fed4        | if (val_3 != null) goto label_5;        
        if(val_3 != null)
        {
            goto label_5;
        }
        // 0x00B8FED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B8FED4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B8FED8: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B8FEDC: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        val_13 = null;
        // 0x00B8FEE0: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B8FEE4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B8FEE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FEEC: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B8FEF0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B8FEF4: LDR x8, [x20]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
        // 0x00B8FEF8: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B8FEFC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        val_12 = 1;
        // 0x00B8FF00: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B8FF04: LDP x9, x3, [x8, #0x180]   | X9 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
        // 0x00B8FF08: BLR x9                     | X0 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180();
        label_4:
        // 0x00B8FF0C: LDR x8, [x19]              | X8 = typeof(Biaoche);                   
        // 0x00B8FF10: MOV x0, x19                | X0 = 1152921514684867408 (0x1000000258B26350);//ML01
        // 0x00B8FF14: LDP x9, x1, [x8, #0x150]   | X9 = public System.Boolean CombatEntity::get_canMove(); X1 = public System.Boolean CombatEntity::get_canMove(); //  | 
        // 0x00B8FF18: BLR x9                     | X0 = this.get_canMove();                
        bool val_4 = this.canMove;
        // 0x00B8FF1C: TBZ w0, #0, #0xb901c4      | if (val_4 == false) goto label_19;      
        if(val_4 == false)
        {
            goto label_19;
        }
        // 0x00B8FF20: LDR x20, [x19, #0x660]     | X20 = this._sumWay; //P2                
        val_14 = this._sumWay;
        // 0x00B8FF24: LDR w23, [x19, #0x65c]     | W23 = this._aimCount; //P2              
        val_15 = this._aimCount;
        // 0x00B8FF28: FMOV s11, wzr              | S11 = 0f;                               
        val_16 = 0f;
        // 0x00B8FF2C: CMP x20, #0                | STATE = COMPARE(this._sumWay, 0x0)      
        // 0x00B8FF30: CSET w8, eq                | W8 = val_14 == null ? 1 : 0;            
        var val_5 = (val_14 == null) ? 1 : 0;
        // 0x00B8FF34: CMP w23, #1                | STATE = COMPARE(this._aimCount, 0x1)    
        // 0x00B8FF38: B.LT #0xb8ff8c             | if (val_15 < 1) goto label_7;           
        if(val_15 < 1)
        {
            goto label_7;
        }
        // 0x00B8FF3C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        var val_12 = 0;
        label_10:
        // 0x00B8FF40: TBZ w8, #0, #0xb8ff48      | if ((val_14 == null ? 1 : 0 & 0x1) == 0) goto label_8;
        if((val_5 & 1) == 0)
        {
            goto label_8;
        }
        // 0x00B8FF44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x00B8FF48: LDR w8, [x20, #0x18]       | W8 = this._sumWay.Length; //P2          
        // 0x00B8FF4C: SXTW x23, w21              | X23 = 0 (0x00000000);                   
        // 0x00B8FF50: CMP w21, w8                | STATE = COMPARE(0x0, this._sumWay.Length)
        // 0x00B8FF54: B.LO #0xb8ff64             | if (0 < this._sumWay.Length) goto label_9;
        if(val_12 < this._sumWay.Length)
        {
            goto label_9;
        }
        // 0x00B8FF58: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
        // 0x00B8FF5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FF60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_9:
        // 0x00B8FF64: ADD x8, x20, x23, lsl #2   | X8 = this._sumWay[0x0]; //PARR1         
        // 0x00B8FF68: LDR x20, [x19, #0x660]     | X20 = this._sumWay; //P2                
        val_14 = this._sumWay;
        // 0x00B8FF6C: LDR s0, [x8, #0x20]        | S0 = this._sumWay[0x0][0]               
        float val_11 = val_14[0];
        // 0x00B8FF70: LDR w23, [x19, #0x65c]     | W23 = this._aimCount; //P2              
        val_15 = this._aimCount;
        // 0x00B8FF74: ADD w21, w21, #1           | W21 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x00B8FF78: CMP x20, #0                | STATE = COMPARE(this._sumWay, 0x0)      
        // 0x00B8FF7C: FADD s11, s11, s0          | S11 = (val_16 + this._sumWay[0x0][0]);  
        val_16 = val_16 + val_11;
        // 0x00B8FF80: CSET w8, eq                | W8 = val_14 == null ? 1 : 0;            
        var val_6 = (val_14 == null) ? 1 : 0;
        // 0x00B8FF84: CMP w21, w23               | STATE = COMPARE((0 + 1), this._aimCount)
        // 0x00B8FF88: B.LT #0xb8ff40             | if (0 < val_15) goto label_10;          
        if(val_12 < val_15)
        {
            goto label_10;
        }
        label_7:
        // 0x00B8FF8C: CBZ w8, #0xb8ff94          | if (val_14 == null ? 1 : 0 == 0) goto label_11;
        if(val_6 == 0)
        {
            goto label_11;
        }
        // 0x00B8FF90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_11:
        // 0x00B8FF94: LDR w8, [x20, #0x18]       | W8 = this._sumWay.Length; //P2          
        // 0x00B8FF98: SXTW x21, w23              | X21 = (long)(int)(this._aimCount);      
        // 0x00B8FF9C: CMP w23, w8                | STATE = COMPARE(this._aimCount, this._sumWay.Length)
        // 0x00B8FFA0: B.LO #0xb8ffb0             | if (val_15 < this._sumWay.Length) goto label_12;
        if(val_15 < this._sumWay.Length)
        {
            goto label_12;
        }
        // 0x00B8FFA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
        // 0x00B8FFA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FFAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_12:
        // 0x00B8FFB0: ADD x8, x20, x21, lsl #2   | X8 = this._sumWay[(long)(int)(this._aimCount)]; //PARR1 
        // 0x00B8FFB4: LDR s12, [x8, #0x20]       | S12 = this._sumWay[(long)(int)(this._aimCount)][0]
        float val_13 = val_14[(long)val_15];
        // 0x00B8FFB8: LDR x20, [x19, #0x58]      | 
        // 0x00B8FFBC: CBNZ x20, #0xb8ffc4        | if (this._sumWay != null) goto label_13;
        if(val_14 != null)
        {
            goto label_13;
        }
        // 0x00B8FFC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_13:
        // 0x00B8FFC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8FFC8: MOV x0, x20                | X0 = this._sumWay;//m1                  
        // 0x00B8FFCC: BL #0x2693510              | X0 = this._sumWay.get_position();       
        UnityEngine.Vector3 val_7 = val_14.position;
        // 0x00B8FFD0: LDR x20, [x19, #0x640]     | X20 = this.targetPointArr; //P2         
        // 0x00B8FFD4: LDRSW x21, [x19, #0x65c]   | X21 = this._aimCount; //P2              
        // 0x00B8FFD8: MOV v8.16b, v0.16b         | V8 = val_7.x;//m1                       
        // 0x00B8FFDC: MOV v9.16b, v1.16b         | V9 = val_7.y;//m1                       
        // 0x00B8FFE0: MOV v10.16b, v2.16b        | V10 = val_7.z;//m1                      
        // 0x00B8FFE4: CBNZ x20, #0xb8ffec        | if (this.targetPointArr != null) goto label_14;
        if(this.targetPointArr != null)
        {
            goto label_14;
        }
        // 0x00B8FFE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._sumWay, ????);
        label_14:
        // 0x00B8FFEC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B8FFF0: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B8FFF4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B8FFF8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B8FFFC: TBZ w8, #0, #0xb9000c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x00B90000: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B90004: CBNZ w8, #0xb9000c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x00B90008: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_16:
        // 0x00B9000C: LDR w8, [x20, #0x18]       | W8 = this.targetPointArr.Length; //P2   
        // 0x00B90010: CMP w21, w8                | STATE = COMPARE(this._aimCount, this.targetPointArr.Length)
        // 0x00B90014: B.LO #0xb90024             | if (this._aimCount < this.targetPointArr.Length) goto label_17;
        if(this._aimCount < this.targetPointArr.Length)
        {
            goto label_17;
        }
        // 0x00B90018: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.Vector3), ????);
        // 0x00B9001C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90020: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.Vector3), ????);
        label_17:
        // 0x00B90024: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_14 = 12;
        // 0x00B90028: MADD x8, x21, x8, x20      | X8 = (this._aimCount * 12) + this.targetPointArr;
        val_14 = this.targetPointArr + (this._aimCount * val_14);
        // 0x00B9002C: LDP s3, s4, [x8, #0x20]    | S3 = (this._aimCount * 12) + this.targetPointArr + 32; S4 = (this._aimCount * 12) + this.targetPointArr + 32 + 4; //  | 
        // 0x00B90030: LDR s5, [x8, #0x28]        | S5 = (this._aimCount * 12) + this.targetPointArr + 40;
        // 0x00B90034: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B90038: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9003C: MOV v0.16b, v8.16b         | V0 = val_7.x;//m1                       
        // 0x00B90040: MOV v1.16b, v9.16b         | V1 = val_7.y;//m1                       
        // 0x00B90044: MOV v2.16b, v10.16b        | V2 = val_7.z;//m1                       
        // 0x00B90048: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, b:  new UnityEngine.Vector3() {x = (this._aimCount * 12) + this.targetPointArr + 32, y = (this._aimCount * 12) + this.targetPointArr + 32 + 4, z = (this._aimCount * 12) + this.targetPointArr + 40});
        float val_8 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, b:  new UnityEngine.Vector3() {x = (this._aimCount * 12) + this.targetPointArr + 32, y = (this._aimCount * 12) + this.targetPointArr + 32 + 4, z = (this._aimCount * 12) + this.targetPointArr + 40});
        // 0x00B9004C: LDR s1, [x19, #0x654]      | S1 = this._maxDis; //P2                 
        // 0x00B90050: FSUB s0, s12, s0           | S0 = (this._sumWay[(long)(int)(this._aimCount)][0] - val_8);
        val_8 = val_13 - val_8;
        // 0x00B90054: FADD s0, s11, s0           | S0 = ((val_16 + this._sumWay[0x0][0]) + (this._sumWay[(long)(int)(this._aimCount)][0] - val_8));
        val_8 = val_16 + val_8;
        // 0x00B90058: FDIV s0, s0, s1            | S0 = (((val_16 + this._sumWay[0x0][0]) + (this._sumWay[(long)(int)(this._aimCount)][0] - val_8)) / this._maxDis);
        val_8 = val_8 / this._maxDis;
        // 0x00B9005C: STR s0, [x19, #0x658]      | this.<MoveJindu>k__BackingField = (((val_16 + this._sumWay[0x0][0]) + (this._sumWay[(long)(int)(this._aimCount)][0] - val_8)) / this._maxDis);  //  dest_result_addr=1152921514684869032
        this.<MoveJindu>k__BackingField = val_8;
        // 0x00B90060: LDR x8, [x22]              | X8 = typeof(GameMgr);                   
        // 0x00B90064: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B90068: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B9006C: CBNZ x20, #0xb90074        | if (GameMgr.UPDATEOnOffEffect != null) goto label_18;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_18;
        }
        // 0x00B90070: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_18:
        // 0x00B90074: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90078: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00B9007C: MOV x1, x19                | X1 = 1152921514684867408 (0x1000000258B26350);//ML01
        // 0x00B90080: SUB sp, x29, #0x60         | SP = (1152921514684855392 - 96) = 1152921514684855296 (0x1000000258B23400);
        // 0x00B90084: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B90088: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B9008C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B90090: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B90094: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B90098: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B9009C: LDP d13, d12, [sp], #0x70  | D13 = ; D12 = ;                          //  | 
        // 0x00B900A0: B #0xc0ce08                | GameMgr.UPDATEOnOffEffect.TriggerBattle(src:  this); return;
        GameMgr.UPDATEOnOffEffect.TriggerBattle(src:  this);
        return;
        label_1:
        // 0x00B900A4: LDR s8, [x19, #0x648]      | S8 = this._curTime; //P2                
        // 0x00B900A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B900AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B900B0: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_9 = UnityEngine.Time.deltaTime;
        // 0x00B900B4: LDR s1, [x19, #0x64c]      | S1 = this._waitTime; //P2               
        // 0x00B900B8: FADD s0, s8, s0            | S0 = (this._curTime + val_9);           
        val_9 = this._curTime + val_9;
        // 0x00B900BC: STR s0, [x19, #0x648]      | this._curTime = (this._curTime + val_9);  //  dest_result_addr=1152921514684869016
        this._curTime = val_9;
        // 0x00B900C0: FCMP s0, s1                | STATE = COMPARE((this._curTime + val_9), this._waitTime)
        // 0x00B900C4: B.LT #0xb901c4             | if (val_9 < this._waitTime) goto label_19;
        if(val_9 < this._waitTime)
        {
            goto label_19;
        }
        // 0x00B900C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B900CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B900D0: MOV x0, x19                | X0 = 1152921514684867408 (0x1000000258B26350);//ML01
        // 0x00B900D4: STRB w8, [x19, #0x650]     | this._isStartMove = true;                //  dest_result_addr=1152921514684869024
        this._isStartMove = true;
        // 0x00B900D8: STR wzr, [x19, #0x648]     | this._curTime = 0;                       //  dest_result_addr=1152921514684869016
        this._curTime = 0f;
        // 0x00B900DC: BL #0xd7dd80               | X0 = this.get_bvrCtrl();                
        Entity.Behavior.IBehaviorCtrl val_10 = this.bvrCtrl;
        // 0x00B900E0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B900E4: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B900E8: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B900EC: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x00B900F0: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B900F4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B900F8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B900FC: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B90100: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B90104: LDR x21, [x19, #0x640]     | X21 = this.targetPointArr; //P2         
        // 0x00B90108: LDRSW x22, [x19, #0x65c]   | X22 = this._aimCount; //P2              
        // 0x00B9010C: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_11 = null;
        // 0x00B90110: CBNZ x21, #0xb90118        | if (this.targetPointArr != null) goto label_20;
        if(this.targetPointArr != null)
        {
            goto label_20;
        }
        // 0x00B90114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_20:
        // 0x00B90118: LDR w8, [x21, #0x18]       | W8 = this.targetPointArr.Length; //P2   
        // 0x00B9011C: CMP w22, w8                | STATE = COMPARE(this._aimCount, this.targetPointArr.Length)
        // 0x00B90120: B.LO #0xb90130             | if (this._aimCount < this.targetPointArr.Length) goto label_21;
        if(this._aimCount < this.targetPointArr.Length)
        {
            goto label_21;
        }
        // 0x00B90124: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Object[]), ????);
        // 0x00B90128: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9012C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Object[]), ????);
        label_21:
        // 0x00B90130: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_15 = 12;
        // 0x00B90134: MADD x8, x22, x8, x21      | X8 = (this._aimCount * 12) + this.targetPointArr;
        val_15 = this.targetPointArr + (this._aimCount * val_15);
        // 0x00B90138: LDR w9, [x8, #0x28]        | W9 = (this._aimCount * 12) + this.targetPointArr + 40;
        // 0x00B9013C: MOV x1, sp                 | X1 = 1152921514684855280 (0x1000000258B233F0);//ML01
        // 0x00B90140: STR w9, [sp, #8]           | stack[1152921514684855288] = (this._aimCount * 12) + this.targetPointArr + 40;  //  dest_result_addr=1152921514684855288
        // 0x00B90144: ADRP x9, #0x3673000        | X9 = 57094144 (0x3673000);              
        // 0x00B90148: LDR x8, [x8, #0x20]        | X8 = (this._aimCount * 12) + this.targetPointArr + 32;
        // 0x00B9014C: LDR x9, [x9, #0x488]       | X9 = 1152921504695078912;               
        // 0x00B90150: STR x8, [sp]               | stack[1152921514684855280] = (this._aimCount * 12) + this.targetPointArr + 32;  //  dest_result_addr=1152921514684855280
        // 0x00B90154: LDR x0, [x9]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B90158: BL #0x27bc028              | X0 = 1152921514685059152 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), (this._aimCount * 12) + this.targetPointArr + 32);
        // 0x00B9015C: MOV x21, x0                | X21 = 1152921514685059152 (0x1000000258B55050);//ML01
        val_13 = (this._aimCount * 12) + this.targetPointArr + 32;
        // 0x00B90160: CBNZ x19, #0xb90168        | if ( != null) goto label_22;            
        if(null != null)
        {
            goto label_22;
        }
        // 0x00B90164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        label_22:
        // 0x00B90168: CBZ x21, #0xb9018c         | if ((this._aimCount * 12) + this.targetPointArr + 32 == 0) goto label_24;
        if(((this._aimCount * 12) + this.targetPointArr + 32) == 0)
        {
            goto label_24;
        }
        // 0x00B9016C: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B90170: MOV x0, x21                | X0 = 1152921514685059152 (0x1000000258B55050);//ML01
        // 0x00B90174: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B90178: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        // 0x00B9017C: CBNZ x0, #0xb9018c         | if ((this._aimCount * 12) + this.targetPointArr + 32 != 0) goto label_24;
        if(((this._aimCount * 12) + this.targetPointArr + 32) != 0)
        {
            goto label_24;
        }
        // 0x00B90180: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        // 0x00B90184: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90188: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        label_24:
        // 0x00B9018C: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B90190: CBNZ w8, #0xb901a0         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_25;
        // 0x00B90194: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        // 0x00B90198: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9019C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        label_25:
        // 0x00B901A0: STR x21, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = (this._aimCount * 12) + this.targetPointArr + 32;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_13;
        // 0x00B901A4: CBNZ x20, #0xb901ac        | if (val_10 != null) goto label_26;      
        if(val_10 != null)
        {
            goto label_26;
        }
        // 0x00B901A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        label_26:
        // 0x00B901AC: LDR x8, [x20]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
        // 0x00B901B0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B901B4: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B901B8: MOV x2, x19                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B901BC: LDP x9, x3, [x8, #0x180]   | X9 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
        // 0x00B901C0: BLR x9                     | X0 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180();
        label_19:
        // 0x00B901C4: SUB sp, x29, #0x60         | SP = (1152921514684855392 - 96) = 1152921514684855296 (0x1000000258B23400);
        // 0x00B901C8: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B901CC: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B901D0: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B901D4: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B901D8: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B901DC: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B901E0: LDP d13, d12, [sp], #0x70  | D13 = ; D12 = ;                          //  | 
        // 0x00B901E4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B901E8 (12124648), len: 476  VirtAddr: 0x00B901E8 RVA: 0x00B901E8 token: 100691628 methodIndex: 25139 delegateWrapperIndex: 0 methodInvoker: 0
    public void BattleStart(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        // 0x00B901E8: STP d9, d8, [sp, #-0x50]!  | stack[1152921514685159840] = ???;  stack[1152921514685159848] = ???;  //  dest_result_addr=1152921514685159840 |  dest_result_addr=1152921514685159848
        // 0x00B901EC: STP x24, x23, [sp, #0x10]  | stack[1152921514685159856] = ???;  stack[1152921514685159864] = ???;  //  dest_result_addr=1152921514685159856 |  dest_result_addr=1152921514685159864
        // 0x00B901F0: STP x22, x21, [sp, #0x20]  | stack[1152921514685159872] = ???;  stack[1152921514685159880] = ???;  //  dest_result_addr=1152921514685159872 |  dest_result_addr=1152921514685159880
        // 0x00B901F4: STP x20, x19, [sp, #0x30]  | stack[1152921514685159888] = ???;  stack[1152921514685159896] = ???;  //  dest_result_addr=1152921514685159888 |  dest_result_addr=1152921514685159896
        // 0x00B901F8: STP x29, x30, [sp, #0x40]  | stack[1152921514685159904] = ???;  stack[1152921514685159912] = ???;  //  dest_result_addr=1152921514685159904 |  dest_result_addr=1152921514685159912
        // 0x00B901FC: ADD x29, sp, #0x40         | X29 = (1152921514685159840 + 64) = 1152921514685159904 (0x1000000258B6D9E0);
        // 0x00B90200: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B90204: LDRB w8, [x20, #0xa34]     | W8 = (bool)static_value_03733A34;       
        // 0x00B90208: MOV x19, x0                | X19 = 1152921514685171920 (0x1000000258B708D0);//ML01
        // 0x00B9020C: TBNZ w8, #0, #0xb90228     | if (static_value_03733A34 == true) goto label_0;
        // 0x00B90210: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00B90214: LDR x8, [x8, #0x7b8]       | X8 = 0x2B8F380;                         
        // 0x00B90218: LDR w0, [x8]               | W0 = 0x13A2;                            
        // 0x00B9021C: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A2, ????);     
        // 0x00B90220: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B90224: STRB w8, [x20, #0xa34]     | static_value_03733A34 = true;            //  dest_result_addr=57883188
        label_0:
        // 0x00B90228: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00B9022C: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00B90230: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00B90234: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B90238: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B9023C: CBNZ x20, #0xb90244        | if (GameMgr.UPDATEOnOffEffect != null) goto label_1;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_1;
        }
        // 0x00B90240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A2, ????);     
        label_1:
        // 0x00B90244: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90248: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00B9024C: BL #0xc188cc               | X0 = GameMgr.UPDATEOnOffEffect.GetAllHostilEntity();
        System.Collections.Generic.List<CombatEntity> val_1 = GameMgr.UPDATEOnOffEffect.GetAllHostilEntity();
        // 0x00B90250: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B90254: ADRP x23, #0x3646000       | X23 = 56909824 (0x3646000);             
        // 0x00B90258: ADRP x24, #0x35cf000       | X24 = 56422400 (0x35CF000);             
        // 0x00B9025C: LDR s8, [x8, #0x944]       | S8 = 1000;                              
        // 0x00B90260: LDR x23, [x23, #0xa00]     | X23 = 1152921510857364848;              
        // 0x00B90264: LDR x24, [x24, #0x628]     | X24 = 1152921510857186288;              
        // 0x00B90268: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B9026C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_7 = 0;
        // 0x00B90270: B #0xb90278                |  goto label_2;                          
        goto label_2;
        label_11:
        // 0x00B90274: ADD w21, w21, #1           | W21 = (val_7 + 1) = val_7 (0x00000001); 
        val_7 = 1;
        label_2:
        // 0x00B90278: CBNZ x20, #0xb90280        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B9027C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B90280: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<CombatEntity>::get_Count();
        // 0x00B90284: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B90288: BL #0x25ed72c              | X0 = val_1.get_Count();                 
        int val_2 = val_1.Count;
        // 0x00B9028C: CMP w21, w0                | STATE = COMPARE(0x1, val_2)             
        // 0x00B90290: B.GE #0xb90308             | if (val_7 >= val_2) goto label_4;       
        if(val_7 >= val_2)
        {
            goto label_4;
        }
        // 0x00B90294: CBNZ x20, #0xb9029c        | if (val_1 != null) goto label_5;        
        if(val_1 != null)
        {
            goto label_5;
        }
        // 0x00B90298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B9029C: LDR x2, [x24]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
        // 0x00B902A0: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B902A4: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B902A8: BL #0x25ed734              | X0 = val_1.get_Item(index:  1);         
        CombatEntity val_3 = val_1.Item[1];
        // 0x00B902AC: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00B902B0: CBNZ x22, #0xb902b8        | if (val_3 != null) goto label_6;        
        if(val_3 != null)
        {
            goto label_6;
        }
        // 0x00B902B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B902B8: LDR x8, [x22, #0x488]      | X8 = val_3.hatredCtrl; //P2             
        // 0x00B902BC: CBZ x8, #0xb90274          | if (val_3.hatredCtrl == null) goto label_11;
        if(val_3.hatredCtrl == null)
        {
            goto label_11;
        }
        // 0x00B902C0: CBNZ x20, #0xb902c8        | if (val_1 != null) goto label_8;        
        if(val_1 != null)
        {
            goto label_8;
        }
        // 0x00B902C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B902C8: LDR x2, [x24]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
        // 0x00B902CC: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B902D0: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B902D4: BL #0x25ed734              | X0 = val_1.get_Item(index:  1);         
        CombatEntity val_4 = val_1.Item[1];
        // 0x00B902D8: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B902DC: CBNZ x22, #0xb902e4        | if (val_4 != null) goto label_9;        
        if(val_4 != null)
        {
            goto label_9;
        }
        // 0x00B902E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00B902E4: LDR x22, [x22, #0x488]     | X22 = val_4.hatredCtrl; //P2            
        // 0x00B902E8: CBNZ x22, #0xb902f0        | if (val_4.hatredCtrl != null) goto label_10;
        if(val_4.hatredCtrl != null)
        {
            goto label_10;
        }
        // 0x00B902EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_10:
        // 0x00B902F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B902F4: MOV x0, x22                | X0 = val_4.hatredCtrl;//m1              
        // 0x00B902F8: MOV x1, x19                | X1 = 1152921514685171920 (0x1000000258B708D0);//ML01
        // 0x00B902FC: MOV v0.16b, v8.16b         | V0 = 1148846080 (0x447A0000);//ML01     
        // 0x00B90300: BL #0x28875f4              | val_4.hatredCtrl.AddHatred(entity:  this, hatred:  1000f);
        val_4.hatredCtrl.AddHatred(entity:  this, hatred:  1000f);
        // 0x00B90304: B #0xb90274                |  goto label_11;                         
        goto label_11;
        label_4:
        // 0x00B90308: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B9030C: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00B90310: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
        CEvent.ZEvent val_5 = null;
        // 0x00B90314: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00B90318: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00B9031C: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921510058805600)("MOVE_TO_END");
        // 0x00B90320: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90324: MOV x20, x0                | X20 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B90328: LDR x1, [x8]               | X1 = "MOVE_TO_END";                     
        // 0x00B9032C: BL #0xd80ce8               | .ctor(name:  "MOVE_TO_END");            
        val_5 = new CEvent.ZEvent(name:  "MOVE_TO_END");
        // 0x00B90330: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B90334: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B90338: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B9033C: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B90340: TBZ w8, #0, #0xb90350      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B90344: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B90348: CBNZ w8, #0xb90350         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B9034C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_13:
        // 0x00B90350: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B90354: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90358: MOV x1, x20                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B9035C: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        // 0x00B90360: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90364: MOV x0, x19                | X0 = 1152921514685171920 (0x1000000258B708D0);//ML01
        // 0x00B90368: BL #0xd7dd80               | X0 = this.get_bvrCtrl();                
        Entity.Behavior.IBehaviorCtrl val_6 = this.bvrCtrl;
        // 0x00B9036C: MOV x19, x0                | X19 = val_6;//m1                        
        // 0x00B90370: CBNZ x19, #0xb90378        | if (val_6 != null) goto label_14;       
        if(val_6 != null)
        {
            goto label_14;
        }
        // 0x00B90374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_14:
        // 0x00B90378: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B9037C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B90380: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x00B90384: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B90388: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B9038C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90390: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B90394: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B90398: LDR x8, [x19]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
        // 0x00B9039C: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B903A0: MOV x0, x19                | X0 = val_6;//m1                         
        // 0x00B903A4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B903A8: LDP x4, x3, [x8, #0x180]   | X4 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
        // 0x00B903AC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B903B0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B903B4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B903B8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B903BC: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B903C0: BR x4                      | goto typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180;
        goto typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B903C4 (12125124), len: 52  VirtAddr: 0x00B903C4 RVA: 0x00B903C4 token: 100691629 methodIndex: 25140 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void Dead()
    {
        //
        // Disasemble & Code
        // 0x00B903C4: STP x20, x19, [sp, #-0x20]! | stack[1152921514685300560] = ???;  stack[1152921514685300568] = ???;  //  dest_result_addr=1152921514685300560 |  dest_result_addr=1152921514685300568
        // 0x00B903C8: STP x29, x30, [sp, #0x10]  | stack[1152921514685300576] = ???;  stack[1152921514685300584] = ???;  //  dest_result_addr=1152921514685300576 |  dest_result_addr=1152921514685300584
        // 0x00B903CC: ADD x29, sp, #0x10         | X29 = (1152921514685300560 + 16) = 1152921514685300576 (0x1000000258B8FF60);
        // 0x00B903D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B903D4: MOV x19, x0                | X19 = 1152921514685312592 (0x1000000258B92E50);//ML01
        // 0x00B903D8: BL #0xac871c               | this.Dead();                            
        this.Dead();
        // 0x00B903DC: LDR x8, [x19]              | X8 = typeof(Biaoche);                   
        // 0x00B903E0: MOV x0, x19                | X0 = 1152921514685312592 (0x1000000258B92E50);//ML01
        // 0x00B903E4: LDR x2, [x8, #0x400]       | X2 = typeof(Biaoche).__il2cppRuntimeField_400;
        // 0x00B903E8: LDR x1, [x8, #0x408]       | X1 = typeof(Biaoche).__il2cppRuntimeField_408;
        // 0x00B903EC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B903F0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B903F4: BR x2                      | goto typeof(Biaoche).__il2cppRuntimeField_400;
        goto typeof(Biaoche).__il2cppRuntimeField_400;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B903F8 (12125176), len: 8  VirtAddr: 0x00B903F8 RVA: 0x00B903F8 token: 100691630 methodIndex: 25141 delegateWrapperIndex: 0 methodInvoker: 0
    public void BattleWin(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        // 0x00B903F8: STRB wzr, [x0, #0x650]     | this._isStartMove = false;               //  dest_result_addr=1152921514685430304
        this._isStartMove = false;
        // 0x00B903FC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B90400 (12125184), len: 996  VirtAddr: 0x00B90400 RVA: 0x00B90400 token: 100691631 methodIndex: 25142 delegateWrapperIndex: 0 methodInvoker: 0
    private void MoveCallback(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        UnityEngine.Vector3[] val_8;
        // 0x00B90400: STP x24, x23, [sp, #-0x40]! | stack[1152921514685676208] = ???;  stack[1152921514685676216] = ???;  //  dest_result_addr=1152921514685676208 |  dest_result_addr=1152921514685676216
        // 0x00B90404: STP x22, x21, [sp, #0x10]  | stack[1152921514685676224] = ???;  stack[1152921514685676232] = ???;  //  dest_result_addr=1152921514685676224 |  dest_result_addr=1152921514685676232
        // 0x00B90408: STP x20, x19, [sp, #0x20]  | stack[1152921514685676240] = ???;  stack[1152921514685676248] = ???;  //  dest_result_addr=1152921514685676240 |  dest_result_addr=1152921514685676248
        // 0x00B9040C: STP x29, x30, [sp, #0x30]  | stack[1152921514685676256] = ???;  stack[1152921514685676264] = ???;  //  dest_result_addr=1152921514685676256 |  dest_result_addr=1152921514685676264
        // 0x00B90410: ADD x29, sp, #0x30         | X29 = (1152921514685676208 + 48) = 1152921514685676256 (0x1000000258BEBAE0);
        // 0x00B90414: SUB sp, sp, #0x20          | SP = (1152921514685676208 - 32) = 1152921514685676176 (0x1000000258BEBA90);
        // 0x00B90418: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B9041C: LDRB w8, [x20, #0xa35]     | W8 = (bool)static_value_03733A35;       
        // 0x00B90420: MOV x19, x0                | X19 = 1152921514685688272 (0x1000000258BEE9D0);//ML01
        val_6 = this;
        // 0x00B90424: TBNZ w8, #0, #0xb90440     | if (static_value_03733A35 == true) goto label_0;
        // 0x00B90428: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00B9042C: LDR x8, [x8, #0xb08]       | X8 = 0x2B8F3B4;                         
        // 0x00B90430: LDR w0, [x8]               | W0 = 0x13AF;                            
        // 0x00B90434: BL #0x2782188              | X0 = sub_2782188( ?? 0x13AF, ????);     
        // 0x00B90438: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B9043C: STRB w8, [x20, #0xa35]     | static_value_03733A35 = true;            //  dest_result_addr=57883189
        label_0:
        // 0x00B90440: LDR w8, [x19, #0x65c]      | W8 = this._aimCount; //P2               
        int val_6 = this._aimCount;
        // 0x00B90444: ADRP x22, #0x3630000       | X22 = 56819712 (0x3630000);             
        // 0x00B90448: ADD w8, w8, #1             | W8 = (this._aimCount + 1);              
        val_6 = val_6 + 1;
        // 0x00B9044C: STR w8, [x19, #0x65c]      | this._aimCount = (this._aimCount + 1);   //  dest_result_addr=1152921514685689900
        this._aimCount = val_6;
        // 0x00B90450: LDR x22, [x22, #0x3d0]     | X22 = 1152921504954501264;              
        // 0x00B90454: LDR x20, [x22]             | X20 = typeof(System.Object[]);          
        // 0x00B90458: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9045C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B90460: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B90464: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B90468: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B9046C: ADRP x23, #0x3652000       | X23 = 56958976 (0x3652000);             
        // 0x00B90470: LDR w9, [x19, #0x65c]      | W9 = this._aimCount; //P2               
        // 0x00B90474: LDR x23, [x23, #0x140]     | X23 = 1152921504607113216;              
        // 0x00B90478: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9047C: ADD x1, sp, #8             | X1 = (1152921514685676176 + 8) = 1152921514685676184 (0x1000000258BEBA98);
        // 0x00B90480: STR w9, [sp, #8]           | stack[1152921514685676184] = this._aimCount;  //  dest_result_addr=1152921514685676184
        // 0x00B90484: LDR x8, [x23]              | X8 = typeof(System.Int32);              
        // 0x00B90488: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00B9048C: BL #0x27bc028              | X0 = 1152921514685724368 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this._aimCount);
        // 0x00B90490: MOV x21, x0                | X21 = 1152921514685724368 (0x1000000258BF76D0);//ML01
        // 0x00B90494: CBNZ x20, #0xb9049c        | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x00B90498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._aimCount, ????);
        label_1:
        // 0x00B9049C: CBZ x21, #0xb904c0         | if (this._aimCount == 0) goto label_3;  
        if(this._aimCount == 0)
        {
            goto label_3;
        }
        // 0x00B904A0: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B904A4: MOV x0, x21                | X0 = 1152921514685724368 (0x1000000258BF76D0);//ML01
        // 0x00B904A8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B904AC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this._aimCount, ????);
        // 0x00B904B0: CBNZ x0, #0xb904c0         | if (this._aimCount != 0) goto label_3;  
        if(this._aimCount != 0)
        {
            goto label_3;
        }
        // 0x00B904B4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this._aimCount, ????);
        // 0x00B904B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B904BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this._aimCount, ????);
        label_3:
        // 0x00B904C0: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B904C4: CBNZ w8, #0xb904d4         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_4;
        // 0x00B904C8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this._aimCount, ????);
        // 0x00B904CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B904D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this._aimCount, ????);
        label_4:
        // 0x00B904D4: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = this._aimCount; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = this._aimCount;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00B904D8: LDR x21, [x19, #0x640]     | X21 = this.targetPointArr; //P2         
        // 0x00B904DC: CBNZ x21, #0xb904e4        | if (this.targetPointArr != null) goto label_5;
        if(this.targetPointArr != null)
        {
            goto label_5;
        }
        // 0x00B904E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._aimCount, ????);
        label_5:
        // 0x00B904E4: LDR x8, [x21, #0x18]       | X8 = this.targetPointArr.Length; //P2   
        // 0x00B904E8: LDR x0, [x23]              | X0 = typeof(System.Int32);              
        // 0x00B904EC: ADD x1, sp, #0x1c          | X1 = (1152921514685676176 + 28) = 1152921514685676204 (0x1000000258BEBAAC);
        // 0x00B904F0: STR w8, [sp, #0x1c]        | stack[1152921514685676204] = this.targetPointArr.Length;  //  dest_result_addr=1152921514685676204
        // 0x00B904F4: BL #0x27bc028              | X0 = 1152921514685765328 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.targetPointArr.Length);
        // 0x00B904F8: MOV x21, x0                | X21 = 1152921514685765328 (0x1000000258C016D0);//ML01
        // 0x00B904FC: CBZ x21, #0xb90520         | if (this.targetPointArr.Length == 0) goto label_7;
        if(this.targetPointArr.Length == 0)
        {
            goto label_7;
        }
        // 0x00B90500: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B90504: MOV x0, x21                | X0 = 1152921514685765328 (0x1000000258C016D0);//ML01
        // 0x00B90508: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        val_7 = mem[null + 48];
        // 0x00B9050C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.targetPointArr.Length, ????);
        // 0x00B90510: CBNZ x0, #0xb90520         | if (this.targetPointArr.Length != 0) goto label_7;
        if(this.targetPointArr.Length != 0)
        {
            goto label_7;
        }
        // 0x00B90514: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.targetPointArr.Length, ????);
        // 0x00B90518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_7 = 0;
        // 0x00B9051C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.targetPointArr.Length, ????);
        label_7:
        // 0x00B90520: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B90524: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B90528: B.HI #0xb90538             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_8;
        // 0x00B9052C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.targetPointArr.Length, ????);
        // 0x00B90530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_7 = 0;
        // 0x00B90534: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.targetPointArr.Length, ????);
        label_8:
        // 0x00B90538: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = this.targetPointArr.Length; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
        typeof(System.Object[]).__il2cppRuntimeField_28 = this.targetPointArr.Length;
        typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
        // 0x00B9053C: LDR x8, [x19]              | X8 = typeof(Biaoche);                   
        // 0x00B90540: MOV x0, x19                | X0 = 1152921514685688272 (0x1000000258BEE9D0);//ML01
        // 0x00B90544: LDP x9, x1, [x8, #0x130]   | X9 = public System.Int32 UnityEngine.Object::GetHashCode(); X1 = public System.Int32 UnityEngine.Object::GetHashCode(); //  | 
        // 0x00B90548: BLR x9                     | X0 = this.GetHashCode();                
        int val_1 = this.GetHashCode();
        // 0x00B9054C: LDR x8, [x23]              | X8 = typeof(System.Int32);              
        // 0x00B90550: STR w0, [sp, #0x18]        | stack[1152921514685676200] = val_1;      //  dest_result_addr=1152921514685676200
        // 0x00B90554: ADD x1, sp, #0x18          | X1 = (1152921514685676176 + 24) = 1152921514685676200 (0x1000000258BEBAA8);
        // 0x00B90558: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00B9055C: BL #0x27bc028              | X0 = 1152921514685769424 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_1);
        // 0x00B90560: MOV x21, x0                | X21 = 1152921514685769424 (0x1000000258C026D0);//ML01
        // 0x00B90564: CBZ x21, #0xb90588         | if (val_1 == 0) goto label_10;          
        if(val_1 == 0)
        {
            goto label_10;
        }
        // 0x00B90568: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B9056C: MOV x0, x21                | X0 = 1152921514685769424 (0x1000000258C026D0);//ML01
        // 0x00B90570: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B90574: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_1, ????);      
        // 0x00B90578: CBNZ x0, #0xb90588         | if (val_1 != 0) goto label_10;          
        if(val_1 != 0)
        {
            goto label_10;
        }
        // 0x00B9057C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_1, ????);      
        // 0x00B90580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90584: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_10:
        // 0x00B90588: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B9058C: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B90590: B.HI #0xb905a0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_11;
        // 0x00B90594: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B90598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9059C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_11:
        // 0x00B905A0: STR x21, [x20, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = val_1; typeof(System.Object[]).__il2cppRuntimeField_34 = 0x10000002;  //  dest_result_addr=1152921504954501312 dest_result_addr=1152921504954501316
        typeof(System.Object[]).__il2cppRuntimeField_30 = val_1;
        typeof(System.Object[]).__il2cppRuntimeField_34 = 268435458;
        // 0x00B905A4: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x00B905A8: LDR x8, [x8, #0xc8]        | X8 = (string**)(1152921514685574032)("镖车当前移动到第{0}个点，总共{1}个移动点{2}");
        // 0x00B905AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B905B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B905B4: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B905B8: LDR x1, [x8]               | X1 = "镖车当前移动到第{0}个点，总共{1}个移动点{2}";      
        // 0x00B905BC: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "镖车当前移动到第{0}个点，总共{1}个移动点{2}");
        string val_2 = EString.EFormat(format:  0, args:  "镖车当前移动到第{0}个点，总共{1}个移动点{2}");
        // 0x00B905C0: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B905C4: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B905C8: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B905CC: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B905D0: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B905D4: TBZ w9, #0, #0xb905e8      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B905D8: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B905DC: CBNZ w9, #0xb905e8         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B905E0: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B905E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_13:
        // 0x00B905E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B905EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B905F0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B905F4: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00B905F8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_2);
        EDebug.Log(message:  0, isShowStack:  val_2);
        // 0x00B905FC: LDR w20, [x19, #0x65c]     | W20 = this._aimCount; //P2              
        // 0x00B90600: LDR x21, [x19, #0x640]     | X21 = this.targetPointArr; //P2         
        val_8 = this.targetPointArr;
        // 0x00B90604: CBNZ x21, #0xb9060c        | if (this.targetPointArr != null) goto label_14;
        if(val_8 != null)
        {
            goto label_14;
        }
        // 0x00B90608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_14:
        // 0x00B9060C: LDR w8, [x21, #0x18]       | W8 = this.targetPointArr.Length; //P2   
        // 0x00B90610: CMP w20, w8                | STATE = COMPARE(this._aimCount, this.targetPointArr.Length)
        // 0x00B90614: B.GE #0xb90704             | if (this._aimCount >= this.targetPointArr.Length) goto label_15;
        if(this._aimCount >= this.targetPointArr.Length)
        {
            goto label_15;
        }
        // 0x00B90618: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9061C: MOV x0, x19                | X0 = 1152921514685688272 (0x1000000258BEE9D0);//ML01
        // 0x00B90620: BL #0xd7dd80               | X0 = this.get_bvrCtrl();                
        Entity.Behavior.IBehaviorCtrl val_3 = this.bvrCtrl;
        // 0x00B90624: LDR x21, [x22]             | X21 = typeof(System.Object[]);          
        // 0x00B90628: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B9062C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B90630: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B90634: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B90638: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9063C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B90640: LDR x21, [x19, #0x640]     | X21 = this.targetPointArr; //P2         
        // 0x00B90644: LDRSW x22, [x19, #0x65c]   | X22 = this._aimCount; //P2              
        // 0x00B90648: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_6 = null;
        // 0x00B9064C: CBNZ x21, #0xb90654        | if (this.targetPointArr != null) goto label_16;
        if(this.targetPointArr != null)
        {
            goto label_16;
        }
        // 0x00B90650: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_16:
        // 0x00B90654: LDR w8, [x21, #0x18]       | W8 = this.targetPointArr.Length; //P2   
        // 0x00B90658: CMP w22, w8                | STATE = COMPARE(this._aimCount, this.targetPointArr.Length)
        // 0x00B9065C: B.LO #0xb9066c             | if (this._aimCount < this.targetPointArr.Length) goto label_17;
        if(this._aimCount < this.targetPointArr.Length)
        {
            goto label_17;
        }
        // 0x00B90660: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Object[]), ????);
        // 0x00B90664: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90668: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Object[]), ????);
        label_17:
        // 0x00B9066C: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_7 = 12;
        // 0x00B90670: MADD x8, x22, x8, x21      | X8 = (this._aimCount * 12) + this.targetPointArr;
        val_7 = this.targetPointArr + (this._aimCount * val_7);
        // 0x00B90674: LDR w9, [x8, #0x28]        | W9 = (this._aimCount * 12) + this.targetPointArr + 40;
        // 0x00B90678: ADD x1, sp, #8             | X1 = (1152921514685676176 + 8) = 1152921514685676184 (0x1000000258BEBA98);
        // 0x00B9067C: STR w9, [sp, #0x10]        | stack[1152921514685676192] = (this._aimCount * 12) + this.targetPointArr + 40;  //  dest_result_addr=1152921514685676192
        // 0x00B90680: ADRP x9, #0x3673000        | X9 = 57094144 (0x3673000);              
        // 0x00B90684: LDR x8, [x8, #0x20]        | X8 = (this._aimCount * 12) + this.targetPointArr + 32;
        // 0x00B90688: LDR x9, [x9, #0x488]       | X9 = 1152921504695078912;               
        // 0x00B9068C: STR x8, [sp, #8]           | stack[1152921514685676184] = (this._aimCount * 12) + this.targetPointArr + 32;  //  dest_result_addr=1152921514685676184
        // 0x00B90690: LDR x0, [x9]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B90694: BL #0x27bc028              | X0 = 1152921514685855440 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), (this._aimCount * 12) + this.targetPointArr + 32);
        // 0x00B90698: MOV x21, x0                | X21 = 1152921514685855440 (0x1000000258C176D0);//ML01
        val_8 = (this._aimCount * 12) + this.targetPointArr + 32;
        // 0x00B9069C: CBNZ x19, #0xb906a4        | if ( != null) goto label_18;            
        if(null != null)
        {
            goto label_18;
        }
        // 0x00B906A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        label_18:
        // 0x00B906A4: CBZ x21, #0xb906c8         | if ((this._aimCount * 12) + this.targetPointArr + 32 == 0) goto label_20;
        if(((this._aimCount * 12) + this.targetPointArr + 32) == 0)
        {
            goto label_20;
        }
        // 0x00B906A8: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B906AC: MOV x0, x21                | X0 = 1152921514685855440 (0x1000000258C176D0);//ML01
        // 0x00B906B0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B906B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        // 0x00B906B8: CBNZ x0, #0xb906c8         | if ((this._aimCount * 12) + this.targetPointArr + 32 != 0) goto label_20;
        if(((this._aimCount * 12) + this.targetPointArr + 32) != 0)
        {
            goto label_20;
        }
        // 0x00B906BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        // 0x00B906C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B906C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        label_20:
        // 0x00B906C8: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B906CC: CBNZ w8, #0xb906dc         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_21;
        // 0x00B906D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        // 0x00B906D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B906D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        label_21:
        // 0x00B906DC: STR x21, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = (this._aimCount * 12) + this.targetPointArr + 32;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_8;
        // 0x00B906E0: CBNZ x20, #0xb906e8        | if (val_3 != null) goto label_22;       
        if(val_3 != null)
        {
            goto label_22;
        }
        // 0x00B906E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (this._aimCount * 12) + this.targetPointArr + 32, ????);
        label_22:
        // 0x00B906E8: LDR x8, [x20]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
        // 0x00B906EC: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B906F0: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B906F4: MOV x2, x19                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B906F8: LDP x9, x3, [x8, #0x180]   | X9 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
        // 0x00B906FC: BLR x9                     | X0 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180();
        // 0x00B90700: B #0xb907cc                |  goto label_25;                         
        goto label_25;
        label_15:
        // 0x00B90704: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00B90708: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00B9070C: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00B90710: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B90714: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B90718: CBNZ x20, #0xb90720        | if (GameMgr.UPDATEOnOffEffect != null) goto label_24;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_24;
        }
        // 0x00B9071C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_24:
        // 0x00B90720: LDR w8, [x20, #0x60]       | W8 = GameMgr.UPDATEOnOffEffect + 96;     //  not_find_field!2:96
        // 0x00B90724: CMP w8, #5                 | STATE = COMPARE(GameMgr.UPDATEOnOffEffect + 96, 0x5)
        // 0x00B90728: B.NE #0xb907cc             | if (GameMgr.UPDATEOnOffEffect + 96 != 0x5) goto label_25;
        if((GameMgr.UPDATEOnOffEffect + 96) != 5)
        {
            goto label_25;
        }
        // 0x00B9072C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90730: MOV x0, x19                | X0 = 1152921514685688272 (0x1000000258BEE9D0);//ML01
        // 0x00B90734: BL #0xd7dd80               | X0 = this.get_bvrCtrl();                
        Entity.Behavior.IBehaviorCtrl val_4 = this.bvrCtrl;
        // 0x00B90738: MOV x19, x0                | X19 = val_4;//m1                        
        // 0x00B9073C: CBNZ x19, #0xb90744        | if (val_4 != null) goto label_26;       
        if(val_4 != null)
        {
            goto label_26;
        }
        // 0x00B90740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_26:
        // 0x00B90744: LDR x20, [x22]             | X20 = typeof(System.Object[]);          
        // 0x00B90748: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9074C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B90750: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90754: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B90758: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B9075C: LDR x8, [x19]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
        // 0x00B90760: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B90764: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B90768: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x00B9076C: LDP x9, x3, [x8, #0x180]   | X9 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
        // 0x00B90770: BLR x9                     | X0 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180();
        // 0x00B90774: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B90778: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00B9077C: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
        CEvent.ZEvent val_5 = null;
        // 0x00B90780: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00B90784: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B90788: LDR x8, [x8, #0x750]       | X8 = (string**)(1152921510361991200)("COMBAT_WIN");
        // 0x00B9078C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90790: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        val_6 = val_5;
        // 0x00B90794: LDR x1, [x8]               | X1 = "COMBAT_WIN";                      
        // 0x00B90798: BL #0xd80ce8               | .ctor(name:  "COMBAT_WIN");             
        val_5 = new CEvent.ZEvent(name:  "COMBAT_WIN");
        // 0x00B9079C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B907A0: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B907A4: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B907A8: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B907AC: TBZ w8, #0, #0xb907bc      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_28;
        // 0x00B907B0: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B907B4: CBNZ w8, #0xb907bc         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
        // 0x00B907B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_28:
        // 0x00B907BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B907C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B907C4: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B907C8: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        label_25:
        // 0x00B907CC: SUB sp, x29, #0x30         | SP = (1152921514685676256 - 48) = 1152921514685676208 (0x1000000258BEBAB0);
        // 0x00B907D0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B907D4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B907D8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B907DC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B907E0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B907E4 (12126180), len: 340  VirtAddr: 0x00B907E4 RVA: 0x00B907E4 token: 100691632 methodIndex: 25143 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Clear()
    {
        //
        // Disasemble & Code
        // 0x00B907E4: STP x24, x23, [sp, #-0x40]! | stack[1152921514685931568] = ???;  stack[1152921514685931576] = ???;  //  dest_result_addr=1152921514685931568 |  dest_result_addr=1152921514685931576
        // 0x00B907E8: STP x22, x21, [sp, #0x10]  | stack[1152921514685931584] = ???;  stack[1152921514685931592] = ???;  //  dest_result_addr=1152921514685931584 |  dest_result_addr=1152921514685931592
        // 0x00B907EC: STP x20, x19, [sp, #0x20]  | stack[1152921514685931600] = ???;  stack[1152921514685931608] = ???;  //  dest_result_addr=1152921514685931600 |  dest_result_addr=1152921514685931608
        // 0x00B907F0: STP x29, x30, [sp, #0x30]  | stack[1152921514685931616] = ???;  stack[1152921514685931624] = ???;  //  dest_result_addr=1152921514685931616 |  dest_result_addr=1152921514685931624
        // 0x00B907F4: ADD x29, sp, #0x30         | X29 = (1152921514685931568 + 48) = 1152921514685931616 (0x1000000258C2A060);
        // 0x00B907F8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B907FC: LDRB w8, [x20, #0xa36]     | W8 = (bool)static_value_03733A36;       
        // 0x00B90800: MOV x19, x0                | X19 = 1152921514685943632 (0x1000000258C2CF50);//ML01
        // 0x00B90804: TBNZ w8, #0, #0xb90820     | if (static_value_03733A36 == true) goto label_0;
        // 0x00B90808: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B9080C: LDR x8, [x8, #0x628]       | X8 = 0x2B8F3A8;                         
        // 0x00B90810: LDR w0, [x8]               | W0 = 0x13AC;                            
        // 0x00B90814: BL #0x2782188              | X0 = sub_2782188( ?? 0x13AC, ????);     
        // 0x00B90818: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B9081C: STRB w8, [x20, #0xa36]     | static_value_03733A36 = true;            //  dest_result_addr=57883190
        label_0:
        // 0x00B90820: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90824: MOV x0, x19                | X0 = 1152921514685943632 (0x1000000258C2CF50);//ML01
        // 0x00B90828: BL #0xd95130               | this.Clear();                           
        this.Clear();
        // 0x00B9082C: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00B90830: ADRP x22, #0x3658000       | X22 = 56983552 (0x3658000);             
        // 0x00B90834: LDR x8, [x8, #0x9a0]       | X8 = 1152921514683952784;               
        // 0x00B90838: LDR x22, [x22, #0x980]     | X22 = 1152921504898113536;              
        // 0x00B9083C: LDR x21, [x8]              | X21 = System.Void Biaoche::MoveCallback(CEvent.ZEvent ev);
        // 0x00B90840: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_1 = null;
        // 0x00B90844: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B90848: ADRP x23, #0x367a000       | X23 = 57122816 (0x367A000);             
        // 0x00B9084C: LDR x23, [x23, #0xc38]     | X23 = 1152921512949758048;              
        // 0x00B90850: MOV x1, x19                | X1 = 1152921514685943632 (0x1000000258C2CF50);//ML01
        // 0x00B90854: MOV x2, x21                | X2 = 1152921514683952784 (0x1000000258A46E90);//ML01
        // 0x00B90858: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B9085C: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B90860: BL #0x19cc774              | .ctor(object:  this, method:  System.Void Biaoche::MoveCallback(CEvent.ZEvent ev));
        val_1 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void Biaoche::MoveCallback(CEvent.ZEvent ev));
        // 0x00B90864: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B90868: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B9086C: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B90870: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B90874: TBZ w8, #0, #0xb90884      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B90878: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B9087C: CBNZ w8, #0xb90884         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B90880: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00B90884: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00B90888: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921510058805600)("MOVE_TO_END");
        // 0x00B9088C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B90890: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B90894: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B90898: LDR x1, [x8]               | X1 = "MOVE_TO_END";                     
        // 0x00B9089C: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "MOVE_TO_END");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "MOVE_TO_END");
        // 0x00B908A0: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00B908A4: LDR x8, [x8, #0xcc8]       | X8 = 1152921514683953808;               
        // 0x00B908A8: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_2 = null;
        // 0x00B908AC: LDR x20, [x8]              | X20 = public System.Void Biaoche::BattleWin(CEvent.ZEvent ev);
        // 0x00B908B0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B908B4: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B908B8: MOV x1, x19                | X1 = 1152921514685943632 (0x1000000258C2CF50);//ML01
        // 0x00B908BC: MOV x2, x20                | X2 = 1152921514683953808 (0x1000000258A47290);//ML01
        // 0x00B908C0: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B908C4: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void Biaoche::BattleWin(CEvent.ZEvent ev));
        val_2 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void Biaoche::BattleWin(CEvent.ZEvent ev));
        // 0x00B908C8: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00B908CC: LDR x8, [x8, #0x550]       | X8 = (string**)(1152921510361990080)("BATTLE_ENDED");
        // 0x00B908D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B908D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B908D8: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B908DC: LDR x1, [x8]               | X1 = "BATTLE_ENDED";                    
        // 0x00B908E0: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "BATTLE_ENDED");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "BATTLE_ENDED");
        // 0x00B908E4: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00B908E8: LDR x8, [x8, #0x1f8]       | X8 = 1152921514683954832;               
        // 0x00B908EC: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_3 = null;
        // 0x00B908F0: LDR x20, [x8]              | X20 = public System.Void Biaoche::BattleStart(CEvent.ZEvent ev);
        // 0x00B908F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B908F8: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B908FC: MOV x1, x19                | X1 = 1152921514685943632 (0x1000000258C2CF50);//ML01
        // 0x00B90900: MOV x2, x20                | X2 = 1152921514683954832 (0x1000000258A47690);//ML01
        // 0x00B90904: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B90908: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void Biaoche::BattleStart(CEvent.ZEvent ev));
        val_3 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void Biaoche::BattleStart(CEvent.ZEvent ev));
        // 0x00B9090C: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B90910: LDR x8, [x8, #0x9c0]       | X8 = (string**)(1152921510361988960)("BATTLE_START");
        // 0x00B90914: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B90918: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9091C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B90920: LDR x1, [x8]               | X1 = "BATTLE_START";                    
        // 0x00B90924: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B90928: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B9092C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B90930: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B90934: B #0xd77798                | CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "BATTLE_START"); return;
        CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "BATTLE_START");
        return;
    
    }

}
