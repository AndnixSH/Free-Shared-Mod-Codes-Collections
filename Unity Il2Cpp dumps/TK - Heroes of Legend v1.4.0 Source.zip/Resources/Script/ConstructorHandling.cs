using UnityEngine;

namespace Newtonsoft.Json
{
    public enum ConstructorHandling
    {
        // Fields
        Default = 0
        ,AllowNonPublicDefaultConstructor = 1
        
    
    }

}
