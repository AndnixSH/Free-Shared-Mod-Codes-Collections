using UnityEngine;

namespace Pathfinding.Ionic.Zip
{
    [System.Runtime.InteropServices.GuidAttribute] // 0x2814054
    public class BadCrcException : ZipException
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x0197034C (26673996), len: 8  VirtAddr: 0x0197034C RVA: 0x0197034C token: 100663346 methodIndex: 20853 delegateWrapperIndex: 0 methodInvoker: 0
        public BadCrcException(string message)
        {
            //
            // Disasemble & Code
            // 0x0197034C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01970350: B #0x1c32b48               | this..ctor(message:  message); return;  
            val_1 = new System.Exception(message:  message);
            return;
        
        }
    
    }

}
