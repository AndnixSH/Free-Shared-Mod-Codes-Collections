using UnityEngine;
public sealed class EventDelegate.Callback : MulticastDelegate
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x00EC0688 (15468168), len: 16  VirtAddr: 0x00EC0688 RVA: 0x00EC0688 token: 100687945 methodIndex: 27473 delegateWrapperIndex: 0 methodInvoker: 0
    public EventDelegate.Callback(object object, IntPtr method)
    {
        //
        // Disasemble & Code
        // 0x00EC0688: LDR x8, [x2]               | X8 = method;                            
        // 0x00EC068C: STP x1, x2, [x0, #0x20]    | mem[1152921514168838256] = object;  mem[1152921514168838264] = method;  //  dest_result_addr=1152921514168838256 |  dest_result_addr=1152921514168838264
        mem[1152921514168838256] = object;
        mem[1152921514168838264] = method;
        // 0x00EC0690: STR x8, [x0, #0x10]        | mem[1152921514168838240] = method;       //  dest_result_addr=1152921514168838240
        mem[1152921514168838240] = method;
        // 0x00EC0694: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00EBF49C (15463580), len: 504  VirtAddr: 0x00EBF49C RVA: 0x00EBF49C token: 100687946 methodIndex: 27474 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void Invoke()
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        label_1:
        // 0x00EBF49C: STP x22, x21, [sp, #-0x30]! | stack[1152921514168950464] = ???;  stack[1152921514168950472] = ???;  //  dest_result_addr=1152921514168950464 |  dest_result_addr=1152921514168950472
        // 0x00EBF4A0: STP x20, x19, [sp, #0x10]  | stack[1152921514168950480] = ???;  stack[1152921514168950488] = ???;  //  dest_result_addr=1152921514168950480 |  dest_result_addr=1152921514168950488
        // 0x00EBF4A4: STP x29, x30, [sp, #0x20]  | stack[1152921514168950496] = ???;  stack[1152921514168950504] = ???;  //  dest_result_addr=1152921514168950496 |  dest_result_addr=1152921514168950504
        // 0x00EBF4A8: ADD x29, sp, #0x20         | X29 = (1152921514168950464 + 32) = 1152921514168950496 (0x1000000239F21EE0);
        // 0x00EBF4AC: SUB sp, sp, #0x10          | SP = (1152921514168950464 - 16) = 1152921514168950448 (0x1000000239F21EB0);
        // 0x00EBF4B0: MOV x21, x0                | X21 = 1152921514168962512 (0x1000000239F24DD0);//ML01
        // 0x00EBF4B4: LDR x0, [x21, #0x58]       | 
        // 0x00EBF4B8: CBZ x0, #0xebf4c0          | if (this == null) goto label_0;         
        if(this == null)
        {
            goto label_0;
        }
        // 0x00EBF4BC: BL #0xebf49c               |  R0 = label_1();                        
        label_0:
        // 0x00EBF4C0: LDR x0, [x21, #0x10]       | 
        // 0x00EBF4C4: STR x0, [sp, #8]           | stack[1152921514168950456] = this;       //  dest_result_addr=1152921514168950456
        // 0x00EBF4C8: LDP x19, x20, [x21, #0x20] |                                          //  | 
        // 0x00EBF4CC: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00EBF4D0: BL #0x2796f94              | X0 = sub_2796F94( ?? X20, ????);        
        // 0x00EBF4D4: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00EBF4D8: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X20, ????);        
        // 0x00EBF4DC: AND w8, w0, #1             | W8 = (X20 & 1);                         
        var val_1 = X20 & 1;
        // 0x00EBF4E0: TBZ w8, #0, #0xebf570      | if (((X20 & 1) & 0x1) == 0) goto label_2;
        if((val_1 & 1) == 0)
        {
            goto label_2;
        }
        // 0x00EBF4E4: LDRSH w8, [x20, #0x4c]     | W8 = X20 + 76;                          
        // 0x00EBF4E8: CMN w8, #1                 | STATE = COMPARE(X20 + 76, 0x1)          
        // 0x00EBF4EC: B.EQ #0xebf59c             | if (X20 + 76 == 0x1) goto label_6;      
        if((X20 + 76) == 1)
        {
            goto label_6;
        }
        // 0x00EBF4F0: CBZ x19, #0xebf500         | if (X19 == 0) goto label_4;             
        if(X19 == 0)
        {
            goto label_4;
        }
        // 0x00EBF4F4: LDR x8, [x19]              | X8 = X19;                               
        // 0x00EBF4F8: LDRB w8, [x8, #0xed]       | W8 = X19 + 237;                         
        // 0x00EBF4FC: TBNZ w8, #0, #0xebf59c     | if ((X19 + 237 & 0x1) != 0) goto label_6;
        if(((X19 + 237) & 1) != 0)
        {
            goto label_6;
        }
        label_4:
        // 0x00EBF500: LDR x8, [x21, #0x18]       | 
        // 0x00EBF504: CBZ x8, #0xebf59c          | if (X19 + 237 == 0) goto label_6;       
        if((X19 + 237) == 0)
        {
            goto label_6;
        }
        // 0x00EBF508: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00EBF50C: BL #0x27c0990              | X0 = sub_27C0990( ?? X20, ????);        
        // 0x00EBF510: MOV w21, w0                | W21 = X20;//m1                          
        // 0x00EBF514: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00EBF518: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
        UnityEngine.Sprite val_2 = X20.pressedSprite;
        // 0x00EBF51C: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
        // 0x00EBF520: TBZ w21, #0, #0xebf5c4     | if ((X20 & 0x1) == 0) goto label_7;     
        if((X20 & 1) == 0)
        {
            goto label_7;
        }
        // 0x00EBF524: TBZ w0, #0, #0xebf620      | if ((val_2 & 0x1) == 0) goto label_8;   
        if((val_2 & 1) == 0)
        {
            goto label_8;
        }
        // 0x00EBF528: LDR x8, [x19]              | X8 = X19;                               
        var val_11 = X19;
        // 0x00EBF52C: LDR x1, [x20, #0x18]       | X1 = X20 + 24;                          
        // 0x00EBF530: LDRH w2, [x20, #0x4c]      | W2 = X20 + 76;                          
        // 0x00EBF534: LDRH w9, [x8, #0x102]      | W9 = X19 + 258;                         
        // 0x00EBF538: CBZ x9, #0xebf564          | if (X19 + 258 == 0) goto label_9;       
        if((X19 + 258) == 0)
        {
            goto label_9;
        }
        // 0x00EBF53C: LDR x10, [x8, #0x98]       | X10 = X19 + 152;                        
        var val_5 = X19 + 152;
        // 0x00EBF540: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_6 = 0;
        // 0x00EBF544: ADD x10, x10, #8           | X10 = (X19 + 152 + 8);                  
        val_5 = val_5 + 8;
        label_11:
        // 0x00EBF548: LDUR x12, [x10, #-8]       | X12 = (X19 + 152 + 8) + -8;             
        // 0x00EBF54C: CMP x12, x1                | STATE = COMPARE((X19 + 152 + 8) + -8, X20 + 24)
        // 0x00EBF550: B.EQ #0xebf648             | if ((X19 + 152 + 8) + -8 == X20 + 24) goto label_10;
        if(((X19 + 152 + 8) + -8) == (X20 + 24))
        {
            goto label_10;
        }
        // 0x00EBF554: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_6 = val_6 + 1;
        // 0x00EBF558: ADD x10, x10, #0x10        | X10 = ((X19 + 152 + 8) + 16);           
        val_5 = val_5 + 16;
        // 0x00EBF55C: CMP x11, x9                | STATE = COMPARE((0 + 1), X19 + 258)     
        // 0x00EBF560: B.LO #0xebf548             | if (0 < X19 + 258) goto label_11;       
        if(val_6 < (X19 + 258))
        {
            goto label_11;
        }
        label_9:
        // 0x00EBF564: MOV x0, x19                | X0 = X19;//m1                           
        val_7 = X19;
        // 0x00EBF568: BL #0x2776c24              | X0 = sub_2776C24( ?? X19, ????);        
        // 0x00EBF56C: B #0xebf658                |  goto label_12;                         
        goto label_12;
        label_2:
        // 0x00EBF570: LDRB w8, [x20, #0x4e]      | W8 = X20 + 78;                          
        // 0x00EBF574: CBZ w8, #0xebf5a4          | if (X20 + 78 == 0) goto label_13;       
        if((X20 + 78) == 0)
        {
            goto label_13;
        }
        // 0x00EBF578: LDR x3, [sp, #8]           | X3 = this;                              
        // 0x00EBF57C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00EBF580: MOV x1, x19                | X1 = X19;//m1                           
        // 0x00EBF584: MOV x2, x20                | X2 = X20;//m1                           
        // 0x00EBF588: SUB sp, x29, #0x20         | SP = (1152921514168950496 - 32) = 1152921514168950464 (0x1000000239F21EC0);
        // 0x00EBF58C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00EBF590: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00EBF594: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00EBF598: BR x3                      | X0 = this( ?? 0x0, ????);               
        label_6:
        // 0x00EBF59C: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00EBF5A0: B #0xebf5a8                |  goto label_14;                         
        goto label_14;
        label_13:
        // 0x00EBF5A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        label_14:
        // 0x00EBF5A8: LDR x2, [sp, #8]           | X2 = this;                              
        // 0x00EBF5AC: MOV x1, x20                | X1 = X20;//m1                           
        label_23:
        // 0x00EBF5B0: SUB sp, x29, #0x20         | SP = (1152921514168950496 - 32) = 1152921514168950464 (0x1000000239F21EC0);
        // 0x00EBF5B4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00EBF5B8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00EBF5BC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00EBF5C0: BR x2                      | X0 = this( ?? 0x0, ????);               
        label_7:
        // 0x00EBF5C4: LDRH w21, [x20, #0x4c]     | W21 = X20 + 76;                         
        // 0x00EBF5C8: TBZ w0, #0, #0xebf634      | if ((val_2 & 0x1) == 0) goto label_15;  
        if((val_2 & 1) == 0)
        {
            goto label_15;
        }
        // 0x00EBF5CC: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00EBF5D0: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
        UnityEngine.Sprite val_3 = X20.pressedSprite;
        // 0x00EBF5D4: LDR x9, [x19]              | X9 = X19;                               
        // 0x00EBF5D8: MOV x8, x0                 | X8 = val_3;//m1                         
        // 0x00EBF5DC: LDRH w10, [x9, #0x102]     | W10 = X19 + 258;                        
        // 0x00EBF5E0: CBZ x10, #0xebf60c         | if (X19 + 258 == 0) goto label_16;      
        if((X19 + 258) == 0)
        {
            goto label_16;
        }
        // 0x00EBF5E4: LDR x11, [x9, #0x98]       | X11 = X19 + 152;                        
        var val_7 = X19 + 152;
        // 0x00EBF5E8: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
        var val_8 = 0;
        // 0x00EBF5EC: ADD x11, x11, #8           | X11 = (X19 + 152 + 8);                  
        val_7 = val_7 + 8;
        label_18:
        // 0x00EBF5F0: LDUR x13, [x11, #-8]       | X13 = (X19 + 152 + 8) + -8;             
        // 0x00EBF5F4: CMP x13, x8                | STATE = COMPARE((X19 + 152 + 8) + -8, val_3)
        // 0x00EBF5F8: B.EQ #0xebf678             | if ((X19 + 152 + 8) + -8 == val_3) goto label_17;
        if(((X19 + 152 + 8) + -8) == val_3)
        {
            goto label_17;
        }
        // 0x00EBF5FC: ADD x12, x12, #1           | X12 = (0 + 1);                          
        val_8 = val_8 + 1;
        // 0x00EBF600: ADD x11, x11, #0x10        | X11 = ((X19 + 152 + 8) + 16);           
        val_7 = val_7 + 16;
        // 0x00EBF604: CMP x12, x10               | STATE = COMPARE((0 + 1), X19 + 258)     
        // 0x00EBF608: B.LO #0xebf5f0             | if (0 < X19 + 258) goto label_18;       
        if(val_8 < (X19 + 258))
        {
            goto label_18;
        }
        label_16:
        // 0x00EBF60C: MOV x0, x19                | X0 = X19;//m1                           
        val_8 = X19;
        // 0x00EBF610: MOV x1, x8                 | X1 = val_3;//m1                         
        // 0x00EBF614: MOV w2, w21                | W2 = X20 + 76;//m1                      
        // 0x00EBF618: BL #0x2776c24              | X0 = sub_2776C24( ?? X19, ????);        
        // 0x00EBF61C: B #0xebf688                |  goto label_19;                         
        goto label_19;
        label_8:
        // 0x00EBF620: LDRH w8, [x20, #0x4c]      | W8 = X20 + 76;                          
        // 0x00EBF624: LDR x9, [x19]              | X9 = X19;                               
        // 0x00EBF628: ADD x8, x9, x8, lsl #4     | X8 = (X19 + (X20 + 76) << 4);           
        var val_4 = X19 + ((X20 + 76) << 4);
        // 0x00EBF62C: LDR x0, [x8, #0x118]       | X0 = (X19 + (X20 + 76) << 4) + 280;     
        val_9 = mem[(X19 + (X20 + 76) << 4) + 280];
        val_9 = (X19 + (X20 + 76) << 4) + 280;
        // 0x00EBF630: B #0xebf65c                |  goto label_20;                         
        goto label_20;
        label_15:
        // 0x00EBF634: LDR x8, [x19]              | X8 = X19;                               
        var val_9 = X19;
        // 0x00EBF638: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00EBF63C: ADD x8, x8, w21, uxtw #4   | X8 = (X19 + X20 + 76);                  
        val_9 = val_9 + (X20 + 76);
        // 0x00EBF640: LDP x2, x1, [x8, #0x110]   | X2 = (X19 + X20 + 76) + 272; X1 = (X19 + X20 + 76) + 272 + 8; //  | 
        // 0x00EBF644: B #0xebf5b0                |  goto label_23;                         
        goto label_23;
        label_10:
        // 0x00EBF648: LDR w9, [x10]              | W9 = (X19 + 152 + 8);                   
        var val_10 = val_5;
        // 0x00EBF64C: ADD w9, w9, w2             | W9 = ((X19 + 152 + 8) + X20 + 76);      
        val_10 = val_10 + (X20 + 76);
        // 0x00EBF650: ADD x8, x8, w9, uxtw #4    | X8 = (X19 + ((X19 + 152 + 8) + X20 + 76));
        val_11 = val_11 + val_10;
        // 0x00EBF654: ADD x0, x8, #0x110         | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272);
        val_7 = val_11 + 272;
        label_12:
        // 0x00EBF658: LDR x0, [x0, #8]           | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
        val_9 = mem[((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8];
        val_9 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
        label_20:
        // 0x00EBF65C: MOV x1, x20                | X1 = X20;//m1                           
        // 0x00EBF660: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8, ????);
        // 0x00EBF664: MOV x8, x0                 | X8 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
        // 0x00EBF668: LDR x2, [x8]               | X2 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
        // 0x00EBF66C: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00EBF670: MOV x1, x8                 | X1 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
        // 0x00EBF674: B #0xebf5b0                |  goto label_23;                         
        goto label_23;
        label_17:
        // 0x00EBF678: LDR w8, [x11]              | W8 = (X19 + 152 + 8);                   
        var val_12 = val_7;
        // 0x00EBF67C: ADD w8, w8, w21            | W8 = ((X19 + 152 + 8) + X20 + 76);      
        val_12 = val_12 + (X20 + 76);
        // 0x00EBF680: ADD x8, x9, w8, uxtw #4    | X8 = (X19 + ((X19 + 152 + 8) + X20 + 76));
        val_12 = X19 + val_12;
        // 0x00EBF684: ADD x0, x8, #0x110         | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272);
        val_8 = val_12 + 272;
        label_19:
        // 0x00EBF688: LDP x2, x1, [x0]           | X2 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272); X1 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8; //  | 
        // 0x00EBF68C: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00EBF690: B #0xebf5b0                |  goto label_23;                         
        goto label_23;
    
    }
    //
    // Offset in libil2cpp.so: 0x00EC0698 (15468184), len: 52  VirtAddr: 0x00EC0698 RVA: 0x00EC0698 token: 100687947 methodIndex: 27475 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual System.IAsyncResult BeginInvoke(System.AsyncCallback callback, object object)
    {
        //
        // Disasemble & Code
        // 0x00EC0698: STP x29, x30, [sp, #-0x10]! | stack[1152921514169078880] = ???;  stack[1152921514169078888] = ???;  //  dest_result_addr=1152921514169078880 |  dest_result_addr=1152921514169078888
        // 0x00EC069C: MOV x29, sp                | X29 = 1152921514169078880 (0x1000000239F41460);//ML01
        // 0x00EC06A0: SUB sp, sp, #0x10          | SP = (1152921514169078880 - 16) = 1152921514169078864 (0x1000000239F41450);
        // 0x00EC06A4: MOV x8, x2                 | X8 = object;//m1                        
        // 0x00EC06A8: MOV x9, x1                 | X9 = callback;//m1                      
        // 0x00EC06AC: ADD x1, sp, #8             | X1 = (1152921514169078864 + 8) = 1152921514169078872 (0x1000000239F41458);
        // 0x00EC06B0: MOV x2, x9                 | X2 = callback;//m1                      
        // 0x00EC06B4: MOV x3, x8                 | X3 = object;//m1                        
        // 0x00EC06B8: STR xzr, [sp, #8]          | stack[1152921514169078872] = 0x0;        //  dest_result_addr=1152921514169078872
        // 0x00EC06BC: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
        // 0x00EC06C0: MOV sp, x29                | SP = 1152921514169078880 (0x1000000239F41460);//ML01
        // 0x00EC06C4: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00EC06C8: RET                        |  return (System.IAsyncResult)this;      
        return (System.IAsyncResult)this;
        //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00EC06CC (15468236), len: 16  VirtAddr: 0x00EC06CC RVA: 0x00EC06CC token: 100687948 methodIndex: 27476 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void EndInvoke(System.IAsyncResult result)
    {
        //
        // Disasemble & Code
        // 0x00EC06CC: MOV x8, x1                 | X8 = result;//m1                        
        // 0x00EC06D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00EC06D4: MOV x0, x8                 | X0 = result;//m1                        
        // 0x00EC06D8: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
    
    }

}
