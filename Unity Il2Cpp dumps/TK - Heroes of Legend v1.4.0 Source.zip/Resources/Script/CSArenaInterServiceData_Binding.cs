using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CSArenaInterServiceData_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache4; // static_offset: 0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01C04EB8 (29380280), len: 8  VirtAddr: 0x01C04EB8 RVA: 0x01C04EB8 token: 100665116 methodIndex: 31165 delegateWrapperIndex: 0 methodInvoker: 0
        public CSArenaInterServiceData_Binding()
        {
            //
            // Disasemble & Code
            // 0x01C04EB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04EBC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C04EC0 (29380288), len: 1008  VirtAddr: 0x01C04EC0 RVA: 0x01C04EC0 token: 100665117 methodIndex: 31166 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_9;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_10;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_11;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_12;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_13;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_14;
            // 0x01C04EC0: STP x24, x23, [sp, #-0x40]! | stack[1152921510261116288] = ???;  stack[1152921510261116296] = ???;  //  dest_result_addr=1152921510261116288 |  dest_result_addr=1152921510261116296
            // 0x01C04EC4: STP x22, x21, [sp, #0x10]  | stack[1152921510261116304] = ???;  stack[1152921510261116312] = ???;  //  dest_result_addr=1152921510261116304 |  dest_result_addr=1152921510261116312
            // 0x01C04EC8: STP x20, x19, [sp, #0x20]  | stack[1152921510261116320] = ???;  stack[1152921510261116328] = ???;  //  dest_result_addr=1152921510261116320 |  dest_result_addr=1152921510261116328
            // 0x01C04ECC: STP x29, x30, [sp, #0x30]  | stack[1152921510261116336] = ???;  stack[1152921510261116344] = ???;  //  dest_result_addr=1152921510261116336 |  dest_result_addr=1152921510261116344
            // 0x01C04ED0: ADD x29, sp, #0x30         | X29 = (1152921510261116288 + 48) = 1152921510261116336 (0x1000000151054DB0);
            // 0x01C04ED4: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C04ED8: LDRB w8, [x20, #0x277]     | W8 = (bool)static_value_0373C277;       
            // 0x01C04EDC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C04EE0: TBNZ w8, #0, #0x1c04efc    | if (static_value_0373C277 == true) goto label_0;
            // 0x01C04EE4: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x01C04EE8: LDR x8, [x8, #0xf90]       | X8 = 0x2B92F74;                         
            // 0x01C04EEC: LDR w0, [x8]               | W0 = 0x22A2;                            
            // 0x01C04EF0: BL #0x2782188              | X0 = sub_2782188( ?? 0x22A2, ????);     
            // 0x01C04EF4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C04EF8: STRB w8, [x20, #0x277]     | static_value_0373C277 = true;            //  dest_result_addr=57918071
            label_0:
            // 0x01C04EFC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C04F00: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C04F04: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x01C04F08: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x01C04F0C: LDR x8, [x8, #0xe18]       | X8 = 1152921504904450048;               
            // 0x01C04F10: LDR x20, [x8]              | X20 = typeof(CSArenaInterServiceData);  
            // 0x01C04F14: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C04F18: TBZ w8, #0, #0x1c04f28     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01C04F1C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C04F20: CBNZ w8, #0x1c04f28        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01C04F24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01C04F28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C04F2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C04F30: MOV x1, x20                | X1 = 1152921504904450048 (0x1000000011BD1000);//ML01
            // 0x01C04F34: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C04F38: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x01C04F3C: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x01C04F40: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01C04F44: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x01C04F48: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01C04F4C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01C04F50: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01C04F54: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01C04F58: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01C04F5C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x01C04F60: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x01C04F64: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01C04F68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C04F6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C04F70: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C04F74: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C04F78: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x01C04F7C: CBNZ x21, #0x1c04f84       | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x01C04F80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x01C04F84: CBZ x22, #0x1c04fa8        | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x01C04F88: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C04F8C: MOV x0, x22                | X0 = val_2;//m1                         
            // 0x01C04F90: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C04F94: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x01C04F98: CBNZ x0, #0x1c04fa8        | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x01C04F9C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x01C04FA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04FA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_5:
            // 0x01C04FA8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01C04FAC: CBNZ w8, #0x1c04fbc        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x01C04FB0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x01C04FB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04FB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x01C04FBC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;
            // 0x01C04FC0: CBNZ x20, #0x1c04fc8       | if (val_1 != null) goto label_7;        
            if(val_1 != null)
            {
                goto label_7;
            }
            // 0x01C04FC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x01C04FC8: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x01C04FCC: LDR x8, [x8, #0x58]        | X8 = (string**)(1152921510261094832)("LoadData");
            // 0x01C04FD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C04FD4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01C04FD8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C04FDC: LDR x1, [x8]               | X1 = "LoadData";                        
            // 0x01C04FE0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C04FE4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01C04FE8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01C04FEC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "LoadData", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_3 = val_1.GetMethod(name:  "LoadData", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01C04FF0: ADRP x24, #0x363e000       | X24 = 56877056 (0x363E000);             
            // 0x01C04FF4: LDR x24, [x24, #0xe30]     | X24 = 1152921504784322560;              
            // 0x01C04FF8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01C04FFC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C05000: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C05004: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache0;
            val_9 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache0;
            // 0x01C05008: CBNZ x22, #0x1c05054       | if (ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache0 != null) goto label_8;
            if(val_9 != null)
            {
                goto label_8;
            }
            // 0x01C0500C: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x01C05010: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01C05014: LDR x8, [x8, #0xa78]       | X8 = 1152921510261099024;               
            // 0x01C05018: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01C0501C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::LoadData_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01C05020: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_4 = null;
            // 0x01C05024: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01C05028: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0502C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C05030: MOV x2, x22                | X2 = 1152921510261099024 (0x1000000151050A10);//ML01
            // 0x01C05034: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_10 = val_4;
            // 0x01C05038: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::LoadData_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::LoadData_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01C0503C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C05040: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C05044: STR x23, [x8]              | ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784326656
            ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache0 = val_10;
            // 0x01C05048: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C0504C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C05050: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_9 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache0;
            label_8:
            // 0x01C05054: CBNZ x19, #0x1c0505c       | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x01C05058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::LoadData_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_9:
            // 0x01C0505C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C05060: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C05064: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01C05068: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01C0506C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_3, func:  val_9);
            X1.RegisterCLRMethodRedirection(mi:  val_3, func:  val_9);
            // 0x01C05070: CBNZ x20, #0x1c05078       | if (val_1 != null) goto label_10;       
            if(val_1 != null)
            {
                goto label_10;
            }
            // 0x01C05074: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_10:
            // 0x01C05078: ADRP x9, #0x367c000        | X9 = 57131008 (0x367C000);              
            // 0x01C0507C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C05080: LDR x9, [x9, #0x7d8]       | X9 = (string**)(1152921510261100048)("enemyPlayerData");
            // 0x01C05084: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C05088: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C0508C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C05090: LDR x1, [x9]               | X1 = "enemyPlayerData";                 
            // 0x01C05094: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C05098: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C0509C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C050A0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C050A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C050A8: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache1;
            val_11 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache1;
            // 0x01C050AC: CBNZ x22, #0x1c050f8       | if (ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache1 != null) goto label_11;
            if(val_11 != null)
            {
                goto label_11;
            }
            // 0x01C050B0: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x01C050B4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C050B8: LDR x8, [x8, #0xb00]       | X8 = 1152921510261100160;               
            // 0x01C050BC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C050C0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::get_enemyPlayerData_0(ref object o);
            // 0x01C050C4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_5 = null;
            // 0x01C050C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C050CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C050D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C050D4: MOV x2, x22                | X2 = 1152921510261100160 (0x1000000151050E80);//ML01
            // 0x01C050D8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_10 = val_5;
            // 0x01C050DC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::get_enemyPlayerData_0(ref object o));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::get_enemyPlayerData_0(ref object o));
            // 0x01C050E0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C050E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C050E8: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784326664
            ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache1 = val_10;
            // 0x01C050EC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C050F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C050F4: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_11 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache1;
            label_11:
            // 0x01C050F8: CBNZ x19, #0x1c05100       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01C050FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::get_enemyPlayerData_0(ref object o)), ????);
            label_12:
            // 0x01C05100: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C05104: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C05108: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C0510C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C05110: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_11);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_11);
            // 0x01C05114: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C05118: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0511C: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache2;
            val_12 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache2;
            // 0x01C05120: CBNZ x22, #0x1c0516c       | if (ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache2 != null) goto label_13;
            if(val_12 != null)
            {
                goto label_13;
            }
            // 0x01C05124: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x01C05128: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C0512C: LDR x8, [x8, #0x160]       | X8 = 1152921510261101184;               
            // 0x01C05130: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C05134: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::set_enemyPlayerData_0(ref object o, object v);
            // 0x01C05138: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_6 = null;
            // 0x01C0513C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C05140: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C05144: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C05148: MOV x2, x22                | X2 = 1152921510261101184 (0x1000000151051280);//ML01
            // 0x01C0514C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_10 = val_6;
            // 0x01C05150: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::set_enemyPlayerData_0(ref object o, object v));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::set_enemyPlayerData_0(ref object o, object v));
            // 0x01C05154: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C05158: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0515C: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784326672
            ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache2 = val_10;
            // 0x01C05160: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C05164: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C05168: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_12 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache2;
            label_13:
            // 0x01C0516C: CBNZ x19, #0x1c05174       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01C05170: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::set_enemyPlayerData_0(ref object o, object v)), ????);
            label_14:
            // 0x01C05174: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C05178: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C0517C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C05180: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C05184: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_12);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_12);
            // 0x01C05188: CBNZ x20, #0x1c05190       | if (val_1 != null) goto label_15;       
            if(val_1 != null)
            {
                goto label_15;
            }
            // 0x01C0518C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x01C05190: ADRP x9, #0x367b000        | X9 = 57126912 (0x367B000);              
            // 0x01C05194: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C05198: LDR x9, [x9, #0xe08]       | X9 = (string**)(1152921510261102208)("ourPlayerData");
            // 0x01C0519C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C051A0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C051A4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C051A8: LDR x1, [x9]               | X1 = "ourPlayerData";                   
            // 0x01C051AC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C051B0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C051B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C051B8: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01C051BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C051C0: LDR x21, [x8, #0x18]       | X21 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache3;
            val_13 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache3;
            // 0x01C051C4: CBNZ x21, #0x1c05210       | if (ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache3 != null) goto label_16;
            if(val_13 != null)
            {
                goto label_16;
            }
            // 0x01C051C8: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01C051CC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C051D0: LDR x8, [x8, #0x8b0]       | X8 = 1152921510261102304;               
            // 0x01C051D4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C051D8: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::get_ourPlayerData_1(ref object o);
            // 0x01C051DC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_7 = null;
            // 0x01C051E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C051E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C051E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C051EC: MOV x2, x21                | X2 = 1152921510261102304 (0x10000001510516E0);//ML01
            // 0x01C051F0: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C051F4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::get_ourPlayerData_1(ref object o));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::get_ourPlayerData_1(ref object o));
            // 0x01C051F8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C051FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C05200: STR x22, [x8, #0x18]       | ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784326680
            ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache3 = val_7;
            // 0x01C05204: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C05208: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0520C: LDR x21, [x8, #0x18]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_13 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache3;
            label_16:
            // 0x01C05210: CBNZ x19, #0x1c05218       | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x01C05214: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::get_ourPlayerData_1(ref object o)), ????);
            label_17:
            // 0x01C05218: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0521C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C05220: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01C05224: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C05228: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_13);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_13);
            // 0x01C0522C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C05230: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C05234: LDR x21, [x8, #0x20]       | X21 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache4;
            val_14 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache4;
            // 0x01C05238: CBNZ x21, #0x1c05284       | if (ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache4 != null) goto label_18;
            if(val_14 != null)
            {
                goto label_18;
            }
            // 0x01C0523C: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x01C05240: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C05244: LDR x8, [x8, #0x118]       | X8 = 1152921510261103328;               
            // 0x01C05248: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C0524C: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::set_ourPlayerData_1(ref object o, object v);
            // 0x01C05250: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_8 = null;
            // 0x01C05254: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C05258: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0525C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C05260: MOV x2, x21                | X2 = 1152921510261103328 (0x1000000151051AE0);//ML01
            // 0x01C05264: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C05268: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::set_ourPlayerData_1(ref object o, object v));
            val_8 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::set_ourPlayerData_1(ref object o, object v));
            // 0x01C0526C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C05270: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C05274: STR x22, [x8, #0x20]       | ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784326688
            ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache4 = val_8;
            // 0x01C05278: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding);
            // 0x01C0527C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C05280: LDR x21, [x8, #0x20]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_14 = ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.<>f__mg$cache4;
            label_18:
            // 0x01C05284: CBNZ x19, #0x1c0528c       | if (X1 != 0) goto label_19;             
            if(X1 != 0)
            {
                goto label_19;
            }
            // 0x01C05288: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding::set_ourPlayerData_1(ref object o, object v)), ????);
            label_19:
            // 0x01C0528C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C05290: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01C05294: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C05298: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01C0529C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01C052A0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01C052A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C052A8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01C052AC: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_14); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_14);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C052B0 (29381296), len: 748  VirtAddr: 0x01C052B0 RVA: 0x01C052B0 token: 100665118 methodIndex: 31167 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* LoadData_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_14;
            //  | 
            var val_15;
            // 0x01C052B0: STP x26, x25, [sp, #-0x50]! | stack[1152921510261285616] = ???;  stack[1152921510261285624] = ???;  //  dest_result_addr=1152921510261285616 |  dest_result_addr=1152921510261285624
            // 0x01C052B4: STP x24, x23, [sp, #0x10]  | stack[1152921510261285632] = ???;  stack[1152921510261285640] = ???;  //  dest_result_addr=1152921510261285632 |  dest_result_addr=1152921510261285640
            // 0x01C052B8: STP x22, x21, [sp, #0x20]  | stack[1152921510261285648] = ???;  stack[1152921510261285656] = ???;  //  dest_result_addr=1152921510261285648 |  dest_result_addr=1152921510261285656
            // 0x01C052BC: STP x20, x19, [sp, #0x30]  | stack[1152921510261285664] = ???;  stack[1152921510261285672] = ???;  //  dest_result_addr=1152921510261285664 |  dest_result_addr=1152921510261285672
            // 0x01C052C0: STP x29, x30, [sp, #0x40]  | stack[1152921510261285680] = ???;  stack[1152921510261285688] = ???;  //  dest_result_addr=1152921510261285680 |  dest_result_addr=1152921510261285688
            // 0x01C052C4: ADD x29, sp, #0x40         | X29 = (1152921510261285616 + 64) = 1152921510261285680 (0x100000015107E330);
            // 0x01C052C8: SUB sp, sp, #0x10          | SP = (1152921510261285616 - 16) = 1152921510261285600 (0x100000015107E2E0);
            // 0x01C052CC: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C052D0: LDRB w8, [x20, #0x278]     | W8 = (bool)static_value_0373C278;       
            // 0x01C052D4: MOV x21, x3                | X21 = X3;//m1                           
            // 0x01C052D8: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01C052DC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C052E0: TBNZ w8, #0, #0x1c052fc    | if (static_value_0373C278 == true) goto label_0;
            // 0x01C052E4: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x01C052E8: LDR x8, [x8, #0xfb0]       | X8 = 0x2B92F70;                         
            // 0x01C052EC: LDR w0, [x8]               | W0 = 0x22A1;                            
            // 0x01C052F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x22A1, ????);     
            // 0x01C052F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C052F8: STRB w8, [x20, #0x278]     | static_value_0373C278 = true;            //  dest_result_addr=57918072
            label_0:
            // 0x01C052FC: CBNZ x19, #0x1c05304       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C05300: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x22A1, ????);     
            label_1:
            // 0x01C05304: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C05308: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C0530C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C05310: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C05314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C05318: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0531C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C05320: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C05324: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C05328: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01C0532C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C05330: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C05334: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C05338: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C0533C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C05340: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C05344: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C05348: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x01C0534C: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x01C05350: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C05354: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01C05358: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x01C0535C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C05360: TBZ w9, #0, #0x1c05374     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C05364: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C05368: CBNZ w9, #0x1c05374        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C0536C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C05370: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C05374: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C05378: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C0537C: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01C05380: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C05384: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01C05388: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01C0538C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C05390: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C05394: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C05398: TBZ w9, #0, #0x1c053ac     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C0539C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C053A0: CBNZ w9, #0x1c053ac        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C053A4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C053A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C053AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C053B0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C053B4: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C053B8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C053BC: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01C053C0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C053C4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C053C8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C053CC: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01C053D0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C053D4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C053D8: TBZ w9, #0, #0x1c053ec     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C053DC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C053E0: CBNZ w9, #0x1c053ec        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C053E4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C053E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C053EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C053F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C053F4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C053F8: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01C053FC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C05400: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x01C05404: CBZ x0, #0x1c0544c         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x01C05408: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C0540C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C05410: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C05414: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C05418: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01C0541C: MOV x24, x0                | X24 = val_6;//m1                        
            val_14 = val_6;
            // 0x01C05420: B.EQ #0x1c0544c            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01C05424: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C05428: MOV x8, sp                 | X8 = 1152921510261285600 (0x100000015107E2E0);//ML01
            // 0x01C0542C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C05430: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510261273696]
            // 0x01C05434: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01C05438: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0543C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x01C05440: MOV x0, sp                 | X0 = 1152921510261285600 (0x100000015107E2E0);//ML01
            // 0x01C05444: BL #0x299a140              | 
            // 0x01C05448: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_9:
            // 0x01C0544C: CBNZ x19, #0x1c05454       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01C05450: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000015107E2E0, ????);
            label_10:
            // 0x01C05454: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C05458: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C0545C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C05460: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C05464: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C05468: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0546C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C05470: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C05474: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C05478: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x01C0547C: LDR x8, [x8, #0xe18]       | X8 = 1152921504904450048;               
            // 0x01C05480: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x01C05484: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C05488: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C0548C: LDR x1, [x8]               | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C05490: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C05494: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x01C05498: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C0549C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C054A0: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C054A4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C054A8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01C054AC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C054B0: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x01C054B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C054B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C054BC: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x01C054C0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x01C054C4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x01C054C8: CBZ x0, #0x1c0552c         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x01C054CC: ADRP x9, #0x35c8000        | X9 = 56393728 (0x35C8000);              
            // 0x01C054D0: LDR x9, [x9, #0xb18]       | X9 = 1152921504904450048;               
            // 0x01C054D4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C054D8: LDR x1, [x9]               | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C054DC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C054E0: LDRB w9, [x1, #0x104]      | W9 = CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C054E4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C054E8: B.LO #0x1c05504            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x01C054EC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C054F0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CSArenaInterServiceData.__il2cppRuntimeFie
            // 0x01C054F4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C054F8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSArenaInterServiceData))
            // 0x01C054FC: MOV x21, x0                | X21 = val_11;//m1                       
            val_15 = val_11;
            // 0x01C05500: B.EQ #0x1c0552c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x01C05504: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C05508: ADD x8, sp, #8             | X8 = (1152921510261285600 + 8) = 1152921510261285608 (0x100000015107E2E8);
            // 0x01C0550C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C05510: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510261273696]
            // 0x01C05514: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x01C05518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0551C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x01C05520: ADD x0, sp, #8             | X0 = (1152921510261285600 + 8) = 1152921510261285608 (0x100000015107E2E8);
            // 0x01C05524: BL #0x299a140              | 
            // 0x01C05528: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_13:
            // 0x01C0552C: CBNZ x19, #0x1c05534       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01C05530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000015107E2E8, ????);
            label_14:
            // 0x01C05534: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C05538: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C0553C: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C05540: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C05544: CBNZ x21, #0x1c0554c       | if (0x0 != 0) goto label_15;            
            if(val_15 != 0)
            {
                goto label_15;
            }
            // 0x01C05548: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x01C0554C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C05550: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01C05554: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x01C05558: BL #0xb44a54               | val_15.LoadData(jsonStr:  val_14);      
            val_15.LoadData(jsonStr:  val_14);
            // 0x01C0555C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01C05560: SUB sp, x29, #0x40         | SP = (1152921510261285680 - 64) = 1152921510261285616 (0x100000015107E2F0);
            // 0x01C05564: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01C05568: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01C0556C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01C05570: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01C05574: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01C05578: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C0557C: MOV x19, x0                | 
            // 0x01C05580: ADD x0, sp, #8             | 
            // 0x01C05584: B #0x1c05590               | 
            // 0x01C05588: MOV x19, x0                | 
            // 0x01C0558C: MOV x0, sp                 | 
            label_16:
            // 0x01C05590: BL #0x299a140              | 
            // 0x01C05594: MOV x0, x19                | 
            // 0x01C05598: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C0559C (29382044), len: 288  VirtAddr: 0x01C0559C RVA: 0x01C0559C token: 100665119 methodIndex: 31168 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_enemyPlayerData_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C0559C: STP x20, x19, [sp, #-0x20]! | stack[1152921510261442640] = ???;  stack[1152921510261442648] = ???;  //  dest_result_addr=1152921510261442640 |  dest_result_addr=1152921510261442648
            // 0x01C055A0: STP x29, x30, [sp, #0x10]  | stack[1152921510261442656] = ???;  stack[1152921510261442664] = ???;  //  dest_result_addr=1152921510261442656 |  dest_result_addr=1152921510261442664
            // 0x01C055A4: ADD x29, sp, #0x10         | X29 = (1152921510261442640 + 16) = 1152921510261442656 (0x10000001510A4860);
            // 0x01C055A8: SUB sp, sp, #0x10          | SP = (1152921510261442640 - 16) = 1152921510261442624 (0x10000001510A4840);
            // 0x01C055AC: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C055B0: LDRB w8, [x20, #0x279]     | W8 = (bool)static_value_0373C279;       
            // 0x01C055B4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C055B8: TBNZ w8, #0, #0x1c055d4    | if (static_value_0373C279 == true) goto label_0;
            // 0x01C055BC: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x01C055C0: LDR x8, [x8, #0xb38]       | X8 = 0x2B92F68;                         
            // 0x01C055C4: LDR w0, [x8]               | W0 = 0x229F;                            
            // 0x01C055C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x229F, ????);     
            // 0x01C055CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C055D0: STRB w8, [x20, #0x279]     | static_value_0373C279 = true;            //  dest_result_addr=57918073
            label_0:
            // 0x01C055D4: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x01C055D8: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C055DC: LDR x20, [x20, #0xb18]     | X20 = 1152921504904450048;              
            // 0x01C055E0: CBZ x19, #0x1c05634        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C055E4: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C055E8: LDR x1, [x20]              | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C055EC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C055F0: LDRB w9, [x1, #0x104]      | W9 = CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C055F4: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C055F8: B.LO #0x1c05610            | if (X1 + 260 < CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C055FC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C05600: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C05604: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C05608: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSArenaInterServiceData))
            // 0x01C0560C: B.EQ #0x1c05638            | if ((X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C05610: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C05614: MOV x8, sp                 | X8 = 1152921510261442624 (0x10000001510A4840);//ML01
            // 0x01C05618: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C0561C: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510261430672]
            // 0x01C05620: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C05624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C05628: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C0562C: MOV x0, sp                 | X0 = 1152921510261442624 (0x10000001510A4840);//ML01
            // 0x01C05630: BL #0x299a140              | 
            label_1:
            // 0x01C05634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001510A4840, ????);
            label_3:
            // 0x01C05638: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C0563C: LDR x1, [x20]              | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C05640: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C05644: LDRB w9, [x1, #0x104]      | W9 = CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C05648: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C0564C: B.LO #0x1c05678            | if (X1 + 260 < CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C05650: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C05654: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C05658: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C0565C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSArenaInterServiceData))
            // 0x01C05660: B.NE #0x1c05678            | if ((X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C05664: LDR x0, [x19, #0x10]       | X0 = X1 + 16;                           
            // 0x01C05668: SUB sp, x29, #0x10         | SP = (1152921510261442656 - 16) = 1152921510261442640 (0x10000001510A4850);
            // 0x01C0566C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C05670: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C05674: RET                        |  return (System.Object)X1 + 16;         
            return (object)X1 + 16;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C05678: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C0567C: ADD x8, sp, #8             | X8 = (1152921510261442624 + 8) = 1152921510261442632 (0x10000001510A4848);
            // 0x01C05680: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C05684: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510261430672]
            // 0x01C05688: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C0568C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C05690: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C05694: ADD x0, sp, #8             | X0 = (1152921510261442624 + 8) = 1152921510261442632 (0x10000001510A4848);
            // 0x01C05698: BL #0x299a140              | 
            // 0x01C0569C: MOV x19, x0                | X19 = 1152921510261442632 (0x10000001510A4848);//ML01
            // 0x01C056A0: MOV x0, sp                 | X0 = 1152921510261442624 (0x10000001510A4840);//ML01
            label_6:
            // 0x01C056A4: BL #0x299a140              | 
            // 0x01C056A8: MOV x0, x19                | X0 = 1152921510261442632 (0x10000001510A4848);//ML01
            // 0x01C056AC: BL #0x980800               | X0 = sub_980800( ?? 0x10000001510A4848, ????);
            // 0x01C056B0: MOV x19, x0                | X19 = 1152921510261442632 (0x10000001510A4848);//ML01
            // 0x01C056B4: ADD x0, sp, #8             | X0 = (1152921510261442624 + 8) = 1152921510261442632 (0x10000001510A4848);
            // 0x01C056B8: B #0x1c056a4               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C056BC (29382332), len: 420  VirtAddr: 0x01C056BC RVA: 0x01C056BC token: 100665120 methodIndex: 31169 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_enemyPlayerData_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01C056BC: STP x22, x21, [sp, #-0x30]! | stack[1152921510261566752] = ???;  stack[1152921510261566760] = ???;  //  dest_result_addr=1152921510261566752 |  dest_result_addr=1152921510261566760
            // 0x01C056C0: STP x20, x19, [sp, #0x10]  | stack[1152921510261566768] = ???;  stack[1152921510261566776] = ???;  //  dest_result_addr=1152921510261566768 |  dest_result_addr=1152921510261566776
            // 0x01C056C4: STP x29, x30, [sp, #0x20]  | stack[1152921510261566784] = ???;  stack[1152921510261566792] = ???;  //  dest_result_addr=1152921510261566784 |  dest_result_addr=1152921510261566792
            // 0x01C056C8: ADD x29, sp, #0x20         | X29 = (1152921510261566752 + 32) = 1152921510261566784 (0x10000001510C2D40);
            // 0x01C056CC: SUB sp, sp, #0x20          | SP = (1152921510261566752 - 32) = 1152921510261566720 (0x10000001510C2D00);
            // 0x01C056D0: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C056D4: LDRB w8, [x21, #0x27a]     | W8 = (bool)static_value_0373C27A;       
            // 0x01C056D8: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x01C056DC: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C056E0: TBNZ w8, #0, #0x1c056fc    | if (static_value_0373C27A == true) goto label_0;
            // 0x01C056E4: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x01C056E8: LDR x8, [x8, #0x8c8]       | X8 = 0x2B92F78;                         
            // 0x01C056EC: LDR w0, [x8]               | W0 = 0x22A3;                            
            // 0x01C056F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x22A3, ????);     
            // 0x01C056F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C056F8: STRB w8, [x21, #0x27a]     | static_value_0373C27A = true;            //  dest_result_addr=57918074
            label_0:
            // 0x01C056FC: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01C05700: CBZ x20, #0x1c057b4        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C05704: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x01C05708: LDR x21, [x21, #0xb18]     | X21 = 1152921504904450048;              
            val_7 = 1152921504904450048;
            // 0x01C0570C: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C05710: LDR x1, [x21]              | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C05714: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C05718: LDRB w9, [x1, #0x104]      | W9 = CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0571C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C05720: B.LO #0x1c05738            | if (mem[null + 260] < CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C05724: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C05728: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C0572C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C05730: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSArenaInterServiceData))
            // 0x01C05734: B.EQ #0x1c05760            | if ((mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C05738: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C0573C: ADD x8, sp, #8             | X8 = (1152921510261566720 + 8) = 1152921510261566728 (0x10000001510C2D08);
            // 0x01C05740: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C05744: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510261554800]
            // 0x01C05748: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C0574C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C05750: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C05754: ADD x0, sp, #8             | X0 = (1152921510261566720 + 8) = 1152921510261566728 (0x10000001510C2D08);
            // 0x01C05758: BL #0x299a140              | 
            // 0x01C0575C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001510C2D08, ????);
            label_3:
            // 0x01C05760: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C05764: LDR x1, [x21]              | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C05768: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C0576C: LDRB w9, [x1, #0x104]      | W9 = CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C05770: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C05774: B.LO #0x1c0578c            | if (mem[null + 260] < CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C05778: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C0577C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C05780: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C05784: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSArenaInterServiceData))
            // 0x01C05788: B.EQ #0x1c057bc            | if ((mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C0578C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C05790: ADD x8, sp, #0x10          | X8 = (1152921510261566720 + 16) = 1152921510261566736 (0x10000001510C2D10);
            // 0x01C05794: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C05798: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510261554800]
            // 0x01C0579C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C057A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C057A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C057A8: ADD x0, sp, #0x10          | X0 = (1152921510261566720 + 16) = 1152921510261566736 (0x10000001510C2D10);
            // 0x01C057AC: BL #0x299a140              | 
            // 0x01C057B0: B #0x1c057b8               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C057B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x22A3, ????);     
            label_6:
            // 0x01C057B8: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x01C057BC: CBZ x19, #0x1c05818        | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x01C057C0: ADRP x9, #0x35cd000        | X9 = 56414208 (0x35CD000);              
            // 0x01C057C4: LDR x9, [x9, #0xd70]       | X9 = 1152921504904503296;               
            // 0x01C057C8: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C057CC: LDR x1, [x9]               | X1 = typeof(CSAISPlayerData);           
            // 0x01C057D0: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x01C057D4: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C057D8: CMP w10, w9                | STATE = COMPARE(X2 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C057DC: B.LO #0x1c057f4            | if (X2 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x01C057E0: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x01C057E4: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C057E8: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C057EC: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C057F0: B.EQ #0x1c0581c            | if ((X2 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x01C057F4: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C057F8: ADD x8, sp, #0x18          | X8 = (1152921510261566720 + 24) = 1152921510261566744 (0x10000001510C2D18);
            // 0x01C057FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01C05800: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510261554800]
            // 0x01C05804: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x01C05808: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0580C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x01C05810: ADD x0, sp, #0x18          | X0 = (1152921510261566720 + 24) = 1152921510261566744 (0x10000001510C2D18);
            // 0x01C05814: BL #0x299a140              | 
            label_7:
            // 0x01C05818: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x01C0581C: STR x19, [x20, #0x10]      | mem[16] = 0x0;                           //  dest_result_addr=16
            mem[16] = val_8;
            // 0x01C05820: SUB sp, x29, #0x20         | SP = (1152921510261566784 - 32) = 1152921510261566752 (0x10000001510C2D20);
            // 0x01C05824: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C05828: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C0582C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C05830: RET                        |  return;                                
            return;
            // 0x01C05834: MOV x19, x0                | 
            // 0x01C05838: ADD x0, sp, #8             | 
            // 0x01C0583C: B #0x1c05854               | 
            // 0x01C05840: MOV x19, x0                | 
            // 0x01C05844: ADD x0, sp, #0x10          | 
            // 0x01C05848: B #0x1c05854               | 
            // 0x01C0584C: MOV x19, x0                | 
            // 0x01C05850: ADD x0, sp, #0x18          | 
            label_11:
            // 0x01C05854: BL #0x299a140              | 
            // 0x01C05858: MOV x0, x19                | 
            // 0x01C0585C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C05860 (29382752), len: 288  VirtAddr: 0x01C05860 RVA: 0x01C05860 token: 100665121 methodIndex: 31170 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_ourPlayerData_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C05860: STP x20, x19, [sp, #-0x20]! | stack[1152921510261690896] = ???;  stack[1152921510261690904] = ???;  //  dest_result_addr=1152921510261690896 |  dest_result_addr=1152921510261690904
            // 0x01C05864: STP x29, x30, [sp, #0x10]  | stack[1152921510261690912] = ???;  stack[1152921510261690920] = ???;  //  dest_result_addr=1152921510261690912 |  dest_result_addr=1152921510261690920
            // 0x01C05868: ADD x29, sp, #0x10         | X29 = (1152921510261690896 + 16) = 1152921510261690912 (0x10000001510E1220);
            // 0x01C0586C: SUB sp, sp, #0x10          | SP = (1152921510261690896 - 16) = 1152921510261690880 (0x10000001510E1200);
            // 0x01C05870: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C05874: LDRB w8, [x20, #0x27b]     | W8 = (bool)static_value_0373C27B;       
            // 0x01C05878: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C0587C: TBNZ w8, #0, #0x1c05898    | if (static_value_0373C27B == true) goto label_0;
            // 0x01C05880: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x01C05884: LDR x8, [x8, #0x8f0]       | X8 = 0x2B92F6C;                         
            // 0x01C05888: LDR w0, [x8]               | W0 = 0x22A0;                            
            // 0x01C0588C: BL #0x2782188              | X0 = sub_2782188( ?? 0x22A0, ????);     
            // 0x01C05890: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C05894: STRB w8, [x20, #0x27b]     | static_value_0373C27B = true;            //  dest_result_addr=57918075
            label_0:
            // 0x01C05898: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x01C0589C: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C058A0: LDR x20, [x20, #0xb18]     | X20 = 1152921504904450048;              
            // 0x01C058A4: CBZ x19, #0x1c058f8        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C058A8: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C058AC: LDR x1, [x20]              | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C058B0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C058B4: LDRB w9, [x1, #0x104]      | W9 = CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C058B8: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C058BC: B.LO #0x1c058d4            | if (X1 + 260 < CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C058C0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C058C4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C058C8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C058CC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSArenaInterServiceData))
            // 0x01C058D0: B.EQ #0x1c058fc            | if ((X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C058D4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C058D8: MOV x8, sp                 | X8 = 1152921510261690880 (0x10000001510E1200);//ML01
            // 0x01C058DC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C058E0: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510261678928]
            // 0x01C058E4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C058E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C058EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C058F0: MOV x0, sp                 | X0 = 1152921510261690880 (0x10000001510E1200);//ML01
            // 0x01C058F4: BL #0x299a140              | 
            label_1:
            // 0x01C058F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001510E1200, ????);
            label_3:
            // 0x01C058FC: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C05900: LDR x1, [x20]              | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C05904: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C05908: LDRB w9, [x1, #0x104]      | W9 = CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0590C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C05910: B.LO #0x1c0593c            | if (X1 + 260 < CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C05914: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C05918: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C0591C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C05920: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSArenaInterServiceData))
            // 0x01C05924: B.NE #0x1c0593c            | if ((X1 + 176 + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C05928: LDR x0, [x19, #0x18]       | X0 = X1 + 24;                           
            // 0x01C0592C: SUB sp, x29, #0x10         | SP = (1152921510261690912 - 16) = 1152921510261690896 (0x10000001510E1210);
            // 0x01C05930: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C05934: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C05938: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C0593C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C05940: ADD x8, sp, #8             | X8 = (1152921510261690880 + 8) = 1152921510261690888 (0x10000001510E1208);
            // 0x01C05944: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C05948: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510261678928]
            // 0x01C0594C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C05950: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C05954: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C05958: ADD x0, sp, #8             | X0 = (1152921510261690880 + 8) = 1152921510261690888 (0x10000001510E1208);
            // 0x01C0595C: BL #0x299a140              | 
            // 0x01C05960: MOV x19, x0                | X19 = 1152921510261690888 (0x10000001510E1208);//ML01
            // 0x01C05964: MOV x0, sp                 | X0 = 1152921510261690880 (0x10000001510E1200);//ML01
            label_6:
            // 0x01C05968: BL #0x299a140              | 
            // 0x01C0596C: MOV x0, x19                | X0 = 1152921510261690888 (0x10000001510E1208);//ML01
            // 0x01C05970: BL #0x980800               | X0 = sub_980800( ?? 0x10000001510E1208, ????);
            // 0x01C05974: MOV x19, x0                | X19 = 1152921510261690888 (0x10000001510E1208);//ML01
            // 0x01C05978: ADD x0, sp, #8             | X0 = (1152921510261690880 + 8) = 1152921510261690888 (0x10000001510E1208);
            // 0x01C0597C: B #0x1c05968               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C05980 (29383040), len: 420  VirtAddr: 0x01C05980 RVA: 0x01C05980 token: 100665122 methodIndex: 31171 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_ourPlayerData_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01C05980: STP x22, x21, [sp, #-0x30]! | stack[1152921510261815008] = ???;  stack[1152921510261815016] = ???;  //  dest_result_addr=1152921510261815008 |  dest_result_addr=1152921510261815016
            // 0x01C05984: STP x20, x19, [sp, #0x10]  | stack[1152921510261815024] = ???;  stack[1152921510261815032] = ???;  //  dest_result_addr=1152921510261815024 |  dest_result_addr=1152921510261815032
            // 0x01C05988: STP x29, x30, [sp, #0x20]  | stack[1152921510261815040] = ???;  stack[1152921510261815048] = ???;  //  dest_result_addr=1152921510261815040 |  dest_result_addr=1152921510261815048
            // 0x01C0598C: ADD x29, sp, #0x20         | X29 = (1152921510261815008 + 32) = 1152921510261815040 (0x10000001510FF700);
            // 0x01C05990: SUB sp, sp, #0x20          | SP = (1152921510261815008 - 32) = 1152921510261814976 (0x10000001510FF6C0);
            // 0x01C05994: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C05998: LDRB w8, [x21, #0x27c]     | W8 = (bool)static_value_0373C27C;       
            // 0x01C0599C: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x01C059A0: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C059A4: TBNZ w8, #0, #0x1c059c0    | if (static_value_0373C27C == true) goto label_0;
            // 0x01C059A8: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x01C059AC: LDR x8, [x8, #0x540]       | X8 = 0x2B92F7C;                         
            // 0x01C059B0: LDR w0, [x8]               | W0 = 0x22A4;                            
            // 0x01C059B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x22A4, ????);     
            // 0x01C059B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C059BC: STRB w8, [x21, #0x27c]     | static_value_0373C27C = true;            //  dest_result_addr=57918076
            label_0:
            // 0x01C059C0: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01C059C4: CBZ x20, #0x1c05a78        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C059C8: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x01C059CC: LDR x21, [x21, #0xb18]     | X21 = 1152921504904450048;              
            val_7 = 1152921504904450048;
            // 0x01C059D0: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C059D4: LDR x1, [x21]              | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C059D8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C059DC: LDRB w9, [x1, #0x104]      | W9 = CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C059E0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C059E4: B.LO #0x1c059fc            | if (mem[null + 260] < CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C059E8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C059EC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C059F0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C059F4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSArenaInterServiceData))
            // 0x01C059F8: B.EQ #0x1c05a24            | if ((mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C059FC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C05A00: ADD x8, sp, #8             | X8 = (1152921510261814976 + 8) = 1152921510261814984 (0x10000001510FF6C8);
            // 0x01C05A04: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C05A08: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510261803056]
            // 0x01C05A0C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C05A10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C05A14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C05A18: ADD x0, sp, #8             | X0 = (1152921510261814976 + 8) = 1152921510261814984 (0x10000001510FF6C8);
            // 0x01C05A1C: BL #0x299a140              | 
            // 0x01C05A20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001510FF6C8, ????);
            label_3:
            // 0x01C05A24: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C05A28: LDR x1, [x21]              | X1 = typeof(CSArenaInterServiceData);   
            // 0x01C05A2C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C05A30: LDRB w9, [x1, #0x104]      | W9 = CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C05A34: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C05A38: B.LO #0x1c05a50            | if (mem[null + 260] < CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C05A3C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C05A40: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C05A44: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C05A48: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSArenaInterServiceData))
            // 0x01C05A4C: B.EQ #0x1c05a80            | if ((mem[null + 176] + (CSArenaInterServiceData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C05A50: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C05A54: ADD x8, sp, #0x10          | X8 = (1152921510261814976 + 16) = 1152921510261814992 (0x10000001510FF6D0);
            // 0x01C05A58: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C05A5C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510261803056]
            // 0x01C05A60: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C05A64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C05A68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C05A6C: ADD x0, sp, #0x10          | X0 = (1152921510261814976 + 16) = 1152921510261814992 (0x10000001510FF6D0);
            // 0x01C05A70: BL #0x299a140              | 
            // 0x01C05A74: B #0x1c05a7c               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C05A78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x22A4, ????);     
            label_6:
            // 0x01C05A7C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x01C05A80: CBZ x19, #0x1c05adc        | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x01C05A84: ADRP x9, #0x35cd000        | X9 = 56414208 (0x35CD000);              
            // 0x01C05A88: LDR x9, [x9, #0xd70]       | X9 = 1152921504904503296;               
            // 0x01C05A8C: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C05A90: LDR x1, [x9]               | X1 = typeof(CSAISPlayerData);           
            // 0x01C05A94: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x01C05A98: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C05A9C: CMP w10, w9                | STATE = COMPARE(X2 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C05AA0: B.LO #0x1c05ab8            | if (X2 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x01C05AA4: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x01C05AA8: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C05AAC: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C05AB0: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C05AB4: B.EQ #0x1c05ae0            | if ((X2 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x01C05AB8: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C05ABC: ADD x8, sp, #0x18          | X8 = (1152921510261814976 + 24) = 1152921510261815000 (0x10000001510FF6D8);
            // 0x01C05AC0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01C05AC4: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510261803056]
            // 0x01C05AC8: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x01C05ACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C05AD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x01C05AD4: ADD x0, sp, #0x18          | X0 = (1152921510261814976 + 24) = 1152921510261815000 (0x10000001510FF6D8);
            // 0x01C05AD8: BL #0x299a140              | 
            label_7:
            // 0x01C05ADC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x01C05AE0: STR x19, [x20, #0x18]      | mem[24] = 0x0;                           //  dest_result_addr=24
            mem[24] = val_8;
            // 0x01C05AE4: SUB sp, x29, #0x20         | SP = (1152921510261815040 - 32) = 1152921510261815008 (0x10000001510FF6E0);
            // 0x01C05AE8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C05AEC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C05AF0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C05AF4: RET                        |  return;                                
            return;
            // 0x01C05AF8: MOV x19, x0                | 
            // 0x01C05AFC: ADD x0, sp, #8             | 
            // 0x01C05B00: B #0x1c05b18               | 
            // 0x01C05B04: MOV x19, x0                | 
            // 0x01C05B08: ADD x0, sp, #0x10          | 
            // 0x01C05B0C: B #0x1c05b18               | 
            // 0x01C05B10: MOV x19, x0                | 
            // 0x01C05B14: ADD x0, sp, #0x18          | 
            label_11:
            // 0x01C05B18: BL #0x299a140              | 
            // 0x01C05B1C: MOV x0, x19                | 
            // 0x01C05B20: BL #0x980800               | 
        
        }
    
    }

}
