using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    public class BsonReader : JsonReader
    {
        // Fields
        private const int MaxCharBytesSize = 128;
        private static readonly byte[] _seqRange1; // static_offset: 0x00000000
        private static readonly byte[] _seqRange2; // static_offset: 0x00000008
        private static readonly byte[] _seqRange3; // static_offset: 0x00000010
        private static readonly byte[] _seqRange4; // static_offset: 0x00000018
        private readonly System.IO.BinaryReader _reader; //  0x00000048
        private readonly System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonReader.ContainerContext> _stack; //  0x00000050
        private byte[] _byteBuffer; //  0x00000058
        private char[] _charBuffer; //  0x00000060
        private Newtonsoft.Json.Bson.BsonType _currentElementType; //  0x00000068
        private Newtonsoft.Json.Bson.BsonReader.BsonReaderState _bsonReaderState; //  0x0000006C
        private Newtonsoft.Json.Bson.BsonReader.ContainerContext _currentContext; //  0x00000070
        private bool _readRootValueAsArray; //  0x00000078
        private bool _jsonNet35BinaryCompatibility; //  0x00000079
        private System.DateTimeKind _dateTimeKindHandling; //  0x0000007C
        
        // Properties
        public bool JsonNet35BinaryCompatibility { get; set; }
        public bool ReadRootValueAsArray { get; set; }
        public System.DateTimeKind DateTimeKindHandling { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD1E84 (11345540), len: 12  VirtAddr: 0x00AD1E84 RVA: 0x00AD1E84 token: 100684724 methodIndex: 47384 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonReader(System.IO.Stream stream)
        {
            //
            // Disasemble & Code
            // 0x00AD1E84: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD1E88: ORR w3, wzr, #2            | W3 = 2(0x2);                            
            // 0x00AD1E8C: B #0xad1e90                | this..ctor(stream:  stream, readRootValueAsArray:  false, dateTimeKindHandling:  2); return;
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1E90 (11345552), len: 220  VirtAddr: 0x00AD1E90 RVA: 0x00AD1E90 token: 100684725 methodIndex: 47385 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonReader(System.IO.Stream stream, bool readRootValueAsArray, System.DateTimeKind dateTimeKindHandling)
        {
            //
            // Disasemble & Code
            // 0x00AD1E90: STP x24, x23, [sp, #-0x40]! | stack[1152921513715934048] = ???;  stack[1152921513715934056] = ???;  //  dest_result_addr=1152921513715934048 |  dest_result_addr=1152921513715934056
            // 0x00AD1E94: STP x22, x21, [sp, #0x10]  | stack[1152921513715934064] = ???;  stack[1152921513715934072] = ???;  //  dest_result_addr=1152921513715934064 |  dest_result_addr=1152921513715934072
            // 0x00AD1E98: STP x20, x19, [sp, #0x20]  | stack[1152921513715934080] = ???;  stack[1152921513715934088] = ???;  //  dest_result_addr=1152921513715934080 |  dest_result_addr=1152921513715934088
            // 0x00AD1E9C: STP x29, x30, [sp, #0x30]  | stack[1152921513715934096] = ???;  stack[1152921513715934104] = ???;  //  dest_result_addr=1152921513715934096 |  dest_result_addr=1152921513715934104
            // 0x00AD1EA0: ADD x29, sp, #0x30         | X29 = (1152921513715934048 + 48) = 1152921513715934096 (0x100000021EF1A390);
            // 0x00AD1EA4: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
            // 0x00AD1EA8: LDRB w8, [x23, #0x4cf]     | W8 = (bool)static_value_037334CF;       
            // 0x00AD1EAC: MOV w19, w3                | W19 = dateTimeKindHandling;//m1         
            // 0x00AD1EB0: MOV w20, w2                | W20 = readRootValueAsArray;//m1         
            // 0x00AD1EB4: MOV x22, x1                | X22 = stream;//m1                       
            // 0x00AD1EB8: MOV x21, x0                | X21 = 1152921513715946112 (0x100000021EF1D280);//ML01
            // 0x00AD1EBC: TBNZ w8, #0, #0xad1ed8     | if (static_value_037334CF == true) goto label_0;
            // 0x00AD1EC0: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x00AD1EC4: LDR x8, [x8, #0x3e8]       | X8 = 0x2B8F998;                         
            // 0x00AD1EC8: LDR w0, [x8]               | W0 = 0x152A;                            
            // 0x00AD1ECC: BL #0x2782188              | X0 = sub_2782188( ?? 0x152A, ????);     
            // 0x00AD1ED0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD1ED4: STRB w8, [x23, #0x4cf]     | static_value_037334CF = true;            //  dest_result_addr=57881807
            label_0:
            // 0x00AD1ED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1EDC: MOV x0, x21                | X0 = 1152921513715946112 (0x100000021EF1D280);//ML01
            // 0x00AD1EE0: BL #0x1313184              | this..ctor();                           
            // 0x00AD1EE4: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00AD1EE8: LDR x8, [x8, #0x248]       | X8 = (string**)(1152921513715922032)("stream");
            // 0x00AD1EEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD1EF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD1EF4: MOV x1, x22                | X1 = stream;//m1                        
            // 0x00AD1EF8: LDR x2, [x8]               | X2 = "stream";                          
            // 0x00AD1EFC: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  stream);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  stream);
            // 0x00AD1F00: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x00AD1F04: LDR x8, [x8, #0x470]       | X8 = 1152921504620691456;               
            // 0x00AD1F08: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryReader);    
            System.IO.BinaryReader val_1 = null;
            // 0x00AD1F0C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x00AD1F10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD1F14: MOV x1, x22                | X1 = stream;//m1                        
            // 0x00AD1F18: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x00AD1F1C: BL #0x1e664fc              | .ctor(input:  stream);                  
            val_1 = new System.IO.BinaryReader(input:  stream);
            // 0x00AD1F20: STR x23, [x21, #0x48]      | this._reader = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921513715946184
            this._reader = val_1;
            // 0x00AD1F24: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00AD1F28: LDR x8, [x8, #0xc98]       | X8 = 1152921504616644608;               
            // 0x00AD1F2C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<ContainerContext> val_2 = null;
            // 0x00AD1F30: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AD1F34: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x00AD1F38: LDR x8, [x8, #0x1c0]       | X8 = 1152921513714024688;               
            // 0x00AD1F3C: MOV x22, x0                | X22 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AD1F40: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<ContainerContext>::.ctor();
            // 0x00AD1F44: BL #0x25e9474              | .ctor();                                
            val_2 = new System.Collections.Generic.List<ContainerContext>();
            // 0x00AD1F48: AND w8, w20, #1            | W8 = (readRootValueAsArray & 1);        
            bool val_3 = readRootValueAsArray;
            // 0x00AD1F4C: STR w19, [x21, #0x7c]      | this._dateTimeKindHandling = dateTimeKindHandling;  //  dest_result_addr=1152921513715946236
            this._dateTimeKindHandling = dateTimeKindHandling;
            // 0x00AD1F50: STR x22, [x21, #0x50]      | this._stack = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513715946192
            this._stack = val_2;
            // 0x00AD1F54: STRB w8, [x21, #0x78]      | this._readRootValueAsArray = (readRootValueAsArray & 1);  //  dest_result_addr=1152921513715946232
            this._readRootValueAsArray = val_3;
            // 0x00AD1F58: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1F5C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD1F60: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD1F64: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AD1F68: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1F6C (11345772), len: 8  VirtAddr: 0x00AD1F6C RVA: 0x00AD1F6C token: 100684726 methodIndex: 47386 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_JsonNet35BinaryCompatibility()
        {
            //
            // Disasemble & Code
            // 0x00AD1F6C: LDRB w0, [x0, #0x79]       | W0 = this._jsonNet35BinaryCompatibility; //P2 
            // 0x00AD1F70: RET                        |  return (System.Boolean)this._jsonNet35BinaryCompatibility;
            return this._jsonNet35BinaryCompatibility;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1F74 (11345780), len: 12  VirtAddr: 0x00AD1F74 RVA: 0x00AD1F74 token: 100684727 methodIndex: 47387 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_JsonNet35BinaryCompatibility(bool value)
        {
            //
            // Disasemble & Code
            // 0x00AD1F74: AND w8, w1, #1             | W8 = (value & 1);                       
            bool val_1 = value;
            // 0x00AD1F78: STRB w8, [x0, #0x79]       | this._jsonNet35BinaryCompatibility = (value & 1);  //  dest_result_addr=1152921513716178425
            this._jsonNet35BinaryCompatibility = val_1;
            // 0x00AD1F7C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1F80 (11345792), len: 8  VirtAddr: 0x00AD1F80 RVA: 0x00AD1F80 token: 100684728 methodIndex: 47388 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_ReadRootValueAsArray()
        {
            //
            // Disasemble & Code
            // 0x00AD1F80: LDRB w0, [x0, #0x78]       | W0 = this._readRootValueAsArray; //P2   
            // 0x00AD1F84: RET                        |  return (System.Boolean)this._readRootValueAsArray;
            return this._readRootValueAsArray;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1F88 (11345800), len: 12  VirtAddr: 0x00AD1F88 RVA: 0x00AD1F88 token: 100684729 methodIndex: 47389 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_ReadRootValueAsArray(bool value)
        {
            //
            // Disasemble & Code
            // 0x00AD1F88: AND w8, w1, #1             | W8 = (value & 1);                       
            bool val_1 = value;
            // 0x00AD1F8C: STRB w8, [x0, #0x78]       | this._readRootValueAsArray = (value & 1);  //  dest_result_addr=1152921513716402424
            this._readRootValueAsArray = val_1;
            // 0x00AD1F90: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1F94 (11345812), len: 8  VirtAddr: 0x00AD1F94 RVA: 0x00AD1F94 token: 100684730 methodIndex: 47390 delegateWrapperIndex: 0 methodInvoker: 0
        public System.DateTimeKind get_DateTimeKindHandling()
        {
            //
            // Disasemble & Code
            // 0x00AD1F94: LDR w0, [x0, #0x7c]        | W0 = this._dateTimeKindHandling; //P2   
            // 0x00AD1F98: RET                        |  return (System.DateTimeKind)this._dateTimeKindHandling;
            return this._dateTimeKindHandling;
            //  |  // // {name=val_0, type=System.DateTimeKind, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1F9C (11345820), len: 8  VirtAddr: 0x00AD1F9C RVA: 0x00AD1F9C token: 100684731 methodIndex: 47391 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_DateTimeKindHandling(System.DateTimeKind value)
        {
            //
            // Disasemble & Code
            // 0x00AD1F9C: STR w1, [x0, #0x7c]        | this._dateTimeKindHandling = value;      //  dest_result_addr=1152921513716638716
            this._dateTimeKindHandling = value;
            // 0x00AD1FA0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1FA4 (11345828), len: 40  VirtAddr: 0x00AD1FA4 RVA: 0x00AD1FA4 token: 100684732 methodIndex: 47392 delegateWrapperIndex: 0 methodInvoker: 0
        private string ReadElement()
        {
            //
            // Disasemble & Code
            // 0x00AD1FA4: STP x20, x19, [sp, #-0x20]! | stack[1152921513716746752] = ???;  stack[1152921513716746760] = ???;  //  dest_result_addr=1152921513716746752 |  dest_result_addr=1152921513716746760
            // 0x00AD1FA8: STP x29, x30, [sp, #0x10]  | stack[1152921513716746768] = ???;  stack[1152921513716746776] = ???;  //  dest_result_addr=1152921513716746768 |  dest_result_addr=1152921513716746776
            // 0x00AD1FAC: ADD x29, sp, #0x10         | X29 = (1152921513716746752 + 16) = 1152921513716746768 (0x100000021EFE0A10);
            // 0x00AD1FB0: MOV x19, x0                | X19 = 1152921513716758784 (0x100000021EFE3900);//ML01
            // 0x00AD1FB4: BL #0xad1fcc               | X0 = this.ReadType();                   
            Newtonsoft.Json.Bson.BsonType val_1 = this.ReadType();
            // 0x00AD1FB8: STRB w0, [x19, #0x68]      | this._currentElementType = val_1;        //  dest_result_addr=1152921513716758888
            this._currentElementType = val_1;
            // 0x00AD1FBC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1FC0: MOV x0, x19                | X0 = 1152921513716758784 (0x100000021EFE3900);//ML01
            // 0x00AD1FC4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD1FC8: B #0xad200c                | return this.ReadString();               
            return this.ReadString();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD2314 (11346708), len: 560  VirtAddr: 0x00AD2314 RVA: 0x00AD2314 token: 100684733 methodIndex: 47393 delegateWrapperIndex: 0 methodInvoker: 0
        public override byte[] ReadAsBytes()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            Newtonsoft.Json.Bson.BsonReader val_5;
            //  | 
            var val_6;
            // 0x00AD2314: STP x22, x21, [sp, #-0x30]! | stack[1152921513716876320] = ???;  stack[1152921513716876328] = ???;  //  dest_result_addr=1152921513716876320 |  dest_result_addr=1152921513716876328
            // 0x00AD2318: STP x20, x19, [sp, #0x10]  | stack[1152921513716876336] = ???;  stack[1152921513716876344] = ???;  //  dest_result_addr=1152921513716876336 |  dest_result_addr=1152921513716876344
            // 0x00AD231C: STP x29, x30, [sp, #0x20]  | stack[1152921513716876352] = ???;  stack[1152921513716876360] = ???;  //  dest_result_addr=1152921513716876352 |  dest_result_addr=1152921513716876360
            // 0x00AD2320: ADD x29, sp, #0x20         | X29 = (1152921513716876320 + 32) = 1152921513716876352 (0x100000021F000440);
            // 0x00AD2324: SUB sp, sp, #0x10          | SP = (1152921513716876320 - 16) = 1152921513716876304 (0x100000021F000410);
            // 0x00AD2328: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD232C: LDRB w8, [x20, #0x4d0]     | W8 = (bool)static_value_037334D0;       
            // 0x00AD2330: MOV x19, x0                | X19 = 1152921513716888368 (0x100000021F003330);//ML01
            val_5 = this;
            // 0x00AD2334: TBNZ w8, #0, #0xad2350     | if (static_value_037334D0 == true) goto label_0;
            // 0x00AD2338: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00AD233C: LDR x8, [x8, #0xc20]       | X8 = 0x2B8F9B4;                         
            // 0x00AD2340: LDR w0, [x8]               | W0 = 0x1531;                            
            // 0x00AD2344: BL #0x2782188              | X0 = sub_2782188( ?? 0x1531, ????);     
            // 0x00AD2348: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD234C: STRB w8, [x20, #0x4d0]     | static_value_037334D0 = true;            //  dest_result_addr=57881808
            label_0:
            // 0x00AD2350: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2354: MOV x0, x19                | X0 = 1152921513716888368 (0x100000021F003330);//ML01
            // 0x00AD2358: LDP x9, x1, [x8, #0x1c0]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_1C0; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_1C8; //  | 
            // 0x00AD235C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_1C0();
            // 0x00AD2360: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2364: MOV x0, x19                | X0 = 1152921513716888368 (0x100000021F003330);//ML01
            // 0x00AD2368: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD236C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD2370: CMP w0, #0xb               | STATE = COMPARE(this, 0xB)              
            // 0x00AD2374: B.EQ #0xad23f0             | if (val_5 == 0xB) goto label_3;         
            if(val_5 == 11)
            {
                goto label_3;
            }
            // 0x00AD2378: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD237C: MOV x0, x19                | X0 = 1152921513716888368 (0x100000021F003330);//ML01
            // 0x00AD2380: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD2384: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD2388: CMP w0, #0x11              | STATE = COMPARE(this, 0x11)             
            // 0x00AD238C: B.NE #0xad2408             | if (val_5 != 0x11) goto label_2;        
            if(val_5 != 17)
            {
                goto label_2;
            }
            // 0x00AD2390: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2394: MOV x0, x19                | X0 = 1152921513716888368 (0x100000021F003330);//ML01
            // 0x00AD2398: LDP x9, x1, [x8, #0x190]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_198; //  | 
            // 0x00AD239C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190();
            // 0x00AD23A0: MOV x20, x0                | X20 = 1152921513716888368 (0x100000021F003330);//ML01
            // 0x00AD23A4: CBZ x20, #0xad23f0         | if (this == null) goto label_3;         
            if(this == null)
            {
                goto label_3;
            }
            // 0x00AD23A8: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00AD23AC: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00AD23B0: MOV x0, x20                | X0 = 1152921513716888368 (0x100000021F003330);//ML01
            val_6 = val_5;
            // 0x00AD23B4: LDR x19, [x8]              | X19 = typeof(System.Byte[]);            
            val_5 = null;
            // 0x00AD23B8: MOV x1, x19                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD23BC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this, ????);       
            // 0x00AD23C0: CBNZ x0, #0xad23f4         | if (this != null) goto label_4;         
            if(this != null)
            {
                goto label_4;
            }
            // 0x00AD23C4: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD23C8: MOV x1, x19                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD23CC: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class;
            // 0x00AD23D0: ADD x8, sp, #8             | X8 = (1152921513716876304 + 8) = 1152921513716876312 (0x100000021F000418);
            // 0x00AD23D4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class, ????);
            // 0x00AD23D8: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513716864368]
            // 0x00AD23DC: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x00AD23E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD23E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x00AD23E8: ADD x0, sp, #8             | X0 = (1152921513716876304 + 8) = 1152921513716876312 (0x100000021F000418);
            // 0x00AD23EC: BL #0x299a140              | 
            label_3:
            // 0x00AD23F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_6 = 0;
            label_4:
            // 0x00AD23F4: SUB sp, x29, #0x20         | SP = (1152921513716876352 - 32) = 1152921513716876320 (0x100000021F000420);
            // 0x00AD23F8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD23FC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD2400: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD2404: RET                        |  return (System.Byte[])null;            
            return (System.Byte[])val_6;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
            label_2:
            // 0x00AD2408: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD240C: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD2410: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD2414: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD2418: TBZ w8, #0, #0xad2428      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AD241C: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD2420: CBNZ w8, #0xad2428         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AD2424: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_6:
            // 0x00AD2428: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD242C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2430: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_2 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD2434: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AD2438: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AD243C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00AD2440: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00AD2444: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2448: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AD244C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD2450: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2454: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AD2458: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD245C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2460: MOV x0, x19                | X0 = 1152921513716888368 (0x100000021F003330);//ML01
            // 0x00AD2464: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD2468: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD246C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00AD2470: LDR x8, [x8, #0xb48]       | X8 = 1152921504860467200;               
            // 0x00AD2474: STR w0, [sp, #4]           | stack[1152921513716876308] = this;       //  dest_result_addr=1152921513716876308
            // 0x00AD2478: ADD x1, sp, #4             | X1 = (1152921513716876304 + 4) = 1152921513716876308 (0x100000021F000414);
            // 0x00AD247C: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonToken); 
            // 0x00AD2480: MOV x0, x8                 | X0 = 1152921504860467200 (0x100000000F1DF000);//ML01
            // 0x00AD2484: BL #0x27bc028              | X0 = 1152921513716924464 = (Il2CppObject*)Box((RuntimeClass*)typeof(Newtonsoft.Json.JsonToken), this);
            // 0x00AD2488: MOV x19, x0                | X19 = 1152921513716924464 (0x100000021F00C030);//ML01
            // 0x00AD248C: CBNZ x21, #0xad2494        | if ( != null) goto label_7;             
            if(null != null)
            {
                goto label_7;
            }
            // 0x00AD2490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_7:
            // 0x00AD2494: CBZ x19, #0xad24b8         | if (this == 0) goto label_9;            
            if(val_5 == 0)
            {
                goto label_9;
            }
            // 0x00AD2498: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AD249C: MOV x0, x19                | X0 = 1152921513716924464 (0x100000021F00C030);//ML01
            // 0x00AD24A0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AD24A4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this, ????);       
            // 0x00AD24A8: CBNZ x0, #0xad24b8         | if (this != 0) goto label_9;            
            if(val_5 != 0)
            {
                goto label_9;
            }
            // 0x00AD24AC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this, ????);       
            // 0x00AD24B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD24B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_9:
            // 0x00AD24B8: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AD24BC: CBNZ w8, #0xad24cc         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_10;
            // 0x00AD24C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x00AD24C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD24C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_10:
            // 0x00AD24CC: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = this;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_5;
            // 0x00AD24D0: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00AD24D4: LDR x8, [x8, #0x8d0]       | X8 = (string**)(1152921513716859072)("Error reading bytes. Expected bytes but got {0}.");
            // 0x00AD24D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD24DC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD24E0: MOV x2, x20                | X2 = val_2;//m1                         
            // 0x00AD24E4: LDR x1, [x8]               | X1 = "Error reading bytes. Expected bytes but got {0}.";
            // 0x00AD24E8: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD24EC: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Error reading bytes. Expected bytes but got {0}.", args:  val_2);
            string val_3 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Error reading bytes. Expected bytes but got {0}.", args:  val_2);
            // 0x00AD24F0: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00AD24F4: LDR x8, [x8, #0xde8]       | X8 = 1152921504860094464;               
            // 0x00AD24F8: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x00AD24FC: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonReaderException);
            // 0x00AD2500: MOV x0, x8                 | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            Newtonsoft.Json.JsonReaderException val_4 = null;
            // 0x00AD2504: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2508: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD250C: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x00AD2510: MOV x20, x0                | X20 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2514: BL #0x13139e4              | .ctor(message:  val_3);                 
            val_4 = new Newtonsoft.Json.JsonReaderException(message:  val_3);
            // 0x00AD2518: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00AD251C: LDR x8, [x8, #0x958]       | X8 = 1152921513716863344;               
            // 0x00AD2520: MOV x0, x20                | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2524: LDR x1, [x8]               | X1 = public System.Byte[] Newtonsoft.Json.Bson.BsonReader::ReadAsBytes();
            // 0x00AD2528: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD252C: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
            // 0x00AD2530: MOV x19, x0                | X19 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2534: ADD x0, sp, #8             | X0 = (1152921513716876304 + 8) = 1152921513716876312 (0x100000021F000418);
            // 0x00AD2538: BL #0x299a140              | 
            // 0x00AD253C: MOV x0, x19                | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2540: BL #0x980800               | X0 = sub_980800( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD2544 (11347268), len: 812  VirtAddr: 0x00AD2544 RVA: 0x00AD2544 token: 100684734 methodIndex: 47394 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Nullable<System.Decimal> ReadAsDecimal()
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_7;
            //  | 
            System.IFormatProvider val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00AD2544: STP x22, x21, [sp, #-0x30]! | stack[1152921513717024336] = ???;  stack[1152921513717024344] = ???;  //  dest_result_addr=1152921513717024336 |  dest_result_addr=1152921513717024344
            // 0x00AD2548: STP x20, x19, [sp, #0x10]  | stack[1152921513717024352] = ???;  stack[1152921513717024360] = ???;  //  dest_result_addr=1152921513717024352 |  dest_result_addr=1152921513717024360
            // 0x00AD254C: STP x29, x30, [sp, #0x20]  | stack[1152921513717024368] = ???;  stack[1152921513717024376] = ???;  //  dest_result_addr=1152921513717024368 |  dest_result_addr=1152921513717024376
            // 0x00AD2550: ADD x29, sp, #0x20         | X29 = (1152921513717024336 + 32) = 1152921513717024368 (0x100000021F024670);
            // 0x00AD2554: SUB sp, sp, #0x20          | SP = (1152921513717024336 - 32) = 1152921513717024304 (0x100000021F024630);
            // 0x00AD2558: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD255C: LDRB w9, [x21, #0x4d1]     | W9 = (bool)static_value_037334D1;       
            // 0x00AD2560: MOV x19, x0                | X19 = 1152921513717036384 (0x100000021F027560);//ML01
            val_8 = this;
            // 0x00AD2564: MOV x20, x8                | X20 = X8;//m1                           
            // 0x00AD2568: TBNZ w9, #0, #0xad2584     | if (static_value_037334D1 == true) goto label_0;
            // 0x00AD256C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00AD2570: LDR x8, [x8, #0x520]       | X8 = 0x2B8F9BC;                         
            // 0x00AD2574: LDR w0, [x8]               | W0 = 0x1533;                            
            // 0x00AD2578: BL #0x2782188              | X0 = sub_2782188( ?? 0x1533, ????);     
            // 0x00AD257C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD2580: STRB w8, [x21, #0x4d1]     | static_value_037334D1 = true;            //  dest_result_addr=57881809
            label_0:
            // 0x00AD2584: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2588: MOV x0, x19                | X0 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD258C: LDP x9, x1, [x8, #0x1c0]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_1C0; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_1C8; //  | 
            // 0x00AD2590: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_1C0();
            // 0x00AD2594: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2598: MOV x0, x19                | X0 = 1152921513717036384 (0x100000021F027560);//ML01
            val_9 = val_8;
            // 0x00AD259C: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD25A0: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD25A4: CMP w0, #0xb               | STATE = COMPARE(this, 0xB)              
            // 0x00AD25A8: B.NE #0xad25b8             | if (val_9 != 0xB) goto label_1;         
            if(val_9 != 11)
            {
                goto label_1;
            }
            // 0x00AD25AC: STR wzr, [x20, #0x10]      | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x00AD25B0: STP xzr, xzr, [x20]        | mem2[0] = 0x0;  mem2[0] = 0x0;           //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 0;
            mem2[0] = 0;
            // 0x00AD25B4: B #0xad26fc                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00AD25B8: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD25BC: MOV x0, x19                | X0 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD25C0: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD25C4: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD25C8: CMP w0, #7                 | STATE = COMPARE(this, 0x7)              
            // 0x00AD25CC: B.EQ #0xad25e8             | if (val_8 == 0x7) goto label_3;         
            if(val_8 == 7)
            {
                goto label_3;
            }
            // 0x00AD25D0: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD25D4: MOV x0, x19                | X0 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD25D8: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD25DC: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD25E0: CMP w0, #8                 | STATE = COMPARE(this, 0x8)              
            // 0x00AD25E4: B.NE #0xad2734             | if (val_8 != 0x8) goto label_4;         
            if(val_8 != 8)
            {
                goto label_4;
            }
            label_3:
            // 0x00AD25E8: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD25EC: MOV x0, x19                | X0 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD25F0: LDP x9, x1, [x8, #0x190]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_198; //  | 
            // 0x00AD25F4: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190();
            // 0x00AD25F8: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD25FC: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD2600: MOV x21, x0                | X21 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD2604: LDR x8, [x8]               | X8 = typeof(System.Globalization.CultureInfo);
            // 0x00AD2608: LDRB w9, [x8, #0x10a]      | W9 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD260C: TBZ w9, #0, #0xad2620      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AD2610: LDR w9, [x8, #0xbc]        | W9 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD2614: CBNZ w9, #0xad2620         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AD2618: MOV x0, x8                 | X0 = 1152921504619892736 (0x1000000000C71000);//ML01
            // 0x00AD261C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_6:
            // 0x00AD2620: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD2624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2628: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_1 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD262C: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00AD2630: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x00AD2634: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x00AD2638: LDR x8, [x8]               | X8 = typeof(System.Convert);            
            // 0x00AD263C: LDRB w9, [x8, #0x10a]      | W9 = System.Convert.__il2cppRuntimeField_10A;
            // 0x00AD2640: TBZ w9, #0, #0xad2654      | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00AD2644: LDR w9, [x8, #0xbc]        | W9 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x00AD2648: CBNZ w9, #0xad2654         | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00AD264C: MOV x0, x8                 | X0 = 1152921504652587008 (0x1000000002B9F000);//ML01
            // 0x00AD2650: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_8:
            // 0x00AD2654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD2658: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD265C: MOV x1, x21                | X1 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD2660: MOV x2, x22                | X2 = val_1;//m1                         
            // 0x00AD2664: BL #0x1ba4bb8              | X0 = System.Convert.ToDecimal(value:  0, provider:  this);
            decimal val_2 = System.Convert.ToDecimal(value:  0, provider:  this);
            // 0x00AD2668: ADRP x21, #0x3608000       | X21 = 56655872 (0x3608000);             
            // 0x00AD266C: LDR x21, [x21, #0x480]     | X21 = 1152921504608550912;              
            // 0x00AD2670: LDR x8, [x21]              | X8 = typeof(System.Decimal);            
            // 0x00AD2674: STP x0, x1, [sp, #8]       | stack[1152921513717024312] = val_2.flags; stack[1152921513717024316] = val_2.hi;  stack[1152921513717024320] = val_2.lo; stack[1152921513717024324] = val_2.mid;  //  dest_result_addr=1152921513717024312 dest_result_addr=1152921513717024316 |  dest_result_addr=1152921513717024320 dest_result_addr=1152921513717024324
            // 0x00AD2678: ADD x1, sp, #8             | X1 = (1152921513717024304 + 8) = 1152921513717024312 (0x100000021F024638);
            // 0x00AD267C: MOV x0, x8                 | X0 = 1152921504608550912 (0x10000000001A0000);//ML01
            // 0x00AD2680: BL #0x27bc028              | X0 = 1152921513717073504 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Decimal), val_2);
            // 0x00AD2684: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2688: MOV x2, x0                 | X2 = 1152921513717073504 (0x100000021F030660);//ML01
            // 0x00AD268C: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x00AD2690: MOV x0, x19                | X0 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD2694: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD2698: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            // 0x00AD269C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200();
            // 0x00AD26A0: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD26A4: MOV x0, x19                | X0 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD26A8: LDP x9, x1, [x8, #0x190]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_198; //  | 
            // 0x00AD26AC: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190();
            // 0x00AD26B0: LDR x21, [x21]             | X21 = typeof(System.Decimal);           
            val_7 = null;
            // 0x00AD26B4: MOV x19, x0                | X19 = 1152921513717036384 (0x100000021F027560);//ML01
            val_8 = val_8;
            // 0x00AD26B8: STR wzr, [x20, #0x10]      | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x00AD26BC: STP xzr, xzr, [x20]        | mem2[0] = 0x0;  mem2[0] = 0x0;           //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 0;
            mem2[0] = 0;
            // 0x00AD26C0: CBNZ x19, #0xad26c8        | if (this != null) goto label_9;         
            if(this != null)
            {
                goto label_9;
            }
            // 0x00AD26C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_9:
            // 0x00AD26C8: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD26CC: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class;
            // 0x00AD26D0: LDR x8, [x21, #0x30]       | X8 = System.Decimal.__il2cppRuntimeField_element_class;
            // 0x00AD26D4: CMP x0, x8                 | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class, System.Decimal.__il2cppRuntimeField_element_class)
            // 0x00AD26D8: B.NE #0xad2710             | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class != System.Decimal.__il2cppRuntimeField_element_class) goto label_10;
            // 0x00AD26DC: MOV x0, x19                | X0 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD26E0: BL #0x27bc4e8              | this.System.IDisposable.Dispose();      
            this.System.IDisposable.Dispose();
            // 0x00AD26E4: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x00AD26E8: LDP x1, x2, [x0]           | X1 = typeof(Newtonsoft.Json.Bson.BsonReader);  //  | 
            // 0x00AD26EC: LDR x8, [x8, #0x6e8]       | X8 = 1152921513716997872;               
            // 0x00AD26F0: MOV x0, x20                | X0 = X8;//m1                            
            val_9 = X8;
            // 0x00AD26F4: LDR x3, [x8]               | X3 = public System.Void System.Nullable<System.Decimal>::.ctor(System.Decimal value);
            // 0x00AD26F8: BL #0x1d6ac1c              | X0 = sub_1D6AC1C( ?? X8, ????);         
            label_2:
            // 0x00AD26FC: SUB sp, x29, #0x20         | SP = (1152921513717024368 - 32) = 1152921513717024336 (0x100000021F024650);
            // 0x00AD2700: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD2704: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD2708: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD270C: RET                        |  return (System.Nullable<System.Decimal>)X8;
            return (System.Nullable<System.Decimal>)val_9;
            //  |  // // {name=val_0.HasValue, type=System.Boolean, size=1, nGRN=0 offset=0 }
            label_10:
            // 0x00AD2710: ADD x8, sp, #0x18          | X8 = (1152921513717024304 + 24) = 1152921513717024328 (0x100000021F024648);
            // 0x00AD2714: MOV x1, x21                | X1 = 1152921504608550912 (0x10000000001A0000);//ML01
            // 0x00AD2718: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class, ????);
            // 0x00AD271C: LDR x0, [sp, #0x18]        | X0 = val_3;                              //  find_add[1152921513717012384]
            // 0x00AD2720: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x00AD2724: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2728: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x00AD272C: ADD x0, sp, #0x18          | X0 = (1152921513717024304 + 24) = 1152921513717024328 (0x100000021F024648);
            // 0x00AD2730: BL #0x299a140              | 
            label_4:
            // 0x00AD2734: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD2738: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD273C: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD2740: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD2744: TBZ w8, #0, #0xad2754      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00AD2748: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD274C: CBNZ w8, #0xad2754         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00AD2750: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_12:
            // 0x00AD2754: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD2758: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD275C: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_4 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD2760: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AD2764: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AD2768: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x00AD276C: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00AD2770: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2774: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AD2778: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD277C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2780: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AD2784: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2788: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD278C: MOV x0, x19                | X0 = 1152921513717036384 (0x100000021F027560);//ML01
            // 0x00AD2790: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD2794: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD2798: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00AD279C: LDR x8, [x8, #0xb48]       | X8 = 1152921504860467200;               
            // 0x00AD27A0: STR w0, [sp, #8]           | stack[1152921513717024312] = this;       //  dest_result_addr=1152921513717024312
            // 0x00AD27A4: ADD x1, sp, #8             | X1 = (1152921513717024304 + 8) = 1152921513717024312 (0x100000021F024638);
            // 0x00AD27A8: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonToken); 
            // 0x00AD27AC: MOV x0, x8                 | X0 = 1152921504860467200 (0x100000000F1DF000);//ML01
            // 0x00AD27B0: BL #0x27bc028              | X0 = 1152921513717081696 = (Il2CppObject*)Box((RuntimeClass*)typeof(Newtonsoft.Json.JsonToken), this);
            // 0x00AD27B4: MOV x19, x0                | X19 = 1152921513717081696 (0x100000021F032660);//ML01
            // 0x00AD27B8: CBNZ x21, #0xad27c0        | if ( != null) goto label_13;            
            if(null != null)
            {
                goto label_13;
            }
            // 0x00AD27BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_13:
            // 0x00AD27C0: CBZ x19, #0xad27e4         | if (this == 0) goto label_15;           
            if(val_8 == 0)
            {
                goto label_15;
            }
            // 0x00AD27C4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AD27C8: MOV x0, x19                | X0 = 1152921513717081696 (0x100000021F032660);//ML01
            // 0x00AD27CC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AD27D0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this, ????);       
            // 0x00AD27D4: CBNZ x0, #0xad27e4         | if (this != 0) goto label_15;           
            if(val_8 != 0)
            {
                goto label_15;
            }
            // 0x00AD27D8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this, ????);       
            // 0x00AD27DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD27E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_15:
            // 0x00AD27E4: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AD27E8: CBNZ w8, #0xad27f8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_16;
            // 0x00AD27EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x00AD27F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD27F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_16:
            // 0x00AD27F8: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = this;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_8;
            // 0x00AD27FC: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x00AD2800: LDR x8, [x8, #0xa30]       | X8 = (string**)(1152921513717007088)("Error reading decimal. Expected a number but got {0}.");
            // 0x00AD2804: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD2808: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD280C: MOV x2, x20                | X2 = val_4;//m1                         
            // 0x00AD2810: LDR x1, [x8]               | X1 = "Error reading decimal. Expected a number but got {0}.";
            // 0x00AD2814: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2818: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Error reading decimal. Expected a number but got {0}.", args:  val_4);
            string val_5 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Error reading decimal. Expected a number but got {0}.", args:  val_4);
            // 0x00AD281C: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00AD2820: LDR x8, [x8, #0xde8]       | X8 = 1152921504860094464;               
            // 0x00AD2824: MOV x19, x0                | X19 = val_5;//m1                        
            // 0x00AD2828: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonReaderException);
            // 0x00AD282C: MOV x0, x8                 | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            Newtonsoft.Json.JsonReaderException val_6 = null;
            // 0x00AD2830: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2834: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD2838: MOV x1, x19                | X1 = val_5;//m1                         
            // 0x00AD283C: MOV x20, x0                | X20 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2840: BL #0x13139e4              | .ctor(message:  val_5);                 
            val_6 = new Newtonsoft.Json.JsonReaderException(message:  val_5);
            // 0x00AD2844: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00AD2848: LDR x8, [x8, #0x438]       | X8 = 1152921513717011360;               
            // 0x00AD284C: MOV x0, x20                | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2850: LDR x1, [x8]               | X1 = public System.Nullable<System.Decimal> Newtonsoft.Json.Bson.BsonReader::ReadAsDecimal();
            // 0x00AD2854: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2858: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
            // 0x00AD285C: MOV x19, x0                | X19 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2860: ADD x0, sp, #0x18          | X0 = (1152921513717024304 + 24) = 1152921513717024328 (0x100000021F024648);
            // 0x00AD2864: BL #0x299a140              | 
            // 0x00AD2868: MOV x0, x19                | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD286C: BL #0x980800               | X0 = sub_980800( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD2870 (11348080), len: 836  VirtAddr: 0x00AD2870 RVA: 0x00AD2870 token: 100684735 methodIndex: 47395 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Nullable<System.DateTimeOffset> ReadAsDateTimeOffset()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            // 0x00AD2870: STP x22, x21, [sp, #-0x30]! | stack[1152921513717176448] = ???;  stack[1152921513717176456] = ???;  //  dest_result_addr=1152921513717176448 |  dest_result_addr=1152921513717176456
            // 0x00AD2874: STP x20, x19, [sp, #0x10]  | stack[1152921513717176464] = ???;  stack[1152921513717176472] = ???;  //  dest_result_addr=1152921513717176464 |  dest_result_addr=1152921513717176472
            // 0x00AD2878: STP x29, x30, [sp, #0x20]  | stack[1152921513717176480] = ???;  stack[1152921513717176488] = ???;  //  dest_result_addr=1152921513717176480 |  dest_result_addr=1152921513717176488
            // 0x00AD287C: ADD x29, sp, #0x20         | X29 = (1152921513717176448 + 32) = 1152921513717176480 (0x100000021F0498A0);
            // 0x00AD2880: SUB sp, sp, #0x60          | SP = (1152921513717176448 - 96) = 1152921513717176352 (0x100000021F049820);
            // 0x00AD2884: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD2888: LDRB w9, [x21, #0x4d2]     | W9 = (bool)static_value_037334D2;       
            // 0x00AD288C: MOV x20, x0                | X20 = 1152921513717188496 (0x100000021F04C790);//ML01
            // 0x00AD2890: MOV x19, x8                | X19 = X8;//m1                           
            // 0x00AD2894: TBNZ w9, #0, #0xad28b0     | if (static_value_037334D2 == true) goto label_0;
            // 0x00AD2898: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AD289C: LDR x8, [x8, #0x860]       | X8 = 0x2B8F9B8;                         
            // 0x00AD28A0: LDR w0, [x8]               | W0 = 0x1532;                            
            // 0x00AD28A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1532, ????);     
            // 0x00AD28A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD28AC: STRB w8, [x21, #0x4d2]     | static_value_037334D2 = true;            //  dest_result_addr=57881810
            label_0:
            // 0x00AD28B0: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD28B4: MOV x0, x20                | X0 = 1152921513717188496 (0x100000021F04C790);//ML01
            // 0x00AD28B8: LDP x9, x1, [x8, #0x1c0]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_1C0; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_1C8; //  | 
            // 0x00AD28BC: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_1C0();
            // 0x00AD28C0: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD28C4: MOV x0, x20                | X0 = 1152921513717188496 (0x100000021F04C790);//ML01
            val_10 = this;
            // 0x00AD28C8: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD28CC: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD28D0: CMP w0, #0xb               | STATE = COMPARE(this, 0xB)              
            // 0x00AD28D4: B.NE #0xad28e4             | if (val_10 != 0xB) goto label_1;        
            if(val_10 != 11)
            {
                goto label_1;
            }
            // 0x00AD28D8: STP xzr, xzr, [x19, #0x10] | mem2[0] = 0x0;  mem2[0] = 0x0;           //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 0;
            mem2[0] = 0;
            // 0x00AD28DC: STP xzr, xzr, [x19]        | mem2[0] = 0x0;  mem2[0] = 0x0;           //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 0;
            mem2[0] = 0;
            // 0x00AD28E0: B #0xad2a34                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00AD28E4: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD28E8: MOV x0, x20                | X0 = 1152921513717188496 (0x100000021F04C790);//ML01
            // 0x00AD28EC: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD28F0: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD28F4: CMP w0, #0x10              | STATE = COMPARE(this, 0x10)             
            // 0x00AD28F8: B.NE #0xad2a5c             | if (this != 0x10) goto label_3;         
            if(this != 16)
            {
                goto label_3;
            }
            // 0x00AD28FC: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2900: MOV x0, x20                | X0 = 1152921513717188496 (0x100000021F04C790);//ML01
            // 0x00AD2904: LDP x9, x1, [x8, #0x190]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_198; //  | 
            // 0x00AD2908: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190();
            // 0x00AD290C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00AD2910: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
            // 0x00AD2914: MOV x21, x0                | X21 = 1152921513717188496 (0x100000021F04C790);//ML01
            // 0x00AD2918: LDR x22, [x8]              | X22 = typeof(System.DateTime);          
            // 0x00AD291C: STP xzr, xzr, [sp, #0x40]  | stack[1152921513717176416] = 0x0;  stack[1152921513717176424] = 0x0;  //  dest_result_addr=1152921513717176416 |  dest_result_addr=1152921513717176424
            // 0x00AD2920: STR xzr, [sp, #0x38]       | stack[1152921513717176408] = 0x0;        //  dest_result_addr=1152921513717176408
            // 0x00AD2924: CBNZ x21, #0xad292c        | if (this != null) goto label_4;         
            if(this != null)
            {
                goto label_4;
            }
            // 0x00AD2928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x00AD292C: LDR x8, [x21]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2930: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class;
            // 0x00AD2934: LDR x8, [x22, #0x30]       | X8 = System.DateTime.__il2cppRuntimeField_element_class;
            // 0x00AD2938: CMP x0, x8                 | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class, System.DateTime.__il2cppRuntimeField_element_class)
            // 0x00AD293C: B.NE #0xad2b84             | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class != System.DateTime.__il2cppRuntimeField_element_class) goto label_5;
            // 0x00AD2940: MOV x0, x21                | X0 = 1152921513717188496 (0x100000021F04C790);//ML01
            // 0x00AD2944: BL #0x27bc4e8              | this.System.IDisposable.Dispose();      
            this.System.IDisposable.Dispose();
            // 0x00AD2948: LDP x1, x2, [x0]           | X1 = typeof(Newtonsoft.Json.Bson.BsonReader);  //  | 
            // 0x00AD294C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD2950: ADD x0, sp, #0x38          | X0 = (1152921513717176352 + 56) = 1152921513717176408 (0x100000021F049858);
            // 0x00AD2954: BL #0x1c28be8              | X0 = label_ILRuntime_Runtime_Generated_CSHeroUnit_Binding_set_movespeed_9_GL01C28BE8();
            // 0x00AD2958: ADRP x21, #0x35cd000       | X21 = 56414208 (0x35CD000);             
            // 0x00AD295C: LDR x8, [sp, #0x48]        | X8 = 0x0;                               
            // 0x00AD2960: LDUR q0, [sp, #0x38]       | Q0 = 0x0;                               
            // 0x00AD2964: LDR x21, [x21, #0x6a8]     | X21 = 1152921504652853248;              
            // 0x00AD2968: ADD x1, sp, #0x20          | X1 = (1152921513717176352 + 32) = 1152921513717176384 (0x100000021F049840);
            // 0x00AD296C: STR x8, [sp, #0x30]        | stack[1152921513717176400] = 0x0;        //  dest_result_addr=1152921513717176400
            // 0x00AD2970: LDR x0, [x21]              | X0 = typeof(System.DateTimeOffset);     
            // 0x00AD2974: STR q0, [sp, #0x20]        | stack[1152921513717176384] = 0x0;        //  dest_result_addr=1152921513717176384
            // 0x00AD2978: BL #0x27bc028              | X0 = 1152921513717220496 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.DateTimeOffset), null);
            // 0x00AD297C: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2980: MOV x2, x0                 | X2 = 1152921513717220496 (0x100000021F054490);//ML01
            // 0x00AD2984: ORR w1, wzr, #0x10         | W1 = 16(0x10);                          
            // 0x00AD2988: MOV x0, x20                | X0 = 1152921513717188496 (0x100000021F04C790);//ML01
            // 0x00AD298C: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD2990: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            // 0x00AD2994: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200();
            // 0x00AD2998: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD299C: MOV x0, x20                | X0 = 1152921513717188496 (0x100000021F04C790);//ML01
            // 0x00AD29A0: LDP x9, x1, [x8, #0x190]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_198; //  | 
            // 0x00AD29A4: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_190();
            // 0x00AD29A8: LDR x21, [x21]             | X21 = typeof(System.DateTimeOffset);    
            val_9 = null;
            // 0x00AD29AC: MOV x20, x0                | X20 = 1152921513717188496 (0x100000021F04C790);//ML01
            // 0x00AD29B0: STR xzr, [x19, #0x18]      | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x00AD29B4: STP xzr, xzr, [x19, #8]    | mem2[0] = 0x0;  mem2[0] = 0x0;           //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 0;
            mem2[0] = 0;
            // 0x00AD29B8: STR xzr, [x19]             | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x00AD29BC: CBNZ x20, #0xad29c4        | if (this != null) goto label_6;         
            if(this != null)
            {
                goto label_6;
            }
            // 0x00AD29C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x00AD29C4: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD29C8: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class;
            // 0x00AD29CC: LDR x8, [x21, #0x30]       | X8 = System.DateTimeOffset.__il2cppRuntimeField_element_class;
            // 0x00AD29D0: CMP x0, x8                 | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class, System.DateTimeOffset.__il2cppRuntimeField_element_class)
            // 0x00AD29D4: B.EQ #0xad2a04             | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class == System.DateTimeOffset.__il2cppRuntimeField_element_class) goto label_7;
            // 0x00AD29D8: SUB x8, x29, #0x28         | X8 = (1152921513717176480 - 40) = 1152921513717176440 (0x100000021F049878);
            // 0x00AD29DC: MOV x1, x21                | X1 = 1152921504652853248 (0x1000000002BE0000);//ML01
            // 0x00AD29E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_element_class, ????);
            // 0x00AD29E4: LDUR x0, [x29, #-0x28]     | X0 = val_1;                              //  find_add[1152921513717164496]
            // 0x00AD29E8: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x00AD29EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD29F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x00AD29F4: SUB x0, x29, #0x28         | X0 = (1152921513717176480 - 40) = 1152921513717176440 (0x100000021F049878);
            // 0x00AD29F8: BL #0x299a140              | 
            // 0x00AD29FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_11 = 0;
            // 0x00AD2A00: B #0xad2a0c                |  goto label_8;                          
            goto label_8;
            label_7:
            // 0x00AD2A04: MOV x0, x20                | X0 = 1152921513717188496 (0x100000021F04C790);//ML01
            val_11 = this;
            // 0x00AD2A08: BL #0x27bc4e8              | this.System.IDisposable.Dispose();      
            this.System.IDisposable.Dispose();
            label_8:
            // 0x00AD2A0C: LDR x8, [x0, #0x10]        | 
            // 0x00AD2A10: MOV x1, sp                 | X1 = 1152921513717176352 (0x100000021F049820);//ML01
            // 0x00AD2A14: STR x8, [sp, #0x10]        | stack[1152921513717176368] = System.DateTimeOffset.__il2cppRuntimeField_element_class;  //  dest_result_addr=1152921513717176368
            // 0x00AD2A18: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
            // 0x00AD2A1C: LDR q0, [x0]               | Q0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD2A20: LDR x8, [x8, #0x5c8]       | X8 = 1152921513717149984;               
            // 0x00AD2A24: MOV x0, x19                | X0 = X8;//m1                            
            val_10 = X8;
            // 0x00AD2A28: STR q0, [sp]               | stack[1152921513717176352] = typeof(Newtonsoft.Json.Bson.BsonReader);  //  dest_result_addr=1152921513717176352
            // 0x00AD2A2C: LDR x2, [x8]               | X2 = public System.Void System.Nullable<System.DateTimeOffset>::.ctor(System.DateTimeOffset value);
            // 0x00AD2A30: BL #0x1d6a4e4              | X0 = sub_1D6A4E4( ?? X8, ????);         
            label_2:
            // 0x00AD2A34: SUB sp, x29, #0x20         | SP = (1152921513717176480 - 32) = 1152921513717176448 (0x100000021F049880);
            // 0x00AD2A38: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD2A3C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD2A40: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD2A44: RET                        |  return (System.Nullable<System.DateTimeOffset>)X8;
            return (System.Nullable<System.DateTimeOffset>)val_10;
            //  |  // // {name=val_0.HasValue, type=System.Boolean, size=1, nGRN=0 offset=0 }
            // 0x00AD2A48: MOV x19, x0                | X19 = X8;//m1                           
            // 0x00AD2A4C: SUB x0, x29, #0x28         | X0 = (??? - 40);                        
            var val_2 = (???) - 40;
            label_15:
            // 0x00AD2A50: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)(??? - 40)); //ERROR_TYPE
            // 0x00AD2A54: MOV x0, x19                | X0 = X8;//m1                            
            // 0x00AD2A58: BL #0x980800               | X0 = sub_980800( ?? X8, ????);          
            label_3:
            // 0x00AD2A5C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD2A60: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD2A64: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD2A68: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD2A6C: TBZ w8, #0, #0xad2a7c      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00AD2A70: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD2A74: CBNZ w8, #0xad2a7c         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00AD2A78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_10:
            // 0x00AD2A7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD2A80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2A84: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_3 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD2A88: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AD2A8C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AD2A90: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x00AD2A94: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00AD2A98: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2A9C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AD2AA0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD2AA4: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2AA8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AD2AAC: LDR x8, [x20]              | X8 = ;                                  
            // 0x00AD2AB0: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2AB4: MOV x0, x20                | X0 = X20;//m1                           
            // 0x00AD2AB8: LDP x9, x1, [x8, #0x180]   | X9 = ??? + 384; X1 = ??? + 384 + 8;      //  | 
            // 0x00AD2ABC: BLR x9                     | X0 = ??? + 384();                       
            // 0x00AD2AC0: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00AD2AC4: LDR x8, [x8, #0xb48]       | X8 = 1152921504860467200;               
            // 0x00AD2AC8: STR w0, [sp, #0x38]        | stack[1152921513717176552] = ;           //  dest_result_addr=1152921513717176552
            // 0x00AD2ACC: ADD x1, sp, #0x38          | X1 = (1152921513717176496 + 56) = 1152921513717176552 (0x100000021F0498E8);
            // 0x00AD2AD0: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonToken); 
            // 0x00AD2AD4: MOV x0, x8                 | X0 = 1152921504860467200 (0x100000000F1DF000);//ML01
            // 0x00AD2AD8: BL #0x27bc028              | X0 = 1152921513717228688 = (Il2CppObject*)Box((RuntimeClass*)typeof(Newtonsoft.Json.JsonToken), );
            // 0x00AD2ADC: MOV x20, x0                | X20 = 1152921513717228688 (0x100000021F056490);//ML01
            // 0x00AD2AE0: CBNZ x21, #0xad2ae8        | if ( != null) goto label_11;            
            if(null != null)
            {
                goto label_11;
            }
            // 0x00AD2AE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ???, ????);        
            label_11:
            // 0x00AD2AE8: CBZ x20, #0xad2b0c         | if (??? == 0) goto label_13;            
            if((???) == 0)
            {
                goto label_13;
            }
            // 0x00AD2AEC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AD2AF0: MOV x0, x20                | X0 = 1152921513717228688 (0x100000021F056490);//ML01
            // 0x00AD2AF4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AD2AF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ???, ????);        
            // 0x00AD2AFC: CBNZ x0, #0xad2b0c         | if (??? != 0) goto label_13;            
            if((???) != 0)
            {
                goto label_13;
            }
            // 0x00AD2B00: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ???, ????);        
            // 0x00AD2B04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2B08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ???, ????);        
            label_13:
            // 0x00AD2B0C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AD2B10: CBNZ w8, #0xad2b20         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_14;
            // 0x00AD2B14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ???, ????);        
            // 0x00AD2B18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2B1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ???, ????);        
            label_14:
            // 0x00AD2B20: STR x20, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 0x100000021F056490;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = ???;
            // 0x00AD2B24: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00AD2B28: LDR x8, [x8, #0x568]       | X8 = (string**)(1152921513717159200)("Error reading date. Expected bytes but got {0}.");
            // 0x00AD2B2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD2B30: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD2B34: MOV x2, x19                | X2 = val_3;//m1                         
            // 0x00AD2B38: LDR x1, [x8]               | X1 = "Error reading date. Expected bytes but got {0}.";
            // 0x00AD2B3C: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2B40: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Error reading date. Expected bytes but got {0}.", args:  val_3);
            string val_4 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Error reading date. Expected bytes but got {0}.", args:  val_3);
            // 0x00AD2B44: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00AD2B48: LDR x8, [x8, #0xde8]       | X8 = 1152921504860094464;               
            // 0x00AD2B4C: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x00AD2B50: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonReaderException);
            // 0x00AD2B54: MOV x0, x8                 | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            Newtonsoft.Json.JsonReaderException val_5 = null;
            // 0x00AD2B58: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2B5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD2B60: MOV x1, x19                | X1 = val_4;//m1                         
            // 0x00AD2B64: MOV x20, x0                | X20 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2B68: BL #0x13139e4              | .ctor(message:  val_4);                 
            val_5 = new Newtonsoft.Json.JsonReaderException(message:  val_4);
            // 0x00AD2B6C: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x00AD2B70: LDR x8, [x8, #0x738]       | X8 = 1152921513717163472;               
            // 0x00AD2B74: MOV x0, x20                | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2B78: LDR x1, [x8]               | X1 = public System.Nullable<System.DateTimeOffset> Newtonsoft.Json.Bson.BsonReader::ReadAsDateTimeOffset();
            // 0x00AD2B7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2B80: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
            label_5:
            // 0x00AD2B84: SUB x8, x29, #0x30         | X8 = (??? - 48);                        
            var val_6 = (???) - 48;
            // 0x00AD2B88: MOV x1, x22                | X1 = X22;//m1                           
            // 0x00AD2B8C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2B90: LDUR x0, [x29, #-0x30]     | X0 = ??? + -48;                         
            // 0x00AD2B94: BL #0x27af090              | X0 = sub_27AF090( ?? ??? + -48, ????);  
            // 0x00AD2B98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2B9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ??? + -48, ????);  
            // 0x00AD2BA0: SUB x0, x29, #0x30         | X0 = (??? - 48);                        
            var val_7 = (???) - 48;
            // 0x00AD2BA4: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)(??? - 48)); //ERROR_TYPE
            // 0x00AD2BA8: MOV x19, x0                | X19 = (??? - 48);//m1                   
            // 0x00AD2BAC: SUB x0, x29, #0x30         | X0 = (??? - 48);                        
            var val_8 = (???) - 48;
            // 0x00AD2BB0: B #0xad2a50                |  goto label_15;                         
            goto label_15;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD2BB4 (11348916), len: 572  VirtAddr: 0x00AD2BB4 RVA: 0x00AD2BB4 token: 100684736 methodIndex: 47396 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool Read()
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00AD2BB4: STP x22, x21, [sp, #-0x30]! | stack[1152921513717326448] = ???;  stack[1152921513717326456] = ???;  //  dest_result_addr=1152921513717326448 |  dest_result_addr=1152921513717326456
            // 0x00AD2BB8: STP x20, x19, [sp, #0x10]  | stack[1152921513717326464] = ???;  stack[1152921513717326472] = ???;  //  dest_result_addr=1152921513717326464 |  dest_result_addr=1152921513717326472
            // 0x00AD2BBC: STP x29, x30, [sp, #0x20]  | stack[1152921513717326480] = ???;  stack[1152921513717326488] = ???;  //  dest_result_addr=1152921513717326480 |  dest_result_addr=1152921513717326488
            // 0x00AD2BC0: ADD x29, sp, #0x20         | X29 = (1152921513717326448 + 32) = 1152921513717326480 (0x100000021F06E290);
            // 0x00AD2BC4: SUB sp, sp, #0x10          | SP = (1152921513717326448 - 16) = 1152921513717326432 (0x100000021F06E260);
            // 0x00AD2BC8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD2BCC: LDRB w8, [x20, #0x4d3]     | W8 = (bool)static_value_037334D3;       
            // 0x00AD2BD0: MOV x19, x0                | X19 = 1152921513717338496 (0x100000021F071180);//ML01
            // 0x00AD2BD4: TBNZ w8, #0, #0xad2bf0     | if (static_value_037334D3 == true) goto label_0;
            // 0x00AD2BD8: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
            // 0x00AD2BDC: LDR x8, [x8, #0xae0]       | X8 = 0x2B8F9B0;                         
            // 0x00AD2BE0: LDR w0, [x8]               | W0 = 0x1530;                            
            val_7 = 5424;
            // 0x00AD2BE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1530, ????);     
            // 0x00AD2BE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD2BEC: STRB w8, [x20, #0x4d3]     | static_value_037334D3 = true;            //  dest_result_addr=57881811
            label_0:
            // 0x00AD2BF0: LDRSW x8, [x19, #0x6c]     | X8 = this._bsonReaderState; //P2        
            // 0x00AD2BF4: CMP w8, #9                 | STATE = COMPARE(this._bsonReaderState, 0x9)
            // 0x00AD2BF8: B.HS #0xad2c60             | if (this._bsonReaderState >= 0x9) goto label_1;
            if(this._bsonReaderState >= 9)
            {
                goto label_1;
            }
            // 0x00AD2BFC: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00AD2C00: ADD x9, x9, #0x6b0         | X9 = (44638208 + 1712) = 44639920 (0x02A926B0);
            // 0x00AD2C04: LDR w8, [x9, x8, lsl #2]   | W8 = 44639920 + (this._bsonReaderState) << 2;
            // 0x00AD2C08: CMP w8, #6                 | STATE = COMPARE(44639920 + (this._bsonReaderState) << 2, 0x6)
            // 0x00AD2C0C: B.HI #0xad2c48             | if (44639920 + (this._bsonReaderState) << 2 > 0x6) goto label_13;
            if((44639920 + (this._bsonReaderState) << 2) > 6)
            {
                goto label_13;
            }
            // 0x00AD2C10: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00AD2C14: ADD x9, x9, #0x558         | X9 = (44638208 + 1368) = 44639576 (0x02A92558);
            // 0x00AD2C18: LDRSW x8, [x9, x8, lsl #2] | X8 = 44639576 + (44639920 + (this._bsonReaderState) << 2) << 2;
            var val_7 = 44639576 + (44639920 + (this._bsonReaderState) << 2) << 2;
            // 0x00AD2C1C: ADD x8, x8, x9             | X8 = (44639576 + (44639920 + (this._bsonReaderState) << 2) << 2 + 44639576);
            val_7 = val_7 + 44639576;
            // 0x00AD2C20: BR x8                      | goto (44639576 + (44639920 + (this._bsonReaderState) << 2) << 2 + 44639576);
            goto (44639576 + (44639920 + (this._bsonReaderState) << 2) << 2 + 44639576);
            // 0x00AD2C24: MOV x0, x19                | X0 = 1152921513717338496 (0x100000021F071180);//ML01
            val_7 = this;
            // 0x00AD2C28: BL #0xad2df0               | X0 = this.ReadNormal();                 
            bool val_1 = this.ReadNormal();
            // 0x00AD2C2C: B #0xad2c48                |  goto label_13;                         
            goto label_13;
            // 0x00AD2C30: MOV x0, x19                | X0 = 1152921513717338496 (0x100000021F071180);//ML01
            val_7 = this;
            // 0x00AD2C34: BL #0xad3254               | X0 = this.ReadCodeWScope();             
            bool val_2 = this.ReadCodeWScope();
            // 0x00AD2C38: B #0xad2c48                |  goto label_13;                         
            goto label_13;
            // 0x00AD2C3C: MOV x0, x19                | X0 = 1152921513717338496 (0x100000021F071180);//ML01
            // 0x00AD2C40: BL #0xad3020               | X0 = this.ReadReference();              
            bool val_3 = this.ReadReference();
            // 0x00AD2C44: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_7 = 1;
            label_13:
            // 0x00AD2C48: AND w0, w0, #1             | W0 = (val_7 & 1);                       
            val_7 = val_7 & 1;
            // 0x00AD2C4C: SUB sp, x29, #0x20         | SP = (1152921513717326480 - 32) = 1152921513717326448 (0x100000021F06E270);
            // 0x00AD2C50: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD2C54: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD2C58: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD2C5C: RET                        |  return (System.Boolean)(val_7 & 1);    
            return (bool)val_7;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_1:
            // 0x00AD2C60: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD2C64: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD2C68: MOV x21, x19               | X21 = 1152921513717338496 (0x100000021F071180);//ML01
            // 0x00AD2C6C: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD2C70: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD2C74: TBZ w8, #0, #0xad2c84      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AD2C78: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD2C7C: CBNZ w8, #0xad2c84         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AD2C80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_6:
            // 0x00AD2C84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD2C88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2C8C: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_4 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD2C90: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x00AD2C94: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AD2C98: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AD2C9C: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x00AD2CA0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2CA4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AD2CA8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD2CAC: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2CB0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AD2CB4: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2CB8: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x00AD2CBC: LDR w8, [x21, #0x6c]       | W8 = this._bsonReaderState; //P2        
            // 0x00AD2CC0: LDR x9, [x9, #0x150]       | X9 = 1152921504857591808;               
            // 0x00AD2CC4: STR w8, [sp, #0xc]         | stack[1152921513717326444] = this._bsonReaderState;  //  dest_result_addr=1152921513717326444
            // 0x00AD2CC8: LDR x0, [x9]               | X0 = typeof(BsonReader.BsonReaderState);
            // 0x00AD2CCC: ADD x1, sp, #0xc           | X1 = (1152921513717326432 + 12) = 1152921513717326444 (0x100000021F06E26C);
            // 0x00AD2CD0: BL #0x27bc028              | X0 = 1152921513717382784 = (Il2CppObject*)Box((RuntimeClass*)typeof(BsonReader.BsonReaderState), this._bsonReaderState);
            // 0x00AD2CD4: MOV x21, x0                | X21 = 1152921513717382784 (0x100000021F07BE80);//ML01
            // 0x00AD2CD8: CBNZ x20, #0xad2ce0        | if ( != null) goto label_7;             
            if(null != null)
            {
                goto label_7;
            }
            // 0x00AD2CDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._bsonReaderState, ????);
            label_7:
            // 0x00AD2CE0: CBZ x21, #0xad2d04         | if (this._bsonReaderState == 0) goto label_9;
            if(this._bsonReaderState == 0)
            {
                goto label_9;
            }
            // 0x00AD2CE4: LDR x8, [x20]              | X8 = ;                                  
            // 0x00AD2CE8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AD2CEC: MOV x0, x21                | X0 = 1152921513717382784 (0x100000021F07BE80);//ML01
            // 0x00AD2CF0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this._bsonReaderState, ????);
            // 0x00AD2CF4: CBNZ x0, #0xad2d04         | if (this._bsonReaderState != 0) goto label_9;
            if(this._bsonReaderState != 0)
            {
                goto label_9;
            }
            // 0x00AD2CF8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this._bsonReaderState, ????);
            // 0x00AD2CFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2D00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this._bsonReaderState, ????);
            label_9:
            // 0x00AD2D04: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AD2D08: CBNZ w8, #0xad2d18         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_10;
            // 0x00AD2D0C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this._bsonReaderState, ????);
            // 0x00AD2D10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2D14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this._bsonReaderState, ????);
            label_10:
            // 0x00AD2D18: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = this._bsonReaderState;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = this._bsonReaderState;
            // 0x00AD2D1C: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x00AD2D20: LDR x8, [x8, #0x590]       | X8 = (string**)(1152921513717309264)("Unexpected state: {0}");
            // 0x00AD2D24: LDR x1, [x8]               | X1 = "Unexpected state: {0}";           
            // 0x00AD2D28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD2D2C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD2D30: MOV x2, x19                | X2 = val_4;//m1                         
            // 0x00AD2D34: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD2D38: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Unexpected state: {0}", args:  val_4);
            string val_5 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Unexpected state: {0}", args:  val_4);
            // 0x00AD2D3C: MOV x19, x0                | X19 = val_5;//m1                        
            // 0x00AD2D40: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00AD2D44: LDR x8, [x8, #0xde8]       | X8 = 1152921504860094464;               
            // 0x00AD2D48: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonReaderException);
            // 0x00AD2D4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2D50: MOV x20, x0                | X20 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2D54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD2D58: MOV x0, x20                | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            Newtonsoft.Json.JsonReaderException val_6 = null;
            // 0x00AD2D5C: MOV x1, x19                | X1 = val_5;//m1                         
            // 0x00AD2D60: BL #0x13139e4              | .ctor(message:  val_5);                 
            val_6 = new Newtonsoft.Json.JsonReaderException(message:  val_5);
            // 0x00AD2D64: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x00AD2D68: LDR x8, [x8, #0xd60]       | X8 = 1152921513717313472;               
            // 0x00AD2D6C: LDR x1, [x8]               | X1 = public System.Boolean Newtonsoft.Json.Bson.BsonReader::Read();
            // 0x00AD2D70: MOV x0, x20                | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2D74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2D78: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
            // 0x00AD2D7C: MOV x19, x0                | X19 = 1152921504860094464 (0x100000000F184000);//ML01
            val_8 = null;
            // 0x00AD2D80: CMP w1, #1                 | STATE = COMPARE(public System.Boolean Newtonsoft.Json.Bson.BsonReader::Read(), 0x1)
            // 0x00AD2D84: B.NE #0xad2de4             | if (public System.Boolean Newtonsoft.Json.Bson.BsonReader::Read() != 0x1) goto label_11;
            if((public System.Boolean Newtonsoft.Json.Bson.BsonReader::Read()) != 1)
            {
                goto label_11;
            }
            // 0x00AD2D88: MOV x0, x19                | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2D8C: BL #0x981060               | X0 = sub_981060( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2D90: MOV x19, x0                | X19 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD2D94: ADRP x9, #0x35c1000        | X9 = 56365056 (0x35C1000);              
            // 0x00AD2D98: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AD2D9C: LDR x9, [x9, #0x310]       | X9 = 1152921504620957696;               
            // 0x00AD2DA0: LDR x1, [x8]               |  //  not_find_field!1:0
            // 0x00AD2DA4: LDR x0, [x9]               | X0 = typeof(System.IO.EndOfStreamException);
            // 0x00AD2DA8: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.IO.EndOfStreamException), ????);
            // 0x00AD2DAC: TBZ w0, #0, #0xad2dbc      | if ((typeof(System.IO.EndOfStreamException) & 0x1) == 0) goto label_12;
            if((null & 1) == 0)
            {
                goto label_12;
            }
            // 0x00AD2DB0: BL #0x980920               | X0 = sub_980920( ?? typeof(System.IO.EndOfStreamException), ????);
            // 0x00AD2DB4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00AD2DB8: B #0xad2c48                |  goto label_13;                         
            goto label_13;
            label_12:
            // 0x00AD2DBC: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00AD2DC0: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x00AD2DC4: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AD2DC8: STR x8, [x0]               | mem[8] = ;                               //  dest_result_addr=8
            mem[8] = null;
            // 0x00AD2DCC: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x00AD2DD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD2DD4: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x00AD2DD8: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            // 0x00AD2DDC: MOV x19, x0                | X19 = 8 (0x8);//ML01                    
            val_8 = 8;
            // 0x00AD2DE0: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
            label_11:
            // 0x00AD2DE4: MOV x0, x19                | X0 = 8 (0x8);//ML01                     
            // 0x00AD2DE8: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
            // 0x00AD2DEC: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD344C (11351116), len: 80  VirtAddr: 0x00AD344C RVA: 0x00AD344C token: 100684737 methodIndex: 47397 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Close()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x00AD344C: STP x20, x19, [sp, #-0x20]! | stack[1152921513717463040] = ???;  stack[1152921513717463048] = ???;  //  dest_result_addr=1152921513717463040 |  dest_result_addr=1152921513717463048
            // 0x00AD3450: STP x29, x30, [sp, #0x10]  | stack[1152921513717463056] = ???;  stack[1152921513717463064] = ???;  //  dest_result_addr=1152921513717463056 |  dest_result_addr=1152921513717463064
            // 0x00AD3454: ADD x29, sp, #0x10         | X29 = (1152921513717463040 + 16) = 1152921513717463056 (0x100000021F08F810);
            // 0x00AD3458: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD345C: MOV x19, x0                | X19 = 1152921513717475072 (0x100000021F092700);//ML01
            val_6 = this;
            // 0x00AD3460: BL #0x1313c00              | this.Close();                           
            this.Close();
            // 0x00AD3464: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD3468: MOV x0, x19                | X0 = 1152921513717475072 (0x100000021F092700);//ML01
            // 0x00AD346C: BL #0x131329c              | X0 = this.get_CloseInput();             
            bool val_1 = this.CloseInput;
            // 0x00AD3470: TBZ w0, #0, #0xad3490      | if (val_1 == false) goto label_1;       
            if(val_1 == false)
            {
                goto label_1;
            }
            // 0x00AD3474: LDR x0, [x19, #0x48]       | X0 = this._reader; //P2                 
            // 0x00AD3478: CBZ x0, #0xad3490          | if (this._reader == null) goto label_1; 
            if(this._reader == null)
            {
                goto label_1;
            }
            // 0x00AD347C: LDR x8, [x0]               | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD3480: LDP x2, x1, [x8, #0x170]   | X2 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_170; X1 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_178; //  | 
            // 0x00AD3484: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3488: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            val_6 = ???;
            // 0x00AD348C: BR x2                      | goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_170;
            goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_170;
            label_1:
            // 0x00AD3490: LDP x29, x30, [sp, #0x10]  | X29 = val_2; X30 = val_3;                //  find_add[1152921513717451072] |  find_add[1152921513717451072]
            // 0x00AD3494: LDP x20, x19, [sp], #0x20  | X20 = val_4; X19 = val_5;                //  find_add[1152921513717451072] |  find_add[1152921513717451072]
            // 0x00AD3498: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3254 (11350612), len: 504  VirtAddr: 0x00AD3254 RVA: 0x00AD3254 token: 100684738 methodIndex: 47398 delegateWrapperIndex: 0 methodInvoker: 0
        private bool ReadCodeWScope()
        {
            //
            // Disasemble & Code
            //  | 
            int val_10;
            //  | 
            var val_11;
            //  | 
            BsonReaderState val_12;
            // 0x00AD3254: STP x20, x19, [sp, #-0x20]! | stack[1152921513717592608] = ???;  stack[1152921513717592616] = ???;  //  dest_result_addr=1152921513717592608 |  dest_result_addr=1152921513717592616
            // 0x00AD3258: STP x29, x30, [sp, #0x10]  | stack[1152921513717592624] = ???;  stack[1152921513717592632] = ???;  //  dest_result_addr=1152921513717592624 |  dest_result_addr=1152921513717592632
            // 0x00AD325C: ADD x29, sp, #0x10         | X29 = (1152921513717592608 + 16) = 1152921513717592624 (0x100000021F0AF230);
            // 0x00AD3260: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD3264: LDRB w8, [x20, #0x4d4]     | W8 = (bool)static_value_037334D4;       
            // 0x00AD3268: MOV x19, x0                | X19 = 1152921513717604640 (0x100000021F0B2120);//ML01
            val_10 = this;
            // 0x00AD326C: TBNZ w8, #0, #0xad3288     | if (static_value_037334D4 == true) goto label_0;
            // 0x00AD3270: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x00AD3274: LDR x8, [x8, #0x1d8]       | X8 = 0x2B8F9C0;                         
            // 0x00AD3278: LDR w0, [x8]               | W0 = 0x1534;                            
            // 0x00AD327C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1534, ????);     
            // 0x00AD3280: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD3284: STRB w8, [x20, #0x4d4]     | static_value_037334D4 = true;            //  dest_result_addr=57881812
            label_0:
            // 0x00AD3288: LDR w8, [x19, #0x6c]       | W8 = this._bsonReaderState; //P2        
            // 0x00AD328C: SUB w9, w8, #4             | W9 = (this._bsonReaderState - 4);       
            BsonReaderState val_1 = this._bsonReaderState - 4;
            // 0x00AD3290: SUB w8, w8, #1             | W8 = (this._bsonReaderState - 1);       
            val_11 = this._bsonReaderState - 1;
            // 0x00AD3294: CMP w9, #5                 | STATE = COMPARE((this._bsonReaderState - 4), 0x5)
            // 0x00AD3298: CSEL w9, w8, wzr, lo       | W9 = val_1 < 0x5 ? (this._bsonReaderState - 1) : 0;
            var val_2 = (val_1 < 5) ? (val_11) : 0;
            // 0x00AD329C: CMP w9, #7                 | STATE = COMPARE(val_1 < 0x5 ? (this._bsonReaderState - 1) : 0, 0x7)
            // 0x00AD32A0: B.HI #0xad3400             | if (val_2 > 0x7) goto label_11;         
            if(val_2 > 7)
            {
                goto label_11;
            }
            // 0x00AD32A4: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x00AD32A8: ADD x8, x8, #0x594         | X8 = (44638208 + 1428) = 44639636 (0x02A92594);
            // 0x00AD32AC: LDRSW x9, [x8, x9, lsl #2] | X9 = 44639636 + (val_1 < 0x5 ? (this._bsonReaderState - 1) : 0) << 2;
            var val_11 = 44639636 + (val_1 < 0x5 ? (this._bsonReaderState - 1) : 0) << 2;
            // 0x00AD32B0: ADD x9, x9, x8             | X9 = (44639636 + (val_1 < 0x5 ? (this._bsonReaderState - 1) : 0) << 2 + 44639636);
            val_11 = val_11 + 44639636;
            // 0x00AD32B4: BR x9                      | goto (44639636 + (val_1 < 0x5 ? (this._bsonReaderState - 1) : 0) << 2 + 44639636);
            goto (44639636 + (val_1 < 0x5 ? (this._bsonReaderState - 1) : 0) << 2 + 44639636);
            // 0x00AD32B8: ADRP x9, #0x363c000        | X9 = 56868864 (0x363C000);              
            // 0x00AD32BC: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD32C0: LDR x9, [x9, #0x1d8]       | X9 = (string**)(1152921513717571264)("$code");
            // 0x00AD32C4: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00AD32C8: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD32CC: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            // 0x00AD32D0: LDR x2, [x9]               | X2 = "$code";                           
            // 0x00AD32D4: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD32D8: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200();
            // 0x00AD32DC: MOVZ w8, #0x5              | W8 = 5 (0x5);//ML01                     
            val_12 = 5;
            // 0x00AD32E0: B #0xad337c                |  goto label_3;                          
            goto label_3;
            // 0x00AD32E4: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD32E8: BL #0xad349c               | X0 = this.ReadInt32();                  
            int val_3 = this.ReadInt32();
            // 0x00AD32EC: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD32F0: BL #0xad34dc               | X0 = this.ReadLengthString();           
            string val_4 = this.ReadLengthString();
            // 0x00AD32F4: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD32F8: MOV x2, x0                 | X2 = val_4;//m1                         
            // 0x00AD32FC: MOVZ w1, #0x9              | W1 = 9 (0x9);//ML01                     
            // 0x00AD3300: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD3304: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD3308: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            // 0x00AD330C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200();
            // 0x00AD3310: ORR w8, wzr, #6            | W8 = 6(0x6);                            
            val_12 = 6;
            // 0x00AD3314: B #0xad337c                |  goto label_3;                          
            goto label_3;
            // 0x00AD3318: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD331C: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD3320: BL #0x1313294              | X0 = this.get_CurrentState();           
            State val_5 = this.CurrentState;
            // 0x00AD3324: CMP w0, #8                 | STATE = COMPARE(val_5, 0x8)             
            // 0x00AD3328: B.NE #0xad339c             | if (val_5 != 0x8) goto label_4;         
            if(val_5 != 8)
            {
                goto label_4;
            }
            // 0x00AD332C: ADRP x9, #0x3677000        | X9 = 57110528 (0x3677000);              
            // 0x00AD3330: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD3334: LDR x9, [x9, #0x1b8]       | X9 = (string**)(1152921513717579536)("$scope");
            // 0x00AD3338: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00AD333C: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD3340: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            // 0x00AD3344: LDR x2, [x9]               | X2 = "$scope";                          
            // 0x00AD3348: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD334C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200();
            // 0x00AD3350: B #0xad33fc                |  goto label_9;                          
            goto label_9;
            // 0x00AD3354: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD3358: BL #0xad2df0               | X0 = this.ReadNormal();                 
            bool val_6 = this.ReadNormal();
            // 0x00AD335C: TBZ w0, #0, #0xad3410      | if (val_6 == false) goto label_6;       
            if(val_6 == false)
            {
                goto label_6;
            }
            // 0x00AD3360: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD3364: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD3368: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180; X1 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_188; //  | 
            // 0x00AD336C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_180();
            // 0x00AD3370: CMP w0, #0xd               | STATE = COMPARE(this, 0xD)              
            // 0x00AD3374: B.NE #0xad33fc             | if (val_10 != 0xD) goto label_9;        
            if(val_10 != 13)
            {
                goto label_9;
            }
            // 0x00AD3378: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            label_3:
            // 0x00AD337C: STR w8, [x19, #0x6c]       | this._bsonReaderState = 0x8;             //  dest_result_addr=1152921513717604748
            this._bsonReaderState = val_12;
            // 0x00AD3380: B #0xad33fc                |  goto label_9;                          
            goto label_9;
            // 0x00AD3384: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD3388: MOVZ w1, #0xd              | W1 = 13 (0xD);//ML01                    
            // 0x00AD338C: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD3390: BL #0x1313534              | this.SetToken(newToken:  13);           
            this.SetToken(newToken:  13);
            // 0x00AD3394: STR wzr, [x19, #0x6c]      | this._bsonReaderState = null;            //  dest_result_addr=1152921513717604748
            this._bsonReaderState = 0;
            // 0x00AD3398: B #0xad33fc                |  goto label_9;                          
            goto label_9;
            label_4:
            // 0x00AD339C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD33A0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD33A4: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD33A8: BL #0x1313534              | this.SetToken(newToken:  1);            
            this.SetToken(newToken:  1);
            // 0x00AD33AC: ORR w8, wzr, #7            | W8 = 7(0x7);                            
            // 0x00AD33B0: STR w8, [x19, #0x6c]       | this._bsonReaderState = 0x7;             //  dest_result_addr=1152921513717604748
            this._bsonReaderState = 7;
            // 0x00AD33B4: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AD33B8: LDR x8, [x8, #0x668]       | X8 = 1152921504857645056;               
            // 0x00AD33BC: LDR x0, [x8]               | X0 = typeof(BsonReader.ContainerContext);
            object val_7 = null;
            // 0x00AD33C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BsonReader.ContainerContext), ????);
            // 0x00AD33C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD33C8: MOV x20, x0                | X20 = 1152921504857645056 (0x100000000EF2E000);//ML01
            // 0x00AD33CC: BL #0x16f59f0              | .ctor();                                
            val_7 = new System.Object();
            // 0x00AD33D0: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00AD33D4: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD33D8: MOV x1, x20                | X1 = 1152921504857645056 (0x100000000EF2E000);//ML01
            // 0x00AD33DC: STRB w8, [x20, #0x10]      | typeof(BsonReader.ContainerContext).__il2cppRuntimeField_10 = 0x3;  //  dest_result_addr=1152921504857645072
            typeof(BsonReader.ContainerContext).__il2cppRuntimeField_10 = 3;
            // 0x00AD33E0: BL #0xad3568               | this.PushContext(newContext:  val_7);   
            this.PushContext(newContext:  val_7);
            // 0x00AD33E4: MOV x0, x19                | X0 = 1152921513717604640 (0x100000021F0B2120);//ML01
            // 0x00AD33E8: BL #0xad349c               | X0 = this.ReadInt32();                  
            int val_8 = this.ReadInt32();
            // 0x00AD33EC: MOV w19, w0                | W19 = val_8;//m1                        
            val_10 = val_8;
            // 0x00AD33F0: CBNZ x20, #0xad33f8        | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x00AD33F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_10:
            // 0x00AD33F8: STR w19, [x20, #0x14]      | typeof(BsonReader.ContainerContext).__il2cppRuntimeField_14 = val_8;  //  dest_result_addr=1152921504857645076
            typeof(BsonReader.ContainerContext).__il2cppRuntimeField_14 = val_10;
            label_9:
            // 0x00AD33FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            val_11 = 1;
            label_11:
            // 0x00AD3400: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3404: AND w0, w8, #1             | W0 = (val_11 & 1);                      
            var val_9 = val_11 & 1;
            // 0x00AD3408: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD340C: RET                        |  return (System.Boolean)(val_11 & 1);   
            return (bool)val_9;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_6:
            // 0x00AD3410: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
            // 0x00AD3414: B #0xad3400                |  goto label_11;                         
            goto label_11;
            // 0x00AD3418: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00AD341C: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x00AD3420: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            System.ArgumentOutOfRangeException val_10 = null;
            // 0x00AD3424: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD3428: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD342C: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD3430: BL #0x18cb840              | .ctor();                                
            val_10 = new System.ArgumentOutOfRangeException();
            // 0x00AD3434: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x00AD3438: LDR x8, [x8, #0xf30]       | X8 = 1152921513717579616;               
            // 0x00AD343C: MOV x0, x19                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD3440: LDR x1, [x8]               | X1 = System.Boolean Newtonsoft.Json.Bson.BsonReader::ReadCodeWScope();
            // 0x00AD3444: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD3448: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3020 (11350048), len: 564  VirtAddr: 0x00AD3020 RVA: 0x00AD3020 token: 100684739 methodIndex: 47399 delegateWrapperIndex: 0 methodInvoker: 0
        private bool ReadReference()
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00AD3020: STP x20, x19, [sp, #-0x20]! | stack[1152921513717783776] = ???;  stack[1152921513717783784] = ???;  //  dest_result_addr=1152921513717783776 |  dest_result_addr=1152921513717783784
            // 0x00AD3024: STP x29, x30, [sp, #0x10]  | stack[1152921513717783792] = ???;  stack[1152921513717783800] = ???;  //  dest_result_addr=1152921513717783792 |  dest_result_addr=1152921513717783800
            // 0x00AD3028: ADD x29, sp, #0x10         | X29 = (1152921513717783776 + 16) = 1152921513717783792 (0x100000021F0DDCF0);
            // 0x00AD302C: SUB sp, sp, #0x10          | SP = (1152921513717783776 - 16) = 1152921513717783760 (0x100000021F0DDCD0);
            // 0x00AD3030: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD3034: LDRB w8, [x20, #0x4d5]     | W8 = (bool)static_value_037334D5;       
            // 0x00AD3038: MOV x19, x0                | X19 = 1152921513717795808 (0x100000021F0E0BE0);//ML01
            // 0x00AD303C: TBNZ w8, #0, #0xad3058     | if (static_value_037334D5 == true) goto label_0;
            // 0x00AD3040: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AD3044: LDR x8, [x8, #0x918]       | X8 = 0x2B8F9C8;                         
            // 0x00AD3048: LDR w0, [x8]               | W0 = 0x1536;                            
            // 0x00AD304C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1536, ????);     
            // 0x00AD3050: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD3054: STRB w8, [x20, #0x4d5]     | static_value_037334D5 = true;            //  dest_result_addr=57881813
            label_0:
            // 0x00AD3058: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD305C: MOV x0, x19                | X0 = 1152921513717795808 (0x100000021F0E0BE0);//ML01
            // 0x00AD3060: BL #0x1313294              | X0 = this.get_CurrentState();           
            State val_1 = this.CurrentState;
            // 0x00AD3064: CMP w0, #2                 | STATE = COMPARE(val_1, 0x2)             
            // 0x00AD3068: B.EQ #0xad30ac             | if (val_1 == 0x2) goto label_1;         
            if(val_1 == 2)
            {
                goto label_1;
            }
            // 0x00AD306C: CMP w0, #8                 | STATE = COMPARE(val_1, 0x8)             
            // 0x00AD3070: B.EQ #0xad30e0             | if (val_1 == 0x8) goto label_2;         
            if(val_1 == 8)
            {
                goto label_2;
            }
            // 0x00AD3074: CMP w0, #3                 | STATE = COMPARE(val_1, 0x3)             
            // 0x00AD3078: B.NE #0xad3178             | if (val_1 != 0x3) goto label_3;         
            if(val_1 != 3)
            {
                goto label_3;
            }
            // 0x00AD307C: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
            // 0x00AD3080: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD3084: LDR x9, [x9, #0xe98]       | X9 = (string**)(1152921513717709024)("$ref");
            // 0x00AD3088: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00AD308C: MOV x0, x19                | X0 = 1152921513717795808 (0x100000021F0E0BE0);//ML01
            // 0x00AD3090: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            // 0x00AD3094: LDR x2, [x9]               | X2 = "$ref";                            
            // 0x00AD3098: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD309C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200();
            // 0x00AD30A0: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00AD30A4: STR w8, [x19, #0x6c]       | this._bsonReaderState = 0x2;             //  dest_result_addr=1152921513717795916
            this._bsonReaderState = 2;
            // 0x00AD30A8: B #0xad3164                |  goto label_11;                         
            goto label_11;
            label_1:
            // 0x00AD30AC: LDR w8, [x19, #0x6c]       | W8 = this._bsonReaderState; //P2        
            // 0x00AD30B0: CMP w8, #3                 | STATE = COMPARE(this._bsonReaderState, 0x3)
            // 0x00AD30B4: B.EQ #0xad3124             | if (this._bsonReaderState == 0x3) goto label_5;
            if(this._bsonReaderState == 3)
            {
                goto label_5;
            }
            // 0x00AD30B8: CMP w8, #2                 | STATE = COMPARE(this._bsonReaderState, 0x2)
            // 0x00AD30BC: B.NE #0xad31a0             | if (this._bsonReaderState != 0x2) goto label_6;
            if(this._bsonReaderState != 2)
            {
                goto label_6;
            }
            // 0x00AD30C0: MOV x0, x19                | X0 = 1152921513717795808 (0x100000021F0E0BE0);//ML01
            // 0x00AD30C4: BL #0xad34dc               | X0 = this.ReadLengthString();           
            string val_2 = this.ReadLengthString();
            // 0x00AD30C8: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD30CC: MOV x2, x0                 | X2 = val_2;//m1                         
            // 0x00AD30D0: MOVZ w1, #0x9              | W1 = 9 (0x9);//ML01                     
            // 0x00AD30D4: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD30D8: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            // 0x00AD30DC: B #0xad3144                |  goto label_7;                          
            goto label_7;
            label_2:
            // 0x00AD30E0: LDR w8, [x19, #0x6c]       | W8 = this._bsonReaderState; //P2        
            // 0x00AD30E4: CMP w8, #3                 | STATE = COMPARE(this._bsonReaderState, 0x3)
            // 0x00AD30E8: B.EQ #0xad3150             | if (this._bsonReaderState == 0x3) goto label_8;
            if(this._bsonReaderState == 3)
            {
                goto label_8;
            }
            // 0x00AD30EC: CMP w8, #2                 | STATE = COMPARE(this._bsonReaderState, 0x2)
            // 0x00AD30F0: B.NE #0xad31b8             | if (this._bsonReaderState != 0x2) goto label_9;
            if(this._bsonReaderState != 2)
            {
                goto label_9;
            }
            // 0x00AD30F4: ADRP x9, #0x3671000        | X9 = 57085952 (0x3671000);              
            // 0x00AD30F8: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD30FC: LDR x9, [x9, #0xa98]       | X9 = (string**)(1152921513717721392)("$id");
            // 0x00AD3100: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00AD3104: MOV x0, x19                | X0 = 1152921513717795808 (0x100000021F0E0BE0);//ML01
            // 0x00AD3108: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            // 0x00AD310C: LDR x2, [x9]               | X2 = "$id";                             
            // 0x00AD3110: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD3114: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200();
            // 0x00AD3118: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00AD311C: STR w8, [x19, #0x6c]       | this._bsonReaderState = 0x3;             //  dest_result_addr=1152921513717795916
            this._bsonReaderState = 3;
            // 0x00AD3120: B #0xad3164                |  goto label_11;                         
            goto label_11;
            label_5:
            // 0x00AD3124: ORR w1, wzr, #0xc          | W1 = 12(0xC);                           
            // 0x00AD3128: MOV x0, x19                | X0 = 1152921513717795808 (0x100000021F0E0BE0);//ML01
            // 0x00AD312C: BL #0xad35dc               | X0 = this.ReadBytes(count:  12);        
            System.Byte[] val_3 = this.ReadBytes(count:  12);
            // 0x00AD3130: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD3134: MOV x2, x0                 | X2 = val_3;//m1                         
            // 0x00AD3138: MOVZ w1, #0x11             | W1 = 17 (0x11);//ML01                   
            // 0x00AD313C: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD3140: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            label_7:
            // 0x00AD3144: MOV x0, x19                | X0 = 1152921513717795808 (0x100000021F0E0BE0);//ML01
            // 0x00AD3148: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200();
            // 0x00AD314C: B #0xad3164                |  goto label_11;                         
            goto label_11;
            label_8:
            // 0x00AD3150: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD3154: MOVZ w1, #0xd              | W1 = 13 (0xD);//ML01                    
            // 0x00AD3158: MOV x0, x19                | X0 = 1152921513717795808 (0x100000021F0E0BE0);//ML01
            // 0x00AD315C: BL #0x1313534              | this.SetToken(newToken:  13);           
            this.SetToken(newToken:  13);
            // 0x00AD3160: STR wzr, [x19, #0x6c]      | this._bsonReaderState = null;            //  dest_result_addr=1152921513717795916
            this._bsonReaderState = 0;
            label_11:
            // 0x00AD3164: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00AD3168: SUB sp, x29, #0x10         | SP = (1152921513717783792 - 16) = 1152921513717783776 (0x100000021F0DDCE0);
            // 0x00AD316C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3170: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3174: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_3:
            // 0x00AD3178: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD317C: MOV x0, x19                | X0 = 1152921513717795808 (0x100000021F0E0BE0);//ML01
            // 0x00AD3180: BL #0x1313294              | X0 = this.get_CurrentState();           
            State val_4 = this.CurrentState;
            // 0x00AD3184: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00AD3188: LDR x8, [x8, #0xd98]       | X8 = 1152921504860041216;               
            // 0x00AD318C: STR w0, [sp, #4]           | stack[1152921513717783764] = val_4;      //  dest_result_addr=1152921513717783764
            // 0x00AD3190: ADD x1, sp, #4             | X1 = (1152921513717783760 + 4) = 1152921513717783764 (0x100000021F0DDCD4);
            // 0x00AD3194: LDR x8, [x8]               | X8 = typeof(JsonReader.State);          
            // 0x00AD3198: MOV x0, x8                 | X0 = 1152921504860041216 (0x100000000F177000);//ML01
            val_8 = null;
            // 0x00AD319C: B #0xad31cc                |  goto label_13;                         
            goto label_13;
            label_6:
            // 0x00AD31A0: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x00AD31A4: LDR x9, [x9, #0x150]       | X9 = 1152921504857591808;               
            // 0x00AD31A8: STR w8, [sp, #0xc]         | stack[1152921513717783772] = this._bsonReaderState;  //  dest_result_addr=1152921513717783772
            // 0x00AD31AC: ADD x1, sp, #0xc           | X1 = (1152921513717783760 + 12) = 1152921513717783772 (0x100000021F0DDCDC);
            // 0x00AD31B0: LDR x0, [x9]               | X0 = typeof(BsonReader.BsonReaderState);
            val_8 = null;
            // 0x00AD31B4: B #0xad31cc                |  goto label_13;                         
            goto label_13;
            label_9:
            // 0x00AD31B8: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x00AD31BC: LDR x9, [x9, #0x150]       | X9 = 1152921504857591808;               
            // 0x00AD31C0: STR w8, [sp, #8]           | stack[1152921513717783768] = this._bsonReaderState;  //  dest_result_addr=1152921513717783768
            // 0x00AD31C4: ADD x1, sp, #8             | X1 = (1152921513717783760 + 8) = 1152921513717783768 (0x100000021F0DDCD8);
            // 0x00AD31C8: LDR x0, [x9]               | X0 = typeof(BsonReader.BsonReaderState);
            val_8 = null;
            label_13:
            // 0x00AD31CC: BL #0x27bc028              | X0 = 1152921513717885152 = (Il2CppObject*)Box((RuntimeClass*)typeof(BsonReader.BsonReaderState), this._bsonReaderState);
            // 0x00AD31D0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AD31D4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AD31D8: MOV x19, x0                | X19 = 1152921513717885152 (0x100000021F0F68E0);//ML01
            // 0x00AD31DC: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00AD31E0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00AD31E4: TBZ w9, #0, #0xad31f8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00AD31E8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AD31EC: CBNZ w9, #0xad31f8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00AD31F0: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AD31F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_15:
            // 0x00AD31F8: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00AD31FC: LDR x8, [x8, #0xc78]       | X8 = (string**)(1152921513717766528)("Unexpected state when reading BSON reference: ");
            // 0x00AD3200: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD3204: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD3208: MOV x2, x19                | X2 = 1152921513717885152 (0x100000021F0F68E0);//ML01
            // 0x00AD320C: LDR x1, [x8]               | X1 = "Unexpected state when reading BSON reference: ";
            // 0x00AD3210: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "Unexpected state when reading BSON reference: ");
            string val_5 = System.String.Concat(arg0:  0, arg1:  "Unexpected state when reading BSON reference: ");
            // 0x00AD3214: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00AD3218: LDR x8, [x8, #0xde8]       | X8 = 1152921504860094464;               
            // 0x00AD321C: MOV x19, x0                | X19 = val_5;//m1                        
            // 0x00AD3220: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonReaderException);
            // 0x00AD3224: MOV x0, x8                 | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            Newtonsoft.Json.JsonReaderException val_6 = null;
            // 0x00AD3228: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD322C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD3230: MOV x1, x19                | X1 = val_5;//m1                         
            // 0x00AD3234: MOV x20, x0                | X20 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD3238: BL #0x13139e4              | .ctor(message:  val_5);                 
            val_6 = new Newtonsoft.Json.JsonReaderException(message:  val_5);
            // 0x00AD323C: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00AD3240: LDR x8, [x8, #0xb38]       | X8 = 1152921513717770784;               
            // 0x00AD3244: MOV x0, x20                | X0 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD3248: LDR x1, [x8]               | X1 = System.Boolean Newtonsoft.Json.Bson.BsonReader::ReadReference();
            // 0x00AD324C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD3250: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD2DF0 (11349488), len: 560  VirtAddr: 0x00AD2DF0 RVA: 0x00AD2DF0 token: 100684740 methodIndex: 47400 delegateWrapperIndex: 0 methodInvoker: 0
        private bool ReadNormal()
        {
            //
            // Disasemble & Code
            //  | 
            int val_13;
            //  | 
            var val_14;
            //  | 
            Newtonsoft.Json.JsonReaderException val_15;
            //  | 
            string val_16;
            // 0x00AD2DF0: STP x22, x21, [sp, #-0x30]! | stack[1152921513717974912] = ???;  stack[1152921513717974920] = ???;  //  dest_result_addr=1152921513717974912 |  dest_result_addr=1152921513717974920
            // 0x00AD2DF4: STP x20, x19, [sp, #0x10]  | stack[1152921513717974928] = ???;  stack[1152921513717974936] = ???;  //  dest_result_addr=1152921513717974928 |  dest_result_addr=1152921513717974936
            // 0x00AD2DF8: STP x29, x30, [sp, #0x20]  | stack[1152921513717974944] = ???;  stack[1152921513717974952] = ???;  //  dest_result_addr=1152921513717974944 |  dest_result_addr=1152921513717974952
            // 0x00AD2DFC: ADD x29, sp, #0x20         | X29 = (1152921513717974912 + 32) = 1152921513717974944 (0x100000021F10C7A0);
            // 0x00AD2E00: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD2E04: LDRB w8, [x20, #0x4d6]     | W8 = (bool)static_value_037334D6;       
            // 0x00AD2E08: MOV x19, x0                | X19 = 1152921513717986960 (0x100000021F10F690);//ML01
            val_13 = this;
            // 0x00AD2E0C: TBNZ w8, #0, #0xad2e28     | if (static_value_037334D6 == true) goto label_0;
            // 0x00AD2E10: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x00AD2E14: LDR x8, [x8, #0xc20]       | X8 = 0x2B8F9C4;                         
            // 0x00AD2E18: LDR w0, [x8]               | W0 = 0x1535;                            
            // 0x00AD2E1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1535, ????);     
            // 0x00AD2E20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD2E24: STRB w8, [x20, #0x4d6]     | static_value_037334D6 = true;            //  dest_result_addr=57881814
            label_0:
            // 0x00AD2E28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2E2C: MOV x0, x19                | X0 = 1152921513717986960 (0x100000021F10F690);//ML01
            // 0x00AD2E30: BL #0x1313294              | X0 = this.get_CurrentState();           
            State val_1 = this.CurrentState;
            // 0x00AD2E34: CMP w0, #0xc               | STATE = COMPARE(val_1, 0xC)             
            // 0x00AD2E38: B.HI #0xad2fa4             | if (val_1 > 0xC) goto label_1;          
            if(val_1 > 12)
            {
                goto label_1;
            }
            // 0x00AD2E3C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x00AD2E40: ADD x8, x8, #0x6e0         | X8 = (44638208 + 1760) = 44639968 (0x02A926E0);
            // 0x00AD2E44: LDR w8, [x8, w0, sxtw #2]  | W8 = 44639968 + (val_1) << 2;           
            // 0x00AD2E48: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_14 = 0;
            // 0x00AD2E4C: CMP w8, #7                 | STATE = COMPARE(44639968 + (val_1) << 2, 0x7)
            // 0x00AD2E50: B.HI #0xad2f94             | if (44639968 + (val_1) << 2 > 0x7) goto label_9;
            if((44639968 + (val_1) << 2) > 7)
            {
                goto label_9;
            }
            // 0x00AD2E54: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00AD2E58: ADD x9, x9, #0x574         | X9 = (44638208 + 1396) = 44639604 (0x02A92574);
            // 0x00AD2E5C: LDRSW x8, [x9, x8, lsl #2] | X8 = 44639604 + (44639968 + (val_1) << 2) << 2;
            var val_12 = 44639604 + (44639968 + (val_1) << 2) << 2;
            // 0x00AD2E60: ADD x8, x8, x9             | X8 = (44639604 + (44639968 + (val_1) << 2) << 2 + 44639604);
            val_12 = val_12 + 44639604;
            // 0x00AD2E64: BR x8                      | goto (44639604 + (44639968 + (val_1) << 2) << 2 + 44639604);
            goto (44639604 + (44639968 + (val_1) << 2) << 2 + 44639604);
            // 0x00AD2E68: LDRB w8, [x19, #0x78]      | W8 = this._readRootValueAsArray; //P2   
            // 0x00AD2E6C: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00AD2E70: ORR w10, wzr, #3           | W10 = 3(0x3);                           
            // 0x00AD2E74: CMP w8, #0                 | STATE = COMPARE(this._readRootValueAsArray, 0x0)
            // 0x00AD2E78: CINC w1, w9, ne            | W1 = this._readRootValueAsArray == true ? (1 + 1) : 1;
            Newtonsoft.Json.JsonToken val_2 = (this._readRootValueAsArray == true) ? (1 + 1) : (1);
            // 0x00AD2E7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD2E80: MOV x0, x19                | X0 = 1152921513717986960 (0x100000021F10F690);//ML01
            // 0x00AD2E84: CINC w21, w10, ne          | W21 = this._readRootValueAsArray == true ? (3 + 1) : 3;
            var val_3 = (this._readRootValueAsArray == true) ? (3 + 1) : (3);
            // 0x00AD2E88: BL #0x1313534              | this.SetToken(newToken:  Newtonsoft.Json.JsonToken val_2 = (this._readRootValueAsArray == true) ? (1 + 1) : (1));
            this.SetToken(newToken:  val_2);
            // 0x00AD2E8C: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AD2E90: LDR x8, [x8, #0x668]       | X8 = 1152921504857645056;               
            // 0x00AD2E94: LDR x0, [x8]               | X0 = typeof(BsonReader.ContainerContext);
            object val_4 = null;
            // 0x00AD2E98: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BsonReader.ContainerContext), ????);
            // 0x00AD2E9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2EA0: MOV x20, x0                | X20 = 1152921504857645056 (0x100000000EF2E000);//ML01
            // 0x00AD2EA4: BL #0x16f59f0              | .ctor();                                
            val_4 = new System.Object();
            // 0x00AD2EA8: MOV x0, x19                | X0 = 1152921513717986960 (0x100000021F10F690);//ML01
            // 0x00AD2EAC: MOV x1, x20                | X1 = 1152921504857645056 (0x100000000EF2E000);//ML01
            // 0x00AD2EB0: STRB w21, [x20, #0x10]     | typeof(BsonReader.ContainerContext).__il2cppRuntimeField_10 = this._readRootValueAsArray == true ? (3 + 1) : 3;  //  dest_result_addr=1152921504857645072
            typeof(BsonReader.ContainerContext).__il2cppRuntimeField_10 = val_3;
            // 0x00AD2EB4: BL #0xad3568               | this.PushContext(newContext:  val_4);   
            this.PushContext(newContext:  val_4);
            // 0x00AD2EB8: MOV x0, x19                | X0 = 1152921513717986960 (0x100000021F10F690);//ML01
            // 0x00AD2EBC: BL #0xad349c               | X0 = this.ReadInt32();                  
            int val_5 = this.ReadInt32();
            // 0x00AD2EC0: MOV w19, w0                | W19 = val_5;//m1                        
            val_13 = val_5;
            // 0x00AD2EC4: CBNZ x20, #0xad2ecc        | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x00AD2EC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_3:
            // 0x00AD2ECC: STR w19, [x20, #0x14]      | typeof(BsonReader.ContainerContext).__il2cppRuntimeField_14 = val_5;  //  dest_result_addr=1152921504857645076
            typeof(BsonReader.ContainerContext).__il2cppRuntimeField_14 = val_13;
            // 0x00AD2ED0: B #0xad2f90                |  goto label_13;                         
            goto label_13;
            // 0x00AD2ED4: LDR x20, [x19, #0x70]      | X20 = val_5 + 112;                      
            // 0x00AD2ED8: CBZ x20, #0xad2f20         | if (val_5 + 112 == 0) goto label_5;     
            if((val_5 + 112) == 0)
            {
                goto label_5;
            }
            // 0x00AD2EDC: LDP w8, w9, [x20, #0x14]   | W8 = val_5 + 112 + 20; W9 = val_5 + 112 + 20 + 4; //  | 
            var val_13 = val_5 + 112 + 20;
            // 0x00AD2EE0: SUB w8, w8, #1             | W8 = (val_5 + 112 + 20 - 1);            
            val_13 = val_13 - 1;
            // 0x00AD2EE4: CMP w9, w8                 | STATE = COMPARE(val_5 + 112 + 20 + 4, (val_5 + 112 + 20 - 1))
            // 0x00AD2EE8: B.GE #0xad2f28             | if (val_5 + 112 + 20 + 4 >= val_5 + 112 + 20) goto label_6;
            if((val_5 + 112 + 20 + 4) >= val_13)
            {
                goto label_6;
            }
            // 0x00AD2EEC: LDRB w20, [x20, #0x10]     | W20 = val_5 + 112 + 16;                 
            // 0x00AD2EF0: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD2EF4: BL #0xad1fcc               | X0 = val_5.ReadType();                  
            Newtonsoft.Json.Bson.BsonType val_6 = val_13.ReadType();
            // 0x00AD2EF8: STRB w0, [x19, #0x68]      | mem2[0] = val_6;                         //  dest_result_addr=0
            mem2[0] = val_6;
            // 0x00AD2EFC: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD2F00: BL #0xad200c               | X0 = val_5.ReadString();                
            string val_7 = val_13.ReadString();
            // 0x00AD2F04: MOV x2, x0                 | X2 = val_7;//m1                         
            // 0x00AD2F08: CMP w20, #4                | STATE = COMPARE(val_5 + 112 + 16, 0x4)  
            // 0x00AD2F0C: B.NE #0xad2f78             | if (val_5 + 112 + 16 != 0x4) goto label_7;
            if((val_5 + 112 + 16) != 4)
            {
                goto label_7;
            }
            // 0x00AD2F10: LDRB w1, [x19, #0x68]      | W1 = val_5 + 104;                       
            // 0x00AD2F14: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD2F18: BL #0xad361c               | val_5.ReadType(type:  val_5 + 104);     
            val_13.ReadType(type:  val_5 + 104);
            // 0x00AD2F1C: B #0xad2f90                |  goto label_13;                         
            goto label_13;
            label_5:
            // 0x00AD2F20: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_14 = 0;
            // 0x00AD2F24: B #0xad2f94                |  goto label_9;                          
            goto label_9;
            label_6:
            // 0x00AD2F28: B.NE #0xad2fd8             | if (val_5 + 112 + 20 + 4 != val_5 + 112 + 20) goto label_10;
            if((val_5 + 112 + 20 + 4) != val_13)
            {
                goto label_10;
            }
            // 0x00AD2F2C: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD2F30: BL #0xad3adc               | X0 = val_5.ReadByte();                  
            byte val_8 = val_13.ReadByte();
            // 0x00AD2F34: AND w8, w0, #0xff          | W8 = (val_8 & 255);                     
            byte val_9 = val_8 & 255;
            // 0x00AD2F38: CBNZ w8, #0xad2ff4         | if ((val_8 & 255) != 0) goto label_11;  
            if(val_9 != 0)
            {
                goto label_11;
            }
            // 0x00AD2F3C: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD2F40: BL #0xad3b18               | val_5.PopContext();                     
            val_13.PopContext();
            // 0x00AD2F44: LDR x8, [x19, #0x70]       | X8 = val_5 + 112;                       
            // 0x00AD2F48: CBZ x8, #0xad2f58          | if (val_5 + 112 == 0) goto label_12;    
            if((val_5 + 112) == 0)
            {
                goto label_12;
            }
            // 0x00AD2F4C: LDR w1, [x20, #0x14]       | W1 = val_5 + 112 + 20;                  
            // 0x00AD2F50: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD2F54: BL #0xad3c40               | val_5.MovePosition(count:  val_5 + 112 + 20);
            val_13.MovePosition(count:  val_5 + 112 + 20);
            label_12:
            // 0x00AD2F58: LDRB w8, [x20, #0x10]      | W8 = val_5 + 112 + 16;                  
            // 0x00AD2F5C: CMP w8, #3                 | STATE = COMPARE(val_5 + 112 + 16, 0x3)  
            // 0x00AD2F60: MOVZ w8, #0xd              | W8 = 13 (0xD);//ML01                    
            // 0x00AD2F64: CINC w1, w8, ne            | W1 = val_5 + 112 + 16 != 0x3 ? (13 + 1) : 13;
            Newtonsoft.Json.JsonToken val_10 = ((val_5 + 112 + 16) != 3) ? (13 + 1) : 13;
            // 0x00AD2F68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD2F6C: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD2F70: BL #0x1313534              | val_5.SetToken(newToken:  Newtonsoft.Json.JsonToken val_10 = ((val_5 + 112 + 16) != 3) ? (13 + 1) : 13);
            val_13.SetToken(newToken:  val_10);
            // 0x00AD2F74: B #0xad2f90                |  goto label_13;                         
            goto label_13;
            label_7:
            // 0x00AD2F78: LDR x8, [x19]              | X8 = val_5;                             
            // 0x00AD2F7C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00AD2F80: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD2F84: LDR x9, [x8, #0x200]       | X9 = val_5 + 512;                       
            // 0x00AD2F88: LDR x3, [x8, #0x208]       | X3 = val_5 + 520;                       
            // 0x00AD2F8C: BLR x9                     | X0 = val_5 + 512();                     
            label_13:
            // 0x00AD2F90: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_14 = 1;
            label_9:
            // 0x00AD2F94: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD2F98: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD2F9C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD2FA0: RET                        |  return (System.Boolean)true;           
            return (bool)val_14;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_1:
            // 0x00AD2FA4: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00AD2FA8: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x00AD2FAC: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            System.ArgumentOutOfRangeException val_11 = null;
            // 0x00AD2FB0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD2FB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2FB8: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD2FBC: BL #0x18cb840              | .ctor();                                
            val_11 = new System.ArgumentOutOfRangeException();
            label_15:
            // 0x00AD2FC0: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x00AD2FC4: LDR x8, [x8, #0xb28]       | X8 = 1152921513717961632;               
            // 0x00AD2FC8: MOV x0, x19                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD2FCC: LDR x1, [x8]               | X1 = System.Boolean Newtonsoft.Json.Bson.BsonReader::ReadNormal();
            // 0x00AD2FD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD2FD4: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
            label_10:
            // 0x00AD2FD8: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00AD2FDC: LDR x8, [x8, #0xde8]       | X8 = 1152921504860094464;               
            // 0x00AD2FE0: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonReaderException);
            val_15 = null;
            // 0x00AD2FE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD2FE8: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00AD2FEC: LDR x8, [x8, #0xf28]       | X8 = (string**)(1152921513717962656)("Read past end of current container context.");
            val_16 = "Read past end of current container context.";
            // 0x00AD2FF0: B #0xad300c                |  goto label_14;                         
            goto label_14;
            label_11:
            // 0x00AD2FF4: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00AD2FF8: LDR x8, [x8, #0xde8]       | X8 = 1152921504860094464;               
            // 0x00AD2FFC: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonReaderException);
            val_15 = null;
            // 0x00AD3000: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.JsonReaderException), ????);
            // 0x00AD3004: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x00AD3008: LDR x8, [x8, #0x5a8]       | X8 = (string**)(1152921513717962816)("Unexpected end of object byte value.");
            val_16 = "Unexpected end of object byte value.";
            label_14:
            // 0x00AD300C: LDR x1, [x8]               | X1 = "Unexpected end of object byte value.";
            // 0x00AD3010: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD3014: MOV x19, x0                | X19 = 1152921504860094464 (0x100000000F184000);//ML01
            // 0x00AD3018: BL #0x13139e4              | .ctor(message:  val_16 = "Unexpected end of object byte value.");
            val_15 = new Newtonsoft.Json.JsonReaderException(message:  val_16);
            // 0x00AD301C: B #0xad2fc0                |  goto label_15;                         
            goto label_15;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3B18 (11352856), len: 296  VirtAddr: 0x00AD3B18 RVA: 0x00AD3B18 token: 100684741 methodIndex: 47401 delegateWrapperIndex: 0 methodInvoker: 0
        private void PopContext()
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.List<ContainerContext> val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            System.Collections.Generic.List<ContainerContext> val_12;
            // 0x00AD3B18: STP x22, x21, [sp, #-0x30]! | stack[1152921513718118656] = ???;  stack[1152921513718118664] = ???;  //  dest_result_addr=1152921513718118656 |  dest_result_addr=1152921513718118664
            // 0x00AD3B1C: STP x20, x19, [sp, #0x10]  | stack[1152921513718118672] = ???;  stack[1152921513718118680] = ???;  //  dest_result_addr=1152921513718118672 |  dest_result_addr=1152921513718118680
            // 0x00AD3B20: STP x29, x30, [sp, #0x20]  | stack[1152921513718118688] = ???;  stack[1152921513718118696] = ???;  //  dest_result_addr=1152921513718118688 |  dest_result_addr=1152921513718118696
            // 0x00AD3B24: ADD x29, sp, #0x20         | X29 = (1152921513718118656 + 32) = 1152921513718118688 (0x100000021F12F920);
            // 0x00AD3B28: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD3B2C: LDRB w8, [x20, #0x4d7]     | W8 = (bool)static_value_037334D7;       
            // 0x00AD3B30: MOV x19, x0                | X19 = 1152921513718130704 (0x100000021F132810);//ML01
            // 0x00AD3B34: TBNZ w8, #0, #0xad3b50     | if (static_value_037334D7 == true) goto label_0;
            // 0x00AD3B38: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x00AD3B3C: LDR x8, [x8, #0xdc8]       | X8 = 0x2B8F9A8;                         
            // 0x00AD3B40: LDR w0, [x8]               | W0 = 0x152E;                            
            // 0x00AD3B44: BL #0x2782188              | X0 = sub_2782188( ?? 0x152E, ????);     
            // 0x00AD3B48: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD3B4C: STRB w8, [x20, #0x4d7]     | static_value_037334D7 = true;            //  dest_result_addr=57881815
            label_0:
            // 0x00AD3B50: LDR x20, [x19, #0x50]      | X20 = this._stack; //P2                 
            val_9 = this._stack;
            // 0x00AD3B54: CBZ x20, #0xad3b74         | if (this._stack == null) goto label_1;  
            if(val_9 == null)
            {
                goto label_1;
            }
            // 0x00AD3B58: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x00AD3B5C: LDR x8, [x8, #0x3e0]       | X8 = 1152921513718091344;               
            // 0x00AD3B60: MOV x0, x20                | X0 = this._stack;//m1                   
            // 0x00AD3B64: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<ContainerContext>::get_Count();
            // 0x00AD3B68: BL #0x25ed72c              | X0 = this._stack.get_Count();           
            int val_1 = val_9.Count;
            // 0x00AD3B6C: MOV w21, w0                | W21 = val_1;//m1                        
            val_10 = val_1;
            // 0x00AD3B70: B #0xad3b98                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00AD3B74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x152E, ????);     
            // 0x00AD3B78: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x00AD3B7C: LDR x8, [x8, #0x3e0]       | X8 = 1152921513718091344;               
            // 0x00AD3B80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD3B84: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<ContainerContext>::get_Count();
            // 0x00AD3B88: BL #0x25ed72c              | X0 = 0.get_Count();                     
            int val_2 = 0.Count;
            // 0x00AD3B8C: MOV w21, w0                | W21 = val_2;//m1                        
            val_10 = val_2;
            // 0x00AD3B90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x00AD3B94: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_2:
            // 0x00AD3B98: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00AD3B9C: LDR x8, [x8, #0x3b8]       | X8 = 1152921513718092368;               
            // 0x00AD3BA0: SUB w1, w21, #1            | W1 = (val_2 - 1);                       
            int val_3 = val_10 - 1;
            // 0x00AD3BA4: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x00AD3BA8: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<ContainerContext>::RemoveAt(int index);
            // 0x00AD3BAC: BL #0x25ed00c              | val_9.RemoveAt(index:  int val_3 = val_10 - 1);
            val_9.RemoveAt(index:  val_3);
            // 0x00AD3BB0: LDR x20, [x19, #0x50]      | X20 = this._stack; //P2                 
            // 0x00AD3BB4: CBNZ x20, #0xad3bbc        | if (this._stack != null) goto label_3;  
            if(this._stack != null)
            {
                goto label_3;
            }
            // 0x00AD3BB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_3:
            // 0x00AD3BBC: ADRP x21, #0x3651000       | X21 = 56954880 (0x3651000);             
            // 0x00AD3BC0: LDR x21, [x21, #0x3e0]     | X21 = 1152921513718091344;              
            val_11 = 1152921513718091344;
            // 0x00AD3BC4: MOV x0, x20                | X0 = this._stack;//m1                   
            // 0x00AD3BC8: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<ContainerContext>::get_Count();
            // 0x00AD3BCC: BL #0x25ed72c              | X0 = this._stack.get_Count();           
            int val_4 = this._stack.Count;
            // 0x00AD3BD0: CBZ w0, #0xad3bf0          | if (val_4 == 0) goto label_4;           
            if(val_4 == 0)
            {
                goto label_4;
            }
            // 0x00AD3BD4: LDR x20, [x19, #0x50]      | X20 = this._stack; //P2                 
            val_12 = this._stack;
            // 0x00AD3BD8: CBZ x20, #0xad3bf8         | if (this._stack == null) goto label_5;  
            if(val_12 == null)
            {
                goto label_5;
            }
            // 0x00AD3BDC: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<ContainerContext>::get_Count();
            // 0x00AD3BE0: MOV x0, x20                | X0 = this._stack;//m1                   
            // 0x00AD3BE4: BL #0x25ed72c              | X0 = this._stack.get_Count();           
            int val_5 = val_12.Count;
            // 0x00AD3BE8: MOV w21, w0                | W21 = val_5;//m1                        
            val_11 = val_5;
            // 0x00AD3BEC: B #0xad3c14                |  goto label_6;                          
            goto label_6;
            label_4:
            // 0x00AD3BF0: STR xzr, [x19, #0x70]      | this._currentContext = null;             //  dest_result_addr=1152921513718130816
            this._currentContext = 0;
            // 0x00AD3BF4: B #0xad3c30                |  goto label_7;                          
            goto label_7;
            label_5:
            // 0x00AD3BF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00AD3BFC: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<ContainerContext>::get_Count();
            // 0x00AD3C00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD3C04: BL #0x25ed72c              | X0 = 0.get_Count();                     
            int val_6 = 0.Count;
            // 0x00AD3C08: MOV w21, w0                | W21 = val_6;//m1                        
            val_11 = val_6;
            // 0x00AD3C0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x00AD3C10: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_12 = 0;
            label_6:
            // 0x00AD3C14: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x00AD3C18: LDR x8, [x8, #0x8c0]       | X8 = 1152921513718101584;               
            // 0x00AD3C1C: SUB w1, w21, #1            | W1 = (val_6 - 1);                       
            int val_7 = val_11 - 1;
            // 0x00AD3C20: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x00AD3C24: LDR x2, [x8]               | X2 = public ContainerContext System.Collections.Generic.List<ContainerContext>::get_Item(int index);
            // 0x00AD3C28: BL #0x25ed734              | X0 = val_12.get_Item(index:  int val_7 = val_11 - 1);
            ContainerContext val_8 = val_12.Item[val_7];
            // 0x00AD3C2C: STR x0, [x19, #0x70]       | this._currentContext = val_8;            //  dest_result_addr=1152921513718130816
            this._currentContext = val_8;
            label_7:
            // 0x00AD3C30: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3C34: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3C38: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD3C3C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3568 (11351400), len: 116  VirtAddr: 0x00AD3568 RVA: 0x00AD3568 token: 100684742 methodIndex: 47402 delegateWrapperIndex: 0 methodInvoker: 0
        private void PushContext(Newtonsoft.Json.Bson.BsonReader.ContainerContext newContext)
        {
            //
            // Disasemble & Code
            // 0x00AD3568: STP x22, x21, [sp, #-0x30]! | stack[1152921513718256256] = ???;  stack[1152921513718256264] = ???;  //  dest_result_addr=1152921513718256256 |  dest_result_addr=1152921513718256264
            // 0x00AD356C: STP x20, x19, [sp, #0x10]  | stack[1152921513718256272] = ???;  stack[1152921513718256280] = ???;  //  dest_result_addr=1152921513718256272 |  dest_result_addr=1152921513718256280
            // 0x00AD3570: STP x29, x30, [sp, #0x20]  | stack[1152921513718256288] = ???;  stack[1152921513718256296] = ???;  //  dest_result_addr=1152921513718256288 |  dest_result_addr=1152921513718256296
            // 0x00AD3574: ADD x29, sp, #0x20         | X29 = (1152921513718256256 + 32) = 1152921513718256288 (0x100000021F1512A0);
            // 0x00AD3578: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD357C: LDRB w8, [x21, #0x4d8]     | W8 = (bool)static_value_037334D8;       
            // 0x00AD3580: MOV x19, x1                | X19 = newContext;//m1                   
            // 0x00AD3584: MOV x20, x0                | X20 = 1152921513718268304 (0x100000021F154190);//ML01
            // 0x00AD3588: TBNZ w8, #0, #0xad35a4     | if (static_value_037334D8 == true) goto label_0;
            // 0x00AD358C: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00AD3590: LDR x8, [x8, #0x900]       | X8 = 0x2B8F9AC;                         
            // 0x00AD3594: LDR w0, [x8]               | W0 = 0x152F;                            
            // 0x00AD3598: BL #0x2782188              | X0 = sub_2782188( ?? 0x152F, ????);     
            // 0x00AD359C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD35A0: STRB w8, [x21, #0x4d8]     | static_value_037334D8 = true;            //  dest_result_addr=57881816
            label_0:
            // 0x00AD35A4: LDR x21, [x20, #0x50]      | X21 = this._stack; //P2                 
            // 0x00AD35A8: CBNZ x21, #0xad35b0        | if (this._stack != null) goto label_1;  
            if(this._stack != null)
            {
                goto label_1;
            }
            // 0x00AD35AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x152F, ????);     
            label_1:
            // 0x00AD35B0: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x00AD35B4: LDR x8, [x8, #0x138]       | X8 = 1152921513718243280;               
            // 0x00AD35B8: MOV x0, x21                | X0 = this._stack;//m1                   
            // 0x00AD35BC: MOV x1, x19                | X1 = newContext;//m1                    
            // 0x00AD35C0: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<ContainerContext>::Add(ContainerContext item);
            // 0x00AD35C4: BL #0x25ea480              | this._stack.Add(item:  newContext);     
            this._stack.Add(item:  newContext);
            // 0x00AD35C8: STR x19, [x20, #0x70]      | this._currentContext = newContext;       //  dest_result_addr=1152921513718268416
            this._currentContext = newContext;
            // 0x00AD35CC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD35D0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD35D4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD35D8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3ADC (11352796), len: 60  VirtAddr: 0x00AD3ADC RVA: 0x00AD3ADC token: 100684743 methodIndex: 47403 delegateWrapperIndex: 0 methodInvoker: 0
        private byte ReadByte()
        {
            //
            // Disasemble & Code
            // 0x00AD3ADC: STP x20, x19, [sp, #-0x20]! | stack[1152921513718380560] = ???;  stack[1152921513718380568] = ???;  //  dest_result_addr=1152921513718380560 |  dest_result_addr=1152921513718380568
            // 0x00AD3AE0: STP x29, x30, [sp, #0x10]  | stack[1152921513718380576] = ???;  stack[1152921513718380584] = ???;  //  dest_result_addr=1152921513718380576 |  dest_result_addr=1152921513718380584
            // 0x00AD3AE4: ADD x29, sp, #0x10         | X29 = (1152921513718380560 + 16) = 1152921513718380576 (0x100000021F16F820);
            // 0x00AD3AE8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD3AEC: MOV x19, x0                | X19 = 1152921513718392592 (0x100000021F172710);//ML01
            // 0x00AD3AF0: BL #0xad3c40               | this.MovePosition(count:  1);           
            this.MovePosition(count:  1);
            // 0x00AD3AF4: LDR x19, [x19, #0x48]      | X19 = this._reader; //P2                
            // 0x00AD3AF8: CBNZ x19, #0xad3b00        | if (this._reader != null) goto label_0; 
            if(this._reader != null)
            {
                goto label_0;
            }
            // 0x00AD3AFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD3B00: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD3B04: MOV x0, x19                | X0 = this._reader;//m1                  
            // 0x00AD3B08: LDP x2, x1, [x8, #0x1e0]   | X2 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E0; X1 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E8; //  | 
            // 0x00AD3B0C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3B10: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3B14: BR x2                      | goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E0;
            goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E0;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD361C (11351580), len: 1216  VirtAddr: 0x00AD361C RVA: 0x00AD361C token: 100684744 methodIndex: 47404 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadType(Newtonsoft.Json.Bson.BsonType type)
        {
            //
            // Disasemble & Code
            //  | 
            System.DateTimeKind val_21;
            //  | 
            int val_22;
            //  | 
            var val_23;
            //  | 
            ContainerContext val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            long val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            var val_31;
            // 0x00AD361C: STP x22, x21, [sp, #-0x30]! | stack[1152921513718616576] = ???;  stack[1152921513718616584] = ???;  //  dest_result_addr=1152921513718616576 |  dest_result_addr=1152921513718616584
            // 0x00AD3620: STP x20, x19, [sp, #0x10]  | stack[1152921513718616592] = ???;  stack[1152921513718616600] = ???;  //  dest_result_addr=1152921513718616592 |  dest_result_addr=1152921513718616600
            // 0x00AD3624: STP x29, x30, [sp, #0x20]  | stack[1152921513718616608] = ???;  stack[1152921513718616616] = ???;  //  dest_result_addr=1152921513718616608 |  dest_result_addr=1152921513718616616
            // 0x00AD3628: ADD x29, sp, #0x20         | X29 = (1152921513718616576 + 32) = 1152921513718616608 (0x100000021F1A9220);
            // 0x00AD362C: SUB sp, sp, #0x20          | SP = (1152921513718616576 - 32) = 1152921513718616544 (0x100000021F1A91E0);
            // 0x00AD3630: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD3634: LDRB w8, [x21, #0x4d9]     | W8 = (bool)static_value_037334D9;       
            // 0x00AD3638: MOV w20, w1                | W20 = type;//m1                         
            // 0x00AD363C: MOV x19, x0                | X19 = 1152921513718628624 (0x100000021F1AC110);//ML01
            val_22 = this;
            // 0x00AD3640: TBNZ w8, #0, #0xad365c     | if (static_value_037334D9 == true) goto label_0;
            // 0x00AD3644: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00AD3648: LDR x8, [x8, #0xb58]       | X8 = 0x2B8F9D0;                         
            // 0x00AD364C: LDR w0, [x8]               | W0 = 0x1538;                            
            // 0x00AD3650: BL #0x2782188              | X0 = sub_2782188( ?? 0x1538, ????);     
            // 0x00AD3654: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD3658: STRB w8, [x21, #0x4d9]     | static_value_037334D9 = true;            //  dest_result_addr=57881817
            label_0:
            // 0x00AD365C: SXTB w8, w20               | W8 = (int)(sbyte)((type) & 0xFF);       
            var val_21 = (int)type & 255;
            // 0x00AD3660: SUB w8, w8, #1             | W8 = ((int)(sbyte)((type) & 0xFF) - 1); 
            val_21 = val_21 - 1;
            // 0x00AD3664: STP xzr, xzr, [sp, #0x10]  | stack[1152921513718616560] = 0x0;  stack[1152921513718616568] = 0x0;  //  dest_result_addr=1152921513718616560 |  dest_result_addr=1152921513718616568
            // 0x00AD3668: CMP w8, #0x11              | STATE = COMPARE(((int)(sbyte)((type) & 0xFF) - 1), 0x11)
            // 0x00AD366C: B.HI #0xad3a34             | if ((int)type & 255 > 0x11) goto label_1;
            if(val_21 > 17)
            {
                goto label_1;
            }
            // 0x00AD3670: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00AD3674: ADD x9, x9, #0x720         | X9 = (44638208 + 1824) = 44640032 (0x02A92720);
            // 0x00AD3678: LDR w8, [x9, w8, sxtw #2]  | W8 = 44640032 + (((int)(sbyte)((type) & 0xFF) - 1)) << 2;
            // 0x00AD367C: CMP w8, #0x12              | STATE = COMPARE(44640032 + (((int)(sbyte)((type) & 0xFF) - 1)) << 2, 0x12)
            // 0x00AD3680: B.HI #0xad3a20             | if (44640032 + (((int)(sbyte)((type) & 0xFF) - 1)) << 2 > 0x12) goto label_26;
            if((44640032 + (((int)(sbyte)((type) & 0xFF) - 1)) << 2) > 18)
            {
                goto label_26;
            }
            // 0x00AD3684: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00AD3688: ADD x9, x9, #0x5b4         | X9 = (44638208 + 1460) = 44639668 (0x02A925B4);
            // 0x00AD368C: LDRSW x8, [x9, x8, lsl #2] | X8 = 44639668 + (44640032 + (((int)(sbyte)((type) & 0xFF) - 1)) << 2) << 2;
            var val_22 = 44639668 + (44640032 + (((int)(sbyte)((type) & 0xFF) - 1)) << 2) << 2;
            // 0x00AD3690: ADD x8, x8, x9             | X8 = (44639668 + (44640032 + (((int)(sbyte)((type) & 0xFF) - 1)) << 2) << 2 + 44639668);
            val_22 = val_22 + 44639668;
            // 0x00AD3694: BR x8                      | goto (44639668 + (44640032 + (((int)(sbyte)((type) & 0xFF) - 1)) << 2) << 2 + 44639668);
            goto (44639668 + (44640032 + (((int)(sbyte)((type) & 0xFF) - 1)) << 2) << 2 + 44639668);
            // 0x00AD3698: MOV x0, x19                | X0 = 1152921513718628624 (0x100000021F1AC110);//ML01
            // 0x00AD369C: BL #0xad34dc               | X0 = this.ReadLengthString();           
            string val_1 = this.ReadLengthString();
            // 0x00AD36A0: B #0xad392c                |  goto label_3;                          
            goto label_3;
            // 0x00AD36A4: MOV x0, x19                | X0 = 1152921513718628624 (0x100000021F1AC110);//ML01
            // 0x00AD36A8: BL #0xad3c8c               | X0 = this.ReadDouble();                 
            double val_2 = this.ReadDouble();
            // 0x00AD36AC: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00AD36B0: LDR x8, [x8, #0x900]       | X8 = 1152921504608497664;               
            // 0x00AD36B4: MOV x1, sp                 | X1 = 1152921513718616544 (0x100000021F1A91E0);//ML01
            // 0x00AD36B8: STR d0, [sp]               | stack[1152921513718616544] = val_2;      //  dest_result_addr=1152921513718616544
            // 0x00AD36BC: LDR x0, [x8]               | X0 = typeof(System.Double);             
            // 0x00AD36C0: BL #0x27bc028              | X0 = 1152921513718668816 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Double), val_2);
            // 0x00AD36C4: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD36C8: MOV x2, x0                 | X2 = 1152921513718668816 (0x100000021F1B5E10);//ML01
            // 0x00AD36CC: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x00AD36D0: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_200;
            // 0x00AD36D4: LDR x3, [x8, #0x208]       | X3 = typeof(Newtonsoft.Json.Bson.BsonReader).__il2cppRuntimeField_208;
            // 0x00AD36D8: B #0xad3a18                |  goto label_28;                         
            goto label_28;
            // 0x00AD36DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD36E0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD36E4: MOV x0, x19                | X0 = 1152921513718628624 (0x100000021F1AC110);//ML01
            // 0x00AD36E8: BL #0x1313534              | this.SetToken(newToken:  1);            
            this.SetToken(newToken:  1);
            // 0x00AD36EC: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AD36F0: LDR x8, [x8, #0x668]       | X8 = 1152921504857645056;               
            // 0x00AD36F4: LDR x0, [x8]               | X0 = typeof(BsonReader.ContainerContext);
            object val_3 = null;
            // 0x00AD36F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BsonReader.ContainerContext), ????);
            // 0x00AD36FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD3700: MOV x20, x0                | X20 = 1152921504857645056 (0x100000000EF2E000);//ML01
            val_24 = val_3;
            // 0x00AD3704: BL #0x16f59f0              | .ctor();                                
            val_3 = new System.Object();
            // 0x00AD3708: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            val_25 = 3;
            // 0x00AD370C: B #0xad3740                |  goto label_5;                          
            goto label_5;
            // 0x00AD3710: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD3714: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00AD3718: MOV x0, x19                | X0 = 1152921513718628624 (0x100000021F1AC110);//ML01
            // 0x00AD371C: BL #0x1313534              | this.SetToken(newToken:  2);            
            this.SetToken(newToken:  2);
            // 0x00AD3720: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AD3724: LDR x8, [x8, #0x668]       | X8 = 1152921504857645056;               
            // 0x00AD3728: LDR x0, [x8]               | X0 = typeof(BsonReader.ContainerContext);
            object val_4 = null;
            // 0x00AD372C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BsonReader.ContainerContext), ????);
            // 0x00AD3730: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD3734: MOV x20, x0                | X20 = 1152921504857645056 (0x100000000EF2E000);//ML01
            val_24 = val_4;
            // 0x00AD3738: BL #0x16f59f0              | .ctor();                                
            val_4 = new System.Object();
            // 0x00AD373C: ORR w8, wzr, #4            | W8 = 4(0x4);                            
            val_25 = 4;
            label_5:
            // 0x00AD3740: MOV x0, x19                | X0 = 1152921513718628624 (0x100000021F1AC110);//ML01
            // 0x00AD3744: MOV x1, x20                | X1 = 1152921504857645056 (0x100000000EF2E000);//ML01
            // 0x00AD3748: STRB w8, [x20, #0x10]      | typeof(BsonReader.ContainerContext).__il2cppRuntimeField_10 = 0x4;  //  dest_result_addr=1152921504857645072
            typeof(BsonReader.ContainerContext).__il2cppRuntimeField_10 = val_25;
            // 0x00AD374C: BL #0xad3568               | this.PushContext(newContext:  val_24);  
            this.PushContext(newContext:  val_24);
            // 0x00AD3750: MOV x0, x19                | X0 = 1152921513718628624 (0x100000021F1AC110);//ML01
            // 0x00AD3754: BL #0xad349c               | X0 = this.ReadInt32();                  
            int val_5 = this.ReadInt32();
            // 0x00AD3758: MOV w19, w0                | W19 = val_5;//m1                        
            val_22 = val_5;
            // 0x00AD375C: CBNZ x20, #0xad3764        | if ( != 0) goto label_6;                
            if(null != 0)
            {
                goto label_6;
            }
            // 0x00AD3760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_6:
            // 0x00AD3764: STR w19, [x20, #0x14]      | typeof(BsonReader.ContainerContext).__il2cppRuntimeField_14 = val_5;  //  dest_result_addr=1152921504857645076
            typeof(BsonReader.ContainerContext).__il2cppRuntimeField_14 = val_22;
            // 0x00AD3768: B #0xad3a20                |  goto label_26;                         
            goto label_26;
            // 0x00AD376C: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD3770: BL #0xad3ccc               | X0 = val_5.ReadBinary();                
            System.Byte[] val_6 = val_22.ReadBinary();
            // 0x00AD3774: B #0xad3790                |  goto label_8;                          
            goto label_8;
            // 0x00AD3778: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD377C: ORR w1, wzr, #0xc          | W1 = 12(0xC);                           
            val_27 = 12;
            // 0x00AD3780: B #0xad38c0                |  goto label_9;                          
            goto label_9;
            // 0x00AD3784: ORR w1, wzr, #0xc          | W1 = 12(0xC);                           
            // 0x00AD3788: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD378C: BL #0xad35dc               | X0 = val_5.ReadBytes(count:  12);       
            System.Byte[] val_7 = val_22.ReadBytes(count:  12);
            label_8:
            // 0x00AD3790: LDR x8, [x19]              | X8 = val_5;                             
            // 0x00AD3794: MOV x2, x0                 | X2 = val_7;//m1                         
            // 0x00AD3798: MOVZ w1, #0x11             | W1 = 17 (0x11);//ML01                   
            // 0x00AD379C: LDR x9, [x8, #0x200]       | X9 = val_5 + 512;                       
            // 0x00AD37A0: LDR x3, [x8, #0x208]       | X3 = val_5 + 520;                       
            // 0x00AD37A4: B #0xad3a18                |  goto label_28;                         
            goto label_28;
            // 0x00AD37A8: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD37AC: BL #0xad3adc               | X0 = val_5.ReadByte();                  
            byte val_8 = val_22.ReadByte();
            // 0x00AD37B0: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00AD37B4: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x00AD37B8: MOV w20, w0                | W20 = val_8;//m1                        
            // 0x00AD37BC: LDR x8, [x8]               | X8 = typeof(System.Convert);            
            // 0x00AD37C0: LDRB w9, [x8, #0x10a]      | W9 = System.Convert.__il2cppRuntimeField_10A;
            // 0x00AD37C4: TBZ w9, #0, #0xad37d8      | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00AD37C8: LDR w9, [x8, #0xbc]        | W9 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x00AD37CC: CBNZ w9, #0xad37d8         | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00AD37D0: MOV x0, x8                 | X0 = 1152921504652587008 (0x1000000002B9F000);//ML01
            // 0x00AD37D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_12:
            // 0x00AD37D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD37DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD37E0: MOV w1, w20                | W1 = val_8;//m1                         
            // 0x00AD37E4: BL #0x1ba2434              | X0 = System.Convert.ToBoolean(value:  0);
            bool val_9 = System.Convert.ToBoolean(value:  0);
            // 0x00AD37E8: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00AD37EC: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00AD37F0: AND w9, w0, #1             | W9 = (val_9 & 1);                       
            bool val_10 = val_9;
            // 0x00AD37F4: MOV x1, sp                 | X1 = 1152921513718616544 (0x100000021F1A91E0);//ML01
            // 0x00AD37F8: STRB w9, [sp]              | stack[1152921513718616544] = (val_9 & 1);  //  dest_result_addr=1152921513718616544
            // 0x00AD37FC: LDR x8, [x8]               | X8 = typeof(System.Boolean);            
            // 0x00AD3800: MOV x0, x8                 | X0 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x00AD3804: BL #0x27bc028              | X0 = 1152921513718746640 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), (val_9 & 1));
            // 0x00AD3808: LDR x8, [x19]              | X8 = val_5;                             
            // 0x00AD380C: MOV x2, x0                 | X2 = 1152921513718746640 (0x100000021F1C8E10);//ML01
            // 0x00AD3810: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
            // 0x00AD3814: LDR x9, [x8, #0x200]       | X9 = val_5 + 512;                       
            // 0x00AD3818: LDR x3, [x8, #0x208]       | X3 = val_5 + 520;                       
            // 0x00AD381C: B #0xad3a18                |  goto label_28;                         
            goto label_28;
            // 0x00AD3820: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD3824: BL #0xad3d20               | X0 = val_5.ReadInt64();                 
            long val_11 = val_22.ReadInt64();
            // 0x00AD3828: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x00AD382C: LDR x8, [x8, #0x9c8]       | X8 = 1152921504859615232;               
            // 0x00AD3830: MOV x20, x0                | X20 = val_11;//m1                       
            // 0x00AD3834: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonConvert);
            // 0x00AD3838: LDRB w9, [x8, #0x10a]      | W9 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_10A;
            // 0x00AD383C: TBZ w9, #0, #0xad3850      | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00AD3840: LDR w9, [x8, #0xbc]        | W9 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished;
            // 0x00AD3844: CBNZ w9, #0xad3850         | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00AD3848: MOV x0, x8                 | X0 = 1152921504859615232 (0x100000000F10F000);//ML01
            // 0x00AD384C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.JsonConvert), ????);
            label_15:
            // 0x00AD3850: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD3854: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD3858: MOV x1, x20                | X1 = val_11;//m1                        
            // 0x00AD385C: BL #0x1304760              | X0 = Newtonsoft.Json.JsonConvert.ConvertJavaScriptTicksToDateTime(javaScriptTicks:  0);
            System.DateTime val_12 = Newtonsoft.Json.JsonConvert.ConvertJavaScriptTicksToDateTime(javaScriptTicks:  0);
            // 0x00AD3860: MOV x20, x0                | X20 = val_12.ticks._ticks;//m1          
            val_28 = val_12.ticks._ticks;
            // 0x00AD3864: MOV x21, x1                | X21 = val_12.kind;//m1                  
            val_21 = val_12.kind;
            // 0x00AD3868: STP x20, x21, [sp, #0x10]  | stack[1152921513718616560] = val_12.ticks._ticks;  stack[1152921513718616568] = val_12.kind;  //  dest_result_addr=1152921513718616560 |  dest_result_addr=1152921513718616568
            // 0x00AD386C: LDR w8, [x19, #0x7c]       | W8 = val_5 + 124;                       
            // 0x00AD3870: CMP w8, #2                 | STATE = COMPARE(val_5 + 124, 0x2)       
            // 0x00AD3874: B.EQ #0xad39d8             | if (val_5 + 124 == 0x2) goto label_16;  
            if((val_5 + 124) == 2)
            {
                goto label_16;
            }
            // 0x00AD3878: CBNZ w8, #0xad39ec         | if (val_5 + 124 != 0) goto label_17;    
            if((val_5 + 124) != 0)
            {
                goto label_17;
            }
            // 0x00AD387C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00AD3880: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
            // 0x00AD3884: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
            // 0x00AD3888: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x00AD388C: TBZ w8, #0, #0xad389c      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00AD3890: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x00AD3894: CBNZ w8, #0xad389c         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00AD3898: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            label_19:
            // 0x00AD389C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD38A0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
            // 0x00AD38A4: MOV x1, x20                | X1 = val_12.ticks._ticks;//m1           
            // 0x00AD38A8: MOV x2, x21                | X2 = val_12.kind;//m1                   
            // 0x00AD38AC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD38B0: BL #0x1bb0a64              | X0 = System.DateTime.SpecifyKind(value:  new System.DateTime() {ticks = new System.TimeSpan(), kind = val_28}, kind:  val_21);
            System.DateTime val_13 = System.DateTime.SpecifyKind(value:  new System.DateTime() {ticks = new System.TimeSpan(), kind = val_28}, kind:  val_21);
            // 0x00AD38B4: B #0xad39e4                |  goto label_20;                         
            goto label_20;
            // 0x00AD38B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD38BC: MOVZ w1, #0xb              | W1 = 11 (0xB);//ML01                    
            val_27 = 11;
            label_9:
            // 0x00AD38C0: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD38C4: BL #0x1313534              | val_5.SetToken(newToken:  11);          
            val_22.SetToken(newToken:  11);
            // 0x00AD38C8: B #0xad3a20                |  goto label_26;                         
            goto label_26;
            // 0x00AD38CC: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD38D0: BL #0xad200c               | X0 = val_5.ReadString();                
            string val_14 = val_22.ReadString();
            // 0x00AD38D4: MOV x20, x0                | X20 = val_14;//m1                       
            // 0x00AD38D8: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD38DC: BL #0xad200c               | X0 = val_5.ReadString();                
            string val_15 = val_22.ReadString();
            // 0x00AD38E0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AD38E4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AD38E8: MOV x21, x0                | X21 = val_15;//m1                       
            val_21 = val_15;
            // 0x00AD38EC: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00AD38F0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00AD38F4: TBZ w9, #0, #0xad3908      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x00AD38F8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AD38FC: CBNZ w9, #0xad3908         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x00AD3900: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AD3904: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_23:
            // 0x00AD3908: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x00AD390C: LDR x8, [x8, #0x458]       | X8 = (string**)(1152921509471652944)("/");
            // 0x00AD3910: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD3914: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00AD3918: MOV x2, x20                | X2 = val_14;//m1                        
            // 0x00AD391C: LDR x1, [x8]               | X1 = "/";                               
            // 0x00AD3920: MOV x4, x21                | X4 = val_15;//m1                        
            // 0x00AD3924: MOV x3, x1                 | X3 = 1152921509471652944 (0x1000000121F70C50);//ML01
            // 0x00AD3928: BL #0x18b0400              | X0 = System.String.Concat(str0:  0, str1:  "/", str2:  val_14, str3:  "/");
            string val_16 = System.String.Concat(str0:  0, str1:  "/", str2:  val_14, str3:  "/");
            label_3:
            // 0x00AD392C: LDR x8, [x19]              | X8 = val_5;                             
            // 0x00AD3930: MOV x2, x0                 | X2 = val_16;//m1                        
            // 0x00AD3934: MOVZ w1, #0x9              | W1 = 9 (0x9);//ML01                     
            // 0x00AD3938: LDR x9, [x8, #0x200]       | X9 = val_5 + 512;                       
            // 0x00AD393C: LDR x3, [x8, #0x208]       | X3 = val_5 + 520;                       
            // 0x00AD3940: B #0xad3a18                |  goto label_28;                         
            goto label_28;
            // 0x00AD3944: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD3948: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD394C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD3950: ORR w20, wzr, #1           | W20 = 1(0x1);                           
            // 0x00AD3954: BL #0x1313534              | val_5.SetToken(newToken:  1);           
            val_22.SetToken(newToken:  1);
            // 0x00AD3958: STR w20, [x19, #0x6c]      | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00AD395C: B #0xad3a20                |  goto label_26;                         
            goto label_26;
            // 0x00AD3960: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD3964: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD3968: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD396C: BL #0x1313534              | val_5.SetToken(newToken:  1);           
            val_22.SetToken(newToken:  1);
            // 0x00AD3970: ORR w8, wzr, #4            | W8 = 4(0x4);                            
            // 0x00AD3974: STR w8, [x19, #0x6c]       | mem2[0] = 0x4;                           //  dest_result_addr=0
            mem2[0] = 4;
            // 0x00AD3978: B #0xad3a20                |  goto label_26;                         
            goto label_26;
            // 0x00AD397C: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD3980: BL #0xad349c               | X0 = val_5.ReadInt32();                 
            int val_17 = val_22.ReadInt32();
            // 0x00AD3984: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x00AD3988: LDR x8, [x8, #0x4b0]       | X8 = 1152921504607592448;               
            // 0x00AD398C: SXTW x9, w0                | X9 = (long)(int)(val_17);               
            // 0x00AD3990: STR x9, [sp]               | stack[1152921513718616544] = (long)(int)(val_17);  //  dest_result_addr=1152921513718616544
            // 0x00AD3994: LDR x8, [x8]               | X8 = typeof(System.Int64);              
            val_31 = null;
            // 0x00AD3998: B #0xad39b4                |  goto label_27;                         
            goto label_27;
            // 0x00AD399C: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD39A0: BL #0xad3d20               | X0 = val_5.ReadInt64();                 
            long val_18 = val_22.ReadInt64();
            // 0x00AD39A4: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x00AD39A8: LDR x8, [x8, #0x4b0]       | X8 = 1152921504607592448;               
            // 0x00AD39AC: STR x0, [sp]               | stack[1152921513718616544] = val_18;     //  dest_result_addr=1152921513718616544
            // 0x00AD39B0: LDR x8, [x8]               | X8 = typeof(System.Int64);              
            val_31 = null;
            label_27:
            // 0x00AD39B4: MOV x1, sp                 | X1 = 1152921513718616544 (0x100000021F1A91E0);//ML01
            // 0x00AD39B8: MOV x0, x8                 | X0 = 1152921504607592448 (0x10000000000B6000);//ML01
            // 0x00AD39BC: BL #0x27bc028              | X0 = 1152921513718763024 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), val_18);
            // 0x00AD39C0: LDR x8, [x19]              | X8 = val_5;                             
            // 0x00AD39C4: MOV x2, x0                 | X2 = 1152921513718763024 (0x100000021F1CCE10);//ML01
            // 0x00AD39C8: ORR w1, wzr, #7            | W1 = 7(0x7);                            
            // 0x00AD39CC: LDR x9, [x8, #0x200]       | X9 = val_5 + 512;                       
            // 0x00AD39D0: LDR x3, [x8, #0x208]       | X3 = val_5 + 520;                       
            // 0x00AD39D4: B #0xad3a18                |  goto label_28;                         
            goto label_28;
            label_16:
            // 0x00AD39D8: ADD x0, sp, #0x10          | X0 = (1152921513718616544 + 16) = 1152921513718616560 (0x100000021F1A91F0);
            // 0x00AD39DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_30 = 0;
            // 0x00AD39E0: BL #0x1bb09dc              | X0 = label_System_DateTime_FromBinary_GL01BB09DC();
            label_20:
            // 0x00AD39E4: MOV x20, x0                | X20 = 1152921513718616560 (0x100000021F1A91F0);//ML01
            val_28;
            // 0x00AD39E8: MOV x21, x1                | X21 = 0 (0x0);//ML01                    
            val_21 = val_30;
            label_17:
            // 0x00AD39EC: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00AD39F0: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
            // 0x00AD39F4: MOV x1, sp                 | X1 = 1152921513718616544 (0x100000021F1A91E0);//ML01
            // 0x00AD39F8: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
            // 0x00AD39FC: STP x20, x21, [sp]         | stack[1152921513718616544] = 0x100000021F1A91F0;  stack[1152921513718616552] = 0x0;  //  dest_result_addr=1152921513718616544 |  dest_result_addr=1152921513718616552
            // 0x00AD3A00: BL #0x27bc028              | X0 = 1152921513718767120 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.DateTime), 0x100000021F1A91F0);
            // 0x00AD3A04: LDR x8, [x19]              | X8 = val_5;                             
            // 0x00AD3A08: MOV x2, x0                 | X2 = 1152921513718767120 (0x100000021F1CDE10);//ML01
            // 0x00AD3A0C: ORR w1, wzr, #0x10         | W1 = 16(0x10);                          
            // 0x00AD3A10: LDR x9, [x8, #0x200]       | X9 = val_5 + 512;                       
            // 0x00AD3A14: LDR x3, [x8, #0x208]       | X3 = val_5 + 520;                       
            label_28:
            // 0x00AD3A18: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00AD3A1C: BLR x9                     | X0 = val_5 + 512();                     
            label_26:
            // 0x00AD3A20: SUB sp, x29, #0x20         | SP = (1152921513718616608 - 32) = 1152921513718616576 (0x100000021F1A9200);
            // 0x00AD3A24: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3A28: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3A2C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD3A30: RET                        |  return;                                
            return;
            label_1:
            // 0x00AD3A34: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00AD3A38: LDR x8, [x8, #0xc00]       | X8 = 1152921504858071040;               
            // 0x00AD3A3C: MOV x1, sp                 | X1 = 1152921513718616544 (0x100000021F1A91E0);//ML01
            // 0x00AD3A40: STRB w20, [sp]             | stack[1152921513718616544] = type;       //  dest_result_addr=1152921513718616544
            // 0x00AD3A44: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonType);
            // 0x00AD3A48: BL #0x27bc028              | X0 = 1152921513718771216 = (Il2CppObject*)Box((RuntimeClass*)typeof(Newtonsoft.Json.Bson.BsonType), type);
            // 0x00AD3A4C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AD3A50: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AD3A54: MOV x19, x0                | X19 = 1152921513718771216 (0x100000021F1CEE10);//ML01
            // 0x00AD3A58: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00AD3A5C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00AD3A60: TBZ w9, #0, #0xad3a74      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_30;
            // 0x00AD3A64: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AD3A68: CBNZ w9, #0xad3a74         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
            // 0x00AD3A6C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AD3A70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_30:
            // 0x00AD3A74: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x00AD3A78: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921513718599376)("Unexpected BsonType value: ");
            // 0x00AD3A7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD3A80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD3A84: MOV x2, x19                | X2 = 1152921513718771216 (0x100000021F1CEE10);//ML01
            // 0x00AD3A88: LDR x1, [x8]               | X1 = "Unexpected BsonType value: ";     
            // 0x00AD3A8C: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "Unexpected BsonType value: ");
            string val_19 = System.String.Concat(arg0:  0, arg1:  "Unexpected BsonType value: ");
            // 0x00AD3A90: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00AD3A94: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x00AD3A98: MOV x19, x0                | X19 = val_19;//m1                       
            // 0x00AD3A9C: LDR x8, [x8]               | X8 = typeof(System.ArgumentOutOfRangeException);
            // 0x00AD3AA0: MOV x0, x8                 | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            System.ArgumentOutOfRangeException val_20 = null;
            // 0x00AD3AA4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD3AA8: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00AD3AAC: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921510122301360)("type");
            // 0x00AD3AB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD3AB4: MOV x2, x19                | X2 = val_19;//m1                        
            // 0x00AD3AB8: MOV x20, x0                | X20 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD3ABC: LDR x1, [x8]               | X1 = "type";                            
            // 0x00AD3AC0: BL #0x18b3e8c              | .ctor(paramName:  "type", message:  val_19);
            val_20 = new System.ArgumentOutOfRangeException(paramName:  "type", message:  val_19);
            // 0x00AD3AC4: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x00AD3AC8: LDR x8, [x8, #0xfe8]       | X8 = 1152921513718603600;               
            // 0x00AD3ACC: MOV x0, x20                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD3AD0: LDR x1, [x8]               | X1 = System.Void Newtonsoft.Json.Bson.BsonReader::ReadType(Newtonsoft.Json.Bson.BsonType type);
            // 0x00AD3AD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD3AD8: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3CCC (11353292), len: 84  VirtAddr: 0x00AD3CCC RVA: 0x00AD3CCC token: 100684745 methodIndex: 47405 delegateWrapperIndex: 0 methodInvoker: 0
        private byte[] ReadBinary()
        {
            //
            // Disasemble & Code
            //  | 
            int val_5;
            // 0x00AD3CCC: STP x20, x19, [sp, #-0x20]! | stack[1152921513718847376] = ???;  stack[1152921513718847384] = ???;  //  dest_result_addr=1152921513718847376 |  dest_result_addr=1152921513718847384
            // 0x00AD3CD0: STP x29, x30, [sp, #0x10]  | stack[1152921513718847392] = ???;  stack[1152921513718847400] = ???;  //  dest_result_addr=1152921513718847392 |  dest_result_addr=1152921513718847400
            // 0x00AD3CD4: ADD x29, sp, #0x10         | X29 = (1152921513718847376 + 16) = 1152921513718847392 (0x100000021F1E17A0);
            // 0x00AD3CD8: MOV x19, x0                | X19 = 1152921513718859408 (0x100000021F1E4690);//ML01
            // 0x00AD3CDC: BL #0xad349c               | X0 = this.ReadInt32();                  
            int val_1 = this.ReadInt32();
            // 0x00AD3CE0: MOV w20, w0                | W20 = val_1;//m1                        
            val_5 = val_1;
            // 0x00AD3CE4: MOV x0, x19                | X0 = 1152921513718859408 (0x100000021F1E4690);//ML01
            // 0x00AD3CE8: BL #0xad3adc               | X0 = this.ReadByte();                   
            byte val_2 = this.ReadByte();
            // 0x00AD3CEC: AND w8, w0, #0xff          | W8 = (val_2 & 255);                     
            byte val_3 = val_2 & 255;
            // 0x00AD3CF0: CMP w8, #2                 | STATE = COMPARE((val_2 & 255), 0x2)     
            // 0x00AD3CF4: B.NE #0xad3d0c             | if (val_3 != 2) goto label_1;           
            if(val_3 != 2)
            {
                goto label_1;
            }
            // 0x00AD3CF8: LDRB w8, [x19, #0x79]      | W8 = this._jsonNet35BinaryCompatibility; //P2 
            // 0x00AD3CFC: CBNZ w8, #0xad3d0c         | if (this._jsonNet35BinaryCompatibility == true) goto label_1;
            if(this._jsonNet35BinaryCompatibility == true)
            {
                goto label_1;
            }
            // 0x00AD3D00: MOV x0, x19                | X0 = 1152921513718859408 (0x100000021F1E4690);//ML01
            // 0x00AD3D04: BL #0xad349c               | X0 = this.ReadInt32();                  
            int val_4 = this.ReadInt32();
            // 0x00AD3D08: MOV w20, w0                | W20 = val_4;//m1                        
            val_5 = val_4;
            label_1:
            // 0x00AD3D0C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3D10: MOV x0, x19                | X0 = 1152921513718859408 (0x100000021F1E4690);//ML01
            // 0x00AD3D14: MOV w1, w20                | W1 = val_4;//m1                         
            // 0x00AD3D18: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3D1C: B #0xad35dc                | return this.ReadBytes(count:  val_5);   
            return this.ReadBytes(count:  val_5);
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD200C (11345932), len: 776  VirtAddr: 0x00AD200C RVA: 0x00AD200C token: 100684746 methodIndex: 47406 delegateWrapperIndex: 0 methodInvoker: 0
        private string ReadString()
        {
            //
            // Disasemble & Code
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            // 0x00AD200C: STP x28, x27, [sp, #-0x60]! | stack[1152921513719160016] = ???;  stack[1152921513719160024] = ???;  //  dest_result_addr=1152921513719160016 |  dest_result_addr=1152921513719160024
            // 0x00AD2010: STP x26, x25, [sp, #0x10]  | stack[1152921513719160032] = ???;  stack[1152921513719160040] = ???;  //  dest_result_addr=1152921513719160032 |  dest_result_addr=1152921513719160040
            // 0x00AD2014: STP x24, x23, [sp, #0x20]  | stack[1152921513719160048] = ???;  stack[1152921513719160056] = ???;  //  dest_result_addr=1152921513719160048 |  dest_result_addr=1152921513719160056
            // 0x00AD2018: STP x22, x21, [sp, #0x30]  | stack[1152921513719160064] = ???;  stack[1152921513719160072] = ???;  //  dest_result_addr=1152921513719160064 |  dest_result_addr=1152921513719160072
            // 0x00AD201C: STP x20, x19, [sp, #0x40]  | stack[1152921513719160080] = ???;  stack[1152921513719160088] = ???;  //  dest_result_addr=1152921513719160080 |  dest_result_addr=1152921513719160088
            // 0x00AD2020: STP x29, x30, [sp, #0x50]  | stack[1152921513719160096] = ???;  stack[1152921513719160104] = ???;  //  dest_result_addr=1152921513719160096 |  dest_result_addr=1152921513719160104
            // 0x00AD2024: ADD x29, sp, #0x50         | X29 = (1152921513719160016 + 80) = 1152921513719160096 (0x100000021F22DD20);
            // 0x00AD2028: SUB sp, sp, #0x10          | SP = (1152921513719160016 - 16) = 1152921513719160000 (0x100000021F22DCC0);
            // 0x00AD202C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD2030: LDRB w8, [x20, #0x4da]     | W8 = (bool)static_value_037334DA;       
            // 0x00AD2034: MOV x19, x0                | X19 = 1152921513719172112 (0x100000021F230C10);//ML01
            // 0x00AD2038: TBNZ w8, #0, #0xad2054     | if (static_value_037334DA == true) goto label_0;
            // 0x00AD203C: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x00AD2040: LDR x8, [x8, #0x8d0]       | X8 = 0x2B8F9CC;                         
            // 0x00AD2044: LDR w0, [x8]               | W0 = 0x1537;                            
            // 0x00AD2048: BL #0x2782188              | X0 = sub_2782188( ?? 0x1537, ????);     
            // 0x00AD204C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD2050: STRB w8, [x20, #0x4da]     | static_value_037334DA = true;            //  dest_result_addr=57881818
            label_0:
            // 0x00AD2054: MOV x0, x19                | X0 = 1152921513719172112 (0x100000021F230C10);//ML01
            // 0x00AD2058: BL #0xad3d60               | this.EnsureBuffers();                   
            this.EnsureBuffers();
            // 0x00AD205C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x00AD2060: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x00AD2064: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_19 = 0;
            // 0x00AD2068: B #0xad2094                |  goto label_16;                         
            goto label_16;
            label_15:
            // 0x00AD206C: LDR x1, [x19, #0x58]       | X1 = this._byteBuffer; //P2             
            // 0x00AD2070: SUB w8, w21, w22           | W8 = (W21 - val_18);                    
            var val_1 = W21 - val_18;
            // 0x00AD2074: SUB w22, w8, #1            | W22 = ((W21 - val_18) - 1);             
            val_18 = val_1 - 1;
            // 0x00AD2078: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD207C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00AD2080: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00AD2084: MOV w2, w23                | W2 = W23;//m1                           
            // 0x00AD2088: MOV x3, x1                 | X3 = this._byteBuffer;//m1              
            // 0x00AD208C: MOV w5, w22                | W5 = ((W21 - val_18) - 1);//m1          
            // 0x00AD2090: BL #0x18ce87c              | System.Array.Copy(sourceArray:  0, sourceIndex:  this._byteBuffer, destinationArray:  W23, destinationIndex:  this._byteBuffer, length:  0);
            System.Array.Copy(sourceArray:  0, sourceIndex:  this._byteBuffer, destinationArray:  W23, destinationIndex:  this._byteBuffer, length:  0);
            label_16:
            // 0x00AD2094: CMP w22, #0x7f             | STATE = COMPARE(((W21 - val_18) - 1), 0x7F)
            // 0x00AD2098: MOV w8, w22                | W8 = ((W21 - val_18) - 1);//m1          
            val_20 = val_18;
            // 0x00AD209C: B.GT #0xad2118             | if (val_18 > 0x7F) goto label_2;        
            if(val_18 > 127)
            {
                goto label_2;
            }
            // 0x00AD20A0: SXTW x8, w22               | X8 = (long)(int)(((W21 - val_18) - 1)); 
            // 0x00AD20A4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00AD20A8: SUB x24, x8, #1            | X24 = ((long)(int)(((W21 - val_18) - 1)) - 1);
            val_22 = (long)val_18 - 1;
            label_7:
            // 0x00AD20AC: LDR x23, [x19, #0x48]      | X23 = this._reader; //P2                
            // 0x00AD20B0: CBNZ x23, #0xad20b8        | if (this._reader != null) goto label_3; 
            if(this._reader != null)
            {
                goto label_3;
            }
            // 0x00AD20B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_3:
            // 0x00AD20B8: LDR x8, [x23]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD20BC: MOV x0, x23                | X0 = this._reader;//m1                  
            // 0x00AD20C0: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E0; X1 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E8; //  | 
            // 0x00AD20C4: BLR x9                     | X0 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E0();
            // 0x00AD20C8: MOV w23, w0                | W23 = this._reader;//m1                 
            // 0x00AD20CC: AND w8, w23, #0xff         | W8 = (this._reader & 255);              
            System.IO.BinaryReader val_2 = this._reader & 255;
            // 0x00AD20D0: CBZ w8, #0xad2134          | if ((this._reader & 255) == null) goto label_4;
            if(val_2 == null)
            {
                goto label_4;
            }
            // 0x00AD20D4: LDR x25, [x19, #0x58]      | X25 = this._byteBuffer; //P2            
            // 0x00AD20D8: CBNZ x25, #0xad20e0        | if (this._byteBuffer != null) goto label_5;
            if(this._byteBuffer != null)
            {
                goto label_5;
            }
            // 0x00AD20DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._reader, ????);
            label_5:
            // 0x00AD20E0: LDR w8, [x25, #0x18]       | W8 = this._byteBuffer.Length; //P2      
            // 0x00AD20E4: ADD w9, w22, w21           | W9 = (((W21 - val_18) - 1) + val_21);   
            var val_3 = val_18 + val_21;
            // 0x00AD20E8: CMP w9, w8                 | STATE = COMPARE((((W21 - val_18) - 1) + val_21), this._byteBuffer.Length)
            // 0x00AD20EC: B.LO #0xad20fc             | if (val_3 < this._byteBuffer.Length) goto label_6;
            if(val_3 < this._byteBuffer.Length)
            {
                goto label_6;
            }
            // 0x00AD20F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this._reader, ????);
            // 0x00AD20F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD20F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this._reader, ????);
            label_6:
            // 0x00AD20FC: ADD x8, x25, x24           | X8 = this._byteBuffer[((long)(int)(((W21 - val_18) - 1)) - 1)]; //PARR1 
            // 0x00AD2100: ADD w21, w21, #1           | W21 = (val_21 + 1);                     
            val_21 = val_21 + 1;
            // 0x00AD2104: ADD x24, x24, #1           | X24 = (((long)(int)(((W21 - val_18) - 1)) - 1) + 1);
            val_22 = val_22 + 1;
            // 0x00AD2108: STRB w23, [x8, #0x21]      | this._byteBuffer[((long)(int)(((W21 - val_18) - 1)) - 1)][1] = this._reader;  //  dest_result_addr=0
            this._byteBuffer[val_22] = this._reader;
            // 0x00AD210C: CMP x24, #0x7f             | STATE = COMPARE((((long)(int)(((W21 - val_18) - 1)) - 1) + 1), 0x7F)
            // 0x00AD2110: B.LT #0xad20ac             | if (val_22 < 0x7F) goto label_7;        
            if(val_22 < 127)
            {
                goto label_7;
            }
            // 0x00AD2114: ADD w8, w22, w21           | W8 = (((W21 - val_18) - 1) + (val_21 + 1));
            val_20 = val_18 + val_21;
            label_2:
            // 0x00AD2118: SUB w21, w8, w22           | W21 = ((((W21 - val_18) - 1) + (val_21 + 1)) - ((W21 - val_18) - 1));
            val_21 = val_20 - val_18;
            // 0x00AD211C: CMP x20, #0                | STATE = COMPARE(0x0, 0x0)               
            // 0x00AD2120: ADD w28, w21, w28          | W28 = (((((W21 - val_18) - 1) + (val_21 + 1)) - ((W21 - val_18) - 1)) + 0);
            val_23 = val_21 + 0;
            // 0x00AD2124: CSET w27, eq               | W27 = val_19 == 0x0 ? 1 : 0;            
            var val_4 = (val_19 == 0) ? 1 : 0;
            // 0x00AD2128: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00AD212C: STR w9, [sp, #0xc]         | stack[1152921513719160012] = 0x1;        //  dest_result_addr=1152921513719160012
            // 0x00AD2130: B #0xad2148                |  goto label_8;                          
            goto label_8;
            label_4:
            // 0x00AD2134: CBZ x20, #0xad2268         | if (0x0 == 0) goto label_9;             
            if(val_19 == 0)
            {
                goto label_9;
            }
            // 0x00AD2138: STR wzr, [sp, #0xc]        | stack[1152921513719160012] = 0x0;        //  dest_result_addr=1152921513719160012
            // 0x00AD213C: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_24 = 0;
            // 0x00AD2140: ADD w8, w22, w21           | W8 = (((W21 - val_18) - 1) + val_21);   
            val_20 = val_18 + val_21;
            // 0x00AD2144: ADD w28, w28, w21          | W28 = (0 + val_21);                     
            val_23 = 0 + val_21;
            label_8:
            // 0x00AD2148: SUB w1, w8, #1             | W1 = ((((W21 - val_18) - 1) + val_21) - 1);
            int val_5 = val_20 - 1;
            // 0x00AD214C: MOV x0, x19                | X0 = 1152921513719172112 (0x100000021F230C10);//ML01
            // 0x00AD2150: BL #0xad3e54               | X0 = this.GetLastFullCharStop(start:  int val_5 = val_20 - 1);
            int val_6 = this.GetLastFullCharStop(start:  val_5);
            // 0x00AD2154: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00AD2158: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x00AD215C: MOV w22, w0                | W22 = val_6;//m1                        
            // 0x00AD2160: LDR x8, [x8]               | X8 = typeof(System.Text.Encoding);      
            // 0x00AD2164: LDRB w9, [x8, #0x10a]      | W9 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x00AD2168: TBZ w9, #0, #0xad217c      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00AD216C: LDR w9, [x8, #0xbc]        | W9 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x00AD2170: CBNZ w9, #0xad217c         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00AD2174: MOV x0, x8                 | X0 = 1152921504649285632 (0x1000000002879000);//ML01
            // 0x00AD2178: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_11:
            // 0x00AD217C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD2180: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2184: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_7 = System.Text.Encoding.UTF8;
            // 0x00AD2188: LDP x25, x24, [x19, #0x58] | X25 = this._byteBuffer; //P2  X24 = this._charBuffer; //P2  //  | 
            // 0x00AD218C: MOV x26, x0                | X26 = val_7;//m1                        
            // 0x00AD2190: CBNZ x26, #0xad2198        | if (val_7 != null) goto label_12;       
            if(val_7 != null)
            {
                goto label_12;
            }
            // 0x00AD2194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_12:
            // 0x00AD2198: LDR x8, [x26]              | X8 = typeof(System.Text.Encoding);      
            // 0x00AD219C: ADD w23, w22, #1           | W23 = (val_6 + 1);                      
            int val_8 = val_6 + 1;
            // 0x00AD21A0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD21A4: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x00AD21A8: LDR x9, [x8, #0x210]       | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_210;
            // 0x00AD21AC: LDR x6, [x8, #0x218]       | X6 = typeof(System.Text.Encoding).__il2cppRuntimeField_218;
            // 0x00AD21B0: MOV x0, x26                | X0 = val_7;//m1                         
            // 0x00AD21B4: MOV x1, x25                | X1 = this._byteBuffer;//m1              
            // 0x00AD21B8: MOV w3, w23                | W3 = (val_6 + 1);//m1                   
            // 0x00AD21BC: MOV x4, x24                | X4 = this._charBuffer;//m1              
            // 0x00AD21C0: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_210();
            // 0x00AD21C4: MOV w24, w0                | W24 = val_7;//m1                        
            // 0x00AD21C8: CBZ w27, #0xad21ec         | if (0x0 == 0) goto label_13;            
            if(val_24 == 0)
            {
                goto label_13;
            }
            // 0x00AD21CC: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00AD21D0: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x00AD21D4: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_9 = null;
            // 0x00AD21D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x00AD21DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD21E0: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
            // 0x00AD21E4: MOV x20, x0                | X20 = 1152921504649605120 (0x10000000028C7000);//ML01
            val_19 = val_9;
            // 0x00AD21E8: BL #0x1b5a3c4              | .ctor(capacity:  256);                  
            val_9 = new System.Text.StringBuilder(capacity:  256);
            label_13:
            // 0x00AD21EC: LDR x25, [x19, #0x60]      | X25 = this._charBuffer; //P2            
            // 0x00AD21F0: CBNZ x20, #0xad21f8        | if ( != 0) goto label_14;               
            if(null != 0)
            {
                goto label_14;
            }
            // 0x00AD21F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(capacity:  256), ????);
            label_14:
            // 0x00AD21F8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD21FC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD2200: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00AD2204: MOV x1, x25                | X1 = this._charBuffer;//m1              
            // 0x00AD2208: MOV w3, w24                | W3 = val_7;//m1                         
            // 0x00AD220C: BL #0x1b5bd68              | X0 = Append(value:  this._charBuffer, startIndex:  0, charCount:  val_7);
            System.Text.StringBuilder val_10 = Append(value:  this._charBuffer, startIndex:  0, charCount:  val_7);
            // 0x00AD2210: SUB w8, w21, #1            | W8 = (val_21 - 1);                      
            var val_11 = val_21 - 1;
            // 0x00AD2214: CMP w22, w8                | STATE = COMPARE(val_6, (val_21 - 1))    
            // 0x00AD2218: B.LT #0xad206c             | if (val_6 < val_11) goto label_15;      
            if(val_6 < val_11)
            {
                goto label_15;
            }
            // 0x00AD221C: LDR w8, [sp, #0xc]         | W8 = 0x0;                               
            // 0x00AD2220: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            // 0x00AD2224: TBNZ w8, #0, #0xad2094     | if ((0x0 & 0x1) != 0) goto label_16;    
            if((0 & 1) != 0)
            {
                goto label_16;
            }
            // 0x00AD2228: ADD w1, w28, #1            | W1 = ((0 + val_21) + 1);                
            int val_12 = val_23 + 1;
            // 0x00AD222C: MOV x0, x19                | X0 = 1152921513719172112 (0x100000021F230C10);//ML01
            // 0x00AD2230: BL #0xad3c40               | this.MovePosition(count:  int val_12 = val_23 + 1);
            this.MovePosition(count:  val_12);
            // 0x00AD2234: CBNZ x20, #0xad223c        | if ( != 0) goto label_17;               
            if(null != 0)
            {
                goto label_17;
            }
            // 0x00AD2238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_17:
            // 0x00AD223C: LDR x8, [x20]              | X8 = ;                                  
            // 0x00AD2240: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00AD2244: LDP x2, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x00AD2248: SUB sp, x29, #0x50         | SP = (1152921513719160096 - 80) = 1152921513719160016 (0x100000021F22DCD0);
            // 0x00AD224C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD2250: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD2254: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD2258: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD225C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AD2260: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AD2264: BR x2                      | goto mem[null + 320];                   
            goto mem[null + 320];
            label_9:
            // 0x00AD2268: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00AD226C: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x00AD2270: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x00AD2274: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x00AD2278: TBZ w8, #0, #0xad2288      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00AD227C: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x00AD2280: CBNZ w8, #0xad2288         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00AD2284: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_19:
            // 0x00AD2288: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD228C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD2290: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_13 = System.Text.Encoding.UTF8;
            // 0x00AD2294: LDP x22, x20, [x19, #0x58] | X22 = ??? + 88; X20 = ??? + 88 + 8;      //  | 
            // 0x00AD2298: MOV x23, x0                | X23 = val_13;//m1                       
            // 0x00AD229C: CBNZ x23, #0xad22a4        | if (val_13 != null) goto label_20;      
            if(val_13 != null)
            {
                goto label_20;
            }
            // 0x00AD22A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_20:
            // 0x00AD22A4: LDR x8, [x23]              | X8 = typeof(System.Text.Encoding);      
            // 0x00AD22A8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD22AC: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x00AD22B0: MOV x0, x23                | X0 = val_13;//m1                        
            // 0x00AD22B4: LDR x9, [x8, #0x210]       | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_210;
            // 0x00AD22B8: LDR x6, [x8, #0x218]       | X6 = typeof(System.Text.Encoding).__il2cppRuntimeField_218;
            // 0x00AD22BC: MOV x1, x22                | X1 = ??? + 88;//m1                      
            // 0x00AD22C0: MOV w3, w21                | W3 = W21;//m1                           
            // 0x00AD22C4: MOV x4, x20                | X4 = ??? + 88 + 8;//m1                  
            // 0x00AD22C8: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_210();
            // 0x00AD22CC: ADD w8, w28, w21           | W8 = (??? + ???);                       
            var val_14 = (???) + (???);
            // 0x00AD22D0: MOV w20, w0                | W20 = val_13;//m1                       
            // 0x00AD22D4: ADD w1, w8, #1             | W1 = ((??? + ???) + 1);                 
            int val_15 = val_14 + 1;
            // 0x00AD22D8: MOV x0, x19                | X0 = X19;//m1                           
            // 0x00AD22DC: BL #0xad3c40               | MovePosition(count:  int val_15 = val_14 + 1);
            ???.MovePosition(count:  val_15);
            // 0x00AD22E0: LDR x1, [x19, #0x60]       | X1 = ??? + 96;                          
            // 0x00AD22E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD22E8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD22EC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD22F0: MOV w3, w20                | W3 = val_13;//m1                        
            // 0x00AD22F4: SUB sp, x29, #0x50         | SP = (??? - 80);                        
            var val_16 = (???) - 80;
            // 0x00AD22F8: LDP x29, x30, [sp, #0x50]  | X29 = (??? - 80) + 80; X30 = (??? - 80) + 80 + 8; //  | 
            // 0x00AD22FC: LDP x20, x19, [sp, #0x40]  | X20 = (??? - 80) + 64; X19 = (??? - 80) + 64 + 8; //  | 
            // 0x00AD2300: LDP x22, x21, [sp, #0x30]  | X22 = (??? - 80) + 48; X21 = (??? - 80) + 48 + 8; //  | 
            // 0x00AD2304: LDP x24, x23, [sp, #0x20]  | X24 = (??? - 80) + 32; X23 = (??? - 80) + 32 + 8; //  | 
            // 0x00AD2308: LDP x26, x25, [sp, #0x10]  | X26 = (??? - 80) + 16; X25 = (??? - 80) + 16 + 8; //  | 
            // 0x00AD230C: LDP x28, x27, [sp], #0x60  | X28 = (??? - 80); X27 = (??? - 80) + 8;  //  | 
            // 0x00AD2310: B #0x18b20c8               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD34DC (11351260), len: 96  VirtAddr: 0x00AD34DC RVA: 0x00AD34DC token: 100684747 methodIndex: 47407 delegateWrapperIndex: 0 methodInvoker: 0
        private string ReadLengthString()
        {
            //
            // Disasemble & Code
            // 0x00AD34DC: STP x20, x19, [sp, #-0x20]! | stack[1152921513719480976] = ???;  stack[1152921513719480984] = ???;  //  dest_result_addr=1152921513719480976 |  dest_result_addr=1152921513719480984
            // 0x00AD34E0: STP x29, x30, [sp, #0x10]  | stack[1152921513719480992] = ???;  stack[1152921513719481000] = ???;  //  dest_result_addr=1152921513719480992 |  dest_result_addr=1152921513719481000
            // 0x00AD34E4: ADD x29, sp, #0x10         | X29 = (1152921513719480976 + 16) = 1152921513719480992 (0x100000021F27C2A0);
            // 0x00AD34E8: MOV x19, x0                | X19 = 1152921513719493008 (0x100000021F27F190);//ML01
            // 0x00AD34EC: BL #0xad349c               | X0 = this.ReadInt32();                  
            int val_1 = this.ReadInt32();
            // 0x00AD34F0: MOV w20, w0                | W20 = val_1;//m1                        
            // 0x00AD34F4: MOV x0, x19                | X0 = 1152921513719493008 (0x100000021F27F190);//ML01
            // 0x00AD34F8: MOV w1, w20                | W1 = val_1;//m1                         
            // 0x00AD34FC: BL #0xad3c40               | this.MovePosition(count:  val_1);       
            this.MovePosition(count:  val_1);
            // 0x00AD3500: SUB w1, w20, #1            | W1 = (val_1 - 1);                       
            int val_2 = val_1 - 1;
            // 0x00AD3504: MOV x0, x19                | X0 = 1152921513719493008 (0x100000021F27F190);//ML01
            // 0x00AD3508: BL #0xad3ef4               | X0 = this.GetString(length:  int val_2 = val_1 - 1);
            string val_3 = this.GetString(length:  val_2);
            // 0x00AD350C: LDR x20, [x19, #0x48]      | X20 = this._reader; //P2                
            // 0x00AD3510: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x00AD3514: CBNZ x20, #0xad351c        | if (this._reader != null) goto label_0; 
            if(this._reader != null)
            {
                goto label_0;
            }
            // 0x00AD3518: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_0:
            // 0x00AD351C: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD3520: MOV x0, x20                | X0 = this._reader;//m1                  
            // 0x00AD3524: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E0; X1 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E8; //  | 
            // 0x00AD3528: BLR x9                     | X0 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1E0();
            // 0x00AD352C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3530: MOV x0, x19                | X0 = val_3;//m1                         
            // 0x00AD3534: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3538: RET                        |  return (System.String)val_3;           
            return (string)val_3;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3EF4 (11353844), len: 848  VirtAddr: 0x00AD3EF4 RVA: 0x00AD3EF4 token: 100684748 methodIndex: 47408 delegateWrapperIndex: 0 methodInvoker: 0
        private string GetString(int length)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            System.Char[] val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x00AD3EF4: STP x28, x27, [sp, #-0x60]! | stack[1152921513719913584] = ???;  stack[1152921513719913592] = ???;  //  dest_result_addr=1152921513719913584 |  dest_result_addr=1152921513719913592
            // 0x00AD3EF8: STP x26, x25, [sp, #0x10]  | stack[1152921513719913600] = ???;  stack[1152921513719913608] = ???;  //  dest_result_addr=1152921513719913600 |  dest_result_addr=1152921513719913608
            // 0x00AD3EFC: STP x24, x23, [sp, #0x20]  | stack[1152921513719913616] = ???;  stack[1152921513719913624] = ???;  //  dest_result_addr=1152921513719913616 |  dest_result_addr=1152921513719913624
            // 0x00AD3F00: STP x22, x21, [sp, #0x30]  | stack[1152921513719913632] = ???;  stack[1152921513719913640] = ???;  //  dest_result_addr=1152921513719913632 |  dest_result_addr=1152921513719913640
            // 0x00AD3F04: STP x20, x19, [sp, #0x40]  | stack[1152921513719913648] = ???;  stack[1152921513719913656] = ???;  //  dest_result_addr=1152921513719913648 |  dest_result_addr=1152921513719913656
            // 0x00AD3F08: STP x29, x30, [sp, #0x50]  | stack[1152921513719913664] = ???;  stack[1152921513719913672] = ???;  //  dest_result_addr=1152921513719913664 |  dest_result_addr=1152921513719913672
            // 0x00AD3F0C: ADD x29, sp, #0x50         | X29 = (1152921513719913584 + 80) = 1152921513719913664 (0x100000021F2E5CC0);
            // 0x00AD3F10: SUB sp, sp, #0x10          | SP = (1152921513719913584 - 16) = 1152921513719913568 (0x100000021F2E5C60);
            // 0x00AD3F14: MOV w26, w1                | W26 = length;//m1                       
            // 0x00AD3F18: STR w26, [sp, #8]          | stack[1152921513719913576] = length;     //  dest_result_addr=1152921513719913576
            // 0x00AD3F1C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD3F20: LDRB w8, [x20, #0x4db]     | W8 = (bool)static_value_037334DB;       
            // 0x00AD3F24: MOV x19, x0                | X19 = 1152921513719925680 (0x100000021F2E8BB0);//ML01
            // 0x00AD3F28: TBNZ w8, #0, #0xad3f44     | if (static_value_037334DB == true) goto label_0;
            // 0x00AD3F2C: ADRP x8, #0x3684000        | X8 = 57163776 (0x3684000);              
            // 0x00AD3F30: LDR x8, [x8, #0x3e8]       | X8 = 0x2B8F9A4;                         
            // 0x00AD3F34: LDR w0, [x8]               | W0 = 0x152D;                            
            // 0x00AD3F38: BL #0x2782188              | X0 = sub_2782188( ?? 0x152D, ????);     
            // 0x00AD3F3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD3F40: STRB w8, [x20, #0x4db]     | static_value_037334DB = true;            //  dest_result_addr=57881819
            label_0:
            // 0x00AD3F44: CBZ w26, #0xad4120         | if (length == 0) goto label_1;          
            if(length == 0)
            {
                goto label_1;
            }
            // 0x00AD3F48: MOV x0, x19                | X0 = 1152921513719925680 (0x100000021F2E8BB0);//ML01
            // 0x00AD3F4C: BL #0xad3d60               | this.EnsureBuffers();                   
            this.EnsureBuffers();
            // 0x00AD3F50: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            // 0x00AD3F54: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            // 0x00AD3F58: MOV x28, xzr               | X28 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_12:
            // 0x00AD3F5C: LDR x23, [x19, #0x48]      | X23 = this._reader; //P2                
            // 0x00AD3F60: ORR w9, wzr, #0x80         | W9 = 128(0x80);                         
            var val_12 = 128;
            // 0x00AD3F64: SUB w8, w26, w20           | W8 = (length - 0);                      
            int val_1 = length - 0;
            // 0x00AD3F68: SUB w9, w9, w25            | W9 = (128 - 0);                         
            val_12 = val_12 - 0;
            // 0x00AD3F6C: CMP w8, w9                 | STATE = COMPARE((length - 0), (128 - 0))
            // 0x00AD3F70: CSEL w22, w9, w8, gt       | W22 = val_1 > 128 ? (128 - 0) : (length - 0);
            var val_2 = (val_1 > val_12) ? (val_12) : (val_1);
            // 0x00AD3F74: CBNZ x23, #0xad3f7c        | if (this._reader != null) goto label_2; 
            if(this._reader != null)
            {
                goto label_2;
            }
            // 0x00AD3F78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x00AD3F7C: LDR x8, [x23]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD3F80: MOV x0, x23                | X0 = this._reader;//m1                  
            // 0x00AD3F84: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_160; X1 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_168; //  | 
            // 0x00AD3F88: BLR x9                     | X0 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_160();
            // 0x00AD3F8C: LDR x23, [x19, #0x58]      | X23 = this._byteBuffer; //P2            
            // 0x00AD3F90: MOV x24, x0                | X24 = this._reader;//m1                 
            // 0x00AD3F94: CBNZ x24, #0xad3f9c        | if (this._reader != null) goto label_3; 
            if(this._reader != null)
            {
                goto label_3;
            }
            // 0x00AD3F98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._reader, ????);
            label_3:
            // 0x00AD3F9C: LDR x8, [x24]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD3FA0: MOV x0, x24                | X0 = this._reader;//m1                  
            // 0x00AD3FA4: MOV x1, x23                | X1 = this._byteBuffer;//m1              
            // 0x00AD3FA8: MOV w2, w25                | W2 = 0 (0x0);//ML01                     
            // 0x00AD3FAC: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_220;
            // 0x00AD3FB0: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_228;
            // 0x00AD3FB4: MOV w3, w22                | W3 = val_1 > 128 ? (128 - 0) : (length - 0);//m1
            // 0x00AD3FB8: BLR x9                     | X0 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_220();
            // 0x00AD3FBC: MOV w24, w0                | W24 = this._reader;//m1                 
            // 0x00AD3FC0: CBZ w24, #0xad4204         | if (this._reader == null) goto label_4; 
            if(this._reader == null)
            {
                goto label_4;
            }
            // 0x00AD3FC4: ADD w21, w24, w25          | W21 = typeof(System.IO.BinaryReader);//AP1  
            // 0x00AD3FC8: CMP w21, w26               | STATE = COMPARE(typeof(System.IO.BinaryReader), length)
            // 0x00AD3FCC: B.EQ #0xad416c             | if (typeof(System.IO.BinaryReader) == length) goto label_5;
            if(null == length)
            {
                goto label_5;
            }
            // 0x00AD3FD0: SUB w23, w21, #1           | W23 = (1152921504620691456 - 1) = 1152921504620691455 (0x1000000000D33FFF);
            // 0x00AD3FD4: MOV x0, x19                | X0 = 1152921513719925680 (0x100000021F2E8BB0);//ML01
            // 0x00AD3FD8: MOV w1, w23                | W1 = 1152921504620691455 (0x1000000000D33FFF);//ML01
            // 0x00AD3FDC: STR w20, [sp, #0xc]        | stack[1152921513719913580] = 0x0;        //  dest_result_addr=1152921513719913580
            // 0x00AD3FE0: BL #0xad3e54               | X0 = this.GetLastFullCharStop(start:  13844479);
            int val_3 = this.GetLastFullCharStop(start:  13844479);
            // 0x00AD3FE4: MOV w22, w0                | W22 = val_3;//m1                        
            // 0x00AD3FE8: CBNZ x28, #0xad400c        | if (0x0 != 0) goto label_6;             
            if(val_14 != 0)
            {
                goto label_6;
            }
            // 0x00AD3FEC: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00AD3FF0: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x00AD3FF4: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_4 = null;
            // 0x00AD3FF8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x00AD3FFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD4000: MOV w1, w26                | W1 = length;//m1                        
            // 0x00AD4004: MOV x28, x0                | X28 = 1152921504649605120 (0x10000000028C7000);//ML01
            val_14 = val_4;
            // 0x00AD4008: BL #0x1b5a3c4              | .ctor(capacity:  length);               
            val_4 = new System.Text.StringBuilder(capacity:  length);
            label_6:
            // 0x00AD400C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00AD4010: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x00AD4014: MOV x20, x28               | X20 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00AD4018: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x00AD401C: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x00AD4020: TBZ w8, #0, #0xad4030      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00AD4024: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x00AD4028: CBNZ w8, #0xad4030         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00AD402C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_8:
            // 0x00AD4030: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD4034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4038: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_5 = System.Text.Encoding.UTF8;
            // 0x00AD403C: LDP x27, x25, [x19, #0x58] | X27 = this._byteBuffer; //P2  X25 = this._charBuffer; //P2  //  | 
            // 0x00AD4040: MOV x28, x0                | X28 = val_5;//m1                        
            // 0x00AD4044: CBNZ x28, #0xad404c        | if (val_5 != null) goto label_9;        
            if(val_5 != null)
            {
                goto label_9;
            }
            // 0x00AD4048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_9:
            // 0x00AD404C: LDR x8, [x28]              | X8 = typeof(System.Text.Encoding);      
            // 0x00AD4050: ADD w26, w22, #1           | W26 = (val_3 + 1);                      
            int val_6 = val_3 + 1;
            // 0x00AD4054: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD4058: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x00AD405C: LDR x9, [x8, #0x210]       | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_210;
            // 0x00AD4060: LDR x6, [x8, #0x218]       | X6 = typeof(System.Text.Encoding).__il2cppRuntimeField_218;
            // 0x00AD4064: MOV x0, x28                | X0 = val_5;//m1                         
            // 0x00AD4068: MOV x1, x27                | X1 = this._byteBuffer;//m1              
            // 0x00AD406C: MOV w3, w26                | W3 = (val_3 + 1);//m1                   
            // 0x00AD4070: MOV x4, x25                | X4 = this._charBuffer;//m1              
            // 0x00AD4074: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_210();
            // 0x00AD4078: LDR x27, [x19, #0x60]      | X27 = this._charBuffer; //P2            
            // 0x00AD407C: MOV w25, w0                | W25 = val_5;//m1                        
            // 0x00AD4080: MOV x28, x20               | X28 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00AD4084: CBNZ x28, #0xad408c        | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x00AD4088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_10:
            // 0x00AD408C: LDR w20, [sp, #0xc]        | W20 = 0x0;                              
            // 0x00AD4090: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD4094: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD4098: MOV x0, x28                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00AD409C: MOV x1, x27                | X1 = this._charBuffer;//m1              
            val_15 = this._charBuffer;
            // 0x00AD40A0: MOV w3, w25                | W3 = val_5;//m1                         
            // 0x00AD40A4: ADD w20, w24, w20          | W20 = typeof(System.IO.BinaryReader);//AP1  
            // 0x00AD40A8: BL #0x1b5bd68              | X0 = Append(value:  val_15 = this._charBuffer, startIndex:  0, charCount:  val_5);
            System.Text.StringBuilder val_7 = Append(value:  val_15, startIndex:  0, charCount:  val_5);
            // 0x00AD40AC: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00AD40B0: CMP w22, w23               | STATE = COMPARE(val_3, 0x1000000000D33FFF)
            // 0x00AD40B4: B.GE #0xad40e0             | if (val_3 >= 1152921504620691455) goto label_11;
            if(val_3 >= 1152921504620691455)
            {
                goto label_11;
            }
            // 0x00AD40B8: LDR x1, [x19, #0x58]       | X1 = this._byteBuffer; //P2             
            val_15 = this._byteBuffer;
            // 0x00AD40BC: SUB w8, w21, w22           | W8 = (1152921504620691456 - val_3);     
            System.IO.BinaryReader val_8 = 1152921504620691456 - val_3;
            // 0x00AD40C0: SUB w25, w8, #1            | W25 = ((1152921504620691456 - val_3) - 1);
            val_16 = val_8 - 1;
            // 0x00AD40C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD40C8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00AD40CC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00AD40D0: MOV w2, w26                | W2 = (val_3 + 1);//m1                   
            // 0x00AD40D4: MOV x3, x1                 | X3 = this._byteBuffer;//m1              
            // 0x00AD40D8: MOV w5, w25                | W5 = ((1152921504620691456 - val_3) - 1);//m1
            // 0x00AD40DC: BL #0x18ce87c              | System.Array.Copy(sourceArray:  0, sourceIndex:  val_15 = this._byteBuffer, destinationArray:  val_6, destinationIndex:  val_15, length:  0);
            System.Array.Copy(sourceArray:  0, sourceIndex:  val_15, destinationArray:  val_6, destinationIndex:  val_15, length:  0);
            label_11:
            // 0x00AD40E0: LDR w26, [sp, #8]          | W26 = length;                           
            // 0x00AD40E4: CMP w20, w26               | STATE = COMPARE(typeof(System.IO.BinaryReader), length)
            // 0x00AD40E8: B.LT #0xad3f5c             | if (typeof(System.IO.BinaryReader) < length) goto label_12;
            if(null < length)
            {
                goto label_12;
            }
            // 0x00AD40EC: CBNZ x28, #0xad40f4        | if ( != 0) goto label_13;               
            if(null != 0)
            {
                goto label_13;
            }
            // 0x00AD40F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_13:
            // 0x00AD40F4: LDR x8, [x28]              | X8 = ;                                  
            // 0x00AD40F8: MOV x0, x28                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00AD40FC: LDP x2, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x00AD4100: SUB sp, x29, #0x50         | SP = (1152921513719913664 - 80) = 1152921513719913584 (0x100000021F2E5C70);
            // 0x00AD4104: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            val_13 = ???;
            // 0x00AD4108: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD410C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD4110: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD4114: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AD4118: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AD411C: BR x2                      | goto mem[null + 320];                   
            goto mem[null + 320];
            label_1:
            // 0x00AD4120: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
            // 0x00AD4124: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
            // 0x00AD4128: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_17 = null;
            // 0x00AD412C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00AD4130: TBZ w8, #0, #0xad4144      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00AD4134: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AD4138: CBNZ w8, #0xad4144         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00AD413C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00AD4140: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_17 = null;
            label_15:
            // 0x00AD4144: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00AD4148: LDR x0, [x8]               | X0 = System.String.Empty;               
            // 0x00AD414C: SUB sp, x29, #0x50         | SP = (val_13 - 80);                     
            var val_9 = val_13 - 80;
            // 0x00AD4150: LDP x29, x30, [sp, #0x50]  | X29 = (val_13 - 80) + 80; X30 = (val_13 - 80) + 80 + 8; //  | 
            // 0x00AD4154: LDP x20, x19, [sp, #0x40]  | X20 = (val_13 - 80) + 64; X19 = (val_13 - 80) + 64 + 8; //  | 
            // 0x00AD4158: LDP x22, x21, [sp, #0x30]  | X22 = (val_13 - 80) + 48; X21 = (val_13 - 80) + 48 + 8; //  | 
            // 0x00AD415C: LDP x24, x23, [sp, #0x20]  | X24 = (val_13 - 80) + 32; X23 = (val_13 - 80) + 32 + 8; //  | 
            // 0x00AD4160: LDP x26, x25, [sp, #0x10]  | X26 = (val_13 - 80) + 16; X25 = (val_13 - 80) + 16 + 8; //  | 
            // 0x00AD4164: LDP x28, x27, [sp], #0x60  | X28 = (val_13 - 80); X27 = (val_13 - 80) + 8; //  | 
            // 0x00AD4168: RET                        |  return (System.String)System.String.Empty;
            return System.String.Empty;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
            label_5:
            // 0x00AD416C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00AD4170: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x00AD4174: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x00AD4178: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x00AD417C: TBZ w8, #0, #0xad418c      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x00AD4180: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x00AD4184: CBNZ w8, #0xad418c         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x00AD4188: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_17:
            // 0x00AD418C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD4190: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4194: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_10 = System.Text.Encoding.UTF8;
            // 0x00AD4198: LDP x22, x21, [x19, #0x58] | X22 = this._byteBuffer; //P2  X21 = this._charBuffer; //P2  //  | 
            // 0x00AD419C: MOV x23, x0                | X23 = val_10;//m1                       
            // 0x00AD41A0: CBNZ x23, #0xad41a8        | if (val_10 != null) goto label_18;      
            if(val_10 != null)
            {
                goto label_18;
            }
            // 0x00AD41A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_18:
            // 0x00AD41A8: LDR x8, [x23]              | X8 = typeof(System.Text.Encoding);      
            // 0x00AD41AC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD41B0: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x00AD41B4: MOV x0, x23                | X0 = val_10;//m1                        
            // 0x00AD41B8: LDR x9, [x8, #0x210]       | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_210;
            // 0x00AD41BC: LDR x6, [x8, #0x218]       | X6 = typeof(System.Text.Encoding).__il2cppRuntimeField_218;
            // 0x00AD41C0: MOV x1, x22                | X1 = this._byteBuffer;//m1              
            // 0x00AD41C4: MOV w3, w26                | W3 = length;//m1                        
            // 0x00AD41C8: MOV x4, x21                | X4 = this._charBuffer;//m1              
            // 0x00AD41CC: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_210();
            // 0x00AD41D0: LDR x1, [x19, #0x60]       | X1 = this._charBuffer; //P2             
            // 0x00AD41D4: MOV w3, w0                 | W3 = val_10;//m1                        
            // 0x00AD41D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD41DC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD41E0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD41E4: SUB sp, x29, #0x50         | SP = (1152921513719913664 - 80) = 1152921513719913584 (0x100000021F2E5C70);
            // 0x00AD41E8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD41EC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD41F0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD41F4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD41F8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AD41FC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AD4200: B #0x18b20c8               | return 0.CreateString(val:  this._charBuffer, startIndex:  0, length:  val_10);
            return 0.CreateString(val:  this._charBuffer, startIndex:  0, length:  val_10);
            label_4:
            // 0x00AD4204: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00AD4208: LDR x8, [x8, #0x310]       | X8 = 1152921504620957696;               
            // 0x00AD420C: LDR x0, [x8]               | X0 = typeof(System.IO.EndOfStreamException);
            System.IO.EndOfStreamException val_11 = null;
            // 0x00AD4210: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.EndOfStreamException), ????);
            // 0x00AD4214: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x00AD4218: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921513719900496)("Unable to read beyond the end of the stream.");
            // 0x00AD421C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD4220: MOV x19, x0                | X19 = 1152921504620957696 (0x1000000000D75000);//ML01
            // 0x00AD4224: LDR x1, [x8]               | X1 = "Unable to read beyond the end of the stream.";
            // 0x00AD4228: BL #0x1e6f1e8              | .ctor(message:  "Unable to read beyond the end of the stream.");
            val_11 = new System.IO.EndOfStreamException(message:  "Unable to read beyond the end of the stream.");
            // 0x00AD422C: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00AD4230: LDR x8, [x8, #0x8a8]       | X8 = 1152921513719900656;               
            // 0x00AD4234: MOV x0, x19                | X0 = 1152921504620957696 (0x1000000000D75000);//ML01
            // 0x00AD4238: LDR x1, [x8]               | X1 = System.String Newtonsoft.Json.Bson.BsonReader::GetString(int length);
            // 0x00AD423C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.EndOfStreamException), ????);
            // 0x00AD4240: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3E54 (11353684), len: 160  VirtAddr: 0x00AD3E54 RVA: 0x00AD3E54 token: 100684749 methodIndex: 47409 delegateWrapperIndex: 0 methodInvoker: 0
        private int GetLastFullCharStop(int start)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x00AD3E54: STP x22, x21, [sp, #-0x30]! | stack[1152921513720373792] = ???;  stack[1152921513720373800] = ???;  //  dest_result_addr=1152921513720373792 |  dest_result_addr=1152921513720373800
            // 0x00AD3E58: STP x20, x19, [sp, #0x10]  | stack[1152921513720373808] = ???;  stack[1152921513720373816] = ???;  //  dest_result_addr=1152921513720373808 |  dest_result_addr=1152921513720373816
            // 0x00AD3E5C: STP x29, x30, [sp, #0x20]  | stack[1152921513720373824] = ???;  stack[1152921513720373832] = ???;  //  dest_result_addr=1152921513720373824 |  dest_result_addr=1152921513720373832
            // 0x00AD3E60: ADD x29, sp, #0x20         | X29 = (1152921513720373792 + 32) = 1152921513720373824 (0x100000021F356240);
            // 0x00AD3E64: MOV w19, w1                | W19 = start;//m1                        
            // 0x00AD3E68: MOV x20, x0                | X20 = 1152921513720385840 (0x100000021F359130);//ML01
            // 0x00AD3E6C: TBNZ w19, #0x1f, #0xad3eb8 | if ((start & 0x80000000) != 0) goto label_0;
            if((start & 2147483648) != 0)
            {
                goto label_0;
            }
            // 0x00AD3E70: SXTW x21, w19              | X21 = (long)(int)(start);               
            val_4 = (long)start;
            label_4:
            // 0x00AD3E74: LDR x22, [x20, #0x58]      | X22 = this._byteBuffer; //P2            
            // 0x00AD3E78: CBNZ x22, #0xad3e80        | if (this._byteBuffer != null) goto label_1;
            if(this._byteBuffer != null)
            {
                goto label_1;
            }
            // 0x00AD3E7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00AD3E80: LDR w8, [x22, #0x18]       | W8 = this._byteBuffer.Length; //P2      
            // 0x00AD3E84: CMP x21, x8                | STATE = COMPARE((long)(int)(start), this._byteBuffer.Length)
            // 0x00AD3E88: B.LO #0xad3e98             | if (val_4 < this._byteBuffer.Length) goto label_2;
            if(val_4 < this._byteBuffer.Length)
            {
                goto label_2;
            }
            // 0x00AD3E8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x00AD3E90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD3E94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_2:
            // 0x00AD3E98: ADD x8, x22, x21           | X8 = this._byteBuffer[(long)(int)(start)]; //PARR1 
            // 0x00AD3E9C: LDRB w1, [x8, #0x20]       | W1 = this._byteBuffer[(long)(int)(start)][0]
            byte val_4 = this._byteBuffer[val_4];
            // 0x00AD3EA0: BL #0xad4244               | X0 = this.BytesInSequence(b:  this._byteBuffer[val_4]);
            int val_1 = this.BytesInSequence(b:  val_4);
            // 0x00AD3EA4: CBNZ w0, #0xad3ec4         | if (val_1 != 0) goto label_3;           
            if(val_1 != 0)
            {
                goto label_3;
            }
            // 0x00AD3EA8: SUBS x21, x21, #1          | X21 = ((long)(int)(start) - 1);         
            val_4 = val_4 - 1;
            // 0x00AD3EAC: B.GE #0xad3e74             | if (val_4 >= this._byteBuffer.Length) goto label_4;
            if(val_4 >= this._byteBuffer.Length)
            {
                goto label_4;
            }
            // 0x00AD3EB0: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x00AD3EB4: B #0xad3ed8                |  goto label_8;                          
            goto label_8;
            label_0:
            // 0x00AD3EB8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x00AD3EBC: MOV w21, w19               | W21 = start;//m1                        
            val_4 = start;
            // 0x00AD3EC0: B #0xad3ed8                |  goto label_8;                          
            goto label_8;
            label_3:
            // 0x00AD3EC4: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
            // 0x00AD3EC8: B.NE #0xad3ed4             | if (val_1 != 1) goto label_7;           
            if(val_1 != 1)
            {
                goto label_7;
            }
            // 0x00AD3ECC: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_5 = 1;
            // 0x00AD3ED0: B #0xad3ed8                |  goto label_8;                          
            goto label_8;
            label_7:
            // 0x00AD3ED4: SUB w21, w21, #1           | W21 = ((long)(int)(start) - 1);         
            val_4 = val_4 - 1;
            label_8:
            // 0x00AD3ED8: SUB w8, w19, w21           | W8 = (start - ((long)(int)(start) - 1));
            int val_2 = start - val_4;
            // 0x00AD3EDC: CMP w0, w8                 | STATE = COMPARE(val_1, (start - ((long)(int)(start) - 1)))
            // 0x00AD3EE0: CSEL w0, w21, w19, ne      | W0 = val_1 != val_2 ? ((long)(int)(start) - 1) : start;
            var val_3 = (val_1 != val_2) ? (val_4) : (start);
            // 0x00AD3EE4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3EE8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3EEC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD3EF0: RET                        |  return (System.Int32)val_1 != val_2 ? ((long)(int)(start) - 1) : start;
            return (int)val_3;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4244 (11354692), len: 664  VirtAddr: 0x00AD4244 RVA: 0x00AD4244 token: 100684750 methodIndex: 47410 delegateWrapperIndex: 0 methodInvoker: 0
        private int BytesInSequence(byte b)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            System.Byte[] val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00AD4244: STP x22, x21, [sp, #-0x30]! | stack[1152921513720522656] = ???;  stack[1152921513720522664] = ???;  //  dest_result_addr=1152921513720522656 |  dest_result_addr=1152921513720522664
            // 0x00AD4248: STP x20, x19, [sp, #0x10]  | stack[1152921513720522672] = ???;  stack[1152921513720522680] = ???;  //  dest_result_addr=1152921513720522672 |  dest_result_addr=1152921513720522680
            // 0x00AD424C: STP x29, x30, [sp, #0x20]  | stack[1152921513720522688] = ???;  stack[1152921513720522696] = ???;  //  dest_result_addr=1152921513720522688 |  dest_result_addr=1152921513720522696
            // 0x00AD4250: ADD x29, sp, #0x20         | X29 = (1152921513720522656 + 32) = 1152921513720522688 (0x100000021F37A7C0);
            // 0x00AD4254: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD4258: LDRB w8, [x20, #0x4dc]     | W8 = (bool)static_value_037334DC;       
            // 0x00AD425C: MOV w19, w1                | W19 = b;//m1                            
            // 0x00AD4260: TBNZ w8, #0, #0xad427c     | if (static_value_037334DC == true) goto label_0;
            // 0x00AD4264: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x00AD4268: LDR x8, [x8, #0x280]       | X8 = 0x2B8F99C;                         
            // 0x00AD426C: LDR w0, [x8]               | W0 = 0x152B;                            
            // 0x00AD4270: BL #0x2782188              | X0 = sub_2782188( ?? 0x152B, ????);     
            // 0x00AD4274: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4278: STRB w8, [x20, #0x4dc]     | static_value_037334DC = true;            //  dest_result_addr=57881820
            label_0:
            // 0x00AD427C: ADRP x20, #0x3672000       | X20 = 57090048 (0x3672000);             
            // 0x00AD4280: LDR x20, [x20, #0x5d0]     | X20 = 1152921504857538560;              
            // 0x00AD4284: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_1 = null;
            // 0x00AD4288: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_10A;
            // 0x00AD428C: TBZ w8, #0, #0xad42a0      | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AD4290: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished;
            // 0x00AD4294: CBNZ w8, #0xad42a0         | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AD4298: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD429C: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_1 = null;
            label_2:
            // 0x00AD42A0: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD42A4: LDR x21, [x8]              | X21 = Newtonsoft.Json.Bson.BsonReader._seqRange1;
            val_2 = Newtonsoft.Json.Bson.BsonReader._seqRange1;
            // 0x00AD42A8: CBNZ x21, #0xad42b0        | if (Newtonsoft.Json.Bson.BsonReader._seqRange1 != null) goto label_3;
            if(val_2 != null)
            {
                goto label_3;
            }
            // 0x00AD42AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_3:
            // 0x00AD42B0: LDR w8, [x21, #0x18]       | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange1.Length;
            // 0x00AD42B4: CMP w8, #1                 | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange1.Length, 0x1)
            // 0x00AD42B8: B.HI #0xad42c8             | if (Newtonsoft.Json.Bson.BsonReader._seqRange1.Length > 1) goto label_4;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange1.Length > 1)
            {
                goto label_4;
            }
            // 0x00AD42BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD42C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD42C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_4:
            // 0x00AD42C8: LDRB w8, [x21, #0x21]      | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange1 + 33; //  not_find_field!2:33
            // 0x00AD42CC: CMP w8, w19, uxtb          | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange1 + 33, b)
            // 0x00AD42D0: B.HS #0xad44b0             | if (Newtonsoft.Json.Bson.BsonReader._seqRange1 + 33 >= b) goto label_5;
            if((Newtonsoft.Json.Bson.BsonReader._seqRange1 + 33) >= b)
            {
                goto label_5;
            }
            // 0x00AD42D4: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_3 = null;
            // 0x00AD42D8: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_10A;
            // 0x00AD42DC: TBZ w8, #0, #0xad42f0      | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00AD42E0: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished;
            // 0x00AD42E4: CBNZ w8, #0xad42f0         | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00AD42E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD42EC: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_3 = null;
            label_7:
            // 0x00AD42F0: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD42F4: LDR x21, [x8, #8]          | X21 = Newtonsoft.Json.Bson.BsonReader._seqRange2;
            // 0x00AD42F8: CBNZ x21, #0xad4300        | if (Newtonsoft.Json.Bson.BsonReader._seqRange2 != null) goto label_8;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange2 != null)
            {
                goto label_8;
            }
            // 0x00AD42FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_8:
            // 0x00AD4300: LDR w8, [x21, #0x18]       | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange2.Length;
            // 0x00AD4304: CBNZ w8, #0xad4314         | if (Newtonsoft.Json.Bson.BsonReader._seqRange2.Length != 0) goto label_9;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange2.Length != 0)
            {
                goto label_9;
            }
            // 0x00AD4308: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD430C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4310: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_9:
            // 0x00AD4314: LDRB w8, [x21, #0x20]      | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange2 + 32; //  not_find_field!2:32
            // 0x00AD4318: CMP w8, w19, uxtb          | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange2 + 32, b)
            // 0x00AD431C: B.HI #0xad4370             | if (Newtonsoft.Json.Bson.BsonReader._seqRange2 + 32 > b) goto label_10;
            if((Newtonsoft.Json.Bson.BsonReader._seqRange2 + 32) > b)
            {
                goto label_10;
            }
            // 0x00AD4320: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_4 = null;
            // 0x00AD4324: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_10A;
            // 0x00AD4328: TBZ w8, #0, #0xad433c      | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00AD432C: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished;
            // 0x00AD4330: CBNZ w8, #0xad433c         | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00AD4334: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD4338: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_4 = null;
            label_12:
            // 0x00AD433C: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD4340: LDR x21, [x8, #8]          | X21 = Newtonsoft.Json.Bson.BsonReader._seqRange2;
            val_2 = Newtonsoft.Json.Bson.BsonReader._seqRange2;
            // 0x00AD4344: CBNZ x21, #0xad434c        | if (Newtonsoft.Json.Bson.BsonReader._seqRange2 != null) goto label_13;
            if(val_2 != null)
            {
                goto label_13;
            }
            // 0x00AD4348: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_13:
            // 0x00AD434C: LDR w8, [x21, #0x18]       | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange2.Length;
            // 0x00AD4350: CMP w8, #1                 | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange2.Length, 0x1)
            // 0x00AD4354: B.HI #0xad4364             | if (Newtonsoft.Json.Bson.BsonReader._seqRange2.Length > 1) goto label_14;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange2.Length > 1)
            {
                goto label_14;
            }
            // 0x00AD4358: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD435C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4360: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_14:
            // 0x00AD4364: LDRB w8, [x21, #0x21]      | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange2 + 33; //  not_find_field!2:33
            // 0x00AD4368: CMP w8, w19, uxtb          | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange2 + 33, b)
            // 0x00AD436C: B.HS #0xad44b8             | if (Newtonsoft.Json.Bson.BsonReader._seqRange2 + 33 >= b) goto label_15;
            if((Newtonsoft.Json.Bson.BsonReader._seqRange2 + 33) >= b)
            {
                goto label_15;
            }
            label_10:
            // 0x00AD4370: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_5 = null;
            // 0x00AD4374: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_10A;
            // 0x00AD4378: TBZ w8, #0, #0xad438c      | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x00AD437C: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished;
            // 0x00AD4380: CBNZ w8, #0xad438c         | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x00AD4384: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD4388: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_5 = null;
            label_17:
            // 0x00AD438C: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD4390: LDR x21, [x8, #0x10]       | X21 = Newtonsoft.Json.Bson.BsonReader._seqRange3;
            // 0x00AD4394: CBNZ x21, #0xad439c        | if (Newtonsoft.Json.Bson.BsonReader._seqRange3 != null) goto label_18;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange3 != null)
            {
                goto label_18;
            }
            // 0x00AD4398: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_18:
            // 0x00AD439C: LDR w8, [x21, #0x18]       | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange3.Length;
            // 0x00AD43A0: CBNZ w8, #0xad43b0         | if (Newtonsoft.Json.Bson.BsonReader._seqRange3.Length != 0) goto label_19;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange3.Length != 0)
            {
                goto label_19;
            }
            // 0x00AD43A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD43A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD43AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_19:
            // 0x00AD43B0: LDRB w8, [x21, #0x20]      | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange3 + 32; //  not_find_field!2:32
            // 0x00AD43B4: CMP w8, w19, uxtb          | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange3 + 32, b)
            // 0x00AD43B8: B.HI #0xad440c             | if (Newtonsoft.Json.Bson.BsonReader._seqRange3 + 32 > b) goto label_20;
            if((Newtonsoft.Json.Bson.BsonReader._seqRange3 + 32) > b)
            {
                goto label_20;
            }
            // 0x00AD43BC: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_6 = null;
            // 0x00AD43C0: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_10A;
            // 0x00AD43C4: TBZ w8, #0, #0xad43d8      | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x00AD43C8: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished;
            // 0x00AD43CC: CBNZ w8, #0xad43d8         | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x00AD43D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD43D4: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_6 = null;
            label_22:
            // 0x00AD43D8: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD43DC: LDR x21, [x8, #0x10]       | X21 = Newtonsoft.Json.Bson.BsonReader._seqRange3;
            val_2 = Newtonsoft.Json.Bson.BsonReader._seqRange3;
            // 0x00AD43E0: CBNZ x21, #0xad43e8        | if (Newtonsoft.Json.Bson.BsonReader._seqRange3 != null) goto label_23;
            if(val_2 != null)
            {
                goto label_23;
            }
            // 0x00AD43E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_23:
            // 0x00AD43E8: LDR w8, [x21, #0x18]       | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange3.Length;
            // 0x00AD43EC: CMP w8, #1                 | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange3.Length, 0x1)
            // 0x00AD43F0: B.HI #0xad4400             | if (Newtonsoft.Json.Bson.BsonReader._seqRange3.Length > 1) goto label_24;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange3.Length > 1)
            {
                goto label_24;
            }
            // 0x00AD43F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD43F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD43FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_24:
            // 0x00AD4400: LDRB w8, [x21, #0x21]      | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange3 + 33; //  not_find_field!2:33
            // 0x00AD4404: CMP w8, w19, uxtb          | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange3 + 33, b)
            // 0x00AD4408: B.HS #0xad44c0             | if (Newtonsoft.Json.Bson.BsonReader._seqRange3 + 33 >= b) goto label_25;
            if((Newtonsoft.Json.Bson.BsonReader._seqRange3 + 33) >= b)
            {
                goto label_25;
            }
            label_20:
            // 0x00AD440C: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_7 = null;
            // 0x00AD4410: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_10A;
            // 0x00AD4414: TBZ w8, #0, #0xad4428      | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_has_cctor == 0) goto label_27;
            // 0x00AD4418: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished;
            // 0x00AD441C: CBNZ w8, #0xad4428         | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x00AD4420: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD4424: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_7 = null;
            label_27:
            // 0x00AD4428: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD442C: LDR x21, [x8, #0x18]       | X21 = Newtonsoft.Json.Bson.BsonReader._seqRange4;
            val_2 = Newtonsoft.Json.Bson.BsonReader._seqRange4;
            // 0x00AD4430: CBNZ x21, #0xad4438        | if (Newtonsoft.Json.Bson.BsonReader._seqRange4 != null) goto label_28;
            if(val_2 != null)
            {
                goto label_28;
            }
            // 0x00AD4434: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_28:
            // 0x00AD4438: LDR w8, [x21, #0x18]       | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange4.Length;
            // 0x00AD443C: CBNZ w8, #0xad444c         | if (Newtonsoft.Json.Bson.BsonReader._seqRange4.Length != 0) goto label_29;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange4.Length != 0)
            {
                goto label_29;
            }
            // 0x00AD4440: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD4444: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4448: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_29:
            // 0x00AD444C: LDRB w8, [x21, #0x20]      | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange4 + 32; //  not_find_field!2:32
            // 0x00AD4450: CMP w8, w19, uxtb          | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange4 + 32, b)
            // 0x00AD4454: B.HI #0xad44a8             | if (Newtonsoft.Json.Bson.BsonReader._seqRange4 + 32 > b) goto label_30;
            if((Newtonsoft.Json.Bson.BsonReader._seqRange4 + 32) > b)
            {
                goto label_30;
            }
            // 0x00AD4458: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_8 = null;
            // 0x00AD445C: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_10A;
            // 0x00AD4460: TBZ w8, #0, #0xad4474      | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x00AD4464: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished;
            // 0x00AD4468: CBNZ w8, #0xad4474         | if (Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x00AD446C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD4470: LDR x0, [x20]              | X0 = typeof(Newtonsoft.Json.Bson.BsonReader);
            val_8 = null;
            label_32:
            // 0x00AD4474: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD4478: LDR x20, [x8, #0x18]       | X20 = Newtonsoft.Json.Bson.BsonReader._seqRange4;
            // 0x00AD447C: CBNZ x20, #0xad4484        | if (Newtonsoft.Json.Bson.BsonReader._seqRange4 != null) goto label_33;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange4 != null)
            {
                goto label_33;
            }
            // 0x00AD4480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_33:
            // 0x00AD4484: LDR w8, [x20, #0x18]       | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange4.Length;
            // 0x00AD4488: CMP w8, #1                 | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange4.Length, 0x1)
            // 0x00AD448C: B.HI #0xad449c             | if (Newtonsoft.Json.Bson.BsonReader._seqRange4.Length > 1) goto label_34;
            if(Newtonsoft.Json.Bson.BsonReader._seqRange4.Length > 1)
            {
                goto label_34;
            }
            // 0x00AD4490: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            // 0x00AD4494: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4498: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.Bson.BsonReader), ????);
            label_34:
            // 0x00AD449C: LDRB w8, [x20, #0x21]      | W8 = Newtonsoft.Json.Bson.BsonReader._seqRange4 + 33; //  not_find_field!2:33
            // 0x00AD44A0: CMP w8, w19, uxtb          | STATE = COMPARE(Newtonsoft.Json.Bson.BsonReader._seqRange4 + 33, b)
            // 0x00AD44A4: B.HS #0xad44c8             | if (Newtonsoft.Json.Bson.BsonReader._seqRange4 + 33 >= b) goto label_35;
            if((Newtonsoft.Json.Bson.BsonReader._seqRange4 + 33) >= b)
            {
                goto label_35;
            }
            label_30:
            // 0x00AD44A8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x00AD44AC: B #0xad44cc                |  goto label_39;                         
            goto label_39;
            label_5:
            // 0x00AD44B0: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_9 = 1;
            // 0x00AD44B4: B #0xad44cc                |  goto label_39;                         
            goto label_39;
            label_15:
            // 0x00AD44B8: ORR w0, wzr, #2            | W0 = 2(0x2);                            
            val_9 = 2;
            // 0x00AD44BC: B #0xad44cc                |  goto label_39;                         
            goto label_39;
            label_25:
            // 0x00AD44C0: ORR w0, wzr, #3            | W0 = 3(0x3);                            
            val_9 = 3;
            // 0x00AD44C4: B #0xad44cc                |  goto label_39;                         
            goto label_39;
            label_35:
            // 0x00AD44C8: ORR w0, wzr, #4            | W0 = 4(0x4);                            
            val_9 = 4;
            label_39:
            // 0x00AD44CC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD44D0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD44D4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD44D8: RET                        |  return (System.Int32)4;                
            return (int)val_9;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3D60 (11353440), len: 244  VirtAddr: 0x00AD3D60 RVA: 0x00AD3D60 token: 100684751 methodIndex: 47411 delegateWrapperIndex: 0 methodInvoker: 0
        private void EnsureBuffers()
        {
            //
            // Disasemble & Code
            // 0x00AD3D60: STP x22, x21, [sp, #-0x30]! | stack[1152921513720712480] = ???;  stack[1152921513720712488] = ???;  //  dest_result_addr=1152921513720712480 |  dest_result_addr=1152921513720712488
            // 0x00AD3D64: STP x20, x19, [sp, #0x10]  | stack[1152921513720712496] = ???;  stack[1152921513720712504] = ???;  //  dest_result_addr=1152921513720712496 |  dest_result_addr=1152921513720712504
            // 0x00AD3D68: STP x29, x30, [sp, #0x20]  | stack[1152921513720712512] = ???;  stack[1152921513720712520] = ???;  //  dest_result_addr=1152921513720712512 |  dest_result_addr=1152921513720712520
            // 0x00AD3D6C: ADD x29, sp, #0x20         | X29 = (1152921513720712480 + 32) = 1152921513720712512 (0x100000021F3A8D40);
            // 0x00AD3D70: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD3D74: LDRB w8, [x20, #0x4dd]     | W8 = (bool)static_value_037334DD;       
            // 0x00AD3D78: MOV x19, x0                | X19 = 1152921513720724528 (0x100000021F3ABC30);//ML01
            // 0x00AD3D7C: TBNZ w8, #0, #0xad3d98     | if (static_value_037334DD == true) goto label_0;
            // 0x00AD3D80: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x00AD3D84: LDR x8, [x8, #0x990]       | X8 = 0x2B8F9A0;                         
            // 0x00AD3D88: LDR w0, [x8]               | W0 = 0x152C;                            
            // 0x00AD3D8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x152C, ????);     
            // 0x00AD3D90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD3D94: STRB w8, [x20, #0x4dd]     | static_value_037334DD = true;            //  dest_result_addr=57881821
            label_0:
            // 0x00AD3D98: LDR x8, [x19, #0x58]       | X8 = this._byteBuffer; //P2             
            // 0x00AD3D9C: CBNZ x8, #0xad3dc4         | if (this._byteBuffer != null) goto label_1;
            if(this._byteBuffer != null)
            {
                goto label_1;
            }
            // 0x00AD3DA0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00AD3DA4: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00AD3DA8: LDR x20, [x8]              | X20 = typeof(System.Byte[]);            
            // 0x00AD3DAC: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD3DB0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00AD3DB4: ORR w1, wzr, #0x80         | W1 = 128(0x80);                         
            // 0x00AD3DB8: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD3DBC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00AD3DC0: STR x0, [x19, #0x58]       | this._byteBuffer = typeof(System.Byte[]);  //  dest_result_addr=1152921513720724616
            this._byteBuffer = null;
            label_1:
            // 0x00AD3DC4: LDR x8, [x19, #0x60]       | X8 = this._charBuffer; //P2             
            // 0x00AD3DC8: CBNZ x8, #0xad3e44         | if (this._charBuffer != null) goto label_2;
            if(this._charBuffer != null)
            {
                goto label_2;
            }
            // 0x00AD3DCC: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00AD3DD0: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x00AD3DD4: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x00AD3DD8: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x00AD3DDC: TBZ w8, #0, #0xad3dec      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00AD3DE0: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x00AD3DE4: CBNZ w8, #0xad3dec         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00AD3DE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_4:
            // 0x00AD3DEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD3DF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD3DF4: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_1 = System.Text.Encoding.UTF8;
            // 0x00AD3DF8: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00AD3DFC: CBNZ x20, #0xad3e04        | if (val_1 != null) goto label_5;        
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x00AD3E00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x00AD3E04: LDR x8, [x20]              | X8 = typeof(System.Text.Encoding);      
            // 0x00AD3E08: ORR w1, wzr, #0x80         | W1 = 128(0x80);                         
            // 0x00AD3E0C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00AD3E10: LDR x9, [x8, #0x290]       | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_290;
            // 0x00AD3E14: LDR x2, [x8, #0x298]       | X2 = typeof(System.Text.Encoding).__il2cppRuntimeField_298;
            // 0x00AD3E18: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_290();
            // 0x00AD3E1C: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00AD3E20: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
            // 0x00AD3E24: MOV w21, w0                | W21 = val_1;//m1                        
            // 0x00AD3E28: LDR x20, [x8]              | X20 = typeof(System.Char[]);            
            // 0x00AD3E2C: MOV x0, x20                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00AD3E30: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
            // 0x00AD3E34: MOV w1, w21                | W1 = val_1;//m1                         
            // 0x00AD3E38: MOV x0, x20                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00AD3E3C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
            // 0x00AD3E40: STR x0, [x19, #0x60]       | this._charBuffer = typeof(System.Char[]);  //  dest_result_addr=1152921513720724624
            this._charBuffer = null;
            label_2:
            // 0x00AD3E44: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3E48: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3E4C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD3E50: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3C8C (11353228), len: 64  VirtAddr: 0x00AD3C8C RVA: 0x00AD3C8C token: 100684752 methodIndex: 47412 delegateWrapperIndex: 0 methodInvoker: 0
        private double ReadDouble()
        {
            //
            // Disasemble & Code
            // 0x00AD3C8C: STP x20, x19, [sp, #-0x20]! | stack[1152921513720906416] = ???;  stack[1152921513720906424] = ???;  //  dest_result_addr=1152921513720906416 |  dest_result_addr=1152921513720906424
            // 0x00AD3C90: STP x29, x30, [sp, #0x10]  | stack[1152921513720906432] = ???;  stack[1152921513720906440] = ???;  //  dest_result_addr=1152921513720906432 |  dest_result_addr=1152921513720906440
            // 0x00AD3C94: ADD x29, sp, #0x10         | X29 = (1152921513720906416 + 16) = 1152921513720906432 (0x100000021F3D82C0);
            // 0x00AD3C98: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x00AD3C9C: MOV x19, x0                | X19 = 1152921513720918448 (0x100000021F3DB1B0);//ML01
            // 0x00AD3CA0: BL #0xad3c40               | this.MovePosition(count:  8);           
            this.MovePosition(count:  8);
            // 0x00AD3CA4: LDR x19, [x19, #0x48]      | X19 = this._reader; //P2                
            // 0x00AD3CA8: CBNZ x19, #0xad3cb0        | if (this._reader != null) goto label_0; 
            if(this._reader != null)
            {
                goto label_0;
            }
            // 0x00AD3CAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD3CB0: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD3CB4: MOV x0, x19                | X0 = this._reader;//m1                  
            // 0x00AD3CB8: LDR x2, [x8, #0x220]       | X2 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_220;
            // 0x00AD3CBC: LDR x1, [x8, #0x228]       | X1 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_228;
            // 0x00AD3CC0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3CC4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3CC8: BR x2                      | goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_220;
            goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_220;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD349C (11351196), len: 64  VirtAddr: 0x00AD349C RVA: 0x00AD349C token: 100684753 methodIndex: 47413 delegateWrapperIndex: 0 methodInvoker: 0
        private int ReadInt32()
        {
            //
            // Disasemble & Code
            // 0x00AD349C: STP x20, x19, [sp, #-0x20]! | stack[1152921513721026608] = ???;  stack[1152921513721026616] = ???;  //  dest_result_addr=1152921513721026608 |  dest_result_addr=1152921513721026616
            // 0x00AD34A0: STP x29, x30, [sp, #0x10]  | stack[1152921513721026624] = ???;  stack[1152921513721026632] = ???;  //  dest_result_addr=1152921513721026624 |  dest_result_addr=1152921513721026632
            // 0x00AD34A4: ADD x29, sp, #0x10         | X29 = (1152921513721026608 + 16) = 1152921513721026624 (0x100000021F3F5840);
            // 0x00AD34A8: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00AD34AC: MOV x19, x0                | X19 = 1152921513721038640 (0x100000021F3F8730);//ML01
            // 0x00AD34B0: BL #0xad3c40               | this.MovePosition(count:  4);           
            this.MovePosition(count:  4);
            // 0x00AD34B4: LDR x19, [x19, #0x48]      | X19 = this._reader; //P2                
            // 0x00AD34B8: CBNZ x19, #0xad34c0        | if (this._reader != null) goto label_0; 
            if(this._reader != null)
            {
                goto label_0;
            }
            // 0x00AD34BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD34C0: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD34C4: MOV x0, x19                | X0 = this._reader;//m1                  
            // 0x00AD34C8: LDR x2, [x8, #0x240]       | X2 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_240;
            // 0x00AD34CC: LDR x1, [x8, #0x248]       | X1 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_248;
            // 0x00AD34D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD34D4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD34D8: BR x2                      | goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_240;
            goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_240;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3D20 (11353376), len: 64  VirtAddr: 0x00AD3D20 RVA: 0x00AD3D20 token: 100684754 methodIndex: 47414 delegateWrapperIndex: 0 methodInvoker: 0
        private long ReadInt64()
        {
            //
            // Disasemble & Code
            // 0x00AD3D20: STP x20, x19, [sp, #-0x20]! | stack[1152921513721146800] = ???;  stack[1152921513721146808] = ???;  //  dest_result_addr=1152921513721146800 |  dest_result_addr=1152921513721146808
            // 0x00AD3D24: STP x29, x30, [sp, #0x10]  | stack[1152921513721146816] = ???;  stack[1152921513721146824] = ???;  //  dest_result_addr=1152921513721146816 |  dest_result_addr=1152921513721146824
            // 0x00AD3D28: ADD x29, sp, #0x10         | X29 = (1152921513721146800 + 16) = 1152921513721146816 (0x100000021F412DC0);
            // 0x00AD3D2C: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x00AD3D30: MOV x19, x0                | X19 = 1152921513721158832 (0x100000021F415CB0);//ML01
            // 0x00AD3D34: BL #0xad3c40               | this.MovePosition(count:  8);           
            this.MovePosition(count:  8);
            // 0x00AD3D38: LDR x19, [x19, #0x48]      | X19 = this._reader; //P2                
            // 0x00AD3D3C: CBNZ x19, #0xad3d44        | if (this._reader != null) goto label_0; 
            if(this._reader != null)
            {
                goto label_0;
            }
            // 0x00AD3D40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD3D44: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD3D48: MOV x0, x19                | X0 = this._reader;//m1                  
            // 0x00AD3D4C: LDR x2, [x8, #0x250]       | X2 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_250;
            // 0x00AD3D50: LDR x1, [x8, #0x258]       | X1 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_258;
            // 0x00AD3D54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3D58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3D5C: BR x2                      | goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_250;
            goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_250;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1FCC (11345868), len: 64  VirtAddr: 0x00AD1FCC RVA: 0x00AD1FCC token: 100684755 methodIndex: 47415 delegateWrapperIndex: 0 methodInvoker: 0
        private Newtonsoft.Json.Bson.BsonType ReadType()
        {
            //
            // Disasemble & Code
            // 0x00AD1FCC: STP x20, x19, [sp, #-0x20]! | stack[1152921513721266992] = ???;  stack[1152921513721267000] = ???;  //  dest_result_addr=1152921513721266992 |  dest_result_addr=1152921513721267000
            // 0x00AD1FD0: STP x29, x30, [sp, #0x10]  | stack[1152921513721267008] = ???;  stack[1152921513721267016] = ???;  //  dest_result_addr=1152921513721267008 |  dest_result_addr=1152921513721267016
            // 0x00AD1FD4: ADD x29, sp, #0x10         | X29 = (1152921513721266992 + 16) = 1152921513721267008 (0x100000021F430340);
            // 0x00AD1FD8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD1FDC: MOV x19, x0                | X19 = 1152921513721279024 (0x100000021F433230);//ML01
            // 0x00AD1FE0: BL #0xad3c40               | this.MovePosition(count:  1);           
            this.MovePosition(count:  1);
            // 0x00AD1FE4: LDR x19, [x19, #0x48]      | X19 = this._reader; //P2                
            // 0x00AD1FE8: CBNZ x19, #0xad1ff0        | if (this._reader != null) goto label_0; 
            if(this._reader != null)
            {
                goto label_0;
            }
            // 0x00AD1FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD1FF0: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD1FF4: MOV x0, x19                | X0 = this._reader;//m1                  
            // 0x00AD1FF8: LDR x2, [x8, #0x260]       | X2 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_260;
            // 0x00AD1FFC: LDR x1, [x8, #0x268]       | X1 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_268;
            // 0x00AD2000: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD2004: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD2008: BR x2                      | goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_260;
            goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_260;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD3C40 (11353152), len: 76  VirtAddr: 0x00AD3C40 RVA: 0x00AD3C40 token: 100684756 methodIndex: 47416 delegateWrapperIndex: 0 methodInvoker: 0
        private void MovePosition(int count)
        {
            //
            // Disasemble & Code
            //  | 
            ContainerContext val_2;
            //  | 
            int val_3;
            // 0x00AD3C40: STP x22, x21, [sp, #-0x30]! | stack[1152921513721387168] = ???;  stack[1152921513721387176] = ???;  //  dest_result_addr=1152921513721387168 |  dest_result_addr=1152921513721387176
            // 0x00AD3C44: STP x20, x19, [sp, #0x10]  | stack[1152921513721387184] = ???;  stack[1152921513721387192] = ???;  //  dest_result_addr=1152921513721387184 |  dest_result_addr=1152921513721387192
            // 0x00AD3C48: STP x29, x30, [sp, #0x20]  | stack[1152921513721387200] = ???;  stack[1152921513721387208] = ???;  //  dest_result_addr=1152921513721387200 |  dest_result_addr=1152921513721387208
            // 0x00AD3C4C: ADD x29, sp, #0x20         | X29 = (1152921513721387168 + 32) = 1152921513721387200 (0x100000021F44D8C0);
            // 0x00AD3C50: LDR x20, [x0, #0x70]       | X20 = this._currentContext; //P2        
            val_2 = this._currentContext;
            // 0x00AD3C54: MOV w19, w1                | W19 = count;//m1                        
            // 0x00AD3C58: CBZ x20, #0xad3c64         | if (this._currentContext == null) goto label_0;
            if(val_2 == null)
            {
                goto label_0;
            }
            // 0x00AD3C5C: LDR w21, [x20, #0x18]!     | W21 = this._currentContext.Position; //P2 
            val_3 = this._currentContext.Position;
            // 0x00AD3C60: B #0xad3c74                |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x00AD3C64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x00AD3C68: ORR w20, wzr, #0x18        | W20 = 24(0x18);                         
            val_2 = 24;
            // 0x00AD3C6C: LDR w21, [x20]             | W21 = 0x9814C0;                         
            val_3 = 9966784;
            // 0x00AD3C70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00AD3C74: ADD w8, w21, w19           | W8 = (val_3 + count);                   
            int val_1 = val_3 + count;
            // 0x00AD3C78: STR w8, [x20]              | mem[24] = (val_3 + count);               //  dest_result_addr=24
            mem[24] = val_1;
            // 0x00AD3C7C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3C80: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3C84: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD3C88: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD35DC (11351516), len: 64  VirtAddr: 0x00AD35DC RVA: 0x00AD35DC token: 100684757 methodIndex: 47417 delegateWrapperIndex: 0 methodInvoker: 0
        private byte[] ReadBytes(int count)
        {
            //
            // Disasemble & Code
            // 0x00AD35DC: STP x20, x19, [sp, #-0x20]! | stack[1152921513721507376] = ???;  stack[1152921513721507384] = ???;  //  dest_result_addr=1152921513721507376 |  dest_result_addr=1152921513721507384
            // 0x00AD35E0: STP x29, x30, [sp, #0x10]  | stack[1152921513721507392] = ???;  stack[1152921513721507400] = ???;  //  dest_result_addr=1152921513721507392 |  dest_result_addr=1152921513721507400
            // 0x00AD35E4: ADD x29, sp, #0x10         | X29 = (1152921513721507376 + 16) = 1152921513721507392 (0x100000021F46AE40);
            // 0x00AD35E8: MOV w19, w1                | W19 = count;//m1                        
            // 0x00AD35EC: MOV x20, x0                | X20 = 1152921513721519408 (0x100000021F46DD30);//ML01
            // 0x00AD35F0: BL #0xad3c40               | this.MovePosition(count:  count);       
            this.MovePosition(count:  count);
            // 0x00AD35F4: LDR x20, [x20, #0x48]      | X20 = this._reader; //P2                
            // 0x00AD35F8: CBNZ x20, #0xad3600        | if (this._reader != null) goto label_0; 
            if(this._reader != null)
            {
                goto label_0;
            }
            // 0x00AD35FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00AD3600: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryReader);    
            // 0x00AD3604: MOV x0, x20                | X0 = this._reader;//m1                  
            // 0x00AD3608: MOV w1, w19                | W1 = count;//m1                         
            // 0x00AD360C: LDP x3, x2, [x8, #0x1f0]   | X3 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1F0; X2 = typeof(System.IO.BinaryReader).__il2cppRuntimeField_1F8; //  | 
            // 0x00AD3610: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD3614: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD3618: BR x3                      | goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_1F0;
            goto typeof(System.IO.BinaryReader).__il2cppRuntimeField_1F0;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD44DC (11355356), len: 488  VirtAddr: 0x00AD44DC RVA: 0x00AD44DC token: 100684758 methodIndex: 47418 delegateWrapperIndex: 0 methodInvoker: 0
        private static BsonReader()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x00AD44DC: STP x22, x21, [sp, #-0x30]! | stack[1152921513721623456] = ???;  stack[1152921513721623464] = ???;  //  dest_result_addr=1152921513721623456 |  dest_result_addr=1152921513721623464
            // 0x00AD44E0: STP x20, x19, [sp, #0x10]  | stack[1152921513721623472] = ???;  stack[1152921513721623480] = ???;  //  dest_result_addr=1152921513721623472 |  dest_result_addr=1152921513721623480
            // 0x00AD44E4: STP x29, x30, [sp, #0x20]  | stack[1152921513721623488] = ???;  stack[1152921513721623496] = ???;  //  dest_result_addr=1152921513721623488 |  dest_result_addr=1152921513721623496
            // 0x00AD44E8: ADD x29, sp, #0x20         | X29 = (1152921513721623456 + 32) = 1152921513721623488 (0x100000021F4873C0);
            // 0x00AD44EC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AD44F0: LDRB w8, [x19, #0x4de]     | W8 = (bool)static_value_037334DE;       
            // 0x00AD44F4: TBNZ w8, #0, #0xad4510     | if (static_value_037334DE == true) goto label_0;
            // 0x00AD44F8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AD44FC: LDR x8, [x8, #0x3f8]       | X8 = 0x2B8F994;                         
            // 0x00AD4500: LDR w0, [x8]               | W0 = 0x1529;                            
            // 0x00AD4504: BL #0x2782188              | X0 = sub_2782188( ?? 0x1529, ????);     
            // 0x00AD4508: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD450C: STRB w8, [x19, #0x4de]     | static_value_037334DE = true;            //  dest_result_addr=57881822
            label_0:
            // 0x00AD4510: ADRP x21, #0x35db000       | X21 = 56471552 (0x35DB000);             
            // 0x00AD4514: LDR x21, [x21, #0xf00]     | X21 = 1152921504996170800;              
            // 0x00AD4518: LDR x19, [x21]             | X19 = typeof(System.Byte[]);            
            // 0x00AD451C: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD4520: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00AD4524: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00AD4528: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD452C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00AD4530: MOV x19, x0                | X19 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD4534: CBNZ x19, #0xad453c        | if ( != null) goto label_1;             
            if(null != null)
            {
                goto label_1;
            }
            // 0x00AD4538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_1:
            // 0x00AD453C: LDR w8, [x19, #0x18]       | W8 = System.Byte[].__il2cppRuntimeField_namespaze;
            // 0x00AD4540: CMP w8, #1                 | STATE = COMPARE(System.Byte[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AD4544: B.HI #0xad4554             | if (System.Byte[].__il2cppRuntimeField_namespaze > 0x1) goto label_2;
            // 0x00AD4548: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x00AD454C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4550: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_2:
            // 0x00AD4554: ORR w8, wzr, #0x7f         | W8 = 127(0x7F);                         
            // 0x00AD4558: STRB w8, [x19, #0x21]      | typeof(System.Byte[]).__il2cppRuntimeField_21 = 0x7F;  //  dest_result_addr=1152921504996170833
            typeof(System.Byte[]).__il2cppRuntimeField_21 = 127;
            // 0x00AD455C: ADRP x20, #0x3672000       | X20 = 57090048 (0x3672000);             
            // 0x00AD4560: LDR x20, [x20, #0x5d0]     | X20 = 1152921504857538560;              
            // 0x00AD4564: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD4568: LDR x8, [x8, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD456C: STR x19, [x8]              | Newtonsoft.Json.Bson.BsonReader._seqRange1 = typeof(System.Byte[]);  //  dest_result_addr=1152921504857542656
            Newtonsoft.Json.Bson.BsonReader._seqRange1 = null;
            // 0x00AD4570: LDR x19, [x21]             | X19 = typeof(System.Byte[]);            
            // 0x00AD4574: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD4578: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00AD457C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00AD4580: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD4584: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00AD4588: MOV x19, x0                | X19 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD458C: CBNZ x19, #0xad4594        | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x00AD4590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_3:
            // 0x00AD4594: LDR x8, [x19, #0x18]       | X8 = System.Byte[].__il2cppRuntimeField_namespaze;
            // 0x00AD4598: CBNZ w8, #0xad45ac         | if (System.Byte[].__il2cppRuntimeField_namespaze != 0) goto label_4;
            // 0x00AD459C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x00AD45A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD45A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            // 0x00AD45A8: LDR x8, [x19, #0x18]       | X8 = System.Byte[].__il2cppRuntimeField_namespaze;
            label_4:
            // 0x00AD45AC: MOVZ w9, #0xc2             | W9 = 194 (0xC2);//ML01                  
            // 0x00AD45B0: STRB w9, [x19, #0x20]      | typeof(System.Byte[]).__il2cppRuntimeField_20 = 0xC2;  //  dest_result_addr=1152921504996170832
            typeof(System.Byte[]).__il2cppRuntimeField_20 = 194;
            // 0x00AD45B4: CMP w8, #1                 | STATE = COMPARE(System.Byte[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AD45B8: B.HI #0xad45c8             | if (System.Byte[].__il2cppRuntimeField_namespaze > 0x1) goto label_5;
            // 0x00AD45BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x00AD45C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD45C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_5:
            // 0x00AD45C8: MOVZ w8, #0xdf             | W8 = 223 (0xDF);//ML01                  
            // 0x00AD45CC: STRB w8, [x19, #0x21]      | typeof(System.Byte[]).__il2cppRuntimeField_21 = 0xDF;  //  dest_result_addr=1152921504996170833
            typeof(System.Byte[]).__il2cppRuntimeField_21 = 223;
            // 0x00AD45D0: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD45D4: LDR x8, [x8, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD45D8: STR x19, [x8, #8]          | Newtonsoft.Json.Bson.BsonReader._seqRange2 = typeof(System.Byte[]);  //  dest_result_addr=1152921504857542664
            Newtonsoft.Json.Bson.BsonReader._seqRange2 = null;
            // 0x00AD45DC: LDR x19, [x21]             | X19 = typeof(System.Byte[]);            
            // 0x00AD45E0: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD45E4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00AD45E8: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00AD45EC: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD45F0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00AD45F4: MOV x19, x0                | X19 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD45F8: CBNZ x19, #0xad4600        | if ( != null) goto label_6;             
            if(null != null)
            {
                goto label_6;
            }
            // 0x00AD45FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_6:
            // 0x00AD4600: LDR x8, [x19, #0x18]       | X8 = System.Byte[].__il2cppRuntimeField_namespaze;
            // 0x00AD4604: CBNZ w8, #0xad4618         | if (System.Byte[].__il2cppRuntimeField_namespaze != 0) goto label_7;
            // 0x00AD4608: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x00AD460C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4610: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            // 0x00AD4614: LDR x8, [x19, #0x18]       | X8 = System.Byte[].__il2cppRuntimeField_namespaze;
            label_7:
            // 0x00AD4618: ORR w9, wzr, #0xe0         | W9 = 224(0xE0);                         
            // 0x00AD461C: STRB w9, [x19, #0x20]      | typeof(System.Byte[]).__il2cppRuntimeField_20 = 0xE0;  //  dest_result_addr=1152921504996170832
            typeof(System.Byte[]).__il2cppRuntimeField_20 = 224;
            // 0x00AD4620: CMP w8, #1                 | STATE = COMPARE(System.Byte[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AD4624: B.HI #0xad4634             | if (System.Byte[].__il2cppRuntimeField_namespaze > 0x1) goto label_8;
            // 0x00AD4628: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x00AD462C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4630: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_8:
            // 0x00AD4634: MOVZ w8, #0xef             | W8 = 239 (0xEF);//ML01                  
            // 0x00AD4638: STRB w8, [x19, #0x21]      | typeof(System.Byte[]).__il2cppRuntimeField_21 = 0xEF;  //  dest_result_addr=1152921504996170833
            typeof(System.Byte[]).__il2cppRuntimeField_21 = 239;
            // 0x00AD463C: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD4640: LDR x8, [x8, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD4644: STR x19, [x8, #0x10]       | Newtonsoft.Json.Bson.BsonReader._seqRange3 = typeof(System.Byte[]);  //  dest_result_addr=1152921504857542672
            Newtonsoft.Json.Bson.BsonReader._seqRange3 = null;
            // 0x00AD4648: LDR x19, [x21]             | X19 = typeof(System.Byte[]);            
            // 0x00AD464C: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD4650: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00AD4654: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00AD4658: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD465C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00AD4660: MOV x19, x0                | X19 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD4664: CBNZ x19, #0xad466c        | if ( != null) goto label_9;             
            if(null != null)
            {
                goto label_9;
            }
            // 0x00AD4668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_9:
            // 0x00AD466C: LDR x8, [x19, #0x18]       | X8 = System.Byte[].__il2cppRuntimeField_namespaze;
            // 0x00AD4670: CBNZ w8, #0xad4684         | if (System.Byte[].__il2cppRuntimeField_namespaze != 0) goto label_10;
            // 0x00AD4674: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x00AD4678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD467C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            // 0x00AD4680: LDR x8, [x19, #0x18]       | X8 = System.Byte[].__il2cppRuntimeField_namespaze;
            label_10:
            // 0x00AD4684: ORR w9, wzr, #0xf0         | W9 = 240(0xF0);                         
            // 0x00AD4688: STRB w9, [x19, #0x20]      | typeof(System.Byte[]).__il2cppRuntimeField_20 = 0xF0;  //  dest_result_addr=1152921504996170832
            typeof(System.Byte[]).__il2cppRuntimeField_20 = 240;
            // 0x00AD468C: CMP w8, #1                 | STATE = COMPARE(System.Byte[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AD4690: B.HI #0xad46a0             | if (System.Byte[].__il2cppRuntimeField_namespaze > 0x1) goto label_11;
            // 0x00AD4694: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x00AD4698: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD469C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_11:
            // 0x00AD46A0: MOVZ w8, #0xf4             | W8 = 244 (0xF4);//ML01                  
            // 0x00AD46A4: STRB w8, [x19, #0x21]      | typeof(System.Byte[]).__il2cppRuntimeField_21 = 0xF4;  //  dest_result_addr=1152921504996170833
            typeof(System.Byte[]).__il2cppRuntimeField_21 = 244;
            // 0x00AD46A8: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonReader);
            // 0x00AD46AC: LDR x8, [x8, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonReader.__il2cppRuntimeField_static_fields;
            // 0x00AD46B0: STR x19, [x8, #0x18]       | Newtonsoft.Json.Bson.BsonReader._seqRange4 = typeof(System.Byte[]);  //  dest_result_addr=1152921504857542680
            Newtonsoft.Json.Bson.BsonReader._seqRange4 = null;
            // 0x00AD46B4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD46B8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD46BC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD46C0: RET                        |  return;                                
            return;
        
        }
    
    }

}
