using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x281A780
[UnityEngine.AddComponentMenu] // 0x281A780
[Serializable]
public class ColorCorrectionCurves : PostEffectsBase
{
    // Fields
    public UnityEngine.AnimationCurve redChannel; //  0x00000020
    public UnityEngine.AnimationCurve greenChannel; //  0x00000028
    public UnityEngine.AnimationCurve blueChannel; //  0x00000030
    public bool useDepthCorrection; //  0x00000038
    public UnityEngine.AnimationCurve zCurve; //  0x00000040
    public UnityEngine.AnimationCurve depthRedChannel; //  0x00000048
    public UnityEngine.AnimationCurve depthGreenChannel; //  0x00000050
    public UnityEngine.AnimationCurve depthBlueChannel; //  0x00000058
    private UnityEngine.Material ccMaterial; //  0x00000060
    private UnityEngine.Material ccDepthMaterial; //  0x00000068
    private UnityEngine.Material selectiveCcMaterial; //  0x00000070
    private UnityEngine.Texture2D rgbChannelTex; //  0x00000078
    private UnityEngine.Texture2D rgbDepthChannelTex; //  0x00000080
    private UnityEngine.Texture2D zCurveTex; //  0x00000088
    public float saturation; //  0x00000090
    public bool selectiveCc; //  0x00000094
    public UnityEngine.Color selectiveFromColor; //  0x00000098
    public UnityEngine.Color selectiveToColor; //  0x000000A8
    public ColorCorrectionMode mode; //  0x000000B8
    public bool updateTextures; //  0x000000BC
    public UnityEngine.Shader colorCorrectionCurvesShader; //  0x000000C0
    public UnityEngine.Shader simpleColorCorrectionCurvesShader; //  0x000000C8
    public UnityEngine.Shader colorCorrectionSelectiveShader; //  0x000000D0
    private bool updateTexturesOnStartup; //  0x000000D8
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x0267808C (40337548), len: 104  VirtAddr: 0x0267808C RVA: 0x0267808C token: 100663342 methodIndex: 24426 delegateWrapperIndex: 0 methodInvoker: 0
    public ColorCorrectionCurves()
    {
        //
        // Disasemble & Code
        // 0x0267808C: STP x20, x19, [sp, #-0x20]! | stack[1152921509951164304] = ???;  stack[1152921509951164312] = ???;  //  dest_result_addr=1152921509951164304 |  dest_result_addr=1152921509951164312
        // 0x02678090: STP x29, x30, [sp, #0x10]  | stack[1152921509951164320] = ???;  stack[1152921509951164328] = ???;  //  dest_result_addr=1152921509951164320 |  dest_result_addr=1152921509951164328
        // 0x02678094: ADD x29, sp, #0x10         | X29 = (1152921509951164304 + 16) = 1152921509951164320 (0x100000013E8BCFA0);
        // 0x02678098: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267809C: MOV x19, x0                | X19 = 1152921509951176336 (0x100000013E8BFE90);//ML01
        // 0x026780A0: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x026780A4: ORR w20, wzr, #1           | W20 = 1(0x1);                           
        // 0x026780A8: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
        // 0x026780AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026780B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026780B4: STRB w20, [x19, #0x18]     | mem[1152921509951176360] = 0x1;          //  dest_result_addr=1152921509951176360
        mem[1152921509951176360] = true;
        // 0x026780B8: STRB w20, [x19, #0x1a]     | mem[1152921509951176362] = 0x1;          //  dest_result_addr=1152921509951176362
        mem[1152921509951176362] = true;
        // 0x026780BC: STR w8, [x19, #0x90]       | this.saturation = 1;                     //  dest_result_addr=1152921509951176480
        this.saturation = 1f;
        // 0x026780C0: BL #0x20d3be4              | X0 = UnityEngine.Color.get_white();     
        UnityEngine.Color val_2 = UnityEngine.Color.white;
        // 0x026780C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026780C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026780CC: STP s0, s1, [x19, #0x98]   | this.selectiveFromColor = val_2;  mem[1152921509951176492] = val_2.g;  //  dest_result_addr=1152921509951176488 |  dest_result_addr=1152921509951176492
        this.selectiveFromColor = val_2;
        mem[1152921509951176492] = val_2.g;
        // 0x026780D0: STP s2, s3, [x19, #0xa0]   | mem[1152921509951176496] = val_2.b;  mem[1152921509951176500] = val_2.a;  //  dest_result_addr=1152921509951176496 |  dest_result_addr=1152921509951176500
        mem[1152921509951176496] = val_2.b;
        mem[1152921509951176500] = val_2.a;
        // 0x026780D4: BL #0x20d3be4              | X0 = UnityEngine.Color.get_white();     
        UnityEngine.Color val_3 = UnityEngine.Color.white;
        // 0x026780D8: STP s0, s1, [x19, #0xa8]   | this.selectiveToColor = val_3;  mem[1152921509951176508] = val_3.g;  //  dest_result_addr=1152921509951176504 |  dest_result_addr=1152921509951176508
        this.selectiveToColor = val_3;
        mem[1152921509951176508] = val_3.g;
        // 0x026780DC: STP s2, s3, [x19, #0xb0]   | mem[1152921509951176512] = val_3.b;  mem[1152921509951176516] = val_3.a;  //  dest_result_addr=1152921509951176512 |  dest_result_addr=1152921509951176516
        mem[1152921509951176512] = val_3.b;
        mem[1152921509951176516] = val_3.a;
        // 0x026780E0: STRB w20, [x19, #0xd8]     | this.updateTexturesOnStartup = true;     //  dest_result_addr=1152921509951176552
        this.updateTexturesOnStartup = true;
        // 0x026780E4: STRB w20, [x19, #0xbc]     | this.updateTextures = true;              //  dest_result_addr=1152921509951176524
        this.updateTextures = true;
        // 0x026780E8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x026780EC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x026780F0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026780F4 (40337652), len: 48  VirtAddr: 0x026780F4 RVA: 0x026780F4 token: 100663343 methodIndex: 24427 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Start()
    {
        //
        // Disasemble & Code
        // 0x026780F4: STP x20, x19, [sp, #-0x20]! | stack[1152921509951276304] = ???;  stack[1152921509951276312] = ???;  //  dest_result_addr=1152921509951276304 |  dest_result_addr=1152921509951276312
        // 0x026780F8: STP x29, x30, [sp, #0x10]  | stack[1152921509951276320] = ???;  stack[1152921509951276328] = ???;  //  dest_result_addr=1152921509951276320 |  dest_result_addr=1152921509951276328
        // 0x026780FC: ADD x29, sp, #0x10         | X29 = (1152921509951276304 + 16) = 1152921509951276320 (0x100000013E8D8520);
        // 0x02678100: MOV x19, x0                | X19 = 1152921509951288336 (0x100000013E8DB410);//ML01
        // 0x02678104: LDR x8, [x19]              | X8 = typeof(ColorCorrectionCurves);     
        // 0x02678108: LDP x9, x1, [x8, #0x190]   | X9 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_190; X1 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_198; //  | 
        // 0x0267810C: BLR x9                     | X0 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_190();
        // 0x02678110: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02678114: STRB w8, [x19, #0xd8]      | this.updateTexturesOnStartup = true;     //  dest_result_addr=1152921509951288552
        this.updateTexturesOnStartup = true;
        // 0x02678118: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0267811C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02678120: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02678130 (40337712), len: 4  VirtAddr: 0x02678130 RVA: 0x02678130 token: 100663344 methodIndex: 24428 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Awake()
    {
        //
        // Disasemble & Code
        // 0x02678130: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02678134 (40337716), len: 708  VirtAddr: 0x02678134 RVA: 0x02678134 token: 100663345 methodIndex: 24429 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        //  | 
        var val_12;
        // 0x02678134: STP x22, x21, [sp, #-0x30]! | stack[1152921509951565824] = ???;  stack[1152921509951565832] = ???;  //  dest_result_addr=1152921509951565824 |  dest_result_addr=1152921509951565832
        // 0x02678138: STP x20, x19, [sp, #0x10]  | stack[1152921509951565840] = ???;  stack[1152921509951565848] = ???;  //  dest_result_addr=1152921509951565840 |  dest_result_addr=1152921509951565848
        // 0x0267813C: STP x29, x30, [sp, #0x20]  | stack[1152921509951565856] = ???;  stack[1152921509951565864] = ???;  //  dest_result_addr=1152921509951565856 |  dest_result_addr=1152921509951565864
        // 0x02678140: ADD x29, sp, #0x20         | X29 = (1152921509951565824 + 32) = 1152921509951565856 (0x100000013E91F020);
        // 0x02678144: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02678148: LDRB w8, [x20, #0xe5b]     | W8 = (bool)static_value_03740E5B;       
        // 0x0267814C: MOV x19, x0                | X19 = 1152921509951577872 (0x100000013E921F10);//ML01
        // 0x02678150: TBNZ w8, #0, #0x267816c    | if (static_value_03740E5B == true) goto label_0;
        // 0x02678154: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x02678158: LDR x8, [x8, #0xbe0]       | X8 = 0x2B9171C;                         
        // 0x0267815C: LDR w0, [x8]               | W0 = 0x1C8C;                            
        // 0x02678160: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C8C, ????);     
        // 0x02678164: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02678168: STRB w8, [x20, #0xe5b]     | static_value_03740E5B = true;            //  dest_result_addr=57937499
        label_0:
        // 0x0267816C: LDR x8, [x19]              | X8 = typeof(ColorCorrectionCurves);     
        // 0x02678170: LDR w9, [x19, #0xb8]       | W9 = this.mode; //P2                    
        // 0x02678174: LDP x10, x2, [x8, #0x1b0]  | X10 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_1B0; X2 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_1B8; //  | 
        // 0x02678178: CMP w9, #1                 | STATE = COMPARE(this.mode, 0x1)         
        // 0x0267817C: CSET w1, eq                | W1 = this.mode == 0x1 ? 1 : 0;          
        var val_1 = (this.mode == 1) ? 1 : 0;
        // 0x02678180: MOV x0, x19                | X0 = 1152921509951577872 (0x100000013E921F10);//ML01
        // 0x02678184: BLR x10                    | X0 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_1B0();
        // 0x02678188: LDR x8, [x19]              | X8 = typeof(ColorCorrectionCurves);     
        // 0x0267818C: LDR x1, [x19, #0xc8]       | X1 = this.simpleColorCorrectionCurvesShader; //P2 
        // 0x02678190: LDR x2, [x19, #0x60]       | X2 = this.ccMaterial; //P2              
        // 0x02678194: MOV x0, x19                | X0 = 1152921509951577872 (0x100000013E921F10);//ML01
        // 0x02678198: LDP x9, x3, [x8, #0x150]   | X9 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_150; X3 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_158; //  | 
        // 0x0267819C: BLR x9                     | X0 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_150();
        // 0x026781A0: LDR x8, [x19]              | X8 = typeof(ColorCorrectionCurves);     
        // 0x026781A4: STR x0, [x19, #0x60]       | this.ccMaterial = this;                  //  dest_result_addr=1152921509951577968
        this.ccMaterial = this;
        // 0x026781A8: LDR x1, [x19, #0xc0]       | X1 = this.colorCorrectionCurvesShader; //P2 
        // 0x026781AC: LDR x2, [x19, #0x68]       | X2 = this.ccDepthMaterial; //P2         
        // 0x026781B0: LDP x9, x3, [x8, #0x150]   | X9 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_150; X3 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_158; //  | 
        // 0x026781B4: MOV x0, x19                | X0 = 1152921509951577872 (0x100000013E921F10);//ML01
        // 0x026781B8: BLR x9                     | X0 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_150();
        // 0x026781BC: LDR x8, [x19]              | X8 = typeof(ColorCorrectionCurves);     
        // 0x026781C0: STR x0, [x19, #0x68]       | this.ccDepthMaterial = this;             //  dest_result_addr=1152921509951577976
        this.ccDepthMaterial = this;
        // 0x026781C4: LDR x1, [x19, #0xd0]       | X1 = this.colorCorrectionSelectiveShader; //P2 
        // 0x026781C8: LDR x2, [x19, #0x70]       | X2 = this.selectiveCcMaterial; //P2     
        // 0x026781CC: LDP x9, x3, [x8, #0x150]   | X9 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_150; X3 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_158; //  | 
        // 0x026781D0: MOV x0, x19                | X0 = 1152921509951577872 (0x100000013E921F10);//ML01
        // 0x026781D4: BLR x9                     | X0 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_150();
        // 0x026781D8: STR x0, [x19, #0x70]       | this.selectiveCcMaterial = this;         //  dest_result_addr=1152921509951577984
        this.selectiveCcMaterial = this;
        // 0x026781DC: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x026781E0: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x026781E4: LDR x20, [x19, #0x78]      | X20 = this.rgbChannelTex; //P2          
        // 0x026781E8: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x026781EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x026781F0: TBZ w8, #0, #0x2678200     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x026781F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x026781F8: CBNZ w8, #0x2678200        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x026781FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x02678200: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678204: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678208: MOV x1, x20                | X1 = this.rgbChannelTex;//m1            
        // 0x0267820C: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_2 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02678210: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x02678214: TBNZ w8, #0, #0x267824c    | if ((val_2 & 1) == true) goto label_3;  
        if(val_3 == true)
        {
            goto label_3;
        }
        // 0x02678218: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x0267821C: LDR x8, [x8, #0x78]        | X8 = 1152921504697102336;               
        // 0x02678220: LDR x0, [x8]               | X0 = typeof(UnityEngine.Texture2D);     
        UnityEngine.Texture2D val_4 = null;
        // 0x02678224: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Texture2D), ????);
        // 0x02678228: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x0267822C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
        // 0x02678230: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
        // 0x02678234: ORR w2, wzr, #4            | W2 = 4(0x4);                            
        // 0x02678238: MOVZ w3, #0x5              | W3 = 5 (0x5);//ML01                     
        // 0x0267823C: ORR w5, wzr, #1            | W5 = 1(0x1);                            
        // 0x02678240: MOV x20, x0                | X20 = 1152921504697102336 (0x1000000005613000);//ML01
        // 0x02678244: BL #0x268f700              | .ctor(width:  256, height:  4, format:  5, mipmap:  false, linear:  true);
        val_4 = new UnityEngine.Texture2D(width:  256, height:  4, format:  5, mipmap:  false, linear:  true);
        // 0x02678248: STR x20, [x19, #0x78]      | this.rgbChannelTex = typeof(UnityEngine.Texture2D);  //  dest_result_addr=1152921509951577992
        this.rgbChannelTex = val_4;
        label_3:
        // 0x0267824C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02678250: LDR x20, [x19, #0x80]      | X20 = this.rgbDepthChannelTex; //P2     
        // 0x02678254: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02678258: TBZ w8, #0, #0x2678268     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0267825C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02678260: CBNZ w8, #0x2678268        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x02678264: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x02678268: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267826C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678270: MOV x1, x20                | X1 = this.rgbDepthChannelTex;//m1       
        // 0x02678274: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_5 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02678278: AND w8, w0, #1             | W8 = (val_5 & 1);                       
        bool val_6 = val_5;
        // 0x0267827C: TBNZ w8, #0, #0x26782b4    | if ((val_5 & 1) == true) goto label_6;  
        if(val_6 == true)
        {
            goto label_6;
        }
        // 0x02678280: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x02678284: LDR x8, [x8, #0x78]        | X8 = 1152921504697102336;               
        // 0x02678288: LDR x0, [x8]               | X0 = typeof(UnityEngine.Texture2D);     
        UnityEngine.Texture2D val_7 = null;
        // 0x0267828C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Texture2D), ????);
        // 0x02678290: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x02678294: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
        // 0x02678298: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
        // 0x0267829C: ORR w2, wzr, #4            | W2 = 4(0x4);                            
        // 0x026782A0: MOVZ w3, #0x5              | W3 = 5 (0x5);//ML01                     
        // 0x026782A4: ORR w5, wzr, #1            | W5 = 1(0x1);                            
        // 0x026782A8: MOV x20, x0                | X20 = 1152921504697102336 (0x1000000005613000);//ML01
        // 0x026782AC: BL #0x268f700              | .ctor(width:  256, height:  4, format:  5, mipmap:  false, linear:  true);
        val_7 = new UnityEngine.Texture2D(width:  256, height:  4, format:  5, mipmap:  false, linear:  true);
        // 0x026782B0: STR x20, [x19, #0x80]      | this.rgbDepthChannelTex = typeof(UnityEngine.Texture2D);  //  dest_result_addr=1152921509951578000
        this.rgbDepthChannelTex = val_7;
        label_6:
        // 0x026782B4: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x026782B8: LDR x20, [x19, #0x88]      | X20 = this.zCurveTex; //P2              
        // 0x026782BC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x026782C0: TBZ w8, #0, #0x26782d0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x026782C4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x026782C8: CBNZ w8, #0x26782d0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x026782CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_8:
        // 0x026782D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026782D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026782D8: MOV x1, x20                | X1 = this.zCurveTex;//m1                
        // 0x026782DC: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_8 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x026782E0: AND w8, w0, #1             | W8 = (val_8 & 1);                       
        bool val_9 = val_8;
        // 0x026782E4: TBNZ w8, #0, #0x267831c    | if ((val_8 & 1) == true) goto label_9;  
        if(val_9 == true)
        {
            goto label_9;
        }
        // 0x026782E8: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x026782EC: LDR x8, [x8, #0x78]        | X8 = 1152921504697102336;               
        // 0x026782F0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Texture2D);     
        UnityEngine.Texture2D val_10 = null;
        // 0x026782F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Texture2D), ????);
        // 0x026782F8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x026782FC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
        // 0x02678300: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
        // 0x02678304: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02678308: MOVZ w3, #0x5              | W3 = 5 (0x5);//ML01                     
        // 0x0267830C: ORR w5, wzr, #1            | W5 = 1(0x1);                            
        // 0x02678310: MOV x20, x0                | X20 = 1152921504697102336 (0x1000000005613000);//ML01
        // 0x02678314: BL #0x268f700              | .ctor(width:  256, height:  1, format:  5, mipmap:  false, linear:  true);
        val_10 = new UnityEngine.Texture2D(width:  256, height:  1, format:  5, mipmap:  false, linear:  true);
        // 0x02678318: STR x20, [x19, #0x88]      | this.zCurveTex = typeof(UnityEngine.Texture2D);  //  dest_result_addr=1152921509951578008
        this.zCurveTex = val_10;
        label_9:
        // 0x0267831C: LDR x20, [x19, #0x78]      | X20 = this.rgbChannelTex; //P2          
        // 0x02678320: CBNZ x20, #0x2678328       | if (this.rgbChannelTex != null) goto label_10;
        if(this.rgbChannelTex != null)
        {
            goto label_10;
        }
        // 0x02678324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(width:  256, height:  1, format:  5, mipmap:  false, linear:  true), ????);
        label_10:
        // 0x02678328: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267832C: MOVZ w1, #0x34             | W1 = 52 (0x34);//ML01                   
        // 0x02678330: MOV x0, x20                | X0 = this.rgbChannelTex;//m1            
        // 0x02678334: BL #0x1b77b04              | this.rgbChannelTex.set_hideFlags(value:  52);
        this.rgbChannelTex.hideFlags = 52;
        // 0x02678338: LDR x20, [x19, #0x80]      | X20 = this.rgbDepthChannelTex; //P2     
        // 0x0267833C: CBNZ x20, #0x2678344       | if (this.rgbDepthChannelTex != null) goto label_11;
        if(this.rgbDepthChannelTex != null)
        {
            goto label_11;
        }
        // 0x02678340: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rgbChannelTex, ????);
        label_11:
        // 0x02678344: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678348: MOVZ w1, #0x34             | W1 = 52 (0x34);//ML01                   
        // 0x0267834C: MOV x0, x20                | X0 = this.rgbDepthChannelTex;//m1       
        // 0x02678350: BL #0x1b77b04              | this.rgbDepthChannelTex.set_hideFlags(value:  52);
        this.rgbDepthChannelTex.hideFlags = 52;
        // 0x02678354: LDR x20, [x19, #0x88]      | X20 = this.zCurveTex; //P2              
        // 0x02678358: CBNZ x20, #0x2678360       | if (this.zCurveTex != null) goto label_12;
        if(this.zCurveTex != null)
        {
            goto label_12;
        }
        // 0x0267835C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rgbDepthChannelTex, ????);
        label_12:
        // 0x02678360: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678364: MOVZ w1, #0x34             | W1 = 52 (0x34);//ML01                   
        // 0x02678368: MOV x0, x20                | X0 = this.zCurveTex;//m1                
        // 0x0267836C: BL #0x1b77b04              | this.zCurveTex.set_hideFlags(value:  52);
        this.zCurveTex.hideFlags = 52;
        // 0x02678370: LDR x20, [x19, #0x78]      | X20 = this.rgbChannelTex; //P2          
        // 0x02678374: CBNZ x20, #0x267837c       | if (this.rgbChannelTex != null) goto label_13;
        if(this.rgbChannelTex != null)
        {
            goto label_13;
        }
        // 0x02678378: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.zCurveTex, ????);
        label_13:
        // 0x0267837C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678380: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02678384: MOV x0, x20                | X0 = this.rgbChannelTex;//m1            
        // 0x02678388: BL #0x268f0a8              | this.rgbChannelTex.set_wrapMode(value:  1);
        this.rgbChannelTex.wrapMode = 1;
        // 0x0267838C: LDR x20, [x19, #0x80]      | X20 = this.rgbDepthChannelTex; //P2     
        // 0x02678390: CBNZ x20, #0x2678398       | if (this.rgbDepthChannelTex != null) goto label_14;
        if(this.rgbDepthChannelTex != null)
        {
            goto label_14;
        }
        // 0x02678394: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rgbChannelTex, ????);
        label_14:
        // 0x02678398: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267839C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x026783A0: MOV x0, x20                | X0 = this.rgbDepthChannelTex;//m1       
        // 0x026783A4: BL #0x268f0a8              | this.rgbDepthChannelTex.set_wrapMode(value:  1);
        this.rgbDepthChannelTex.wrapMode = 1;
        // 0x026783A8: LDR x20, [x19, #0x88]      | X20 = this.zCurveTex; //P2              
        // 0x026783AC: CBNZ x20, #0x26783b4       | if (this.zCurveTex != null) goto label_15;
        if(this.zCurveTex != null)
        {
            goto label_15;
        }
        // 0x026783B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rgbDepthChannelTex, ????);
        label_15:
        // 0x026783B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026783B8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x026783BC: MOV x0, x20                | X0 = this.zCurveTex;//m1                
        // 0x026783C0: BL #0x268f0a8              | this.zCurveTex.set_wrapMode(value:  1); 
        this.zCurveTex.wrapMode = 1;
        // 0x026783C4: LDRB w8, [x19, #0x1a]      | 
        // 0x026783C8: CBNZ w8, #0x26783e0        | if (typeof(UnityEngine.Texture2D) != 0) goto label_16;
        if(null != 0)
        {
            goto label_16;
        }
        // 0x026783CC: LDR x8, [x19]              | X8 = typeof(ColorCorrectionCurves);     
        // 0x026783D0: MOV x0, x19                | X0 = 1152921509951577872 (0x100000013E921F10);//ML01
        // 0x026783D4: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_1E0; X1 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_1E8; //  | 
        // 0x026783D8: BLR x9                     | X0 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_1E0();
        // 0x026783DC: LDRB w8, [x19, #0x1a]      | 
        label_16:
        // 0x026783E0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x026783E4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x026783E8: CMP w8, #0                 | STATE = COMPARE(typeof(ColorCorrectionCurves), 0x0)
        // 0x026783EC: CSET w0, ne                | W0 = typeof(ColorCorrectionCurves) != null ? 1 : 0;
        var val_11 = (null != 0) ? 1 : 0;
        // 0x026783F0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x026783F4: RET                        |  return (System.Boolean)typeof(ColorCorrectionCurves) != null ? 1 : 0;
        return (bool)val_11;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x026783F8 (40338424), len: 1160  VirtAddr: 0x026783F8 RVA: 0x026783F8 token: 100663346 methodIndex: 24430 delegateWrapperIndex: 0 methodInvoker: 0
    public override void UpdateParameters()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Texture2D val_15;
        //  | 
        UnityEngine.AnimationCurve val_16;
        // 0x026783F8: STP d15, d14, [sp, #-0x70]! | stack[1152921509951825216] = ???;  stack[1152921509951825224] = ???;  //  dest_result_addr=1152921509951825216 |  dest_result_addr=1152921509951825224
        // 0x026783FC: STP d13, d12, [sp, #0x10]  | stack[1152921509951825232] = ???;  stack[1152921509951825240] = ???;  //  dest_result_addr=1152921509951825232 |  dest_result_addr=1152921509951825240
        // 0x02678400: STP d11, d10, [sp, #0x20]  | stack[1152921509951825248] = ???;  stack[1152921509951825256] = ???;  //  dest_result_addr=1152921509951825248 |  dest_result_addr=1152921509951825256
        // 0x02678404: STP d9, d8, [sp, #0x30]    | stack[1152921509951825264] = ???;  stack[1152921509951825272] = ???;  //  dest_result_addr=1152921509951825264 |  dest_result_addr=1152921509951825272
        // 0x02678408: STP x22, x21, [sp, #0x40]  | stack[1152921509951825280] = ???;  stack[1152921509951825288] = ???;  //  dest_result_addr=1152921509951825280 |  dest_result_addr=1152921509951825288
        // 0x0267840C: STP x20, x19, [sp, #0x50]  | stack[1152921509951825296] = ???;  stack[1152921509951825304] = ???;  //  dest_result_addr=1152921509951825296 |  dest_result_addr=1152921509951825304
        // 0x02678410: STP x29, x30, [sp, #0x60]  | stack[1152921509951825312] = ???;  stack[1152921509951825320] = ???;  //  dest_result_addr=1152921509951825312 |  dest_result_addr=1152921509951825320
        // 0x02678414: ADD x29, sp, #0x60         | X29 = (1152921509951825216 + 96) = 1152921509951825312 (0x100000013E95E5A0);
        // 0x02678418: SUB sp, sp, #0x80          | SP = (1152921509951825216 - 128) = 1152921509951825088 (0x100000013E95E4C0);
        // 0x0267841C: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02678420: LDRB w8, [x20, #0xe5c]     | W8 = (bool)static_value_03740E5C;       
        // 0x02678424: MOV x19, x0                | X19 = 1152921509951837328 (0x100000013E961490);//ML01
        val_15 = this;
        // 0x02678428: TBNZ w8, #0, #0x2678444    | if (static_value_03740E5C == true) goto label_0;
        // 0x0267842C: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x02678430: LDR x8, [x8, #0x9a8]       | X8 = 0x2B91724;                         
        // 0x02678434: LDR w0, [x8]               | W0 = 0x1C8E;                            
        // 0x02678438: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C8E, ????);     
        // 0x0267843C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02678440: STRB w8, [x20, #0xe5c]     | static_value_03740E5C = true;            //  dest_result_addr=57937500
        label_0:
        // 0x02678444: LDR x8, [x19]              | X8 = typeof(ColorCorrectionCurves);     
        // 0x02678448: MOV x0, x19                | X0 = 1152921509951837328 (0x100000013E961490);//ML01
        // 0x0267844C: LDP x9, x1, [x8, #0x190]   | X9 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_190; X1 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_198; //  | 
        // 0x02678450: BLR x9                     | X0 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_190();
        // 0x02678454: LDR x20, [x19, #0x20]      | X20 = this.redChannel; //P2             
        val_16 = this.redChannel;
        // 0x02678458: CBZ x20, #0x267885c        | if (this.redChannel == null) goto label_3;
        if(val_16 == null)
        {
            goto label_3;
        }
        // 0x0267845C: LDR x8, [x19, #0x28]       | X8 = this.greenChannel; //P2            
        // 0x02678460: CBZ x8, #0x267885c         | if (this.greenChannel == null) goto label_3;
        if(this.greenChannel == null)
        {
            goto label_3;
        }
        // 0x02678464: LDR x8, [x19, #0x30]       | X8 = this.blueChannel; //P2             
        // 0x02678468: CBZ x8, #0x267885c         | if (this.blueChannel == null) goto label_3;
        if(this.blueChannel == null)
        {
            goto label_3;
        }
        // 0x0267846C: ADRP x8, #0x2a96000        | X8 = 44654592 (0x2A96000);              
        // 0x02678470: LDR s0, [x8, #0xe98]       | S0 = 255;                               
        // 0x02678474: ADRP x9, #0x2a96000        | X9 = 44654592 (0x2A96000);              
        // 0x02678478: ADRP x22, #0x363f000       | X22 = 56881152 (0x363F000);             
        // 0x0267847C: LDR s15, [x9, #0xe9c]      | S15 = 0.003921569;                      
        // 0x02678480: STR s0, [sp, #0xc]         | stack[1152921509951825100] = 0x437F0000;  //  dest_result_addr=1152921509951825100
        // 0x02678484: LDR x22, [x22, #0x3b0]     | X22 = 1152921504695345152;              
        // 0x02678488: FMOV s8, wzr               | S8 = 0f;                                
        // 0x0267848C: FMOV s9, #1.00000000       | S9 = 1;                                 
        // 0x02678490: MOV v10.16b, v8.16b        | V10 = 0;//m1                            
        float val_16 = 0f;
        // 0x02678494: B #0x267849c               |  goto label_4;                          
        goto label_4;
        label_21:
        // 0x02678498: LDR x20, [x19, #0x20]      | X20 = this.redChannel; //P2             
        val_16 = this.redChannel;
        label_4:
        // 0x0267849C: CBNZ x20, #0x26784a4       | if (this.redChannel != null) goto label_5;
        if(val_16 != null)
        {
            goto label_5;
        }
        // 0x026784A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_5:
        // 0x026784A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026784A8: MOV x0, x20                | X0 = this.redChannel;//m1               
        // 0x026784AC: MOV v0.16b, v10.16b        | V0 = 0;//m1                             
        // 0x026784B0: BL #0x20c5fd4              | X0 = this.redChannel.Evaluate(time:  0f);
        float val_1 = val_16.Evaluate(time:  val_16);
        // 0x026784B4: LDR x0, [x22]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x026784B8: MOV v11.16b, v0.16b        | V11 = val_1;//m1                        
        // 0x026784BC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x026784C0: TBZ w8, #0, #0x26784d0     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x026784C4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x026784C8: CBNZ w8, #0x26784d0        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x026784CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_7:
        // 0x026784D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026784D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026784D8: MOV v0.16b, v11.16b        | V0 = val_1;//m1                         
        // 0x026784DC: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x026784E0: MOV v2.16b, v9.16b         | V2 = 1;//m1                             
        // 0x026784E4: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  val_1, min:  0f, max:  1f);
        float val_2 = UnityEngine.Mathf.Clamp(value:  val_1, min:  0f, max:  1f);
        // 0x026784E8: LDR x20, [x19, #0x28]      | X20 = this.greenChannel; //P2           
        // 0x026784EC: MOV v13.16b, v0.16b        | V13 = val_2;//m1                        
        // 0x026784F0: CBNZ x20, #0x26784f8       | if (this.greenChannel != null) goto label_8;
        if(this.greenChannel != null)
        {
            goto label_8;
        }
        // 0x026784F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_8:
        // 0x026784F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026784FC: MOV x0, x20                | X0 = this.greenChannel;//m1             
        // 0x02678500: MOV v0.16b, v10.16b        | V0 = 0;//m1                             
        // 0x02678504: BL #0x20c5fd4              | X0 = this.greenChannel.Evaluate(time:  0f);
        float val_3 = this.greenChannel.Evaluate(time:  val_16);
        // 0x02678508: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267850C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678510: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x02678514: MOV v2.16b, v9.16b         | V2 = 1;//m1                             
        // 0x02678518: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  float val_3 = this.greenChannel.Evaluate(time:  0f), min:  0f, max:  1f);
        float val_4 = UnityEngine.Mathf.Clamp(value:  val_3, min:  0f, max:  1f);
        // 0x0267851C: LDR x20, [x19, #0x30]      | X20 = this.blueChannel; //P2            
        // 0x02678520: MOV v12.16b, v0.16b        | V12 = val_4;//m1                        
        // 0x02678524: CBNZ x20, #0x267852c       | if (this.blueChannel != null) goto label_9;
        if(this.blueChannel != null)
        {
            goto label_9;
        }
        // 0x02678528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_9:
        // 0x0267852C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678530: MOV x0, x20                | X0 = this.blueChannel;//m1              
        // 0x02678534: MOV v0.16b, v10.16b        | V0 = 0;//m1                             
        // 0x02678538: BL #0x20c5fd4              | X0 = this.blueChannel.Evaluate(time:  0f);
        float val_5 = this.blueChannel.Evaluate(time:  val_16);
        // 0x0267853C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678540: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678544: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x02678548: MOV v2.16b, v9.16b         | V2 = 1;//m1                             
        // 0x0267854C: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  float val_5 = this.blueChannel.Evaluate(time:  0f), min:  0f, max:  1f);
        float val_6 = UnityEngine.Mathf.Clamp(value:  val_5, min:  0f, max:  1f);
        // 0x02678550: MOV v11.16b, v0.16b        | V11 = val_6;//m1                        
        // 0x02678554: LDR s0, [sp, #0xc]         | S0 = 255;                               
        float val_15 = 255f;
        // 0x02678558: LDR x21, [x19, #0x78]      | X21 = this.rgbChannelTex; //P2          
        // 0x0267855C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678560: ADD x0, sp, #0x70          | X0 = (1152921509951825088 + 112) = 1152921509951825200 (0x100000013E95E530);
        // 0x02678564: FMUL s0, s10, s0           | S0 = (0f * 255f);                       
        val_15 = val_16 * val_15;
        // 0x02678568: FRINTM s14, s0             | 
        // 0x0267856C: MOV v0.16b, v13.16b        | V0 = val_2;//m1                         
        // 0x02678570: MOV v1.16b, v13.16b        | V1 = val_2;//m1                         
        // 0x02678574: MOV v2.16b, v13.16b        | V2 = val_2;//m1                         
        // 0x02678578: STP xzr, xzr, [sp, #0x70]  | stack[1152921509951825200] = 0x0;  stack[1152921509951825208] = 0x0;  //  dest_result_addr=1152921509951825200 |  dest_result_addr=1152921509951825208
        // 0x0267857C: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
        // 0x02678580: CBNZ x21, #0x2678588       | if (this.rgbChannelTex != null) goto label_10;
        if(this.rgbChannelTex != null)
        {
            goto label_10;
        }
        // 0x02678584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E95E530, ????);
        label_10:
        // 0x02678588: LDP s0, s1, [sp, #0x70]    | S0 = 0; S1 = 0;                          //  | 
        // 0x0267858C: LDP s2, s3, [sp, #0x78]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02678590: FCVTZS w20, s14            | W20 = (int)(S14);                       
        // 0x02678594: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x02678598: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267859C: MOV x0, x21                | X0 = this.rgbChannelTex;//m1            
        // 0x026785A0: MOV w1, w20                | W1 = S14;//m1                           
        // 0x026785A4: BL #0x268f924              | this.rgbChannelTex.SetPixel(x:  (int)S14, y:  0, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        this.rgbChannelTex.SetPixel(x:  (int)S14, y:  0, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        // 0x026785A8: LDR x21, [x19, #0x78]      | X21 = this.rgbChannelTex; //P2          
        // 0x026785AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026785B0: ADD x0, sp, #0x60          | X0 = (1152921509951825088 + 96) = 1152921509951825184 (0x100000013E95E520);
        // 0x026785B4: MOV v0.16b, v12.16b        | V0 = val_4;//m1                         
        // 0x026785B8: MOV v1.16b, v12.16b        | V1 = val_4;//m1                         
        // 0x026785BC: MOV v2.16b, v12.16b        | V2 = val_4;//m1                         
        // 0x026785C0: STP xzr, xzr, [sp, #0x60]  | stack[1152921509951825184] = 0x0;  stack[1152921509951825192] = 0x0;  //  dest_result_addr=1152921509951825184 |  dest_result_addr=1152921509951825192
        // 0x026785C4: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
        // 0x026785C8: CBNZ x21, #0x26785d0       | if (this.rgbChannelTex != null) goto label_11;
        if(this.rgbChannelTex != null)
        {
            goto label_11;
        }
        // 0x026785CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E95E520, ????);
        label_11:
        // 0x026785D0: LDP s0, s1, [sp, #0x60]    | S0 = 0; S1 = 0;                          //  | 
        // 0x026785D4: LDP s2, s3, [sp, #0x68]    | S2 = 0; S3 = 0;                          //  | 
        // 0x026785D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026785DC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x026785E0: MOV x0, x21                | X0 = this.rgbChannelTex;//m1            
        // 0x026785E4: MOV w1, w20                | W1 = S14;//m1                           
        // 0x026785E8: BL #0x268f924              | this.rgbChannelTex.SetPixel(x:  (int)S14, y:  1, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        this.rgbChannelTex.SetPixel(x:  (int)S14, y:  1, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        // 0x026785EC: LDR x21, [x19, #0x78]      | X21 = this.rgbChannelTex; //P2          
        // 0x026785F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026785F4: ADD x0, sp, #0x50          | X0 = (1152921509951825088 + 80) = 1152921509951825168 (0x100000013E95E510);
        // 0x026785F8: MOV v0.16b, v11.16b        | V0 = val_6;//m1                         
        // 0x026785FC: MOV v1.16b, v11.16b        | V1 = val_6;//m1                         
        // 0x02678600: MOV v2.16b, v11.16b        | V2 = val_6;//m1                         
        // 0x02678604: STP xzr, xzr, [sp, #0x50]  | stack[1152921509951825168] = 0x0;  stack[1152921509951825176] = 0x0;  //  dest_result_addr=1152921509951825168 |  dest_result_addr=1152921509951825176
        // 0x02678608: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
        // 0x0267860C: CBNZ x21, #0x2678614       | if (this.rgbChannelTex != null) goto label_12;
        if(this.rgbChannelTex != null)
        {
            goto label_12;
        }
        // 0x02678610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E95E510, ????);
        label_12:
        // 0x02678614: LDP s0, s1, [sp, #0x50]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02678618: LDP s2, s3, [sp, #0x58]    | S2 = 0; S3 = 0;                          //  | 
        // 0x0267861C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02678620: ORR w2, wzr, #2            | W2 = 2(0x2);                            
        // 0x02678624: MOV x0, x21                | X0 = this.rgbChannelTex;//m1            
        // 0x02678628: MOV w1, w20                | W1 = S14;//m1                           
        // 0x0267862C: BL #0x268f924              | this.rgbChannelTex.SetPixel(x:  (int)S14, y:  2, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        this.rgbChannelTex.SetPixel(x:  (int)S14, y:  2, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        // 0x02678630: LDR x21, [x19, #0x40]      | X21 = this.zCurve; //P2                 
        // 0x02678634: CBNZ x21, #0x267863c       | if (this.zCurve != null) goto label_13; 
        if(this.zCurve != null)
        {
            goto label_13;
        }
        // 0x02678638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rgbChannelTex, ????);
        label_13:
        // 0x0267863C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678640: MOV x0, x21                | X0 = this.zCurve;//m1                   
        // 0x02678644: MOV v0.16b, v10.16b        | V0 = 0;//m1                             
        // 0x02678648: BL #0x20c5fd4              | X0 = this.zCurve.Evaluate(time:  0f);   
        float val_7 = this.zCurve.Evaluate(time:  val_16);
        // 0x0267864C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678650: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678654: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x02678658: MOV v2.16b, v9.16b         | V2 = 1;//m1                             
        // 0x0267865C: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  float val_7 = this.zCurve.Evaluate(time:  0f), min:  0f, max:  1f);
        float val_8 = UnityEngine.Mathf.Clamp(value:  val_7, min:  0f, max:  1f);
        // 0x02678660: LDR x21, [x19, #0x88]      | X21 = this.zCurveTex; //P2              
        // 0x02678664: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678668: ADD x0, sp, #0x40          | X0 = (1152921509951825088 + 64) = 1152921509951825152 (0x100000013E95E500);
        // 0x0267866C: MOV v1.16b, v0.16b         | V1 = val_8;//m1                         
        // 0x02678670: MOV v2.16b, v0.16b         | V2 = val_8;//m1                         
        // 0x02678674: STP xzr, xzr, [sp, #0x40]  | stack[1152921509951825152] = 0x0;  stack[1152921509951825160] = 0x0;  //  dest_result_addr=1152921509951825152 |  dest_result_addr=1152921509951825160
        // 0x02678678: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
        // 0x0267867C: CBNZ x21, #0x2678684       | if (this.zCurveTex != null) goto label_14;
        if(this.zCurveTex != null)
        {
            goto label_14;
        }
        // 0x02678680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E95E500, ????);
        label_14:
        // 0x02678684: LDP s0, s1, [sp, #0x40]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02678688: LDP s2, s3, [sp, #0x48]    | S2 = 0; S3 = 0;                          //  | 
        // 0x0267868C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x02678690: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02678694: MOV x0, x21                | X0 = this.zCurveTex;//m1                
        // 0x02678698: MOV w1, w20                | W1 = S14;//m1                           
        // 0x0267869C: BL #0x268f924              | this.zCurveTex.SetPixel(x:  (int)S14, y:  0, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        this.zCurveTex.SetPixel(x:  (int)S14, y:  0, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        // 0x026786A0: LDR x21, [x19, #0x48]      | X21 = this.depthRedChannel; //P2        
        // 0x026786A4: CBNZ x21, #0x26786ac       | if (this.depthRedChannel != null) goto label_15;
        if(this.depthRedChannel != null)
        {
            goto label_15;
        }
        // 0x026786A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.zCurveTex, ????);
        label_15:
        // 0x026786AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026786B0: MOV x0, x21                | X0 = this.depthRedChannel;//m1          
        // 0x026786B4: MOV v0.16b, v10.16b        | V0 = 0;//m1                             
        // 0x026786B8: BL #0x20c5fd4              | X0 = this.depthRedChannel.Evaluate(time:  0f);
        float val_9 = this.depthRedChannel.Evaluate(time:  val_16);
        // 0x026786BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026786C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026786C4: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x026786C8: MOV v2.16b, v9.16b         | V2 = 1;//m1                             
        // 0x026786CC: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  float val_9 = this.depthRedChannel.Evaluate(time:  0f), min:  0f, max:  1f);
        float val_10 = UnityEngine.Mathf.Clamp(value:  val_9, min:  0f, max:  1f);
        // 0x026786D0: LDR x21, [x19, #0x50]      | X21 = this.depthGreenChannel; //P2      
        // 0x026786D4: MOV v13.16b, v0.16b        | V13 = val_10;//m1                       
        // 0x026786D8: CBNZ x21, #0x26786e0       | if (this.depthGreenChannel != null) goto label_16;
        if(this.depthGreenChannel != null)
        {
            goto label_16;
        }
        // 0x026786DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_16:
        // 0x026786E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026786E4: MOV x0, x21                | X0 = this.depthGreenChannel;//m1        
        // 0x026786E8: MOV v0.16b, v10.16b        | V0 = 0;//m1                             
        // 0x026786EC: BL #0x20c5fd4              | X0 = this.depthGreenChannel.Evaluate(time:  0f);
        float val_11 = this.depthGreenChannel.Evaluate(time:  val_16);
        // 0x026786F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026786F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026786F8: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x026786FC: MOV v2.16b, v9.16b         | V2 = 1;//m1                             
        // 0x02678700: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  float val_11 = this.depthGreenChannel.Evaluate(time:  0f), min:  0f, max:  1f);
        float val_12 = UnityEngine.Mathf.Clamp(value:  val_11, min:  0f, max:  1f);
        // 0x02678704: LDR x21, [x19, #0x58]      | X21 = this.depthBlueChannel; //P2       
        // 0x02678708: MOV v12.16b, v0.16b        | V12 = val_12;//m1                       
        // 0x0267870C: CBNZ x21, #0x2678714       | if (this.depthBlueChannel != null) goto label_17;
        if(this.depthBlueChannel != null)
        {
            goto label_17;
        }
        // 0x02678710: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_17:
        // 0x02678714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678718: MOV x0, x21                | X0 = this.depthBlueChannel;//m1         
        // 0x0267871C: MOV v0.16b, v10.16b        | V0 = 0;//m1                             
        // 0x02678720: BL #0x20c5fd4              | X0 = this.depthBlueChannel.Evaluate(time:  0f);
        float val_13 = this.depthBlueChannel.Evaluate(time:  val_16);
        // 0x02678724: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678728: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267872C: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x02678730: MOV v2.16b, v9.16b         | V2 = 1;//m1                             
        // 0x02678734: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  float val_13 = this.depthBlueChannel.Evaluate(time:  0f), min:  0f, max:  1f);
        float val_14 = UnityEngine.Mathf.Clamp(value:  val_13, min:  0f, max:  1f);
        // 0x02678738: LDR x21, [x19, #0x80]      | X21 = this.rgbDepthChannelTex; //P2     
        // 0x0267873C: MOV v11.16b, v0.16b        | V11 = val_14;//m1                       
        // 0x02678740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678744: ADD x0, sp, #0x30          | X0 = (1152921509951825088 + 48) = 1152921509951825136 (0x100000013E95E4F0);
        // 0x02678748: MOV v0.16b, v13.16b        | V0 = val_10;//m1                        
        // 0x0267874C: MOV v1.16b, v13.16b        | V1 = val_10;//m1                        
        // 0x02678750: MOV v2.16b, v13.16b        | V2 = val_10;//m1                        
        // 0x02678754: STP xzr, xzr, [sp, #0x30]  | stack[1152921509951825136] = 0x0;  stack[1152921509951825144] = 0x0;  //  dest_result_addr=1152921509951825136 |  dest_result_addr=1152921509951825144
        // 0x02678758: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
        // 0x0267875C: CBNZ x21, #0x2678764       | if (this.rgbDepthChannelTex != null) goto label_18;
        if(this.rgbDepthChannelTex != null)
        {
            goto label_18;
        }
        // 0x02678760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E95E4F0, ????);
        label_18:
        // 0x02678764: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02678768: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x0267876C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x02678770: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02678774: MOV x0, x21                | X0 = this.rgbDepthChannelTex;//m1       
        // 0x02678778: MOV w1, w20                | W1 = S14;//m1                           
        // 0x0267877C: BL #0x268f924              | this.rgbDepthChannelTex.SetPixel(x:  (int)S14, y:  0, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        this.rgbDepthChannelTex.SetPixel(x:  (int)S14, y:  0, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        // 0x02678780: LDR x21, [x19, #0x80]      | X21 = this.rgbDepthChannelTex; //P2     
        // 0x02678784: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678788: ADD x0, sp, #0x20          | X0 = (1152921509951825088 + 32) = 1152921509951825120 (0x100000013E95E4E0);
        // 0x0267878C: MOV v0.16b, v12.16b        | V0 = val_12;//m1                        
        // 0x02678790: MOV v1.16b, v12.16b        | V1 = val_12;//m1                        
        // 0x02678794: MOV v2.16b, v12.16b        | V2 = val_12;//m1                        
        // 0x02678798: STP xzr, xzr, [sp, #0x20]  | stack[1152921509951825120] = 0x0;  stack[1152921509951825128] = 0x0;  //  dest_result_addr=1152921509951825120 |  dest_result_addr=1152921509951825128
        // 0x0267879C: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
        // 0x026787A0: CBNZ x21, #0x26787a8       | if (this.rgbDepthChannelTex != null) goto label_19;
        if(this.rgbDepthChannelTex != null)
        {
            goto label_19;
        }
        // 0x026787A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E95E4E0, ????);
        label_19:
        // 0x026787A8: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
        // 0x026787AC: LDP s2, s3, [sp, #0x28]    | S2 = 0; S3 = 0;                          //  | 
        // 0x026787B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026787B4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x026787B8: MOV x0, x21                | X0 = this.rgbDepthChannelTex;//m1       
        // 0x026787BC: MOV w1, w20                | W1 = S14;//m1                           
        // 0x026787C0: BL #0x268f924              | this.rgbDepthChannelTex.SetPixel(x:  (int)S14, y:  1, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        this.rgbDepthChannelTex.SetPixel(x:  (int)S14, y:  1, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        // 0x026787C4: LDR x21, [x19, #0x80]      | X21 = this.rgbDepthChannelTex; //P2     
        // 0x026787C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026787CC: ADD x0, sp, #0x10          | X0 = (1152921509951825088 + 16) = 1152921509951825104 (0x100000013E95E4D0);
        // 0x026787D0: MOV v0.16b, v11.16b        | V0 = val_14;//m1                        
        // 0x026787D4: MOV v1.16b, v11.16b        | V1 = val_14;//m1                        
        // 0x026787D8: MOV v2.16b, v11.16b        | V2 = val_14;//m1                        
        // 0x026787DC: STP xzr, xzr, [sp, #0x10]  | stack[1152921509951825104] = 0x0;  stack[1152921509951825112] = 0x0;  //  dest_result_addr=1152921509951825104 |  dest_result_addr=1152921509951825112
        // 0x026787E0: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
        // 0x026787E4: CBNZ x21, #0x26787ec       | if (this.rgbDepthChannelTex != null) goto label_20;
        if(this.rgbDepthChannelTex != null)
        {
            goto label_20;
        }
        // 0x026787E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E95E4D0, ????);
        label_20:
        // 0x026787EC: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x026787F0: LDP s2, s3, [sp, #0x18]    | S2 = 0; S3 = 0;                          //  | 
        // 0x026787F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026787F8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
        // 0x026787FC: MOV x0, x21                | X0 = this.rgbDepthChannelTex;//m1       
        // 0x02678800: MOV w1, w20                | W1 = S14;//m1                           
        // 0x02678804: BL #0x268f924              | this.rgbDepthChannelTex.SetPixel(x:  (int)S14, y:  2, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        this.rgbDepthChannelTex.SetPixel(x:  (int)S14, y:  2, color:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
        // 0x02678808: FADD s10, s10, s15         | S10 = (0f + 0.003921569f);              
        val_16 = val_16 + 0.003921569f;
        // 0x0267880C: FCMP s10, s9               | STATE = COMPARE((0f + 0.003921569f), 1) 
        // 0x02678810: B.LS #0x2678498            | if (0f <= 1f) goto label_21;            
        if(val_16 <= 1f)
        {
            goto label_21;
        }
        // 0x02678814: LDR x20, [x19, #0x78]      | X20 = this.rgbChannelTex; //P2          
        // 0x02678818: CBNZ x20, #0x2678820       | if (this.rgbChannelTex != null) goto label_22;
        if(this.rgbChannelTex != null)
        {
            goto label_22;
        }
        // 0x0267881C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rgbDepthChannelTex, ????);
        label_22:
        // 0x02678820: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678824: MOV x0, x20                | X0 = this.rgbChannelTex;//m1            
        // 0x02678828: BL #0x2690134              | this.rgbChannelTex.Apply();             
        this.rgbChannelTex.Apply();
        // 0x0267882C: LDR x20, [x19, #0x80]      | X20 = this.rgbDepthChannelTex; //P2     
        // 0x02678830: CBNZ x20, #0x2678838       | if (this.rgbDepthChannelTex != null) goto label_23;
        if(this.rgbDepthChannelTex != null)
        {
            goto label_23;
        }
        // 0x02678834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rgbChannelTex, ????);
        label_23:
        // 0x02678838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267883C: MOV x0, x20                | X0 = this.rgbDepthChannelTex;//m1       
        // 0x02678840: BL #0x2690134              | this.rgbDepthChannelTex.Apply();        
        this.rgbDepthChannelTex.Apply();
        // 0x02678844: LDR x19, [x19, #0x88]      | X19 = this.zCurveTex; //P2              
        val_15 = this.zCurveTex;
        // 0x02678848: CBNZ x19, #0x2678850       | if (this.zCurveTex != null) goto label_24;
        if(val_15 != null)
        {
            goto label_24;
        }
        // 0x0267884C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rgbDepthChannelTex, ????);
        label_24:
        // 0x02678850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678854: MOV x0, x19                | X0 = this.zCurveTex;//m1                
        // 0x02678858: BL #0x2690134              | this.zCurveTex.Apply();                 
        val_15.Apply();
        label_3:
        // 0x0267885C: SUB sp, x29, #0x60         | SP = (1152921509951825312 - 96) = 1152921509951825216 (0x100000013E95E540);
        // 0x02678860: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x02678864: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x02678868: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x0267886C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x02678870: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x02678874: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x02678878: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x0267887C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02678880 (40339584), len: 16  VirtAddr: 0x02678880 RVA: 0x02678880 token: 100663347 methodIndex: 24431 delegateWrapperIndex: 0 methodInvoker: 0
    public override void UpdateTextures()
    {
        //
        // Disasemble & Code
        // 0x02678880: LDR x8, [x0]               | X8 = typeof(ColorCorrectionCurves);     
        // 0x02678884: LDR x2, [x8, #0x240]       | X2 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_240;
        // 0x02678888: LDR x1, [x8, #0x248]       | X1 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_248;
        // 0x0267888C: BR x2                      | goto typeof(ColorCorrectionCurves).__il2cppRuntimeField_240;
        goto typeof(ColorCorrectionCurves).__il2cppRuntimeField_240;
    
    }
    //
    // Offset in libil2cpp.so: 0x02678890 (40339600), len: 1000  VirtAddr: 0x02678890 RVA: 0x02678890 token: 100663348 methodIndex: 24432 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.DepthTextureMode val_6;
        //  | 
        UnityEngine.Material val_7;
        //  | 
        float val_8;
        //  | 
        UnityEngine.Material val_9;
        //  | 
        var val_10;
        // 0x02678890: STP d11, d10, [sp, #-0x60]! | stack[1152921509952217648] = ???;  stack[1152921509952217656] = ???;  //  dest_result_addr=1152921509952217648 |  dest_result_addr=1152921509952217656
        // 0x02678894: STP d9, d8, [sp, #0x10]    | stack[1152921509952217664] = ???;  stack[1152921509952217672] = ???;  //  dest_result_addr=1152921509952217664 |  dest_result_addr=1152921509952217672
        // 0x02678898: STP x24, x23, [sp, #0x20]  | stack[1152921509952217680] = ???;  stack[1152921509952217688] = ???;  //  dest_result_addr=1152921509952217680 |  dest_result_addr=1152921509952217688
        // 0x0267889C: STP x22, x21, [sp, #0x30]  | stack[1152921509952217696] = ???;  stack[1152921509952217704] = ???;  //  dest_result_addr=1152921509952217696 |  dest_result_addr=1152921509952217704
        // 0x026788A0: STP x20, x19, [sp, #0x40]  | stack[1152921509952217712] = ???;  stack[1152921509952217720] = ???;  //  dest_result_addr=1152921509952217712 |  dest_result_addr=1152921509952217720
        // 0x026788A4: STP x29, x30, [sp, #0x50]  | stack[1152921509952217728] = ???;  stack[1152921509952217736] = ???;  //  dest_result_addr=1152921509952217728 |  dest_result_addr=1152921509952217736
        // 0x026788A8: ADD x29, sp, #0x50         | X29 = (1152921509952217648 + 80) = 1152921509952217728 (0x100000013E9BE280);
        // 0x026788AC: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x026788B0: LDRB w8, [x22, #0xe5d]     | W8 = (bool)static_value_03740E5D;       
        // 0x026788B4: MOV x19, x2                | X19 = destination;//m1                  
        // 0x026788B8: MOV x21, x1                | X21 = source;//m1                       
        // 0x026788BC: MOV x20, x0                | X20 = 1152921509952229744 (0x100000013E9C1170);//ML01
        // 0x026788C0: TBNZ w8, #0, #0x26788dc    | if (static_value_03740E5D == true) goto label_0;
        // 0x026788C4: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x026788C8: LDR x8, [x8, #0xdc0]       | X8 = 0x2B91720;                         
        // 0x026788CC: LDR w0, [x8]               | W0 = 0x1C8D;                            
        // 0x026788D0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C8D, ????);     
        // 0x026788D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026788D8: STRB w8, [x22, #0xe5d]     | static_value_03740E5D = true;            //  dest_result_addr=57937501
        label_0:
        // 0x026788DC: LDR x8, [x20]              | X8 = typeof(ColorCorrectionCurves);     
        // 0x026788E0: MOV x0, x20                | X0 = 1152921509952229744 (0x100000013E9C1170);//ML01
        // 0x026788E4: LDP x9, x1, [x8, #0x190]   | X9 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_190; X1 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_198; //  | 
        // 0x026788E8: BLR x9                     | X0 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_190();
        // 0x026788EC: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
        // 0x026788F0: TBZ w8, #0, #0x2678a98     | if (((ColorCorrectionCurves)[1152921509952229744] & 0x1) == 0) goto label_1;
        if((0 & 1) == 0)
        {
            goto label_1;
        }
        // 0x026788F4: LDRB w8, [x20, #0xd8]      | W8 = this.updateTexturesOnStartup; //P2 
        // 0x026788F8: CBZ w8, #0x2678914         | if (this.updateTexturesOnStartup == false) goto label_2;
        if(this.updateTexturesOnStartup == false)
        {
            goto label_2;
        }
        // 0x026788FC: LDR x8, [x20]              | X8 = typeof(ColorCorrectionCurves);     
        // 0x02678900: MOV x0, x20                | X0 = 1152921509952229744 (0x100000013E9C1170);//ML01
        // 0x02678904: LDR x9, [x8, #0x240]       | X9 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_240;
        // 0x02678908: LDR x1, [x8, #0x248]       | X1 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_248;
        // 0x0267890C: BLR x9                     | X0 = typeof(ColorCorrectionCurves).__il2cppRuntimeField_240();
        // 0x02678910: STRB wzr, [x20, #0xd8]     | this.updateTexturesOnStartup = false;    //  dest_result_addr=1152921509952229960
        this.updateTexturesOnStartup = false;
        label_2:
        // 0x02678914: LDRB w8, [x20, #0x38]      | W8 = this.useDepthCorrection; //P2      
        // 0x02678918: CBZ w8, #0x2678974         | if (this.useDepthCorrection == false) goto label_3;
        if(this.useDepthCorrection == false)
        {
            goto label_3;
        }
        // 0x0267891C: ADRP x22, #0x3668000       | X22 = 57049088 (0x3668000);             
        // 0x02678920: LDR x22, [x22, #0x338]     | X22 = 1152921509941328016;              
        // 0x02678924: MOV x0, x20                | X0 = 1152921509952229744 (0x100000013E9C1170);//ML01
        // 0x02678928: LDR x1, [x22]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x0267892C: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_1 = this.GetComponent<UnityEngine.Camera>();
        // 0x02678930: LDR x1, [x22]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02678934: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x02678938: MOV x0, x20                | X0 = 1152921509952229744 (0x100000013E9C1170);//ML01
        // 0x0267893C: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_2 = this.GetComponent<UnityEngine.Camera>();
        // 0x02678940: MOV x23, x0                | X23 = val_2;//m1                        
        // 0x02678944: CBNZ x23, #0x267894c       | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x02678948: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x0267894C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678950: MOV x0, x23                | X0 = val_2;//m1                         
        // 0x02678954: BL #0x20d2b10              | X0 = val_2.get_depthTextureMode();      
        UnityEngine.DepthTextureMode val_3 = val_2.depthTextureMode;
        // 0x02678958: MOV w23, w0                | W23 = val_3;//m1                        
        // 0x0267895C: CBNZ x22, #0x2678964       | if (val_1 != null) goto label_5;        
        if(val_1 != null)
        {
            goto label_5;
        }
        // 0x02678960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x02678964: ORR w1, w23, #1            | W1 = (val_3 | 1);                       
        val_6 = val_3 | 1;
        // 0x02678968: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267896C: MOV x0, x22                | X0 = val_1;//m1                         
        // 0x02678970: BL #0x20d2b78              | val_1.set_depthTextureMode(value:  val_6 = val_3 | 1);
        val_1.depthTextureMode = val_6;
        label_3:
        // 0x02678974: LDRB w8, [x20, #0x94]      | W8 = this.selectiveCc; //P2             
        // 0x02678978: MOV x22, x19               | X22 = destination;//m1                  
        val_7 = destination;
        // 0x0267897C: CBZ w8, #0x26789cc         | if (this.selectiveCc == false) goto label_6;
        if(this.selectiveCc == false)
        {
            goto label_6;
        }
        // 0x02678980: CBNZ x21, #0x2678988       | if (source != null) goto label_7;       
        if(source != null)
        {
            goto label_7;
        }
        // 0x02678984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_7:
        // 0x02678988: LDR x8, [x21]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0267898C: MOV x0, x21                | X0 = source;//m1                        
        // 0x02678990: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02678994: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02678998: MOV w22, w0                | W22 = source;//m1                       
        // 0x0267899C: CBNZ x21, #0x26789a4       | if (source != null) goto label_8;       
        if(source != null)
        {
            goto label_8;
        }
        // 0x026789A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_8:
        // 0x026789A4: LDR x8, [x21]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026789A8: MOV x0, x21                | X0 = source;//m1                        
        // 0x026789AC: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x026789B0: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x026789B4: MOV w2, w0                 | W2 = source;//m1                        
        // 0x026789B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026789BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026789C0: MOV w1, w22                | W1 = source;//m1                        
        // 0x026789C4: BL #0x1b89198              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        UnityEngine.RenderTexture val_4 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        // 0x026789C8: MOV x22, x0                | X22 = val_4;//m1                        
        val_7 = val_4;
        label_6:
        // 0x026789CC: LDRB w8, [x20, #0x38]      | W8 = this.useDepthCorrection; //P2      
        // 0x026789D0: CBZ w8, #0x2678ae4         | if (this.useDepthCorrection == false) goto label_9;
        if(this.useDepthCorrection == false)
        {
            goto label_9;
        }
        // 0x026789D4: LDR x23, [x20, #0x68]      | X23 = this.ccDepthMaterial; //P2        
        // 0x026789D8: LDR x24, [x20, #0x78]      | X24 = this.rgbChannelTex; //P2          
        // 0x026789DC: CBNZ x23, #0x26789e4       | if (this.ccDepthMaterial != null) goto label_10;
        if(this.ccDepthMaterial != null)
        {
            goto label_10;
        }
        // 0x026789E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_10:
        // 0x026789E4: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x026789E8: LDR x8, [x8, #0x5a0]       | X8 = (string**)(1152921509952152016)("_RgbTex");
        // 0x026789EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026789F0: MOV x0, x23                | X0 = this.ccDepthMaterial;//m1          
        // 0x026789F4: MOV x2, x24                | X2 = this.rgbChannelTex;//m1            
        // 0x026789F8: LDR x1, [x8]               | X1 = "_RgbTex";                         
        // 0x026789FC: BL #0x1a780c4              | this.ccDepthMaterial.SetTexture(name:  "_RgbTex", value:  this.rgbChannelTex);
        this.ccDepthMaterial.SetTexture(name:  "_RgbTex", value:  this.rgbChannelTex);
        // 0x02678A00: LDR x23, [x20, #0x68]      | X23 = this.ccDepthMaterial; //P2        
        // 0x02678A04: LDR x24, [x20, #0x88]      | X24 = this.zCurveTex; //P2              
        // 0x02678A08: CBNZ x23, #0x2678a10       | if (this.ccDepthMaterial != null) goto label_11;
        if(this.ccDepthMaterial != null)
        {
            goto label_11;
        }
        // 0x02678A0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ccDepthMaterial, ????);
        label_11:
        // 0x02678A10: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x02678A14: LDR x8, [x8, #0x128]       | X8 = (string**)(1152921509952160304)("_ZCurve");
        // 0x02678A18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02678A1C: MOV x0, x23                | X0 = this.ccDepthMaterial;//m1          
        // 0x02678A20: MOV x2, x24                | X2 = this.zCurveTex;//m1                
        // 0x02678A24: LDR x1, [x8]               | X1 = "_ZCurve";                         
        // 0x02678A28: BL #0x1a780c4              | this.ccDepthMaterial.SetTexture(name:  "_ZCurve", value:  this.zCurveTex);
        this.ccDepthMaterial.SetTexture(name:  "_ZCurve", value:  this.zCurveTex);
        // 0x02678A2C: LDR x23, [x20, #0x68]      | X23 = this.ccDepthMaterial; //P2        
        // 0x02678A30: LDR x24, [x20, #0x80]      | X24 = this.rgbDepthChannelTex; //P2     
        // 0x02678A34: CBNZ x23, #0x2678a3c       | if (this.ccDepthMaterial != null) goto label_12;
        if(this.ccDepthMaterial != null)
        {
            goto label_12;
        }
        // 0x02678A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ccDepthMaterial, ????);
        label_12:
        // 0x02678A3C: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
        // 0x02678A40: LDR x8, [x8, #0x750]       | X8 = (string**)(1152921509952168592)("_RgbDepthTex");
        // 0x02678A44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02678A48: MOV x0, x23                | X0 = this.ccDepthMaterial;//m1          
        // 0x02678A4C: MOV x2, x24                | X2 = this.rgbDepthChannelTex;//m1       
        // 0x02678A50: LDR x1, [x8]               | X1 = "_RgbDepthTex";                    
        // 0x02678A54: BL #0x1a780c4              | this.ccDepthMaterial.SetTexture(name:  "_RgbDepthTex", value:  this.rgbDepthChannelTex);
        this.ccDepthMaterial.SetTexture(name:  "_RgbDepthTex", value:  this.rgbDepthChannelTex);
        // 0x02678A58: LDR x23, [x20, #0x68]      | X23 = this.ccDepthMaterial; //P2        
        // 0x02678A5C: LDR s8, [x20, #0x90]       | S8 = this.saturation; //P2              
        val_8 = this.saturation;
        // 0x02678A60: CBNZ x23, #0x2678a68       | if (this.ccDepthMaterial != null) goto label_13;
        if(this.ccDepthMaterial != null)
        {
            goto label_13;
        }
        // 0x02678A64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ccDepthMaterial, ????);
        label_13:
        // 0x02678A68: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x02678A6C: LDR x8, [x8, #0xfa0]       | X8 = (string**)(1152921509945005712)("_Saturation");
        // 0x02678A70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678A74: MOV x0, x23                | X0 = this.ccDepthMaterial;//m1          
        // 0x02678A78: MOV v0.16b, v8.16b         | V0 = this.saturation;//m1               
        // 0x02678A7C: LDR x1, [x8]               | X1 = "_Saturation";                     
        // 0x02678A80: BL #0x1a79ef8              | this.ccDepthMaterial.SetFloat(name:  "_Saturation", value:  val_8);
        this.ccDepthMaterial.SetFloat(name:  "_Saturation", value:  val_8);
        // 0x02678A84: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02678A88: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02678A8C: LDR x23, [x20, #0x68]      | X23 = this.ccDepthMaterial; //P2        
        val_9 = this.ccDepthMaterial;
        // 0x02678A90: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        val_10 = null;
        // 0x02678A94: B #0x2678b4c               |  goto label_14;                         
        goto label_14;
        label_1:
        // 0x02678A98: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02678A9C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02678AA0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02678AA4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02678AA8: TBZ w8, #0, #0x2678ab8     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x02678AAC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02678AB0: CBNZ w8, #0x2678ab8        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x02678AB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_16:
        // 0x02678AB8: MOV x1, x21                | X1 = source;//m1                        
        // 0x02678ABC: MOV x2, x19                | X2 = destination;//m1                   
        // 0x02678AC0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x02678AC4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x02678AC8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x02678ACC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x02678AD0: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x02678AD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678AD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02678ADC: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x02678AE0: B #0x1a6ba68               | UnityEngine.Graphics.Blit(source:  0, dest:  source); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        return;
        label_9:
        // 0x02678AE4: LDR x23, [x20, #0x60]      | X23 = this.ccMaterial; //P2             
        // 0x02678AE8: LDR x24, [x20, #0x78]      | X24 = this.rgbChannelTex; //P2          
        // 0x02678AEC: CBNZ x23, #0x2678af4       | if (this.ccMaterial != null) goto label_17;
        if(this.ccMaterial != null)
        {
            goto label_17;
        }
        // 0x02678AF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_17:
        // 0x02678AF4: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x02678AF8: LDR x8, [x8, #0x5a0]       | X8 = (string**)(1152921509952152016)("_RgbTex");
        // 0x02678AFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02678B00: MOV x0, x23                | X0 = this.ccMaterial;//m1               
        // 0x02678B04: MOV x2, x24                | X2 = this.rgbChannelTex;//m1            
        // 0x02678B08: LDR x1, [x8]               | X1 = "_RgbTex";                         
        // 0x02678B0C: BL #0x1a780c4              | this.ccMaterial.SetTexture(name:  "_RgbTex", value:  this.rgbChannelTex);
        this.ccMaterial.SetTexture(name:  "_RgbTex", value:  this.rgbChannelTex);
        // 0x02678B10: LDR x23, [x20, #0x60]      | X23 = this.ccMaterial; //P2             
        // 0x02678B14: LDR s8, [x20, #0x90]       | S8 = this.saturation; //P2              
        val_8 = this.saturation;
        // 0x02678B18: CBNZ x23, #0x2678b20       | if (this.ccMaterial != null) goto label_18;
        if(this.ccMaterial != null)
        {
            goto label_18;
        }
        // 0x02678B1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ccMaterial, ????);
        label_18:
        // 0x02678B20: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x02678B24: LDR x8, [x8, #0xfa0]       | X8 = (string**)(1152921509945005712)("_Saturation");
        // 0x02678B28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678B2C: MOV x0, x23                | X0 = this.ccMaterial;//m1               
        // 0x02678B30: MOV v0.16b, v8.16b         | V0 = this.saturation;//m1               
        // 0x02678B34: LDR x1, [x8]               | X1 = "_Saturation";                     
        // 0x02678B38: BL #0x1a79ef8              | this.ccMaterial.SetFloat(name:  "_Saturation", value:  val_8);
        this.ccMaterial.SetFloat(name:  "_Saturation", value:  val_8);
        // 0x02678B3C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02678B40: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02678B44: LDR x23, [x20, #0x60]      | X23 = this.ccMaterial; //P2             
        val_9 = this.ccMaterial;
        // 0x02678B48: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        val_10 = null;
        label_14:
        // 0x02678B4C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02678B50: TBZ w8, #0, #0x2678b60     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x02678B54: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02678B58: CBNZ w8, #0x2678b60        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x02678B5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_20:
        // 0x02678B60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678B64: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02678B68: MOV x1, x21                | X1 = source;//m1                        
        // 0x02678B6C: MOV x2, x22                | X2 = val_4;//m1                         
        // 0x02678B70: MOV x3, x23                | X3 = this.ccMaterial;//m1               
        // 0x02678B74: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_7);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_7);
        // 0x02678B78: LDRB w8, [x20, #0x94]      | W8 = this.selectiveCc; //P2             
        // 0x02678B7C: CBZ w8, #0x2678c5c         | if (this.selectiveCc == false) goto label_21;
        if(this.selectiveCc == false)
        {
            goto label_21;
        }
        // 0x02678B80: LDR x21, [x20, #0x70]      | X21 = this.selectiveCcMaterial; //P2    
        // 0x02678B84: LDP s8, s9, [x20, #0x98]   | S8 = this.selectiveFromColor; //P2       //  | 
        // 0x02678B88: LDP s10, s11, [x20, #0xa0] |                                          //  | 
        // 0x02678B8C: CBNZ x21, #0x2678b94       | if (this.selectiveCcMaterial != null) goto label_22;
        if(this.selectiveCcMaterial != null)
        {
            goto label_22;
        }
        // 0x02678B90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_22:
        // 0x02678B94: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
        // 0x02678B98: LDR x8, [x8, #0xb88]       | X8 = (string**)(1152921509952197360)("selColor");
        // 0x02678B9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678BA0: MOV x0, x21                | X0 = this.selectiveCcMaterial;//m1      
        // 0x02678BA4: MOV v0.16b, v8.16b         | V0 = this.selectiveFromColor;//m1       
        // 0x02678BA8: LDR x1, [x8]               | X1 = "selColor";                        
        // 0x02678BAC: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x02678BB0: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x02678BB4: MOV v3.16b, v11.16b        | V3 = V11.16B;//m1                       
        // 0x02678BB8: BL #0x1a77f5c              | this.selectiveCcMaterial.SetColor(name:  "selColor", value:  new UnityEngine.Color() {r = this.selectiveFromColor, g = V9.16B, b = V10.16B, a = V11.16B});
        this.selectiveCcMaterial.SetColor(name:  "selColor", value:  new UnityEngine.Color() {r = this.selectiveFromColor, g = V9.16B, b = V10.16B, a = V11.16B});
        // 0x02678BBC: LDR x21, [x20, #0x70]      | X21 = this.selectiveCcMaterial; //P2    
        // 0x02678BC0: LDP s8, s9, [x20, #0xa8]   | S8 = this.selectiveToColor; //P2         //  | 
        // 0x02678BC4: LDP s10, s11, [x20, #0xb0] |                                          //  | 
        // 0x02678BC8: CBNZ x21, #0x2678bd0       | if (this.selectiveCcMaterial != null) goto label_23;
        if(this.selectiveCcMaterial != null)
        {
            goto label_23;
        }
        // 0x02678BCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.selectiveCcMaterial, ????);
        label_23:
        // 0x02678BD0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x02678BD4: LDR x8, [x8, #0x9d8]       | X8 = (string**)(1152921509952201552)("targetColor");
        // 0x02678BD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678BDC: MOV x0, x21                | X0 = this.selectiveCcMaterial;//m1      
        // 0x02678BE0: MOV v0.16b, v8.16b         | V0 = this.selectiveToColor;//m1         
        // 0x02678BE4: LDR x1, [x8]               | X1 = "targetColor";                     
        // 0x02678BE8: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x02678BEC: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x02678BF0: MOV v3.16b, v11.16b        | V3 = V11.16B;//m1                       
        // 0x02678BF4: BL #0x1a77f5c              | this.selectiveCcMaterial.SetColor(name:  "targetColor", value:  new UnityEngine.Color() {r = this.selectiveToColor, g = V9.16B, b = V10.16B, a = V11.16B});
        this.selectiveCcMaterial.SetColor(name:  "targetColor", value:  new UnityEngine.Color() {r = this.selectiveToColor, g = V9.16B, b = V10.16B, a = V11.16B});
        // 0x02678BF8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02678BFC: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02678C00: LDR x20, [x20, #0x70]      | X20 = this.selectiveCcMaterial; //P2    
        // 0x02678C04: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02678C08: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02678C0C: TBZ w8, #0, #0x2678c1c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x02678C10: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02678C14: CBNZ w8, #0x2678c1c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x02678C18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_25:
        // 0x02678C1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678C20: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02678C24: MOV x1, x22                | X1 = val_4;//m1                         
        // 0x02678C28: MOV x2, x19                | X2 = destination;//m1                   
        // 0x02678C2C: MOV x3, x20                | X3 = this.selectiveCcMaterial;//m1      
        // 0x02678C30: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_7, mat:  destination);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_7, mat:  destination);
        // 0x02678C34: MOV x1, x22                | X1 = val_4;//m1                         
        // 0x02678C38: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x02678C3C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x02678C40: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x02678C44: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x02678C48: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x02678C4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678C50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678C54: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x02678C58: B #0x1b892ac               | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0); return;
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        return;
        label_21:
        // 0x02678C5C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x02678C60: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x02678C64: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x02678C68: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x02678C6C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x02678C70: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x02678C74: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02678C78 (40340600), len: 4  VirtAddr: 0x02678C78 RVA: 0x02678C78 token: 100663349 methodIndex: 24433 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x02678C78: RET                        |  return;                                
        return;
    
    }

}
