using UnityEngine;

namespace Mihua.Asset
{
    public static class AssetCollect
    {
        // Fields
        public static System.Collections.Generic.List<string> uiNeedList; // static_offset: 0x00000000
        private static System.Collections.Generic.List<string> nextList; // static_offset: 0x00000008
        private static System.Collections.Generic.List<int> summonList; // static_offset: 0x00000010
        private static string AssetsJArray; // static_offset: 0x00000018
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AB0EF4 (11210484), len: 132  VirtAddr: 0x00AB0EF4 RVA: 0x00AB0EF4 token: 100693129 methodIndex: 46951 delegateWrapperIndex: 0 methodInvoker: 0
        public static void AddUIAssets(string assetPath)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB0EF4: STP x20, x19, [sp, #-0x20]! | stack[1152921514943357456] = ???;  stack[1152921514943357464] = ???;  //  dest_result_addr=1152921514943357456 |  dest_result_addr=1152921514943357464
            // 0x00AB0EF8: STP x29, x30, [sp, #0x10]  | stack[1152921514943357472] = ???;  stack[1152921514943357480] = ???;  //  dest_result_addr=1152921514943357472 |  dest_result_addr=1152921514943357480
            // 0x00AB0EFC: ADD x29, sp, #0x10         | X29 = (1152921514943357456 + 16) = 1152921514943357472 (0x10000002681AA220);
            // 0x00AB0F00: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB0F04: LDRB w8, [x20, #0x3e5]     | W8 = (bool)static_value_037333E5;       
            // 0x00AB0F08: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB0F0C: TBNZ w8, #0, #0xab0f28     | if (static_value_037333E5 == true) goto label_0;
            // 0x00AB0F10: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
            // 0x00AB0F14: LDR x8, [x8, #0x870]       | X8 = 0x2B8EAAC;                         
            // 0x00AB0F18: LDR w0, [x8]               | W0 = 0x116B;                            
            // 0x00AB0F1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x116B, ????);     
            // 0x00AB0F20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB0F24: STRB w8, [x20, #0x3e5]     | static_value_037333E5 = true;            //  dest_result_addr=57881573
            label_0:
            // 0x00AB0F28: ADRP x20, #0x35de000       | X20 = 56483840 (0x35DE000);             
            // 0x00AB0F2C: LDR x20, [x20, #0xc20]     | X20 = 1152921504902639616;              
            // 0x00AB0F30: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            val_1 = null;
            // 0x00AB0F34: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_10A;
            // 0x00AB0F38: TBZ w9, #0, #0xab0f50      | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB0F3C: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished;
            // 0x00AB0F40: CBNZ w9, #0xab0f50         | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB0F44: MOV x0, x8                 | X0 = 1152921504902639616 (0x1000000011A17000);//ML01
            // 0x00AB0F48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetCollect), ????);
            // 0x00AB0F4C: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            val_1 = null;
            label_2:
            // 0x00AB0F50: ADRP x9, #0x3633000        | X9 = 56832000 (0x3633000);              
            // 0x00AB0F54: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB0F58: LDR x9, [x9, #0xae0]       | X9 = 1152921514943344464;               
            // 0x00AB0F5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB0F60: MOV x2, x19                | X2 = X1;//m1                            
            // 0x00AB0F64: LDR x1, [x8]               | X1 = Mihua.Asset.AssetCollect.uiNeedList;
            // 0x00AB0F68: LDR x3, [x9]               | X3 = public static System.Void EList::Add<System.String>(System.Collections.Generic.List<T> list, System.String item);
            // 0x00AB0F6C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB0F70: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB0F74: B #0x10cf778               | EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetCollect.uiNeedList); return;
            EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetCollect.uiNeedList);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB0F78 (11210616), len: 132  VirtAddr: 0x00AB0F78 RVA: 0x00AB0F78 token: 100693130 methodIndex: 46952 delegateWrapperIndex: 0 methodInvoker: 0
        public static void AddAssets(string assetPath)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB0F78: STP x20, x19, [sp, #-0x20]! | stack[1152921514943477648] = ???;  stack[1152921514943477656] = ???;  //  dest_result_addr=1152921514943477648 |  dest_result_addr=1152921514943477656
            // 0x00AB0F7C: STP x29, x30, [sp, #0x10]  | stack[1152921514943477664] = ???;  stack[1152921514943477672] = ???;  //  dest_result_addr=1152921514943477664 |  dest_result_addr=1152921514943477672
            // 0x00AB0F80: ADD x29, sp, #0x10         | X29 = (1152921514943477648 + 16) = 1152921514943477664 (0x10000002681C77A0);
            // 0x00AB0F84: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB0F88: LDRB w8, [x20, #0x3e6]     | W8 = (bool)static_value_037333E6;       
            // 0x00AB0F8C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB0F90: TBNZ w8, #0, #0xab0fac     | if (static_value_037333E6 == true) goto label_0;
            // 0x00AB0F94: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00AB0F98: LDR x8, [x8, #0xc20]       | X8 = 0x2B8EAA4;                         
            // 0x00AB0F9C: LDR w0, [x8]               | W0 = 0x1169;                            
            // 0x00AB0FA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1169, ????);     
            // 0x00AB0FA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB0FA8: STRB w8, [x20, #0x3e6]     | static_value_037333E6 = true;            //  dest_result_addr=57881574
            label_0:
            // 0x00AB0FAC: ADRP x20, #0x35de000       | X20 = 56483840 (0x35DE000);             
            // 0x00AB0FB0: LDR x20, [x20, #0xc20]     | X20 = 1152921504902639616;              
            // 0x00AB0FB4: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            val_1 = null;
            // 0x00AB0FB8: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_10A;
            // 0x00AB0FBC: TBZ w9, #0, #0xab0fd4      | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB0FC0: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished;
            // 0x00AB0FC4: CBNZ w9, #0xab0fd4         | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB0FC8: MOV x0, x8                 | X0 = 1152921504902639616 (0x1000000011A17000);//ML01
            // 0x00AB0FCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetCollect), ????);
            // 0x00AB0FD0: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            val_1 = null;
            label_2:
            // 0x00AB0FD4: ADRP x9, #0x3633000        | X9 = 56832000 (0x3633000);              
            // 0x00AB0FD8: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB0FDC: LDR x9, [x9, #0xae0]       | X9 = 1152921514943344464;               
            // 0x00AB0FE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB0FE4: MOV x2, x19                | X2 = X1;//m1                            
            // 0x00AB0FE8: LDR x1, [x8, #8]           | X1 = Mihua.Asset.AssetCollect.nextList; 
            // 0x00AB0FEC: LDR x3, [x9]               | X3 = public static System.Void EList::Add<System.String>(System.Collections.Generic.List<T> list, System.String item);
            // 0x00AB0FF0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB0FF4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB0FF8: B #0x10cf778               | EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetCollect.nextList); return;
            EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetCollect.nextList);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB0FFC (11210748), len: 560  VirtAddr: 0x00AB0FFC RVA: 0x00AB0FFC token: 100693131 methodIndex: 46953 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.List<string> AllAssets(checkpointCfg checkPoint)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x00AB0FFC: STP x24, x23, [sp, #-0x40]! | stack[1152921514943602000] = ???;  stack[1152921514943602008] = ???;  //  dest_result_addr=1152921514943602000 |  dest_result_addr=1152921514943602008
            // 0x00AB1000: STP x22, x21, [sp, #0x10]  | stack[1152921514943602016] = ???;  stack[1152921514943602024] = ???;  //  dest_result_addr=1152921514943602016 |  dest_result_addr=1152921514943602024
            // 0x00AB1004: STP x20, x19, [sp, #0x20]  | stack[1152921514943602032] = ???;  stack[1152921514943602040] = ???;  //  dest_result_addr=1152921514943602032 |  dest_result_addr=1152921514943602040
            // 0x00AB1008: STP x29, x30, [sp, #0x30]  | stack[1152921514943602048] = ???;  stack[1152921514943602056] = ???;  //  dest_result_addr=1152921514943602048 |  dest_result_addr=1152921514943602056
            // 0x00AB100C: ADD x29, sp, #0x30         | X29 = (1152921514943602000 + 48) = 1152921514943602048 (0x10000002681E5D80);
            // 0x00AB1010: SUB sp, sp, #0x10          | SP = (1152921514943602000 - 16) = 1152921514943601984 (0x10000002681E5D40);
            // 0x00AB1014: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB1018: LDRB w8, [x19, #0x3e7]     | W8 = (bool)static_value_037333E7;       
            // 0x00AB101C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00AB1020: TBNZ w8, #0, #0xab103c     | if (static_value_037333E7 == true) goto label_0;
            // 0x00AB1024: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x00AB1028: LDR x8, [x8, #0x978]       | X8 = 0x2B8EAB0;                         
            // 0x00AB102C: LDR w0, [x8]               | W0 = 0x116C;                            
            // 0x00AB1030: BL #0x2782188              | X0 = sub_2782188( ?? 0x116C, ????);     
            // 0x00AB1034: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB1038: STRB w8, [x19, #0x3e7]     | static_value_037333E7 = true;            //  dest_result_addr=57881575
            label_0:
            // 0x00AB103C: ADRP x22, #0x35de000       | X22 = 56483840 (0x35DE000);             
            // 0x00AB1040: LDR x22, [x22, #0xc20]     | X22 = 1152921504902639616;              
            // 0x00AB1044: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetCollect);  
            val_2 = null;
            // 0x00AB1048: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_10A;
            // 0x00AB104C: TBZ w8, #0, #0xab1060      | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB1050: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished;
            // 0x00AB1054: CBNZ w8, #0xab1060         | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB1058: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetCollect), ????);
            // 0x00AB105C: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetCollect);  
            val_2 = null;
            label_2:
            // 0x00AB1060: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB1064: LDR x19, [x8]              | X19 = Mihua.Asset.AssetCollect.uiNeedList;
            // 0x00AB1068: CBNZ x19, #0xab1070        | if (Mihua.Asset.AssetCollect.uiNeedList != null) goto label_3;
            if(Mihua.Asset.AssetCollect.uiNeedList != null)
            {
                goto label_3;
            }
            // 0x00AB106C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetCollect), ????);
            label_3:
            // 0x00AB1070: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00AB1074: LDR x8, [x8, #0xca8]       | X8 = 1152921510890633680;               
            // 0x00AB1078: MOV x0, x19                | X0 = Mihua.Asset.AssetCollect.uiNeedList;//m1
            // 0x00AB107C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB1080: BL #0x25ead28              | Mihua.Asset.AssetCollect.uiNeedList.Clear();
            Mihua.Asset.AssetCollect.uiNeedList.Clear();
            // 0x00AB1084: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x00AB1088: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x00AB108C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_1 = null;
            // 0x00AB1090: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB1094: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00AB1098: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x00AB109C: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB10A0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB10A4: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<System.String>();
            // 0x00AB10A8: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            // 0x00AB10AC: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB10B0: LDR x21, [x8, #0x10]       | X21 = Mihua.Asset.AssetCollect.summonList;
            // 0x00AB10B4: CBNZ x21, #0xab10bc        | if (Mihua.Asset.AssetCollect.summonList != null) goto label_4;
            if(Mihua.Asset.AssetCollect.summonList != null)
            {
                goto label_4;
            }
            // 0x00AB10B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_4:
            // 0x00AB10BC: ADRP x23, #0x35ff000       | X23 = 56619008 (0x35FF000);             
            // 0x00AB10C0: LDR x23, [x23, #0x748]     | X23 = 1152921510876940848;              
            // 0x00AB10C4: MOV x0, x21                | X0 = Mihua.Asset.AssetCollect.summonList;//m1
            // 0x00AB10C8: LDR x1, [x23]              | X1 = public System.Void System.Collections.Generic.List<System.Int32>::Clear();
            // 0x00AB10CC: BL #0x25e23dc              | Mihua.Asset.AssetCollect.summonList.Clear();
            Mihua.Asset.AssetCollect.summonList.Clear();
            // 0x00AB10D0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AB10D4: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AB10D8: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00AB10DC: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB10E0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB10E4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AB10E8: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB10EC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB10F0: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB10F4: CBNZ x20, #0xab10fc        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00AB10F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_5:
            // 0x00AB10FC: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00AB1100: LDR w8, [x20, #0x10]       | W8 = X1 + 16;                           
            // 0x00AB1104: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00AB1108: ADD x1, sp, #0xc           | X1 = (1152921514943601984 + 12) = 1152921514943601996 (0x10000002681E5D4C);
            // 0x00AB110C: STR w8, [sp, #0xc]         | stack[1152921514943601996] = X1 + 16;    //  dest_result_addr=1152921514943601996
            // 0x00AB1110: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00AB1114: BL #0x27bc028              | X0 = 1152921514943650160 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 16);
            // 0x00AB1118: MOV x20, x0                | X20 = 1152921514943650160 (0x10000002681F1970);//ML01
            // 0x00AB111C: CBNZ x21, #0xab1124        | if ( != null) goto label_6;             
            if(null != null)
            {
                goto label_6;
            }
            // 0x00AB1120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 16, ????);    
            label_6:
            // 0x00AB1124: CBZ x20, #0xab1148         | if (X1 + 16 == 0) goto label_8;         
            if((X1 + 16) == 0)
            {
                goto label_8;
            }
            // 0x00AB1128: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AB112C: MOV x0, x20                | X0 = 1152921514943650160 (0x10000002681F1970);//ML01
            // 0x00AB1130: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB1134: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1 + 16, ????);    
            // 0x00AB1138: CBNZ x0, #0xab1148         | if (X1 + 16 != 0) goto label_8;         
            if((X1 + 16) != 0)
            {
                goto label_8;
            }
            // 0x00AB113C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1 + 16, ????);    
            // 0x00AB1140: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1144: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 16, ????);    
            label_8:
            // 0x00AB1148: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB114C: CBNZ w8, #0xab115c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_9;
            // 0x00AB1150: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 16, ????);    
            // 0x00AB1154: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1158: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 16, ????);    
            label_9:
            // 0x00AB115C: STR x20, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1 + 16; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
            typeof(System.Object[]).__il2cppRuntimeField_20 = X1 + 16;
            typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
            // 0x00AB1160: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x00AB1164: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x00AB1168: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
            // 0x00AB116C: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x00AB1170: TBZ w8, #0, #0xab1180      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00AB1174: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x00AB1178: CBNZ w8, #0xab1180         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00AB117C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_11:
            // 0x00AB1180: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x00AB1184: LDR x8, [x8, #0xed8]       | X8 = (string**)(1152921514943589968)("AssetCollect");
            // 0x00AB1188: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB118C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB1190: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB1194: LDR x1, [x8]               | X1 = "AssetCollect";                    
            // 0x00AB1198: BL #0xba5838               | CallJSApi.CallJsFun(funName:  0, args:  "AssetCollect");
            CallJSApi.CallJsFun(funName:  0, args:  "AssetCollect");
            // 0x00AB119C: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            // 0x00AB11A0: MOV x2, x19                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB11A4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB11A8: LDR x1, [x8, #0x18]        | X1 = Mihua.Asset.AssetCollect.AssetsJArray;
            // 0x00AB11AC: BL #0xab122c               | Mihua.Asset.AssetCollect.AnalysisAseets(arr:  0, list:  Mihua.Asset.AssetCollect.AssetsJArray);
            Mihua.Asset.AssetCollect.AnalysisAseets(arr:  0, list:  Mihua.Asset.AssetCollect.AssetsJArray);
            // 0x00AB11B0: MOV x1, x19                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB11B4: BL #0xab1378               | Mihua.Asset.AssetCollect.NextAssets(list:  0);
            Mihua.Asset.AssetCollect.NextAssets(list:  0);
            // 0x00AB11B8: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            // 0x00AB11BC: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB11C0: LDR x20, [x8, #0x10]       | X20 = Mihua.Asset.AssetCollect.summonList;
            // 0x00AB11C4: CBNZ x20, #0xab11cc        | if (Mihua.Asset.AssetCollect.summonList != null) goto label_12;
            if(Mihua.Asset.AssetCollect.summonList != null)
            {
                goto label_12;
            }
            // 0x00AB11C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_12:
            // 0x00AB11CC: LDR x1, [x23]              | X1 = public System.Void System.Collections.Generic.List<System.Int32>::Clear();
            // 0x00AB11D0: MOV x0, x20                | X0 = Mihua.Asset.AssetCollect.summonList;//m1
            // 0x00AB11D4: BL #0x25e23dc              | Mihua.Asset.AssetCollect.summonList.Clear();
            Mihua.Asset.AssetCollect.summonList.Clear();
            // 0x00AB11D8: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
            // 0x00AB11DC: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
            // 0x00AB11E0: LDR x0, [x20]              | X0 = typeof(System.String);             
            val_3 = null;
            // 0x00AB11E4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB11E8: TBZ w8, #0, #0xab11fc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00AB11EC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB11F0: CBNZ w8, #0xab11fc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00AB11F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00AB11F8: LDR x0, [x20]              | X0 = typeof(System.String);             
            val_3 = null;
            label_14:
            // 0x00AB11FC: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00AB1200: LDR x9, [x22]              | X9 = typeof(Mihua.Asset.AssetCollect);  
            // 0x00AB1204: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB1208: LDR x8, [x8]               | X8 = System.String.Empty;               
            // 0x00AB120C: LDR x9, [x9, #0xa0]        | X9 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB1210: STR x8, [x9, #0x18]        | Mihua.Asset.AssetCollect.AssetsJArray = System.String.Empty;  //  dest_result_addr=1152921504902643736
            Mihua.Asset.AssetCollect.AssetsJArray = System.String.Empty;
            // 0x00AB1214: SUB sp, x29, #0x30         | SP = (1152921514943602048 - 48) = 1152921514943602000 (0x10000002681E5D50);
            // 0x00AB1218: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB121C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB1220: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB1224: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AB1228: RET                        |  return (System.Collections.Generic.List<System.String>)typeof(System.Collections.Generic.List<T>);
            return (System.Collections.Generic.List<System.String>)val_1;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<System.String>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB122C (11211308), len: 332  VirtAddr: 0x00AB122C RVA: 0x00AB122C token: 100693132 methodIndex: 46954 delegateWrapperIndex: 0 methodInvoker: 0
        private static void AnalysisAseets(string arr, System.Collections.Generic.List<string> list)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x00AB122C: STP x24, x23, [sp, #-0x40]! | stack[1152921514943738576] = ???;  stack[1152921514943738584] = ???;  //  dest_result_addr=1152921514943738576 |  dest_result_addr=1152921514943738584
            // 0x00AB1230: STP x22, x21, [sp, #0x10]  | stack[1152921514943738592] = ???;  stack[1152921514943738600] = ???;  //  dest_result_addr=1152921514943738592 |  dest_result_addr=1152921514943738600
            // 0x00AB1234: STP x20, x19, [sp, #0x20]  | stack[1152921514943738608] = ???;  stack[1152921514943738616] = ???;  //  dest_result_addr=1152921514943738608 |  dest_result_addr=1152921514943738616
            // 0x00AB1238: STP x29, x30, [sp, #0x30]  | stack[1152921514943738624] = ???;  stack[1152921514943738632] = ???;  //  dest_result_addr=1152921514943738624 |  dest_result_addr=1152921514943738632
            // 0x00AB123C: ADD x29, sp, #0x30         | X29 = (1152921514943738576 + 48) = 1152921514943738624 (0x1000000268207300);
            // 0x00AB1240: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AB1244: LDRB w8, [x21, #0x3e8]     | W8 = (bool)static_value_037333E8;       
            // 0x00AB1248: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00AB124C: MOV x20, x1                | X20 = list;//m1                         
            // 0x00AB1250: TBNZ w8, #0, #0xab126c     | if (static_value_037333E8 == true) goto label_0;
            // 0x00AB1254: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00AB1258: LDR x8, [x8, #0x78]        | X8 = 0x2B8EAB4;                         
            // 0x00AB125C: LDR w0, [x8]               | W0 = 0x116D;                            
            // 0x00AB1260: BL #0x2782188              | X0 = sub_2782188( ?? 0x116D, ????);     
            // 0x00AB1264: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB1268: STRB w8, [x21, #0x3e8]     | static_value_037333E8 = true;            //  dest_result_addr=57881576
            label_0:
            // 0x00AB126C: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x00AB1270: LDR x8, [x8, #0x9c8]       | X8 = 1152921504859615232;               
            // 0x00AB1274: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonConvert);
            // 0x00AB1278: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_10A;
            // 0x00AB127C: TBZ w8, #0, #0xab128c      | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB1280: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished;
            // 0x00AB1284: CBNZ w8, #0xab128c         | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB1288: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.JsonConvert), ????);
            label_2:
            // 0x00AB128C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB1290: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB1294: MOV x1, x20                | X1 = list;//m1                          
            // 0x00AB1298: BL #0x1311974              | X0 = Newtonsoft.Json.JsonConvert.DeserializeObject(value:  0);
            object val_1 = Newtonsoft.Json.JsonConvert.DeserializeObject(value:  0);
            // 0x00AB129C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x00AB12A0: CBZ x0, #0xab12e0          | if (val_1 == null) goto label_5;        
            if(val_1 == null)
            {
                goto label_5;
            }
            // 0x00AB12A4: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AB12A8: LDR x8, [x8, #0x48]        | X8 = 1152921504860946432;               
            // 0x00AB12AC: LDR x9, [x0]               | X9 = typeof(System.Object);             
            // 0x00AB12B0: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Linq.JArray);
            // 0x00AB12B4: LDRB w11, [x9, #0x104]     | W11 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AB12B8: LDRB w10, [x8, #0x104]     | W10 = Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AB12BC: CMP w11, w10               | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AB12C0: B.HS #0xab12cc             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth >= Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00AB12C4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x00AB12C8: B #0xab12e0                |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x00AB12CC: LDR x9, [x9, #0xb0]        | X9 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00AB12D0: ADD x9, x9, x10, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntim
            // 0x00AB12D4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AB12D8: CMP x9, x8                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Linq.JArray))
            // 0x00AB12DC: CSEL x20, x0, xzr, eq      | X20 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_1 : 0;
            var val_2 = (((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (val_1) : 0;
            label_5:
            // 0x00AB12E0: ADRP x23, #0x35e6000       | X23 = 56516608 (0x35E6000);             
            // 0x00AB12E4: LDR x23, [x23, #0x500]     | X23 = 1152921510890816336;              
            // 0x00AB12E8: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00AB12EC: B #0xab1304                |  goto label_6;                          
            goto label_6;
            label_12:
            // 0x00AB12F0: LDR x2, [x23]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB12F4: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00AB12F8: MOV x1, x22                | X1 = X22;//m1                           
            // 0x00AB12FC: BL #0x25ea480              | X2.Add(item:  X22);                     
            X2.Add(item:  X22);
            // 0x00AB1300: ADD w21, w21, #1           | W21 = (val_6 + 1) = val_6 (0x00000001); 
            val_6 = 1;
            label_6:
            // 0x00AB1304: CBNZ x20, #0xab130c        | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_1 : 0 != 0) goto label_7;
            // 0x00AB1308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_7:
            // 0x00AB130C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1310: MOV x0, x20                | X0 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_1 : 0;//m1
            // 0x00AB1314: BL #0x132a574              | X0 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_1 : 0.get_Count();
            int val_3 = val_2.Count;
            // 0x00AB1318: CMP w21, w0                | STATE = COMPARE(0x1, val_3)             
            // 0x00AB131C: B.GE #0xab1364             | if (val_6 >= val_3) goto label_8;       
            if(val_6 >= val_3)
            {
                goto label_8;
            }
            // 0x00AB1320: CBNZ x20, #0xab1328        | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_1 : 0 != 0) goto label_9;
            // 0x00AB1324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x00AB1328: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB132C: MOV x0, x20                | X0 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_1 : 0;//m1
            // 0x00AB1330: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
            // 0x00AB1334: BL #0x1327740              | X0 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_1 : 0.get_Item(index:  1);
            Newtonsoft.Json.Linq.JToken val_4 = val_2.Item[1];
            // 0x00AB1338: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00AB133C: CBNZ x22, #0xab1344        | if (val_4 != null) goto label_10;       
            if(val_4 != null)
            {
                goto label_10;
            }
            // 0x00AB1340: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_10:
            // 0x00AB1344: LDR x8, [x22]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
            // 0x00AB1348: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x00AB134C: LDP x9, x1, [x8, #0x140]   | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_140; X1 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_148; //  | 
            // 0x00AB1350: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_140();
            // 0x00AB1354: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00AB1358: CBNZ x19, #0xab12f0        | if (X2 != 0) goto label_12;             
            if(X2 != 0)
            {
                goto label_12;
            }
            // 0x00AB135C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00AB1360: B #0xab12f0                |  goto label_12;                         
            goto label_12;
            label_8:
            // 0x00AB1364: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB1368: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB136C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB1370: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AB1374: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB14D8 (11211992), len: 108  VirtAddr: 0x00AB14D8 RVA: 0x00AB14D8 token: 100693133 methodIndex: 46955 delegateWrapperIndex: 0 methodInvoker: 0
        public static void AddAssetsByJArray(string arr)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB14D8: STP x20, x19, [sp, #-0x20]! | stack[1152921514943871088] = ???;  stack[1152921514943871096] = ???;  //  dest_result_addr=1152921514943871088 |  dest_result_addr=1152921514943871096
            // 0x00AB14DC: STP x29, x30, [sp, #0x10]  | stack[1152921514943871104] = ???;  stack[1152921514943871112] = ???;  //  dest_result_addr=1152921514943871104 |  dest_result_addr=1152921514943871112
            // 0x00AB14E0: ADD x29, sp, #0x10         | X29 = (1152921514943871088 + 16) = 1152921514943871104 (0x1000000268227880);
            // 0x00AB14E4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB14E8: LDRB w8, [x20, #0x3e9]     | W8 = (bool)static_value_037333E9;       
            // 0x00AB14EC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB14F0: TBNZ w8, #0, #0xab150c     | if (static_value_037333E9 == true) goto label_0;
            // 0x00AB14F4: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00AB14F8: LDR x8, [x8, #0x230]       | X8 = 0x2B8EAA8;                         
            // 0x00AB14FC: LDR w0, [x8]               | W0 = 0x116A;                            
            // 0x00AB1500: BL #0x2782188              | X0 = sub_2782188( ?? 0x116A, ????);     
            // 0x00AB1504: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB1508: STRB w8, [x20, #0x3e9]     | static_value_037333E9 = true;            //  dest_result_addr=57881577
            label_0:
            // 0x00AB150C: ADRP x20, #0x35de000       | X20 = 56483840 (0x35DE000);             
            // 0x00AB1510: LDR x20, [x20, #0xc20]     | X20 = 1152921504902639616;              
            // 0x00AB1514: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetCollect);  
            val_1 = null;
            // 0x00AB1518: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_10A;
            // 0x00AB151C: TBZ w8, #0, #0xab1530      | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB1520: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished;
            // 0x00AB1524: CBNZ w8, #0xab1530         | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB1528: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetCollect), ????);
            // 0x00AB152C: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetCollect);  
            val_1 = null;
            label_2:
            // 0x00AB1530: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB1534: STR x19, [x8, #0x18]       | Mihua.Asset.AssetCollect.AssetsJArray = X1;  //  dest_result_addr=1152921504902643736
            Mihua.Asset.AssetCollect.AssetsJArray = X1;
            // 0x00AB1538: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB153C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB1540: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB1544 (11212100), len: 1864  VirtAddr: 0x00AB1544 RVA: 0x00AB1544 token: 100693134 methodIndex: 46956 delegateWrapperIndex: 0 methodInvoker: 0
        public static string NpcAseetsCs(int mapID)
        {
            //
            // Disasemble & Code
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            // 0x00AB1544: STP x28, x27, [sp, #-0x60]! | stack[1152921514944093872] = ???;  stack[1152921514944093880] = ???;  //  dest_result_addr=1152921514944093872 |  dest_result_addr=1152921514944093880
            // 0x00AB1548: STP x26, x25, [sp, #0x10]  | stack[1152921514944093888] = ???;  stack[1152921514944093896] = ???;  //  dest_result_addr=1152921514944093888 |  dest_result_addr=1152921514944093896
            // 0x00AB154C: STP x24, x23, [sp, #0x20]  | stack[1152921514944093904] = ???;  stack[1152921514944093912] = ???;  //  dest_result_addr=1152921514944093904 |  dest_result_addr=1152921514944093912
            // 0x00AB1550: STP x22, x21, [sp, #0x30]  | stack[1152921514944093920] = ???;  stack[1152921514944093928] = ???;  //  dest_result_addr=1152921514944093920 |  dest_result_addr=1152921514944093928
            // 0x00AB1554: STP x20, x19, [sp, #0x40]  | stack[1152921514944093936] = ???;  stack[1152921514944093944] = ???;  //  dest_result_addr=1152921514944093936 |  dest_result_addr=1152921514944093944
            // 0x00AB1558: STP x29, x30, [sp, #0x50]  | stack[1152921514944093952] = ???;  stack[1152921514944093960] = ???;  //  dest_result_addr=1152921514944093952 |  dest_result_addr=1152921514944093960
            // 0x00AB155C: ADD x29, sp, #0x50         | X29 = (1152921514944093872 + 80) = 1152921514944093952 (0x100000026825DF00);
            // 0x00AB1560: SUB sp, sp, #0x10          | SP = (1152921514944093872 - 16) = 1152921514944093856 (0x100000026825DEA0);
            // 0x00AB1564: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB1568: LDRB w8, [x20, #0x3ea]     | W8 = (bool)static_value_037333EA;       
            // 0x00AB156C: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00AB1570: TBNZ w8, #0, #0xab158c     | if (static_value_037333EA == true) goto label_0;
            // 0x00AB1574: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x00AB1578: LDR x8, [x8, #0xb38]       | X8 = 0x2B8EABC;                         
            // 0x00AB157C: LDR w0, [x8]               | W0 = 0x116F;                            
            // 0x00AB1580: BL #0x2782188              | X0 = sub_2782188( ?? 0x116F, ????);     
            // 0x00AB1584: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB1588: STRB w8, [x20, #0x3ea]     | static_value_037333EA = true;            //  dest_result_addr=57881578
            label_0:
            // 0x00AB158C: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00AB1590: LDR x8, [x8, #0x50]        | X8 = 1152921504891510784;               
            // 0x00AB1594: LDR x0, [x8]               | X0 = typeof(LevelConfigManager);        
            // 0x00AB1598: LDRB w8, [x0, #0x10a]      | W8 = LevelConfigManager.__il2cppRuntimeField_10A;
            // 0x00AB159C: TBZ w8, #0, #0xab15ac      | if (LevelConfigManager.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB15A0: LDR w8, [x0, #0xbc]        | W8 = LevelConfigManager.__il2cppRuntimeField_cctor_finished;
            // 0x00AB15A4: CBNZ w8, #0xab15ac         | if (LevelConfigManager.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB15A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(LevelConfigManager), ????);
            label_2:
            // 0x00AB15AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB15B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB15B4: BL #0xda0c5c               | X0 = LevelConfigManager.get_instance(); 
            LevelConfigManager val_1 = LevelConfigManager.instance;
            // 0x00AB15B8: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00AB15BC: CBNZ x20, #0xab15c4        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00AB15C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00AB15C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB15C8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00AB15CC: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00AB15D0: BL #0xda10c4               | X0 = val_1.GetLevelConfigByID(level:  W1);
            JSCLevelConfig val_2 = val_1.GetLevelConfigByID(level:  W1);
            // 0x00AB15D4: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00AB15D8: LDR x8, [x8, #0x5f0]       | X8 = 1152921504861265920;               
            // 0x00AB15DC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00AB15E0: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00AB15E4: MOV x0, x8                 | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
            Newtonsoft.Json.Linq.JObject val_3 = null;
            // 0x00AB15E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Linq.JObject), ????);
            // 0x00AB15EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB15F0: MOV x19, x0                | X19 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00AB15F4: BL #0x2924c68              | .ctor();                                
            val_3 = new Newtonsoft.Json.Linq.JObject();
            // 0x00AB15F8: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AB15FC: LDR x8, [x8, #0x48]        | X8 = 1152921504860946432;               
            // 0x00AB1600: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Linq.JArray);
            Newtonsoft.Json.Linq.JArray val_4 = null;
            // 0x00AB1604: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            // 0x00AB1608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB160C: MOV x21, x0                | X21 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1610: BL #0x1326264              | .ctor();                                
            val_4 = new Newtonsoft.Json.Linq.JArray();
            // 0x00AB1614: CBNZ x19, #0xab161c        | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x00AB1618: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_4:
            // 0x00AB161C: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x00AB1620: LDR x8, [x8, #0x5e0]       | X8 = (string**)(1152921514550753968)("monsters");
            // 0x00AB1624: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB1628: MOV x0, x19                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00AB162C: MOV x2, x21                | X2 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1630: LDR x1, [x8]               | X1 = "monsters";                        
            // 0x00AB1634: STR x19, [sp, #8]          | stack[1152921514944093864] = typeof(Newtonsoft.Json.Linq.JObject);  //  dest_result_addr=1152921514944093864
            // 0x00AB1638: BL #0x2926f6c              | Add(propertyName:  "monsters", value:  val_4);
            Add(propertyName:  "monsters", value:  val_4);
            // 0x00AB163C: CBNZ x20, #0xab1644        | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x00AB1640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JObject), ????);
            label_5:
            // 0x00AB1644: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1648: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00AB164C: BL #0xd9e920               | X0 = val_2.get_monsters();              
            System.Collections.Generic.List<JSCWaveNpcConfig> val_5 = val_2.monsters;
            // 0x00AB1650: ADRP x27, #0x364b000       | X27 = 56930304 (0x364B000);             
            // 0x00AB1654: ADRP x19, #0x3623000       | X19 = 56766464 (0x3623000);             
            // 0x00AB1658: ADRP x28, #0x35e6000       | X28 = 56516608 (0x35E6000);             
            // 0x00AB165C: LDR x27, [x27, #0x118]     | X27 = 1152921514565929872;              
            // 0x00AB1660: LDR x19, [x19, #0x750]     | X19 = 1152921514565792272;              
            // 0x00AB1664: LDR x28, [x28, #0xf18]     | X28 = 1152921514565389712;              
            // 0x00AB1668: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00AB166C: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_47 = 0;
            // 0x00AB1670: B #0xab1678                |  goto label_6;                          
            goto label_6;
            label_13:
            // 0x00AB1674: ADD w23, w23, #1           | W23 = (val_47 + 1) = val_47 (0x00000001);
            val_47 = 1;
            label_6:
            // 0x00AB1678: CBNZ x22, #0xab1680        | if (val_5 != null) goto label_7;        
            if(val_5 != null)
            {
                goto label_7;
            }
            // 0x00AB167C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_7:
            // 0x00AB1680: LDR x1, [x27]              | X1 = public System.Int32 System.Collections.Generic.List<JSCWaveNpcConfig>::get_Count();
            // 0x00AB1684: MOV x0, x22                | X0 = val_5;//m1                         
            // 0x00AB1688: BL #0x25ed72c              | X0 = val_5.get_Count();                 
            int val_6 = val_5.Count;
            // 0x00AB168C: CMP w23, w0                | STATE = COMPARE(0x1, val_6)             
            // 0x00AB1690: B.GE #0xab1758             | if (val_47 >= val_6) goto label_8;      
            if(val_47 >= val_6)
            {
                goto label_8;
            }
            // 0x00AB1694: CBNZ x22, #0xab169c        | if (val_5 != null) goto label_9;        
            if(val_5 != null)
            {
                goto label_9;
            }
            // 0x00AB1698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_9:
            // 0x00AB169C: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00AB16A0: LDR x8, [x8, #0x470]       | X8 = 1152921514565380496;               
            // 0x00AB16A4: MOV x0, x22                | X0 = val_5;//m1                         
            // 0x00AB16A8: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x00AB16AC: LDR x2, [x8]               | X2 = public JSCWaveNpcConfig System.Collections.Generic.List<JSCWaveNpcConfig>::get_Item(int index);
            // 0x00AB16B0: BL #0x25ed734              | X0 = val_5.get_Item(index:  1);         
            JSCWaveNpcConfig val_7 = val_5.Item[1];
            // 0x00AB16B4: MOV x24, x0                | X24 = val_7;//m1                        
            // 0x00AB16B8: CBNZ x24, #0xab16c0        | if (val_7 != null) goto label_10;       
            if(val_7 != null)
            {
                goto label_10;
            }
            // 0x00AB16BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_10:
            // 0x00AB16C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB16C4: MOV x0, x24                | X0 = val_7;//m1                         
            // 0x00AB16C8: BL #0xd9ede8               | X0 = val_7.get_wave();                  
            System.Collections.Generic.List<JSCLevelMonsterConfig> val_8 = val_7.wave;
            // 0x00AB16CC: MOV x24, x0                | X24 = val_8;//m1                        
            // 0x00AB16D0: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_48 = 0;
            // 0x00AB16D4: B #0xab16ec                |  goto label_11;                         
            goto label_11;
            label_17:
            // 0x00AB16D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB16DC: MOV x0, x21                | X0 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB16E0: MOV x1, x26                | X1 = X26;//m1                           
            // 0x00AB16E4: BL #0x1327830              | Add(item:  X26);                        
            Add(item:  X26);
            // 0x00AB16E8: ADD w25, w25, #1           | W25 = (val_48 + 1) = val_48 (0x00000001);
            val_48 = 1;
            label_11:
            // 0x00AB16EC: CBNZ x24, #0xab16f4        | if (val_8 != null) goto label_12;       
            if(val_8 != null)
            {
                goto label_12;
            }
            // 0x00AB16F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            label_12:
            // 0x00AB16F4: LDR x1, [x19]              | X1 = public System.Int32 System.Collections.Generic.List<JSCLevelMonsterConfig>::get_Count();
            // 0x00AB16F8: MOV x0, x24                | X0 = val_8;//m1                         
            // 0x00AB16FC: BL #0x25ed72c              | X0 = val_8.get_Count();                 
            int val_9 = val_8.Count;
            // 0x00AB1700: CMP w25, w0                | STATE = COMPARE(0x1, val_9)             
            // 0x00AB1704: B.GE #0xab1674             | if (val_48 >= val_9) goto label_13;     
            if(val_48 >= val_9)
            {
                goto label_13;
            }
            // 0x00AB1708: CBNZ x24, #0xab1710        | if (val_8 != null) goto label_14;       
            if(val_8 != null)
            {
                goto label_14;
            }
            // 0x00AB170C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x00AB1710: LDR x2, [x28]              | X2 = public JSCLevelMonsterConfig System.Collections.Generic.List<JSCLevelMonsterConfig>::get_Item(int index);
            // 0x00AB1714: MOV x0, x24                | X0 = val_8;//m1                         
            // 0x00AB1718: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
            // 0x00AB171C: BL #0x25ed734              | X0 = val_8.get_Item(index:  1);         
            JSCLevelMonsterConfig val_10 = val_8.Item[1];
            // 0x00AB1720: MOV x26, x0                | X26 = val_10;//m1                       
            // 0x00AB1724: CBNZ x26, #0xab172c        | if (val_10 != null) goto label_15;      
            if(val_10 != null)
            {
                goto label_15;
            }
            // 0x00AB1728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_15:
            // 0x00AB172C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1730: MOV x0, x26                | X0 = val_10;//m1                        
            // 0x00AB1734: BL #0xd9eab0               | X0 = val_10.get_id();                   
            int val_11 = val_10.id;
            // 0x00AB1738: MOV w1, w0                 | W1 = val_11;//m1                        
            // 0x00AB173C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB1740: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB1744: BL #0x292ff20              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            Newtonsoft.Json.Linq.JToken val_12 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            // 0x00AB1748: MOV x26, x0                | X26 = val_12;//m1                       
            // 0x00AB174C: CBNZ x21, #0xab16d8        | if ( != 0) goto label_17;               
            if(null != 0)
            {
                goto label_17;
            }
            // 0x00AB1750: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            // 0x00AB1754: B #0xab16d8                |  goto label_17;                         
            goto label_17;
            label_8:
            // 0x00AB1758: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AB175C: LDR x8, [x8, #0x48]        | X8 = 1152921504860946432;               
            // 0x00AB1760: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Linq.JArray);
            Newtonsoft.Json.Linq.JArray val_13 = null;
            // 0x00AB1764: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            // 0x00AB1768: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB176C: MOV x21, x0                | X21 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1770: BL #0x1326264              | .ctor();                                
            val_13 = new Newtonsoft.Json.Linq.JArray();
            // 0x00AB1774: LDR x22, [sp, #8]          | X22 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00AB1778: CBNZ x22, #0xab1780        | if ( != 0) goto label_18;               
            if(null != 0)
            {
                goto label_18;
            }
            // 0x00AB177C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_18:
            // 0x00AB1780: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB1784: LDR x8, [x8, #0x3f0]       | X8 = (string**)(1152921514944003888)("others");
            // 0x00AB1788: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB178C: MOV x0, x22                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00AB1790: MOV x2, x21                | X2 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1794: LDR x1, [x8]               | X1 = "others";                          
            // 0x00AB1798: BL #0x2926f6c              | Add(propertyName:  "others", value:  val_13);
            Add(propertyName:  "others", value:  val_13);
            // 0x00AB179C: CBNZ x20, #0xab17a4        | if (val_2 != null) goto label_19;       
            if(val_2 != null)
            {
                goto label_19;
            }
            // 0x00AB17A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JObject), ????);
            label_19:
            // 0x00AB17A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB17A8: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00AB17AC: BL #0xd9e928               | X0 = val_2.get_others();                
            System.Collections.Generic.List<JSCWaveNpcConfig> val_14 = val_2.others;
            // 0x00AB17B0: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x00AB17B4: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_49 = 0;
            // 0x00AB17B8: B #0xab17c0                |  goto label_20;                         
            goto label_20;
            label_27:
            // 0x00AB17BC: ADD w23, w23, #1           | W23 = (val_49 + 1) = val_49 (0x00000001);
            val_49 = 1;
            label_20:
            // 0x00AB17C0: CBNZ x22, #0xab17c8        | if (val_14 != null) goto label_21;      
            if(val_14 != null)
            {
                goto label_21;
            }
            // 0x00AB17C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_21:
            // 0x00AB17C8: LDR x1, [x27]              | X1 = public System.Int32 System.Collections.Generic.List<JSCWaveNpcConfig>::get_Count();
            // 0x00AB17CC: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x00AB17D0: BL #0x25ed72c              | X0 = val_14.get_Count();                
            int val_15 = val_14.Count;
            // 0x00AB17D4: CMP w23, w0                | STATE = COMPARE(0x1, val_15)            
            // 0x00AB17D8: B.GE #0xab18a0             | if (val_49 >= val_15) goto label_22;    
            if(val_49 >= val_15)
            {
                goto label_22;
            }
            // 0x00AB17DC: CBNZ x22, #0xab17e4        | if (val_14 != null) goto label_23;      
            if(val_14 != null)
            {
                goto label_23;
            }
            // 0x00AB17E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_23:
            // 0x00AB17E4: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00AB17E8: LDR x8, [x8, #0x470]       | X8 = 1152921514565380496;               
            // 0x00AB17EC: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x00AB17F0: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x00AB17F4: LDR x2, [x8]               | X2 = public JSCWaveNpcConfig System.Collections.Generic.List<JSCWaveNpcConfig>::get_Item(int index);
            // 0x00AB17F8: BL #0x25ed734              | X0 = val_14.get_Item(index:  1);        
            JSCWaveNpcConfig val_16 = val_14.Item[1];
            // 0x00AB17FC: MOV x24, x0                | X24 = val_16;//m1                       
            // 0x00AB1800: CBNZ x24, #0xab1808        | if (val_16 != null) goto label_24;      
            if(val_16 != null)
            {
                goto label_24;
            }
            // 0x00AB1804: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_24:
            // 0x00AB1808: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB180C: MOV x0, x24                | X0 = val_16;//m1                        
            // 0x00AB1810: BL #0xd9ede8               | X0 = val_16.get_wave();                 
            System.Collections.Generic.List<JSCLevelMonsterConfig> val_17 = val_16.wave;
            // 0x00AB1814: MOV x24, x0                | X24 = val_17;//m1                       
            // 0x00AB1818: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_50 = 0;
            // 0x00AB181C: B #0xab1834                |  goto label_25;                         
            goto label_25;
            label_31:
            // 0x00AB1820: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB1824: MOV x0, x21                | X0 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1828: MOV x1, x26                | X1 = X26;//m1                           
            // 0x00AB182C: BL #0x1327830              | Add(item:  X26);                        
            Add(item:  X26);
            // 0x00AB1830: ADD w25, w25, #1           | W25 = (val_50 + 1) = val_50 (0x00000001);
            val_50 = 1;
            label_25:
            // 0x00AB1834: CBNZ x24, #0xab183c        | if (val_17 != null) goto label_26;      
            if(val_17 != null)
            {
                goto label_26;
            }
            // 0x00AB1838: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            label_26:
            // 0x00AB183C: LDR x1, [x19]              | X1 = public System.Int32 System.Collections.Generic.List<JSCLevelMonsterConfig>::get_Count();
            // 0x00AB1840: MOV x0, x24                | X0 = val_17;//m1                        
            // 0x00AB1844: BL #0x25ed72c              | X0 = val_17.get_Count();                
            int val_18 = val_17.Count;
            // 0x00AB1848: CMP w25, w0                | STATE = COMPARE(0x1, val_18)            
            // 0x00AB184C: B.GE #0xab17bc             | if (val_50 >= val_18) goto label_27;    
            if(val_50 >= val_18)
            {
                goto label_27;
            }
            // 0x00AB1850: CBNZ x24, #0xab1858        | if (val_17 != null) goto label_28;      
            if(val_17 != null)
            {
                goto label_28;
            }
            // 0x00AB1854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_28:
            // 0x00AB1858: LDR x2, [x28]              | X2 = public JSCLevelMonsterConfig System.Collections.Generic.List<JSCLevelMonsterConfig>::get_Item(int index);
            // 0x00AB185C: MOV x0, x24                | X0 = val_17;//m1                        
            // 0x00AB1860: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
            // 0x00AB1864: BL #0x25ed734              | X0 = val_17.get_Item(index:  1);        
            JSCLevelMonsterConfig val_19 = val_17.Item[1];
            // 0x00AB1868: MOV x26, x0                | X26 = val_19;//m1                       
            // 0x00AB186C: CBNZ x26, #0xab1874        | if (val_19 != null) goto label_29;      
            if(val_19 != null)
            {
                goto label_29;
            }
            // 0x00AB1870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_29:
            // 0x00AB1874: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1878: MOV x0, x26                | X0 = val_19;//m1                        
            // 0x00AB187C: BL #0xd9eab0               | X0 = val_19.get_id();                   
            int val_20 = val_19.id;
            // 0x00AB1880: MOV w1, w0                 | W1 = val_20;//m1                        
            // 0x00AB1884: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB1888: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB188C: BL #0x292ff20              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            Newtonsoft.Json.Linq.JToken val_21 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            // 0x00AB1890: MOV x26, x0                | X26 = val_21;//m1                       
            // 0x00AB1894: CBNZ x21, #0xab1820        | if ( != 0) goto label_31;               
            if(null != 0)
            {
                goto label_31;
            }
            // 0x00AB1898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            // 0x00AB189C: B #0xab1820                |  goto label_31;                         
            goto label_31;
            label_22:
            // 0x00AB18A0: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AB18A4: LDR x8, [x8, #0x48]        | X8 = 1152921504860946432;               
            // 0x00AB18A8: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Linq.JArray);
            Newtonsoft.Json.Linq.JArray val_22 = null;
            // 0x00AB18AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            // 0x00AB18B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB18B4: MOV x21, x0                | X21 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB18B8: BL #0x1326264              | .ctor();                                
            val_22 = new Newtonsoft.Json.Linq.JArray();
            // 0x00AB18BC: LDR x22, [sp, #8]          | X22 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00AB18C0: CBNZ x22, #0xab18c8        | if ( != 0) goto label_32;               
            if(null != 0)
            {
                goto label_32;
            }
            // 0x00AB18C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_32:
            // 0x00AB18C8: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x00AB18CC: LDR x8, [x8, #0x428]       | X8 = (string**)(1152921510416368368)("guide");
            // 0x00AB18D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB18D4: MOV x0, x22                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00AB18D8: MOV x2, x21                | X2 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB18DC: LDR x1, [x8]               | X1 = "guide";                           
            // 0x00AB18E0: BL #0x2926f6c              | Add(propertyName:  "guide", value:  val_22);
            Add(propertyName:  "guide", value:  val_22);
            // 0x00AB18E4: CBNZ x20, #0xab18ec        | if (val_2 != null) goto label_33;       
            if(val_2 != null)
            {
                goto label_33;
            }
            // 0x00AB18E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JObject), ????);
            label_33:
            // 0x00AB18EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB18F0: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00AB18F4: BL #0xd9e930               | X0 = val_2.get_guide();                 
            System.Collections.Generic.List<JSCWaveNpcConfig> val_23 = val_2.guide;
            // 0x00AB18F8: MOV x22, x0                | X22 = val_23;//m1                       
            // 0x00AB18FC: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_51 = 0;
            // 0x00AB1900: B #0xab1908                |  goto label_34;                         
            goto label_34;
            label_41:
            // 0x00AB1904: ADD w23, w23, #1           | W23 = (val_51 + 1) = val_51 (0x00000001);
            val_51 = 1;
            label_34:
            // 0x00AB1908: CBNZ x22, #0xab1910        | if (val_23 != null) goto label_35;      
            if(val_23 != null)
            {
                goto label_35;
            }
            // 0x00AB190C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_35:
            // 0x00AB1910: LDR x1, [x27]              | X1 = public System.Int32 System.Collections.Generic.List<JSCWaveNpcConfig>::get_Count();
            // 0x00AB1914: MOV x0, x22                | X0 = val_23;//m1                        
            // 0x00AB1918: BL #0x25ed72c              | X0 = val_23.get_Count();                
            int val_24 = val_23.Count;
            // 0x00AB191C: CMP w23, w0                | STATE = COMPARE(0x1, val_24)            
            // 0x00AB1920: B.GE #0xab19e8             | if (val_51 >= val_24) goto label_36;    
            if(val_51 >= val_24)
            {
                goto label_36;
            }
            // 0x00AB1924: CBNZ x22, #0xab192c        | if (val_23 != null) goto label_37;      
            if(val_23 != null)
            {
                goto label_37;
            }
            // 0x00AB1928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_37:
            // 0x00AB192C: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00AB1930: LDR x8, [x8, #0x470]       | X8 = 1152921514565380496;               
            // 0x00AB1934: MOV x0, x22                | X0 = val_23;//m1                        
            // 0x00AB1938: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x00AB193C: LDR x2, [x8]               | X2 = public JSCWaveNpcConfig System.Collections.Generic.List<JSCWaveNpcConfig>::get_Item(int index);
            // 0x00AB1940: BL #0x25ed734              | X0 = val_23.get_Item(index:  1);        
            JSCWaveNpcConfig val_25 = val_23.Item[1];
            // 0x00AB1944: MOV x24, x0                | X24 = val_25;//m1                       
            // 0x00AB1948: CBNZ x24, #0xab1950        | if (val_25 != null) goto label_38;      
            if(val_25 != null)
            {
                goto label_38;
            }
            // 0x00AB194C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_38:
            // 0x00AB1950: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1954: MOV x0, x24                | X0 = val_25;//m1                        
            // 0x00AB1958: BL #0xd9ede8               | X0 = val_25.get_wave();                 
            System.Collections.Generic.List<JSCLevelMonsterConfig> val_26 = val_25.wave;
            // 0x00AB195C: MOV x24, x0                | X24 = val_26;//m1                       
            // 0x00AB1960: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_52 = 0;
            // 0x00AB1964: B #0xab197c                |  goto label_39;                         
            goto label_39;
            label_45:
            // 0x00AB1968: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB196C: MOV x0, x21                | X0 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1970: MOV x1, x26                | X1 = X26;//m1                           
            // 0x00AB1974: BL #0x1327830              | Add(item:  X26);                        
            Add(item:  X26);
            // 0x00AB1978: ADD w25, w25, #1           | W25 = (val_52 + 1) = val_52 (0x00000001);
            val_52 = 1;
            label_39:
            // 0x00AB197C: CBNZ x24, #0xab1984        | if (val_26 != null) goto label_40;      
            if(val_26 != null)
            {
                goto label_40;
            }
            // 0x00AB1980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            label_40:
            // 0x00AB1984: LDR x1, [x19]              | X1 = public System.Int32 System.Collections.Generic.List<JSCLevelMonsterConfig>::get_Count();
            // 0x00AB1988: MOV x0, x24                | X0 = val_26;//m1                        
            // 0x00AB198C: BL #0x25ed72c              | X0 = val_26.get_Count();                
            int val_27 = val_26.Count;
            // 0x00AB1990: CMP w25, w0                | STATE = COMPARE(0x1, val_27)            
            // 0x00AB1994: B.GE #0xab1904             | if (val_52 >= val_27) goto label_41;    
            if(val_52 >= val_27)
            {
                goto label_41;
            }
            // 0x00AB1998: CBNZ x24, #0xab19a0        | if (val_26 != null) goto label_42;      
            if(val_26 != null)
            {
                goto label_42;
            }
            // 0x00AB199C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_42:
            // 0x00AB19A0: LDR x2, [x28]              | X2 = public JSCLevelMonsterConfig System.Collections.Generic.List<JSCLevelMonsterConfig>::get_Item(int index);
            // 0x00AB19A4: MOV x0, x24                | X0 = val_26;//m1                        
            // 0x00AB19A8: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
            // 0x00AB19AC: BL #0x25ed734              | X0 = val_26.get_Item(index:  1);        
            JSCLevelMonsterConfig val_28 = val_26.Item[1];
            // 0x00AB19B0: MOV x26, x0                | X26 = val_28;//m1                       
            // 0x00AB19B4: CBNZ x26, #0xab19bc        | if (val_28 != null) goto label_43;      
            if(val_28 != null)
            {
                goto label_43;
            }
            // 0x00AB19B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_43:
            // 0x00AB19BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB19C0: MOV x0, x26                | X0 = val_28;//m1                        
            // 0x00AB19C4: BL #0xd9eab0               | X0 = val_28.get_id();                   
            int val_29 = val_28.id;
            // 0x00AB19C8: MOV w1, w0                 | W1 = val_29;//m1                        
            // 0x00AB19CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB19D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB19D4: BL #0x292ff20              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            Newtonsoft.Json.Linq.JToken val_30 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            // 0x00AB19D8: MOV x26, x0                | X26 = val_30;//m1                       
            // 0x00AB19DC: CBNZ x21, #0xab1968        | if ( != 0) goto label_45;               
            if(null != 0)
            {
                goto label_45;
            }
            // 0x00AB19E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
            // 0x00AB19E4: B #0xab1968                |  goto label_45;                         
            goto label_45;
            label_36:
            // 0x00AB19E8: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AB19EC: LDR x8, [x8, #0x48]        | X8 = 1152921504860946432;               
            // 0x00AB19F0: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Linq.JArray);
            Newtonsoft.Json.Linq.JArray val_31 = null;
            // 0x00AB19F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            // 0x00AB19F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB19FC: MOV x21, x0                | X21 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1A00: BL #0x1326264              | .ctor();                                
            val_31 = new Newtonsoft.Json.Linq.JArray();
            // 0x00AB1A04: LDR x22, [sp, #8]          | X22 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00AB1A08: CBNZ x22, #0xab1a10        | if ( != 0) goto label_46;               
            if(null != 0)
            {
                goto label_46;
            }
            // 0x00AB1A0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_46:
            // 0x00AB1A10: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB1A14: LDR x8, [x8, #0x4e0]       | X8 = (string**)(1152921514944044928)("guideHero");
            // 0x00AB1A18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB1A1C: MOV x0, x22                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00AB1A20: MOV x2, x21                | X2 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1A24: LDR x1, [x8]               | X1 = "guideHero";                       
            // 0x00AB1A28: BL #0x2926f6c              | Add(propertyName:  "guideHero", value:  val_31);
            Add(propertyName:  "guideHero", value:  val_31);
            // 0x00AB1A2C: CBNZ x20, #0xab1a34        | if (val_2 != null) goto label_47;       
            if(val_2 != null)
            {
                goto label_47;
            }
            // 0x00AB1A30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JObject), ????);
            label_47:
            // 0x00AB1A34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1A38: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00AB1A3C: BL #0xd9e948               | X0 = val_2.get_guideHero();             
            JSCLevelHeroConfig val_32 = val_2.guideHero;
            // 0x00AB1A40: CBZ x0, #0xab1af4          | if (val_32 == null) goto label_53;      
            if(val_32 == null)
            {
                goto label_53;
            }
            // 0x00AB1A44: CBNZ x20, #0xab1a4c        | if (val_2 != null) goto label_49;       
            if(val_2 != null)
            {
                goto label_49;
            }
            // 0x00AB1A48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_49:
            // 0x00AB1A4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1A50: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00AB1A54: BL #0xd9e948               | X0 = val_2.get_guideHero();             
            JSCLevelHeroConfig val_33 = val_2.guideHero;
            // 0x00AB1A58: MOV x22, x0                | X22 = val_33;//m1                       
            // 0x00AB1A5C: CBNZ x22, #0xab1a64        | if (val_33 != null) goto label_50;      
            if(val_33 != null)
            {
                goto label_50;
            }
            // 0x00AB1A60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
            label_50:
            // 0x00AB1A64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1A68: MOV x0, x22                | X0 = val_33;//m1                        
            // 0x00AB1A6C: BL #0xd9ea18               | X0 = val_33.get_idList();               
            System.Collections.Generic.List<System.Int32> val_34 = val_33.idList;
            // 0x00AB1A70: ADRP x25, #0x3632000       | X25 = 56827904 (0x3632000);             
            // 0x00AB1A74: ADRP x26, #0x3653000       | X26 = 56963072 (0x3653000);             
            // 0x00AB1A78: LDR x25, [x25, #0x598]     | X25 = 1152921510876601136;              
            // 0x00AB1A7C: LDR x26, [x26, #0x408]     | X26 = 1152921510876430768;              
            // 0x00AB1A80: MOV x22, x0                | X22 = val_34;//m1                       
            // 0x00AB1A84: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_51 = 0;
            // 0x00AB1A88: B #0xab1aa0                |  goto label_51;                         
            goto label_51;
            label_56:
            // 0x00AB1A8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB1A90: MOV x0, x21                | X0 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1A94: MOV x1, x24                | X1 = X24;//m1                           
            // 0x00AB1A98: BL #0x1327830              | Add(item:  X24);                        
            Add(item:  X24);
            // 0x00AB1A9C: ADD w23, w23, #1           | W23 = (val_51 + 1) = val_51 (0x00000001);
            val_51 = 1;
            label_51:
            // 0x00AB1AA0: CBNZ x22, #0xab1aa8        | if (val_34 != null) goto label_52;      
            if(val_34 != null)
            {
                goto label_52;
            }
            // 0x00AB1AA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            label_52:
            // 0x00AB1AA8: LDR x1, [x25]              | X1 = public System.Int32 System.Collections.Generic.List<System.Int32>::get_Count();
            // 0x00AB1AAC: MOV x0, x22                | X0 = val_34;//m1                        
            // 0x00AB1AB0: BL #0x25e4ddc              | X0 = val_34.get_Count();                
            int val_35 = val_34.Count;
            // 0x00AB1AB4: CMP w23, w0                | STATE = COMPARE(0x1, val_35)            
            // 0x00AB1AB8: B.GE #0xab1af4             | if (val_51 >= val_35) goto label_53;    
            if(val_51 >= val_35)
            {
                goto label_53;
            }
            // 0x00AB1ABC: CBNZ x22, #0xab1ac4        | if (val_34 != null) goto label_54;      
            if(val_34 != null)
            {
                goto label_54;
            }
            // 0x00AB1AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_54:
            // 0x00AB1AC4: LDR x2, [x26]              | X2 = public System.Int32 System.Collections.Generic.List<System.Int32>::get_Item(int index);
            // 0x00AB1AC8: MOV x0, x22                | X0 = val_34;//m1                        
            // 0x00AB1ACC: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x00AB1AD0: BL #0x25e4de4              | X0 = val_34.get_Item(index:  1);        
            int val_36 = val_34.Item[1];
            // 0x00AB1AD4: MOV w1, w0                 | W1 = val_36;//m1                        
            // 0x00AB1AD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB1ADC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB1AE0: BL #0x292ff20              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            Newtonsoft.Json.Linq.JToken val_37 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            // 0x00AB1AE4: MOV x24, x0                | X24 = val_37;//m1                       
            // 0x00AB1AE8: CBNZ x21, #0xab1a8c        | if ( != 0) goto label_56;               
            if(null != 0)
            {
                goto label_56;
            }
            // 0x00AB1AEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            // 0x00AB1AF0: B #0xab1a8c                |  goto label_56;                         
            goto label_56;
            label_53:
            // 0x00AB1AF4: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AB1AF8: LDR x8, [x8, #0x48]        | X8 = 1152921504860946432;               
            // 0x00AB1AFC: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Linq.JArray);
            Newtonsoft.Json.Linq.JArray val_38 = null;
            // 0x00AB1B00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            // 0x00AB1B04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1B08: MOV x21, x0                | X21 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1B0C: BL #0x1326264              | .ctor();                                
            val_38 = new Newtonsoft.Json.Linq.JArray();
            // 0x00AB1B10: LDR x22, [sp, #8]          | X22 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00AB1B14: CBNZ x22, #0xab1b1c        | if ( != 0) goto label_57;               
            if(null != 0)
            {
                goto label_57;
            }
            // 0x00AB1B18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_57:
            // 0x00AB1B1C: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x00AB1B20: LDR x8, [x8, #0x628]       | X8 = (string**)(1152921514944061408)("plot");
            // 0x00AB1B24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB1B28: MOV x0, x22                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00AB1B2C: MOV x2, x21                | X2 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1B30: LDR x1, [x8]               | X1 = "plot";                            
            // 0x00AB1B34: MOV x26, x22               | X26 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00AB1B38: BL #0x2926f6c              | Add(propertyName:  "plot", value:  val_38);
            Add(propertyName:  "plot", value:  val_38);
            // 0x00AB1B3C: CBNZ x20, #0xab1b44        | if (val_2 != null) goto label_58;       
            if(val_2 != null)
            {
                goto label_58;
            }
            // 0x00AB1B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JObject), ????);
            label_58:
            // 0x00AB1B44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1B48: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00AB1B4C: BL #0xd9e958               | X0 = val_2.get_plot();                  
            System.Collections.Generic.List<JSCWaveNpcConfig> val_39 = val_2.plot;
            // 0x00AB1B50: MOV x20, x0                | X20 = val_39;//m1                       
            // 0x00AB1B54: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_53 = 0;
            // 0x00AB1B58: B #0xab1b60                |  goto label_59;                         
            goto label_59;
            label_66:
            // 0x00AB1B5C: ADD w22, w22, #1           | W22 = (val_53 + 1) = val_53 (0x00000001);
            val_53 = 1;
            label_59:
            // 0x00AB1B60: CBNZ x20, #0xab1b68        | if (val_39 != null) goto label_60;      
            if(val_39 != null)
            {
                goto label_60;
            }
            // 0x00AB1B64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_60:
            // 0x00AB1B68: LDR x1, [x27]              | X1 = public System.Int32 System.Collections.Generic.List<JSCWaveNpcConfig>::get_Count();
            // 0x00AB1B6C: MOV x0, x20                | X0 = val_39;//m1                        
            // 0x00AB1B70: BL #0x25ed72c              | X0 = val_39.get_Count();                
            int val_40 = val_39.Count;
            // 0x00AB1B74: CMP w22, w0                | STATE = COMPARE(0x1, val_40)            
            // 0x00AB1B78: B.GE #0xab1c40             | if (val_53 >= val_40) goto label_61;    
            if(val_53 >= val_40)
            {
                goto label_61;
            }
            // 0x00AB1B7C: CBNZ x20, #0xab1b84        | if (val_39 != null) goto label_62;      
            if(val_39 != null)
            {
                goto label_62;
            }
            // 0x00AB1B80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            label_62:
            // 0x00AB1B84: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00AB1B88: LDR x8, [x8, #0x470]       | X8 = 1152921514565380496;               
            // 0x00AB1B8C: MOV x0, x20                | X0 = val_39;//m1                        
            // 0x00AB1B90: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
            // 0x00AB1B94: LDR x2, [x8]               | X2 = public JSCWaveNpcConfig System.Collections.Generic.List<JSCWaveNpcConfig>::get_Item(int index);
            // 0x00AB1B98: BL #0x25ed734              | X0 = val_39.get_Item(index:  1);        
            JSCWaveNpcConfig val_41 = val_39.Item[1];
            // 0x00AB1B9C: MOV x23, x0                | X23 = val_41;//m1                       
            // 0x00AB1BA0: CBNZ x23, #0xab1ba8        | if (val_41 != null) goto label_63;      
            if(val_41 != null)
            {
                goto label_63;
            }
            // 0x00AB1BA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
            label_63:
            // 0x00AB1BA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1BAC: MOV x0, x23                | X0 = val_41;//m1                        
            // 0x00AB1BB0: BL #0xd9ede8               | X0 = val_41.get_wave();                 
            System.Collections.Generic.List<JSCLevelMonsterConfig> val_42 = val_41.wave;
            // 0x00AB1BB4: MOV x23, x0                | X23 = val_42;//m1                       
            // 0x00AB1BB8: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_54 = 0;
            // 0x00AB1BBC: B #0xab1bd4                |  goto label_64;                         
            goto label_64;
            label_70:
            // 0x00AB1BC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB1BC4: MOV x0, x21                | X0 = 1152921504860946432 (0x100000000F254000);//ML01
            // 0x00AB1BC8: MOV x1, x25                | X1 = X25;//m1                           
            // 0x00AB1BCC: BL #0x1327830              | Add(item:  X25);                        
            Add(item:  X25);
            // 0x00AB1BD0: ADD w24, w24, #1           | W24 = (val_54 + 1) = val_54 (0x00000001);
            val_54 = 1;
            label_64:
            // 0x00AB1BD4: CBNZ x23, #0xab1bdc        | if (val_42 != null) goto label_65;      
            if(val_42 != null)
            {
                goto label_65;
            }
            // 0x00AB1BD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JArray), ????);
            label_65:
            // 0x00AB1BDC: LDR x1, [x19]              | X1 = public System.Int32 System.Collections.Generic.List<JSCLevelMonsterConfig>::get_Count();
            // 0x00AB1BE0: MOV x0, x23                | X0 = val_42;//m1                        
            // 0x00AB1BE4: BL #0x25ed72c              | X0 = val_42.get_Count();                
            int val_43 = val_42.Count;
            // 0x00AB1BE8: CMP w24, w0                | STATE = COMPARE(0x1, val_43)            
            // 0x00AB1BEC: B.GE #0xab1b5c             | if (val_54 >= val_43) goto label_66;    
            if(val_54 >= val_43)
            {
                goto label_66;
            }
            // 0x00AB1BF0: CBNZ x23, #0xab1bf8        | if (val_42 != null) goto label_67;      
            if(val_42 != null)
            {
                goto label_67;
            }
            // 0x00AB1BF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
            label_67:
            // 0x00AB1BF8: LDR x2, [x28]              | X2 = public JSCLevelMonsterConfig System.Collections.Generic.List<JSCLevelMonsterConfig>::get_Item(int index);
            // 0x00AB1BFC: MOV x0, x23                | X0 = val_42;//m1                        
            // 0x00AB1C00: MOV w1, w24                | W1 = 1 (0x1);//ML01                     
            // 0x00AB1C04: BL #0x25ed734              | X0 = val_42.get_Item(index:  1);        
            JSCLevelMonsterConfig val_44 = val_42.Item[1];
            // 0x00AB1C08: MOV x25, x0                | X25 = val_44;//m1                       
            // 0x00AB1C0C: CBNZ x25, #0xab1c14        | if (val_44 != null) goto label_68;      
            if(val_44 != null)
            {
                goto label_68;
            }
            // 0x00AB1C10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
            label_68:
            // 0x00AB1C14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1C18: MOV x0, x25                | X0 = val_44;//m1                        
            // 0x00AB1C1C: BL #0xd9eab0               | X0 = val_44.get_id();                   
            int val_45 = val_44.id;
            // 0x00AB1C20: MOV w1, w0                 | W1 = val_45;//m1                        
            // 0x00AB1C24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB1C28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB1C2C: BL #0x292ff20              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            Newtonsoft.Json.Linq.JToken val_46 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
            // 0x00AB1C30: MOV x25, x0                | X25 = val_46;//m1                       
            // 0x00AB1C34: CBNZ x21, #0xab1bc0        | if ( != 0) goto label_70;               
            if(null != 0)
            {
                goto label_70;
            }
            // 0x00AB1C38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            // 0x00AB1C3C: B #0xab1bc0                |  goto label_70;                         
            goto label_70;
            label_61:
            // 0x00AB1C40: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x00AB1C44: LDR x8, [x8, #0x9c8]       | X8 = 1152921504859615232;               
            // 0x00AB1C48: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonConvert);
            // 0x00AB1C4C: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_10A;
            // 0x00AB1C50: TBZ w8, #0, #0xab1c60      | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_has_cctor == 0) goto label_72;
            // 0x00AB1C54: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished;
            // 0x00AB1C58: CBNZ w8, #0xab1c60         | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
            // 0x00AB1C5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.JsonConvert), ????);
            label_72:
            // 0x00AB1C60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB1C64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB1C68: MOV x1, x26                | X1 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00AB1C6C: SUB sp, x29, #0x50         | SP = (1152921514944093952 - 80) = 1152921514944093872 (0x100000026825DEB0);
            // 0x00AB1C70: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB1C74: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB1C78: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB1C7C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB1C80: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AB1C84: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AB1C88: B #0x1311134               | return Newtonsoft.Json.JsonConvert.SerializeObject(value:  0);
            return Newtonsoft.Json.JsonConvert.SerializeObject(value:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB1378 (11211640), len: 352  VirtAddr: 0x00AB1378 RVA: 0x00AB1378 token: 100693135 methodIndex: 46957 delegateWrapperIndex: 0 methodInvoker: 0
        private static void NextAssets(System.Collections.Generic.List<string> list)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00AB1378: STP x26, x25, [sp, #-0x50]! | stack[1152921514944320576] = ???;  stack[1152921514944320584] = ???;  //  dest_result_addr=1152921514944320576 |  dest_result_addr=1152921514944320584
            // 0x00AB137C: STP x24, x23, [sp, #0x10]  | stack[1152921514944320592] = ???;  stack[1152921514944320600] = ???;  //  dest_result_addr=1152921514944320592 |  dest_result_addr=1152921514944320600
            // 0x00AB1380: STP x22, x21, [sp, #0x20]  | stack[1152921514944320608] = ???;  stack[1152921514944320616] = ???;  //  dest_result_addr=1152921514944320608 |  dest_result_addr=1152921514944320616
            // 0x00AB1384: STP x20, x19, [sp, #0x30]  | stack[1152921514944320624] = ???;  stack[1152921514944320632] = ???;  //  dest_result_addr=1152921514944320624 |  dest_result_addr=1152921514944320632
            // 0x00AB1388: STP x29, x30, [sp, #0x40]  | stack[1152921514944320640] = ???;  stack[1152921514944320648] = ???;  //  dest_result_addr=1152921514944320640 |  dest_result_addr=1152921514944320648
            // 0x00AB138C: ADD x29, sp, #0x40         | X29 = (1152921514944320576 + 64) = 1152921514944320640 (0x1000000268295480);
            // 0x00AB1390: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB1394: LDRB w8, [x20, #0x3eb]     | W8 = (bool)static_value_037333EB;       
            // 0x00AB1398: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB139C: TBNZ w8, #0, #0xab13b8     | if (static_value_037333EB == true) goto label_0;
            // 0x00AB13A0: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00AB13A4: LDR x8, [x8, #0xe88]       | X8 = 0x2B8EAB8;                         
            // 0x00AB13A8: LDR w0, [x8]               | W0 = 0x116E;                            
            // 0x00AB13AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x116E, ????);     
            // 0x00AB13B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB13B4: STRB w8, [x20, #0x3eb]     | static_value_037333EB = true;            //  dest_result_addr=57881579
            label_0:
            // 0x00AB13B8: ADRP x22, #0x35de000       | X22 = 56483840 (0x35DE000);             
            // 0x00AB13BC: ADRP x23, #0x35fc000       | X23 = 56606720 (0x35FC000);             
            // 0x00AB13C0: ADRP x24, #0x35bd000       | X24 = 56348672 (0x35BD000);             
            // 0x00AB13C4: ADRP x25, #0x3633000       | X25 = 56832000 (0x3633000);             
            // 0x00AB13C8: LDR x22, [x22, #0xc20]     | X22 = 1152921504902639616;              
            // 0x00AB13CC: LDR x23, [x23, #0xb58]     | X23 = 1152921510022759280;              
            // 0x00AB13D0: LDR x24, [x24, #0xb50]     | X24 = 1152921510890998992;              
            // 0x00AB13D4: LDR x25, [x25, #0xae0]     | X25 = 1152921514943344464;              
            // 0x00AB13D8: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00AB13DC: B #0xab1408                |  goto label_1;                          
            goto label_1;
            label_9:
            // 0x00AB13E0: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB13E4: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00AB13E8: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
            // 0x00AB13EC: BL #0x25ed734              | X0 = X21.get_Item(index:  0);           
            string val_1 = X21.Item[0];
            // 0x00AB13F0: LDR x3, [x25]              | X3 = public static System.Void EList::Add<System.String>(System.Collections.Generic.List<T> list, System.String item);
            // 0x00AB13F4: MOV x2, x0                 | X2 = val_1;//m1                         
            // 0x00AB13F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB13FC: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB1400: BL #0x10cf778              | EList.Add<System.String>(list:  0, item:  X1);
            EList.Add<System.String>(list:  0, item:  X1);
            // 0x00AB1404: ADD w20, w20, #1           | W20 = (val_6 + 1) = val_6 (0x00000001); 
            val_6 = 1;
            label_1:
            // 0x00AB1408: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetCollect);  
            val_7 = null;
            // 0x00AB140C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_10A;
            // 0x00AB1410: TBZ w8, #0, #0xab1424      | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00AB1414: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished;
            // 0x00AB1418: CBNZ w8, #0xab1424         | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00AB141C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetCollect), ????);
            // 0x00AB1420: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetCollect);  
            val_7 = null;
            label_3:
            // 0x00AB1424: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB1428: LDR x21, [x8, #8]          | X21 = Mihua.Asset.AssetCollect.nextList;
            // 0x00AB142C: CBNZ x21, #0xab1434        | if (Mihua.Asset.AssetCollect.nextList != null) goto label_4;
            if(Mihua.Asset.AssetCollect.nextList != null)
            {
                goto label_4;
            }
            // 0x00AB1430: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetCollect), ????);
            label_4:
            // 0x00AB1434: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB1438: MOV x0, x21                | X0 = Mihua.Asset.AssetCollect.nextList;//m1
            // 0x00AB143C: BL #0x25ed72c              | X0 = Mihua.Asset.AssetCollect.nextList.get_Count();
            int val_2 = Mihua.Asset.AssetCollect.nextList.Count;
            // 0x00AB1440: MOV w8, w0                 | W8 = val_2;//m1                         
            // 0x00AB1444: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetCollect);  
            val_8 = null;
            // 0x00AB1448: CMP w20, w8                | STATE = COMPARE(0x1, val_2)             
            // 0x00AB144C: ADD x9, x0, #0x109         | X9 = (val_8 + 265) = 1152921504902639881 (0x1000000011A17109);
            // 0x00AB1450: LDRH w9, [x9]              | W9 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_109;
            // 0x00AB1454: AND w9, w9, #0x100         | W9 = (Mihua.Asset.AssetCollect.__il2cppRuntimeField_109 & 256);
            // 0x00AB1458: B.GE #0xab1488             | if (val_6 >= val_2) goto label_5;       
            if(val_6 >= val_2)
            {
                goto label_5;
            }
            // 0x00AB145C: AND w8, w9, #0xffff        | W8 = ((Mihua.Asset.AssetCollect.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00AB1460: CBZ w8, #0xab1474          | if (((Mihua.Asset.AssetCollect.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_7;
            // 0x00AB1464: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished;
            // 0x00AB1468: CBNZ w8, #0xab1474         | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00AB146C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetCollect), ????);
            // 0x00AB1470: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetCollect);  
            val_9 = null;
            label_7:
            // 0x00AB1474: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB1478: LDR x21, [x8, #8]          | X21 = Mihua.Asset.AssetCollect.nextList;
            // 0x00AB147C: CBNZ x21, #0xab13e0        | if (Mihua.Asset.AssetCollect.nextList != null) goto label_9;
            if(Mihua.Asset.AssetCollect.nextList != null)
            {
                goto label_9;
            }
            // 0x00AB1480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetCollect), ????);
            // 0x00AB1484: B #0xab13e0                |  goto label_9;                          
            goto label_9;
            label_5:
            // 0x00AB1488: AND w8, w9, #0xffff        | W8 = ((Mihua.Asset.AssetCollect.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00AB148C: CBZ w8, #0xab14a0          | if (((Mihua.Asset.AssetCollect.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_11;
            // 0x00AB1490: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished;
            // 0x00AB1494: CBNZ w8, #0xab14a0         | if (Mihua.Asset.AssetCollect.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00AB1498: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetCollect), ????);
            // 0x00AB149C: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetCollect);  
            val_10 = null;
            label_11:
            // 0x00AB14A0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB14A4: LDR x19, [x8, #8]          | X19 = Mihua.Asset.AssetCollect.nextList;
            // 0x00AB14A8: CBNZ x19, #0xab14b0        | if (Mihua.Asset.AssetCollect.nextList != null) goto label_12;
            if(Mihua.Asset.AssetCollect.nextList != null)
            {
                goto label_12;
            }
            // 0x00AB14AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetCollect), ????);
            label_12:
            // 0x00AB14B0: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00AB14B4: LDR x8, [x8, #0xca8]       | X8 = 1152921510890633680;               
            // 0x00AB14B8: MOV x0, x19                | X0 = Mihua.Asset.AssetCollect.nextList;//m1
            // 0x00AB14BC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB14C0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB14C4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB14C8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB14CC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB14D0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AB14D4: B #0x25ead28               | Mihua.Asset.AssetCollect.nextList.Clear(); return;
            Mihua.Asset.AssetCollect.nextList.Clear();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB1C8C (11213964), len: 4  VirtAddr: 0x00AB1C8C RVA: 0x00AB1C8C token: 100693136 methodIndex: 46958 delegateWrapperIndex: 0 methodInvoker: 0
        private static void UIAssets(System.Collections.Generic.List<string> list)
        {
            //
            // Disasemble & Code
            // 0x00AB1C8C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB1C90 (11213968), len: 4  VirtAddr: 0x00AB1C90 RVA: 0x00AB1C90 token: 100693137 methodIndex: 46959 delegateWrapperIndex: 0 methodInvoker: 0
        private static void SkillAssets(System.Collections.Generic.List<string> list)
        {
            //
            // Disasemble & Code
            // 0x00AB1C90: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB1C94 (11213972), len: 204  VirtAddr: 0x00AB1C94 RVA: 0x00AB1C94 token: 100693138 methodIndex: 46960 delegateWrapperIndex: 0 methodInvoker: 0
        private static AssetCollect()
        {
            //
            // Disasemble & Code
            // 0x00AB1C94: STP x22, x21, [sp, #-0x30]! | stack[1152921514944681184] = ???;  stack[1152921514944681192] = ???;  //  dest_result_addr=1152921514944681184 |  dest_result_addr=1152921514944681192
            // 0x00AB1C98: STP x20, x19, [sp, #0x10]  | stack[1152921514944681200] = ???;  stack[1152921514944681208] = ???;  //  dest_result_addr=1152921514944681200 |  dest_result_addr=1152921514944681208
            // 0x00AB1C9C: STP x29, x30, [sp, #0x20]  | stack[1152921514944681216] = ???;  stack[1152921514944681224] = ???;  //  dest_result_addr=1152921514944681216 |  dest_result_addr=1152921514944681224
            // 0x00AB1CA0: ADD x29, sp, #0x20         | X29 = (1152921514944681184 + 32) = 1152921514944681216 (0x10000002682ED500);
            // 0x00AB1CA4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB1CA8: LDRB w8, [x19, #0x3ec]     | W8 = (bool)static_value_037333EC;       
            // 0x00AB1CAC: TBNZ w8, #0, #0xab1cc8     | if (static_value_037333EC == true) goto label_0;
            // 0x00AB1CB0: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00AB1CB4: LDR x8, [x8, #0xac8]       | X8 = 0x2B8EAA0;                         
            // 0x00AB1CB8: LDR w0, [x8]               | W0 = 0x1168;                            
            // 0x00AB1CBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1168, ????);     
            // 0x00AB1CC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB1CC4: STRB w8, [x19, #0x3ec]     | static_value_037333EC = true;            //  dest_result_addr=57881580
            label_0:
            // 0x00AB1CC8: ADRP x20, #0x367b000       | X20 = 57126912 (0x367B000);             
            // 0x00AB1CCC: LDR x20, [x20, #0xe00]     | X20 = 1152921504616644608;              
            // 0x00AB1CD0: LDR x0, [x20]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_1 = null;
            // 0x00AB1CD4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB1CD8: ADRP x21, #0x35e9000       | X21 = 56528896 (0x35E9000);             
            // 0x00AB1CDC: LDR x21, [x21, #0xe88]     | X21 = 1152921510893072720;              
            // 0x00AB1CE0: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB1CE4: LDR x1, [x21]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB1CE8: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<System.String>();
            // 0x00AB1CEC: ADRP x22, #0x35de000       | X22 = 56483840 (0x35DE000);             
            // 0x00AB1CF0: LDR x22, [x22, #0xc20]     | X22 = 1152921504902639616;              
            // 0x00AB1CF4: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            // 0x00AB1CF8: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB1CFC: STR x19, [x8]              | Mihua.Asset.AssetCollect.uiNeedList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504902643712
            Mihua.Asset.AssetCollect.uiNeedList = val_1;
            // 0x00AB1D00: LDR x0, [x20]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_2 = null;
            // 0x00AB1D04: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB1D08: LDR x1, [x21]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB1D0C: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB1D10: BL #0x25e9474              | .ctor();                                
            val_2 = new System.Collections.Generic.List<System.String>();
            // 0x00AB1D14: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            // 0x00AB1D18: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB1D1C: STR x19, [x8, #8]          | Mihua.Asset.AssetCollect.nextList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504902643720
            Mihua.Asset.AssetCollect.nextList = val_2;
            // 0x00AB1D20: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00AB1D24: LDR x8, [x8, #0x1c0]       | X8 = 1152921504616644608;               
            // 0x00AB1D28: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.Int32> val_3 = null;
            // 0x00AB1D2C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB1D30: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x00AB1D34: LDR x8, [x8, #0x268]       | X8 = 1152921510015557168;               
            // 0x00AB1D38: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB1D3C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Int32>::.ctor();
            // 0x00AB1D40: BL #0x25e0ae0              | .ctor();                                
            val_3 = new System.Collections.Generic.List<System.Int32>();
            // 0x00AB1D44: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetCollect);  
            // 0x00AB1D48: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetCollect.__il2cppRuntimeField_static_fields;
            // 0x00AB1D4C: STR x19, [x8, #0x10]       | Mihua.Asset.AssetCollect.summonList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504902643728
            Mihua.Asset.AssetCollect.summonList = val_3;
            // 0x00AB1D50: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB1D54: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB1D58: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB1D5C: RET                        |  return;                                
            return;
        
        }
    
    }

}
