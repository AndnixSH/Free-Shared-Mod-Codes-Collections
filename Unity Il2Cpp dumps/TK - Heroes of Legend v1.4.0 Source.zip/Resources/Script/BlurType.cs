using UnityEngine;
[Serializable]
public enum FastBloom.BlurType
{
    // Fields
    Standard = 0
    ,Sgx = 1
    

}
