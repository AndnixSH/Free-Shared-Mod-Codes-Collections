using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CLRBindings : CLRBindingsBase
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00A207A0 (10618784), len: 8  VirtAddr: 0x00A207A0 RVA: 0x00A207A0 token: 100664480 methodIndex: 30527 delegateWrapperIndex: 0 methodInvoker: 0
        public CLRBindings()
        {
            //
            // Disasemble & Code
            // 0x00A207A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A207A4: B #0x16f59f0               | this..ctor(); return;                   
            val_1 = new System.Object();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00A207B0 (10618800), len: 11364  VirtAddr: 0x00A207B0 RVA: 0x00A207B0 token: 100664481 methodIndex: 30528 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Initialize(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            // 0x00A207B0: STP x20, x19, [sp, #-0x20]! | stack[1152921510155865616] = ???;  stack[1152921510155865624] = ???;  //  dest_result_addr=1152921510155865616 |  dest_result_addr=1152921510155865624
            // 0x00A207B4: STP x29, x30, [sp, #0x10]  | stack[1152921510155865632] = ???;  stack[1152921510155865640] = ???;  //  dest_result_addr=1152921510155865632 |  dest_result_addr=1152921510155865640
            // 0x00A207B8: ADD x29, sp, #0x10         | X29 = (1152921510155865616 + 16) = 1152921510155865632 (0x100000014ABF4E20);
            // 0x00A207BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A207C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A207C4: MOV x19, x1                | X19 = app;//m1                          
            // 0x00A207C8: BL #0x221f138              | ILRuntime.Runtime.Generated.System_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Int32_Binding.Register(app:  0);
            // 0x00A207CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A207D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A207D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A207D8: BL #0x1d14928              | ILRuntime.Runtime.Generated.System_Boolean_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Boolean_Binding.Register(app:  0);
            // 0x00A207DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A207E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A207E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A207E8: BL #0x1a33cfc              | ILRuntime.Runtime.Generated.System_Single_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Single_Binding.Register(app:  0);
            // 0x00A207EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A207F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A207F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A207F8: BL #0x1cd8a40              | ILRuntime.Runtime.Generated.System_UInt32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_UInt32_Binding.Register(app:  0);
            // 0x00A207FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20800: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20804: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20808: BL #0xe8b60c               | ILRuntime.Runtime.Generated.SceneMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.SceneMgr_Binding.Register(app:  0);
            // 0x00A2080C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20810: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20814: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20818: BL #0x143a528              | ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.Register(app:  0);
            // 0x00A2081C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20820: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20824: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20828: BL #0x17597a0              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A2082C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20830: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20834: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20838: BL #0x159ade8              | ILRuntime.Runtime.Generated.JsDBMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.JsDBMgr_Binding.Register(app:  0);
            // 0x00A2083C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20840: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20844: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20848: BL #0x1a39be4              | ILRuntime.Runtime.Generated.System_String_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_String_Binding.Register(app:  0);
            // 0x00A2084C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20850: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20854: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20858: BL #0x1d00ac4              | ILRuntime.Runtime.Generated.System_Activator_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Activator_Binding.Register(app:  0);
            // 0x00A2085C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20860: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20864: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20868: BL #0x166cb00              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Int32_Binding.Register(app:  0);
            // 0x00A2086C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20870: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20874: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20878: BL #0x1a8cd70              | ILRuntime.Runtime.Generated.UnityEngine_Mathf_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Mathf_Binding.Register(app:  0);
            // 0x00A2087C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20880: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20884: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20888: BL #0x165d994              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A2088C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20894: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20898: BL #0x1438124              | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.Register(app:  0);
            // 0x00A2089C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A208A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A208A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A208A8: BL #0x15cd4f0              | ILRuntime.Runtime.Generated.EDebug_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.EDebug_Binding.Register(app:  0);
            // 0x00A208AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A208B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A208B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A208B8: BL #0x1a2c4e8              | ILRuntime.Runtime.Generated.System_Object_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Object_Binding.Register(app:  0);
            // 0x00A208BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A208C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A208C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A208C8: BL #0x17f3cdc              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A208CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A208D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A208D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A208D8: BL #0x15ed63c              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UInt32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UInt32_Binding.Register(app:  0);
            // 0x00A208DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A208E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A208E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A208E8: BL #0x1597edc              | ILRuntime.Runtime.Generated.ZMG_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ZMG_Binding.Register(app:  0);
            // 0x00A208EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A208F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A208F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A208F8: BL #0x294d97c              | ILRuntime.Runtime.Generated.FloatTextMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.FloatTextMgr_Binding.Register(app:  0);
            // 0x00A208FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20900: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20904: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20908: BL #0x1d160e8              | ILRuntime.Runtime.Generated.System_Char_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Char_Binding.Register(app:  0);
            // 0x00A2090C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20910: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20914: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20918: BL #0x17600a0              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Int32_Array_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Int32_Array_Binding.Register(app:  0);
            // 0x00A2091C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20920: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20924: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20928: BL #0x15cfb70              | ILRuntime.Runtime.Generated.EString_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.EString_Binding.Register(app:  0);
            // 0x00A2092C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20930: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20934: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20938: BL #0x22242c0              | ILRuntime.Runtime.Generated.System_Int64_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Int64_Binding.Register(app:  0);
            // 0x00A2093C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20940: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20944: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20948: BL #0x1ce6cd0              | ILRuntime.Runtime.Generated.TimeMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TimeMgr_Binding.Register(app:  0);
            // 0x00A2094C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20950: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20954: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20958: BL #0x21e4050              | ILRuntime.Runtime.Generated.UnityEngine_Random_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Random_Binding.Register(app:  0);
            // 0x00A2095C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20960: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20964: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20968: BL #0x195fc94              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A2096C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20970: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20974: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20978: BL #0x1d00698              | ILRuntime.Runtime.Generated.System_Action_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Action_Binding.Register(app:  0);
            // 0x00A2097C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20980: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20984: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20988: BL #0x1679ecc              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_String_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_String_Binding.Register(app:  0);
            // 0x00A2098C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20990: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20994: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20998: BL #0x194de98              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A2099C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A209A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A209A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A209A8: BL #0x157db2c              | ILRuntime.Runtime.Generated.Util_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Util_Binding.Register(app:  0);
            // 0x00A209AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A209B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A209B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A209B8: BL #0x1673954              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_List_1_String_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_List_1_String_Binding.Register(app:  0);
            // 0x00A209BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A209C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A209C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A209C8: BL #0x175dc00              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_ILTypeInstance_Binding_Enumerator_Int32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_ILTypeInstance_Binding_Enumerator_Int32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A209CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A209D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A209D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A209D8: BL #0x1803c34              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A209DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A209E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A209E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A209E8: BL #0x17f9428              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_Int32_Binding.Register(app:  0);
            // 0x00A209EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A209F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A209F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A209F8: BL #0x17f6f70              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_ILTypeInstance_Binding_Enumerator_UInt32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_ILTypeInstance_Binding_Enumerator_UInt32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A209FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A08: BL #0x180e76c              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_UInt32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_UInt32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20A0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A18: BL #0x1751d58              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_Int32_Dictionary_2_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_Int32_Dictionary_2_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20A1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A28: BL #0x174dd44              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_ILTypeInstance_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_ILTypeInstance_Int32_Binding.Register(app:  0);
            // 0x00A20A2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A38: BL #0x17531b4              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20A3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A48: BL #0x166bc18              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_ILTypeInstance_Binding_Enumerator_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_ILTypeInstance_Binding_Enumerator_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20A4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A58: BL #0x221ed70              | ILRuntime.Runtime.Generated.System_IDisposable_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_IDisposable_Binding.Register(app:  0);
            // 0x00A20A5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A68: BL #0x174f51c              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Boolean_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Boolean_Binding.Register(app:  0);
            // 0x00A20A6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A78: BL #0x1656b00              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Boolean_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Boolean_Binding.Register(app:  0);
            // 0x00A20A7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A88: BL #0x1da43b8              | ILRuntime.Runtime.Generated.UnityEngine_Vector3_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Vector3_Binding.Register(app:  0);
            // 0x00A20A8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20A90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20A94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20A98: BL #0x19622e4              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_ILTypeInstance_Binding_Enumerator_String_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_ILTypeInstance_Binding_Enumerator_String_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20A9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20AA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20AA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20AA8: BL #0x180977c              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20AAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20AB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20AB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20AB8: BL #0x220d094              | ILRuntime.Runtime.Generated.System_Enum_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Enum_Binding.Register(app:  0);
            // 0x00A20ABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20AC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20AC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20AC8: BL #0x194ae34              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Int32_Binding.Register(app:  0);
            // 0x00A20ACC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20AD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20AD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20AD8: BL #0x1cab56c              | ILRuntime.Runtime.Generated.UILabel_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UILabel_Binding.Register(app:  0);
            // 0x00A20ADC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20AE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20AE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20AE8: BL #0x15b81e8              | ILRuntime.Runtime.Generated.Mihua_Asset_AssetMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Asset_AssetMgr_Binding.Register(app:  0);
            // 0x00A20AEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20AF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20AF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20AF8: BL #0x1908580              | ILRuntime.Runtime.Generated.UISprite_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UISprite_Binding.Register(app:  0);
            // 0x00A20AFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B08: BL #0xc30c3c               | ILRuntime.Runtime.Generated.UnityEngine_Color_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Color_Binding.Register(app:  0);
            // 0x00A20B0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B18: BL #0x14b8ce4              | ILRuntime.Runtime.Generated.UIWidget_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIWidget_Binding.Register(app:  0);
            // 0x00A20B1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B28: BL #0x15b1574              | ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_AssetOperation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_AssetOperation_Binding.Register(app:  0);
            // 0x00A20B2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B38: BL #0x10a882c              | ILRuntime.Runtime.Generated.UnityEngine_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GameObject_Binding.Register(app:  0);
            // 0x00A20B3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B48: BL #0x194fdac              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_List_1_ILTypeInstance_Binding_Enumerator_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_List_1_ILTypeInstance_Binding_Enumerator_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20B4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B58: BL #0x18055d4              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20B5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B68: BL #0x1677f80              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Single_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Single_Binding.Register(app:  0);
            // 0x00A20B6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B78: BL #0x15f0d90              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UISprite_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UISprite_Binding.Register(app:  0);
            // 0x00A20B7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B88: BL #0x1671074              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Int32_Binding_Enumerator_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Int32_Binding_Enumerator_Int32_Binding.Register(app:  0);
            // 0x00A20B8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20B90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20B94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20B98: BL #0x1756998              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_GameObject_Binding.Register(app:  0);
            // 0x00A20B9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20BA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20BA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20BA8: BL #0x17ad820              | ILRuntime.Runtime.Generated.UnityEngine_Object_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Object_Binding.Register(app:  0);
            // 0x00A20BAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20BB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20BB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20BB8: BL #0x296ebe4              | ILRuntime.Runtime.Generated.GameObject_Hierarchy_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.GameObject_Hierarchy_Binding.Register(app:  0);
            // 0x00A20BBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20BC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20BC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20BC8: BL #0x16c9130              | ILRuntime.Runtime.Generated.UIPanel_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIPanel_Binding.Register(app:  0);
            // 0x00A20BCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20BD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20BD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20BD8: BL #0x1758580              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_GameObject_Binding_Enumerator_Int32_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_GameObject_Binding_Enumerator_Int32_GameObject_Binding.Register(app:  0);
            // 0x00A20BDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20BE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20BE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20BE8: BL #0x1803114              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_GameObject_Binding.Register(app:  0);
            // 0x00A20BEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20BF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20BF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20BF8: BL #0x1fedb1c              | ILRuntime.Runtime.Generated.UnityEngine_Transform_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Transform_Binding.Register(app:  0);
            // 0x00A20BFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C08: BL #0x11a180c              | ILRuntime.Runtime.Generated.GameObject_Instantiate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.GameObject_Instantiate_Binding.Register(app:  0);
            // 0x00A20C0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C18: BL #0x1671f74              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20C1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C28: BL #0x142bddc              | ILRuntime.Runtime.Generated.CallJSApi_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CallJSApi_Binding.Register(app:  0);
            // 0x00A20C2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C38: BL #0x2046254              | ILRuntime.Runtime.Generated.UnityEngine_Time_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Time_Binding.Register(app:  0);
            // 0x00A20C3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C48: BL #0x15b6f4c              | ILRuntime.Runtime.Generated.Mihua_Asset_AssetCollect_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Asset_AssetCollect_Binding.Register(app:  0);
            // 0x00A20C4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C58: BL #0xbc023c               | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.Register(app:  0);
            // 0x00A20C5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C68: BL #0xbc4370               | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.Register(app:  0);
            // 0x00A20C6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C78: BL #0x11bdda4              | ILRuntime.Runtime.Generated.HeroMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.HeroMgr_Binding.Register(app:  0);
            // 0x00A20C7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C88: BL #0x165d11c              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Hero_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Hero_Binding.Register(app:  0);
            // 0x00A20C8C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20C90: BL #0xa23414               | ILRuntime.Runtime.Generated.CombatEntity_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CombatEntity_Binding.Register(app:  0);
            // 0x00A20C94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20C98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20C9C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20CA0: BL #0xbd5db8               | ILRuntime.Runtime.Generated.BuffCtrl_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.BuffCtrl_Binding.Register(app:  0);
            // 0x00A20CA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20CA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20CAC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20CB0: BL #0x20772d8              | ILRuntime.Runtime.Generated.UnityEngine_Application_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Application_Binding.Register(app:  0);
            // 0x00A20CB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20CB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20CBC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20CC0: BL #0x100c208              | ILRuntime.Runtime.Generated.NpcMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.NpcMgr_Binding.Register(app:  0);
            // 0x00A20CC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20CC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20CCC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20CD0: BL #0x1657624              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_CombatEntity_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_CombatEntity_Binding.Register(app:  0);
            // 0x00A20CD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20CD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20CDC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20CE0: BL #0x15efe90              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UInt32_Binding_Enumerator_UInt32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UInt32_Binding_Enumerator_UInt32_Binding.Register(app:  0);
            // 0x00A20CE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20CE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20CEC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20CF0: BL #0x295a00c              | ILRuntime.Runtime.Generated.GameMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.GameMgr_Binding.Register(app:  0);
            // 0x00A20CF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20CF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20CFC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D00: BL #0x1021dfc              | ILRuntime.Runtime.Generated.PlotFightTalkMgr_Binding_PlotTermParam_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PlotFightTalkMgr_Binding_PlotTermParam_Binding.Register(app:  0);
            // 0x00A20D04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D0C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D10: BL #0x159ecf4              | ILRuntime.Runtime.Generated.Loader_PathUtil_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Loader_PathUtil_Binding.Register(app:  0);
            // 0x00A20D14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D1C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D20: BL #0x195bcf4              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Double_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Double_Binding.Register(app:  0);
            // 0x00A20D24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D2C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D30: BL #0x1b301b0              | ILRuntime.Runtime.Generated.UnityEngine_PlayerPrefs_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_PlayerPrefs_Binding.Register(app:  0);
            // 0x00A20D34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D3C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D40: BL #0x1032d30              | ILRuntime.Runtime.Generated.PluginsSdkMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PluginsSdkMgr_Binding.Register(app:  0);
            // 0x00A20D44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D4C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D50: BL #0x158ecd4              | ILRuntime.Runtime.Generated.VersionMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.VersionMgr_Binding.Register(app:  0);
            // 0x00A20D54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D5C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D60: BL #0x1587774              | ILRuntime.Runtime.Generated.VersionInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.VersionInfo_Binding.Register(app:  0);
            // 0x00A20D64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D6C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D70: BL #0x2289bcc              | ILRuntime.Runtime.Generated.UnityEngine_Debug_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Debug_Binding.Register(app:  0);
            // 0x00A20D74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D7C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D80: BL #0x196cbb0              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_String_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_String_Binding.Register(app:  0);
            // 0x00A20D84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D8C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20D90: BL #0x1f58290              | ILRuntime.Runtime.Generated.System_Math_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Math_Binding.Register(app:  0);
            // 0x00A20D94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20D98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20D9C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20DA0: BL #0x220c3a8              | ILRuntime.Runtime.Generated.System_Double_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Double_Binding.Register(app:  0);
            // 0x00A20DA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20DA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20DAC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20DB0: BL #0x1963504              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Int32_Binding.Register(app:  0);
            // 0x00A20DB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20DB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20DBC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20DC0: BL #0x1965720              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Int32_Binding_Enumerator_String_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Int32_Binding_Enumerator_String_Int32_Binding.Register(app:  0);
            // 0x00A20DC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20DC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20DCC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20DD0: BL #0x180a5dc              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_Int32_Binding.Register(app:  0);
            // 0x00A20DD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20DD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20DDC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20DE0: BL #0x1675c94              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Object_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Object_Binding.Register(app:  0);
            // 0x00A20DE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20DE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20DEC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20DF0: BL #0x1950fcc              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_List_1_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_List_1_Int32_Binding.Register(app:  0);
            // 0x00A20DF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20DF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20DFC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E00: BL #0x17fc6b8              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_UInt32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_UInt32_Binding.Register(app:  0);
            // 0x00A20E04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E0C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E10: BL #0x17fde44              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_UInt32_Binding_Enumerator_UInt32_UInt32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_UInt32_Binding_Enumerator_UInt32_UInt32_Binding.Register(app:  0);
            // 0x00A20E14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E1C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E20: BL #0x180f5e4              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_UInt32_UInt32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_UInt32_UInt32_Binding.Register(app:  0);
            // 0x00A20E24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E2C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E30: BL #0x17ef090              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_Boolean_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_Boolean_Binding.Register(app:  0);
            // 0x00A20E34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E3C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E40: BL #0xc44140               | ILRuntime.Runtime.Generated.UnityEngine_Component_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Component_Binding.Register(app:  0);
            // 0x00A20E44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E4C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E50: BL #0x1cf05fc              | ILRuntime.Runtime.Generated.SoundMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.SoundMgr_Binding.Register(app:  0);
            // 0x00A20E54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E5C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E60: BL #0x1ef0984              | ILRuntime.Runtime.Generated.UnityEngine_Screen_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Screen_Binding.Register(app:  0);
            // 0x00A20E64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E6C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E70: BL #0x146de40              | ILRuntime.Runtime.Generated.UnityEngine_SystemInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SystemInfo_Binding.Register(app:  0);
            // 0x00A20E74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E7C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E80: BL #0x15fa32c              | ILRuntime.Runtime.Generated.System_DateTime_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_DateTime_Binding.Register(app:  0);
            // 0x00A20E84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E8C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20E90: BL #0x147402c              | ILRuntime.Runtime.Generated.UnityEngine_TextAsset_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TextAsset_Binding.Register(app:  0);
            // 0x00A20E94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20E98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20E9C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20EA0: BL #0x159c73c              | ILRuntime.Runtime.Generated.JSON_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.JSON_Binding.Register(app:  0);
            // 0x00A20EA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20EA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20EAC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20EB0: BL #0x15c8d84              | ILRuntime.Runtime.Generated.DateUtil_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.DateUtil_Binding.Register(app:  0);
            // 0x00A20EB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20EB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20EBC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20EC0: BL #0x143c3f0              | ILRuntime.Runtime.Generated.checkpointCfg_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.checkpointCfg_Binding.Register(app:  0);
            // 0x00A20EC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20EC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20ECC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20ED0: BL #0x175ee20              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_ILTypeInstance_Binding_ValueCollection_Int32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_ILTypeInstance_Binding_ValueCollection_Int32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20ED4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20ED8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20EDC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20EE0: BL #0x175f1c4              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_ILTypeInstance_Binding_ValueCollection_Int32_ILTypeInstance_Binding_Enumerator_Int32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_ILTypeInstance_Binding_ValueCollection_Int32_ILTypeInstance_Binding_Enumerator_Int32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20EE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20EE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20EEC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20EF0: BL #0x1813a8c              | ILRuntime.Runtime.Generated.UnityEngine_Resources_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Resources_Binding.Register(app:  0);
            // 0x00A20EF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20EF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20EFC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F00: BL #0x15f6038              | ILRuntime.Runtime.Generated.System_Collections_Generic_Queue_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Queue_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20F04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F0C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F10: BL #0x19537d0              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_String_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_String_Binding.Register(app:  0);
            // 0x00A20F14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F1C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F20: BL #0x15f6f70              | ILRuntime.Runtime.Generated.System_Collections_Generic_Queue_1_String_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Queue_1_String_Binding.Register(app:  0);
            // 0x00A20F24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F2C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F30: BL #0x17542fc              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20F34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F3C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F40: BL #0x1966940              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20F44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F4C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F50: BL #0x1755778              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_String_List_1_ILTypeInstance_Binding_Enumerator_Int32_Dictionary_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_String_List_1_ILTypeInstance_Binding_Enumerator_Int32_Dictionary_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20F54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F5C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F60: BL #0x18025f4              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_Dictionary_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_Dictionary_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20F64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F6C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F70: BL #0x1967cb4              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_List_1_ILTypeInstance_Binding_Enumerator_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_List_1_ILTypeInstance_Binding_Enumerator_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20F74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F7C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F80: BL #0x180b454              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_List_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20F84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F8C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20F90: BL #0x17f052c              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_Dictionary_2_UInt32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_Dictionary_2_UInt32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A20F94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20F98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20F9C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20FA0: BL #0x294edb4              | ILRuntime.Runtime.Generated.Formula_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Formula_Binding.Register(app:  0);
            // 0x00A20FA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20FA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20FAC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20FB0: BL #0x1e87678              | ILRuntime.Runtime.Generated.UnityEngine_Renderer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Renderer_Binding.Register(app:  0);
            // 0x00A20FB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20FB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20FBC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20FC0: BL #0x13e39b4              | ILRuntime.Runtime.Generated.UnityEngine_Material_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Material_Binding.Register(app:  0);
            // 0x00A20FC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20FC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20FCC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20FD0: BL #0x1992020              | ILRuntime.Runtime.Generated.UnityEngine_ParticleSystem_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ParticleSystem_Binding.Register(app:  0);
            // 0x00A20FD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20FD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20FDC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20FE0: BL #0x199d5f8              | ILRuntime.Runtime.Generated.UnityEngine_ParticleSystem_Binding_MainModule_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ParticleSystem_Binding_MainModule_Binding.Register(app:  0);
            // 0x00A20FE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20FE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20FEC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A20FF0: BL #0x1928d1c              | ILRuntime.Runtime.Generated.UIEffect_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIEffect_Binding.Register(app:  0);
            // 0x00A20FF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20FF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20FFC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21000: BL #0x1956bc8              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_UInt32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_UInt32_Binding.Register(app:  0);
            // 0x00A21004: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21008: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2100C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21010: BL #0xe8e13c               | ILRuntime.Runtime.Generated.ShowError_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ShowError_Binding.Register(app:  0);
            // 0x00A21014: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21018: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2101C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21020: BL #0x16e2564              | ILRuntime.Runtime.Generated.UIPnl_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIPnl_Binding.Register(app:  0);
            // 0x00A21024: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21028: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2102C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21030: BL #0x193312c              | ILRuntime.Runtime.Generated.UIFBXDisplaySprite_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIFBXDisplaySprite_Binding.Register(app:  0);
            // 0x00A21034: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21038: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2103C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21040: BL #0x1cc2434              | ILRuntime.Runtime.Generated.UIModelDisplayMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIModelDisplayMgr_Binding.Register(app:  0);
            // 0x00A21044: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21048: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2104C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21050: BL #0x1d968b8              | ILRuntime.Runtime.Generated.UnityEngine_Vector2_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Vector2_Binding.Register(app:  0);
            // 0x00A21054: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21058: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2105C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21060: BL #0x192a2a0              | ILRuntime.Runtime.Generated.UIEventListener_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIEventListener_Binding.Register(app:  0);
            // 0x00A21064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21068: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2106C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21070: BL #0x1c979c0              | ILRuntime.Runtime.Generated.UIBasicSprite_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIBasicSprite_Binding.Register(app:  0);
            // 0x00A21074: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21078: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2107C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21080: BL #0xffa600               | ILRuntime.Runtime.Generated.NGUITools_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.NGUITools_Binding.Register(app:  0);
            // 0x00A21084: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21088: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2108C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21090: BL #0x19429b0              | ILRuntime.Runtime.Generated.UIGrid_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIGrid_Binding.Register(app:  0);
            // 0x00A21094: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21098: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2109C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A210A0: BL #0x1c7bcf0              | ILRuntime.Runtime.Generated.TweenPosition_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenPosition_Binding.Register(app:  0);
            // 0x00A210A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A210A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A210AC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A210B0: BL #0x14b11f4              | ILRuntime.Runtime.Generated.UITweener_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UITweener_Binding.Register(app:  0);
            // 0x00A210B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A210B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A210BC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A210C0: BL #0x125d010              | ILRuntime.Runtime.Generated.MScrollView_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.MScrollView_Binding.Register(app:  0);
            // 0x00A210C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A210C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A210CC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A210D0: BL #0x1ce4248              | ILRuntime.Runtime.Generated.TexturesStaticLoad_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TexturesStaticLoad_Binding.Register(app:  0);
            // 0x00A210D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A210D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A210DC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A210E0: BL #0x1d19040              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A210E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A210E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A210EC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A210F0: BL #0x1260574              | ILRuntime.Runtime.Generated.MUIWrapContent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.MUIWrapContent_Binding.Register(app:  0);
            // 0x00A210F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A210F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A210FC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21100: BL #0x11f3e2c              | ILRuntime.Runtime.Generated.UnityEngine_Behaviour_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Behaviour_Binding.Register(app:  0);
            // 0x00A21104: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21108: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2110C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21110: BL #0x17620b0              | ILRuntime.Runtime.Generated.UIButtonColor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIButtonColor_Binding.Register(app:  0);
            // 0x00A21114: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21118: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2111C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21120: BL #0x1659ab8              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_GameObject_Binding.Register(app:  0);
            // 0x00A21124: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21128: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2112C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21130: BL #0xe85e38               | ILRuntime.Runtime.Generated.ReplayMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ReplayMgr_Binding.Register(app:  0);
            // 0x00A21134: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21138: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2113C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21140: BL #0x173e4a8              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Binding_Enumerator_GameObject_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Binding_Enumerator_GameObject_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A21144: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21148: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2114C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21150: BL #0x17ff06c              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_GameObject_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_GameObject_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A21154: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21158: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2115C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21160: BL #0x1810674              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_AssetOperation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_AssetOperation_Binding.Register(app:  0);
            // 0x00A21164: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21168: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2116C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21170: BL #0x15af8a4              | ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_ABOperation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_ABOperation_Binding.Register(app:  0);
            // 0x00A21174: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21178: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2117C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21180: BL #0x1eec4d0              | ILRuntime.Runtime.Generated.UnityEngine_Collider_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Collider_Binding.Register(app:  0);
            // 0x00A21184: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21188: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2118C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21190: BL #0x205d438              | ILRuntime.Runtime.Generated.UnityEngine_LayerMask_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LayerMask_Binding.Register(app:  0);
            // 0x00A21194: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21198: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2119C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A211A0: BL #0x1b43e84              | ILRuntime.Runtime.Generated.UnityEngine_Quaternion_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Quaternion_Binding.Register(app:  0);
            // 0x00A211A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A211A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A211AC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A211B0: BL #0x1bf26e0              | ILRuntime.Runtime.Generated.UnityEngine_Input_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Input_Binding.Register(app:  0);
            // 0x00A211B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A211B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A211BC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A211C0: BL #0x1209a88              | ILRuntime.Runtime.Generated.UnityEngine_Camera_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Camera_Binding.Register(app:  0);
            // 0x00A211C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A211C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A211CC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A211D0: BL #0x15ec520              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UILabel_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UILabel_Binding.Register(app:  0);
            // 0x00A211D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A211D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A211DC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A211E0: BL #0x18fb188              | ILRuntime.Runtime.Generated.UIScrollView_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIScrollView_Binding.Register(app:  0);
            // 0x00A211E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A211E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A211EC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A211F0: BL #0x1253578              | ILRuntime.Runtime.Generated.MonoBehaviourVisitor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.MonoBehaviourVisitor_Binding.Register(app:  0);
            // 0x00A211F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A211F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A211FC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21200: BL #0x11f9de0              | ILRuntime.Runtime.Generated.UnityEngine_Bounds_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Bounds_Binding.Register(app:  0);
            // 0x00A21204: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21208: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2120C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21210: BL #0x19159e8              | ILRuntime.Runtime.Generated.UITable_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UITable_Binding.Register(app:  0);
            // 0x00A21214: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21218: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2121C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21220: BL #0x191fa88              | ILRuntime.Runtime.Generated.UIDragScrollView_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIDragScrollView_Binding.Register(app:  0);
            // 0x00A21224: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21228: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2122C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21230: BL #0x14a9b84              | ILRuntime.Runtime.Generated.UIToggle_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIToggle_Binding.Register(app:  0);
            // 0x00A21234: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21238: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2123C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21240: BL #0x11a77b8              | ILRuntime.Runtime.Generated.GlobalGOMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.GlobalGOMgr_Binding.Register(app:  0);
            // 0x00A21244: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21248: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2124C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21250: BL #0x16ea264              | ILRuntime.Runtime.Generated.UIProgressBar_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIProgressBar_Binding.Register(app:  0);
            // 0x00A21254: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21258: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2125C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21260: BL #0x190c354              | ILRuntime.Runtime.Generated.UISpriteAnimation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UISpriteAnimation_Binding.Register(app:  0);
            // 0x00A21264: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21268: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2126C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21270: BL #0x1c9ff9c              | ILRuntime.Runtime.Generated.UIInput_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIInput_Binding.Register(app:  0);
            // 0x00A21274: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21278: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2127C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21280: BL #0x1cf507c              | ILRuntime.Runtime.Generated.SpringPanel_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.SpringPanel_Binding.Register(app:  0);
            // 0x00A21284: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21288: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2128C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21290: BL #0x1741e98              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UILabel_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UILabel_Binding.Register(app:  0);
            // 0x00A21294: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21298: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2129C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A212A0: BL #0x176bc60              | ILRuntime.Runtime.Generated.UICamera_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UICamera_Binding.Register(app:  0);
            // 0x00A212A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A212A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A212AC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A212B0: BL #0x15f3ee8              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UITweener_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UITweener_Binding.Register(app:  0);
            // 0x00A212B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A212B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A212BC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A212C0: BL #0xcd5280               | ILRuntime.Runtime.Generated.UnityEngine_Animator_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Animator_Binding.Register(app:  0);
            // 0x00A212C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A212C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A212CC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A212D0: BL #0x195835c              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_UInt32_Binding_Enumerator_Int32_UInt32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_UInt32_Binding_Enumerator_Int32_UInt32_Binding.Register(app:  0);
            // 0x00A212D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A212D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A212DC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A212E0: BL #0x1807de4              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_UInt32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_UInt32_Binding.Register(app:  0);
            // 0x00A212E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A212E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A212EC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A212F0: BL #0x11a21f8              | ILRuntime.Runtime.Generated.GameObjectVisitor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.GameObjectVisitor_Binding.Register(app:  0);
            // 0x00A212F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A212F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A212FC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21300: BL #0xbb954c               | ILRuntime.Runtime.Generated.AnimationRunner_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.Register(app:  0);
            // 0x00A21304: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21308: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2130C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21310: BL #0x12023e0              | ILRuntime.Runtime.Generated.UnityEngine_BoxCollider_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_BoxCollider_Binding.Register(app:  0);
            // 0x00A21314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21318: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2131C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21320: BL #0x16592dc              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_EventDelegate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_EventDelegate_Binding.Register(app:  0);
            // 0x00A21324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21328: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2132C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21330: BL #0x1672f5c              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_List_1_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_List_1_Int32_Binding.Register(app:  0);
            // 0x00A21334: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21338: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2133C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21340: BL #0x16ee700              | ILRuntime.Runtime.Generated.UIRect_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIRect_Binding.Register(app:  0);
            // 0x00A21344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21348: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2134C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21350: BL #0x1cdce7c              | ILRuntime.Runtime.Generated.TeamSkillMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TeamSkillMgr_Binding.Register(app:  0);
            // 0x00A21354: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21358: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2135C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21360: BL #0x11a3fbc              | ILRuntime.Runtime.Generated.GesturesMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.GesturesMgr_Binding.Register(app:  0);
            // 0x00A21364: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21368: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2136C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21370: BL #0x11ad320              | ILRuntime.Runtime.Generated.Hero_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Hero_Binding.Register(app:  0);
            // 0x00A21374: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21378: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2137C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21380: BL #0xe8e888               | ILRuntime.Runtime.Generated.Skill_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Skill_Binding.Register(app:  0);
            // 0x00A21384: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21388: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2138C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21390: BL #0x1c0a500              | ILRuntime.Runtime.Generated.CSCheckPointUnit_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSCheckPointUnit_Binding.Register(app:  0);
            // 0x00A21394: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21398: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2139C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A213A0: BL #0x1c91710              | ILRuntime.Runtime.Generated.UI3DWidgetMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UI3DWidgetMgr_Binding.Register(app:  0);
            // 0x00A213A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A213A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A213AC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A213B0: BL #0x1cf8c94              | ILRuntime.Runtime.Generated.suodingEff_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.suodingEff_Binding.Register(app:  0);
            // 0x00A213B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A213B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A213BC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A213C0: BL #0x1cdb6e0              | ILRuntime.Runtime.Generated.TeamSkill_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TeamSkill_Binding.Register(app:  0);
            // 0x00A213C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A213C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A213CC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A213D0: BL #0x1cf910c              | ILRuntime.Runtime.Generated.superskillCfg_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.superskillCfg_Binding.Register(app:  0);
            // 0x00A213D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A213D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A213DC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A213E0: BL #0x1c9c0cc              | ILRuntime.Runtime.Generated.UIButton_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIButton_Binding.Register(app:  0);
            // 0x00A213E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A213E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A213EC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A213F0: BL #0x15db484              | ILRuntime.Runtime.Generated.FightCtrl_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.FightCtrl_Binding.Register(app:  0);
            // 0x00A213F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A213F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A213FC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21400: BL #0x1929094              | ILRuntime.Runtime.Generated.UIEffectMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIEffectMgr_Binding.Register(app:  0);
            // 0x00A21404: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21408: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2140C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21410: BL #0x1ceae70              | ILRuntime.Runtime.Generated.TweenAlpha_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenAlpha_Binding.Register(app:  0);
            // 0x00A21414: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21418: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2141C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21420: BL #0xe9a34c               | ILRuntime.Runtime.Generated.skillCfg_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.skillCfg_Binding.Register(app:  0);
            // 0x00A21424: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21428: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2142C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21430: BL #0x1cda2e0              | ILRuntime.Runtime.Generated.taixuTipCfg_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.taixuTipCfg_Binding.Register(app:  0);
            // 0x00A21434: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21438: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2143C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21440: BL #0xe89f78               | ILRuntime.Runtime.Generated.RollNumber_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.RollNumber_Binding.Register(app:  0);
            // 0x00A21444: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21448: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2144C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21450: BL #0x1c80714              | ILRuntime.Runtime.Generated.TweenScale_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenScale_Binding.Register(app:  0);
            // 0x00A21454: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21458: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2145C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21460: BL #0x12512a8              | ILRuntime.Runtime.Generated.MonoBehaviour_MonoBehaviour_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.MonoBehaviour_MonoBehaviour_Binding.Register(app:  0);
            // 0x00A21464: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21468: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2146C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21470: BL #0x1657e9c              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_CSHeroUnit_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_CSHeroUnit_Binding.Register(app:  0);
            // 0x00A21474: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21478: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2147C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21480: BL #0xbc3f08               | ILRuntime.Runtime.Generated.AssetGOList_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.AssetGOList_Binding.Register(app:  0);
            // 0x00A21484: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21488: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2148C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21490: BL #0x1c0e778              | ILRuntime.Runtime.Generated.CSGameDataMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSGameDataMgr_Binding.Register(app:  0);
            // 0x00A21494: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21498: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2149C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A214A0: BL #0x1c04ec0              | ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSArenaInterServiceData_Binding.Register(app:  0);
            // 0x00A214A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A214A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A214AC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A214B0: BL #0x1c01fe4              | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.Register(app:  0);
            // 0x00A214B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A214B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A214BC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A214C0: BL #0x1c1577c              | ILRuntime.Runtime.Generated.CSHeroUnit_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSHeroUnit_Binding.Register(app:  0);
            // 0x00A214C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A214C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A214CC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A214D0: BL #0x165c234              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_GameObject_Binding_Enumerator_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_GameObject_Binding_Enumerator_GameObject_Binding.Register(app:  0);
            // 0x00A214D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A214D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A214DC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A214E0: BL #0x17ee09c              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_UIFont_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_UIFont_Binding.Register(app:  0);
            // 0x00A214E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A214E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A214EC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A214F0: BL #0x17a7f20              | ILRuntime.Runtime.Generated.UnityEngine_MonoBehaviour_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_MonoBehaviour_Binding.Register(app:  0);
            // 0x00A214F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A214F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A214FC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21500: BL #0x15d21c4              | ILRuntime.Runtime.Generated.EventDelegate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.EventDelegate_Binding.Register(app:  0);
            // 0x00A21504: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21508: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2150C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21510: BL #0x209e544              | ILRuntime.Runtime.Generated.UnityEngine_WaitForSeconds_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WaitForSeconds_Binding.Register(app:  0);
            // 0x00A21514: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21518: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2151C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21520: BL #0x1a2c2d8              | ILRuntime.Runtime.Generated.System_NotSupportedException_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_NotSupportedException_Binding.Register(app:  0);
            // 0x00A21524: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21528: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2152C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21530: BL #0x1cff944              | ILRuntime.Runtime.Generated.System_Action_1_Boolean_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Action_1_Boolean_Binding.Register(app:  0);
            // 0x00A21534: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21538: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2153C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21540: BL #0xbc994c               | ILRuntime.Runtime.Generated.Biaoche_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Biaoche_Binding.Register(app:  0);
            // 0x00A21544: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21548: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2154C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21550: BL #0x1fe6944              | ILRuntime.Runtime.Generated.UnityEngine_TrailRenderer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TrailRenderer_Binding.Register(app:  0);
            // 0x00A21554: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21558: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2155C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21560: BL #0x1c93874              | ILRuntime.Runtime.Generated.UIAtlas_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIAtlas_Binding.Register(app:  0);
            // 0x00A21564: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21568: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2156C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21570: BL #0x2090d20              | ILRuntime.Runtime.Generated.UnityEngine_Vector4_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Vector4_Binding.Register(app:  0);
            // 0x00A21574: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21578: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2157C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21580: BL #0x15f5024              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Vector3_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Vector3_Binding.Register(app:  0);
            // 0x00A21584: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21588: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2158C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21590: BL #0x1968ed4              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_ParticleSystem_Array_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_ParticleSystem_Array_Binding.Register(app:  0);
            // 0x00A21594: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21598: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A2159C: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A215A0: BL #0x196a520              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_ParticleSystem_Array_Binding_Enumerator_String_ParticleSystem_Array_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_ParticleSystem_Array_Binding_Enumerator_String_ParticleSystem_Array_Binding.Register(app:  0);
            // 0x00A215A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A215A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A215AC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A215B0: BL #0x180bf74              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_ParticleSystem_Array_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_ParticleSystem_Array_Binding.Register(app:  0);
            // 0x00A215B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A215B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A215BC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A215C0: BL #0x1676fb4              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_ParticleSystem_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_ParticleSystem_Binding.Register(app:  0);
            // 0x00A215C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A215C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A215CC: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A215D0: BL #0x1fd83e8              | ILRuntime.Runtime.Generated.UnityEngine_Touch_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Touch_Binding.Register(app:  0);
            // 0x00A215D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A215D8: BL #0xa1dbb0               | ILRuntime.Runtime.Generated.Client_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Client_Binding.Register(app:  0);
            // 0x00A215DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A215E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A215E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A215E8: BL #0x1ef5edc              | ILRuntime.Runtime.Generated.UnityEngine_Shader_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Shader_Binding.Register(app:  0);
            // 0x00A215EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A215F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A215F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A215F8: BL #0x15f2238              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UISpriteData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UISpriteData_Binding.Register(app:  0);
            // 0x00A215FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21600: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21604: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21608: BL #0x190e9e0              | ILRuntime.Runtime.Generated.UISpriteData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UISpriteData_Binding.Register(app:  0);
            // 0x00A2160C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21610: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21614: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21618: BL #0x191b678              | ILRuntime.Runtime.Generated.UITexture_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UITexture_Binding.Register(app:  0);
            // 0x00A2161C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21620: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21624: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21628: BL #0x1744524              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UISprite_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UISprite_Binding.Register(app:  0);
            // 0x00A2162C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21630: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21634: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21638: BL #0x17461d8              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UISprite_Binding_Enumerator_GameObject_UISprite_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UISprite_Binding_Enumerator_GameObject_UISprite_Binding.Register(app:  0);
            // 0x00A2163C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21640: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21644: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21648: BL #0x1801650              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_GameObject_UISprite_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_GameObject_UISprite_Binding.Register(app:  0);
            // 0x00A2164C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21650: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21654: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21658: BL #0x15eb404              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UIGrid_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UIGrid_Binding.Register(app:  0);
            // 0x00A2165C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21660: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21664: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21668: BL #0x1d01028              | ILRuntime.Runtime.Generated.System_Array_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Array_Binding.Register(app:  0);
            // 0x00A2166C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21670: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21674: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21678: BL #0x1866540              | ILRuntime.Runtime.Generated.iTween_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.iTween_Binding.Register(app:  0);
            // 0x00A2167C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21680: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21684: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21688: BL #0x1954600              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Transform_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Transform_Binding.Register(app:  0);
            // 0x00A2168C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21690: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21694: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21698: BL #0x195925c              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Vector3_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Vector3_Binding.Register(app:  0);
            // 0x00A2169C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A216A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A216A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A216A8: BL #0xbb1224               | ILRuntime.Runtime.Generated.AIPath_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.AIPath_Binding.Register(app:  0);
            // 0x00A216AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A216B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A216B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A216B8: BL #0x1cffd3c              | ILRuntime.Runtime.Generated.System_Action_1_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Action_1_GameObject_Binding.Register(app:  0);
            // 0x00A216BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A216C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A216C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A216C8: BL #0x159d3cc              | ILRuntime.Runtime.Generated.LabelWriteEffect_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.LabelWriteEffect_Binding.Register(app:  0);
            // 0x00A216CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A216D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A216D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A216D8: BL #0x1ef05f4              | ILRuntime.Runtime.Generated.UnityEngine_RuntimeAnimatorController_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_RuntimeAnimatorController_Binding.Register(app:  0);
            // 0x00A216DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A216E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A216E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A216E8: BL #0xcc3478               | ILRuntime.Runtime.Generated.UnityEngine_AnimationClip_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AnimationClip_Binding.Register(app:  0);
            // 0x00A216EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A216F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A216F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A216F8: BL #0x195d440              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_GameObject_Binding.Register(app:  0);
            // 0x00A216FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21700: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21704: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21708: BL #0x195ea74              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_GameObject_Binding_Enumerator_String_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_GameObject_Binding_Enumerator_String_GameObject_Binding.Register(app:  0);
            // 0x00A2170C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21710: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21714: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21718: BL #0x1808c5c              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_GameObject_Binding.Register(app:  0);
            // 0x00A2171C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21720: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21724: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21728: BL #0x1674b58              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_MUIWrapContent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_MUIWrapContent_Binding.Register(app:  0);
            // 0x00A2172C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21730: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21734: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21738: BL #0x19559a8              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Transform_Binding_Enumerator_Int32_Transform_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Transform_Binding_Enumerator_Int32_Transform_Binding.Register(app:  0);
            // 0x00A2173C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21740: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21744: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21748: BL #0x18072c4              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_Transform_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_Transform_Binding.Register(app:  0);
            // 0x00A2174C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21750: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21754: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21758: BL #0x15e70c8              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Transform_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Transform_Binding.Register(app:  0);
            // 0x00A2175C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21760: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21764: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21768: BL #0x173f6c8              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_Int32_Binding.Register(app:  0);
            // 0x00A2176C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21770: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21774: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21778: BL #0x15ea2e8              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UIAtlas_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UIAtlas_Binding.Register(app:  0);
            // 0x00A2177C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21780: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21784: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21788: BL #0x1426b6c              | ILRuntime.Runtime.Generated.ButtonClickState_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.Register(app:  0);
            // 0x00A2178C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21790: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21794: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21798: BL #0x1cf4818              | ILRuntime.Runtime.Generated.SpinWithMouse_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.SpinWithMouse_Binding.Register(app:  0);
            // 0x00A2179C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A217A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A217A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A217A8: BL #0x17f1654              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_GameObject_Binding.Register(app:  0);
            // 0x00A217AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A217B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A217B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A217B8: BL #0x17f2de4              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_GameObject_Binding_Enumerator_UInt32_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_GameObject_Binding_Enumerator_UInt32_GameObject_Binding.Register(app:  0);
            // 0x00A217BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A217C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A217C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A217C8: BL #0x180dc34              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_UInt32_GameObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_UInt32_GameObject_Binding.Register(app:  0);
            // 0x00A217CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A217D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A217D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A217D8: BL #0x1d16c20              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Array_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Array_Binding.Register(app:  0);
            // 0x00A217DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A217E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A217E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A217E8: BL #0x1d17dc0              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Array_Binding_ValueCollection_GameObject_ILTypeInstance_Array_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Array_Binding_ValueCollection_GameObject_ILTypeInstance_Array_Binding.Register(app:  0);
            // 0x00A217EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A217F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A217F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A217F8: BL #0x1d18164              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Array_Binding_ValueCollection_GameObject_ILTypeInstance_Array_Binding_Enumerator_GameObject_ILTypeInstance_Array_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_ILTypeInstance_Array_Binding_ValueCollection_GameObject_ILTypeInstance_Array_Binding_Enumerator_GameObject_ILTypeInstance_Array_Binding.Register(app:  0);
            // 0x00A217FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21800: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21804: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21808: BL #0x1c920a8              | ILRuntime.Runtime.Generated.UIAnchor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIAnchor_Binding.Register(app:  0);
            // 0x00A2180C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21810: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21814: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21818: BL #0xe76428               | ILRuntime.Runtime.Generated.PluginXunFei_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PluginXunFei_Binding.Register(app:  0);
            // 0x00A2181C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21820: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21824: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21828: BL #0x23094e0              | ILRuntime.Runtime.Generated.System_Text_Encoding_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Text_Encoding_Binding.Register(app:  0);
            // 0x00A2182C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21830: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21834: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21838: BL #0x15a38d8              | ILRuntime.Runtime.Generated.LoadEvent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.LoadEvent_Binding.Register(app:  0);
            // 0x00A2183C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21840: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21844: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21848: BL #0x1570a38              | ILRuntime.Runtime.Generated.UnityEngine_WWW_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WWW_Binding.Register(app:  0);
            // 0x00A2184C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21850: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21854: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21858: BL #0x124d318              | ILRuntime.Runtime.Generated.Mihua_Assets_SubAssetMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Assets_SubAssetMgr_Binding.Register(app:  0);
            // 0x00A2185C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21860: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21864: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21868: BL #0x157c078              | ILRuntime.Runtime.Generated.UnzipABAsset_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnzipABAsset_Binding.Register(app:  0);
            // 0x00A2186C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21870: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21874: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21878: BL #0x28f4cb0              | ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ABCheckUpdate_Binding.Register(app:  0);
            // 0x00A2187C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21880: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21884: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21888: BL #0x17470d0              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UIToggle_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UIToggle_Binding.Register(app:  0);
            // 0x00A2188C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21894: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21898: BL #0x15f2dcc              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UIToggle_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_UIToggle_Binding.Register(app:  0);
            // 0x00A2189C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A218A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A218A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A218A8: BL #0x15e91cc              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_TweenScale_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_TweenScale_Binding.Register(app:  0);
            // 0x00A218AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A218B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A218B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A218B8: BL #0x1c7e7e4              | ILRuntime.Runtime.Generated.TweenRotation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenRotation_Binding.Register(app:  0);
            // 0x00A218BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A218C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A218C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A218C8: BL #0x29545a8              | ILRuntime.Runtime.Generated.FS_ShadowSimple_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.FS_ShadowSimple_Binding.Register(app:  0);
            // 0x00A218CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A218D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A218D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A218D8: BL #0x1cec990              | ILRuntime.Runtime.Generated.TweenColor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenColor_Binding.Register(app:  0);
            // 0x00A218DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A218E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A218E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A218E8: BL #0x15e80b0              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_TweenPosition_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_TweenPosition_Binding.Register(app:  0);
            // 0x00A218EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A218F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A218F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A218F8: BL #0x1437a24              | ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.Register(app:  0);
            // 0x00A218FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21900: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21904: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21908: BL #0x194cf98              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Int32_Binding_Enumerator_Int32_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Int32_Binding_Enumerator_Int32_Int32_Binding.Register(app:  0);
            // 0x00A2190C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21910: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21914: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21918: BL #0x1804aac              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_Int32_Binding.Register(app:  0);
            // 0x00A2191C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21920: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21924: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21928: BL #0x19528d8              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_List_1_Int32_Binding_Enumerator_Int32_List_1_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_List_1_Int32_Binding_Enumerator_Int32_List_1_Int32_Binding.Register(app:  0);
            // 0x00A2192C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21930: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21934: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21938: BL #0x180644c              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_List_1_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_Int32_List_1_Int32_Binding.Register(app:  0);
            // 0x00A2193C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21940: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21944: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21948: BL #0x1750fe0              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_GameObject_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_Int32_Dictionary_2_GameObject_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A2194C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21950: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21954: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21958: BL #0x18fa770              | ILRuntime.Runtime.Generated.UIScrollBar_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIScrollBar_Binding.Register(app:  0);
            // 0x00A2195C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21960: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21964: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21968: BL #0x1740c78              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_Int32_Binding_Enumerator_GameObject_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_Int32_Binding_Enumerator_GameObject_Int32_Binding.Register(app:  0);
            // 0x00A2196C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21970: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21974: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21978: BL #0x17ffecc              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_GameObject_Int32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_GameObject_Int32_Binding.Register(app:  0);
            // 0x00A2197C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21980: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21984: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21988: BL #0x294ff28              | ILRuntime.Runtime.Generated.Formula_Binding_PlusAtt_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Formula_Binding_PlusAtt_Binding.Register(app:  0);
            // 0x00A2198C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21990: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21994: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21998: BL #0xcb714c               | ILRuntime.Runtime.Generated.UnityEngine_Animation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Animation_Binding.Register(app:  0);
            // 0x00A2199C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A219A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A219A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A219A8: BL #0xccfd88               | ILRuntime.Runtime.Generated.UnityEngine_AnimationState_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AnimationState_Binding.Register(app:  0);
            // 0x00A219AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A219B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A219B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A219B8: BL #0x15c1984              | ILRuntime.Runtime.Generated.CSLevelDate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSLevelDate_Binding.Register(app:  0);
            // 0x00A219BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A219C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A219C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A219C8: BL #0x15c24f0              | ILRuntime.Runtime.Generated.CSPlayerData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSPlayerData_Binding.Register(app:  0);
            // 0x00A219CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A219D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A219D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A219D8: BL #0x15c6ba0              | ILRuntime.Runtime.Generated.CSProvingGroundData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSProvingGroundData_Binding.Register(app:  0);
            // 0x00A219DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A219E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A219E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A219E8: BL #0x1c1347c              | ILRuntime.Runtime.Generated.CSHeroData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSHeroData_Binding.Register(app:  0);
            // 0x00A219EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A219F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A219F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A219F8: BL #0x15c0b24              | ILRuntime.Runtime.Generated.CSKruunuData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSKruunuData_Binding.Register(app:  0);
            // 0x00A219FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A08: BL #0x1c11e1c              | ILRuntime.Runtime.Generated.CSGuideData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSGuideData_Binding.Register(app:  0);
            // 0x00A21A0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A18: BL #0x1c05b2c              | ILRuntime.Runtime.Generated.CSBossData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSBossData_Binding.Register(app:  0);
            // 0x00A21A1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A28: BL #0x15c8218              | ILRuntime.Runtime.Generated.CSShiliBossData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSShiliBossData_Binding.Register(app:  0);
            // 0x00A21A2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A38: BL #0x1c0b928              | ILRuntime.Runtime.Generated.CSFightforData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSFightforData_Binding.Register(app:  0);
            // 0x00A21A3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A48: BL #0x1c06698              | ILRuntime.Runtime.Generated.CSCampfightData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSCampfightData_Binding.Register(app:  0);
            // 0x00A21A4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A58: BL #0x142ec44              | ILRuntime.Runtime.Generated.CameraHelper_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CameraHelper_Binding.Register(app:  0);
            // 0x00A21A5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A68: BL #0x143439c              | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.Register(app:  0);
            // 0x00A21A6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A78: BL #0x1866188              | ILRuntime.Runtime.Generated.ILUpdate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ILUpdate_Binding.Register(app:  0);
            // 0x00A21A7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A88: BL #0x196b740              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Single_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Single_Binding.Register(app:  0);
            // 0x00A21A8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21A90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21A94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21A98: BL #0x1ccd8b8              | ILRuntime.Runtime.Generated.System_TimeSpan_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_TimeSpan_Binding.Register(app:  0);
            // 0x00A21A9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21AA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21AA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21AA8: BL #0x17ece7c              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_String_Binding_Enumerator_String_String_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_String_Binding_Enumerator_String_String_Binding.Register(app:  0);
            // 0x00A21AAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21AB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21AB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21AB8: BL #0x180cdd4              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_String_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_String_String_Binding.Register(app:  0);
            // 0x00A21ABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21AC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21AC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21AC8: BL #0x157904c              | ILRuntime.Runtime.Generated.UnityEngine_WWWForm_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WWWForm_Binding.Register(app:  0);
            // 0x00A21ACC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21AD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21AD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21AD8: BL #0x1d15734              | ILRuntime.Runtime.Generated.System_Byte_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Byte_Binding.Register(app:  0);
            // 0x00A21ADC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21AE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21AE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21AE8: BL #0x2208cf4              | ILRuntime.Runtime.Generated.System_Decimal_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Decimal_Binding.Register(app:  0);
            // 0x00A21AEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21AF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21AF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21AF8: BL #0x1f433f0              | ILRuntime.Runtime.Generated.System_IO_File_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_IO_File_Binding.Register(app:  0);
            // 0x00A21AFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B08: BL #0x20392d8              | ILRuntime.Runtime.Generated.UnityEngine_Texture2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Texture2D_Binding.Register(app:  0);
            // 0x00A21B0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B18: BL #0x1bf218c              | ILRuntime.Runtime.Generated.UnityEngine_ImageConversion_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ImageConversion_Binding.Register(app:  0);
            // 0x00A21B1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B28: BL #0x1c094b4              | ILRuntime.Runtime.Generated.CSCheckFinishData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CSCheckFinishData_Binding.Register(app:  0);
            // 0x00A21B2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B38: BL #0x181045c              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Action_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_Action_Binding.Register(app:  0);
            // 0x00A21B3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B48: BL #0x124bafc              | ILRuntime.Runtime.Generated.Mihua_Assets_AssetUtil_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Assets_AssetUtil_Binding.Register(app:  0);
            // 0x00A21B4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B58: BL #0x15a3d60              | ILRuntime.Runtime.Generated.LoadingBoardMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.LoadingBoardMgr_Binding.Register(app:  0);
            // 0x00A21B5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B68: BL #0x1cea0d4              | ILRuntime.Runtime.Generated.TimeUpdateVo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TimeUpdateVo_Binding.Register(app:  0);
            // 0x00A21B6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B78: BL #0x1ce8f14              | ILRuntime.Runtime.Generated.TimeUpdateMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TimeUpdateMgr_Binding.Register(app:  0);
            // 0x00A21B7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B88: BL #0x100b880              | ILRuntime.Runtime.Generated.NotifyP_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.NotifyP_Binding.Register(app:  0);
            // 0x00A21B8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21B90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21B94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21B98: BL #0x1673e2c              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_MEventDelegate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_MEventDelegate_Binding.Register(app:  0);
            // 0x00A21B9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21BA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21BA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21BA8: BL #0x12506d0              | ILRuntime.Runtime.Generated.Mihua_MEventDelegate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_MEventDelegate_Binding.Register(app:  0);
            // 0x00A21BAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21BB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21BB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21BB8: BL #0x1250ef8              | ILRuntime.Runtime.Generated.Mihua_MEventDelegate_Binding_RequestDelegate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_MEventDelegate_Binding_RequestDelegate_Binding.Register(app:  0);
            // 0x00A21BBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21BC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21BC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21BC8: BL #0x17f8190              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_ILTypeInstance_Binding_KeyCollection_UInt32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_ILTypeInstance_Binding_KeyCollection_UInt32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A21BCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21BD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21BD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21BD8: BL #0x17f8534              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_ILTypeInstance_Binding_KeyCollection_UInt32_ILTypeInstance_Binding_Enumerator_UInt32_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_ILTypeInstance_Binding_KeyCollection_UInt32_ILTypeInstance_Binding_Enumerator_UInt32_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A21BDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21BE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21BE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21BE8: BL #0x1d001dc              | ILRuntime.Runtime.Generated.System_Action_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Action_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A21BEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21BF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21BF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21BF8: BL #0x17fabd4              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_String_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_UInt32_String_Binding.Register(app:  0);
            // 0x00A21BFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C08: BL #0x195a000              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Action_1_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_String_Action_1_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A21C0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C18: BL #0x1ccd28c              | ILRuntime.Runtime.Generated.System_Threading_Monitor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Threading_Monitor_Binding.Register(app:  0);
            // 0x00A21C1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C28: BL #0x174362c              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UILabel_Binding_Enumerator_GameObject_UILabel_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_GameObject_UILabel_Binding_Enumerator_GameObject_UILabel_Binding.Register(app:  0);
            // 0x00A21C2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C38: BL #0x18009ec              | ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_GameObject_UILabel_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_KeyValuePair_2_GameObject_UILabel_Binding.Register(app:  0);
            // 0x00A21C3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C48: BL #0x15e6ca0              | ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_TeamSkill_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_List_1_TeamSkill_Binding.Register(app:  0);
            // 0x00A21C4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C58: BL #0x1597668              | ILRuntime.Runtime.Generated.VersionTag_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.VersionTag_Binding.Register(app:  0);
            // 0x00A21C5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C68: BL #0x211f750              | ILRuntime.Runtime.Generated.UnityEngine_AndroidJavaClass_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AndroidJavaClass_Binding.Register(app:  0);
            // 0x00A21C6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C78: BL #0x15ad1dc              | ILRuntime.Runtime.Generated.MHFileStream_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.MHFileStream_Binding.Register(app:  0);
            // 0x00A21C7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C88: BL #0xbbe478               | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.Register(app:  0);
            // 0x00A21C8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21C90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21C94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21C98: BL #0x16c8100              | ILRuntime.Runtime.Generated.UIModelDisplayType_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIModelDisplayType_Binding.Register(app:  0);
            // 0x00A21C9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21CA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21CA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21CA8: BL #0x294b59c              | ILRuntime.Runtime.Generated.FLOAT_TEXT_ID_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.FLOAT_TEXT_ID_Binding.Register(app:  0);
            // 0x00A21CAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21CB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21CB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21CB8: BL #0x2957e38              | ILRuntime.Runtime.Generated.FunctionType_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.FunctionType_Binding.Register(app:  0);
            // 0x00A21CBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21CC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21CC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21CC8: BL #0x2949be4              | ILRuntime.Runtime.Generated.FinishPanelType_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.FinishPanelType_Binding.Register(app:  0);
            // 0x00A21CCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21CD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21CD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21CD8: BL #0x143b770              | ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.Register(app:  0);
            // 0x00A21CDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21CE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21CE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21CE8: BL #0x10203a0              | ILRuntime.Runtime.Generated.PanelType_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PanelType_Binding.Register(app:  0);
            // 0x00A21CEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21CF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21CF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21CF8: BL #0xe8d3b8               | ILRuntime.Runtime.Generated.SEX_TYPE_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.SEX_TYPE_Binding.Register(app:  0);
            // 0x00A21CFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D08: BL #0x11b6bfc              | ILRuntime.Runtime.Generated.HERO_COUNTRY_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.HERO_COUNTRY_Binding.Register(app:  0);
            // 0x00A21D0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D18: BL #0x11bc08c              | ILRuntime.Runtime.Generated.HERO_STATE_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.HERO_STATE_Binding.Register(app:  0);
            // 0x00A21D1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D28: BL #0x11bcf18              | ILRuntime.Runtime.Generated.HERO_TYPE_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.HERO_TYPE_Binding.Register(app:  0);
            // 0x00A21D2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D38: BL #0x11ba9e4              | ILRuntime.Runtime.Generated.HERO_LINEUP_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.HERO_LINEUP_Binding.Register(app:  0);
            // 0x00A21D3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D48: BL #0x11b7a84              | ILRuntime.Runtime.Generated.HERO_ELEMENT_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.HERO_ELEMENT_Binding.Register(app:  0);
            // 0x00A21D4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D58: BL #0x11b8c1c              | ILRuntime.Runtime.Generated.HERO_EVOLVE_LEVEL_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.HERO_EVOLVE_LEVEL_Binding.Register(app:  0);
            // 0x00A21D5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D68: BL #0xe993c0               | ILRuntime.Runtime.Generated.SKILL_TYPE_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.SKILL_TYPE_Binding.Register(app:  0);
            // 0x00A21D6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D78: BL #0xbb702c               | ILRuntime.Runtime.Generated.AllUpdate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.AllUpdate_Binding.Register(app:  0);
            // 0x00A21D7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D88: BL #0x159a950              | ILRuntime.Runtime.Generated.IZUpdate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.IZUpdate_Binding.Register(app:  0);
            // 0x00A21D8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21D90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21D94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21D98: BL #0xe849ac               | ILRuntime.Runtime.Generated.ReadFileTool_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ReadFileTool_Binding.Register(app:  0);
            // 0x00A21D9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21DA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21DA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21DA8: BL #0x2213bac              | ILRuntime.Runtime.Generated.System_Guid_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Guid_Binding.Register(app:  0);
            // 0x00A21DAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21DB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21DB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21DB8: BL #0x1025ce4              | ILRuntime.Runtime.Generated.PluginPush_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PluginPush_Binding.Register(app:  0);
            // 0x00A21DBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21DC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21DC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21DC8: BL #0x1024714              | ILRuntime.Runtime.Generated.PluginBugly_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PluginBugly_Binding.Register(app:  0);
            // 0x00A21DCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21DD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21DD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21DD8: BL #0x1030144              | ILRuntime.Runtime.Generated.PluginSjoy_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PluginSjoy_Binding.Register(app:  0);
            // 0x00A21DDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21DE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21DE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21DE8: BL #0x1028ebc              | ILRuntime.Runtime.Generated.PluginReYun_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PluginReYun_Binding.Register(app:  0);
            // 0x00A21DEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21DF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21DF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21DF8: BL #0x1bff5f0              | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.Register(app:  0);
            // 0x00A21DFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E08: BL #0x15cb624              | ILRuntime.Runtime.Generated.EArray_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.EArray_Binding.Register(app:  0);
            // 0x00A21E0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E18: BL #0x15cfb64              | ILRuntime.Runtime.Generated.EList_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.EList_Binding.Register(app:  0);
            // 0x00A21E1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E28: BL #0x15d83a8              | ILRuntime.Runtime.Generated.EventNameMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.EventNameMgr_Binding.Register(app:  0);
            // 0x00A21E2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E38: BL #0xbd561c               | ILRuntime.Runtime.Generated.Boss_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Boss_Binding.Register(app:  0);
            // 0x00A21E3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E48: BL #0x1254070              | ILRuntime.Runtime.Generated.Monster_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Monster_Binding.Register(app:  0);
            // 0x00A21E4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E58: BL #0x18630e0              | ILRuntime.Runtime.Generated.HeroNpc_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.HeroNpc_Binding.Register(app:  0);
            // 0x00A21E5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E68: BL #0x29510e8              | ILRuntime.Runtime.Generated.FriendNpc_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.FriendNpc_Binding.Register(app:  0);
            // 0x00A21E6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E78: BL #0x1021128              | ILRuntime.Runtime.Generated.PlotFightTalkMgr_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PlotFightTalkMgr_Binding.Register(app:  0);
            // 0x00A21E7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E88: BL #0x18656c0              | ILRuntime.Runtime.Generated.ICSData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ICSData_Binding.Register(app:  0);
            // 0x00A21E8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21E90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21E94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21E98: BL #0x1c08ccc              | ILRuntime.Runtime.Generated.CsCfgBase_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.CsCfgBase_Binding.Register(app:  0);
            // 0x00A21E9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21EA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21EA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21EA8: BL #0xe84334               | ILRuntime.Runtime.Generated.ProtoBuf_IExtensible_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ProtoBuf_IExtensible_Binding.Register(app:  0);
            // 0x00A21EAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21EB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21EB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21EB8: BL #0x124a91c              | ILRuntime.Runtime.Generated.Mihua_Asset_LoadedAssetBundle_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Asset_LoadedAssetBundle_Binding.Register(app:  0);
            // 0x00A21EBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21EC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21EC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21EC8: BL #0x15b1d60              | ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_AssetOperationFull_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_AssetOperationFull_Binding.Register(app:  0);
            // 0x00A21ECC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21ED0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21ED4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21ED8: BL #0x15b6550              | ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_ManifestOperation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_ManifestOperation_Binding.Register(app:  0);
            // 0x00A21EDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21EE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21EE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21EE8: BL #0x15b3aac              | ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_AssetOperationLoaded_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_AssetOperationLoaded_Binding.Register(app:  0);
            // 0x00A21EEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21EF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21EF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21EF8: BL #0x15b4ff0              | ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_AssetOperationSimulation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Mihua_Asset_ABLoadOperation_AssetOperationSimulation_Binding.Register(app:  0);
            // 0x00A21EFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F08: BL #0x1bff5e4              | ILRuntime.Runtime.Generated.Component_Extension_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Component_Extension_Binding.Register(app:  0);
            // 0x00A21F0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F18: BL #0x11a21ec              | ILRuntime.Runtime.Generated.GameObject_MonoBehaviour_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.GameObject_MonoBehaviour_Binding.Register(app:  0);
            // 0x00A21F1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F28: BL #0x1cf3914              | ILRuntime.Runtime.Generated.Spin_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Spin_Binding.Register(app:  0);
            // 0x00A21F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F38: BL #0x1ca8198              | ILRuntime.Runtime.Generated.UIInputOnGUI_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIInputOnGUI_Binding.Register(app:  0);
            // 0x00A21F3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F48: BL #0x1766f08              | ILRuntime.Runtime.Generated.UIButtonMessage_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIButtonMessage_Binding.Register(app:  0);
            // 0x00A21F4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F58: BL #0x1c79ca8              | ILRuntime.Runtime.Generated.TweenOrthoSize_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenOrthoSize_Binding.Register(app:  0);
            // 0x00A21F5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F68: BL #0x1787374              | ILRuntime.Runtime.Generated.UIDragResize_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIDragResize_Binding.Register(app:  0);
            // 0x00A21F6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F78: BL #0x193d864              | ILRuntime.Runtime.Generated.UIForwardEvents_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIForwardEvents_Binding.Register(app:  0);
            // 0x00A21F7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F88: BL #0x1c77708              | ILRuntime.Runtime.Generated.TweenHeight_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenHeight_Binding.Register(app:  0);
            // 0x00A21F8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21F90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21F94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21F98: BL #0x14ad870              | ILRuntime.Runtime.Generated.UIToggledComponents_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIToggledComponents_Binding.Register(app:  0);
            // 0x00A21F9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21FA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21FA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21FA8: BL #0x15a9e90              | ILRuntime.Runtime.Generated.Localization_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.Localization_Binding.Register(app:  0);
            // 0x00A21FAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21FB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21FB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21FB8: BL #0x176a8f0              | ILRuntime.Runtime.Generated.UIButtonScale_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIButtonScale_Binding.Register(app:  0);
            // 0x00A21FBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21FC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21FC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21FC8: BL #0x14b79d0              | ILRuntime.Runtime.Generated.UIViewport_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIViewport_Binding.Register(app:  0);
            // 0x00A21FCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21FD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21FD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21FD8: BL #0x1cf653c              | ILRuntime.Runtime.Generated.SpringPosition_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.SpringPosition_Binding.Register(app:  0);
            // 0x00A21FDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21FE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21FE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21FE8: BL #0x178475c              | ILRuntime.Runtime.Generated.UIDragObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIDragObject_Binding.Register(app:  0);
            // 0x00A21FEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A21FF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A21FF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A21FF8: BL #0xbb89c4               | ILRuntime.Runtime.Generated.AnimatedWidget_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.AnimatedWidget_Binding.Register(app:  0);
            // 0x00A21FFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22000: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22004: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22008: BL #0x177cc80              | ILRuntime.Runtime.Generated.UICenterOnClick_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UICenterOnClick_Binding.Register(app:  0);
            // 0x00A2200C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22010: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22014: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22018: BL #0x1c88e4c              | ILRuntime.Runtime.Generated.TypewriterEffect_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TypewriterEffect_Binding.Register(app:  0);
            // 0x00A2201C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22020: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22024: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22028: BL #0x1429ee8              | ILRuntime.Runtime.Generated.ByteReader_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ByteReader_Binding.Register(app:  0);
            // 0x00A2202C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22030: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22034: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22038: BL #0xbcf6b0               | ILRuntime.Runtime.Generated.BMGlyph_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.BMGlyph_Binding.Register(app:  0);
            // 0x00A2203C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22040: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22044: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22048: BL #0x1265dc0              | ILRuntime.Runtime.Generated.NGUIMath_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.NGUIMath_Binding.Register(app:  0);
            // 0x00A2204C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22050: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22054: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22058: BL #0x16df51c              | ILRuntime.Runtime.Generated.UIPlayTween_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIPlayTween_Binding.Register(app:  0);
            // 0x00A2205C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22060: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22064: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22068: BL #0x177f4b8              | ILRuntime.Runtime.Generated.UIDragDropContainer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIDragDropContainer_Binding.Register(app:  0);
            // 0x00A2206C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22070: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22074: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22078: BL #0xe7e77c               | ILRuntime.Runtime.Generated.PropertyReference_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PropertyReference_Binding.Register(app:  0);
            // 0x00A2207C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22080: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22084: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22088: BL #0x17815b8              | ILRuntime.Runtime.Generated.UIDraggableCamera_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIDraggableCamera_Binding.Register(app:  0);
            // 0x00A2208C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22090: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22094: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22098: BL #0x19342e4              | ILRuntime.Runtime.Generated.UIFont_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIFont_Binding.Register(app:  0);
            // 0x00A2209C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A220A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A220A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A220A8: BL #0x1cc18ac              | ILRuntime.Runtime.Generated.UILocalize_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UILocalize_Binding.Register(app:  0);
            // 0x00A220AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A220B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A220B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A220B8: BL #0x19066c4              | ILRuntime.Runtime.Generated.UISnapshotPoint_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UISnapshotPoint_Binding.Register(app:  0);
            // 0x00A220BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A220C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A220C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A220C8: BL #0x19081d0              | ILRuntime.Runtime.Generated.UISoundVolume_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UISoundVolume_Binding.Register(app:  0);
            // 0x00A220CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A220D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A220D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A220D8: BL #0x1cee5b4              | ILRuntime.Runtime.Generated.TweenFOV_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenFOV_Binding.Register(app:  0);
            // 0x00A220DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A220E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A220E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A220E8: BL #0x16daae8              | ILRuntime.Runtime.Generated.UIPlayAnimation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIPlayAnimation_Binding.Register(app:  0);
            // 0x00A220EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A220F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A220F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A220F8: BL #0x177af64              | ILRuntime.Runtime.Generated.UICenterOnChild_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UICenterOnChild_Binding.Register(app:  0);
            // 0x00A220FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22100: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22104: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22108: BL #0xbcb56c               | ILRuntime.Runtime.Generated.BMFont_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.BMFont_Binding.Register(app:  0);
            // 0x00A2210C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22110: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22114: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22118: BL #0x18f5320              | ILRuntime.Runtime.Generated.UIRoot_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIRoot_Binding.Register(app:  0);
            // 0x00A2211C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22120: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22124: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22128: BL #0x18f977c              | ILRuntime.Runtime.Generated.UISavedOption_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UISavedOption_Binding.Register(app:  0);
            // 0x00A2212C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22130: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22134: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22138: BL #0x1c868ac              | ILRuntime.Runtime.Generated.TweenWidth_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenWidth_Binding.Register(app:  0);
            // 0x00A2213C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22140: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22144: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22148: BL #0xe7cd74               | ILRuntime.Runtime.Generated.PropertyBinding_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.PropertyBinding_Binding.Register(app:  0);
            // 0x00A2214C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22150: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22154: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22158: BL #0x192f924              | ILRuntime.Runtime.Generated.UIEventTrigger_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIEventTrigger_Binding.Register(app:  0);
            // 0x00A2215C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22160: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22164: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22168: BL #0x191ff00              | ILRuntime.Runtime.Generated.UIDrawCall_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIDrawCall_Binding.Register(app:  0);
            // 0x00A2216C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22170: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22174: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22178: BL #0x14ca234              | ILRuntime.Runtime.Generated.UIWidgetContainer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIWidgetContainer_Binding.Register(app:  0);
            // 0x00A2217C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22180: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22184: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22188: BL #0x14af4f8              | ILRuntime.Runtime.Generated.UITooltip_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UITooltip_Binding.Register(app:  0);
            // 0x00A2218C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22190: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22194: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22198: BL #0x16ddf0c              | ILRuntime.Runtime.Generated.UIPlaySound_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIPlaySound_Binding.Register(app:  0);
            // 0x00A2219C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A221A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A221A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A221A8: BL #0x1c82aec              | ILRuntime.Runtime.Generated.TweenTransform_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenTransform_Binding.Register(app:  0);
            // 0x00A221AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A221B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A221B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A221B8: BL #0x16e2a34              | ILRuntime.Runtime.Generated.UIPopupList_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIPopupList_Binding.Register(app:  0);
            // 0x00A221BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A221C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A221C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A221C8: BL #0xbb8228               | ILRuntime.Runtime.Generated.AnimatedColor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.AnimatedColor_Binding.Register(app:  0);
            // 0x00A221CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A221D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A221D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A221D8: BL #0xbd2e1c               | ILRuntime.Runtime.Generated.BMSymbol_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.BMSymbol_Binding.Register(app:  0);
            // 0x00A221DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A221E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A221E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A221E8: BL #0x1264c48              | ILRuntime.Runtime.Generated.NGUIDebug_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.NGUIDebug_Binding.Register(app:  0);
            // 0x00A221EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A221F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A221F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A221F8: BL #0x1780fd0              | ILRuntime.Runtime.Generated.UIDragDropRoot_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIDragDropRoot_Binding.Register(app:  0);
            // 0x00A221FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22200: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22204: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22208: BL #0x1769580              | ILRuntime.Runtime.Generated.UIButtonRotation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIButtonRotation_Binding.Register(app:  0);
            // 0x00A2220C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22210: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22214: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22218: BL #0x177d030              | ILRuntime.Runtime.Generated.UIColorPicker_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIColorPicker_Binding.Register(app:  0);
            // 0x00A2221C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22220: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22224: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22228: BL #0x14ca5e4              | ILRuntime.Runtime.Generated.UIWrapContent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIWrapContent_Binding.Register(app:  0);
            // 0x00A2222C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22230: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22234: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22238: BL #0x1768210              | ILRuntime.Runtime.Generated.UIButtonOffset_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIButtonOffset_Binding.Register(app:  0);
            // 0x00A2223C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22240: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22244: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22248: BL #0xfe8c48               | ILRuntime.Runtime.Generated.NGUIText_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.NGUIText_Binding.Register(app:  0);
            // 0x00A2224C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22250: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22254: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22258: BL #0x16c8d80              | ILRuntime.Runtime.Generated.UIOrthoCamera_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIOrthoCamera_Binding.Register(app:  0);
            // 0x00A2225C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22260: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22264: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22268: BL #0x17611e4              | ILRuntime.Runtime.Generated.UIButtonActivate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIButtonActivate_Binding.Register(app:  0);
            // 0x00A2226C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22270: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22274: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22278: BL #0x1c84864              | ILRuntime.Runtime.Generated.TweenVolume_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TweenVolume_Binding.Register(app:  0);
            // 0x00A2227C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22280: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22284: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22288: BL #0x1ca94bc              | ILRuntime.Runtime.Generated.UIKeyNavigation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIKeyNavigation_Binding.Register(app:  0);
            // 0x00A2228C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22290: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22294: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22298: BL #0x1765558              | ILRuntime.Runtime.Generated.UIButtonKeys_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIButtonKeys_Binding.Register(app:  0);
            // 0x00A2229C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A222A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A222A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A222A8: BL #0x14ae6b4              | ILRuntime.Runtime.Generated.UIToggledObjects_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIToggledObjects_Binding.Register(app:  0);
            // 0x00A222AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A222B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A222B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A222B8: BL #0x1940320              | ILRuntime.Runtime.Generated.UIGeometry_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIGeometry_Binding.Register(app:  0);
            // 0x00A222BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A222C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A222C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A222C8: BL #0x1918aa0              | ILRuntime.Runtime.Generated.UITextList_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UITextList_Binding.Register(app:  0);
            // 0x00A222CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A222D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A222D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A222D8: BL #0xbb7a8c               | ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.Register(app:  0);
            // 0x00A222DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A222E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A222E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A222E8: BL #0x1913b1c              | ILRuntime.Runtime.Generated.UIStretch_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIStretch_Binding.Register(app:  0);
            // 0x00A222EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A222F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A222F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A222F8: BL #0x177fc44              | ILRuntime.Runtime.Generated.UIDragDropItem_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIDragDropItem_Binding.Register(app:  0);
            // 0x00A222FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22300: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22304: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22308: BL #0x1ca8548              | ILRuntime.Runtime.Generated.UIKeyBinding_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIKeyBinding_Binding.Register(app:  0);
            // 0x00A2230C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22310: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22314: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22318: BL #0x159e944              | ILRuntime.Runtime.Generated.LanguageSelection_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.LanguageSelection_Binding.Register(app:  0);
            // 0x00A2231C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22320: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22324: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22328: BL #0x177ed2c              | ILRuntime.Runtime.Generated.UIDragCamera_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIDragCamera_Binding.Register(app:  0);
            // 0x00A2232C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22330: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22334: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22338: BL #0x1906314              | ILRuntime.Runtime.Generated.UISlider_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UISlider_Binding.Register(app:  0);
            // 0x00A2233C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22340: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22344: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22348: BL #0x28f9e78              | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.Register(app:  0);
            // 0x00A2234C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22350: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22354: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22358: BL #0x1c8b854              | ILRuntime.Runtime.Generated.UI2DSprite_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UI2DSprite_Binding.Register(app:  0);
            // 0x00A2235C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22360: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22364: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22368: BL #0x1948d04              | ILRuntime.Runtime.Generated.UIImageButton_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UIImageButton_Binding.Register(app:  0);
            // 0x00A2236C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22370: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22374: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22378: BL #0x1c8f580              | ILRuntime.Runtime.Generated.UI2DSpriteAnimation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UI2DSpriteAnimation_Binding.Register(app:  0);
            // 0x00A2237C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22380: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22384: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22388: BL #0xe85770               | ILRuntime.Runtime.Generated.RealTime_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.RealTime_Binding.Register(app:  0);
            // 0x00A2238C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22390: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22394: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22398: BL #0x22038c4              | ILRuntime.Runtime.Generated.UnityEngine_RectTransform_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_RectTransform_Binding.Register(app:  0);
            // 0x00A2239C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A223A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A223A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A223A8: BL #0x200e064              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_EventTrigger_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_EventTrigger_Binding.Register(app:  0);
            // 0x00A223AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A223B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A223B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A223B8: BL #0x1ce550c              | ILRuntime.Runtime.Generated.TimedEffect_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.TimedEffect_Binding.Register(app:  0);
            // 0x00A223BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A223C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A223C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A223C8: BL #0x1a2c8c8              | ILRuntime.Runtime.Generated.System_Random_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Random_Binding.Register(app:  0);
            // 0x00A223CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A223D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A223D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A223D8: BL #0x1e81a38              | ILRuntime.Runtime.Generated.UnityEngine_RectTransformUtility_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_RectTransformUtility_Binding.Register(app:  0);
            // 0x00A223DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A223E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A223E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A223E8: BL #0x1f54178              | ILRuntime.Runtime.Generated.System_IO_Path_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_IO_Path_Binding.Register(app:  0);
            // 0x00A223EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A223F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A223F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A223F8: BL #0x2229380              | ILRuntime.Runtime.Generated.System_IO_Directory_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_IO_Directory_Binding.Register(app:  0);
            // 0x00A223FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22400: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22404: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22408: BL #0x1f3f038              | ILRuntime.Runtime.Generated.System_IO_DirectoryInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_IO_DirectoryInfo_Binding.Register(app:  0);
            // 0x00A2240C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22410: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22414: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22418: BL #0x1f4f608              | ILRuntime.Runtime.Generated.System_IO_FileSystemInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_IO_FileSystemInfo_Binding.Register(app:  0);
            // 0x00A2241C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22420: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22424: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22428: BL #0x1f5731c              | ILRuntime.Runtime.Generated.System_MarshalByRefObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_MarshalByRefObject_Binding.Register(app:  0);
            // 0x00A2242C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22430: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22434: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22438: BL #0x1bf1a20              | ILRuntime.Runtime.Generated.UnityEngine_ICanvasRaycastFilter_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ICanvasRaycastFilter_Binding.Register(app:  0);
            // 0x00A2243C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22440: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22444: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22448: BL #0x1eca704              | ILRuntime.Runtime.Generated.UnityEngine_CanvasGroup_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_CanvasGroup_Binding.Register(app:  0);
            // 0x00A2244C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22450: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22454: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22458: BL #0x15f9690              | ILRuntime.Runtime.Generated.System_Collections_IEnumerator_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_IEnumerator_Binding.Register(app:  0);
            // 0x00A2245C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22460: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22464: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22468: BL #0x1cc85c0              | ILRuntime.Runtime.Generated.System_Text_UTF8Encoding_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Text_UTF8Encoding_Binding.Register(app:  0);
            // 0x00A2246C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22470: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22474: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22478: BL #0x2305850              | ILRuntime.Runtime.Generated.System_Text_Encoder_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Text_Encoder_Binding.Register(app:  0);
            // 0x00A2247C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22480: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22484: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22488: BL #0x2300ee8              | ILRuntime.Runtime.Generated.System_Text_Decoder_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Text_Decoder_Binding.Register(app:  0);
            // 0x00A2248C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22490: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22494: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22498: BL #0x2219a28              | ILRuntime.Runtime.Generated.System_IConvertible_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_IConvertible_Binding.Register(app:  0);
            // 0x00A2249C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A224A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A224A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A224A8: BL #0x15f7eac              | ILRuntime.Runtime.Generated.System_Collections_ICollection_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_ICollection_Binding.Register(app:  0);
            // 0x00A224AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A224B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A224B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A224B8: BL #0x1a31b38              | ILRuntime.Runtime.Generated.System_Runtime_Serialization_ISerializable_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Runtime_Serialization_ISerializable_Binding.Register(app:  0);
            // 0x00A224BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A224C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A224C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A224C8: BL #0x1a2e0dc              | ILRuntime.Runtime.Generated.System_Runtime_InteropServices__Exception_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Runtime_InteropServices__Exception_Binding.Register(app:  0);
            // 0x00A224CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A224D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A224D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A224D8: BL #0x1a32250              | ILRuntime.Runtime.Generated.System_Runtime_Serialization_ISurrogateSelector_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Runtime_Serialization_ISurrogateSelector_Binding.Register(app:  0);
            // 0x00A224DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A224E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A224E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A224E8: BL #0x1bf98dc              | ILRuntime.Runtime.Generated.UnityEngine_ISerializationCallbackReceiver_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ISerializationCallbackReceiver_Binding.Register(app:  0);
            // 0x00A224EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A224F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A224F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A224F8: BL #0x2219430              | ILRuntime.Runtime.Generated.System_ICloneable_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_ICloneable_Binding.Register(app:  0);
            // 0x00A224FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22500: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22504: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22508: BL #0x15f909c              | ILRuntime.Runtime.Generated.System_Collections_IEnumerable_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_IEnumerable_Binding.Register(app:  0);
            // 0x00A2250C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22510: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22514: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22518: BL #0x1ef3f44              | ILRuntime.Runtime.Generated.UnityEngine_Security_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Security_Binding.Register(app:  0);
            // 0x00A2251C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22520: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22524: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22528: BL #0x1d95d0c              | ILRuntime.Runtime.Generated.UnityEngine_UnityException_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_UnityException_Binding.Register(app:  0);
            // 0x00A2252C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22530: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22534: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22538: BL #0x17a67c8              | ILRuntime.Runtime.Generated.UnityEngine_MissingComponentException_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_MissingComponentException_Binding.Register(app:  0);
            // 0x00A2253C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22540: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22544: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22548: BL #0x1d95160              | ILRuntime.Runtime.Generated.UnityEngine_UnassignedReferenceException_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_UnassignedReferenceException_Binding.Register(app:  0);
            // 0x00A2254C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22550: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22554: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22558: BL #0x17a7374              | ILRuntime.Runtime.Generated.UnityEngine_MissingReferenceException_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_MissingReferenceException_Binding.Register(app:  0);
            // 0x00A2255C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22560: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22564: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22568: BL #0x14749a0              | ILRuntime.Runtime.Generated.UnityEngine_TextEditor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TextEditor_Binding.Register(app:  0);
            // 0x00A2256C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22570: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22574: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22578: BL #0x20293e4              | ILRuntime.Runtime.Generated.UnityEngine_TextGenerator_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TextGenerator_Binding.Register(app:  0);
            // 0x00A2257C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22580: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22584: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22588: BL #0x1fe5350              | ILRuntime.Runtime.Generated.UnityEngine_TrackedReference_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TrackedReference_Binding.Register(app:  0);
            // 0x00A2258C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22590: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22594: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22598: BL #0x1ef42f4              | ILRuntime.Runtime.Generated.UnityEngine_Serialization_UnitySurrogateSelector_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Serialization_UnitySurrogateSelector_Binding.Register(app:  0);
            // 0x00A2259C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A225A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A225A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A225A8: BL #0xf416bc               | ILRuntime.Runtime.Generated.UnityEngine_Physics_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Physics_Binding.Register(app:  0);
            // 0x00A225AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A225B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A225B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A225B8: BL #0x1816644              | ILRuntime.Runtime.Generated.UnityEngine_Rigidbody_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Rigidbody_Binding.Register(app:  0);
            // 0x00A225BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A225C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A225C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A225C8: BL #0x1bfa0a4              | ILRuntime.Runtime.Generated.UnityEngine_Joint_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Joint_Binding.Register(app:  0);
            // 0x00A225CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A225D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A225D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A225D8: BL #0x1be06dc              | ILRuntime.Runtime.Generated.UnityEngine_HingeJoint_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_HingeJoint_Binding.Register(app:  0);
            // 0x00A225DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A225E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A225E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A225E8: BL #0x145ca8c              | ILRuntime.Runtime.Generated.UnityEngine_SpringJoint_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SpringJoint_Binding.Register(app:  0);
            // 0x00A225EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A225F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A225F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A225F8: BL #0x10a0d90              | ILRuntime.Runtime.Generated.UnityEngine_FixedJoint_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_FixedJoint_Binding.Register(app:  0);
            // 0x00A225FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22600: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22604: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22608: BL #0x1eda648              | ILRuntime.Runtime.Generated.UnityEngine_CharacterJoint_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_CharacterJoint_Binding.Register(app:  0);
            // 0x00A2260C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22610: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22614: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22618: BL #0x20e57c4              | ILRuntime.Runtime.Generated.UnityEngine_ConfigurableJoint_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ConfigurableJoint_Binding.Register(app:  0);
            // 0x00A2261C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22620: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22624: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22628: BL #0x20f3514              | ILRuntime.Runtime.Generated.UnityEngine_ConstantForce_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ConstantForce_Binding.Register(app:  0);
            // 0x00A2262C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22630: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22634: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22638: BL #0x1f136e4              | ILRuntime.Runtime.Generated.UnityEngine_SphereCollider_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SphereCollider_Binding.Register(app:  0);
            // 0x00A2263C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22640: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22644: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22648: BL #0x17a0284              | ILRuntime.Runtime.Generated.UnityEngine_MeshCollider_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_MeshCollider_Binding.Register(app:  0);
            // 0x00A2264C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22650: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22654: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22658: BL #0x1ecca2c              | ILRuntime.Runtime.Generated.UnityEngine_CapsuleCollider_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_CapsuleCollider_Binding.Register(app:  0);
            // 0x00A2265C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22660: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22664: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22668: BL #0x20a5074              | ILRuntime.Runtime.Generated.UnityEngine_WheelCollider_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WheelCollider_Binding.Register(app:  0);
            // 0x00A2266C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22670: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22674: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22678: BL #0xf3ee90               | ILRuntime.Runtime.Generated.UnityEngine_PhysicMaterial_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_PhysicMaterial_Binding.Register(app:  0);
            // 0x00A2267C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22680: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22684: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22688: BL #0xc2c680               | ILRuntime.Runtime.Generated.UnityEngine_Collision_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Collision_Binding.Register(app:  0);
            // 0x00A2268C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22690: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22694: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22698: BL #0x20fa66c              | ILRuntime.Runtime.Generated.UnityEngine_ControllerColliderHit_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ControllerColliderHit_Binding.Register(app:  0);
            // 0x00A2269C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A226A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A226A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A226A8: BL #0x1ece820              | ILRuntime.Runtime.Generated.UnityEngine_CharacterController_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_CharacterController_Binding.Register(app:  0);
            // 0x00A226AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A226B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A226B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A226B8: BL #0x1edf930              | ILRuntime.Runtime.Generated.UnityEngine_Cloth_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Cloth_Binding.Register(app:  0);
            // 0x00A226BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A226C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A226C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A226C8: BL #0x1473590              | ILRuntime.Runtime.Generated.UnityEngine_TerrainCollider_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TerrainCollider_Binding.Register(app:  0);
            // 0x00A226CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A226D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A226D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A226D8: BL #0xd21e40               | ILRuntime.Runtime.Generated.UnityEngine_Physics2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Physics2D_Binding.Register(app:  0);
            // 0x00A226DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A226E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A226E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A226E8: BL #0x182d2a4              | ILRuntime.Runtime.Generated.UnityEngine_Rigidbody2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Rigidbody2D_Binding.Register(app:  0);
            // 0x00A226EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A226F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A226F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A226F8: BL #0xc1f100               | ILRuntime.Runtime.Generated.UnityEngine_Collider2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Collider2D_Binding.Register(app:  0);
            // 0x00A226FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22700: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22704: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22708: BL #0x1edef1c              | ILRuntime.Runtime.Generated.UnityEngine_CircleCollider2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_CircleCollider2D_Binding.Register(app:  0);
            // 0x00A2270C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22710: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22714: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22718: BL #0x12032e4              | ILRuntime.Runtime.Generated.UnityEngine_BoxCollider2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_BoxCollider2D_Binding.Register(app:  0);
            // 0x00A2271C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22720: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22724: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22728: BL #0x229e0cc              | ILRuntime.Runtime.Generated.UnityEngine_EdgeCollider2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EdgeCollider2D_Binding.Register(app:  0);
            // 0x00A2272C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22730: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22734: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22738: BL #0x1b331f0              | ILRuntime.Runtime.Generated.UnityEngine_PolygonCollider2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_PolygonCollider2D_Binding.Register(app:  0);
            // 0x00A2273C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22740: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22744: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22748: BL #0xc2e5a0               | ILRuntime.Runtime.Generated.UnityEngine_Collision2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Collision2D_Binding.Register(app:  0);
            // 0x00A2274C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22750: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22754: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22758: BL #0x204876c              | ILRuntime.Runtime.Generated.UnityEngine_Joint2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Joint2D_Binding.Register(app:  0);
            // 0x00A2275C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22760: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22764: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22768: BL #0x211d478              | ILRuntime.Runtime.Generated.UnityEngine_AnchoredJoint2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AnchoredJoint2D_Binding.Register(app:  0);
            // 0x00A2276C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22770: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22774: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22778: BL #0x145edf8              | ILRuntime.Runtime.Generated.UnityEngine_SpringJoint2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SpringJoint2D_Binding.Register(app:  0);
            // 0x00A2277C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22780: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22784: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22788: BL #0x229c9c8              | ILRuntime.Runtime.Generated.UnityEngine_DistanceJoint2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_DistanceJoint2D_Binding.Register(app:  0);
            // 0x00A2278C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22790: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22794: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22798: BL #0x1be3980              | ILRuntime.Runtime.Generated.UnityEngine_HingeJoint2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_HingeJoint2D_Binding.Register(app:  0);
            // 0x00A2279C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A227A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A227A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A227A8: BL #0x1f0a4bc              | ILRuntime.Runtime.Generated.UnityEngine_SliderJoint2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SliderJoint2D_Binding.Register(app:  0);
            // 0x00A227AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A227B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A227B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A227B8: BL #0x20b4af8              | ILRuntime.Runtime.Generated.UnityEngine_WheelJoint2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WheelJoint2D_Binding.Register(app:  0);
            // 0x00A227BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A227C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A227C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A227C8: BL #0x1b28018              | ILRuntime.Runtime.Generated.UnityEngine_PhysicsMaterial2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_PhysicsMaterial2D_Binding.Register(app:  0);
            // 0x00A227CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A227D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A227D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A227D8: BL #0x20fd4c0              | ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshAgent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshAgent_Binding.Register(app:  0);
            // 0x00A227DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A227E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A227E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A227E8: BL #0x14cd64c              | ILRuntime.Runtime.Generated.UnityEngine_AI_NavMesh_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AI_NavMesh_Binding.Register(app:  0);
            // 0x00A227EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A227F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A227F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A227F8: BL #0x2117b4c              | ILRuntime.Runtime.Generated.UnityEngine_AI_OffMeshLink_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AI_OffMeshLink_Binding.Register(app:  0);
            // 0x00A227FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22800: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22804: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22808: BL #0x21157dc              | ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshPath_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshPath_Binding.Register(app:  0);
            // 0x00A2280C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22810: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22814: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22818: BL #0x211114c              | ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshObstacle_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshObstacle_Binding.Register(app:  0);
            // 0x00A2281C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22820: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22824: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22828: BL #0x1d2e78c              | ILRuntime.Runtime.Generated.UnityEngine_AudioSettings_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioSettings_Binding.Register(app:  0);
            // 0x00A2282C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22830: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22834: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22838: BL #0x208cabc              | ILRuntime.Runtime.Generated.UnityEngine_AudioClip_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioClip_Binding.Register(app:  0);
            // 0x00A2283C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22840: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22844: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22848: BL #0x1d1e8b8              | ILRuntime.Runtime.Generated.UnityEngine_AudioListener_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioListener_Binding.Register(app:  0);
            // 0x00A2284C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22850: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22854: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22858: BL #0x1d30b84              | ILRuntime.Runtime.Generated.UnityEngine_AudioSource_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioSource_Binding.Register(app:  0);
            // 0x00A2285C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22860: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22864: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22868: BL #0x1d27dd4              | ILRuntime.Runtime.Generated.UnityEngine_AudioReverbZone_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioReverbZone_Binding.Register(app:  0);
            // 0x00A2286C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22870: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22874: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22878: BL #0x1d20310              | ILRuntime.Runtime.Generated.UnityEngine_AudioLowPassFilter_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioLowPassFilter_Binding.Register(app:  0);
            // 0x00A2287C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22880: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22884: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22888: BL #0x1d1d848              | ILRuntime.Runtime.Generated.UnityEngine_AudioHighPassFilter_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioHighPassFilter_Binding.Register(app:  0);
            // 0x00A2288C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22894: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22898: BL #0x1d1b11c              | ILRuntime.Runtime.Generated.UnityEngine_AudioDistortionFilter_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioDistortionFilter_Binding.Register(app:  0);
            // 0x00A2289C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A228A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A228A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A228A8: BL #0x1d1bb30              | ILRuntime.Runtime.Generated.UnityEngine_AudioEchoFilter_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioEchoFilter_Binding.Register(app:  0);
            // 0x00A228AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A228B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A228B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A228B8: BL #0x2089aa8              | ILRuntime.Runtime.Generated.UnityEngine_AudioChorusFilter_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioChorusFilter_Binding.Register(app:  0);
            // 0x00A228BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A228C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A228C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A228C8: BL #0x1d21a64              | ILRuntime.Runtime.Generated.UnityEngine_AudioReverbFilter_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AudioReverbFilter_Binding.Register(app:  0);
            // 0x00A228CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A228D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A228D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A228D8: BL #0x17a43d0              | ILRuntime.Runtime.Generated.UnityEngine_Microphone_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Microphone_Binding.Register(app:  0);
            // 0x00A228DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A228E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A228E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A228E8: BL #0x209f87c              | ILRuntime.Runtime.Generated.UnityEngine_WebCamTexture_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WebCamTexture_Binding.Register(app:  0);
            // 0x00A228EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A228F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A228F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A228F8: BL #0xccbadc               | ILRuntime.Runtime.Generated.UnityEngine_AnimationEvent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AnimationEvent_Binding.Register(app:  0);
            // 0x00A228FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22900: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22904: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22908: BL #0xcc7624               | ILRuntime.Runtime.Generated.UnityEngine_AnimationCurve_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AnimationCurve_Binding.Register(app:  0);
            // 0x00A2290C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22910: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22914: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22918: BL #0x11f3144              | ILRuntime.Runtime.Generated.UnityEngine_AvatarBuilder_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AvatarBuilder_Binding.Register(app:  0);
            // 0x00A2291C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22920: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22924: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22928: BL #0x206eab8              | ILRuntime.Runtime.Generated.UnityEngine_AnimatorOverrideController_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AnimatorOverrideController_Binding.Register(app:  0);
            // 0x00A2292C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22930: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22934: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22938: BL #0x11f29b0              | ILRuntime.Runtime.Generated.UnityEngine_Avatar_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Avatar_Binding.Register(app:  0);
            // 0x00A2293C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22940: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22944: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22948: BL #0x1bf01d4              | ILRuntime.Runtime.Generated.UnityEngine_HumanTrait_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_HumanTrait_Binding.Register(app:  0);
            // 0x00A2294C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22950: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22954: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22958: BL #0x1d8f4dc              | ILRuntime.Runtime.Generated.UnityEngine_TreePrototype_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TreePrototype_Binding.Register(app:  0);
            // 0x00A2295C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22960: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22964: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22968: BL #0x22948c4              | ILRuntime.Runtime.Generated.UnityEngine_DetailPrototype_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_DetailPrototype_Binding.Register(app:  0);
            // 0x00A2296C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22970: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22974: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22978: BL #0x1459700              | ILRuntime.Runtime.Generated.UnityEngine_SplatPrototype_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SplatPrototype_Binding.Register(app:  0);
            // 0x00A2297C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22980: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22984: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22988: BL #0x2087254              | ILRuntime.Runtime.Generated.UnityEngine_AssetBundleCreateRequest_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AssetBundleCreateRequest_Binding.Register(app:  0);
            // 0x00A2298C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22990: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22994: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22998: BL #0x20878dc              | ILRuntime.Runtime.Generated.UnityEngine_AssetBundleRequest_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AssetBundleRequest_Binding.Register(app:  0);
            // 0x00A2299C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A229A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A229A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A229A8: BL #0x207ce64              | ILRuntime.Runtime.Generated.UnityEngine_AssetBundle_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AssetBundle_Binding.Register(app:  0);
            // 0x00A229AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A229B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A229B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A229B8: BL #0x209e194              | ILRuntime.Runtime.Generated.UnityEngine_WaitForFixedUpdate_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WaitForFixedUpdate_Binding.Register(app:  0);
            // 0x00A229BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A229C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A229C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A229C8: BL #0x209dde4              | ILRuntime.Runtime.Generated.UnityEngine_WaitForEndOfFrame_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WaitForEndOfFrame_Binding.Register(app:  0);
            // 0x00A229CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A229D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A229D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A229D8: BL #0x20fc770              | ILRuntime.Runtime.Generated.UnityEngine_Coroutine_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Coroutine_Binding.Register(app:  0);
            // 0x00A229DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A229E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A229E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A229E8: BL #0x1ef3270              | ILRuntime.Runtime.Generated.UnityEngine_ScriptableObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ScriptableObject_Binding.Register(app:  0);
            // 0x00A229EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A229F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A229F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A229F8: BL #0x1b36288              | ILRuntime.Runtime.Generated.UnityEngine_Profiling_Profiler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Profiling_Profiler_Binding.Register(app:  0);
            // 0x00A229FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A08: BL #0x20fc8dc              | ILRuntime.Runtime.Generated.UnityEngine_CrashReport_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_CrashReport_Binding.Register(app:  0);
            // 0x00A22A0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A18: BL #0x2288a28              | ILRuntime.Runtime.Generated.UnityEngine_Cursor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Cursor_Binding.Register(app:  0);
            // 0x00A22A1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A28: BL #0x19903e0              | ILRuntime.Runtime.Generated.UnityEngine_OcclusionArea_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_OcclusionArea_Binding.Register(app:  0);
            // 0x00A22A2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A38: BL #0x19915f0              | ILRuntime.Runtime.Generated.UnityEngine_OcclusionPortal_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_OcclusionPortal_Binding.Register(app:  0);
            // 0x00A22A3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A48: BL #0x1e91f8c              | ILRuntime.Runtime.Generated.UnityEngine_RenderSettings_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_RenderSettings_Binding.Register(app:  0);
            // 0x00A22A4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A58: BL #0x1b3ca94              | ILRuntime.Runtime.Generated.UnityEngine_QualitySettings_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_QualitySettings_Binding.Register(app:  0);
            // 0x00A22A5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A68: BL #0x17a277c              | ILRuntime.Runtime.Generated.UnityEngine_MeshFilter_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_MeshFilter_Binding.Register(app:  0);
            // 0x00A22A6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A78: BL #0x1788e9c              | ILRuntime.Runtime.Generated.UnityEngine_Mesh_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Mesh_Binding.Register(app:  0);
            // 0x00A22A7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A88: BL #0x1f05064              | ILRuntime.Runtime.Generated.UnityEngine_SkinnedMeshRenderer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SkinnedMeshRenderer_Binding.Register(app:  0);
            // 0x00A22A8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22A90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22A94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22A98: BL #0x10a1140              | ILRuntime.Runtime.Generated.UnityEngine_Flare_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Flare_Binding.Register(app:  0);
            // 0x00A22A9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22AA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22AA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22AA8: BL #0x205f658              | ILRuntime.Runtime.Generated.UnityEngine_LensFlare_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LensFlare_Binding.Register(app:  0);
            // 0x00A22AAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22AB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22AB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22AB8: BL #0x1b39214              | ILRuntime.Runtime.Generated.UnityEngine_Projector_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Projector_Binding.Register(app:  0);
            // 0x00A22ABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22AC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22AC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22AC8: BL #0x1f09308              | ILRuntime.Runtime.Generated.UnityEngine_Skybox_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Skybox_Binding.Register(app:  0);
            // 0x00A22ACC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22AD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22AD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22AD8: BL #0x202e7c8              | ILRuntime.Runtime.Generated.UnityEngine_TextMesh_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TextMesh_Binding.Register(app:  0);
            // 0x00A22ADC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22AE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22AE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22AE8: BL #0x13d18c8              | ILRuntime.Runtime.Generated.UnityEngine_LineRenderer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LineRenderer_Binding.Register(app:  0);
            // 0x00A22AEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22AF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22AF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22AF8: BL #0x1a7ea50              | ILRuntime.Runtime.Generated.UnityEngine_MaterialPropertyBlock_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_MaterialPropertyBlock_Binding.Register(app:  0);
            // 0x00A22AFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B08: BL #0x10683fc              | ILRuntime.Runtime.Generated.UnityEngine_Graphics_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Graphics_Binding.Register(app:  0);
            // 0x00A22B0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B18: BL #0x206c1ec              | ILRuntime.Runtime.Generated.UnityEngine_LightmapData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LightmapData_Binding.Register(app:  0);
            // 0x00A22B1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B28: BL #0x13cf754              | ILRuntime.Runtime.Generated.UnityEngine_LightProbes_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LightProbes_Binding.Register(app:  0);
            // 0x00A22B2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B38: BL #0x13cdb20              | ILRuntime.Runtime.Generated.UnityEngine_LightmapSettings_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LightmapSettings_Binding.Register(app:  0);
            // 0x00A22B3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B48: BL #0x1050034              | ILRuntime.Runtime.Generated.UnityEngine_GeometryUtility_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GeometryUtility_Binding.Register(app:  0);
            // 0x00A22B4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B58: BL #0x1f09f04              | ILRuntime.Runtime.Generated.UnityEngine_SleepTimeout_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SleepTimeout_Binding.Register(app:  0);
            // 0x00A22B5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B68: BL #0x105db80              | ILRuntime.Runtime.Generated.UnityEngine_GL_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GL_Binding.Register(app:  0);
            // 0x00A22B6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B78: BL #0x17a38fc              | ILRuntime.Runtime.Generated.UnityEngine_MeshRenderer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_MeshRenderer_Binding.Register(app:  0);
            // 0x00A22B7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B88: BL #0x146d300              | ILRuntime.Runtime.Generated.UnityEngine_StaticBatchingUtility_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_StaticBatchingUtility_Binding.Register(app:  0);
            // 0x00A22B8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22B90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22B94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22B98: BL #0x2033bdc              | ILRuntime.Runtime.Generated.UnityEngine_Texture_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Texture_Binding.Register(app:  0);
            // 0x00A22B9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22BA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22BA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22BA8: BL #0x2284e20              | ILRuntime.Runtime.Generated.UnityEngine_Cubemap_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Cubemap_Binding.Register(app:  0);
            // 0x00A22BAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22BB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22BB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22BB8: BL #0x2042d60              | ILRuntime.Runtime.Generated.UnityEngine_Texture3D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Texture3D_Binding.Register(app:  0);
            // 0x00A22BBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22BC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22BC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22BC8: BL #0x1f11290              | ILRuntime.Runtime.Generated.UnityEngine_SparseTexture_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SparseTexture_Binding.Register(app:  0);
            // 0x00A22BCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22BD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22BD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22BD8: BL #0x1e987a4              | ILRuntime.Runtime.Generated.UnityEngine_RenderTexture_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_RenderTexture_Binding.Register(app:  0);
            // 0x00A22BDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22BE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22BE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22BE8: BL #0x22ada4c              | ILRuntime.Runtime.Generated.UnityEngine_GUIElement_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUIElement_Binding.Register(app:  0);
            // 0x00A22BEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22BF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22BF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22BF8: BL #0x10a14f0              | ILRuntime.Runtime.Generated.UnityEngine_Font_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Font_Binding.Register(app:  0);
            // 0x00A22BFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C08: BL #0x13de3a4              | ILRuntime.Runtime.Generated.UnityEngine_LODGroup_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LODGroup_Binding.Register(app:  0);
            // 0x00A22C0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C18: BL #0x1063a6c              | ILRuntime.Runtime.Generated.UnityEngine_Gradient_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Gradient_Binding.Register(app:  0);
            // 0x00A22C1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C28: BL #0x216ce50              | ILRuntime.Runtime.Generated.UnityEngine_GUI_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUI_Binding.Register(app:  0);
            // 0x00A22C2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C38: BL #0x22af010              | ILRuntime.Runtime.Generated.UnityEngine_GUILayout_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUILayout_Binding.Register(app:  0);
            // 0x00A22C3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C48: BL #0x2147990              | ILRuntime.Runtime.Generated.UnityEngine_GUILayoutUtility_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUILayoutUtility_Binding.Register(app:  0);
            // 0x00A22C4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C58: BL #0x2147824              | ILRuntime.Runtime.Generated.UnityEngine_GUILayoutOption_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUILayoutOption_Binding.Register(app:  0);
            // 0x00A22C5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C68: BL #0x10a09e0              | ILRuntime.Runtime.Generated.UnityEngine_ExitGUIException_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ExitGUIException_Binding.Register(app:  0);
            // 0x00A22C6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C78: BL #0x1bd9b80              | ILRuntime.Runtime.Generated.UnityEngine_GUIUtility_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUIUtility_Binding.Register(app:  0);
            // 0x00A22C7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C88: BL #0x214c154              | ILRuntime.Runtime.Generated.UnityEngine_GUISettings_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUISettings_Binding.Register(app:  0);
            // 0x00A22C8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22C90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22C94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22C98: BL #0x214e6b8              | ILRuntime.Runtime.Generated.UnityEngine_GUISkin_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUISkin_Binding.Register(app:  0);
            // 0x00A22C9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22CA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22CA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22CA8: BL #0x22aa024              | ILRuntime.Runtime.Generated.UnityEngine_GUIContent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUIContent_Binding.Register(app:  0);
            // 0x00A22CAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22CB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22CB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22CB8: BL #0x216bc80              | ILRuntime.Runtime.Generated.UnityEngine_GUIStyleState_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUIStyleState_Binding.Register(app:  0);
            // 0x00A22CBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22CC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22CC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22CC8: BL #0x220068c              | ILRuntime.Runtime.Generated.UnityEngine_RectOffset_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_RectOffset_Binding.Register(app:  0);
            // 0x00A22CCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22CD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22CD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22CD8: BL #0x21590c4              | ILRuntime.Runtime.Generated.UnityEngine_GUIStyle_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GUIStyle_Binding.Register(app:  0);
            // 0x00A22CDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22CE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22CE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22CE8: BL #0x229fa74              | ILRuntime.Runtime.Generated.UnityEngine_Event_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Event_Binding.Register(app:  0);
            // 0x00A22CEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22CF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22CF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22CF8: BL #0x1052b14              | ILRuntime.Runtime.Generated.UnityEngine_Gizmos_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Gizmos_Binding.Register(app:  0);
            // 0x00A22CFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D08: BL #0x13ceca0              | ILRuntime.Runtime.Generated.UnityEngine_LightProbeGroup_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LightProbeGroup_Binding.Register(app:  0);
            // 0x00A22D0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D18: BL #0x19b057c              | ILRuntime.Runtime.Generated.UnityEngine_ParticleSystemRenderer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ParticleSystemRenderer_Binding.Register(app:  0);
            // 0x00A22D1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D28: BL #0x1460b34              | ILRuntime.Runtime.Generated.UnityEngine_Sprite_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Sprite_Binding.Register(app:  0);
            // 0x00A22D2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D38: BL #0x146806c              | ILRuntime.Runtime.Generated.UnityEngine_SpriteRenderer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SpriteRenderer_Binding.Register(app:  0);
            // 0x00A22D3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D48: BL #0x146c1d0              | ILRuntime.Runtime.Generated.UnityEngine_Sprites_DataUtility_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Sprites_DataUtility_Binding.Register(app:  0);
            // 0x00A22D4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D58: BL #0x1204a88              | ILRuntime.Runtime.Generated.UnityEngine_Caching_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Caching_Binding.Register(app:  0);
            // 0x00A22D5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D68: BL #0x2088378              | ILRuntime.Runtime.Generated.UnityEngine_AsyncOperation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AsyncOperation_Binding.Register(app:  0);
            // 0x00A22D6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D78: BL #0x20dade4              | ILRuntime.Runtime.Generated.UnityEngine_ComputeShader_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ComputeShader_Binding.Register(app:  0);
            // 0x00A22D7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D88: BL #0x20d7e28              | ILRuntime.Runtime.Generated.UnityEngine_ComputeBuffer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ComputeBuffer_Binding.Register(app:  0);
            // 0x00A22D8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22D90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22D94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22D98: BL #0x2299c34              | ILRuntime.Runtime.Generated.UnityEngine_Display_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Display_Binding.Register(app:  0);
            // 0x00A22D9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22DA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22DA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22DA8: BL #0x1bde9ec              | ILRuntime.Runtime.Generated.UnityEngine_Gyroscope_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Gyroscope_Binding.Register(app:  0);
            // 0x00A22DAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22DB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22DB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22DB8: BL #0x13db2ec              | ILRuntime.Runtime.Generated.UnityEngine_LocationService_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LocationService_Binding.Register(app:  0);
            // 0x00A22DBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22DC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22DC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22DC8: BL #0xc42854               | ILRuntime.Runtime.Generated.UnityEngine_Compass_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Compass_Binding.Register(app:  0);
            // 0x00A22DCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22DD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22DD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22DD8: BL #0x20614e0              | ILRuntime.Runtime.Generated.UnityEngine_Light_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Light_Binding.Register(app:  0);
            // 0x00A22DDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22DE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22DE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22DE8: BL #0x157bcc8              | ILRuntime.Runtime.Generated.UnityEngine_YieldInstruction_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_YieldInstruction_Binding.Register(app:  0);
            // 0x00A22DEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22DF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22DF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22DF8: BL #0x1b32d2c              | ILRuntime.Runtime.Generated.UnityEngine_PlayerPrefsException_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_PlayerPrefsException_Binding.Register(app:  0);
            // 0x00A22DFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E08: BL #0x1f0dfc4              | ILRuntime.Runtime.Generated.UnityEngine_SocialPlatforms_Range_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SocialPlatforms_Range_Binding.Register(app:  0);
            // 0x00A22E0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E18: BL #0x2024da0              | ILRuntime.Runtime.Generated.UnityEngine_TextGenerationSettings_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TextGenerationSettings_Binding.Register(app:  0);
            // 0x00A22E1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E28: BL #0x2051cc4              | ILRuntime.Runtime.Generated.UnityEngine_JointMotor_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_JointMotor_Binding.Register(app:  0);
            // 0x00A22E2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E38: BL #0x20554bc              | ILRuntime.Runtime.Generated.UnityEngine_JointSpring_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_JointSpring_Binding.Register(app:  0);
            // 0x00A22E3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E48: BL #0x204ee64              | ILRuntime.Runtime.Generated.UnityEngine_JointLimits_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_JointLimits_Binding.Register(app:  0);
            // 0x00A22E4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E58: BL #0x1f0f2b4              | ILRuntime.Runtime.Generated.UnityEngine_SoftJointLimit_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SoftJointLimit_Binding.Register(app:  0);
            // 0x00A22E5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E68: BL #0x204ce88              | ILRuntime.Runtime.Generated.UnityEngine_JointDrive_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_JointDrive_Binding.Register(app:  0);
            // 0x00A22E6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E78: BL #0x20ad330              | ILRuntime.Runtime.Generated.UnityEngine_WheelFrictionCurve_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WheelFrictionCurve_Binding.Register(app:  0);
            // 0x00A22E7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E88: BL #0x20b015c              | ILRuntime.Runtime.Generated.UnityEngine_WheelHit_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WheelHit_Binding.Register(app:  0);
            // 0x00A22E8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22E90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22E94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22E98: BL #0x21ebe48              | ILRuntime.Runtime.Generated.UnityEngine_RaycastHit_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_RaycastHit_Binding.Register(app:  0);
            // 0x00A22E9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22EA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22EA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22EA8: BL #0x20f556c              | ILRuntime.Runtime.Generated.UnityEngine_ContactPoint_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ContactPoint_Binding.Register(app:  0);
            // 0x00A22EAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22EB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22EB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22EB8: BL #0x1eeb4f4              | ILRuntime.Runtime.Generated.UnityEngine_ClothSkinningCoefficient_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ClothSkinningCoefficient_Binding.Register(app:  0);
            // 0x00A22EBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22EC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22EC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22EC8: BL #0x21f028c              | ILRuntime.Runtime.Generated.UnityEngine_RaycastHit2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_RaycastHit2D_Binding.Register(app:  0);
            // 0x00A22ECC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22ED0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22ED4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22ED8: BL #0x20f7374              | ILRuntime.Runtime.Generated.UnityEngine_ContactPoint2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_ContactPoint2D_Binding.Register(app:  0);
            // 0x00A22EDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22EE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22EE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22EE8: BL #0x204b67c              | ILRuntime.Runtime.Generated.UnityEngine_JointAngleLimits2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_JointAngleLimits2D_Binding.Register(app:  0);
            // 0x00A22EEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22EF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22EF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22EF8: BL #0x20587c4              | ILRuntime.Runtime.Generated.UnityEngine_JointTranslationLimits2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_JointTranslationLimits2D_Binding.Register(app:  0);
            // 0x00A22EFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F04: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F08: BL #0x2053cb0              | ILRuntime.Runtime.Generated.UnityEngine_JointMotor2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_JointMotor2D_Binding.Register(app:  0);
            // 0x00A22F0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F14: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F18: BL #0x20567e8              | ILRuntime.Runtime.Generated.UnityEngine_JointSuspension2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_JointSuspension2D_Binding.Register(app:  0);
            // 0x00A22F1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F24: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F28: BL #0x211b55c              | ILRuntime.Runtime.Generated.UnityEngine_AI_OffMeshLinkData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AI_OffMeshLinkData_Binding.Register(app:  0);
            // 0x00A22F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F34: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F38: BL #0x210e0a4              | ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshHit_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshHit_Binding.Register(app:  0);
            // 0x00A22F3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F44: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F48: BL #0x2116844              | ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshTriangulation_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AI_NavMeshTriangulation_Binding.Register(app:  0);
            // 0x00A22F4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F54: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F58: BL #0x209e7e0              | ILRuntime.Runtime.Generated.UnityEngine_WebCamDevice_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_WebCamDevice_Binding.Register(app:  0);
            // 0x00A22F5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F64: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F68: BL #0x2059fd0              | ILRuntime.Runtime.Generated.UnityEngine_Keyframe_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Keyframe_Binding.Register(app:  0);
            // 0x00A22F6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F74: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F78: BL #0x206da48              | ILRuntime.Runtime.Generated.UnityEngine_AnimatorClipInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AnimatorClipInfo_Binding.Register(app:  0);
            // 0x00A22F7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F84: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F88: BL #0x2071850              | ILRuntime.Runtime.Generated.UnityEngine_AnimatorStateInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AnimatorStateInfo_Binding.Register(app:  0);
            // 0x00A22F8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22F90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22F94: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22F98: BL #0x20747ac              | ILRuntime.Runtime.Generated.UnityEngine_AnimatorTransitionInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AnimatorTransitionInfo_Binding.Register(app:  0);
            // 0x00A22F9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22FA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22FA4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22FA8: BL #0x13e1c34              | ILRuntime.Runtime.Generated.UnityEngine_MatchTargetWeightMask_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_MatchTargetWeightMask_Binding.Register(app:  0);
            // 0x00A22FAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22FB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22FB4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22FB8: BL #0x1f0397c              | ILRuntime.Runtime.Generated.UnityEngine_SkeletonBone_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_SkeletonBone_Binding.Register(app:  0);
            // 0x00A22FBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22FC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22FC4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22FC8: BL #0x1bed010              | ILRuntime.Runtime.Generated.UnityEngine_HumanLimit_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_HumanLimit_Binding.Register(app:  0);
            // 0x00A22FCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22FD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22FD4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22FD8: BL #0x1be67c4              | ILRuntime.Runtime.Generated.UnityEngine_HumanBone_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_HumanBone_Binding.Register(app:  0);
            // 0x00A22FDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22FE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22FE4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22FE8: BL #0x1be8590              | ILRuntime.Runtime.Generated.UnityEngine_HumanDescription_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_HumanDescription_Binding.Register(app:  0);
            // 0x00A22FEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A22FF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A22FF4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A22FF8: BL #0x1d8d4f4              | ILRuntime.Runtime.Generated.UnityEngine_TreeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TreeInstance_Binding.Register(app:  0);
            // 0x00A22FFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23000: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23004: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23008: BL #0x1d92c10              | ILRuntime.Runtime.Generated.UnityEngine_UIVertex_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_UIVertex_Binding.Register(app:  0);
            // 0x00A2300C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23010: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23014: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23018: BL #0xc3f654               | ILRuntime.Runtime.Generated.UnityEngine_CombineInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_CombineInstance_Binding.Register(app:  0);
            // 0x00A2301C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23020: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23024: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23028: BL #0x11f48b0              | ILRuntime.Runtime.Generated.UnityEngine_BoneWeight_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_BoneWeight_Binding.Register(app:  0);
            // 0x00A2302C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23030: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23034: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23038: BL #0x1e86c7c              | ILRuntime.Runtime.Generated.UnityEngine_RenderBuffer_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_RenderBuffer_Binding.Register(app:  0);
            // 0x00A2303C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23040: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23044: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23048: BL #0x18117b0              | ILRuntime.Runtime.Generated.UnityEngine_Resolution_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Resolution_Binding.Register(app:  0);
            // 0x00A2304C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23050: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23054: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23058: BL #0x1ed37b0              | ILRuntime.Runtime.Generated.UnityEngine_CharacterInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_CharacterInfo_Binding.Register(app:  0);
            // 0x00A2305C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23060: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23064: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23068: BL #0x1d905d4              | ILRuntime.Runtime.Generated.UnityEngine_UICharInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_UICharInfo_Binding.Register(app:  0);
            // 0x00A2306C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23070: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23074: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23078: BL #0x1d91634              | ILRuntime.Runtime.Generated.UnityEngine_UILineInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_UILineInfo_Binding.Register(app:  0);
            // 0x00A2307C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23080: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23084: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23088: BL #0x13dcc38              | ILRuntime.Runtime.Generated.UnityEngine_LOD_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LOD_Binding.Register(app:  0);
            // 0x00A2308C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23090: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23094: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23098: BL #0x1066f08              | ILRuntime.Runtime.Generated.UnityEngine_GradientColorKey_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GradientColorKey_Binding.Register(app:  0);
            // 0x00A2309C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A230A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A230A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A230A8: BL #0x1065c10              | ILRuntime.Runtime.Generated.UnityEngine_GradientAlphaKey_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_GradientAlphaKey_Binding.Register(app:  0);
            // 0x00A230AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A230B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A230B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A230B8: BL #0xc3be60               | ILRuntime.Runtime.Generated.UnityEngine_Color32_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Color32_Binding.Register(app:  0);
            // 0x00A230BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A230C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A230C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A230C8: BL #0x21f48cc              | ILRuntime.Runtime.Generated.UnityEngine_Rect_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Rect_Binding.Register(app:  0);
            // 0x00A230CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A230D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A230D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A230D8: BL #0x1a9afcc              | ILRuntime.Runtime.Generated.UnityEngine_Matrix4x4_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Matrix4x4_Binding.Register(app:  0);
            // 0x00A230DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A230E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A230E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A230E8: BL #0x21e6850              | ILRuntime.Runtime.Generated.UnityEngine_Ray_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Ray_Binding.Register(app:  0);
            // 0x00A230EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A230F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A230F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A230F8: BL #0x21e93d4              | ILRuntime.Runtime.Generated.UnityEngine_Ray2D_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Ray2D_Binding.Register(app:  0);
            // 0x00A230FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23100: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23104: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23108: BL #0x1b293d8              | ILRuntime.Runtime.Generated.UnityEngine_Plane_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Plane_Binding.Register(app:  0);
            // 0x00A2310C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23110: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23114: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23118: BL #0x14cc588              | ILRuntime.Runtime.Generated.UnityEngine_AccelerationEvent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AccelerationEvent_Binding.Register(app:  0);
            // 0x00A2311C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23120: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23124: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23128: BL #0x13d946c              | ILRuntime.Runtime.Generated.UnityEngine_LocationInfo_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_LocationInfo_Binding.Register(app:  0);
            // 0x00A2312C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23130: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23134: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23138: BL #0x220a420              | ILRuntime.Runtime.Generated.System_Diagnostics_Stopwatch_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Diagnostics_Stopwatch_Binding.Register(app:  0);
            // 0x00A2313C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23140: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23144: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23148: BL #0xcb5b64               | ILRuntime.Runtime.Generated.UnityEngine_AndroidJNIHelper_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AndroidJNIHelper_Binding.Register(app:  0);
            // 0x00A2314C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23150: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23154: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23158: BL #0xcb4b84               | ILRuntime.Runtime.Generated.UnityEngine_AndroidJNI_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AndroidJNI_Binding.Register(app:  0);
            // 0x00A2315C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23160: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23164: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23168: BL #0x211ed80              | ILRuntime.Runtime.Generated.UnityEngine_AndroidInput_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AndroidInput_Binding.Register(app:  0);
            // 0x00A2316C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23170: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23174: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23178: BL #0x211fb24              | ILRuntime.Runtime.Generated.UnityEngine_AndroidJavaException_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AndroidJavaException_Binding.Register(app:  0);
            // 0x00A2317C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23180: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23184: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23188: BL #0xcb2964               | ILRuntime.Runtime.Generated.UnityEngine_AndroidJavaProxy_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AndroidJavaProxy_Binding.Register(app:  0);
            // 0x00A2318C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23190: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23194: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23198: BL #0x211ff70              | ILRuntime.Runtime.Generated.UnityEngine_AndroidJavaObject_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_AndroidJavaObject_Binding.Register(app:  0);
            // 0x00A2319C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A231A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A231A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A231A8: BL #0x1fdf4c8              | ILRuntime.Runtime.Generated.UnityEngine_TouchScreenKeyboard_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_TouchScreenKeyboard_Binding.Register(app:  0);
            // 0x00A231AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A231B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A231B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A231B8: BL #0x17abeb8              | ILRuntime.Runtime.Generated.UnityEngine_Motion_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Motion_Binding.Register(app:  0);
            // 0x00A231BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A231C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A231C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A231C8: BL #0x2015aa8              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IEventSystemHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IEventSystemHandler_Binding.Register(app:  0);
            // 0x00A231CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A231D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A231D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A231D8: BL #0x20173b4              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerEnterHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerEnterHandler_Binding.Register(app:  0);
            // 0x00A231DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A231E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A231E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A231E8: BL #0x201799c              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerExitHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerExitHandler_Binding.Register(app:  0);
            // 0x00A231EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A231F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A231F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A231F8: BL #0x2016dcc              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerDownHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerDownHandler_Binding.Register(app:  0);
            // 0x00A231FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23200: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23204: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23208: BL #0x2017f84              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerUpHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerUpHandler_Binding.Register(app:  0);
            // 0x00A2320C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23210: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23214: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23218: BL #0x20167e4              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerClickHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IPointerClickHandler_Binding.Register(app:  0);
            // 0x00A2321C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23220: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23224: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23228: BL #0x2013738              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IBeginDragHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IBeginDragHandler_Binding.Register(app:  0);
            // 0x00A2322C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23230: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23234: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23238: BL #0x2015c14              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IInitializePotentialDragHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IInitializePotentialDragHandler_Binding.Register(app:  0);
            // 0x00A2323C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23240: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23244: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23248: BL #0x20148f0              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IDragHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IDragHandler_Binding.Register(app:  0);
            // 0x00A2324C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23250: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23254: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23258: BL #0x20154c0              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IEndDragHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IEndDragHandler_Binding.Register(app:  0);
            // 0x00A2325C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23260: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23264: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23268: BL #0x2014ed8              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IDropHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IDropHandler_Binding.Register(app:  0);
            // 0x00A2326C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23270: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23274: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23278: BL #0x201856c              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IScrollHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IScrollHandler_Binding.Register(app:  0);
            // 0x00A2327C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23280: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23284: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23288: BL #0x2019724              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IUpdateSelectedHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IUpdateSelectedHandler_Binding.Register(app:  0);
            // 0x00A2328C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23290: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23294: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23298: BL #0x2018b54              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_ISelectHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_ISelectHandler_Binding.Register(app:  0);
            // 0x00A2329C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A232A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A232A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A232A8: BL #0x2014308              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IDeselectHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IDeselectHandler_Binding.Register(app:  0);
            // 0x00A232AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A232B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A232B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A232B8: BL #0x20161fc              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IMoveHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_IMoveHandler_Binding.Register(app:  0);
            // 0x00A232BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A232C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A232C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A232C8: BL #0x201913c              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_ISubmitHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_ISubmitHandler_Binding.Register(app:  0);
            // 0x00A232CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A232D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A232D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A232D8: BL #0x2013d20              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_ICancelHandler_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_ICancelHandler_Binding.Register(app:  0);
            // 0x00A232DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A232E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A232E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A232E8: BL #0x2009e00              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_EventSystem_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_EventSystem_Binding.Register(app:  0);
            // 0x00A232EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A232F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A232F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A232F8: BL #0x2013388              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_EventTrigger_Binding_TriggerEvent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_EventTrigger_Binding_TriggerEvent_Binding.Register(app:  0);
            // 0x00A232FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23300: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23304: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23308: BL #0x10a0210              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_UIBehaviour_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_UIBehaviour_Binding.Register(app:  0);
            // 0x00A2330C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23310: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23314: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23318: BL #0x2005020              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_AxisEventData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_AxisEventData_Binding.Register(app:  0);
            // 0x00A2331C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23320: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23324: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23328: BL #0x20063a0              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_BaseEventData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_BaseEventData_Binding.Register(app:  0);
            // 0x00A2332C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23330: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23334: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23338: BL #0x20045c8              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_AbstractEventData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_AbstractEventData_Binding.Register(app:  0);
            // 0x00A2333C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23340: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23344: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23348: BL #0x201bb78              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_PointerEventData_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_PointerEventData_Binding.Register(app:  0);
            // 0x00A2334C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23350: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23354: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23358: BL #0x20073d4              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_BaseInputModule_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_BaseInputModule_Binding.Register(app:  0);
            // 0x00A2335C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23360: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23364: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23368: BL #0x1097adc              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_PointerInputModule_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_PointerInputModule_Binding.Register(app:  0);
            // 0x00A2336C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23370: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23374: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23378: BL #0x109be94              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_StandaloneInputModule_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_StandaloneInputModule_Binding.Register(app:  0);
            // 0x00A2337C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23380: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23384: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23388: BL #0x2008af8              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_BaseRaycaster_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_BaseRaycaster_Binding.Register(app:  0);
            // 0x00A2338C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23390: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23394: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A23398: BL #0x2019d0c              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_Physics2DRaycaster_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_Physics2DRaycaster_Binding.Register(app:  0);
            // 0x00A2339C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A233A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A233A4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A233A8: BL #0x201a400              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_PhysicsRaycaster_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_PhysicsRaycaster_Binding.Register(app:  0);
            // 0x00A233AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A233B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A233B4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A233B8: BL #0x1098710              | ILRuntime.Runtime.Generated.UnityEngine_EventSystems_RaycastResult_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_EventSystems_RaycastResult_Binding.Register(app:  0);
            // 0x00A233BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A233C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A233C4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A233C8: BL #0x2316c10              | ILRuntime.Runtime.Generated.System_Text_StringBuilder_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Text_StringBuilder_Binding.Register(app:  0);
            // 0x00A233CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A233D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A233D4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A233D8: BL #0x2002798              | ILRuntime.Runtime.Generated.UnityEngine_Events_UnityEventBase_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Events_UnityEventBase_Binding.Register(app:  0);
            // 0x00A233DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A233E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A233E4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A233E8: BL #0x20018cc              | ILRuntime.Runtime.Generated.UnityEngine_Events_UnityEvent_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.UnityEngine_Events_UnityEvent_Binding.Register(app:  0);
            // 0x00A233EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A233F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A233F4: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A233F8: BL #0x17480c4              | ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_ILTypeInstance_ILTypeInstance_Binding.Register(app:  0);
            ILRuntime.Runtime.Generated.System_Collections_Generic_Dictionary_2_ILTypeInstance_ILTypeInstance_Binding.Register(app:  0);
            // 0x00A233FC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00A23400: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A23404: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A23408: MOV x1, x19                | X1 = app;//m1                           
            // 0x00A2340C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00A23410: B #0x2000aac               | ILRuntime.Runtime.Generated.UnityEngine_Events_UnityEvent_1_ILTypeInstance_Binding.Register(app:  0); return;
            ILRuntime.Runtime.Generated.UnityEngine_Events_UnityEvent_1_ILTypeInstance_Binding.Register(app:  0);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00A45BBC (10771388), len: 4  VirtAddr: 0x00A45BBC RVA: 0x00A45BBC token: 100664482 methodIndex: 30529 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Shutdown(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            // 0x00A45BBC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00A45BC0 (10771392), len: 116  VirtAddr: 0x00A45BC0 RVA: 0x00A45BC0 token: 100664483 methodIndex: 30530 delegateWrapperIndex: 0 methodInvoker: 0
        public static void RegisterAll(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            // 0x00A45BC0: STP x20, x19, [sp, #-0x20]! | stack[1152921510156106000] = ???;  stack[1152921510156106008] = ???;  //  dest_result_addr=1152921510156106000 |  dest_result_addr=1152921510156106008
            // 0x00A45BC4: STP x29, x30, [sp, #0x10]  | stack[1152921510156106016] = ???;  stack[1152921510156106024] = ???;  //  dest_result_addr=1152921510156106016 |  dest_result_addr=1152921510156106024
            // 0x00A45BC8: ADD x29, sp, #0x10         | X29 = (1152921510156106000 + 16) = 1152921510156106016 (0x100000014AC2F920);
            // 0x00A45BCC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00A45BD0: LDRB w8, [x20, #0x14d]     | W8 = (bool)static_value_0373314D;       
            // 0x00A45BD4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00A45BD8: TBNZ w8, #0, #0xa45bf4     | if (static_value_0373314D == true) goto label_0;
            // 0x00A45BDC: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00A45BE0: LDR x8, [x8, #0x8e0]       | X8 = 0x2B90C80;                         
            // 0x00A45BE4: LDR w0, [x8]               | W0 = 0x19E4;                            
            // 0x00A45BE8: BL #0x2782188              | X0 = sub_2782188( ?? 0x19E4, ????);     
            // 0x00A45BEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A45BF0: STRB w8, [x20, #0x14d]     | static_value_0373314D = true;            //  dest_result_addr=57880909
            label_0:
            // 0x00A45BF4: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x00A45BF8: LDR x8, [x8, #0x570]       | X8 = 1152921504784056320;               
            // 0x00A45BFC: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Generated.CLRBindings);
            object val_1 = null;
            // 0x00A45C00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Generated.CLRBindings), ????);
            // 0x00A45C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A45C08: MOV x20, x0                | X20 = 1152921504784056320 (0x100000000A900000);//ML01
            // 0x00A45C0C: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00A45C10: CBNZ x20, #0xa45c18        | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x00A45C14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_1:
            // 0x00A45C18: LDR x8, [x20]              | X8 = ;                                  
            // 0x00A45C1C: MOV x0, x20                | X0 = 1152921504784056320 (0x100000000A900000);//ML01
            // 0x00A45C20: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00A45C24: LDP x3, x2, [x8, #0x150]   |                                          //  not_find_field!1:336 |  not_find_field!1:344
            // 0x00A45C28: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00A45C2C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00A45C30: BR x3                      | goto mem[null + 336];                   
            goto mem[null + 336];
        
        }
    
    }

}
