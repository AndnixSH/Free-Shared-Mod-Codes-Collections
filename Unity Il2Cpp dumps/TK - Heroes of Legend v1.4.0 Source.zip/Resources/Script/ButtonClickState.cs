using UnityEngine;
public class ButtonClickState : MonoBehaviour
{
    // Fields
    public string strNormal; //  0x00000018
    public string strPress; //  0x00000020
    public float interval_max_time; //  0x00000028
    public float interval_min_time; //  0x0000002C
    public float less_speed; //  0x00000030
    public float UsingSumTime; //  0x00000034
    private float _using_time; //  0x00000038
    private float _move_time; //  0x0000003C
    private float _call_time; //  0x00000040
    private bool _fun_enable; //  0x00000044
    private bool _isClick; //  0x00000045
    private UISprite _cur_sprite; //  0x00000048
    public ButtonClickState.VoidDelegate onClick; //  0x00000050
    
    // Properties
    public bool value { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA2578 (12199288), len: 36  VirtAddr: 0x00BA2578 RVA: 0x00BA2578 token: 100696742 methodIndex: 25552 delegateWrapperIndex: 0 methodInvoker: 0
    public ButtonClickState()
    {
        //
        // Disasemble & Code
        // 0x00BA2578: MOVZ w9, #0x3dcc, lsl #16  | W9 = 1036779520 (0x3DCC0000);//ML01     
        // 0x00BA257C: ORR w8, wzr, #0x3f000000   | W8 = 1056964608(0x3F000000);            
        // 0x00BA2580: MOVK w9, #0xcccd           | W9 = 1036831949 (0x3DCCCCCD);           
        // 0x00BA2584: ORR w10, wzr, #1           | W10 = 1(0x1);                           
        // 0x00BA2588: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA258C: STP w8, w9, [x0, #0x28]    | this.interval_max_time = 0.5;  this.interval_min_time = 0.1;  //  dest_result_addr=1152921515579600472 |  dest_result_addr=1152921515579600476
        this.interval_max_time = 0.5f;
        this.interval_min_time = 0.1f;
        // 0x00BA2590: STR w9, [x0, #0x30]        | this.less_speed = 0.1;                   //  dest_result_addr=1152921515579600480
        this.less_speed = 0.1f;
        // 0x00BA2594: STRB w10, [x0, #0x44]      | this._fun_enable = true;                 //  dest_result_addr=1152921515579600500
        this._fun_enable = true;
        // 0x00BA2598: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA259C (12199324), len: 8  VirtAddr: 0x00BA259C RVA: 0x00BA259C token: 100696743 methodIndex: 25553 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_value()
    {
        //
        // Disasemble & Code
        // 0x00BA259C: LDRB w0, [x0, #0x45]       | W0 = this._isClick; //P2                
        // 0x00BA25A0: RET                        |  return (System.Boolean)this._isClick;  
        return this._isClick;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA25A4 (12199332), len: 404  VirtAddr: 0x00BA25A4 RVA: 0x00BA25A4 token: 100696744 methodIndex: 25554 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_value(bool value)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        UISprite val_9;
        //  | 
        string val_10;
        //  | 
        var val_11;
        // 0x00BA25A4: STP x22, x21, [sp, #-0x30]! | stack[1152921515579849248] = ???;  stack[1152921515579849256] = ???;  //  dest_result_addr=1152921515579849248 |  dest_result_addr=1152921515579849256
        // 0x00BA25A8: STP x20, x19, [sp, #0x10]  | stack[1152921515579849264] = ???;  stack[1152921515579849272] = ???;  //  dest_result_addr=1152921515579849264 |  dest_result_addr=1152921515579849272
        // 0x00BA25AC: STP x29, x30, [sp, #0x20]  | stack[1152921515579849280] = ???;  stack[1152921515579849288] = ???;  //  dest_result_addr=1152921515579849280 |  dest_result_addr=1152921515579849288
        // 0x00BA25B0: ADD x29, sp, #0x20         | X29 = (1152921515579849248 + 32) = 1152921515579849280 (0x100000028E0ABA40);
        // 0x00BA25B4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA25B8: LDRB w8, [x21, #0xab6]     | W8 = (bool)static_value_03733AB6;       
        // 0x00BA25BC: MOV w20, w1                | W20 = value;//m1                        
        // 0x00BA25C0: MOV x19, x0                | X19 = 1152921515579861296 (0x100000028E0AE930);//ML01
        // 0x00BA25C4: TBNZ w8, #0, #0xba25e0     | if (static_value_03733AB6 == true) goto label_0;
        // 0x00BA25C8: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00BA25CC: LDR x8, [x8, #0xf58]       | X8 = 0x2B8FEF0;                         
        // 0x00BA25D0: LDR w0, [x8]               | W0 = 0x1680;                            
        // 0x00BA25D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1680, ????);     
        // 0x00BA25D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA25DC: STRB w8, [x21, #0xab6]     | static_value_03733AB6 = true;            //  dest_result_addr=57883318
        label_0:
        // 0x00BA25E0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BA25E4: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BA25E8: LDR x21, [x19, #0x48]      | X21 = this._cur_sprite; //P2            
        // 0x00BA25EC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BA25F0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BA25F4: TBZ w8, #0, #0xba2604      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA25F8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BA25FC: CBNZ w8, #0xba2604         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA2600: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00BA2604: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA2608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA260C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA2610: MOV x2, x21                | X2 = this._cur_sprite;//m1              
        // 0x00BA2614: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  0);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  0);
        // 0x00BA2618: TBZ w0, #0, #0xba264c      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00BA261C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2620: MOV x0, x19                | X0 = 1152921515579861296 (0x100000028E0AE930);//ML01
        // 0x00BA2624: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_2 = this.transform;
        // 0x00BA2628: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00BA262C: CBNZ x21, #0xba2634        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00BA2630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00BA2634: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x00BA2638: LDR x8, [x8, #0x570]       | X8 = 1152921511724753616;               
        // 0x00BA263C: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00BA2640: LDR x1, [x8]               | X1 = public UISprite UnityEngine.Component::GetComponent<UISprite>();
        // 0x00BA2644: BL #0x23d5410              | X0 = val_2.GetComponent<UISprite>();    
        UISprite val_3 = val_2.GetComponent<UISprite>();
        // 0x00BA2648: STR x0, [x19, #0x48]       | this._cur_sprite = val_3;                //  dest_result_addr=1152921515579861368
        this._cur_sprite = val_3;
        label_3:
        // 0x00BA264C: AND w8, w20, #1            | W8 = (value & 1);                       
        bool val_4 = value;
        // 0x00BA2650: STRB w8, [x19, #0x45]      | this._isClick = (value & 1);             //  dest_result_addr=1152921515579861365
        this._isClick = val_4;
        // 0x00BA2654: TBZ w20, #0, #0xba26ac     | if (value == false) goto label_5;       
        if(value == false)
        {
            goto label_5;
        }
        // 0x00BA2658: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
        // 0x00BA265C: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
        val_7 = 1152921504608284672;
        // 0x00BA2660: LDR x20, [x19, #0x20]      | X20 = this.strPress; //P2               
        // 0x00BA2664: LDR x0, [x21]              | X0 = typeof(System.String);             
        val_8 = null;
        // 0x00BA2668: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00BA266C: TBZ w8, #0, #0xba2680      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00BA2670: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00BA2674: CBNZ w8, #0xba2680         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00BA2678: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00BA267C: LDR x0, [x21]              | X0 = typeof(System.String);             
        val_8 = null;
        label_7:
        // 0x00BA2680: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00BA2684: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA2688: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA268C: MOV x1, x20                | X1 = this.strPress;//m1                 
        // 0x00BA2690: LDR x2, [x8]               | X2 = System.String.Empty;               
        // 0x00BA2694: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  this.strPress);
        bool val_5 = System.String.op_Inequality(a:  0, b:  this.strPress);
        // 0x00BA2698: TBZ w0, #0, #0xba2728      | if (val_5 == false) goto label_13;      
        if(val_5 == false)
        {
            goto label_13;
        }
        // 0x00BA269C: LDR x20, [x19, #0x48]      | X20 = this._cur_sprite; //P2            
        val_9 = this._cur_sprite;
        // 0x00BA26A0: LDR x19, [x19, #0x20]      | X19 = this.strPress; //P2               
        val_10 = this.strPress;
        // 0x00BA26A4: CBNZ x20, #0xba270c        | if (this._cur_sprite != null) goto label_14;
        if(val_9 != null)
        {
            goto label_14;
        }
        // 0x00BA26A8: B #0xba2708                |  goto label_10;                         
        goto label_10;
        label_5:
        // 0x00BA26AC: LDR w8, [x19, #0x28]       | W8 = this.interval_max_time; //P2       
        // 0x00BA26B0: STUR xzr, [x19, #0x34]     | this.UsingSumTime = 0; this._using_time = 0;  //  dest_result_addr=1152921515579861348 dest_result_addr=1152921515579861352
        this.UsingSumTime = 0f;
        this._using_time = 0f;
        // 0x00BA26B4: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
        // 0x00BA26B8: STP wzr, w8, [x19, #0x3c]  | this._move_time = 0;  this._call_time = this.interval_max_time;  //  dest_result_addr=1152921515579861356 |  dest_result_addr=1152921515579861360
        this._move_time = 0f;
        this._call_time = this.interval_max_time;
        // 0x00BA26BC: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
        val_7 = 1152921504608284672;
        // 0x00BA26C0: LDR x20, [x19, #0x18]      | X20 = this.strNormal; //P2              
        // 0x00BA26C4: LDR x0, [x21]              | X0 = typeof(System.String);             
        val_11 = null;
        // 0x00BA26C8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00BA26CC: TBZ w8, #0, #0xba26e0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00BA26D0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00BA26D4: CBNZ w8, #0xba26e0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00BA26D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00BA26DC: LDR x0, [x21]              | X0 = typeof(System.String);             
        val_11 = null;
        label_12:
        // 0x00BA26E0: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00BA26E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA26E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA26EC: MOV x1, x20                | X1 = this.strNormal;//m1                
        // 0x00BA26F0: LDR x2, [x8]               | X2 = System.String.Empty;               
        // 0x00BA26F4: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  this.strNormal);
        bool val_6 = System.String.op_Inequality(a:  0, b:  this.strNormal);
        // 0x00BA26F8: TBZ w0, #0, #0xba2728      | if (val_6 == false) goto label_13;      
        if(val_6 == false)
        {
            goto label_13;
        }
        // 0x00BA26FC: LDR x20, [x19, #0x48]      | X20 = this._cur_sprite; //P2            
        val_9 = this._cur_sprite;
        // 0x00BA2700: LDR x19, [x19, #0x18]      | X19 = this.strNormal; //P2              
        val_10 = this.strNormal;
        // 0x00BA2704: CBNZ x20, #0xba270c        | if (this._cur_sprite != null) goto label_14;
        if(val_9 != null)
        {
            goto label_14;
        }
        label_10:
        // 0x00BA2708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_14:
        // 0x00BA270C: MOV x0, x20                | X0 = this._cur_sprite;//m1              
        // 0x00BA2710: MOV x1, x19                | X1 = this.strNormal;//m1                
        // 0x00BA2714: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2718: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA271C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA2720: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA2724: B #0x1538560               | this._cur_sprite.set_spriteName(value:  val_10); return;
        val_9.spriteName = val_10;
        return;
        label_13:
        // 0x00BA2728: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA272C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2730: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA2734: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2738 (12199736), len: 76  VirtAddr: 0x00BA2738 RVA: 0x00BA2738 token: 100696745 methodIndex: 25555 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnClick()
    {
        //
        // Disasemble & Code
        // 0x00BA2738: STP x20, x19, [sp, #-0x20]! | stack[1152921515580006320] = ???;  stack[1152921515580006328] = ???;  //  dest_result_addr=1152921515580006320 |  dest_result_addr=1152921515580006328
        // 0x00BA273C: STP x29, x30, [sp, #0x10]  | stack[1152921515580006336] = ???;  stack[1152921515580006344] = ???;  //  dest_result_addr=1152921515580006336 |  dest_result_addr=1152921515580006344
        // 0x00BA2740: ADD x29, sp, #0x10         | X29 = (1152921515580006320 + 16) = 1152921515580006336 (0x100000028E0D1FC0);
        // 0x00BA2744: LDRB w8, [x0, #0x44]       | W8 = this._fun_enable; //P2             
        // 0x00BA2748: CBZ w8, #0xba2778          | if (this._fun_enable == false) goto label_1;
        if(this._fun_enable == false)
        {
            goto label_1;
        }
        // 0x00BA274C: LDR x19, [x0, #0x50]       | X19 = this.onClick; //P2                
        // 0x00BA2750: CBZ x19, #0xba2778         | if (this.onClick == null) goto label_1; 
        if(this.onClick == null)
        {
            goto label_1;
        }
        // 0x00BA2754: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2758: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00BA275C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2760: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00BA2764: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA2768: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00BA276C: MOV x0, x19                | X0 = this.onClick;//m1                  
        // 0x00BA2770: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2774: B #0xba2784                | this.onClick.Invoke(go:  val_1, isPress:  true); return;
        this.onClick.Invoke(go:  val_1, isPress:  true);
        return;
        label_1:
        // 0x00BA2778: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA277C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2780: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2B58 (12200792), len: 20  VirtAddr: 0x00BA2B58 RVA: 0x00BA2B58 token: 100696746 methodIndex: 25556 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnPress(bool ispress)
    {
        //
        // Disasemble & Code
        // 0x00BA2B58: LDRB w8, [x0, #0x44]       | W8 = this._fun_enable; //P2             
        // 0x00BA2B5C: CBZ w8, #0xba2b68          | if (this._fun_enable == false) goto label_0;
        if(this._fun_enable == false)
        {
            goto label_0;
        }
        // 0x00BA2B60: AND w1, w1, #1             | W1 = (ispress & 1);                     
        bool val_1 = ispress;
        // 0x00BA2B64: B #0xba25a4                | this.set_value(value:  bool val_1 = ispress); return;
        this.value = val_1;
        return;
        label_0:
        // 0x00BA2B68: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2B6C (12200812), len: 104  VirtAddr: 0x00BA2B6C RVA: 0x00BA2B6C token: 100696747 methodIndex: 25557 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnHover(bool ishover)
    {
        //
        // Disasemble & Code
        // 0x00BA2B6C: STP x20, x19, [sp, #-0x20]! | stack[1152921515580246704] = ???;  stack[1152921515580246712] = ???;  //  dest_result_addr=1152921515580246704 |  dest_result_addr=1152921515580246712
        // 0x00BA2B70: STP x29, x30, [sp, #0x10]  | stack[1152921515580246720] = ???;  stack[1152921515580246728] = ???;  //  dest_result_addr=1152921515580246720 |  dest_result_addr=1152921515580246728
        // 0x00BA2B74: ADD x29, sp, #0x10         | X29 = (1152921515580246704 + 16) = 1152921515580246720 (0x100000028E10CAC0);
        // 0x00BA2B78: MOV x19, x0                | X19 = 1152921515580258736 (0x100000028E10F9B0);//ML01
        // 0x00BA2B7C: LDRB w8, [x19, #0x44]      | W8 = this._fun_enable; //P2             
        // 0x00BA2B80: CBZ w8, #0xba2bc8          | if (this._fun_enable == false) goto label_2;
        if(this._fun_enable == false)
        {
            goto label_2;
        }
        // 0x00BA2B84: AND w8, w1, #1             | W8 = (ishover & 1);                     
        bool val_1 = ishover;
        // 0x00BA2B88: TBNZ w8, #0, #0xba2bc8     | if ((ishover & 1) == true) goto label_2;
        if(val_1 == true)
        {
            goto label_2;
        }
        // 0x00BA2B8C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA2B90: MOV x0, x19                | X0 = 1152921515580258736 (0x100000028E10F9B0);//ML01
        // 0x00BA2B94: BL #0xba25a4               | this.set_value(value:  false);          
        this.value = false;
        // 0x00BA2B98: LDR x20, [x19, #0x50]      | X20 = this.onClick; //P2                
        // 0x00BA2B9C: CBZ x20, #0xba2bc8         | if (this.onClick == null) goto label_2; 
        if(this.onClick == null)
        {
            goto label_2;
        }
        // 0x00BA2BA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2BA4: MOV x0, x19                | X0 = 1152921515580258736 (0x100000028E10F9B0);//ML01
        // 0x00BA2BA8: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_2 = this.gameObject;
        // 0x00BA2BAC: LDRB w2, [x19, #0x45]      | W2 = this._isClick; //P2                
        // 0x00BA2BB0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2BB4: MOV x1, x0                 | X1 = val_2;//m1                         
        // 0x00BA2BB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA2BBC: MOV x0, x20                | X0 = this.onClick;//m1                  
        // 0x00BA2BC0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2BC4: B #0xba2784                | this.onClick.Invoke(go:  val_2, isPress:  this._isClick); return;
        this.onClick.Invoke(go:  val_2, isPress:  this._isClick);
        return;
        label_2:
        // 0x00BA2BC8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2BCC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2BD0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2BD4 (12200916), len: 252  VirtAddr: 0x00BA2BD4 RVA: 0x00BA2BD4 token: 100696748 methodIndex: 25558 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        //  | 
        float val_6;
        //  | 
        float val_7;
        // 0x00BA2BD4: STP d9, d8, [sp, #-0x40]!  | stack[1152921515580379152] = ???;  stack[1152921515580379160] = ???;  //  dest_result_addr=1152921515580379152 |  dest_result_addr=1152921515580379160
        // 0x00BA2BD8: STP x22, x21, [sp, #0x10]  | stack[1152921515580379168] = ???;  stack[1152921515580379176] = ???;  //  dest_result_addr=1152921515580379168 |  dest_result_addr=1152921515580379176
        // 0x00BA2BDC: STP x20, x19, [sp, #0x20]  | stack[1152921515580379184] = ???;  stack[1152921515580379192] = ???;  //  dest_result_addr=1152921515580379184 |  dest_result_addr=1152921515580379192
        // 0x00BA2BE0: STP x29, x30, [sp, #0x30]  | stack[1152921515580379200] = ???;  stack[1152921515580379208] = ???;  //  dest_result_addr=1152921515580379200 |  dest_result_addr=1152921515580379208
        // 0x00BA2BE4: ADD x29, sp, #0x30         | X29 = (1152921515580379152 + 48) = 1152921515580379200 (0x100000028E12D040);
        // 0x00BA2BE8: MOV x19, x0                | X19 = 1152921515580391216 (0x100000028E12FF30);//ML01
        // 0x00BA2BEC: LDR x8, [x19, #0x50]       | X8 = this.onClick; //P2                 
        // 0x00BA2BF0: CBZ x8, #0xba2c38          | if (this.onClick == null) goto label_1; 
        if(this.onClick == null)
        {
            goto label_1;
        }
        // 0x00BA2BF4: LDRB w8, [x19, #0x45]      | W8 = this._isClick; //P2                
        // 0x00BA2BF8: CBZ w8, #0xba2c38          | if (this._isClick == false) goto label_1;
        if(this._isClick == false)
        {
            goto label_1;
        }
        // 0x00BA2BFC: LDR s8, [x19, #0x34]       | S8 = this.UsingSumTime; //P2            
        val_6 = this.UsingSumTime;
        // 0x00BA2C00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA2C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2C08: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_1 = UnityEngine.Time.deltaTime;
        // 0x00BA2C0C: LDR s9, [x19, #0x38]       | S9 = this._using_time; //P2             
        // 0x00BA2C10: FADD s0, s8, s0            | S0 = (this.UsingSumTime + val_1);       
        val_1 = val_6 + val_1;
        // 0x00BA2C14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA2C18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2C1C: STR s0, [x19, #0x34]       | this.UsingSumTime = (this.UsingSumTime + val_1);  //  dest_result_addr=1152921515580391268
        this.UsingSumTime = val_1;
        // 0x00BA2C20: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_2 = UnityEngine.Time.deltaTime;
        // 0x00BA2C24: LDR s1, [x19, #0x28]       | S1 = this.interval_max_time; //P2       
        // 0x00BA2C28: FADD s0, s9, s0            | S0 = (this._using_time + val_2);        
        val_2 = this._using_time + val_2;
        // 0x00BA2C2C: STR s0, [x19, #0x38]       | this._using_time = (this._using_time + val_2);  //  dest_result_addr=1152921515580391272
        this._using_time = val_2;
        // 0x00BA2C30: FCMP s0, s1                | STATE = COMPARE((this._using_time + val_2), this.interval_max_time)
        // 0x00BA2C34: B.GE #0xba2c4c             | if (val_2 >= this.interval_max_time) goto label_2;
        if(val_2 >= this.interval_max_time)
        {
            goto label_2;
        }
        label_1:
        // 0x00BA2C38: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2C3C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2C40: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA2C44: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00BA2C48: RET                        |  return;                                
        return;
        label_2:
        // 0x00BA2C4C: LDR s0, [x19, #0x2c]       | S0 = this.interval_min_time; //P2       
        val_7 = this.interval_min_time;
        // 0x00BA2C50: FCMP s1, s0                | STATE = COMPARE(this.interval_max_time, this.interval_min_time)
        // 0x00BA2C54: B.LE #0xba2c80             | if (this.interval_max_time <= val_7) goto label_3;
        if(this.interval_max_time <= val_7)
        {
            goto label_3;
        }
        // 0x00BA2C58: LDR s8, [x19, #0x3c]       | S8 = this._move_time; //P2              
        val_6 = this._move_time;
        // 0x00BA2C5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA2C60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2C64: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_3 = UnityEngine.Time.deltaTime;
        // 0x00BA2C68: LDR s1, [x19, #0x30]       | S1 = this.less_speed; //P2              
        // 0x00BA2C6C: LDR s2, [x19, #0x28]       | S2 = this.interval_max_time; //P2       
        // 0x00BA2C70: FADD s0, s8, s0            | S0 = (this._move_time + val_3);         
        val_3 = val_6 + val_3;
        // 0x00BA2C74: STR s0, [x19, #0x3c]       | this._move_time = (this._move_time + val_3);  //  dest_result_addr=1152921515580391276
        this._move_time = val_3;
        // 0x00BA2C78: FMUL s0, s0, s1            | S0 = ((this._move_time + val_3) * this.less_speed);
        val_3 = val_3 * this.less_speed;
        // 0x00BA2C7C: FSUB s0, s2, s0            | S0 = (this.interval_max_time - ((this._move_time + val_3) * this.less_speed));
        val_7 = this.interval_max_time - val_3;
        label_3:
        // 0x00BA2C80: LDR x20, [x19, #0x50]      | X20 = this.onClick; //P2                
        // 0x00BA2C84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2C88: MOV x0, x19                | X0 = 1152921515580391216 (0x100000028E12FF30);//ML01
        // 0x00BA2C8C: STR s0, [x19, #0x28]       | this.interval_max_time = (this.interval_max_time - ((this._move_time + val_3) * this.less_speed));  //  dest_result_addr=1152921515580391256
        this.interval_max_time = val_7;
        // 0x00BA2C90: STR wzr, [x19, #0x38]      | this._using_time = 0;                    //  dest_result_addr=1152921515580391272
        this._using_time = 0f;
        // 0x00BA2C94: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_4 = this.gameObject;
        // 0x00BA2C98: LDRB w21, [x19, #0x45]     | W21 = this._isClick; //P2               
        // 0x00BA2C9C: MOV x19, x0                | X19 = val_4;//m1                        
        // 0x00BA2CA0: CBNZ x20, #0xba2ca8        | if (this.onClick != null) goto label_4; 
        if(this.onClick != null)
        {
            goto label_4;
        }
        // 0x00BA2CA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_4:
        // 0x00BA2CA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA2CAC: CMP w21, #0                | STATE = COMPARE(this._isClick, 0x0)     
        // 0x00BA2CB0: MOV x0, x20                | X0 = this.onClick;//m1                  
        // 0x00BA2CB4: MOV x1, x19                | X1 = val_4;//m1                         
        // 0x00BA2CB8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2CBC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2CC0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA2CC4: CSET w2, ne                | W2 = this._isClick == true ? 1 : 0;     
        bool val_5 = (this._isClick == true) ? 1 : 0;
        // 0x00BA2CC8: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00BA2CCC: B #0xba2784                | this.onClick.Invoke(go:  val_4, isPress:  bool val_5 = (this._isClick == true) ? 1 : 0); return;
        this.onClick.Invoke(go:  val_4, isPress:  val_5);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2CD0 (12201168), len: 8  VirtAddr: 0x00BA2CD0 RVA: 0x00BA2CD0 token: 100696749 methodIndex: 25559 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnDestroy()
    {
        //
        // Disasemble & Code
        // 0x00BA2CD0: STR xzr, [x0, #0x50]       | this.onClick = null;                     //  dest_result_addr=1152921515580515584
        this.onClick = 0;
        // 0x00BA2CD4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2CD8 (12201176), len: 196  VirtAddr: 0x00BA2CD8 RVA: 0x00BA2CD8 token: 100696750 methodIndex: 25560 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetFunctionState(object isactive)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00BA2CD8: STP x22, x21, [sp, #-0x30]! | stack[1152921515580619552] = ???;  stack[1152921515580619560] = ???;  //  dest_result_addr=1152921515580619552 |  dest_result_addr=1152921515580619560
        // 0x00BA2CDC: STP x20, x19, [sp, #0x10]  | stack[1152921515580619568] = ???;  stack[1152921515580619576] = ???;  //  dest_result_addr=1152921515580619568 |  dest_result_addr=1152921515580619576
        // 0x00BA2CE0: STP x29, x30, [sp, #0x20]  | stack[1152921515580619584] = ???;  stack[1152921515580619592] = ???;  //  dest_result_addr=1152921515580619584 |  dest_result_addr=1152921515580619592
        // 0x00BA2CE4: ADD x29, sp, #0x20         | X29 = (1152921515580619552 + 32) = 1152921515580619584 (0x100000028E167B40);
        // 0x00BA2CE8: SUB sp, sp, #0x10          | SP = (1152921515580619552 - 16) = 1152921515580619536 (0x100000028E167B10);
        // 0x00BA2CEC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA2CF0: LDRB w8, [x21, #0xab7]     | W8 = (bool)static_value_03733AB7;       
        // 0x00BA2CF4: MOV x20, x1                | X20 = isactive;//m1                     
        // 0x00BA2CF8: MOV x19, x0                | X19 = 1152921515580631600 (0x100000028E16AA30);//ML01
        // 0x00BA2CFC: TBNZ w8, #0, #0xba2d18     | if (static_value_03733AB7 == true) goto label_0;
        // 0x00BA2D00: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
        // 0x00BA2D04: LDR x8, [x8, #0x8d8]       | X8 = 0x2B8FEF4;                         
        // 0x00BA2D08: LDR w0, [x8]               | W0 = 0x1681;                            
        // 0x00BA2D0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1681, ????);     
        // 0x00BA2D10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA2D14: STRB w8, [x21, #0xab7]     | static_value_03733AB7 = true;            //  dest_result_addr=57883319
        label_0:
        // 0x00BA2D18: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00BA2D1C: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
        // 0x00BA2D20: LDR x21, [x8]              | X21 = typeof(System.Boolean);           
        // 0x00BA2D24: CBNZ x20, #0xba2d2c        | if (isactive != null) goto label_1;     
        if(isactive != null)
        {
            goto label_1;
        }
        // 0x00BA2D28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1681, ????);     
        label_1:
        // 0x00BA2D2C: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00BA2D30: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA2D34: LDR x8, [x21, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
        // 0x00BA2D38: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Boolean.__il2cppRuntimeField_element_class)
        // 0x00BA2D3C: B.NE #0xba2d64             | if (System.Object.__il2cppRuntimeField_element_class != System.Boolean.__il2cppRuntimeField_element_class) goto label_2;
        // 0x00BA2D40: MOV x0, x20                | X0 = isactive;//m1                      
        // 0x00BA2D44: BL #0x27bc4e8              | isactive.System.IDisposable.Dispose();  
        isactive.System.IDisposable.Dispose();
        // 0x00BA2D48: LDRB w8, [x0]              | W8 = typeof(System.Object);             
        // 0x00BA2D4C: STRB w8, [x19, #0x44]      | this._fun_enable = typeof(System.Object);  //  dest_result_addr=1152921515580631668
        this._fun_enable = null;
        // 0x00BA2D50: SUB sp, x29, #0x20         | SP = (1152921515580619584 - 32) = 1152921515580619552 (0x100000028E167B20);
        // 0x00BA2D54: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2D58: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2D5C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA2D60: RET                        |  return;                                
        return;
        label_2:
        // 0x00BA2D64: ADD x8, sp, #8             | X8 = (1152921515580619536 + 8) = 1152921515580619544 (0x100000028E167B18);
        // 0x00BA2D68: MOV x1, x21                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
        // 0x00BA2D6C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00BA2D70: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921515580607600]
        // 0x00BA2D74: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
        // 0x00BA2D78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2D7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00BA2D80: ADD x0, sp, #8             | X0 = (1152921515580619536 + 8) = 1152921515580619544 (0x100000028E167B18);
        // 0x00BA2D84: BL #0x299a140              | 
        // 0x00BA2D88: MOV x19, x0                | X19 = 1152921515580619544 (0x100000028E167B18);//ML01
        // 0x00BA2D8C: ADD x0, sp, #8             | X0 = (1152921515580619536 + 8) = 1152921515580619544 (0x100000028E167B18);
        // 0x00BA2D90: BL #0x299a140              | 
        // 0x00BA2D94: MOV x0, x19                | X0 = 1152921515580619544 (0x100000028E167B18);//ML01
        // 0x00BA2D98: BL #0x980800               | X0 = sub_980800( ?? 0x100000028E167B18, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2D9C (12201372), len: 12  VirtAddr: 0x00BA2D9C RVA: 0x00BA2D9C token: 100696751 methodIndex: 25561 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetFunctionState(bool isactive)
    {
        //
        // Disasemble & Code
        // 0x00BA2D9C: AND w8, w1, #1             | W8 = (isactive & 1);                    
        bool val_1 = isactive;
        // 0x00BA2DA0: STRB w8, [x0, #0x44]       | this._fun_enable = (isactive & 1);       //  dest_result_addr=1152921515580747764
        this._fun_enable = val_1;
        // 0x00BA2DA4: RET                        |  return;                                
        return;
    
    }

}
