using UnityEngine;

namespace wxb
{
    internal class AnyType : ITypeSerialize
    {
        // Fields
        private System.Type type; //  0x00000010
        private System.Collections.Generic.List<System.Reflection.FieldInfo> fieldInfos; //  0x00000018
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2AC6C (14855276), len: 56  VirtAddr: 0x00E2AC6C RVA: 0x00E2AC6C token: 100681097 methodIndex: 57185 delegateWrapperIndex: 0 methodInvoker: 0
        public AnyType(System.Type type, System.Collections.Generic.List<System.Reflection.FieldInfo> fieldInfos)
        {
            //
            // Disasemble & Code
            // 0x00E2AC6C: STP x22, x21, [sp, #-0x30]! | stack[1152921513013923152] = ???;  stack[1152921513013923160] = ???;  //  dest_result_addr=1152921513013923152 |  dest_result_addr=1152921513013923160
            // 0x00E2AC70: STP x20, x19, [sp, #0x10]  | stack[1152921513013923168] = ???;  stack[1152921513013923176] = ???;  //  dest_result_addr=1152921513013923168 |  dest_result_addr=1152921513013923176
            // 0x00E2AC74: STP x29, x30, [sp, #0x20]  | stack[1152921513013923184] = ???;  stack[1152921513013923192] = ???;  //  dest_result_addr=1152921513013923184 |  dest_result_addr=1152921513013923192
            // 0x00E2AC78: ADD x29, sp, #0x20         | X29 = (1152921513013923152 + 32) = 1152921513013923184 (0x10000001F519CD70);
            // 0x00E2AC7C: MOV x20, x1                | X20 = type;//m1                         
            // 0x00E2AC80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2AC84: MOV x19, x2                | X19 = fieldInfos;//m1                   
            // 0x00E2AC88: MOV x21, x0                | X21 = 1152921513013935200 (0x10000001F519FC60);//ML01
            // 0x00E2AC8C: BL #0x16f59f0              | fieldInfos..ctor();                     
            val_1 = new System.Object();
            // 0x00E2AC90: STP x20, x19, [x21, #0x10] | this.type = type;  this.fieldInfos = fieldInfos;  //  dest_result_addr=1152921513013935216 |  dest_result_addr=1152921513013935224
            this.type = type;
            this.fieldInfos = val_1;
            // 0x00E2AC94: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2AC98: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2AC9C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2ACA0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2ACA4 (14855332), len: 556  VirtAddr: 0x00E2ACA4 RVA: 0x00E2ACA4 token: 100681098 methodIndex: 57186 delegateWrapperIndex: 0 methodInvoker: 0
        private int wxb.ITypeSerialize.CalculateSize(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            // 0x00E2ACA4: STP x28, x27, [sp, #-0x60]! | stack[1152921513014065824] = ???;  stack[1152921513014065832] = ???;  //  dest_result_addr=1152921513014065824 |  dest_result_addr=1152921513014065832
            // 0x00E2ACA8: STP x26, x25, [sp, #0x10]  | stack[1152921513014065840] = ???;  stack[1152921513014065848] = ???;  //  dest_result_addr=1152921513014065840 |  dest_result_addr=1152921513014065848
            // 0x00E2ACAC: STP x24, x23, [sp, #0x20]  | stack[1152921513014065856] = ???;  stack[1152921513014065864] = ???;  //  dest_result_addr=1152921513014065856 |  dest_result_addr=1152921513014065864
            // 0x00E2ACB0: STP x22, x21, [sp, #0x30]  | stack[1152921513014065872] = ???;  stack[1152921513014065880] = ???;  //  dest_result_addr=1152921513014065872 |  dest_result_addr=1152921513014065880
            // 0x00E2ACB4: STP x20, x19, [sp, #0x40]  | stack[1152921513014065888] = ???;  stack[1152921513014065896] = ???;  //  dest_result_addr=1152921513014065888 |  dest_result_addr=1152921513014065896
            // 0x00E2ACB8: STP x29, x30, [sp, #0x50]  | stack[1152921513014065904] = ???;  stack[1152921513014065912] = ???;  //  dest_result_addr=1152921513014065904 |  dest_result_addr=1152921513014065912
            // 0x00E2ACBC: ADD x29, sp, #0x50         | X29 = (1152921513014065824 + 80) = 1152921513014065904 (0x10000001F51BFAF0);
            // 0x00E2ACC0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2ACC4: LDRB w8, [x21, #0x8e6]     | W8 = (bool)static_value_037348E6;       
            // 0x00E2ACC8: MOV x19, x1                | X19 = value;//m1                        
            // 0x00E2ACCC: MOV x20, x0                | X20 = 1152921513014077920 (0x10000001F51C29E0);//ML01
            // 0x00E2ACD0: TBNZ w8, #0, #0xe2acec     | if (static_value_037348E6 == true) goto label_0;
            // 0x00E2ACD4: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00E2ACD8: LDR x8, [x8, #0x588]       | X8 = 0x2B8AFBC;                         
            // 0x00E2ACDC: LDR w0, [x8]               | W0 = 0x2AD;                             
            // 0x00E2ACE0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2AD, ????);      
            // 0x00E2ACE4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2ACE8: STRB w8, [x21, #0x8e6]     | static_value_037348E6 = true;            //  dest_result_addr=57886950
            label_0:
            // 0x00E2ACEC: CBZ x19, #0xe2aeac         | if (value == null) goto label_1;        
            if(value == null)
            {
                goto label_1;
            }
            // 0x00E2ACF0: ADRP x26, #0x35c8000       | X26 = 56393728 (0x35C8000);             
            // 0x00E2ACF4: ADRP x27, #0x35f4000       | X27 = 56573952 (0x35F4000);             
            // 0x00E2ACF8: ADRP x28, #0x35fb000       | X28 = 56602624 (0x35FB000);             
            // 0x00E2ACFC: LDR x26, [x26, #0x4c0]     | X26 = 1152921513014035488;              
            // 0x00E2AD00: LDR x27, [x27, #0xb30]     | X27 = 1152921513014036512;              
            // 0x00E2AD04: LDR x28, [x28, #0x108]     | X28 = 1152921504831660032;              
            // 0x00E2AD08: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00E2AD0C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00E2AD10: B #0xe2ad18                |  goto label_2;                          
            goto label_2;
            label_17:
            // 0x00E2AD14: ADD w21, w21, #1           | W21 = (val_8 + 1) = val_8 (0x00000001); 
            val_8 = 1;
            label_2:
            // 0x00E2AD18: LDR x23, [x20, #0x18]      | X23 = this.fieldInfos; //P2             
            // 0x00E2AD1C: CBNZ x23, #0xe2ad24        | if (this.fieldInfos != null) goto label_3;
            if(this.fieldInfos != null)
            {
                goto label_3;
            }
            // 0x00E2AD20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2AD, ????);      
            label_3:
            // 0x00E2AD24: LDR x1, [x26]              | X1 = public System.Int32 System.Collections.Generic.List<System.Reflection.FieldInfo>::get_Count();
            // 0x00E2AD28: MOV x0, x23                | X0 = this.fieldInfos;//m1               
            // 0x00E2AD2C: BL #0x25ed72c              | X0 = this.fieldInfos.get_Count();       
            int val_1 = this.fieldInfos.Count;
            // 0x00E2AD30: CMP w21, w0                | STATE = COMPARE(0x1, val_1)             
            // 0x00E2AD34: B.GE #0xe2aeb0             | if (val_8 >= val_1) goto label_4;       
            if(val_8 >= val_1)
            {
                goto label_4;
            }
            // 0x00E2AD38: LDR x23, [x20, #0x18]      | X23 = this.fieldInfos; //P2             
            // 0x00E2AD3C: CBNZ x23, #0xe2ad44        | if (this.fieldInfos != null) goto label_5;
            if(this.fieldInfos != null)
            {
                goto label_5;
            }
            // 0x00E2AD40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x00E2AD44: LDR x2, [x27]              | X2 = public System.Reflection.FieldInfo System.Collections.Generic.List<System.Reflection.FieldInfo>::get_Item(int index);
            // 0x00E2AD48: MOV x0, x23                | X0 = this.fieldInfos;//m1               
            // 0x00E2AD4C: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
            // 0x00E2AD50: BL #0x25ed734              | X0 = this.fieldInfos.get_Item(index:  1);
            System.Reflection.FieldInfo val_2 = this.fieldInfos.Item[1];
            // 0x00E2AD54: MOV x24, x0                | X24 = val_2;//m1                        
            // 0x00E2AD58: CBNZ x24, #0xe2ad60        | if (val_2 != null) goto label_6;        
            if(val_2 != null)
            {
                goto label_6;
            }
            // 0x00E2AD5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x00E2AD60: LDR x8, [x24]              | X8 = typeof(System.Reflection.FieldInfo);
            // 0x00E2AD64: MOV x0, x24                | X0 = val_2;//m1                         
            // 0x00E2AD68: MOV x1, x19                | X1 = value;//m1                         
            // 0x00E2AD6C: LDR x9, [x8, #0x220]       | X9 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_220;
            // 0x00E2AD70: LDR x2, [x8, #0x228]       | X2 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_228;
            // 0x00E2AD74: BLR x9                     | X0 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_220();
            // 0x00E2AD78: MOV x23, x0                | X23 = val_2;//m1                        
            // 0x00E2AD7C: CBZ x23, #0xe2ad14         | if (val_2 == null) goto label_17;       
            if(val_2 == null)
            {
                goto label_17;
            }
            // 0x00E2AD80: LDR x8, [x24]              | X8 = typeof(System.Reflection.FieldInfo);
            // 0x00E2AD84: MOV x0, x24                | X0 = val_2;//m1                         
            // 0x00E2AD88: LDR x9, [x8, #0x210]       | X9 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_210;
            // 0x00E2AD8C: LDR x1, [x8, #0x218]       | X1 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_218;
            // 0x00E2AD90: BLR x9                     | X0 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_210();
            // 0x00E2AD94: LDR x8, [x24]              | X8 = typeof(System.Reflection.FieldInfo);
            // 0x00E2AD98: MOV x0, x24                | X0 = val_2;//m1                         
            // 0x00E2AD9C: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_190; X1 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_198; //  | 
            // 0x00E2ADA0: BLR x9                     | X0 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_190();
            // 0x00E2ADA4: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x00E2ADA8: LDR x8, [x8, #0xfd8]       | X8 = 1152921504831766528;               
            // 0x00E2ADAC: MOV x25, x0                | X25 = val_2;//m1                        
            // 0x00E2ADB0: LDR x8, [x8]               | X8 = typeof(wxb.WRStream);              
            // 0x00E2ADB4: LDRB w9, [x8, #0x10a]      | W9 = wxb.WRStream.__il2cppRuntimeField_10A;
            // 0x00E2ADB8: TBZ w9, #0, #0xe2adcc      | if (wxb.WRStream.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00E2ADBC: LDR w9, [x8, #0xbc]        | W9 = wxb.WRStream.__il2cppRuntimeField_cctor_finished;
            // 0x00E2ADC0: CBNZ w9, #0xe2adcc         | if (wxb.WRStream.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00E2ADC4: MOV x0, x8                 | X0 = 1152921504831766528 (0x100000000D680000);//ML01
            // 0x00E2ADC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.WRStream), ????);
            label_9:
            // 0x00E2ADCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2ADD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2ADD4: MOV x1, x25                | X1 = val_2;//m1                         
            // 0x00E2ADD8: BL #0x26a3c24              | X0 = wxb.WRStream.ComputeStringSize(value:  0);
            int val_3 = wxb.WRStream.ComputeStringSize(value:  0);
            // 0x00E2ADDC: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x00E2ADE0: LDR x8, [x8, #0xa58]       | X8 = 1152921504831713280;               
            // 0x00E2ADE4: MOV w25, w0                | W25 = val_3;//m1                        
            var val_8 = val_3;
            // 0x00E2ADE8: LDR x8, [x8]               | X8 = typeof(wxb.MonoSerialize);         
            // 0x00E2ADEC: LDRB w9, [x8, #0x10a]      | W9 = wxb.MonoSerialize.__il2cppRuntimeField_10A;
            // 0x00E2ADF0: TBZ w9, #0, #0xe2ae04      | if (wxb.MonoSerialize.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00E2ADF4: LDR w9, [x8, #0xbc]        | W9 = wxb.MonoSerialize.__il2cppRuntimeField_cctor_finished;
            // 0x00E2ADF8: CBNZ w9, #0xe2ae04         | if (wxb.MonoSerialize.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00E2ADFC: MOV x0, x8                 | X0 = 1152921504831713280 (0x100000000D673000);//ML01
            // 0x00E2AE00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.MonoSerialize), ????);
            label_11:
            // 0x00E2AE04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2AE08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x00E2AE0C: MOV x1, x24                | X1 = val_2;//m1                         
            // 0x00E2AE10: BL #0x269f45c              | X0 = wxb.MonoSerialize.GetByType(fieldInfo:  0);
            wxb.ITypeSerialize val_4 = wxb.MonoSerialize.GetByType(fieldInfo:  0);
            // 0x00E2AE14: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00E2AE18: CBNZ x24, #0xe2ae20        | if (val_4 != null) goto label_12;       
            if(val_4 != null)
            {
                goto label_12;
            }
            // 0x00E2AE1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x00E2AE20: LDR x8, [x24]              | X8 = typeof(wxb.ITypeSerialize);        
            // 0x00E2AE24: LDR x1, [x28]              | X1 = typeof(wxb.ITypeSerialize);        
            // 0x00E2AE28: ADD w25, w25, w22          | W25 = (val_3 + val_9);                  
            val_8 = val_8 + val_9;
            // 0x00E2AE2C: LDRH w9, [x8, #0x102]      | W9 = wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E2AE30: CBZ x9, #0xe2ae5c          | if (wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count == 0) goto label_13;
            // 0x00E2AE34: LDR x10, [x8, #0x98]       | X10 = wxb.ITypeSerialize.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E2AE38: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x00E2AE3C: ADD x10, x10, #8           | X10 = (wxb.ITypeSerialize.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504831696904 (0x100000000D66F008);
            label_15:
            // 0x00E2AE40: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E2AE44: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(wxb.ITypeSerialize))
            // 0x00E2AE48: B.EQ #0xe2ae6c             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_14;
            // 0x00E2AE4C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x00E2AE50: ADD x10, x10, #0x10        | X10 = (1152921504831696904 + 16) = 1152921504831696920 (0x100000000D66F018);
            // 0x00E2AE54: CMP x11, x9                | STATE = COMPARE((0 + 1), wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E2AE58: B.LO #0xe2ae40             | if (0 < wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count) goto label_15;
            label_13:
            // 0x00E2AE5C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            val_10 = 2;
            // 0x00E2AE60: MOV x0, x24                | X0 = val_4;//m1                         
            val_11 = val_4;
            // 0x00E2AE64: BL #0x2776c24              | X0 = sub_2776C24( ?? val_4, ????);      
            // 0x00E2AE68: B #0xe2ae7c                |  goto label_16;                         
            goto label_16;
            label_14:
            // 0x00E2AE6C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E2AE70: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x00E2AE74: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504831660032 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x00E2AE78: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504831660032 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_16:
            // 0x00E2AE7C: LDP x8, x2, [x0]           | X8 = typeof(wxb.ITypeSerialize);         //  | 
            // 0x00E2AE80: MOV x0, x24                | X0 = val_4;//m1                         
            // 0x00E2AE84: MOV x1, x23                | X1 = val_2;//m1                         
            // 0x00E2AE88: BLR x8                     | X0 = sub_100000000D666000( ?? val_4, ????);
            // 0x00E2AE8C: MOV w22, w0                | W22 = val_4;//m1                        
            var val_10 = val_4;
            // 0x00E2AE90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2AE94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2AE98: MOV w1, w22                | W1 = val_4;//m1                         
            // 0x00E2AE9C: BL #0x26a48fc              | X0 = wxb.WRStream.ComputeLengthSize(length:  0);
            int val_6 = wxb.WRStream.ComputeLengthSize(length:  0);
            // 0x00E2AEA0: ADD w8, w25, w22           | W8 = ((val_3 + val_9) + val_4);         
            int val_7 = val_8 + val_10;
            // 0x00E2AEA4: ADD w22, w8, w0            | W22 = (((val_3 + val_9) + val_4) + val_6);
            val_10 = val_7 + val_6;
            // 0x00E2AEA8: B #0xe2ad14                |  goto label_17;                         
            goto label_17;
            label_1:
            // 0x00E2AEAC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_4:
            // 0x00E2AEB0: MOV w0, w22                | W0 = 0 (0x0);//ML01                     
            // 0x00E2AEB4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2AEB8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2AEBC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2AEC0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E2AEC4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E2AEC8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E2AECC: RET                        |  return (System.Int32)0;                
            return (int)val_9;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2AED0 (14855888), len: 632  VirtAddr: 0x00E2AED0 RVA: 0x00E2AED0 token: 100681099 methodIndex: 57187 delegateWrapperIndex: 0 methodInvoker: 0
        private void wxb.ITypeSerialize.WriteTo(object value, wxb.MonoStream ms)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00E2AED0: STP x28, x27, [sp, #-0x60]! | stack[1152921513014226976] = ???;  stack[1152921513014226984] = ???;  //  dest_result_addr=1152921513014226976 |  dest_result_addr=1152921513014226984
            // 0x00E2AED4: STP x26, x25, [sp, #0x10]  | stack[1152921513014226992] = ???;  stack[1152921513014227000] = ???;  //  dest_result_addr=1152921513014226992 |  dest_result_addr=1152921513014227000
            // 0x00E2AED8: STP x24, x23, [sp, #0x20]  | stack[1152921513014227008] = ???;  stack[1152921513014227016] = ???;  //  dest_result_addr=1152921513014227008 |  dest_result_addr=1152921513014227016
            // 0x00E2AEDC: STP x22, x21, [sp, #0x30]  | stack[1152921513014227024] = ???;  stack[1152921513014227032] = ???;  //  dest_result_addr=1152921513014227024 |  dest_result_addr=1152921513014227032
            // 0x00E2AEE0: STP x20, x19, [sp, #0x40]  | stack[1152921513014227040] = ???;  stack[1152921513014227048] = ???;  //  dest_result_addr=1152921513014227040 |  dest_result_addr=1152921513014227048
            // 0x00E2AEE4: STP x29, x30, [sp, #0x50]  | stack[1152921513014227056] = ???;  stack[1152921513014227064] = ???;  //  dest_result_addr=1152921513014227056 |  dest_result_addr=1152921513014227064
            // 0x00E2AEE8: ADD x29, sp, #0x50         | X29 = (1152921513014226976 + 80) = 1152921513014227056 (0x10000001F51E7070);
            // 0x00E2AEEC: SUB sp, sp, #0x10          | SP = (1152921513014226976 - 16) = 1152921513014226960 (0x10000001F51E7010);
            // 0x00E2AEF0: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E2AEF4: LDRB w8, [x19, #0x8e7]     | W8 = (bool)static_value_037348E7;       
            // 0x00E2AEF8: MOV x22, x2                | X22 = ms;//m1                           
            // 0x00E2AEFC: MOV x20, x1                | X20 = value;//m1                        
            // 0x00E2AF00: MOV x21, x0                | X21 = 1152921513014239072 (0x10000001F51E9F60);//ML01
            // 0x00E2AF04: TBNZ w8, #0, #0xe2af20     | if (static_value_037348E7 == true) goto label_0;
            // 0x00E2AF08: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x00E2AF0C: LDR x8, [x8, #0x320]       | X8 = 0x2B8AFC0;                         
            // 0x00E2AF10: LDR w0, [x8]               | W0 = 0x2AE;                             
            // 0x00E2AF14: BL #0x2782188              | X0 = sub_2782188( ?? 0x2AE, ????);      
            // 0x00E2AF18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2AF1C: STRB w8, [x19, #0x8e7]     | static_value_037348E7 = true;            //  dest_result_addr=57886951
            label_0:
            // 0x00E2AF20: CBZ x20, #0xe2b128         | if (value == null) goto label_5;        
            if(value == null)
            {
                goto label_5;
            }
            // 0x00E2AF24: MOV x19, x22               | X19 = ms;//m1                           
            // 0x00E2AF28: CBNZ x19, #0xe2af30        | if (ms != null) goto label_2;           
            if(ms != null)
            {
                goto label_2;
            }
            // 0x00E2AF2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2AE, ????);      
            label_2:
            // 0x00E2AF30: LDR x23, [x19, #0x10]      | X23 = ms.Stream; //P2                   
            // 0x00E2AF34: STR x19, [sp, #8]          | stack[1152921513014226968] = ms;         //  dest_result_addr=1152921513014226968
            // 0x00E2AF38: ADRP x27, #0x35c8000       | X27 = 56393728 (0x35C8000);             
            // 0x00E2AF3C: ADRP x28, #0x35f4000       | X28 = 56573952 (0x35F4000);             
            // 0x00E2AF40: ADRP x19, #0x35fb000       | X19 = 56602624 (0x35FB000);             
            // 0x00E2AF44: LDR x27, [x27, #0x4c0]     | X27 = 1152921513014035488;              
            // 0x00E2AF48: LDR x28, [x28, #0xb30]     | X28 = 1152921513014036512;              
            // 0x00E2AF4C: LDR x19, [x19, #0x108]     | X19 = 1152921504831660032;              
            val_6 = 1152921504831660032;
            // 0x00E2AF50: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x00E2AF54: B #0xe2af5c                |  goto label_3;                          
            goto label_3;
            label_24:
            // 0x00E2AF58: ADD w22, w22, #1           | W22 = (val_7 + 1) = val_7 (0x00000001); 
            val_7 = 1;
            label_3:
            // 0x00E2AF5C: LDR x24, [x21, #0x18]      | X24 = this.fieldInfos; //P2             
            // 0x00E2AF60: CBNZ x24, #0xe2af68        | if (this.fieldInfos != null) goto label_4;
            if(this.fieldInfos != null)
            {
                goto label_4;
            }
            // 0x00E2AF64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2AE, ????);      
            label_4:
            // 0x00E2AF68: LDR x1, [x27]              | X1 = public System.Int32 System.Collections.Generic.List<System.Reflection.FieldInfo>::get_Count();
            // 0x00E2AF6C: MOV x0, x24                | X0 = this.fieldInfos;//m1               
            // 0x00E2AF70: BL #0x25ed72c              | X0 = this.fieldInfos.get_Count();       
            int val_1 = this.fieldInfos.Count;
            // 0x00E2AF74: CMP w22, w0                | STATE = COMPARE(0x1, val_1)             
            // 0x00E2AF78: B.GE #0xe2b128             | if (val_7 >= val_1) goto label_5;       
            if(val_7 >= val_1)
            {
                goto label_5;
            }
            // 0x00E2AF7C: LDR x24, [x21, #0x18]      | X24 = this.fieldInfos; //P2             
            // 0x00E2AF80: CBNZ x24, #0xe2af88        | if (this.fieldInfos != null) goto label_6;
            if(this.fieldInfos != null)
            {
                goto label_6;
            }
            // 0x00E2AF84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x00E2AF88: LDR x2, [x28]              | X2 = public System.Reflection.FieldInfo System.Collections.Generic.List<System.Reflection.FieldInfo>::get_Item(int index);
            // 0x00E2AF8C: MOV x0, x24                | X0 = this.fieldInfos;//m1               
            // 0x00E2AF90: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
            // 0x00E2AF94: BL #0x25ed734              | X0 = this.fieldInfos.get_Item(index:  1);
            System.Reflection.FieldInfo val_2 = this.fieldInfos.Item[1];
            // 0x00E2AF98: MOV x26, x0                | X26 = val_2;//m1                        
            // 0x00E2AF9C: CBNZ x26, #0xe2afa4        | if (val_2 != null) goto label_7;        
            if(val_2 != null)
            {
                goto label_7;
            }
            // 0x00E2AFA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x00E2AFA4: LDR x8, [x26]              | X8 = typeof(System.Reflection.FieldInfo);
            // 0x00E2AFA8: MOV x0, x26                | X0 = val_2;//m1                         
            // 0x00E2AFAC: MOV x1, x20                | X1 = value;//m1                         
            // 0x00E2AFB0: LDR x9, [x8, #0x220]       | X9 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_220;
            // 0x00E2AFB4: LDR x2, [x8, #0x228]       | X2 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_228;
            // 0x00E2AFB8: BLR x9                     | X0 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_220();
            // 0x00E2AFBC: MOV x24, x0                | X24 = val_2;//m1                        
            // 0x00E2AFC0: CBZ x24, #0xe2af58         | if (val_2 == null) goto label_24;       
            if(val_2 == null)
            {
                goto label_24;
            }
            // 0x00E2AFC4: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x00E2AFC8: LDR x8, [x8, #0xa58]       | X8 = 1152921504831713280;               
            // 0x00E2AFCC: LDR x0, [x8]               | X0 = typeof(wxb.MonoSerialize);         
            // 0x00E2AFD0: LDRB w8, [x0, #0x10a]      | W8 = wxb.MonoSerialize.__il2cppRuntimeField_10A;
            // 0x00E2AFD4: TBZ w8, #0, #0xe2afe4      | if (wxb.MonoSerialize.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00E2AFD8: LDR w8, [x0, #0xbc]        | W8 = wxb.MonoSerialize.__il2cppRuntimeField_cctor_finished;
            // 0x00E2AFDC: CBNZ w8, #0xe2afe4         | if (wxb.MonoSerialize.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00E2AFE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.MonoSerialize), ????);
            label_10:
            // 0x00E2AFE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2AFE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2AFEC: MOV x1, x26                | X1 = val_2;//m1                         
            // 0x00E2AFF0: BL #0x269f45c              | X0 = wxb.MonoSerialize.GetByType(fieldInfo:  0);
            wxb.ITypeSerialize val_3 = wxb.MonoSerialize.GetByType(fieldInfo:  0);
            // 0x00E2AFF4: LDR x8, [x26]              | X8 = typeof(System.Reflection.FieldInfo);
            // 0x00E2AFF8: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00E2AFFC: MOV x0, x26                | X0 = val_2;//m1                         
            // 0x00E2B000: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_190; X1 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_198; //  | 
            // 0x00E2B004: BLR x9                     | X0 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_190();
            // 0x00E2B008: MOV x26, x0                | X26 = val_2;//m1                        
            // 0x00E2B00C: CBNZ x23, #0xe2b014        | if (ms.Stream != null) goto label_11;   
            if(ms.Stream != null)
            {
                goto label_11;
            }
            // 0x00E2B010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_11:
            // 0x00E2B014: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x00E2B018: MOV x0, x23                | X0 = ms.Stream;//m1                     
            // 0x00E2B01C: MOV x1, x26                | X1 = val_2;//m1                         
            // 0x00E2B020: BL #0x26a3d18              | ms.Stream.WriteString(value:  val_2);   
            ms.Stream.WriteString(value:  val_2);
            // 0x00E2B024: CBNZ x25, #0xe2b02c        | if (val_3 != null) goto label_12;       
            if(val_3 != null)
            {
                goto label_12;
            }
            // 0x00E2B028: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ms.Stream, ????);  
            label_12:
            // 0x00E2B02C: LDR x8, [x25]              | X8 = typeof(wxb.ITypeSerialize);        
            // 0x00E2B030: LDR x1, [x19]              | X1 = typeof(wxb.ITypeSerialize);        
            // 0x00E2B034: LDRH w9, [x8, #0x102]      | W9 = wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E2B038: CBZ x9, #0xe2b064          | if (wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count == 0) goto label_13;
            // 0x00E2B03C: LDR x10, [x8, #0x98]       | X10 = wxb.ITypeSerialize.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E2B040: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x00E2B044: ADD x10, x10, #8           | X10 = (wxb.ITypeSerialize.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504831696904 (0x100000000D66F008);
            label_15:
            // 0x00E2B048: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E2B04C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(wxb.ITypeSerialize))
            // 0x00E2B050: B.EQ #0xe2b074             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_14;
            // 0x00E2B054: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x00E2B058: ADD x10, x10, #0x10        | X10 = (1152921504831696904 + 16) = 1152921504831696920 (0x100000000D66F018);
            // 0x00E2B05C: CMP x11, x9                | STATE = COMPARE((0 + 1), wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E2B060: B.LO #0xe2b048             | if (0 < wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count) goto label_15;
            label_13:
            // 0x00E2B064: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            val_8 = 2;
            // 0x00E2B068: MOV x0, x25                | X0 = val_3;//m1                         
            val_9 = val_3;
            // 0x00E2B06C: BL #0x2776c24              | X0 = sub_2776C24( ?? val_3, ????);      
            // 0x00E2B070: B #0xe2b084                |  goto label_16;                         
            goto label_16;
            label_14:
            // 0x00E2B074: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E2B078: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x00E2B07C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504831660032 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x00E2B080: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504831660032 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_16:
            // 0x00E2B084: LDP x8, x2, [x0]           | X8 = typeof(wxb.WRStream);               //  | 
            // 0x00E2B088: MOV x0, x25                | X0 = val_3;//m1                         
            // 0x00E2B08C: MOV x1, x24                | X1 = val_2;//m1                         
            // 0x00E2B090: BLR x8                     | X0 = sub_100000000D680000( ?? val_3, ????);
            // 0x00E2B094: MOV w26, w0                | W26 = val_3;//m1                        
            // 0x00E2B098: CBZ w26, #0xe2af58         | if (val_3 == null) goto label_24;       
            if(val_3 == null)
            {
                goto label_24;
            }
            // 0x00E2B09C: CBNZ x23, #0xe2b0a4        | if (ms.Stream != null) goto label_18;   
            if(ms.Stream != null)
            {
                goto label_18;
            }
            // 0x00E2B0A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_18:
            // 0x00E2B0A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2B0A8: MOV x0, x23                | X0 = ms.Stream;//m1                     
            // 0x00E2B0AC: MOV w1, w26                | W1 = val_3;//m1                         
            // 0x00E2B0B0: BL #0x26a4da0              | ms.Stream.WriteLength(length:  val_3);  
            ms.Stream.WriteLength(length:  val_3);
            // 0x00E2B0B4: CBNZ x25, #0xe2b0bc        | if (val_3 != null) goto label_19;       
            if(val_3 != null)
            {
                goto label_19;
            }
            // 0x00E2B0B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ms.Stream, ????);  
            label_19:
            // 0x00E2B0BC: LDR x8, [x25]              | X8 = typeof(wxb.ITypeSerialize);        
            // 0x00E2B0C0: LDR x1, [x19]              | X1 = typeof(wxb.ITypeSerialize);        
            // 0x00E2B0C4: LDRH w9, [x8, #0x102]      | W9 = wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E2B0C8: CBZ x9, #0xe2b0f4          | if (wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count == 0) goto label_20;
            // 0x00E2B0CC: LDR x10, [x8, #0x98]       | X10 = wxb.ITypeSerialize.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E2B0D0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x00E2B0D4: ADD x10, x10, #8           | X10 = (wxb.ITypeSerialize.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504831696904 (0x100000000D66F008);
            label_22:
            // 0x00E2B0D8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E2B0DC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(wxb.ITypeSerialize))
            // 0x00E2B0E0: B.EQ #0xe2b104             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_21;
            // 0x00E2B0E4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x00E2B0E8: ADD x10, x10, #0x10        | X10 = (1152921504831696904 + 16) = 1152921504831696920 (0x100000000D66F018);
            // 0x00E2B0EC: CMP x11, x9                | STATE = COMPARE((0 + 1), wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E2B0F0: B.LO #0xe2b0d8             | if (0 < wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count) goto label_22;
            label_20:
            // 0x00E2B0F4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00E2B0F8: MOV x0, x25                | X0 = val_3;//m1                         
            val_10 = val_3;
            // 0x00E2B0FC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_3, ????);      
            // 0x00E2B100: B #0xe2b110                |  goto label_23;                         
            goto label_23;
            label_21:
            // 0x00E2B104: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E2B108: ADD x8, x8, x9, lsl #4     | X8 = (1152921504831660032 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00E2B10C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504831660032 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_23:
            // 0x00E2B110: LDP x8, x3, [x0]           | X8 = typeof(wxb.WRStream);               //  | 
            // 0x00E2B114: LDR x2, [sp, #8]           | X2 = ms;                                
            // 0x00E2B118: MOV x0, x25                | X0 = val_3;//m1                         
            // 0x00E2B11C: MOV x1, x24                | X1 = val_2;//m1                         
            // 0x00E2B120: BLR x8                     | X0 = sub_100000000D680000( ?? val_3, ????);
            // 0x00E2B124: B #0xe2af58                |  goto label_24;                         
            goto label_24;
            label_5:
            // 0x00E2B128: SUB sp, x29, #0x50         | SP = (1152921513014227056 - 80) = 1152921513014226976 (0x10000001F51E7020);
            // 0x00E2B12C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2B130: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2B134: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2B138: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E2B13C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E2B140: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E2B144: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2B148 (14856520), len: 1120  VirtAddr: 0x00E2B148 RVA: 0x00E2B148 token: 100681100 methodIndex: 57188 delegateWrapperIndex: 0 methodInvoker: 0
        public void MergeFrom(ref object value, wxb.MonoStream ms)
        {
            //
            // Disasemble & Code
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            // 0x00E2B148: STP x28, x27, [sp, #-0x60]! | stack[1152921513014407504] = ???;  stack[1152921513014407512] = ???;  //  dest_result_addr=1152921513014407504 |  dest_result_addr=1152921513014407512
            // 0x00E2B14C: STP x26, x25, [sp, #0x10]  | stack[1152921513014407520] = ???;  stack[1152921513014407528] = ???;  //  dest_result_addr=1152921513014407520 |  dest_result_addr=1152921513014407528
            // 0x00E2B150: STP x24, x23, [sp, #0x20]  | stack[1152921513014407536] = ???;  stack[1152921513014407544] = ???;  //  dest_result_addr=1152921513014407536 |  dest_result_addr=1152921513014407544
            // 0x00E2B154: STP x22, x21, [sp, #0x30]  | stack[1152921513014407552] = ???;  stack[1152921513014407560] = ???;  //  dest_result_addr=1152921513014407552 |  dest_result_addr=1152921513014407560
            // 0x00E2B158: STP x20, x19, [sp, #0x40]  | stack[1152921513014407568] = ???;  stack[1152921513014407576] = ???;  //  dest_result_addr=1152921513014407568 |  dest_result_addr=1152921513014407576
            // 0x00E2B15C: STP x29, x30, [sp, #0x50]  | stack[1152921513014407584] = ???;  stack[1152921513014407592] = ???;  //  dest_result_addr=1152921513014407584 |  dest_result_addr=1152921513014407592
            // 0x00E2B160: ADD x29, sp, #0x50         | X29 = (1152921513014407504 + 80) = 1152921513014407584 (0x10000001F52131A0);
            // 0x00E2B164: SUB sp, sp, #0x20          | SP = (1152921513014407504 - 32) = 1152921513014407472 (0x10000001F5213130);
            // 0x00E2B168: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2B16C: LDRB w8, [x21, #0x8e8]     | W8 = (bool)static_value_037348E8;       
            // 0x00E2B170: MOV x19, x2                | X19 = ms;//m1                           
            // 0x00E2B174: MOV x20, x1                | X20 = 1152921513014451600 (0x10000001F521DD90);//ML01
            // 0x00E2B178: MOV x27, x0                | X27 = 1152921513014419600 (0x10000001F5216090);//ML01
            // 0x00E2B17C: STR x27, [sp, #8]          | stack[1152921513014407480] = this;       //  dest_result_addr=1152921513014407480
            // 0x00E2B180: TBNZ w8, #0, #0xe2b19c     | if (static_value_037348E8 == true) goto label_0;
            // 0x00E2B184: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00E2B188: LDR x8, [x8, #0x6f8]       | X8 = 0x2B8AFB8;                         
            // 0x00E2B18C: LDR w0, [x8]               | W0 = 0x2AC;                             
            // 0x00E2B190: BL #0x2782188              | X0 = sub_2782188( ?? 0x2AC, ????);      
            // 0x00E2B194: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2B198: STRB w8, [x21, #0x8e8]     | static_value_037348E8 = true;            //  dest_result_addr=57886952
            label_0:
            // 0x00E2B19C: STR xzr, [sp, #0x18]       | stack[1152921513014407496] = 0x0;        //  dest_result_addr=1152921513014407496
            // 0x00E2B1A0: LDR x8, [x20]              | X8 = value;                             
            // 0x00E2B1A4: CBNZ x8, #0xe2b1d8         | if (value != null) goto label_1;        
            if(value != null)
            {
                goto label_1;
            }
            // 0x00E2B1A8: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00E2B1AC: LDR x8, [x8, #0xb60]       | X8 = 1152921504828358656;               
            // 0x00E2B1B0: LDR x22, [x27, #0x10]      | X22 = this.type; //P2                   
            // 0x00E2B1B4: LDR x0, [x8]               | X0 = typeof(wxb.IL.Help);               
            // 0x00E2B1B8: LDRB w8, [x0, #0x10a]      | W8 = wxb.IL.Help.__il2cppRuntimeField_10A;
            // 0x00E2B1BC: TBZ w8, #0, #0xe2b1cc      | if (wxb.IL.Help.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E2B1C0: LDR w8, [x0, #0xbc]        | W8 = wxb.IL.Help.__il2cppRuntimeField_cctor_finished;
            // 0x00E2B1C4: CBNZ w8, #0xe2b1cc         | if (wxb.IL.Help.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E2B1C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.IL.Help), ????);
            label_3:
            // 0x00E2B1CC: MOV x1, x22                | X1 = this.type;//m1                     
            // 0x00E2B1D0: BL #0xe2b5a8               | X0 = wxb.IL.Help.Create(type:  null);   
            object val_1 = wxb.IL.Help.Create(type:  null);
            // 0x00E2B1D4: STR x0, [x20]              | value = val_1;                           //  dest_result_addr=1152921513014451600
            value = val_1;
            label_1:
            // 0x00E2B1D8: CBNZ x19, #0xe2b1e0        | if (ms != null) goto label_4;           
            if(ms != null)
            {
                goto label_4;
            }
            // 0x00E2B1DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00E2B1E0: ADRP x21, #0x35cb000       | X21 = 56406016 (0x35CB000);             
            // 0x00E2B1E4: ADRP x28, #0x35f0000       | X28 = 56557568 (0x35F0000);             
            // 0x00E2B1E8: LDR x22, [x19, #0x10]      | X22 = ms.Stream; //P2                   
            // 0x00E2B1EC: LDR x21, [x21, #0x518]     | X21 = 1152921504829636608;              
            // 0x00E2B1F0: LDR x28, [x28, #0xbe0]     | X28 = 1152921513014376144;              
            // 0x00E2B1F4: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x00E2B1F8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            // 0x00E2B1FC: B #0xe2b4a8                |  goto label_28;                         
            goto label_28;
            label_29:
            // 0x00E2B200: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B204: MOV x0, x25                | X0 = X25;//m1                           
            // 0x00E2B208: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X25, ????);        
            // 0x00E2B20C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            // 0x00E2B210: MOV w9, w23                | W9 = W23;//m1                           
            val_17 = W23;
            // 0x00E2B214: B #0xe2b4a8                |  goto label_28;                         
            goto label_28;
            label_30:
            // 0x00E2B218: CBNZ x22, #0xe2b220        | if (ms.Stream != null) goto label_7;    
            if(ms.Stream != null)
            {
                goto label_7;
            }
            // 0x00E2B21C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X25, ????);        
            label_7:
            // 0x00E2B220: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B224: MOV x0, x22                | X0 = ms.Stream;//m1                     
            // 0x00E2B228: BL #0x26a4a08              | X0 = ms.Stream.get_ReadSize();          
            int val_2 = ms.Stream.ReadSize;
            // 0x00E2B22C: CBZ w0, #0xe2b580          | if (val_2 == 0) goto label_8;           
            if(val_2 == 0)
            {
                goto label_8;
            }
            // 0x00E2B230: LDR x0, [x21]              | X0 = typeof(AnyType.<MergeFrom>c__AnonStorey0);
            object val_3 = null;
            // 0x00E2B234: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AnyType.<MergeFrom>c__AnonStorey0), ????);
            // 0x00E2B238: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B23C: MOV x26, x0                | X26 = 1152921504829636608 (0x100000000D478000);//ML01
            // 0x00E2B240: BL #0x16f59f0              | .ctor();                                
            val_3 = new System.Object();
            // 0x00E2B244: CBNZ x22, #0xe2b24c        | if (ms.Stream != null) goto label_9;    
            if(ms.Stream != null)
            {
                goto label_9;
            }
            // 0x00E2B248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_9:
            // 0x00E2B24C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B250: MOV x0, x22                | X0 = ms.Stream;//m1                     
            // 0x00E2B254: BL #0x26a3f24              | X0 = ms.Stream.ReadString();            
            string val_4 = ms.Stream.ReadString();
            // 0x00E2B258: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x00E2B25C: CBNZ x26, #0xe2b264        | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x00E2B260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_10:
            // 0x00E2B264: STR x23, [x26, #0x10]      | typeof(AnyType.<MergeFrom>c__AnonStorey0).__il2cppRuntimeField_10 = val_4;  //  dest_result_addr=1152921504829636624
            typeof(AnyType.<MergeFrom>c__AnonStorey0).__il2cppRuntimeField_10 = val_4;
            // 0x00E2B268: CBNZ x22, #0xe2b270        | if (ms.Stream != null) goto label_11;   
            if(ms.Stream != null)
            {
                goto label_11;
            }
            // 0x00E2B26C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_11:
            // 0x00E2B270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B274: MOV x0, x22                | X0 = ms.Stream;//m1                     
            // 0x00E2B278: BL #0x26a4e7c              | X0 = ms.Stream.ReadLength();            
            int val_5 = ms.Stream.ReadLength();
            // 0x00E2B27C: MOV w25, w0                | W25 = val_5;//m1                        
            // 0x00E2B280: CBZ w25, #0xe2b218         | if (val_5 == 0) goto label_30;          
            if(val_5 == 0)
            {
                goto label_30;
            }
            // 0x00E2B284: CBZ x22, #0xe2b2ac         | if (ms.Stream == null) goto label_13;   
            if(ms.Stream == null)
            {
                goto label_13;
            }
            // 0x00E2B288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B28C: MOV x0, x22                | X0 = ms.Stream;//m1                     
            // 0x00E2B290: BL #0x26a4a00              | X0 = ms.Stream.get_WritePos();          
            int val_6 = ms.Stream.WritePos;
            // 0x00E2B294: STR w0, [sp, #4]           | stack[1152921513014407476] = val_6;      //  dest_result_addr=1152921513014407476
            // 0x00E2B298: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B29C: MOV x0, x22                | X0 = ms.Stream;//m1                     
            // 0x00E2B2A0: BL #0x26a49f0              | X0 = ms.Stream.get_ReadPos();           
            int val_7 = ms.Stream.ReadPos;
            // 0x00E2B2A4: MOV w23, w0                | W23 = val_7;//m1                        
            val_18 = val_7;
            // 0x00E2B2A8: B #0xe2b2d8                |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x00E2B2AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            // 0x00E2B2B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2B2B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B2B8: BL #0x26a4a00              | X0 = 0.get_WritePos();                  
            int val_8 = 0.WritePos;
            // 0x00E2B2BC: STR w0, [sp, #4]           | stack[1152921513014407476] = val_8;      //  dest_result_addr=1152921513014407476
            // 0x00E2B2C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            // 0x00E2B2C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2B2C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B2CC: BL #0x26a49f0              | X0 = 0.get_ReadPos();                   
            int val_9 = 0.ReadPos;
            // 0x00E2B2D0: MOV w23, w0                | W23 = val_9;//m1                        
            val_18 = val_9;
            // 0x00E2B2D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x00E2B2D8: ADD w1, w23, w25           | W1 = (val_9 + val_5);                   
            int val_10 = val_18 + val_5;
            // 0x00E2B2DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2B2E0: MOV x0, x22                | X0 = ms.Stream;//m1                     
            // 0x00E2B2E4: BL #0x269fc48              | ms.Stream.set_WritePos(value:  int val_10 = val_18 + val_5);
            ms.Stream.WritePos = val_10;
            // 0x00E2B2E8: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00E2B2EC: LDR x27, [x27, #0x18]      | X27 = this.fieldInfos; //P2             
            // 0x00E2B2F0: LDR x23, [x28]             | X23 = System.Boolean AnyType.<MergeFrom>c__AnonStorey0::<>m__0(System.Reflection.FieldInfo field);
            // 0x00E2B2F4: LDR x8, [x8, #0xb38]       | X8 = 1152921504658337792;               
            // 0x00E2B2F8: LDR x0, [x8]               | X0 = typeof(System.Predicate<T>);       
            // 0x00E2B2FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Predicate<T>), ????);
            // 0x00E2B300: MOV x28, x0                | X28 = 1152921504658337792 (0x100000000311B000);//ML01
            // 0x00E2B304: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00E2B308: LDR x8, [x8, #0x570]       | X8 = 1152921513014385360;               
            // 0x00E2B30C: LDR x3, [x8]               | X3 = public System.Void System.Predicate<System.Reflection.FieldInfo>::.ctor(object object, IntPtr method);
            // 0x00E2B310: MOV x0, x28                | X0 = 1152921504658337792 (0x100000000311B000);//ML01
            System.Predicate<System.Reflection.FieldInfo> val_11 = null;
            // 0x00E2B314: MOV x1, x26                | X1 = 1152921504829636608 (0x100000000D478000);//ML01
            // 0x00E2B318: MOV x2, x23                | X2 = 1152921513014376144 (0x10000001F520B6D0);//ML01
            // 0x00E2B31C: BL #0x1d74230              | .ctor(object:  val_3, method:  System.Boolean AnyType.<MergeFrom>c__AnonStorey0::<>m__0(System.Reflection.FieldInfo field));
            val_11 = new System.Predicate<System.Reflection.FieldInfo>(object:  val_3, method:  System.Boolean AnyType.<MergeFrom>c__AnonStorey0::<>m__0(System.Reflection.FieldInfo field));
            // 0x00E2B320: CBNZ x27, #0xe2b328        | if (this.fieldInfos != null) goto label_15;
            if(this.fieldInfos != null)
            {
                goto label_15;
            }
            // 0x00E2B324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_3, method:  System.Boolean AnyType.<MergeFrom>c__AnonStorey0::<>m__0(System.Reflection.FieldInfo field)), ????);
            label_15:
            // 0x00E2B328: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00E2B32C: LDR x8, [x8, #0xa80]       | X8 = 1152921513014386384;               
            // 0x00E2B330: LDR x2, [x8]               | X2 = public System.Reflection.FieldInfo System.Collections.Generic.List<System.Reflection.FieldInfo>::Find(System.Predicate<T> match);
            // 0x00E2B334: MOV x0, x27                | X0 = this.fieldInfos;//m1               
            // 0x00E2B338: MOV x1, x28                | X1 = 1152921504658337792 (0x100000000311B000);//ML01
            // 0x00E2B33C: BL #0x25eaf68              | X0 = this.fieldInfos.Find(match:  null);
            System.Reflection.FieldInfo val_12 = this.fieldInfos.Find(match:  null);
            // 0x00E2B340: MOV x26, x0                | X26 = val_12;//m1                       
            // 0x00E2B344: CBZ x26, #0xe2b3f4         | if (val_12 == null) goto label_16;      
            if(val_12 == null)
            {
                goto label_16;
            }
            // 0x00E2B348: LDR x8, [x26]              | X8 = typeof(System.Reflection.FieldInfo);
            // 0x00E2B34C: LDR x1, [x20]              | X1 = val_1;                             
            // 0x00E2B350: LDR x9, [x8, #0x220]       | X9 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_220;
            // 0x00E2B354: LDR x2, [x8, #0x228]       | X2 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_228;
            // 0x00E2B358: MOV x0, x26                | X0 = val_12;//m1                        
            // 0x00E2B35C: BLR x9                     | X0 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_220();
            // 0x00E2B360: MOV x8, x0                 | X8 = val_12;//m1                        
            // 0x00E2B364: ADRP x9, #0x35f9000        | X9 = 56594432 (0x35F9000);              
            // 0x00E2B368: LDR x9, [x9, #0xa58]       | X9 = 1152921504831713280;               
            // 0x00E2B36C: STR x8, [sp, #0x18]        | stack[1152921513014407496] = val_12;     //  dest_result_addr=1152921513014407496
            // 0x00E2B370: LDR x0, [x9]               | X0 = typeof(wxb.MonoSerialize);         
            // 0x00E2B374: LDRB w8, [x0, #0x10a]      | W8 = wxb.MonoSerialize.__il2cppRuntimeField_10A;
            // 0x00E2B378: TBZ w8, #0, #0xe2b388      | if (wxb.MonoSerialize.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x00E2B37C: LDR w8, [x0, #0xbc]        | W8 = wxb.MonoSerialize.__il2cppRuntimeField_cctor_finished;
            // 0x00E2B380: CBNZ w8, #0xe2b388         | if (wxb.MonoSerialize.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x00E2B384: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.MonoSerialize), ????);
            label_18:
            // 0x00E2B388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2B38C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2B390: MOV x1, x26                | X1 = val_12;//m1                        
            // 0x00E2B394: BL #0x269f45c              | X0 = wxb.MonoSerialize.GetByType(fieldInfo:  0);
            wxb.ITypeSerialize val_13 = wxb.MonoSerialize.GetByType(fieldInfo:  0);
            // 0x00E2B398: MOV x25, x0                | X25 = val_13;//m1                       
            // 0x00E2B39C: CBNZ x25, #0xe2b3a4        | if (val_13 != null) goto label_19;      
            if(val_13 != null)
            {
                goto label_19;
            }
            // 0x00E2B3A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_19:
            // 0x00E2B3A4: ADRP x9, #0x35fb000        | X9 = 56602624 (0x35FB000);              
            // 0x00E2B3A8: LDR x8, [x25]              | X8 = typeof(wxb.ITypeSerialize);        
            // 0x00E2B3AC: LDR x9, [x9, #0x108]       | X9 = 1152921504831660032;               
            // 0x00E2B3B0: LDR x1, [x9]               | X1 = typeof(wxb.ITypeSerialize);        
            // 0x00E2B3B4: LDRH w9, [x8, #0x102]      | W9 = wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E2B3B8: CBZ x9, #0xe2b3e4          | if (wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count == 0) goto label_20;
            // 0x00E2B3BC: LDR x10, [x8, #0x98]       | X10 = wxb.ITypeSerialize.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E2B3C0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_17 = 0;
            // 0x00E2B3C4: ADD x10, x10, #8           | X10 = (wxb.ITypeSerialize.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504831696904 (0x100000000D66F008);
            label_22:
            // 0x00E2B3C8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E2B3CC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(wxb.ITypeSerialize))
            // 0x00E2B3D0: B.EQ #0xe2b428             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_21;
            // 0x00E2B3D4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_17 = val_17 + 1;
            // 0x00E2B3D8: ADD x10, x10, #0x10        | X10 = (1152921504831696904 + 16) = 1152921504831696920 (0x100000000D66F018);
            // 0x00E2B3DC: CMP x11, x9                | STATE = COMPARE((0 + 1), wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E2B3E0: B.LO #0xe2b3c8             | if (0 < wxb.ITypeSerialize.__il2cppRuntimeField_interface_offsets_count) goto label_22;
            label_20:
            // 0x00E2B3E4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00E2B3E8: MOV x0, x25                | X0 = val_13;//m1                        
            val_19 = val_13;
            // 0x00E2B3EC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_13, ????);     
            // 0x00E2B3F0: B #0xe2b438                |  goto label_23;                         
            goto label_23;
            label_16:
            // 0x00E2B3F4: CBNZ x22, #0xe2b3fc        | if (ms.Stream != null) goto label_24;   
            if(ms.Stream != null)
            {
                goto label_24;
            }
            // 0x00E2B3F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_24:
            // 0x00E2B3FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2B400: MOV x0, x22                | X0 = ms.Stream;//m1                     
            // 0x00E2B404: BL #0x26a49f0              | X0 = ms.Stream.get_ReadPos();           
            int val_14 = ms.Stream.ReadPos;
            // 0x00E2B408: MOV w23, w0                | W23 = val_14;//m1                       
            // 0x00E2B40C: CBNZ x22, #0xe2b414        | if (ms.Stream != null) goto label_25;   
            if(ms.Stream != null)
            {
                goto label_25;
            }
            // 0x00E2B410: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_25:
            // 0x00E2B414: ADD w1, w23, w25           | W1 = (val_14 + val_5);                  
            int val_15 = val_14 + val_5;
            // 0x00E2B418: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2B41C: MOV x0, x22                | X0 = ms.Stream;//m1                     
            // 0x00E2B420: BL #0x26a49f8              | ms.Stream.set_ReadPos(value:  int val_15 = val_14 + val_5);
            ms.Stream.ReadPos = val_15;
            // 0x00E2B424: B #0xe2b460                |  goto label_35;                         
            goto label_35;
            label_21:
            // 0x00E2B428: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E2B42C: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00E2B430: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504831660032 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00E2B434: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504831660032 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_23:
            // 0x00E2B438: LDP x8, x3, [x0]           | X8 = typeof(wxb.ITypeSerialize);         //  | 
            // 0x00E2B43C: ADD x1, sp, #0x18          | X1 = (1152921513014407472 + 24) = 1152921513014407496 (0x10000001F5213148);
            // 0x00E2B440: MOV x0, x25                | X0 = val_13;//m1                        
            // 0x00E2B444: MOV x2, x19                | X2 = ms;//m1                            
            // 0x00E2B448: BLR x8                     | X0 = sub_100000000D666000( ?? val_13, ????);
            // 0x00E2B44C: LDR x1, [x20]              | X1 = val_1;                             
            // 0x00E2B450: LDR x2, [sp, #0x18]        | X2 = val_12;                            
            // 0x00E2B454: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E2B458: MOV x0, x26                | X0 = val_12;//m1                        
            // 0x00E2B45C: BL #0x13bd088              | val_12.SetValue(obj:  value, value:  val_12);
            val_12.SetValue(obj:  value, value:  val_12);
            label_35:
            // 0x00E2B460: MOVZ w23, #0xcc            | W23 = 204 (0xCC);//ML01                 
            // 0x00E2B464: MOV x25, x24               | X25 = 0 (0x0);//ML01                    
            label_39:
            // 0x00E2B468: ADRP x28, #0x35f0000       | X28 = 56557568 (0x35F0000);             
            // 0x00E2B46C: LDR x27, [sp, #8]          | X27 = this;                             
            // 0x00E2B470: LDR x28, [x28, #0xbe0]     | X28 = 1152921513014376144;              
            // 0x00E2B474: CBNZ x22, #0xe2b47c        | if (ms.Stream != null) goto label_27;   
            if(ms.Stream != null)
            {
                goto label_27;
            }
            // 0x00E2B478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_27:
            // 0x00E2B47C: LDR w1, [sp, #4]           | W1 = val_8;                             
            // 0x00E2B480: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2B484: MOV x0, x22                | X0 = ms.Stream;//m1                     
            // 0x00E2B488: BL #0x269fc48              | ms.Stream.set_WritePos(value:  val_8);  
            ms.Stream.WritePos = val_8;
            // 0x00E2B48C: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x00E2B490: CMP w23, #0xcc             | STATE = COMPARE(0xCC, 0xCC)             
            // 0x00E2B494: MOV x24, x25               | X24 = 0 (0x0);//ML01                    
            // 0x00E2B498: B.EQ #0xe2b4a8             | if (0xCC == 0xCC) goto label_28;        
            if(204 == 204)
            {
                goto label_28;
            }
            // 0x00E2B49C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            // 0x00E2B4A0: MOV w9, w23                | W9 = 204 (0xCC);//ML01                  
            val_17 = 204;
            // 0x00E2B4A4: CBNZ x25, #0xe2b200        | if (0x0 != 0) goto label_29;            
            if(0 != 0)
            {
                goto label_29;
            }
            label_28:
            // 0x00E2B4A8: STR w9, [sp, #0x14]        | stack[1152921513014407492] = 0xCC;       //  dest_result_addr=1152921513014407492
            // 0x00E2B4AC: B #0xe2b218                |  goto label_30;                         
            goto label_30;
            // 0x00E2B4B0: MOV x26, x1                | X26 = val_8;//m1                        
            val_20 = val_8;
            // 0x00E2B4B4: MOV x25, x0                | X25 = ms.Stream;//m1                    
            val_21 = ms.Stream;
            // 0x00E2B4B8: CMP w26, #1                | STATE = COMPARE(val_8, 0x1)             
            // 0x00E2B4BC: B.NE #0xe2b55c             | if (val_20 != 1) goto label_36;         
            if(val_20 != 1)
            {
                goto label_36;
            }
            // 0x00E2B4C0: MOV x0, x25                | X0 = ms.Stream;//m1                     
            // 0x00E2B4C4: BL #0x981060               | X0 = sub_981060( ?? ms.Stream, ????);   
            // 0x00E2B4C8: MOV x26, x0                | X26 = ms.Stream;//m1                    
            // 0x00E2B4CC: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00E2B4D0: LDR x25, [x26]             | X25 = typeof(wxb.WRStream);             
            // 0x00E2B4D4: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x00E2B4D8: LDR x1, [x25]              | X1 = ;                                  
            // 0x00E2B4DC: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x00E2B4E0: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
            // 0x00E2B4E4: TBZ w0, #0, #0xe2b52c      | if ((typeof(System.Exception) & 0x1) == 0) goto label_32;
            if((null & 1) == 0)
            {
                goto label_32;
            }
            // 0x00E2B4E8: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
            // 0x00E2B4EC: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x00E2B4F0: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x00E2B4F4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x00E2B4F8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x00E2B4FC: TBZ w8, #0, #0xe2b50c      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x00E2B500: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x00E2B504: CBNZ w8, #0xe2b50c         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x00E2B508: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_34:
            // 0x00E2B50C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2B510: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2B514: MOV x1, x25                | X1 = 1152921504831766528 (0x100000000D680000);//ML01
            // 0x00E2B518: BL #0x1a5d9d4              | UnityEngine.Debug.LogException(exception:  0);
            UnityEngine.Debug.LogException(exception:  0);
            // 0x00E2B51C: B #0xe2b460                |  goto label_35;                         
            goto label_35;
            // 0x00E2B520: MOV x26, x1                | X26 = 1152921504831766528 (0x100000000D680000);//ML01
            val_20 = 1152921504831766528;
            // 0x00E2B524: MOV x25, x0                | X25 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00E2B528: B #0xe2b55c                |  goto label_36;                         
            goto label_36;
            label_32:
            // 0x00E2B52C: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00E2B530: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x00E2B534: LDR x8, [x26]              | X8 = typeof(wxb.WRStream);              
            // 0x00E2B538: STR x8, [x0]               | mem[8] = typeof(wxb.WRStream);           //  dest_result_addr=8
            mem[8] = null;
            // 0x00E2B53C: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x00E2B540: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2B544: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x00E2B548: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            // 0x00E2B54C: B #0xe2b5a0                |  goto label_37;                         
            goto label_37;
            // 0x00E2B550: MOV x26, x1                | X26 = 54927608 (0x34620F8);//ML01       
            val_20 = 54927608;
            // 0x00E2B554: MOV x25, x0                | X25 = 8 (0x8);//ML01                    
            val_21 = 8;
            // 0x00E2B558: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
            label_36:
            // 0x00E2B55C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2B560: MOV x0, x25                | X0 = 8 (0x8);//ML01                     
            // 0x00E2B564: CMP w26, w8                | STATE = COMPARE(0x34620F8, 0x1)         
            // 0x00E2B568: B.NE #0xe2b5a4             | if (val_20 != 1) goto label_38;         
            if(val_20 != 1)
            {
                goto label_38;
            }
            // 0x00E2B56C: BL #0x981060               | X0 = sub_981060( ?? 0x8, ????);         
            // 0x00E2B570: LDR x25, [x0]              | X25 = typeof(wxb.WRStream);             
            // 0x00E2B574: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
            // 0x00E2B578: LDR w23, [sp, #0x14]       | W23 = 0xCC;                             
            // 0x00E2B57C: B #0xe2b468                |  goto label_39;                         
            goto label_39;
            label_8:
            // 0x00E2B580: SUB sp, x29, #0x50         | SP = (1152921513014407584 - 80) = 1152921513014407504 (0x10000001F5213150);
            // 0x00E2B584: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2B588: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2B58C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2B590: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E2B594: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E2B598: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E2B59C: RET                        |  return;                                
            return;
            label_37:
            // 0x00E2B5A0: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
            label_38:
            // 0x00E2B5A4: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
        
        }
    
    }

}
