using UnityEngine;
[Serializable]
public enum BloomScreenBlendMode
{
    // Fields
    Screen = 0
    ,Add = 1
    

}
