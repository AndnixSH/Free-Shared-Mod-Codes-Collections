using UnityEngine;

namespace ProtoBuf.Meta
{
    internal class BasicList : IEnumerable
    {
        // Fields
        private static readonly ProtoBuf.Meta.BasicList.Node nil; // static_offset: 0x00000000
        protected ProtoBuf.Meta.BasicList.Node head; //  0x00000010
        
        // Properties
        public object Item { get; }
        public int Count { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00C7EE20 (13102624), len: 120  VirtAddr: 0x00C7EE20 RVA: 0x00C7EE20 token: 100689217 methodIndex: 53429 delegateWrapperIndex: 0 methodInvoker: 0
        public BasicList()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00C7EE20: STP x20, x19, [sp, #-0x20]! | stack[1152921514347864544] = ???;  stack[1152921514347864552] = ???;  //  dest_result_addr=1152921514347864544 |  dest_result_addr=1152921514347864552
            // 0x00C7EE24: STP x29, x30, [sp, #0x10]  | stack[1152921514347864560] = ???;  stack[1152921514347864568] = ???;  //  dest_result_addr=1152921514347864560 |  dest_result_addr=1152921514347864568
            // 0x00C7EE28: ADD x29, sp, #0x10         | X29 = (1152921514347864544 + 16) = 1152921514347864560 (0x10000002449C21F0);
            // 0x00C7EE2C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7EE30: LDRB w8, [x20, #0xf9e]     | W8 = (bool)static_value_03733F9E;       
            // 0x00C7EE34: MOV x19, x0                | X19 = 1152921514347876576 (0x10000002449C50E0);//ML01
            // 0x00C7EE38: TBNZ w8, #0, #0xc7ee54     | if (static_value_03733F9E == true) goto label_0;
            // 0x00C7EE3C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00C7EE40: LDR x8, [x8, #0x560]       | X8 = 0x2B8F10C;                         
            // 0x00C7EE44: LDR w0, [x8]               | W0 = 0x1305;                            
            // 0x00C7EE48: BL #0x2782188              | X0 = sub_2782188( ?? 0x1305, ????);     
            // 0x00C7EE4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7EE50: STRB w8, [x20, #0xf9e]     | static_value_03733F9E = true;            //  dest_result_addr=57884574
            label_0:
            // 0x00C7EE54: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00C7EE58: LDR x20, [x20, #0x8f0]     | X20 = 1152921504882405376;              
            // 0x00C7EE5C: LDR x0, [x20]              | X0 = typeof(ProtoBuf.Meta.BasicList);   
            val_1 = null;
            // 0x00C7EE60: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Meta.BasicList.__il2cppRuntimeField_10A;
            // 0x00C7EE64: TBZ w8, #0, #0xc7ee78      | if (ProtoBuf.Meta.BasicList.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00C7EE68: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Meta.BasicList.__il2cppRuntimeField_cctor_finished;
            // 0x00C7EE6C: CBNZ w8, #0xc7ee78         | if (ProtoBuf.Meta.BasicList.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00C7EE70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Meta.BasicList), ????);
            // 0x00C7EE74: LDR x0, [x20]              | X0 = typeof(ProtoBuf.Meta.BasicList);   
            val_1 = null;
            label_2:
            // 0x00C7EE78: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.Meta.BasicList.__il2cppRuntimeField_static_fields;
            // 0x00C7EE7C: MOV x0, x19                | X0 = 1152921514347876576 (0x10000002449C50E0);//ML01
            // 0x00C7EE80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7EE84: LDR x8, [x8]               | X8 = ProtoBuf.Meta.BasicList.nil;       
            // 0x00C7EE88: STR x8, [x19, #0x10]       | this.head = ProtoBuf.Meta.BasicList.nil;  //  dest_result_addr=1152921514347876592
            this.head = ProtoBuf.Meta.BasicList.nil;
            // 0x00C7EE8C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7EE90: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7EE94: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7EE98 (13102744), len: 104  VirtAddr: 0x00C7EE98 RVA: 0x00C7EE98 token: 100689218 methodIndex: 53430 delegateWrapperIndex: 0 methodInvoker: 0
        public void CopyTo(System.Array array, int offset)
        {
            //
            // Disasemble & Code
            // 0x00C7EE98: STP x22, x21, [sp, #-0x30]! | stack[1152921514348021584] = ???;  stack[1152921514348021592] = ???;  //  dest_result_addr=1152921514348021584 |  dest_result_addr=1152921514348021592
            // 0x00C7EE9C: STP x20, x19, [sp, #0x10]  | stack[1152921514348021600] = ???;  stack[1152921514348021608] = ???;  //  dest_result_addr=1152921514348021600 |  dest_result_addr=1152921514348021608
            // 0x00C7EEA0: STP x29, x30, [sp, #0x20]  | stack[1152921514348021616] = ???;  stack[1152921514348021624] = ???;  //  dest_result_addr=1152921514348021616 |  dest_result_addr=1152921514348021624
            // 0x00C7EEA4: ADD x29, sp, #0x20         | X29 = (1152921514348021584 + 32) = 1152921514348021616 (0x10000002449E8770);
            // 0x00C7EEA8: LDR x21, [x0, #0x10]       | X21 = this.head; //P2                   
            // 0x00C7EEAC: MOV w19, w2                | W19 = offset;//m1                       
            // 0x00C7EEB0: MOV x20, x1                | X20 = array;//m1                        
            // 0x00C7EEB4: CBNZ x21, #0xc7eebc        | if (this.head != null) goto label_0;    
            if(this.head != null)
            {
                goto label_0;
            }
            // 0x00C7EEB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C7EEBC: LDR w5, [x21, #0x18]       | W5 = this.head.length; //P2             
            // 0x00C7EEC0: CMP w5, #1                 | STATE = COMPARE(this.head.length, 0x1)  
            // 0x00C7EEC4: B.LT #0xc7eef0             | if (this.head.length < 1) goto label_1; 
            if(this.head.length < 1)
            {
                goto label_1;
            }
            // 0x00C7EEC8: LDR x1, [x21, #0x10]       | X1 = this.head.data; //P2               
            // 0x00C7EECC: MOV x3, x20                | X3 = array;//m1                         
            // 0x00C7EED0: MOV w4, w19                | W4 = offset;//m1                        
            // 0x00C7EED4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7EED8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7EEDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7EEE0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7EEE4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00C7EEE8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C7EEEC: B #0x18ce87c               | System.Array.Copy(sourceArray:  0, sourceIndex:  this.head.data, destinationArray:  0, destinationIndex:  array, length:  offset); return;
            System.Array.Copy(sourceArray:  0, sourceIndex:  this.head.data, destinationArray:  0, destinationIndex:  array, length:  offset);
            return;
            label_1:
            // 0x00C7EEF0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7EEF4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7EEF8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C7EEFC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7EF38 (13102904), len: 88  VirtAddr: 0x00C7EF38 RVA: 0x00C7EF38 token: 100689219 methodIndex: 53431 delegateWrapperIndex: 0 methodInvoker: 0
        public int Add(object value)
        {
            //
            // Disasemble & Code
            // 0x00C7EF38: STP x22, x21, [sp, #-0x30]! | stack[1152921514348190928] = ???;  stack[1152921514348190936] = ???;  //  dest_result_addr=1152921514348190928 |  dest_result_addr=1152921514348190936
            // 0x00C7EF3C: STP x20, x19, [sp, #0x10]  | stack[1152921514348190944] = ???;  stack[1152921514348190952] = ???;  //  dest_result_addr=1152921514348190944 |  dest_result_addr=1152921514348190952
            // 0x00C7EF40: STP x29, x30, [sp, #0x20]  | stack[1152921514348190960] = ???;  stack[1152921514348190968] = ???;  //  dest_result_addr=1152921514348190960 |  dest_result_addr=1152921514348190968
            // 0x00C7EF44: ADD x29, sp, #0x20         | X29 = (1152921514348190928 + 32) = 1152921514348190960 (0x1000000244A11CF0);
            // 0x00C7EF48: MOV x19, x0                | X19 = 1152921514348202976 (0x1000000244A14BE0);//ML01
            // 0x00C7EF4C: LDR x21, [x19, #0x10]      | X21 = this.head; //P2                   
            // 0x00C7EF50: MOV x20, x1                | X20 = value;//m1                        
            // 0x00C7EF54: CBNZ x21, #0xc7ef5c        | if (this.head != null) goto label_0;    
            if(this.head != null)
            {
                goto label_0;
            }
            // 0x00C7EF58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C7EF5C: MOV x0, x21                | X0 = this.head;//m1                     
            // 0x00C7EF60: MOV x1, x20                | X1 = value;//m1                         
            // 0x00C7EF64: BL #0xc7ef90               | X0 = this.head.Append(value:  value);   
            Node val_1 = this.head.Append(value:  value);
            // 0x00C7EF68: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00C7EF6C: STR x20, [x19, #0x10]      | this.head = val_1;                       //  dest_result_addr=1152921514348202992
            this.head = val_1;
            // 0x00C7EF70: CBNZ x20, #0xc7ef78        | if (val_1 != null) goto label_1;        
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x00C7EF74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00C7EF78: LDR w8, [x20, #0x18]       | W8 = val_1.length; //P2                 
            // 0x00C7EF7C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7EF80: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7EF84: SUB w0, w8, #1             | W0 = (val_1.length - 1);                
            int val_2 = val_1.length - 1;
            // 0x00C7EF88: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C7EF8C: RET                        |  return (System.Int32)(val_1.length - 1);
            return val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F0F4 (13103348), len: 48  VirtAddr: 0x00C7F0F4 RVA: 0x00C7F0F4 token: 100689220 methodIndex: 53432 delegateWrapperIndex: 0 methodInvoker: 0
        public object get_Item(int index)
        {
            //
            // Disasemble & Code
            // 0x00C7F0F4: STP x20, x19, [sp, #-0x20]! | stack[1152921514348319328] = ???;  stack[1152921514348319336] = ???;  //  dest_result_addr=1152921514348319328 |  dest_result_addr=1152921514348319336
            // 0x00C7F0F8: STP x29, x30, [sp, #0x10]  | stack[1152921514348319344] = ???;  stack[1152921514348319352] = ???;  //  dest_result_addr=1152921514348319344 |  dest_result_addr=1152921514348319352
            // 0x00C7F0FC: ADD x29, sp, #0x10         | X29 = (1152921514348319328 + 16) = 1152921514348319344 (0x1000000244A31270);
            // 0x00C7F100: LDR x20, [x0, #0x10]       | X20 = this.head; //P2                   
            // 0x00C7F104: MOV w19, w1                | W19 = index;//m1                        
            // 0x00C7F108: CBNZ x20, #0xc7f110        | if (this.head != null) goto label_0;    
            if(this.head != null)
            {
                goto label_0;
            }
            // 0x00C7F10C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C7F110: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7F114: MOV x0, x20                | X0 = this.head;//m1                     
            // 0x00C7F118: MOV w1, w19                | W1 = index;//m1                         
            // 0x00C7F11C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7F120: B #0xc7f124                | return this.head.get_Item(index:  index);
            return this.head.Item[index];
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F1F0 (13103600), len: 52  VirtAddr: 0x00C7F1F0 RVA: 0x00C7F1F0 token: 100689221 methodIndex: 53433 delegateWrapperIndex: 0 methodInvoker: 0
        public void Trim()
        {
            //
            // Disasemble & Code
            // 0x00C7F1F0: STP x20, x19, [sp, #-0x20]! | stack[1152921514348443616] = ???;  stack[1152921514348443624] = ???;  //  dest_result_addr=1152921514348443616 |  dest_result_addr=1152921514348443624
            // 0x00C7F1F4: STP x29, x30, [sp, #0x10]  | stack[1152921514348443632] = ???;  stack[1152921514348443640] = ???;  //  dest_result_addr=1152921514348443632 |  dest_result_addr=1152921514348443640
            // 0x00C7F1F8: ADD x29, sp, #0x10         | X29 = (1152921514348443616 + 16) = 1152921514348443632 (0x1000000244A4F7F0);
            // 0x00C7F1FC: MOV x19, x0                | X19 = 1152921514348455648 (0x1000000244A526E0);//ML01
            // 0x00C7F200: LDR x20, [x19, #0x10]      | X20 = this.head; //P2                   
            // 0x00C7F204: CBNZ x20, #0xc7f20c        | if (this.head != null) goto label_0;    
            if(this.head != null)
            {
                goto label_0;
            }
            // 0x00C7F208: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C7F20C: MOV x0, x20                | X0 = this.head;//m1                     
            // 0x00C7F210: BL #0xc7f224               | X0 = this.head.Trim();                  
            Node val_1 = this.head.Trim();
            // 0x00C7F214: STR x0, [x19, #0x10]       | this.head = val_1;                       //  dest_result_addr=1152921514348455664
            this.head = val_1;
            // 0x00C7F218: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7F21C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7F220: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F2F8 (13103864), len: 40  VirtAddr: 0x00C7F2F8 RVA: 0x00C7F2F8 token: 100689222 methodIndex: 53434 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_Count()
        {
            //
            // Disasemble & Code
            // 0x00C7F2F8: STP x20, x19, [sp, #-0x20]! | stack[1152921514348567904] = ???;  stack[1152921514348567912] = ???;  //  dest_result_addr=1152921514348567904 |  dest_result_addr=1152921514348567912
            // 0x00C7F2FC: STP x29, x30, [sp, #0x10]  | stack[1152921514348567920] = ???;  stack[1152921514348567928] = ???;  //  dest_result_addr=1152921514348567920 |  dest_result_addr=1152921514348567928
            // 0x00C7F300: ADD x29, sp, #0x10         | X29 = (1152921514348567904 + 16) = 1152921514348567920 (0x1000000244A6DD70);
            // 0x00C7F304: LDR x19, [x0, #0x10]       | X19 = this.head; //P2                   
            // 0x00C7F308: CBNZ x19, #0xc7f310        | if (this.head != null) goto label_0;    
            if(this.head != null)
            {
                goto label_0;
            }
            // 0x00C7F30C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C7F310: LDR w0, [x19, #0x18]       | W0 = this.head.length; //P2             
            // 0x00C7F314: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7F318: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7F31C: RET                        |  return (System.Int32)this.head.length; 
            return this.head.length;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F320 (13103904), len: 108  VirtAddr: 0x00C7F320 RVA: 0x00C7F320 token: 100689223 methodIndex: 53435 delegateWrapperIndex: 0 methodInvoker: 0
        private System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            //
            // Disasemble & Code
            // 0x00C7F320: STP x20, x19, [sp, #-0x20]! | stack[1152921514348692192] = ???;  stack[1152921514348692200] = ???;  //  dest_result_addr=1152921514348692192 |  dest_result_addr=1152921514348692200
            // 0x00C7F324: STP x29, x30, [sp, #0x10]  | stack[1152921514348692208] = ???;  stack[1152921514348692216] = ???;  //  dest_result_addr=1152921514348692208 |  dest_result_addr=1152921514348692216
            // 0x00C7F328: ADD x29, sp, #0x10         | X29 = (1152921514348692192 + 16) = 1152921514348692208 (0x1000000244A8C2F0);
            // 0x00C7F32C: SUB sp, sp, #0x10          | SP = (1152921514348692192 - 16) = 1152921514348692176 (0x1000000244A8C2D0);
            // 0x00C7F330: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7F334: LDRB w8, [x20, #0xf9f]     | W8 = (bool)static_value_03733F9F;       
            // 0x00C7F338: MOV x19, x0                | X19 = 1152921514348704224 (0x1000000244A8F1E0);//ML01
            // 0x00C7F33C: TBNZ w8, #0, #0xc7f358     | if (static_value_03733F9F == true) goto label_0;
            // 0x00C7F340: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x00C7F344: LDR x8, [x8, #0x2c8]       | X8 = 0x2B8F114;                         
            // 0x00C7F348: LDR w0, [x8]               | W0 = 0x1307;                            
            // 0x00C7F34C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1307, ????);     
            // 0x00C7F350: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7F354: STRB w8, [x20, #0xf9f]     | static_value_03733F9F = true;            //  dest_result_addr=57884575
            label_0:
            // 0x00C7F358: ADRP x10, #0x3631000       | X10 = 56823808 (0x3631000);             
            // 0x00C7F35C: LDR x8, [x19, #0x10]       | X8 = this.head; //P2                    
            // 0x00C7F360: LDR x10, [x10, #0xd80]     | X10 = 1152921504882458624;              
            // 0x00C7F364: MOVN w9, #0                | W9 = 0 (0x0);//ML01                     
            // 0x00C7F368: MOV x1, sp                 | X1 = 1152921514348692176 (0x1000000244A8C2D0);//ML01
            // 0x00C7F36C: LDR x0, [x10]              | X0 = typeof(BasicList.NodeEnumerator);  
            // 0x00C7F370: STP w9, wzr, [sp]          | stack[1152921514348692176] = 0x0;  stack[1152921514348692180] = 0x0;  //  dest_result_addr=1152921514348692176 |  dest_result_addr=1152921514348692180
            // 0x00C7F374: STR x8, [sp, #8]           | stack[1152921514348692184] = this.head;  //  dest_result_addr=1152921514348692184
            // 0x00C7F378: BL #0x27bc028              | X0 = 1152921514348740320 = (Il2CppObject*)Box((RuntimeClass*)typeof(BasicList.NodeEnumerator), null);
            // 0x00C7F37C: SUB sp, x29, #0x10         | SP = (1152921514348692208 - 16) = 1152921514348692192 (0x1000000244A8C2E0);
            // 0x00C7F380: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7F384: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7F388: RET                        |  return (System.Collections.IEnumerator)null;
            return (System.Collections.IEnumerator)0;
            //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F38C (13104012), len: 12  VirtAddr: 0x00C7F38C RVA: 0x00C7F38C token: 100689224 methodIndex: 53436 delegateWrapperIndex: 0 methodInvoker: 0
        public ProtoBuf.Meta.BasicList.NodeEnumerator GetEnumerator()
        {
            //
            // Disasemble & Code
            // 0x00C7F38C: LDR x1, [x0, #0x10]        | X1 = this.head; //P2                    
            // 0x00C7F390: MOVN w0, #0                | W0 = 0 (0x0);//ML01                     
            // 0x00C7F394: RET                        |  return new NodeEnumerator() {node = this.head};
            return new NodeEnumerator() {node = this.head};
            //  |  // // {name=val_0.position, type=System.Int32, size=4, nGRN=0 offset=0 }
            //  |  // // {name=val_0.node, type=Node, size=8, nGRN=1 offset=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F398 (13104024), len: 64  VirtAddr: 0x00C7F398 RVA: 0x00C7F398 token: 100689225 methodIndex: 53437 delegateWrapperIndex: 0 methodInvoker: 0
        internal int IndexOf(ProtoBuf.Meta.BasicList.MatchPredicate predicate, object ctx)
        {
            //
            // Disasemble & Code
            // 0x00C7F398: STP x22, x21, [sp, #-0x30]! | stack[1152921514348944848] = ???;  stack[1152921514348944856] = ???;  //  dest_result_addr=1152921514348944848 |  dest_result_addr=1152921514348944856
            // 0x00C7F39C: STP x20, x19, [sp, #0x10]  | stack[1152921514348944864] = ???;  stack[1152921514348944872] = ???;  //  dest_result_addr=1152921514348944864 |  dest_result_addr=1152921514348944872
            // 0x00C7F3A0: STP x29, x30, [sp, #0x20]  | stack[1152921514348944880] = ???;  stack[1152921514348944888] = ???;  //  dest_result_addr=1152921514348944880 |  dest_result_addr=1152921514348944888
            // 0x00C7F3A4: ADD x29, sp, #0x20         | X29 = (1152921514348944848 + 32) = 1152921514348944880 (0x1000000244AC9DF0);
            // 0x00C7F3A8: LDR x21, [x0, #0x10]       | X21 = this.head; //P2                   
            // 0x00C7F3AC: MOV x19, x2                | X19 = ctx;//m1                          
            // 0x00C7F3B0: MOV x20, x1                | X20 = predicate;//m1                    
            // 0x00C7F3B4: CBNZ x21, #0xc7f3bc        | if (this.head != null) goto label_0;    
            if(this.head != null)
            {
                goto label_0;
            }
            // 0x00C7F3B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C7F3BC: MOV x1, x20                | X1 = predicate;//m1                     
            // 0x00C7F3C0: MOV x2, x19                | X2 = ctx;//m1                           
            // 0x00C7F3C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7F3C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7F3CC: MOV x0, x21                | X0 = this.head;//m1                     
            // 0x00C7F3D0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C7F3D4: B #0xc7f3d8                | return this.head.IndexOf(predicate:  predicate, ctx:  ctx);
            return this.head.IndexOf(predicate:  predicate, ctx:  ctx);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F488 (13104264), len: 48  VirtAddr: 0x00C7F488 RVA: 0x00C7F488 token: 100689226 methodIndex: 53438 delegateWrapperIndex: 0 methodInvoker: 0
        internal int IndexOfString(string value)
        {
            //
            // Disasemble & Code
            // 0x00C7F488: STP x20, x19, [sp, #-0x20]! | stack[1152921514349077344] = ???;  stack[1152921514349077352] = ???;  //  dest_result_addr=1152921514349077344 |  dest_result_addr=1152921514349077352
            // 0x00C7F48C: STP x29, x30, [sp, #0x10]  | stack[1152921514349077360] = ???;  stack[1152921514349077368] = ???;  //  dest_result_addr=1152921514349077360 |  dest_result_addr=1152921514349077368
            // 0x00C7F490: ADD x29, sp, #0x10         | X29 = (1152921514349077344 + 16) = 1152921514349077360 (0x1000000244AEA370);
            // 0x00C7F494: LDR x20, [x0, #0x10]       | X20 = this.head; //P2                   
            // 0x00C7F498: MOV x19, x1                | X19 = value;//m1                        
            // 0x00C7F49C: CBNZ x20, #0xc7f4a4        | if (this.head != null) goto label_0;    
            if(this.head != null)
            {
                goto label_0;
            }
            // 0x00C7F4A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C7F4A4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7F4A8: MOV x0, x20                | X0 = this.head;//m1                     
            // 0x00C7F4AC: MOV x1, x19                | X1 = value;//m1                         
            // 0x00C7F4B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7F4B4: B #0xc7f4b8                | return this.head.IndexOfString(value:  value);
            return this.head.IndexOfString(value:  value);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F5FC (13104636), len: 48  VirtAddr: 0x00C7F5FC RVA: 0x00C7F5FC token: 100689227 methodIndex: 53439 delegateWrapperIndex: 0 methodInvoker: 0
        internal int IndexOfReference(object instance)
        {
            //
            // Disasemble & Code
            // 0x00C7F5FC: STP x20, x19, [sp, #-0x20]! | stack[1152921514349205728] = ???;  stack[1152921514349205736] = ???;  //  dest_result_addr=1152921514349205728 |  dest_result_addr=1152921514349205736
            // 0x00C7F600: STP x29, x30, [sp, #0x10]  | stack[1152921514349205744] = ???;  stack[1152921514349205752] = ???;  //  dest_result_addr=1152921514349205744 |  dest_result_addr=1152921514349205752
            // 0x00C7F604: ADD x29, sp, #0x10         | X29 = (1152921514349205728 + 16) = 1152921514349205744 (0x1000000244B098F0);
            // 0x00C7F608: LDR x20, [x0, #0x10]       | X20 = this.head; //P2                   
            // 0x00C7F60C: MOV x19, x1                | X19 = instance;//m1                     
            // 0x00C7F610: CBNZ x20, #0xc7f618        | if (this.head != null) goto label_0;    
            if(this.head != null)
            {
                goto label_0;
            }
            // 0x00C7F614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C7F618: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7F61C: MOV x0, x20                | X0 = this.head;//m1                     
            // 0x00C7F620: MOV x1, x19                | X1 = instance;//m1                      
            // 0x00C7F624: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7F628: B #0xc7f62c                | return this.head.IndexOfReference(instance:  instance);
            return this.head.IndexOfReference(instance:  instance);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F6BC (13104828), len: 256  VirtAddr: 0x00C7F6BC RVA: 0x00C7F6BC token: 100689228 methodIndex: 53440 delegateWrapperIndex: 0 methodInvoker: 0
        internal bool Contains(object value)
        {
            //
            // Disasemble & Code
            //  | 
            int val_4;
            //  | 
            var val_5;
            // 0x00C7F6BC: STP x22, x21, [sp, #-0x30]! | stack[1152921514349338192] = ???;  stack[1152921514349338200] = ???;  //  dest_result_addr=1152921514349338192 |  dest_result_addr=1152921514349338200
            // 0x00C7F6C0: STP x20, x19, [sp, #0x10]  | stack[1152921514349338208] = ???;  stack[1152921514349338216] = ???;  //  dest_result_addr=1152921514349338208 |  dest_result_addr=1152921514349338216
            // 0x00C7F6C4: STP x29, x30, [sp, #0x20]  | stack[1152921514349338224] = ???;  stack[1152921514349338232] = ???;  //  dest_result_addr=1152921514349338224 |  dest_result_addr=1152921514349338232
            // 0x00C7F6C8: ADD x29, sp, #0x20         | X29 = (1152921514349338192 + 32) = 1152921514349338224 (0x1000000244B29E70);
            // 0x00C7F6CC: LDR x19, [x0, #0x10]       | X19 = this.head; //P2                   
            // 0x00C7F6D0: MOV x20, x1                | X20 = value;//m1                        
            // 0x00C7F6D4: MOVN w21, #0               | W21 = 0 (0x0);//ML01                    
            val_4 = 0;
            label_3:
            // 0x00C7F6D8: CBNZ x19, #0xc7f6e0        | if (this.head != null) goto label_0;    
            if(this.head != null)
            {
                goto label_0;
            }
            // 0x00C7F6DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C7F6E0: LDR w8, [x19, #0x18]       | W8 = this.head.length; //P2             
            // 0x00C7F6E4: CMP w21, w8                | STATE = COMPARE(0x0, this.head.length)  
            // 0x00C7F6E8: B.GT #0xc7f728             | if (val_4 > this.head.length) goto label_2;
            if(val_4 > this.head.length)
            {
                goto label_2;
            }
            // 0x00C7F6EC: ADD w21, w21, #1           | W21 = (val_4 + 1);                      
            val_4 = val_4 + 1;
            // 0x00C7F6F0: CMP w21, w8                | STATE = COMPARE((val_4 + 1), this.head.length)
            // 0x00C7F6F4: B.GE #0xc7f728             | if (val_4 >= this.head.length) goto label_2;
            if(val_4 >= this.head.length)
            {
                goto label_2;
            }
            // 0x00C7F6F8: MOV x0, x19                | X0 = this.head;//m1                     
            // 0x00C7F6FC: MOV w1, w21                | W1 = (val_4 + 1);//m1                   
            // 0x00C7F700: BL #0xc7f124               | X0 = this.head.get_Item(index:  val_4); 
            object val_1 = this.head.Item[val_4];
            // 0x00C7F704: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x00C7F708: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7F70C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7F710: MOV x2, x20                | X2 = value;//m1                         
            // 0x00C7F714: BL #0x1708de4              | X0 = System.Object.Equals(objA:  0, objB:  val_1);
            bool val_2 = System.Object.Equals(objA:  0, objB:  val_1);
            // 0x00C7F718: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x00C7F71C: TBZ w8, #0, #0xc7f6d8      | if ((val_2 & 1) == false) goto label_3; 
            if(val_3 == false)
            {
                goto label_3;
            }
            // 0x00C7F720: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_5 = 1;
            // 0x00C7F724: B #0xc7f72c                |  goto label_4;                          
            goto label_4;
            label_2:
            // 0x00C7F728: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            label_4:
            // 0x00C7F72C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7F730: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7F734: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C7F738: RET                        |  return (System.Boolean)false;          
            return (bool)val_5;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7F7BC (13105084), len: 592  VirtAddr: 0x00C7F7BC RVA: 0x00C7F7BC token: 100689229 methodIndex: 53441 delegateWrapperIndex: 0 methodInvoker: 0
        internal static ProtoBuf.Meta.BasicList GetContiguousGroups(int[] keys, object[] values)
        {
            //
            // Disasemble & Code
            //  | 
            int val_9;
            //  | 
            object val_10;
            //  | 
            var val_11;
            //  | 
            int val_12;
            //  | 
            int val_13;
            //  | 
            System.ArgumentNullException val_14;
            //  | 
            string val_15;
            //  | 
            var val_16;
            // 0x00C7F7BC: STP x28, x27, [sp, #-0x60]! | stack[1152921514349586560] = ???;  stack[1152921514349586568] = ???;  //  dest_result_addr=1152921514349586560 |  dest_result_addr=1152921514349586568
            // 0x00C7F7C0: STP x26, x25, [sp, #0x10]  | stack[1152921514349586576] = ???;  stack[1152921514349586584] = ???;  //  dest_result_addr=1152921514349586576 |  dest_result_addr=1152921514349586584
            // 0x00C7F7C4: STP x24, x23, [sp, #0x20]  | stack[1152921514349586592] = ???;  stack[1152921514349586600] = ???;  //  dest_result_addr=1152921514349586592 |  dest_result_addr=1152921514349586600
            // 0x00C7F7C8: STP x22, x21, [sp, #0x30]  | stack[1152921514349586608] = ???;  stack[1152921514349586616] = ???;  //  dest_result_addr=1152921514349586608 |  dest_result_addr=1152921514349586616
            // 0x00C7F7CC: STP x20, x19, [sp, #0x40]  | stack[1152921514349586624] = ???;  stack[1152921514349586632] = ???;  //  dest_result_addr=1152921514349586624 |  dest_result_addr=1152921514349586632
            // 0x00C7F7D0: STP x29, x30, [sp, #0x50]  | stack[1152921514349586640] = ???;  stack[1152921514349586648] = ???;  //  dest_result_addr=1152921514349586640 |  dest_result_addr=1152921514349586648
            // 0x00C7F7D4: ADD x29, sp, #0x50         | X29 = (1152921514349586560 + 80) = 1152921514349586640 (0x1000000244B668D0);
            // 0x00C7F7D8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00C7F7DC: LDRB w8, [x21, #0xfa0]     | W8 = (bool)static_value_03733FA0;       
            // 0x00C7F7E0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00C7F7E4: MOV x20, x1                | X20 = values;//m1                       
            // 0x00C7F7E8: TBNZ w8, #0, #0xc7f804     | if (static_value_03733FA0 == true) goto label_0;
            // 0x00C7F7EC: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00C7F7F0: LDR x8, [x8, #0xd80]       | X8 = 0x2B8F110;                         
            // 0x00C7F7F4: LDR w0, [x8]               | W0 = 0x1306;                            
            // 0x00C7F7F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1306, ????);     
            // 0x00C7F7FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7F800: STRB w8, [x21, #0xfa0]     | static_value_03733FA0 = true;            //  dest_result_addr=57884576
            label_0:
            // 0x00C7F804: CBZ x20, #0xc7f978         | if (values == null) goto label_1;       
            if(values == null)
            {
                goto label_1;
            }
            // 0x00C7F808: CBZ x19, #0xc7f994         | if (X2 == 0) goto label_2;              
            if(X2 == 0)
            {
                goto label_2;
            }
            // 0x00C7F80C: LDR w8, [x19, #0x18]       | W8 = X2 + 24;                           
            // 0x00C7F810: LDR w9, [x20, #0x18]       | W9 = values.Length; //P2                
            // 0x00C7F814: CMP w8, w9                 | STATE = COMPARE(X2 + 24, values.Length) 
            // 0x00C7F818: B.LT #0xc7f9c0             | if (X2 + 24 < values.Length) goto label_3;
            if((X2 + 24) < values.Length)
            {
                goto label_3;
            }
            // 0x00C7F81C: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00C7F820: LDR x8, [x8, #0x8f0]       | X8 = 1152921504882405376;               
            // 0x00C7F824: LDR x0, [x8]               | X0 = typeof(ProtoBuf.Meta.BasicList);   
            ProtoBuf.Meta.BasicList val_1 = null;
            // 0x00C7F828: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ProtoBuf.Meta.BasicList), ????);
            // 0x00C7F82C: MOV x21, x0                | X21 = 1152921504882405376 (0x10000000106CB000);//ML01
            // 0x00C7F830: BL #0xc7ee20               | .ctor();                                
            val_1 = new ProtoBuf.Meta.BasicList();
            // 0x00C7F834: LDR x8, [x20, #0x18]       | X8 = values.Length; //P2                
            val_9 = values.Length;
            // 0x00C7F838: CMP w8, #1                 | STATE = COMPARE(values.Length, 0x1)     
            // 0x00C7F83C: B.LT #0xc7f958             | if (val_9 < 1) goto label_4;            
            if(val_9 < 1)
            {
                goto label_4;
            }
            // 0x00C7F840: ADRP x25, #0x35fc000       | X25 = 56606720 (0x35FC000);             
            // 0x00C7F844: LDR x25, [x25, #0xbd0]     | X25 = 1152921504882618368;              
            // 0x00C7F848: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00C7F84C: MOVN w26, #0               | W26 = 0 (0x0);//ML01                    
            label_16:
            // 0x00C7F850: ADD w24, w26, #1           | W24 = (0 + 1) = 1 (0x00000001);         
            // 0x00C7F854: CMN w26, #1                | STATE = COMPARE(0x0, 0x1)               
            // 0x00C7F858: B.EQ #0xc7f8b4             | if (0 == 0x1) goto label_5;             
            if(0 == 1)
            {
                goto label_5;
            }
            // 0x00C7F85C: SXTW x23, w24              | X23 = 1 (0x00000001);                   
            val_11 = 1;
            // 0x00C7F860: CMP w24, w8                | STATE = COMPARE(0x1, values.Length)     
            // 0x00C7F864: B.LO #0xc7f878             | if (1 < val_9) goto label_6;            
            if(1 < val_9)
            {
                goto label_6;
            }
            // 0x00C7F868: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x00C7F86C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7F870: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            // 0x00C7F874: LDR x8, [x20, #0x18]       | X8 = values.Length; //P2                
            val_12 = values.Length;
            label_6:
            // 0x00C7F878: ADD x9, x20, x23, lsl #2   | X9 = values[0x4]; //PARR1               
            // 0x00C7F87C: LDR w27, [x9, #0x20]       | W27 = values[0x4][0]                    
            object val_10 = values[4];
            // 0x00C7F880: CMP w26, w8                | STATE = COMPARE(0x0, values.Length)     
            // 0x00C7F884: B.LO #0xc7f894             | if (0 < val_12) goto label_7;           
            if(0 < val_12)
            {
                goto label_7;
            }
            // 0x00C7F888: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x00C7F88C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7F890: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_7:
            // 0x00C7F894: CBZ x22, #0xc7f8ac         | if (0x0 == 0) goto label_8;             
            if(val_10 == 0)
            {
                goto label_8;
            }
            // 0x00C7F898: SXTW x8, w26               | X8 = 0 (0x00000000);                    
            // 0x00C7F89C: ADD x8, x20, x8, lsl #2    | X8 = values[0x0]; //PARR1               
            // 0x00C7F8A0: LDR w8, [x8, #0x20]        | W8 = values[0x0][0]                     
            object val_11 = values[0];
            // 0x00C7F8A4: CMP w27, w8                | STATE = COMPARE(values[0x4][0], values[0x0][0])
            // 0x00C7F8A8: B.EQ #0xc7f8fc             | if (values[4] == values[0]) goto label_9;
            if(val_10 == val_11)
            {
                goto label_9;
            }
            label_8:
            // 0x00C7F8AC: LDR x8, [x20, #0x18]       | X8 = values.Length; //P2                
            val_13 = values.Length;
            // 0x00C7F8B0: B #0xc7f8b8                |  goto label_10;                         
            goto label_10;
            label_5:
            // 0x00C7F8B4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00C7F8B8: CMP w24, w8                | STATE = COMPARE(0x1, values.Length)     
            // 0x00C7F8BC: B.LO #0xc7f8cc             | if (1 < val_9) goto label_11;           
            if(1 < val_9)
            {
                goto label_11;
            }
            // 0x00C7F8C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x00C7F8C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7F8C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_11:
            // 0x00C7F8CC: ADD x8, x20, x23, lsl #2   | X8 = values[0x0]; //PARR1               
            // 0x00C7F8D0: LDR x0, [x25]              | X0 = typeof(BasicList.Group);           
            BasicList.Group val_2 = null;
            // 0x00C7F8D4: LDR w23, [x8, #0x20]       | W23 = values[0x0][0]                    
            object val_12 = values[0];
            // 0x00C7F8D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BasicList.Group), ????);
            // 0x00C7F8DC: MOV w1, w23                | W1 = values[0x0][0];//m1                
            // 0x00C7F8E0: MOV x22, x0                | X22 = 1152921504882618368 (0x10000000106FF000);//ML01
            val_10 = val_2;
            // 0x00C7F8E4: BL #0xc7fa0c               | .ctor(first:  values[0]);               
            val_2 = new BasicList.Group(first:  val_12);
            // 0x00C7F8E8: CBNZ x21, #0xc7f8f0        | if ( != 0) goto label_12;               
            if(null != 0)
            {
                goto label_12;
            }
            // 0x00C7F8EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(first:  values[0]), ????);
            label_12:
            // 0x00C7F8F0: MOV x0, x21                | X0 = 1152921504882405376 (0x10000000106CB000);//ML01
            // 0x00C7F8F4: MOV x1, x22                | X1 = 1152921504882618368 (0x10000000106FF000);//ML01
            // 0x00C7F8F8: BL #0xc7ef38               | X0 = Add(value:  val_10);               
            int val_3 = Add(value:  val_10);
            label_9:
            // 0x00C7F8FC: CBNZ x22, #0xc7f904        | if ( != 0) goto label_13;               
            if(null != 0)
            {
                goto label_13;
            }
            // 0x00C7F900: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_13:
            // 0x00C7F904: LDR w8, [x19, #0x18]       | W8 = X2 + 24;                           
            // 0x00C7F908: LDR x23, [x22, #0x18]      | X23 = BasicList.Group.__il2cppRuntimeField_namespaze;
            // 0x00C7F90C: SXTW x27, w24              | X27 = 1 (0x00000001);                   
            // 0x00C7F910: CMP w24, w8                | STATE = COMPARE(0x1, X2 + 24)           
            // 0x00C7F914: B.LO #0xc7f924             | if (1 < X2 + 24) goto label_14;         
            if(1 < (X2 + 24))
            {
                goto label_14;
            }
            // 0x00C7F918: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x00C7F91C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7F920: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_14:
            // 0x00C7F924: ADD x8, x19, x27, lsl #3   | X8 = (X2 + 8);                          
            var val_4 = X2 + 8;
            // 0x00C7F928: LDR x24, [x8, #0x20]       | X24 = (X2 + 8) + 32;                    
            // 0x00C7F92C: CBNZ x23, #0xc7f934        | if ( != null) goto label_15;            
            if( != null)
            {
                goto label_15;
            }
            // 0x00C7F930: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_15:
            // 0x00C7F934: MOV x0, x23                | X0 = 1152921507852043952 (0x10000000C16DC6B0);//ML01
            // 0x00C7F938: MOV x1, x24                | X1 = (X2 + 8) + 32;//m1                 
            // 0x00C7F93C: BL #0xc7ef38               | X0 = Add(value:  (X2 + 8) + 32);        
            int val_5 = Add(value:  (X2 + 8) + 32);
            // 0x00C7F940: LDR x8, [x20, #0x18]       | X8 = values.Length; //P2                
            // 0x00C7F944: ADD w10, w26, #1           | W10 = (0 + 1);                          
            var val_6 = 0 + 1;
            // 0x00C7F948: ADD w9, w26, #2            | W9 = (0 + 2);                           
            var val_7 = 0 + 2;
            // 0x00C7F94C: MOV w26, w10               | W26 = (0 + 1);//m1                      
            // 0x00C7F950: CMP w9, w8                 | STATE = COMPARE((0 + 2), values.Length) 
            // 0x00C7F954: B.LT #0xc7f850             | if (val_7 < values.Length) goto label_16;
            if(val_7 < values.Length)
            {
                goto label_16;
            }
            label_4:
            // 0x00C7F958: MOV x0, x21                | X0 = 1152921504882405376 (0x10000000106CB000);//ML01
            // 0x00C7F95C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7F960: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7F964: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7F968: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7F96C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00C7F970: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00C7F974: RET                        |  return (ProtoBuf.Meta.BasicList)typeof(ProtoBuf.Meta.BasicList);
            return (ProtoBuf.Meta.BasicList)val_1;
            //  |  // // {name=val_0, type=ProtoBuf.Meta.BasicList, size=8, nGRN=0 }
            label_1:
            // 0x00C7F978: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00C7F97C: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00C7F980: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            val_14 = null;
            // 0x00C7F984: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C7F988: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00C7F98C: LDR x8, [x8, #0x940]       | X8 = (string**)(1152921514349536544)("keys");
            val_15 = "keys";
            // 0x00C7F990: B #0xc7f9ac                |  goto label_17;                         
            goto label_17;
            label_2:
            // 0x00C7F994: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00C7F998: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00C7F99C: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            val_14 = null;
            // 0x00C7F9A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C7F9A4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00C7F9A8: LDR x8, [x8, #0x4a8]       | X8 = (string**)(1152921513267573920)("values");
            val_15 = "values";
            label_17:
            // 0x00C7F9AC: LDR x1, [x8]               | X1 = "values";                          
            // 0x00C7F9B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7F9B4: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            val_16 = val_14;
            // 0x00C7F9B8: BL #0x18b3df0              | .ctor(paramName:  val_15 = "values");   
            val_14 = new System.ArgumentNullException(paramName:  val_15);
            // 0x00C7F9BC: B #0xc7f9f4                |  goto label_18;                         
            goto label_18;
            label_3:
            // 0x00C7F9C0: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00C7F9C4: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x00C7F9C8: LDR x0, [x8]               | X0 = typeof(System.ArgumentException);  
            System.ArgumentException val_8 = null;
            // 0x00C7F9CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x00C7F9D0: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00C7F9D4: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
            // 0x00C7F9D8: LDR x8, [x8, #0x10]        | X8 = (string**)(1152921514349536624)("Not all keys are covered by values");
            // 0x00C7F9DC: LDR x9, [x9, #0x4a8]       | X9 = (string**)(1152921513267573920)("values");
            // 0x00C7F9E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7F9E4: MOV x19, x0                | X19 = 1152921504651841536 (0x1000000002AE9000);//ML01
            val_16 = val_8;
            // 0x00C7F9E8: LDR x1, [x8]               | X1 = "Not all keys are covered by values";
            // 0x00C7F9EC: LDR x2, [x9]               | X2 = "values";                          
            // 0x00C7F9F0: BL #0x18b3ee4              | .ctor(message:  "Not all keys are covered by values", paramName:  "values");
            val_8 = new System.ArgumentException(message:  "Not all keys are covered by values", paramName:  "values");
            label_18:
            // 0x00C7F9F4: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00C7F9F8: LDR x8, [x8, #0x1a8]       | X8 = 1152921514349536768;               
            // 0x00C7F9FC: MOV x0, x19                | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x00C7FA00: LDR x1, [x8]               | X1 = static ProtoBuf.Meta.BasicList ProtoBuf.Meta.BasicList::GetContiguousGroups(int[] keys, object[] values);
            // 0x00C7FA04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentException), ????);
            // 0x00C7FA08: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  44994560);
            System.Byte[] val_9 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  44994560);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7FA84 (13105796), len: 116  VirtAddr: 0x00C7FA84 RVA: 0x00C7FA84 token: 100689230 methodIndex: 53442 delegateWrapperIndex: 0 methodInvoker: 0
        private static BasicList()
        {
            //
            // Disasemble & Code
            // 0x00C7FA84: STP x20, x19, [sp, #-0x20]! | stack[1152921514349821504] = ???;  stack[1152921514349821512] = ???;  //  dest_result_addr=1152921514349821504 |  dest_result_addr=1152921514349821512
            // 0x00C7FA88: STP x29, x30, [sp, #0x10]  | stack[1152921514349821520] = ???;  stack[1152921514349821528] = ???;  //  dest_result_addr=1152921514349821520 |  dest_result_addr=1152921514349821528
            // 0x00C7FA8C: ADD x29, sp, #0x10         | X29 = (1152921514349821504 + 16) = 1152921514349821520 (0x1000000244B9FE50);
            // 0x00C7FA90: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00C7FA94: LDRB w8, [x19, #0xfa1]     | W8 = (bool)static_value_03733FA1;       
            // 0x00C7FA98: TBNZ w8, #0, #0xc7fab4     | if (static_value_03733FA1 == true) goto label_0;
            // 0x00C7FA9C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00C7FAA0: LDR x8, [x8, #0xb0]        | X8 = 0x2B8F108;                         
            // 0x00C7FAA4: LDR w0, [x8]               | W0 = 0x1304;                            
            // 0x00C7FAA8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1304, ????);     
            // 0x00C7FAAC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7FAB0: STRB w8, [x19, #0xfa1]     | static_value_03733FA1 = true;            //  dest_result_addr=57884577
            label_0:
            // 0x00C7FAB4: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00C7FAB8: LDR x8, [x8, #0x218]       | X8 = 1152921504882511872;               
            // 0x00C7FABC: LDR x0, [x8]               | X0 = typeof(BasicList.Node);            
            object val_1 = null;
            // 0x00C7FAC0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BasicList.Node), ????);
            // 0x00C7FAC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7FAC8: MOV x19, x0                | X19 = 1152921504882511872 (0x10000000106E5000);//ML01
            // 0x00C7FACC: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00C7FAD0: STR wzr, [x19, #0x18]      | typeof(BasicList.Node).__il2cppRuntimeField_18 = 0x0;  //  dest_result_addr=1152921504882511896
            typeof(BasicList.Node).__il2cppRuntimeField_18 = 0;
            // 0x00C7FAD4: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00C7FAD8: STR xzr, [x19, #0x10]      | typeof(BasicList.Node).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504882511888
            typeof(BasicList.Node).__il2cppRuntimeField_10 = 0;
            // 0x00C7FADC: LDR x8, [x8, #0x8f0]       | X8 = 1152921504882405376;               
            // 0x00C7FAE0: LDR x8, [x8]               | X8 = typeof(ProtoBuf.Meta.BasicList);   
            // 0x00C7FAE4: LDR x8, [x8, #0xa0]        | X8 = ProtoBuf.Meta.BasicList.__il2cppRuntimeField_static_fields;
            // 0x00C7FAE8: STR x19, [x8]              | ProtoBuf.Meta.BasicList.nil = typeof(BasicList.Node);  //  dest_result_addr=1152921504882409472
            ProtoBuf.Meta.BasicList.nil = val_1;
            // 0x00C7FAEC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7FAF0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7FAF4: RET                        |  return;                                
            return;
        
        }
    
    }

}
