using UnityEngine;
public class AnimationPoint : MonoBehaviour
{
    // Fields
    public AnimationRunner.AniType AniType; //  0x00000018
    public float AniTime; //  0x0000001C
    [UnityEngine.HideInInspector] // 0x286A8E8
    public UnityEngine.Vector3 Pos; //  0x00000020
    public UnityEngine.Vector3 Rot; //  0x0000002C
    public float Delay; //  0x00000038
    public float Time; //  0x0000003C
    public string Fun; //  0x00000040
    public UnityEngine.Vector3 VibrationV3; //  0x00000048
    public float VibrationTime; //  0x00000054
    public float VibrationDelay; //  0x00000058
    [UnityEngine.HideInInspector] // 0x286A8F8
    public UnityEngine.GameObject targe; //  0x00000060
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B276D4 (11695828), len: 180  VirtAddr: 0x00B276D4 RVA: 0x00B276D4 token: 100690114 methodIndex: 24787 delegateWrapperIndex: 0 methodInvoker: 0
    public AnimationPoint()
    {
        //
        // Disasemble & Code
        // 0x00B276D4: STP x20, x19, [sp, #-0x20]! | stack[1152921514474574032] = ???;  stack[1152921514474574040] = ???;  //  dest_result_addr=1152921514474574032 |  dest_result_addr=1152921514474574040
        // 0x00B276D8: STP x29, x30, [sp, #0x10]  | stack[1152921514474574048] = ???;  stack[1152921514474574056] = ???;  //  dest_result_addr=1152921514474574048 |  dest_result_addr=1152921514474574056
        // 0x00B276DC: ADD x29, sp, #0x10         | X29 = (1152921514474574032 + 16) = 1152921514474574048 (0x100000024C2990E0);
        // 0x00B276E0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B276E4: LDRB w8, [x20, #0x74d]     | W8 = (bool)static_value_0373374D;       
        // 0x00B276E8: MOV x19, x0                | X19 = 1152921514474586064 (0x100000024C29BFD0);//ML01
        // 0x00B276EC: TBNZ w8, #0, #0xb27708     | if (static_value_0373374D == true) goto label_0;
        // 0x00B276F0: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B276F4: LDR x8, [x8, #0xb8]        | X8 = 0x2B8AE08;                         
        // 0x00B276F8: LDR w0, [x8]               | W0 = 0x240;                             
        // 0x00B276FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x240, ????);      
        // 0x00B27700: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B27704: STRB w8, [x20, #0x74d]     | static_value_0373374D = true;            //  dest_result_addr=57882445
        label_0:
        // 0x00B27708: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B2770C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B27710: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B27714: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B27718: TBZ w8, #0, #0xb27728      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B2771C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B27720: CBNZ w8, #0xb27728         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B27724: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_2:
        // 0x00B27728: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2772C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27730: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_1 = UnityEngine.Vector3.zero;
        // 0x00B27734: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B27738: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2773C: STP s0, s1, [x19, #0x20]   | this.Pos = val_1;  mem[1152921514474586100] = val_1.y;  //  dest_result_addr=1152921514474586096 |  dest_result_addr=1152921514474586100
        this.Pos = val_1;
        mem[1152921514474586100] = val_1.y;
        // 0x00B27740: STR s2, [x19, #0x28]       | mem[1152921514474586104] = val_1.z;      //  dest_result_addr=1152921514474586104
        mem[1152921514474586104] = val_1.z;
        // 0x00B27744: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_2 = UnityEngine.Vector3.zero;
        // 0x00B27748: STP s0, s1, [x19, #0x2c]   | this.Rot = val_2;  mem[1152921514474586112] = val_2.y;  //  dest_result_addr=1152921514474586108 |  dest_result_addr=1152921514474586112
        this.Rot = val_2;
        mem[1152921514474586112] = val_2.y;
        // 0x00B2774C: STR s2, [x19, #0x34]       | mem[1152921514474586116] = val_2.z;      //  dest_result_addr=1152921514474586116
        mem[1152921514474586116] = val_2.z;
        // 0x00B27750: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00B27754: LDR x8, [x8, #0x5a8]       | X8 = (string**)(1152921513178512912)("0");
        // 0x00B27758: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2775C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27760: LDR x8, [x8]               | X8 = "0";                               
        // 0x00B27764: STR x8, [x19, #0x40]       | this.Fun = "0";                          //  dest_result_addr=1152921514474586128
        this.Fun = "0";
        // 0x00B27768: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_3 = UnityEngine.Vector3.zero;
        // 0x00B2776C: STP s0, s1, [x19, #0x48]   | this.VibrationV3 = val_3;  mem[1152921514474586140] = val_3.y;  //  dest_result_addr=1152921514474586136 |  dest_result_addr=1152921514474586140
        this.VibrationV3 = val_3;
        mem[1152921514474586140] = val_3.y;
        // 0x00B27770: STR s2, [x19, #0x50]       | mem[1152921514474586144] = val_3.z;      //  dest_result_addr=1152921514474586144
        mem[1152921514474586144] = val_3.z;
        // 0x00B27774: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B27778: MOV x0, x19                | X0 = 1152921514474586064 (0x100000024C29BFD0);//ML01
        // 0x00B2777C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27780: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B27784: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27788 (11696008), len: 508  VirtAddr: 0x00B27788 RVA: 0x00B27788 token: 100690115 methodIndex: 24788 delegateWrapperIndex: 0 methodInvoker: 0
    public void ToObject(AnimationPoint point)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00B27788: STP d11, d10, [sp, #-0x50]! | stack[1152921514474706464] = ???;  stack[1152921514474706472] = ???;  //  dest_result_addr=1152921514474706464 |  dest_result_addr=1152921514474706472
        // 0x00B2778C: STP d9, d8, [sp, #0x10]    | stack[1152921514474706480] = ???;  stack[1152921514474706488] = ???;  //  dest_result_addr=1152921514474706480 |  dest_result_addr=1152921514474706488
        // 0x00B27790: STP x22, x21, [sp, #0x20]  | stack[1152921514474706496] = ???;  stack[1152921514474706504] = ???;  //  dest_result_addr=1152921514474706496 |  dest_result_addr=1152921514474706504
        // 0x00B27794: STP x20, x19, [sp, #0x30]  | stack[1152921514474706512] = ???;  stack[1152921514474706520] = ???;  //  dest_result_addr=1152921514474706512 |  dest_result_addr=1152921514474706520
        // 0x00B27798: STP x29, x30, [sp, #0x40]  | stack[1152921514474706528] = ???;  stack[1152921514474706536] = ???;  //  dest_result_addr=1152921514474706528 |  dest_result_addr=1152921514474706536
        // 0x00B2779C: ADD x29, sp, #0x40         | X29 = (1152921514474706464 + 64) = 1152921514474706528 (0x100000024C2B9660);
        // 0x00B277A0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B277A4: LDRB w8, [x21, #0x74e]     | W8 = (bool)static_value_0373374E;       
        // 0x00B277A8: MOV x19, x1                | X19 = point;//m1                        
        // 0x00B277AC: MOV x20, x0                | X20 = 1152921514474718544 (0x100000024C2BC550);//ML01
        // 0x00B277B0: TBNZ w8, #0, #0xb277cc     | if (static_value_0373374E == true) goto label_0;
        // 0x00B277B4: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x00B277B8: LDR x8, [x8, #0xd98]       | X8 = 0x2B8AE0C;                         
        // 0x00B277BC: LDR w0, [x8]               | W0 = 0x241;                             
        // 0x00B277C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x241, ????);      
        // 0x00B277C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B277C8: STRB w8, [x21, #0x74e]     | static_value_0373374E = true;            //  dest_result_addr=57882446
        label_0:
        // 0x00B277CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B277D0: MOV x0, x20                | X0 = 1152921514474718544 (0x100000024C2BC550);//ML01
        // 0x00B277D4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_1 = this.transform;
        // 0x00B277D8: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B277DC: CBNZ x19, #0xb277e4        | if (point != null) goto label_1;        
        if(point != null)
        {
            goto label_1;
        }
        // 0x00B277E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B277E4: LDP s8, s9, [x19, #0x20]   | S8 = point.Pos; //P2                     //  | 
        // 0x00B277E8: LDR s10, [x19, #0x28]      | 
        // 0x00B277EC: CBNZ x21, #0xb277f4        | if (val_1 != null) goto label_2;        
        if(val_1 != null)
        {
            goto label_2;
        }
        // 0x00B277F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B277F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B277F8: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B277FC: MOV v0.16b, v8.16b         | V0 = point.Pos;//m1                     
        // 0x00B27800: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00B27804: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00B27808: BL #0x26935b8              | val_1.set_position(value:  new UnityEngine.Vector3() {x = point.Pos, y = V9.16B, z = V10.16B});
        val_1.position = new UnityEngine.Vector3() {x = point.Pos, y = V9.16B, z = V10.16B};
        // 0x00B2780C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27810: MOV x0, x20                | X0 = 1152921514474718544 (0x100000024C2BC550);//ML01
        // 0x00B27814: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_2 = this.transform;
        // 0x00B27818: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B2781C: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00B27820: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00B27824: LDR x8, [x8]               | X8 = typeof(UnityEngine.Quaternion);    
        // 0x00B27828: LDP s10, s9, [x19, #0x2c]  | S10 = point.Rot; //P2                    //  | 
        // 0x00B2782C: LDR s8, [x19, #0x34]       | 
        // 0x00B27830: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00B27834: TBZ w9, #0, #0xb27848      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B27838: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00B2783C: CBNZ w9, #0xb27848         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B27840: MOV x0, x8                 | X0 = 1152921504695132160 (0x1000000005432000);//ML01
        // 0x00B27844: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_4:
        // 0x00B27848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2784C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27850: MOV v0.16b, v10.16b        | V0 = point.Rot;//m1                     
        // 0x00B27854: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00B27858: MOV v2.16b, v8.16b         | V2 = point.Pos;//m1                     
        // 0x00B2785C: BL #0x1b7f628              | X0 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = point.Rot, y = V9.16B, z = point.Pos});
        UnityEngine.Quaternion val_3 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = point.Rot, y = V9.16B, z = point.Pos});
        // 0x00B27860: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        // 0x00B27864: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x00B27868: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
        // 0x00B2786C: MOV v11.16b, v3.16b        | V11 = val_3.w;//m1                      
        // 0x00B27870: CBNZ x21, #0xb27878        | if (val_2 != null) goto label_5;        
        if(val_2 != null)
        {
            goto label_5;
        }
        // 0x00B27874: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_5:
        // 0x00B27878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2787C: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00B27880: MOV v0.16b, v8.16b         | V0 = val_3.x;//m1                       
        // 0x00B27884: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x00B27888: MOV v2.16b, v10.16b        | V2 = val_3.z;//m1                       
        // 0x00B2788C: MOV v3.16b, v11.16b        | V3 = val_3.w;//m1                       
        // 0x00B27890: BL #0x26938b0              | val_2.set_rotation(value:  new UnityEngine.Quaternion() {x = val_3.x, y = val_3.y, z = val_3.z, w = val_3.w});
        val_2.rotation = new UnityEngine.Quaternion() {x = val_3.x, y = val_3.y, z = val_3.z, w = val_3.w};
        // 0x00B27894: CBNZ x19, #0xb2789c        | if (point != null) goto label_6;        
        if(point != null)
        {
            goto label_6;
        }
        // 0x00B27898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B2789C: LDP w8, w9, [x19, #0x2c]   | W8 = point.Rot; //P2                     //  | 
        // 0x00B278A0: LDR w10, [x19, #0x34]      | 
        // 0x00B278A4: STP w8, w9, [x20, #0x2c]   | this.Rot = point.Rot;  mem[1152921514474718592] = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;  //  dest_result_addr=1152921514474718588 |  dest_result_addr=1152921514474718592
        this.Rot = point.Rot;
        mem[1152921514474718592] = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00B278A8: STR w10, [x20, #0x34]      | mem[1152921514474718596] = ???;          //  dest_result_addr=1152921514474718596
        mem[1152921514474718596] = ???;
        // 0x00B278AC: CBZ x19, #0xb278dc         | if (point == null) goto label_7;        
        if(point == null)
        {
            goto label_7;
        }
        // 0x00B278B0: LDR w8, [x19, #0x18]       | W8 = point.AniType; //P2                
        // 0x00B278B4: STR w8, [x20, #0x18]       | this.AniType = point.AniType;            //  dest_result_addr=1152921514474718568
        this.AniType = point.AniType;
        // 0x00B278B8: LDR w8, [x19, #0x1c]       | W8 = point.AniTime; //P2                
        // 0x00B278BC: STR w8, [x20, #0x1c]       | this.AniTime = point.AniTime;            //  dest_result_addr=1152921514474718572
        this.AniTime = point.AniTime;
        // 0x00B278C0: LDR w8, [x19, #0x38]       | W8 = point.Delay; //P2                  
        // 0x00B278C4: STR w8, [x20, #0x38]       | this.Delay = point.Delay;                //  dest_result_addr=1152921514474718600
        this.Delay = point.Delay;
        // 0x00B278C8: LDR w8, [x19, #0x3c]       | W8 = point.Time; //P2                   
        // 0x00B278CC: STR w8, [x20, #0x3c]       | this.Time = point.Time;                  //  dest_result_addr=1152921514474718604
        this.Time = point.Time;
        // 0x00B278D0: LDR x8, [x19, #0x40]       | X8 = point.Fun; //P2                    
        // 0x00B278D4: STR x8, [x20, #0x40]       | this.Fun = point.Fun;                    //  dest_result_addr=1152921514474718608
        this.Fun = point.Fun;
        // 0x00B278D8: B #0xb27930                |  goto label_8;                          
        goto label_8;
        label_7:
        // 0x00B278DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B278E0: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
        // 0x00B278E4: LDR w8, [x8]               | W8 = 0x9814C0;                          
        // 0x00B278E8: STR w8, [x20, #0x18]       | this.AniType = 0x9814C0;                 //  dest_result_addr=1152921514474718568
        this.AniType = 9966784;
        // 0x00B278EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B278F0: ORR w8, wzr, #0x1c         | W8 = 28(0x1C);                          
        // 0x00B278F4: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00B278F8: STR w8, [x20, #0x1c]       | this.AniTime = 0;                        //  dest_result_addr=1152921514474718572
        this.AniTime = 0f;
        // 0x00B278FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B27900: ORR w8, wzr, #0x38         | W8 = 56(0x38);                          
        // 0x00B27904: LDR w8, [x8]               | W8 = 0x400006;                          
        // 0x00B27908: STR w8, [x20, #0x38]       | this.Delay = 5.87748016190222E-39;       //  dest_result_addr=1152921514474718600
        this.Delay = 5.87748E-39f;
        // 0x00B2790C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B27910: ORR w8, wzr, #0x3c         | W8 = 60(0x3C);                          
        // 0x00B27914: LDR w8, [x8]               | W8 = 0x19001A;                          
        // 0x00B27918: STR w8, [x20, #0x3c]       | this.Time = 2.29592383770985E-39;        //  dest_result_addr=1152921514474718604
        this.Time = 2.295924E-39f;
        // 0x00B2791C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B27920: ORR w8, wzr, #0x40         | W8 = 64(0x40);                          
        // 0x00B27924: LDR x8, [x8]               | X8 = 0x500000001;                       
        // 0x00B27928: STR x8, [x20, #0x40]       | this.Fun = 0x500000001;                  //  dest_result_addr=1152921514474718608
        this.Fun = 1;
        // 0x00B2792C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00B27930: LDP w8, w9, [x19, #0x48]   | W8 = point.VibrationV3; //P2             //  | 
        // 0x00B27934: LDR w10, [x19, #0x50]      | 
        // 0x00B27938: STP w8, w9, [x20, #0x48]   | this.VibrationV3 = point.VibrationV3;  mem[1152921514474718620] = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;  //  dest_result_addr=1152921514474718616 |  dest_result_addr=1152921514474718620
        this.VibrationV3 = point.VibrationV3;
        mem[1152921514474718620] = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00B2793C: STR w10, [x20, #0x50]      | mem[1152921514474718624] = ???;          //  dest_result_addr=1152921514474718624
        mem[1152921514474718624] = ???;
        // 0x00B27940: CBZ x19, #0xb27950         | if (point == null) goto label_9;        
        if(point == null)
        {
            goto label_9;
        }
        // 0x00B27944: LDR w8, [x19, #0x54]       | W8 = point.VibrationTime; //P2          
        // 0x00B27948: STR w8, [x20, #0x54]       | this.VibrationTime = point.VibrationTime;  //  dest_result_addr=1152921514474718628
        this.VibrationTime = point.VibrationTime;
        // 0x00B2794C: B #0xb27964                |  goto label_10;                         
        goto label_10;
        label_9:
        // 0x00B27950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B27954: MOVZ w8, #0x54             | W8 = 84 (0x54);//ML01                   
        // 0x00B27958: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00B2795C: STR w8, [x20, #0x54]       | this.VibrationTime = 0;                  //  dest_result_addr=1152921514474718628
        this.VibrationTime = 0f;
        // 0x00B27960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_10:
        // 0x00B27964: LDR w8, [x19, #0x58]       | W8 = point.VibrationDelay; //P2         
        // 0x00B27968: STR w8, [x20, #0x58]       | this.VibrationDelay = point.VibrationDelay;  //  dest_result_addr=1152921514474718632
        this.VibrationDelay = point.VibrationDelay;
        // 0x00B2796C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B27970: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B27974: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B27978: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B2797C: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00B27980: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27984 (11696516), len: 208  VirtAddr: 0x00B27984 RVA: 0x00B27984 token: 100690116 methodIndex: 24789 delegateWrapperIndex: 0 methodInvoker: 0
    public void ToJson(AnimationPoint point)
    {
        //
        // Disasemble & Code
        //  | 
        float val_3;
        // 0x00B27984: STP d9, d8, [sp, #-0x40]!  | stack[1152921514474855344] = ???;  stack[1152921514474855352] = ???;  //  dest_result_addr=1152921514474855344 |  dest_result_addr=1152921514474855352
        // 0x00B27988: STP x22, x21, [sp, #0x10]  | stack[1152921514474855360] = ???;  stack[1152921514474855368] = ???;  //  dest_result_addr=1152921514474855360 |  dest_result_addr=1152921514474855368
        // 0x00B2798C: STP x20, x19, [sp, #0x20]  | stack[1152921514474855376] = ???;  stack[1152921514474855384] = ???;  //  dest_result_addr=1152921514474855376 |  dest_result_addr=1152921514474855384
        // 0x00B27990: STP x29, x30, [sp, #0x30]  | stack[1152921514474855392] = ???;  stack[1152921514474855400] = ???;  //  dest_result_addr=1152921514474855392 |  dest_result_addr=1152921514474855400
        // 0x00B27994: ADD x29, sp, #0x30         | X29 = (1152921514474855344 + 48) = 1152921514474855392 (0x100000024C2DDBE0);
        // 0x00B27998: MOV x19, x0                | X19 = 1152921514474867408 (0x100000024C2E0AD0);//ML01
        // 0x00B2799C: LDR w21, [x19, #0x18]      | W21 = this.AniType; //P2                
        // 0x00B279A0: MOV x20, x1                | X20 = point;//m1                        
        // 0x00B279A4: CBZ x20, #0xb279b4         | if (point == null) goto label_0;        
        if(point == null)
        {
            goto label_0;
        }
        // 0x00B279A8: STR w21, [x20, #0x18]      | point.AniType = this.AniType;            //  dest_result_addr=0
        point.AniType = this.AniType;
        // 0x00B279AC: LDR s8, [x19, #0x1c]       | S8 = this.AniTime; //P2                 
        val_3 = this.AniTime;
        // 0x00B279B0: B #0xb279c8                |  goto label_1;                          
        goto label_1;
        label_0:
        // 0x00B279B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        // 0x00B279B8: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
        // 0x00B279BC: STR w21, [x8]              | mem[24] = this.AniType;                  //  dest_result_addr=24
        mem[24] = this.AniType;
        // 0x00B279C0: LDR s8, [x19, #0x1c]       | S8 = this.AniTime; //P2                 
        val_3 = this.AniTime;
        // 0x00B279C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_1:
        // 0x00B279C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B279CC: MOV x0, x19                | X0 = 1152921514474867408 (0x100000024C2E0AD0);//ML01
        // 0x00B279D0: STR s8, [x20, #0x1c]       | point.AniTime = this.AniTime;            //  dest_result_addr=0
        point.AniTime = val_3;
        // 0x00B279D4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_1 = this.transform;
        // 0x00B279D8: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B279DC: CBNZ x21, #0xb279e4        | if (val_1 != null) goto label_2;        
        if(val_1 != null)
        {
            goto label_2;
        }
        // 0x00B279E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B279E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B279E8: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B279EC: BL #0x2693510              | X0 = val_1.get_position();              
        UnityEngine.Vector3 val_2 = val_1.position;
        // 0x00B279F0: STP s0, s1, [x20, #0x20]   | point.Pos = val_2;  mem2[0] = val_2.y;   //  dest_result_addr=0 |  dest_result_addr=0
        point.Pos = val_2;
        mem2[0] = val_2.y;
        // 0x00B279F4: STR s2, [x20, #0x28]       | mem2[0] = val_2.z;                       //  dest_result_addr=0
        mem2[0] = val_2.z;
        // 0x00B279F8: LDP w8, w9, [x19, #0x2c]   | W8 = this.Rot; //P2                      //  | 
        // 0x00B279FC: LDR w10, [x19, #0x34]      | 
        // 0x00B27A00: STP w8, w9, [x20, #0x2c]   | point.Rot = this.Rot;  mem2[0] = ???;    //  dest_result_addr=0 |  dest_result_addr=0
        point.Rot = this.Rot;
        mem2[0] = ???;
        // 0x00B27A04: STR w10, [x20, #0x34]      | mem2[0] = ???;                           //  dest_result_addr=0
        mem2[0] = ???;
        // 0x00B27A08: LDR w8, [x19, #0x38]       | W8 = this.Delay; //P2                   
        // 0x00B27A0C: STR w8, [x20, #0x38]       | point.Delay = this.Delay;                //  dest_result_addr=0
        point.Delay = this.Delay;
        // 0x00B27A10: LDR w8, [x19, #0x3c]       | W8 = this.Time; //P2                    
        // 0x00B27A14: STR w8, [x20, #0x3c]       | point.Time = this.Time;                  //  dest_result_addr=0
        point.Time = this.Time;
        // 0x00B27A18: LDR x8, [x19, #0x40]       | X8 = this.Fun; //P2                     
        // 0x00B27A1C: STR x8, [x20, #0x40]       | point.Fun = this.Fun;                    //  dest_result_addr=0
        point.Fun = this.Fun;
        // 0x00B27A20: LDP w8, w9, [x19, #0x48]   | W8 = this.VibrationV3; //P2              //  | 
        // 0x00B27A24: LDR w10, [x19, #0x50]      | 
        // 0x00B27A28: STP w8, w9, [x20, #0x48]   | point.VibrationV3 = this.VibrationV3;  mem2[0] = ???;  //  dest_result_addr=0 |  dest_result_addr=0
        point.VibrationV3 = this.VibrationV3;
        mem2[0] = ???;
        // 0x00B27A2C: STR w10, [x20, #0x50]      | mem2[0] = ???;                           //  dest_result_addr=0
        mem2[0] = ???;
        // 0x00B27A30: LDR w8, [x19, #0x54]       | W8 = this.VibrationTime; //P2           
        // 0x00B27A34: STR w8, [x20, #0x54]       | point.VibrationTime = this.VibrationTime;  //  dest_result_addr=0
        point.VibrationTime = this.VibrationTime;
        // 0x00B27A38: LDR w8, [x19, #0x58]       | W8 = this.VibrationDelay; //P2          
        // 0x00B27A3C: STR w8, [x20, #0x58]       | point.VibrationDelay = this.VibrationDelay;  //  dest_result_addr=0
        point.VibrationDelay = this.VibrationDelay;
        // 0x00B27A40: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B27A44: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B27A48: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B27A4C: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B27A50: RET                        |  return;                                
        return;
    
    }

}
