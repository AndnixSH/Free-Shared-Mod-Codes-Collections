using UnityEngine;
public class APaymentHelper
{
    // Fields
    private UnityEngine.AndroidJavaClass klass; //  0x00000010
    private static APaymentHelper _instance; // static_offset: 0x00000000
    
    // Properties
    public static APaymentHelper Instance { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B2A790 (11708304), len: 116  VirtAddr: 0x00B2A790 RVA: 0x00B2A790 token: 100696272 methodIndex: 24871 delegateWrapperIndex: 0 methodInvoker: 0
    public APaymentHelper()
    {
        //
        // Disasemble & Code
        // 0x00B2A790: STP x20, x19, [sp, #-0x20]! | stack[1152921515506702336] = ???;  stack[1152921515506702344] = ???;  //  dest_result_addr=1152921515506702336 |  dest_result_addr=1152921515506702344
        // 0x00B2A794: STP x29, x30, [sp, #0x10]  | stack[1152921515506702352] = ???;  stack[1152921515506702360] = ???;  //  dest_result_addr=1152921515506702352 |  dest_result_addr=1152921515506702360
        // 0x00B2A798: ADD x29, sp, #0x10         | X29 = (1152921515506702336 + 16) = 1152921515506702352 (0x1000000289AE9810);
        // 0x00B2A79C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B2A7A0: LDRB w8, [x20, #0x768]     | W8 = (bool)static_value_03733768;       
        // 0x00B2A7A4: MOV x19, x0                | X19 = 1152921515506714368 (0x1000000289AEC700);//ML01
        // 0x00B2A7A8: TBNZ w8, #0, #0xb2a7c4     | if (static_value_03733768 == true) goto label_0;
        // 0x00B2A7AC: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00B2A7B0: LDR x8, [x8, #0xae8]       | X8 = 0x2B8AFC4;                         
        // 0x00B2A7B4: LDR w0, [x8]               | W0 = 0x2AF;                             
        // 0x00B2A7B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2AF, ????);      
        // 0x00B2A7BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A7C0: STRB w8, [x20, #0x768]     | static_value_03733768 = true;            //  dest_result_addr=57882472
        label_0:
        // 0x00B2A7C4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B2A7C8: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B2A7CC: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00B2A7D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2A7D4: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00B2A7D8: LDR x8, [x8, #0x358]       | X8 = (string**)(1152921515506690208)("com.snowfish.android.ahelper.APaymentUnity");
        // 0x00B2A7DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2A7E0: MOV x20, x0                | X20 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2A7E4: LDR x1, [x8]               | X1 = "com.snowfish.android.ahelper.APaymentUnity";
        // 0x00B2A7E8: BL #0x20b9834              | .ctor(className:  "com.snowfish.android.ahelper.APaymentUnity");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.snowfish.android.ahelper.APaymentUnity");
        // 0x00B2A7EC: STR x20, [x19, #0x10]      | this.klass = typeof(UnityEngine.AndroidJavaClass);  //  dest_result_addr=1152921515506714384
        this.klass = val_1;
        // 0x00B2A7F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A7F4: MOV x0, x19                | X0 = 1152921515506714368 (0x1000000289AEC700);//ML01
        // 0x00B2A7F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2A7FC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A800: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A804 (11708420), len: 124  VirtAddr: 0x00B2A804 RVA: 0x00B2A804 token: 100696273 methodIndex: 24872 delegateWrapperIndex: 0 methodInvoker: 0
    public static APaymentHelper get_Instance()
    {
        //
        // Disasemble & Code
        //  | 
        APaymentHelper val_2;
        //  | 
        APaymentHelper val_3;
        // 0x00B2A804: STP x20, x19, [sp, #-0x20]! | stack[1152921515506814336] = ???;  stack[1152921515506814344] = ???;  //  dest_result_addr=1152921515506814336 |  dest_result_addr=1152921515506814344
        // 0x00B2A808: STP x29, x30, [sp, #0x10]  | stack[1152921515506814352] = ???;  stack[1152921515506814360] = ???;  //  dest_result_addr=1152921515506814352 |  dest_result_addr=1152921515506814360
        // 0x00B2A80C: ADD x29, sp, #0x10         | X29 = (1152921515506814336 + 16) = 1152921515506814352 (0x1000000289B04D90);
        // 0x00B2A810: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B2A814: LDRB w8, [x19, #0x769]     | W8 = (bool)static_value_03733769;       
        // 0x00B2A818: TBNZ w8, #0, #0xb2a834     | if (static_value_03733769 == true) goto label_0;
        // 0x00B2A81C: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00B2A820: LDR x8, [x8, #0x5c8]       | X8 = 0x2B8AFCC;                         
        // 0x00B2A824: LDR w0, [x8]               | W0 = 0x2B1;                             
        // 0x00B2A828: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B1, ????);      
        // 0x00B2A82C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A830: STRB w8, [x19, #0x769]     | static_value_03733769 = true;            //  dest_result_addr=57882473
        label_0:
        // 0x00B2A834: ADRP x20, #0x364b000       | X20 = 56930304 (0x364B000);             
        // 0x00B2A838: LDR x20, [x20, #0x978]     | X20 = 1152921504919732224;              
        // 0x00B2A83C: LDR x0, [x20]              | X0 = typeof(APaymentHelper);            
        APaymentHelper val_1 = null;
        // 0x00B2A840: LDR x8, [x0, #0xa0]        | X8 = APaymentHelper.__il2cppRuntimeField_static_fields;
        // 0x00B2A844: LDR x8, [x8]               | X8 = APaymentHelper._instance;          
        val_3 = APaymentHelper._instance;
        // 0x00B2A848: CBNZ x8, #0xb2a870         | if (APaymentHelper._instance != null) goto label_1;
        if(val_3 != null)
        {
            goto label_1;
        }
        // 0x00B2A84C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(APaymentHelper), ????);
        // 0x00B2A850: MOV x19, x0                | X19 = 1152921504919732224 (0x1000000012A64000);//ML01
        val_2 = val_1;
        // 0x00B2A854: BL #0xb2a790               | .ctor();                                
        val_1 = new APaymentHelper();
        // 0x00B2A858: LDR x8, [x20]              | X8 = typeof(APaymentHelper);            
        // 0x00B2A85C: LDR x8, [x8, #0xa0]        | X8 = APaymentHelper.__il2cppRuntimeField_static_fields;
        // 0x00B2A860: STR x19, [x8]              | APaymentHelper._instance = typeof(APaymentHelper);  //  dest_result_addr=1152921504919736320
        APaymentHelper._instance = val_2;
        // 0x00B2A864: LDR x8, [x20]              | X8 = typeof(APaymentHelper);            
        // 0x00B2A868: LDR x8, [x8, #0xa0]        | X8 = APaymentHelper.__il2cppRuntimeField_static_fields;
        // 0x00B2A86C: LDR x8, [x8]               | X8 = typeof(APaymentHelper);            
        val_3 = APaymentHelper._instance;
        label_1:
        // 0x00B2A870: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A874: MOV x0, x8                 | X0 = 1152921504919732224 (0x1000000012A64000);//ML01
        // 0x00B2A878: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A87C: RET                        |  return (APaymentHelper)typeof(APaymentHelper);
        return (APaymentHelper)val_3;
        //  |  // // {name=val_0, type=APaymentHelper, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A880 (11708544), len: 660  VirtAddr: 0x00B2A880 RVA: 0x00B2A880 token: 100696274 methodIndex: 24873 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        // 0x00B2A880: STP x22, x21, [sp, #-0x30]! | stack[1152921515506934592] = ???;  stack[1152921515506934600] = ???;  //  dest_result_addr=1152921515506934592 |  dest_result_addr=1152921515506934600
        // 0x00B2A884: STP x20, x19, [sp, #0x10]  | stack[1152921515506934608] = ???;  stack[1152921515506934616] = ???;  //  dest_result_addr=1152921515506934608 |  dest_result_addr=1152921515506934616
        // 0x00B2A888: STP x29, x30, [sp, #0x20]  | stack[1152921515506934624] = ???;  stack[1152921515506934632] = ???;  //  dest_result_addr=1152921515506934624 |  dest_result_addr=1152921515506934632
        // 0x00B2A88C: ADD x29, sp, #0x20         | X29 = (1152921515506934592 + 32) = 1152921515506934624 (0x1000000289B22360);
        // 0x00B2A890: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B2A894: LDRB w8, [x19, #0x76a]     | W8 = (bool)static_value_0373376A;       
        // 0x00B2A898: MOV x21, x0                | X21 = 1152921515506946640 (0x1000000289B25250);//ML01
        // 0x00B2A89C: TBNZ w8, #0, #0xb2a8b8     | if (static_value_0373376A == true) goto label_0;
        // 0x00B2A8A0: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
        // 0x00B2A8A4: LDR x8, [x8, #0x230]       | X8 = 0x2B8AFD8;                         
        // 0x00B2A8A8: LDR w0, [x8]               | W0 = 0x2B4;                             
        // 0x00B2A8AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B4, ????);      
        // 0x00B2A8B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A8B4: STRB w8, [x19, #0x76a]     | static_value_0373376A = true;            //  dest_result_addr=57882474
        label_0:
        // 0x00B2A8B8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B2A8BC: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B2A8C0: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00B2A8C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2A8C8: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B2A8CC: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921514474312160)("com.unity3d.player.UnityPlayer");
        // 0x00B2A8D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2A8D4: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_10 = val_1;
        // 0x00B2A8D8: LDR x1, [x8]               | X1 = "com.unity3d.player.UnityPlayer";  
        // 0x00B2A8DC: BL #0x20b9834              | .ctor(className:  "com.unity3d.player.UnityPlayer");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.unity3d.player.UnityPlayer");
        // 0x00B2A8E0: CBNZ x19, #0xb2a8ec        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B2A8E4: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        // 0x00B2A8E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "com.unity3d.player.UnityPlayer"), ????);
        label_1:
        // 0x00B2A8EC: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B2A8F0: LDR x8, [x8, #0xb8]        | X8 = (string**)(1152921514474312288)("currentActivity");
        // 0x00B2A8F4: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x00B2A8F8: LDR x9, [x9, #0x458]       | X9 = 1152921514474312400;               
        // 0x00B2A8FC: LDR x1, [x8]               | X1 = "currentActivity";                 
        // 0x00B2A900: LDR x2, [x9]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00B2A904: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2A908: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        // 0x00B2A90C: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        // 0x00B2A910: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B2A914: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B2A918: LDR x21, [x21, #0x10]      | X21 = this.klass; //P2                  
        // 0x00B2A91C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B2A920: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
        // 0x00B2A924: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2A928: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B2A92C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B2A930: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2A934: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B2A938: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2A93C: CBNZ x22, #0xb2a944        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00B2A940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_2:
        // 0x00B2A944: CBZ x20, #0xb2a968         | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00B2A948: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B2A94C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2A950: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2A954: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B2A958: CBNZ x0, #0xb2a968         | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B2A95C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00B2A960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2A964: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_4:
        // 0x00B2A968: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2A96C: CBNZ w8, #0xb2a97c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00B2A970: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00B2A974: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2A978: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_5:
        // 0x00B2A97C: STR x20, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00B2A980: CBNZ x21, #0xb2a988        | if (this.klass != null) goto label_6;   
        if(this.klass != null)
        {
            goto label_6;
        }
        // 0x00B2A984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B2A988: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00B2A98C: LDR x8, [x8, #0x600]       | X8 = (string**)(1152921515506922560)("onInit");
        // 0x00B2A990: LDR x1, [x8]               | X1 = "onInit";                          
        // 0x00B2A994: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B2A998: MOV x0, x21                | X0 = this.klass;//m1                    
        // 0x00B2A99C: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2A9A0: BL #0x20bdcfc              | this.klass.CallStatic(methodName:  "onInit", args:  null);
        this.klass.CallStatic(methodName:  "onInit", args:  null);
        // 0x00B2A9A4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_11 = 0;
        // 0x00B2A9A8: MOVZ w22, #0x43            | W22 = 67 (0x43);//ML01                  
        label_22:
        // 0x00B2A9AC: CBZ x20, #0xb2aa18         | if (val_2 == null) goto label_7;        
        if(val_2 == null)
        {
            goto label_7;
        }
        // 0x00B2A9B0: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2A9B4: LDR x8, [x20]              | X8 = typeof(UnityEngine.AndroidJavaObject);
        // 0x00B2A9B8: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2A9BC: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2A9C0: LDRH w9, [x8, #0x102]      | W9 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B2A9C4: CBZ x9, #0xb2a9f0          | if (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count == 0) goto label_8;
        // 0x00B2A9C8: LDR x10, [x8, #0x98]       | X10 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B2A9CC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_10 = 0;
        // 0x00B2A9D0: ADD x10, x10, #8           | X10 = (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504690216968 (0x1000000004F82008);
        label_10:
        // 0x00B2A9D4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B2A9D8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B2A9DC: B.EQ #0xb2aa00             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_9;
        // 0x00B2A9E0: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_10 = val_10 + 1;
        // 0x00B2A9E4: ADD x10, x10, #0x10        | X10 = (1152921504690216968 + 16) = 1152921504690216984 (0x1000000004F82018);
        // 0x00B2A9E8: CMP x11, x9                | STATE = COMPARE((0 + 1), UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B2A9EC: B.LO #0xb2a9d4             | if (0 < UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count) goto label_10;
        label_8:
        // 0x00B2A9F0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2A9F4: MOV x0, x20                | X0 = val_2;//m1                         
        val_12 = val_2;
        // 0x00B2A9F8: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B2A9FC: B #0xb2aa0c                |  goto label_11;                         
        goto label_11;
        label_9:
        // 0x00B2AA00: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B2AA04: ADD x8, x8, x9, lsl #4     | X8 = (1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B2AA08: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_11:
        // 0x00B2AA0C: LDP x8, x1, [x0]           | X8 = typeof(UnityEngine.AndroidJavaClass);  //  | 
        // 0x00B2AA10: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2AA14: BLR x8                     | X0 = sub_1000000004F86000( ?? val_2, ????);
        label_7:
        // 0x00B2AA18: MOVZ w20, #0x55            | W20 = 85 (0x55);//ML01                  
        val_13 = 85;
        // 0x00B2AA1C: CMP w22, #0x43             | STATE = COMPARE(0x43, 0x43)             
        // 0x00B2AA20: B.EQ #0xb2aa3c             | if (0x43 == 0x43) goto label_24;        
        if(67 == 67)
        {
            goto label_24;
        }
        // 0x00B2AA24: CBZ x21, #0xb2aa3c         | if (0x0 == 0) goto label_24;            
        if(val_11 == 0)
        {
            goto label_24;
        }
        // 0x00B2AA28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AA2C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B2AA30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B2AA34: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_11 = 0;
        // 0x00B2AA38: MOVZ w20, #0x55            | W20 = 85 (0x55);//ML01                  
        val_13 = 85;
        label_24:
        // 0x00B2AA3C: CBZ x19, #0xb2aaa8         | if ( == 0) goto label_14;               
        if(null == 0)
        {
            goto label_14;
        }
        // 0x00B2AA40: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2AA44: LDR x8, [x19]              | X8 = ;                                  
        UnityEngine.AndroidJavaClass val_13 = null;
        // 0x00B2AA48: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2AA4C: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2AA50: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00B2AA54: CBZ x9, #0xb2aa80          | if (mem[null + 258] == 0) goto label_15;
        if((mem[null + 258]) == 0)
        {
            goto label_15;
        }
        // 0x00B2AA58: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_11 = mem[null + 152];
        // 0x00B2AA5C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_12 = 0;
        // 0x00B2AA60: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_11 = val_11 + 8;
        label_17:
        // 0x00B2AA64: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00B2AA68: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00B2AA6C: B.EQ #0xb2aa90             | if ((mem[null + 152] + 8) + -8 == null) goto label_16;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_16;
        }
        // 0x00B2AA70: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x00B2AA74: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_11 = val_11 + 16;
        // 0x00B2AA78: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00B2AA7C: B.LO #0xb2aa64             | if (0 < mem[null + 258]) goto label_17; 
        if(val_12 < (mem[null + 258]))
        {
            goto label_17;
        }
        label_15:
        // 0x00B2AA80: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2AA84: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_14 = val_10;
        // 0x00B2AA88: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2AA8C: B #0xb2aa9c                |  goto label_18;                         
        goto label_18;
        label_16:
        // 0x00B2AA90: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00B2AA94: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_13 = val_13 + (((mem[null + 152] + 8)) << 4);
        // 0x00B2AA98: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_18:
        // 0x00B2AA9C: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
        // 0x00B2AAA0: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2AAA4: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        label_14:
        // 0x00B2AAA8: CMP w20, #0x55             | STATE = COMPARE(0x55, 0x55)             
        // 0x00B2AAAC: B.EQ #0xb2aacc             | if (0x55 == 0x55) goto label_20;        
        if(85 == 85)
        {
            goto label_20;
        }
        // 0x00B2AAB0: CBZ x21, #0xb2aacc         | if (0x0 == 0) goto label_20;            
        if(val_11 == 0)
        {
            goto label_20;
        }
        // 0x00B2AAB4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2AAB8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        val_10 = ???;
        // 0x00B2AABC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AAC0: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B2AAC4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        val_11 = ???;
        // 0x00B2AAC8: B #0x27ae3bc               | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_20:
        // 0x00B2AACC: LDP x29, x30, [sp, #0x20]  | X29 = val_4; X30 = val_5;                //  find_add[1152921515506922640] |  find_add[1152921515506922640]
        // 0x00B2AAD0: LDP x20, x19, [sp, #0x10]  | X20 = val_6; X19 = val_7;                //  find_add[1152921515506922640] |  find_add[1152921515506922640]
        // 0x00B2AAD4: LDP x22, x21, [sp], #0x30  | X22 = val_8; X21 = val_9;                //  find_add[1152921515506922640] |  find_add[1152921515506922640]
        // 0x00B2AAD8: RET                        |  return;                                
        return;
        // 0x00B2AADC: CMP w1, #1                 | 
        // 0x00B2AAE0: B.NE #0xb2ab00             | 
        // 0x00B2AAE4: BL #0x981060               | 
        // 0x00B2AAE8: LDR x21, [x0]              | 
        // 0x00B2AAEC: MOV w22, wzr               | 
        // 0x00B2AAF0: BL #0x980920               | 
        // 0x00B2AAF4: B #0xb2a9ac                | 
        // 0x00B2AAF8: MOV w20, w22               | 
        // 0x00B2AAFC: B #0xb2ab04                | 
        label_21:
        // 0x00B2AB00: MOV w20, wzr               | 
        label_23:
        // 0x00B2AB04: BL #0x981060               | 
        // 0x00B2AB08: LDR x21, [x0]              | 
        // 0x00B2AB0C: BL #0x980920               | 
        // 0x00B2AB10: B #0xb2aa3c                | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2AB14 (11709204), len: 1036  VirtAddr: 0x00B2AB14 RVA: 0x00B2AB14 token: 100696275 methodIndex: 24874 delegateWrapperIndex: 0 methodInvoker: 0
    public void Pay(string payId, string gameObject, string runtimeScriptMethod, string usedPrice, string remained)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        string val_16;
        //  | 
        string val_17;
        //  | 
        string val_18;
        //  | 
        var val_19;
        //  | 
        var val_20;
        //  | 
        var val_21;
        //  | 
        var val_22;
        //  | 
        var val_23;
        // 0x00B2AB14: STP x28, x27, [sp, #-0x60]! | stack[1152921515507083488] = ???;  stack[1152921515507083496] = ???;  //  dest_result_addr=1152921515507083488 |  dest_result_addr=1152921515507083496
        // 0x00B2AB18: STP x26, x25, [sp, #0x10]  | stack[1152921515507083504] = ???;  stack[1152921515507083512] = ???;  //  dest_result_addr=1152921515507083504 |  dest_result_addr=1152921515507083512
        // 0x00B2AB1C: STP x24, x23, [sp, #0x20]  | stack[1152921515507083520] = ???;  stack[1152921515507083528] = ???;  //  dest_result_addr=1152921515507083520 |  dest_result_addr=1152921515507083528
        // 0x00B2AB20: STP x22, x21, [sp, #0x30]  | stack[1152921515507083536] = ???;  stack[1152921515507083544] = ???;  //  dest_result_addr=1152921515507083536 |  dest_result_addr=1152921515507083544
        // 0x00B2AB24: STP x20, x19, [sp, #0x40]  | stack[1152921515507083552] = ???;  stack[1152921515507083560] = ???;  //  dest_result_addr=1152921515507083552 |  dest_result_addr=1152921515507083560
        // 0x00B2AB28: STP x29, x30, [sp, #0x50]  | stack[1152921515507083568] = ???;  stack[1152921515507083576] = ???;  //  dest_result_addr=1152921515507083568 |  dest_result_addr=1152921515507083576
        // 0x00B2AB2C: ADD x29, sp, #0x50         | X29 = (1152921515507083488 + 80) = 1152921515507083568 (0x1000000289B46930);
        // 0x00B2AB30: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B2AB34: LDRB w8, [x19, #0x76b]     | W8 = (bool)static_value_0373376B;       
        // 0x00B2AB38: MOV x21, x5                | X21 = remained;//m1                     
        // 0x00B2AB3C: MOV x23, x4                | X23 = usedPrice;//m1                    
        val_16 = usedPrice;
        // 0x00B2AB40: MOV x25, x3                | X25 = runtimeScriptMethod;//m1          
        val_17 = runtimeScriptMethod;
        // 0x00B2AB44: MOV x26, x2                | X26 = gameObject;//m1                   
        // 0x00B2AB48: MOV x27, x1                | X27 = payId;//m1                        
        val_18 = payId;
        // 0x00B2AB4C: MOV x22, x0                | X22 = 1152921515507095584 (0x1000000289B49820);//ML01
        // 0x00B2AB50: TBNZ w8, #0, #0xb2ab6c     | if (static_value_0373376B == true) goto label_0;
        // 0x00B2AB54: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x00B2AB58: LDR x8, [x8, #0x800]       | X8 = 0x2B8AFE0;                         
        // 0x00B2AB5C: LDR w0, [x8]               | W0 = 0x2B6;                             
        // 0x00B2AB60: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B6, ????);      
        // 0x00B2AB64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2AB68: STRB w8, [x19, #0x76b]     | static_value_0373376B = true;            //  dest_result_addr=57882475
        label_0:
        // 0x00B2AB6C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B2AB70: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B2AB74: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00B2AB78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2AB7C: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B2AB80: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921514474312160)("com.unity3d.player.UnityPlayer");
        // 0x00B2AB84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2AB88: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_19 = val_1;
        // 0x00B2AB8C: LDR x1, [x8]               | X1 = "com.unity3d.player.UnityPlayer";  
        // 0x00B2AB90: BL #0x20b9834              | .ctor(className:  "com.unity3d.player.UnityPlayer");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.unity3d.player.UnityPlayer");
        // 0x00B2AB94: CBNZ x19, #0xb2aba0        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B2AB98: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
        // 0x00B2AB9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "com.unity3d.player.UnityPlayer"), ????);
        label_1:
        // 0x00B2ABA0: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B2ABA4: LDR x8, [x8, #0xb8]        | X8 = (string**)(1152921514474312288)("currentActivity");
        // 0x00B2ABA8: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x00B2ABAC: LDR x9, [x9, #0x458]       | X9 = 1152921514474312400;               
        // 0x00B2ABB0: LDR x1, [x8]               | X1 = "currentActivity";                 
        // 0x00B2ABB4: LDR x2, [x9]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00B2ABB8: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2ABBC: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
        // 0x00B2ABC0: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        // 0x00B2ABC4: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B2ABC8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B2ABCC: LDR x22, [x22, #0x10]      | X22 = this.klass; //P2                  
        // 0x00B2ABD0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B2ABD4: LDR x24, [x8]              | X24 = typeof(System.Object[]);          
        // 0x00B2ABD8: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2ABDC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B2ABE0: ORR w1, wzr, #6            | W1 = 6(0x6);                            
        // 0x00B2ABE4: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2ABE8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B2ABEC: MOV x24, x0                | X24 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2ABF0: CBNZ x24, #0xb2abf8        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00B2ABF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_2:
        // 0x00B2ABF8: CBZ x20, #0xb2ac1c         | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00B2ABFC: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B2AC00: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2AC04: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2AC08: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B2AC0C: CBNZ x0, #0xb2ac1c         | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B2AC10: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00B2AC14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AC18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_4:
        // 0x00B2AC1C: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2AC20: CBNZ w8, #0xb2ac30         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00B2AC24: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00B2AC28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AC2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_5:
        // 0x00B2AC30: STR x20, [x24, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00B2AC34: CBZ x27, #0xb2ac58         | if (payId == null) goto label_7;        
        if(val_18 == null)
        {
            goto label_7;
        }
        // 0x00B2AC38: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B2AC3C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2AC40: MOV x0, x27                | X0 = payId;//m1                         
        // 0x00B2AC44: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? payId, ????);      
        // 0x00B2AC48: CBNZ x0, #0xb2ac58         | if (payId != null) goto label_7;        
        if(val_18 != null)
        {
            goto label_7;
        }
        // 0x00B2AC4C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? payId, ????);      
        // 0x00B2AC50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AC54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? payId, ????);      
        label_7:
        // 0x00B2AC58: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2AC5C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B2AC60: B.HI #0xb2ac70             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_8;
        // 0x00B2AC64: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? payId, ????);      
        // 0x00B2AC68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AC6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? payId, ????);      
        label_8:
        // 0x00B2AC70: STR x27, [x24, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = payId;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_18;
        // 0x00B2AC74: CBZ x26, #0xb2ac98         | if (gameObject == null) goto label_10;  
        if(gameObject == null)
        {
            goto label_10;
        }
        // 0x00B2AC78: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B2AC7C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2AC80: MOV x0, x26                | X0 = gameObject;//m1                    
        // 0x00B2AC84: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? gameObject, ????); 
        // 0x00B2AC88: CBNZ x0, #0xb2ac98         | if (gameObject != null) goto label_10;  
        if(gameObject != null)
        {
            goto label_10;
        }
        // 0x00B2AC8C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? gameObject, ????); 
        // 0x00B2AC90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AC94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? gameObject, ????); 
        label_10:
        // 0x00B2AC98: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2AC9C: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B2ACA0: B.HI #0xb2acb0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_11;
        // 0x00B2ACA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? gameObject, ????); 
        // 0x00B2ACA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2ACAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? gameObject, ????); 
        label_11:
        // 0x00B2ACB0: STR x26, [x24, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = gameObject;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = gameObject;
        // 0x00B2ACB4: CBZ x25, #0xb2acd8         | if (runtimeScriptMethod == null) goto label_13;
        if(val_17 == null)
        {
            goto label_13;
        }
        // 0x00B2ACB8: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B2ACBC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2ACC0: MOV x0, x25                | X0 = runtimeScriptMethod;//m1           
        // 0x00B2ACC4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? runtimeScriptMethod, ????);
        // 0x00B2ACC8: CBNZ x0, #0xb2acd8         | if (runtimeScriptMethod != null) goto label_13;
        if(val_17 != null)
        {
            goto label_13;
        }
        // 0x00B2ACCC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? runtimeScriptMethod, ????);
        // 0x00B2ACD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2ACD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? runtimeScriptMethod, ????);
        label_13:
        // 0x00B2ACD8: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2ACDC: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00B2ACE0: B.HI #0xb2acf0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_14;
        // 0x00B2ACE4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? runtimeScriptMethod, ????);
        // 0x00B2ACE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2ACEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? runtimeScriptMethod, ????);
        label_14:
        // 0x00B2ACF0: STR x25, [x24, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = runtimeScriptMethod;  //  dest_result_addr=1152921504954501320
        typeof(System.Object[]).__il2cppRuntimeField_38 = val_17;
        // 0x00B2ACF4: CBZ x23, #0xb2ad18         | if (usedPrice == null) goto label_16;   
        if(val_16 == null)
        {
            goto label_16;
        }
        // 0x00B2ACF8: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B2ACFC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2AD00: MOV x0, x23                | X0 = usedPrice;//m1                     
        // 0x00B2AD04: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? usedPrice, ????);  
        // 0x00B2AD08: CBNZ x0, #0xb2ad18         | if (usedPrice != null) goto label_16;   
        if(val_16 != null)
        {
            goto label_16;
        }
        // 0x00B2AD0C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? usedPrice, ????);  
        // 0x00B2AD10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AD14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? usedPrice, ????);  
        label_16:
        // 0x00B2AD18: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2AD1C: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x00B2AD20: B.HI #0xb2ad30             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_17;
        // 0x00B2AD24: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? usedPrice, ????);  
        // 0x00B2AD28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AD2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? usedPrice, ????);  
        label_17:
        // 0x00B2AD30: STR x23, [x24, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = usedPrice;  //  dest_result_addr=1152921504954501328
        typeof(System.Object[]).__il2cppRuntimeField_40 = val_16;
        // 0x00B2AD34: CBZ x21, #0xb2ad58         | if (remained == null) goto label_19;    
        if(remained == null)
        {
            goto label_19;
        }
        // 0x00B2AD38: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B2AD3C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2AD40: MOV x0, x21                | X0 = remained;//m1                      
        // 0x00B2AD44: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? remained, ????);   
        // 0x00B2AD48: CBNZ x0, #0xb2ad58         | if (remained != null) goto label_19;    
        if(remained != null)
        {
            goto label_19;
        }
        // 0x00B2AD4C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? remained, ????);   
        // 0x00B2AD50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AD54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? remained, ????);   
        label_19:
        // 0x00B2AD58: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2AD5C: CMP w8, #5                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x5)
        // 0x00B2AD60: B.HI #0xb2ad70             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x5) goto label_20;
        // 0x00B2AD64: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? remained, ????);   
        // 0x00B2AD68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AD6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? remained, ????);   
        label_20:
        // 0x00B2AD70: STR x21, [x24, #0x48]      | typeof(System.Object[]).__il2cppRuntimeField_48 = remained;  //  dest_result_addr=1152921504954501336
        typeof(System.Object[]).__il2cppRuntimeField_48 = remained;
        // 0x00B2AD74: CBNZ x22, #0xb2ad7c        | if (this.klass != null) goto label_21;  
        if(this.klass != null)
        {
            goto label_21;
        }
        // 0x00B2AD78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? remained, ????);   
        label_21:
        // 0x00B2AD7C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00B2AD80: LDR x8, [x8, #0xc0]        | X8 = (string**)(1152921515507071504)("pay");
        // 0x00B2AD84: LDR x1, [x8]               | X1 = "pay";                             
        // 0x00B2AD88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B2AD8C: MOV x0, x22                | X0 = this.klass;//m1                    
        // 0x00B2AD90: MOV x2, x24                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2AD94: BL #0x20bdcfc              | this.klass.CallStatic(methodName:  "pay", args:  null);
        this.klass.CallStatic(methodName:  "pay", args:  null);
        // 0x00B2AD98: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_20 = 0;
        // 0x00B2AD9C: MOVZ w24, #0x59            | W24 = 89 (0x59);//ML01                  
        label_37:
        // 0x00B2ADA0: CBZ x20, #0xb2ae0c         | if (val_2 == null) goto label_22;       
        if(val_2 == null)
        {
            goto label_22;
        }
        // 0x00B2ADA4: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2ADA8: LDR x8, [x20]              | X8 = typeof(UnityEngine.AndroidJavaObject);
        // 0x00B2ADAC: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2ADB0: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2ADB4: LDRH w9, [x8, #0x102]      | W9 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B2ADB8: CBZ x9, #0xb2ade4          | if (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count == 0) goto label_23;
        // 0x00B2ADBC: LDR x10, [x8, #0x98]       | X10 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B2ADC0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_16 = 0;
        // 0x00B2ADC4: ADD x10, x10, #8           | X10 = (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504690216968 (0x1000000004F82008);
        label_25:
        // 0x00B2ADC8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B2ADCC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B2ADD0: B.EQ #0xb2adf4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_24;
        // 0x00B2ADD4: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_16 = val_16 + 1;
        // 0x00B2ADD8: ADD x10, x10, #0x10        | X10 = (1152921504690216968 + 16) = 1152921504690216984 (0x1000000004F82018);
        // 0x00B2ADDC: CMP x11, x9                | STATE = COMPARE((0 + 1), UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B2ADE0: B.LO #0xb2adc8             | if (0 < UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count) goto label_25;
        label_23:
        // 0x00B2ADE4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2ADE8: MOV x0, x20                | X0 = val_2;//m1                         
        val_21 = val_2;
        // 0x00B2ADEC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B2ADF0: B #0xb2ae00                |  goto label_26;                         
        goto label_26;
        label_24:
        // 0x00B2ADF4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B2ADF8: ADD x8, x8, x9, lsl #4     | X8 = (1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B2ADFC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_26:
        // 0x00B2AE00: LDP x8, x1, [x0]           | X8 = typeof(UnityEngine.AndroidJavaClass);  //  | 
        // 0x00B2AE04: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2AE08: BLR x8                     | X0 = sub_1000000004F86000( ?? val_2, ????);
        label_22:
        // 0x00B2AE0C: MOVZ w20, #0x6b            | W20 = 107 (0x6B);//ML01                 
        val_22 = 107;
        // 0x00B2AE10: CMP w24, #0x59             | STATE = COMPARE(0x59, 0x59)             
        // 0x00B2AE14: B.EQ #0xb2ae30             | if (0x59 == 0x59) goto label_39;        
        if(89 == 89)
        {
            goto label_39;
        }
        // 0x00B2AE18: CBZ x21, #0xb2ae30         | if (0x0 == 0) goto label_39;            
        if(val_20 == 0)
        {
            goto label_39;
        }
        // 0x00B2AE1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AE20: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B2AE24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B2AE28: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_20 = 0;
        // 0x00B2AE2C: MOVZ w20, #0x6b            | W20 = 107 (0x6B);//ML01                 
        val_22 = 107;
        label_39:
        // 0x00B2AE30: CBZ x19, #0xb2ae9c         | if ( == 0) goto label_29;               
        if(null == 0)
        {
            goto label_29;
        }
        // 0x00B2AE34: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2AE38: LDR x8, [x19]              | X8 = ;                                  
        UnityEngine.AndroidJavaClass val_19 = null;
        // 0x00B2AE3C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2AE40: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2AE44: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00B2AE48: CBZ x9, #0xb2ae74          | if (mem[null + 258] == 0) goto label_30;
        if((mem[null + 258]) == 0)
        {
            goto label_30;
        }
        // 0x00B2AE4C: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_17 = mem[null + 152];
        // 0x00B2AE50: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_18 = 0;
        // 0x00B2AE54: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_17 = val_17 + 8;
        label_32:
        // 0x00B2AE58: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00B2AE5C: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00B2AE60: B.EQ #0xb2ae84             | if ((mem[null + 152] + 8) + -8 == null) goto label_31;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_31;
        }
        // 0x00B2AE64: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_18 = val_18 + 1;
        // 0x00B2AE68: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_17 = val_17 + 16;
        // 0x00B2AE6C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00B2AE70: B.LO #0xb2ae58             | if (0 < mem[null + 258]) goto label_32; 
        if(val_18 < (mem[null + 258]))
        {
            goto label_32;
        }
        label_30:
        // 0x00B2AE74: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2AE78: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_23 = val_19;
        // 0x00B2AE7C: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2AE80: B #0xb2ae90                |  goto label_33;                         
        goto label_33;
        label_31:
        // 0x00B2AE84: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00B2AE88: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_19 = val_19 + (((mem[null + 152] + 8)) << 4);
        // 0x00B2AE8C: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_33:
        // 0x00B2AE90: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
        // 0x00B2AE94: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2AE98: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        label_29:
        // 0x00B2AE9C: CMP w20, #0x6b             | STATE = COMPARE(0x6B, 0x6B)             
        // 0x00B2AEA0: B.EQ #0xb2aecc             | if (0x6B == 0x6B) goto label_35;        
        if(107 == 107)
        {
            goto label_35;
        }
        // 0x00B2AEA4: CBZ x21, #0xb2aecc         | if (0x0 == 0) goto label_35;            
        if(val_20 == 0)
        {
            goto label_35;
        }
        // 0x00B2AEA8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B2AEAC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2AEB0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        val_19 = ???;
        // 0x00B2AEB4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        val_20 = ???;
        // 0x00B2AEB8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        val_16 = ???;
        // 0x00B2AEBC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        val_17 = ???;
        // 0x00B2AEC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2AEC4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        val_18 = ???;
        // 0x00B2AEC8: B #0x27ae3bc               | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_35:
        // 0x00B2AECC: LDP x29, x30, [sp, #0x50]  | X29 = val_4; X30 = val_5;                //  find_add[1152921515507071584] |  find_add[1152921515507071584]
        // 0x00B2AED0: LDP x20, x19, [sp, #0x40]  | X20 = val_6; X19 = val_7;                //  find_add[1152921515507071584] |  find_add[1152921515507071584]
        // 0x00B2AED4: LDP x22, x21, [sp, #0x30]  | X22 = val_8; X21 = val_9;                //  find_add[1152921515507071584] |  find_add[1152921515507071584]
        // 0x00B2AED8: LDP x24, x23, [sp, #0x20]  | X24 = val_10; X23 = val_11;              //  find_add[1152921515507071584] |  find_add[1152921515507071584]
        // 0x00B2AEDC: LDP x26, x25, [sp, #0x10]  | X26 = val_12; X25 = val_13;              //  find_add[1152921515507071584] |  find_add[1152921515507071584]
        // 0x00B2AEE0: LDP x28, x27, [sp], #0x60  | X28 = val_14; X27 = val_15;              //  find_add[1152921515507071584] |  find_add[1152921515507071584]
        // 0x00B2AEE4: RET                        |  return;                                
        return;
        // 0x00B2AEE8: CMP w1, #1                 | 
        // 0x00B2AEEC: B.NE #0xb2af0c             | 
        // 0x00B2AEF0: BL #0x981060               | 
        // 0x00B2AEF4: LDR x21, [x0]              | 
        // 0x00B2AEF8: MOV w24, wzr               | 
        // 0x00B2AEFC: BL #0x980920               | 
        // 0x00B2AF00: B #0xb2ada0                | 
        // 0x00B2AF04: MOV w20, w24               | 
        // 0x00B2AF08: B #0xb2af10                | 
        label_36:
        // 0x00B2AF0C: MOV w20, wzr               | 
        label_38:
        // 0x00B2AF10: BL #0x981060               | 
        // 0x00B2AF14: LDR x21, [x0]              | 
        // 0x00B2AF18: BL #0x980920               | 
        // 0x00B2AF1C: B #0xb2ae30                | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2AF20 (11710240), len: 660  VirtAddr: 0x00B2AF20 RVA: 0x00B2AF20 token: 100696276 methodIndex: 24875 delegateWrapperIndex: 0 methodInvoker: 0
    public void Exit()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        // 0x00B2AF20: STP x22, x21, [sp, #-0x30]! | stack[1152921515507232480] = ???;  stack[1152921515507232488] = ???;  //  dest_result_addr=1152921515507232480 |  dest_result_addr=1152921515507232488
        // 0x00B2AF24: STP x20, x19, [sp, #0x10]  | stack[1152921515507232496] = ???;  stack[1152921515507232504] = ???;  //  dest_result_addr=1152921515507232496 |  dest_result_addr=1152921515507232504
        // 0x00B2AF28: STP x29, x30, [sp, #0x20]  | stack[1152921515507232512] = ???;  stack[1152921515507232520] = ???;  //  dest_result_addr=1152921515507232512 |  dest_result_addr=1152921515507232520
        // 0x00B2AF2C: ADD x29, sp, #0x20         | X29 = (1152921515507232480 + 32) = 1152921515507232512 (0x1000000289B6AF00);
        // 0x00B2AF30: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B2AF34: LDRB w8, [x19, #0x76c]     | W8 = (bool)static_value_0373376C;       
        // 0x00B2AF38: MOV x21, x0                | X21 = 1152921515507244528 (0x1000000289B6DDF0);//ML01
        // 0x00B2AF3C: TBNZ w8, #0, #0xb2af58     | if (static_value_0373376C == true) goto label_0;
        // 0x00B2AF40: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
        // 0x00B2AF44: LDR x8, [x8, #0xd68]       | X8 = 0x2B8AFC8;                         
        // 0x00B2AF48: LDR w0, [x8]               | W0 = 0x2B0;                             
        // 0x00B2AF4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B0, ????);      
        // 0x00B2AF50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2AF54: STRB w8, [x19, #0x76c]     | static_value_0373376C = true;            //  dest_result_addr=57882476
        label_0:
        // 0x00B2AF58: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B2AF5C: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B2AF60: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00B2AF64: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2AF68: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B2AF6C: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921514474312160)("com.unity3d.player.UnityPlayer");
        // 0x00B2AF70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2AF74: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_10 = val_1;
        // 0x00B2AF78: LDR x1, [x8]               | X1 = "com.unity3d.player.UnityPlayer";  
        // 0x00B2AF7C: BL #0x20b9834              | .ctor(className:  "com.unity3d.player.UnityPlayer");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.unity3d.player.UnityPlayer");
        // 0x00B2AF80: CBNZ x19, #0xb2af8c        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B2AF84: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        // 0x00B2AF88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "com.unity3d.player.UnityPlayer"), ????);
        label_1:
        // 0x00B2AF8C: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B2AF90: LDR x8, [x8, #0xb8]        | X8 = (string**)(1152921514474312288)("currentActivity");
        // 0x00B2AF94: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x00B2AF98: LDR x9, [x9, #0x458]       | X9 = 1152921514474312400;               
        // 0x00B2AF9C: LDR x1, [x8]               | X1 = "currentActivity";                 
        // 0x00B2AFA0: LDR x2, [x9]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00B2AFA4: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2AFA8: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        // 0x00B2AFAC: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        // 0x00B2AFB0: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B2AFB4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B2AFB8: LDR x21, [x21, #0x10]      | X21 = this.klass; //P2                  
        // 0x00B2AFBC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B2AFC0: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
        // 0x00B2AFC4: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2AFC8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B2AFCC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B2AFD0: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2AFD4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B2AFD8: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2AFDC: CBNZ x22, #0xb2afe4        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00B2AFE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_2:
        // 0x00B2AFE4: CBZ x20, #0xb2b008         | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00B2AFE8: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B2AFEC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2AFF0: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2AFF4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B2AFF8: CBNZ x0, #0xb2b008         | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B2AFFC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00B2B000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B004: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_4:
        // 0x00B2B008: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2B00C: CBNZ w8, #0xb2b01c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00B2B010: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00B2B014: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B018: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_5:
        // 0x00B2B01C: STR x20, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00B2B020: CBNZ x21, #0xb2b028        | if (this.klass != null) goto label_6;   
        if(this.klass != null)
        {
            goto label_6;
        }
        // 0x00B2B024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B2B028: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
        // 0x00B2B02C: LDR x8, [x8, #0xb70]       | X8 = (string**)(1152921515507220448)("onExit");
        // 0x00B2B030: LDR x1, [x8]               | X1 = "onExit";                          
        // 0x00B2B034: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B2B038: MOV x0, x21                | X0 = this.klass;//m1                    
        // 0x00B2B03C: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B040: BL #0x20bdcfc              | this.klass.CallStatic(methodName:  "onExit", args:  null);
        this.klass.CallStatic(methodName:  "onExit", args:  null);
        // 0x00B2B044: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_11 = 0;
        // 0x00B2B048: MOVZ w22, #0x43            | W22 = 67 (0x43);//ML01                  
        label_22:
        // 0x00B2B04C: CBZ x20, #0xb2b0b8         | if (val_2 == null) goto label_7;        
        if(val_2 == null)
        {
            goto label_7;
        }
        // 0x00B2B050: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2B054: LDR x8, [x20]              | X8 = typeof(UnityEngine.AndroidJavaObject);
        // 0x00B2B058: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2B05C: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2B060: LDRH w9, [x8, #0x102]      | W9 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B2B064: CBZ x9, #0xb2b090          | if (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count == 0) goto label_8;
        // 0x00B2B068: LDR x10, [x8, #0x98]       | X10 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B2B06C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_10 = 0;
        // 0x00B2B070: ADD x10, x10, #8           | X10 = (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504690216968 (0x1000000004F82008);
        label_10:
        // 0x00B2B074: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B2B078: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B2B07C: B.EQ #0xb2b0a0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_9;
        // 0x00B2B080: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_10 = val_10 + 1;
        // 0x00B2B084: ADD x10, x10, #0x10        | X10 = (1152921504690216968 + 16) = 1152921504690216984 (0x1000000004F82018);
        // 0x00B2B088: CMP x11, x9                | STATE = COMPARE((0 + 1), UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B2B08C: B.LO #0xb2b074             | if (0 < UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count) goto label_10;
        label_8:
        // 0x00B2B090: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2B094: MOV x0, x20                | X0 = val_2;//m1                         
        val_12 = val_2;
        // 0x00B2B098: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B2B09C: B #0xb2b0ac                |  goto label_11;                         
        goto label_11;
        label_9:
        // 0x00B2B0A0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B2B0A4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B2B0A8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_11:
        // 0x00B2B0AC: LDP x8, x1, [x0]           | X8 = typeof(UnityEngine.AndroidJavaClass);  //  | 
        // 0x00B2B0B0: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2B0B4: BLR x8                     | X0 = sub_1000000004F86000( ?? val_2, ????);
        label_7:
        // 0x00B2B0B8: MOVZ w20, #0x55            | W20 = 85 (0x55);//ML01                  
        val_13 = 85;
        // 0x00B2B0BC: CMP w22, #0x43             | STATE = COMPARE(0x43, 0x43)             
        // 0x00B2B0C0: B.EQ #0xb2b0dc             | if (0x43 == 0x43) goto label_24;        
        if(67 == 67)
        {
            goto label_24;
        }
        // 0x00B2B0C4: CBZ x21, #0xb2b0dc         | if (0x0 == 0) goto label_24;            
        if(val_11 == 0)
        {
            goto label_24;
        }
        // 0x00B2B0C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B0CC: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B2B0D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B2B0D4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_11 = 0;
        // 0x00B2B0D8: MOVZ w20, #0x55            | W20 = 85 (0x55);//ML01                  
        val_13 = 85;
        label_24:
        // 0x00B2B0DC: CBZ x19, #0xb2b148         | if ( == 0) goto label_14;               
        if(null == 0)
        {
            goto label_14;
        }
        // 0x00B2B0E0: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2B0E4: LDR x8, [x19]              | X8 = ;                                  
        UnityEngine.AndroidJavaClass val_13 = null;
        // 0x00B2B0E8: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2B0EC: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2B0F0: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00B2B0F4: CBZ x9, #0xb2b120          | if (mem[null + 258] == 0) goto label_15;
        if((mem[null + 258]) == 0)
        {
            goto label_15;
        }
        // 0x00B2B0F8: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_11 = mem[null + 152];
        // 0x00B2B0FC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_12 = 0;
        // 0x00B2B100: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_11 = val_11 + 8;
        label_17:
        // 0x00B2B104: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00B2B108: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00B2B10C: B.EQ #0xb2b130             | if ((mem[null + 152] + 8) + -8 == null) goto label_16;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_16;
        }
        // 0x00B2B110: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x00B2B114: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_11 = val_11 + 16;
        // 0x00B2B118: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00B2B11C: B.LO #0xb2b104             | if (0 < mem[null + 258]) goto label_17; 
        if(val_12 < (mem[null + 258]))
        {
            goto label_17;
        }
        label_15:
        // 0x00B2B120: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2B124: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_14 = val_10;
        // 0x00B2B128: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2B12C: B #0xb2b13c                |  goto label_18;                         
        goto label_18;
        label_16:
        // 0x00B2B130: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00B2B134: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_13 = val_13 + (((mem[null + 152] + 8)) << 4);
        // 0x00B2B138: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_18:
        // 0x00B2B13C: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
        // 0x00B2B140: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2B144: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        label_14:
        // 0x00B2B148: CMP w20, #0x55             | STATE = COMPARE(0x55, 0x55)             
        // 0x00B2B14C: B.EQ #0xb2b16c             | if (0x55 == 0x55) goto label_20;        
        if(85 == 85)
        {
            goto label_20;
        }
        // 0x00B2B150: CBZ x21, #0xb2b16c         | if (0x0 == 0) goto label_20;            
        if(val_11 == 0)
        {
            goto label_20;
        }
        // 0x00B2B154: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2B158: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        val_10 = ???;
        // 0x00B2B15C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B160: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B2B164: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        val_11 = ???;
        // 0x00B2B168: B #0x27ae3bc               | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_20:
        // 0x00B2B16C: LDP x29, x30, [sp, #0x20]  | X29 = val_4; X30 = val_5;                //  find_add[1152921515507220528] |  find_add[1152921515507220528]
        // 0x00B2B170: LDP x20, x19, [sp, #0x10]  | X20 = val_6; X19 = val_7;                //  find_add[1152921515507220528] |  find_add[1152921515507220528]
        // 0x00B2B174: LDP x22, x21, [sp], #0x30  | X22 = val_8; X21 = val_9;                //  find_add[1152921515507220528] |  find_add[1152921515507220528]
        // 0x00B2B178: RET                        |  return;                                
        return;
        // 0x00B2B17C: CMP w1, #1                 | 
        // 0x00B2B180: B.NE #0xb2b1a0             | 
        // 0x00B2B184: BL #0x981060               | 
        // 0x00B2B188: LDR x21, [x0]              | 
        // 0x00B2B18C: MOV w22, wzr               | 
        // 0x00B2B190: BL #0x980920               | 
        // 0x00B2B194: B #0xb2b04c                | 
        // 0x00B2B198: MOV w20, w22               | 
        // 0x00B2B19C: B #0xb2b1a4                | 
        label_21:
        // 0x00B2B1A0: MOV w20, wzr               | 
        label_23:
        // 0x00B2B1A4: BL #0x981060               | 
        // 0x00B2B1A8: LDR x21, [x0]              | 
        // 0x00B2B1AC: BL #0x980920               | 
        // 0x00B2B1B0: B #0xb2b0dc                | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2B1B4 (11710900), len: 768  VirtAddr: 0x00B2B1B4 RVA: 0x00B2B1B4 token: 100696277 methodIndex: 24876 delegateWrapperIndex: 0 methodInvoker: 0
    public bool isPaid(string id)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        // 0x00B2B1B4: STP x24, x23, [sp, #-0x40]! | stack[1152921515507366048] = ???;  stack[1152921515507366056] = ???;  //  dest_result_addr=1152921515507366048 |  dest_result_addr=1152921515507366056
        // 0x00B2B1B8: STP x22, x21, [sp, #0x10]  | stack[1152921515507366064] = ???;  stack[1152921515507366072] = ???;  //  dest_result_addr=1152921515507366064 |  dest_result_addr=1152921515507366072
        // 0x00B2B1BC: STP x20, x19, [sp, #0x20]  | stack[1152921515507366080] = ???;  stack[1152921515507366088] = ???;  //  dest_result_addr=1152921515507366080 |  dest_result_addr=1152921515507366088
        // 0x00B2B1C0: STP x29, x30, [sp, #0x30]  | stack[1152921515507366096] = ???;  stack[1152921515507366104] = ???;  //  dest_result_addr=1152921515507366096 |  dest_result_addr=1152921515507366104
        // 0x00B2B1C4: ADD x29, sp, #0x30         | X29 = (1152921515507366048 + 48) = 1152921515507366096 (0x1000000289B8B8D0);
        // 0x00B2B1C8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B2B1CC: LDRB w8, [x19, #0x76d]     | W8 = (bool)static_value_0373376D;       
        // 0x00B2B1D0: MOV x22, x1                | X22 = id;//m1                           
        // 0x00B2B1D4: MOV x23, x0                | X23 = 1152921515507378112 (0x1000000289B8E7C0);//ML01
        // 0x00B2B1D8: TBNZ w8, #0, #0xb2b1f4     | if (static_value_0373376D == true) goto label_0;
        // 0x00B2B1DC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B2B1E0: LDR x8, [x8, #0x718]       | X8 = 0x2B8AFDC;                         
        // 0x00B2B1E4: LDR w0, [x8]               | W0 = 0x2B5;                             
        // 0x00B2B1E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B5, ????);      
        // 0x00B2B1EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2B1F0: STRB w8, [x19, #0x76d]     | static_value_0373376D = true;            //  dest_result_addr=57882477
        label_0:
        // 0x00B2B1F4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B2B1F8: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B2B1FC: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00B2B200: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2B204: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B2B208: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921514474312160)("com.unity3d.player.UnityPlayer");
        // 0x00B2B20C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2B210: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2B214: LDR x1, [x8]               | X1 = "com.unity3d.player.UnityPlayer";  
        // 0x00B2B218: BL #0x20b9834              | .ctor(className:  "com.unity3d.player.UnityPlayer");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.unity3d.player.UnityPlayer");
        // 0x00B2B21C: CBNZ x19, #0xb2b22c        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B2B220: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
        // 0x00B2B224: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        // 0x00B2B228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "com.unity3d.player.UnityPlayer"), ????);
        label_1:
        // 0x00B2B22C: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B2B230: LDR x8, [x8, #0xb8]        | X8 = (string**)(1152921514474312288)("currentActivity");
        // 0x00B2B234: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x00B2B238: LDR x9, [x9, #0x458]       | X9 = 1152921514474312400;               
        // 0x00B2B23C: LDR x1, [x8]               | X1 = "currentActivity";                 
        // 0x00B2B240: LDR x2, [x9]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00B2B244: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2B248: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
        // 0x00B2B24C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        // 0x00B2B250: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        // 0x00B2B254: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B2B258: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B2B25C: LDR x21, [x23, #0x10]      | X21 = this.klass; //P2                  
        // 0x00B2B260: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B2B264: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
        // 0x00B2B268: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B26C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B2B270: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B2B274: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B278: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B2B27C: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        System.Object[] val_7 = null;
        // 0x00B2B280: CBNZ x23, #0xb2b288        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00B2B284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_2:
        // 0x00B2B288: CBZ x20, #0xb2b2ac         | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00B2B28C: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B2B290: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2B294: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2B298: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B2B29C: CBNZ x0, #0xb2b2ac         | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B2B2A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00B2B2A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B2A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_4:
        // 0x00B2B2AC: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2B2B0: CBNZ w8, #0xb2b2c0         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00B2B2B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00B2B2B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B2BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_5:
        // 0x00B2B2C0: STR x20, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00B2B2C4: CBZ x22, #0xb2b2e8         | if (id == null) goto label_7;           
        if(id == null)
        {
            goto label_7;
        }
        // 0x00B2B2C8: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B2B2CC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2B2D0: MOV x0, x22                | X0 = id;//m1                            
        // 0x00B2B2D4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? id, ????);         
        // 0x00B2B2D8: CBNZ x0, #0xb2b2e8         | if (id != null) goto label_7;           
        if(id != null)
        {
            goto label_7;
        }
        // 0x00B2B2DC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? id, ????);         
        // 0x00B2B2E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B2E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? id, ????);         
        label_7:
        // 0x00B2B2E8: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2B2EC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B2B2F0: B.HI #0xb2b300             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_8;
        // 0x00B2B2F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? id, ????);         
        // 0x00B2B2F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B2FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? id, ????);         
        label_8:
        // 0x00B2B300: STR x22, [x23, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = id;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = id;
        // 0x00B2B304: CBNZ x21, #0xb2b30c        | if (this.klass != null) goto label_9;   
        if(this.klass != null)
        {
            goto label_9;
        }
        // 0x00B2B308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? id, ????);         
        label_9:
        // 0x00B2B30C: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B2B310: LDR x8, [x8, #0x700]       | X8 = (string**)(1152921515507353008)("isPaid");
        // 0x00B2B314: ADRP x9, #0x3612000        | X9 = 56696832 (0x3612000);              
        // 0x00B2B318: LDR x9, [x9, #0x8a0]       | X9 = 1152921515507353088;               
        // 0x00B2B31C: LDR x1, [x8]               | X1 = "isPaid";                          
        // 0x00B2B320: LDR x3, [x9]               | X3 = public System.Boolean UnityEngine.AndroidJavaObject::CallStatic<System.Boolean>(string methodName, object[] args);
        // 0x00B2B324: MOV x0, x21                | X0 = this.klass;//m1                    
        // 0x00B2B328: MOV x2, x23                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B32C: BL #0x12f5f14              | X0 = this.klass.CallStatic<System.Boolean>(methodName:  "isPaid", args:  null);
        bool val_3 = this.klass.CallStatic<System.Boolean>(methodName:  "isPaid", args:  val_7);
        // 0x00B2B330: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_7 = 0;
        // 0x00B2B334: AND w23, w0, #1            | W23 = (val_3 & 1);                      
        val_7 = val_3;
        // 0x00B2B338: MOVZ w24, #0x55            | W24 = 85 (0x55);//ML01                  
        label_25:
        // 0x00B2B33C: CBZ x20, #0xb2b3b0         | if (val_2 == null) goto label_10;       
        if(val_2 == null)
        {
            goto label_10;
        }
        // 0x00B2B340: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2B344: LDR x8, [x20]              | X8 = typeof(UnityEngine.AndroidJavaObject);
        // 0x00B2B348: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2B34C: CMP w23, #0                | STATE = COMPARE((val_3 & 1), 0x0)       
        // 0x00B2B350: CSET w21, ne               | W21 = null == true ? 1 : 0;             
        var val_4 = (val_7 == true) ? 1 : 0;
        // 0x00B2B354: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2B358: LDRH w9, [x8, #0x102]      | W9 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B2B35C: CBZ x9, #0xb2b388          | if (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count == 0) goto label_11;
        // 0x00B2B360: LDR x10, [x8, #0x98]       | X10 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B2B364: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_8 = 0;
        // 0x00B2B368: ADD x10, x10, #8           | X10 = (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504690216968 (0x1000000004F82008);
        label_13:
        // 0x00B2B36C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B2B370: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B2B374: B.EQ #0xb2b398             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_12;
        // 0x00B2B378: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_8 = val_8 + 1;
        // 0x00B2B37C: ADD x10, x10, #0x10        | X10 = (1152921504690216968 + 16) = 1152921504690216984 (0x1000000004F82018);
        // 0x00B2B380: CMP x11, x9                | STATE = COMPARE((0 + 1), UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B2B384: B.LO #0xb2b36c             | if (0 < UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count) goto label_13;
        label_11:
        // 0x00B2B388: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2B38C: MOV x0, x20                | X0 = val_2;//m1                         
        val_8 = val_2;
        // 0x00B2B390: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B2B394: B #0xb2b3a4                |  goto label_14;                         
        goto label_14;
        label_12:
        // 0x00B2B398: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B2B39C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B2B3A0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_14:
        // 0x00B2B3A4: LDP x8, x1, [x0]           | X8 = val_3; X1 = val_3 + 8;              //  | 
        // 0x00B2B3A8: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2B3AC: BLR x8                     | X0 = val_3();                           
        label_10:
        // 0x00B2B3B0: CMP w23, #0                | STATE = COMPARE((val_3 & 1), 0x0)       
        // 0x00B2B3B4: CSET w21, ne               | W21 = null == true ? 1 : 0;             
        var val_6 = (val_7 == true) ? 1 : 0;
        // 0x00B2B3B8: CMP w24, #0x55             | STATE = COMPARE(0x55, 0x55)             
        // 0x00B2B3BC: B.EQ #0xb2b3d4             | if (0x55 == 0x55) goto label_27;        
        if(85 == 85)
        {
            goto label_27;
        }
        // 0x00B2B3C0: CBZ x22, #0xb2b3d4         | if (0x0 == 0) goto label_27;            
        if(val_7 == 0)
        {
            goto label_27;
        }
        // 0x00B2B3C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B3C8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
        // 0x00B2B3CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B2B3D0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_7 = 0;
        label_27:
        // 0x00B2B3D4: CBZ x19, #0xb2b440         | if ( == 0) goto label_17;               
        if(null == 0)
        {
            goto label_17;
        }
        // 0x00B2B3D8: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2B3DC: LDR x8, [x19]              | X8 = ;                                  
        UnityEngine.AndroidJavaClass val_11 = null;
        // 0x00B2B3E0: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2B3E4: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2B3E8: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00B2B3EC: CBZ x9, #0xb2b418          | if (mem[null + 258] == 0) goto label_18;
        if((mem[null + 258]) == 0)
        {
            goto label_18;
        }
        // 0x00B2B3F0: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_9 = mem[null + 152];
        // 0x00B2B3F4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_10 = 0;
        // 0x00B2B3F8: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_9 = val_9 + 8;
        label_20:
        // 0x00B2B3FC: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00B2B400: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00B2B404: B.EQ #0xb2b428             | if ((mem[null + 152] + 8) + -8 == null) goto label_19;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_19;
        }
        // 0x00B2B408: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_10 = val_10 + 1;
        // 0x00B2B40C: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_9 = val_9 + 16;
        // 0x00B2B410: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00B2B414: B.LO #0xb2b3fc             | if (0 < mem[null + 258]) goto label_20; 
        if(val_10 < (mem[null + 258]))
        {
            goto label_20;
        }
        label_18:
        // 0x00B2B418: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2B41C: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_9 = val_1;
        // 0x00B2B420: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2B424: B #0xb2b434                |  goto label_21;                         
        goto label_21;
        label_19:
        // 0x00B2B428: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00B2B42C: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_11 = val_11 + (((mem[null + 152] + 8)) << 4);
        // 0x00B2B430: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_21:
        // 0x00B2B434: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
        // 0x00B2B438: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2B43C: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        label_17:
        // 0x00B2B440: CMP w24, #0x55             | STATE = COMPARE(0x55, 0x55)             
        // 0x00B2B444: B.EQ #0xb2b458             | if (0x55 == 0x55) goto label_23;        
        if(85 == 85)
        {
            goto label_23;
        }
        // 0x00B2B448: CBZ x22, #0xb2b458         | if (0x0 == 0) goto label_23;            
        if(val_7 == 0)
        {
            goto label_23;
        }
        // 0x00B2B44C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B450: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
        // 0x00B2B454: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_23:
        // 0x00B2B458: MOV w0, w21                | W0 = null == true ? 1 : 0;//m1          
        // 0x00B2B45C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2B460: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2B464: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2B468: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B2B46C: RET                        |  return (System.Boolean)null == true ? 1 : 0;
        return (bool)val_6;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        // 0x00B2B470: CMP w1, #1                 | 
        // 0x00B2B474: B.NE #0xb2b498             | 
        // 0x00B2B478: BL #0x981060               | 
        // 0x00B2B47C: LDR x22, [x0]              | 
        // 0x00B2B480: MOV w24, wzr               | 
        // 0x00B2B484: MOV w21, wzr               | 
        // 0x00B2B488: BL #0x980920               | 
        // 0x00B2B48C: MOV w24, wzr               | 
        // 0x00B2B490: MOV w23, wzr               | 
        // 0x00B2B494: B #0xb2b33c                | 
        label_24:
        // 0x00B2B498: MOV w24, wzr               | 
        // 0x00B2B49C: MOV w21, wzr               | 
        // 0x00B2B4A0: B #0xb2b4a4                | 
        label_26:
        // 0x00B2B4A4: BL #0x981060               | 
        // 0x00B2B4A8: LDR x22, [x0]              | 
        // 0x00B2B4AC: BL #0x980920               | 
        // 0x00B2B4B0: B #0xb2b3d4                | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2B4B4 (11711668), len: 832  VirtAddr: 0x00B2B4B4 RVA: 0x00B2B4B4 token: 100696278 methodIndex: 24877 delegateWrapperIndex: 0 methodInvoker: 0
    public void setPaid(string id, bool paid)
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        // 0x00B2B4B4: STP x24, x23, [sp, #-0x40]! | stack[1152921515507506816] = ???;  stack[1152921515507506824] = ???;  //  dest_result_addr=1152921515507506816 |  dest_result_addr=1152921515507506824
        // 0x00B2B4B8: STP x22, x21, [sp, #0x10]  | stack[1152921515507506832] = ???;  stack[1152921515507506840] = ???;  //  dest_result_addr=1152921515507506832 |  dest_result_addr=1152921515507506840
        // 0x00B2B4BC: STP x20, x19, [sp, #0x20]  | stack[1152921515507506848] = ???;  stack[1152921515507506856] = ???;  //  dest_result_addr=1152921515507506848 |  dest_result_addr=1152921515507506856
        // 0x00B2B4C0: STP x29, x30, [sp, #0x30]  | stack[1152921515507506864] = ???;  stack[1152921515507506872] = ???;  //  dest_result_addr=1152921515507506864 |  dest_result_addr=1152921515507506872
        // 0x00B2B4C4: ADD x29, sp, #0x30         | X29 = (1152921515507506816 + 48) = 1152921515507506864 (0x1000000289BADEB0);
        // 0x00B2B4C8: SUB sp, sp, #0x10          | SP = (1152921515507506816 - 16) = 1152921515507506800 (0x1000000289BADE70);
        // 0x00B2B4CC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B2B4D0: LDRB w8, [x19, #0x76e]     | W8 = (bool)static_value_0373376E;       
        // 0x00B2B4D4: MOV w23, w2                | W23 = paid;//m1                         
        // 0x00B2B4D8: MOV x24, x1                | X24 = id;//m1                           
        // 0x00B2B4DC: MOV x21, x0                | X21 = 1152921515507518880 (0x1000000289BB0DA0);//ML01
        // 0x00B2B4E0: TBNZ w8, #0, #0xb2b4fc     | if (static_value_0373376E == true) goto label_0;
        // 0x00B2B4E4: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
        // 0x00B2B4E8: LDR x8, [x8, #0x860]       | X8 = 0x2B8AFE4;                         
        // 0x00B2B4EC: LDR w0, [x8]               | W0 = 0x2B7;                             
        // 0x00B2B4F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B7, ????);      
        // 0x00B2B4F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2B4F8: STRB w8, [x19, #0x76e]     | static_value_0373376E = true;            //  dest_result_addr=57882478
        label_0:
        // 0x00B2B4FC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B2B500: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B2B504: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00B2B508: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2B50C: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B2B510: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921514474312160)("com.unity3d.player.UnityPlayer");
        // 0x00B2B514: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2B518: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2B51C: LDR x1, [x8]               | X1 = "com.unity3d.player.UnityPlayer";  
        // 0x00B2B520: BL #0x20b9834              | .ctor(className:  "com.unity3d.player.UnityPlayer");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.unity3d.player.UnityPlayer");
        // 0x00B2B524: CBNZ x19, #0xb2b530        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B2B528: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        // 0x00B2B52C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "com.unity3d.player.UnityPlayer"), ????);
        label_1:
        // 0x00B2B530: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B2B534: LDR x8, [x8, #0xb8]        | X8 = (string**)(1152921514474312288)("currentActivity");
        // 0x00B2B538: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x00B2B53C: LDR x9, [x9, #0x458]       | X9 = 1152921514474312400;               
        // 0x00B2B540: LDR x1, [x8]               | X1 = "currentActivity";                 
        // 0x00B2B544: LDR x2, [x9]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00B2B548: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2B54C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        // 0x00B2B550: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        // 0x00B2B554: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B2B558: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B2B55C: LDR x21, [x21, #0x10]      | X21 = this.klass; //P2                  
        // 0x00B2B560: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B2B564: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
        // 0x00B2B568: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B56C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B2B570: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B2B574: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B578: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B2B57C: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B580: CBNZ x22, #0xb2b588        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00B2B584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_2:
        // 0x00B2B588: CBZ x20, #0xb2b5ac         | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00B2B58C: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B2B590: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2B594: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2B598: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B2B59C: CBNZ x0, #0xb2b5ac         | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B2B5A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00B2B5A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B5A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_4:
        // 0x00B2B5AC: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2B5B0: CBNZ w8, #0xb2b5c0         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00B2B5B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00B2B5B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B5BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_5:
        // 0x00B2B5C0: STR x20, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00B2B5C4: CBZ x24, #0xb2b5e8         | if (id == null) goto label_7;           
        if(id == null)
        {
            goto label_7;
        }
        // 0x00B2B5C8: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B2B5CC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2B5D0: MOV x0, x24                | X0 = id;//m1                            
        // 0x00B2B5D4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? id, ????);         
        // 0x00B2B5D8: CBNZ x0, #0xb2b5e8         | if (id != null) goto label_7;           
        if(id != null)
        {
            goto label_7;
        }
        // 0x00B2B5DC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? id, ????);         
        // 0x00B2B5E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B5E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? id, ????);         
        label_7:
        // 0x00B2B5E8: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2B5EC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B2B5F0: B.HI #0xb2b600             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_8;
        // 0x00B2B5F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? id, ????);         
        // 0x00B2B5F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B5FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? id, ????);         
        label_8:
        // 0x00B2B600: STR x24, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = id;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = id;
        // 0x00B2B604: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00B2B608: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
        // 0x00B2B60C: LDR x0, [x8]               | X0 = typeof(System.Boolean);            
        // 0x00B2B610: AND w8, w23, #1            | W8 = (paid & 1);                        
        bool val_3 = paid;
        // 0x00B2B614: STRB w8, [sp, #0xf]        | stack[1152921515507506815] = (paid & 1);  //  dest_result_addr=1152921515507506815
        // 0x00B2B618: ADD x1, sp, #0xf           | X1 = (1152921515507506800 + 15) = 1152921515507506815 (0x1000000289BADE7F);
        // 0x00B2B61C: BL #0x27bc028              | X0 = 1152921515507563168 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), (paid & 1));
        // 0x00B2B620: MOV x23, x0                | X23 = 1152921515507563168 (0x1000000289BBBAA0);//ML01
        // 0x00B2B624: CBZ x23, #0xb2b648         | if ((paid & 1) == false) goto label_10; 
        if(val_3 == false)
        {
            goto label_10;
        }
        // 0x00B2B628: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B2B62C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2B630: MOV x0, x23                | X0 = 1152921515507563168 (0x1000000289BBBAA0);//ML01
        // 0x00B2B634: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (paid & 1), ????); 
        // 0x00B2B638: CBNZ x0, #0xb2b648         | if ((paid & 1) == true) goto label_10;  
        if(val_3 == true)
        {
            goto label_10;
        }
        // 0x00B2B63C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (paid & 1), ????); 
        // 0x00B2B640: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B644: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (paid & 1), ????); 
        label_10:
        // 0x00B2B648: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2B64C: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B2B650: B.HI #0xb2b660             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_11;
        // 0x00B2B654: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (paid & 1), ????); 
        // 0x00B2B658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B65C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (paid & 1), ????); 
        label_11:
        // 0x00B2B660: STR x23, [x22, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = (paid & 1); typeof(System.Object[]).__il2cppRuntimeField_31 = 0x1000000289BBBA;  //  dest_result_addr=1152921504954501312 dest_result_addr=1152921504954501313
        typeof(System.Object[]).__il2cppRuntimeField_30 = val_3;
        typeof(System.Object[]).__il2cppRuntimeField_31 = 42580922;
        // 0x00B2B664: CBNZ x21, #0xb2b66c        | if (this.klass != null) goto label_12;  
        if(this.klass != null)
        {
            goto label_12;
        }
        // 0x00B2B668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (paid & 1), ????); 
        label_12:
        // 0x00B2B66C: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B2B670: LDR x8, [x8, #0xae0]       | X8 = (string**)(1152921515507494784)("setPaid");
        // 0x00B2B674: LDR x1, [x8]               | X1 = "setPaid";                         
        // 0x00B2B678: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B2B67C: MOV x0, x21                | X0 = this.klass;//m1                    
        // 0x00B2B680: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B684: BL #0x20bdcfc              | this.klass.CallStatic(methodName:  "setPaid", args:  null);
        this.klass.CallStatic(methodName:  "setPaid", args:  null);
        // 0x00B2B688: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00B2B68C: MOVZ w22, #0x50            | W22 = 80 (0x50);//ML01                  
        label_28:
        // 0x00B2B690: CBZ x20, #0xb2b6fc         | if (val_2 == null) goto label_13;       
        if(val_2 == null)
        {
            goto label_13;
        }
        // 0x00B2B694: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2B698: LDR x8, [x20]              | X8 = typeof(UnityEngine.AndroidJavaObject);
        // 0x00B2B69C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2B6A0: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2B6A4: LDRH w9, [x8, #0x102]      | W9 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B2B6A8: CBZ x9, #0xb2b6d4          | if (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count == 0) goto label_14;
        // 0x00B2B6AC: LDR x10, [x8, #0x98]       | X10 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B2B6B0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_5 = 0;
        // 0x00B2B6B4: ADD x10, x10, #8           | X10 = (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504690216968 (0x1000000004F82008);
        label_16:
        // 0x00B2B6B8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B2B6BC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B2B6C0: B.EQ #0xb2b6e4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_15;
        // 0x00B2B6C4: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_5 = val_5 + 1;
        // 0x00B2B6C8: ADD x10, x10, #0x10        | X10 = (1152921504690216968 + 16) = 1152921504690216984 (0x1000000004F82018);
        // 0x00B2B6CC: CMP x11, x9                | STATE = COMPARE((0 + 1), UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B2B6D0: B.LO #0xb2b6b8             | if (0 < UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count) goto label_16;
        label_14:
        // 0x00B2B6D4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2B6D8: MOV x0, x20                | X0 = val_2;//m1                         
        val_6 = val_2;
        // 0x00B2B6DC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B2B6E0: B #0xb2b6f0                |  goto label_17;                         
        goto label_17;
        label_15:
        // 0x00B2B6E4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B2B6E8: ADD x8, x8, x9, lsl #4     | X8 = (1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B2B6EC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_17:
        // 0x00B2B6F0: LDP x8, x1, [x0]           | X8 = typeof(UnityEngine.AndroidJavaClass);  //  | 
        // 0x00B2B6F4: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2B6F8: BLR x8                     | X0 = sub_1000000004F86000( ?? val_2, ????);
        label_13:
        // 0x00B2B6FC: MOVZ w20, #0x62            | W20 = 98 (0x62);//ML01                  
        val_7 = 98;
        // 0x00B2B700: CMP w22, #0x50             | STATE = COMPARE(0x50, 0x50)             
        // 0x00B2B704: B.EQ #0xb2b720             | if (0x50 == 0x50) goto label_30;        
        if(80 == 80)
        {
            goto label_30;
        }
        // 0x00B2B708: CBZ x21, #0xb2b720         | if (0x0 == 0) goto label_30;            
        if(val_5 == 0)
        {
            goto label_30;
        }
        // 0x00B2B70C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B710: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B2B714: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B2B718: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00B2B71C: MOVZ w20, #0x62            | W20 = 98 (0x62);//ML01                  
        val_7 = 98;
        label_30:
        // 0x00B2B720: CBZ x19, #0xb2b78c         | if ( == 0) goto label_20;               
        if(null == 0)
        {
            goto label_20;
        }
        // 0x00B2B724: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2B728: LDR x8, [x19]              | X8 = ;                                  
        UnityEngine.AndroidJavaClass val_8 = null;
        // 0x00B2B72C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2B730: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2B734: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00B2B738: CBZ x9, #0xb2b764          | if (mem[null + 258] == 0) goto label_21;
        if((mem[null + 258]) == 0)
        {
            goto label_21;
        }
        // 0x00B2B73C: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_6 = mem[null + 152];
        // 0x00B2B740: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_7 = 0;
        // 0x00B2B744: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_6 = val_6 + 8;
        label_23:
        // 0x00B2B748: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00B2B74C: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00B2B750: B.EQ #0xb2b774             | if ((mem[null + 152] + 8) + -8 == null) goto label_22;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_22;
        }
        // 0x00B2B754: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_7 = val_7 + 1;
        // 0x00B2B758: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_6 = val_6 + 16;
        // 0x00B2B75C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00B2B760: B.LO #0xb2b748             | if (0 < mem[null + 258]) goto label_23; 
        if(val_7 < (mem[null + 258]))
        {
            goto label_23;
        }
        label_21:
        // 0x00B2B764: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2B768: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_8 = val_1;
        // 0x00B2B76C: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2B770: B #0xb2b780                |  goto label_24;                         
        goto label_24;
        label_22:
        // 0x00B2B774: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00B2B778: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_8 = val_8 + (((mem[null + 152] + 8)) << 4);
        // 0x00B2B77C: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_24:
        // 0x00B2B780: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
        // 0x00B2B784: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2B788: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        label_20:
        // 0x00B2B78C: CMP w20, #0x62             | STATE = COMPARE(0x62, 0x62)             
        // 0x00B2B790: B.EQ #0xb2b7a4             | if (0x62 == 0x62) goto label_26;        
        if(98 == 98)
        {
            goto label_26;
        }
        // 0x00B2B794: CBZ x21, #0xb2b7a4         | if (0x0 == 0) goto label_26;            
        if(val_5 == 0)
        {
            goto label_26;
        }
        // 0x00B2B798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B79C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B2B7A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_26:
        // 0x00B2B7A4: SUB sp, x29, #0x30         | SP = (1152921515507506864 - 48) = 1152921515507506816 (0x1000000289BADE80);
        // 0x00B2B7A8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2B7AC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2B7B0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2B7B4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B2B7B8: RET                        |  return;                                
        return;
        // 0x00B2B7BC: CMP w1, #1                 | 
        // 0x00B2B7C0: B.NE #0xb2b7e0             | 
        // 0x00B2B7C4: BL #0x981060               | 
        // 0x00B2B7C8: LDR x21, [x0]              | 
        // 0x00B2B7CC: MOV w22, wzr               | 
        // 0x00B2B7D0: BL #0x980920               | 
        // 0x00B2B7D4: B #0xb2b690                | 
        // 0x00B2B7D8: MOV w20, w22               | 
        // 0x00B2B7DC: B #0xb2b7e4                | 
        label_27:
        // 0x00B2B7E0: MOV w20, wzr               | 
        label_29:
        // 0x00B2B7E4: BL #0x981060               | 
        // 0x00B2B7E8: LDR x21, [x0]              | 
        // 0x00B2B7EC: BL #0x980920               | 
        // 0x00B2B7F0: B #0xb2b720                | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2B7F4 (11712500), len: 744  VirtAddr: 0x00B2B7F4 RVA: 0x00B2B7F4 token: 100696279 methodIndex: 24878 delegateWrapperIndex: 0 methodInvoker: 0
    public string getPayingResult(string id)
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        // 0x00B2B7F4: STP x24, x23, [sp, #-0x40]! | stack[1152921515507651696] = ???;  stack[1152921515507651704] = ???;  //  dest_result_addr=1152921515507651696 |  dest_result_addr=1152921515507651704
        // 0x00B2B7F8: STP x22, x21, [sp, #0x10]  | stack[1152921515507651712] = ???;  stack[1152921515507651720] = ???;  //  dest_result_addr=1152921515507651712 |  dest_result_addr=1152921515507651720
        // 0x00B2B7FC: STP x20, x19, [sp, #0x20]  | stack[1152921515507651728] = ???;  stack[1152921515507651736] = ???;  //  dest_result_addr=1152921515507651728 |  dest_result_addr=1152921515507651736
        // 0x00B2B800: STP x29, x30, [sp, #0x30]  | stack[1152921515507651744] = ???;  stack[1152921515507651752] = ???;  //  dest_result_addr=1152921515507651744 |  dest_result_addr=1152921515507651752
        // 0x00B2B804: ADD x29, sp, #0x30         | X29 = (1152921515507651696 + 48) = 1152921515507651744 (0x1000000289BD14A0);
        // 0x00B2B808: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B2B80C: LDRB w8, [x19, #0x76f]     | W8 = (bool)static_value_0373376F;       
        // 0x00B2B810: MOV x22, x1                | X22 = id;//m1                           
        // 0x00B2B814: MOV x23, x0                | X23 = 1152921515507663760 (0x1000000289BD4390);//ML01
        // 0x00B2B818: TBNZ w8, #0, #0xb2b834     | if (static_value_0373376F == true) goto label_0;
        // 0x00B2B81C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00B2B820: LDR x8, [x8, #0x1e0]       | X8 = 0x2B8AFD0;                         
        // 0x00B2B824: LDR w0, [x8]               | W0 = 0x2B2;                             
        // 0x00B2B828: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B2, ????);      
        // 0x00B2B82C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2B830: STRB w8, [x19, #0x76f]     | static_value_0373376F = true;            //  dest_result_addr=57882479
        label_0:
        // 0x00B2B834: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B2B838: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B2B83C: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00B2B840: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2B844: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B2B848: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921514474312160)("com.unity3d.player.UnityPlayer");
        // 0x00B2B84C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2B850: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2B854: LDR x1, [x8]               | X1 = "com.unity3d.player.UnityPlayer";  
        // 0x00B2B858: BL #0x20b9834              | .ctor(className:  "com.unity3d.player.UnityPlayer");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.unity3d.player.UnityPlayer");
        // 0x00B2B85C: CBNZ x19, #0xb2b86c        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B2B860: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        // 0x00B2B864: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
        // 0x00B2B868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "com.unity3d.player.UnityPlayer"), ????);
        label_1:
        // 0x00B2B86C: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B2B870: LDR x8, [x8, #0xb8]        | X8 = (string**)(1152921514474312288)("currentActivity");
        // 0x00B2B874: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x00B2B878: LDR x9, [x9, #0x458]       | X9 = 1152921514474312400;               
        // 0x00B2B87C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        // 0x00B2B880: LDR x1, [x8]               | X1 = "currentActivity";                 
        // 0x00B2B884: LDR x2, [x9]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00B2B888: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2B88C: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
        // 0x00B2B890: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        // 0x00B2B894: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B2B898: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B2B89C: LDR x21, [x23, #0x10]      | X21 = this.klass; //P2                  
        // 0x00B2B8A0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B2B8A4: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
        // 0x00B2B8A8: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B8AC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B2B8B0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B2B8B4: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B8B8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B2B8BC: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B8C0: CBNZ x23, #0xb2b8c8        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00B2B8C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_2:
        // 0x00B2B8C8: CBZ x20, #0xb2b8ec         | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00B2B8CC: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B2B8D0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2B8D4: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2B8D8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B2B8DC: CBNZ x0, #0xb2b8ec         | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B2B8E0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00B2B8E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B8E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_4:
        // 0x00B2B8EC: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2B8F0: CBNZ w8, #0xb2b900         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00B2B8F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00B2B8F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B8FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_5:
        // 0x00B2B900: STR x20, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00B2B904: CBZ x22, #0xb2b928         | if (id == null) goto label_7;           
        if(id == null)
        {
            goto label_7;
        }
        // 0x00B2B908: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B2B90C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2B910: MOV x0, x22                | X0 = id;//m1                            
        // 0x00B2B914: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? id, ????);         
        // 0x00B2B918: CBNZ x0, #0xb2b928         | if (id != null) goto label_7;           
        if(id != null)
        {
            goto label_7;
        }
        // 0x00B2B91C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? id, ????);         
        // 0x00B2B920: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B924: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? id, ????);         
        label_7:
        // 0x00B2B928: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2B92C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B2B930: B.HI #0xb2b940             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_8;
        // 0x00B2B934: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? id, ????);         
        // 0x00B2B938: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B93C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? id, ????);         
        label_8:
        // 0x00B2B940: STR x22, [x23, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = id;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = id;
        // 0x00B2B944: CBNZ x21, #0xb2b94c        | if (this.klass != null) goto label_9;   
        if(this.klass != null)
        {
            goto label_9;
        }
        // 0x00B2B948: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? id, ????);         
        label_9:
        // 0x00B2B94C: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00B2B950: LDR x8, [x8, #0x170]       | X8 = (string**)(1152921515507635552)("getPayingResult");
        // 0x00B2B954: ADRP x9, #0x35fc000        | X9 = 56606720 (0x35FC000);              
        // 0x00B2B958: LDR x9, [x9, #0x8b0]       | X9 = 1152921509932495296;               
        // 0x00B2B95C: LDR x1, [x8]               | X1 = "getPayingResult";                 
        // 0x00B2B960: LDR x3, [x9]               | X3 = public System.String UnityEngine.AndroidJavaObject::CallStatic<System.String>(string methodName, object[] args);
        // 0x00B2B964: MOV x0, x21                | X0 = this.klass;//m1                    
        // 0x00B2B968: MOV x2, x23                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2B96C: BL #0x12f6004              | X0 = this.klass.CallStatic<System.String>(methodName:  "getPayingResult", args:  null);
        string val_3 = this.klass.CallStatic<System.String>(methodName:  "getPayingResult", args:  null);
        // 0x00B2B970: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B2B974: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00B2B978: MOVZ w24, #0x55            | W24 = 85 (0x55);//ML01                  
        label_25:
        // 0x00B2B97C: CBZ x20, #0xb2b9e8         | if (val_2 == null) goto label_10;       
        if(val_2 == null)
        {
            goto label_10;
        }
        // 0x00B2B980: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2B984: LDR x8, [x20]              | X8 = typeof(UnityEngine.AndroidJavaObject);
        // 0x00B2B988: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2B98C: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2B990: LDRH w9, [x8, #0x102]      | W9 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B2B994: CBZ x9, #0xb2b9c0          | if (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count == 0) goto label_11;
        // 0x00B2B998: LDR x10, [x8, #0x98]       | X10 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B2B99C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_5 = 0;
        // 0x00B2B9A0: ADD x10, x10, #8           | X10 = (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504690216968 (0x1000000004F82008);
        label_13:
        // 0x00B2B9A4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B2B9A8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B2B9AC: B.EQ #0xb2b9d0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_12;
        // 0x00B2B9B0: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_5 = val_5 + 1;
        // 0x00B2B9B4: ADD x10, x10, #0x10        | X10 = (1152921504690216968 + 16) = 1152921504690216984 (0x1000000004F82018);
        // 0x00B2B9B8: CMP x11, x9                | STATE = COMPARE((0 + 1), UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B2B9BC: B.LO #0xb2b9a4             | if (0 < UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count) goto label_13;
        label_11:
        // 0x00B2B9C0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2B9C4: MOV x0, x20                | X0 = val_2;//m1                         
        val_6 = val_2;
        // 0x00B2B9C8: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B2B9CC: B #0xb2b9dc                |  goto label_14;                         
        goto label_14;
        label_12:
        // 0x00B2B9D0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B2B9D4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B2B9D8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_14:
        // 0x00B2B9DC: LDP x8, x1, [x0]           | X8 = typeof(System.String);              //  | 
        // 0x00B2B9E0: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B2B9E4: BLR x8                     | X0 = sub_100000000015F000( ?? val_2, ????);
        label_10:
        // 0x00B2B9E8: CMP w24, #0x55             | STATE = COMPARE(0x55, 0x55)             
        // 0x00B2B9EC: B.EQ #0xb2ba04             | if (0x55 == 0x55) goto label_27;        
        if(85 == 85)
        {
            goto label_27;
        }
        // 0x00B2B9F0: CBZ x22, #0xb2ba04         | if (0x0 == 0) goto label_27;            
        if(val_5 == 0)
        {
            goto label_27;
        }
        // 0x00B2B9F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2B9F8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
        // 0x00B2B9FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B2BA00: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_5 = 0;
        label_27:
        // 0x00B2BA04: CBZ x19, #0xb2ba70         | if ( == 0) goto label_17;               
        if(null == 0)
        {
            goto label_17;
        }
        // 0x00B2BA08: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2BA0C: LDR x8, [x19]              | X8 = ;                                  
        UnityEngine.AndroidJavaClass val_8 = null;
        // 0x00B2BA10: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2BA14: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2BA18: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00B2BA1C: CBZ x9, #0xb2ba48          | if (mem[null + 258] == 0) goto label_18;
        if((mem[null + 258]) == 0)
        {
            goto label_18;
        }
        // 0x00B2BA20: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_6 = mem[null + 152];
        // 0x00B2BA24: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_7 = 0;
        // 0x00B2BA28: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_6 = val_6 + 8;
        label_20:
        // 0x00B2BA2C: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00B2BA30: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00B2BA34: B.EQ #0xb2ba58             | if ((mem[null + 152] + 8) + -8 == null) goto label_19;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_19;
        }
        // 0x00B2BA38: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_7 = val_7 + 1;
        // 0x00B2BA3C: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_6 = val_6 + 16;
        // 0x00B2BA40: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00B2BA44: B.LO #0xb2ba2c             | if (0 < mem[null + 258]) goto label_20; 
        if(val_7 < (mem[null + 258]))
        {
            goto label_20;
        }
        label_18:
        // 0x00B2BA48: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2BA4C: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_7 = val_1;
        // 0x00B2BA50: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2BA54: B #0xb2ba64                |  goto label_21;                         
        goto label_21;
        label_19:
        // 0x00B2BA58: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00B2BA5C: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_8 = val_8 + (((mem[null + 152] + 8)) << 4);
        // 0x00B2BA60: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_21:
        // 0x00B2BA64: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
        // 0x00B2BA68: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2BA6C: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        label_17:
        // 0x00B2BA70: CMP w24, #0x55             | STATE = COMPARE(0x55, 0x55)             
        // 0x00B2BA74: B.EQ #0xb2ba88             | if (0x55 == 0x55) goto label_23;        
        if(85 == 85)
        {
            goto label_23;
        }
        // 0x00B2BA78: CBZ x22, #0xb2ba88         | if (0x0 == 0) goto label_23;            
        if(val_5 == 0)
        {
            goto label_23;
        }
        // 0x00B2BA7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2BA80: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
        // 0x00B2BA84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_23:
        // 0x00B2BA88: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B2BA8C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2BA90: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2BA94: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2BA98: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B2BA9C: RET                        |  return (System.String)val_3;           
        return (string)val_3;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        // 0x00B2BAA0: CMP w1, #1                 | 
        // 0x00B2BAA4: B.NE #0xb2bac4             | 
        // 0x00B2BAA8: BL #0x981060               | 
        // 0x00B2BAAC: LDR x22, [x0]              | 
        // 0x00B2BAB0: MOV x21, xzr               | 
        // 0x00B2BAB4: MOV w24, wzr               | 
        // 0x00B2BAB8: BL #0x980920               | 
        // 0x00B2BABC: B #0xb2b97c                | 
        // 0x00B2BAC0: B #0xb2bacc                | 
        label_24:
        // 0x00B2BAC4: MOV w24, wzr               | 
        // 0x00B2BAC8: MOV x21, xzr               | 
        label_26:
        // 0x00B2BACC: BL #0x981060               | 
        // 0x00B2BAD0: LDR x22, [x0]              | 
        // 0x00B2BAD4: BL #0x980920               | 
        // 0x00B2BAD8: B #0xb2ba04                | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2BADC (11713244), len: 676  VirtAddr: 0x00B2BADC RVA: 0x00B2BADC token: 100696280 methodIndex: 24879 delegateWrapperIndex: 0 methodInvoker: 0
    public long getUserId()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        // 0x00B2BADC: STP x24, x23, [sp, #-0x40]! | stack[1152921515507788368] = ???;  stack[1152921515507788376] = ???;  //  dest_result_addr=1152921515507788368 |  dest_result_addr=1152921515507788376
        // 0x00B2BAE0: STP x22, x21, [sp, #0x10]  | stack[1152921515507788384] = ???;  stack[1152921515507788392] = ???;  //  dest_result_addr=1152921515507788384 |  dest_result_addr=1152921515507788392
        // 0x00B2BAE4: STP x20, x19, [sp, #0x20]  | stack[1152921515507788400] = ???;  stack[1152921515507788408] = ???;  //  dest_result_addr=1152921515507788400 |  dest_result_addr=1152921515507788408
        // 0x00B2BAE8: STP x29, x30, [sp, #0x30]  | stack[1152921515507788416] = ???;  stack[1152921515507788424] = ???;  //  dest_result_addr=1152921515507788416 |  dest_result_addr=1152921515507788424
        // 0x00B2BAEC: ADD x29, sp, #0x30         | X29 = (1152921515507788368 + 48) = 1152921515507788416 (0x1000000289BF2A80);
        // 0x00B2BAF0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B2BAF4: LDRB w8, [x19, #0x770]     | W8 = (bool)static_value_03733770;       
        // 0x00B2BAF8: MOV x22, x0                | X22 = 1152921515507800432 (0x1000000289BF5970);//ML01
        // 0x00B2BAFC: TBNZ w8, #0, #0xb2bb18     | if (static_value_03733770 == true) goto label_0;
        // 0x00B2BB00: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00B2BB04: LDR x8, [x8, #0xa48]       | X8 = 0x2B8AFD4;                         
        // 0x00B2BB08: LDR w0, [x8]               | W0 = 0x2B3;                             
        // 0x00B2BB0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B3, ????);      
        // 0x00B2BB10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2BB14: STRB w8, [x19, #0x770]     | static_value_03733770 = true;            //  dest_result_addr=57882480
        label_0:
        // 0x00B2BB18: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B2BB1C: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B2BB20: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00B2BB24: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2BB28: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B2BB2C: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921514474312160)("com.unity3d.player.UnityPlayer");
        // 0x00B2BB30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2BB34: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2BB38: LDR x1, [x8]               | X1 = "com.unity3d.player.UnityPlayer";  
        // 0x00B2BB3C: BL #0x20b9834              | .ctor(className:  "com.unity3d.player.UnityPlayer");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.unity3d.player.UnityPlayer");
        // 0x00B2BB40: CBNZ x19, #0xb2bb50        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B2BB44: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        // 0x00B2BB48: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        // 0x00B2BB4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "com.unity3d.player.UnityPlayer"), ????);
        label_1:
        // 0x00B2BB50: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B2BB54: LDR x8, [x8, #0xb8]        | X8 = (string**)(1152921514474312288)("currentActivity");
        // 0x00B2BB58: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x00B2BB5C: LDR x9, [x9, #0x458]       | X9 = 1152921514474312400;               
        // 0x00B2BB60: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        // 0x00B2BB64: LDR x1, [x8]               | X1 = "currentActivity";                 
        // 0x00B2BB68: LDR x2, [x9]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00B2BB6C: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2BB70: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        // 0x00B2BB74: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        // 0x00B2BB78: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00B2BB7C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B2BB80: LDR x20, [x22, #0x10]      | X20 = this.klass; //P2                  
        // 0x00B2BB84: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B2BB88: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
        // 0x00B2BB8C: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2BB90: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B2BB94: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B2BB98: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2BB9C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B2BBA0: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2BBA4: CBNZ x22, #0xb2bbac        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00B2BBA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_2:
        // 0x00B2BBAC: CBZ x21, #0xb2bbd0         | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00B2BBB0: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B2BBB4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2BBB8: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00B2BBBC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B2BBC0: CBNZ x0, #0xb2bbd0         | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B2BBC4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00B2BBC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2BBCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_4:
        // 0x00B2BBD0: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B2BBD4: CBNZ w8, #0xb2bbe4         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00B2BBD8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00B2BBDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2BBE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_5:
        // 0x00B2BBE4: STR x21, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00B2BBE8: CBNZ x20, #0xb2bbf0        | if (this.klass != null) goto label_6;   
        if(this.klass != null)
        {
            goto label_6;
        }
        // 0x00B2BBEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B2BBF0: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
        // 0x00B2BBF4: LDR x8, [x8, #0xe18]       | X8 = (string**)(1152921515507776336)("getUserId");
        // 0x00B2BBF8: ADRP x9, #0x3635000        | X9 = 56840192 (0x3635000);              
        // 0x00B2BBFC: LDR x9, [x9, #0x4e8]       | X9 = 1152921514474357408;               
        // 0x00B2BC00: LDR x1, [x8]               | X1 = "getUserId";                       
        // 0x00B2BC04: LDR x3, [x9]               | X3 = public System.Int64 UnityEngine.AndroidJavaObject::CallStatic<System.Int64>(string methodName, object[] args);
        // 0x00B2BC08: MOV x0, x20                | X0 = this.klass;//m1                    
        // 0x00B2BC0C: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2BC10: BL #0x12f5fb4              | X0 = this.klass.CallStatic<System.Int64>(methodName:  "getUserId", args:  null);
        long val_3 = this.klass.CallStatic<System.Int64>(methodName:  "getUserId", args:  null);
        // 0x00B2BC14: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B2BC18: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00B2BC1C: MOVZ w23, #0x51            | W23 = 81 (0x51);//ML01                  
        label_22:
        // 0x00B2BC20: CBZ x21, #0xb2bc8c         | if (val_2 == null) goto label_7;        
        if(val_2 == null)
        {
            goto label_7;
        }
        // 0x00B2BC24: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2BC28: LDR x8, [x21]              | X8 = typeof(UnityEngine.AndroidJavaObject);
        // 0x00B2BC2C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2BC30: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2BC34: LDRH w9, [x8, #0x102]      | W9 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B2BC38: CBZ x9, #0xb2bc64          | if (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count == 0) goto label_8;
        // 0x00B2BC3C: LDR x10, [x8, #0x98]       | X10 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B2BC40: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_5 = 0;
        // 0x00B2BC44: ADD x10, x10, #8           | X10 = (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504690216968 (0x1000000004F82008);
        label_10:
        // 0x00B2BC48: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B2BC4C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B2BC50: B.EQ #0xb2bc74             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_9;
        // 0x00B2BC54: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_5 = val_5 + 1;
        // 0x00B2BC58: ADD x10, x10, #0x10        | X10 = (1152921504690216968 + 16) = 1152921504690216984 (0x1000000004F82018);
        // 0x00B2BC5C: CMP x11, x9                | STATE = COMPARE((0 + 1), UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B2BC60: B.LO #0xb2bc48             | if (0 < UnityEngine.AndroidJavaObject.__il2cppRuntimeField_interface_offsets_count) goto label_10;
        label_8:
        // 0x00B2BC64: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2BC68: MOV x0, x21                | X0 = val_2;//m1                         
        val_6 = val_2;
        // 0x00B2BC6C: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B2BC70: B #0xb2bc80                |  goto label_11;                         
        goto label_11;
        label_9:
        // 0x00B2BC74: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B2BC78: ADD x8, x8, x9, lsl #4     | X8 = (1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B2BC7C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504690180096 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_11:
        // 0x00B2BC80: LDP x8, x1, [x0]           | X8 = val_3; X1 = val_3 + 8;              //  | 
        // 0x00B2BC84: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00B2BC88: BLR x8                     | X0 = val_3();                           
        label_7:
        // 0x00B2BC8C: CMP w23, #0x51             | STATE = COMPARE(0x51, 0x51)             
        // 0x00B2BC90: B.EQ #0xb2bca8             | if (0x51 == 0x51) goto label_24;        
        if(81 == 81)
        {
            goto label_24;
        }
        // 0x00B2BC94: CBZ x22, #0xb2bca8         | if (0x0 == 0) goto label_24;            
        if(val_5 == 0)
        {
            goto label_24;
        }
        // 0x00B2BC98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2BC9C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
        // 0x00B2BCA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B2BCA4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_5 = 0;
        label_24:
        // 0x00B2BCA8: CBZ x19, #0xb2bd14         | if ( == 0) goto label_14;               
        if(null == 0)
        {
            goto label_14;
        }
        // 0x00B2BCAC: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B2BCB0: LDR x8, [x19]              | X8 = ;                                  
        UnityEngine.AndroidJavaClass val_8 = null;
        // 0x00B2BCB4: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B2BCB8: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B2BCBC: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00B2BCC0: CBZ x9, #0xb2bcec          | if (mem[null + 258] == 0) goto label_15;
        if((mem[null + 258]) == 0)
        {
            goto label_15;
        }
        // 0x00B2BCC4: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_6 = mem[null + 152];
        // 0x00B2BCC8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_7 = 0;
        // 0x00B2BCCC: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_6 = val_6 + 8;
        label_17:
        // 0x00B2BCD0: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00B2BCD4: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00B2BCD8: B.EQ #0xb2bcfc             | if ((mem[null + 152] + 8) + -8 == null) goto label_16;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_16;
        }
        // 0x00B2BCDC: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_7 = val_7 + 1;
        // 0x00B2BCE0: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_6 = val_6 + 16;
        // 0x00B2BCE4: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00B2BCE8: B.LO #0xb2bcd0             | if (0 < mem[null + 258]) goto label_17; 
        if(val_7 < (mem[null + 258]))
        {
            goto label_17;
        }
        label_15:
        // 0x00B2BCEC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B2BCF0: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_7 = val_1;
        // 0x00B2BCF4: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B2BCF8: B #0xb2bd08                |  goto label_18;                         
        goto label_18;
        label_16:
        // 0x00B2BCFC: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00B2BD00: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_8 = val_8 + (((mem[null + 152] + 8)) << 4);
        // 0x00B2BD04: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_18:
        // 0x00B2BD08: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
        // 0x00B2BD0C: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B2BD10: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        label_14:
        // 0x00B2BD14: CMP w23, #0x51             | STATE = COMPARE(0x51, 0x51)             
        // 0x00B2BD18: B.EQ #0xb2bd2c             | if (0x51 == 0x51) goto label_20;        
        if(81 == 81)
        {
            goto label_20;
        }
        // 0x00B2BD1C: CBZ x22, #0xb2bd2c         | if (0x0 == 0) goto label_20;            
        if(val_5 == 0)
        {
            goto label_20;
        }
        // 0x00B2BD20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2BD24: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
        // 0x00B2BD28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_20:
        // 0x00B2BD2C: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B2BD30: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2BD34: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2BD38: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2BD3C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B2BD40: RET                        |  return (System.Int64)val_3;            
        return (long)val_3;
        //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        // 0x00B2BD44: CMP w1, #1                 | 
        // 0x00B2BD48: B.NE #0xb2bd68             | 
        // 0x00B2BD4C: BL #0x981060               | 
        // 0x00B2BD50: LDR x22, [x0]              | 
        // 0x00B2BD54: MOV x20, xzr               | 
        // 0x00B2BD58: MOV w23, wzr               | 
        // 0x00B2BD5C: BL #0x980920               | 
        // 0x00B2BD60: B #0xb2bc20                | 
        // 0x00B2BD64: B #0xb2bd70                | 
        label_21:
        // 0x00B2BD68: MOV w23, wzr               | 
        // 0x00B2BD6C: MOV x20, xzr               | 
        label_23:
        // 0x00B2BD70: BL #0x981060               | 
        // 0x00B2BD74: LDR x22, [x0]              | 
        // 0x00B2BD78: BL #0x980920               | 
        // 0x00B2BD7C: B #0xb2bca8                | 
    
    }

}
