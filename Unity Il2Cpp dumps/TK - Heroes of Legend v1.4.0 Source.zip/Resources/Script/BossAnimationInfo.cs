using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286A908
[Serializable]
public class BossAnimationInfo : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private float _trigerPos_x; //  0x00000014
    private float _trigerPos_y; //  0x00000018
    private float _trigerPos_z; //  0x0000001C
    private int _isBoss; //  0x00000020
    private float _bossPos_x; //  0x00000024
    private float _bossPos_y; //  0x00000028
    private float _bossPos_z; //  0x0000002C
    private float _bossRot_y; //  0x00000030
    private readonly System.Collections.Generic.List<AnimationPointJSC> _camera; //  0x00000038
    private readonly System.Collections.Generic.List<AnimationPointJSC> _boss; //  0x00000040
    private ProtoBuf.IExtension extensionObject; //  0x00000048
    
    // Properties
    public UnityEngine.Vector3 TrigerPos { get; }
    public UnityEngine.Vector3 BossPos { get; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286A94C
    [System.ComponentModel.DefaultValueAttribute] // 0x286A94C
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286A9CC
    [System.ComponentModel.DefaultValueAttribute] // 0x286A9CC
    public float trigerPos_x { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286AA4C
    [System.ComponentModel.DefaultValueAttribute] // 0x286AA4C
    public float trigerPos_y { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286AACC
    [System.ComponentModel.DefaultValueAttribute] // 0x286AACC
    public float trigerPos_z { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286AB4C
    [System.ComponentModel.DefaultValueAttribute] // 0x286AB4C
    public int isBoss { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286ABCC
    [System.ComponentModel.DefaultValueAttribute] // 0x286ABCC
    public float bossPos_x { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286AC4C
    [System.ComponentModel.DefaultValueAttribute] // 0x286AC4C
    public float bossPos_y { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286ACCC
    [System.ComponentModel.DefaultValueAttribute] // 0x286ACCC
    public float bossPos_z { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286AD4C
    [System.ComponentModel.DefaultValueAttribute] // 0x286AD4C
    public float bossRot_y { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286ADCC
    public System.Collections.Generic.List<AnimationPointJSC> camera { get; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286AE24
    public System.Collections.Generic.List<AnimationPointJSC> boss { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B93D84 (12139908), len: 144  VirtAddr: 0x00B93D84 RVA: 0x00B93D84 token: 100690121 methodIndex: 25213 delegateWrapperIndex: 0 methodInvoker: 0
    public BossAnimationInfo()
    {
        //
        // Disasemble & Code
        // 0x00B93D84: STP x22, x21, [sp, #-0x30]! | stack[1152921514475513904] = ???;  stack[1152921514475513912] = ???;  //  dest_result_addr=1152921514475513904 |  dest_result_addr=1152921514475513912
        // 0x00B93D88: STP x20, x19, [sp, #0x10]  | stack[1152921514475513920] = ???;  stack[1152921514475513928] = ???;  //  dest_result_addr=1152921514475513920 |  dest_result_addr=1152921514475513928
        // 0x00B93D8C: STP x29, x30, [sp, #0x20]  | stack[1152921514475513936] = ???;  stack[1152921514475513944] = ???;  //  dest_result_addr=1152921514475513936 |  dest_result_addr=1152921514475513944
        // 0x00B93D90: ADD x29, sp, #0x20         | X29 = (1152921514475513904 + 32) = 1152921514475513936 (0x100000024C37E850);
        // 0x00B93D94: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B93D98: LDRB w8, [x20, #0xa68]     | W8 = (bool)static_value_03733A68;       
        // 0x00B93D9C: MOV x19, x0                | X19 = 1152921514475525952 (0x100000024C381740);//ML01
        // 0x00B93DA0: TBNZ w8, #0, #0xb93dbc     | if (static_value_03733A68 == true) goto label_0;
        // 0x00B93DA4: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00B93DA8: LDR x8, [x8, #0xf18]       | X8 = 0x2B8F8C0;                         
        // 0x00B93DAC: LDR w0, [x8]               | W0 = 0x14F4;                            
        // 0x00B93DB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F4, ????);     
        // 0x00B93DB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B93DB8: STRB w8, [x20, #0xa68]     | static_value_03733A68 = true;            //  dest_result_addr=57883240
        label_0:
        // 0x00B93DBC: ADRP x21, #0x35cb000       | X21 = 56406016 (0x35CB000);             
        // 0x00B93DC0: LDR x21, [x21, #0x990]     | X21 = 1152921504616644608;              
        // 0x00B93DC4: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<AnimationPointJSC> val_1 = null;
        // 0x00B93DC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B93DCC: ADRP x22, #0x35bc000       | X22 = 56344576 (0x35BC000);             
        // 0x00B93DD0: LDR x22, [x22, #0xe40]     | X22 = 1152921514475500928;              
        // 0x00B93DD4: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B93DD8: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<AnimationPointJSC>::.ctor();
        // 0x00B93DDC: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<AnimationPointJSC>();
        // 0x00B93DE0: STR x20, [x19, #0x38]      | this._camera = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514475526008
        this._camera = val_1;
        // 0x00B93DE4: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<AnimationPointJSC> val_2 = null;
        // 0x00B93DE8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B93DEC: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<AnimationPointJSC>::.ctor();
        // 0x00B93DF0: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B93DF4: BL #0x25e9474              | .ctor();                                
        val_2 = new System.Collections.Generic.List<AnimationPointJSC>();
        // 0x00B93DF8: STR x20, [x19, #0x40]      | this._boss = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514475526016
        this._boss = val_2;
        // 0x00B93DFC: MOV x0, x19                | X0 = 1152921514475525952 (0x100000024C381740);//ML01
        // 0x00B93E00: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B93E04: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B93E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93E0C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B93E10: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93E14 (12140052), len: 60  VirtAddr: 0x00B93E14 RVA: 0x00B93E14 token: 100690122 methodIndex: 25214 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Vector3 get_TrigerPos()
    {
        //
        // Disasemble & Code
        // 0x00B93E14: STP x29, x30, [sp, #-0x10]! | stack[1152921514475625936] = ???;  stack[1152921514475625944] = ???;  //  dest_result_addr=1152921514475625936 |  dest_result_addr=1152921514475625944
        // 0x00B93E18: MOV x29, sp                | X29 = 1152921514475625936 (0x100000024C399DD0);//ML01
        // 0x00B93E1C: SUB sp, sp, #0x10          | SP = (1152921514475625936 - 16) = 1152921514475625920 (0x100000024C399DC0);
        // 0x00B93E20: LDP s0, s1, [x0, #0x14]    | S0 = this._trigerPos_x; //P2  S1 = this._trigerPos_y; //P2  //  | 
        // 0x00B93E24: LDR s2, [x0, #0x1c]        | S2 = this._trigerPos_z; //P2            
        // 0x00B93E28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93E2C: MOV x0, sp                 | X0 = 1152921514475625920 (0x100000024C399DC0);//ML01
        // 0x00B93E30: STR wzr, [sp, #8]          | stack[1152921514475625928] = 0x0;        //  dest_result_addr=1152921514475625928
        // 0x00B93E34: STR xzr, [sp]              | stack[1152921514475625920] = 0x0;        //  dest_result_addr=1152921514475625920
        // 0x00B93E38: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B93E3C: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x00B93E40: LDR s2, [sp, #8]           | S2 = 0;                                 
        // 0x00B93E44: MOV sp, x29                | SP = 1152921514475625936 (0x100000024C399DD0);//ML01
        // 0x00B93E48: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00B93E4C: RET                        |  return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93E68 (12140136), len: 60  VirtAddr: 0x00B93E68 RVA: 0x00B93E68 token: 100690123 methodIndex: 25215 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Vector3 get_BossPos()
    {
        //
        // Disasemble & Code
        // 0x00B93E68: STP x29, x30, [sp, #-0x10]! | stack[1152921514475737936] = ???;  stack[1152921514475737944] = ???;  //  dest_result_addr=1152921514475737936 |  dest_result_addr=1152921514475737944
        // 0x00B93E6C: MOV x29, sp                | X29 = 1152921514475737936 (0x100000024C3B5350);//ML01
        // 0x00B93E70: SUB sp, sp, #0x10          | SP = (1152921514475737936 - 16) = 1152921514475737920 (0x100000024C3B5340);
        // 0x00B93E74: LDP s0, s1, [x0, #0x24]    | S0 = this._bossPos_x; //P2  S1 = this._bossPos_y; //P2  //  | 
        // 0x00B93E78: LDR s2, [x0, #0x2c]        | S2 = this._bossPos_z; //P2              
        // 0x00B93E7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93E80: MOV x0, sp                 | X0 = 1152921514475737920 (0x100000024C3B5340);//ML01
        // 0x00B93E84: STR wzr, [sp, #8]          | stack[1152921514475737928] = 0x0;        //  dest_result_addr=1152921514475737928
        // 0x00B93E88: STR xzr, [sp]              | stack[1152921514475737920] = 0x0;        //  dest_result_addr=1152921514475737920
        // 0x00B93E8C: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B93E90: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x00B93E94: LDR s2, [sp, #8]           | S2 = 0;                                 
        // 0x00B93E98: MOV sp, x29                | SP = 1152921514475737936 (0x100000024C3B5350);//ML01
        // 0x00B93E9C: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00B93EA0: RET                        |  return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93C64 (12139620), len: 8  VirtAddr: 0x00B93C64 RVA: 0x00B93C64 token: 100690124 methodIndex: 25216 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00B93C64: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00B93C68: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EBC (12140220), len: 8  VirtAddr: 0x00B93EBC RVA: 0x00B93EBC token: 100690125 methodIndex: 25217 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00B93EBC: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514475973968
        this._id = value;
        // 0x00B93EC0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93E50 (12140112), len: 8  VirtAddr: 0x00B93E50 RVA: 0x00B93E50 token: 100690126 methodIndex: 25218 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_trigerPos_x()
    {
        //
        // Disasemble & Code
        // 0x00B93E50: LDR s0, [x0, #0x14]        | S0 = this._trigerPos_x; //P2            
        // 0x00B93E54: RET                        |  return (System.Single)this._trigerPos_x;
        return this._trigerPos_x;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EC4 (12140228), len: 8  VirtAddr: 0x00B93EC4 RVA: 0x00B93EC4 token: 100690127 methodIndex: 25219 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_trigerPos_x(float value)
    {
        //
        // Disasemble & Code
        // 0x00B93EC4: STR s0, [x0, #0x14]        | this._trigerPos_x = value;               //  dest_result_addr=1152921514476197972
        this._trigerPos_x = value;
        // 0x00B93EC8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93E58 (12140120), len: 8  VirtAddr: 0x00B93E58 RVA: 0x00B93E58 token: 100690128 methodIndex: 25220 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_trigerPos_y()
    {
        //
        // Disasemble & Code
        // 0x00B93E58: LDR s0, [x0, #0x18]        | S0 = this._trigerPos_y; //P2            
        // 0x00B93E5C: RET                        |  return (System.Single)this._trigerPos_y;
        return this._trigerPos_y;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93ECC (12140236), len: 8  VirtAddr: 0x00B93ECC RVA: 0x00B93ECC token: 100690129 methodIndex: 25221 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_trigerPos_y(float value)
    {
        //
        // Disasemble & Code
        // 0x00B93ECC: STR s0, [x0, #0x18]        | this._trigerPos_y = value;               //  dest_result_addr=1152921514476421976
        this._trigerPos_y = value;
        // 0x00B93ED0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93E60 (12140128), len: 8  VirtAddr: 0x00B93E60 RVA: 0x00B93E60 token: 100690130 methodIndex: 25222 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_trigerPos_z()
    {
        //
        // Disasemble & Code
        // 0x00B93E60: LDR s0, [x0, #0x1c]        | S0 = this._trigerPos_z; //P2            
        // 0x00B93E64: RET                        |  return (System.Single)this._trigerPos_z;
        return this._trigerPos_z;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93ED4 (12140244), len: 8  VirtAddr: 0x00B93ED4 RVA: 0x00B93ED4 token: 100690131 methodIndex: 25223 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_trigerPos_z(float value)
    {
        //
        // Disasemble & Code
        // 0x00B93ED4: STR s0, [x0, #0x1c]        | this._trigerPos_z = value;               //  dest_result_addr=1152921514476645980
        this._trigerPos_z = value;
        // 0x00B93ED8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EDC (12140252), len: 8  VirtAddr: 0x00B93EDC RVA: 0x00B93EDC token: 100690132 methodIndex: 25224 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isBoss()
    {
        //
        // Disasemble & Code
        // 0x00B93EDC: LDR w0, [x0, #0x20]        | W0 = this._isBoss; //P2                 
        // 0x00B93EE0: RET                        |  return (System.Int32)this._isBoss;     
        return this._isBoss;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EE4 (12140260), len: 8  VirtAddr: 0x00B93EE4 RVA: 0x00B93EE4 token: 100690133 methodIndex: 25225 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isBoss(int value)
    {
        //
        // Disasemble & Code
        // 0x00B93EE4: STR w1, [x0, #0x20]        | this._isBoss = value;                    //  dest_result_addr=1152921514476869984
        this._isBoss = value;
        // 0x00B93EE8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EA4 (12140196), len: 8  VirtAddr: 0x00B93EA4 RVA: 0x00B93EA4 token: 100690134 methodIndex: 25226 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_bossPos_x()
    {
        //
        // Disasemble & Code
        // 0x00B93EA4: LDR s0, [x0, #0x24]        | S0 = this._bossPos_x; //P2              
        // 0x00B93EA8: RET                        |  return (System.Single)this._bossPos_x; 
        return this._bossPos_x;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EEC (12140268), len: 8  VirtAddr: 0x00B93EEC RVA: 0x00B93EEC token: 100690135 methodIndex: 25227 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_bossPos_x(float value)
    {
        //
        // Disasemble & Code
        // 0x00B93EEC: STR s0, [x0, #0x24]        | this._bossPos_x = value;                 //  dest_result_addr=1152921514477093988
        this._bossPos_x = value;
        // 0x00B93EF0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EAC (12140204), len: 8  VirtAddr: 0x00B93EAC RVA: 0x00B93EAC token: 100690136 methodIndex: 25228 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_bossPos_y()
    {
        //
        // Disasemble & Code
        // 0x00B93EAC: LDR s0, [x0, #0x28]        | S0 = this._bossPos_y; //P2              
        // 0x00B93EB0: RET                        |  return (System.Single)this._bossPos_y; 
        return this._bossPos_y;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EF4 (12140276), len: 8  VirtAddr: 0x00B93EF4 RVA: 0x00B93EF4 token: 100690137 methodIndex: 25229 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_bossPos_y(float value)
    {
        //
        // Disasemble & Code
        // 0x00B93EF4: STR s0, [x0, #0x28]        | this._bossPos_y = value;                 //  dest_result_addr=1152921514477317992
        this._bossPos_y = value;
        // 0x00B93EF8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EB4 (12140212), len: 8  VirtAddr: 0x00B93EB4 RVA: 0x00B93EB4 token: 100690138 methodIndex: 25230 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_bossPos_z()
    {
        //
        // Disasemble & Code
        // 0x00B93EB4: LDR s0, [x0, #0x2c]        | S0 = this._bossPos_z; //P2              
        // 0x00B93EB8: RET                        |  return (System.Single)this._bossPos_z; 
        return this._bossPos_z;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93EFC (12140284), len: 8  VirtAddr: 0x00B93EFC RVA: 0x00B93EFC token: 100690139 methodIndex: 25231 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_bossPos_z(float value)
    {
        //
        // Disasemble & Code
        // 0x00B93EFC: STR s0, [x0, #0x2c]        | this._bossPos_z = value;                 //  dest_result_addr=1152921514477541996
        this._bossPos_z = value;
        // 0x00B93F00: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93F04 (12140292), len: 8  VirtAddr: 0x00B93F04 RVA: 0x00B93F04 token: 100690140 methodIndex: 25232 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_bossRot_y()
    {
        //
        // Disasemble & Code
        // 0x00B93F04: LDR s0, [x0, #0x30]        | S0 = this._bossRot_y; //P2              
        // 0x00B93F08: RET                        |  return (System.Single)this._bossRot_y; 
        return this._bossRot_y;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93F0C (12140300), len: 8  VirtAddr: 0x00B93F0C RVA: 0x00B93F0C token: 100690141 methodIndex: 25233 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_bossRot_y(float value)
    {
        //
        // Disasemble & Code
        // 0x00B93F0C: STR s0, [x0, #0x30]        | this._bossRot_y = value;                 //  dest_result_addr=1152921514477766000
        this._bossRot_y = value;
        // 0x00B93F10: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93F14 (12140308), len: 8  VirtAddr: 0x00B93F14 RVA: 0x00B93F14 token: 100690142 methodIndex: 25234 delegateWrapperIndex: 0 methodInvoker: 0
    public System.Collections.Generic.List<AnimationPointJSC> get_camera()
    {
        //
        // Disasemble & Code
        // 0x00B93F14: LDR x0, [x0, #0x38]        | X0 = this._camera; //P2                 
        // 0x00B93F18: RET                        |  return (System.Collections.Generic.List<AnimationPointJSC>)this._camera;
        return this._camera;
        //  |  // // {name=val_0, type=System.Collections.Generic.List<AnimationPointJSC>, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93F1C (12140316), len: 8  VirtAddr: 0x00B93F1C RVA: 0x00B93F1C token: 100690143 methodIndex: 25235 delegateWrapperIndex: 0 methodInvoker: 0
    public System.Collections.Generic.List<AnimationPointJSC> get_boss()
    {
        //
        // Disasemble & Code
        // 0x00B93F1C: LDR x0, [x0, #0x40]        | X0 = this._boss; //P2                   
        // 0x00B93F20: RET                        |  return (System.Collections.Generic.List<AnimationPointJSC>)this._boss;
        return this._boss;
        //  |  // // {name=val_0, type=System.Collections.Generic.List<AnimationPointJSC>, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93F24 (12140324), len: 24  VirtAddr: 0x00B93F24 RVA: 0x00B93F24 token: 100690144 methodIndex: 25236 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00B93F24: ADD x8, x0, #0x48          | X8 = this.extensionObject;//AP2 res_addr=1152921514478118408
        // 0x00B93F28: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00B93F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00B93F30: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00B93F34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B93F38: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
