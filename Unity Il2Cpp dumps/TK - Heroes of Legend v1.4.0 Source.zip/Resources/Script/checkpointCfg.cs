using UnityEngine;
public class checkpointCfg : CsCfgBase
{
    // Fields
    public int id; //  0x00000010
    public int mapID; //  0x00000014
    public string name; //  0x00000018
    public string sceneName; //  0x00000020
    public int iconType; //  0x00000028
    public string LevelIcon; //  0x00000030
    public string localPos; //  0x00000038
    public int Hatred; //  0x00000040
    public int Super_Skill_Limit; //  0x00000044
    public int attack_effect; //  0x00000048
    public int workpoint; //  0x0000004C
    public string preloadUIID; //  0x00000050
    public int type; //  0x00000058
    public int panelType; //  0x0000005C
    public int finishType; //  0x00000060
    public int effect_nf; //  0x00000064
    public int ifAppear; //  0x00000068
    public int time; //  0x0000006C
    public int action; //  0x00000070
    public int exp; //  0x00000074
    public int heroExp; //  0x00000078
    public int copper; //  0x0000007C
    public int brushEnemy; //  0x00000080
    public int passType; //  0x00000084
    public int passValue; //  0x00000088
    public string loseValue; //  0x00000090
    public int passAnimation; //  0x00000098
    public float delayFinishTime; //  0x0000009C
    public string passCameraAnimation; //  0x000000A0
    public string npcArr; //  0x000000A8
    public string rewardArr; //  0x000000B0
    public int dropId; //  0x000000B8
    public int firsttimedrop; //  0x000000BC
    public int firsttimedropnum; //  0x000000C0
    public int sweep_lv; //  0x000000C4
    public string swipedrop; //  0x000000C8
    public string swipedropcount; //  0x000000D0
    public int hidestartext; //  0x000000D8
    public int gradeType1; //  0x000000DC
    public int gradeValue1; //  0x000000E0
    public string gradetext1; //  0x000000E8
    public string gradetext1_lose; //  0x000000F0
    public int gradeType2; //  0x000000F8
    public int gradeValue2; //  0x000000FC
    public string gradetext2; //  0x00000100
    public string gradetext2_lose; //  0x00000108
    public int gradeType3; //  0x00000110
    public int gradeValue3; //  0x00000114
    public string gradetext3; //  0x00000118
    public string gradetext3_lose; //  0x00000120
    public int Plot_off; //  0x00000128
    public int enterPlotId; //  0x0000012C
    public int passPlotId; //  0x00000130
    public string rewards; //  0x00000138
    public string des; //  0x00000140
    public int AI; //  0x00000148
    public int ifAuto; //  0x0000014C
    public int ifMotion; //  0x00000150
    public bool ifStartAuto; //  0x00000154
    public int Formation; //  0x00000158
    public int MusicID; //  0x0000015C
    public int bossAnimationId; //  0x00000160
    public float isCameraSlow; //  0x00000164
    public float Camera_distance; //  0x00000168
    public int camera_if_move; //  0x0000016C
    public bool isCameraAnimation; //  0x00000170
    public float Camera_distance_outattack; //  0x00000174
    public float Camera_alternate_time; //  0x00000178
    public int Camera_time; //  0x0000017C
    public string Camera_end; //  0x00000180
    public float Camera_rx; //  0x00000188
    public int Camera_rx__outattack; //  0x0000018C
    public float Camera_ry; //  0x00000190
    public float Camera_posDamping; //  0x00000194
    public float Camera_MoveMax; //  0x00000198
    public float Camera_waittime; //  0x0000019C
    public bool Camera_disMove; //  0x000001A0
    public bool IsExtryHero; //  0x000001A1
    public string hero_Pos; //  0x000001A8
    public float hero_Px; //  0x000001B0
    public string moster_Pos; //  0x000001B8
    public float moster_Px; //  0x000001C0
    public int friendNpc; //  0x000001C4
    public int power; //  0x000001C8
    public int maxSweepCount; //  0x000001CC
    public int maxCopper; //  0x000001D0
    public int need_checkpoint_id; //  0x000001D4
    public int need_normal_checkpoint_id; //  0x000001D8
    public int need_role_level; //  0x000001DC
    public int bigType; //  0x000001E0
    public bool isAutoCreatNpc; //  0x000001E4
    public int bossId; //  0x000001E8
    public int isSpeedup; //  0x000001EC
    public string largeTip; //  0x000001F0
    public int isTop; //  0x000001F8
    public int monsterwavecount; //  0x000001FC
    public int islvrepress; //  0x00000200
    public bool isShowNew; //  0x00000204
    public int loc1_anger; //  0x00000208
    public int loc2_anger; //  0x0000020C
    public int loc3_anger; //  0x00000210
    public int loc4_anger; //  0x00000214
    public int boxID; //  0x00000218
    public string treasure_pos; //  0x00000220
    public bool is_superskill_prompt; //  0x00000228
    public bool ifUseHint; //  0x00000229
    public string hintText; //  0x00000230
    public int guide_or_not; //  0x00000238
    public int chapter_id; //  0x0000023C
    public int energy_rate; //  0x00000240
    public float wait_time; //  0x00000244
    public int item_id; //  0x00000248
    public int is_time_not; //  0x0000024C
    public string camera_limit; //  0x00000250
    public int layer; //  0x00000258
    public bool Is_Lead_skill; //  0x0000025C
    public bool Is_relief; //  0x0000025D
    public bool Is_close; //  0x0000025E
    public int child_type; //  0x00000260
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D8235C (14164828), len: 8  VirtAddr: 0x00D8235C RVA: 0x00D8235C token: 100690514 methodIndex: 25968 delegateWrapperIndex: 0 methodInvoker: 0
    public checkpointCfg()
    {
        //
        // Disasemble & Code
        // 0x00D8235C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D82360: B #0xb46154                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D82364 (14164836), len: 8336  VirtAddr: 0x00D82364 RVA: 0x00D82364 token: 100690515 methodIndex: 25969 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Init(System.Collections.Generic.Dictionary<string, string> _info)
    {
        //
        // Disasemble & Code
        // 0x00D82364: STP x22, x21, [sp, #-0x30]! | stack[1152921514531366784] = ???;  stack[1152921514531366792] = ???;  //  dest_result_addr=1152921514531366784 |  dest_result_addr=1152921514531366792
        // 0x00D82368: STP x20, x19, [sp, #0x10]  | stack[1152921514531366800] = ???;  stack[1152921514531366808] = ???;  //  dest_result_addr=1152921514531366800 |  dest_result_addr=1152921514531366808
        // 0x00D8236C: STP x29, x30, [sp, #0x20]  | stack[1152921514531366816] = ???;  stack[1152921514531366824] = ???;  //  dest_result_addr=1152921514531366816 |  dest_result_addr=1152921514531366824
        // 0x00D82370: ADD x29, sp, #0x20         | X29 = (1152921514531366784 + 32) = 1152921514531366816 (0x100000024F8C27A0);
        // 0x00D82374: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D82378: LDRB w8, [x21, #0x42e]     | W8 = (bool)static_value_0373442E;       
        // 0x00D8237C: MOV x20, x1                | X20 = _info;//m1                        
        // 0x00D82380: MOV x19, x0                | X19 = 1152921514531378832 (0x100000024F8C5690);//ML01
        // 0x00D82384: TBNZ w8, #0, #0xd823a0     | if (static_value_0373442E == true) goto label_0;
        // 0x00D82388: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
        // 0x00D8238C: LDR x8, [x8, #0x238]       | X8 = 0x2B90A6C;                         
        // 0x00D82390: LDR w0, [x8]               | W0 = 0x195F;                            
        // 0x00D82394: BL #0x2782188              | X0 = sub_2782188( ?? 0x195F, ????);     
        // 0x00D82398: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D8239C: STRB w8, [x21, #0x42e]     | static_value_0373442E = true;            //  dest_result_addr=57885742
        label_0:
        // 0x00D823A0: CBNZ x20, #0xd823a8        | if (_info != null) goto label_1;        
        if(_info != null)
        {
            goto label_1;
        }
        // 0x00D823A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x195F, ????);     
        label_1:
        // 0x00D823A8: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00D823AC: ADRP x22, #0x3667000       | X22 = 57044992 (0x3667000);             
        // 0x00D823B0: LDR x8, [x8, #0xf28]       | X8 = (string**)(1152921510122275760)("id");
        // 0x00D823B4: LDR x22, [x22, #0x90]      | X22 = 1152921510817398768;              
        // 0x00D823B8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D823BC: LDR x1, [x8]               | X1 = "id";                              
        // 0x00D823C0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D823C4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "id");        
        string val_1 = _info.Item["id"];
        // 0x00D823C8: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00D823CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D823D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D823D4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_2 = System.Int32.Parse(s:  0);
        // 0x00D823D8: STR w0, [x19, #0x10]       | this.id = val_2;                         //  dest_result_addr=1152921514531378848
        this.id = val_2;
        // 0x00D823DC: CBZ x20, #0xd82410         | if (_info == null) goto label_2;        
        if(_info == null)
        {
            goto label_2;
        }
        // 0x00D823E0: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x00D823E4: LDR x8, [x8, #0x690]       | X8 = (string**)(1152921510122277888)("mapID");
        // 0x00D823E8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D823EC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D823F0: LDR x1, [x8]               | X1 = "mapID";                           
        // 0x00D823F4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "mapID");     
        string val_3 = _info.Item["mapID"];
        // 0x00D823F8: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00D823FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82400: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82404: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_4 = System.Int32.Parse(s:  0);
        // 0x00D82408: STR w0, [x19, #0x14]       | this.mapID = val_4;                      //  dest_result_addr=1152921514531378852
        this.mapID = val_4;
        // 0x00D8240C: B #0xd82444                |  goto label_3;                          
        goto label_3;
        label_2:
        // 0x00D82410: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00D82414: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x00D82418: LDR x8, [x8, #0x690]       | X8 = (string**)(1152921510122277888)("mapID");
        // 0x00D8241C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82420: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82424: LDR x1, [x8]               | X1 = "mapID";                           
        // 0x00D82428: BL #0x23fc26c              | X0 = _info.get_Item(key:  "mapID");     
        string val_5 = _info.Item["mapID"];
        // 0x00D8242C: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x00D82430: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82434: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82438: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_6 = System.Int32.Parse(s:  0);
        // 0x00D8243C: STR w0, [x19, #0x14]       | this.mapID = val_6;                      //  dest_result_addr=1152921514531378852
        this.mapID = val_6;
        // 0x00D82440: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_3:
        // 0x00D82444: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00D82448: LDR x8, [x8, #0x5f0]       | X8 = (string**)(1152921509593945888)("name");
        // 0x00D8244C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82450: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82454: LDR x1, [x8]               | X1 = "name";                            
        // 0x00D82458: BL #0x23fc26c              | X0 = _info.get_Item(key:  "name");      
        string val_7 = _info.Item["name"];
        // 0x00D8245C: STR x0, [x19, #0x18]       | this.name = val_7;                       //  dest_result_addr=1152921514531378856
        this.name = val_7;
        // 0x00D82460: CBZ x20, #0xd82484         | if (_info == null) goto label_4;        
        if(_info == null)
        {
            goto label_4;
        }
        // 0x00D82464: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00D82468: LDR x8, [x8, #0x1a0]       | X8 = (string**)(1152921510122282064)("sceneName");
        // 0x00D8246C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82470: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82474: LDR x1, [x8]               | X1 = "sceneName";                       
        // 0x00D82478: BL #0x23fc26c              | X0 = _info.get_Item(key:  "sceneName"); 
        string val_8 = _info.Item["sceneName"];
        // 0x00D8247C: STR x0, [x19, #0x20]       | this.sceneName = val_8;                  //  dest_result_addr=1152921514531378864
        this.sceneName = val_8;
        // 0x00D82480: B #0xd824a8                |  goto label_5;                          
        goto label_5;
        label_4:
        // 0x00D82484: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        // 0x00D82488: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00D8248C: LDR x8, [x8, #0x1a0]       | X8 = (string**)(1152921510122282064)("sceneName");
        // 0x00D82490: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82494: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82498: LDR x1, [x8]               | X1 = "sceneName";                       
        // 0x00D8249C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "sceneName"); 
        string val_9 = _info.Item["sceneName"];
        // 0x00D824A0: STR x0, [x19, #0x20]       | this.sceneName = val_9;                  //  dest_result_addr=1152921514531378864
        this.sceneName = val_9;
        // 0x00D824A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_5:
        // 0x00D824A8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
        // 0x00D824AC: LDR x8, [x8, #0x860]       | X8 = (string**)(1152921510122284208)("iconType");
        // 0x00D824B0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D824B4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D824B8: LDR x1, [x8]               | X1 = "iconType";                        
        // 0x00D824BC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "iconType");  
        string val_10 = _info.Item["iconType"];
        // 0x00D824C0: MOV x1, x0                 | X1 = val_10;//m1                        
        // 0x00D824C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D824C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D824CC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_11 = System.Int32.Parse(s:  0);
        // 0x00D824D0: STR w0, [x19, #0x28]       | this.iconType = val_11;                  //  dest_result_addr=1152921514531378872
        this.iconType = val_11;
        // 0x00D824D4: CBZ x20, #0xd824f8         | if (_info == null) goto label_6;        
        if(_info == null)
        {
            goto label_6;
        }
        // 0x00D824D8: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00D824DC: LDR x8, [x8, #0x848]       | X8 = (string**)(1152921510122286352)("LevelIcon");
        // 0x00D824E0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D824E4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D824E8: LDR x1, [x8]               | X1 = "LevelIcon";                       
        // 0x00D824EC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "LevelIcon"); 
        string val_12 = _info.Item["LevelIcon"];
        // 0x00D824F0: STR x0, [x19, #0x30]       | this.LevelIcon = val_12;                 //  dest_result_addr=1152921514531378880
        this.LevelIcon = val_12;
        // 0x00D824F4: B #0xd8251c                |  goto label_7;                          
        goto label_7;
        label_6:
        // 0x00D824F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        // 0x00D824FC: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00D82500: LDR x8, [x8, #0x848]       | X8 = (string**)(1152921510122286352)("LevelIcon");
        // 0x00D82504: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82508: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8250C: LDR x1, [x8]               | X1 = "LevelIcon";                       
        // 0x00D82510: BL #0x23fc26c              | X0 = _info.get_Item(key:  "LevelIcon"); 
        string val_13 = _info.Item["LevelIcon"];
        // 0x00D82514: STR x0, [x19, #0x30]       | this.LevelIcon = val_13;                 //  dest_result_addr=1152921514531378880
        this.LevelIcon = val_13;
        // 0x00D82518: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_7:
        // 0x00D8251C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00D82520: LDR x8, [x8, #0xa00]       | X8 = (string**)(1152921510122288496)("localPos");
        // 0x00D82524: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82528: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8252C: LDR x1, [x8]               | X1 = "localPos";                        
        // 0x00D82530: BL #0x23fc26c              | X0 = _info.get_Item(key:  "localPos");  
        string val_14 = _info.Item["localPos"];
        // 0x00D82534: STR x0, [x19, #0x38]       | this.localPos = val_14;                  //  dest_result_addr=1152921514531378888
        this.localPos = val_14;
        // 0x00D82538: CBZ x20, #0xd8256c         | if (_info == null) goto label_8;        
        if(_info == null)
        {
            goto label_8;
        }
        // 0x00D8253C: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
        // 0x00D82540: LDR x8, [x8, #0x640]       | X8 = (string**)(1152921510122290640)("Hatred");
        // 0x00D82544: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82548: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8254C: LDR x1, [x8]               | X1 = "Hatred";                          
        // 0x00D82550: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Hatred");    
        string val_15 = _info.Item["Hatred"];
        // 0x00D82554: MOV x1, x0                 | X1 = val_15;//m1                        
        // 0x00D82558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8255C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82560: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_16 = System.Int32.Parse(s:  0);
        // 0x00D82564: STR w0, [x19, #0x40]       | this.Hatred = val_16;                    //  dest_result_addr=1152921514531378896
        this.Hatred = val_16;
        // 0x00D82568: B #0xd825a0                |  goto label_9;                          
        goto label_9;
        label_8:
        // 0x00D8256C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        // 0x00D82570: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
        // 0x00D82574: LDR x8, [x8, #0x640]       | X8 = (string**)(1152921510122290640)("Hatred");
        // 0x00D82578: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8257C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82580: LDR x1, [x8]               | X1 = "Hatred";                          
        // 0x00D82584: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Hatred");    
        string val_17 = _info.Item["Hatred"];
        // 0x00D82588: MOV x1, x0                 | X1 = val_17;//m1                        
        // 0x00D8258C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82590: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82594: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_18 = System.Int32.Parse(s:  0);
        // 0x00D82598: STR w0, [x19, #0x40]       | this.Hatred = val_18;                    //  dest_result_addr=1152921514531378896
        this.Hatred = val_18;
        // 0x00D8259C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_9:
        // 0x00D825A0: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00D825A4: LDR x8, [x8, #0x378]       | X8 = (string**)(1152921510122292768)("Super_Skill_Limit");
        // 0x00D825A8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D825AC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D825B0: LDR x1, [x8]               | X1 = "Super_Skill_Limit";               
        // 0x00D825B4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Super_Skill_Limit");
        string val_19 = _info.Item["Super_Skill_Limit"];
        // 0x00D825B8: MOV x1, x0                 | X1 = val_19;//m1                        
        // 0x00D825BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D825C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D825C4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_20 = System.Int32.Parse(s:  0);
        // 0x00D825C8: STR w0, [x19, #0x44]       | this.Super_Skill_Limit = val_20;         //  dest_result_addr=1152921514531378900
        this.Super_Skill_Limit = val_20;
        // 0x00D825CC: CBZ x20, #0xd82600         | if (_info == null) goto label_10;       
        if(_info == null)
        {
            goto label_10;
        }
        // 0x00D825D0: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
        // 0x00D825D4: LDR x8, [x8, #0xdd8]       | X8 = (string**)(1152921510122294928)("attack_effect");
        // 0x00D825D8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D825DC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D825E0: LDR x1, [x8]               | X1 = "attack_effect";                   
        // 0x00D825E4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "attack_effect");
        string val_21 = _info.Item["attack_effect"];
        // 0x00D825E8: MOV x1, x0                 | X1 = val_21;//m1                        
        // 0x00D825EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D825F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D825F4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_22 = System.Int32.Parse(s:  0);
        // 0x00D825F8: STR w0, [x19, #0x48]       | this.attack_effect = val_22;             //  dest_result_addr=1152921514531378904
        this.attack_effect = val_22;
        // 0x00D825FC: B #0xd82634                |  goto label_11;                         
        goto label_11;
        label_10:
        // 0x00D82600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        // 0x00D82604: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
        // 0x00D82608: LDR x8, [x8, #0xdd8]       | X8 = (string**)(1152921510122294928)("attack_effect");
        // 0x00D8260C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82610: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82614: LDR x1, [x8]               | X1 = "attack_effect";                   
        // 0x00D82618: BL #0x23fc26c              | X0 = _info.get_Item(key:  "attack_effect");
        string val_23 = _info.Item["attack_effect"];
        // 0x00D8261C: MOV x1, x0                 | X1 = val_23;//m1                        
        // 0x00D82620: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82624: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82628: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_24 = System.Int32.Parse(s:  0);
        // 0x00D8262C: STR w0, [x19, #0x48]       | this.attack_effect = val_24;             //  dest_result_addr=1152921514531378904
        this.attack_effect = val_24;
        // 0x00D82630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_11:
        // 0x00D82634: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00D82638: LDR x8, [x8, #0x1e0]       | X8 = (string**)(1152921510122297072)("workpoint");
        // 0x00D8263C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82640: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82644: LDR x1, [x8]               | X1 = "workpoint";                       
        // 0x00D82648: BL #0x23fc26c              | X0 = _info.get_Item(key:  "workpoint"); 
        string val_25 = _info.Item["workpoint"];
        // 0x00D8264C: MOV x1, x0                 | X1 = val_25;//m1                        
        // 0x00D82650: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82654: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82658: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_26 = System.Int32.Parse(s:  0);
        // 0x00D8265C: STR w0, [x19, #0x4c]       | this.workpoint = val_26;                 //  dest_result_addr=1152921514531378908
        this.workpoint = val_26;
        // 0x00D82660: CBZ x20, #0xd82684         | if (_info == null) goto label_12;       
        if(_info == null)
        {
            goto label_12;
        }
        // 0x00D82664: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00D82668: LDR x8, [x8, #0x3d8]       | X8 = (string**)(1152921510122299216)("preloadUIID");
        // 0x00D8266C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82670: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82674: LDR x1, [x8]               | X1 = "preloadUIID";                     
        // 0x00D82678: BL #0x23fc26c              | X0 = _info.get_Item(key:  "preloadUIID");
        string val_27 = _info.Item["preloadUIID"];
        // 0x00D8267C: STR x0, [x19, #0x50]       | this.preloadUIID = val_27;               //  dest_result_addr=1152921514531378912
        this.preloadUIID = val_27;
        // 0x00D82680: B #0xd826a8                |  goto label_13;                         
        goto label_13;
        label_12:
        // 0x00D82684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        // 0x00D82688: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00D8268C: LDR x8, [x8, #0x3d8]       | X8 = (string**)(1152921510122299216)("preloadUIID");
        // 0x00D82690: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82694: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82698: LDR x1, [x8]               | X1 = "preloadUIID";                     
        // 0x00D8269C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "preloadUIID");
        string val_28 = _info.Item["preloadUIID"];
        // 0x00D826A0: STR x0, [x19, #0x50]       | this.preloadUIID = val_28;               //  dest_result_addr=1152921514531378912
        this.preloadUIID = val_28;
        // 0x00D826A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_13:
        // 0x00D826A8: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00D826AC: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921510122301360)("type");
        // 0x00D826B0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D826B4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D826B8: LDR x1, [x8]               | X1 = "type";                            
        // 0x00D826BC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "type");      
        string val_29 = _info.Item["type"];
        // 0x00D826C0: MOV x1, x0                 | X1 = val_29;//m1                        
        // 0x00D826C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D826C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D826CC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_30 = System.Int32.Parse(s:  0);
        // 0x00D826D0: STR w0, [x19, #0x58]       | this.type = val_30;                      //  dest_result_addr=1152921514531378920
        this.type = val_30;
        // 0x00D826D4: CBZ x20, #0xd82708         | if (_info == null) goto label_14;       
        if(_info == null)
        {
            goto label_14;
        }
        // 0x00D826D8: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00D826DC: LDR x8, [x8, #0x1c8]       | X8 = (string**)(1152921510122303488)("panelType");
        // 0x00D826E0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D826E4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D826E8: LDR x1, [x8]               | X1 = "panelType";                       
        // 0x00D826EC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "panelType"); 
        string val_31 = _info.Item["panelType"];
        // 0x00D826F0: MOV x1, x0                 | X1 = val_31;//m1                        
        // 0x00D826F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D826F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D826FC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_32 = System.Int32.Parse(s:  0);
        // 0x00D82700: STR w0, [x19, #0x5c]       | this.panelType = val_32;                 //  dest_result_addr=1152921514531378924
        this.panelType = val_32;
        // 0x00D82704: B #0xd8273c                |  goto label_15;                         
        goto label_15;
        label_14:
        // 0x00D82708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        // 0x00D8270C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00D82710: LDR x8, [x8, #0x1c8]       | X8 = (string**)(1152921510122303488)("panelType");
        // 0x00D82714: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82718: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8271C: LDR x1, [x8]               | X1 = "panelType";                       
        // 0x00D82720: BL #0x23fc26c              | X0 = _info.get_Item(key:  "panelType"); 
        string val_33 = _info.Item["panelType"];
        // 0x00D82724: MOV x1, x0                 | X1 = val_33;//m1                        
        // 0x00D82728: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8272C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82730: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_34 = System.Int32.Parse(s:  0);
        // 0x00D82734: STR w0, [x19, #0x5c]       | this.panelType = val_34;                 //  dest_result_addr=1152921514531378924
        this.panelType = val_34;
        // 0x00D82738: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_15:
        // 0x00D8273C: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
        // 0x00D82740: LDR x8, [x8, #0xe0]        | X8 = (string**)(1152921510122305632)("finishType");
        // 0x00D82744: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82748: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8274C: LDR x1, [x8]               | X1 = "finishType";                      
        // 0x00D82750: BL #0x23fc26c              | X0 = _info.get_Item(key:  "finishType");
        string val_35 = _info.Item["finishType"];
        // 0x00D82754: MOV x1, x0                 | X1 = val_35;//m1                        
        // 0x00D82758: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8275C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82760: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_36 = System.Int32.Parse(s:  0);
        // 0x00D82764: STR w0, [x19, #0x60]       | this.finishType = val_36;                //  dest_result_addr=1152921514531378928
        this.finishType = val_36;
        // 0x00D82768: CBZ x20, #0xd8279c         | if (_info == null) goto label_16;       
        if(_info == null)
        {
            goto label_16;
        }
        // 0x00D8276C: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00D82770: LDR x8, [x8, #0x1a0]       | X8 = (string**)(1152921510122307776)("effect_nf");
        // 0x00D82774: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82778: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8277C: LDR x1, [x8]               | X1 = "effect_nf";                       
        // 0x00D82780: BL #0x23fc26c              | X0 = _info.get_Item(key:  "effect_nf"); 
        string val_37 = _info.Item["effect_nf"];
        // 0x00D82784: MOV x1, x0                 | X1 = val_37;//m1                        
        // 0x00D82788: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8278C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82790: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_38 = System.Int32.Parse(s:  0);
        // 0x00D82794: STR w0, [x19, #0x64]       | this.effect_nf = val_38;                 //  dest_result_addr=1152921514531378932
        this.effect_nf = val_38;
        // 0x00D82798: B #0xd827d0                |  goto label_17;                         
        goto label_17;
        label_16:
        // 0x00D8279C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        // 0x00D827A0: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00D827A4: LDR x8, [x8, #0x1a0]       | X8 = (string**)(1152921510122307776)("effect_nf");
        // 0x00D827A8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D827AC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D827B0: LDR x1, [x8]               | X1 = "effect_nf";                       
        // 0x00D827B4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "effect_nf"); 
        string val_39 = _info.Item["effect_nf"];
        // 0x00D827B8: MOV x1, x0                 | X1 = val_39;//m1                        
        // 0x00D827BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D827C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D827C4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_40 = System.Int32.Parse(s:  0);
        // 0x00D827C8: STR w0, [x19, #0x64]       | this.effect_nf = val_40;                 //  dest_result_addr=1152921514531378932
        this.effect_nf = val_40;
        // 0x00D827CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_17:
        // 0x00D827D0: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00D827D4: LDR x8, [x8, #0x280]       | X8 = (string**)(1152921510122309920)("ifAppear");
        // 0x00D827D8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D827DC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D827E0: LDR x1, [x8]               | X1 = "ifAppear";                        
        // 0x00D827E4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "ifAppear");  
        string val_41 = _info.Item["ifAppear"];
        // 0x00D827E8: MOV x1, x0                 | X1 = val_41;//m1                        
        // 0x00D827EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D827F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D827F4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_42 = System.Int32.Parse(s:  0);
        // 0x00D827F8: STR w0, [x19, #0x68]       | this.ifAppear = val_42;                  //  dest_result_addr=1152921514531378936
        this.ifAppear = val_42;
        // 0x00D827FC: CBZ x20, #0xd82830         | if (_info == null) goto label_18;       
        if(_info == null)
        {
            goto label_18;
        }
        // 0x00D82800: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00D82804: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921510122312064)("time");
        // 0x00D82808: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8280C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82810: LDR x1, [x8]               | X1 = "time";                            
        // 0x00D82814: BL #0x23fc26c              | X0 = _info.get_Item(key:  "time");      
        string val_43 = _info.Item["time"];
        // 0x00D82818: MOV x1, x0                 | X1 = val_43;//m1                        
        // 0x00D8281C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82820: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82824: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_44 = System.Int32.Parse(s:  0);
        // 0x00D82828: STR w0, [x19, #0x6c]       | this.time = val_44;                      //  dest_result_addr=1152921514531378940
        this.time = val_44;
        // 0x00D8282C: B #0xd82864                |  goto label_19;                         
        goto label_19;
        label_18:
        // 0x00D82830: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
        // 0x00D82834: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00D82838: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921510122312064)("time");
        // 0x00D8283C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82840: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82844: LDR x1, [x8]               | X1 = "time";                            
        // 0x00D82848: BL #0x23fc26c              | X0 = _info.get_Item(key:  "time");      
        string val_45 = _info.Item["time"];
        // 0x00D8284C: MOV x1, x0                 | X1 = val_45;//m1                        
        // 0x00D82850: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82854: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82858: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_46 = System.Int32.Parse(s:  0);
        // 0x00D8285C: STR w0, [x19, #0x6c]       | this.time = val_46;                      //  dest_result_addr=1152921514531378940
        this.time = val_46;
        // 0x00D82860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
        label_19:
        // 0x00D82864: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00D82868: LDR x8, [x8, #0xe58]       | X8 = (string**)(1152921510122314192)("action");
        // 0x00D8286C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82870: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82874: LDR x1, [x8]               | X1 = "action";                          
        // 0x00D82878: BL #0x23fc26c              | X0 = _info.get_Item(key:  "action");    
        string val_47 = _info.Item["action"];
        // 0x00D8287C: MOV x1, x0                 | X1 = val_47;//m1                        
        // 0x00D82880: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82884: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82888: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_48 = System.Int32.Parse(s:  0);
        // 0x00D8288C: STR w0, [x19, #0x70]       | this.action = val_48;                    //  dest_result_addr=1152921514531378944
        this.action = val_48;
        // 0x00D82890: CBZ x20, #0xd828c4         | if (_info == null) goto label_20;       
        if(_info == null)
        {
            goto label_20;
        }
        // 0x00D82894: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00D82898: LDR x8, [x8, #0xe58]       | X8 = (string**)(1152921510122316320)("exp");
        // 0x00D8289C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D828A0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D828A4: LDR x1, [x8]               | X1 = "exp";                             
        // 0x00D828A8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "exp");       
        string val_49 = _info.Item["exp"];
        // 0x00D828AC: MOV x1, x0                 | X1 = val_49;//m1                        
        // 0x00D828B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D828B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D828B8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_50 = System.Int32.Parse(s:  0);
        // 0x00D828BC: STR w0, [x19, #0x74]       | this.exp = val_50;                       //  dest_result_addr=1152921514531378948
        this.exp = val_50;
        // 0x00D828C0: B #0xd828f8                |  goto label_21;                         
        goto label_21;
        label_20:
        // 0x00D828C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        // 0x00D828C8: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00D828CC: LDR x8, [x8, #0xe58]       | X8 = (string**)(1152921510122316320)("exp");
        // 0x00D828D0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D828D4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D828D8: LDR x1, [x8]               | X1 = "exp";                             
        // 0x00D828DC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "exp");       
        string val_51 = _info.Item["exp"];
        // 0x00D828E0: MOV x1, x0                 | X1 = val_51;//m1                        
        // 0x00D828E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D828E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D828EC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_52 = System.Int32.Parse(s:  0);
        // 0x00D828F0: STR w0, [x19, #0x74]       | this.exp = val_52;                       //  dest_result_addr=1152921514531378948
        this.exp = val_52;
        // 0x00D828F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
        label_21:
        // 0x00D828F8: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00D828FC: LDR x8, [x8, #0x228]       | X8 = (string**)(1152921510122318448)("heroExp");
        // 0x00D82900: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82904: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82908: LDR x1, [x8]               | X1 = "heroExp";                         
        // 0x00D8290C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "heroExp");   
        string val_53 = _info.Item["heroExp"];
        // 0x00D82910: MOV x1, x0                 | X1 = val_53;//m1                        
        // 0x00D82914: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82918: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8291C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_54 = System.Int32.Parse(s:  0);
        // 0x00D82920: STR w0, [x19, #0x78]       | this.heroExp = val_54;                   //  dest_result_addr=1152921514531378952
        this.heroExp = val_54;
        // 0x00D82924: CBZ x20, #0xd82958         | if (_info == null) goto label_22;       
        if(_info == null)
        {
            goto label_22;
        }
        // 0x00D82928: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
        // 0x00D8292C: LDR x8, [x8, #0x720]       | X8 = (string**)(1152921510122320592)("copper");
        // 0x00D82930: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82934: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82938: LDR x1, [x8]               | X1 = "copper";                          
        // 0x00D8293C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "copper");    
        string val_55 = _info.Item["copper"];
        // 0x00D82940: MOV x1, x0                 | X1 = val_55;//m1                        
        // 0x00D82944: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82948: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8294C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_56 = System.Int32.Parse(s:  0);
        // 0x00D82950: STR w0, [x19, #0x7c]       | this.copper = val_56;                    //  dest_result_addr=1152921514531378956
        this.copper = val_56;
        // 0x00D82954: B #0xd8298c                |  goto label_23;                         
        goto label_23;
        label_22:
        // 0x00D82958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_54, ????);     
        // 0x00D8295C: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
        // 0x00D82960: LDR x8, [x8, #0x720]       | X8 = (string**)(1152921510122320592)("copper");
        // 0x00D82964: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82968: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8296C: LDR x1, [x8]               | X1 = "copper";                          
        // 0x00D82970: BL #0x23fc26c              | X0 = _info.get_Item(key:  "copper");    
        string val_57 = _info.Item["copper"];
        // 0x00D82974: MOV x1, x0                 | X1 = val_57;//m1                        
        // 0x00D82978: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8297C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82980: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_58 = System.Int32.Parse(s:  0);
        // 0x00D82984: STR w0, [x19, #0x7c]       | this.copper = val_58;                    //  dest_result_addr=1152921514531378956
        this.copper = val_58;
        // 0x00D82988: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_23:
        // 0x00D8298C: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00D82990: LDR x8, [x8, #0x110]       | X8 = (string**)(1152921510122322720)("brushEnemy");
        // 0x00D82994: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82998: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8299C: LDR x1, [x8]               | X1 = "brushEnemy";                      
        // 0x00D829A0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "brushEnemy");
        string val_59 = _info.Item["brushEnemy"];
        // 0x00D829A4: MOV x1, x0                 | X1 = val_59;//m1                        
        // 0x00D829A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D829AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D829B0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_60 = System.Int32.Parse(s:  0);
        // 0x00D829B4: STR w0, [x19, #0x80]       | this.brushEnemy = val_60;                //  dest_result_addr=1152921514531378960
        this.brushEnemy = val_60;
        // 0x00D829B8: CBZ x20, #0xd829ec         | if (_info == null) goto label_24;       
        if(_info == null)
        {
            goto label_24;
        }
        // 0x00D829BC: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00D829C0: LDR x8, [x8, #0xbe8]       | X8 = (string**)(1152921510122324864)("passType");
        // 0x00D829C4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D829C8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D829CC: LDR x1, [x8]               | X1 = "passType";                        
        // 0x00D829D0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "passType");  
        string val_61 = _info.Item["passType"];
        // 0x00D829D4: MOV x1, x0                 | X1 = val_61;//m1                        
        // 0x00D829D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D829DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D829E0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_62 = System.Int32.Parse(s:  0);
        // 0x00D829E4: STR w0, [x19, #0x84]       | this.passType = val_62;                  //  dest_result_addr=1152921514531378964
        this.passType = val_62;
        // 0x00D829E8: B #0xd82a20                |  goto label_25;                         
        goto label_25;
        label_24:
        // 0x00D829EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_60, ????);     
        // 0x00D829F0: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00D829F4: LDR x8, [x8, #0xbe8]       | X8 = (string**)(1152921510122324864)("passType");
        // 0x00D829F8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D829FC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82A00: LDR x1, [x8]               | X1 = "passType";                        
        // 0x00D82A04: BL #0x23fc26c              | X0 = _info.get_Item(key:  "passType");  
        string val_63 = _info.Item["passType"];
        // 0x00D82A08: MOV x1, x0                 | X1 = val_63;//m1                        
        // 0x00D82A0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82A10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82A14: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_64 = System.Int32.Parse(s:  0);
        // 0x00D82A18: STR w0, [x19, #0x84]       | this.passType = val_64;                  //  dest_result_addr=1152921514531378964
        this.passType = val_64;
        // 0x00D82A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
        label_25:
        // 0x00D82A20: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00D82A24: LDR x8, [x8, #0x548]       | X8 = (string**)(1152921510122327008)("passValue");
        // 0x00D82A28: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82A2C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82A30: LDR x1, [x8]               | X1 = "passValue";                       
        // 0x00D82A34: BL #0x23fc26c              | X0 = _info.get_Item(key:  "passValue"); 
        string val_65 = _info.Item["passValue"];
        // 0x00D82A38: MOV x1, x0                 | X1 = val_65;//m1                        
        // 0x00D82A3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82A40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82A44: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_66 = System.Int32.Parse(s:  0);
        // 0x00D82A48: STR w0, [x19, #0x88]       | this.passValue = val_66;                 //  dest_result_addr=1152921514531378968
        this.passValue = val_66;
        // 0x00D82A4C: CBZ x20, #0xd82a70         | if (_info == null) goto label_26;       
        if(_info == null)
        {
            goto label_26;
        }
        // 0x00D82A50: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00D82A54: LDR x8, [x8, #0x9d0]       | X8 = (string**)(1152921510122329152)("loseValue");
        // 0x00D82A58: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82A5C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82A60: LDR x1, [x8]               | X1 = "loseValue";                       
        // 0x00D82A64: BL #0x23fc26c              | X0 = _info.get_Item(key:  "loseValue"); 
        string val_67 = _info.Item["loseValue"];
        // 0x00D82A68: STR x0, [x19, #0x90]       | this.loseValue = val_67;                 //  dest_result_addr=1152921514531378976
        this.loseValue = val_67;
        // 0x00D82A6C: B #0xd82a94                |  goto label_27;                         
        goto label_27;
        label_26:
        // 0x00D82A70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_66, ????);     
        // 0x00D82A74: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00D82A78: LDR x8, [x8, #0x9d0]       | X8 = (string**)(1152921510122329152)("loseValue");
        // 0x00D82A7C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82A80: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82A84: LDR x1, [x8]               | X1 = "loseValue";                       
        // 0x00D82A88: BL #0x23fc26c              | X0 = _info.get_Item(key:  "loseValue"); 
        string val_68 = _info.Item["loseValue"];
        // 0x00D82A8C: STR x0, [x19, #0x90]       | this.loseValue = val_68;                 //  dest_result_addr=1152921514531378976
        this.loseValue = val_68;
        // 0x00D82A90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_68, ????);     
        label_27:
        // 0x00D82A94: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00D82A98: LDR x8, [x8, #0x780]       | X8 = (string**)(1152921510122331296)("passAnimation");
        // 0x00D82A9C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82AA0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82AA4: LDR x1, [x8]               | X1 = "passAnimation";                   
        // 0x00D82AA8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "passAnimation");
        string val_69 = _info.Item["passAnimation"];
        // 0x00D82AAC: MOV x1, x0                 | X1 = val_69;//m1                        
        // 0x00D82AB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82AB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82AB8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_70 = System.Int32.Parse(s:  0);
        // 0x00D82ABC: STR w0, [x19, #0x98]       | this.passAnimation = val_70;             //  dest_result_addr=1152921514531378984
        this.passAnimation = val_70;
        // 0x00D82AC0: CBZ x20, #0xd82af4         | if (_info == null) goto label_28;       
        if(_info == null)
        {
            goto label_28;
        }
        // 0x00D82AC4: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00D82AC8: LDR x8, [x8, #0xa0]        | X8 = (string**)(1152921510122333440)("delayFinishTime");
        // 0x00D82ACC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82AD0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82AD4: LDR x1, [x8]               | X1 = "delayFinishTime";                 
        // 0x00D82AD8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "delayFinishTime");
        string val_71 = _info.Item["delayFinishTime"];
        // 0x00D82ADC: MOV x1, x0                 | X1 = val_71;//m1                        
        // 0x00D82AE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82AE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82AE8: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_72 = System.Single.Parse(s:  0);
        // 0x00D82AEC: STR s0, [x19, #0x9c]       | this.delayFinishTime = val_72;           //  dest_result_addr=1152921514531378988
        this.delayFinishTime = val_72;
        // 0x00D82AF0: B #0xd82b28                |  goto label_29;                         
        goto label_29;
        label_28:
        // 0x00D82AF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        // 0x00D82AF8: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00D82AFC: LDR x8, [x8, #0xa0]        | X8 = (string**)(1152921510122333440)("delayFinishTime");
        // 0x00D82B00: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82B04: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82B08: LDR x1, [x8]               | X1 = "delayFinishTime";                 
        // 0x00D82B0C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "delayFinishTime");
        string val_73 = _info.Item["delayFinishTime"];
        // 0x00D82B10: MOV x1, x0                 | X1 = val_73;//m1                        
        // 0x00D82B14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82B18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82B1C: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_74 = System.Single.Parse(s:  0);
        // 0x00D82B20: STR s0, [x19, #0x9c]       | this.delayFinishTime = val_74;           //  dest_result_addr=1152921514531378988
        this.delayFinishTime = val_74;
        // 0x00D82B24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_29:
        // 0x00D82B28: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D82B2C: LDR x8, [x8, #0xcc8]       | X8 = (string**)(1152921510122335600)("passCameraAnimation");
        // 0x00D82B30: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82B34: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82B38: LDR x1, [x8]               | X1 = "passCameraAnimation";             
        // 0x00D82B3C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "passCameraAnimation");
        string val_75 = _info.Item["passCameraAnimation"];
        // 0x00D82B40: STR x0, [x19, #0xa0]       | this.passCameraAnimation = val_75;       //  dest_result_addr=1152921514531378992
        this.passCameraAnimation = val_75;
        // 0x00D82B44: CBZ x20, #0xd82b68         | if (_info == null) goto label_30;       
        if(_info == null)
        {
            goto label_30;
        }
        // 0x00D82B48: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D82B4C: LDR x8, [x8, #0xf88]       | X8 = (string**)(1152921510122337760)("npcArr");
        // 0x00D82B50: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82B54: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82B58: LDR x1, [x8]               | X1 = "npcArr";                          
        // 0x00D82B5C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "npcArr");    
        string val_76 = _info.Item["npcArr"];
        // 0x00D82B60: STR x0, [x19, #0xa8]       | this.npcArr = val_76;                    //  dest_result_addr=1152921514531379000
        this.npcArr = val_76;
        // 0x00D82B64: B #0xd82b8c                |  goto label_31;                         
        goto label_31;
        label_30:
        // 0x00D82B68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_75, ????);     
        // 0x00D82B6C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D82B70: LDR x8, [x8, #0xf88]       | X8 = (string**)(1152921510122337760)("npcArr");
        // 0x00D82B74: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82B78: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82B7C: LDR x1, [x8]               | X1 = "npcArr";                          
        // 0x00D82B80: BL #0x23fc26c              | X0 = _info.get_Item(key:  "npcArr");    
        string val_77 = _info.Item["npcArr"];
        // 0x00D82B84: STR x0, [x19, #0xa8]       | this.npcArr = val_77;                    //  dest_result_addr=1152921514531379000
        this.npcArr = val_77;
        // 0x00D82B88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_77, ????);     
        label_31:
        // 0x00D82B8C: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00D82B90: LDR x8, [x8, #0xff8]       | X8 = (string**)(1152921510122339888)("rewardArr");
        // 0x00D82B94: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82B98: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82B9C: LDR x1, [x8]               | X1 = "rewardArr";                       
        // 0x00D82BA0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "rewardArr"); 
        string val_78 = _info.Item["rewardArr"];
        // 0x00D82BA4: STR x0, [x19, #0xb0]       | this.rewardArr = val_78;                 //  dest_result_addr=1152921514531379008
        this.rewardArr = val_78;
        // 0x00D82BA8: CBZ x20, #0xd82bdc         | if (_info == null) goto label_32;       
        if(_info == null)
        {
            goto label_32;
        }
        // 0x00D82BAC: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00D82BB0: LDR x8, [x8, #0xbf8]       | X8 = (string**)(1152921510122342032)("dropId");
        // 0x00D82BB4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82BB8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82BBC: LDR x1, [x8]               | X1 = "dropId";                          
        // 0x00D82BC0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "dropId");    
        string val_79 = _info.Item["dropId"];
        // 0x00D82BC4: MOV x1, x0                 | X1 = val_79;//m1                        
        // 0x00D82BC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82BCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82BD0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_80 = System.Int32.Parse(s:  0);
        // 0x00D82BD4: STR w0, [x19, #0xb8]       | this.dropId = val_80;                    //  dest_result_addr=1152921514531379016
        this.dropId = val_80;
        // 0x00D82BD8: B #0xd82c10                |  goto label_33;                         
        goto label_33;
        label_32:
        // 0x00D82BDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_78, ????);     
        // 0x00D82BE0: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00D82BE4: LDR x8, [x8, #0xbf8]       | X8 = (string**)(1152921510122342032)("dropId");
        // 0x00D82BE8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82BEC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82BF0: LDR x1, [x8]               | X1 = "dropId";                          
        // 0x00D82BF4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "dropId");    
        string val_81 = _info.Item["dropId"];
        // 0x00D82BF8: MOV x1, x0                 | X1 = val_81;//m1                        
        // 0x00D82BFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82C00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82C04: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_82 = System.Int32.Parse(s:  0);
        // 0x00D82C08: STR w0, [x19, #0xb8]       | this.dropId = val_82;                    //  dest_result_addr=1152921514531379016
        this.dropId = val_82;
        // 0x00D82C0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_82, ????);     
        label_33:
        // 0x00D82C10: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00D82C14: LDR x8, [x8, #0x7a8]       | X8 = (string**)(1152921510122344160)("firsttimedrop");
        // 0x00D82C18: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82C1C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82C20: LDR x1, [x8]               | X1 = "firsttimedrop";                   
        // 0x00D82C24: BL #0x23fc26c              | X0 = _info.get_Item(key:  "firsttimedrop");
        string val_83 = _info.Item["firsttimedrop"];
        // 0x00D82C28: MOV x1, x0                 | X1 = val_83;//m1                        
        // 0x00D82C2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82C30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82C34: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_84 = System.Int32.Parse(s:  0);
        // 0x00D82C38: STR w0, [x19, #0xbc]       | this.firsttimedrop = val_84;             //  dest_result_addr=1152921514531379020
        this.firsttimedrop = val_84;
        // 0x00D82C3C: CBZ x20, #0xd82c70         | if (_info == null) goto label_34;       
        if(_info == null)
        {
            goto label_34;
        }
        // 0x00D82C40: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D82C44: LDR x8, [x8, #0x180]       | X8 = (string**)(1152921510122346304)("firsttimedropnum");
        // 0x00D82C48: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82C4C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82C50: LDR x1, [x8]               | X1 = "firsttimedropnum";                
        // 0x00D82C54: BL #0x23fc26c              | X0 = _info.get_Item(key:  "firsttimedropnum");
        string val_85 = _info.Item["firsttimedropnum"];
        // 0x00D82C58: MOV x1, x0                 | X1 = val_85;//m1                        
        // 0x00D82C5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82C60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82C64: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_86 = System.Int32.Parse(s:  0);
        // 0x00D82C68: STR w0, [x19, #0xc0]       | this.firsttimedropnum = val_86;          //  dest_result_addr=1152921514531379024
        this.firsttimedropnum = val_86;
        // 0x00D82C6C: B #0xd82ca4                |  goto label_35;                         
        goto label_35;
        label_34:
        // 0x00D82C70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_84, ????);     
        // 0x00D82C74: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D82C78: LDR x8, [x8, #0x180]       | X8 = (string**)(1152921510122346304)("firsttimedropnum");
        // 0x00D82C7C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82C80: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82C84: LDR x1, [x8]               | X1 = "firsttimedropnum";                
        // 0x00D82C88: BL #0x23fc26c              | X0 = _info.get_Item(key:  "firsttimedropnum");
        string val_87 = _info.Item["firsttimedropnum"];
        // 0x00D82C8C: MOV x1, x0                 | X1 = val_87;//m1                        
        // 0x00D82C90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82C94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82C98: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_88 = System.Int32.Parse(s:  0);
        // 0x00D82C9C: STR w0, [x19, #0xc0]       | this.firsttimedropnum = val_88;          //  dest_result_addr=1152921514531379024
        this.firsttimedropnum = val_88;
        // 0x00D82CA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_88, ????);     
        label_35:
        // 0x00D82CA4: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00D82CA8: LDR x8, [x8, #0xec0]       | X8 = (string**)(1152921510122348464)("sweep_lv");
        // 0x00D82CAC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82CB0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82CB4: LDR x1, [x8]               | X1 = "sweep_lv";                        
        // 0x00D82CB8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "sweep_lv");  
        string val_89 = _info.Item["sweep_lv"];
        // 0x00D82CBC: MOV x1, x0                 | X1 = val_89;//m1                        
        // 0x00D82CC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82CC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82CC8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_90 = System.Int32.Parse(s:  0);
        // 0x00D82CCC: STR w0, [x19, #0xc4]       | this.sweep_lv = val_90;                  //  dest_result_addr=1152921514531379028
        this.sweep_lv = val_90;
        // 0x00D82CD0: CBZ x20, #0xd82cf4         | if (_info == null) goto label_36;       
        if(_info == null)
        {
            goto label_36;
        }
        // 0x00D82CD4: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00D82CD8: LDR x8, [x8, #0xc00]       | X8 = (string**)(1152921510122350608)("swipedrop");
        // 0x00D82CDC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82CE0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82CE4: LDR x1, [x8]               | X1 = "swipedrop";                       
        // 0x00D82CE8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "swipedrop"); 
        string val_91 = _info.Item["swipedrop"];
        // 0x00D82CEC: STR x0, [x19, #0xc8]       | this.swipedrop = val_91;                 //  dest_result_addr=1152921514531379032
        this.swipedrop = val_91;
        // 0x00D82CF0: B #0xd82d18                |  goto label_37;                         
        goto label_37;
        label_36:
        // 0x00D82CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_90, ????);     
        // 0x00D82CF8: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00D82CFC: LDR x8, [x8, #0xc00]       | X8 = (string**)(1152921510122350608)("swipedrop");
        // 0x00D82D00: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82D04: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82D08: LDR x1, [x8]               | X1 = "swipedrop";                       
        // 0x00D82D0C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "swipedrop"); 
        string val_92 = _info.Item["swipedrop"];
        // 0x00D82D10: STR x0, [x19, #0xc8]       | this.swipedrop = val_92;                 //  dest_result_addr=1152921514531379032
        this.swipedrop = val_92;
        // 0x00D82D14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_92, ????);     
        label_37:
        // 0x00D82D18: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00D82D1C: LDR x8, [x8, #0xd28]       | X8 = (string**)(1152921510122352752)("swipedropcount");
        // 0x00D82D20: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82D24: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82D28: LDR x1, [x8]               | X1 = "swipedropcount";                  
        // 0x00D82D2C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "swipedropcount");
        string val_93 = _info.Item["swipedropcount"];
        // 0x00D82D30: STR x0, [x19, #0xd0]       | this.swipedropcount = val_93;            //  dest_result_addr=1152921514531379040
        this.swipedropcount = val_93;
        // 0x00D82D34: CBZ x20, #0xd82d68         | if (_info == null) goto label_38;       
        if(_info == null)
        {
            goto label_38;
        }
        // 0x00D82D38: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00D82D3C: LDR x8, [x8, #0x620]       | X8 = (string**)(1152921510122354896)("hidestartext");
        // 0x00D82D40: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82D44: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82D48: LDR x1, [x8]               | X1 = "hidestartext";                    
        // 0x00D82D4C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "hidestartext");
        string val_94 = _info.Item["hidestartext"];
        // 0x00D82D50: MOV x1, x0                 | X1 = val_94;//m1                        
        // 0x00D82D54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82D58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82D5C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_95 = System.Int32.Parse(s:  0);
        // 0x00D82D60: STR w0, [x19, #0xd8]       | this.hidestartext = val_95;              //  dest_result_addr=1152921514531379048
        this.hidestartext = val_95;
        // 0x00D82D64: B #0xd82d9c                |  goto label_39;                         
        goto label_39;
        label_38:
        // 0x00D82D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_93, ????);     
        // 0x00D82D6C: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00D82D70: LDR x8, [x8, #0x620]       | X8 = (string**)(1152921510122354896)("hidestartext");
        // 0x00D82D74: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82D78: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82D7C: LDR x1, [x8]               | X1 = "hidestartext";                    
        // 0x00D82D80: BL #0x23fc26c              | X0 = _info.get_Item(key:  "hidestartext");
        string val_96 = _info.Item["hidestartext"];
        // 0x00D82D84: MOV x1, x0                 | X1 = val_96;//m1                        
        // 0x00D82D88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82D8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82D90: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_97 = System.Int32.Parse(s:  0);
        // 0x00D82D94: STR w0, [x19, #0xd8]       | this.hidestartext = val_97;              //  dest_result_addr=1152921514531379048
        this.hidestartext = val_97;
        // 0x00D82D98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_97, ????);     
        label_39:
        // 0x00D82D9C: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00D82DA0: LDR x8, [x8, #0x540]       | X8 = (string**)(1152921510122357040)("gradeType1");
        // 0x00D82DA4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82DA8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82DAC: LDR x1, [x8]               | X1 = "gradeType1";                      
        // 0x00D82DB0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradeType1");
        string val_98 = _info.Item["gradeType1"];
        // 0x00D82DB4: MOV x1, x0                 | X1 = val_98;//m1                        
        // 0x00D82DB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82DBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82DC0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_99 = System.Int32.Parse(s:  0);
        // 0x00D82DC4: STR w0, [x19, #0xdc]       | this.gradeType1 = val_99;                //  dest_result_addr=1152921514531379052
        this.gradeType1 = val_99;
        // 0x00D82DC8: CBZ x20, #0xd82dfc         | if (_info == null) goto label_40;       
        if(_info == null)
        {
            goto label_40;
        }
        // 0x00D82DCC: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00D82DD0: LDR x8, [x8, #0xf38]       | X8 = (string**)(1152921510122359184)("gradeValue1");
        // 0x00D82DD4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82DD8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82DDC: LDR x1, [x8]               | X1 = "gradeValue1";                     
        // 0x00D82DE0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradeValue1");
        string val_100 = _info.Item["gradeValue1"];
        // 0x00D82DE4: MOV x1, x0                 | X1 = val_100;//m1                       
        // 0x00D82DE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82DEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82DF0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_101 = System.Int32.Parse(s:  0);
        // 0x00D82DF4: STR w0, [x19, #0xe0]       | this.gradeValue1 = val_101;              //  dest_result_addr=1152921514531379056
        this.gradeValue1 = val_101;
        // 0x00D82DF8: B #0xd82e30                |  goto label_41;                         
        goto label_41;
        label_40:
        // 0x00D82DFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_99, ????);     
        // 0x00D82E00: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00D82E04: LDR x8, [x8, #0xf38]       | X8 = (string**)(1152921510122359184)("gradeValue1");
        // 0x00D82E08: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82E0C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82E10: LDR x1, [x8]               | X1 = "gradeValue1";                     
        // 0x00D82E14: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradeValue1");
        string val_102 = _info.Item["gradeValue1"];
        // 0x00D82E18: MOV x1, x0                 | X1 = val_102;//m1                       
        // 0x00D82E1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82E20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82E24: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_103 = System.Int32.Parse(s:  0);
        // 0x00D82E28: STR w0, [x19, #0xe0]       | this.gradeValue1 = val_103;              //  dest_result_addr=1152921514531379056
        this.gradeValue1 = val_103;
        // 0x00D82E2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_103, ????);    
        label_41:
        // 0x00D82E30: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x00D82E34: LDR x8, [x8, #0x5f0]       | X8 = (string**)(1152921510122361328)("gradetext1");
        // 0x00D82E38: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82E3C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82E40: LDR x1, [x8]               | X1 = "gradetext1";                      
        // 0x00D82E44: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradetext1");
        string val_104 = _info.Item["gradetext1"];
        // 0x00D82E48: STR x0, [x19, #0xe8]       | this.gradetext1 = val_104;               //  dest_result_addr=1152921514531379064
        this.gradetext1 = val_104;
        // 0x00D82E4C: CBZ x20, #0xd82e70         | if (_info == null) goto label_42;       
        if(_info == null)
        {
            goto label_42;
        }
        // 0x00D82E50: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D82E54: LDR x8, [x8, #0xd38]       | X8 = (string**)(1152921510122363472)("gradetext1_lose");
        // 0x00D82E58: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82E5C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82E60: LDR x1, [x8]               | X1 = "gradetext1_lose";                 
        // 0x00D82E64: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradetext1_lose");
        string val_105 = _info.Item["gradetext1_lose"];
        // 0x00D82E68: STR x0, [x19, #0xf0]       | this.gradetext1_lose = val_105;          //  dest_result_addr=1152921514531379072
        this.gradetext1_lose = val_105;
        // 0x00D82E6C: B #0xd82e94                |  goto label_43;                         
        goto label_43;
        label_42:
        // 0x00D82E70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_104, ????);    
        // 0x00D82E74: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D82E78: LDR x8, [x8, #0xd38]       | X8 = (string**)(1152921510122363472)("gradetext1_lose");
        // 0x00D82E7C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82E80: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82E84: LDR x1, [x8]               | X1 = "gradetext1_lose";                 
        // 0x00D82E88: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradetext1_lose");
        string val_106 = _info.Item["gradetext1_lose"];
        // 0x00D82E8C: STR x0, [x19, #0xf0]       | this.gradetext1_lose = val_106;          //  dest_result_addr=1152921514531379072
        this.gradetext1_lose = val_106;
        // 0x00D82E90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_106, ????);    
        label_43:
        // 0x00D82E94: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
        // 0x00D82E98: LDR x8, [x8, #0x658]       | X8 = (string**)(1152921510122365632)("gradeType2");
        // 0x00D82E9C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82EA0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82EA4: LDR x1, [x8]               | X1 = "gradeType2";                      
        // 0x00D82EA8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradeType2");
        string val_107 = _info.Item["gradeType2"];
        // 0x00D82EAC: MOV x1, x0                 | X1 = val_107;//m1                       
        // 0x00D82EB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82EB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82EB8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_108 = System.Int32.Parse(s:  0);
        // 0x00D82EBC: STR w0, [x19, #0xf8]       | this.gradeType2 = val_108;               //  dest_result_addr=1152921514531379080
        this.gradeType2 = val_108;
        // 0x00D82EC0: CBZ x20, #0xd82ef4         | if (_info == null) goto label_44;       
        if(_info == null)
        {
            goto label_44;
        }
        // 0x00D82EC4: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
        // 0x00D82EC8: LDR x8, [x8, #0xe28]       | X8 = (string**)(1152921510122367776)("gradeValue2");
        // 0x00D82ECC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82ED0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82ED4: LDR x1, [x8]               | X1 = "gradeValue2";                     
        // 0x00D82ED8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradeValue2");
        string val_109 = _info.Item["gradeValue2"];
        // 0x00D82EDC: MOV x1, x0                 | X1 = val_109;//m1                       
        // 0x00D82EE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82EE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82EE8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_110 = System.Int32.Parse(s:  0);
        // 0x00D82EEC: STR w0, [x19, #0xfc]       | this.gradeValue2 = val_110;              //  dest_result_addr=1152921514531379084
        this.gradeValue2 = val_110;
        // 0x00D82EF0: B #0xd82f28                |  goto label_45;                         
        goto label_45;
        label_44:
        // 0x00D82EF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_108, ????);    
        // 0x00D82EF8: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
        // 0x00D82EFC: LDR x8, [x8, #0xe28]       | X8 = (string**)(1152921510122367776)("gradeValue2");
        // 0x00D82F00: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82F04: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82F08: LDR x1, [x8]               | X1 = "gradeValue2";                     
        // 0x00D82F0C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradeValue2");
        string val_111 = _info.Item["gradeValue2"];
        // 0x00D82F10: MOV x1, x0                 | X1 = val_111;//m1                       
        // 0x00D82F14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82F18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82F1C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_112 = System.Int32.Parse(s:  0);
        // 0x00D82F20: STR w0, [x19, #0xfc]       | this.gradeValue2 = val_112;              //  dest_result_addr=1152921514531379084
        this.gradeValue2 = val_112;
        // 0x00D82F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_112, ????);    
        label_45:
        // 0x00D82F28: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
        // 0x00D82F2C: LDR x8, [x8, #0x398]       | X8 = (string**)(1152921510122369920)("gradetext2");
        // 0x00D82F30: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82F34: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82F38: LDR x1, [x8]               | X1 = "gradetext2";                      
        // 0x00D82F3C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradetext2");
        string val_113 = _info.Item["gradetext2"];
        // 0x00D82F40: STR x0, [x19, #0x100]      | this.gradetext2 = val_113;               //  dest_result_addr=1152921514531379088
        this.gradetext2 = val_113;
        // 0x00D82F44: CBZ x20, #0xd82f68         | if (_info == null) goto label_46;       
        if(_info == null)
        {
            goto label_46;
        }
        // 0x00D82F48: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x00D82F4C: LDR x8, [x8, #0x398]       | X8 = (string**)(1152921510122372064)("gradetext2_lose");
        // 0x00D82F50: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82F54: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82F58: LDR x1, [x8]               | X1 = "gradetext2_lose";                 
        // 0x00D82F5C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradetext2_lose");
        string val_114 = _info.Item["gradetext2_lose"];
        // 0x00D82F60: STR x0, [x19, #0x108]      | this.gradetext2_lose = val_114;          //  dest_result_addr=1152921514531379096
        this.gradetext2_lose = val_114;
        // 0x00D82F64: B #0xd82f8c                |  goto label_47;                         
        goto label_47;
        label_46:
        // 0x00D82F68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_113, ????);    
        // 0x00D82F6C: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x00D82F70: LDR x8, [x8, #0x398]       | X8 = (string**)(1152921510122372064)("gradetext2_lose");
        // 0x00D82F74: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82F78: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82F7C: LDR x1, [x8]               | X1 = "gradetext2_lose";                 
        // 0x00D82F80: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradetext2_lose");
        string val_115 = _info.Item["gradetext2_lose"];
        // 0x00D82F84: STR x0, [x19, #0x108]      | this.gradetext2_lose = val_115;          //  dest_result_addr=1152921514531379096
        this.gradetext2_lose = val_115;
        // 0x00D82F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_115, ????);    
        label_47:
        // 0x00D82F8C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00D82F90: LDR x8, [x8, #0x920]       | X8 = (string**)(1152921510122374224)("gradeType3");
        // 0x00D82F94: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82F98: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82F9C: LDR x1, [x8]               | X1 = "gradeType3";                      
        // 0x00D82FA0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradeType3");
        string val_116 = _info.Item["gradeType3"];
        // 0x00D82FA4: MOV x1, x0                 | X1 = val_116;//m1                       
        // 0x00D82FA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82FAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82FB0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_117 = System.Int32.Parse(s:  0);
        // 0x00D82FB4: STR w0, [x19, #0x110]      | this.gradeType3 = val_117;               //  dest_result_addr=1152921514531379104
        this.gradeType3 = val_117;
        // 0x00D82FB8: CBZ x20, #0xd82fec         | if (_info == null) goto label_48;       
        if(_info == null)
        {
            goto label_48;
        }
        // 0x00D82FBC: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
        // 0x00D82FC0: LDR x8, [x8, #0x990]       | X8 = (string**)(1152921510122376368)("gradeValue3");
        // 0x00D82FC4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82FC8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82FCC: LDR x1, [x8]               | X1 = "gradeValue3";                     
        // 0x00D82FD0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradeValue3");
        string val_118 = _info.Item["gradeValue3"];
        // 0x00D82FD4: MOV x1, x0                 | X1 = val_118;//m1                       
        // 0x00D82FD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82FDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82FE0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_119 = System.Int32.Parse(s:  0);
        // 0x00D82FE4: STR w0, [x19, #0x114]      | this.gradeValue3 = val_119;              //  dest_result_addr=1152921514531379108
        this.gradeValue3 = val_119;
        // 0x00D82FE8: B #0xd83020                |  goto label_49;                         
        goto label_49;
        label_48:
        // 0x00D82FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_117, ????);    
        // 0x00D82FF0: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
        // 0x00D82FF4: LDR x8, [x8, #0x990]       | X8 = (string**)(1152921510122376368)("gradeValue3");
        // 0x00D82FF8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D82FFC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83000: LDR x1, [x8]               | X1 = "gradeValue3";                     
        // 0x00D83004: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradeValue3");
        string val_120 = _info.Item["gradeValue3"];
        // 0x00D83008: MOV x1, x0                 | X1 = val_120;//m1                       
        // 0x00D8300C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83010: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83014: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_121 = System.Int32.Parse(s:  0);
        // 0x00D83018: STR w0, [x19, #0x114]      | this.gradeValue3 = val_121;              //  dest_result_addr=1152921514531379108
        this.gradeValue3 = val_121;
        // 0x00D8301C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_121, ????);    
        label_49:
        // 0x00D83020: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x00D83024: LDR x8, [x8, #0xa90]       | X8 = (string**)(1152921510122378512)("gradetext3");
        // 0x00D83028: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8302C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83030: LDR x1, [x8]               | X1 = "gradetext3";                      
        // 0x00D83034: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradetext3");
        string val_122 = _info.Item["gradetext3"];
        // 0x00D83038: STR x0, [x19, #0x118]      | this.gradetext3 = val_122;               //  dest_result_addr=1152921514531379112
        this.gradetext3 = val_122;
        // 0x00D8303C: CBZ x20, #0xd83060         | if (_info == null) goto label_50;       
        if(_info == null)
        {
            goto label_50;
        }
        // 0x00D83040: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00D83044: LDR x8, [x8, #0x220]       | X8 = (string**)(1152921510122380656)("gradetext3_lose");
        // 0x00D83048: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8304C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83050: LDR x1, [x8]               | X1 = "gradetext3_lose";                 
        // 0x00D83054: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradetext3_lose");
        string val_123 = _info.Item["gradetext3_lose"];
        // 0x00D83058: STR x0, [x19, #0x120]      | this.gradetext3_lose = val_123;          //  dest_result_addr=1152921514531379120
        this.gradetext3_lose = val_123;
        // 0x00D8305C: B #0xd83084                |  goto label_51;                         
        goto label_51;
        label_50:
        // 0x00D83060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_122, ????);    
        // 0x00D83064: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00D83068: LDR x8, [x8, #0x220]       | X8 = (string**)(1152921510122380656)("gradetext3_lose");
        // 0x00D8306C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83070: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83074: LDR x1, [x8]               | X1 = "gradetext3_lose";                 
        // 0x00D83078: BL #0x23fc26c              | X0 = _info.get_Item(key:  "gradetext3_lose");
        string val_124 = _info.Item["gradetext3_lose"];
        // 0x00D8307C: STR x0, [x19, #0x120]      | this.gradetext3_lose = val_124;          //  dest_result_addr=1152921514531379120
        this.gradetext3_lose = val_124;
        // 0x00D83080: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_124, ????);    
        label_51:
        // 0x00D83084: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
        // 0x00D83088: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921510122382816)("Plot_off");
        // 0x00D8308C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83090: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83094: LDR x1, [x8]               | X1 = "Plot_off";                        
        // 0x00D83098: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Plot_off");  
        string val_125 = _info.Item["Plot_off"];
        // 0x00D8309C: MOV x1, x0                 | X1 = val_125;//m1                       
        // 0x00D830A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D830A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D830A8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_126 = System.Int32.Parse(s:  0);
        // 0x00D830AC: STR w0, [x19, #0x128]      | this.Plot_off = val_126;                 //  dest_result_addr=1152921514531379128
        this.Plot_off = val_126;
        // 0x00D830B0: CBZ x20, #0xd830e4         | if (_info == null) goto label_52;       
        if(_info == null)
        {
            goto label_52;
        }
        // 0x00D830B4: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x00D830B8: LDR x8, [x8, #0x3b8]       | X8 = (string**)(1152921510122384960)("enterPlotId");
        // 0x00D830BC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D830C0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D830C4: LDR x1, [x8]               | X1 = "enterPlotId";                     
        // 0x00D830C8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "enterPlotId");
        string val_127 = _info.Item["enterPlotId"];
        // 0x00D830CC: MOV x1, x0                 | X1 = val_127;//m1                       
        // 0x00D830D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D830D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D830D8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_128 = System.Int32.Parse(s:  0);
        // 0x00D830DC: STR w0, [x19, #0x12c]      | this.enterPlotId = val_128;              //  dest_result_addr=1152921514531379132
        this.enterPlotId = val_128;
        // 0x00D830E0: B #0xd83118                |  goto label_53;                         
        goto label_53;
        label_52:
        // 0x00D830E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_126, ????);    
        // 0x00D830E8: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x00D830EC: LDR x8, [x8, #0x3b8]       | X8 = (string**)(1152921510122384960)("enterPlotId");
        // 0x00D830F0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D830F4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D830F8: LDR x1, [x8]               | X1 = "enterPlotId";                     
        // 0x00D830FC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "enterPlotId");
        string val_129 = _info.Item["enterPlotId"];
        // 0x00D83100: MOV x1, x0                 | X1 = val_129;//m1                       
        // 0x00D83104: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83108: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8310C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_130 = System.Int32.Parse(s:  0);
        // 0x00D83110: STR w0, [x19, #0x12c]      | this.enterPlotId = val_130;              //  dest_result_addr=1152921514531379132
        this.enterPlotId = val_130;
        // 0x00D83114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_130, ????);    
        label_53:
        // 0x00D83118: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
        // 0x00D8311C: LDR x8, [x8, #0x50]        | X8 = (string**)(1152921510122387104)("passPlotId");
        // 0x00D83120: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83124: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83128: LDR x1, [x8]               | X1 = "passPlotId";                      
        // 0x00D8312C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "passPlotId");
        string val_131 = _info.Item["passPlotId"];
        // 0x00D83130: MOV x1, x0                 | X1 = val_131;//m1                       
        // 0x00D83134: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83138: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8313C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_132 = System.Int32.Parse(s:  0);
        // 0x00D83140: STR w0, [x19, #0x130]      | this.passPlotId = val_132;               //  dest_result_addr=1152921514531379136
        this.passPlotId = val_132;
        // 0x00D83144: CBZ x20, #0xd83168         | if (_info == null) goto label_54;       
        if(_info == null)
        {
            goto label_54;
        }
        // 0x00D83148: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00D8314C: LDR x8, [x8, #0xe08]       | X8 = (string**)(1152921510122389248)("rewards");
        // 0x00D83150: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83154: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83158: LDR x1, [x8]               | X1 = "rewards";                         
        // 0x00D8315C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "rewards");   
        string val_133 = _info.Item["rewards"];
        // 0x00D83160: STR x0, [x19, #0x138]      | this.rewards = val_133;                  //  dest_result_addr=1152921514531379144
        this.rewards = val_133;
        // 0x00D83164: B #0xd8318c                |  goto label_55;                         
        goto label_55;
        label_54:
        // 0x00D83168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_132, ????);    
        // 0x00D8316C: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00D83170: LDR x8, [x8, #0xe08]       | X8 = (string**)(1152921510122389248)("rewards");
        // 0x00D83174: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83178: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8317C: LDR x1, [x8]               | X1 = "rewards";                         
        // 0x00D83180: BL #0x23fc26c              | X0 = _info.get_Item(key:  "rewards");   
        string val_134 = _info.Item["rewards"];
        // 0x00D83184: STR x0, [x19, #0x138]      | this.rewards = val_134;                  //  dest_result_addr=1152921514531379144
        this.rewards = val_134;
        // 0x00D83188: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_134, ????);    
        label_55:
        // 0x00D8318C: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
        // 0x00D83190: LDR x8, [x8, #0xe00]       | X8 = (string**)(1152921510122391392)("des");
        // 0x00D83194: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83198: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8319C: LDR x1, [x8]               | X1 = "des";                             
        // 0x00D831A0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "des");       
        string val_135 = _info.Item["des"];
        // 0x00D831A4: STR x0, [x19, #0x140]      | this.des = val_135;                      //  dest_result_addr=1152921514531379152
        this.des = val_135;
        // 0x00D831A8: CBZ x20, #0xd831dc         | if (_info == null) goto label_56;       
        if(_info == null)
        {
            goto label_56;
        }
        // 0x00D831AC: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
        // 0x00D831B0: LDR x8, [x8, #0xfe8]       | X8 = (string**)(1152921510122393520)("AI");
        // 0x00D831B4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D831B8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D831BC: LDR x1, [x8]               | X1 = "AI";                              
        // 0x00D831C0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "AI");        
        string val_136 = _info.Item["AI"];
        // 0x00D831C4: MOV x1, x0                 | X1 = val_136;//m1                       
        // 0x00D831C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D831CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D831D0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_137 = System.Int32.Parse(s:  0);
        // 0x00D831D4: STR w0, [x19, #0x148]      | this.AI = val_137;                       //  dest_result_addr=1152921514531379160
        this.AI = val_137;
        // 0x00D831D8: B #0xd83210                |  goto label_57;                         
        goto label_57;
        label_56:
        // 0x00D831DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_135, ????);    
        // 0x00D831E0: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
        // 0x00D831E4: LDR x8, [x8, #0xfe8]       | X8 = (string**)(1152921510122393520)("AI");
        // 0x00D831E8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D831EC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D831F0: LDR x1, [x8]               | X1 = "AI";                              
        // 0x00D831F4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "AI");        
        string val_138 = _info.Item["AI"];
        // 0x00D831F8: MOV x1, x0                 | X1 = val_138;//m1                       
        // 0x00D831FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83200: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83204: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_139 = System.Int32.Parse(s:  0);
        // 0x00D83208: STR w0, [x19, #0x148]      | this.AI = val_139;                       //  dest_result_addr=1152921514531379160
        this.AI = val_139;
        // 0x00D8320C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_139, ????);    
        label_57:
        // 0x00D83210: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
        // 0x00D83214: LDR x8, [x8, #0xcb0]       | X8 = (string**)(1152921510122395648)("ifAuto");
        // 0x00D83218: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8321C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83220: LDR x1, [x8]               | X1 = "ifAuto";                          
        // 0x00D83224: BL #0x23fc26c              | X0 = _info.get_Item(key:  "ifAuto");    
        string val_140 = _info.Item["ifAuto"];
        // 0x00D83228: MOV x1, x0                 | X1 = val_140;//m1                       
        // 0x00D8322C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83230: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83234: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_141 = System.Int32.Parse(s:  0);
        // 0x00D83238: STR w0, [x19, #0x14c]      | this.ifAuto = val_141;                   //  dest_result_addr=1152921514531379164
        this.ifAuto = val_141;
        // 0x00D8323C: CBZ x20, #0xd83270         | if (_info == null) goto label_58;       
        if(_info == null)
        {
            goto label_58;
        }
        // 0x00D83240: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00D83244: LDR x8, [x8, #0xd50]       | X8 = (string**)(1152921510122397776)("ifMotion");
        // 0x00D83248: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8324C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83250: LDR x1, [x8]               | X1 = "ifMotion";                        
        // 0x00D83254: BL #0x23fc26c              | X0 = _info.get_Item(key:  "ifMotion");  
        string val_142 = _info.Item["ifMotion"];
        // 0x00D83258: MOV x1, x0                 | X1 = val_142;//m1                       
        // 0x00D8325C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83260: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83264: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_143 = System.Int32.Parse(s:  0);
        // 0x00D83268: STR w0, [x19, #0x150]      | this.ifMotion = val_143;                 //  dest_result_addr=1152921514531379168
        this.ifMotion = val_143;
        // 0x00D8326C: B #0xd832a4                |  goto label_59;                         
        goto label_59;
        label_58:
        // 0x00D83270: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_141, ????);    
        // 0x00D83274: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00D83278: LDR x8, [x8, #0xd50]       | X8 = (string**)(1152921510122397776)("ifMotion");
        // 0x00D8327C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83280: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83284: LDR x1, [x8]               | X1 = "ifMotion";                        
        // 0x00D83288: BL #0x23fc26c              | X0 = _info.get_Item(key:  "ifMotion");  
        string val_144 = _info.Item["ifMotion"];
        // 0x00D8328C: MOV x1, x0                 | X1 = val_144;//m1                       
        // 0x00D83290: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83294: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83298: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_145 = System.Int32.Parse(s:  0);
        // 0x00D8329C: STR w0, [x19, #0x150]      | this.ifMotion = val_145;                 //  dest_result_addr=1152921514531379168
        this.ifMotion = val_145;
        // 0x00D832A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_145, ????);    
        label_59:
        // 0x00D832A4: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
        // 0x00D832A8: LDR x8, [x8, #0x5c0]       | X8 = (string**)(1152921510122399920)("ifStartAuto");
        // 0x00D832AC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D832B0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D832B4: LDR x1, [x8]               | X1 = "ifStartAuto";                     
        // 0x00D832B8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "ifStartAuto");
        string val_146 = _info.Item["ifStartAuto"];
        // 0x00D832BC: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00D832C0: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
        // 0x00D832C4: MOV x21, x0                | X21 = val_146;//m1                      
        // 0x00D832C8: LDR x8, [x8]               | X8 = typeof(System.Boolean);            
        // 0x00D832CC: LDRB w9, [x8, #0x10a]      | W9 = System.Boolean.__il2cppRuntimeField_10A;
        // 0x00D832D0: TBZ w9, #0, #0xd832e4      | if (System.Boolean.__il2cppRuntimeField_has_cctor == 0) goto label_61;
        // 0x00D832D4: LDR w9, [x8, #0xbc]        | W9 = System.Boolean.__il2cppRuntimeField_cctor_finished;
        // 0x00D832D8: CBNZ w9, #0xd832e4         | if (System.Boolean.__il2cppRuntimeField_cctor_finished != 0) goto label_61;
        // 0x00D832DC: MOV x0, x8                 | X0 = 1152921504608604160 (0x10000000001AD000);//ML01
        // 0x00D832E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Boolean), ????);
        label_61:
        // 0x00D832E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D832E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D832EC: MOV x1, x21                | X1 = val_146;//m1                       
        // 0x00D832F0: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_147 = System.Boolean.Parse(value:  0);
        // 0x00D832F4: AND w8, w0, #1             | W8 = (val_147 & 1);                     
        bool val_148 = val_147;
        // 0x00D832F8: STRB w8, [x19, #0x154]     | this.ifStartAuto = (val_147 & 1);        //  dest_result_addr=1152921514531379172
        this.ifStartAuto = val_148;
        // 0x00D832FC: CBZ x20, #0xd83330         | if (_info == null) goto label_62;       
        if(_info == null)
        {
            goto label_62;
        }
        // 0x00D83300: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x00D83304: LDR x8, [x8, #0x838]       | X8 = (string**)(1152921510122402064)("Formation");
        // 0x00D83308: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8330C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83310: LDR x1, [x8]               | X1 = "Formation";                       
        // 0x00D83314: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Formation"); 
        string val_149 = _info.Item["Formation"];
        // 0x00D83318: MOV x1, x0                 | X1 = val_149;//m1                       
        // 0x00D8331C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83320: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83324: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_150 = System.Int32.Parse(s:  0);
        // 0x00D83328: STR w0, [x19, #0x158]      | this.Formation = val_150;                //  dest_result_addr=1152921514531379176
        this.Formation = val_150;
        // 0x00D8332C: B #0xd83364                |  goto label_63;                         
        goto label_63;
        label_62:
        // 0x00D83330: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_147, ????);    
        // 0x00D83334: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x00D83338: LDR x8, [x8, #0x838]       | X8 = (string**)(1152921510122402064)("Formation");
        // 0x00D8333C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83340: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83344: LDR x1, [x8]               | X1 = "Formation";                       
        // 0x00D83348: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Formation"); 
        string val_151 = _info.Item["Formation"];
        // 0x00D8334C: MOV x1, x0                 | X1 = val_151;//m1                       
        // 0x00D83350: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83354: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83358: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_152 = System.Int32.Parse(s:  0);
        // 0x00D8335C: STR w0, [x19, #0x158]      | this.Formation = val_152;                //  dest_result_addr=1152921514531379176
        this.Formation = val_152;
        // 0x00D83360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_152, ????);    
        label_63:
        // 0x00D83364: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
        // 0x00D83368: LDR x8, [x8, #0xb50]       | X8 = (string**)(1152921510122404208)("MusicID");
        // 0x00D8336C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83370: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83374: LDR x1, [x8]               | X1 = "MusicID";                         
        // 0x00D83378: BL #0x23fc26c              | X0 = _info.get_Item(key:  "MusicID");   
        string val_153 = _info.Item["MusicID"];
        // 0x00D8337C: MOV x1, x0                 | X1 = val_153;//m1                       
        // 0x00D83380: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83384: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83388: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_154 = System.Int32.Parse(s:  0);
        // 0x00D8338C: STR w0, [x19, #0x15c]      | this.MusicID = val_154;                  //  dest_result_addr=1152921514531379180
        this.MusicID = val_154;
        // 0x00D83390: CBZ x20, #0xd833c4         | if (_info == null) goto label_64;       
        if(_info == null)
        {
            goto label_64;
        }
        // 0x00D83394: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
        // 0x00D83398: LDR x8, [x8, #0x848]       | X8 = (string**)(1152921510122406352)("bossAnimationId");
        // 0x00D8339C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D833A0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D833A4: LDR x1, [x8]               | X1 = "bossAnimationId";                 
        // 0x00D833A8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "bossAnimationId");
        string val_155 = _info.Item["bossAnimationId"];
        // 0x00D833AC: MOV x1, x0                 | X1 = val_155;//m1                       
        // 0x00D833B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D833B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D833B8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_156 = System.Int32.Parse(s:  0);
        // 0x00D833BC: STR w0, [x19, #0x160]      | this.bossAnimationId = val_156;          //  dest_result_addr=1152921514531379184
        this.bossAnimationId = val_156;
        // 0x00D833C0: B #0xd833f8                |  goto label_65;                         
        goto label_65;
        label_64:
        // 0x00D833C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_154, ????);    
        // 0x00D833C8: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
        // 0x00D833CC: LDR x8, [x8, #0x848]       | X8 = (string**)(1152921510122406352)("bossAnimationId");
        // 0x00D833D0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D833D4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D833D8: LDR x1, [x8]               | X1 = "bossAnimationId";                 
        // 0x00D833DC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "bossAnimationId");
        string val_157 = _info.Item["bossAnimationId"];
        // 0x00D833E0: MOV x1, x0                 | X1 = val_157;//m1                       
        // 0x00D833E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D833E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D833EC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_158 = System.Int32.Parse(s:  0);
        // 0x00D833F0: STR w0, [x19, #0x160]      | this.bossAnimationId = val_158;          //  dest_result_addr=1152921514531379184
        this.bossAnimationId = val_158;
        // 0x00D833F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_158, ????);    
        label_65:
        // 0x00D833F8: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
        // 0x00D833FC: LDR x8, [x8, #0xb80]       | X8 = (string**)(1152921510122408512)("isCameraSlow");
        // 0x00D83400: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83404: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83408: LDR x1, [x8]               | X1 = "isCameraSlow";                    
        // 0x00D8340C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isCameraSlow");
        string val_159 = _info.Item["isCameraSlow"];
        // 0x00D83410: MOV x1, x0                 | X1 = val_159;//m1                       
        // 0x00D83414: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83418: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8341C: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_160 = System.Single.Parse(s:  0);
        // 0x00D83420: STR s0, [x19, #0x164]      | this.isCameraSlow = val_160;             //  dest_result_addr=1152921514531379188
        this.isCameraSlow = val_160;
        // 0x00D83424: CBZ x20, #0xd83458         | if (_info == null) goto label_66;       
        if(_info == null)
        {
            goto label_66;
        }
        // 0x00D83428: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00D8342C: LDR x8, [x8, #0xdc8]       | X8 = (string**)(1152921510122410656)("Camera_distance");
        // 0x00D83430: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83434: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83438: LDR x1, [x8]               | X1 = "Camera_distance";                 
        // 0x00D8343C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_distance");
        string val_161 = _info.Item["Camera_distance"];
        // 0x00D83440: MOV x1, x0                 | X1 = val_161;//m1                       
        // 0x00D83444: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83448: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8344C: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_162 = System.Single.Parse(s:  0);
        // 0x00D83450: STR s0, [x19, #0x168]      | this.Camera_distance = val_162;          //  dest_result_addr=1152921514531379192
        this.Camera_distance = val_162;
        // 0x00D83454: B #0xd8348c                |  goto label_67;                         
        goto label_67;
        label_66:
        // 0x00D83458: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00D8345C: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00D83460: LDR x8, [x8, #0xdc8]       | X8 = (string**)(1152921510122410656)("Camera_distance");
        // 0x00D83464: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83468: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8346C: LDR x1, [x8]               | X1 = "Camera_distance";                 
        // 0x00D83470: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_distance");
        string val_163 = _info.Item["Camera_distance"];
        // 0x00D83474: MOV x1, x0                 | X1 = val_163;//m1                       
        // 0x00D83478: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8347C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83480: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_164 = System.Single.Parse(s:  0);
        // 0x00D83484: STR s0, [x19, #0x168]      | this.Camera_distance = val_164;          //  dest_result_addr=1152921514531379192
        this.Camera_distance = val_164;
        // 0x00D83488: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_67:
        // 0x00D8348C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00D83490: LDR x8, [x8, #0xed0]       | X8 = (string**)(1152921510122412816)("camera_if_move");
        // 0x00D83494: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83498: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8349C: LDR x1, [x8]               | X1 = "camera_if_move";                  
        // 0x00D834A0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "camera_if_move");
        string val_165 = _info.Item["camera_if_move"];
        // 0x00D834A4: MOV x1, x0                 | X1 = val_165;//m1                       
        // 0x00D834A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D834AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D834B0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_166 = System.Int32.Parse(s:  0);
        // 0x00D834B4: STR w0, [x19, #0x16c]      | this.camera_if_move = val_166;           //  dest_result_addr=1152921514531379196
        this.camera_if_move = val_166;
        // 0x00D834B8: CBZ x20, #0xd834f0         | if (_info == null) goto label_68;       
        if(_info == null)
        {
            goto label_68;
        }
        // 0x00D834BC: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
        // 0x00D834C0: LDR x8, [x8, #0x60]        | X8 = (string**)(1152921510122414960)("isCameraAnimation");
        // 0x00D834C4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D834C8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D834CC: LDR x1, [x8]               | X1 = "isCameraAnimation";               
        // 0x00D834D0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isCameraAnimation");
        string val_167 = _info.Item["isCameraAnimation"];
        // 0x00D834D4: MOV x1, x0                 | X1 = val_167;//m1                       
        // 0x00D834D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D834DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D834E0: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_168 = System.Boolean.Parse(value:  0);
        // 0x00D834E4: AND w8, w0, #1             | W8 = (val_168 & 1);                     
        bool val_169 = val_168;
        // 0x00D834E8: STRB w8, [x19, #0x170]     | this.isCameraAnimation = (val_168 & 1);  //  dest_result_addr=1152921514531379200
        this.isCameraAnimation = val_169;
        // 0x00D834EC: B #0xd83528                |  goto label_69;                         
        goto label_69;
        label_68:
        // 0x00D834F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_166, ????);    
        // 0x00D834F4: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
        // 0x00D834F8: LDR x8, [x8, #0x60]        | X8 = (string**)(1152921510122414960)("isCameraAnimation");
        // 0x00D834FC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83500: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83504: LDR x1, [x8]               | X1 = "isCameraAnimation";               
        // 0x00D83508: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isCameraAnimation");
        string val_170 = _info.Item["isCameraAnimation"];
        // 0x00D8350C: MOV x1, x0                 | X1 = val_170;//m1                       
        // 0x00D83510: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83514: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83518: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_171 = System.Boolean.Parse(value:  0);
        // 0x00D8351C: AND w8, w0, #1             | W8 = (val_171 & 1);                     
        bool val_172 = val_171;
        // 0x00D83520: STRB w8, [x19, #0x170]     | this.isCameraAnimation = (val_171 & 1);  //  dest_result_addr=1152921514531379200
        this.isCameraAnimation = val_172;
        // 0x00D83524: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_171, ????);    
        label_69:
        // 0x00D83528: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x00D8352C: LDR x8, [x8, #0x20]        | X8 = (string**)(1152921510122417120)("Camera_distance_outattack");
        // 0x00D83530: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83534: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83538: LDR x1, [x8]               | X1 = "Camera_distance_outattack";       
        // 0x00D8353C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_distance_outattack");
        string val_173 = _info.Item["Camera_distance_outattack"];
        // 0x00D83540: MOV x1, x0                 | X1 = val_173;//m1                       
        // 0x00D83544: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83548: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8354C: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_174 = System.Single.Parse(s:  0);
        // 0x00D83550: STR s0, [x19, #0x174]      | this.Camera_distance_outattack = val_174;  //  dest_result_addr=1152921514531379204
        this.Camera_distance_outattack = val_174;
        // 0x00D83554: CBZ x20, #0xd83588         | if (_info == null) goto label_70;       
        if(_info == null)
        {
            goto label_70;
        }
        // 0x00D83558: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00D8355C: LDR x8, [x8, #0xf38]       | X8 = (string**)(1152921510122419296)("Camera_alternate_time");
        // 0x00D83560: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83564: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83568: LDR x1, [x8]               | X1 = "Camera_alternate_time";           
        // 0x00D8356C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_alternate_time");
        string val_175 = _info.Item["Camera_alternate_time"];
        // 0x00D83570: MOV x1, x0                 | X1 = val_175;//m1                       
        // 0x00D83574: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83578: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8357C: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_176 = System.Single.Parse(s:  0);
        // 0x00D83580: STR s0, [x19, #0x178]      | this.Camera_alternate_time = val_176;    //  dest_result_addr=1152921514531379208
        this.Camera_alternate_time = val_176;
        // 0x00D83584: B #0xd835bc                |  goto label_71;                         
        goto label_71;
        label_70:
        // 0x00D83588: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00D8358C: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00D83590: LDR x8, [x8, #0xf38]       | X8 = (string**)(1152921510122419296)("Camera_alternate_time");
        // 0x00D83594: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83598: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8359C: LDR x1, [x8]               | X1 = "Camera_alternate_time";           
        // 0x00D835A0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_alternate_time");
        string val_177 = _info.Item["Camera_alternate_time"];
        // 0x00D835A4: MOV x1, x0                 | X1 = val_177;//m1                       
        // 0x00D835A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D835AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D835B0: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_178 = System.Single.Parse(s:  0);
        // 0x00D835B4: STR s0, [x19, #0x178]      | this.Camera_alternate_time = val_178;    //  dest_result_addr=1152921514531379208
        this.Camera_alternate_time = val_178;
        // 0x00D835B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_71:
        // 0x00D835BC: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00D835C0: LDR x8, [x8, #0x6b8]       | X8 = (string**)(1152921510122421456)("Camera_time");
        // 0x00D835C4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D835C8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D835CC: LDR x1, [x8]               | X1 = "Camera_time";                     
        // 0x00D835D0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_time");
        string val_179 = _info.Item["Camera_time"];
        // 0x00D835D4: MOV x1, x0                 | X1 = val_179;//m1                       
        // 0x00D835D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D835DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D835E0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_180 = System.Int32.Parse(s:  0);
        // 0x00D835E4: STR w0, [x19, #0x17c]      | this.Camera_time = val_180;              //  dest_result_addr=1152921514531379212
        this.Camera_time = val_180;
        // 0x00D835E8: CBZ x20, #0xd8360c         | if (_info == null) goto label_72;       
        if(_info == null)
        {
            goto label_72;
        }
        // 0x00D835EC: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D835F0: LDR x8, [x8, #0x1a0]       | X8 = (string**)(1152921510122423600)("Camera_end");
        // 0x00D835F4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D835F8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D835FC: LDR x1, [x8]               | X1 = "Camera_end";                      
        // 0x00D83600: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_end");
        string val_181 = _info.Item["Camera_end"];
        // 0x00D83604: STR x0, [x19, #0x180]      | this.Camera_end = val_181;               //  dest_result_addr=1152921514531379216
        this.Camera_end = val_181;
        // 0x00D83608: B #0xd83630                |  goto label_73;                         
        goto label_73;
        label_72:
        // 0x00D8360C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_180, ????);    
        // 0x00D83610: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D83614: LDR x8, [x8, #0x1a0]       | X8 = (string**)(1152921510122423600)("Camera_end");
        // 0x00D83618: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8361C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83620: LDR x1, [x8]               | X1 = "Camera_end";                      
        // 0x00D83624: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_end");
        string val_182 = _info.Item["Camera_end"];
        // 0x00D83628: STR x0, [x19, #0x180]      | this.Camera_end = val_182;               //  dest_result_addr=1152921514531379216
        this.Camera_end = val_182;
        // 0x00D8362C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_182, ????);    
        label_73:
        // 0x00D83630: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x00D83634: LDR x8, [x8, #0xad8]       | X8 = (string**)(1152921510122425744)("Camera_rx");
        // 0x00D83638: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8363C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83640: LDR x1, [x8]               | X1 = "Camera_rx";                       
        // 0x00D83644: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_rx"); 
        string val_183 = _info.Item["Camera_rx"];
        // 0x00D83648: MOV x1, x0                 | X1 = val_183;//m1                       
        // 0x00D8364C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83650: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83654: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_184 = System.Single.Parse(s:  0);
        // 0x00D83658: STR s0, [x19, #0x188]      | this.Camera_rx = val_184;                //  dest_result_addr=1152921514531379224
        this.Camera_rx = val_184;
        // 0x00D8365C: CBZ x20, #0xd83690         | if (_info == null) goto label_74;       
        if(_info == null)
        {
            goto label_74;
        }
        // 0x00D83660: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D83664: LDR x8, [x8, #0x150]       | X8 = (string**)(1152921510122427888)("Camera_rx__outattack");
        // 0x00D83668: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8366C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83670: LDR x1, [x8]               | X1 = "Camera_rx__outattack";            
        // 0x00D83674: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_rx__outattack");
        string val_185 = _info.Item["Camera_rx__outattack"];
        // 0x00D83678: MOV x1, x0                 | X1 = val_185;//m1                       
        // 0x00D8367C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83680: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83684: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_186 = System.Int32.Parse(s:  0);
        // 0x00D83688: STR w0, [x19, #0x18c]      | this.Camera_rx__outattack = val_186;     //  dest_result_addr=1152921514531379228
        this.Camera_rx__outattack = val_186;
        // 0x00D8368C: B #0xd836c4                |  goto label_75;                         
        goto label_75;
        label_74:
        // 0x00D83690: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00D83694: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D83698: LDR x8, [x8, #0x150]       | X8 = (string**)(1152921510122427888)("Camera_rx__outattack");
        // 0x00D8369C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D836A0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D836A4: LDR x1, [x8]               | X1 = "Camera_rx__outattack";            
        // 0x00D836A8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_rx__outattack");
        string val_187 = _info.Item["Camera_rx__outattack"];
        // 0x00D836AC: MOV x1, x0                 | X1 = val_187;//m1                       
        // 0x00D836B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D836B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D836B8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_188 = System.Int32.Parse(s:  0);
        // 0x00D836BC: STR w0, [x19, #0x18c]      | this.Camera_rx__outattack = val_188;     //  dest_result_addr=1152921514531379228
        this.Camera_rx__outattack = val_188;
        // 0x00D836C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_188, ????);    
        label_75:
        // 0x00D836C4: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x00D836C8: LDR x8, [x8, #0x7f8]       | X8 = (string**)(1152921510122430048)("Camera_ry");
        // 0x00D836CC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D836D0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D836D4: LDR x1, [x8]               | X1 = "Camera_ry";                       
        // 0x00D836D8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_ry"); 
        string val_189 = _info.Item["Camera_ry"];
        // 0x00D836DC: MOV x1, x0                 | X1 = val_189;//m1                       
        // 0x00D836E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D836E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D836E8: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_190 = System.Single.Parse(s:  0);
        // 0x00D836EC: STR s0, [x19, #0x190]      | this.Camera_ry = val_190;                //  dest_result_addr=1152921514531379232
        this.Camera_ry = val_190;
        // 0x00D836F0: CBZ x20, #0xd83724         | if (_info == null) goto label_76;       
        if(_info == null)
        {
            goto label_76;
        }
        // 0x00D836F4: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
        // 0x00D836F8: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921510122432192)("Camera_posDamping");
        // 0x00D836FC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83700: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83704: LDR x1, [x8]               | X1 = "Camera_posDamping";               
        // 0x00D83708: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_posDamping");
        string val_191 = _info.Item["Camera_posDamping"];
        // 0x00D8370C: MOV x1, x0                 | X1 = val_191;//m1                       
        // 0x00D83710: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83714: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83718: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_192 = System.Single.Parse(s:  0);
        // 0x00D8371C: STR s0, [x19, #0x194]      | this.Camera_posDamping = val_192;        //  dest_result_addr=1152921514531379236
        this.Camera_posDamping = val_192;
        // 0x00D83720: B #0xd83758                |  goto label_77;                         
        goto label_77;
        label_76:
        // 0x00D83724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00D83728: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
        // 0x00D8372C: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921510122432192)("Camera_posDamping");
        // 0x00D83730: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83734: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83738: LDR x1, [x8]               | X1 = "Camera_posDamping";               
        // 0x00D8373C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_posDamping");
        string val_193 = _info.Item["Camera_posDamping"];
        // 0x00D83740: MOV x1, x0                 | X1 = val_193;//m1                       
        // 0x00D83744: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83748: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8374C: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_194 = System.Single.Parse(s:  0);
        // 0x00D83750: STR s0, [x19, #0x194]      | this.Camera_posDamping = val_194;        //  dest_result_addr=1152921514531379236
        this.Camera_posDamping = val_194;
        // 0x00D83754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_77:
        // 0x00D83758: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
        // 0x00D8375C: LDR x8, [x8, #0x210]       | X8 = (string**)(1152921510122434352)("Camera_MoveMax");
        // 0x00D83760: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83764: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83768: LDR x1, [x8]               | X1 = "Camera_MoveMax";                  
        // 0x00D8376C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_MoveMax");
        string val_195 = _info.Item["Camera_MoveMax"];
        // 0x00D83770: MOV x1, x0                 | X1 = val_195;//m1                       
        // 0x00D83774: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83778: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8377C: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_196 = System.Single.Parse(s:  0);
        // 0x00D83780: STR s0, [x19, #0x198]      | this.Camera_MoveMax = val_196;           //  dest_result_addr=1152921514531379240
        this.Camera_MoveMax = val_196;
        // 0x00D83784: CBZ x20, #0xd837b8         | if (_info == null) goto label_78;       
        if(_info == null)
        {
            goto label_78;
        }
        // 0x00D83788: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D8378C: LDR x8, [x8, #0xa88]       | X8 = (string**)(1152921510122436496)("Camera_waittime");
        // 0x00D83790: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83794: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83798: LDR x1, [x8]               | X1 = "Camera_waittime";                 
        // 0x00D8379C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_waittime");
        string val_197 = _info.Item["Camera_waittime"];
        // 0x00D837A0: MOV x1, x0                 | X1 = val_197;//m1                       
        // 0x00D837A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D837A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D837AC: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_198 = System.Single.Parse(s:  0);
        // 0x00D837B0: STR s0, [x19, #0x19c]      | this.Camera_waittime = val_198;          //  dest_result_addr=1152921514531379244
        this.Camera_waittime = val_198;
        // 0x00D837B4: B #0xd837ec                |  goto label_79;                         
        goto label_79;
        label_78:
        // 0x00D837B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00D837BC: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D837C0: LDR x8, [x8, #0xa88]       | X8 = (string**)(1152921510122436496)("Camera_waittime");
        // 0x00D837C4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D837C8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D837CC: LDR x1, [x8]               | X1 = "Camera_waittime";                 
        // 0x00D837D0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_waittime");
        string val_199 = _info.Item["Camera_waittime"];
        // 0x00D837D4: MOV x1, x0                 | X1 = val_199;//m1                       
        // 0x00D837D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D837DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D837E0: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_200 = System.Single.Parse(s:  0);
        // 0x00D837E4: STR s0, [x19, #0x19c]      | this.Camera_waittime = val_200;          //  dest_result_addr=1152921514531379244
        this.Camera_waittime = val_200;
        // 0x00D837E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_79:
        // 0x00D837EC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D837F0: LDR x8, [x8, #0x4e8]       | X8 = (string**)(1152921510122438656)("Camera_disMove");
        // 0x00D837F4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D837F8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D837FC: LDR x1, [x8]               | X1 = "Camera_disMove";                  
        // 0x00D83800: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Camera_disMove");
        string val_201 = _info.Item["Camera_disMove"];
        // 0x00D83804: MOV x1, x0                 | X1 = val_201;//m1                       
        // 0x00D83808: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8380C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83810: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_202 = System.Boolean.Parse(value:  0);
        // 0x00D83814: AND w8, w0, #1             | W8 = (val_202 & 1);                     
        bool val_203 = val_202;
        // 0x00D83818: STRB w8, [x19, #0x1a0]     | this.Camera_disMove = (val_202 & 1);     //  dest_result_addr=1152921514531379248
        this.Camera_disMove = val_203;
        // 0x00D8381C: CBZ x20, #0xd83854         | if (_info == null) goto label_80;       
        if(_info == null)
        {
            goto label_80;
        }
        // 0x00D83820: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
        // 0x00D83824: LDR x8, [x8, #0x1e0]       | X8 = (string**)(1152921510122440800)("IsExtryHero");
        // 0x00D83828: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8382C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83830: LDR x1, [x8]               | X1 = "IsExtryHero";                     
        // 0x00D83834: BL #0x23fc26c              | X0 = _info.get_Item(key:  "IsExtryHero");
        string val_204 = _info.Item["IsExtryHero"];
        // 0x00D83838: MOV x1, x0                 | X1 = val_204;//m1                       
        // 0x00D8383C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83840: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83844: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_205 = System.Boolean.Parse(value:  0);
        // 0x00D83848: AND w8, w0, #1             | W8 = (val_205 & 1);                     
        bool val_206 = val_205;
        // 0x00D8384C: STRB w8, [x19, #0x1a1]     | this.IsExtryHero = (val_205 & 1);        //  dest_result_addr=1152921514531379249
        this.IsExtryHero = val_206;
        // 0x00D83850: B #0xd8388c                |  goto label_81;                         
        goto label_81;
        label_80:
        // 0x00D83854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_202, ????);    
        // 0x00D83858: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
        // 0x00D8385C: LDR x8, [x8, #0x1e0]       | X8 = (string**)(1152921510122440800)("IsExtryHero");
        // 0x00D83860: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83864: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83868: LDR x1, [x8]               | X1 = "IsExtryHero";                     
        // 0x00D8386C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "IsExtryHero");
        string val_207 = _info.Item["IsExtryHero"];
        // 0x00D83870: MOV x1, x0                 | X1 = val_207;//m1                       
        // 0x00D83874: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83878: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8387C: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_208 = System.Boolean.Parse(value:  0);
        // 0x00D83880: AND w8, w0, #1             | W8 = (val_208 & 1);                     
        bool val_209 = val_208;
        // 0x00D83884: STRB w8, [x19, #0x1a1]     | this.IsExtryHero = (val_208 & 1);        //  dest_result_addr=1152921514531379249
        this.IsExtryHero = val_209;
        // 0x00D83888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_208, ????);    
        label_81:
        // 0x00D8388C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x00D83890: LDR x8, [x8, #0xb18]       | X8 = (string**)(1152921510122442944)("hero_Pos");
        // 0x00D83894: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83898: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8389C: LDR x1, [x8]               | X1 = "hero_Pos";                        
        // 0x00D838A0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "hero_Pos");  
        string val_210 = _info.Item["hero_Pos"];
        // 0x00D838A4: STR x0, [x19, #0x1a8]      | this.hero_Pos = val_210;                 //  dest_result_addr=1152921514531379256
        this.hero_Pos = val_210;
        // 0x00D838A8: CBZ x20, #0xd838dc         | if (_info == null) goto label_82;       
        if(_info == null)
        {
            goto label_82;
        }
        // 0x00D838AC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00D838B0: LDR x8, [x8, #0xc98]       | X8 = (string**)(1152921510122445088)("hero_Px");
        // 0x00D838B4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D838B8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D838BC: LDR x1, [x8]               | X1 = "hero_Px";                         
        // 0x00D838C0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "hero_Px");   
        string val_211 = _info.Item["hero_Px"];
        // 0x00D838C4: MOV x1, x0                 | X1 = val_211;//m1                       
        // 0x00D838C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D838CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D838D0: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_212 = System.Single.Parse(s:  0);
        // 0x00D838D4: STR s0, [x19, #0x1b0]      | this.hero_Px = val_212;                  //  dest_result_addr=1152921514531379264
        this.hero_Px = val_212;
        // 0x00D838D8: B #0xd83910                |  goto label_83;                         
        goto label_83;
        label_82:
        // 0x00D838DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_210, ????);    
        // 0x00D838E0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00D838E4: LDR x8, [x8, #0xc98]       | X8 = (string**)(1152921510122445088)("hero_Px");
        // 0x00D838E8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D838EC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D838F0: LDR x1, [x8]               | X1 = "hero_Px";                         
        // 0x00D838F4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "hero_Px");   
        string val_213 = _info.Item["hero_Px"];
        // 0x00D838F8: MOV x1, x0                 | X1 = val_213;//m1                       
        // 0x00D838FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83900: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83904: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_214 = System.Single.Parse(s:  0);
        // 0x00D83908: STR s0, [x19, #0x1b0]      | this.hero_Px = val_214;                  //  dest_result_addr=1152921514531379264
        this.hero_Px = val_214;
        // 0x00D8390C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_83:
        // 0x00D83910: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00D83914: LDR x8, [x8, #0x918]       | X8 = (string**)(1152921510122447232)("moster_Pos");
        // 0x00D83918: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8391C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83920: LDR x1, [x8]               | X1 = "moster_Pos";                      
        // 0x00D83924: BL #0x23fc26c              | X0 = _info.get_Item(key:  "moster_Pos");
        string val_215 = _info.Item["moster_Pos"];
        // 0x00D83928: STR x0, [x19, #0x1b8]      | this.moster_Pos = val_215;               //  dest_result_addr=1152921514531379272
        this.moster_Pos = val_215;
        // 0x00D8392C: CBZ x20, #0xd83960         | if (_info == null) goto label_84;       
        if(_info == null)
        {
            goto label_84;
        }
        // 0x00D83930: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
        // 0x00D83934: LDR x8, [x8, #0xc40]       | X8 = (string**)(1152921510122449376)("moster_Px");
        // 0x00D83938: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8393C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83940: LDR x1, [x8]               | X1 = "moster_Px";                       
        // 0x00D83944: BL #0x23fc26c              | X0 = _info.get_Item(key:  "moster_Px"); 
        string val_216 = _info.Item["moster_Px"];
        // 0x00D83948: MOV x1, x0                 | X1 = val_216;//m1                       
        // 0x00D8394C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83950: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83954: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_217 = System.Single.Parse(s:  0);
        // 0x00D83958: STR s0, [x19, #0x1c0]      | this.moster_Px = val_217;                //  dest_result_addr=1152921514531379280
        this.moster_Px = val_217;
        // 0x00D8395C: B #0xd83994                |  goto label_85;                         
        goto label_85;
        label_84:
        // 0x00D83960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_215, ????);    
        // 0x00D83964: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
        // 0x00D83968: LDR x8, [x8, #0xc40]       | X8 = (string**)(1152921510122449376)("moster_Px");
        // 0x00D8396C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83970: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83974: LDR x1, [x8]               | X1 = "moster_Px";                       
        // 0x00D83978: BL #0x23fc26c              | X0 = _info.get_Item(key:  "moster_Px"); 
        string val_218 = _info.Item["moster_Px"];
        // 0x00D8397C: MOV x1, x0                 | X1 = val_218;//m1                       
        // 0x00D83980: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83984: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83988: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_219 = System.Single.Parse(s:  0);
        // 0x00D8398C: STR s0, [x19, #0x1c0]      | this.moster_Px = val_219;                //  dest_result_addr=1152921514531379280
        this.moster_Px = val_219;
        // 0x00D83990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_85:
        // 0x00D83994: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x00D83998: LDR x8, [x8, #0xaa8]       | X8 = (string**)(1152921510122451520)("friendNpc");
        // 0x00D8399C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D839A0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D839A4: LDR x1, [x8]               | X1 = "friendNpc";                       
        // 0x00D839A8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "friendNpc"); 
        string val_220 = _info.Item["friendNpc"];
        // 0x00D839AC: MOV x1, x0                 | X1 = val_220;//m1                       
        // 0x00D839B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D839B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D839B8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_221 = System.Int32.Parse(s:  0);
        // 0x00D839BC: STR w0, [x19, #0x1c4]      | this.friendNpc = val_221;                //  dest_result_addr=1152921514531379284
        this.friendNpc = val_221;
        // 0x00D839C0: CBZ x20, #0xd839f4         | if (_info == null) goto label_86;       
        if(_info == null)
        {
            goto label_86;
        }
        // 0x00D839C4: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D839C8: LDR x8, [x8, #0x660]       | X8 = (string**)(1152921510122453664)("power");
        // 0x00D839CC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D839D0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D839D4: LDR x1, [x8]               | X1 = "power";                           
        // 0x00D839D8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "power");     
        string val_222 = _info.Item["power"];
        // 0x00D839DC: MOV x1, x0                 | X1 = val_222;//m1                       
        // 0x00D839E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D839E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D839E8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_223 = System.Int32.Parse(s:  0);
        // 0x00D839EC: STR w0, [x19, #0x1c8]      | this.power = val_223;                    //  dest_result_addr=1152921514531379288
        this.power = val_223;
        // 0x00D839F0: B #0xd83a28                |  goto label_87;                         
        goto label_87;
        label_86:
        // 0x00D839F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_221, ????);    
        // 0x00D839F8: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D839FC: LDR x8, [x8, #0x660]       | X8 = (string**)(1152921510122453664)("power");
        // 0x00D83A00: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83A04: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83A08: LDR x1, [x8]               | X1 = "power";                           
        // 0x00D83A0C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "power");     
        string val_224 = _info.Item["power"];
        // 0x00D83A10: MOV x1, x0                 | X1 = val_224;//m1                       
        // 0x00D83A14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83A18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83A1C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_225 = System.Int32.Parse(s:  0);
        // 0x00D83A20: STR w0, [x19, #0x1c8]      | this.power = val_225;                    //  dest_result_addr=1152921514531379288
        this.power = val_225;
        // 0x00D83A24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_225, ????);    
        label_87:
        // 0x00D83A28: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00D83A2C: LDR x8, [x8, #0xf78]       | X8 = (string**)(1152921510122455792)("maxSweepCount");
        // 0x00D83A30: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83A34: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83A38: LDR x1, [x8]               | X1 = "maxSweepCount";                   
        // 0x00D83A3C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "maxSweepCount");
        string val_226 = _info.Item["maxSweepCount"];
        // 0x00D83A40: MOV x1, x0                 | X1 = val_226;//m1                       
        // 0x00D83A44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83A48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83A4C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_227 = System.Int32.Parse(s:  0);
        // 0x00D83A50: STR w0, [x19, #0x1cc]      | this.maxSweepCount = val_227;            //  dest_result_addr=1152921514531379292
        this.maxSweepCount = val_227;
        // 0x00D83A54: CBZ x20, #0xd83a88         | if (_info == null) goto label_88;       
        if(_info == null)
        {
            goto label_88;
        }
        // 0x00D83A58: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00D83A5C: LDR x8, [x8, #0x9c8]       | X8 = (string**)(1152921510122457936)("maxCopper");
        // 0x00D83A60: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83A64: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83A68: LDR x1, [x8]               | X1 = "maxCopper";                       
        // 0x00D83A6C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "maxCopper"); 
        string val_228 = _info.Item["maxCopper"];
        // 0x00D83A70: MOV x1, x0                 | X1 = val_228;//m1                       
        // 0x00D83A74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83A78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83A7C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_229 = System.Int32.Parse(s:  0);
        // 0x00D83A80: STR w0, [x19, #0x1d0]      | this.maxCopper = val_229;                //  dest_result_addr=1152921514531379296
        this.maxCopper = val_229;
        // 0x00D83A84: B #0xd83abc                |  goto label_89;                         
        goto label_89;
        label_88:
        // 0x00D83A88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_227, ????);    
        // 0x00D83A8C: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00D83A90: LDR x8, [x8, #0x9c8]       | X8 = (string**)(1152921510122457936)("maxCopper");
        // 0x00D83A94: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83A98: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83A9C: LDR x1, [x8]               | X1 = "maxCopper";                       
        // 0x00D83AA0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "maxCopper"); 
        string val_230 = _info.Item["maxCopper"];
        // 0x00D83AA4: MOV x1, x0                 | X1 = val_230;//m1                       
        // 0x00D83AA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83AAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83AB0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_231 = System.Int32.Parse(s:  0);
        // 0x00D83AB4: STR w0, [x19, #0x1d0]      | this.maxCopper = val_231;                //  dest_result_addr=1152921514531379296
        this.maxCopper = val_231;
        // 0x00D83AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_231, ????);    
        label_89:
        // 0x00D83ABC: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
        // 0x00D83AC0: LDR x8, [x8, #0xeb8]       | X8 = (string**)(1152921510122460080)("need_checkpoint_id");
        // 0x00D83AC4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83AC8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83ACC: LDR x1, [x8]               | X1 = "need_checkpoint_id";              
        // 0x00D83AD0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "need_checkpoint_id");
        string val_232 = _info.Item["need_checkpoint_id"];
        // 0x00D83AD4: MOV x1, x0                 | X1 = val_232;//m1                       
        // 0x00D83AD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83ADC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83AE0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_233 = System.Int32.Parse(s:  0);
        // 0x00D83AE4: STR w0, [x19, #0x1d4]      | this.need_checkpoint_id = val_233;       //  dest_result_addr=1152921514531379300
        this.need_checkpoint_id = val_233;
        // 0x00D83AE8: CBZ x20, #0xd83b1c         | if (_info == null) goto label_90;       
        if(_info == null)
        {
            goto label_90;
        }
        // 0x00D83AEC: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00D83AF0: LDR x8, [x8, #0x208]       | X8 = (string**)(1152921510122462240)("need_normal_checkpoint_id");
        // 0x00D83AF4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83AF8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83AFC: LDR x1, [x8]               | X1 = "need_normal_checkpoint_id";       
        // 0x00D83B00: BL #0x23fc26c              | X0 = _info.get_Item(key:  "need_normal_checkpoint_id");
        string val_234 = _info.Item["need_normal_checkpoint_id"];
        // 0x00D83B04: MOV x1, x0                 | X1 = val_234;//m1                       
        // 0x00D83B08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83B0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83B10: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_235 = System.Int32.Parse(s:  0);
        // 0x00D83B14: STR w0, [x19, #0x1d8]      | this.need_normal_checkpoint_id = val_235;  //  dest_result_addr=1152921514531379304
        this.need_normal_checkpoint_id = val_235;
        // 0x00D83B18: B #0xd83b50                |  goto label_91;                         
        goto label_91;
        label_90:
        // 0x00D83B1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_233, ????);    
        // 0x00D83B20: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00D83B24: LDR x8, [x8, #0x208]       | X8 = (string**)(1152921510122462240)("need_normal_checkpoint_id");
        // 0x00D83B28: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83B2C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83B30: LDR x1, [x8]               | X1 = "need_normal_checkpoint_id";       
        // 0x00D83B34: BL #0x23fc26c              | X0 = _info.get_Item(key:  "need_normal_checkpoint_id");
        string val_236 = _info.Item["need_normal_checkpoint_id"];
        // 0x00D83B38: MOV x1, x0                 | X1 = val_236;//m1                       
        // 0x00D83B3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83B40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83B44: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_237 = System.Int32.Parse(s:  0);
        // 0x00D83B48: STR w0, [x19, #0x1d8]      | this.need_normal_checkpoint_id = val_237;  //  dest_result_addr=1152921514531379304
        this.need_normal_checkpoint_id = val_237;
        // 0x00D83B4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_237, ????);    
        label_91:
        // 0x00D83B50: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
        // 0x00D83B54: LDR x8, [x8, #0x258]       | X8 = (string**)(1152921510122464416)("need_role_level");
        // 0x00D83B58: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83B5C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83B60: LDR x1, [x8]               | X1 = "need_role_level";                 
        // 0x00D83B64: BL #0x23fc26c              | X0 = _info.get_Item(key:  "need_role_level");
        string val_238 = _info.Item["need_role_level"];
        // 0x00D83B68: MOV x1, x0                 | X1 = val_238;//m1                       
        // 0x00D83B6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83B70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83B74: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_239 = System.Int32.Parse(s:  0);
        // 0x00D83B78: STR w0, [x19, #0x1dc]      | this.need_role_level = val_239;          //  dest_result_addr=1152921514531379308
        this.need_role_level = val_239;
        // 0x00D83B7C: CBZ x20, #0xd83bb0         | if (_info == null) goto label_92;       
        if(_info == null)
        {
            goto label_92;
        }
        // 0x00D83B80: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D83B84: LDR x8, [x8, #0x780]       | X8 = (string**)(1152921510122466576)("bigType");
        // 0x00D83B88: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83B8C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83B90: LDR x1, [x8]               | X1 = "bigType";                         
        // 0x00D83B94: BL #0x23fc26c              | X0 = _info.get_Item(key:  "bigType");   
        string val_240 = _info.Item["bigType"];
        // 0x00D83B98: MOV x1, x0                 | X1 = val_240;//m1                       
        // 0x00D83B9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83BA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83BA4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_241 = System.Int32.Parse(s:  0);
        // 0x00D83BA8: STR w0, [x19, #0x1e0]      | this.bigType = val_241;                  //  dest_result_addr=1152921514531379312
        this.bigType = val_241;
        // 0x00D83BAC: B #0xd83be4                |  goto label_93;                         
        goto label_93;
        label_92:
        // 0x00D83BB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_239, ????);    
        // 0x00D83BB4: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D83BB8: LDR x8, [x8, #0x780]       | X8 = (string**)(1152921510122466576)("bigType");
        // 0x00D83BBC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83BC0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83BC4: LDR x1, [x8]               | X1 = "bigType";                         
        // 0x00D83BC8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "bigType");   
        string val_242 = _info.Item["bigType"];
        // 0x00D83BCC: MOV x1, x0                 | X1 = val_242;//m1                       
        // 0x00D83BD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83BD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83BD8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_243 = System.Int32.Parse(s:  0);
        // 0x00D83BDC: STR w0, [x19, #0x1e0]      | this.bigType = val_243;                  //  dest_result_addr=1152921514531379312
        this.bigType = val_243;
        // 0x00D83BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_243, ????);    
        label_93:
        // 0x00D83BE4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00D83BE8: LDR x8, [x8, #0xd68]       | X8 = (string**)(1152921510122468720)("isAutoCreatNpc");
        // 0x00D83BEC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83BF0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83BF4: LDR x1, [x8]               | X1 = "isAutoCreatNpc";                  
        // 0x00D83BF8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isAutoCreatNpc");
        string val_244 = _info.Item["isAutoCreatNpc"];
        // 0x00D83BFC: MOV x1, x0                 | X1 = val_244;//m1                       
        // 0x00D83C00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83C04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83C08: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_245 = System.Boolean.Parse(value:  0);
        // 0x00D83C0C: AND w8, w0, #1             | W8 = (val_245 & 1);                     
        bool val_246 = val_245;
        // 0x00D83C10: STRB w8, [x19, #0x1e4]     | this.isAutoCreatNpc = (val_245 & 1);     //  dest_result_addr=1152921514531379316
        this.isAutoCreatNpc = val_246;
        // 0x00D83C14: CBZ x20, #0xd83c48         | if (_info == null) goto label_94;       
        if(_info == null)
        {
            goto label_94;
        }
        // 0x00D83C18: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
        // 0x00D83C1C: LDR x8, [x8, #0x5c8]       | X8 = (string**)(1152921510122470864)("bossId");
        // 0x00D83C20: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83C24: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83C28: LDR x1, [x8]               | X1 = "bossId";                          
        // 0x00D83C2C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "bossId");    
        string val_247 = _info.Item["bossId"];
        // 0x00D83C30: MOV x1, x0                 | X1 = val_247;//m1                       
        // 0x00D83C34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83C38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83C3C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_248 = System.Int32.Parse(s:  0);
        // 0x00D83C40: STR w0, [x19, #0x1e8]      | this.bossId = val_248;                   //  dest_result_addr=1152921514531379320
        this.bossId = val_248;
        // 0x00D83C44: B #0xd83c7c                |  goto label_95;                         
        goto label_95;
        label_94:
        // 0x00D83C48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_245, ????);    
        // 0x00D83C4C: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
        // 0x00D83C50: LDR x8, [x8, #0x5c8]       | X8 = (string**)(1152921510122470864)("bossId");
        // 0x00D83C54: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83C58: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83C5C: LDR x1, [x8]               | X1 = "bossId";                          
        // 0x00D83C60: BL #0x23fc26c              | X0 = _info.get_Item(key:  "bossId");    
        string val_249 = _info.Item["bossId"];
        // 0x00D83C64: MOV x1, x0                 | X1 = val_249;//m1                       
        // 0x00D83C68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83C6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83C70: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_250 = System.Int32.Parse(s:  0);
        // 0x00D83C74: STR w0, [x19, #0x1e8]      | this.bossId = val_250;                   //  dest_result_addr=1152921514531379320
        this.bossId = val_250;
        // 0x00D83C78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_250, ????);    
        label_95:
        // 0x00D83C7C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00D83C80: LDR x8, [x8, #0xa8]        | X8 = (string**)(1152921510122472992)("isSpeedup");
        // 0x00D83C84: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83C88: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83C8C: LDR x1, [x8]               | X1 = "isSpeedup";                       
        // 0x00D83C90: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isSpeedup"); 
        string val_251 = _info.Item["isSpeedup"];
        // 0x00D83C94: MOV x1, x0                 | X1 = val_251;//m1                       
        // 0x00D83C98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83C9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83CA0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_252 = System.Int32.Parse(s:  0);
        // 0x00D83CA4: STR w0, [x19, #0x1ec]      | this.isSpeedup = val_252;                //  dest_result_addr=1152921514531379324
        this.isSpeedup = val_252;
        // 0x00D83CA8: CBZ x20, #0xd83ccc         | if (_info == null) goto label_96;       
        if(_info == null)
        {
            goto label_96;
        }
        // 0x00D83CAC: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00D83CB0: LDR x8, [x8, #0xb78]       | X8 = (string**)(1152921510122475136)("largeTip");
        // 0x00D83CB4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83CB8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83CBC: LDR x1, [x8]               | X1 = "largeTip";                        
        // 0x00D83CC0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "largeTip");  
        string val_253 = _info.Item["largeTip"];
        // 0x00D83CC4: STR x0, [x19, #0x1f0]      | this.largeTip = val_253;                 //  dest_result_addr=1152921514531379328
        this.largeTip = val_253;
        // 0x00D83CC8: B #0xd83cf0                |  goto label_97;                         
        goto label_97;
        label_96:
        // 0x00D83CCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_252, ????);    
        // 0x00D83CD0: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00D83CD4: LDR x8, [x8, #0xb78]       | X8 = (string**)(1152921510122475136)("largeTip");
        // 0x00D83CD8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83CDC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83CE0: LDR x1, [x8]               | X1 = "largeTip";                        
        // 0x00D83CE4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "largeTip");  
        string val_254 = _info.Item["largeTip"];
        // 0x00D83CE8: STR x0, [x19, #0x1f0]      | this.largeTip = val_254;                 //  dest_result_addr=1152921514531379328
        this.largeTip = val_254;
        // 0x00D83CEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_254, ????);    
        label_97:
        // 0x00D83CF0: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00D83CF4: LDR x8, [x8, #0xe68]       | X8 = (string**)(1152921510122477280)("isTop");
        // 0x00D83CF8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83CFC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83D00: LDR x1, [x8]               | X1 = "isTop";                           
        // 0x00D83D04: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isTop");     
        string val_255 = _info.Item["isTop"];
        // 0x00D83D08: MOV x1, x0                 | X1 = val_255;//m1                       
        // 0x00D83D0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83D10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83D14: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_256 = System.Int32.Parse(s:  0);
        // 0x00D83D18: STR w0, [x19, #0x1f8]      | this.isTop = val_256;                    //  dest_result_addr=1152921514531379336
        this.isTop = val_256;
        // 0x00D83D1C: CBZ x20, #0xd83d50         | if (_info == null) goto label_98;       
        if(_info == null)
        {
            goto label_98;
        }
        // 0x00D83D20: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00D83D24: LDR x8, [x8, #0xc80]       | X8 = (string**)(1152921510122479408)("monsterwavecount");
        // 0x00D83D28: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83D2C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83D30: LDR x1, [x8]               | X1 = "monsterwavecount";                
        // 0x00D83D34: BL #0x23fc26c              | X0 = _info.get_Item(key:  "monsterwavecount");
        string val_257 = _info.Item["monsterwavecount"];
        // 0x00D83D38: MOV x1, x0                 | X1 = val_257;//m1                       
        // 0x00D83D3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83D40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83D44: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_258 = System.Int32.Parse(s:  0);
        // 0x00D83D48: STR w0, [x19, #0x1fc]      | this.monsterwavecount = val_258;         //  dest_result_addr=1152921514531379340
        this.monsterwavecount = val_258;
        // 0x00D83D4C: B #0xd83d84                |  goto label_99;                         
        goto label_99;
        label_98:
        // 0x00D83D50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_256, ????);    
        // 0x00D83D54: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00D83D58: LDR x8, [x8, #0xc80]       | X8 = (string**)(1152921510122479408)("monsterwavecount");
        // 0x00D83D5C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83D60: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83D64: LDR x1, [x8]               | X1 = "monsterwavecount";                
        // 0x00D83D68: BL #0x23fc26c              | X0 = _info.get_Item(key:  "monsterwavecount");
        string val_259 = _info.Item["monsterwavecount"];
        // 0x00D83D6C: MOV x1, x0                 | X1 = val_259;//m1                       
        // 0x00D83D70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83D74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83D78: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_260 = System.Int32.Parse(s:  0);
        // 0x00D83D7C: STR w0, [x19, #0x1fc]      | this.monsterwavecount = val_260;         //  dest_result_addr=1152921514531379340
        this.monsterwavecount = val_260;
        // 0x00D83D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_260, ????);    
        label_99:
        // 0x00D83D84: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
        // 0x00D83D88: LDR x8, [x8, #0x5f8]       | X8 = (string**)(1152921510122481568)("islvrepress");
        // 0x00D83D8C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83D90: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83D94: LDR x1, [x8]               | X1 = "islvrepress";                     
        // 0x00D83D98: BL #0x23fc26c              | X0 = _info.get_Item(key:  "islvrepress");
        string val_261 = _info.Item["islvrepress"];
        // 0x00D83D9C: MOV x1, x0                 | X1 = val_261;//m1                       
        // 0x00D83DA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83DA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83DA8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_262 = System.Int32.Parse(s:  0);
        // 0x00D83DAC: STR w0, [x19, #0x200]      | this.islvrepress = val_262;              //  dest_result_addr=1152921514531379344
        this.islvrepress = val_262;
        // 0x00D83DB0: CBZ x20, #0xd83de8         | if (_info == null) goto label_100;      
        if(_info == null)
        {
            goto label_100;
        }
        // 0x00D83DB4: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00D83DB8: LDR x8, [x8, #0x670]       | X8 = (string**)(1152921510122483712)("isShowNew");
        // 0x00D83DBC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83DC0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83DC4: LDR x1, [x8]               | X1 = "isShowNew";                       
        // 0x00D83DC8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isShowNew"); 
        string val_263 = _info.Item["isShowNew"];
        // 0x00D83DCC: MOV x1, x0                 | X1 = val_263;//m1                       
        // 0x00D83DD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83DD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83DD8: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_264 = System.Boolean.Parse(value:  0);
        // 0x00D83DDC: AND w8, w0, #1             | W8 = (val_264 & 1);                     
        bool val_265 = val_264;
        // 0x00D83DE0: STRB w8, [x19, #0x204]     | this.isShowNew = (val_264 & 1);          //  dest_result_addr=1152921514531379348
        this.isShowNew = val_265;
        // 0x00D83DE4: B #0xd83e20                |  goto label_101;                        
        goto label_101;
        label_100:
        // 0x00D83DE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_262, ????);    
        // 0x00D83DEC: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00D83DF0: LDR x8, [x8, #0x670]       | X8 = (string**)(1152921510122483712)("isShowNew");
        // 0x00D83DF4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83DF8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83DFC: LDR x1, [x8]               | X1 = "isShowNew";                       
        // 0x00D83E00: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isShowNew"); 
        string val_266 = _info.Item["isShowNew"];
        // 0x00D83E04: MOV x1, x0                 | X1 = val_266;//m1                       
        // 0x00D83E08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83E0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83E10: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_267 = System.Boolean.Parse(value:  0);
        // 0x00D83E14: AND w8, w0, #1             | W8 = (val_267 & 1);                     
        bool val_268 = val_267;
        // 0x00D83E18: STRB w8, [x19, #0x204]     | this.isShowNew = (val_267 & 1);          //  dest_result_addr=1152921514531379348
        this.isShowNew = val_268;
        // 0x00D83E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_267, ????);    
        label_101:
        // 0x00D83E20: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x00D83E24: LDR x8, [x8, #0x98]        | X8 = (string**)(1152921510122485856)("loc1_anger");
        // 0x00D83E28: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83E2C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83E30: LDR x1, [x8]               | X1 = "loc1_anger";                      
        // 0x00D83E34: BL #0x23fc26c              | X0 = _info.get_Item(key:  "loc1_anger");
        string val_269 = _info.Item["loc1_anger"];
        // 0x00D83E38: MOV x1, x0                 | X1 = val_269;//m1                       
        // 0x00D83E3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83E40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83E44: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_270 = System.Int32.Parse(s:  0);
        // 0x00D83E48: STR w0, [x19, #0x208]      | this.loc1_anger = val_270;               //  dest_result_addr=1152921514531379352
        this.loc1_anger = val_270;
        // 0x00D83E4C: CBZ x20, #0xd83e80         | if (_info == null) goto label_102;      
        if(_info == null)
        {
            goto label_102;
        }
        // 0x00D83E50: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
        // 0x00D83E54: LDR x8, [x8, #0x620]       | X8 = (string**)(1152921510122488000)("loc2_anger");
        // 0x00D83E58: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83E5C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83E60: LDR x1, [x8]               | X1 = "loc2_anger";                      
        // 0x00D83E64: BL #0x23fc26c              | X0 = _info.get_Item(key:  "loc2_anger");
        string val_271 = _info.Item["loc2_anger"];
        // 0x00D83E68: MOV x1, x0                 | X1 = val_271;//m1                       
        // 0x00D83E6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83E70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83E74: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_272 = System.Int32.Parse(s:  0);
        // 0x00D83E78: STR w0, [x19, #0x20c]      | this.loc2_anger = val_272;               //  dest_result_addr=1152921514531379356
        this.loc2_anger = val_272;
        // 0x00D83E7C: B #0xd83eb4                |  goto label_103;                        
        goto label_103;
        label_102:
        // 0x00D83E80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_270, ????);    
        // 0x00D83E84: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
        // 0x00D83E88: LDR x8, [x8, #0x620]       | X8 = (string**)(1152921510122488000)("loc2_anger");
        // 0x00D83E8C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83E90: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83E94: LDR x1, [x8]               | X1 = "loc2_anger";                      
        // 0x00D83E98: BL #0x23fc26c              | X0 = _info.get_Item(key:  "loc2_anger");
        string val_273 = _info.Item["loc2_anger"];
        // 0x00D83E9C: MOV x1, x0                 | X1 = val_273;//m1                       
        // 0x00D83EA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83EA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83EA8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_274 = System.Int32.Parse(s:  0);
        // 0x00D83EAC: STR w0, [x19, #0x20c]      | this.loc2_anger = val_274;               //  dest_result_addr=1152921514531379356
        this.loc2_anger = val_274;
        // 0x00D83EB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_274, ????);    
        label_103:
        // 0x00D83EB4: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00D83EB8: LDR x8, [x8, #0x510]       | X8 = (string**)(1152921510122490144)("loc3_anger");
        // 0x00D83EBC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83EC0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83EC4: LDR x1, [x8]               | X1 = "loc3_anger";                      
        // 0x00D83EC8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "loc3_anger");
        string val_275 = _info.Item["loc3_anger"];
        // 0x00D83ECC: MOV x1, x0                 | X1 = val_275;//m1                       
        // 0x00D83ED0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83ED4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83ED8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_276 = System.Int32.Parse(s:  0);
        // 0x00D83EDC: STR w0, [x19, #0x210]      | this.loc3_anger = val_276;               //  dest_result_addr=1152921514531379360
        this.loc3_anger = val_276;
        // 0x00D83EE0: CBZ x20, #0xd83f14         | if (_info == null) goto label_104;      
        if(_info == null)
        {
            goto label_104;
        }
        // 0x00D83EE4: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00D83EE8: LDR x8, [x8, #0x60]        | X8 = (string**)(1152921510122492288)("loc4_anger");
        // 0x00D83EEC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83EF0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83EF4: LDR x1, [x8]               | X1 = "loc4_anger";                      
        // 0x00D83EF8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "loc4_anger");
        string val_277 = _info.Item["loc4_anger"];
        // 0x00D83EFC: MOV x1, x0                 | X1 = val_277;//m1                       
        // 0x00D83F00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83F04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83F08: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_278 = System.Int32.Parse(s:  0);
        // 0x00D83F0C: STR w0, [x19, #0x214]      | this.loc4_anger = val_278;               //  dest_result_addr=1152921514531379364
        this.loc4_anger = val_278;
        // 0x00D83F10: B #0xd83f48                |  goto label_105;                        
        goto label_105;
        label_104:
        // 0x00D83F14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_276, ????);    
        // 0x00D83F18: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00D83F1C: LDR x8, [x8, #0x60]        | X8 = (string**)(1152921510122492288)("loc4_anger");
        // 0x00D83F20: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83F24: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83F28: LDR x1, [x8]               | X1 = "loc4_anger";                      
        // 0x00D83F2C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "loc4_anger");
        string val_279 = _info.Item["loc4_anger"];
        // 0x00D83F30: MOV x1, x0                 | X1 = val_279;//m1                       
        // 0x00D83F34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83F38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83F3C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_280 = System.Int32.Parse(s:  0);
        // 0x00D83F40: STR w0, [x19, #0x214]      | this.loc4_anger = val_280;               //  dest_result_addr=1152921514531379364
        this.loc4_anger = val_280;
        // 0x00D83F44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_280, ????);    
        label_105:
        // 0x00D83F48: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D83F4C: LDR x8, [x8, #0x3c0]       | X8 = (string**)(1152921510122494432)("boxID");
        // 0x00D83F50: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83F54: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83F58: LDR x1, [x8]               | X1 = "boxID";                           
        // 0x00D83F5C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "boxID");     
        string val_281 = _info.Item["boxID"];
        // 0x00D83F60: MOV x1, x0                 | X1 = val_281;//m1                       
        // 0x00D83F64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83F68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83F6C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_282 = System.Int32.Parse(s:  0);
        // 0x00D83F70: STR w0, [x19, #0x218]      | this.boxID = val_282;                    //  dest_result_addr=1152921514531379368
        this.boxID = val_282;
        // 0x00D83F74: CBZ x20, #0xd83f98         | if (_info == null) goto label_106;      
        if(_info == null)
        {
            goto label_106;
        }
        // 0x00D83F78: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D83F7C: LDR x8, [x8, #0xcd0]       | X8 = (string**)(1152921510122496560)("treasure_pos");
        // 0x00D83F80: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83F84: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83F88: LDR x1, [x8]               | X1 = "treasure_pos";                    
        // 0x00D83F8C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "treasure_pos");
        string val_283 = _info.Item["treasure_pos"];
        // 0x00D83F90: STR x0, [x19, #0x220]      | this.treasure_pos = val_283;             //  dest_result_addr=1152921514531379376
        this.treasure_pos = val_283;
        // 0x00D83F94: B #0xd83fbc                |  goto label_107;                        
        goto label_107;
        label_106:
        // 0x00D83F98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_282, ????);    
        // 0x00D83F9C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D83FA0: LDR x8, [x8, #0xcd0]       | X8 = (string**)(1152921510122496560)("treasure_pos");
        // 0x00D83FA4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83FA8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83FAC: LDR x1, [x8]               | X1 = "treasure_pos";                    
        // 0x00D83FB0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "treasure_pos");
        string val_284 = _info.Item["treasure_pos"];
        // 0x00D83FB4: STR x0, [x19, #0x220]      | this.treasure_pos = val_284;             //  dest_result_addr=1152921514531379376
        this.treasure_pos = val_284;
        // 0x00D83FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_284, ????);    
        label_107:
        // 0x00D83FBC: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00D83FC0: LDR x8, [x8, #0xe10]       | X8 = (string**)(1152921510122498704)("is_superskill_prompt");
        // 0x00D83FC4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83FC8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D83FCC: LDR x1, [x8]               | X1 = "is_superskill_prompt";            
        // 0x00D83FD0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "is_superskill_prompt");
        string val_285 = _info.Item["is_superskill_prompt"];
        // 0x00D83FD4: MOV x1, x0                 | X1 = val_285;//m1                       
        // 0x00D83FD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D83FDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D83FE0: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_286 = System.Boolean.Parse(value:  0);
        // 0x00D83FE4: AND w8, w0, #1             | W8 = (val_286 & 1);                     
        bool val_287 = val_286;
        // 0x00D83FE8: STRB w8, [x19, #0x228]     | this.is_superskill_prompt = (val_286 & 1);  //  dest_result_addr=1152921514531379384
        this.is_superskill_prompt = val_287;
        // 0x00D83FEC: CBZ x20, #0xd84024         | if (_info == null) goto label_108;      
        if(_info == null)
        {
            goto label_108;
        }
        // 0x00D83FF0: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
        // 0x00D83FF4: LDR x8, [x8, #0x268]       | X8 = (string**)(1152921510122500864)("ifUseHint");
        // 0x00D83FF8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D83FFC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D84000: LDR x1, [x8]               | X1 = "ifUseHint";                       
        // 0x00D84004: BL #0x23fc26c              | X0 = _info.get_Item(key:  "ifUseHint"); 
        string val_288 = _info.Item["ifUseHint"];
        // 0x00D84008: MOV x1, x0                 | X1 = val_288;//m1                       
        // 0x00D8400C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84010: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84014: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_289 = System.Boolean.Parse(value:  0);
        // 0x00D84018: AND w8, w0, #1             | W8 = (val_289 & 1);                     
        bool val_290 = val_289;
        // 0x00D8401C: STRB w8, [x19, #0x229]     | this.ifUseHint = (val_289 & 1);          //  dest_result_addr=1152921514531379385
        this.ifUseHint = val_290;
        // 0x00D84020: B #0xd8405c                |  goto label_109;                        
        goto label_109;
        label_108:
        // 0x00D84024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_286, ????);    
        // 0x00D84028: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
        // 0x00D8402C: LDR x8, [x8, #0x268]       | X8 = (string**)(1152921510122500864)("ifUseHint");
        // 0x00D84030: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84034: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D84038: LDR x1, [x8]               | X1 = "ifUseHint";                       
        // 0x00D8403C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "ifUseHint"); 
        string val_291 = _info.Item["ifUseHint"];
        // 0x00D84040: MOV x1, x0                 | X1 = val_291;//m1                       
        // 0x00D84044: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84048: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8404C: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_292 = System.Boolean.Parse(value:  0);
        // 0x00D84050: AND w8, w0, #1             | W8 = (val_292 & 1);                     
        bool val_293 = val_292;
        // 0x00D84054: STRB w8, [x19, #0x229]     | this.ifUseHint = (val_292 & 1);          //  dest_result_addr=1152921514531379385
        this.ifUseHint = val_293;
        // 0x00D84058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_292, ????);    
        label_109:
        // 0x00D8405C: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
        // 0x00D84060: LDR x8, [x8, #0xea0]       | X8 = (string**)(1152921510122503008)("hintText");
        // 0x00D84064: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84068: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8406C: LDR x1, [x8]               | X1 = "hintText";                        
        // 0x00D84070: BL #0x23fc26c              | X0 = _info.get_Item(key:  "hintText");  
        string val_294 = _info.Item["hintText"];
        // 0x00D84074: STR x0, [x19, #0x230]      | this.hintText = val_294;                 //  dest_result_addr=1152921514531379392
        this.hintText = val_294;
        // 0x00D84078: CBZ x20, #0xd840ac         | if (_info == null) goto label_110;      
        if(_info == null)
        {
            goto label_110;
        }
        // 0x00D8407C: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
        // 0x00D84080: LDR x8, [x8, #0x980]       | X8 = (string**)(1152921510122505152)("guide_or_not");
        // 0x00D84084: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84088: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8408C: LDR x1, [x8]               | X1 = "guide_or_not";                    
        // 0x00D84090: BL #0x23fc26c              | X0 = _info.get_Item(key:  "guide_or_not");
        string val_295 = _info.Item["guide_or_not"];
        // 0x00D84094: MOV x1, x0                 | X1 = val_295;//m1                       
        // 0x00D84098: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8409C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D840A0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_296 = System.Int32.Parse(s:  0);
        // 0x00D840A4: STR w0, [x19, #0x238]      | this.guide_or_not = val_296;             //  dest_result_addr=1152921514531379400
        this.guide_or_not = val_296;
        // 0x00D840A8: B #0xd840e0                |  goto label_111;                        
        goto label_111;
        label_110:
        // 0x00D840AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_294, ????);    
        // 0x00D840B0: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
        // 0x00D840B4: LDR x8, [x8, #0x980]       | X8 = (string**)(1152921510122505152)("guide_or_not");
        // 0x00D840B8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D840BC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D840C0: LDR x1, [x8]               | X1 = "guide_or_not";                    
        // 0x00D840C4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "guide_or_not");
        string val_297 = _info.Item["guide_or_not"];
        // 0x00D840C8: MOV x1, x0                 | X1 = val_297;//m1                       
        // 0x00D840CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D840D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D840D4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_298 = System.Int32.Parse(s:  0);
        // 0x00D840D8: STR w0, [x19, #0x238]      | this.guide_or_not = val_298;             //  dest_result_addr=1152921514531379400
        this.guide_or_not = val_298;
        // 0x00D840DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_298, ????);    
        label_111:
        // 0x00D840E0: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00D840E4: LDR x8, [x8, #0x330]       | X8 = (string**)(1152921510122507296)("chapter_id");
        // 0x00D840E8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D840EC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D840F0: LDR x1, [x8]               | X1 = "chapter_id";                      
        // 0x00D840F4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "chapter_id");
        string val_299 = _info.Item["chapter_id"];
        // 0x00D840F8: MOV x1, x0                 | X1 = val_299;//m1                       
        // 0x00D840FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84100: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84104: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_300 = System.Int32.Parse(s:  0);
        // 0x00D84108: STR w0, [x19, #0x23c]      | this.chapter_id = val_300;               //  dest_result_addr=1152921514531379404
        this.chapter_id = val_300;
        // 0x00D8410C: CBZ x20, #0xd84140         | if (_info == null) goto label_112;      
        if(_info == null)
        {
            goto label_112;
        }
        // 0x00D84110: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00D84114: LDR x8, [x8, #0xfb0]       | X8 = (string**)(1152921510122509440)("energy_rate");
        // 0x00D84118: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8411C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D84120: LDR x1, [x8]               | X1 = "energy_rate";                     
        // 0x00D84124: BL #0x23fc26c              | X0 = _info.get_Item(key:  "energy_rate");
        string val_301 = _info.Item["energy_rate"];
        // 0x00D84128: MOV x1, x0                 | X1 = val_301;//m1                       
        // 0x00D8412C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84130: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84134: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_302 = System.Int32.Parse(s:  0);
        // 0x00D84138: STR w0, [x19, #0x240]      | this.energy_rate = val_302;              //  dest_result_addr=1152921514531379408
        this.energy_rate = val_302;
        // 0x00D8413C: B #0xd84174                |  goto label_113;                        
        goto label_113;
        label_112:
        // 0x00D84140: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_300, ????);    
        // 0x00D84144: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00D84148: LDR x8, [x8, #0xfb0]       | X8 = (string**)(1152921510122509440)("energy_rate");
        // 0x00D8414C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84150: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D84154: LDR x1, [x8]               | X1 = "energy_rate";                     
        // 0x00D84158: BL #0x23fc26c              | X0 = _info.get_Item(key:  "energy_rate");
        string val_303 = _info.Item["energy_rate"];
        // 0x00D8415C: MOV x1, x0                 | X1 = val_303;//m1                       
        // 0x00D84160: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84164: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84168: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_304 = System.Int32.Parse(s:  0);
        // 0x00D8416C: STR w0, [x19, #0x240]      | this.energy_rate = val_304;              //  dest_result_addr=1152921514531379408
        this.energy_rate = val_304;
        // 0x00D84170: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_304, ????);    
        label_113:
        // 0x00D84174: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00D84178: LDR x8, [x8, #0x950]       | X8 = (string**)(1152921510122511584)("wait_time");
        // 0x00D8417C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84180: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D84184: LDR x1, [x8]               | X1 = "wait_time";                       
        // 0x00D84188: BL #0x23fc26c              | X0 = _info.get_Item(key:  "wait_time"); 
        string val_305 = _info.Item["wait_time"];
        // 0x00D8418C: MOV x1, x0                 | X1 = val_305;//m1                       
        // 0x00D84190: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84194: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84198: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_306 = System.Single.Parse(s:  0);
        // 0x00D8419C: STR s0, [x19, #0x244]      | this.wait_time = val_306;                //  dest_result_addr=1152921514531379412
        this.wait_time = val_306;
        // 0x00D841A0: CBZ x20, #0xd841d4         | if (_info == null) goto label_114;      
        if(_info == null)
        {
            goto label_114;
        }
        // 0x00D841A4: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
        // 0x00D841A8: LDR x8, [x8, #0x1e0]       | X8 = (string**)(1152921510122513728)("item_id");
        // 0x00D841AC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D841B0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D841B4: LDR x1, [x8]               | X1 = "item_id";                         
        // 0x00D841B8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "item_id");   
        string val_307 = _info.Item["item_id"];
        // 0x00D841BC: MOV x1, x0                 | X1 = val_307;//m1                       
        // 0x00D841C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D841C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D841C8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_308 = System.Int32.Parse(s:  0);
        // 0x00D841CC: STR w0, [x19, #0x248]      | this.item_id = val_308;                  //  dest_result_addr=1152921514531379416
        this.item_id = val_308;
        // 0x00D841D0: B #0xd84208                |  goto label_115;                        
        goto label_115;
        label_114:
        // 0x00D841D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00D841D8: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
        // 0x00D841DC: LDR x8, [x8, #0x1e0]       | X8 = (string**)(1152921510122513728)("item_id");
        // 0x00D841E0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D841E4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D841E8: LDR x1, [x8]               | X1 = "item_id";                         
        // 0x00D841EC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "item_id");   
        string val_309 = _info.Item["item_id"];
        // 0x00D841F0: MOV x1, x0                 | X1 = val_309;//m1                       
        // 0x00D841F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D841F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D841FC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_310 = System.Int32.Parse(s:  0);
        // 0x00D84200: STR w0, [x19, #0x248]      | this.item_id = val_310;                  //  dest_result_addr=1152921514531379416
        this.item_id = val_310;
        // 0x00D84204: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_310, ????);    
        label_115:
        // 0x00D84208: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00D8420C: LDR x8, [x8, #0x9d0]       | X8 = (string**)(1152921510122515872)("is_time_not");
        // 0x00D84210: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84214: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D84218: LDR x1, [x8]               | X1 = "is_time_not";                     
        // 0x00D8421C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "is_time_not");
        string val_311 = _info.Item["is_time_not"];
        // 0x00D84220: MOV x1, x0                 | X1 = val_311;//m1                       
        // 0x00D84224: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84228: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8422C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_312 = System.Int32.Parse(s:  0);
        // 0x00D84230: STR w0, [x19, #0x24c]      | this.is_time_not = val_312;              //  dest_result_addr=1152921514531379420
        this.is_time_not = val_312;
        // 0x00D84234: CBZ x20, #0xd84258         | if (_info == null) goto label_116;      
        if(_info == null)
        {
            goto label_116;
        }
        // 0x00D84238: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x00D8423C: LDR x8, [x8, #0xd50]       | X8 = (string**)(1152921510122518016)("camera_limit");
        // 0x00D84240: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84244: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D84248: LDR x1, [x8]               | X1 = "camera_limit";                    
        // 0x00D8424C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "camera_limit");
        string val_313 = _info.Item["camera_limit"];
        // 0x00D84250: STR x0, [x19, #0x250]      | this.camera_limit = val_313;             //  dest_result_addr=1152921514531379424
        this.camera_limit = val_313;
        // 0x00D84254: B #0xd8427c                |  goto label_117;                        
        goto label_117;
        label_116:
        // 0x00D84258: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_312, ????);    
        // 0x00D8425C: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x00D84260: LDR x8, [x8, #0xd50]       | X8 = (string**)(1152921510122518016)("camera_limit");
        // 0x00D84264: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84268: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8426C: LDR x1, [x8]               | X1 = "camera_limit";                    
        // 0x00D84270: BL #0x23fc26c              | X0 = _info.get_Item(key:  "camera_limit");
        string val_314 = _info.Item["camera_limit"];
        // 0x00D84274: STR x0, [x19, #0x250]      | this.camera_limit = val_314;             //  dest_result_addr=1152921514531379424
        this.camera_limit = val_314;
        // 0x00D84278: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_314, ????);    
        label_117:
        // 0x00D8427C: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
        // 0x00D84280: LDR x8, [x8, #0x150]       | X8 = (string**)(1152921510122520160)("layer");
        // 0x00D84284: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84288: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8428C: LDR x1, [x8]               | X1 = "layer";                           
        // 0x00D84290: BL #0x23fc26c              | X0 = _info.get_Item(key:  "layer");     
        string val_315 = _info.Item["layer"];
        // 0x00D84294: MOV x1, x0                 | X1 = val_315;//m1                       
        // 0x00D84298: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8429C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D842A0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_316 = System.Int32.Parse(s:  0);
        // 0x00D842A4: STR w0, [x19, #0x258]      | this.layer = val_316;                    //  dest_result_addr=1152921514531379432
        this.layer = val_316;
        // 0x00D842A8: CBZ x20, #0xd842e0         | if (_info == null) goto label_118;      
        if(_info == null)
        {
            goto label_118;
        }
        // 0x00D842AC: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00D842B0: LDR x8, [x8, #0x3d0]       | X8 = (string**)(1152921510122522288)("Is_Lead_skill");
        // 0x00D842B4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D842B8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D842BC: LDR x1, [x8]               | X1 = "Is_Lead_skill";                   
        // 0x00D842C0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Is_Lead_skill");
        string val_317 = _info.Item["Is_Lead_skill"];
        // 0x00D842C4: MOV x1, x0                 | X1 = val_317;//m1                       
        // 0x00D842C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D842CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D842D0: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_318 = System.Boolean.Parse(value:  0);
        // 0x00D842D4: AND w8, w0, #1             | W8 = (val_318 & 1);                     
        bool val_319 = val_318;
        // 0x00D842D8: STRB w8, [x19, #0x25c]     | this.Is_Lead_skill = (val_318 & 1);      //  dest_result_addr=1152921514531379436
        this.Is_Lead_skill = val_319;
        // 0x00D842DC: B #0xd84318                |  goto label_119;                        
        goto label_119;
        label_118:
        // 0x00D842E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_316, ????);    
        // 0x00D842E4: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00D842E8: LDR x8, [x8, #0x3d0]       | X8 = (string**)(1152921510122522288)("Is_Lead_skill");
        // 0x00D842EC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D842F0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D842F4: LDR x1, [x8]               | X1 = "Is_Lead_skill";                   
        // 0x00D842F8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Is_Lead_skill");
        string val_320 = _info.Item["Is_Lead_skill"];
        // 0x00D842FC: MOV x1, x0                 | X1 = val_320;//m1                       
        // 0x00D84300: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84304: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84308: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_321 = System.Boolean.Parse(value:  0);
        // 0x00D8430C: AND w8, w0, #1             | W8 = (val_321 & 1);                     
        bool val_322 = val_321;
        // 0x00D84310: STRB w8, [x19, #0x25c]     | this.Is_Lead_skill = (val_321 & 1);      //  dest_result_addr=1152921514531379436
        this.Is_Lead_skill = val_322;
        // 0x00D84314: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_321, ????);    
        label_119:
        // 0x00D84318: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x00D8431C: LDR x8, [x8, #0xa00]       | X8 = (string**)(1152921510122524432)("Is_relief");
        // 0x00D84320: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84324: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D84328: LDR x1, [x8]               | X1 = "Is_relief";                       
        // 0x00D8432C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Is_relief"); 
        string val_323 = _info.Item["Is_relief"];
        // 0x00D84330: MOV x1, x0                 | X1 = val_323;//m1                       
        // 0x00D84334: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84338: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8433C: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_324 = System.Boolean.Parse(value:  0);
        // 0x00D84340: AND w8, w0, #1             | W8 = (val_324 & 1);                     
        bool val_325 = val_324;
        // 0x00D84344: STRB w8, [x19, #0x25d]     | this.Is_relief = (val_324 & 1);          //  dest_result_addr=1152921514531379437
        this.Is_relief = val_325;
        // 0x00D84348: CBZ x20, #0xd84380         | if (_info == null) goto label_120;      
        if(_info == null)
        {
            goto label_120;
        }
        // 0x00D8434C: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00D84350: LDR x8, [x8, #0x6f8]       | X8 = (string**)(1152921510122526576)("Is_close");
        // 0x00D84354: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84358: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D8435C: LDR x1, [x8]               | X1 = "Is_close";                        
        // 0x00D84360: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Is_close");  
        string val_326 = _info.Item["Is_close"];
        // 0x00D84364: MOV x1, x0                 | X1 = val_326;//m1                       
        // 0x00D84368: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8436C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84370: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_327 = System.Boolean.Parse(value:  0);
        // 0x00D84374: AND w8, w0, #1             | W8 = (val_327 & 1);                     
        bool val_328 = val_327;
        // 0x00D84378: STRB w8, [x19, #0x25e]     | this.Is_close = (val_327 & 1);           //  dest_result_addr=1152921514531379438
        this.Is_close = val_328;
        // 0x00D8437C: B #0xd843b8                |  goto label_121;                        
        goto label_121;
        label_120:
        // 0x00D84380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_324, ????);    
        // 0x00D84384: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00D84388: LDR x8, [x8, #0x6f8]       | X8 = (string**)(1152921510122526576)("Is_close");
        // 0x00D8438C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D84390: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D84394: LDR x1, [x8]               | X1 = "Is_close";                        
        // 0x00D84398: BL #0x23fc26c              | X0 = _info.get_Item(key:  "Is_close");  
        string val_329 = _info.Item["Is_close"];
        // 0x00D8439C: MOV x1, x0                 | X1 = val_329;//m1                       
        // 0x00D843A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D843A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D843A8: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_330 = System.Boolean.Parse(value:  0);
        // 0x00D843AC: AND w8, w0, #1             | W8 = (val_330 & 1);                     
        bool val_331 = val_330;
        // 0x00D843B0: STRB w8, [x19, #0x25e]     | this.Is_close = (val_330 & 1);           //  dest_result_addr=1152921514531379438
        this.Is_close = val_331;
        // 0x00D843B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_330, ????);    
        label_121:
        // 0x00D843B8: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x00D843BC: LDR x8, [x8, #0x9d0]       | X8 = (string**)(1152921510122528720)("child_type");
        // 0x00D843C0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D843C4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D843C8: LDR x1, [x8]               | X1 = "child_type";                      
        // 0x00D843CC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "child_type");
        string val_332 = _info.Item["child_type"];
        // 0x00D843D0: MOV x1, x0                 | X1 = val_332;//m1                       
        // 0x00D843D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D843D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D843DC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_333 = System.Int32.Parse(s:  0);
        // 0x00D843E0: STR w0, [x19, #0x260]      | this.child_type = val_333;               //  dest_result_addr=1152921514531379440
        this.child_type = val_333;
        // 0x00D843E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D843E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D843EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D843F0: RET                        |  return;                                
        return;
    
    }

}
