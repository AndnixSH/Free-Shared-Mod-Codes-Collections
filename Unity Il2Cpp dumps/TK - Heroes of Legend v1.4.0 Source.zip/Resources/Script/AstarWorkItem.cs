using UnityEngine;
public struct AstarPath.AstarWorkItem
{
    // Fields
    public OnVoidDelegate init; //  0x00000000
    public System.Func<bool, bool> update; //  0x00000008
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B8C654 (12109396), len: 8  VirtAddr: 0x00B8C654 RVA: 0x00B8C654 token: 100682098 methodIndex: 25067 delegateWrapperIndex: 0 methodInvoker: 0
    public AstarPath.AstarWorkItem(System.Func<bool, bool> update)
    {
        //
        // Disasemble & Code
        // 0x00B8C654: STP xzr, x1, [x0, #0x10]   | mem[1152921513183119696] = 0x0;  mem[1152921513183119704] = update;  //  dest_result_addr=1152921513183119696 |  dest_result_addr=1152921513183119704
        mem[1152921513183119696] = 0;
        mem[1152921513183119704] = update;
        // 0x00B8C658: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8C65C (12109404), len: 76  VirtAddr: 0x00B8C65C RVA: 0x00B8C65C token: 100682099 methodIndex: 25068 delegateWrapperIndex: 0 methodInvoker: 0
    public AstarPath.AstarWorkItem(OnVoidDelegate init, System.Func<bool, bool> update)
    {
        //
        // Disasemble & Code
        // 0x00B8C65C: STP x1, x2, [x0, #0x10]    | mem[1152921513183243984] = init;  mem[1152921513183243992] = update;  //  dest_result_addr=1152921513183243984 |  dest_result_addr=1152921513183243992
        mem[1152921513183243984] = init;
        mem[1152921513183243992] = update;
        // 0x00B8C660: RET                        |  return;                                
        return;
        // 0x00B8C664: STP x29, x30, [sp, #-0x10]! | 
        // 0x00B8C668: MOV x29, sp                | 
        // 0x00B8C66C: ADRP x0, #0x2a93000        | 
        // 0x00B8C670: ADD x0, x0, #0x4c          | 
        // 0x00B8C674: BL #0x27af3c8              | 
        // 0x00B8C678: MOV x1, xzr                | 
        // 0x00B8C67C: BL #0x27ae3bc              | 
        // 0x00B8C680: BL #0xb8bb04               | 
        // 0x00B8C684: STP x29, x30, [sp, #-0x10]! | 
        // 0x00B8C688: MOV x29, sp                | 
        // 0x00B8C68C: ADRP x0, #0x2a93000        | 
        // 0x00B8C690: ADD x0, x0, #0x4c          | 
        // 0x00B8C694: BL #0x27af3c8              | 
        // 0x00B8C698: MOV x1, xzr                | 
        // 0x00B8C69C: BL #0x27ae3bc              | 
        // 0x00B8C6A0: BL #0xb8bb04               | 
        // 0x00B8C6A4: RET                        | 
    
    }

}
