using UnityEngine;

namespace Newtonsoft.Json.Serialization
{
    public class CamelCasePropertyNamesContractResolver : DefaultContractResolver
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x029434D8 (43267288), len: 124  VirtAddr: 0x029434D8 RVA: 0x029434D8 token: 100686154 methodIndex: 48757 delegateWrapperIndex: 0 methodInvoker: 0
        public CamelCasePropertyNamesContractResolver()
        {
            //
            // Disasemble & Code
            // 0x029434D8: STP x20, x19, [sp, #-0x20]! | stack[1152921513907218432] = ???;  stack[1152921513907218440] = ???;  //  dest_result_addr=1152921513907218432 |  dest_result_addr=1152921513907218440
            // 0x029434DC: STP x29, x30, [sp, #0x10]  | stack[1152921513907218448] = ???;  stack[1152921513907218456] = ???;  //  dest_result_addr=1152921513907218448 |  dest_result_addr=1152921513907218456
            // 0x029434E0: ADD x29, sp, #0x10         | X29 = (1152921513907218432 + 16) = 1152921513907218448 (0x100000022A586810);
            // 0x029434E4: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x029434E8: LDRB w8, [x20, #0xcde]     | W8 = (bool)static_value_037B8CDE;       
            // 0x029434EC: MOV x19, x0                | X19 = 1152921513907230464 (0x100000022A589700);//ML01
            // 0x029434F0: TBNZ w8, #0, #0x294350c    | if (static_value_037B8CDE == true) goto label_0;
            // 0x029434F4: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x029434F8: LDR x8, [x8, #0x898]       | X8 = 0x2B90114;                         
            // 0x029434FC: LDR w0, [x8]               | W0 = 0x1709;                            
            // 0x02943500: BL #0x2782188              | X0 = sub_2782188( ?? 0x1709, ????);     
            // 0x02943504: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02943508: STRB w8, [x20, #0xcde]     | static_value_037B8CDE = true;            //  dest_result_addr=58428638
            label_0:
            // 0x0294350C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x02943510: LDR x8, [x8, #0x1a0]       | X8 = 1152921504864407552;               
            // 0x02943514: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Serialization.DefaultContractResolver);
            // 0x02943518: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Serialization.DefaultContractResolver.__il2cppRuntimeField_10A;
            // 0x0294351C: TBZ w8, #0, #0x294352c     | if (Newtonsoft.Json.Serialization.DefaultContractResolver.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x02943520: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Serialization.DefaultContractResolver.__il2cppRuntimeField_cctor_finished;
            // 0x02943524: CBNZ w8, #0x294352c        | if (Newtonsoft.Json.Serialization.DefaultContractResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x02943528: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Serialization.DefaultContractResolver), ????);
            label_2:
            // 0x0294352C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02943530: MOV x0, x19                | X0 = 1152921513907230464 (0x100000022A589700);//ML01
            object val_1 = this;
            // 0x02943534: BL #0x16f59f0              | this..ctor();                           
            val_1 = new System.Object();
            // 0x02943538: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x0294353C: MOVZ w8, #0x14             | W8 = 20 (0x14);//ML01                   
            // 0x02943540: STRB w9, [x19, #0x18]      | mem[1152921513907230488] = 0x1;          //  dest_result_addr=1152921513907230488
            mem[1152921513907230488] = 1;
            // 0x02943544: STR w8, [x19, #0x1c]       | mem[1152921513907230492] = 0x14;         //  dest_result_addr=1152921513907230492
            mem[1152921513907230492] = 20;
            // 0x02943548: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0294354C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x02943550: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0294358C (43267468), len: 12  VirtAddr: 0x0294358C RVA: 0x0294358C token: 100686155 methodIndex: 48758 delegateWrapperIndex: 0 methodInvoker: 0
        protected internal override string ResolvePropertyName(string propertyName)
        {
            //
            // Disasemble & Code
            // 0x0294358C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02943590: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02943594: B #0x291d880               | return Newtonsoft.Json.Utilities.StringUtils.ToCamelCase(s:  0);
            return Newtonsoft.Json.Utilities.StringUtils.ToCamelCase(s:  0);
        
        }
    
    }

}
