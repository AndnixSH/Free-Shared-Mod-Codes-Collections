using UnityEngine;
[Serializable]
public enum Bloom.BloomQuality
{
    // Fields
    Cheap = 0
    ,High = 1
    

}
