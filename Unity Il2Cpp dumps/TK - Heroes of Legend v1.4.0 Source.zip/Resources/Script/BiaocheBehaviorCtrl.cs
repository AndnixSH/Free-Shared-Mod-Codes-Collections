using UnityEngine;

namespace Entity.Behavior
{
    internal class BiaocheBehaviorCtrl : IBehaviorCtrl
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00B68BA8 (11963304), len: 44  VirtAddr: 0x00B68BA8 RVA: 0x00B68BA8 token: 100691597 methodIndex: 27224 delegateWrapperIndex: 0 methodInvoker: 0
        public BiaocheBehaviorCtrl(CombatEntity entity)
        {
            //
            // Disasemble & Code
            // 0x00B68BA8: STP x20, x19, [sp, #-0x20]! | stack[1152921514680439632] = ???;  stack[1152921514680439640] = ???;  //  dest_result_addr=1152921514680439632 |  dest_result_addr=1152921514680439640
            // 0x00B68BAC: STP x29, x30, [sp, #0x10]  | stack[1152921514680439648] = ???;  stack[1152921514680439656] = ???;  //  dest_result_addr=1152921514680439648 |  dest_result_addr=1152921514680439656
            // 0x00B68BB0: ADD x29, sp, #0x10         | X29 = (1152921514680439632 + 16) = 1152921514680439648 (0x10000002586ED360);
            // 0x00B68BB4: MOV x19, x1                | X19 = entity;//m1                       
            // 0x00B68BB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68BBC: MOV x20, x0                | X20 = 1152921514680451664 (0x10000002586F0250);//ML01
            // 0x00B68BC0: BL #0xeb8ae8               | this..ctor();                           
            // 0x00B68BC4: STR x19, [x20, #0x18]      | mem[1152921514680451688] = entity;       //  dest_result_addr=1152921514680451688
            mem[1152921514680451688] = entity;
            // 0x00B68BC8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68BCC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00B68BD0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68BD4 (11963348), len: 320  VirtAddr: 0x00B68BD4 RVA: 0x00B68BD4 token: 100691598 methodIndex: 27225 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Init()
        {
            //
            // Disasemble & Code
            // 0x00B68BD4: STP x20, x19, [sp, #-0x20]! | stack[1152921514680555728] = ???;  stack[1152921514680555736] = ???;  //  dest_result_addr=1152921514680555728 |  dest_result_addr=1152921514680555736
            // 0x00B68BD8: STP x29, x30, [sp, #0x10]  | stack[1152921514680555744] = ???;  stack[1152921514680555752] = ???;  //  dest_result_addr=1152921514680555744 |  dest_result_addr=1152921514680555752
            // 0x00B68BDC: ADD x29, sp, #0x10         | X29 = (1152921514680555728 + 16) = 1152921514680555744 (0x10000002587098E0);
            // 0x00B68BE0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00B68BE4: LDRB w8, [x20, #0x96a]     | W8 = (bool)static_value_0373396A;       
            // 0x00B68BE8: MOV x19, x0                | X19 = 1152921514680567760 (0x100000025870C7D0);//ML01
            // 0x00B68BEC: TBNZ w8, #0, #0xb68c08     | if (static_value_0373396A == true) goto label_0;
            // 0x00B68BF0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00B68BF4: LDR x8, [x8, #0xa88]       | X8 = 0x2B8F3BC;                         
            // 0x00B68BF8: LDR w0, [x8]               | W0 = 0x13B1;                            
            // 0x00B68BFC: BL #0x2782188              | X0 = sub_2782188( ?? 0x13B1, ????);     
            // 0x00B68C00: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B68C04: STRB w8, [x20, #0x96a]     | static_value_0373396A = true;            //  dest_result_addr=57882986
            label_0:
            // 0x00B68C08: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x00B68C0C: LDR x8, [x8, #0xc38]       | X8 = 1152921504893054976;               
            // 0x00B68C10: LDR x0, [x8]               | X0 = typeof(Entity.Behavior.NormalBvr); 
            Entity.Behavior.NormalBvr val_1 = null;
            // 0x00B68C14: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Entity.Behavior.NormalBvr), ????);
            // 0x00B68C18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68C1C: MOV x20, x0                | X20 = 1152921504893054976 (0x10000000110F3000);//ML01
            // 0x00B68C20: BL #0xeb8f50               | .ctor();                                
            val_1 = new Entity.Behavior.NormalBvr();
            // 0x00B68C24: LDR x8, [x19]              | X8 = typeof(Entity.Behavior.BiaocheBehaviorCtrl);
            // 0x00B68C28: MOV x0, x19                | X0 = 1152921514680567760 (0x100000025870C7D0);//ML01
            // 0x00B68C2C: MOV x1, x20                | X1 = 1152921504893054976 (0x10000000110F3000);//ML01
            // 0x00B68C30: LDP x9, x2, [x8, #0x1b0]   | X9 = public System.Void Entity.Behavior.IBehaviorCtrl::AddBehavior(Entity.Behavior.IBehavior behavior); X2 = public System.Void Entity.Behavior.IBehaviorCtrl::AddBehavior(Entity.Behavior.IBehavior behavior); //  | 
            // 0x00B68C34: BLR x9                     | this.AddBehavior(behavior:  val_1);     
            this.AddBehavior(behavior:  val_1);
            // 0x00B68C38: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x00B68C3C: LDR x8, [x8, #0x2b8]       | X8 = 1152921504893534208;               
            // 0x00B68C40: LDR x0, [x8]               | X0 = typeof(Entity.Behavior.BiaocheMoveBvr);
            Entity.Behavior.IBehavior val_2 = null;
            // 0x00B68C44: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Entity.Behavior.BiaocheMoveBvr), ????);
            // 0x00B68C48: MOVZ w8, #0x3f4c, lsl #16  | W8 = 1061945344 (0x3F4C0000);//ML01     
            // 0x00B68C4C: MOV x20, x0                | X20 = 1152921504893534208 (0x1000000011168000);//ML01
            // 0x00B68C50: MOVK w8, #0xcccd           | W8 = 1061997773 (0x3F4CCCCD);           
            // 0x00B68C54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68C58: STR w8, [x20, #0x2c]       | typeof(Entity.Behavior.BiaocheMoveBvr).__il2cppRuntimeField_2C = 0x3F4CCCCD;  //  dest_result_addr=1152921504893534252
            typeof(Entity.Behavior.BiaocheMoveBvr).__il2cppRuntimeField_2C = 1061997773;
            // 0x00B68C5C: BL #0xeb3a54               | .ctor();                                
            val_2 = new Entity.Behavior.IBehavior();
            // 0x00B68C60: LDR x8, [x19]              | X8 = typeof(Entity.Behavior.BiaocheBehaviorCtrl);
            // 0x00B68C64: MOV x0, x19                | X0 = 1152921514680567760 (0x100000025870C7D0);//ML01
            // 0x00B68C68: MOV x1, x20                | X1 = 1152921504893534208 (0x1000000011168000);//ML01
            // 0x00B68C6C: LDP x9, x2, [x8, #0x1b0]   | X9 = public System.Void Entity.Behavior.IBehaviorCtrl::AddBehavior(Entity.Behavior.IBehavior behavior); X2 = public System.Void Entity.Behavior.IBehaviorCtrl::AddBehavior(Entity.Behavior.IBehavior behavior); //  | 
            // 0x00B68C70: BLR x9                     | this.AddBehavior(behavior:  val_2);     
            this.AddBehavior(behavior:  val_2);
            // 0x00B68C74: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00B68C78: LDR x8, [x8, #0xcc8]       | X8 = 1152921504892522496;               
            // 0x00B68C7C: LDR x0, [x8]               | X0 = typeof(Entity.Behavior.DeathBvr);  
            Entity.Behavior.DeathBvr val_3 = null;
            // 0x00B68C80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Entity.Behavior.DeathBvr), ????);
            // 0x00B68C84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68C88: MOV x20, x0                | X20 = 1152921504892522496 (0x1000000011071000);//ML01
            // 0x00B68C8C: BL #0xeb418c               | .ctor();                                
            val_3 = new Entity.Behavior.DeathBvr();
            // 0x00B68C90: LDR x8, [x19]              | X8 = typeof(Entity.Behavior.BiaocheBehaviorCtrl);
            // 0x00B68C94: MOV x0, x19                | X0 = 1152921514680567760 (0x100000025870C7D0);//ML01
            // 0x00B68C98: MOV x1, x20                | X1 = 1152921504892522496 (0x1000000011071000);//ML01
            // 0x00B68C9C: LDP x9, x2, [x8, #0x1b0]   | X9 = public System.Void Entity.Behavior.IBehaviorCtrl::AddBehavior(Entity.Behavior.IBehavior behavior); X2 = public System.Void Entity.Behavior.IBehaviorCtrl::AddBehavior(Entity.Behavior.IBehavior behavior); //  | 
            // 0x00B68CA0: BLR x9                     | this.AddBehavior(behavior:  val_3);     
            this.AddBehavior(behavior:  val_3);
            // 0x00B68CA4: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x00B68CA8: LDR x8, [x8, #0x178]       | X8 = 1152921504892416000;               
            // 0x00B68CAC: LDR x0, [x8]               | X0 = typeof(Entity.Behavior.BirthBvr);  
            Entity.Behavior.IBehavior val_4 = null;
            // 0x00B68CB0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Entity.Behavior.BirthBvr), ????);
            // 0x00B68CB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68CB8: MOV x20, x0                | X20 = 1152921504892416000 (0x1000000011057000);//ML01
            // 0x00B68CBC: BL #0xeb3a54               | .ctor();                                
            val_4 = new Entity.Behavior.IBehavior();
            // 0x00B68CC0: LDR x8, [x19]              | X8 = typeof(Entity.Behavior.BiaocheBehaviorCtrl);
            // 0x00B68CC4: MOV x0, x19                | X0 = 1152921514680567760 (0x100000025870C7D0);//ML01
            // 0x00B68CC8: MOV x1, x20                | X1 = 1152921504892416000 (0x1000000011057000);//ML01
            // 0x00B68CCC: LDP x9, x2, [x8, #0x1b0]   | X9 = public System.Void Entity.Behavior.IBehaviorCtrl::AddBehavior(Entity.Behavior.IBehavior behavior); X2 = public System.Void Entity.Behavior.IBehaviorCtrl::AddBehavior(Entity.Behavior.IBehavior behavior); //  | 
            // 0x00B68CD0: BLR x9                     | this.AddBehavior(behavior:  val_4);     
            this.AddBehavior(behavior:  val_4);
            // 0x00B68CD4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00B68CD8: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00B68CDC: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x00B68CE0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B68CE4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00B68CE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68CEC: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B68CF0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00B68CF4: LDR x8, [x19]              | X8 = typeof(Entity.Behavior.BiaocheBehaviorCtrl);
            // 0x00B68CF8: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B68CFC: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x00B68D00: MOV x0, x19                | X0 = 1152921514680567760 (0x100000025870C7D0);//ML01
            // 0x00B68D04: LDP x4, x3, [x8, #0x170]   | X4 = System.Void Entity.Behavior.IBehaviorCtrl::SetCurBehavior(Entity.Behavior.EBehaviorID id, object[] arg); X3 = System.Void Entity.Behavior.IBehaviorCtrl::SetCurBehavior(Entity.Behavior.EBehaviorID id, object[] arg); //  | 
            // 0x00B68D08: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68D0C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00B68D10: BR x4                      | this.SetCurBehavior(id:  8, arg:  null); return;
            this.SetCurBehavior(id:  8, arg:  null);
            return;
        
        }
    
    }

}
