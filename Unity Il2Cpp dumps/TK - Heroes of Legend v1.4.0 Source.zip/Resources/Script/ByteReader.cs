using UnityEngine;
public class ByteReader
{
    // Fields
    private byte[] mBuffer; //  0x00000010
    private int mOffset; //  0x00000018
    private static BetterList<string> mTemp; // static_offset: 0x00000000
    
    // Properties
    public bool canRead { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA42F4 (12206836), len: 44  VirtAddr: 0x00BA42F4 RVA: 0x00BA42F4 token: 100687900 methodIndex: 25590 delegateWrapperIndex: 0 methodInvoker: 0
    public ByteReader(byte[] bytes)
    {
        //
        // Disasemble & Code
        // 0x00BA42F4: STP x20, x19, [sp, #-0x20]! | stack[1152921514159494448] = ???;  stack[1152921514159494456] = ???;  //  dest_result_addr=1152921514159494448 |  dest_result_addr=1152921514159494456
        // 0x00BA42F8: STP x29, x30, [sp, #0x10]  | stack[1152921514159494464] = ???;  stack[1152921514159494472] = ???;  //  dest_result_addr=1152921514159494464 |  dest_result_addr=1152921514159494472
        // 0x00BA42FC: ADD x29, sp, #0x10         | X29 = (1152921514159494448 + 16) = 1152921514159494464 (0x100000023961D540);
        // 0x00BA4300: MOV x19, x1                | X19 = bytes;//m1                        
        // 0x00BA4304: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4308: MOV x20, x0                | X20 = 1152921514159506480 (0x1000000239620430);//ML01
        // 0x00BA430C: BL #0x16f59f0              | this..ctor();                           
        // 0x00BA4310: STR x19, [x20, #0x10]      | this.mBuffer = bytes;                    //  dest_result_addr=1152921514159506496
        this.mBuffer = bytes;
        // 0x00BA4314: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA4318: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA431C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4320 (12206880), len: 64  VirtAddr: 0x00BA4320 RVA: 0x00BA4320 token: 100687901 methodIndex: 25591 delegateWrapperIndex: 0 methodInvoker: 0
    public ByteReader(UnityEngine.TextAsset asset)
    {
        //
        // Disasemble & Code
        // 0x00BA4320: STP x20, x19, [sp, #-0x20]! | stack[1152921514159684272] = ???;  stack[1152921514159684280] = ???;  //  dest_result_addr=1152921514159684272 |  dest_result_addr=1152921514159684280
        // 0x00BA4324: STP x29, x30, [sp, #0x10]  | stack[1152921514159684288] = ???;  stack[1152921514159684296] = ???;  //  dest_result_addr=1152921514159684288 |  dest_result_addr=1152921514159684296
        // 0x00BA4328: ADD x29, sp, #0x10         | X29 = (1152921514159684272 + 16) = 1152921514159684288 (0x100000023964BAC0);
        // 0x00BA432C: MOV x20, x1                | X20 = asset;//m1                        
        // 0x00BA4330: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4334: MOV x19, x0                | X19 = 1152921514159696304 (0x100000023964E9B0);//ML01
        // 0x00BA4338: BL #0x16f59f0              | this..ctor();                           
        // 0x00BA433C: CBNZ x20, #0xba4344        | if (asset != null) goto label_0;        
        if(asset != null)
        {
            goto label_0;
        }
        // 0x00BA4340: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA4344: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4348: MOV x0, x20                | X0 = asset;//m1                         
        // 0x00BA434C: BL #0x268e974              | X0 = asset.get_bytes();                 
        System.Byte[] val_1 = asset.bytes;
        // 0x00BA4350: STR x0, [x19, #0x10]       | this.mBuffer = val_1;                    //  dest_result_addr=1152921514159696320
        this.mBuffer = val_1;
        // 0x00BA4354: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA4358: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA435C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4360 (12206944), len: 304  VirtAddr: 0x00BA4360 RVA: 0x00BA4360 token: 100687902 methodIndex: 25592 delegateWrapperIndex: 0 methodInvoker: 0
    public static ByteReader Open(string path)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00BA4360: STP x22, x21, [sp, #-0x30]! | stack[1152921514159845408] = ???;  stack[1152921514159845416] = ???;  //  dest_result_addr=1152921514159845408 |  dest_result_addr=1152921514159845416
        // 0x00BA4364: STP x20, x19, [sp, #0x10]  | stack[1152921514159845424] = ???;  stack[1152921514159845432] = ???;  //  dest_result_addr=1152921514159845424 |  dest_result_addr=1152921514159845432
        // 0x00BA4368: STP x29, x30, [sp, #0x20]  | stack[1152921514159845440] = ???;  stack[1152921514159845448] = ???;  //  dest_result_addr=1152921514159845440 |  dest_result_addr=1152921514159845448
        // 0x00BA436C: ADD x29, sp, #0x20         | X29 = (1152921514159845408 + 32) = 1152921514159845440 (0x1000000239673040);
        // 0x00BA4370: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA4374: LDRB w8, [x20, #0xac8]     | W8 = (bool)static_value_03733AC8;       
        // 0x00BA4378: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00BA437C: TBNZ w8, #0, #0xba4398     | if (static_value_03733AC8 == true) goto label_0;
        // 0x00BA4380: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00BA4384: LDR x8, [x8, #0xa68]       | X8 = 0x2B8FFF4;                         
        // 0x00BA4388: LDR w0, [x8]               | W0 = 0x16C1;                            
        // 0x00BA438C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C1, ????);     
        // 0x00BA4390: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA4394: STRB w8, [x20, #0xac8]     | static_value_03733AC8 = true;            //  dest_result_addr=57883336
        label_0:
        // 0x00BA4398: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA439C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA43A0: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00BA43A4: BL #0x1e70ac4              | X0 = System.IO.File.OpenRead(path:  0); 
        System.IO.FileStream val_1 = System.IO.File.OpenRead(path:  0);
        // 0x00BA43A8: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00BA43AC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_4 = 0;
        // 0x00BA43B0: CBZ x19, #0xba447c         | if (val_1 == null) goto label_1;        
        if(val_1 == null)
        {
            goto label_1;
        }
        // 0x00BA43B4: LDR x8, [x19]              | X8 = typeof(System.IO.FileStream);      
        // 0x00BA43B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA43BC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
        // 0x00BA43C0: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00BA43C4: LDR x9, [x8, #0x240]       | X9 = typeof(System.IO.FileStream).__il2cppRuntimeField_240;
        // 0x00BA43C8: LDR x3, [x8, #0x248]       | X3 = typeof(System.IO.FileStream).__il2cppRuntimeField_248;
        // 0x00BA43CC: BLR x9                     | X0 = typeof(System.IO.FileStream).__il2cppRuntimeField_240();
        // 0x00BA43D0: LDR x8, [x19]              | X8 = typeof(System.IO.FileStream);      
        // 0x00BA43D4: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00BA43D8: LDP x9, x1, [x8, #0x1a0]   | X9 = typeof(System.IO.FileStream).__il2cppRuntimeField_1A0; X1 = typeof(System.IO.FileStream).__il2cppRuntimeField_1A8; //  | 
        // 0x00BA43DC: BLR x9                     | X0 = typeof(System.IO.FileStream).__il2cppRuntimeField_1A0();
        // 0x00BA43E0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00BA43E4: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
        // 0x00BA43E8: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00BA43EC: LDR x20, [x8]              | X20 = typeof(System.Byte[]);            
        // 0x00BA43F0: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA43F4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
        // 0x00BA43F8: AND x1, x21, #0xffffffff   | X1 = (val_1 & 4294967295);              
        System.IO.FileStream val_2 = val_1 & 4294967295;
        // 0x00BA43FC: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA4400: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        // 0x00BA4404: LDR x8, [x19]              | X8 = typeof(System.IO.FileStream);      
        // 0x00BA4408: MOV x20, x0                | X20 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA440C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4410: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA4414: LDR x9, [x8, #0x240]       | X9 = typeof(System.IO.FileStream).__il2cppRuntimeField_240;
        // 0x00BA4418: LDR x3, [x8, #0x248]       | X3 = typeof(System.IO.FileStream).__il2cppRuntimeField_248;
        // 0x00BA441C: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00BA4420: BLR x9                     | X0 = typeof(System.IO.FileStream).__il2cppRuntimeField_240();
        // 0x00BA4424: CBNZ x20, #0xba442c        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00BA4428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00BA442C: LDR x8, [x19]              | X8 = typeof(System.IO.FileStream);      
        // 0x00BA4430: LDR w3, [x20, #0x18]       | W3 = System.Byte[].__il2cppRuntimeField_namespaze;
        // 0x00BA4434: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA4438: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00BA443C: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.FileStream).__il2cppRuntimeField_220;
        // 0x00BA4440: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.FileStream).__il2cppRuntimeField_228;
        // 0x00BA4444: MOV x1, x20                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA4448: BLR x9                     | X0 = typeof(System.IO.FileStream).__il2cppRuntimeField_220();
        // 0x00BA444C: LDR x8, [x19]              | X8 = typeof(System.IO.FileStream);      
        // 0x00BA4450: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00BA4454: LDP x9, x1, [x8, #0x1d0]   | X9 = typeof(System.IO.FileStream).__il2cppRuntimeField_1D0; X1 = typeof(System.IO.FileStream).__il2cppRuntimeField_1D8; //  | 
        // 0x00BA4458: BLR x9                     | X0 = typeof(System.IO.FileStream).__il2cppRuntimeField_1D0();
        // 0x00BA445C: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00BA4460: LDR x8, [x8, #0x30]        | X8 = 1152921504876068864;               
        // 0x00BA4464: LDR x0, [x8]               | X0 = typeof(ByteReader);                
        object val_3 = null;
        // 0x00BA4468: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ByteReader), ????);
        // 0x00BA446C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4470: MOV x21, x0                | X21 = 1152921504876068864 (0x10000000100C0000);//ML01
        val_4 = val_3;
        // 0x00BA4474: BL #0x16f59f0              | .ctor();                                
        val_3 = new System.Object();
        // 0x00BA4478: STR x20, [x21, #0x10]      | typeof(ByteReader).__il2cppRuntimeField_10 = typeof(System.Byte[]);  //  dest_result_addr=1152921504876068880
        typeof(ByteReader).__il2cppRuntimeField_10 = null;
        label_1:
        // 0x00BA447C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA4480: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA4484: MOV x0, x21                | X0 = 1152921504876068864 (0x10000000100C0000);//ML01
        // 0x00BA4488: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA448C: RET                        |  return (ByteReader)typeof(ByteReader); 
        return (ByteReader)val_4;
        //  |  // // {name=val_0, type=ByteReader, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4490 (12207248), len: 36  VirtAddr: 0x00BA4490 RVA: 0x00BA4490 token: 100687903 methodIndex: 25593 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_canRead()
    {
        //
        // Disasemble & Code
        // 0x00BA4490: LDR x8, [x0, #0x10]        | X8 = this.mBuffer; //P2                 
        // 0x00BA4494: CBZ x8, #0xba44ac          | if (this.mBuffer == null) goto label_0; 
        if(this.mBuffer == null)
        {
            goto label_0;
        }
        // 0x00BA4498: LDR w9, [x0, #0x18]        | W9 = this.mOffset; //P2                 
        // 0x00BA449C: LDR w8, [x8, #0x18]        | W8 = this.mBuffer.Length; //P2          
        // 0x00BA44A0: CMP w9, w8                 | STATE = COMPARE(this.mOffset, this.mBuffer.Length)
        // 0x00BA44A4: CSET w0, lt                | W0 = this.mOffset < this.mBuffer.Length ? 1 : 0;
        var val_1 = (this.mOffset < this.mBuffer.Length) ? 1 : 0;
        // 0x00BA44A8: RET                        |  return (System.Boolean)this.mOffset < this.mBuffer.Length ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        label_0:
        // 0x00BA44AC: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        // 0x00BA44B0: RET                        |  return (System.Boolean)false;          
        return (bool)0;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA44B4 (12207284), len: 164  VirtAddr: 0x00BA44B4 RVA: 0x00BA44B4 token: 100687904 methodIndex: 25594 delegateWrapperIndex: 0 methodInvoker: 0
    private static string ReadLine(byte[] buffer, int start, int count)
    {
        //
        // Disasemble & Code
        // 0x00BA44B4: STP x22, x21, [sp, #-0x30]! | stack[1152921514160192288] = ???;  stack[1152921514160192296] = ???;  //  dest_result_addr=1152921514160192288 |  dest_result_addr=1152921514160192296
        // 0x00BA44B8: STP x20, x19, [sp, #0x10]  | stack[1152921514160192304] = ???;  stack[1152921514160192312] = ???;  //  dest_result_addr=1152921514160192304 |  dest_result_addr=1152921514160192312
        // 0x00BA44BC: STP x29, x30, [sp, #0x20]  | stack[1152921514160192320] = ???;  stack[1152921514160192328] = ???;  //  dest_result_addr=1152921514160192320 |  dest_result_addr=1152921514160192328
        // 0x00BA44C0: ADD x29, sp, #0x20         | X29 = (1152921514160192288 + 32) = 1152921514160192320 (0x10000002396C7B40);
        // 0x00BA44C4: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00BA44C8: LDRB w8, [x22, #0xac9]     | W8 = (bool)static_value_03733AC9;       
        // 0x00BA44CC: MOV w19, w3                | W19 = W3;//m1                           
        // 0x00BA44D0: MOV w20, w2                | W20 = count;//m1                        
        // 0x00BA44D4: MOV x21, x1                | X21 = start;//m1                        
        // 0x00BA44D8: TBNZ w8, #0, #0xba44f4     | if (static_value_03733AC9 == true) goto label_0;
        // 0x00BA44DC: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
        // 0x00BA44E0: LDR x8, [x8, #0x8d8]       | X8 = 0x2B90000;                         
        // 0x00BA44E4: LDR w0, [x8]               | W0 = 0x16C4;                            
        // 0x00BA44E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C4, ????);     
        // 0x00BA44EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA44F0: STRB w8, [x22, #0xac9]     | static_value_03733AC9 = true;            //  dest_result_addr=57883337
        label_0:
        // 0x00BA44F4: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00BA44F8: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
        // 0x00BA44FC: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
        // 0x00BA4500: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
        // 0x00BA4504: TBZ w8, #0, #0xba4514      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA4508: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
        // 0x00BA450C: CBNZ w8, #0xba4514         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA4510: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
        label_2:
        // 0x00BA4514: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA4518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA451C: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_1 = System.Text.Encoding.UTF8;
        // 0x00BA4520: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00BA4524: CBNZ x22, #0xba452c        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00BA4528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00BA452C: LDR x8, [x22]              | X8 = typeof(System.Text.Encoding);      
        // 0x00BA4530: MOV w2, w20                | W2 = count;//m1                         
        // 0x00BA4534: MOV w3, w19                | W3 = W3;//m1                            
        // 0x00BA4538: MOV x0, x22                | X0 = val_1;//m1                         
        // 0x00BA453C: LDR x5, [x8, #0x2b0]       | X5 = typeof(System.Text.Encoding).__il2cppRuntimeField_2B0;
        // 0x00BA4540: LDR x4, [x8, #0x2b8]       | X4 = typeof(System.Text.Encoding).__il2cppRuntimeField_2B8;
        // 0x00BA4544: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA4548: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA454C: MOV x1, x21                | X1 = start;//m1                         
        // 0x00BA4550: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA4554: BR x5                      | goto typeof(System.Text.Encoding).__il2cppRuntimeField_2B0;
        goto typeof(System.Text.Encoding).__il2cppRuntimeField_2B0;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4558 (12207448), len: 8  VirtAddr: 0x00BA4558 RVA: 0x00BA4558 token: 100687905 methodIndex: 25595 delegateWrapperIndex: 0 methodInvoker: 0
    public string ReadLine()
    {
        //
        // Disasemble & Code
        // 0x00BA4558: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA455C: B #0xba4560                | return this.ReadLine(skipEmptyLines:  true);
        return this.ReadLine(skipEmptyLines:  true);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4560 (12207456), len: 368  VirtAddr: 0x00BA4560 RVA: 0x00BA4560 token: 100687906 methodIndex: 25596 delegateWrapperIndex: 0 methodInvoker: 0
    public string ReadLine(bool skipEmptyLines)
    {
        //
        // Disasemble & Code
        //  | 
        System.Byte[] val_7;
        //  | 
        int val_8;
        //  | 
        int val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        // 0x00BA4560: STP x24, x23, [sp, #-0x40]! | stack[1152921514160608784] = ???;  stack[1152921514160608792] = ???;  //  dest_result_addr=1152921514160608784 |  dest_result_addr=1152921514160608792
        // 0x00BA4564: STP x22, x21, [sp, #0x10]  | stack[1152921514160608800] = ???;  stack[1152921514160608808] = ???;  //  dest_result_addr=1152921514160608800 |  dest_result_addr=1152921514160608808
        // 0x00BA4568: STP x20, x19, [sp, #0x20]  | stack[1152921514160608816] = ???;  stack[1152921514160608824] = ???;  //  dest_result_addr=1152921514160608816 |  dest_result_addr=1152921514160608824
        // 0x00BA456C: STP x29, x30, [sp, #0x30]  | stack[1152921514160608832] = ???;  stack[1152921514160608840] = ???;  //  dest_result_addr=1152921514160608832 |  dest_result_addr=1152921514160608840
        // 0x00BA4570: ADD x29, sp, #0x30         | X29 = (1152921514160608784 + 48) = 1152921514160608832 (0x100000023972D640);
        // 0x00BA4574: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA4578: LDRB w8, [x21, #0xaca]     | W8 = (bool)static_value_03733ACA;       
        // 0x00BA457C: MOV w20, w1                | W20 = skipEmptyLines;//m1               
        // 0x00BA4580: MOV x19, x0                | X19 = 1152921514160620848 (0x1000000239730530);//ML01
        // 0x00BA4584: TBNZ w8, #0, #0xba45a0     | if (static_value_03733ACA == true) goto label_0;
        // 0x00BA4588: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00BA458C: LDR x8, [x8, #0x500]       | X8 = 0x2B90004;                         
        // 0x00BA4590: LDR w0, [x8]               | W0 = 0x16C5;                            
        // 0x00BA4594: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C5, ????);     
        // 0x00BA4598: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA459C: STRB w8, [x21, #0xaca]     | static_value_03733ACA = true;            //  dest_result_addr=57883338
        label_0:
        // 0x00BA45A0: LDR x21, [x19, #0x10]      | X21 = this.mBuffer; //P2                
        val_7 = this.mBuffer;
        // 0x00BA45A4: CBNZ x21, #0xba45ac        | if (this.mBuffer != null) goto label_1; 
        if(val_7 != null)
        {
            goto label_1;
        }
        // 0x00BA45A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16C5, ????);     
        label_1:
        // 0x00BA45AC: LDR x22, [x21, #0x18]      | X22 = this.mBuffer.Length; //P2         
        val_8 = this.mBuffer.Length;
        // 0x00BA45B0: TBZ w20, #0, #0xba4608     | if (skipEmptyLines == false) goto label_4;
        if(skipEmptyLines == false)
        {
            goto label_4;
        }
        // 0x00BA45B4: LDR w20, [x19, #0x18]      | W20 = this.mOffset; //P2                
        val_9 = this.mOffset;
        // 0x00BA45B8: B #0xba45c8                |  goto label_3;                          
        goto label_3;
        label_7:
        // 0x00BA45BC: LDR w8, [x19, #0x18]       | W8 = this.mOffset; //P2                 
        // 0x00BA45C0: ADD w20, w8, #1            | W20 = (this.mOffset + 1);               
        val_9 = this.mOffset + 1;
        // 0x00BA45C4: STR w20, [x19, #0x18]      | this.mOffset = (this.mOffset + 1);       //  dest_result_addr=1152921514160620872
        this.mOffset = val_9;
        label_3:
        // 0x00BA45C8: CMP w20, w22               | STATE = COMPARE((this.mOffset + 1), this.mBuffer.Length)
        // 0x00BA45CC: B.GE #0xba4608             | if (val_9 >= val_8) goto label_4;       
        if(val_9 >= val_8)
        {
            goto label_4;
        }
        // 0x00BA45D0: LDR x21, [x19, #0x10]      | X21 = this.mBuffer; //P2                
        val_7 = this.mBuffer;
        // 0x00BA45D4: CBNZ x21, #0xba45dc        | if (this.mBuffer != null) goto label_5; 
        if(val_7 != null)
        {
            goto label_5;
        }
        // 0x00BA45D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16C5, ????);     
        label_5:
        // 0x00BA45DC: LDR w8, [x21, #0x18]       | W8 = this.mBuffer.Length; //P2          
        // 0x00BA45E0: SXTW x23, w20              | X23 = (long)(int)((this.mOffset + 1));  
        val_10 = (long)val_9;
        // 0x00BA45E4: CMP w20, w8                | STATE = COMPARE((this.mOffset + 1), this.mBuffer.Length)
        // 0x00BA45E8: B.LO #0xba45f8             | if (val_9 < this.mBuffer.Length) goto label_6;
        if(val_9 < this.mBuffer.Length)
        {
            goto label_6;
        }
        // 0x00BA45EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x16C5, ????);     
        // 0x00BA45F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA45F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x16C5, ????);     
        label_6:
        // 0x00BA45F8: ADD x8, x21, x23           | X8 = this.mBuffer[(long)(int)((this.mOffset + 1))]; //PARR1 
        // 0x00BA45FC: LDRB w8, [x8, #0x20]       | W8 = this.mBuffer[(long)(int)((this.mOffset + 1))][0]
        byte val_5 = val_7[val_10];
        // 0x00BA4600: CMP w8, #0x20              | STATE = COMPARE(this.mBuffer[(long)(int)((this.mOffset + 1))][0], 0x20)
        // 0x00BA4604: B.LO #0xba45bc             | if (val_7[val_10] < 32) goto label_7;   
        if(val_5 < 32)
        {
            goto label_7;
        }
        label_4:
        // 0x00BA4608: LDRSW x20, [x19, #0x18]    | X20 = this.mOffset; //P2                
        int val_7 = this.mOffset;
        // 0x00BA460C: CMP w20, w22               | STATE = COMPARE(this.mOffset, this.mBuffer.Length)
        // 0x00BA4610: B.GE #0xba4670             | if (this.mOffset >= val_8) goto label_8;
        if(val_7 >= val_8)
        {
            goto label_8;
        }
        // 0x00BA4614: SXTW x21, w22              | X21 = (long)(int)(this.mBuffer.Length); 
        // 0x00BA4618: SUB w23, w20, #1           | W23 = (this.mOffset - 1);               
        int val_1 = val_7 - 1;
        label_13:
        // 0x00BA461C: CMP x20, x21               | STATE = COMPARE(this.mOffset, (long)(int)(this.mBuffer.Length))
        // 0x00BA4620: B.GE #0xba4678             | if (this.mOffset >= (long)val_8) goto label_9;
        if(val_7 >= (long)val_8)
        {
            goto label_9;
        }
        // 0x00BA4624: LDR x22, [x19, #0x10]      | X22 = this.mBuffer; //P2                
        // 0x00BA4628: ADD w24, w23, #1           | W24 = ((this.mOffset - 1) + 1);         
        int val_2 = val_1 + 1;
        // 0x00BA462C: CBNZ x22, #0xba4634        | if (this.mBuffer != null) goto label_10;
        if(this.mBuffer != null)
        {
            goto label_10;
        }
        // 0x00BA4630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16C5, ????);     
        label_10:
        // 0x00BA4634: LDR w8, [x22, #0x18]       | W8 = this.mBuffer.Length; //P2          
        // 0x00BA4638: CMP w24, w8                | STATE = COMPARE(((this.mOffset - 1) + 1), this.mBuffer.Length)
        // 0x00BA463C: B.LO #0xba464c             | if (val_2 < this.mBuffer.Length) goto label_11;
        if(val_2 < this.mBuffer.Length)
        {
            goto label_11;
        }
        // 0x00BA4640: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x16C5, ????);     
        // 0x00BA4644: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4648: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x16C5, ????);     
        label_11:
        // 0x00BA464C: ADD x8, x22, x20           | X8 = this.mBuffer[this.mOffset]; //PARR1 
        // 0x00BA4650: LDRB w8, [x8, #0x20]       | W8 = this.mBuffer[this.mOffset][0]      
        byte val_6 = this.mBuffer[val_7];
        // 0x00BA4654: ADD w23, w23, #1           | W23 = ((this.mOffset - 1) + 1);         
        val_10 = val_1 + 1;
        // 0x00BA4658: CMP w8, #0xa               | STATE = COMPARE(this.mBuffer[this.mOffset][0], 0xA)
        // 0x00BA465C: B.EQ #0xba467c             | if (this.mBuffer[this.mOffset] == 10) goto label_14;
        if(val_6 == 10)
        {
            goto label_14;
        }
        // 0x00BA4660: ADD x20, x20, #1           | X20 = (this.mOffset + 1);               
        val_7 = val_7 + 1;
        // 0x00BA4664: CMP w8, #0xd               | STATE = COMPARE(this.mBuffer[this.mOffset][0], 0xD)
        // 0x00BA4668: B.NE #0xba461c             | if (this.mBuffer[this.mOffset] != 13) goto label_13;
        if(val_6 != 13)
        {
            goto label_13;
        }
        // 0x00BA466C: B #0xba467c                |  goto label_14;                         
        goto label_14;
        label_8:
        // 0x00BA4670: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_11 = 0;
        // 0x00BA4674: B #0xba46b8                |  goto label_15;                         
        goto label_15;
        label_9:
        // 0x00BA4678: ADD w23, w23, #1           | W23 = ((this.mOffset - 1) + 1);         
        val_10 = val_1 + 1;
        label_14:
        // 0x00BA467C: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00BA4680: LDR x8, [x8, #0x30]        | X8 = 1152921504876068864;               
        // 0x00BA4684: LDR x21, [x19, #0x10]      | X21 = this.mBuffer; //P2                
        val_7 = this.mBuffer;
        // 0x00BA4688: LDR w20, [x19, #0x18]      | W20 = this.mOffset; //P2                
        // 0x00BA468C: ADD w22, w23, #1           | W22 = (((this.mOffset - 1) + 1) + 1);   
        val_8 = val_10 + 1;
        // 0x00BA4690: LDR x0, [x8]               | X0 = typeof(ByteReader);                
        // 0x00BA4694: LDRB w8, [x0, #0x10a]      | W8 = ByteReader.__il2cppRuntimeField_10A;
        // 0x00BA4698: TBZ w8, #0, #0xba46a8      | if (ByteReader.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00BA469C: LDR w8, [x0, #0xbc]        | W8 = ByteReader.__il2cppRuntimeField_cctor_finished;
        // 0x00BA46A0: CBNZ w8, #0xba46a8         | if (ByteReader.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00BA46A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReader), ????);
        label_17:
        // 0x00BA46A8: SUB w3, w23, w20           | W3 = (((this.mOffset - 1) + 1) - this.mOffset);
        int val_3 = val_10 - this.mOffset;
        // 0x00BA46AC: MOV x1, x21                | X1 = this.mBuffer;//m1                  
        // 0x00BA46B0: MOV w2, w20                | W2 = this.mOffset;//m1                  
        // 0x00BA46B4: BL #0xba44b4               | X0 = ByteReader.ReadLine(buffer:  null, start:  val_7, count:  this.mOffset);
        string val_4 = ByteReader.ReadLine(buffer:  null, start:  val_7, count:  this.mOffset);
        label_15:
        // 0x00BA46B8: STR w22, [x19, #0x18]      | this.mOffset = (((this.mOffset - 1) + 1) + 1);  //  dest_result_addr=1152921514160620872
        this.mOffset = val_8;
        // 0x00BA46BC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA46C0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA46C4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA46C8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00BA46CC: RET                        |  return (System.String)val_4;           
        return val_4;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA46D0 (12207824), len: 504  VirtAddr: 0x00BA46D0 RVA: 0x00BA46D0 token: 100687907 methodIndex: 25597 delegateWrapperIndex: 0 methodInvoker: 0
    public System.Collections.Generic.Dictionary<string, string> ReadDictionary()
    {
        //
        // Disasemble & Code
        //  | 
        string val_9;
        // 0x00BA46D0: STP x28, x27, [sp, #-0x60]! | stack[1152921514161008496] = ???;  stack[1152921514161008504] = ???;  //  dest_result_addr=1152921514161008496 |  dest_result_addr=1152921514161008504
        // 0x00BA46D4: STP x26, x25, [sp, #0x10]  | stack[1152921514161008512] = ???;  stack[1152921514161008520] = ???;  //  dest_result_addr=1152921514161008512 |  dest_result_addr=1152921514161008520
        // 0x00BA46D8: STP x24, x23, [sp, #0x20]  | stack[1152921514161008528] = ???;  stack[1152921514161008536] = ???;  //  dest_result_addr=1152921514161008528 |  dest_result_addr=1152921514161008536
        // 0x00BA46DC: STP x22, x21, [sp, #0x30]  | stack[1152921514161008544] = ???;  stack[1152921514161008552] = ???;  //  dest_result_addr=1152921514161008544 |  dest_result_addr=1152921514161008552
        // 0x00BA46E0: STP x20, x19, [sp, #0x40]  | stack[1152921514161008560] = ???;  stack[1152921514161008568] = ???;  //  dest_result_addr=1152921514161008560 |  dest_result_addr=1152921514161008568
        // 0x00BA46E4: STP x29, x30, [sp, #0x50]  | stack[1152921514161008576] = ???;  stack[1152921514161008584] = ???;  //  dest_result_addr=1152921514161008576 |  dest_result_addr=1152921514161008584
        // 0x00BA46E8: ADD x29, sp, #0x50         | X29 = (1152921514161008496 + 80) = 1152921514161008576 (0x100000023978EFC0);
        // 0x00BA46EC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA46F0: LDRB w8, [x20, #0xacb]     | W8 = (bool)static_value_03733ACB;       
        // 0x00BA46F4: MOV x19, x0                | X19 = 1152921514161020592 (0x1000000239791EB0);//ML01
        // 0x00BA46F8: TBNZ w8, #0, #0xba4714     | if (static_value_03733ACB == true) goto label_0;
        // 0x00BA46FC: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x00BA4700: LDR x8, [x8, #0xf10]       | X8 = 0x2B8FFFC;                         
        // 0x00BA4704: LDR w0, [x8]               | W0 = 0x16C3;                            
        // 0x00BA4708: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C3, ????);     
        // 0x00BA470C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA4710: STRB w8, [x20, #0xacb]     | static_value_03733ACB = true;            //  dest_result_addr=57883339
        label_0:
        // 0x00BA4714: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x00BA4718: LDR x8, [x8, #0xf18]       | X8 = 1152921504615792640;               
        // 0x00BA471C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.String> val_1 = null;
        // 0x00BA4720: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00BA4724: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00BA4728: LDR x8, [x8, #0x9f8]       | X8 = 1152921509931587600;               
        // 0x00BA472C: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00BA4730: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::.ctor();
        // 0x00BA4734: BL #0x23fb0c4              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.String, System.String>();
        // 0x00BA4738: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00BA473C: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
        // 0x00BA4740: LDR x21, [x8]              | X21 = typeof(System.Char[]);            
        // 0x00BA4744: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BA4748: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00BA474C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA4750: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BA4754: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00BA4758: MOV x21, x0                | X21 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BA475C: CBNZ x21, #0xba4764        | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x00BA4760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_1:
        // 0x00BA4764: LDR w8, [x21, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00BA4768: CBNZ w8, #0xba4778         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_2;
        // 0x00BA476C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00BA4770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4774: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_2:
        // 0x00BA4778: MOVZ w8, #0x3d             | W8 = 61 (0x3D);//ML01                   
        // 0x00BA477C: STRH w8, [x21, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x3D;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 61;
        // 0x00BA4780: LDR x8, [x19, #0x10]       | X8 = this.mBuffer; //P2                 
        // 0x00BA4784: CBZ x8, #0xba48a8          | if (this.mBuffer == null) goto label_5; 
        if(this.mBuffer == null)
        {
            goto label_5;
        }
        // 0x00BA4788: ADRP x24, #0x35df000       | X24 = 56487936 (0x35DF000);             
        // 0x00BA478C: ADRP x25, #0x367b000       | X25 = 57126912 (0x367B000);             
        // 0x00BA4790: ADRP x26, #0x3635000       | X26 = 56840192 (0x3635000);             
        // 0x00BA4794: ADRP x27, #0x35c7000       | X27 = 56389632 (0x35C7000);             
        // 0x00BA4798: LDR x24, [x24, #0xc68]     | X24 = (string**)(1152921509747292080)("//");
        // 0x00BA479C: LDR x25, [x25, #0x8e8]     | X25 = (string**)(1152921509750977824)("\\n");
        // 0x00BA47A0: LDR x26, [x26, #0x288]     | X26 = (string**)(1152921509777796272)("\n");
        // 0x00BA47A4: LDR x27, [x27, #0x878]     | X27 = 1152921514160897264;              
        label_14:
        // 0x00BA47A8: LDR w9, [x19, #0x18]       | W9 = this.mOffset; //P2                 
        // 0x00BA47AC: LDR w8, [x8, #0x18]        | W8 = this.mBuffer.Length; //P2          
        // 0x00BA47B0: CMP w9, w8                 | STATE = COMPARE(this.mOffset, this.mBuffer.Length)
        // 0x00BA47B4: B.GE #0xba48a8             | if (this.mOffset >= this.mBuffer.Length) goto label_5;
        if(this.mOffset >= this.mBuffer.Length)
        {
            goto label_5;
        }
        // 0x00BA47B8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA47BC: MOV x0, x19                | X0 = 1152921514161020592 (0x1000000239791EB0);//ML01
        // 0x00BA47C0: BL #0xba4560               | X0 = this.ReadLine(skipEmptyLines:  true);
        string val_2 = this.ReadLine(skipEmptyLines:  true);
        // 0x00BA47C4: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00BA47C8: CBZ x22, #0xba48a8         | if (val_2 == null) goto label_5;        
        if(val_2 == null)
        {
            goto label_5;
        }
        // 0x00BA47CC: LDR x1, [x24]              | X1 = "//";                              
        // 0x00BA47D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA47D4: MOV x0, x22                | X0 = val_2;//m1                         
        // 0x00BA47D8: BL #0x18add38              | X0 = val_2.StartsWith(value:  "//");    
        bool val_3 = val_2.StartsWith(value:  "//");
        // 0x00BA47DC: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00BA47E0: TBNZ w8, #0, #0xba48a0     | if ((val_3 & 1) == true) goto label_8;  
        if(val_4 == true)
        {
            goto label_8;
        }
        // 0x00BA47E4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA47E8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
        // 0x00BA47EC: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x00BA47F0: MOV x0, x22                | X0 = val_2;//m1                         
        // 0x00BA47F4: MOV x1, x21                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BA47F8: BL #0x18a89b8              | X0 = val_2.Split(separator:  null, count:  2, options:  1);
        System.String[] val_5 = val_2.Split(separator:  null, count:  2, options:  1);
        // 0x00BA47FC: MOV x23, x0                | X23 = val_5;//m1                        
        val_9 = val_5;
        // 0x00BA4800: CBNZ x23, #0xba4808        | if (val_5 != null) goto label_7;        
        if(val_9 != null)
        {
            goto label_7;
        }
        // 0x00BA4804: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00BA4808: LDR w8, [x23, #0x18]       | W8 = val_5.Length; //P2                 
        // 0x00BA480C: CMP w8, #2                 | STATE = COMPARE(val_5.Length, 0x2)      
        // 0x00BA4810: B.NE #0xba48a0             | if (val_5.Length != 2) goto label_8;    
        if(val_5.Length != 2)
        {
            goto label_8;
        }
        // 0x00BA4814: LDR x22, [x23, #0x20]      | X22 = val_5[0]                          
        string val_9 = val_9[0];
        // 0x00BA4818: CBNZ x22, #0xba4820        | if (val_5[0] != null) goto label_9;     
        if(val_9 != null)
        {
            goto label_9;
        }
        // 0x00BA481C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00BA4820: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4824: MOV x0, x22                | X0 = val_5[0];//m1                      
        // 0x00BA4828: BL #0x18a946c              | X0 = val_5[0].Trim();                   
        string val_6 = val_9.Trim();
        // 0x00BA482C: LDR w8, [x23, #0x18]       | W8 = val_5.Length; //P2                 
        // 0x00BA4830: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00BA4834: CMP w8, #1                 | STATE = COMPARE(val_5.Length, 0x1)      
        // 0x00BA4838: B.HI #0xba4848             | if (val_5.Length > 1) goto label_10;    
        if(val_5.Length > 1)
        {
            goto label_10;
        }
        // 0x00BA483C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
        // 0x00BA4840: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4844: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_10:
        // 0x00BA4848: LDR x23, [x23, #0x28]      | X23 = val_5[1]                          
        string val_10 = val_9[1];
        // 0x00BA484C: CBNZ x23, #0xba4854        | if (val_5[1] != null) goto label_11;    
        if(val_10 != null)
        {
            goto label_11;
        }
        // 0x00BA4850: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00BA4854: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4858: MOV x0, x23                | X0 = val_5[1];//m1                      
        // 0x00BA485C: BL #0x18a946c              | X0 = val_5[1].Trim();                   
        string val_7 = val_10.Trim();
        // 0x00BA4860: MOV x23, x0                | X23 = val_7;//m1                        
        // 0x00BA4864: CBNZ x23, #0xba486c        | if (val_7 != null) goto label_12;       
        if(val_7 != null)
        {
            goto label_12;
        }
        // 0x00BA4868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_12:
        // 0x00BA486C: LDR x1, [x25]              | X1 = "\\n";                             
        // 0x00BA4870: LDR x2, [x26]              | X2 = "\n";                              
        // 0x00BA4874: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA4878: MOV x0, x23                | X0 = val_7;//m1                         
        // 0x00BA487C: BL #0x18ae7e4              | X0 = val_7.Replace(oldValue:  "\\n", newValue:  "\n");
        string val_8 = val_7.Replace(oldValue:  "\\n", newValue:  "\n");
        // 0x00BA4880: MOV x23, x0                | X23 = val_8;//m1                        
        val_9 = val_8;
        // 0x00BA4884: CBNZ x20, #0xba488c        | if ( != 0) goto label_13;               
        if(null != 0)
        {
            goto label_13;
        }
        // 0x00BA4888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_13:
        // 0x00BA488C: LDR x3, [x27]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::set_Item(System.String key, System.String value);
        // 0x00BA4890: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00BA4894: MOV x1, x22                | X1 = val_6;//m1                         
        // 0x00BA4898: MOV x2, x23                | X2 = val_8;//m1                         
        // 0x00BA489C: BL #0x23fc55c              | set_Item(key:  val_6, value:  val_9);   
        set_Item(key:  val_6, value:  val_9);
        label_8:
        // 0x00BA48A0: LDR x8, [x19, #0x10]       | X8 = this.mBuffer; //P2                 
        // 0x00BA48A4: CBNZ x8, #0xba47a8         | if (this.mBuffer != null) goto label_14;
        if(this.mBuffer != null)
        {
            goto label_14;
        }
        label_5:
        // 0x00BA48A8: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00BA48AC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA48B0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA48B4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA48B8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA48BC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00BA48C0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00BA48C4: RET                        |  return (System.Collections.Generic.Dictionary<System.String, System.String>)typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        return (System.Collections.Generic.Dictionary<System.String, System.String>)val_1;
        //  |  // // {name=val_0, type=System.Collections.Generic.Dictionary<System.String, System.String>, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA48C8 (12208328), len: 1292  VirtAddr: 0x00BA48C8 RVA: 0x00BA48C8 token: 100687908 methodIndex: 25598 delegateWrapperIndex: 0 methodInvoker: 0
    public BetterList<string> ReadCSV()
    {
        //
        // Disasemble & Code
        //  | 
        BetterList<System.String> val_25;
        //  | 
        var val_26;
        //  | 
        var val_27;
        //  | 
        var val_28;
        //  | 
        var val_29;
        //  | 
        var val_30;
        //  | 
        var val_31;
        //  | 
        var val_32;
        //  | 
        var val_33;
        //  | 
        var val_34;
        //  | 
        BetterList<System.String> val_35;
        //  | 
        var val_36;
        // 0x00BA48C8: STP x28, x27, [sp, #-0x60]! | stack[1152921514161339712] = ???;  stack[1152921514161339720] = ???;  //  dest_result_addr=1152921514161339712 |  dest_result_addr=1152921514161339720
        // 0x00BA48CC: STP x26, x25, [sp, #0x10]  | stack[1152921514161339728] = ???;  stack[1152921514161339736] = ???;  //  dest_result_addr=1152921514161339728 |  dest_result_addr=1152921514161339736
        // 0x00BA48D0: STP x24, x23, [sp, #0x20]  | stack[1152921514161339744] = ???;  stack[1152921514161339752] = ???;  //  dest_result_addr=1152921514161339744 |  dest_result_addr=1152921514161339752
        // 0x00BA48D4: STP x22, x21, [sp, #0x30]  | stack[1152921514161339760] = ???;  stack[1152921514161339768] = ???;  //  dest_result_addr=1152921514161339760 |  dest_result_addr=1152921514161339768
        // 0x00BA48D8: STP x20, x19, [sp, #0x40]  | stack[1152921514161339776] = ???;  stack[1152921514161339784] = ???;  //  dest_result_addr=1152921514161339776 |  dest_result_addr=1152921514161339784
        // 0x00BA48DC: STP x29, x30, [sp, #0x50]  | stack[1152921514161339792] = ???;  stack[1152921514161339800] = ???;  //  dest_result_addr=1152921514161339792 |  dest_result_addr=1152921514161339800
        // 0x00BA48E0: ADD x29, sp, #0x50         | X29 = (1152921514161339712 + 80) = 1152921514161339792 (0x10000002397DFD90);
        // 0x00BA48E4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA48E8: LDRB w8, [x20, #0xacc]     | W8 = (bool)static_value_03733ACC;       
        // 0x00BA48EC: MOV x19, x0                | X19 = 1152921514161351808 (0x10000002397E2C80);//ML01
        val_25 = this;
        // 0x00BA48F0: TBNZ w8, #0, #0xba490c     | if (static_value_03733ACC == true) goto label_0;
        // 0x00BA48F4: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00BA48F8: LDR x8, [x8, #0x638]       | X8 = 0x2B8FFF8;                         
        // 0x00BA48FC: LDR w0, [x8]               | W0 = 0x16C2;                            
        // 0x00BA4900: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C2, ????);     
        // 0x00BA4904: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA4908: STRB w8, [x20, #0xacc]     | static_value_03733ACC = true;            //  dest_result_addr=57883340
        label_0:
        // 0x00BA490C: ADRP x27, #0x3636000       | X27 = 56844288 (0x3636000);             
        // 0x00BA4910: LDR x27, [x27, #0x30]      | X27 = 1152921504876068864;              
        // 0x00BA4914: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_26 = null;
        // 0x00BA4918: LDRB w8, [x0, #0x10a]      | W8 = ByteReader.__il2cppRuntimeField_10A;
        // 0x00BA491C: TBZ w8, #0, #0xba4930      | if (ByteReader.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA4920: LDR w8, [x0, #0xbc]        | W8 = ByteReader.__il2cppRuntimeField_cctor_finished;
        // 0x00BA4924: CBNZ w8, #0xba4930         | if (ByteReader.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA4928: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReader), ????);
        // 0x00BA492C: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_26 = null;
        label_2:
        // 0x00BA4930: LDR x8, [x0, #0xa0]        | X8 = ByteReader.__il2cppRuntimeField_static_fields;
        // 0x00BA4934: LDR x20, [x8]              | X20 = ByteReader.mTemp;                 
        // 0x00BA4938: CBNZ x20, #0xba4940        | if (ByteReader.mTemp != null) goto label_3;
        if(ByteReader.mTemp != null)
        {
            goto label_3;
        }
        // 0x00BA493C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReader), ????);
        label_3:
        // 0x00BA4940: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
        // 0x00BA4944: LDR x8, [x8, #0x7a0]       | X8 = 1152921514161243760;               
        // 0x00BA4948: MOV x0, x20                | X0 = ByteReader.mTemp;//m1              
        // 0x00BA494C: LDR x1, [x8]               | X1 = public System.Void BetterList<System.String>::Clear();
        // 0x00BA4950: BL #0x19c1cf4              | ByteReader.mTemp.Clear();               
        ByteReader.mTemp.Clear();
        // 0x00BA4954: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00BA4958: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00BA495C: LDR x0, [x8]               | X0 = typeof(System.String);             
        val_27 = null;
        // 0x00BA4960: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00BA4964: TBZ w8, #0, #0xba4980      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00BA4968: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00BA496C: CBNZ w8, #0xba4980         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00BA4970: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00BA4974: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00BA4978: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00BA497C: LDR x0, [x8]               | X0 = typeof(System.String);             
        val_27 = null;
        label_5:
        // 0x00BA4980: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00BA4984: ADRP x28, #0x362a000       | X28 = 56795136 (0x362A000);             
        // 0x00BA4988: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_28 = 0;
        // 0x00BA498C: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        val_29 = 0;
        // 0x00BA4990: LDR x20, [x8]              | X20 = System.String.Empty;              
        // 0x00BA4994: LDR x28, [x28, #0xc28]     | X28 = 1152921514161244784;              
        label_41:
        // 0x00BA4998: LDR x8, [x19, #0x10]       | X8 = this.mBuffer; //P2                 
        // 0x00BA499C: CBZ x8, #0xba4d44          | if (this.mBuffer == null) goto label_13;
        if(this.mBuffer == null)
        {
            goto label_13;
        }
        // 0x00BA49A0: LDR w9, [x19, #0x18]       | W9 = this.mOffset; //P2                 
        // 0x00BA49A4: LDR w8, [x8, #0x18]        | W8 = this.mBuffer.Length; //P2          
        // 0x00BA49A8: CMP w9, w8                 | STATE = COMPARE(this.mOffset, this.mBuffer.Length)
        // 0x00BA49AC: B.GE #0xba4d44             | if (this.mOffset >= this.mBuffer.Length) goto label_13;
        if(this.mOffset >= this.mBuffer.Length)
        {
            goto label_13;
        }
        // 0x00BA49B0: TBZ w25, #0, #0xba4a34     | if ((0x0 & 0x1) == 0) goto label_8;     
        if((val_29 & 1) == 0)
        {
            goto label_8;
        }
        // 0x00BA49B4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA49B8: MOV x0, x19                | X0 = 1152921514161351808 (0x10000002397E2C80);//ML01
        // 0x00BA49BC: BL #0xba4560               | X0 = this.ReadLine(skipEmptyLines:  false);
        string val_1 = this.ReadLine(skipEmptyLines:  false);
        // 0x00BA49C0: CBZ x0, #0xba4d44          | if (val_1 == null) goto label_13;       
        if(val_1 == null)
        {
            goto label_13;
        }
        // 0x00BA49C4: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x00BA49C8: LDR x8, [x8, #0x8e8]       | X8 = (string**)(1152921509750977824)("\\n");
        // 0x00BA49CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA49D0: LDR x1, [x8]               | X1 = "\\n";                             
        // 0x00BA49D4: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00BA49D8: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509777796272)("\n");
        // 0x00BA49DC: LDR x2, [x8]               | X2 = "\n";                              
        // 0x00BA49E0: BL #0x18ae7e4              | X0 = val_1.Replace(oldValue:  "\\n", newValue:  "\n");
        string val_2 = val_1.Replace(oldValue:  "\\n", newValue:  "\n");
        // 0x00BA49E4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00BA49E8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00BA49EC: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00BA49F0: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00BA49F4: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00BA49F8: TBZ w9, #0, #0xba4a0c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00BA49FC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00BA4A00: CBNZ w9, #0xba4a0c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00BA4A04: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00BA4A08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_11:
        // 0x00BA4A0C: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00BA4A10: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509777796272)("\n");
        // 0x00BA4A14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA4A18: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA4A1C: MOV x1, x20                | X1 = System.String.Empty;//m1           
        // 0x00BA4A20: LDR x2, [x8]               | X2 = "\n";                              
        // 0x00BA4A24: MOV x3, x22                | X3 = val_2;//m1                         
        // 0x00BA4A28: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  System.String.Empty, str2:  "\n");
        string val_3 = System.String.Concat(str0:  0, str1:  System.String.Empty, str2:  "\n");
        // 0x00BA4A2C: MOV x20, x0                | X20 = val_3;//m1                        
        val_30 = val_3;
        // 0x00BA4A30: B #0xba4a6c                |  goto label_12;                         
        goto label_12;
        label_8:
        // 0x00BA4A34: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA4A38: MOV x0, x19                | X0 = 1152921514161351808 (0x10000002397E2C80);//ML01
        // 0x00BA4A3C: BL #0xba4560               | X0 = this.ReadLine(skipEmptyLines:  true);
        string val_4 = this.ReadLine(skipEmptyLines:  true);
        // 0x00BA4A40: CBZ x0, #0xba4d44          | if (val_4 == null) goto label_13;       
        if(val_4 == null)
        {
            goto label_13;
        }
        // 0x00BA4A44: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x00BA4A48: LDR x8, [x8, #0x8e8]       | X8 = (string**)(1152921509750977824)("\\n");
        // 0x00BA4A4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA4A50: LDR x1, [x8]               | X1 = "\\n";                             
        // 0x00BA4A54: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00BA4A58: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509777796272)("\n");
        // 0x00BA4A5C: LDR x2, [x8]               | X2 = "\n";                              
        // 0x00BA4A60: BL #0x18ae7e4              | X0 = val_4.Replace(oldValue:  "\\n", newValue:  "\n");
        string val_5 = val_4.Replace(oldValue:  "\\n", newValue:  "\n");
        // 0x00BA4A64: MOV x20, x0                | X20 = val_5;//m1                        
        val_30 = val_5;
        // 0x00BA4A68: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_28 = 0;
        label_12:
        // 0x00BA4A6C: CBNZ x20, #0xba4a74        | if (val_5 != null) goto label_14;       
        if(val_30 != null)
        {
            goto label_14;
        }
        // 0x00BA4A70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_14:
        // 0x00BA4A74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4A78: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4A7C: BL #0x18a4460              | X0 = val_5.get_Length();                
        int val_6 = val_30.Length;
        // 0x00BA4A80: MOV w23, w0                | W23 = val_6;//m1                        
        // 0x00BA4A84: MOV w22, w21               | W22 = 0 (0x0);//ML01                    
        // 0x00BA4A88: B #0xba4a90                |  goto label_15;                         
        goto label_15;
        label_39:
        // 0x00BA4A8C: ADD w21, w21, #1           | W21 = (val_28 + 1) = val_28 (0x00000001);
        val_28 = 1;
        label_15:
        // 0x00BA4A90: CBNZ x20, #0xba4a98        | if (val_5 != null) goto label_16;       
        if(val_30 != null)
        {
            goto label_16;
        }
        // 0x00BA4A94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_16:
        // 0x00BA4A98: CMP w21, w23               | STATE = COMPARE(0x1, val_6)             
        // 0x00BA4A9C: B.GE #0xba4c48             | if (val_28 >= val_6) goto label_17;     
        if(val_28 >= val_6)
        {
            goto label_17;
        }
        // 0x00BA4AA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA4AA4: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4AA8: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00BA4AAC: BL #0x18a4468              | X0 = val_5.get_Chars(index:  1);        
        char val_7 = val_30.Chars[1];
        // 0x00BA4AB0: AND w8, w0, #0xffff        | W8 = (val_7 & 65535);                   
        char val_8 = val_7 & 65535;
        // 0x00BA4AB4: CMP w8, #0x22              | STATE = COMPARE((val_7 & 65535), 0x22)  
        // 0x00BA4AB8: B.EQ #0xba4ad4             | if (val_8 == '"') goto label_18;        
        if(val_8 == '"')
        {
            goto label_18;
        }
        // 0x00BA4ABC: CMP w8, #0x2c              | STATE = COMPARE((val_7 & 65535), 0x2C)  
        // 0x00BA4AC0: B.NE #0xba4a8c             | if (val_8 != ',') goto label_39;        
        if(val_8 != ',')
        {
            goto label_39;
        }
        // 0x00BA4AC4: AND w8, w25, #1            | W8 = (val_29 & 1);                      
        var val_9 = val_29 & 1;
        // 0x00BA4AC8: TBZ w8, #0, #0xba4b14      | if (((val_29 & 1) & 0x1) == 0) goto label_20;
        if((val_9 & 1) == 0)
        {
            goto label_20;
        }
        // 0x00BA4ACC: ORR w25, wzr, #1           | W25 = 1(0x1);                           
        // 0x00BA4AD0: B #0xba4a8c                |  goto label_39;                         
        goto label_39;
        label_18:
        // 0x00BA4AD4: ADD w24, w21, #1           | W24 = (val_28 + 1);                     
        int val_10 = val_28 + 1;
        // 0x00BA4AD8: TBZ w25, #0, #0xba4b7c     | if ((0x0 & 0x1) == 0) goto label_22;    
        if((val_29 & 1) == 0)
        {
            goto label_22;
        }
        // 0x00BA4ADC: CMP w24, w23               | STATE = COMPARE((val_28 + 1), val_6)    
        // 0x00BA4AE0: B.GE #0xba4ca8             | if (val_10 >= val_6) goto label_23;     
        if(val_10 >= val_6)
        {
            goto label_23;
        }
        // 0x00BA4AE4: CBNZ x20, #0xba4aec        | if (val_5 != null) goto label_24;       
        if(val_30 != null)
        {
            goto label_24;
        }
        // 0x00BA4AE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_24:
        // 0x00BA4AEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA4AF0: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4AF4: MOV w1, w24                | W1 = (val_28 + 1);//m1                  
        // 0x00BA4AF8: BL #0x18a4468              | X0 = val_5.get_Chars(index:  val_10);   
        char val_11 = val_30.Chars[val_10];
        // 0x00BA4AFC: AND w8, w0, #0xffff        | W8 = (val_11 & 65535);                  
        char val_12 = val_11 & 65535;
        // 0x00BA4B00: CMP w8, #0x22              | STATE = COMPARE((val_11 & 65535), 0x22) 
        // 0x00BA4B04: B.NE #0xba4b88             | if (val_12 != '"') goto label_25;       
        if(val_12 != '"')
        {
            goto label_25;
        }
        // 0x00BA4B08: ORR w25, wzr, #1           | W25 = 1(0x1);                           
        // 0x00BA4B0C: MOV w21, w24               | W21 = (val_28 + 1);//m1                 
        // 0x00BA4B10: B #0xba4a8c                |  goto label_39;                         
        goto label_39;
        label_20:
        // 0x00BA4B14: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_31 = null;
        // 0x00BA4B18: LDRB w8, [x0, #0x10a]      | W8 = ByteReader.__il2cppRuntimeField_10A;
        // 0x00BA4B1C: TBZ w8, #0, #0xba4b30      | if (ByteReader.__il2cppRuntimeField_has_cctor == 0) goto label_28;
        // 0x00BA4B20: LDR w8, [x0, #0xbc]        | W8 = ByteReader.__il2cppRuntimeField_cctor_finished;
        // 0x00BA4B24: CBNZ w8, #0xba4b30         | if (ByteReader.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
        // 0x00BA4B28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReader), ????);
        // 0x00BA4B2C: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_31 = null;
        label_28:
        // 0x00BA4B30: LDR x8, [x0, #0xa0]        | X8 = ByteReader.__il2cppRuntimeField_static_fields;
        // 0x00BA4B34: LDR x24, [x8]              | X24 = ByteReader.mTemp;                 
        // 0x00BA4B38: CBNZ x20, #0xba4b40        | if (val_5 != null) goto label_29;       
        if(val_30 != null)
        {
            goto label_29;
        }
        // 0x00BA4B3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReader), ????);
        label_29:
        // 0x00BA4B40: SUB w2, w21, w22           | W2 = (val_28 - val_28);                 
        int val_13 = val_28 - val_28;
        // 0x00BA4B44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA4B48: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4B4C: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00BA4B50: BL #0x18a920c              | X0 = val_5.Substring(startIndex:  0, length:  int val_13 = val_28 - val_28);
        string val_14 = val_30.Substring(startIndex:  0, length:  val_13);
        // 0x00BA4B54: MOV x22, x0                | X22 = val_14;//m1                       
        // 0x00BA4B58: CBNZ x24, #0xba4b60        | if (ByteReader.mTemp != null) goto label_30;
        if(ByteReader.mTemp != null)
        {
            goto label_30;
        }
        // 0x00BA4B5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_30:
        // 0x00BA4B60: LDR x2, [x28]              | X2 = public System.Void BetterList<System.String>::Add(System.String item);
        // 0x00BA4B64: MOV x0, x24                | X0 = ByteReader.mTemp;//m1              
        // 0x00BA4B68: MOV x1, x22                | X1 = val_14;//m1                        
        // 0x00BA4B6C: BL #0x19c1d08              | ByteReader.mTemp.Add(item:  val_14);    
        ByteReader.mTemp.Add(item:  val_14);
        // 0x00BA4B70: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00BA4B74: ADD w22, w21, #1           | W22 = (val_28 + 1);                     
        var val_15 = val_28 + 1;
        // 0x00BA4B78: B #0xba4a8c                |  goto label_39;                         
        goto label_39;
        label_22:
        // 0x00BA4B7C: ORR w25, wzr, #1           | W25 = 1(0x1);                           
        // 0x00BA4B80: MOV w22, w24               | W22 = (val_28 + 1);//m1                 
        // 0x00BA4B84: B #0xba4a8c                |  goto label_39;                         
        goto label_39;
        label_25:
        // 0x00BA4B88: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_32 = null;
        // 0x00BA4B8C: LDRB w8, [x0, #0x10a]      | W8 = ByteReader.__il2cppRuntimeField_10A;
        // 0x00BA4B90: TBZ w8, #0, #0xba4ba4      | if (ByteReader.__il2cppRuntimeField_has_cctor == 0) goto label_34;
        // 0x00BA4B94: LDR w8, [x0, #0xbc]        | W8 = ByteReader.__il2cppRuntimeField_cctor_finished;
        // 0x00BA4B98: CBNZ w8, #0xba4ba4         | if (ByteReader.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
        // 0x00BA4B9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReader), ????);
        // 0x00BA4BA0: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_32 = null;
        label_34:
        // 0x00BA4BA4: LDR x8, [x0, #0xa0]        | X8 = ByteReader.__il2cppRuntimeField_static_fields;
        // 0x00BA4BA8: LDR x25, [x8]              | X25 = ByteReader.mTemp;                 
        // 0x00BA4BAC: CBNZ x20, #0xba4bb4        | if (val_5 != null) goto label_35;       
        if(val_30 != null)
        {
            goto label_35;
        }
        // 0x00BA4BB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReader), ????);
        label_35:
        // 0x00BA4BB4: SUB w2, w21, w22           | W2 = (val_28 - val_28);                 
        int val_16 = val_28 - val_28;
        // 0x00BA4BB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA4BBC: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4BC0: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00BA4BC4: BL #0x18a920c              | X0 = val_5.Substring(startIndex:  0, length:  int val_16 = val_28 - val_28);
        string val_17 = val_30.Substring(startIndex:  0, length:  val_16);
        // 0x00BA4BC8: MOV x26, x0                | X26 = val_17;//m1                       
        // 0x00BA4BCC: CBNZ x26, #0xba4bd4        | if (val_17 != null) goto label_36;      
        if(val_17 != null)
        {
            goto label_36;
        }
        // 0x00BA4BD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_36:
        // 0x00BA4BD4: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00BA4BD8: LDR x8, [x8, #0xca8]       | X8 = (string**)(1152921514161311344)("\"\"");
        // 0x00BA4BDC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA4BE0: MOV x0, x26                | X0 = val_17;//m1                        
        // 0x00BA4BE4: LDR x1, [x8]               | X1 = "\"\"";                            
        // 0x00BA4BE8: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00BA4BEC: LDR x8, [x8, #0x6a0]       | X8 = (string**)(1152921513630838320)("\"");
        // 0x00BA4BF0: LDR x2, [x8]               | X2 = "\"";                              
        // 0x00BA4BF4: BL #0x18ae7e4              | X0 = val_17.Replace(oldValue:  "\"\"", newValue:  "\"");
        string val_18 = val_17.Replace(oldValue:  "\"\"", newValue:  "\"");
        // 0x00BA4BF8: MOV x26, x0                | X26 = val_18;//m1                       
        // 0x00BA4BFC: CBNZ x25, #0xba4c04        | if (ByteReader.mTemp != null) goto label_37;
        if(ByteReader.mTemp != null)
        {
            goto label_37;
        }
        // 0x00BA4C00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_37:
        // 0x00BA4C04: LDR x2, [x28]              | X2 = public System.Void BetterList<System.String>::Add(System.String item);
        // 0x00BA4C08: MOV x0, x25                | X0 = ByteReader.mTemp;//m1              
        // 0x00BA4C0C: MOV x1, x26                | X1 = val_18;//m1                        
        // 0x00BA4C10: BL #0x19c1d08              | ByteReader.mTemp.Add(item:  val_18);    
        ByteReader.mTemp.Add(item:  val_18);
        // 0x00BA4C14: CBNZ x20, #0xba4c1c        | if (val_5 != null) goto label_38;       
        if(val_30 != null)
        {
            goto label_38;
        }
        // 0x00BA4C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ByteReader.mTemp, ????);
        label_38:
        // 0x00BA4C1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA4C20: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4C24: MOV w1, w24                | W1 = (val_28 + 1);//m1                  
        // 0x00BA4C28: BL #0x18a4468              | X0 = val_5.get_Chars(index:  val_10);   
        char val_19 = val_30.Chars[val_10];
        // 0x00BA4C2C: AND w8, w0, #0xffff        | W8 = (val_19 & 65535);                  
        char val_20 = val_19 & 65535;
        // 0x00BA4C30: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00BA4C34: ADD w9, w21, #2            | W9 = (val_28 + 2);                      
        var val_21 = val_28 + 2;
        // 0x00BA4C38: CMP w8, #0x2c              | STATE = COMPARE((val_19 & 65535), 0x2C) 
        // 0x00BA4C3C: CSEL w21, w24, w21, eq     | W21 = val_20 == ',' ? (val_28 + 1) : val_28;
        val_28 = (val_20 == ',') ? (val_10) : (val_28);
        // 0x00BA4C40: CSEL w22, w9, w22, eq      | W22 = val_20 == ',' ? (val_28 + 2) : val_28;
        var val_22 = (val_20 == ',') ? (val_21) : (val_28);
        // 0x00BA4C44: B #0xba4a8c                |  goto label_39;                         
        goto label_39;
        label_17:
        // 0x00BA4C48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4C4C: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4C50: BL #0x18a4460              | X0 = val_5.get_Length();                
        int val_23 = val_30.Length;
        // 0x00BA4C54: CMP w22, w0                | STATE = COMPARE(0x0, val_23)            
        // 0x00BA4C58: B.GE #0xba4d94             | if (val_28 >= val_23) goto label_40;    
        if(val_28 >= val_23)
        {
            goto label_40;
        }
        // 0x00BA4C5C: AND w8, w25, #1            | W8 = (val_29 & 1);                      
        var val_24 = val_29 & 1;
        // 0x00BA4C60: MOV w21, w22               | W21 = 0 (0x0);//ML01                    
        // 0x00BA4C64: ORR w25, wzr, #1           | W25 = 1(0x1);                           
        val_29 = 1;
        // 0x00BA4C68: TBNZ w8, #0, #0xba4998     | if (((val_29 & 1) & 0x1) != 0) goto label_41;
        if((val_24 & 1) != 0)
        {
            goto label_41;
        }
        // 0x00BA4C6C: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_33 = null;
        // 0x00BA4C70: LDRB w8, [x0, #0x10a]      | W8 = ByteReader.__il2cppRuntimeField_10A;
        // 0x00BA4C74: TBZ w8, #0, #0xba4c88      | if (ByteReader.__il2cppRuntimeField_has_cctor == 0) goto label_43;
        // 0x00BA4C78: LDR w8, [x0, #0xbc]        | W8 = ByteReader.__il2cppRuntimeField_cctor_finished;
        // 0x00BA4C7C: CBNZ w8, #0xba4c88         | if (ByteReader.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
        // 0x00BA4C80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReader), ????);
        // 0x00BA4C84: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_33 = null;
        label_43:
        // 0x00BA4C88: LDR x8, [x0, #0xa0]        | X8 = ByteReader.__il2cppRuntimeField_static_fields;
        // 0x00BA4C8C: LDR x19, [x8]              | X19 = ByteReader.mTemp;                 
        val_25 = ByteReader.mTemp;
        // 0x00BA4C90: CBZ x20, #0xba4d4c         | if (val_5 == null) goto label_44;       
        if(val_30 == null)
        {
            goto label_44;
        }
        // 0x00BA4C94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4C98: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4C9C: BL #0x18a4460              | X0 = val_5.get_Length();                
        int val_25 = val_30.Length;
        // 0x00BA4CA0: MOV w21, w0                | W21 = val_25;//m1                       
        val_28 = val_25;
        // 0x00BA4CA4: B #0xba4d64                |  goto label_45;                         
        goto label_45;
        label_23:
        // 0x00BA4CA8: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_34 = null;
        // 0x00BA4CAC: LDRB w8, [x0, #0x10a]      | W8 = ByteReader.__il2cppRuntimeField_10A;
        // 0x00BA4CB0: TBZ w8, #0, #0xba4cc4      | if (ByteReader.__il2cppRuntimeField_has_cctor == 0) goto label_47;
        // 0x00BA4CB4: LDR w8, [x0, #0xbc]        | W8 = ByteReader.__il2cppRuntimeField_cctor_finished;
        // 0x00BA4CB8: CBNZ w8, #0xba4cc4         | if (ByteReader.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
        // 0x00BA4CBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReader), ????);
        // 0x00BA4CC0: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_34 = null;
        label_47:
        // 0x00BA4CC4: LDR x8, [x0, #0xa0]        | X8 = ByteReader.__il2cppRuntimeField_static_fields;
        // 0x00BA4CC8: LDR x19, [x8]              | X19 = ByteReader.mTemp;                 
        val_25 = ByteReader.mTemp;
        // 0x00BA4CCC: CBNZ x20, #0xba4cd4        | if (val_5 != null) goto label_48;       
        if(val_30 != null)
        {
            goto label_48;
        }
        // 0x00BA4CD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReader), ????);
        label_48:
        // 0x00BA4CD4: SUB w2, w21, w22           | W2 = (val_28 - val_28);                 
        int val_26 = val_28 - val_28;
        // 0x00BA4CD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA4CDC: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4CE0: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00BA4CE4: BL #0x18a920c              | X0 = val_5.Substring(startIndex:  0, length:  int val_26 = val_28 - val_28);
        string val_27 = val_30.Substring(startIndex:  0, length:  val_26);
        // 0x00BA4CE8: MOV x20, x0                | X20 = val_27;//m1                       
        // 0x00BA4CEC: CBNZ x20, #0xba4cf4        | if (val_27 != null) goto label_49;      
        if(val_27 != null)
        {
            goto label_49;
        }
        // 0x00BA4CF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_49:
        // 0x00BA4CF4: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00BA4CF8: LDR x8, [x8, #0xca8]       | X8 = (string**)(1152921514161311344)("\"\"");
        // 0x00BA4CFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA4D00: MOV x0, x20                | X0 = val_27;//m1                        
        // 0x00BA4D04: LDR x1, [x8]               | X1 = "\"\"";                            
        // 0x00BA4D08: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00BA4D0C: LDR x8, [x8, #0x6a0]       | X8 = (string**)(1152921513630838320)("\"");
        // 0x00BA4D10: LDR x2, [x8]               | X2 = "\"";                              
        // 0x00BA4D14: BL #0x18ae7e4              | X0 = val_27.Replace(oldValue:  "\"\"", newValue:  "\"");
        string val_28 = val_27.Replace(oldValue:  "\"\"", newValue:  "\"");
        // 0x00BA4D18: MOV x20, x0                | X20 = val_28;//m1                       
        // 0x00BA4D1C: CBNZ x19, #0xba4d24        | if (ByteReader.mTemp != null) goto label_50;
        if(val_25 != null)
        {
            goto label_50;
        }
        // 0x00BA4D20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_50:
        // 0x00BA4D24: LDR x2, [x28]              | X2 = public System.Void BetterList<System.String>::Add(System.String item);
        // 0x00BA4D28: MOV x0, x19                | X0 = ByteReader.mTemp;//m1              
        // 0x00BA4D2C: MOV x1, x20                | X1 = val_28;//m1                        
        // 0x00BA4D30: BL #0x19c1d08              | ByteReader.mTemp.Add(item:  val_28);    
        val_25.Add(item:  val_28);
        // 0x00BA4D34: LDR x8, [x27]              | X8 = typeof(ByteReader);                
        // 0x00BA4D38: LDR x8, [x8, #0xa0]        | X8 = ByteReader.__il2cppRuntimeField_static_fields;
        // 0x00BA4D3C: LDR x0, [x8]               | X0 = ByteReader.mTemp;                  
        val_35 = ByteReader.mTemp;
        // 0x00BA4D40: B #0xba4db8                |  goto label_52;                         
        goto label_52;
        label_13:
        // 0x00BA4D44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_35 = 0;
        // 0x00BA4D48: B #0xba4db8                |  goto label_52;                         
        goto label_52;
        label_44:
        // 0x00BA4D4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReader), ????);
        // 0x00BA4D50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA4D54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4D58: BL #0x18a4460              | X0 = 0.get_Length();                    
        int val_29 = 0.Length;
        // 0x00BA4D5C: MOV w21, w0                | W21 = val_29;//m1                       
        val_28 = val_29;
        // 0x00BA4D60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
        label_45:
        // 0x00BA4D64: SUB w2, w21, w22           | W2 = (val_29 - val_28);                 
        int val_30 = val_28 - val_28;
        // 0x00BA4D68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA4D6C: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA4D70: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00BA4D74: BL #0x18a920c              | X0 = val_5.Substring(startIndex:  0, length:  int val_30 = val_28 - val_28);
        string val_31 = val_30.Substring(startIndex:  0, length:  val_30);
        // 0x00BA4D78: MOV x20, x0                | X20 = val_31;//m1                       
        // 0x00BA4D7C: CBNZ x19, #0xba4d84        | if (ByteReader.mTemp != null) goto label_53;
        if(val_25 != null)
        {
            goto label_53;
        }
        // 0x00BA4D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_53:
        // 0x00BA4D84: LDR x2, [x28]              | X2 = public System.Void BetterList<System.String>::Add(System.String item);
        // 0x00BA4D88: MOV x0, x19                | X0 = ByteReader.mTemp;//m1              
        // 0x00BA4D8C: MOV x1, x20                | X1 = val_31;//m1                        
        // 0x00BA4D90: BL #0x19c1d08              | ByteReader.mTemp.Add(item:  val_31);    
        val_25.Add(item:  val_31);
        label_40:
        // 0x00BA4D94: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_36 = null;
        // 0x00BA4D98: LDRB w8, [x0, #0x10a]      | W8 = ByteReader.__il2cppRuntimeField_10A;
        // 0x00BA4D9C: TBZ w8, #0, #0xba4db0      | if (ByteReader.__il2cppRuntimeField_has_cctor == 0) goto label_55;
        // 0x00BA4DA0: LDR w8, [x0, #0xbc]        | W8 = ByteReader.__il2cppRuntimeField_cctor_finished;
        // 0x00BA4DA4: CBNZ w8, #0xba4db0         | if (ByteReader.__il2cppRuntimeField_cctor_finished != 0) goto label_55;
        // 0x00BA4DA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReader), ????);
        // 0x00BA4DAC: LDR x0, [x27]              | X0 = typeof(ByteReader);                
        val_36 = null;
        label_55:
        // 0x00BA4DB0: LDR x8, [x0, #0xa0]        | X8 = ByteReader.__il2cppRuntimeField_static_fields;
        // 0x00BA4DB4: LDR x0, [x8]               | X0 = ByteReader.mTemp;                  
        val_35 = ByteReader.mTemp;
        label_52:
        // 0x00BA4DB8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA4DBC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA4DC0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA4DC4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA4DC8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00BA4DCC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00BA4DD0: RET                        |  return (BetterList<System.String>)ByteReader.mTemp;
        return val_35;
        //  |  // // {name=val_0, type=BetterList<System.String>, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4DD4 (12209620), len: 116  VirtAddr: 0x00BA4DD4 RVA: 0x00BA4DD4 token: 100687909 methodIndex: 25599 delegateWrapperIndex: 0 methodInvoker: 0
    private static ByteReader()
    {
        //
        // Disasemble & Code
        // 0x00BA4DD4: STP x20, x19, [sp, #-0x20]! | stack[1152921514161534720] = ???;  stack[1152921514161534728] = ???;  //  dest_result_addr=1152921514161534720 |  dest_result_addr=1152921514161534728
        // 0x00BA4DD8: STP x29, x30, [sp, #0x10]  | stack[1152921514161534736] = ???;  stack[1152921514161534744] = ???;  //  dest_result_addr=1152921514161534736 |  dest_result_addr=1152921514161534744
        // 0x00BA4DDC: ADD x29, sp, #0x10         | X29 = (1152921514161534720 + 16) = 1152921514161534736 (0x100000023980F710);
        // 0x00BA4DE0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA4DE4: LDRB w8, [x19, #0xacd]     | W8 = (bool)static_value_03733ACD;       
        // 0x00BA4DE8: TBNZ w8, #0, #0xba4e04     | if (static_value_03733ACD == true) goto label_0;
        // 0x00BA4DEC: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00BA4DF0: LDR x8, [x8, #0x150]       | X8 = 0x2B8FFC8;                         
        // 0x00BA4DF4: LDR w0, [x8]               | W0 = 0x16B6;                            
        // 0x00BA4DF8: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B6, ????);     
        // 0x00BA4DFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA4E00: STRB w8, [x19, #0xacd]     | static_value_03733ACD = true;            //  dest_result_addr=57883341
        label_0:
        // 0x00BA4E04: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
        // 0x00BA4E08: LDR x8, [x8, #0xfb0]       | X8 = 1152921504875749376;               
        // 0x00BA4E0C: LDR x0, [x8]               | X0 = typeof(BetterList<T>);             
        BetterList<System.String> val_1 = null;
        // 0x00BA4E10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BetterList<T>), ????);
        // 0x00BA4E14: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00BA4E18: LDR x8, [x8, #0xb10]       | X8 = 1152921514161521728;               
        // 0x00BA4E1C: MOV x19, x0                | X19 = 1152921504875749376 (0x1000000010072000);//ML01
        // 0x00BA4E20: LDR x1, [x8]               | X1 = public System.Void BetterList<System.String>::.ctor();
        // 0x00BA4E24: BL #0x19c19a0              | .ctor();                                
        val_1 = new BetterList<System.String>();
        // 0x00BA4E28: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00BA4E2C: LDR x8, [x8, #0x30]        | X8 = 1152921504876068864;               
        // 0x00BA4E30: LDR x8, [x8]               | X8 = typeof(ByteReader);                
        // 0x00BA4E34: LDR x8, [x8, #0xa0]        | X8 = ByteReader.__il2cppRuntimeField_static_fields;
        // 0x00BA4E38: STR x19, [x8]              | ByteReader.mTemp = typeof(BetterList<T>);  //  dest_result_addr=1152921504876072960
        ByteReader.mTemp = val_1;
        // 0x00BA4E3C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA4E40: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA4E44: RET                        |  return;                                
        return;
    
    }

}
