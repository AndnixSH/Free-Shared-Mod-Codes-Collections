using UnityEngine;
[Serializable]
public class AdvancedSmooth.ConstantTurn : AdvancedSmooth.TurnConstructor
{
    // Fields
    private UnityEngine.Vector3 circleCenter; //  0x00000018
    private double gamma1; //  0x00000028
    private double gamma2; //  0x00000030
    private bool clockwise; //  0x00000038
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D1E424 (13755428), len: 112  VirtAddr: 0x00D1E424 RVA: 0x00D1E424 token: 100683411 methodIndex: 49707 delegateWrapperIndex: 0 methodInvoker: 0
    public AdvancedSmooth.ConstantTurn()
    {
        //
        // Disasemble & Code
        // 0x00D1E424: STP x20, x19, [sp, #-0x20]! | stack[1152921513480235680] = ???;  stack[1152921513480235688] = ???;  //  dest_result_addr=1152921513480235680 |  dest_result_addr=1152921513480235688
        // 0x00D1E428: STP x29, x30, [sp, #0x10]  | stack[1152921513480235696] = ???;  stack[1152921513480235704] = ???;  //  dest_result_addr=1152921513480235696 |  dest_result_addr=1152921513480235704
        // 0x00D1E42C: ADD x29, sp, #0x10         | X29 = (1152921513480235680 + 16) = 1152921513480235696 (0x1000000210E52AB0);
        // 0x00D1E430: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D1E434: LDRB w8, [x20, #0x2e0]     | W8 = (bool)static_value_037342E0;       
        // 0x00D1E438: MOV x19, x0                | X19 = 1152921513480247712 (0x1000000210E559A0);//ML01
        // 0x00D1E43C: TBNZ w8, #0, #0xd1e458     | if (static_value_037342E0 == true) goto label_0;
        // 0x00D1E440: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00D1E444: LDR x8, [x8, #0x360]       | X8 = 0x2B92838;                         
        // 0x00D1E448: LDR w0, [x8]               | W0 = 0x20D3;                            
        // 0x00D1E44C: BL #0x2782188              | X0 = sub_2782188( ?? 0x20D3, ????);     
        // 0x00D1E450: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D1E454: STRB w8, [x20, #0x2e0]     | static_value_037342E0 = true;            //  dest_result_addr=57885408
        label_0:
        // 0x00D1E458: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
        // 0x00D1E45C: LDR x8, [x8, #0x640]       | X8 = 1152921504848539648;               
        // 0x00D1E460: LDR x0, [x8]               | X0 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1E464: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
        // 0x00D1E468: TBZ w8, #0, #0xd1e478      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D1E46C: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
        // 0x00D1E470: CBNZ w8, #0xd1e478         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D1E474: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
        label_2:
        // 0x00D1E478: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
        // 0x00D1E47C: STR w8, [x19, #0x14]       | mem[1152921513480247732] = 0x3F800000;   //  dest_result_addr=1152921513480247732
        mem[1152921513480247732] = 1065353216;
        // 0x00D1E480: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D1E484: MOV x0, x19                | X0 = 1152921513480247712 (0x1000000210E559A0);//ML01
        object val_1 = this;
        // 0x00D1E488: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1E48C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D1E490: B #0x16f59f0               | this..ctor(); return;                   
        val_1 = new System.Object();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D1ED68 (13757800), len: 4  VirtAddr: 0x00D1ED68 RVA: 0x00D1ED68 token: 100683412 methodIndex: 49708 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Prepare(int i, UnityEngine.Vector3[] vectorPath)
    {
        //
        // Disasemble & Code
        // 0x00D1ED68: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D1ED6C (13757804), len: 1228  VirtAddr: 0x00D1ED6C RVA: 0x00D1ED6C token: 100683413 methodIndex: 49709 delegateWrapperIndex: 0 methodInvoker: 0
    public override void TangentToTangent(System.Collections.Generic.List<Pathfinding.AdvancedSmooth.Turn> turnList)
    {
        //
        // Disasemble & Code
        //  | 
        var val_18;
        //  | 
        float val_19;
        //  | 
        float val_20;
        //  | 
        var val_21;
        //  | 
        float val_22;
        //  | 
        float val_23;
        //  | 
        var val_24;
        //  | 
        UnityEngine.Vector3 val_25;
        //  | 
        var val_26;
        //  | 
        var val_27;
        //  | 
        UnityEngine.Vector3 val_28;
        //  | 
        float val_29;
        // 0x00D1ED6C: STP d15, d14, [sp, #-0x80]! | stack[1152921513480537408] = ???;  stack[1152921513480537416] = ???;  //  dest_result_addr=1152921513480537408 |  dest_result_addr=1152921513480537416
        // 0x00D1ED70: STP d13, d12, [sp, #0x10]  | stack[1152921513480537424] = ???;  stack[1152921513480537432] = ???;  //  dest_result_addr=1152921513480537424 |  dest_result_addr=1152921513480537432
        // 0x00D1ED74: STP d11, d10, [sp, #0x20]  | stack[1152921513480537440] = ???;  stack[1152921513480537448] = ???;  //  dest_result_addr=1152921513480537440 |  dest_result_addr=1152921513480537448
        // 0x00D1ED78: STP d9, d8, [sp, #0x30]    | stack[1152921513480537456] = ???;  stack[1152921513480537464] = ???;  //  dest_result_addr=1152921513480537456 |  dest_result_addr=1152921513480537464
        // 0x00D1ED7C: STP x24, x23, [sp, #0x40]  | stack[1152921513480537472] = ???;  stack[1152921513480537480] = ???;  //  dest_result_addr=1152921513480537472 |  dest_result_addr=1152921513480537480
        // 0x00D1ED80: STP x22, x21, [sp, #0x50]  | stack[1152921513480537488] = ???;  stack[1152921513480537496] = ???;  //  dest_result_addr=1152921513480537488 |  dest_result_addr=1152921513480537496
        // 0x00D1ED84: STP x20, x19, [sp, #0x60]  | stack[1152921513480537504] = ???;  stack[1152921513480537512] = ???;  //  dest_result_addr=1152921513480537504 |  dest_result_addr=1152921513480537512
        // 0x00D1ED88: STP x29, x30, [sp, #0x70]  | stack[1152921513480537520] = ???;  stack[1152921513480537528] = ???;  //  dest_result_addr=1152921513480537520 |  dest_result_addr=1152921513480537528
        // 0x00D1ED8C: ADD x29, sp, #0x70         | X29 = (1152921513480537408 + 112) = 1152921513480537520 (0x1000000210E9C5B0);
        // 0x00D1ED90: SUB sp, sp, #0x40          | SP = (1152921513480537408 - 64) = 1152921513480537344 (0x1000000210E9C500);
        // 0x00D1ED94: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D1ED98: LDRB w8, [x21, #0x2e1]     | W8 = (bool)static_value_037342E1;       
        // 0x00D1ED9C: MOV x19, x1                | X19 = turnList;//m1                     
        // 0x00D1EDA0: MOV x20, x0                | X20 = 1152921513480549536 (0x1000000210E9F4A0);//ML01
        // 0x00D1EDA4: TBNZ w8, #0, #0xd1edc0     | if (static_value_037342E1 == true) goto label_0;
        // 0x00D1EDA8: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
        // 0x00D1EDAC: LDR x8, [x8, #0x670]       | X8 = 0x2B92840;                         
        // 0x00D1EDB0: LDR w0, [x8]               | W0 = 0x20D5;                            
        // 0x00D1EDB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x20D5, ????);     
        // 0x00D1EDB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D1EDBC: STRB w8, [x21, #0x2e1]     | static_value_037342E1 = true;            //  dest_result_addr=57885409
        label_0:
        // 0x00D1EDC0: ADRP x21, #0x3640000       | X21 = 56885248 (0x3640000);             
        // 0x00D1EDC4: LDR x21, [x21, #0x640]     | X21 = 1152921504848539648;              
        // 0x00D1EDC8: STRB wzr, [sp, #0x3f]      | stack[1152921513480537407] = 0x0;        //  dest_result_addr=1152921513480537407
        // 0x00D1EDCC: STR wzr, [sp, #0x38]       | stack[1152921513480537400] = 0x0;        //  dest_result_addr=1152921513480537400
        // 0x00D1EDD0: LDR x0, [x21]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_18 = null;
        // 0x00D1EDD4: STR xzr, [sp, #0x30]       | stack[1152921513480537392] = 0x0;        //  dest_result_addr=1152921513480537392
        // 0x00D1EDD8: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
        // 0x00D1EDDC: TBZ w8, #0, #0xd1edf0      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D1EDE0: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
        // 0x00D1EDE4: CBNZ w8, #0xd1edf0         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D1EDE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
        // 0x00D1EDEC: LDR x0, [x21]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_18 = null;
        label_2:
        // 0x00D1EDF0: ADRP x22, #0x3673000       | X22 = 57094144 (0x3673000);             
        // 0x00D1EDF4: LDR x8, [x0, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1EDF8: LDR x22, [x22, #0x488]     | X22 = 1152921504695078912;              
        // 0x00D1EDFC: LDR x0, [x22]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D1EE00: LDP s10, s9, [x8, #0x28]   | S10 = AdvancedSmooth.TurnConstructor.t1; S9 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_2C; //  | 
        // 0x00D1EE04: LDR s8, [x8, #0x30]        | S8 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_30;
        // 0x00D1EE08: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D1EE0C: TBZ w8, #0, #0xd1ee1c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D1EE10: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D1EE14: CBNZ w8, #0xd1ee1c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D1EE18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_4:
        // 0x00D1EE1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1EE20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1EE24: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_1 = UnityEngine.Vector3.up;
        // 0x00D1EE28: MOV v3.16b, v0.16b         | V3 = val_1.x;//m1                       
        // 0x00D1EE2C: MOV v4.16b, v1.16b         | V4 = val_1.y;//m1                       
        // 0x00D1EE30: MOV v5.16b, v2.16b         | V5 = val_1.z;//m1                       
        // 0x00D1EE34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1EE38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1EE3C: MOV v0.16b, v10.16b        | V0 = AdvancedSmooth.TurnConstructor.t1;//m1
        // 0x00D1EE40: MOV v1.16b, v9.16b         | V1 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_2C;//m1
        // 0x00D1EE44: MOV v2.16b, v8.16b         | V2 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_30;//m1
        // 0x00D1EE48: BL #0x269988c              | X0 = UnityEngine.Vector3.Cross(lhs:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.t1, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_2C, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_30}, rhs:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z});
        UnityEngine.Vector3 val_2 = UnityEngine.Vector3.Cross(lhs:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.t1, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_2C, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_30}, rhs:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z});
        // 0x00D1EE4C: STP s1, s0, [sp, #0x28]    | stack[1152921513480537384] = val_2.y;  stack[1152921513480537388] = val_2.x;  //  dest_result_addr=1152921513480537384 |  dest_result_addr=1152921513480537388
        // 0x00D1EE50: LDR x8, [x21]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1EE54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1EE58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1EE5C: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1EE60: LDP s1, s6, [x8, #0x14]    | S1 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14; S6 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18; //  | 
        // 0x00D1EE64: LDP s5, s0, [x8, #0xc]     | S5 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C; S0 = AdvancedSmooth.TurnConstructor.current; //  | 
        // 0x00D1EE68: LDP s3, s4, [x8, #4]       | S3 = AdvancedSmooth.TurnConstructor.prev; S4 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8; //  | 
        // 0x00D1EE6C: STR s2, [sp, #0x24]        | stack[1152921513480537380] = val_2.z;    //  dest_result_addr=1152921513480537380
        // 0x00D1EE70: MOV v2.16b, v6.16b         | V2 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18;//m1
        // 0x00D1EE74: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C});
        UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C});
        // 0x00D1EE78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1EE7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1EE80: FMOV s3, #0.50000000       | S3 = 0.5;                               
        // 0x00D1EE84: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        // 0x00D1EE88: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x00D1EE8C: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
        // 0x00D1EE90: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, d:  0.5f);
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, d:  0.5f);
        // 0x00D1EE94: LDR x8, [x21]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1EE98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1EE9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1EEA0: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1EEA4: LDP s3, s4, [x8, #4]       | S3 = AdvancedSmooth.TurnConstructor.prev; S4 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8; //  | 
        // 0x00D1EEA8: LDR s5, [x8, #0xc]         | S5 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C;
        // 0x00D1EEAC: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C});
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C});
        // 0x00D1EEB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1EEB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1EEB8: STR s0, [sp, #0x20]        | stack[1152921513480537376] = val_5.x;    //  dest_result_addr=1152921513480537376
        // 0x00D1EEBC: MOV v12.16b, v1.16b        | V12 = val_5.y;//m1                      
        val_19 = val_5.y;
        // 0x00D1EEC0: MOV v13.16b, v2.16b        | V13 = val_5.z;//m1                      
        // 0x00D1EEC4: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_6 = UnityEngine.Vector3.up;
        // 0x00D1EEC8: MOV v3.16b, v0.16b         | V3 = val_6.x;//m1                       
        // 0x00D1EECC: MOV v4.16b, v1.16b         | V4 = val_6.y;//m1                       
        // 0x00D1EED0: MOV v5.16b, v2.16b         | V5 = val_6.z;//m1                       
        // 0x00D1EED4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1EED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1EEDC: MOV v0.16b, v8.16b         | V0 = val_3.x;//m1                       
        // 0x00D1EEE0: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x00D1EEE4: MOV v2.16b, v10.16b        | V2 = val_3.z;//m1                       
        // 0x00D1EEE8: BL #0x269988c              | X0 = UnityEngine.Vector3.Cross(lhs:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, rhs:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.Cross(lhs:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, rhs:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        // 0x00D1EEEC: LDR x8, [x21]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1EEF0: ADRP x23, #0x366c000       | X23 = 57065472 (0x366C000);             
        // 0x00D1EEF4: MOV v14.16b, v0.16b        | V14 = val_7.x;//m1                      
        val_20 = val_7.x;
        // 0x00D1EEF8: MOV v15.16b, v1.16b        | V15 = val_7.y;//m1                      
        // 0x00D1EEFC: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1EF00: LDR x23, [x23, #0x440]     | X23 = 1152921504837943296;              
        // 0x00D1EF04: MOV v11.16b, v2.16b        | V11 = val_7.z;//m1                      
        // 0x00D1EF08: LDR x0, [x23]              | X0 = typeof(Pathfinding.Polygon);       
        // 0x00D1EF0C: LDP s10, s9, [x8, #4]      | S10 = AdvancedSmooth.TurnConstructor.prev; S9 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8; //  | 
        // 0x00D1EF10: LDR s8, [x8, #0xc]         | S8 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C;
        // 0x00D1EF14: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Polygon.__il2cppRuntimeField_10A;
        // 0x00D1EF18: TBZ w8, #0, #0xd1ef28      | if (Pathfinding.Polygon.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00D1EF1C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Polygon.__il2cppRuntimeField_cctor_finished;
        // 0x00D1EF20: CBNZ w8, #0xd1ef28         | if (Pathfinding.Polygon.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00D1EF24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Polygon), ????);
        label_6:
        // 0x00D1EF28: STP s15, s11, [sp, #0x14]  | stack[1152921513480537364] = val_7.y;  stack[1152921513480537368] = val_7.z;  //  dest_result_addr=1152921513480537364 |  dest_result_addr=1152921513480537368
        // 0x00D1EF2C: STR s14, [sp, #0x10]       | stack[1152921513480537360] = val_7.x;    //  dest_result_addr=1152921513480537360
        // 0x00D1EF30: STP s12, s13, [sp, #4]     | stack[1152921513480537348] = val_5.y;  stack[1152921513480537352] = val_5.z;  //  dest_result_addr=1152921513480537348 |  dest_result_addr=1152921513480537352
        // 0x00D1EF34: LDP s0, s5, [sp, #0x20]    | S0 = val_5.x; S5 = val_2.z;              //  | 
        // 0x00D1EF38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        bool val_8 = false;
        // 0x00D1EF3C: ADD x1, sp, #0x3f          | X1 = (1152921513480537344 + 63) = 1152921513480537407 (0x1000000210E9C53F);
        // 0x00D1EF40: MOV v1.16b, v9.16b         | V1 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8;//m1
        // 0x00D1EF44: STR s0, [sp]               | stack[1152921513480537344] = val_5.x;    //  dest_result_addr=1152921513480537344
        // 0x00D1EF48: LDP s4, s3, [sp, #0x28]    | S4 = val_2.y; S3 = val_2.x;              //  | 
        // 0x00D1EF4C: MOV v0.16b, v10.16b        | V0 = AdvancedSmooth.TurnConstructor.prev;//m1
        // 0x00D1EF50: MOV v2.16b, v8.16b         | V2 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C;//m1
        // 0x00D1EF54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D1EF58: BL #0x1410108              | X0 = Pathfinding.Polygon.IntersectionPointOptimized(start1:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, dir1:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, start2:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.z, z = val_20}, dir2:  new UnityEngine.Vector3() {x = val_7.z, y = val_5.x, z = val
        UnityEngine.Vector3 val_9 = Pathfinding.Polygon.IntersectionPointOptimized(start1:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, dir1:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, start2:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.z, z = val_20}, dir2:  new UnityEngine.Vector3() {x = val_7.z, y = val_5.x, z = val_2.y}, intersects: out  val_8);
        // 0x00D1EF5C: MOV v8.16b, v0.16b         | V8 = val_9.x;//m1                       
        val_21 = val_9.x;
        // 0x00D1EF60: MOV v9.16b, v1.16b         | V9 = val_9.y;//m1                       
        val_22 = val_9.y;
        // 0x00D1EF64: MOV v10.16b, v2.16b        | V10 = val_9.z;//m1                      
        val_23 = val_9.z;
        // 0x00D1EF68: STP s8, s9, [x20, #0x18]   | this.circleCenter = val_9;  mem[1152921513480549564] = val_9.y;  //  dest_result_addr=1152921513480549560 |  dest_result_addr=1152921513480549564
        this.circleCenter = val_9;
        mem[1152921513480549564] = val_22;
        // 0x00D1EF6C: STR s10, [x20, #0x20]      | mem[1152921513480549568] = val_9.z;      //  dest_result_addr=1152921513480549568
        mem[1152921513480549568] = val_23;
        // 0x00D1EF70: LDRB w8, [sp, #0x3f]       | W8 = 0x0;                               
        // 0x00D1EF74: CBZ w8, #0xd1f210          | if (0x0 == 0) goto label_7;             
        if(0 == 0)
        {
            goto label_7;
        }
        // 0x00D1EF78: LDR x0, [x21]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_24 = null;
        // 0x00D1EF7C: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
        // 0x00D1EF80: TBZ w8, #0, #0xd1ef9c      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00D1EF84: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
        // 0x00D1EF88: CBNZ w8, #0xd1ef9c         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00D1EF8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
        // 0x00D1EF90: LDR x0, [x21]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_24 = null;
        // 0x00D1EF94: LDP s8, s9, [x20, #0x18]   | S8 = this.circleCenter; //P2             //  | 
        val_25 = this.circleCenter;
        // 0x00D1EF98: LDR s10, [x20, #0x20]      | 
        label_9:
        // 0x00D1EF9C: LDR x8, [x0, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1EFA0: LDR x0, [x22]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D1EFA4: LDP s13, s12, [x8, #4]     | S13 = AdvancedSmooth.TurnConstructor.prev; S12 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8; //  | 
        // 0x00D1EFA8: LDR s11, [x8, #0xc]        | S11 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C;
        // 0x00D1EFAC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D1EFB0: TBZ w8, #0, #0xd1efc0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00D1EFB4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D1EFB8: CBNZ w8, #0xd1efc0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00D1EFBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_11:
        // 0x00D1EFC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1EFC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1EFC8: MOV v0.16b, v13.16b        | V0 = AdvancedSmooth.TurnConstructor.prev;//m1
        // 0x00D1EFCC: MOV v1.16b, v12.16b        | V1 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8;//m1
        // 0x00D1EFD0: MOV v2.16b, v11.16b        | V2 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C;//m1
        // 0x00D1EFD4: MOV v3.16b, v8.16b         | V3 = this.circleCenter;//m1             
        // 0x00D1EFD8: MOV v4.16b, v9.16b         | V4 = val_9.y;//m1                       
        // 0x00D1EFDC: MOV v5.16b, v10.16b        | V5 = val_9.z;//m1                       
        // 0x00D1EFE0: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, b:  new UnityEngine.Vector3() {x = val_25, y = val_22, z = val_23});
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, b:  new UnityEngine.Vector3() {x = val_25, y = val_22, z = val_23});
        // 0x00D1EFE4: FCVT d2, s2                | D2 = (double)val_10.z);                 
        // 0x00D1EFE8: FCVT d1, s0                | D1 = (double)val_10.x);                 
        // 0x00D1EFEC: MOV v0.16b, v2.16b         | V0 = val_10.z;//m1                      
        // 0x00D1EFF0: BL #0x980580               | X0 = sub_980580( ?? 0x0, ????);         
        // 0x00D1EFF4: STR d0, [x20, #0x28]       | this.gamma1 = val_10.z;                  //  dest_result_addr=1152921513480549576
        this.gamma1 = (double)val_10.z;
        // 0x00D1EFF8: LDR x8, [x21]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1EFFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F004: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F008: LDP s3, s4, [x20, #0x18]   | S3 = this.circleCenter; //P2             //  | 
        // 0x00D1F00C: LDP s0, s1, [x8, #0x10]    | S0 = AdvancedSmooth.TurnConstructor.current; S1 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14; //  | 
        // 0x00D1F010: LDR s2, [x8, #0x18]        | S2 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18;
        // 0x00D1F014: LDR s5, [x20, #0x20]       | 
        // 0x00D1F018: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18}, b:  new UnityEngine.Vector3() {x = this.circleCenter, y = val_22, z = val_23});
        UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18}, b:  new UnityEngine.Vector3() {x = this.circleCenter, y = val_22, z = val_23});
        // 0x00D1F01C: FCVT d2, s2                | D2 = (double)val_11.z);                 
        // 0x00D1F020: FCVT d1, s0                | D1 = (double)val_11.x);                 
        // 0x00D1F024: MOV v0.16b, v2.16b         | V0 = val_11.z;//m1                      
        // 0x00D1F028: BL #0x980580               | X0 = sub_980580( ?? 0x0, ????);         
        // 0x00D1F02C: STR d0, [x20, #0x30]       | this.gamma2 = val_11.z;                  //  dest_result_addr=1152921513480549584
        this.gamma2 = (double)val_11.z;
        // 0x00D1F030: LDR x8, [x21]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F034: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F038: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F03C: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F040: LDP s13, s12, [x20, #0x18] | S13 = this.circleCenter; //P2            //  | 
        // 0x00D1F044: LDR s0, [x20, #0x20]       | 
        // 0x00D1F048: STR s0, [sp, #0x2c]        | stack[1152921513480537388] = val_11.z;   //  dest_result_addr=1152921513480537388
        // 0x00D1F04C: LDP s10, s9, [x8, #4]      | S10 = AdvancedSmooth.TurnConstructor.prev; S9 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8; //  | 
        // 0x00D1F050: LDR s8, [x8, #0xc]         | S8 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C;
        // 0x00D1F054: LDP s3, s4, [x8, #0x28]    | S3 = AdvancedSmooth.TurnConstructor.t1; S4 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_2C; //  | 
        // 0x00D1F058: LDR s5, [x8, #0x30]        | S5 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_30;
        // 0x00D1F05C: MOV v0.16b, v10.16b        | V0 = AdvancedSmooth.TurnConstructor.prev;//m1
        // 0x00D1F060: MOV v1.16b, v9.16b         | V1 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8;//m1
        // 0x00D1F064: MOV v2.16b, v8.16b         | V2 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C;//m1
        // 0x00D1F068: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.t1, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_2C, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_30});
        UnityEngine.Vector3 val_12 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.t1, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_2C, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_30});
        // 0x00D1F06C: LDR x0, [x23]              | X0 = typeof(Pathfinding.Polygon);       
        // 0x00D1F070: MOV v14.16b, v0.16b        | V14 = val_12.x;//m1                     
        // 0x00D1F074: MOV v15.16b, v1.16b        | V15 = val_12.y;//m1                     
        // 0x00D1F078: MOV v11.16b, v2.16b        | V11 = val_12.z;//m1                     
        // 0x00D1F07C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Polygon.__il2cppRuntimeField_10A;
        // 0x00D1F080: TBZ w8, #0, #0xd1f090      | if (Pathfinding.Polygon.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00D1F084: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Polygon.__il2cppRuntimeField_cctor_finished;
        // 0x00D1F088: CBNZ w8, #0xd1f090         | if (Pathfinding.Polygon.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00D1F08C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Polygon), ????);
        label_13:
        // 0x00D1F090: STP s15, s11, [sp, #4]     | stack[1152921513480537348] = val_12.y;  stack[1152921513480537352] = val_12.z;  //  dest_result_addr=1152921513480537348 |  dest_result_addr=1152921513480537352
        // 0x00D1F094: LDR s2, [sp, #0x2c]        | S2 = val_11.z;                          
        // 0x00D1F098: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F09C: MOV v0.16b, v13.16b        | V0 = this.circleCenter;//m1             
        // 0x00D1F0A0: MOV v1.16b, v12.16b        | V1 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8;//m1
        // 0x00D1F0A4: MOV v3.16b, v10.16b        | V3 = AdvancedSmooth.TurnConstructor.prev;//m1
        // 0x00D1F0A8: MOV v4.16b, v9.16b         | V4 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8;//m1
        // 0x00D1F0AC: MOV v5.16b, v8.16b         | V5 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C;//m1
        // 0x00D1F0B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F0B4: STR s14, [sp]              | stack[1152921513480537344] = val_12.x;   //  dest_result_addr=1152921513480537344
        // 0x00D1F0B8: BL #0x140f910              | X0 = Pathfinding.Polygon.Left(a:  new UnityEngine.Vector3() {x = this.circleCenter, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = (double)val_11.z}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, p:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.z, z = val_20});
        bool val_13 = Pathfinding.Polygon.Left(a:  new UnityEngine.Vector3() {x = this.circleCenter, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = (double)val_11.z}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.prev, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, p:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.z, z = val_20});
        // 0x00D1F0BC: LDP d0, d1, [x20, #0x28]   | D0 = this.gamma1; //P2  D1 = this.gamma2; //P2  //  | 
        // 0x00D1F0C0: MVN w9, w0                 | W9 = ~(val_13);                         
        bool val_16 = ~val_13;
        // 0x00D1F0C4: AND w9, w9, #1             | W9 = (~(val_13) & 1);                   
        val_16 = val_16 & 1;
        // 0x00D1F0C8: AND w8, w0, #1             | W8 = (val_13 & 1);                      
        bool val_14 = val_13;
        // 0x00D1F0CC: STRB w9, [x20, #0x38]      | this.clockwise = (~(val_13) & 1);        //  dest_result_addr=1152921513480549592
        this.clockwise = val_16;
        // 0x00D1F0D0: TBZ w8, #0, #0xd1f11c      | if ((val_13 & 1) == false) goto label_14;
        if(val_14 == false)
        {
            goto label_14;
        }
        // 0x00D1F0D4: FSUB d14, d0, d1           | D14 = (this.gamma1 - this.gamma2);      
        val_20 = this.gamma1 - this.gamma2;
        // 0x00D1F0D8: FCMP d14, #0.0             | STATE = COMPARE((this.gamma1 - this.gamma2), 0)
        // 0x00D1F0DC: B.PL #0xd1f0f4             | if (val_20 >= 0) goto label_15;         
        if(val_20 >= 0)
        {
            goto label_15;
        }
        // 0x00D1F0E0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00D1F0E4: LDR d0, [x8, #0xb00]       | D0 = 6.28318530717959;                  
        label_16:
        // 0x00D1F0E8: FADD d14, d14, d0          | D14 = ((this.gamma1 - this.gamma2) + 6.28318530717959);
        val_20 = val_20 + 6.28318530717959;
        // 0x00D1F0EC: FCMP d14, #0.0             | STATE = COMPARE(((this.gamma1 - this.gamma2) + 6.28318530717959), 0)
        // 0x00D1F0F0: B.MI #0xd1f0e8             | if (val_20 < 0) goto label_16;          
        if(val_20 < 0)
        {
            goto label_16;
        }
        label_15:
        // 0x00D1F0F4: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00D1F0F8: LDR d0, [x8, #0xb00]       | D0 = 6.28318530717959;                  
        // 0x00D1F0FC: FCMP d14, d0               | STATE = COMPARE(((this.gamma1 - this.gamma2) + 6.28318530717959), 3370280550400)
        // 0x00D1F100: B.LE #0xd1f160             | if (val_20 <= 6.28318530717959) goto label_22;
        if(val_20 <= 6.28318530717959)
        {
            goto label_22;
        }
        // 0x00D1F104: ADRP x8, #0x2a96000        | X8 = 44654592 (0x2A96000);              
        // 0x00D1F108: LDR d1, [x8, #0xf98]       | D1 = -6.28318530717959;                 
        label_18:
        // 0x00D1F10C: FADD d14, d14, d1          | D14 = (((this.gamma1 - this.gamma2) + 6.28318530717959) + -6.28318530717959);
        val_20 = val_20 + (-6.28318530717959);
        // 0x00D1F110: FCMP d14, d0               | STATE = COMPARE((((this.gamma1 - this.gamma2) + 6.28318530717959) + -6.28318530717959), 3370280550400)
        // 0x00D1F114: B.GT #0xd1f10c             | if (val_20 > 6.28318530717959) goto label_18;
        if(val_20 > 6.28318530717959)
        {
            goto label_18;
        }
        // 0x00D1F118: B #0xd1f160                |  goto label_22;                         
        goto label_22;
        label_14:
        // 0x00D1F11C: FSUB d14, d1, d0           | D14 = (this.gamma2 - this.gamma1);      
        val_20 = this.gamma2 - this.gamma1;
        // 0x00D1F120: FCMP d14, #0.0             | STATE = COMPARE((this.gamma2 - this.gamma1), 0)
        // 0x00D1F124: B.PL #0xd1f13c             | if (val_20 >= 0) goto label_20;         
        if(val_20 >= 0)
        {
            goto label_20;
        }
        // 0x00D1F128: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00D1F12C: LDR d0, [x8, #0xb00]       | D0 = 6.28318530717959;                  
        label_21:
        // 0x00D1F130: FADD d14, d14, d0          | D14 = ((this.gamma2 - this.gamma1) + 6.28318530717959);
        val_20 = val_20 + 6.28318530717959;
        // 0x00D1F134: FCMP d14, #0.0             | STATE = COMPARE(((this.gamma2 - this.gamma1) + 6.28318530717959), 0)
        // 0x00D1F138: B.MI #0xd1f130             | if (val_20 < 0) goto label_21;          
        if(val_20 < 0)
        {
            goto label_21;
        }
        label_20:
        // 0x00D1F13C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00D1F140: LDR d0, [x8, #0xb00]       | D0 = 6.28318530717959;                  
        // 0x00D1F144: FCMP d14, d0               | STATE = COMPARE(((this.gamma2 - this.gamma1) + 6.28318530717959), 3370280550400)
        // 0x00D1F148: B.LE #0xd1f160             | if (val_20 <= 6.28318530717959) goto label_22;
        if(val_20 <= 6.28318530717959)
        {
            goto label_22;
        }
        // 0x00D1F14C: ADRP x8, #0x2a96000        | X8 = 44654592 (0x2A96000);              
        // 0x00D1F150: LDR d1, [x8, #0xf98]       | D1 = -6.28318530717959;                 
        label_23:
        // 0x00D1F154: FADD d14, d14, d1          | D14 = (((this.gamma2 - this.gamma1) + 6.28318530717959) + -6.28318530717959);
        val_20 = val_20 + (-6.28318530717959);
        // 0x00D1F158: FCMP d14, d0               | STATE = COMPARE((((this.gamma2 - this.gamma1) + 6.28318530717959) + -6.28318530717959), 3370280550400)
        // 0x00D1F15C: B.GT #0xd1f154             | if (val_20 > 6.28318530717959) goto label_23;
        if(val_20 > 6.28318530717959)
        {
            goto label_23;
        }
        label_22:
        // 0x00D1F160: LDR x0, [x21]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_27 = null;
        // 0x00D1F164: LDP s10, s9, [x20, #0x18]  | S10 = this.circleCenter; //P2            //  | 
        val_28 = this.circleCenter;
        // 0x00D1F168: LDR s8, [x20, #0x20]       | 
        // 0x00D1F16C: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
        // 0x00D1F170: TBZ w8, #0, #0xd1f184      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x00D1F174: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
        // 0x00D1F178: CBNZ w8, #0xd1f184         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x00D1F17C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
        // 0x00D1F180: LDR x0, [x21]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_27 = null;
        label_25:
        // 0x00D1F184: LDR x8, [x0, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F188: LDR x0, [x22]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D1F18C: LDP s13, s12, [x8, #0x10]  | S13 = AdvancedSmooth.TurnConstructor.current; S12 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14; //  | 
        // 0x00D1F190: LDR s11, [x8, #0x18]       | S11 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18;
        // 0x00D1F194: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D1F198: TBZ w8, #0, #0xd1f1a8      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x00D1F19C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D1F1A0: CBNZ w8, #0xd1f1a8         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x00D1F1A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_27:
        // 0x00D1F1A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F1AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F1B0: MOV v0.16b, v10.16b        | V0 = this.circleCenter;//m1             
        // 0x00D1F1B4: MOV v1.16b, v9.16b         | V1 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8;//m1
        // 0x00D1F1B8: MOV v2.16b, v8.16b         | V2 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C;//m1
        // 0x00D1F1BC: MOV v3.16b, v13.16b        | V3 = AdvancedSmooth.TurnConstructor.current;//m1
        // 0x00D1F1C0: MOV v4.16b, v12.16b        | V4 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14;//m1
        // 0x00D1F1C4: MOV v5.16b, v11.16b        | V5 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18;//m1
        // 0x00D1F1C8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_28, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18});
        UnityEngine.Vector3 val_15 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_28, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_8, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_C}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18});
        // 0x00D1F1CC: ADD x0, sp, #0x30          | X0 = (1152921513480537344 + 48) = 1152921513480537392 (0x1000000210E9C530);
        // 0x00D1F1D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F1D4: STP s0, s1, [sp, #0x30]    | stack[1152921513480537392] = val_15.x;  stack[1152921513480537396] = val_15.y;  //  dest_result_addr=1152921513480537392 |  dest_result_addr=1152921513480537396
        // 0x00D1F1D8: STR s2, [sp, #0x38]        | stack[1152921513480537400] = val_15.z;   //  dest_result_addr=1152921513480537400
        // 0x00D1F1DC: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
        // 0x00D1F1E0: FCVT d0, s0                | D0 = (double)val_15.x);                 
        double val_17 = (double)val_15.x;
        // 0x00D1F1E4: FMUL d0, d14, d0           | D0 = ((((this.gamma2 - this.gamma1) + 6.28318530717959) + -6.28318530717959) * val_15.x);
        val_17 = val_20 * val_17;
        // 0x00D1F1E8: FCVT s8, d0                | S8 = (float)((((this.gamma2 - this.gamma1) + 6.28318530717959) + -6.28318530717959) * val_15.x));
        val_29 = (float)val_17;
        // 0x00D1F1EC: CBNZ x19, #0xd1f1f4        | if (turnList != null) goto label_28;    
        if(turnList != null)
        {
            goto label_28;
        }
        // 0x00D1F1F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000210E9C530, ????);
        label_28:
        // 0x00D1F1F4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D1F1F8: LDR x8, [x8, #0x748]       | X8 = 1152921513479746016;               
        // 0x00D1F1FC: FMOV w1, s8                | W1 = (((((this.gamma2 - this.gamma1) + 6.28318530717959) + -6.28318530717959) * val_15.x));
        // 0x00D1F200: MOV x0, x19                | X0 = turnList;//m1                      
        // 0x00D1F204: MOV x2, x20                | X2 = 1152921513480549536 (0x1000000210E9F4A0);//ML01
        // 0x00D1F208: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.List<Turn>::Add(Turn item);
        // 0x00D1F20C: BL #0x25a7050              | turnList.Add(item:  new Turn() {length = val_29, id = val_29, constructor = this});
        turnList.Add(item:  new Turn() {length = val_29, id = val_29, constructor = this});
        label_7:
        // 0x00D1F210: SUB sp, x29, #0x70         | SP = (1152921513480537520 - 112) = 1152921513480537408 (0x1000000210E9C540);
        // 0x00D1F214: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00D1F218: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00D1F21C: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00D1F220: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00D1F224: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00D1F228: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00D1F22C: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00D1F230: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00D1F234: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D1F2E0 (13759200), len: 760  VirtAddr: 0x00D1F2E0 RVA: 0x00D1F2E0 token: 100683414 methodIndex: 49710 delegateWrapperIndex: 0 methodInvoker: 0
    public override void GetPath(Pathfinding.AdvancedSmooth.Turn turn, System.Collections.Generic.List<UnityEngine.Vector3> output)
    {
        //
        // Disasemble & Code
        //  | 
        var val_9;
        //  | 
        float val_10;
        //  | 
        float val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        // 0x00D1F2E0: STP d15, d14, [sp, #-0x80]! | stack[1152921513480657600] = ???;  stack[1152921513480657608] = ???;  //  dest_result_addr=1152921513480657600 |  dest_result_addr=1152921513480657608
        // 0x00D1F2E4: STP d13, d12, [sp, #0x10]  | stack[1152921513480657616] = ???;  stack[1152921513480657624] = ???;  //  dest_result_addr=1152921513480657616 |  dest_result_addr=1152921513480657624
        // 0x00D1F2E8: STP d11, d10, [sp, #0x20]  | stack[1152921513480657632] = ???;  stack[1152921513480657640] = ???;  //  dest_result_addr=1152921513480657632 |  dest_result_addr=1152921513480657640
        // 0x00D1F2EC: STP d9, d8, [sp, #0x30]    | stack[1152921513480657648] = ???;  stack[1152921513480657656] = ???;  //  dest_result_addr=1152921513480657648 |  dest_result_addr=1152921513480657656
        // 0x00D1F2F0: STP x24, x23, [sp, #0x40]  | stack[1152921513480657664] = ???;  stack[1152921513480657672] = ???;  //  dest_result_addr=1152921513480657664 |  dest_result_addr=1152921513480657672
        // 0x00D1F2F4: STP x22, x21, [sp, #0x50]  | stack[1152921513480657680] = ???;  stack[1152921513480657688] = ???;  //  dest_result_addr=1152921513480657680 |  dest_result_addr=1152921513480657688
        // 0x00D1F2F8: STP x20, x19, [sp, #0x60]  | stack[1152921513480657696] = ???;  stack[1152921513480657704] = ???;  //  dest_result_addr=1152921513480657696 |  dest_result_addr=1152921513480657704
        // 0x00D1F2FC: STP x29, x30, [sp, #0x70]  | stack[1152921513480657712] = ???;  stack[1152921513480657720] = ???;  //  dest_result_addr=1152921513480657712 |  dest_result_addr=1152921513480657720
        // 0x00D1F300: ADD x29, sp, #0x70         | X29 = (1152921513480657600 + 112) = 1152921513480657712 (0x1000000210EB9B30);
        // 0x00D1F304: SUB sp, sp, #0x30          | SP = (1152921513480657600 - 48) = 1152921513480657552 (0x1000000210EB9A90);
        // 0x00D1F308: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D1F30C: LDRB w8, [x21, #0x2e2]     | W8 = (bool)static_value_037342E2;       
        // 0x00D1F310: MOV x20, x3                | X20 = output;//m1                       
        // 0x00D1F314: MOV x19, x0                | X19 = 1152921513480669728 (0x1000000210EBCA20);//ML01
        // 0x00D1F318: TBNZ w8, #0, #0xd1f334     | if (static_value_037342E2 == true) goto label_0;
        // 0x00D1F31C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00D1F320: LDR x8, [x8, #0x7d8]       | X8 = 0x2B9283C;                         
        // 0x00D1F324: LDR w0, [x8]               | W0 = 0x20D4;                            
        // 0x00D1F328: BL #0x2782188              | X0 = sub_2782188( ?? 0x20D4, ????);     
        // 0x00D1F32C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D1F330: STRB w8, [x21, #0x2e2]     | static_value_037342E2 = true;            //  dest_result_addr=57885410
        label_0:
        // 0x00D1F334: ADRP x22, #0x3640000       | X22 = 56885248 (0x3640000);             
        // 0x00D1F338: STR wzr, [sp, #0x28]       | stack[1152921513480657592] = 0x0;        //  dest_result_addr=1152921513480657592
        // 0x00D1F33C: STR xzr, [sp, #0x20]       | stack[1152921513480657584] = 0x0;        //  dest_result_addr=1152921513480657584
        // 0x00D1F340: STR wzr, [sp, #0x18]       | stack[1152921513480657576] = 0x0;        //  dest_result_addr=1152921513480657576
        // 0x00D1F344: STR xzr, [sp, #0x10]       | stack[1152921513480657568] = 0x0;        //  dest_result_addr=1152921513480657568
        // 0x00D1F348: STR wzr, [sp, #8]          | stack[1152921513480657560] = 0x0;        //  dest_result_addr=1152921513480657560
        // 0x00D1F34C: STR xzr, [sp]              | stack[1152921513480657552] = 0x0;        //  dest_result_addr=1152921513480657552
        // 0x00D1F350: LDR x22, [x22, #0x640]     | X22 = 1152921504848539648;              
        // 0x00D1F354: LDP d12, d11, [x19, #0x28] | D12 = this.gamma1; //P2  D11 = this.gamma2; //P2  //  | 
        // 0x00D1F358: LDRB w21, [x19, #0x38]     | W21 = this.clockwise; //P2              
        // 0x00D1F35C: LDR x0, [x22]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_9 = null;
        // 0x00D1F360: LDP s10, s9, [x19, #0x18]  | S10 = this.circleCenter; //P2            //  | 
        // 0x00D1F364: LDR s8, [x19, #0x20]       | 
        // 0x00D1F368: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
        // 0x00D1F36C: TBZ w8, #0, #0xd1f380      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D1F370: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
        // 0x00D1F374: CBNZ w8, #0xd1f380         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D1F378: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
        // 0x00D1F37C: LDR x0, [x22]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_9 = null;
        label_2:
        // 0x00D1F380: ADRP x23, #0x3673000       | X23 = 57094144 (0x3673000);             
        // 0x00D1F384: LDR x8, [x0, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F388: LDR x23, [x23, #0x488]     | X23 = 1152921504695078912;              
        // 0x00D1F38C: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D1F390: LDP s15, s14, [x8, #0x10]  | S15 = AdvancedSmooth.TurnConstructor.current; S14 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14; //  | 
        // 0x00D1F394: LDR s13, [x8, #0x18]       | S13 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18;
        // 0x00D1F398: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D1F39C: TBZ w8, #0, #0xd1f3ac      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D1F3A0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D1F3A4: CBNZ w8, #0xd1f3ac         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D1F3A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_4:
        // 0x00D1F3AC: CMP w21, #0                | STATE = COMPARE(this.clockwise, 0x0)    
        // 0x00D1F3B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F3B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F3B8: MOV v0.16b, v10.16b        | V0 = this.circleCenter;//m1             
        // 0x00D1F3BC: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00D1F3C0: MOV v2.16b, v8.16b         | V2 = V8.16B;//m1                        
        // 0x00D1F3C4: MOV v3.16b, v15.16b        | V3 = AdvancedSmooth.TurnConstructor.current;//m1
        // 0x00D1F3C8: MOV v4.16b, v14.16b        | V4 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14;//m1
        // 0x00D1F3CC: MOV v5.16b, v13.16b        | V5 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18;//m1
        // 0x00D1F3D0: CSET w21, ne               | W21 = this.clockwise == true ? 1 : 0;   
        bool val_1 = (this.clockwise == true) ? 1 : 0;
        // 0x00D1F3D4: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.circleCenter, y = V9.16B, z = V8.16B}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18});
        UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.circleCenter, y = V9.16B, z = V8.16B}, b:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18});
        // 0x00D1F3D8: ADD x0, sp, #0x20          | X0 = (1152921513480657552 + 32) = 1152921513480657584 (0x1000000210EB9AB0);
        // 0x00D1F3DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F3E0: STP s0, s1, [sp, #0x20]    | stack[1152921513480657584] = val_2.x;  stack[1152921513480657588] = val_2.y;  //  dest_result_addr=1152921513480657584 |  dest_result_addr=1152921513480657588
        // 0x00D1F3E4: STR s2, [sp, #0x28]        | stack[1152921513480657592] = val_2.z;    //  dest_result_addr=1152921513480657592
        // 0x00D1F3E8: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
        // 0x00D1F3EC: MOV v5.16b, v0.16b         | V5 = val_2.x;//m1                       
        // 0x00D1F3F0: MOV x0, x19                | X0 = 1152921513480669728 (0x1000000210EBCA20);//ML01
        // 0x00D1F3F4: MOV v0.16b, v12.16b        | V0 = this.gamma1;//m1                   
        // 0x00D1F3F8: MOV v1.16b, v11.16b        | V1 = this.gamma2;//m1                   
        // 0x00D1F3FC: MOV w1, w21                | W1 = this.clockwise == true ? 1 : 0;//m1
        // 0x00D1F400: MOV v2.16b, v10.16b        | V2 = this.circleCenter;//m1             
        // 0x00D1F404: MOV v3.16b, v9.16b         | V3 = V9.16B;//m1                        
        // 0x00D1F408: MOV v4.16b, v8.16b         | V4 = V8.16B;//m1                        
        // 0x00D1F40C: MOV x2, x20                | X2 = output;//m1                        
        // 0x00D1F410: BL #0xd1f5d8               | this.AddCircleSegment(startAngle:  this.gamma1, endAngle:  this.gamma2, clockwise:  val_1, center:  new UnityEngine.Vector3() {x = this.circleCenter, y = V9.16B, z = V8.16B}, output:  output, radius:  val_2.x);
        this.AddCircleSegment(startAngle:  this.gamma1, endAngle:  this.gamma2, clockwise:  val_1, center:  new UnityEngine.Vector3() {x = this.circleCenter, y = V9.16B, z = V8.16B}, output:  output, radius:  val_2.x);
        // 0x00D1F414: LDR x8, [x22]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F418: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F41C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F420: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F424: LDP s3, s4, [x19, #0x18]   | S3 = this.circleCenter; //P2             //  | 
        // 0x00D1F428: LDP s0, s1, [x8, #0x10]    | S0 = AdvancedSmooth.TurnConstructor.current; S1 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14; //  | 
        // 0x00D1F42C: LDR s2, [x8, #0x18]        | S2 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18;
        // 0x00D1F430: LDR s5, [x19, #0x20]       | 
        // 0x00D1F434: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18}, b:  new UnityEngine.Vector3() {x = this.circleCenter, y = V8.16B, z = val_2.x});
        UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.current, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_14, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_18}, b:  new UnityEngine.Vector3() {x = this.circleCenter, y = V8.16B, z = val_2.x});
        // 0x00D1F438: ADD x0, sp, #0x10          | X0 = (1152921513480657552 + 16) = 1152921513480657568 (0x1000000210EB9AA0);
        // 0x00D1F43C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F440: STP s0, s1, [sp, #0x10]    | stack[1152921513480657568] = val_3.x;  stack[1152921513480657572] = val_3.y;  //  dest_result_addr=1152921513480657568 |  dest_result_addr=1152921513480657572
        // 0x00D1F444: STR s2, [sp, #0x18]        | stack[1152921513480657576] = val_3.z;    //  dest_result_addr=1152921513480657576
        // 0x00D1F448: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00D1F44C: LDR x8, [x22]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F450: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F454: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F458: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F45C: STP s0, s1, [x8, #0x40]    | AdvancedSmooth.TurnConstructor.normal = val_3.x;  AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44 = val_3.y;  //  dest_result_addr=1152921504848543808 |  dest_result_addr=1152921504848543812
        AdvancedSmooth.TurnConstructor.normal = val_3.x;
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44 = val_3.y;
        // 0x00D1F460: STR s2, [x8, #0x48]        | AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48 = val_3.z;  //  dest_result_addr=1152921504848543816
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48 = val_3.z;
        // 0x00D1F464: LDR x8, [x22]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F468: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F46C: LDP s8, s9, [x8, #0x40]    | S8 = val_3.x; S9 = val_3.y;              //  | 
        val_10 = AdvancedSmooth.TurnConstructor.normal;
        // 0x00D1F470: LDR s10, [x8, #0x48]       | S10 = val_3.z;                          
        val_11 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48;
        // 0x00D1F474: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.up;
        // 0x00D1F478: MOV v3.16b, v0.16b         | V3 = val_4.x;//m1                       
        // 0x00D1F47C: MOV v4.16b, v1.16b         | V4 = val_4.y;//m1                       
        // 0x00D1F480: MOV v5.16b, v2.16b         | V5 = val_4.z;//m1                       
        // 0x00D1F484: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F488: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F48C: MOV v0.16b, v8.16b         | V0 = val_3.x;//m1                       
        // 0x00D1F490: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x00D1F494: MOV v2.16b, v10.16b        | V2 = val_3.z;//m1                       
        // 0x00D1F498: BL #0x269988c              | X0 = UnityEngine.Vector3.Cross(lhs:  new UnityEngine.Vector3() {x = val_10, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44, z = val_11}, rhs:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.Cross(lhs:  new UnityEngine.Vector3() {x = val_10, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44, z = val_11}, rhs:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        // 0x00D1F49C: MOV x0, sp                 | X0 = 1152921513480657552 (0x1000000210EB9A90);//ML01
        // 0x00D1F4A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F4A4: STP s0, s1, [sp]           | stack[1152921513480657552] = val_5.x;  stack[1152921513480657556] = val_5.y;  //  dest_result_addr=1152921513480657552 |  dest_result_addr=1152921513480657556
        // 0x00D1F4A8: STR s2, [sp, #8]           | stack[1152921513480657560] = val_5.z;    //  dest_result_addr=1152921513480657560
        // 0x00D1F4AC: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00D1F4B0: LDR x8, [x22]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F4B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F4B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F4BC: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F4C0: STP s0, s1, [x8, #0x34]    | AdvancedSmooth.TurnConstructor.t2 = val_5.x;  AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_38 = val_5.y;  //  dest_result_addr=1152921504848543796 |  dest_result_addr=1152921504848543800
        AdvancedSmooth.TurnConstructor.t2 = val_5.x;
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_38 = val_5.y;
        // 0x00D1F4C4: STR s2, [x8, #0x3c]        | AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_3C = val_5.z;  //  dest_result_addr=1152921504848543804
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_3C = val_5.z;
        // 0x00D1F4C8: LDR x8, [x22]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F4CC: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F4D0: LDP s0, s1, [x8, #0x40]    | S0 = val_3.x; S1 = val_3.y;              //  | 
        // 0x00D1F4D4: LDR s2, [x8, #0x48]        | S2 = val_3.z;                           
        // 0x00D1F4D8: BL #0x269a814              | X0 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.normal, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48});
        UnityEngine.Vector3 val_6 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.normal, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48});
        // 0x00D1F4DC: LDR x8, [x22]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F4E0: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F4E4: STP s0, s1, [x8, #0x40]    | AdvancedSmooth.TurnConstructor.normal = val_6.x;  AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44 = val_6.y;  //  dest_result_addr=1152921504848543808 |  dest_result_addr=1152921504848543812
        AdvancedSmooth.TurnConstructor.normal = val_6.x;
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44 = val_6.y;
        // 0x00D1F4E8: STR s2, [x8, #0x48]        | AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48 = val_6.z;  //  dest_result_addr=1152921504848543816
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48 = val_6.z;
        // 0x00D1F4EC: LDRB w8, [x19, #0x38]      | W8 = this.clockwise; //P2               
        // 0x00D1F4F0: CBNZ w8, #0xd1f588         | if (this.clockwise == true) goto label_5;
        if(this.clockwise == true)
        {
            goto label_5;
        }
        // 0x00D1F4F4: LDR x0, [x22]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_12 = null;
        // 0x00D1F4F8: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
        // 0x00D1F4FC: TBZ w8, #0, #0xd1f510      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00D1F500: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
        // 0x00D1F504: CBNZ w8, #0xd1f510         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00D1F508: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
        // 0x00D1F50C: LDR x0, [x22]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_12 = null;
        label_7:
        // 0x00D1F510: LDR x8, [x0, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F514: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D1F518: LDP s10, s9, [x8, #0x34]   | S10 = val_5.x; S9 = val_5.y;             //  | 
        val_11 = AdvancedSmooth.TurnConstructor.t2;
        // 0x00D1F51C: LDR s8, [x8, #0x3c]        | S8 = val_5.z;                           
        val_10 = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_3C;
        // 0x00D1F520: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D1F524: TBZ w8, #0, #0xd1f534      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00D1F528: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D1F52C: CBNZ w8, #0xd1f534         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00D1F530: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_9:
        // 0x00D1F534: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F538: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F53C: MOV v0.16b, v10.16b        | V0 = val_5.x;//m1                       
        // 0x00D1F540: MOV v1.16b, v9.16b         | V1 = val_5.y;//m1                       
        // 0x00D1F544: MOV v2.16b, v8.16b         | V2 = val_5.z;//m1                       
        // 0x00D1F548: BL #0x269a814              | X0 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = val_11, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_38, z = val_10});
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = val_11, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_38, z = val_10});
        // 0x00D1F54C: LDR x8, [x22]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F550: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D1F554: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D1F558: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F55C: STP s0, s1, [x8, #0x34]    | AdvancedSmooth.TurnConstructor.t2 = val_7.x;  AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_38 = val_7.y;  //  dest_result_addr=1152921504848543796 |  dest_result_addr=1152921504848543800
        AdvancedSmooth.TurnConstructor.t2 = val_7.x;
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_38 = val_7.y;
        // 0x00D1F560: STR s2, [x8, #0x3c]        | AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_3C = val_7.z;  //  dest_result_addr=1152921504848543804
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_3C = val_7.z;
        // 0x00D1F564: LDR x8, [x22]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F568: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F56C: LDP s0, s1, [x8, #0x40]    | S0 = val_6.x; S1 = val_6.y;              //  | 
        // 0x00D1F570: LDR s2, [x8, #0x48]        | S2 = val_6.z;                           
        // 0x00D1F574: BL #0x269a814              | X0 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.normal, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48});
        UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = AdvancedSmooth.TurnConstructor.normal, y = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44, z = AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48});
        // 0x00D1F578: LDR x8, [x22]              | X8 = typeof(AdvancedSmooth.TurnConstructor);
        // 0x00D1F57C: LDR x8, [x8, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F580: STP s0, s1, [x8, #0x40]    | AdvancedSmooth.TurnConstructor.normal = val_8.x;  AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44 = val_8.y;  //  dest_result_addr=1152921504848543808 |  dest_result_addr=1152921504848543812
        AdvancedSmooth.TurnConstructor.normal = val_8.x;
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_44 = val_8.y;
        // 0x00D1F584: STR s2, [x8, #0x48]        | AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48 = val_8.z;  //  dest_result_addr=1152921504848543816
        AdvancedSmooth.TurnConstructor.ThreeSixtyRadians.__il2cppRuntimeField_48 = val_8.z;
        label_5:
        // 0x00D1F588: LDR x0, [x22]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_13 = null;
        // 0x00D1F58C: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
        // 0x00D1F590: TBZ w8, #0, #0xd1f5a4      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00D1F594: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
        // 0x00D1F598: CBNZ w8, #0xd1f5a4         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00D1F59C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
        // 0x00D1F5A0: LDR x0, [x22]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
        val_13 = null;
        label_11:
        // 0x00D1F5A4: LDR x8, [x0, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
        // 0x00D1F5A8: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00D1F5AC: STRB w9, [x8, #0x58]       | AdvancedSmooth.TurnConstructor.changedPreviousTangent = true;  //  dest_result_addr=1152921504848543832
        AdvancedSmooth.TurnConstructor.changedPreviousTangent = true;
        // 0x00D1F5B0: SUB sp, x29, #0x70         | SP = (1152921513480657712 - 112) = 1152921513480657600 (0x1000000210EB9AC0);
        // 0x00D1F5B4: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00D1F5B8: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00D1F5BC: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00D1F5C0: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00D1F5C4: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00D1F5C8: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00D1F5CC: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00D1F5D0: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00D1F5D4: RET                        |  return;                                
        return;
    
    }

}
