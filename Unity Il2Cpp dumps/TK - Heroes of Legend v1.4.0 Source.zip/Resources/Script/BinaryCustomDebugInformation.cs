using UnityEngine;

namespace ILRuntime.Mono.Cecil.Cil
{
    public sealed class BinaryCustomDebugInformation : CustomDebugInformation
    {
        // Fields
        private byte[] data; //  0x00000030
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E59074 (15044724), len: 100  VirtAddr: 0x00E59074 RVA: 0x00E59074 token: 100664767 methodIndex: 19361 delegateWrapperIndex: 0 methodInvoker: 0
        public BinaryCustomDebugInformation(System.Guid identifier, byte[] data)
        {
            //
            // Disasemble & Code
            // 0x00E59074: STP x22, x21, [sp, #-0x30]! | stack[1152921509594835104] = ???;  stack[1152921509594835112] = ???;  //  dest_result_addr=1152921509594835104 |  dest_result_addr=1152921509594835112
            // 0x00E59078: STP x20, x19, [sp, #0x10]  | stack[1152921509594835120] = ???;  stack[1152921509594835128] = ???;  //  dest_result_addr=1152921509594835120 |  dest_result_addr=1152921509594835128
            // 0x00E5907C: STP x29, x30, [sp, #0x20]  | stack[1152921509594835136] = ???;  stack[1152921509594835144] = ???;  //  dest_result_addr=1152921509594835136 |  dest_result_addr=1152921509594835144
            // 0x00E59080: ADD x29, sp, #0x20         | X29 = (1152921509594835104 + 32) = 1152921509594835136 (0x10000001294EA8C0);
            // 0x00E59084: SUB sp, sp, #0x10          | SP = (1152921509594835104 - 16) = 1152921509594835088 (0x10000001294EA890);
            // 0x00E59088: MOV x21, x1                | X21 = identifier._a;//m1                
            // 0x00E5908C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59090: MOV x19, x3                | X19 = data;//m1                         
            // 0x00E59094: MOV x20, x2                | X20 = identifier._d;//m1                
            // 0x00E59098: MOV x22, x0                | X22 = 1152921509594847152 (0x10000001294ED7B0);//ML01
            // 0x00E5909C: BL #0x16f59f0              | this..ctor();                           
            val_1 = new System.Object();
            // 0x00E590A0: ADD x0, sp, #8             | X0 = (1152921509594835088 + 8) = 1152921509594835096 (0x10000001294EA898);
            // 0x00E590A4: MOVZ w1, #0x3700, lsl #16  | W1 = 922746880 (0x37000000);//ML01      
            // 0x00E590A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E590AC: STP x21, x20, [x22, #0x20] | mem[1152921509594847184] = identifier._a; mem[1152921509594847188] = identifier._b; mem[1152921509594847190] = identifier._c;  mem[1152921509594847192] = identifier._d; mem[1152921509594847193] = identifier._e; mem[1152921509594847194] = identifier._f; mem[1152921509594847195] = identifier._g; mem[1152921509594847196] = identifier._h; mem[1152921509594847197] = identifier._i; mem[1152921509594847198] = identifier._j; mem[1152921509594847199] = identifier._k;  //  dest_result_addr=1152921509594847184 dest_result_addr=1152921509594847188 dest_result_addr=1152921509594847190 |  dest_result_addr=1152921509594847192 dest_result_addr=1152921509594847193 dest_result_addr=1152921509594847194 dest_result_addr=1152921509594847195 dest_result_addr=1152921509594847196 dest_result_addr=1152921509594847197 dest_result_addr=1152921509594847198 dest_result_addr=1152921509594847199
            mem[1152921509594847184] = identifier._a;
            mem[1152921509594847188] = identifier._b;
            mem[1152921509594847190] = identifier._c;
            mem[1152921509594847192] = identifier._d;
            mem[1152921509594847193] = identifier._e;
            mem[1152921509594847194] = identifier._f;
            mem[1152921509594847195] = identifier._g;
            mem[1152921509594847196] = identifier._h;
            mem[1152921509594847197] = identifier._i;
            mem[1152921509594847198] = identifier._j;
            mem[1152921509594847199] = identifier._k;
            // 0x00E590B0: STR wzr, [sp, #8]          | stack[1152921509594835096] = 0x0;        //  dest_result_addr=1152921509594835096
            // 0x00E590B4: BL #0x11d58e4              | null..ctor(value:  0);                  
            ProtoBuf.SubItemToken val_2 = new ProtoBuf.SubItemToken(value:  0);
            // 0x00E590B8: LDR w8, [sp, #8]           | W8 = val_2.value;                       
            // 0x00E590BC: STR x19, [x22, #0x30]      | this.data = data;                        //  dest_result_addr=1152921509594847200
            this.data = data;
            // 0x00E590C0: STR w8, [x22, #0x10]       | mem[1152921509594847168] = val_2.value;  //  dest_result_addr=1152921509594847168
            mem[1152921509594847168] = val_2.value;
            // 0x00E590C4: SUB sp, x29, #0x20         | SP = (1152921509594835136 - 32) = 1152921509594835104 (0x10000001294EA8A0);
            // 0x00E590C8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E590CC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E590D0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E590D4: RET                        |  return;                                
            return;
        
        }
    
    }

}
