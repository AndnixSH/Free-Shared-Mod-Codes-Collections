using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286BB54
[Serializable]
public class CameraAniGroup : IExtensible
{
    // Fields
    private int _startID; //  0x00000010
    private int _eventType; //  0x00000014
    private int _round; //  0x00000018
    private int _id; //  0x0000001C
    private ProtoBuf.IExtension extensionObject; //  0x00000020
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286BB98
    [System.ComponentModel.DefaultValueAttribute] // 0x286BB98
    public int startID { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286BC18
    [System.ComponentModel.DefaultValueAttribute] // 0x286BC18
    public int eventType { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286BC98
    [System.ComponentModel.DefaultValueAttribute] // 0x286BC98
    public int round { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286BD18
    [System.ComponentModel.DefaultValueAttribute] // 0x286BD18
    public int id { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA7094 (12218516), len: 8  VirtAddr: 0x00BA7094 RVA: 0x00BA7094 token: 100690305 methodIndex: 25639 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraAniGroup()
    {
        //
        // Disasemble & Code
        // 0x00BA7094: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7098: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA709C (12218524), len: 8  VirtAddr: 0x00BA709C RVA: 0x00BA709C token: 100690306 methodIndex: 25640 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_startID()
    {
        //
        // Disasemble & Code
        // 0x00BA709C: LDR w0, [x0, #0x10]        | W0 = this._startID; //P2                
        // 0x00BA70A0: RET                        |  return (System.Int32)this._startID;    
        return this._startID;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA70A4 (12218532), len: 8  VirtAddr: 0x00BA70A4 RVA: 0x00BA70A4 token: 100690307 methodIndex: 25641 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_startID(int value)
    {
        //
        // Disasemble & Code
        // 0x00BA70A4: STR w1, [x0, #0x10]        | this._startID = value;                   //  dest_result_addr=1152921514506309232
        this._startID = value;
        // 0x00BA70A8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA70AC (12218540), len: 8  VirtAddr: 0x00BA70AC RVA: 0x00BA70AC token: 100690308 methodIndex: 25642 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_eventType()
    {
        //
        // Disasemble & Code
        // 0x00BA70AC: LDR w0, [x0, #0x14]        | W0 = this._eventType; //P2              
        // 0x00BA70B0: RET                        |  return (System.Int32)this._eventType;  
        return this._eventType;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA70B4 (12218548), len: 8  VirtAddr: 0x00BA70B4 RVA: 0x00BA70B4 token: 100690309 methodIndex: 25643 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_eventType(int value)
    {
        //
        // Disasemble & Code
        // 0x00BA70B4: STR w1, [x0, #0x14]        | this._eventType = value;                 //  dest_result_addr=1152921514506533236
        this._eventType = value;
        // 0x00BA70B8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA70BC (12218556), len: 8  VirtAddr: 0x00BA70BC RVA: 0x00BA70BC token: 100690310 methodIndex: 25644 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_round()
    {
        //
        // Disasemble & Code
        // 0x00BA70BC: LDR w0, [x0, #0x18]        | W0 = this._round; //P2                  
        // 0x00BA70C0: RET                        |  return (System.Int32)this._round;      
        return this._round;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA70C4 (12218564), len: 8  VirtAddr: 0x00BA70C4 RVA: 0x00BA70C4 token: 100690311 methodIndex: 25645 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_round(int value)
    {
        //
        // Disasemble & Code
        // 0x00BA70C4: STR w1, [x0, #0x18]        | this._round = value;                     //  dest_result_addr=1152921514506757240
        this._round = value;
        // 0x00BA70C8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA70CC (12218572), len: 8  VirtAddr: 0x00BA70CC RVA: 0x00BA70CC token: 100690312 methodIndex: 25646 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00BA70CC: LDR w0, [x0, #0x1c]        | W0 = this._id; //P2                     
        // 0x00BA70D0: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA70D4 (12218580), len: 8  VirtAddr: 0x00BA70D4 RVA: 0x00BA70D4 token: 100690313 methodIndex: 25647 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00BA70D4: STR w1, [x0, #0x1c]        | this._id = value;                        //  dest_result_addr=1152921514506981244
        this._id = value;
        // 0x00BA70D8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA70DC (12218588), len: 24  VirtAddr: 0x00BA70DC RVA: 0x00BA70DC token: 100690314 methodIndex: 25648 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00BA70DC: ADD x8, x0, #0x20          | X8 = this.extensionObject;//AP2 res_addr=1152921514507093248
        // 0x00BA70E0: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00BA70E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00BA70E8: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00BA70EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA70F0: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
