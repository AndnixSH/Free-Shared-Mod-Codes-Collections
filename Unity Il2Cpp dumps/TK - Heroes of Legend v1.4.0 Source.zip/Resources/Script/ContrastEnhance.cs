using UnityEngine;
[UnityEngine.AddComponentMenu] // 0x281A818
[UnityEngine.ExecuteInEditMode] // 0x281A818
[UnityEngine.RequireComponent] // 0x281A818
[Serializable]
public class ContrastEnhance : PostEffectsBase
{
    // Fields
    public float intensity; //  0x0000001C
    public float threshhold; //  0x00000020
    private UnityEngine.Material separableBlurMaterial; //  0x00000028
    private UnityEngine.Material contrastCompositeMaterial; //  0x00000030
    public float blurSpread; //  0x00000038
    public UnityEngine.Shader separableBlurShader; //  0x00000040
    public UnityEngine.Shader contrastCompositeShader; //  0x00000048
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x026798B4 (40343732), len: 64  VirtAddr: 0x026798B4 RVA: 0x026798B4 token: 100663359 methodIndex: 24443 delegateWrapperIndex: 0 methodInvoker: 0
    public ContrastEnhance()
    {
        //
        // Disasemble & Code
        // 0x026798B4: STP x20, x19, [sp, #-0x20]! | stack[1152921509953823184] = ???;  stack[1152921509953823192] = ???;  //  dest_result_addr=1152921509953823184 |  dest_result_addr=1152921509953823192
        // 0x026798B8: STP x29, x30, [sp, #0x10]  | stack[1152921509953823200] = ???;  stack[1152921509953823208] = ???;  //  dest_result_addr=1152921509953823200 |  dest_result_addr=1152921509953823208
        // 0x026798BC: ADD x29, sp, #0x10         | X29 = (1152921509953823184 + 16) = 1152921509953823200 (0x100000013EB461E0);
        // 0x026798C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026798C4: MOV x19, x0                | X19 = 1152921509953835216 (0x100000013EB490D0);//ML01
        // 0x026798C8: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x026798CC: ORR w10, wzr, #0x3f800000  | W10 = 1065353216(0x3F800000);           
        // 0x026798D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026798D4: ORR w9, wzr, #0x3f000000   | W9 = 1056964608(0x3F000000);            
        // 0x026798D8: STR w10, [x19, #0x38]      | this.blurSpread = 1;                     //  dest_result_addr=1152921509953835272
        this.blurSpread = 1f;
        // 0x026798DC: STRB w8, [x19, #0x18]      | mem[1152921509953835240] = 0x1;          //  dest_result_addr=1152921509953835240
        mem[1152921509953835240] = 1;
        // 0x026798E0: STRB w8, [x19, #0x1a]      | mem[1152921509953835242] = 0x1;          //  dest_result_addr=1152921509953835242
        mem[1152921509953835242] = 1;
        // 0x026798E4: STR w9, [x19, #0x1c]       | this.intensity = 0.5;                    //  dest_result_addr=1152921509953835244
        this.intensity = 0.5f;
        // 0x026798E8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x026798EC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x026798F0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026798F4 (40343796), len: 136  VirtAddr: 0x026798F4 RVA: 0x026798F4 token: 100663360 methodIndex: 24444 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x026798F4: STP x20, x19, [sp, #-0x20]! | stack[1152921509953951568] = ???;  stack[1152921509953951576] = ???;  //  dest_result_addr=1152921509953951568 |  dest_result_addr=1152921509953951576
        // 0x026798F8: STP x29, x30, [sp, #0x10]  | stack[1152921509953951584] = ???;  stack[1152921509953951592] = ???;  //  dest_result_addr=1152921509953951584 |  dest_result_addr=1152921509953951592
        // 0x026798FC: ADD x29, sp, #0x10         | X29 = (1152921509953951568 + 16) = 1152921509953951584 (0x100000013EB65760);
        // 0x02679900: MOV x19, x0                | X19 = 1152921509953963600 (0x100000013EB68650);//ML01
        // 0x02679904: LDR x8, [x19]              | X8 = typeof(ContrastEnhance);           
        // 0x02679908: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x0267990C: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(ContrastEnhance).__il2cppRuntimeField_1B0; X2 = typeof(ContrastEnhance).__il2cppRuntimeField_1B8; //  | 
        // 0x02679910: BLR x9                     | X0 = typeof(ContrastEnhance).__il2cppRuntimeField_1B0();
        // 0x02679914: LDR x8, [x19]              | X8 = typeof(ContrastEnhance);           
        // 0x02679918: LDR x1, [x19, #0x48]       | X1 = this.contrastCompositeShader; //P2 
        // 0x0267991C: LDR x2, [x19, #0x30]       | X2 = this.contrastCompositeMaterial; //P2 
        // 0x02679920: MOV x0, x19                | X0 = 1152921509953963600 (0x100000013EB68650);//ML01
        // 0x02679924: LDP x9, x3, [x8, #0x150]   | X9 = typeof(ContrastEnhance).__il2cppRuntimeField_150; X3 = typeof(ContrastEnhance).__il2cppRuntimeField_158; //  | 
        // 0x02679928: BLR x9                     | X0 = typeof(ContrastEnhance).__il2cppRuntimeField_150();
        // 0x0267992C: LDR x8, [x19]              | X8 = typeof(ContrastEnhance);           
        // 0x02679930: STR x0, [x19, #0x30]       | this.contrastCompositeMaterial = this;   //  dest_result_addr=1152921509953963648
        this.contrastCompositeMaterial = this;
        // 0x02679934: LDR x1, [x19, #0x40]       | X1 = this.separableBlurShader; //P2     
        // 0x02679938: LDR x2, [x19, #0x28]       | X2 = this.separableBlurMaterial; //P2   
        // 0x0267993C: LDP x9, x3, [x8, #0x150]   | X9 = typeof(ContrastEnhance).__il2cppRuntimeField_150; X3 = typeof(ContrastEnhance).__il2cppRuntimeField_158; //  | 
        // 0x02679940: MOV x0, x19                | X0 = 1152921509953963600 (0x100000013EB68650);//ML01
        // 0x02679944: BLR x9                     | X0 = typeof(ContrastEnhance).__il2cppRuntimeField_150();
        // 0x02679948: LDRB w8, [x19, #0x1a]      | 
        // 0x0267994C: STR x0, [x19, #0x28]       | this.separableBlurMaterial = this;       //  dest_result_addr=1152921509953963640
        this.separableBlurMaterial = this;
        // 0x02679950: CBNZ w8, #0x2679968        | if (typeof(ContrastEnhance) != null) goto label_0;
        if(null != null)
        {
            goto label_0;
        }
        // 0x02679954: LDR x8, [x19]              | X8 = typeof(ContrastEnhance);           
        // 0x02679958: MOV x0, x19                | X0 = 1152921509953963600 (0x100000013EB68650);//ML01
        // 0x0267995C: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(ContrastEnhance).__il2cppRuntimeField_1E0; X1 = typeof(ContrastEnhance).__il2cppRuntimeField_1E8; //  | 
        // 0x02679960: BLR x9                     | X0 = typeof(ContrastEnhance).__il2cppRuntimeField_1E0();
        // 0x02679964: LDRB w8, [x19, #0x1a]      | 
        label_0:
        // 0x02679968: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0267996C: CMP w8, #0                 | STATE = COMPARE(typeof(ContrastEnhance), 0x0)
        // 0x02679970: CSET w0, ne                | W0 = typeof(ContrastEnhance) != null ? 1 : 0;
        var val_1 = (null != 0) ? 1 : 0;
        // 0x02679974: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02679978: RET                        |  return (System.Boolean)typeof(ContrastEnhance) != null ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x0267997C (40343932), len: 984  VirtAddr: 0x0267997C RVA: 0x0267997C token: 100663361 methodIndex: 24445 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        // 0x0267997C: STP d9, d8, [sp, #-0x70]!  | stack[1152921509954137424] = ???;  stack[1152921509954137432] = ???;  //  dest_result_addr=1152921509954137424 |  dest_result_addr=1152921509954137432
        // 0x02679980: STP x28, x27, [sp, #0x10]  | stack[1152921509954137440] = ???;  stack[1152921509954137448] = ???;  //  dest_result_addr=1152921509954137440 |  dest_result_addr=1152921509954137448
        // 0x02679984: STP x26, x25, [sp, #0x20]  | stack[1152921509954137456] = ???;  stack[1152921509954137464] = ???;  //  dest_result_addr=1152921509954137456 |  dest_result_addr=1152921509954137464
        // 0x02679988: STP x24, x23, [sp, #0x30]  | stack[1152921509954137472] = ???;  stack[1152921509954137480] = ???;  //  dest_result_addr=1152921509954137472 |  dest_result_addr=1152921509954137480
        // 0x0267998C: STP x22, x21, [sp, #0x40]  | stack[1152921509954137488] = ???;  stack[1152921509954137496] = ???;  //  dest_result_addr=1152921509954137488 |  dest_result_addr=1152921509954137496
        // 0x02679990: STP x20, x19, [sp, #0x50]  | stack[1152921509954137504] = ???;  stack[1152921509954137512] = ???;  //  dest_result_addr=1152921509954137504 |  dest_result_addr=1152921509954137512
        // 0x02679994: STP x29, x30, [sp, #0x60]  | stack[1152921509954137520] = ???;  stack[1152921509954137528] = ???;  //  dest_result_addr=1152921509954137520 |  dest_result_addr=1152921509954137528
        // 0x02679998: ADD x29, sp, #0x60         | X29 = (1152921509954137424 + 96) = 1152921509954137520 (0x100000013EB92DB0);
        // 0x0267999C: SUB sp, sp, #0x20          | SP = (1152921509954137424 - 32) = 1152921509954137392 (0x100000013EB92D30);
        // 0x026799A0: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x026799A4: LDRB w8, [x22, #0xe65]     | W8 = (bool)static_value_03740E65;       
        // 0x026799A8: MOV x19, x2                | X19 = destination;//m1                  
        // 0x026799AC: MOV x20, x1                | X20 = source;//m1                       
        // 0x026799B0: MOV x21, x0                | X21 = 1152921509954149536 (0x100000013EB95CA0);//ML01
        // 0x026799B4: TBNZ w8, #0, #0x26799d0    | if (static_value_03740E65 == true) goto label_0;
        // 0x026799B8: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
        // 0x026799BC: LDR x8, [x8, #0xbd0]       | X8 = 0x2B929B4;                         
        // 0x026799C0: LDR w0, [x8]               | W0 = 0x2132;                            
        // 0x026799C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2132, ????);     
        // 0x026799C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026799CC: STRB w8, [x22, #0xe65]     | static_value_03740E65 = true;            //  dest_result_addr=57937509
        label_0:
        // 0x026799D0: LDR x8, [x21]              | X8 = typeof(ContrastEnhance);           
        // 0x026799D4: MOV x0, x21                | X0 = 1152921509954149536 (0x100000013EB95CA0);//ML01
        // 0x026799D8: LDP x9, x1, [x8, #0x190]   | X9 = typeof(ContrastEnhance).__il2cppRuntimeField_190; X1 = typeof(ContrastEnhance).__il2cppRuntimeField_198; //  | 
        // 0x026799DC: BLR x9                     | X0 = typeof(ContrastEnhance).__il2cppRuntimeField_190();
        // 0x026799E0: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
        // 0x026799E4: TBZ w8, #0, #0x2679d00     | if (((ContrastEnhance)[1152921509954149536] & 0x1) == 0) goto label_1;
        if((0 & 1) == 0)
        {
            goto label_1;
        }
        // 0x026799E8: CBNZ x20, #0x26799f0       | if (source != null) goto label_2;       
        if(source != null)
        {
            goto label_2;
        }
        // 0x026799EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x026799F0: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026799F4: MOV x0, x20                | X0 = source;//m1                        
        // 0x026799F8: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x026799FC: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02679A00: MOV w22, w0                | W22 = source;//m1                       
        int val_14 = source;
        // 0x02679A04: CBNZ x20, #0x2679a0c       | if (source != null) goto label_3;       
        if(source != null)
        {
            goto label_3;
        }
        // 0x02679A08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_3:
        // 0x02679A0C: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02679A10: MOV x0, x20                | X0 = source;//m1                        
        // 0x02679A14: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02679A18: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02679A1C: MOV w23, w0                | W23 = source;//m1                       
        int val_15 = source;
        // 0x02679A20: CMP w22, #0                | STATE = COMPARE(source, 0x0)            
        // 0x02679A24: CINC w8, w22, lt           | W8 = source < null ? (source + 1) : source;
        var val_1 = (val_14 < 0) ? (val_14 + 1) : (val_14);
        // 0x02679A28: CMP w23, #0                | STATE = COMPARE(source, 0x0)            
        // 0x02679A2C: CINC w9, w23, lt           | W9 = source < null ? (source + 1) : source;
        var val_2 = (val_15 < 0) ? (val_15 + 1) : (val_15);
        // 0x02679A30: ASR w1, w8, #1             | W1 = (source < null ? (source + 1) : source >> 1);
        int val_3 = val_1 >> 1;
        // 0x02679A34: ASR w2, w9, #1             | W2 = (source < null ? (source + 1) : source >> 1);
        int val_4 = val_2 >> 1;
        // 0x02679A38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679A3C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02679A40: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679A44: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  int val_3 = val_1 >> 1, depthBuffer:  int val_4 = val_2 >> 1);
        UnityEngine.RenderTexture val_5 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_3, depthBuffer:  val_4);
        // 0x02679A48: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02679A4C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02679A50: MOV x25, x0                | X25 = val_5;//m1                        
        // 0x02679A54: LDR x8, [x8]               | X8 = typeof(UnityEngine.Graphics);      
        // 0x02679A58: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02679A5C: TBZ w9, #0, #0x2679a70     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x02679A60: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02679A64: CBNZ w9, #0x2679a70        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x02679A68: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02679A6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_5:
        // 0x02679A70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679A74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02679A78: MOV x1, x20                | X1 = source;//m1                        
        // 0x02679A7C: MOV x2, x25                | X2 = val_5;//m1                         
        // 0x02679A80: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  source);
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        // 0x02679A84: ADD w8, w22, #3            | W8 = (source + 3);                      
        UnityEngine.RenderTexture val_6 = val_14 + 3;
        // 0x02679A88: CMP w22, #0                | STATE = COMPARE(source, 0x0)            
        // 0x02679A8C: ADD w9, w23, #3            | W9 = (source + 3);                      
        UnityEngine.RenderTexture val_7 = val_15 + 3;
        // 0x02679A90: CSEL w8, w8, w22, lt       | W8 = source < null ? (source + 3) : source;
        var val_8 = (val_14 < 0) ? (val_6) : (val_14);
        // 0x02679A94: CMP w23, #0                | STATE = COMPARE(source, 0x0)            
        // 0x02679A98: ASR w22, w8, #2            | W22 = (source < null ? (source + 3) : source >> 2);
        val_14 = val_8 >> 2;
        // 0x02679A9C: CSEL w8, w9, w23, lt       | W8 = source < null ? (source + 3) : source;
        var val_9 = (val_15 < 0) ? (val_7) : (val_15);
        // 0x02679AA0: ASR w23, w8, #2            | W23 = (source < null ? (source + 3) : source >> 2);
        val_15 = val_9 >> 2;
        // 0x02679AA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679AA8: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02679AAC: MOV w1, w22                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02679AB0: MOV w2, w23                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02679AB4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679AB8: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source, depthBuffer:  source);
        UnityEngine.RenderTexture val_10 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_14, depthBuffer:  val_15);
        // 0x02679ABC: MOV x24, x0                | X24 = val_10;//m1                       
        // 0x02679AC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679AC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02679AC8: MOV x1, x25                | X1 = val_5;//m1                         
        // 0x02679ACC: MOV x2, x24                | X2 = val_10;//m1                        
        // 0x02679AD0: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  val_5);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_5);
        // 0x02679AD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679AD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679ADC: MOV x1, x25                | X1 = val_5;//m1                         
        // 0x02679AE0: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02679AE4: LDR x25, [x21, #0x28]      | X25 = this.separableBlurMaterial; //P2  
        // 0x02679AE8: LDR s8, [x21, #0x38]       | S8 = this.blurSpread; //P2              
        // 0x02679AEC: CBNZ x24, #0x2679af4       | if (val_10 != null) goto label_6;       
        if(val_10 != null)
        {
            goto label_6;
        }
        // 0x02679AF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x02679AF4: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02679AF8: MOV x0, x24                | X0 = val_10;//m1                        
        // 0x02679AFC: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02679B00: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02679B04: SCVTF s0, w0               | S0 = (float)(val_10);                   
        // 0x02679B08: FDIV s1, s8, s0            | S1 = (this.blurSpread / val_10);        
        float val_11 = this.blurSpread / (float)val_10;
        // 0x02679B0C: FMOV s0, wzr               | S0 = 0f;                                
        // 0x02679B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02679B14: ADD x0, sp, #0x10          | X0 = (1152921509954137392 + 16) = 1152921509954137408 (0x100000013EB92D40);
        // 0x02679B18: MOV v2.16b, v0.16b         | V2 = 0;//m1                             
        // 0x02679B1C: MOV v3.16b, v0.16b         | V3 = 0;//m1                             
        // 0x02679B20: STP xzr, xzr, [sp, #0x10]  | stack[1152921509954137408] = 0x0;  stack[1152921509954137416] = 0x0;  //  dest_result_addr=1152921509954137408 |  dest_result_addr=1152921509954137416
        // 0x02679B24: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02679B28: CBNZ x25, #0x2679b30       | if (this.separableBlurMaterial != null) goto label_7;
        if(this.separableBlurMaterial != null)
        {
            goto label_7;
        }
        // 0x02679B2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013EB92D40, ????);
        label_7:
        // 0x02679B30: ADRP x27, #0x364a000       | X27 = 56926208 (0x364A000);             
        // 0x02679B34: LDR x27, [x27, #0x178]     | X27 = (string**)(1152921509946714736)("offsets");
        // 0x02679B38: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02679B3C: LDP s2, s3, [sp, #0x18]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02679B40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679B44: LDR x1, [x27]              | X1 = "offsets";                         
        // 0x02679B48: MOV x0, x25                | X0 = this.separableBlurMaterial;//m1    
        // 0x02679B4C: BL #0x1a79fa8              | this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02679B50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679B54: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02679B58: MOV w1, w22                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02679B5C: MOV w2, w23                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02679B60: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679B64: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source, depthBuffer:  source);
        UnityEngine.RenderTexture val_12 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_14, depthBuffer:  val_15);
        // 0x02679B68: LDR x3, [x21, #0x28]       | X3 = this.separableBlurMaterial; //P2   
        // 0x02679B6C: MOV x25, x0                | X25 = val_12;//m1                       
        // 0x02679B70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679B74: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679B78: MOV x1, x24                | X1 = val_10;//m1                        
        // 0x02679B7C: MOV x2, x25                | X2 = val_12;//m1                        
        // 0x02679B80: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_10, mat:  val_12);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_10, mat:  val_12);
        // 0x02679B84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679B88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679B8C: MOV x1, x24                | X1 = val_10;//m1                        
        // 0x02679B90: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02679B94: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02679B98: LDR x26, [x21, #0x28]      | X26 = this.separableBlurMaterial; //P2  
        // 0x02679B9C: LDR s8, [x21, #0x38]       | S8 = this.blurSpread; //P2              
        // 0x02679BA0: MOV x0, x24                | X0 = val_10;//m1                        
        // 0x02679BA4: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02679BA8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02679BAC: SCVTF s0, w0               | S0 = (float)(val_10);                   
        float val_16 = (float)val_10;
        // 0x02679BB0: FMOV s1, wzr               | S1 = 0f;                                
        // 0x02679BB4: FDIV s0, s8, s0            | S0 = (this.blurSpread / val_10);        
        val_16 = this.blurSpread / val_16;
        // 0x02679BB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02679BBC: MOV x0, sp                 | X0 = 1152921509954137392 (0x100000013EB92D30);//ML01
        // 0x02679BC0: MOV v2.16b, v1.16b         | V2 = 0;//m1                             
        // 0x02679BC4: MOV v3.16b, v1.16b         | V3 = 0;//m1                             
        // 0x02679BC8: STP xzr, xzr, [sp]         | stack[1152921509954137392] = 0x0;  stack[1152921509954137400] = 0x0;  //  dest_result_addr=1152921509954137392 |  dest_result_addr=1152921509954137400
        // 0x02679BCC: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02679BD0: CBNZ x26, #0x2679bd8       | if (this.separableBlurMaterial != null) goto label_8;
        if(this.separableBlurMaterial != null)
        {
            goto label_8;
        }
        // 0x02679BD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013EB92D30, ????);
        label_8:
        // 0x02679BD8: LDR x1, [x27]              | X1 = "offsets";                         
        // 0x02679BDC: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x02679BE0: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
        // 0x02679BE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679BE8: MOV x0, x26                | X0 = this.separableBlurMaterial;//m1    
        // 0x02679BEC: BL #0x1a79fa8              | this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02679BF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679BF4: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02679BF8: MOV w1, w22                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02679BFC: MOV w2, w23                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x02679C00: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679C04: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source, depthBuffer:  source);
        UnityEngine.RenderTexture val_13 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_14, depthBuffer:  val_15);
        // 0x02679C08: LDR x3, [x21, #0x28]       | X3 = this.separableBlurMaterial; //P2   
        // 0x02679C0C: MOV x22, x0                | X22 = val_13;//m1                       
        // 0x02679C10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679C14: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679C18: MOV x1, x25                | X1 = val_12;//m1                        
        // 0x02679C1C: MOV x2, x22                | X2 = val_13;//m1                        
        // 0x02679C20: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_12, mat:  val_13);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_12, mat:  val_13);
        // 0x02679C24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679C28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679C2C: MOV x1, x25                | X1 = val_12;//m1                        
        // 0x02679C30: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02679C34: LDR x23, [x21, #0x30]      | X23 = this.contrastCompositeMaterial; //P2 
        // 0x02679C38: CBNZ x23, #0x2679c40       | if (this.contrastCompositeMaterial != null) goto label_9;
        if(this.contrastCompositeMaterial != null)
        {
            goto label_9;
        }
        // 0x02679C3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_9:
        // 0x02679C40: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x02679C44: LDR x8, [x8, #0x488]       | X8 = (string**)(1152921509954113040)("_MainTexBlurred");
        // 0x02679C48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02679C4C: MOV x0, x23                | X0 = this.contrastCompositeMaterial;//m1
        // 0x02679C50: MOV x2, x22                | X2 = val_13;//m1                        
        // 0x02679C54: LDR x1, [x8]               | X1 = "_MainTexBlurred";                 
        // 0x02679C58: BL #0x1a780c4              | this.contrastCompositeMaterial.SetTexture(name:  "_MainTexBlurred", value:  val_13);
        this.contrastCompositeMaterial.SetTexture(name:  "_MainTexBlurred", value:  val_13);
        // 0x02679C5C: LDR x23, [x21, #0x30]      | X23 = this.contrastCompositeMaterial; //P2 
        // 0x02679C60: LDR s8, [x21, #0x1c]       | S8 = this.intensity; //P2               
        // 0x02679C64: CBNZ x23, #0x2679c6c       | if (this.contrastCompositeMaterial != null) goto label_10;
        if(this.contrastCompositeMaterial != null)
        {
            goto label_10;
        }
        // 0x02679C68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.contrastCompositeMaterial, ????);
        label_10:
        // 0x02679C6C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x02679C70: LDR x8, [x8, #0xe80]       | X8 = (string**)(1152921509954117248)("intensity");
        // 0x02679C74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679C78: MOV x0, x23                | X0 = this.contrastCompositeMaterial;//m1
        // 0x02679C7C: MOV v0.16b, v8.16b         | V0 = this.intensity;//m1                
        // 0x02679C80: LDR x1, [x8]               | X1 = "intensity";                       
        // 0x02679C84: BL #0x1a79ef8              | this.contrastCompositeMaterial.SetFloat(name:  "intensity", value:  this.intensity);
        this.contrastCompositeMaterial.SetFloat(name:  "intensity", value:  this.intensity);
        // 0x02679C88: LDR x23, [x21, #0x30]      | X23 = this.contrastCompositeMaterial; //P2 
        // 0x02679C8C: LDR s8, [x21, #0x20]       | S8 = this.threshhold; //P2              
        // 0x02679C90: CBNZ x23, #0x2679c98       | if (this.contrastCompositeMaterial != null) goto label_11;
        if(this.contrastCompositeMaterial != null)
        {
            goto label_11;
        }
        // 0x02679C94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.contrastCompositeMaterial, ????);
        label_11:
        // 0x02679C98: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
        // 0x02679C9C: LDR x8, [x8, #0x248]       | X8 = (string**)(1152921509947431952)("threshhold");
        // 0x02679CA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679CA4: MOV x0, x23                | X0 = this.contrastCompositeMaterial;//m1
        // 0x02679CA8: MOV v0.16b, v8.16b         | V0 = this.threshhold;//m1               
        // 0x02679CAC: LDR x1, [x8]               | X1 = "threshhold";                      
        // 0x02679CB0: BL #0x1a79ef8              | this.contrastCompositeMaterial.SetFloat(name:  "threshhold", value:  this.threshhold);
        this.contrastCompositeMaterial.SetFloat(name:  "threshhold", value:  this.threshhold);
        // 0x02679CB4: LDR x3, [x21, #0x30]       | X3 = this.contrastCompositeMaterial; //P2 
        // 0x02679CB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679CBC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679CC0: MOV x1, x20                | X1 = source;//m1                        
        // 0x02679CC4: MOV x2, x19                | X2 = destination;//m1                   
        // 0x02679CC8: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        // 0x02679CCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679CD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679CD4: MOV x1, x22                | X1 = val_13;//m1                        
        // 0x02679CD8: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02679CDC: SUB sp, x29, #0x60         | SP = (1152921509954137520 - 96) = 1152921509954137424 (0x100000013EB92D50);
        // 0x02679CE0: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x02679CE4: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x02679CE8: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x02679CEC: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x02679CF0: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x02679CF4: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x02679CF8: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x02679CFC: RET                        |  return;                                
        return;
        label_1:
        // 0x02679D00: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02679D04: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02679D08: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02679D0C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02679D10: TBZ w8, #0, #0x2679d20     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x02679D14: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02679D18: CBNZ w8, #0x2679d20        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x02679D1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_13:
        // 0x02679D20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679D24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02679D28: MOV x1, x20                | X1 = source;//m1                        
        // 0x02679D2C: MOV x2, x19                | X2 = destination;//m1                   
        // 0x02679D30: SUB sp, x29, #0x60         | SP = (1152921509954137520 - 96) = 1152921509954137424 (0x100000013EB92D50);
        // 0x02679D34: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x02679D38: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x02679D3C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x02679D40: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x02679D44: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x02679D48: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x02679D4C: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x02679D50: B #0x1a6ba68               | UnityEngine.Graphics.Blit(source:  0, dest:  source); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02679D54 (40344916), len: 4  VirtAddr: 0x02679D54 RVA: 0x02679D54 token: 100663362 methodIndex: 24446 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x02679D54: RET                        |  return;                                
        return;
    
    }

}
