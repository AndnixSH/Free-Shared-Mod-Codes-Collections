using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286D954
[Serializable]
public class CameraShotSkillCfg : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private int _heroOrNpcId; //  0x00000014
    private int _isHero; //  0x00000018
    private int _skillId; //  0x0000001C
    private ProtoBuf.IExtension extensionObject; //  0x00000020
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286D998
    [System.ComponentModel.DefaultValueAttribute] // 0x286D998
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286DA18
    [System.ComponentModel.DefaultValueAttribute] // 0x286DA18
    public int heroOrNpcId { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286DA98
    [System.ComponentModel.DefaultValueAttribute] // 0x286DA98
    public int isHero { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286DB18
    [System.ComponentModel.DefaultValueAttribute] // 0x286DB18
    public int skillId { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D7F210 (14152208), len: 8  VirtAddr: 0x00D7F210 RVA: 0x00D7F210 token: 100690434 methodIndex: 25901 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotSkillCfg()
    {
        //
        // Disasemble & Code
        // 0x00D7F210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F214: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F218 (14152216), len: 8  VirtAddr: 0x00D7F218 RVA: 0x00D7F218 token: 100690435 methodIndex: 25902 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00D7F218: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00D7F21C: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F220 (14152224), len: 8  VirtAddr: 0x00D7F220 RVA: 0x00D7F220 token: 100690436 methodIndex: 25903 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F220: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514520973744
        this._id = value;
        // 0x00D7F224: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F228 (14152232), len: 8  VirtAddr: 0x00D7F228 RVA: 0x00D7F228 token: 100690437 methodIndex: 25904 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_heroOrNpcId()
    {
        //
        // Disasemble & Code
        // 0x00D7F228: LDR w0, [x0, #0x14]        | W0 = this._heroOrNpcId; //P2            
        // 0x00D7F22C: RET                        |  return (System.Int32)this._heroOrNpcId;
        return this._heroOrNpcId;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F230 (14152240), len: 8  VirtAddr: 0x00D7F230 RVA: 0x00D7F230 token: 100690438 methodIndex: 25905 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_heroOrNpcId(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F230: STR w1, [x0, #0x14]        | this._heroOrNpcId = value;               //  dest_result_addr=1152921514521197748
        this._heroOrNpcId = value;
        // 0x00D7F234: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F238 (14152248), len: 8  VirtAddr: 0x00D7F238 RVA: 0x00D7F238 token: 100690439 methodIndex: 25906 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isHero()
    {
        //
        // Disasemble & Code
        // 0x00D7F238: LDR w0, [x0, #0x18]        | W0 = this._isHero; //P2                 
        // 0x00D7F23C: RET                        |  return (System.Int32)this._isHero;     
        return this._isHero;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F240 (14152256), len: 8  VirtAddr: 0x00D7F240 RVA: 0x00D7F240 token: 100690440 methodIndex: 25907 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isHero(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F240: STR w1, [x0, #0x18]        | this._isHero = value;                    //  dest_result_addr=1152921514521421752
        this._isHero = value;
        // 0x00D7F244: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F248 (14152264), len: 8  VirtAddr: 0x00D7F248 RVA: 0x00D7F248 token: 100690441 methodIndex: 25908 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_skillId()
    {
        //
        // Disasemble & Code
        // 0x00D7F248: LDR w0, [x0, #0x1c]        | W0 = this._skillId; //P2                
        // 0x00D7F24C: RET                        |  return (System.Int32)this._skillId;    
        return this._skillId;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F250 (14152272), len: 8  VirtAddr: 0x00D7F250 RVA: 0x00D7F250 token: 100690442 methodIndex: 25909 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_skillId(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F250: STR w1, [x0, #0x1c]        | this._skillId = value;                   //  dest_result_addr=1152921514521645756
        this._skillId = value;
        // 0x00D7F254: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F258 (14152280), len: 24  VirtAddr: 0x00D7F258 RVA: 0x00D7F258 token: 100690443 methodIndex: 25910 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00D7F258: ADD x8, x0, #0x20          | X8 = this.extensionObject;//AP2 res_addr=1152921514521757760
        // 0x00D7F25C: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00D7F260: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00D7F264: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00D7F268: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7F26C: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
