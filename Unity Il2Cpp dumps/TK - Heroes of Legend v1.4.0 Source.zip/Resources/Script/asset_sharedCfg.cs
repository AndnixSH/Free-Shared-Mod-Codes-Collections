using UnityEngine;
public class asset_sharedCfg : CsCfgBase
{
    // Fields
    public int id; //  0x00000010
    public int type; //  0x00000014
    public string asset; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B2FF1C (11730716), len: 8  VirtAddr: 0x00B2FF1C RVA: 0x00B2FF1C token: 100690504 methodIndex: 24919 delegateWrapperIndex: 0 methodInvoker: 0
    public asset_sharedCfg()
    {
        //
        // Disasemble & Code
        // 0x00B2FF1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2FF20: B #0xb46154                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2FF24 (11730724), len: 268  VirtAddr: 0x00B2FF24 RVA: 0x00B2FF24 token: 100690505 methodIndex: 24920 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Init(System.Collections.Generic.Dictionary<string, string> _info)
    {
        //
        // Disasemble & Code
        // 0x00B2FF24: STP x22, x21, [sp, #-0x30]! | stack[1152921514528784448] = ???;  stack[1152921514528784456] = ???;  //  dest_result_addr=1152921514528784448 |  dest_result_addr=1152921514528784456
        // 0x00B2FF28: STP x20, x19, [sp, #0x10]  | stack[1152921514528784464] = ???;  stack[1152921514528784472] = ???;  //  dest_result_addr=1152921514528784464 |  dest_result_addr=1152921514528784472
        // 0x00B2FF2C: STP x29, x30, [sp, #0x20]  | stack[1152921514528784480] = ???;  stack[1152921514528784488] = ???;  //  dest_result_addr=1152921514528784480 |  dest_result_addr=1152921514528784488
        // 0x00B2FF30: ADD x29, sp, #0x20         | X29 = (1152921514528784448 + 32) = 1152921514528784480 (0x100000024F64C060);
        // 0x00B2FF34: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B2FF38: LDRB w8, [x21, #0x78b]     | W8 = (bool)static_value_0373378B;       
        // 0x00B2FF3C: MOV x20, x1                | X20 = _info;//m1                        
        // 0x00B2FF40: MOV x19, x0                | X19 = 1152921514528796496 (0x100000024F64EF50);//ML01
        // 0x00B2FF44: TBNZ w8, #0, #0xb2ff60     | if (static_value_0373378B == true) goto label_0;
        // 0x00B2FF48: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B2FF4C: LDR x8, [x8, #0x230]       | X8 = 0x2B8EA58;                         
        // 0x00B2FF50: LDR w0, [x8]               | W0 = 0x1154;                            
        // 0x00B2FF54: BL #0x2782188              | X0 = sub_2782188( ?? 0x1154, ????);     
        // 0x00B2FF58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2FF5C: STRB w8, [x21, #0x78b]     | static_value_0373378B = true;            //  dest_result_addr=57882507
        label_0:
        // 0x00B2FF60: CBNZ x20, #0xb2ff68        | if (_info != null) goto label_1;        
        if(_info != null)
        {
            goto label_1;
        }
        // 0x00B2FF64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1154, ????);     
        label_1:
        // 0x00B2FF68: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00B2FF6C: ADRP x21, #0x3667000       | X21 = 57044992 (0x3667000);             
        // 0x00B2FF70: LDR x8, [x8, #0xf28]       | X8 = (string**)(1152921510122275760)("id");
        // 0x00B2FF74: LDR x21, [x21, #0x90]      | X21 = 1152921510817398768;              
        // 0x00B2FF78: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B2FF7C: LDR x1, [x8]               | X1 = "id";                              
        // 0x00B2FF80: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B2FF84: BL #0x23fc26c              | X0 = _info.get_Item(key:  "id");        
        string val_1 = _info.Item["id"];
        // 0x00B2FF88: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00B2FF8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2FF90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2FF94: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_2 = System.Int32.Parse(s:  0);
        // 0x00B2FF98: STR w0, [x19, #0x10]       | this.id = val_2;                         //  dest_result_addr=1152921514528796512
        this.id = val_2;
        // 0x00B2FF9C: CBZ x20, #0xb2ffd0         | if (_info == null) goto label_2;        
        if(_info == null)
        {
            goto label_2;
        }
        // 0x00B2FFA0: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B2FFA4: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921510122301360)("type");
        // 0x00B2FFA8: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B2FFAC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B2FFB0: LDR x1, [x8]               | X1 = "type";                            
        // 0x00B2FFB4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "type");      
        string val_3 = _info.Item["type"];
        // 0x00B2FFB8: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00B2FFBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2FFC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2FFC4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_4 = System.Int32.Parse(s:  0);
        // 0x00B2FFC8: STR w0, [x19, #0x14]       | this.type = val_4;                       //  dest_result_addr=1152921514528796516
        this.type = val_4;
        // 0x00B2FFCC: B #0xb30004                |  goto label_3;                          
        goto label_3;
        label_2:
        // 0x00B2FFD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B2FFD4: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B2FFD8: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921510122301360)("type");
        // 0x00B2FFDC: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B2FFE0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B2FFE4: LDR x1, [x8]               | X1 = "type";                            
        // 0x00B2FFE8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "type");      
        string val_5 = _info.Item["type"];
        // 0x00B2FFEC: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x00B2FFF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2FFF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2FFF8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_6 = System.Int32.Parse(s:  0);
        // 0x00B2FFFC: STR w0, [x19, #0x14]       | this.type = val_6;                       //  dest_result_addr=1152921514528796516
        this.type = val_6;
        // 0x00B30000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_3:
        // 0x00B30004: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B30008: LDR x8, [x8, #0x8c0]       | X8 = (string**)(1152921514528768320)("asset");
        // 0x00B3000C: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B30010: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B30014: LDR x1, [x8]               | X1 = "asset";                           
        // 0x00B30018: BL #0x23fc26c              | X0 = _info.get_Item(key:  "asset");     
        string val_7 = _info.Item["asset"];
        // 0x00B3001C: STR x0, [x19, #0x18]       | this.asset = val_7;                      //  dest_result_addr=1152921514528796520
        this.asset = val_7;
        // 0x00B30020: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B30024: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B30028: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B3002C: RET                        |  return;                                
        return;
    
    }

}
