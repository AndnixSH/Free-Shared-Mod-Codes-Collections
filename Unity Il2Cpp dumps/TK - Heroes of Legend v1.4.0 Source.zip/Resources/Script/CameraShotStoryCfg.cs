using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286D3F8
[Serializable]
public class CameraShotStoryCfg : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private ProtoBuf.IExtension extensionObject; //  0x00000018
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286D43C
    [System.ComponentModel.DefaultValueAttribute] // 0x286D43C
    public int id { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D7F270 (14152304), len: 8  VirtAddr: 0x00D7F270 RVA: 0x00D7F270 token: 100690410 methodIndex: 25911 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotStoryCfg()
    {
        //
        // Disasemble & Code
        // 0x00D7F270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F274: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F278 (14152312), len: 8  VirtAddr: 0x00D7F278 RVA: 0x00D7F278 token: 100690411 methodIndex: 25912 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00D7F278: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00D7F27C: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F280 (14152320), len: 8  VirtAddr: 0x00D7F280 RVA: 0x00D7F280 token: 100690412 methodIndex: 25913 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F280: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514518269360
        this._id = value;
        // 0x00D7F284: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F288 (14152328), len: 24  VirtAddr: 0x00D7F288 RVA: 0x00D7F288 token: 100690413 methodIndex: 25914 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00D7F288: ADD x8, x0, #0x18          | X8 = this.extensionObject;//AP2 res_addr=1152921514518381368
        // 0x00D7F28C: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00D7F290: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00D7F294: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00D7F298: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7F29C: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
