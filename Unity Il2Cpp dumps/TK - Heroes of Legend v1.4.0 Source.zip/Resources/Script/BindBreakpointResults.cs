using UnityEngine;

namespace ILRuntime.Runtime.Debugger.Protocol
{
    public enum BindBreakpointResults
    {
        // Fields
        OK = 0
        ,TypeNotFound = 1
        ,CodeNotFound = 2
        
    
    }

}
