using UnityEngine;

namespace SevenZip.Compression.RangeCoder
{
    internal struct BitEncoder
    {
        // Fields
        public const int kNumBitModelTotalBits = 11;
        public const uint kBitModelTotal = 2048;
        private const int kNumMoveBits = 5;
        private const int kNumMoveReducingBits = 2;
        public const int kNumBitPriceShiftBits = 6;
        private uint Prob; //  0x00000000
        private static uint[] ProbPrices; // static_offset: 0x00000000
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD764C (11368012), len: 300  VirtAddr: 0x00AD764C RVA: 0x00AD764C token: 100681664 methodIndex: 54710 delegateWrapperIndex: 0 methodInvoker: 0
        private static BitEncoder()
        {
            //
            // Disasemble & Code
            //  | 
            System.UInt32[] val_1;
            // 0x00AD764C: STP x28, x27, [sp, #-0x60]! | stack[1152921513108344528] = ???;  stack[1152921513108344536] = ???;  //  dest_result_addr=1152921513108344528 |  dest_result_addr=1152921513108344536
            // 0x00AD7650: STP x26, x25, [sp, #0x10]  | stack[1152921513108344544] = ???;  stack[1152921513108344552] = ???;  //  dest_result_addr=1152921513108344544 |  dest_result_addr=1152921513108344552
            // 0x00AD7654: STP x24, x23, [sp, #0x20]  | stack[1152921513108344560] = ???;  stack[1152921513108344568] = ???;  //  dest_result_addr=1152921513108344560 |  dest_result_addr=1152921513108344568
            // 0x00AD7658: STP x22, x21, [sp, #0x30]  | stack[1152921513108344576] = ???;  stack[1152921513108344584] = ???;  //  dest_result_addr=1152921513108344576 |  dest_result_addr=1152921513108344584
            // 0x00AD765C: STP x20, x19, [sp, #0x40]  | stack[1152921513108344592] = ???;  stack[1152921513108344600] = ???;  //  dest_result_addr=1152921513108344592 |  dest_result_addr=1152921513108344600
            // 0x00AD7660: STP x29, x30, [sp, #0x50]  | stack[1152921513108344608] = ???;  stack[1152921513108344616] = ???;  //  dest_result_addr=1152921513108344608 |  dest_result_addr=1152921513108344616
            // 0x00AD7664: ADD x29, sp, #0x50         | X29 = (1152921513108344528 + 80) = 1152921513108344608 (0x10000001FABA8F20);
            // 0x00AD7668: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AD766C: LDRB w8, [x19, #0x505]     | W8 = (bool)static_value_03733505;       
            // 0x00AD7670: TBNZ w8, #0, #0xad768c     | if (static_value_03733505 == true) goto label_0;
            // 0x00AD7674: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AD7678: LDR x8, [x8, #0x58]        | X8 = 0x2B8F618;                         
            // 0x00AD767C: LDR w0, [x8]               | W0 = 0x1448;                            
            // 0x00AD7680: BL #0x2782188              | X0 = sub_2782188( ?? 0x1448, ????);     
            // 0x00AD7684: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD7688: STRB w8, [x19, #0x505]     | static_value_03733505 = true;            //  dest_result_addr=57881861
            label_0:
            // 0x00AD768C: ADRP x20, #0x3634000       | X20 = 56836096 (0x3634000);             
            // 0x00AD7690: LDR x20, [x20, #0x448]     | X20 = 1152921504834269184;              
            // 0x00AD7694: ADRP x9, #0x367c000        | X9 = 57131008 (0x367C000);              
            // 0x00AD7698: LDR x8, [x20]              | X8 = typeof(SevenZip.Compression.RangeCoder.BitEncoder);
            // 0x00AD769C: LDR x9, [x9, #0x1b8]       | X9 = 1152921505007033440;               
            // 0x00AD76A0: LDR x21, [x8, #0xa0]       | X21 = SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_static_fields;
            // 0x00AD76A4: LDR x19, [x9]              | X19 = typeof(System.UInt32[]);          
            // 0x00AD76A8: MOV x0, x19                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x00AD76AC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.UInt32[]), ????);
            // 0x00AD76B0: ORR w1, wzr, #0x200        | W1 = 512(0x200);                        
            // 0x00AD76B4: MOV x0, x19                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x00AD76B8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.UInt32[]), ????);
            // 0x00AD76BC: ORR w19, wzr, #8           | W19 = 8(0x8);                           
            // 0x00AD76C0: ORR w23, wzr, #1           | W23 = 1(0x1);                           
            // 0x00AD76C4: STR x0, [x21]              | SevenZip.Compression.RangeCoder.BitEncoder.ProbPrices = typeof(System.UInt32[]);  //  dest_result_addr=1152921504834273280
            SevenZip.Compression.RangeCoder.BitEncoder.ProbPrices = null;
            label_5:
            // 0x00AD76C8: MOVZ w9, #0x28             | W9 = 40 (0x28);//ML01                   
            // 0x00AD76CC: MOVZ w8, #0x9              | W8 = 9 (0x9);//ML01                     
            // 0x00AD76D0: SUB w9, w9, w19            | W9 = (40 - 8);                          
            var val_1 = 40 - 8;
            // 0x00AD76D4: SUB w8, w8, w19            | W8 = (9 - 8);                           
            var val_2 = 9 - 8;
            // 0x00AD76D8: AND w24, w9, #0x1f         | W24 = ((40 - 8) & 31);                  
            var val_3 = val_1 & 31;
            // 0x00AD76DC: LSL w9, w23, w24           | W9 = (1 << ((40 - 8) & 31));            
            val_1 = 1 << val_3;
            // 0x00AD76E0: LSL w8, w23, w8            | W8 = (1 << (9 - 8));                    
            val_2 = 1 << val_2;
            // 0x00AD76E4: CMP w8, w9                 | STATE = COMPARE((1 << (9 - 8)), (1 << ((40 - 8) & 31)))
            // 0x00AD76E8: B.LS #0xad774c             | if (val_2 <= val_1) goto label_1;       
            if(val_2 <= val_1)
            {
                goto label_1;
            }
            // 0x00AD76EC: LSL w10, w8, #6            | W10 = ((1 << (9 - 8)) << 6);            
            var val_4 = val_2 << 6;
            // 0x00AD76F0: LSL w25, w19, #6           | W25 = (8 << 6) = 0 (0x00000000);        
            // 0x00AD76F4: MOV w26, w9                | W26 = (1 << ((40 - 8) & 31));//m1       
            var val_9 = val_1;
            // 0x00AD76F8: SUB w27, w10, w9, lsl #6   | W27 = (((1 << (9 - 8)) << 6) - ((1 << ((40 - 8) & 31))) << 6);
            var val_5 = val_4 - (val_1 << 6);
            // 0x00AD76FC: MOV w28, w8                | W28 = (1 << (9 - 8));//m1               
            label_4:
            // 0x00AD7700: LDR x8, [x20]              | X8 = typeof(SevenZip.Compression.RangeCoder.BitEncoder);
            // 0x00AD7704: LDR x8, [x8, #0xa0]        | X8 = SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_static_fields;
            // 0x00AD7708: LDR x21, [x8]              | X21 = typeof(System.UInt32[]);          
            val_1 = SevenZip.Compression.RangeCoder.BitEncoder.ProbPrices;
            // 0x00AD770C: CBNZ x21, #0xad7714        | if ( != null) goto label_2;             
            if(null != null)
            {
                goto label_2;
            }
            // 0x00AD7710: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.UInt32[]), ????);
            label_2:
            // 0x00AD7714: LDR w8, [x21, #0x18]       | W8 = System.UInt32[].__il2cppRuntimeField_namespaze;
            // 0x00AD7718: LSR w9, w27, w24           | W9 = ((((1 << (9 - 8)) << 6) - ((1 << ((40 - 8) & 31))) << 6) >> ((40 - 8) & 31));
            val_1 = val_5 >> val_3;
            // 0x00AD771C: ADD w22, w9, w25           | W22 = (((((1 << (9 - 8)) << 6) - ((1 << ((40 - 8) & 31))) << 6) >> ((40 - 8) & 31)) + 0);
            var val_6 = val_1 + 0;
            // 0x00AD7720: CMP x26, x8                | STATE = COMPARE((1 << ((40 - 8) & 31)), System.UInt32[].__il2cppRuntimeField_namespaze)
            // 0x00AD7724: B.LO #0xad7734             | if (val_1 < System.UInt32[].__il2cppRuntimeField_namespaze) goto label_3;
            // 0x00AD7728: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.UInt32[]), ????);
            // 0x00AD772C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD7730: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.UInt32[]), ????);
            label_3:
            // 0x00AD7734: ADD x8, x21, x26, lsl #2   | X8 = (val_1 + ((1 << ((40 - 8) & 31))) << 2);
            System.UInt32[] val_7 = val_1 + (((1 << ((40 - 8) & 31))) << 2);
            // 0x00AD7738: ADD x26, x26, #1           | X26 = ((1 << ((40 - 8) & 31)) + 1);     
            val_9 = val_9 + 1;
            // 0x00AD773C: SUB w27, w27, #0x40        | W27 = ((((1 << (9 - 8)) << 6) - ((1 << ((40 - 8) & 31))) << 6) - 64);
            val_5 = val_5 - 64;
            // 0x00AD7740: STR w22, [x8, #0x20]       | mem2[0] = (((((1 << (9 - 8)) << 6) - ((1 << ((40 - 8) & 31))) << 6) >> ((40 - 8) & 31)) + 0);  //  dest_result_addr=0
            mem2[0] = val_6;
            // 0x00AD7744: CMP w28, w26               | STATE = COMPARE((1 << (9 - 8)), ((1 << ((40 - 8) & 31)) + 1))
            // 0x00AD7748: B.NE #0xad7700             | if (val_2 != val_1) goto label_4;       
            if(val_2 != val_9)
            {
                goto label_4;
            }
            label_1:
            // 0x00AD774C: SUB w8, w19, #1            | W8 = (8 - 1);                           
            var val_8 = 8 - 1;
            // 0x00AD7750: CMP w19, #0                | STATE = COMPARE(0x8, 0x0)               
            // 0x00AD7754: MOV w19, w8                | W19 = (8 - 1);//m1                      
            // 0x00AD7758: B.GT #0xad76c8             | if (8 > 0x0) goto label_5;              
            if(8 > 0)
            {
                goto label_5;
            }
            // 0x00AD775C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD7760: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD7764: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD7768: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD776C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AD7770: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AD7774: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7778 (11368312), len: 12  VirtAddr: 0x00AD7778 RVA: 0x00AD7778 token: 100681665 methodIndex: 54711 delegateWrapperIndex: 0 methodInvoker: 0
        public void Init()
        {
            //
            // Disasemble & Code
            // 0x00AD7778: ORR w8, wzr, #0x400        | W8 = 1024(0x400);                       
            // 0x00AD777C: STR w8, [x0, #0x10]        | mem[1152921513108468640] = 0x400;        //  dest_result_addr=1152921513108468640
            mem[1152921513108468640] = 1024;
            // 0x00AD7780: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7784 (11368324), len: 36  VirtAddr: 0x00AD7784 RVA: 0x00AD7784 token: 100681666 methodIndex: 54712 delegateWrapperIndex: 0 methodInvoker: 0
        public void UpdateModel(uint symbol)
        {
            //
            // Disasemble & Code
            // 0x00AD7784: LDR w8, [x0, #0x10]        | 
            // 0x00AD7788: ORR w9, wzr, #0x800        | W9 = 2048(0x800);                       
            var val_4 = 2048;
            // 0x00AD778C: CMP w1, #0                 | STATE = COMPARE(symbol, 0x0)            
            // 0x00AD7790: SUB w9, w9, w8             | W9 = (2048 - W8);                       
            val_4 = val_4 - W8;
            // 0x00AD7794: SUB w10, w8, w8, lsr #5    | W10 = (W8 - (W8) >> 5);                 
            var val_1 = W8 - ((W8) >> 5);
            // 0x00AD7798: ADD w8, w8, w9, lsr #5     | W8 = (W8 + ((2048 - W8)) >> 5);         
            var val_2 = W8 + (val_4 >> 5);
            // 0x00AD779C: CSEL w8, w10, w8, ne       | W8 = symbol != null ? (W8 - (W8) >> 5) : (W8 + ((2048 - W8)) >> 5);
            var val_3 = (symbol != 0) ? (val_1) : (val_2);
            // 0x00AD77A0: STR w8, [x0, #0x10]        | mem[1152921513108580640] = symbol != null ? (W8 - (W8) >> 5) : (W8 + ((2048 - W8)) >> 5);  //  dest_result_addr=1152921513108580640
            mem[1152921513108580640] = val_3;
            // 0x00AD77A4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7854 (11368532), len: 8  VirtAddr: 0x00AD7854 RVA: 0x00AD7854 token: 100681667 methodIndex: 54713 delegateWrapperIndex: 0 methodInvoker: 0
        public void Encode(SevenZip.Compression.RangeCoder.Encoder encoder, uint symbol)
        {
            //
            // Disasemble & Code
            // 0x00AD7854: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513108696736 (0x10000001FABFEEA0);
            // 0x00AD7858: B #0xad63d8                | goto label_Encoder_LenEncoder_Encode_GL00AD63D8;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD785C (11368540), len: 8  VirtAddr: 0x00AD785C RVA: 0x00AD785C token: 100681668 methodIndex: 54714 delegateWrapperIndex: 0 methodInvoker: 0
        public uint GetPrice(uint symbol)
        {
            //
            // Disasemble & Code
            // 0x00AD785C: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513108812832 (0x10000001FAC1B420);
            // 0x00AD7860: B #0xad7324                | goto label_Encoder_LiteralEncoder_Encoder2_EncodeMatched_GL00AD7324;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7864 (11368548), len: 8  VirtAddr: 0x00AD7864 RVA: 0x00AD7864 token: 100681669 methodIndex: 54715 delegateWrapperIndex: 0 methodInvoker: 0
        public uint GetPrice0()
        {
            //
            // Disasemble & Code
            // 0x00AD7864: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513108924832 (0x10000001FAC369A0);
            // 0x00AD7868: B #0xad67a4                | goto label_Encoder_LenEncoder_SetPrices_GL00AD67A4;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD786C (11368556), len: 544  VirtAddr: 0x00AD786C RVA: 0x00AD786C token: 100681670 methodIndex: 54716 delegateWrapperIndex: 0 methodInvoker: 0
        public uint GetPrice1()
        {
            //
            // Disasemble & Code
            //  | 
            char* val_1;
            // 0x00AD786C: ADD x0, x0, #0x10          | X0 = (this + 16) = val_1 (0x10000001FAC51F20);
            val_1 = 1152921513109036832;
            // 0x00AD7870: B #0xad6840                | goto label_Encoder_LenEncoder_SetPrices_GL00AD6840;
            // 0x00AD7874: STP x22, x21, [sp, #-0x30]! | stack[1152921513109024768] = ???;  stack[1152921513109024776] = ???;  //  dest_result_addr=1152921513109024768 |  dest_result_addr=1152921513109024776
            // 0x00AD7878: STP x20, x19, [sp, #0x10]  | stack[1152921513109024784] = ???;  stack[1152921513109024792] = ???;  //  dest_result_addr=1152921513109024784 |  dest_result_addr=1152921513109024792
            // 0x00AD787C: STP x29, x30, [sp, #0x20]  | stack[1152921513109024800] = ???;  stack[1152921513109024808] = ???;  //  dest_result_addr=1152921513109024800 |  dest_result_addr=1152921513109024808
            // 0x00AD7880: ADD x29, sp, #0x20         | X29 = (1152921513109024768 + 32) = 1152921513109024800 (0x10000001FAC4F020);
            // 0x00AD7884: MOV x19, x0                | X19 = 1152921513109036832 (0x10000001FAC51F20);//ML01
            // 0x00AD7888: LDR x8, [x19]              | X8 = typeof(SevenZip.Compression.RangeCoder.BitEncoder);
            // 0x00AD788C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00AD7890: CBZ x8, #0xad78f0          | if (typeof(SevenZip.Compression.RangeCoder.BitEncoder) == 0) goto label_0;
            if(new SevenZip.Compression.RangeCoder.BitEncoder() == 0)
            {
                goto label_0;
            }
            // 0x00AD7894: LDR x21, [x8, #0x18]       | X21 = SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_namespaze;
            // 0x00AD7898: LSL x0, x21, #2            | X0 = (SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_namespaze << 2) = val_1 (0x00000000);
            val_1 = 0;
            // 0x00AD789C: BL #0x27c8278              | X0 = sub_9810E0( ?? 0x400000029B3AD180, ????);
            // 0x00AD78A0: STR x0, [x20]              | mem2[0] = 0x400000029B3AD180;            //  dest_result_addr=0
            mem2[0] = val_1;
            // 0x00AD78A4: CMP w21, #1                | STATE = COMPARE(SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AD78A8: B.LT #0xad78f4             | if (SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_namespaze < 0x1) goto label_4;
            // 0x00AD78AC: LDR x8, [x19]              | X8 = typeof(SevenZip.Compression.RangeCoder.BitEncoder);
            // 0x00AD78B0: CMP w21, #1                | STATE = COMPARE(SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AD78B4: LDR w8, [x8, #0x20]        | W8 = SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_byval_arg;
            // 0x00AD78B8: STR w8, [x0]               | mem[4611686029621645696] = SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_byval_arg;  //  dest_result_addr=4611686029621645696
            mem[4611686029621645696] = SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_byval_arg;
            // 0x00AD78BC: B.EQ #0xad78f4             | if (SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_namespaze == 0x1) goto label_4;
            // 0x00AD78C0: MOV x8, xzr                | X8 = 0 (0x0);//ML01                     
            var val_2 = 0;
            // 0x00AD78C4: SUB w9, w21, #1            | W9 = (SevenZip.Compression.RangeCoder.BitEncoder.__il2cppRuntimeField_namespaze - 1) = 1152921507405411423 (0x10000000A6CEB45F);
            label_3:
            // 0x00AD78C8: LDR x10, [x19]             | X10 = typeof(SevenZip.Compression.RangeCoder.BitEncoder);
            // 0x00AD78CC: LDR x11, [x20]             | X11 = X1;                               
            var val_1 = X1;
            // 0x00AD78D0: ADD x10, x10, x8, lsl #2   | 
            // 0x00AD78D4: LDR w10, [x10, #0x24]      | W10 = typeof(SevenZip.Compression.RangeCoder.BitEncoder).Prob + 36;
            // 0x00AD78D8: ADD x11, x11, x8, lsl #2   | X11 = (X1 + 0);                         
            val_1 = val_1 + 0;
            // 0x00AD78DC: ADD x8, x8, #1             | X8 = (0 + 1);                           
            val_2 = val_2 + 1;
            // 0x00AD78E0: CMP w9, w8                 | STATE = COMPARE(0x10000000A6CEB45F, (0 + 1))
            // 0x00AD78E4: STR w10, [x11, #4]         | mem2[0] = typeof(SevenZip.Compression.RangeCoder.BitEncoder).Prob + 36;  //  dest_result_addr=0
            mem2[0] = typeof(SevenZip.Compression.RangeCoder.BitEncoder).Prob + 36;
            // 0x00AD78E8: B.NE #0xad78c8             | if (1152921507405411423 != 0) goto label_3;
            if(1152921507405411423 != val_2)
            {
                goto label_3;
            }
            // 0x00AD78EC: B #0xad78f4                |  goto label_4;                          
            goto label_4;
            label_0:
            // 0x00AD78F0: STR xzr, [x20]             | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            label_4:
            // 0x00AD78F4: LDR w8, [x19, #8]          |  //  find_add[1152921513109036816]
            // 0x00AD78F8: STR w8, [x20, #8]          | mem2[0] = typeof(SevenZip.Compression.RangeCoder.BitEncoder);  //  dest_result_addr=0
            mem2[0] = null;
            // 0x00AD78FC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD7900: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD7904: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD7908: RET                        |  return (System.UInt32)(SevenZip.Compression.RangeCoder.BitEncoder)[1152921513109036816];
            return (uint)val_1;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
    
    }

}
