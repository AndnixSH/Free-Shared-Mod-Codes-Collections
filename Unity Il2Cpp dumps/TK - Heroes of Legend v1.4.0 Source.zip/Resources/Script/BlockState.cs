using UnityEngine;

namespace Pathfinding.Ionic.Zlib
{
    internal enum BlockState
    {
        // Fields
        NeedMore = 0
        ,BlockDone = 1
        ,FinishStarted = 2
        ,FinishDone = 3
        
    
    }

}
