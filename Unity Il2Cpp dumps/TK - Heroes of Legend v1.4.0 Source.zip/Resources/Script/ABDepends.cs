using UnityEngine;
[Serializable]
public class ABDepends : ScriptableObject
{
    // Fields
    private static ABDepends abDepends; // static_offset: 0x00000000
    public System.Collections.Generic.List<string> nameList; //  0x00000018
    public System.Collections.Generic.List<string[]> dependList; //  0x00000020
    public System.Collections.Generic.List<string> dependStrList; //  0x00000028
    private bool isInit; //  0x00000030
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B1B84C (11647052), len: 184  VirtAddr: 0x00B1B84C RVA: 0x00B1B84C token: 100693124 methodIndex: 24653 delegateWrapperIndex: 0 methodInvoker: 0
    public ABDepends()
    {
        //
        // Disasemble & Code
        // 0x00B1B84C: STP x22, x21, [sp, #-0x30]! | stack[1152921514942315216] = ???;  stack[1152921514942315224] = ???;  //  dest_result_addr=1152921514942315216 |  dest_result_addr=1152921514942315224
        // 0x00B1B850: STP x20, x19, [sp, #0x10]  | stack[1152921514942315232] = ???;  stack[1152921514942315240] = ???;  //  dest_result_addr=1152921514942315232 |  dest_result_addr=1152921514942315240
        // 0x00B1B854: STP x29, x30, [sp, #0x20]  | stack[1152921514942315248] = ???;  stack[1152921514942315256] = ???;  //  dest_result_addr=1152921514942315248 |  dest_result_addr=1152921514942315256
        // 0x00B1B858: ADD x29, sp, #0x20         | X29 = (1152921514942315216 + 32) = 1152921514942315248 (0x10000002680ABAF0);
        // 0x00B1B85C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1B860: LDRB w8, [x20, #0x6fb]     | W8 = (bool)static_value_037336FB;       
        // 0x00B1B864: MOV x19, x0                | X19 = 1152921514942327264 (0x10000002680AE9E0);//ML01
        // 0x00B1B868: TBNZ w8, #0, #0xb1b884     | if (static_value_037336FB == true) goto label_0;
        // 0x00B1B86C: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00B1B870: LDR x8, [x8, #0xba8]       | X8 = 0x2B8A748;                         
        // 0x00B1B874: LDR w0, [x8]               | W0 = 0x90;                              
        // 0x00B1B878: BL #0x2782188              | X0 = sub_2782188( ?? 0x90, ????);       
        // 0x00B1B87C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1B880: STRB w8, [x20, #0x6fb]     | static_value_037336FB = true;            //  dest_result_addr=57882363
        label_0:
        // 0x00B1B884: ADRP x21, #0x367b000       | X21 = 57126912 (0x367B000);             
        // 0x00B1B888: LDR x21, [x21, #0xe00]     | X21 = 1152921504616644608;              
        // 0x00B1B88C: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.String> val_1 = null;
        // 0x00B1B890: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B1B894: ADRP x22, #0x35e9000       | X22 = 56528896 (0x35E9000);             
        // 0x00B1B898: LDR x22, [x22, #0xe88]     | X22 = 1152921510893072720;              
        // 0x00B1B89C: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B1B8A0: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
        // 0x00B1B8A4: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<System.String>();
        // 0x00B1B8A8: STR x20, [x19, #0x18]      | this.nameList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514942327288
        this.nameList = val_1;
        // 0x00B1B8AC: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
        // 0x00B1B8B0: LDR x8, [x8, #0xe40]       | X8 = 1152921504616644608;               
        // 0x00B1B8B4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.String[]> val_2 = null;
        // 0x00B1B8B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B1B8BC: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00B1B8C0: LDR x8, [x8, #0xdd8]       | X8 = 1152921514942302240;               
        // 0x00B1B8C4: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B1B8C8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String[]>::.ctor();
        // 0x00B1B8CC: BL #0x25e9474              | .ctor();                                
        val_2 = new System.Collections.Generic.List<System.String[]>();
        // 0x00B1B8D0: STR x20, [x19, #0x20]      | this.dependList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514942327296
        this.dependList = val_2;
        // 0x00B1B8D4: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.String> val_3 = null;
        // 0x00B1B8D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B1B8DC: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
        // 0x00B1B8E0: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B1B8E4: BL #0x25e9474              | .ctor();                                
        val_3 = new System.Collections.Generic.List<System.String>();
        // 0x00B1B8E8: STR x20, [x19, #0x28]      | this.dependStrList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514942327304
        this.dependStrList = val_3;
        // 0x00B1B8EC: MOV x0, x19                | X0 = 1152921514942327264 (0x10000002680AE9E0);//ML01
        // 0x00B1B8F0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B8F4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1B8F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B8FC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1B900: B #0x1b778f8               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B904 (11647236), len: 440  VirtAddr: 0x00B1B904 RVA: 0x00B1B904 token: 100693125 methodIndex: 24654 delegateWrapperIndex: 0 methodInvoker: 0
    public void AddDepend(string key, string[] depends)
    {
        //
        // Disasemble & Code
        // 0x00B1B904: STP x24, x23, [sp, #-0x40]! | stack[1152921514942501008] = ???;  stack[1152921514942501016] = ???;  //  dest_result_addr=1152921514942501008 |  dest_result_addr=1152921514942501016
        // 0x00B1B908: STP x22, x21, [sp, #0x10]  | stack[1152921514942501024] = ???;  stack[1152921514942501032] = ???;  //  dest_result_addr=1152921514942501024 |  dest_result_addr=1152921514942501032
        // 0x00B1B90C: STP x20, x19, [sp, #0x20]  | stack[1152921514942501040] = ???;  stack[1152921514942501048] = ???;  //  dest_result_addr=1152921514942501040 |  dest_result_addr=1152921514942501048
        // 0x00B1B910: STP x29, x30, [sp, #0x30]  | stack[1152921514942501056] = ???;  stack[1152921514942501064] = ???;  //  dest_result_addr=1152921514942501056 |  dest_result_addr=1152921514942501064
        // 0x00B1B914: ADD x29, sp, #0x30         | X29 = (1152921514942501008 + 48) = 1152921514942501056 (0x10000002680D90C0);
        // 0x00B1B918: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B1B91C: LDRB w8, [x22, #0x6fc]     | W8 = (bool)static_value_037336FC;       
        // 0x00B1B920: MOV x20, x2                | X20 = depends;//m1                      
        // 0x00B1B924: MOV x19, x1                | X19 = key;//m1                          
        // 0x00B1B928: MOV x21, x0                | X21 = 1152921514942513072 (0x10000002680DBFB0);//ML01
        // 0x00B1B92C: TBNZ w8, #0, #0xb1b948     | if (static_value_037336FC == true) goto label_0;
        // 0x00B1B930: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00B1B934: LDR x8, [x8, #0x688]       | X8 = 0x2B8A74C;                         
        // 0x00B1B938: LDR w0, [x8]               | W0 = 0x91;                              
        // 0x00B1B93C: BL #0x2782188              | X0 = sub_2782188( ?? 0x91, ????);       
        // 0x00B1B940: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1B944: STRB w8, [x22, #0x6fc]     | static_value_037336FC = true;            //  dest_result_addr=57882364
        label_0:
        // 0x00B1B948: LDR x22, [x21, #0x18]      | X22 = this.nameList; //P2               
        // 0x00B1B94C: CBNZ x22, #0xb1b954        | if (this.nameList != null) goto label_1;
        if(this.nameList != null)
        {
            goto label_1;
        }
        // 0x00B1B950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x91, ????);       
        label_1:
        // 0x00B1B954: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00B1B958: LDR x8, [x8, #0x780]       | X8 = 1152921510892731984;               
        // 0x00B1B95C: MOV x0, x22                | X0 = this.nameList;//m1                 
        // 0x00B1B960: MOV x1, x19                | X1 = key;//m1                           
        // 0x00B1B964: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.List<System.String>::IndexOf(System.String item);
        // 0x00B1B968: BL #0x25ec03c              | X0 = this.nameList.IndexOf(item:  key); 
        int val_1 = this.nameList.IndexOf(item:  key);
        // 0x00B1B96C: MOV w22, w0                | W22 = val_1;//m1                        
        // 0x00B1B970: TBNZ w22, #0x1f, #0xb1ba0c | if ((val_1 & 0x80000000) != 0) goto label_2;
        if((val_1 & 2147483648) != 0)
        {
            goto label_2;
        }
        // 0x00B1B974: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1B978: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1B97C: LDR x21, [x21, #0x28]      | X21 = this.dependStrList; //P2          
        // 0x00B1B980: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B1B984: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1B988: TBZ w8, #0, #0xb1b998      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B1B98C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1B990: CBNZ w8, #0xb1b998         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B1B994: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_4:
        // 0x00B1B998: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B1B99C: LDR x8, [x8, #0x770]       | X8 = (string**)(1152921509470674944)(" ");
        // 0x00B1B9A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B9A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1B9A8: MOV x2, x20                | X2 = depends;//m1                       
        // 0x00B1B9AC: LDR x1, [x8]               | X1 = " ";                               
        // 0x00B1B9B0: BL #0x18b0f8c              | X0 = System.String.Join(separator:  0, value:  " ");
        string val_2 = System.String.Join(separator:  0, value:  " ");
        // 0x00B1B9B4: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00B1B9B8: LDR x8, [x8, #0xb78]       | X8 = (string**)(1152921514942468512)("   ");
        // 0x00B1B9BC: MOV x3, x0                 | X3 = val_2;//m1                         
        // 0x00B1B9C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B9C4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B1B9C8: LDR x2, [x8]               | X2 = "   ";                             
        // 0x00B1B9CC: MOV x1, x19                | X1 = key;//m1                           
        // 0x00B1B9D0: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  key, str2:  "   ");
        string val_3 = System.String.Concat(str0:  0, str1:  key, str2:  "   ");
        // 0x00B1B9D4: MOV x19, x0                | X19 = val_3;//m1                        
        // 0x00B1B9D8: CBNZ x21, #0xb1b9e0        | if (this.dependStrList != null) goto label_5;
        if(this.dependStrList != null)
        {
            goto label_5;
        }
        // 0x00B1B9DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B1B9E0: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00B1B9E4: LDR x8, [x8, #0xff8]       | X8 = 1152921510891554128;               
        // 0x00B1B9E8: MOV x0, x21                | X0 = this.dependStrList;//m1            
        // 0x00B1B9EC: MOV w1, w22                | W1 = val_1;//m1                         
        // 0x00B1B9F0: MOV x2, x19                | X2 = val_3;//m1                         
        // 0x00B1B9F4: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.List<System.String>::set_Item(int index, System.String value);
        // 0x00B1B9F8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B9FC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1BA00: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1BA04: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B1BA08: B #0x25ed7fc               | this.dependStrList.set_Item(index:  val_1, value:  val_3); return;
        this.dependStrList.set_Item(index:  val_1, value:  val_3);
        return;
        label_2:
        // 0x00B1BA0C: LDR x22, [x21, #0x18]      | X22 = this.nameList; //P2               
        // 0x00B1BA10: CBNZ x22, #0xb1ba18        | if (this.nameList != null) goto label_6;
        if(this.nameList != null)
        {
            goto label_6;
        }
        // 0x00B1BA14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00B1BA18: ADRP x23, #0x35e6000       | X23 = 56516608 (0x35E6000);             
        // 0x00B1BA1C: LDR x23, [x23, #0x500]     | X23 = 1152921510890816336;              
        // 0x00B1BA20: MOV x0, x22                | X0 = this.nameList;//m1                 
        // 0x00B1BA24: MOV x1, x19                | X1 = key;//m1                           
        // 0x00B1BA28: LDR x2, [x23]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
        // 0x00B1BA2C: BL #0x25ea480              | this.nameList.Add(item:  key);          
        this.nameList.Add(item:  key);
        // 0x00B1BA30: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1BA34: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1BA38: LDR x21, [x21, #0x28]      | X21 = this.dependStrList; //P2          
        // 0x00B1BA3C: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B1BA40: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1BA44: TBZ w8, #0, #0xb1ba54      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B1BA48: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1BA4C: CBNZ w8, #0xb1ba54         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B1BA50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_8:
        // 0x00B1BA54: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B1BA58: LDR x8, [x8, #0x770]       | X8 = (string**)(1152921509470674944)(" ");
        // 0x00B1BA5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1BA60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1BA64: MOV x2, x20                | X2 = depends;//m1                       
        // 0x00B1BA68: LDR x1, [x8]               | X1 = " ";                               
        // 0x00B1BA6C: BL #0x18b0f8c              | X0 = System.String.Join(separator:  0, value:  " ");
        string val_4 = System.String.Join(separator:  0, value:  " ");
        // 0x00B1BA70: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00B1BA74: LDR x8, [x8, #0xb78]       | X8 = (string**)(1152921514942468512)("   ");
        // 0x00B1BA78: MOV x3, x0                 | X3 = val_4;//m1                         
        // 0x00B1BA7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1BA80: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B1BA84: LDR x2, [x8]               | X2 = "   ";                             
        // 0x00B1BA88: MOV x1, x19                | X1 = key;//m1                           
        // 0x00B1BA8C: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  key, str2:  "   ");
        string val_5 = System.String.Concat(str0:  0, str1:  key, str2:  "   ");
        // 0x00B1BA90: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00B1BA94: CBNZ x21, #0xb1ba9c        | if (this.dependStrList != null) goto label_9;
        if(this.dependStrList != null)
        {
            goto label_9;
        }
        // 0x00B1BA98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00B1BA9C: LDR x2, [x23]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
        // 0x00B1BAA0: MOV x0, x21                | X0 = this.dependStrList;//m1            
        // 0x00B1BAA4: MOV x1, x19                | X1 = val_5;//m1                         
        // 0x00B1BAA8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1BAAC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1BAB0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1BAB4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B1BAB8: B #0x25ea480               | this.dependStrList.Add(item:  val_5); return;
        this.dependStrList.Add(item:  val_5);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1BABC (11647676), len: 168  VirtAddr: 0x00B1BABC RVA: 0x00B1BABC token: 100693126 methodIndex: 24655 delegateWrapperIndex: 0 methodInvoker: 0
    public string[] GetDepend(string key)
    {
        //
        // Disasemble & Code
        //  | 
        System.Collections.Generic.List<System.String[]> val_4;
        //  | 
        var val_5;
        // 0x00B1BABC: STP x22, x21, [sp, #-0x30]! | stack[1152921514942736928] = ???;  stack[1152921514942736936] = ???;  //  dest_result_addr=1152921514942736928 |  dest_result_addr=1152921514942736936
        // 0x00B1BAC0: STP x20, x19, [sp, #0x10]  | stack[1152921514942736944] = ???;  stack[1152921514942736952] = ???;  //  dest_result_addr=1152921514942736944 |  dest_result_addr=1152921514942736952
        // 0x00B1BAC4: STP x29, x30, [sp, #0x20]  | stack[1152921514942736960] = ???;  stack[1152921514942736968] = ???;  //  dest_result_addr=1152921514942736960 |  dest_result_addr=1152921514942736968
        // 0x00B1BAC8: ADD x29, sp, #0x20         | X29 = (1152921514942736928 + 32) = 1152921514942736960 (0x1000000268112A40);
        // 0x00B1BACC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1BAD0: LDRB w8, [x21, #0x6fd]     | W8 = (bool)static_value_037336FD;       
        // 0x00B1BAD4: MOV x20, x1                | X20 = key;//m1                          
        // 0x00B1BAD8: MOV x19, x0                | X19 = 1152921514942748976 (0x1000000268115930);//ML01
        val_4 = this;
        // 0x00B1BADC: TBNZ w8, #0, #0xb1baf8     | if (static_value_037336FD == true) goto label_0;
        // 0x00B1BAE0: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
        // 0x00B1BAE4: LDR x8, [x8, #0x190]       | X8 = 0x2B8A750;                         
        // 0x00B1BAE8: LDR w0, [x8]               | W0 = 0x92;                              
        // 0x00B1BAEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x92, ????);       
        // 0x00B1BAF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1BAF4: STRB w8, [x21, #0x6fd]     | static_value_037336FD = true;            //  dest_result_addr=57882365
        label_0:
        // 0x00B1BAF8: LDR x21, [x19, #0x18]      | X21 = this.nameList; //P2               
        // 0x00B1BAFC: CBNZ x21, #0xb1bb04        | if (this.nameList != null) goto label_1;
        if(this.nameList != null)
        {
            goto label_1;
        }
        // 0x00B1BB00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x92, ????);       
        label_1:
        // 0x00B1BB04: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00B1BB08: LDR x8, [x8, #0x780]       | X8 = 1152921510892731984;               
        // 0x00B1BB0C: MOV x0, x21                | X0 = this.nameList;//m1                 
        // 0x00B1BB10: MOV x1, x20                | X1 = key;//m1                           
        // 0x00B1BB14: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.List<System.String>::IndexOf(System.String item);
        // 0x00B1BB18: BL #0x25ec03c              | X0 = this.nameList.IndexOf(item:  key); 
        int val_1 = this.nameList.IndexOf(item:  key);
        // 0x00B1BB1C: MOV w20, w0                | W20 = val_1;//m1                        
        // 0x00B1BB20: LSR w8, w20, #0x1e         | W8 = (val_1 >> 30);                     
        int val_2 = val_1 >> 30;
        // 0x00B1BB24: TBNZ w8, #1, #0xb1bb50     | if (((val_1 >> 30) & 0x2) != 0) goto label_2;
        if((val_2 & 2) != 0)
        {
            goto label_2;
        }
        // 0x00B1BB28: LDR x19, [x19, #0x20]      | X19 = this.dependList; //P2             
        val_4 = this.dependList;
        // 0x00B1BB2C: CBNZ x19, #0xb1bb34        | if (this.dependList != null) goto label_3;
        if(val_4 != null)
        {
            goto label_3;
        }
        // 0x00B1BB30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B1BB34: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
        // 0x00B1BB38: LDR x8, [x8, #0xe30]       | X8 = 1152921514942687088;               
        // 0x00B1BB3C: MOV x0, x19                | X0 = this.dependList;//m1               
        // 0x00B1BB40: MOV w1, w20                | W1 = val_1;//m1                         
        // 0x00B1BB44: LDR x2, [x8]               | X2 = public System.String[] System.Collections.Generic.List<System.String[]>::get_Item(int index);
        // 0x00B1BB48: BL #0x25ed734              | X0 = this.dependList.get_Item(index:  val_1);
        System.String[] val_3 = val_4.Item[val_1];
        // 0x00B1BB4C: B #0xb1bb54                |  goto label_4;                          
        goto label_4;
        label_2:
        // 0x00B1BB50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_5 = 0;
        label_4:
        // 0x00B1BB54: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1BB58: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1BB5C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1BB60: RET                        |  return (System.String[])null;          
        return (System.String[])val_5;
        //  |  // // {name=val_0, type=System.String[], size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1BB64 (11647844), len: 484  VirtAddr: 0x00B1BB64 RVA: 0x00B1BB64 token: 100693127 methodIndex: 24656 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init()
    {
        //
        // Disasemble & Code
        // 0x00B1BB64: STP x28, x27, [sp, #-0x60]! | stack[1152921514942968688] = ???;  stack[1152921514942968696] = ???;  //  dest_result_addr=1152921514942968688 |  dest_result_addr=1152921514942968696
        // 0x00B1BB68: STP x26, x25, [sp, #0x10]  | stack[1152921514942968704] = ???;  stack[1152921514942968712] = ???;  //  dest_result_addr=1152921514942968704 |  dest_result_addr=1152921514942968712
        // 0x00B1BB6C: STP x24, x23, [sp, #0x20]  | stack[1152921514942968720] = ???;  stack[1152921514942968728] = ???;  //  dest_result_addr=1152921514942968720 |  dest_result_addr=1152921514942968728
        // 0x00B1BB70: STP x22, x21, [sp, #0x30]  | stack[1152921514942968736] = ???;  stack[1152921514942968744] = ???;  //  dest_result_addr=1152921514942968736 |  dest_result_addr=1152921514942968744
        // 0x00B1BB74: STP x20, x19, [sp, #0x40]  | stack[1152921514942968752] = ???;  stack[1152921514942968760] = ???;  //  dest_result_addr=1152921514942968752 |  dest_result_addr=1152921514942968760
        // 0x00B1BB78: STP x29, x30, [sp, #0x50]  | stack[1152921514942968768] = ???;  stack[1152921514942968776] = ???;  //  dest_result_addr=1152921514942968768 |  dest_result_addr=1152921514942968776
        // 0x00B1BB7C: ADD x29, sp, #0x50         | X29 = (1152921514942968688 + 80) = 1152921514942968768 (0x100000026814B3C0);
        // 0x00B1BB80: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1BB84: LDRB w8, [x20, #0x6fe]     | W8 = (bool)static_value_037336FE;       
        // 0x00B1BB88: MOV x19, x0                | X19 = 1152921514942980784 (0x100000026814E2B0);//ML01
        // 0x00B1BB8C: TBNZ w8, #0, #0xb1bba8     | if (static_value_037336FE == true) goto label_0;
        // 0x00B1BB90: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x00B1BB94: LDR x8, [x8, #0x118]       | X8 = 0x2B8A758;                         
        // 0x00B1BB98: LDR w0, [x8]               | W0 = 0x94;                              
        // 0x00B1BB9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x94, ????);       
        // 0x00B1BBA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1BBA4: STRB w8, [x20, #0x6fe]     | static_value_037336FE = true;            //  dest_result_addr=57882366
        label_0:
        // 0x00B1BBA8: LDRB w8, [x19, #0x30]      | W8 = this.isInit; //P2                  
        // 0x00B1BBAC: CBNZ w8, #0xb1bd2c         | if (this.isInit == true) goto label_1;  
        if(this.isInit == true)
        {
            goto label_1;
        }
        // 0x00B1BBB0: ADRP x9, #0x3671000        | X9 = 57085952 (0x3671000);              
        // 0x00B1BBB4: LDR x9, [x9, #0xec8]       | X9 = 1152921504902586368;               
        // 0x00B1BBB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1BBBC: STRB w8, [x19, #0x30]      | this.isInit = true;                      //  dest_result_addr=1152921514942980832
        this.isInit = true;
        // 0x00B1BBC0: LDR x8, [x9]               | X8 = typeof(ABDepends);                 
        // 0x00B1BBC4: LDR x8, [x8, #0xa0]        | X8 = ABDepends.__il2cppRuntimeField_static_fields;
        // 0x00B1BBC8: STR x19, [x8]              | ABDepends.abDepends = this;              //  dest_result_addr=1152921504902590464
        ABDepends.abDepends = this;
        // 0x00B1BBCC: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00B1BBD0: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
        // 0x00B1BBD4: LDR x20, [x8]              | X20 = typeof(System.Char[]);            
        // 0x00B1BBD8: MOV x0, x20                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1BBDC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00B1BBE0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B1BBE4: MOV x0, x20                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1BBE8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00B1BBEC: MOV x20, x0                | X20 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1BBF0: CBNZ x20, #0xb1bbf8        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00B1BBF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_2:
        // 0x00B1BBF8: LDR w8, [x20, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00B1BBFC: CBNZ w8, #0xb1bc0c         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_3;
        // 0x00B1BC00: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00B1BC04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BC08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_3:
        // 0x00B1BC0C: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
        // 0x00B1BC10: STRH w8, [x20, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x20;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 32;
        // 0x00B1BC14: LDR x21, [x19, #0x28]      | X21 = this.dependStrList; //P2          
        // 0x00B1BC18: CBNZ x21, #0xb1bc20        | if (this.dependStrList != null) goto label_4;
        if(this.dependStrList != null)
        {
            goto label_4;
        }
        // 0x00B1BC1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_4:
        // 0x00B1BC20: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B1BC24: LDR x8, [x8, #0xb58]       | X8 = 1152921510022759280;               
        // 0x00B1BC28: MOV x0, x21                | X0 = this.dependStrList;//m1            
        // 0x00B1BC2C: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B1BC30: BL #0x25ed72c              | X0 = this.dependStrList.get_Count();    
        int val_1 = this.dependStrList.Count;
        // 0x00B1BC34: MOV w21, w0                | W21 = val_1;//m1                        
        // 0x00B1BC38: CMP w21, #1                | STATE = COMPARE(val_1, 0x1)             
        // 0x00B1BC3C: B.LT #0xb1bd08             | if (val_1 < 1) goto label_5;            
        if(val_1 < 1)
        {
            goto label_5;
        }
        // 0x00B1BC40: ADRP x26, #0x35bd000       | X26 = 56348672 (0x35BD000);             
        // 0x00B1BC44: ADRP x27, #0x35fd000       | X27 = 56610816 (0x35FD000);             
        // 0x00B1BC48: LDR x26, [x26, #0xb50]     | X26 = 1152921510890998992;              
        // 0x00B1BC4C: LDR x27, [x27, #0x950]     | X27 = 1152921514942890224;              
        // 0x00B1BC50: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        var val_8 = 0;
        label_12:
        // 0x00B1BC54: LDP x23, x24, [x19, #0x20] | X23 = this.dependList; //P2  X24 = this.dependStrList; //P2  //  | 
        // 0x00B1BC58: CBNZ x24, #0xb1bc60        | if (this.dependStrList != null) goto label_6;
        if(this.dependStrList != null)
        {
            goto label_6;
        }
        // 0x00B1BC5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00B1BC60: LDR x2, [x26]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B1BC64: MOV x0, x24                | X0 = this.dependStrList;//m1            
        // 0x00B1BC68: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B1BC6C: BL #0x25ed734              | X0 = this.dependStrList.get_Item(index:  0);
        string val_2 = this.dependStrList.Item[0];
        // 0x00B1BC70: LDR x25, [x19, #0x18]      | X25 = this.nameList; //P2               
        // 0x00B1BC74: MOV x24, x0                | X24 = val_2;//m1                        
        // 0x00B1BC78: CBNZ x25, #0xb1bc80        | if (this.nameList != null) goto label_7;
        if(this.nameList != null)
        {
            goto label_7;
        }
        // 0x00B1BC7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B1BC80: LDR x2, [x26]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B1BC84: MOV x0, x25                | X0 = this.nameList;//m1                 
        // 0x00B1BC88: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B1BC8C: BL #0x25ed734              | X0 = this.nameList.get_Item(index:  0); 
        string val_3 = this.nameList.Item[0];
        // 0x00B1BC90: MOV x25, x0                | X25 = val_3;//m1                        
        // 0x00B1BC94: CBNZ x25, #0xb1bc9c        | if (val_3 != null) goto label_8;        
        if(val_3 != null)
        {
            goto label_8;
        }
        // 0x00B1BC98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B1BC9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BCA0: MOV x0, x25                | X0 = val_3;//m1                         
        // 0x00B1BCA4: BL #0x18a4460              | X0 = val_3.get_Length();                
        int val_4 = val_3.Length;
        // 0x00B1BCA8: MOV w25, w0                | W25 = val_4;//m1                        
        // 0x00B1BCAC: CBNZ x24, #0xb1bcb4        | if (val_2 != null) goto label_9;        
        if(val_2 != null)
        {
            goto label_9;
        }
        // 0x00B1BCB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00B1BCB4: ADD w1, w25, #3            | W1 = (val_4 + 3);                       
        int val_5 = val_4 + 3;
        // 0x00B1BCB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1BCBC: MOV x0, x24                | X0 = val_2;//m1                         
        // 0x00B1BCC0: BL #0x18a5a40              | X0 = val_2.Substring(startIndex:  int val_5 = val_4 + 3);
        string val_6 = val_2.Substring(startIndex:  val_5);
        // 0x00B1BCC4: MOV x24, x0                | X24 = val_6;//m1                        
        // 0x00B1BCC8: CBNZ x24, #0xb1bcd0        | if (val_6 != null) goto label_10;       
        if(val_6 != null)
        {
            goto label_10;
        }
        // 0x00B1BCCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_10:
        // 0x00B1BCD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1BCD4: MOV x0, x24                | X0 = val_6;//m1                         
        // 0x00B1BCD8: MOV x1, x20                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1BCDC: BL #0x18a881c              | X0 = val_6.Split(separator:  null);     
        System.String[] val_7 = val_6.Split(separator:  null);
        // 0x00B1BCE0: MOV x24, x0                | X24 = val_7;//m1                        
        // 0x00B1BCE4: CBNZ x23, #0xb1bcec        | if (this.dependList != null) goto label_11;
        if(this.dependList != null)
        {
            goto label_11;
        }
        // 0x00B1BCE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_11:
        // 0x00B1BCEC: LDR x2, [x27]              | X2 = public System.Void System.Collections.Generic.List<System.String[]>::Add(System.String[] item);
        // 0x00B1BCF0: MOV x0, x23                | X0 = this.dependList;//m1               
        // 0x00B1BCF4: MOV x1, x24                | X1 = val_7;//m1                         
        // 0x00B1BCF8: BL #0x25ea480              | this.dependList.Add(item:  val_7);      
        this.dependList.Add(item:  val_7);
        // 0x00B1BCFC: ADD w22, w22, #1           | W22 = (0 + 1);                          
        val_8 = val_8 + 1;
        // 0x00B1BD00: CMP w21, w22               | STATE = COMPARE(val_1, (0 + 1))         
        // 0x00B1BD04: B.NE #0xb1bc54             | if (val_1 != 0) goto label_12;          
        if(val_1 != val_8)
        {
            goto label_12;
        }
        label_5:
        // 0x00B1BD08: LDR x20, [x19, #0x28]      | X20 = this.dependStrList; //P2          
        // 0x00B1BD0C: CBNZ x20, #0xb1bd14        | if (this.dependStrList != null) goto label_13;
        if(this.dependStrList != null)
        {
            goto label_13;
        }
        // 0x00B1BD10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.dependList, ????);
        label_13:
        // 0x00B1BD14: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00B1BD18: LDR x8, [x8, #0xca8]       | X8 = 1152921510890633680;               
        // 0x00B1BD1C: MOV x0, x20                | X0 = this.dependStrList;//m1            
        // 0x00B1BD20: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
        // 0x00B1BD24: BL #0x25ead28              | this.dependStrList.Clear();             
        this.dependStrList.Clear();
        // 0x00B1BD28: STR xzr, [x19, #0x28]      | this.dependStrList = null;               //  dest_result_addr=1152921514942980824
        this.dependStrList = 0;
        label_1:
        // 0x00B1BD2C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1BD30: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1BD34: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1BD38: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1BD3C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1BD40: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B1BD44: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1BD48 (11648328), len: 132  VirtAddr: 0x00B1BD48 RVA: 0x00B1BD48 token: 100693128 methodIndex: 24657 delegateWrapperIndex: 0 methodInvoker: 0
    public static bool GetDepend(string key, out string[] depends)
    {
        //
        // Disasemble & Code
        // 0x00B1BD48: STP x22, x21, [sp, #-0x30]! | stack[1152921514943195344] = ???;  stack[1152921514943195352] = ???;  //  dest_result_addr=1152921514943195344 |  dest_result_addr=1152921514943195352
        // 0x00B1BD4C: STP x20, x19, [sp, #0x10]  | stack[1152921514943195360] = ???;  stack[1152921514943195368] = ???;  //  dest_result_addr=1152921514943195360 |  dest_result_addr=1152921514943195368
        // 0x00B1BD50: STP x29, x30, [sp, #0x20]  | stack[1152921514943195376] = ???;  stack[1152921514943195384] = ???;  //  dest_result_addr=1152921514943195376 |  dest_result_addr=1152921514943195384
        // 0x00B1BD54: ADD x29, sp, #0x20         | X29 = (1152921514943195344 + 32) = 1152921514943195376 (0x10000002681828F0);
        // 0x00B1BD58: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1BD5C: LDRB w8, [x21, #0x6ff]     | W8 = (bool)static_value_037336FF;       
        // 0x00B1BD60: MOV x19, x2                | X19 = X2;//m1                           
        // 0x00B1BD64: MOV x20, x1                | X20 = 1152921514943243488 (0x100000026818E4E0);//ML01
        // 0x00B1BD68: TBNZ w8, #0, #0xb1bd84     | if (static_value_037336FF == true) goto label_0;
        // 0x00B1BD6C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00B1BD70: LDR x8, [x8, #0xec8]       | X8 = 0x2B8A754;                         
        // 0x00B1BD74: LDR w0, [x8]               | W0 = 0x93;                              
        // 0x00B1BD78: BL #0x2782188              | X0 = sub_2782188( ?? 0x93, ????);       
        // 0x00B1BD7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1BD80: STRB w8, [x21, #0x6ff]     | static_value_037336FF = true;            //  dest_result_addr=57882367
        label_0:
        // 0x00B1BD84: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x00B1BD88: LDR x8, [x8, #0xec8]       | X8 = 1152921504902586368;               
        // 0x00B1BD8C: LDR x8, [x8]               | X8 = typeof(ABDepends);                 
        // 0x00B1BD90: LDR x8, [x8, #0xa0]        | X8 = ABDepends.__il2cppRuntimeField_static_fields;
        // 0x00B1BD94: LDR x21, [x8]              | X21 = ABDepends.abDepends;              
        // 0x00B1BD98: CBNZ x21, #0xb1bda0        | if (ABDepends.abDepends != null) goto label_1;
        if(ABDepends.abDepends != null)
        {
            goto label_1;
        }
        // 0x00B1BD9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x93, ????);       
        label_1:
        // 0x00B1BDA0: MOV x0, x21                | X0 = ABDepends.abDepends;//m1           
        // 0x00B1BDA4: MOV x1, x20                | X1 = 1152921514943243488 (0x100000026818E4E0);//ML01
        // 0x00B1BDA8: BL #0xb1babc               | X0 = ABDepends.abDepends.GetDepend(key:  depends);
        System.String[] val_1 = ABDepends.abDepends.GetDepend(key:  depends);
        // 0x00B1BDAC: STR x0, [x19]              | mem2[0] = val_1;                         //  dest_result_addr=0
        mem2[0] = val_1;
        // 0x00B1BDB0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1BDB4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1BDB8: CMP x0, #0                 | STATE = COMPARE(val_1, 0x0)             
        // 0x00B1BDBC: CSET w8, ne                | W8 = val_1 != null ? 1 : 0;             
        var val_2 = (val_1 != null) ? 1 : 0;
        // 0x00B1BDC0: MOV w0, w8                 | W0 = val_1 != null ? 1 : 0;//m1         
        // 0x00B1BDC4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1BDC8: RET                        |  return (System.Boolean)val_1 != null ? 1 : 0;
        return (bool)val_2;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }

}
