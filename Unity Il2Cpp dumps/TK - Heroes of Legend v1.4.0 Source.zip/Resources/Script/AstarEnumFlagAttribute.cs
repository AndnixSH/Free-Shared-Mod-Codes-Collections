using UnityEngine;

namespace Pathfinding
{
    public class AstarEnumFlagAttribute : PropertyAttribute
    {
        // Fields
        public string enumName; //  0x00000010
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x016833B4 (23606196), len: 8  VirtAddr: 0x016833B4 RVA: 0x016833B4 token: 100682136 methodIndex: 49824 delegateWrapperIndex: 0 methodInvoker: 0
        public AstarEnumFlagAttribute()
        {
            //
            // Disasemble & Code
            // 0x016833B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016833B8: B #0x1b77710               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x016833BC (23606204), len: 44  VirtAddr: 0x016833BC RVA: 0x016833BC token: 100682137 methodIndex: 49825 delegateWrapperIndex: 0 methodInvoker: 0
        public AstarEnumFlagAttribute(string name)
        {
            //
            // Disasemble & Code
            // 0x016833BC: STP x20, x19, [sp, #-0x20]! | stack[1152921513198812064] = ???;  stack[1152921513198812072] = ???;  //  dest_result_addr=1152921513198812064 |  dest_result_addr=1152921513198812072
            // 0x016833C0: STP x29, x30, [sp, #0x10]  | stack[1152921513198812080] = ???;  stack[1152921513198812088] = ???;  //  dest_result_addr=1152921513198812080 |  dest_result_addr=1152921513198812088
            // 0x016833C4: ADD x29, sp, #0x10         | X29 = (1152921513198812064 + 16) = 1152921513198812080 (0x10000002001EFBB0);
            // 0x016833C8: MOV x19, x1                | X19 = name;//m1                         
            // 0x016833CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016833D0: MOV x20, x0                | X20 = 1152921513198824096 (0x10000002001F2AA0);//ML01
            // 0x016833D4: BL #0x1b77710              | this..ctor();                           
            // 0x016833D8: STR x19, [x20, #0x10]      | this.enumName = name;                    //  dest_result_addr=1152921513198824112
            this.enumName = name;
            // 0x016833DC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x016833E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x016833E4: RET                        |  return;                                
            return;
        
        }
    
    }

}
