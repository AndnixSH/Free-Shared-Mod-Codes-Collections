using UnityEngine;

namespace Pathfinding
{
    public class AstarMath
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x016833E8 (23606248), len: 8  VirtAddr: 0x016833E8 RVA: 0x016833E8 token: 100681935 methodIndex: 49826 delegateWrapperIndex: 0 methodInvoker: 0
        public AstarMath()
        {
            //
            // Disasemble & Code
            // 0x016833E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016833EC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x016833F0 (23606256), len: 44  VirtAddr: 0x016833F0 RVA: 0x016833F0 token: 100681936 methodIndex: 49827 delegateWrapperIndex: 0 methodInvoker: 0
        public static int ComputeVertexHash(int x, int y, int z)
        {
            //
            // Disasemble & Code
            // 0x016833F0: MOVZ w8, #0x8da6, lsl #16  | W8 = 2376466432 (0x8DA60000);//ML01     
            // 0x016833F4: MOVK w8, #0xb343           | W8 = 2376512323 (0x8DA6B343);           
            // 0x016833F8: MOVZ w9, #0xd816, lsl #16  | W9 = 3625320448 (0xD8160000);//ML01     
            // 0x016833FC: MOVK w9, #0x3841           | W9 = 3625334849 (0xD8163841);           
            // 0x01683400: MUL w8, w1, w8             | W8 = (y * 2376512323);                  
            int val_1 = y * 2376512323;
            // 0x01683404: MADD w8, w2, w9, w8        | W8 = (z * 3625334849) + (y * 2376512323);
            val_1 = val_1 + (z * 3625334849);
            // 0x01683408: MOVZ w9, #0xcb1a, lsl #16  | W9 = 3407478784 (0xCB1A0000);//ML01     
            // 0x0168340C: MOVK w9, #0xb31f           | W9 = 3407524639 (0xCB1AB31F);           
            // 0x01683410: MADD w8, w3, w9, w8        | W8 = (W3 * 3407524639) + (z * 3625334849) + (y * 2376512323);
            val_1 = val_1 + (W3 * 3407524639);
            // 0x01683414: AND w0, w8, #0x3fffffff    | W0 = ((W3 * 3407524639) + (z * 3625334849) + (y * 2376512323) & 1073741823);
            var val_2 = val_1 & 1073741823;
            // 0x01683418: RET                        |  return (System.Int32)((W3 * 3407524639) + (z * 3625334849) + (y * 2376512323) & 1073741823);
            return (int)val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168341C (23606300), len: 344  VirtAddr: 0x0168341C RVA: 0x0168341C token: 100681937 methodIndex: 49828 delegateWrapperIndex: 0 methodInvoker: 0
        public static UnityEngine.Vector3 NearestPoint(UnityEngine.Vector3 lineStart, UnityEngine.Vector3 lineEnd, UnityEngine.Vector3 point)
        {
            //
            // Disasemble & Code
            //  | 
            float val_1;
            // 0x0168341C: STP d15, d14, [sp, #-0x60]! | stack[1152921513157679632] = ???;  stack[1152921513157679640] = ???;  //  dest_result_addr=1152921513157679632 |  dest_result_addr=1152921513157679640
            // 0x01683420: STP d13, d12, [sp, #0x10]  | stack[1152921513157679648] = ???;  stack[1152921513157679656] = ???;  //  dest_result_addr=1152921513157679648 |  dest_result_addr=1152921513157679656
            // 0x01683424: STP d11, d10, [sp, #0x20]  | stack[1152921513157679664] = ???;  stack[1152921513157679672] = ???;  //  dest_result_addr=1152921513157679664 |  dest_result_addr=1152921513157679672
            // 0x01683428: STP d9, d8, [sp, #0x30]    | stack[1152921513157679680] = ???;  stack[1152921513157679688] = ???;  //  dest_result_addr=1152921513157679680 |  dest_result_addr=1152921513157679688
            // 0x0168342C: STP x20, x19, [sp, #0x40]  | stack[1152921513157679696] = ???;  stack[1152921513157679704] = ???;  //  dest_result_addr=1152921513157679696 |  dest_result_addr=1152921513157679704
            // 0x01683430: STP x29, x30, [sp, #0x50]  | stack[1152921513157679712] = ???;  stack[1152921513157679720] = ???;  //  dest_result_addr=1152921513157679712 |  dest_result_addr=1152921513157679720
            // 0x01683434: ADD x29, sp, #0x50         | X29 = (1152921513157679632 + 80) = 1152921513157679712 (0x10000001FDAB5A60);
            // 0x01683438: SUB sp, sp, #0x10          | SP = (1152921513157679632 - 16) = 1152921513157679616 (0x10000001FDAB5A00);
            // 0x0168343C: MOV v9.16b, v1.16b         | V9 = lineStart.y;//m1                   
            // 0x01683440: LDR s1, [x29, #0x18]       | S1 = point.y;                           
            // 0x01683444: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01683448: MOV v14.16b, v5.16b        | V14 = lineEnd.z;//m1                    
            // 0x0168344C: MOV v15.16b, v4.16b        | V15 = lineEnd.y;//m1                    
            // 0x01683450: STR s1, [sp, #0xc]         | stack[1152921513157679628] = point.y;    //  dest_result_addr=1152921513157679628
            // 0x01683454: LDP s13, s12, [x29, #0x10] | S13 = point.x; S12 = val_1;              //  |  find_add[1152921513157667728]
            // 0x01683458: LDRB w8, [x19, #0xd5]      | W8 = (bool)static_value_037380D5;       
            // 0x0168345C: MOV v11.16b, v3.16b        | V11 = lineEnd.x;//m1                    
            // 0x01683460: MOV v8.16b, v2.16b         | V8 = lineStart.z;//m1                   
            // 0x01683464: MOV v10.16b, v0.16b        | V10 = lineStart.x;//m1                  
            // 0x01683468: TBNZ w8, #0, #0x1683484    | if (static_value_037380D5 == true) goto label_0;
            // 0x0168346C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x01683470: LDR x8, [x8, #0x4b8]       | X8 = 0x2B8EC88;                         
            // 0x01683474: LDR w0, [x8]               | W0 = 0x11E2;                            
            // 0x01683478: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E2, ????);     
            // 0x0168347C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01683480: STRB w8, [x19, #0xd5]      | static_value_037380D5 = true;            //  dest_result_addr=57901269
            label_0:
            // 0x01683484: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x01683488: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x0168348C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683490: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01683494: TBZ w8, #0, #0x16834a4     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01683498: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0168349C: CBNZ w8, #0x16834a4        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016834A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x016834A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016834A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016834AC: MOV v0.16b, v11.16b        | V0 = lineEnd.x;//m1                     
            // 0x016834B0: MOV v1.16b, v15.16b        | V1 = lineEnd.y;//m1                     
            // 0x016834B4: MOV v2.16b, v14.16b        | V2 = lineEnd.z;//m1                     
            // 0x016834B8: MOV v3.16b, v10.16b        | V3 = lineStart.x;//m1                   
            // 0x016834BC: MOV v4.16b, v9.16b         | V4 = lineStart.y;//m1                   
            // 0x016834C0: MOV v5.16b, v8.16b         | V5 = lineStart.z;//m1                   
            // 0x016834C4: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = lineEnd.x, y = lineEnd.y, z = lineEnd.z}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z});
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = lineEnd.x, y = lineEnd.y, z = lineEnd.z}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z});
            // 0x016834C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016834CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016834D0: BL #0x2699aa0              | X0 = UnityEngine.Vector3.Normalize(value:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.Normalize(value:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
            // 0x016834D4: MOV v15.16b, v2.16b        | V15 = val_3.z;//m1                      
            // 0x016834D8: LDR s2, [sp, #0xc]         | S2 = point.y;                           
            // 0x016834DC: MOV v11.16b, v0.16b        | V11 = val_3.x;//m1                      
            // 0x016834E0: MOV v14.16b, v1.16b        | V14 = val_3.y;//m1                      
            // 0x016834E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016834E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016834EC: MOV v0.16b, v13.16b        | V0 = point.x;//m1                       
            // 0x016834F0: MOV v1.16b, v12.16b        | V1 = val_1;//m1                         
            // 0x016834F4: MOV v3.16b, v10.16b        | V3 = lineStart.x;//m1                   
            // 0x016834F8: MOV v4.16b, v9.16b         | V4 = lineStart.y;//m1                   
            // 0x016834FC: MOV v5.16b, v8.16b         | V5 = lineStart.z;//m1                   
            // 0x01683500: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = point.x, y = val_1, z = point.y}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z});
            UnityEngine.Vector3 val_4 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = point.x, y = val_1, z = point.y}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z});
            // 0x01683504: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168350C: MOV v3.16b, v11.16b        | V3 = val_3.x;//m1                       
            // 0x01683510: MOV v4.16b, v14.16b        | V4 = val_3.y;//m1                       
            // 0x01683514: MOV v5.16b, v15.16b        | V5 = val_3.z;//m1                       
            // 0x01683518: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, rhs:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            float val_5 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, rhs:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            // 0x0168351C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683524: MOV v1.16b, v11.16b        | V1 = val_3.x;//m1                       
            // 0x01683528: MOV v2.16b, v14.16b        | V2 = val_3.y;//m1                       
            // 0x0168352C: MOV v3.16b, v15.16b        | V3 = val_3.z;//m1                       
            // 0x01683530: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  float val_5 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, rhs:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}), a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            UnityEngine.Vector3 val_6 = UnityEngine.Vector3.op_Multiply(d:  val_5, a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            // 0x01683534: MOV v3.16b, v0.16b         | V3 = val_6.x;//m1                       
            // 0x01683538: MOV v4.16b, v1.16b         | V4 = val_6.y;//m1                       
            // 0x0168353C: MOV v5.16b, v2.16b         | V5 = val_6.z;//m1                       
            // 0x01683540: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683544: MOV v0.16b, v10.16b        | V0 = lineStart.x;//m1                   
            // 0x01683548: MOV v1.16b, v9.16b         | V1 = lineStart.y;//m1                   
            // 0x0168354C: MOV v2.16b, v8.16b         | V2 = lineStart.z;//m1                   
            // 0x01683550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683554: SUB sp, x29, #0x50         | SP = (1152921513157679712 - 80) = 1152921513157679632 (0x10000001FDAB5A10);
            // 0x01683558: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0168355C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01683560: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x01683564: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01683568: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x0168356C: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x01683570: B #0x2694984               | return UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
            return UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        
        }
        //
        // Offset in libil2cpp.so: 0x01683574 (23606644), len: 440  VirtAddr: 0x01683574 RVA: 0x01683574 token: 100681938 methodIndex: 49829 delegateWrapperIndex: 0 methodInvoker: 0
        public static float NearestPointFactor(UnityEngine.Vector3 lineStart, UnityEngine.Vector3 lineEnd, UnityEngine.Vector3 point)
        {
            //
            // Disasemble & Code
            //  | 
            float val_4;
            //  | 
            float val_7;
            //  | 
            float val_8;
            //  | 
            float val_9;
            //  | 
            float val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x01683574: STP d15, d14, [sp, #-0x60]! | stack[1152921513157791632] = ???;  stack[1152921513157791640] = ???;  //  dest_result_addr=1152921513157791632 |  dest_result_addr=1152921513157791640
            // 0x01683578: STP d13, d12, [sp, #0x10]  | stack[1152921513157791648] = ???;  stack[1152921513157791656] = ???;  //  dest_result_addr=1152921513157791648 |  dest_result_addr=1152921513157791656
            // 0x0168357C: STP d11, d10, [sp, #0x20]  | stack[1152921513157791664] = ???;  stack[1152921513157791672] = ???;  //  dest_result_addr=1152921513157791664 |  dest_result_addr=1152921513157791672
            // 0x01683580: STP d9, d8, [sp, #0x30]    | stack[1152921513157791680] = ???;  stack[1152921513157791688] = ???;  //  dest_result_addr=1152921513157791680 |  dest_result_addr=1152921513157791688
            // 0x01683584: STP x20, x19, [sp, #0x40]  | stack[1152921513157791696] = ???;  stack[1152921513157791704] = ???;  //  dest_result_addr=1152921513157791696 |  dest_result_addr=1152921513157791704
            // 0x01683588: STP x29, x30, [sp, #0x50]  | stack[1152921513157791712] = ???;  stack[1152921513157791720] = ???;  //  dest_result_addr=1152921513157791712 |  dest_result_addr=1152921513157791720
            // 0x0168358C: ADD x29, sp, #0x50         | X29 = (1152921513157791632 + 80) = 1152921513157791712 (0x10000001FDAD0FE0);
            // 0x01683590: SUB sp, sp, #0x10          | SP = (1152921513157791632 - 16) = 1152921513157791616 (0x10000001FDAD0F80);
            // 0x01683594: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01683598: LDRB w8, [x19, #0xd6]      | W8 = (bool)static_value_037380D6;       
            // 0x0168359C: MOV v11.16b, v5.16b        | V11 = lineEnd.z;//m1                    
            // 0x016835A0: MOV v12.16b, v4.16b        | V12 = lineEnd.y;//m1                    
            val_7 = lineEnd.y;
            // 0x016835A4: MOV v13.16b, v3.16b        | V13 = lineEnd.x;//m1                    
            // 0x016835A8: MOV v8.16b, v2.16b         | V8 = lineStart.z;//m1                   
            // 0x016835AC: MOV v9.16b, v1.16b         | V9 = lineStart.y;//m1                   
            // 0x016835B0: MOV v10.16b, v0.16b        | V10 = lineStart.x;//m1                  
            // 0x016835B4: TBNZ w8, #0, #0x16835d0    | if (static_value_037380D6 == true) goto label_0;
            // 0x016835B8: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x016835BC: LDR x8, [x8, #0x238]       | X8 = 0x2B8EC94;                         
            // 0x016835C0: LDR w0, [x8]               | W0 = 0x11E5;                            
            // 0x016835C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E5, ????);     
            // 0x016835C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016835CC: STRB w8, [x19, #0xd6]      | static_value_037380D6 = true;            //  dest_result_addr=57901270
            label_0:
            // 0x016835D0: ADRP x19, #0x3673000       | X19 = 57094144 (0x3673000);             
            // 0x016835D4: LDR x19, [x19, #0x488]     | X19 = 1152921504695078912;              
            // 0x016835D8: STR wzr, [sp, #8]          | stack[1152921513157791624] = 0x0;        //  dest_result_addr=1152921513157791624
            // 0x016835DC: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x016835E0: STR xzr, [sp]              | stack[1152921513157791616] = 0x0;        //  dest_result_addr=1152921513157791616
            // 0x016835E4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x016835E8: TBZ w8, #0, #0x16835f8     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016835EC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x016835F0: CBNZ w8, #0x16835f8        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016835F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x016835F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016835FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683600: MOV v0.16b, v13.16b        | V0 = lineEnd.x;//m1                     
            val_8 = lineEnd.x;
            // 0x01683604: MOV v1.16b, v12.16b        | V1 = lineEnd.y;//m1                     
            // 0x01683608: MOV v2.16b, v11.16b        | V2 = lineEnd.z;//m1                     
            val_9 = lineEnd.z;
            // 0x0168360C: MOV v3.16b, v10.16b        | V3 = lineStart.x;//m1                   
            // 0x01683610: MOV v4.16b, v9.16b         | V4 = lineStart.y;//m1                   
            // 0x01683614: MOV v5.16b, v8.16b         | V5 = lineStart.z;//m1                   
            // 0x01683618: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_8, y = val_7, z = val_9}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z});
            UnityEngine.Vector3 val_1 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_8, y = val_7, z = val_9}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z});
            // 0x0168361C: MOV x0, sp                 | X0 = 1152921513157791616 (0x10000001FDAD0F80);//ML01
            // 0x01683620: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683624: STP s0, s1, [sp]           | stack[1152921513157791616] = val_1.x;  stack[1152921513157791620] = val_1.y;  //  dest_result_addr=1152921513157791616 |  dest_result_addr=1152921513157791620
            // 0x01683628: STR s2, [sp, #8]           | stack[1152921513157791624] = val_1.z;    //  dest_result_addr=1152921513157791624
            // 0x0168362C: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
            // 0x01683630: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x01683634: LDR s1, [x8, #0xe8]        | S1 = 1.401298E-45;                      
            val_10 = 1.401298E-45f;
            // 0x01683638: MOV v11.16b, v0.16b        | V11 = val_1.x;//m1                      
            // 0x0168363C: FCMP s11, s1               | STATE = COMPARE(val_1.x, 1.40129846432482E-45)
            // 0x01683640: B.LE #0x1683684            | if (val_1.x <= val_10) goto label_3;    
            if(val_1.x <= val_10)
            {
                goto label_3;
            }
            // 0x01683644: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683648: LDP s14, s13, [sp]         | S14 = val_1.x; S13 = val_1.y;            //  | 
            // 0x0168364C: LDR s12, [sp, #8]          | S12 = val_1.z;                          
            val_7 = val_1.z;
            // 0x01683650: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01683654: TBZ w8, #0, #0x1683664     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01683658: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0168365C: CBNZ w8, #0x1683664        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01683660: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_5:
            // 0x01683664: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683668: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168366C: MOV v0.16b, v14.16b        | V0 = val_1.x;//m1                       
            val_8 = val_1.x;
            // 0x01683670: MOV v1.16b, v13.16b        | V1 = val_1.y;//m1                       
            val_10 = val_1.y;
            // 0x01683674: MOV v2.16b, v12.16b        | V2 = val_1.z;//m1                       
            val_9 = val_7;
            // 0x01683678: MOV v3.16b, v11.16b        | V3 = val_1.x;//m1                       
            // 0x0168367C: BL #0x2699130              | X0 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_8, y = val_10, z = val_9}, d:  val_1.x);
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_8, y = val_10, z = val_9}, d:  val_1.x);
            // 0x01683680: B #0x16836a8               |  goto label_6;                          
            goto label_6;
            label_3:
            // 0x01683684: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683688: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x0168368C: TBZ w8, #0, #0x168369c     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01683690: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01683694: CBNZ w8, #0x168369c        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01683698: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_8:
            // 0x0168369C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016836A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016836A4: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.zero;
            label_6:
            // 0x016836A8: LDP s13, s12, [x29, #0x14] | S13 = val_4; S12 = point.y;              //  find_add[1152921513157779728] | 
            // 0x016836AC: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x016836B0: LDR s14, [x29, #0x10]      | S14 = point.x;                          
            // 0x016836B4: STP s0, s1, [sp]           | stack[1152921513157791616] = val_3.x;  stack[1152921513157791620] = val_3.y;  //  dest_result_addr=1152921513157791616 |  dest_result_addr=1152921513157791620
            // 0x016836B8: STR s2, [sp, #8]           | stack[1152921513157791624] = val_3.z;    //  dest_result_addr=1152921513157791624
            // 0x016836BC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x016836C0: TBZ w8, #0, #0x16836d0     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x016836C4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x016836C8: CBNZ w8, #0x16836d0        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x016836CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_10:
            // 0x016836D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016836D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016836D8: MOV v0.16b, v14.16b        | V0 = point.x;//m1                       
            // 0x016836DC: MOV v1.16b, v13.16b        | V1 = val_4;//m1                         
            // 0x016836E0: MOV v2.16b, v12.16b        | V2 = point.y;//m1                       
            // 0x016836E4: MOV v3.16b, v10.16b        | V3 = lineStart.x;//m1                   
            // 0x016836E8: MOV v4.16b, v9.16b         | V4 = lineStart.y;//m1                   
            // 0x016836EC: MOV v5.16b, v8.16b         | V5 = lineStart.z;//m1                   
            // 0x016836F0: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = point.x, y = val_4, z = point.y}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z});
            UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = point.x, y = val_4, z = point.y}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = lineStart.y, z = lineStart.z});
            // 0x016836F4: LDP s3, s4, [sp]           | S3 = val_3.x; S4 = val_3.y;              //  | 
            // 0x016836F8: LDR s5, [sp, #8]           | S5 = val_3.z;                           
            // 0x016836FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683700: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683704: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, rhs:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            float val_6 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, rhs:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            // 0x01683708: FDIV s0, s0, s11           | S0 = (val_6 / val_1.x);                 
            val_6 = val_6 / val_1.x;
            // 0x0168370C: SUB sp, x29, #0x50         | SP = (1152921513157791712 - 80) = 1152921513157791632 (0x10000001FDAD0F90);
            // 0x01683710: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01683714: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01683718: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x0168371C: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01683720: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01683724: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x01683728: RET                        |  return (System.Single)(val_6 / val_1.x);
            return (float)val_6;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168372C (23607084), len: 296  VirtAddr: 0x0168372C RVA: 0x0168372C token: 100681939 methodIndex: 49830 delegateWrapperIndex: 0 methodInvoker: 0
        public static float NearestPointFactor(Pathfinding.Int3 lineStart, Pathfinding.Int3 lineEnd, Pathfinding.Int3 point)
        {
            //
            // Disasemble & Code
            // 0x0168372C: STP d9, d8, [sp, #-0x60]!  | stack[1152921513157903632] = ???;  stack[1152921513157903640] = ???;  //  dest_result_addr=1152921513157903632 |  dest_result_addr=1152921513157903640
            // 0x01683730: STP x26, x25, [sp, #0x10]  | stack[1152921513157903648] = ???;  stack[1152921513157903656] = ???;  //  dest_result_addr=1152921513157903648 |  dest_result_addr=1152921513157903656
            // 0x01683734: STP x24, x23, [sp, #0x20]  | stack[1152921513157903664] = ???;  stack[1152921513157903672] = ???;  //  dest_result_addr=1152921513157903664 |  dest_result_addr=1152921513157903672
            // 0x01683738: STP x22, x21, [sp, #0x30]  | stack[1152921513157903680] = ???;  stack[1152921513157903688] = ???;  //  dest_result_addr=1152921513157903680 |  dest_result_addr=1152921513157903688
            // 0x0168373C: STP x20, x19, [sp, #0x40]  | stack[1152921513157903696] = ???;  stack[1152921513157903704] = ???;  //  dest_result_addr=1152921513157903696 |  dest_result_addr=1152921513157903704
            // 0x01683740: STP x29, x30, [sp, #0x50]  | stack[1152921513157903712] = ???;  stack[1152921513157903720] = ???;  //  dest_result_addr=1152921513157903712 |  dest_result_addr=1152921513157903720
            // 0x01683744: ADD x29, sp, #0x50         | X29 = (1152921513157903632 + 80) = 1152921513157903712 (0x10000001FDAEC560);
            // 0x01683748: SUB sp, sp, #0x10          | SP = (1152921513157903632 - 16) = 1152921513157903616 (0x10000001FDAEC500);
            // 0x0168374C: ADRP x25, #0x3738000       | X25 = 57901056 (0x3738000);             
            // 0x01683750: LDRB w8, [x25, #0xd7]      | W8 = (bool)static_value_037380D7;       
            // 0x01683754: MOV x20, x6                | X20 = X6;//m1                           
            // 0x01683758: MOV x19, x5                | X19 = point.z;//m1                      
            // 0x0168375C: MOV x24, x4                | X24 = point.x;//m1                      
            // 0x01683760: MOV x22, x3                | X22 = lineEnd.z;//m1                    
            // 0x01683764: MOV x23, x2                | X23 = lineEnd.x;//m1                    
            int val_8 = lineEnd.x;
            // 0x01683768: MOV x21, x1                | X21 = lineStart.z;//m1                  
            // 0x0168376C: TBNZ w8, #0, #0x1683788    | if (static_value_037380D7 == true) goto label_0;
            // 0x01683770: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x01683774: LDR x8, [x8, #0x418]       | X8 = 0x2B8EC90;                         
            // 0x01683778: LDR w0, [x8]               | W0 = 0x11E4;                            
            // 0x0168377C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E4, ????);     
            // 0x01683780: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01683784: STRB w8, [x25, #0xd7]      | static_value_037380D7 = true;            //  dest_result_addr=57901271
            label_0:
            // 0x01683788: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x0168378C: LDR x8, [x8, #0x540]       | X8 = 1152921504839380992;               
            // 0x01683790: STR wzr, [sp, #8]          | stack[1152921513157903624] = 0x0;        //  dest_result_addr=1152921513157903624
            // 0x01683794: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int3);          
            // 0x01683798: STR xzr, [sp]              | stack[1152921513157903616] = 0x0;        //  dest_result_addr=1152921513157903616
            // 0x0168379C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x016837A0: TBZ w8, #0, #0x16837b0     | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016837A4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x016837A8: CBNZ w8, #0x16837b0        | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016837AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_2:
            // 0x016837B0: AND x23, x23, #0xffffffff  | X23 = (lineEnd.x & 4294967295);         
            val_8 = val_8 & 4294967295;
            // 0x016837B4: AND x2, x24, #0xffffffff   | X2 = (point.x & 4294967295);            
            int val_1 = point.x & 4294967295;
            // 0x016837B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016837BC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x016837C0: MOV x1, x22                | X1 = lineEnd.z;//m1                     
            // 0x016837C4: MOV x3, x21                | X3 = lineStart.z;//m1                   
            // 0x016837C8: MOV x4, x23                | X4 = (lineEnd.x & 4294967295);//m1      
            // 0x016837CC: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = lineEnd.z}, rhs:  new Pathfinding.Int3() {x = val_1, y = val_1, z = lineStart.z});
            Pathfinding.Int3 val_2 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = lineEnd.z}, rhs:  new Pathfinding.Int3() {x = val_1, y = val_1, z = lineStart.z});
            // 0x016837D0: STR x0, [sp]               | stack[1152921513157903616] = val_2.x; stack[1152921513157903620] = val_2.y;  //  dest_result_addr=1152921513157903616 dest_result_addr=1152921513157903620
            // 0x016837D4: STR w1, [sp, #8]           | stack[1152921513157903624] = val_2.z;    //  dest_result_addr=1152921513157903624
            // 0x016837D8: MOV x0, sp                 | X0 = 1152921513157903616 (0x10000001FDAEC500);//ML01
            // 0x016837DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016837E0: BL #0x1549e98              | X0 = label_Pathfinding_Int3_get_worldMagnitude_GL01549E98();
            // 0x016837E4: AND x2, x20, #0xffffffff   | X2 = (X6 & 4294967295);                 
            int val_3 = X6 & 4294967295;
            // 0x016837E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016837EC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x016837F0: MOV x1, x19                | X1 = point.z;//m1                       
            // 0x016837F4: MOV x3, x21                | X3 = lineStart.z;//m1                   
            // 0x016837F8: MOV x4, x23                | X4 = (lineEnd.x & 4294967295);//m1      
            // 0x016837FC: MOV v8.16b, v0.16b         | V8 = V0.16B;//m1                        
            // 0x01683800: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = point.z}, rhs:  new Pathfinding.Int3() {x = val_3, y = val_3, z = lineStart.z});
            Pathfinding.Int3 val_4 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = point.z}, rhs:  new Pathfinding.Int3() {x = val_3, y = val_3, z = lineStart.z});
            // 0x01683804: LDR x3, [sp]               | X3 = val_2.x;                           
            // 0x01683808: LDR w4, [sp, #8]           | W4 = val_2.z;                           
            // 0x0168380C: MOV x6, x0                 | X6 = val_4.x;//m1                       
            // 0x01683810: AND x2, x1, #0xffffffff    | X2 = (val_4.z & 4294967295);            
            int val_5 = val_4.z & 4294967295;
            // 0x01683814: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683818: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0168381C: MOV x1, x6                 | X1 = val_4.x;//m1                       
            // 0x01683820: BL #0x1549a7c              | X0 = Pathfinding.Int3.Dot(lhs:  new Pathfinding.Int3() {z = val_4.x}, rhs:  new Pathfinding.Int3() {x = val_5, y = val_5, z = val_2.x});
            int val_6 = Pathfinding.Int3.Dot(lhs:  new Pathfinding.Int3() {z = val_4.x}, rhs:  new Pathfinding.Int3() {x = val_5, y = val_5, z = val_2.x});
            // 0x01683824: SCVTF s0, w0               | S0 = (float)(val_6);                    
            float val_9 = (float)val_6;
            // 0x01683828: FDIV s1, s0, s8            | S1 = (val_6 / V0.16B);                  
            float val_7 = val_9 / V0.16B;
            // 0x0168382C: FCMP s8, #0.0              | STATE = COMPARE(V0.16B, 0)              
            // 0x01683830: FCSEL s0, s1, s0, ne       | S0 = V0.16B != 0 ? (val_6 / V0.16B) : val_6;
            val_9 = (V0.16B != 0f) ? (val_7) : (val_9);
            // 0x01683834: SUB sp, x29, #0x50         | SP = (1152921513157903712 - 80) = 1152921513157903632 (0x10000001FDAEC510);
            // 0x01683838: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0168383C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01683840: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01683844: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01683848: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0168384C: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
            // 0x01683850: RET                        |  return (System.Single)V0.16B != 0 ? (val_6 / V0.16B) : val_6;
            return (float)val_9;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01683854 (23607380), len: 180  VirtAddr: 0x01683854 RVA: 0x01683854 token: 100681940 methodIndex: 49831 delegateWrapperIndex: 0 methodInvoker: 0
        public static float NearestPointFactor(Pathfinding.Int2 lineStart, Pathfinding.Int2 lineEnd, Pathfinding.Int2 point)
        {
            //
            // Disasemble & Code
            // 0x01683854: STP x22, x21, [sp, #-0x30]! | stack[1152921513158015680] = ???;  stack[1152921513158015688] = ???;  //  dest_result_addr=1152921513158015680 |  dest_result_addr=1152921513158015688
            // 0x01683858: STP x20, x19, [sp, #0x10]  | stack[1152921513158015696] = ???;  stack[1152921513158015704] = ???;  //  dest_result_addr=1152921513158015696 |  dest_result_addr=1152921513158015704
            // 0x0168385C: STP x29, x30, [sp, #0x20]  | stack[1152921513158015712] = ???;  stack[1152921513158015720] = ???;  //  dest_result_addr=1152921513158015712 |  dest_result_addr=1152921513158015720
            // 0x01683860: ADD x29, sp, #0x20         | X29 = (1152921513158015680 + 32) = 1152921513158015712 (0x10000001FDB07AE0);
            // 0x01683864: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x01683868: LDRB w8, [x22, #0xd8]      | W8 = (bool)static_value_037380D8;       
            // 0x0168386C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x01683870: MOV x20, x2                | X20 = point.x;//m1                      
            // 0x01683874: MOV x21, x1                | X21 = lineEnd.x;//m1                    
            // 0x01683878: TBNZ w8, #0, #0x1683894    | if (static_value_037380D8 == true) goto label_0;
            // 0x0168387C: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x01683880: LDR x8, [x8, #0xf10]       | X8 = 0x2B8EC8C;                         
            // 0x01683884: LDR w0, [x8]               | W0 = 0x11E3;                            
            // 0x01683888: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E3, ????);     
            // 0x0168388C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01683890: STRB w8, [x22, #0xd8]      | static_value_037380D8 = true;            //  dest_result_addr=57901272
            label_0:
            // 0x01683894: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x01683898: LDR x8, [x8, #0xc50]       | X8 = 1152921504839434240;               
            // 0x0168389C: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int2);          
            // 0x016838A0: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int2.__il2cppRuntimeField_10A;
            // 0x016838A4: TBZ w8, #0, #0x16838b4     | if (Pathfinding.Int2.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016838A8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int2.__il2cppRuntimeField_cctor_finished;
            // 0x016838AC: CBNZ w8, #0x16838b4        | if (Pathfinding.Int2.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016838B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int2), ????);
            label_2:
            // 0x016838B4: AND x8, x21, #0xffffffff00000000 | X8 = (lineEnd.x & -4294967296);         
            int val_1 = lineEnd.x & (-4294967296);
            // 0x016838B8: SUB x11, x20, x8           | X11 = (point.x - (lineEnd.x & -4294967296));
            int val_2 = point.x - val_1;
            // 0x016838BC: SUB x8, x19, x8            | X8 = (X3 - (lineEnd.x & -4294967296));  
            val_1 = X3 - val_1;
            // 0x016838C0: ASR x11, x11, #0x20        | X11 = ((point.x - (lineEnd.x & -4294967296)) >> 32);
            val_2 = val_2 >> 32;
            // 0x016838C4: ASR x8, x8, #0x20          | X8 = ((X3 - (lineEnd.x & -4294967296)) >> 32);
            val_1 = val_1 >> 32;
            // 0x016838C8: SUB w9, w20, w21           | W9 = (point.x - lineEnd.x);             
            int val_3 = point.x - lineEnd.x;
            // 0x016838CC: SUB w10, w19, w21          | W10 = (X3 - lineEnd.x);                 
            int val_4 = X3 - lineEnd.x;
            // 0x016838D0: MUL x12, x11, x11          | X12 = (((point.x - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)
            int val_5 = val_2 * val_2;
            // 0x016838D4: MUL x8, x8, x11            | X8 = (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32));
            val_1 = val_1 * val_2;
            // 0x016838D8: SMADDL x11, w9, w9, x12    | X11 = ((point.x - lineEnd.x) * (point.x - lineEnd.x)) + (((point.x - (lineEnd.x & -4294967296)) >> 3
            val_2 = val_5 + (val_3 * val_3);
            // 0x016838DC: SMADDL x8, w10, w9, x8     | X8 = ((X3 - lineEnd.x) * (point.x - lineEnd.x)) + (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((poin
            val_1 = val_1 + (val_4 * val_3);
            // 0x016838E0: SCVTF d0, x11              | D0 = (double)(((point.x - lineEnd.x) * (point.x - lineEnd.x)) + (((point.x - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)));
            double val_7 = (double)val_2;
            // 0x016838E4: SCVTF d1, x8               | D1 = (double)(((X3 - lineEnd.x) * (point.x - lineEnd.x)) + (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)));
            // 0x016838E8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x016838EC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x016838F0: FDIV d0, d1, d0            | D0 = (((X3 - lineEnd.x) * (point.x - lineEnd.x)) + (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)) / ((point.x - lineEnd.x) * (point.x - lineEnd.x)) + (((point.x - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)));
            val_7 = (double)val_1 / val_7;
            // 0x016838F4: CMP x11, #0                | STATE = COMPARE(((point.x - lineEnd.x) * (point.x - lineEnd.x)) + (((point.x - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)), 0x0)
            // 0x016838F8: FCSEL d0, d1, d0, eq       | D0 = val_2 == 0 ? ((X3 - lineEnd.x) * (point.x - lineEnd.x)) + (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)) : (((X3 - lineEnd.x) * (point.x - lineEnd.x)) + (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)) / ((point.x - lineEnd.x) * (point.x - lineEnd.x)) + (((point.x - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)));
            var val_6 = (val_2 == 0) ? ((double)val_1) : (val_7);
            // 0x016838FC: FCVT s0, d0                | S0 = (float)val_2 == 0 ? ((X3 - lineEnd.x) * (point.x - lineEnd.x)) + (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)) : (((X3 - lineEnd.x) * (point.x - lineEnd.x)) + (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)) / ((point.x - lineEnd.x) * (point.x - lineEnd.x)) + (((point.x - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32))));
            // 0x01683900: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01683904: RET                        |  return (System.Single)val_2 == 0 ? ((X3 - lineEnd.x) * (point.x - lineEnd.x)) + (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)) : (((X3 - lineEnd.x) * (point.x - lineEnd.x)) + (((X3 - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)) / ((point.x - lineEnd.x) * (point.x - lineEnd.x)) + (((point.x - (lineEnd.x & -4294967296)) >> 32) * ((point.x - (lineEnd.x & -4294967296)) >> 32)));
            return (float)val_6;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168393C (23607612), len: 580  VirtAddr: 0x0168393C RVA: 0x0168393C token: 100681941 methodIndex: 49832 delegateWrapperIndex: 0 methodInvoker: 0
        public static UnityEngine.Vector3 NearestPointStrict(UnityEngine.Vector3 lineStart, UnityEngine.Vector3 lineEnd, UnityEngine.Vector3 point)
        {
            //
            // Disasemble & Code
            //  | 
            float val_4;
            //  | 
            float val_10;
            //  | 
            float val_11;
            //  | 
            float val_12;
            //  | 
            float val_13;
            //  | 
            float val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x0168393C: STP d15, d14, [sp, #-0x60]! | stack[1152921513158127632] = ???;  stack[1152921513158127640] = ???;  //  dest_result_addr=1152921513158127632 |  dest_result_addr=1152921513158127640
            // 0x01683940: STP d13, d12, [sp, #0x10]  | stack[1152921513158127648] = ???;  stack[1152921513158127656] = ???;  //  dest_result_addr=1152921513158127648 |  dest_result_addr=1152921513158127656
            // 0x01683944: STP d11, d10, [sp, #0x20]  | stack[1152921513158127664] = ???;  stack[1152921513158127672] = ???;  //  dest_result_addr=1152921513158127664 |  dest_result_addr=1152921513158127672
            // 0x01683948: STP d9, d8, [sp, #0x30]    | stack[1152921513158127680] = ???;  stack[1152921513158127688] = ???;  //  dest_result_addr=1152921513158127680 |  dest_result_addr=1152921513158127688
            // 0x0168394C: STP x20, x19, [sp, #0x40]  | stack[1152921513158127696] = ???;  stack[1152921513158127704] = ???;  //  dest_result_addr=1152921513158127696 |  dest_result_addr=1152921513158127704
            // 0x01683950: STP x29, x30, [sp, #0x50]  | stack[1152921513158127712] = ???;  stack[1152921513158127720] = ???;  //  dest_result_addr=1152921513158127712 |  dest_result_addr=1152921513158127720
            // 0x01683954: ADD x29, sp, #0x50         | X29 = (1152921513158127632 + 80) = 1152921513158127712 (0x10000001FDB23060);
            // 0x01683958: SUB sp, sp, #0x20          | SP = (1152921513158127632 - 32) = 1152921513158127600 (0x10000001FDB22FF0);
            // 0x0168395C: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01683960: LDRB w8, [x19, #0xd9]      | W8 = (bool)static_value_037380D9;       
            // 0x01683964: MOV v11.16b, v5.16b        | V11 = lineEnd.z;//m1                    
            // 0x01683968: MOV v12.16b, v4.16b        | V12 = lineEnd.y;//m1                    
            // 0x0168396C: MOV v13.16b, v3.16b        | V13 = lineEnd.x;//m1                    
            // 0x01683970: MOV v8.16b, v2.16b         | V8 = lineStart.z;//m1                   
            // 0x01683974: MOV v9.16b, v1.16b         | V9 = lineStart.y;//m1                   
            // 0x01683978: MOV v10.16b, v0.16b        | V10 = lineStart.x;//m1                  
            // 0x0168397C: TBNZ w8, #0, #0x1683998    | if (static_value_037380D9 == true) goto label_0;
            // 0x01683980: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x01683984: LDR x8, [x8, #0x830]       | X8 = 0x2B8EC98;                         
            // 0x01683988: LDR w0, [x8]               | W0 = 0x11E6;                            
            // 0x0168398C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E6, ????);     
            // 0x01683990: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01683994: STRB w8, [x19, #0xd9]      | static_value_037380D9 = true;            //  dest_result_addr=57901273
            label_0:
            // 0x01683998: ADRP x19, #0x3673000       | X19 = 57094144 (0x3673000);             
            // 0x0168399C: LDR x19, [x19, #0x488]     | X19 = 1152921504695078912;              
            // 0x016839A0: STR wzr, [sp, #0x18]       | stack[1152921513158127624] = 0x0;        //  dest_result_addr=1152921513158127624
            // 0x016839A4: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x016839A8: STR xzr, [sp, #0x10]       | stack[1152921513158127616] = 0x0;        //  dest_result_addr=1152921513158127616
            // 0x016839AC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x016839B0: TBZ w8, #0, #0x16839c0     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016839B4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x016839B8: CBNZ w8, #0x16839c0        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016839BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x016839C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016839C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016839C8: MOV v0.16b, v13.16b        | V0 = lineEnd.x;//m1                     
            val_10 = lineEnd.x;
            // 0x016839CC: MOV v1.16b, v12.16b        | V1 = lineEnd.y;//m1                     
            // 0x016839D0: MOV v2.16b, v11.16b        | V2 = lineEnd.z;//m1                     
            val_11 = lineEnd.z;
            // 0x016839D4: MOV v3.16b, v10.16b        | V3 = lineStart.x;//m1                   
            val_12 = lineStart.x;
            // 0x016839D8: MOV v4.16b, v9.16b         | V4 = lineStart.y;//m1                   
            // 0x016839DC: MOV v5.16b, v8.16b         | V5 = lineStart.z;//m1                   
            // 0x016839E0: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10, y = lineEnd.y, z = val_11}, b:  new UnityEngine.Vector3() {x = val_12, y = lineStart.y, z = lineStart.z});
            UnityEngine.Vector3 val_1 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10, y = lineEnd.y, z = val_11}, b:  new UnityEngine.Vector3() {x = val_12, y = lineStart.y, z = lineStart.z});
            // 0x016839E4: ADD x0, sp, #0x10          | X0 = (1152921513158127600 + 16) = 1152921513158127616 (0x10000001FDB23000);
            // 0x016839E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016839EC: STP s0, s1, [sp, #0x10]    | stack[1152921513158127616] = val_1.x;  stack[1152921513158127620] = val_1.y;  //  dest_result_addr=1152921513158127616 |  dest_result_addr=1152921513158127620
            // 0x016839F0: STR s2, [sp, #0x18]        | stack[1152921513158127624] = val_1.z;    //  dest_result_addr=1152921513158127624
            // 0x016839F4: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
            // 0x016839F8: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x016839FC: LDR s1, [x8, #0xe8]        | S1 = 1.401298E-45;                      
            val_13 = 1.401298E-45f;
            // 0x01683A00: MOV v11.16b, v0.16b        | V11 = val_1.x;//m1                      
            // 0x01683A04: FCMP s11, s1               | STATE = COMPARE(val_1.x, 1.40129846432482E-45)
            // 0x01683A08: B.LE #0x1683a54            | if (val_1.x <= val_13) goto label_3;    
            if(val_1.x <= val_13)
            {
                goto label_3;
            }
            // 0x01683A0C: STP s8, s10, [sp, #8]      | stack[1152921513158127608] = lineStart.z;  stack[1152921513158127612] = lineStart.x;  //  dest_result_addr=1152921513158127608 |  dest_result_addr=1152921513158127612
            // 0x01683A10: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683A14: LDP s8, s13, [sp, #0x10]   | S8 = val_1.x; S13 = val_1.y;             //  | 
            // 0x01683A18: LDR s12, [sp, #0x18]       | S12 = val_1.z;                          
            // 0x01683A1C: MOV v10.16b, v9.16b        | V10 = lineStart.y;//m1                  
            val_14 = lineStart.y;
            // 0x01683A20: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01683A24: TBZ w8, #0, #0x1683a34     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01683A28: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01683A2C: CBNZ w8, #0x1683a34        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01683A30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_5:
            // 0x01683A34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683A3C: MOV v0.16b, v8.16b         | V0 = val_1.x;//m1                       
            val_10 = val_1.x;
            // 0x01683A40: MOV v1.16b, v13.16b        | V1 = val_1.y;//m1                       
            val_13 = val_1.y;
            // 0x01683A44: MOV v2.16b, v12.16b        | V2 = val_1.z;//m1                       
            val_11 = val_1.z;
            // 0x01683A48: MOV v3.16b, v11.16b        | V3 = val_1.x;//m1                       
            val_12 = val_1.x;
            // 0x01683A4C: BL #0x2699130              | X0 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_10, y = val_13, z = val_11}, d:  val_12 = val_1.x);
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_10, y = val_13, z = val_11}, d:  val_12);
            // 0x01683A50: B #0x1683a80               |  goto label_6;                          
            goto label_6;
            label_3:
            // 0x01683A54: STP s8, s10, [sp, #8]      | stack[1152921513158127608] = lineStart.z;  stack[1152921513158127612] = lineStart.x;  //  dest_result_addr=1152921513158127608 |  dest_result_addr=1152921513158127612
            // 0x01683A58: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683A5C: MOV v10.16b, v9.16b        | V10 = lineStart.y;//m1                  
            val_14 = lineStart.y;
            // 0x01683A60: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01683A64: TBZ w8, #0, #0x1683a74     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01683A68: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01683A6C: CBNZ w8, #0x1683a74        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01683A70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_8:
            // 0x01683A74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683A78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683A7C: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.zero;
            label_6:
            // 0x01683A80: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683A84: LDP s8, s15, [x29, #0x14]  | S8 = val_4; S15 = point.y;               //  find_add[1152921513158115728] | 
            // 0x01683A88: LDR s9, [x29, #0x10]       | S9 = point.x;                           
            // 0x01683A8C: MOV v12.16b, v0.16b        | V12 = val_3.x;//m1                      
            // 0x01683A90: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01683A94: MOV v13.16b, v1.16b        | V13 = val_3.y;//m1                      
            // 0x01683A98: MOV v14.16b, v2.16b        | V14 = val_3.z;//m1                      
            // 0x01683A9C: TBZ w8, #0, #0x1683aac     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x01683AA0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01683AA4: CBNZ w8, #0x1683aac        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x01683AA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_10:
            // 0x01683AAC: MOV v0.16b, v9.16b         | V0 = point.x;//m1                       
            // 0x01683AB0: LDP s9, s3, [sp, #8]       | S9 = lineStart.z; S3 = lineStart.x;      //  | 
            // 0x01683AB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683AB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683ABC: MOV v1.16b, v8.16b         | V1 = val_4;//m1                         
            // 0x01683AC0: MOV v2.16b, v15.16b        | V2 = point.y;//m1                       
            // 0x01683AC4: MOV v4.16b, v10.16b        | V4 = lineStart.y;//m1                   
            // 0x01683AC8: MOV v5.16b, v9.16b         | V5 = lineStart.z;//m1                   
            // 0x01683ACC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = point.x, y = val_4, z = point.y}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = val_14, z = lineStart.z});
            UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = point.x, y = val_4, z = point.y}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = val_14, z = lineStart.z});
            // 0x01683AD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683AD8: MOV v3.16b, v12.16b        | V3 = val_3.x;//m1                       
            // 0x01683ADC: MOV v4.16b, v13.16b        | V4 = val_3.y;//m1                       
            // 0x01683AE0: MOV v5.16b, v14.16b        | V5 = val_3.z;//m1                       
            // 0x01683AE4: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, rhs:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            float val_6 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, rhs:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            // 0x01683AE8: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x01683AEC: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x01683AF0: MOV v8.16b, v0.16b         | V8 = val_6;//m1                         
            // 0x01683AF4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x01683AF8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x01683AFC: TBZ w8, #0, #0x1683b0c     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x01683B00: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x01683B04: CBNZ w8, #0x1683b0c        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x01683B08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_12:
            // 0x01683B0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683B14: FMOV s1, wzr               | S1 = 0f;                                
            // 0x01683B18: MOV v0.16b, v8.16b         | V0 = val_6;//m1                         
            // 0x01683B1C: MOV v2.16b, v11.16b        | V2 = val_1.x;//m1                       
            // 0x01683B20: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  val_6, min:  0f, max:  val_1.x);
            float val_7 = UnityEngine.Mathf.Clamp(value:  val_6, min:  0f, max:  val_1.x);
            // 0x01683B24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683B28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683B2C: MOV v1.16b, v12.16b        | V1 = val_3.x;//m1                       
            // 0x01683B30: MOV v2.16b, v13.16b        | V2 = val_3.y;//m1                       
            // 0x01683B34: MOV v3.16b, v14.16b        | V3 = val_3.z;//m1                       
            // 0x01683B38: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  float val_7 = UnityEngine.Mathf.Clamp(value:  val_6, min:  0f, max:  val_1.x), a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Multiply(d:  val_7, a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            // 0x01683B3C: MOV v3.16b, v0.16b         | V3 = val_8.x;//m1                       
            // 0x01683B40: LDR s0, [sp, #0xc]         | S0 = lineStart.x;                       
            // 0x01683B44: MOV v4.16b, v1.16b         | V4 = val_8.y;//m1                       
            // 0x01683B48: MOV v5.16b, v2.16b         | V5 = val_8.z;//m1                       
            // 0x01683B4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683B50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683B54: MOV v1.16b, v10.16b        | V1 = lineStart.y;//m1                   
            // 0x01683B58: MOV v2.16b, v9.16b         | V2 = lineStart.z;//m1                   
            // 0x01683B5C: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = lineStart.x, y = val_14, z = lineStart.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
            UnityEngine.Vector3 val_9 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = lineStart.x, y = val_14, z = lineStart.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
            // 0x01683B60: SUB sp, x29, #0x50         | SP = (1152921513158127712 - 80) = 1152921513158127632 (0x10000001FDB23010);
            // 0x01683B64: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01683B68: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01683B6C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x01683B70: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01683B74: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01683B78: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x01683B7C: RET                        |  return new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z};
            return new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z};
            //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01683B80 (23608192), len: 580  VirtAddr: 0x01683B80 RVA: 0x01683B80 token: 100681942 methodIndex: 49833 delegateWrapperIndex: 0 methodInvoker: 0
        public static UnityEngine.Vector3 NearestPointStrictXZ(UnityEngine.Vector3 lineStart, UnityEngine.Vector3 lineEnd, UnityEngine.Vector3 point)
        {
            //
            // Disasemble & Code
            //  | 
            float val_1;
            //  | 
            float val_10;
            //  | 
            float val_11;
            //  | 
            float val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            // 0x01683B80: STP d15, d14, [sp, #-0x60]! | stack[1152921513158239632] = ???;  stack[1152921513158239640] = ???;  //  dest_result_addr=1152921513158239632 |  dest_result_addr=1152921513158239640
            // 0x01683B84: STP d13, d12, [sp, #0x10]  | stack[1152921513158239648] = ???;  stack[1152921513158239656] = ???;  //  dest_result_addr=1152921513158239648 |  dest_result_addr=1152921513158239656
            // 0x01683B88: STP d11, d10, [sp, #0x20]  | stack[1152921513158239664] = ???;  stack[1152921513158239672] = ???;  //  dest_result_addr=1152921513158239664 |  dest_result_addr=1152921513158239672
            // 0x01683B8C: STP d9, d8, [sp, #0x30]    | stack[1152921513158239680] = ???;  stack[1152921513158239688] = ???;  //  dest_result_addr=1152921513158239680 |  dest_result_addr=1152921513158239688
            // 0x01683B90: STP x20, x19, [sp, #0x40]  | stack[1152921513158239696] = ???;  stack[1152921513158239704] = ???;  //  dest_result_addr=1152921513158239696 |  dest_result_addr=1152921513158239704
            // 0x01683B94: STP x29, x30, [sp, #0x50]  | stack[1152921513158239712] = ???;  stack[1152921513158239720] = ???;  //  dest_result_addr=1152921513158239712 |  dest_result_addr=1152921513158239720
            // 0x01683B98: ADD x29, sp, #0x50         | X29 = (1152921513158239632 + 80) = 1152921513158239712 (0x10000001FDB3E5E0);
            // 0x01683B9C: SUB sp, sp, #0x10          | SP = (1152921513158239632 - 16) = 1152921513158239616 (0x10000001FDB3E580);
            // 0x01683BA0: LDR s9, [x29, #0x14]       | S9 = val_1;                              //  find_add[1152921513158227728]
            // 0x01683BA4: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01683BA8: LDRB w8, [x19, #0xda]      | W8 = (bool)static_value_037380DA;       
            // 0x01683BAC: MOV v11.16b, v5.16b        | V11 = lineEnd.z;//m1                    
            // 0x01683BB0: MOV v12.16b, v3.16b        | V12 = lineEnd.x;//m1                    
            // 0x01683BB4: MOV v8.16b, v2.16b         | V8 = lineStart.z;//m1                   
            // 0x01683BB8: MOV v10.16b, v0.16b        | V10 = lineStart.x;//m1                  
            // 0x01683BBC: TBNZ w8, #0, #0x1683bd8    | if (static_value_037380DA == true) goto label_0;
            // 0x01683BC0: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x01683BC4: LDR x8, [x8, #0xfa0]       | X8 = 0x2B8EC9C;                         
            // 0x01683BC8: LDR w0, [x8]               | W0 = 0x11E7;                            
            // 0x01683BCC: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E7, ????);     
            // 0x01683BD0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01683BD4: STRB w8, [x19, #0xda]      | static_value_037380DA = true;            //  dest_result_addr=57901274
            label_0:
            // 0x01683BD8: ADRP x19, #0x3673000       | X19 = 57094144 (0x3673000);             
            // 0x01683BDC: LDR x19, [x19, #0x488]     | X19 = 1152921504695078912;              
            // 0x01683BE0: STR wzr, [sp, #8]          | stack[1152921513158239624] = 0x0;        //  dest_result_addr=1152921513158239624
            // 0x01683BE4: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683BE8: STR xzr, [sp]              | stack[1152921513158239616] = 0x0;        //  dest_result_addr=1152921513158239616
            // 0x01683BEC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01683BF0: TBZ w8, #0, #0x1683c00     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01683BF4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01683BF8: CBNZ w8, #0x1683c00        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01683BFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x01683C00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683C08: MOV v0.16b, v12.16b        | V0 = lineEnd.x;//m1                     
            val_10 = lineEnd.x;
            // 0x01683C0C: MOV v1.16b, v9.16b         | V1 = val_1;//m1                         
            // 0x01683C10: MOV v2.16b, v11.16b        | V2 = lineEnd.z;//m1                     
            val_11 = lineEnd.z;
            // 0x01683C14: MOV v3.16b, v10.16b        | V3 = lineStart.x;//m1                   
            // 0x01683C18: MOV v4.16b, v9.16b         | V4 = val_1;//m1                         
            // 0x01683C1C: MOV v5.16b, v8.16b         | V5 = lineStart.z;//m1                   
            // 0x01683C20: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10, y = val_1, z = val_11}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = val_1, z = lineStart.z});
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10, y = val_1, z = val_11}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = val_1, z = lineStart.z});
            // 0x01683C24: MOV x0, sp                 | X0 = 1152921513158239616 (0x10000001FDB3E580);//ML01
            // 0x01683C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683C2C: STR s0, [sp]               | stack[1152921513158239616] = val_2.x;    //  dest_result_addr=1152921513158239616
            // 0x01683C30: STR s2, [sp, #8]           | stack[1152921513158239624] = val_2.z;    //  dest_result_addr=1152921513158239624
            // 0x01683C34: STR wzr, [sp, #4]          | stack[1152921513158239620] = 0x0;        //  dest_result_addr=1152921513158239620
            // 0x01683C38: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
            // 0x01683C3C: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x01683C40: LDR s1, [x8, #0xe8]        | S1 = 1.401298E-45;                      
            val_12 = 1.401298E-45f;
            // 0x01683C44: MOV v11.16b, v0.16b        | V11 = val_2.x;//m1                      
            // 0x01683C48: FCMP s11, s1               | STATE = COMPARE(val_2.x, 1.40129846432482E-45)
            // 0x01683C4C: B.LE #0x1683c90            | if (val_2.x <= val_12) goto label_3;    
            if(val_2.x <= val_12)
            {
                goto label_3;
            }
            // 0x01683C50: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683C54: LDP s14, s13, [sp]         | S14 = val_2.x; S13 = 0;                  //  | 
            // 0x01683C58: LDR s12, [sp, #8]          | S12 = val_2.z;                          
            // 0x01683C5C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01683C60: TBZ w8, #0, #0x1683c70     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01683C64: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01683C68: CBNZ w8, #0x1683c70        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01683C6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_5:
            // 0x01683C70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683C74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683C78: MOV v0.16b, v14.16b        | V0 = val_2.x;//m1                       
            val_10 = val_2.x;
            // 0x01683C7C: MOV v1.16b, v13.16b        | V1 = 0 (0x0);//ML01                     
            val_12 = 0f;
            // 0x01683C80: MOV v2.16b, v12.16b        | V2 = val_2.z;//m1                       
            val_11 = val_2.z;
            // 0x01683C84: MOV v3.16b, v11.16b        | V3 = val_2.x;//m1                       
            // 0x01683C88: BL #0x2699130              | X0 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_10, y = 0f, z = val_11}, d:  val_2.x);
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_10, y = 0f, z = val_11}, d:  val_2.x);
            // 0x01683C8C: B #0x1683cb4               |  goto label_6;                          
            goto label_6;
            label_3:
            // 0x01683C90: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683C94: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01683C98: TBZ w8, #0, #0x1683ca8     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01683C9C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01683CA0: CBNZ w8, #0x1683ca8        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01683CA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_8:
            // 0x01683CA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683CAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683CB0: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_4 = UnityEngine.Vector3.zero;
            label_6:
            // 0x01683CB4: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01683CB8: LDR s14, [x29, #0x18]      | S14 = point.y;                          
            // 0x01683CBC: LDR s15, [x29, #0x10]      | S15 = point.x;                          
            // 0x01683CC0: MOV v11.16b, v0.16b        | V11 = val_4.x;//m1                      
            // 0x01683CC4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01683CC8: MOV v12.16b, v1.16b        | V12 = val_4.y;//m1                      
            // 0x01683CCC: MOV v13.16b, v2.16b        | V13 = val_4.z;//m1                      
            // 0x01683CD0: TBZ w8, #0, #0x1683ce0     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x01683CD4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01683CD8: CBNZ w8, #0x1683ce0        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x01683CDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_10:
            // 0x01683CE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683CE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683CE8: MOV v0.16b, v15.16b        | V0 = point.x;//m1                       
            // 0x01683CEC: MOV v1.16b, v9.16b         | V1 = val_1;//m1                         
            // 0x01683CF0: MOV v2.16b, v14.16b        | V2 = point.y;//m1                       
            // 0x01683CF4: MOV v3.16b, v10.16b        | V3 = lineStart.x;//m1                   
            // 0x01683CF8: MOV v4.16b, v9.16b         | V4 = val_1;//m1                         
            // 0x01683CFC: MOV v5.16b, v8.16b         | V5 = lineStart.z;//m1                   
            // 0x01683D00: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = point.x, y = val_1, z = point.y}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = val_1, z = lineStart.z});
            UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = point.x, y = val_1, z = point.y}, b:  new UnityEngine.Vector3() {x = lineStart.x, y = val_1, z = lineStart.z});
            // 0x01683D04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683D08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683D0C: MOV v3.16b, v11.16b        | V3 = val_4.x;//m1                       
            // 0x01683D10: MOV v4.16b, v12.16b        | V4 = val_4.y;//m1                       
            // 0x01683D14: MOV v5.16b, v13.16b        | V5 = val_4.z;//m1                       
            // 0x01683D18: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, rhs:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
            float val_6 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, rhs:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
            // 0x01683D1C: MOV x0, sp                 | X0 = 1152921513158239616 (0x10000001FDB3E580);//ML01
            // 0x01683D20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683D24: MOV v14.16b, v0.16b        | V14 = val_6;//m1                        
            // 0x01683D28: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
            // 0x01683D2C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x01683D30: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x01683D34: MOV v15.16b, v0.16b        | V15 = val_6;//m1                        
            // 0x01683D38: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x01683D3C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x01683D40: TBZ w8, #0, #0x1683d50     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x01683D44: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x01683D48: CBNZ w8, #0x1683d50        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x01683D4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_12:
            // 0x01683D50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683D54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683D58: FMOV s1, wzr               | S1 = 0f;                                
            // 0x01683D5C: MOV v0.16b, v14.16b        | V0 = val_6;//m1                         
            // 0x01683D60: MOV v2.16b, v15.16b        | V2 = val_6;//m1                         
            // 0x01683D64: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  val_6, min:  0f, max:  val_6);
            float val_7 = UnityEngine.Mathf.Clamp(value:  val_6, min:  0f, max:  val_6);
            // 0x01683D68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683D6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683D70: MOV v1.16b, v11.16b        | V1 = val_4.x;//m1                       
            // 0x01683D74: MOV v2.16b, v12.16b        | V2 = val_4.y;//m1                       
            // 0x01683D78: MOV v3.16b, v13.16b        | V3 = val_4.z;//m1                       
            // 0x01683D7C: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  float val_7 = UnityEngine.Mathf.Clamp(value:  val_6, min:  0f, max:  val_6), a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
            UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Multiply(d:  val_7, a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
            // 0x01683D80: MOV v3.16b, v0.16b         | V3 = val_8.x;//m1                       
            // 0x01683D84: MOV v4.16b, v1.16b         | V4 = val_8.y;//m1                       
            // 0x01683D88: MOV v5.16b, v2.16b         | V5 = val_8.z;//m1                       
            // 0x01683D8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01683D90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683D94: MOV v0.16b, v10.16b        | V0 = lineStart.x;//m1                   
            // 0x01683D98: MOV v1.16b, v9.16b         | V1 = val_1;//m1                         
            // 0x01683D9C: MOV v2.16b, v8.16b         | V2 = lineStart.z;//m1                   
            // 0x01683DA0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = lineStart.x, y = val_1, z = lineStart.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
            UnityEngine.Vector3 val_9 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = lineStart.x, y = val_1, z = lineStart.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
            // 0x01683DA4: SUB sp, x29, #0x50         | SP = (1152921513158239712 - 80) = 1152921513158239632 (0x10000001FDB3E590);
            // 0x01683DA8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01683DAC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01683DB0: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x01683DB4: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01683DB8: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01683DBC: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x01683DC0: RET                        |  return new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z};
            return new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z};
            //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01683DC4 (23608772), len: 156  VirtAddr: 0x01683DC4 RVA: 0x01683DC4 token: 100681943 methodIndex: 49834 delegateWrapperIndex: 0 methodInvoker: 0
        public static float DistancePointSegment(int x, int z, int px, int pz, int qx, int qz)
        {
            //
            // Disasemble & Code
            //  | 
            float val_7;
            // 0x01683DC4: SUB w8, w5, w3             | W8 = (qz - pz);                         
            int val_1 = qz - pz;
            // 0x01683DC8: SUB w9, w6, w4             | W9 = (W6 - qx);                         
            int val_2 = W6 - qx;
            // 0x01683DCC: SCVTF s1, w8               | S1 = (float)((qz - pz));                
            float val_9 = (float)val_1;
            // 0x01683DD0: SUB w8, w1, w3             | W8 = (z - pz);                          
            int val_3 = z - pz;
            // 0x01683DD4: SCVTF s0, w9               | S0 = (float)((W6 - qx));                
            float val_10 = (float)val_2;
            // 0x01683DD8: SUB w9, w2, w4             | W9 = (px - qx);                         
            int val_4 = px - qx;
            // 0x01683DDC: SCVTF s2, w8               | S2 = (float)((z - pz));                 
            float val_7 = (float)val_3;
            // 0x01683DE0: SCVTF s3, w9               | S3 = (float)((px - qx));                
            float val_8 = (float)val_4;
            // 0x01683DE4: FMUL s4, s1, s1            | S4 = ((qz - pz) * (qz - pz));           
            float val_5 = val_9 * val_9;
            // 0x01683DE8: FMUL s5, s0, s0            | S5 = ((W6 - qx) * (W6 - qx));           
            float val_6 = val_10 * val_10;
            // 0x01683DEC: FMUL s2, s2, s1            | S2 = ((z - pz) * (qz - pz));            
            val_7 = val_7 * val_9;
            // 0x01683DF0: FMUL s3, s3, s0            | S3 = ((px - qx) * (W6 - qx));           
            val_8 = val_8 * val_10;
            // 0x01683DF4: FADD s4, s4, s5            | S4 = (((qz - pz) * (qz - pz)) + ((W6 - qx) * (W6 - qx)));
            val_5 = val_5 + val_6;
            // 0x01683DF8: FADD s2, s2, s3            | S2 = (((z - pz) * (qz - pz)) + ((px - qx) * (W6 - qx)));
            val_7 = val_7 + val_8;
            // 0x01683DFC: FDIV s3, s2, s4            | S3 = ((((z - pz) * (qz - pz)) + ((px - qx) * (W6 - qx))) / (((qz - pz) * (qz - pz)) + ((W6 - qx) * (W6 - qx))));
            val_8 = val_7 / val_5;
            // 0x01683E00: FCMP s4, #0.0              | STATE = COMPARE((((qz - pz) * (qz - pz)) + ((W6 - qx) * (W6 - qx))), 0)
            // 0x01683E04: FCSEL s2, s3, s2, gt       | S2 = val_5 > 0 ? ((((z - pz) * (qz - pz)) + ((px - qx) * (W6 - qx))) / (((qz - pz) * (qz - pz)) + ((W6 - qx) * (W6 - qx)))) : (((z - pz) * (qz - pz)) + ((px - qx) * (W6 - qx)));
            val_7 = (val_5 > 0f) ? (val_8) : (val_7);
            // 0x01683E08: FCMP s2, #0.0              | STATE = COMPARE(val_5 > 0 ? ((((z - pz) * (qz - pz)) + ((px - qx) * (W6 - qx))) / (((qz - pz) * (qz - pz)) + ((W6 - qx) * (W6 - qx)))) : (((z - pz) * (qz - pz)) + ((px - qx) * (W6 - qx))), 0)
            // 0x01683E0C: B.PL #0x1683e18            | if ((float)val_3 >= 0) goto label_0;    
            if(val_7 >= 0)
            {
                goto label_0;
            }
            // 0x01683E10: FMOV s2, wzr               | S2 = 0f;                                
            val_7 = 0f;
            // 0x01683E14: B #0x1683e28               |  goto label_2;                          
            goto label_2;
            label_0:
            // 0x01683E18: FMOV s3, #1.00000000       | S3 = 1;                                 
            // 0x01683E1C: FCMP s2, s3                | STATE = COMPARE(val_5 > 0 ? ((((z - pz) * (qz - pz)) + ((px - qx) * (W6 - qx))) / (((qz - pz) * (qz - pz)) + ((W6 - qx) * (W6 - qx)))) : (((z - pz) * (qz - pz)) + ((px - qx) * (W6 - qx))), 1)
            // 0x01683E20: B.LE #0x1683e28            | if ((float)val_3 <= 1f) goto label_2;   
            if(val_7 <= 1f)
            {
                goto label_2;
            }
            // 0x01683E24: MOV v2.16b, v3.16b         | V2 = 1;//m1                             
            val_7 = 1f;
            label_2:
            // 0x01683E28: SCVTF s3, w3               | S3 = (float)(pz);                       
            // 0x01683E2C: FMUL s1, s1, s2            | S1 = ((qz - pz) * val_7);               
            val_9 = val_9 * val_7;
            // 0x01683E30: SCVTF s5, w4               | S5 = (float)(qx);                       
            // 0x01683E34: FMUL s0, s0, s2            | S0 = ((W6 - qx) * val_7);               
            val_10 = val_10 * val_7;
            // 0x01683E38: SCVTF s4, w1               | S4 = (float)(z);                        
            // 0x01683E3C: SCVTF s2, w2               | S2 = (float)(px);                       
            // 0x01683E40: FADD s1, s3, s1            | S1 = (pz + ((qz - pz) * val_7));        
            val_9 = (float)pz + val_9;
            // 0x01683E44: FADD s0, s5, s0            | S0 = (qx + ((W6 - qx) * val_7));        
            val_10 = (float)qx + val_10;
            // 0x01683E48: FSUB s1, s1, s4            | S1 = ((pz + ((qz - pz) * val_7)) - z);  
            val_9 = val_9 - (float)z;
            // 0x01683E4C: FSUB s0, s0, s2            | S0 = ((qx + ((W6 - qx) * val_7)) - px); 
            val_10 = val_10 - (float)px;
            // 0x01683E50: FMUL s1, s1, s1            | S1 = (((pz + ((qz - pz) * val_7)) - z) * ((pz + ((qz - pz) * val_7)) - z));
            val_9 = val_9 * val_9;
            // 0x01683E54: FMUL s0, s0, s0            | S0 = (((qx + ((W6 - qx) * val_7)) - px) * ((qx + ((W6 - qx) * val_7)) - px));
            val_10 = val_10 * val_10;
            // 0x01683E58: FADD s0, s1, s0            | S0 = ((((pz + ((qz - pz) * val_7)) - z) * ((pz + ((qz - pz) * val_7)) - z)) + (((qx + ((W6 - qx) * val_7)) - px) * ((qx + ((W6 - qx) * val_7)) - px)));
            val_10 = val_9 + val_10;
            // 0x01683E5C: RET                        |  return (System.Single)((((pz + ((qz - pz) * val_7)) - z) * ((pz + ((qz - pz) * val_7)) - z)) + (((qx + ((W6 - qx) * val_7)) - px) * ((qx + ((W6 - qx) * val_7)) - px)));
            return (float)val_10;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01683E60 (23608928), len: 156  VirtAddr: 0x01683E60 RVA: 0x01683E60 token: 100681944 methodIndex: 49835 delegateWrapperIndex: 0 methodInvoker: 0
        public static float DistancePointSegment(Pathfinding.Int3 a, Pathfinding.Int3 b, Pathfinding.Int3 p)
        {
            //
            // Disasemble & Code
            //  | 
            float val_7;
            // 0x01683E60: SUB w8, w3, w1             | W8 = (b.z - a.z);                       
            int val_1 = b.z - a.z;
            // 0x01683E64: SUB w9, w4, w2             | W9 = (p.x - b.x);                       
            int val_2 = p.x - b.x;
            // 0x01683E68: SCVTF s1, w8               | S1 = (float)((b.z - a.z));              
            float val_9 = (float)val_1;
            // 0x01683E6C: SUB w8, w5, w1             | W8 = (p.z - a.z);                       
            int val_3 = p.z - a.z;
            // 0x01683E70: SCVTF s0, w9               | S0 = (float)((p.x - b.x));              
            float val_10 = (float)val_2;
            // 0x01683E74: SUB w9, w6, w2             | W9 = (W6 - b.x);                        
            int val_4 = W6 - b.x;
            // 0x01683E78: SCVTF s2, w8               | S2 = (float)((p.z - a.z));              
            float val_7 = (float)val_3;
            // 0x01683E7C: SCVTF s3, w9               | S3 = (float)((W6 - b.x));               
            float val_8 = (float)val_4;
            // 0x01683E80: FMUL s4, s1, s1            | S4 = ((b.z - a.z) * (b.z - a.z));       
            float val_5 = val_9 * val_9;
            // 0x01683E84: FMUL s5, s0, s0            | S5 = ((p.x - b.x) * (p.x - b.x));       
            float val_6 = val_10 * val_10;
            // 0x01683E88: FMUL s2, s1, s2            | S2 = ((b.z - a.z) * (p.z - a.z));       
            val_7 = val_9 * val_7;
            // 0x01683E8C: FMUL s3, s0, s3            | S3 = ((p.x - b.x) * (W6 - b.x));        
            val_8 = val_10 * val_8;
            // 0x01683E90: FADD s4, s4, s5            | S4 = (((b.z - a.z) * (b.z - a.z)) + ((p.x - b.x) * (p.x - b.x)));
            val_5 = val_5 + val_6;
            // 0x01683E94: FADD s2, s2, s3            | S2 = (((b.z - a.z) * (p.z - a.z)) + ((p.x - b.x) * (W6 - b.x)));
            val_7 = val_7 + val_8;
            // 0x01683E98: FDIV s3, s2, s4            | S3 = ((((b.z - a.z) * (p.z - a.z)) + ((p.x - b.x) * (W6 - b.x))) / (((b.z - a.z) * (b.z - a.z)) + ((p.x - b.x) * (p.x - b.x))));
            val_8 = val_7 / val_5;
            // 0x01683E9C: FCMP s4, #0.0              | STATE = COMPARE((((b.z - a.z) * (b.z - a.z)) + ((p.x - b.x) * (p.x - b.x))), 0)
            // 0x01683EA0: FCSEL s2, s3, s2, gt       | S2 = val_5 > 0 ? ((((b.z - a.z) * (p.z - a.z)) + ((p.x - b.x) * (W6 - b.x))) / (((b.z - a.z) * (b.z - a.z)) + ((p.x - b.x) * (p.x - b.x)))) : (((b.z - a.z) * (p.z - a.z)) + ((p.x - b.x) * (W6 - b.x)));
            val_7 = (val_5 > 0f) ? (val_8) : (val_7);
            // 0x01683EA4: FCMP s2, #0.0              | STATE = COMPARE(val_5 > 0 ? ((((b.z - a.z) * (p.z - a.z)) + ((p.x - b.x) * (W6 - b.x))) / (((b.z - a.z) * (b.z - a.z)) + ((p.x - b.x) * (p.x - b.x)))) : (((b.z - a.z) * (p.z - a.z)) + ((p.x - b.x) * (W6 - b.x))), 0)
            // 0x01683EA8: B.PL #0x1683eb4            | if ((float)val_3 >= 0) goto label_0;    
            if(val_7 >= 0)
            {
                goto label_0;
            }
            // 0x01683EAC: FMOV s2, wzr               | S2 = 0f;                                
            val_7 = 0f;
            // 0x01683EB0: B #0x1683ec4               |  goto label_2;                          
            goto label_2;
            label_0:
            // 0x01683EB4: FMOV s3, #1.00000000       | S3 = 1;                                 
            // 0x01683EB8: FCMP s2, s3                | STATE = COMPARE(val_5 > 0 ? ((((b.z - a.z) * (p.z - a.z)) + ((p.x - b.x) * (W6 - b.x))) / (((b.z - a.z) * (b.z - a.z)) + ((p.x - b.x) * (p.x - b.x)))) : (((b.z - a.z) * (p.z - a.z)) + ((p.x - b.x) * (W6 - b.x))), 1)
            // 0x01683EBC: B.LE #0x1683ec4            | if ((float)val_3 <= 1f) goto label_2;   
            if(val_7 <= 1f)
            {
                goto label_2;
            }
            // 0x01683EC0: MOV v2.16b, v3.16b         | V2 = 1;//m1                             
            val_7 = 1f;
            label_2:
            // 0x01683EC4: SCVTF s3, w1               | S3 = (float)(a.z);                      
            // 0x01683EC8: FMUL s1, s1, s2            | S1 = ((b.z - a.z) * val_7);             
            val_9 = val_9 * val_7;
            // 0x01683ECC: SCVTF s5, w2               | S5 = (float)(b.x);                      
            // 0x01683ED0: FMUL s0, s0, s2            | S0 = ((p.x - b.x) * val_7);             
            val_10 = val_10 * val_7;
            // 0x01683ED4: SCVTF s4, w5               | S4 = (float)(p.z);                      
            // 0x01683ED8: SCVTF s2, w6               | S2 = (float)(W6);                       
            // 0x01683EDC: FADD s1, s3, s1            | S1 = (a.z + ((b.z - a.z) * val_7));     
            val_9 = (float)a.z + val_9;
            // 0x01683EE0: FADD s0, s5, s0            | S0 = (b.x + ((p.x - b.x) * val_7));     
            val_10 = (float)b.x + val_10;
            // 0x01683EE4: FSUB s1, s1, s4            | S1 = ((a.z + ((b.z - a.z) * val_7)) - p.z);
            val_9 = val_9 - (float)p.z;
            // 0x01683EE8: FSUB s0, s0, s2            | S0 = ((b.x + ((p.x - b.x) * val_7)) - W6);
            val_10 = val_10 - (float)W6;
            // 0x01683EEC: FMUL s1, s1, s1            | S1 = (((a.z + ((b.z - a.z) * val_7)) - p.z) * ((a.z + ((b.z - a.z) * val_7)) - p.z));
            val_9 = val_9 * val_9;
            // 0x01683EF0: FMUL s0, s0, s0            | S0 = (((b.x + ((p.x - b.x) * val_7)) - W6) * ((b.x + ((p.x - b.x) * val_7)) - W6));
            val_10 = val_10 * val_10;
            // 0x01683EF4: FADD s0, s1, s0            | S0 = ((((a.z + ((b.z - a.z) * val_7)) - p.z) * ((a.z + ((b.z - a.z) * val_7)) - p.z)) + (((b.x + ((p.x - b.x) * val_7)) - W6) * ((b.x + ((p.x - b.x) * val_7)) - W6)));
            val_10 = val_9 + val_10;
            // 0x01683EF8: RET                        |  return (System.Single)((((a.z + ((b.z - a.z) * val_7)) - p.z) * ((a.z + ((b.z - a.z) * val_7)) - p.z)) + (((b.x + ((p.x - b.x) * val_7)) - W6) * ((b.x + ((p.x - b.x) * val_7)) - W6)));
            return (float)val_10;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01683EFC (23609084), len: 200  VirtAddr: 0x01683EFC RVA: 0x01683EFC token: 100681945 methodIndex: 49836 delegateWrapperIndex: 0 methodInvoker: 0
        public static float DistancePointSegment2(int x, int z, int px, int pz, int qx, int qz)
        {
            //
            // Disasemble & Code
            // 0x01683EFC: STP d9, d8, [sp, #-0x40]!  | stack[1152921513158575664] = ???;  stack[1152921513158575672] = ???;  //  dest_result_addr=1152921513158575664 |  dest_result_addr=1152921513158575672
            // 0x01683F00: STP x22, x21, [sp, #0x10]  | stack[1152921513158575680] = ???;  stack[1152921513158575688] = ???;  //  dest_result_addr=1152921513158575680 |  dest_result_addr=1152921513158575688
            // 0x01683F04: STP x20, x19, [sp, #0x20]  | stack[1152921513158575696] = ???;  stack[1152921513158575704] = ???;  //  dest_result_addr=1152921513158575696 |  dest_result_addr=1152921513158575704
            // 0x01683F08: STP x29, x30, [sp, #0x30]  | stack[1152921513158575712] = ???;  stack[1152921513158575720] = ???;  //  dest_result_addr=1152921513158575712 |  dest_result_addr=1152921513158575720
            // 0x01683F0C: ADD x29, sp, #0x30         | X29 = (1152921513158575664 + 48) = 1152921513158575712 (0x10000001FDB90660);
            // 0x01683F10: SUB sp, sp, #0x40          | SP = (1152921513158575664 - 64) = 1152921513158575600 (0x10000001FDB905F0);
            // 0x01683F14: FMOV s8, wzr               | S8 = 0f;                                
            // 0x01683F18: SCVTF s0, w1               | S0 = (float)(z);                        
            // 0x01683F1C: SCVTF s2, w2               | S2 = (float)(px);                       
            // 0x01683F20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683F24: ADD x0, sp, #0x30          | X0 = (1152921513158575600 + 48) = 1152921513158575648 (0x10000001FDB90620);
            // 0x01683F28: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x01683F2C: MOV w19, w6                | W19 = W6;//m1                           
            // 0x01683F30: MOV w20, w5                | W20 = qz;//m1                           
            // 0x01683F34: MOV w21, w4                | W21 = qx;//m1                           
            // 0x01683F38: MOV w22, w3                | W22 = pz;//m1                           
            // 0x01683F3C: STR wzr, [sp, #0x38]       | stack[1152921513158575656] = 0x0;        //  dest_result_addr=1152921513158575656
            // 0x01683F40: STR xzr, [sp, #0x30]       | stack[1152921513158575648] = 0x0;        //  dest_result_addr=1152921513158575648
            // 0x01683F44: STR wzr, [sp, #0x28]       | stack[1152921513158575640] = 0x0;        //  dest_result_addr=1152921513158575640
            // 0x01683F48: STR xzr, [sp, #0x20]       | stack[1152921513158575632] = 0x0;        //  dest_result_addr=1152921513158575632
            // 0x01683F4C: STR wzr, [sp, #0x18]       | stack[1152921513158575624] = 0x0;        //  dest_result_addr=1152921513158575624
            // 0x01683F50: STR xzr, [sp, #0x10]       | stack[1152921513158575616] = 0x0;        //  dest_result_addr=1152921513158575616
            // 0x01683F54: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x01683F58: SCVTF s0, w22              | S0 = (float)(pz);                       
            // 0x01683F5C: SCVTF s2, w21              | S2 = (float)(qx);                       
            // 0x01683F60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683F64: ADD x0, sp, #0x20          | X0 = (1152921513158575600 + 32) = 1152921513158575632 (0x10000001FDB90610);
            // 0x01683F68: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x01683F6C: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x01683F70: SCVTF s0, w20              | S0 = (float)(qz);                       
            // 0x01683F74: SCVTF s2, w19              | S2 = (float)(W6);                       
            // 0x01683F78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01683F7C: ADD x0, sp, #0x10          | X0 = (1152921513158575600 + 16) = 1152921513158575616 (0x10000001FDB90600);
            // 0x01683F80: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x01683F84: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x01683F88: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
            // 0x01683F8C: LDR s2, [sp, #0x28]        | S2 = 0;                                 
            // 0x01683F90: LDP s3, s4, [sp, #0x10]    | S3 = 0; S4 = 0;                          //  | 
            // 0x01683F94: LDR s5, [sp, #0x18]        | S5 = 0;                                 
            // 0x01683F98: LDP s6, s7, [sp, #0x30]    | S6 = 0; S7 = 0;                          //  | 
            // 0x01683F9C: LDR s16, [sp, #0x38]       | S16 = 0;                                
            // 0x01683FA0: STP s7, s16, [sp, #4]      | stack[1152921513158575604] = 0x0;  stack[1152921513158575608] = 0x0;  //  dest_result_addr=1152921513158575604 |  dest_result_addr=1152921513158575608
            // 0x01683FA4: STR s6, [sp]               | stack[1152921513158575600] = 0x0;        //  dest_result_addr=1152921513158575600
            // 0x01683FA8: BL #0x1683fc4              | X0 = Pathfinding.AstarMath.DistancePointSegment2(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, p:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
            float val_1 = Pathfinding.AstarMath.DistancePointSegment2(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, p:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
            // 0x01683FAC: SUB sp, x29, #0x30         | SP = (1152921513158575712 - 48) = 1152921513158575664 (0x10000001FDB90630);
            // 0x01683FB0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01683FB4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01683FB8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01683FBC: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
            // 0x01683FC0: RET                        |  return (System.Single)val_1;           
            return val_1;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01683FC4 (23609284), len: 364  VirtAddr: 0x01683FC4 RVA: 0x01683FC4 token: 100681946 methodIndex: 49837 delegateWrapperIndex: 0 methodInvoker: 0
        public static float DistancePointSegment2(UnityEngine.Vector3 a, UnityEngine.Vector3 b, UnityEngine.Vector3 p)
        {
            //
            // Disasemble & Code
            //  | 
            float val_7;
            //  | 
            float val_9;
            //  | 
            float val_10;
            // 0x01683FC4: STP d15, d14, [sp, #-0x60]! | stack[1152921513158687632] = ???;  stack[1152921513158687640] = ???;  //  dest_result_addr=1152921513158687632 |  dest_result_addr=1152921513158687640
            // 0x01683FC8: STP d13, d12, [sp, #0x10]  | stack[1152921513158687648] = ???;  stack[1152921513158687656] = ???;  //  dest_result_addr=1152921513158687648 |  dest_result_addr=1152921513158687656
            // 0x01683FCC: STP d11, d10, [sp, #0x20]  | stack[1152921513158687664] = ???;  stack[1152921513158687672] = ???;  //  dest_result_addr=1152921513158687664 |  dest_result_addr=1152921513158687672
            // 0x01683FD0: STP d9, d8, [sp, #0x30]    | stack[1152921513158687680] = ???;  stack[1152921513158687688] = ???;  //  dest_result_addr=1152921513158687680 |  dest_result_addr=1152921513158687688
            // 0x01683FD4: STP x20, x19, [sp, #0x40]  | stack[1152921513158687696] = ???;  stack[1152921513158687704] = ???;  //  dest_result_addr=1152921513158687696 |  dest_result_addr=1152921513158687704
            // 0x01683FD8: STP x29, x30, [sp, #0x50]  | stack[1152921513158687712] = ???;  stack[1152921513158687720] = ???;  //  dest_result_addr=1152921513158687712 |  dest_result_addr=1152921513158687720
            // 0x01683FDC: ADD x29, sp, #0x50         | X29 = (1152921513158687632 + 80) = 1152921513158687712 (0x10000001FDBABBE0);
            // 0x01683FE0: SUB sp, sp, #0x10          | SP = (1152921513158687632 - 16) = 1152921513158687616 (0x10000001FDBABB80);
            // 0x01683FE4: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01683FE8: LDRB w8, [x19, #0xdb]      | W8 = (bool)static_value_037380DB;       
            // 0x01683FEC: MOV v11.16b, v5.16b        | V11 = b.z;//m1                          
            // 0x01683FF0: MOV v12.16b, v3.16b        | V12 = b.x;//m1                          
            // 0x01683FF4: MOV v8.16b, v2.16b         | V8 = a.z;//m1                           
            val_9 = a.z;
            // 0x01683FF8: MOV v10.16b, v1.16b        | V10 = a.y;//m1                          
            // 0x01683FFC: MOV v9.16b, v0.16b         | V9 = a.x;//m1                           
            // 0x01684000: TBNZ w8, #0, #0x168401c    | if (static_value_037380DB == true) goto label_0;
            // 0x01684004: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x01684008: LDR x8, [x8, #0x978]       | X8 = 0x2B8EC68;                         
            // 0x0168400C: LDR w0, [x8]               | W0 = 0x11DA;                            
            // 0x01684010: BL #0x2782188              | X0 = sub_2782188( ?? 0x11DA, ????);     
            // 0x01684014: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01684018: STRB w8, [x19, #0xdb]      | static_value_037380DB = true;            //  dest_result_addr=57901275
            label_0:
            // 0x0168401C: ADRP x19, #0x363f000       | X19 = 56881152 (0x363F000);             
            // 0x01684020: LDR x19, [x19, #0x3b0]     | X19 = 1152921504695345152;              
            // 0x01684024: STR wzr, [sp, #8]          | stack[1152921513158687624] = 0x0;        //  dest_result_addr=1152921513158687624
            // 0x01684028: FSUB s15, s12, s9          | S15 = (b.x - a.x);                      
            float val_1 = b.x - a.x;
            // 0x0168402C: FSUB s14, s11, s8          | S14 = (b.z - a.z);                      
            float val_2 = b.z - val_9;
            // 0x01684030: LDR x0, [x19]              | X0 = typeof(UnityEngine.Mathf);         
            // 0x01684034: STR xzr, [sp]              | stack[1152921513158687616] = 0x0;        //  dest_result_addr=1152921513158687616
            // 0x01684038: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x0168403C: TBZ w8, #0, #0x168404c     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01684040: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x01684044: CBNZ w8, #0x168404c        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01684048: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_2:
            // 0x0168404C: LDR s11, [x29, #0x18]      | S11 = p.y;                              
            // 0x01684050: LDR s12, [x29, #0x10]      | S12 = p.x;                              
            // 0x01684054: FMUL s0, s15, s15          | S0 = ((b.x - a.x) * (b.x - a.x));       
            a.x = val_1 * val_1;
            // 0x01684058: FMUL s1, s14, s14          | S1 = ((b.z - a.z) * (b.z - a.z));       
            float val_3 = val_2 * val_2;
            // 0x0168405C: FADD s13, s0, s1           | S13 = (((b.x - a.x) * (b.x - a.x)) + ((b.z - a.z) * (b.z - a.z)));
            float val_4 = a.x + val_3;
            // 0x01684060: FCMP s13, #0.0             | STATE = COMPARE((((b.x - a.x) * (b.x - a.x)) + ((b.z - a.z) * (b.z - a.z))), 0)
            // 0x01684064: B.LE #0x16840b4            | if (val_4 <= 0) goto label_3;           
            if(val_4 <= 0f)
            {
                goto label_3;
            }
            // 0x01684068: LDR x0, [x19]              | X0 = typeof(UnityEngine.Mathf);         
            // 0x0168406C: FSUB s0, s11, s8           | S0 = (p.y - a.z);                       
            float val_5 = p.y - val_9;
            // 0x01684070: FSUB s1, s12, s9           | S1 = (p.x - a.x);                       
            float val_6 = p.x - a.x;
            // 0x01684074: FMUL s0, s15, s0           | S0 = ((b.x - a.x) * (p.y - a.z));       
            val_5 = val_1 * val_5;
            // 0x01684078: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x0168407C: FMUL s1, s14, s1           | S1 = ((b.z - a.z) * (p.x - a.x));       
            val_6 = val_2 * val_6;
            // 0x01684080: FSUB s8, s0, s1            | S8 = (((b.x - a.x) * (p.y - a.z)) - ((b.z - a.z) * (p.x - a.x)));
            val_9 = val_5 - val_6;
            // 0x01684084: TBZ w8, #0, #0x1684094     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01684088: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x0168408C: CBNZ w8, #0x1684094        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01684090: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_5:
            // 0x01684094: FABS s8, s8                | S8 = System.Math.Abs((((b.x - a.x) * (p.y - a.z)) - ((b.z - a.z) * (p.x - a.x))));
            val_9 = System.Math.Abs(val_9);
            // 0x01684098: FSQRT s0, s13              | 
            // 0x0168409C: FCMP s0, s0                | STATE = COMPARE(((b.x - a.x) * (p.y - a.z)), ((b.x - a.x) * (p.y - a.z)))
            // 0x016840A0: B.VC #0x16840ac            | if (val_5 < _TYPE_MAX_) goto label_6;   
            if(val_5 < _TYPE_MAX_)
            {
                goto label_6;
            }
            // 0x016840A4: MOV v0.16b, v13.16b        | V0 = (((b.x - a.x) * (b.x - a.x)) + ((b.z - a.z) * (b.z - a.z)));//m1
            val_10 = val_4;
            // 0x016840A8: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
            label_6:
            // 0x016840AC: FDIV s0, s8, s0            | S0 = ((((b.x - a.x) * (p.y - a.z)) - ((b.z - a.z) * (p.x - a.x))) / (((b.x - a.x) * (b.x - a.x)) + ((b.z - a.z) * (b.z - a.z))));
            val_10 = val_9 / val_10;
            // 0x016840B0: B #0x1684110               |  goto label_7;                          
            goto label_7;
            label_3:
            // 0x016840B4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x016840B8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x016840BC: LDR s13, [x29, #0x14]      | S13 = val_7;                             //  find_add[1152921513158675728]
            // 0x016840C0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x016840C4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x016840C8: TBZ w8, #0, #0x16840d8     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x016840CC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x016840D0: CBNZ w8, #0x16840d8        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x016840D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_9:
            // 0x016840D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016840DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016840E0: MOV v0.16b, v9.16b         | V0 = a.x;//m1                           
            // 0x016840E4: MOV v1.16b, v10.16b        | V1 = a.y;//m1                           
            // 0x016840E8: MOV v2.16b, v8.16b         | V2 = a.z;//m1                           
            // 0x016840EC: MOV v3.16b, v12.16b        | V3 = p.x;//m1                           
            // 0x016840F0: MOV v4.16b, v13.16b        | V4 = val_7;//m1                         
            // 0x016840F4: MOV v5.16b, v11.16b        | V5 = p.y;//m1                           
            // 0x016840F8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = a.x, y = a.y, z = val_9}, b:  new UnityEngine.Vector3() {x = p.x, y = val_7, z = p.y});
            UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = a.x, y = a.y, z = val_9}, b:  new UnityEngine.Vector3() {x = p.x, y = val_7, z = p.y});
            // 0x016840FC: MOV x0, sp                 | X0 = 1152921513158687616 (0x10000001FDBABB80);//ML01
            // 0x01684100: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684104: STP s0, s1, [sp]           | stack[1152921513158687616] = val_8.x;  stack[1152921513158687620] = val_8.y;  //  dest_result_addr=1152921513158687616 |  dest_result_addr=1152921513158687620
            // 0x01684108: STR s2, [sp, #8]           | stack[1152921513158687624] = val_8.z;    //  dest_result_addr=1152921513158687624
            // 0x0168410C: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
            label_7:
            // 0x01684110: SUB sp, x29, #0x50         | SP = (1152921513158687712 - 80) = 1152921513158687632 (0x10000001FDBABB90);
            // 0x01684114: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01684118: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0168411C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x01684120: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01684124: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01684128: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x0168412C: RET                        |  return (System.Single)val_8.x;         
            return (float)val_8.x;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684130 (23609648), len: 292  VirtAddr: 0x01684130 RVA: 0x01684130 token: 100681947 methodIndex: 49838 delegateWrapperIndex: 0 methodInvoker: 0
        public static float DistancePointSegmentStrict(UnityEngine.Vector3 a, UnityEngine.Vector3 b, UnityEngine.Vector3 p)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            float val_4;
            //  | 
            float val_5;
            // 0x01684130: STP d15, d14, [sp, #-0x60]! | stack[1152921513158799632] = ???;  stack[1152921513158799640] = ???;  //  dest_result_addr=1152921513158799632 |  dest_result_addr=1152921513158799640
            // 0x01684134: STP d13, d12, [sp, #0x10]  | stack[1152921513158799648] = ???;  stack[1152921513158799656] = ???;  //  dest_result_addr=1152921513158799648 |  dest_result_addr=1152921513158799656
            // 0x01684138: STP d11, d10, [sp, #0x20]  | stack[1152921513158799664] = ???;  stack[1152921513158799672] = ???;  //  dest_result_addr=1152921513158799664 |  dest_result_addr=1152921513158799672
            // 0x0168413C: STP d9, d8, [sp, #0x30]    | stack[1152921513158799680] = ???;  stack[1152921513158799688] = ???;  //  dest_result_addr=1152921513158799680 |  dest_result_addr=1152921513158799688
            // 0x01684140: STP x20, x19, [sp, #0x40]  | stack[1152921513158799696] = ???;  stack[1152921513158799704] = ???;  //  dest_result_addr=1152921513158799696 |  dest_result_addr=1152921513158799704
            // 0x01684144: STP x29, x30, [sp, #0x50]  | stack[1152921513158799712] = ???;  stack[1152921513158799720] = ???;  //  dest_result_addr=1152921513158799712 |  dest_result_addr=1152921513158799720
            // 0x01684148: ADD x29, sp, #0x50         | X29 = (1152921513158799632 + 80) = 1152921513158799712 (0x10000001FDBC7160);
            // 0x0168414C: SUB sp, sp, #0x20          | SP = (1152921513158799632 - 32) = 1152921513158799600 (0x10000001FDBC70F0);
            // 0x01684150: LDP s9, s8, [x29, #0x14]   | S9 = val_1; S8 = p.y;                    //  find_add[1152921513158787728] | 
            val_4 = val_1;
            val_5 = p.y;
            // 0x01684154: LDR s15, [x29, #0x10]      | S15 = p.x;                              
            // 0x01684158: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0168415C: LDRB w8, [x19, #0xdc]      | W8 = (bool)static_value_037380DC;       
            // 0x01684160: MOV v11.16b, v0.16b        | V11 = a.x;//m1                          
            // 0x01684164: TBNZ w8, #0, #0x16841b8    | if (static_value_037380DC == true) goto label_0;
            // 0x01684168: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x0168416C: LDR x8, [x8, #0xf8]        | X8 = 0x2B8EC6C;                         
            // 0x01684170: MOV v12.16b, v5.16b        | V12 = b.z;//m1                          
            // 0x01684174: MOV v13.16b, v4.16b        | V13 = b.y;//m1                          
            // 0x01684178: STR s9, [sp, #0xc]         | stack[1152921513158799612] = val_1;      //  dest_result_addr=1152921513158799612
            // 0x0168417C: LDR w0, [x8]               | W0 = 0x11DB;                            
            // 0x01684180: MOV v9.16b, v8.16b         | V9 = p.y;//m1                           
            // 0x01684184: MOV v8.16b, v3.16b         | V8 = b.x;//m1                           
            // 0x01684188: MOV v10.16b, v2.16b        | V10 = a.z;//m1                          
            // 0x0168418C: MOV v14.16b, v1.16b        | V14 = a.y;//m1                          
            // 0x01684190: BL #0x2782188              | X0 = sub_2782188( ?? 0x11DB, ????);     
            // 0x01684194: MOV v3.16b, v8.16b         | V3 = b.x;//m1                           
            // 0x01684198: MOV v8.16b, v9.16b         | V8 = p.y;//m1                           
            val_5 = val_5;
            // 0x0168419C: LDR s9, [sp, #0xc]         | S9 = val_1;                             
            val_4 = val_4;
            // 0x016841A0: MOV v1.16b, v14.16b        | V1 = a.y;//m1                           
            // 0x016841A4: MOV v2.16b, v10.16b        | V2 = a.z;//m1                           
            // 0x016841A8: MOV v4.16b, v13.16b        | V4 = b.y;//m1                           
            // 0x016841AC: MOV v5.16b, v12.16b        | V5 = b.z;//m1                           
            // 0x016841B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016841B4: STRB w8, [x19, #0xdc]      | static_value_037380DC = true;            //  dest_result_addr=57901276
            label_0:
            // 0x016841B8: MOV v0.16b, v11.16b        | V0 = a.x;//m1                           
            // 0x016841BC: STR wzr, [sp, #0x18]       | stack[1152921513158799624] = 0x0;        //  dest_result_addr=1152921513158799624
            // 0x016841C0: STR xzr, [sp, #0x10]       | stack[1152921513158799616] = 0x0;        //  dest_result_addr=1152921513158799616
            // 0x016841C4: STP s9, s8, [sp, #4]       | stack[1152921513158799604] = val_1;  stack[1152921513158799608] = p.y;  //  dest_result_addr=1152921513158799604 |  dest_result_addr=1152921513158799608
            // 0x016841C8: STR s15, [sp]              | stack[1152921513158799600] = p.x;        //  dest_result_addr=1152921513158799600
            // 0x016841CC: BL #0x168393c              | X0 = Pathfinding.AstarMath.NearestPointStrict(lineStart:  new UnityEngine.Vector3() {x = a.x, y = a.y, z = a.z}, lineEnd:  new UnityEngine.Vector3() {x = b.x, y = b.y, z = b.z}, point:  new UnityEngine.Vector3() {x = p.x, y = val_5, z = 0f});
            UnityEngine.Vector3 val_2 = Pathfinding.AstarMath.NearestPointStrict(lineStart:  new UnityEngine.Vector3() {x = a.x, y = a.y, z = a.z}, lineEnd:  new UnityEngine.Vector3() {x = b.x, y = b.y, z = b.z}, point:  new UnityEngine.Vector3() {x = p.x, y = val_5, z = 0f});
            // 0x016841D0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x016841D4: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x016841D8: MOV v11.16b, v0.16b        | V11 = val_2.x;//m1                      
            // 0x016841DC: MOV v12.16b, v1.16b        | V12 = val_2.y;//m1                      
            // 0x016841E0: MOV v13.16b, v2.16b        | V13 = val_2.z;//m1                      
            // 0x016841E4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x016841E8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x016841EC: TBZ w8, #0, #0x16841fc     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016841F0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x016841F4: CBNZ w8, #0x16841fc        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016841F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x016841FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684200: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684204: MOV v0.16b, v11.16b        | V0 = val_2.x;//m1                       
            // 0x01684208: MOV v1.16b, v12.16b        | V1 = val_2.y;//m1                       
            // 0x0168420C: MOV v2.16b, v13.16b        | V2 = val_2.z;//m1                       
            // 0x01684210: MOV v3.16b, v15.16b        | V3 = p.x;//m1                           
            // 0x01684214: MOV v4.16b, v9.16b         | V4 = val_1;//m1                         
            // 0x01684218: MOV v5.16b, v8.16b         | V5 = p.y;//m1                           
            // 0x0168421C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = p.x, y = val_4, z = val_5});
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = p.x, y = val_4, z = val_5});
            // 0x01684220: ADD x0, sp, #0x10          | X0 = (1152921513158799600 + 16) = 1152921513158799616 (0x10000001FDBC7100);
            // 0x01684224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684228: STP s0, s1, [sp, #0x10]    | stack[1152921513158799616] = val_3.x;  stack[1152921513158799620] = val_3.y;  //  dest_result_addr=1152921513158799616 |  dest_result_addr=1152921513158799620
            // 0x0168422C: STR s2, [sp, #0x18]        | stack[1152921513158799624] = val_3.z;    //  dest_result_addr=1152921513158799624
            // 0x01684230: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
            // 0x01684234: SUB sp, x29, #0x50         | SP = (1152921513158799712 - 80) = 1152921513158799632 (0x10000001FDBC7110);
            // 0x01684238: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0168423C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01684240: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x01684244: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01684248: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x0168424C: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x01684250: RET                        |  return (System.Single)val_3.x;         
            return (float)val_3.x;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684254 (23609940), len: 160  VirtAddr: 0x01684254 RVA: 0x01684254 token: 100681948 methodIndex: 49839 delegateWrapperIndex: 0 methodInvoker: 0
        public static float Hermite(float start, float end, float value)
        {
            //
            // Disasemble & Code
            // 0x01684254: STP d11, d10, [sp, #-0x40]! | stack[1152921513158911664] = ???;  stack[1152921513158911672] = ???;  //  dest_result_addr=1152921513158911664 |  dest_result_addr=1152921513158911672
            // 0x01684258: STP d9, d8, [sp, #0x10]    | stack[1152921513158911680] = ???;  stack[1152921513158911688] = ???;  //  dest_result_addr=1152921513158911680 |  dest_result_addr=1152921513158911688
            // 0x0168425C: STP x20, x19, [sp, #0x20]  | stack[1152921513158911696] = ???;  stack[1152921513158911704] = ???;  //  dest_result_addr=1152921513158911696 |  dest_result_addr=1152921513158911704
            // 0x01684260: STP x29, x30, [sp, #0x30]  | stack[1152921513158911712] = ???;  stack[1152921513158911720] = ???;  //  dest_result_addr=1152921513158911712 |  dest_result_addr=1152921513158911720
            // 0x01684264: ADD x29, sp, #0x30         | X29 = (1152921513158911664 + 48) = 1152921513158911712 (0x10000001FDBE26E0);
            // 0x01684268: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0168426C: LDRB w8, [x19, #0xdd]      | W8 = (bool)static_value_037380DD;       
            // 0x01684270: MOV v10.16b, v2.16b        | V10 = value;//m1                        
            // 0x01684274: MOV v8.16b, v1.16b         | V8 = end;//m1                           
            // 0x01684278: MOV v9.16b, v0.16b         | V9 = start;//m1                         
            // 0x0168427C: TBNZ w8, #0, #0x1684298    | if (static_value_037380DD == true) goto label_0;
            // 0x01684280: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x01684284: LDR x8, [x8, #0xcb0]       | X8 = 0x2B8EC78;                         
            // 0x01684288: LDR w0, [x8]               | W0 = 0x11DE;                            
            // 0x0168428C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11DE, ????);     
            // 0x01684290: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01684294: STRB w8, [x19, #0xdd]      | static_value_037380DD = true;            //  dest_result_addr=57901277
            label_0:
            // 0x01684298: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x0168429C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x016842A0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x016842A4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x016842A8: TBZ w8, #0, #0x16842b8     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016842AC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x016842B0: CBNZ w8, #0x16842b8        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016842B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_2:
            // 0x016842B8: FMOV s1, #-2.00000000      | S1 = -2;                                
            float val_2 = -2f;
            // 0x016842BC: FMUL s1, s10, s1           | S1 = (value * -2f);                     
            val_2 = value * val_2;
            // 0x016842C0: FMOV s2, #3.00000000       | S2 = 3;                                 
            float val_3 = 3f;
            // 0x016842C4: FMUL s0, s10, s10          | S0 = (value * value);                   
            float val_1 = value * value;
            // 0x016842C8: FADD s1, s1, s2            | S1 = ((value * -2f) + 3f);              
            val_2 = val_2 + val_3;
            // 0x016842CC: FMUL s2, s0, s1            | S2 = ((value * value) * ((value * -2f) + 3f));
            val_3 = val_1 * val_2;
            // 0x016842D0: MOV v0.16b, v9.16b         | V0 = start;//m1                         
            // 0x016842D4: MOV v1.16b, v8.16b         | V1 = end;//m1                           
            // 0x016842D8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x016842DC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x016842E0: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x016842E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016842E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016842EC: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
            // 0x016842F0: B #0x1a7dd1c               | return UnityEngine.Mathf.Lerp(a:  start, b:  end, t:  3f = val_1 * (-2f));
            return UnityEngine.Mathf.Lerp(a:  start, b:  end, t:  val_3);
        
        }
        //
        // Offset in libil2cpp.so: 0x016842F4 (23610100), len: 536  VirtAddr: 0x016842F4 RVA: 0x016842F4 token: 100681949 methodIndex: 49840 delegateWrapperIndex: 0 methodInvoker: 0
        public static UnityEngine.Vector3 CubicBezier(UnityEngine.Vector3 p0, UnityEngine.Vector3 p1, UnityEngine.Vector3 p2, UnityEngine.Vector3 p3, float t)
        {
            //
            // Disasemble & Code
            //  | 
            float val_1;
            //  | 
            float val_2;
            // 0x016842F4: STP d15, d14, [sp, #-0x60]! | stack[1152921513159023632] = ???;  stack[1152921513159023640] = ???;  //  dest_result_addr=1152921513159023632 |  dest_result_addr=1152921513159023640
            // 0x016842F8: STP d13, d12, [sp, #0x10]  | stack[1152921513159023648] = ???;  stack[1152921513159023656] = ???;  //  dest_result_addr=1152921513159023648 |  dest_result_addr=1152921513159023656
            // 0x016842FC: STP d11, d10, [sp, #0x20]  | stack[1152921513159023664] = ???;  stack[1152921513159023672] = ???;  //  dest_result_addr=1152921513159023664 |  dest_result_addr=1152921513159023672
            // 0x01684300: STP d9, d8, [sp, #0x30]    | stack[1152921513159023680] = ???;  stack[1152921513159023688] = ???;  //  dest_result_addr=1152921513159023680 |  dest_result_addr=1152921513159023688
            // 0x01684304: STP x20, x19, [sp, #0x40]  | stack[1152921513159023696] = ???;  stack[1152921513159023704] = ???;  //  dest_result_addr=1152921513159023696 |  dest_result_addr=1152921513159023704
            // 0x01684308: STP x29, x30, [sp, #0x50]  | stack[1152921513159023712] = ???;  stack[1152921513159023720] = ???;  //  dest_result_addr=1152921513159023712 |  dest_result_addr=1152921513159023720
            // 0x0168430C: ADD x29, sp, #0x50         | X29 = (1152921513159023632 + 80) = 1152921513159023712 (0x10000001FDBFDC60);
            // 0x01684310: SUB sp, sp, #0x20          | SP = (1152921513159023632 - 32) = 1152921513159023600 (0x10000001FDBFDBF0);
            // 0x01684314: STR s5, [sp, #4]           | stack[1152921513159023604] = p1.z;       //  dest_result_addr=1152921513159023604
            // 0x01684318: MOV v11.16b, v1.16b        | V11 = p0.y;//m1                         
            // 0x0168431C: LDR s1, [x29, #0x28]       | S1 = p3.x;                              
            // 0x01684320: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01684324: MOV v15.16b, v4.16b        | V15 = p1.y;//m1                         
            // 0x01684328: MOV v8.16b, v3.16b         | V8 = p1.x;//m1                          
            // 0x0168432C: STR s1, [sp, #0x1c]        | stack[1152921513159023628] = p3.x;       //  dest_result_addr=1152921513159023628
            // 0x01684330: LDR s1, [x29, #0x24]       | S1 = val_1;                              //  find_add[1152921513159011728]
            // 0x01684334: MOV v10.16b, v2.16b        | V10 = p0.z;//m1                         
            // 0x01684338: MOV v12.16b, v0.16b        | V12 = p0.x;//m1                         
            // 0x0168433C: STR s1, [sp, #0x18]        | stack[1152921513159023624] = val_1;      //  dest_result_addr=1152921513159023624
            // 0x01684340: LDR s1, [x29, #0x20]       | S1 = p2.z;                              
            // 0x01684344: STR s1, [sp, #0x14]        | stack[1152921513159023620] = p2.z;       //  dest_result_addr=1152921513159023620
            // 0x01684348: LDR s1, [x29, #0x18]       | S1 = p2.y;                              
            // 0x0168434C: STR s1, [sp, #0x10]        | stack[1152921513159023616] = p2.y;       //  dest_result_addr=1152921513159023616
            // 0x01684350: LDR s1, [x29, #0x14]       | S1 = val_2;                              //  find_add[1152921513159011728]
            // 0x01684354: STR s1, [sp, #0xc]         | stack[1152921513159023612] = val_2;      //  dest_result_addr=1152921513159023612
            // 0x01684358: LDR s1, [x29, #0x10]       | S1 = p2.x;                              
            // 0x0168435C: STR s1, [sp, #8]           | stack[1152921513159023608] = p2.x;       //  dest_result_addr=1152921513159023608
            // 0x01684360: LDR s9, [x29, #0x30]       | S9 = p3.y;                              
            // 0x01684364: LDRB w8, [x19, #0xde]      | W8 = (bool)static_value_037380DE;       
            // 0x01684368: TBNZ w8, #0, #0x1684384    | if (static_value_037380DE == true) goto label_0;
            // 0x0168436C: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x01684370: LDR x8, [x8, #0xd30]       | X8 = 0x2B8EC64;                         
            // 0x01684374: LDR w0, [x8]               | W0 = 0x11D9;                            
            // 0x01684378: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D9, ????);     
            // 0x0168437C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01684380: STRB w8, [x19, #0xde]      | static_value_037380DE = true;            //  dest_result_addr=57901278
            label_0:
            // 0x01684384: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x01684388: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x0168438C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x01684390: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x01684394: TBZ w8, #0, #0x16843a4     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01684398: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x0168439C: CBNZ w8, #0x16843a4        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016843A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_2:
            // 0x016843A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016843A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016843AC: MOV v0.16b, v9.16b         | V0 = p3.y;//m1                          
            // 0x016843B0: BL #0x1a7dd00              | X0 = UnityEngine.Mathf.Clamp01(value:  p3.y);
            float val_3 = UnityEngine.Mathf.Clamp01(value:  p3.y);
            // 0x016843B4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x016843B8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x016843BC: MOV v9.16b, v0.16b         | V9 = val_3;//m1                         
            // 0x016843C0: FMOV s0, #1.00000000       | S0 = 1;                                 
            float val_14 = 1f;
            // 0x016843C4: FSUB s13, s0, s9           | S13 = (1f - val_3);                     
            float val_4 = val_14 - val_3;
            // 0x016843C8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x016843CC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x016843D0: TBZ w8, #0, #0x16843e0     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x016843D4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x016843D8: CBNZ w8, #0x16843e0        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x016843DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_4:
            // 0x016843E0: FMUL s0, s13, s13          | S0 = ((1f - val_3) * (1f - val_3));     
            val_14 = val_4 * val_4;
            // 0x016843E4: FMUL s0, s13, s0           | S0 = ((1f - val_3) * ((1f - val_3) * (1f - val_3)));
            val_14 = val_4 * val_14;
            // 0x016843E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016843EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016843F0: MOV v1.16b, v12.16b        | V1 = p0.x;//m1                          
            // 0x016843F4: MOV v2.16b, v11.16b        | V2 = p0.y;//m1                          
            // 0x016843F8: MOV v3.16b, v10.16b        | V3 = p0.z;//m1                          
            // 0x016843FC: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  1f = val_4 * 1f, a:  new UnityEngine.Vector3() {x = p0.x, y = p0.y, z = p0.z});
            UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Multiply(d:  val_14, a:  new UnityEngine.Vector3() {x = p0.x, y = p0.y, z = p0.z});
            // 0x01684400: MOV v10.16b, v0.16b        | V10 = val_5.x;//m1                      
            // 0x01684404: FMOV s0, #3.00000000       | S0 = 3;                                 
            float val_15 = 3f;
            // 0x01684408: LDR s3, [sp, #4]           | S3 = p1.z;                              
            // 0x0168440C: FMUL s14, s13, s0          | S14 = ((1f - val_3) * 3f);              
            float val_6 = val_4 * val_15;
            // 0x01684410: FMUL s0, s13, s14          | S0 = ((1f - val_3) * ((1f - val_3) * 3f));
            val_15 = val_4 * val_6;
            // 0x01684414: MOV v11.16b, v1.16b        | V11 = val_5.y;//m1                      
            // 0x01684418: MOV v12.16b, v2.16b        | V12 = val_5.z;//m1                      
            // 0x0168441C: FMUL s0, s9, s0            | S0 = (val_3 * ((1f - val_3) * ((1f - val_3) * 3f)));
            val_15 = val_3 * val_15;
            // 0x01684420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684424: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684428: MOV v1.16b, v8.16b         | V1 = p1.x;//m1                          
            // 0x0168442C: MOV v2.16b, v15.16b        | V2 = p1.y;//m1                          
            // 0x01684430: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  3f = val_3 * 3f, a:  new UnityEngine.Vector3() {x = p1.x, y = p1.y, z = p1.z});
            UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Multiply(d:  val_15, a:  new UnityEngine.Vector3() {x = p1.x, y = p1.y, z = p1.z});
            // 0x01684434: MOV v3.16b, v0.16b         | V3 = val_7.x;//m1                       
            // 0x01684438: MOV v4.16b, v1.16b         | V4 = val_7.y;//m1                       
            // 0x0168443C: MOV v5.16b, v2.16b         | V5 = val_7.z;//m1                       
            // 0x01684440: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684444: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684448: MOV v0.16b, v10.16b        | V0 = val_5.x;//m1                       
            // 0x0168444C: MOV v1.16b, v11.16b        | V1 = val_5.y;//m1                       
            // 0x01684450: MOV v2.16b, v12.16b        | V2 = val_5.z;//m1                       
            // 0x01684454: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z});
            UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z});
            // 0x01684458: MOV v10.16b, v1.16b        | V10 = val_8.y;//m1                      
            // 0x0168445C: MOV v11.16b, v2.16b        | V11 = val_8.z;//m1                      
            // 0x01684460: LDP s1, s2, [sp, #8]       | S1 = p2.x; S2 = val_2;                   //  | 
            // 0x01684464: LDR s3, [sp, #0x10]        | S3 = p2.y;                              
            // 0x01684468: MOV v8.16b, v0.16b         | V8 = val_8.x;//m1                       
            // 0x0168446C: FMUL s0, s9, s14           | S0 = (val_3 * ((1f - val_3) * 3f));     
            float val_9 = val_3 * val_6;
            // 0x01684470: FMUL s0, s9, s0            | S0 = (val_3 * (val_3 * ((1f - val_3) * 3f)));
            val_9 = val_3 * val_9;
            // 0x01684474: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684478: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168447C: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  val_9 = val_3 * val_9, a:  new UnityEngine.Vector3() {x = p2.x, y = val_2, z = p2.y});
            UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Multiply(d:  val_9, a:  new UnityEngine.Vector3() {x = p2.x, y = val_2, z = p2.y});
            // 0x01684480: MOV v3.16b, v0.16b         | V3 = val_10.x;//m1                      
            // 0x01684484: MOV v4.16b, v1.16b         | V4 = val_10.y;//m1                      
            // 0x01684488: MOV v5.16b, v2.16b         | V5 = val_10.z;//m1                      
            // 0x0168448C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684490: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684494: MOV v0.16b, v8.16b         | V0 = val_8.x;//m1                       
            // 0x01684498: MOV v1.16b, v10.16b        | V1 = val_8.y;//m1                       
            // 0x0168449C: MOV v2.16b, v11.16b        | V2 = val_8.z;//m1                       
            // 0x016844A0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, b:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z});
            UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, b:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z});
            // 0x016844A4: MOV v10.16b, v1.16b        | V10 = val_11.y;//m1                     
            // 0x016844A8: MOV v11.16b, v2.16b        | V11 = val_11.z;//m1                     
            // 0x016844AC: LDP s1, s2, [sp, #0x14]    | S1 = p2.z; S2 = val_1;                   //  | 
            // 0x016844B0: LDR s3, [sp, #0x1c]        | S3 = p3.x;                              
            // 0x016844B4: MOV v8.16b, v0.16b         | V8 = val_11.x;//m1                      
            // 0x016844B8: FMUL s0, s9, s9            | S0 = (val_3 * val_3);                   
            float val_12 = val_3 * val_3;
            // 0x016844BC: FMUL s0, s9, s0            | S0 = (val_3 * (val_3 * val_3));         
            val_12 = val_3 * val_12;
            // 0x016844C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016844C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016844C8: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  val_12 = val_3 * val_12, a:  new UnityEngine.Vector3() {x = p2.z, y = val_1, z = p3.x});
            UnityEngine.Vector3 val_13 = UnityEngine.Vector3.op_Multiply(d:  val_12, a:  new UnityEngine.Vector3() {x = p2.z, y = val_1, z = p3.x});
            // 0x016844CC: MOV v3.16b, v0.16b         | V3 = val_13.x;//m1                      
            // 0x016844D0: MOV v4.16b, v1.16b         | V4 = val_13.y;//m1                      
            // 0x016844D4: MOV v5.16b, v2.16b         | V5 = val_13.z;//m1                      
            // 0x016844D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016844DC: MOV v0.16b, v8.16b         | V0 = val_11.x;//m1                      
            // 0x016844E0: MOV v1.16b, v10.16b        | V1 = val_11.y;//m1                      
            // 0x016844E4: MOV v2.16b, v11.16b        | V2 = val_11.z;//m1                      
            // 0x016844E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016844EC: SUB sp, x29, #0x50         | SP = (1152921513159023712 - 80) = 1152921513159023632 (0x10000001FDBFDC10);
            // 0x016844F0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x016844F4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x016844F8: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x016844FC: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01684500: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01684504: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x01684508: B #0x2694984               | return UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, b:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z});
            return UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, b:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z});
        
        }
        //
        // Offset in libil2cpp.so: 0x0168450C (23610636), len: 144  VirtAddr: 0x0168450C RVA: 0x0168450C token: 100681950 methodIndex: 49841 delegateWrapperIndex: 0 methodInvoker: 0
        public static float MapTo(float startMin, float startMax, float value)
        {
            //
            // Disasemble & Code
            // 0x0168450C: STP d11, d10, [sp, #-0x40]! | stack[1152921513159135664] = ???;  stack[1152921513159135672] = ???;  //  dest_result_addr=1152921513159135664 |  dest_result_addr=1152921513159135672
            // 0x01684510: STP d9, d8, [sp, #0x10]    | stack[1152921513159135680] = ???;  stack[1152921513159135688] = ???;  //  dest_result_addr=1152921513159135680 |  dest_result_addr=1152921513159135688
            // 0x01684514: STP x20, x19, [sp, #0x20]  | stack[1152921513159135696] = ???;  stack[1152921513159135704] = ???;  //  dest_result_addr=1152921513159135696 |  dest_result_addr=1152921513159135704
            // 0x01684518: STP x29, x30, [sp, #0x30]  | stack[1152921513159135712] = ???;  stack[1152921513159135720] = ???;  //  dest_result_addr=1152921513159135712 |  dest_result_addr=1152921513159135720
            // 0x0168451C: ADD x29, sp, #0x30         | X29 = (1152921513159135664 + 48) = 1152921513159135712 (0x10000001FDC191E0);
            // 0x01684520: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01684524: LDRB w8, [x19, #0xdf]      | W8 = (bool)static_value_037380DF;       
            // 0x01684528: MOV v8.16b, v2.16b         | V8 = value;//m1                         
            float val_1 = value;
            // 0x0168452C: MOV v9.16b, v1.16b         | V9 = startMax;//m1                      
            // 0x01684530: MOV v10.16b, v0.16b        | V10 = startMin;//m1                     
            // 0x01684534: TBNZ w8, #0, #0x1684550    | if (static_value_037380DF == true) goto label_0;
            // 0x01684538: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x0168453C: LDR x8, [x8, #0x700]       | X8 = 0x2B8EC84;                         
            // 0x01684540: LDR w0, [x8]               | W0 = 0x11E1;                            
            // 0x01684544: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E1, ????);     
            // 0x01684548: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168454C: STRB w8, [x19, #0xdf]      | static_value_037380DF = true;            //  dest_result_addr=57901279
            label_0:
            // 0x01684550: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x01684554: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x01684558: FSUB s0, s8, s10           | S0 = (value - startMin);                
            startMin = val_1 - startMin;
            // 0x0168455C: FSUB s1, s9, s10           | S1 = (startMax - startMin);             
            startMax = startMax - startMin;
            // 0x01684560: FDIV s8, s0, s1            | S8 = ((value - startMin) / (startMax - startMin));
            val_1 = startMin / startMax;
            // 0x01684564: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x01684568: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x0168456C: TBZ w8, #0, #0x168457c     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01684570: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x01684574: CBNZ w8, #0x168457c        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01684578: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_2:
            // 0x0168457C: MOV v0.16b, v8.16b         | V0 = ((value - startMin) / (startMax - startMin));//m1
            // 0x01684580: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01684584: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01684588: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x0168458C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684590: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684594: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
            // 0x01684598: B #0x1a7dd00               | return UnityEngine.Mathf.Clamp01(value:  value);
            return UnityEngine.Mathf.Clamp01(value:  val_1);
        
        }
        //
        // Offset in libil2cpp.so: 0x0168459C (23610780), len: 16  VirtAddr: 0x0168459C RVA: 0x0168459C token: 100681951 methodIndex: 49842 delegateWrapperIndex: 0 methodInvoker: 0
        public static float MapToRange(float targetMin, float targetMax, float value)
        {
            //
            // Disasemble & Code
            // 0x0168459C: FSUB s1, s1, s0            | S1 = (targetMax - targetMin);           
            targetMax = targetMax - targetMin;
            // 0x016845A0: FMUL s1, s1, s2            | S1 = ((targetMax - targetMin) * value); 
            targetMax = targetMax * value;
            // 0x016845A4: FADD s0, s1, s0            | S0 = (((targetMax - targetMin) * value) + targetMin);
            targetMin = targetMax + targetMin;
            // 0x016845A8: RET                        |  return (System.Single)(((targetMax - targetMin) * value) + targetMin);
            return (float)targetMin;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x016845AC (23610796), len: 176  VirtAddr: 0x016845AC RVA: 0x016845AC token: 100681952 methodIndex: 49843 delegateWrapperIndex: 0 methodInvoker: 0
        public static float MapTo(float startMin, float startMax, float targetMin, float targetMax, float value)
        {
            //
            // Disasemble & Code
            // 0x016845AC: STP d13, d12, [sp, #-0x50]! | stack[1152921513159359648] = ???;  stack[1152921513159359656] = ???;  //  dest_result_addr=1152921513159359648 |  dest_result_addr=1152921513159359656
            // 0x016845B0: STP d11, d10, [sp, #0x10]  | stack[1152921513159359664] = ???;  stack[1152921513159359672] = ???;  //  dest_result_addr=1152921513159359664 |  dest_result_addr=1152921513159359672
            // 0x016845B4: STP d9, d8, [sp, #0x20]    | stack[1152921513159359680] = ???;  stack[1152921513159359688] = ???;  //  dest_result_addr=1152921513159359680 |  dest_result_addr=1152921513159359688
            // 0x016845B8: STP x20, x19, [sp, #0x30]  | stack[1152921513159359696] = ???;  stack[1152921513159359704] = ???;  //  dest_result_addr=1152921513159359696 |  dest_result_addr=1152921513159359704
            // 0x016845BC: STP x29, x30, [sp, #0x40]  | stack[1152921513159359712] = ???;  stack[1152921513159359720] = ???;  //  dest_result_addr=1152921513159359712 |  dest_result_addr=1152921513159359720
            // 0x016845C0: ADD x29, sp, #0x40         | X29 = (1152921513159359648 + 64) = 1152921513159359712 (0x10000001FDC4FCE0);
            // 0x016845C4: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x016845C8: LDRB w8, [x19, #0xe0]      | W8 = (bool)static_value_037380E0;       
            // 0x016845CC: MOV v10.16b, v4.16b        | V10 = value;//m1                        
            float val_3 = value;
            // 0x016845D0: MOV v8.16b, v3.16b         | V8 = targetMax;//m1                     
            // 0x016845D4: MOV v9.16b, v2.16b         | V9 = targetMin;//m1                     
            // 0x016845D8: MOV v11.16b, v1.16b        | V11 = startMax;//m1                     
            // 0x016845DC: MOV v12.16b, v0.16b        | V12 = startMin;//m1                     
            // 0x016845E0: TBNZ w8, #0, #0x16845fc    | if (static_value_037380E0 == true) goto label_0;
            // 0x016845E4: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x016845E8: LDR x8, [x8, #0xa78]       | X8 = 0x2B8EC80;                         
            // 0x016845EC: LDR w0, [x8]               | W0 = 0x11E0;                            
            // 0x016845F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E0, ????);     
            // 0x016845F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016845F8: STRB w8, [x19, #0xe0]      | static_value_037380E0 = true;            //  dest_result_addr=57901280
            label_0:
            // 0x016845FC: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x01684600: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x01684604: FSUB s0, s10, s12          | S0 = (value - startMin);                
            startMin = val_3 - startMin;
            // 0x01684608: FSUB s1, s11, s12          | S1 = (startMax - startMin);             
            startMax = startMax - startMin;
            // 0x0168460C: FDIV s10, s0, s1           | S10 = ((value - startMin) / (startMax - startMin));
            val_3 = startMin / startMax;
            // 0x01684610: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x01684614: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x01684618: TBZ w8, #0, #0x1684628     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0168461C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x01684620: CBNZ w8, #0x1684628        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01684624: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_2:
            // 0x01684628: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168462C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684630: MOV v0.16b, v10.16b        | V0 = ((value - startMin) / (startMax - startMin));//m1
            // 0x01684634: BL #0x1a7dd00              | X0 = UnityEngine.Mathf.Clamp01(value:  value);
            float val_1 = UnityEngine.Mathf.Clamp01(value:  val_3);
            // 0x01684638: FSUB s1, s8, s9            | S1 = (targetMax - targetMin);           
            float val_2 = targetMax - targetMin;
            // 0x0168463C: FMUL s0, s1, s0            | S0 = ((targetMax - targetMin) * val_1); 
            val_1 = val_2 * val_1;
            // 0x01684640: FADD s0, s0, s9            | S0 = (((targetMax - targetMin) * val_1) + targetMin);
            val_1 = val_1 + targetMin;
            // 0x01684644: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01684648: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0168464C: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x01684650: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x01684654: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
            // 0x01684658: RET                        |  return (System.Single)(((targetMax - targetMin) * val_1) + targetMin);
            return (float)val_1;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168465C (23610972), len: 528  VirtAddr: 0x0168465C RVA: 0x0168465C token: 100681953 methodIndex: 49844 delegateWrapperIndex: 0 methodInvoker: 0
        public static string FormatBytes(int bytes)
        {
            //
            // Disasemble & Code
            //  | 
            string val_7;
            //  | 
            var val_8;
            // 0x0168465C: STP x20, x19, [sp, #-0x20]! | stack[1152921513159488480] = ???;  stack[1152921513159488488] = ???;  //  dest_result_addr=1152921513159488480 |  dest_result_addr=1152921513159488488
            // 0x01684660: STP x29, x30, [sp, #0x10]  | stack[1152921513159488496] = ???;  stack[1152921513159488504] = ???;  //  dest_result_addr=1152921513159488496 |  dest_result_addr=1152921513159488504
            // 0x01684664: ADD x29, sp, #0x10         | X29 = (1152921513159488480 + 16) = 1152921513159488496 (0x10000001FDC6F3F0);
            // 0x01684668: SUB sp, sp, #0x20          | SP = (1152921513159488480 - 32) = 1152921513159488448 (0x10000001FDC6F3C0);
            // 0x0168466C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01684670: LDRB w8, [x20, #0xe1]      | W8 = (bool)static_value_037380E1;       
            // 0x01684674: MOV w19, w1                | W19 = W1;//m1                           
            // 0x01684678: TBNZ w8, #0, #0x1684694    | if (static_value_037380E1 == true) goto label_0;
            // 0x0168467C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x01684680: LDR x8, [x8, #0xf00]       | X8 = 0x2B8EC70;                         
            // 0x01684684: LDR w0, [x8]               | W0 = 0x11DC;                            
            // 0x01684688: BL #0x2782188              | X0 = sub_2782188( ?? 0x11DC, ????);     
            // 0x0168468C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01684690: STRB w8, [x20, #0xe1]      | static_value_037380E1 = true;            //  dest_result_addr=57901281
            label_0:
            // 0x01684694: STP xzr, xzr, [sp, #0x10]  | stack[1152921513159488464] = 0x0;  stack[1152921513159488472] = 0x0;  //  dest_result_addr=1152921513159488464 |  dest_result_addr=1152921513159488472
            // 0x01684698: STP xzr, xzr, [sp]         | stack[1152921513159488448] = 0x0;  stack[1152921513159488456] = 0x0;  //  dest_result_addr=1152921513159488448 |  dest_result_addr=1152921513159488456
            // 0x0168469C: CMP w19, #0                | STATE = COMPARE(W1, 0x0)                
            // 0x016846A0: FMOV d0, #1.00000000       | D0 = 1;                                 
            // 0x016846A4: FMOV d1, #-1.00000000      | D1 = -1;                                
            // 0x016846A8: CNEG w8, w19, mi           | W8 = W1 < 0 ?  (-W1) : W1;              
            var val_1 = (W1 < 0) ? (-W1) : (W1);
            // 0x016846AC: FCSEL d0, d1, d0, lt       | D0 = W1 < 0x0 ? -1 : 1;                 
            float val_2 = (W1 < 0) ? (-1) : (1);
            // 0x016846B0: CMP w8, #0x3e7             | STATE = COMPARE(W1 < 0 ?  (-W1) : W1, 0x3E7)
            // 0x016846B4: B.LE #0x168473c            | if (val_1 <= 0x3E7) goto label_1;       
            if(val_1 <= 999)
            {
                goto label_1;
            }
            // 0x016846B8: MOVZ w9, #0xf, lsl #16     | W9 = 983040 (0xF0000);//ML01            
            // 0x016846BC: MOVK w9, #0x423f           | W9 = 999999 (0xF423F);                  
            // 0x016846C0: CMP w8, w9                 | STATE = COMPARE(W1 < 0 ?  (-W1) : W1, 0xF423F)
            // 0x016846C4: B.LE #0x1684788            | if (val_1 <= 0xF423F) goto label_2;     
            if(val_1 <= 999999)
            {
                goto label_2;
            }
            // 0x016846C8: MOVZ w9, #0x3b9a, lsl #16  | W9 = 999948288 (0x3B9A0000);//ML01      
            // 0x016846CC: SCVTF d1, w8               | D1 = (double)(W1 < 0 ?  (-W1) : W1);    
            double val_7 = (double)val_1;
            // 0x016846D0: MOVK w9, #0xc9ff           | W9 = 999999999 (0x3B9AC9FF);            
            // 0x016846D4: CMP w8, w9                 | STATE = COMPARE(W1 < 0 ?  (-W1) : W1, 0x3B9AC9FF)
            // 0x016846D8: B.LE #0x16847ec            | if (val_1 <= 0x3B9AC9FF) goto label_3;  
            if(val_1 <= 999999999)
            {
                goto label_3;
            }
            // 0x016846DC: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x016846E0: LDR d2, [x8, #0xed8]       | D2 = 1000000000;                        
            // 0x016846E4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x016846E8: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921513159459728)("0.0");
            // 0x016846EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016846F0: FDIV d1, d1, d2            | D1 = (W1 < 0 ?  (-W1) : W1 / 1000000000);
            val_7 = val_7 / 1000000000;
            // 0x016846F4: FMUL d0, d0, d1            | D0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 / 1000000000));
            val_2 = val_2 * val_7;
            // 0x016846F8: LDR x1, [x8]               | X1 = "0.0";                             
            // 0x016846FC: MOV x0, sp                 | X0 = 1152921513159488448 (0x10000001FDC6F3C0);//ML01
            // 0x01684700: STR d0, [sp]               | stack[1152921513159488448] = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 / 1000000000));  //  dest_result_addr=1152921513159488448
            // 0x01684704: BL #0x1c3883c              | X0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 / 1000000000)).ToString(format:  "0.0");
            string val_3 = val_2.ToString(format:  "0.0");
            // 0x01684708: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0168470C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01684710: MOV x19, x0                | X19 = val_3;//m1                        
            val_7 = val_3;
            // 0x01684714: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x01684718: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0168471C: TBZ w9, #0, #0x1684730     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01684720: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01684724: CBNZ w9, #0x1684730        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01684728: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0168472C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_5:
            // 0x01684730: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x01684734: LDR x8, [x8, #0x688]       | X8 = (string**)(1152921513159463904)(" gb");
            val_8 = " gb";
            // 0x01684738: B #0x1684848               |  goto label_12;                         
            goto label_12;
            label_1:
            // 0x0168473C: SCVTF d1, w8               | D1 = (double)(W1 < 0 ?  (-W1) : W1);    
            // 0x01684740: FMUL d0, d0, d1            | D0 = (W1 < 0x0 ? -1 : 1 * W1 < 0 ?  (-W1) : W1);
            val_2 = val_2 * (double)val_1;
            // 0x01684744: ADD x0, sp, #0x18          | X0 = (1152921513159488448 + 24) = 1152921513159488472 (0x10000001FDC6F3D8);
            // 0x01684748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168474C: STR d0, [sp, #0x18]        | stack[1152921513159488472] = (W1 < 0x0 ? -1 : 1 * W1 < 0 ?  (-W1) : W1);  //  dest_result_addr=1152921513159488472
            // 0x01684750: BL #0x1c387bc              | X0 = label_System_Double_TryParse_GL01C387BC();
            // 0x01684754: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01684758: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0168475C: MOV x19, x0                | X19 = 1152921513159488472 (0x10000001FDC6F3D8);//ML01
            val_7;
            // 0x01684760: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x01684764: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x01684768: TBZ w9, #0, #0x168477c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x0168476C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01684770: CBNZ w9, #0x168477c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01684774: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01684778: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_8:
            // 0x0168477C: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x01684780: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921513159463984)(" bytes");
            val_8 = " bytes";
            // 0x01684784: B #0x1684848               |  goto label_12;                         
            goto label_12;
            label_2:
            // 0x01684788: SCVTF d2, w8               | D2 = (double)(W1 < 0 ?  (-W1) : W1);    
            // 0x0168478C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x01684790: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921513159459728)("0.0");
            // 0x01684794: ADRP x9, #0x2a97000        | X9 = 44658688 (0x2A97000);              
            // 0x01684798: LDR d1, [x9, #0x718]       | D1 = 1000;                              
            double val_8 = 1000;
            // 0x0168479C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016847A0: LDR x1, [x8]               | X1 = "0.0";                             
            // 0x016847A4: ADD x0, sp, #0x10          | X0 = (1152921513159488448 + 16) = 1152921513159488464 (0x10000001FDC6F3D0);
            // 0x016847A8: FDIV d1, d2, d1            | D1 = (W1 < 0 ?  (-W1) : W1 / 1000);     
            val_8 = (double)val_1 / val_8;
            // 0x016847AC: FMUL d0, d0, d1            | D0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 / 1000));
            val_2 = val_2 * val_8;
            // 0x016847B0: STR d0, [sp, #0x10]        | stack[1152921513159488464] = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 / 1000));  //  dest_result_addr=1152921513159488464
            // 0x016847B4: BL #0x1c3883c              | X0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 / 1000)).ToString(format:  "0.0");
            string val_4 = val_2.ToString(format:  "0.0");
            // 0x016847B8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x016847BC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x016847C0: MOV x19, x0                | X19 = val_4;//m1                        
            val_7 = val_4;
            // 0x016847C4: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x016847C8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x016847CC: TBZ w9, #0, #0x16847e0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x016847D0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x016847D4: CBNZ w9, #0x16847e0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x016847D8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x016847DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_11:
            // 0x016847E0: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x016847E4: LDR x8, [x8, #0x430]       | X8 = (string**)(1152921513159468160)(" kb");
            val_8 = " kb";
            // 0x016847E8: B #0x1684848               |  goto label_12;                         
            goto label_12;
            label_3:
            // 0x016847EC: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x016847F0: LDR d2, [x8, #0xed0]       | D2 = 1000000;                           
            // 0x016847F4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x016847F8: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921513159459728)("0.0");
            // 0x016847FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01684800: FDIV d1, d1, d2            | D1 = (W1 < 0 ?  (-W1) : W1 / 1000000);  
            val_7 = val_7 / 1000000;
            // 0x01684804: FMUL d0, d0, d1            | D0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 / 1000000));
            val_2 = val_2 * val_7;
            // 0x01684808: LDR x1, [x8]               | X1 = "0.0";                             
            // 0x0168480C: ADD x0, sp, #8             | X0 = (1152921513159488448 + 8) = 1152921513159488456 (0x10000001FDC6F3C8);
            // 0x01684810: STR d0, [sp, #8]           | stack[1152921513159488456] = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 / 1000000));  //  dest_result_addr=1152921513159488456
            // 0x01684814: BL #0x1c3883c              | X0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 / 1000000)).ToString(format:  "0.0");
            string val_5 = val_2.ToString(format:  "0.0");
            // 0x01684818: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0168481C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01684820: MOV x19, x0                | X19 = val_5;//m1                        
            val_7 = val_5;
            // 0x01684824: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x01684828: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0168482C: TBZ w9, #0, #0x1684840     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x01684830: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01684834: CBNZ w9, #0x1684840        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x01684838: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0168483C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_14:
            // 0x01684840: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x01684844: LDR x8, [x8, #0xfe8]       | X8 = (string**)(1152921513159472336)(" mb");
            val_8 = " mb";
            label_12:
            // 0x01684848: LDR x2, [x8]               | X2 = " mb";                             
            // 0x0168484C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684850: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01684854: MOV x1, x19                | X1 = val_5;//m1                         
            // 0x01684858: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_7);
            string val_6 = System.String.Concat(str0:  0, str1:  val_7);
            // 0x0168485C: SUB sp, x29, #0x10         | SP = (1152921513159488496 - 16) = 1152921513159488480 (0x10000001FDC6F3E0);
            // 0x01684860: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01684864: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01684868: RET                        |  return (System.String)val_6;           
            return val_6;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168486C (23611500), len: 516  VirtAddr: 0x0168486C RVA: 0x0168486C token: 100681954 methodIndex: 49845 delegateWrapperIndex: 0 methodInvoker: 0
        public static string FormatBytesBinary(int bytes)
        {
            //
            // Disasemble & Code
            //  | 
            string val_7;
            //  | 
            var val_8;
            // 0x0168486C: STP x20, x19, [sp, #-0x20]! | stack[1152921513159633248] = ???;  stack[1152921513159633256] = ???;  //  dest_result_addr=1152921513159633248 |  dest_result_addr=1152921513159633256
            // 0x01684870: STP x29, x30, [sp, #0x10]  | stack[1152921513159633264] = ???;  stack[1152921513159633272] = ???;  //  dest_result_addr=1152921513159633264 |  dest_result_addr=1152921513159633272
            // 0x01684874: ADD x29, sp, #0x10         | X29 = (1152921513159633248 + 16) = 1152921513159633264 (0x10000001FDC92970);
            // 0x01684878: SUB sp, sp, #0x20          | SP = (1152921513159633248 - 32) = 1152921513159633216 (0x10000001FDC92940);
            // 0x0168487C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01684880: LDRB w8, [x20, #0xe2]      | W8 = (bool)static_value_037380E2;       
            // 0x01684884: MOV w19, w1                | W19 = W1;//m1                           
            // 0x01684888: TBNZ w8, #0, #0x16848a4    | if (static_value_037380E2 == true) goto label_0;
            // 0x0168488C: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x01684890: LDR x8, [x8, #0x4c8]       | X8 = 0x2B8EC74;                         
            // 0x01684894: LDR w0, [x8]               | W0 = 0x11DD;                            
            // 0x01684898: BL #0x2782188              | X0 = sub_2782188( ?? 0x11DD, ????);     
            // 0x0168489C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016848A0: STRB w8, [x20, #0xe2]      | static_value_037380E2 = true;            //  dest_result_addr=57901282
            label_0:
            // 0x016848A4: STP xzr, xzr, [sp, #0x10]  | stack[1152921513159633232] = 0x0;  stack[1152921513159633240] = 0x0;  //  dest_result_addr=1152921513159633232 |  dest_result_addr=1152921513159633240
            // 0x016848A8: STP xzr, xzr, [sp]         | stack[1152921513159633216] = 0x0;  stack[1152921513159633224] = 0x0;  //  dest_result_addr=1152921513159633216 |  dest_result_addr=1152921513159633224
            // 0x016848AC: CMP w19, #0                | STATE = COMPARE(W1, 0x0)                
            // 0x016848B0: FMOV d0, #1.00000000       | D0 = 1;                                 
            // 0x016848B4: FMOV d1, #-1.00000000      | D1 = -1;                                
            // 0x016848B8: CNEG w8, w19, mi           | W8 = W1 < 0 ?  (-W1) : W1;              
            var val_1 = (W1 < 0) ? (-W1) : (W1);
            // 0x016848BC: FCSEL d0, d1, d0, lt       | D0 = W1 < 0x0 ? -1 : 1;                 
            float val_2 = (W1 < 0) ? (-1) : (1);
            // 0x016848C0: CMP w8, #0x3ff             | STATE = COMPARE(W1 < 0 ?  (-W1) : W1, 0x3FF)
            // 0x016848C4: B.LE #0x1684940            | if (val_1 <= 0x3FF) goto label_1;       
            if(val_1 <= 1023)
            {
                goto label_1;
            }
            // 0x016848C8: CMP w8, #0x100, lsl #12    | STATE = COMPARE(W1 < 0 ?  (-W1) : W1, 0x100000)
            // 0x016848CC: B.LT #0x168498c            | if (val_1 < 0x100000) goto label_2;     
            if(val_1 < 1048576)
            {
                goto label_2;
            }
            // 0x016848D0: SCVTF d1, w8               | D1 = (double)(W1 < 0 ?  (-W1) : W1);    
            double val_7 = (double)val_1;
            // 0x016848D4: ORR w9, wzr, #0x3fffffff   | W9 = 1073741823(0x3FFFFFFF);            
            // 0x016848D8: CMP w8, w9                 | STATE = COMPARE(W1 < 0 ?  (-W1) : W1, 0x3FFFFFFF)
            // 0x016848DC: B.LE #0x16849f0            | if (val_1 <= 1073741823) goto label_3;  
            if(val_1 <= 1073741823)
            {
                goto label_3;
            }
            // 0x016848E0: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x016848E4: LDR d2, [x8, #0xef0]       | D2 = 9.31322574615479E-10;              
            // 0x016848E8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x016848EC: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921513159459728)("0.0");
            // 0x016848F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016848F4: FMUL d1, d1, d2            | D1 = (W1 < 0 ?  (-W1) : W1 * 9.31322574615479E-10);
            val_7 = val_7 * (9.31322574615479E-10);
            // 0x016848F8: FMUL d0, d0, d1            | D0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 * 9.31322574615479E-10));
            val_2 = val_2 * val_7;
            // 0x016848FC: LDR x1, [x8]               | X1 = "0.0";                             
            // 0x01684900: MOV x0, sp                 | X0 = 1152921513159633216 (0x10000001FDC92940);//ML01
            // 0x01684904: STR d0, [sp]               | stack[1152921513159633216] = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 * 9.31322574615479E-10));  //  dest_result_addr=1152921513159633216
            // 0x01684908: BL #0x1c3883c              | X0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 * 9.31322574615479E-10)).ToString(format:  "0.0");
            string val_3 = val_2.ToString(format:  "0.0");
            // 0x0168490C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01684910: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01684914: MOV x19, x0                | X19 = val_3;//m1                        
            val_7 = val_3;
            // 0x01684918: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x0168491C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x01684920: TBZ w9, #0, #0x1684934     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01684924: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01684928: CBNZ w9, #0x1684934        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0168492C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01684930: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_5:
            // 0x01684934: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x01684938: LDR x8, [x8, #0x688]       | X8 = (string**)(1152921513159463904)(" gb");
            val_8 = " gb";
            // 0x0168493C: B #0x1684a4c               |  goto label_12;                         
            goto label_12;
            label_1:
            // 0x01684940: SCVTF d1, w8               | D1 = (double)(W1 < 0 ?  (-W1) : W1);    
            // 0x01684944: FMUL d0, d0, d1            | D0 = (W1 < 0x0 ? -1 : 1 * W1 < 0 ?  (-W1) : W1);
            val_2 = val_2 * (double)val_1;
            // 0x01684948: ADD x0, sp, #0x18          | X0 = (1152921513159633216 + 24) = 1152921513159633240 (0x10000001FDC92958);
            // 0x0168494C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684950: STR d0, [sp, #0x18]        | stack[1152921513159633240] = (W1 < 0x0 ? -1 : 1 * W1 < 0 ?  (-W1) : W1);  //  dest_result_addr=1152921513159633240
            // 0x01684954: BL #0x1c387bc              | X0 = label_System_Double_TryParse_GL01C387BC();
            // 0x01684958: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0168495C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01684960: MOV x19, x0                | X19 = 1152921513159633240 (0x10000001FDC92958);//ML01
            val_7;
            // 0x01684964: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x01684968: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0168496C: TBZ w9, #0, #0x1684980     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01684970: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01684974: CBNZ w9, #0x1684980        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01684978: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0168497C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_8:
            // 0x01684980: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x01684984: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921513159463984)(" bytes");
            val_8 = " bytes";
            // 0x01684988: B #0x1684a4c               |  goto label_12;                         
            goto label_12;
            label_2:
            // 0x0168498C: SCVTF d2, w8               | D2 = (double)(W1 < 0 ?  (-W1) : W1);    
            // 0x01684990: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x01684994: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921513159459728)("0.0");
            // 0x01684998: ADRP x9, #0x2aa0000        | X9 = 44695552 (0x2AA0000);              
            // 0x0168499C: LDR d1, [x9, #0xee0]       | D1 = 0.0009765625;                      
            double val_8 = 0.0009765625;
            // 0x016849A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016849A4: LDR x1, [x8]               | X1 = "0.0";                             
            // 0x016849A8: ADD x0, sp, #0x10          | X0 = (1152921513159633216 + 16) = 1152921513159633232 (0x10000001FDC92950);
            // 0x016849AC: FMUL d1, d2, d1            | D1 = (W1 < 0 ?  (-W1) : W1 * 0.0009765625);
            val_8 = (double)val_1 * val_8;
            // 0x016849B0: FMUL d0, d0, d1            | D0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 * 0.0009765625));
            val_2 = val_2 * val_8;
            // 0x016849B4: STR d0, [sp, #0x10]        | stack[1152921513159633232] = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 * 0.0009765625));  //  dest_result_addr=1152921513159633232
            // 0x016849B8: BL #0x1c3883c              | X0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 * 0.0009765625)).ToString(format:  "0.0");
            string val_4 = val_2.ToString(format:  "0.0");
            // 0x016849BC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x016849C0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x016849C4: MOV x19, x0                | X19 = val_4;//m1                        
            val_7 = val_4;
            // 0x016849C8: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x016849CC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x016849D0: TBZ w9, #0, #0x16849e4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x016849D4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x016849D8: CBNZ w9, #0x16849e4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x016849DC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x016849E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_11:
            // 0x016849E4: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x016849E8: LDR x8, [x8, #0x430]       | X8 = (string**)(1152921513159468160)(" kb");
            val_8 = " kb";
            // 0x016849EC: B #0x1684a4c               |  goto label_12;                         
            goto label_12;
            label_3:
            // 0x016849F0: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x016849F4: LDR d2, [x8, #0xee8]       | D2 = 9.5367431640625E-07;               
            // 0x016849F8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x016849FC: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921513159459728)("0.0");
            // 0x01684A00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01684A04: FMUL d1, d1, d2            | D1 = (W1 < 0 ?  (-W1) : W1 * 9.5367431640625E-07);
            val_7 = val_7 * (9.5367431640625E-07);
            // 0x01684A08: FMUL d0, d0, d1            | D0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 * 9.5367431640625E-07));
            val_2 = val_2 * val_7;
            // 0x01684A0C: LDR x1, [x8]               | X1 = "0.0";                             
            // 0x01684A10: ADD x0, sp, #8             | X0 = (1152921513159633216 + 8) = 1152921513159633224 (0x10000001FDC92948);
            // 0x01684A14: STR d0, [sp, #8]           | stack[1152921513159633224] = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 * 9.5367431640625E-07));  //  dest_result_addr=1152921513159633224
            // 0x01684A18: BL #0x1c3883c              | X0 = (W1 < 0x0 ? -1 : 1 * (W1 < 0 ?  (-W1) : W1 * 9.5367431640625E-07)).ToString(format:  "0.0");
            string val_5 = val_2.ToString(format:  "0.0");
            // 0x01684A1C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01684A20: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01684A24: MOV x19, x0                | X19 = val_5;//m1                        
            val_7 = val_5;
            // 0x01684A28: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x01684A2C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x01684A30: TBZ w9, #0, #0x1684a44     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x01684A34: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01684A38: CBNZ w9, #0x1684a44        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x01684A3C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01684A40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_14:
            // 0x01684A44: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x01684A48: LDR x8, [x8, #0xfe8]       | X8 = (string**)(1152921513159472336)(" mb");
            val_8 = " mb";
            label_12:
            // 0x01684A4C: LDR x2, [x8]               | X2 = " mb";                             
            // 0x01684A50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684A54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01684A58: MOV x1, x19                | X1 = val_5;//m1                         
            // 0x01684A5C: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_7);
            string val_6 = System.String.Concat(str0:  0, str1:  val_7);
            // 0x01684A60: SUB sp, x29, #0x10         | SP = (1152921513159633264 - 16) = 1152921513159633248 (0x10000001FDC92960);
            // 0x01684A64: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01684A68: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01684A6C: RET                        |  return (System.String)val_6;           
            return val_6;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684A70 (23612016), len: 16  VirtAddr: 0x01684A70 RVA: 0x01684A70 token: 100681955 methodIndex: 49846 delegateWrapperIndex: 0 methodInvoker: 0
        public static int Bit(int a, int b)
        {
            //
            // Disasemble & Code
            // 0x01684A70: AND w8, w2, #0x1f          | W8 = (W2 & 31);                         
            var val_1 = W2 & 31;
            // 0x01684A74: LSR w8, w1, w8             | W8 = (b >> (W2 & 31));                  
            val_1 = b >> val_1;
            // 0x01684A78: AND w0, w8, #1             | W0 = ((b >> (W2 & 31)) & 1);            
            int val_2 = val_1 & 1;
            // 0x01684A7C: RET                        |  return (System.Int32)((b >> (W2 & 31)) & 1);
            return val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0167F484 (23590020), len: 124  VirtAddr: 0x0167F484 RVA: 0x0167F484 token: 100681956 methodIndex: 49847 delegateWrapperIndex: 0 methodInvoker: 0
        public static UnityEngine.Color IntToColor(int i, float a)
        {
            //
            // Disasemble & Code
            // 0x0167F484: STP x29, x30, [sp, #-0x10]! | stack[1152921513159873648] = ???;  stack[1152921513159873656] = ???;  //  dest_result_addr=1152921513159873648 |  dest_result_addr=1152921513159873656
            // 0x0167F488: MOV x29, sp                | X29 = 1152921513159873648 (0x10000001FDCCD470);//ML01
            // 0x0167F48C: MOV v3.16b, v0.16b         | V3 = a;//m1                             
            // 0x0167F490: LSR w8, w1, #2             | W8 = (W1 >> 2);                         
            var val_1 = W1 >> 2;
            // 0x0167F494: LSR w9, w1, #3             | W9 = (W1 >> 3);                         
            var val_2 = W1 >> 3;
            // 0x0167F498: LSR w10, w1, #4            | W10 = (W1 >> 4);                        
            var val_3 = W1 >> 4;
            // 0x0167F49C: STP xzr, xzr, [sp, #-0x10]! | stack[1152921513159873632] = 0x0;  stack[1152921513159873640] = 0x0;  //  dest_result_addr=1152921513159873632 |  dest_result_addr=1152921513159873640
            // 0x0167F4A0: AND w8, w8, #2             | W8 = ((W1 >> 2) & 2);                   
            val_1 = val_1 & 2;
            // 0x0167F4A4: AND w9, w9, #2             | W9 = ((W1 >> 3) & 2);                   
            val_2 = val_2 & 2;
            // 0x0167F4A8: AND w10, w10, #2           | W10 = ((W1 >> 4) & 2);                  
            val_3 = val_3 & 2;
            // 0x0167F4AC: BFXIL w8, w1, #1, #1       | 
            // 0x0167F4B0: BFXIL w9, w1, #2, #1       | 
            // 0x0167F4B4: BFXIL w10, w1, #0, #1      | 
            // 0x0167F4B8: ADD w8, w8, #1             | W8 = (((W1 >> 2) & 2) + 1);             
            val_1 = val_1 + 1;
            // 0x0167F4BC: ADD w9, w9, #1             | W9 = (((W1 >> 3) & 2) + 1);             
            val_2 = val_2 + 1;
            // 0x0167F4C0: ADD w10, w10, #1           | W10 = (((W1 >> 4) & 2) + 1);            
            val_3 = val_3 + 1;
            // 0x0167F4C4: FMOV s2, #0.25000000       | S2 = 0.25;                              
            float val_6 = 0.25f;
            // 0x0167F4C8: SCVTF s0, w8               | S0 = (float)((((W1 >> 2) & 2) + 1));    
            float val_4 = (float)val_1;
            // 0x0167F4CC: SCVTF s1, w9               | S1 = (float)((((W1 >> 3) & 2) + 1));    
            float val_5 = (float)val_2;
            // 0x0167F4D0: SCVTF s4, w10              | S4 = (float)((((W1 >> 4) & 2) + 1));    
            // 0x0167F4D4: FMUL s0, s0, s2            | S0 = ((((W1 >> 2) & 2) + 1) * 0.25f);   
            val_4 = val_4 * val_6;
            // 0x0167F4D8: FMUL s1, s1, s2            | S1 = ((((W1 >> 3) & 2) + 1) * 0.25f);   
            val_5 = val_5 * val_6;
            // 0x0167F4DC: FMUL s2, s4, s2            | S2 = ((((W1 >> 4) & 2) + 1) * 0.25f);   
            val_6 = (float)val_3 * val_6;
            // 0x0167F4E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F4E4: MOV x0, sp                 | X0 = 1152921513159873632 (0x10000001FDCCD460);//ML01
            // 0x0167F4E8: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F4EC: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
            // 0x0167F4F0: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
            // 0x0167F4F4: MOV sp, x29                | SP = 1152921513159873648 (0x10000001FDCCD470);//ML01
            // 0x0167F4F8: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x0167F4FC: RET                        |  return new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f};
            return new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f};
            //  |  // // {name=val_0.r, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.g, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.b, type=System.Single, size=4, nSRN=2 }
            //  |  // // {name=val_0.a, type=System.Single, size=4, nSRN=3 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684A80 (23612032), len: 228  VirtAddr: 0x01684A80 RVA: 0x01684A80 token: 100681957 methodIndex: 49848 delegateWrapperIndex: 0 methodInvoker: 0
        public static float MagnitudeXZ(UnityEngine.Vector3 a, UnityEngine.Vector3 b)
        {
            //
            // Disasemble & Code
            // 0x01684A80: STP d13, d12, [sp, #-0x50]! | stack[1152921513159985584] = ???;  stack[1152921513159985592] = ???;  //  dest_result_addr=1152921513159985584 |  dest_result_addr=1152921513159985592
            // 0x01684A84: STP d11, d10, [sp, #0x10]  | stack[1152921513159985600] = ???;  stack[1152921513159985608] = ???;  //  dest_result_addr=1152921513159985600 |  dest_result_addr=1152921513159985608
            // 0x01684A88: STP d9, d8, [sp, #0x20]    | stack[1152921513159985616] = ???;  stack[1152921513159985624] = ???;  //  dest_result_addr=1152921513159985616 |  dest_result_addr=1152921513159985624
            // 0x01684A8C: STP x20, x19, [sp, #0x30]  | stack[1152921513159985632] = ???;  stack[1152921513159985640] = ???;  //  dest_result_addr=1152921513159985632 |  dest_result_addr=1152921513159985640
            // 0x01684A90: STP x29, x30, [sp, #0x40]  | stack[1152921513159985648] = ???;  stack[1152921513159985656] = ???;  //  dest_result_addr=1152921513159985648 |  dest_result_addr=1152921513159985656
            // 0x01684A94: ADD x29, sp, #0x40         | X29 = (1152921513159985584 + 64) = 1152921513159985648 (0x10000001FDCE89F0);
            // 0x01684A98: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01684A9C: LDRB w8, [x19, #0xe3]      | W8 = (bool)static_value_037380E3;       
            // 0x01684AA0: MOV v8.16b, v5.16b         | V8 = b.z;//m1                           
            // 0x01684AA4: MOV v9.16b, v4.16b         | V9 = b.y;//m1                           
            // 0x01684AA8: MOV v10.16b, v3.16b        | V10 = b.x;//m1                          
            // 0x01684AAC: MOV v11.16b, v2.16b        | V11 = a.z;//m1                          
            // 0x01684AB0: MOV v12.16b, v1.16b        | V12 = a.y;//m1                          
            // 0x01684AB4: MOV v13.16b, v0.16b        | V13 = a.x;//m1                          
            // 0x01684AB8: TBNZ w8, #0, #0x1684ad4    | if (static_value_037380E3 == true) goto label_0;
            // 0x01684ABC: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x01684AC0: LDR x8, [x8, #0xe88]       | X8 = 0x2B8EC7C;                         
            // 0x01684AC4: LDR w0, [x8]               | W0 = 0x11DF;                            
            // 0x01684AC8: BL #0x2782188              | X0 = sub_2782188( ?? 0x11DF, ????);     
            // 0x01684ACC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01684AD0: STRB w8, [x19, #0xe3]      | static_value_037380E3 = true;            //  dest_result_addr=57901283
            label_0:
            // 0x01684AD4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x01684AD8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x01684ADC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x01684AE0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01684AE4: TBZ w8, #0, #0x1684af4     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01684AE8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01684AEC: CBNZ w8, #0x1684af4        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01684AF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x01684AF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684AF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684AFC: MOV v0.16b, v13.16b        | V0 = a.x;//m1                           
            // 0x01684B00: MOV v1.16b, v12.16b        | V1 = a.y;//m1                           
            // 0x01684B04: MOV v2.16b, v11.16b        | V2 = a.z;//m1                           
            // 0x01684B08: MOV v3.16b, v10.16b        | V3 = b.x;//m1                           
            // 0x01684B0C: MOV v4.16b, v9.16b         | V4 = b.y;//m1                           
            // 0x01684B10: MOV v5.16b, v8.16b         | V5 = b.z;//m1                           
            // 0x01684B14: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = a.x, y = a.y, z = a.z}, b:  new UnityEngine.Vector3() {x = b.x, y = b.y, z = b.z});
            UnityEngine.Vector3 val_1 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = a.x, y = a.y, z = a.z}, b:  new UnityEngine.Vector3() {x = b.x, y = b.y, z = b.z});
            // 0x01684B18: FMUL s0, s0, s0            | S0 = (val_1.x * val_1.x);               
            val_1.x = val_1.x * val_1.x;
            // 0x01684B1C: FMUL s1, s2, s2            | S1 = (val_1.z * val_1.z);               
            float val_2 = val_1.z * val_1.z;
            // 0x01684B20: FADD s0, s0, s1            | S0 = ((val_1.x * val_1.x) + (val_1.z * val_1.z));
            val_1.x = val_1.x + val_2;
            // 0x01684B24: FSQRT s1, s0               | 
            // 0x01684B28: FCMP s1, s1                | STATE = COMPARE((val_1.z * val_1.z), (val_1.z * val_1.z))
            // 0x01684B2C: B.VS #0x1684b4c            | if (val_2 > _TYPE_MAX_) goto label_3;   
            if(val_2 > _TYPE_MAX_)
            {
                goto label_3;
            }
            // 0x01684B30: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01684B34: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01684B38: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x01684B3C: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x01684B40: MOV v0.16b, v1.16b         | V0 = (val_1.z * val_1.z);//m1           
            // 0x01684B44: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
            // 0x01684B48: RET                        |  return (System.Single)(val_1.z * val_1.z);
            return (float)val_2;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
            label_3:
            // 0x01684B4C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01684B50: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01684B54: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x01684B58: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x01684B5C: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
            // 0x01684B60: B #0x9813c0                | X0 = sub_9813C0( ?? 0x0, ????);         
        
        }
        //
        // Offset in libil2cpp.so: 0x01684B64 (23612260), len: 188  VirtAddr: 0x01684B64 RVA: 0x01684B64 token: 100681958 methodIndex: 49849 delegateWrapperIndex: 0 methodInvoker: 0
        public static float SqrMagnitudeXZ(UnityEngine.Vector3 a, UnityEngine.Vector3 b)
        {
            //
            // Disasemble & Code
            // 0x01684B64: STP d13, d12, [sp, #-0x50]! | stack[1152921513160097584] = ???;  stack[1152921513160097592] = ???;  //  dest_result_addr=1152921513160097584 |  dest_result_addr=1152921513160097592
            // 0x01684B68: STP d11, d10, [sp, #0x10]  | stack[1152921513160097600] = ???;  stack[1152921513160097608] = ???;  //  dest_result_addr=1152921513160097600 |  dest_result_addr=1152921513160097608
            // 0x01684B6C: STP d9, d8, [sp, #0x20]    | stack[1152921513160097616] = ???;  stack[1152921513160097624] = ???;  //  dest_result_addr=1152921513160097616 |  dest_result_addr=1152921513160097624
            // 0x01684B70: STP x20, x19, [sp, #0x30]  | stack[1152921513160097632] = ???;  stack[1152921513160097640] = ???;  //  dest_result_addr=1152921513160097632 |  dest_result_addr=1152921513160097640
            // 0x01684B74: STP x29, x30, [sp, #0x40]  | stack[1152921513160097648] = ???;  stack[1152921513160097656] = ???;  //  dest_result_addr=1152921513160097648 |  dest_result_addr=1152921513160097656
            // 0x01684B78: ADD x29, sp, #0x40         | X29 = (1152921513160097584 + 64) = 1152921513160097648 (0x10000001FDD03F70);
            // 0x01684B7C: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01684B80: LDRB w8, [x19, #0xe4]      | W8 = (bool)static_value_037380E4;       
            // 0x01684B84: MOV v8.16b, v5.16b         | V8 = b.z;//m1                           
            // 0x01684B88: MOV v9.16b, v4.16b         | V9 = b.y;//m1                           
            // 0x01684B8C: MOV v10.16b, v3.16b        | V10 = b.x;//m1                          
            // 0x01684B90: MOV v11.16b, v2.16b        | V11 = a.z;//m1                          
            // 0x01684B94: MOV v12.16b, v1.16b        | V12 = a.y;//m1                          
            // 0x01684B98: MOV v13.16b, v0.16b        | V13 = a.x;//m1                          
            // 0x01684B9C: TBNZ w8, #0, #0x1684bb8    | if (static_value_037380E4 == true) goto label_0;
            // 0x01684BA0: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x01684BA4: LDR x8, [x8, #0x8a0]       | X8 = 0x2B8ECA0;                         
            // 0x01684BA8: LDR w0, [x8]               | W0 = 0x11E8;                            
            // 0x01684BAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E8, ????);     
            // 0x01684BB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01684BB4: STRB w8, [x19, #0xe4]      | static_value_037380E4 = true;            //  dest_result_addr=57901284
            label_0:
            // 0x01684BB8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x01684BBC: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x01684BC0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x01684BC4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01684BC8: TBZ w8, #0, #0x1684bd8     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01684BCC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01684BD0: CBNZ w8, #0x1684bd8        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01684BD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x01684BD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684BDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684BE0: MOV v0.16b, v13.16b        | V0 = a.x;//m1                           
            // 0x01684BE4: MOV v1.16b, v12.16b        | V1 = a.y;//m1                           
            // 0x01684BE8: MOV v2.16b, v11.16b        | V2 = a.z;//m1                           
            // 0x01684BEC: MOV v3.16b, v10.16b        | V3 = b.x;//m1                           
            // 0x01684BF0: MOV v4.16b, v9.16b         | V4 = b.y;//m1                           
            // 0x01684BF4: MOV v5.16b, v8.16b         | V5 = b.z;//m1                           
            // 0x01684BF8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = a.x, y = a.y, z = a.z}, b:  new UnityEngine.Vector3() {x = b.x, y = b.y, z = b.z});
            UnityEngine.Vector3 val_1 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = a.x, y = a.y, z = a.z}, b:  new UnityEngine.Vector3() {x = b.x, y = b.y, z = b.z});
            // 0x01684BFC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01684C00: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01684C04: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x01684C08: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x01684C0C: FMUL s0, s0, s0            | S0 = (val_1.x * val_1.x);               
            val_1.x = val_1.x * val_1.x;
            // 0x01684C10: FMUL s1, s2, s2            | S1 = (val_1.z * val_1.z);               
            float val_2 = val_1.z * val_1.z;
            // 0x01684C14: FADD s0, s0, s1            | S0 = ((val_1.x * val_1.x) + (val_1.z * val_1.z));
            val_1.x = val_1.x + val_2;
            // 0x01684C18: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
            // 0x01684C1C: RET                        |  return (System.Single)((val_1.x * val_1.x) + (val_1.z * val_1.z));
            return (float)val_1.x;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C20 (23612448), len: 20  VirtAddr: 0x01684C20 RVA: 0x01684C20 token: 100681959 methodIndex: 49850 delegateWrapperIndex: 0 methodInvoker: 0
        public static int Repeat(int i, int n)
        {
            //
            // Disasemble & Code
            // 0x01684C20: ADD w0, w2, w1             | W0 = (W2 + n);                          
            int val_1 = W2 + n;
            label_0:
            // 0x01684C24: SUB w0, w0, w2             | W0 = ((W2 + n) - W2);                   
            val_1 = val_1 - W2;
            // 0x01684C28: CMP w0, w2                 | STATE = COMPARE(((W2 + n) - W2), W2)    
            // 0x01684C2C: B.GE #0x1684c24            | if (val_1 >= W2) goto label_0;          
            if(val_1 >= W2)
            {
                goto label_0;
            }
            // 0x01684C30: RET                        |  return (System.Int32)((W2 + n) - W2);  
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C34 (23612468), len: 16  VirtAddr: 0x01684C34 RVA: 0x01684C34 token: 100681960 methodIndex: 49851 delegateWrapperIndex: 0 methodInvoker: 0
        public static float Abs(float a)
        {
            //
            // Disasemble & Code
            // 0x01684C34: FNEG s1, s0                | S1 = -(a);                              
            // 0x01684C38: FCMP s0, #0.0              | STATE = COMPARE(a, 0)                   
            // 0x01684C3C: FCSEL s0, s1, s0, mi       | S0 = a < 0 ? a : a;                     
            a = (a < 0) ? (-a) : a;
            // 0x01684C40: RET                        |  return (System.Single)a < 0 ? a : a;   
            return (float)a;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C44 (23612484), len: 12  VirtAddr: 0x01684C44 RVA: 0x01684C44 token: 100681961 methodIndex: 49852 delegateWrapperIndex: 0 methodInvoker: 0
        public static int Abs(int a)
        {
            //
            // Disasemble & Code
            // 0x01684C44: CMP w1, #0                 | STATE = COMPARE(W1, 0x0)                
            // 0x01684C48: CNEG w0, w1, mi            | W0 = W1 < 0 ?  (-W1) : W1;              
            var val_1 = (W1 < 0) ? (-W1) : (W1);
            // 0x01684C4C: RET                        |  return (System.Int32)W1 < 0 ?  (-W1) : W1;
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C50 (23612496), len: 12  VirtAddr: 0x01684C50 RVA: 0x01684C50 token: 100681962 methodIndex: 49853 delegateWrapperIndex: 0 methodInvoker: 0
        public static float Min(float a, float b)
        {
            //
            // Disasemble & Code
            // 0x01684C50: FCMP s0, s1                | STATE = COMPARE(a, b)                   
            // 0x01684C54: FCSEL s0, s0, s1, mi       | S0 = a < 0 ? a : b;                     
            var val_1 = (a < 0) ? a : b;
            // 0x01684C58: RET                        |  return (System.Single)a < 0 ? a : b;   
            return (float)val_1;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C5C (23612508), len: 12  VirtAddr: 0x01684C5C RVA: 0x01684C5C token: 100681963 methodIndex: 49854 delegateWrapperIndex: 0 methodInvoker: 0
        public static int Min(int a, int b)
        {
            //
            // Disasemble & Code
            // 0x01684C5C: CMP w1, w2                 | STATE = COMPARE(b, W2)                  
            // 0x01684C60: CSEL w0, w2, w1, ge        | W0 = b >= W2 ? W2 : b;                  
            var val_1 = (b >= W2) ? (W2) : b;
            // 0x01684C64: RET                        |  return (System.Int32)b >= W2 ? W2 : b; 
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C68 (23612520), len: 12  VirtAddr: 0x01684C68 RVA: 0x01684C68 token: 100681964 methodIndex: 49855 delegateWrapperIndex: 0 methodInvoker: 0
        public static uint Min(uint a, uint b)
        {
            //
            // Disasemble & Code
            // 0x01684C68: CMP w1, w2                 | STATE = COMPARE(b, W2)                  
            // 0x01684C6C: CSEL w0, w2, w1, hs        | W0 = b >= W2 ? W2 : b;                  
            var val_1 = (b >= W2) ? (W2) : b;
            // 0x01684C70: RET                        |  return (System.UInt32)b >= W2 ? W2 : b;
            return (uint)val_1;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C74 (23612532), len: 12  VirtAddr: 0x01684C74 RVA: 0x01684C74 token: 100681965 methodIndex: 49856 delegateWrapperIndex: 0 methodInvoker: 0
        public static float Max(float a, float b)
        {
            //
            // Disasemble & Code
            // 0x01684C74: FCMP s0, s1                | STATE = COMPARE(a, b)                   
            // 0x01684C78: FCSEL s0, s0, s1, gt       | S0 = a > b ? a : b;                     
            var val_1 = (a > b) ? a : b;
            // 0x01684C7C: RET                        |  return (System.Single)a > b ? a : b;   
            return (float)val_1;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C80 (23612544), len: 12  VirtAddr: 0x01684C80 RVA: 0x01684C80 token: 100681966 methodIndex: 49857 delegateWrapperIndex: 0 methodInvoker: 0
        public static int Max(int a, int b)
        {
            //
            // Disasemble & Code
            // 0x01684C80: CMP w1, w2                 | STATE = COMPARE(b, W2)                  
            // 0x01684C84: CSEL w0, w2, w1, le        | W0 = b <= W2 ? W2 : b;                  
            var val_1 = (b <= W2) ? (W2) : b;
            // 0x01684C88: RET                        |  return (System.Int32)b <= W2 ? W2 : b; 
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C8C (23612556), len: 12  VirtAddr: 0x01684C8C RVA: 0x01684C8C token: 100681967 methodIndex: 49858 delegateWrapperIndex: 0 methodInvoker: 0
        public static uint Max(uint a, uint b)
        {
            //
            // Disasemble & Code
            // 0x01684C8C: CMP w1, w2                 | STATE = COMPARE(b, W2)                  
            // 0x01684C90: CSEL w0, w2, w1, ls        | W0 = b <= W2 ? W2 : b;                  
            var val_1 = (b <= W2) ? (W2) : b;
            // 0x01684C94: RET                        |  return (System.UInt32)b <= W2 ? W2 : b;
            return (uint)val_1;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684C98 (23612568), len: 16  VirtAddr: 0x01684C98 RVA: 0x01684C98 token: 100681968 methodIndex: 49859 delegateWrapperIndex: 0 methodInvoker: 0
        public static ushort Max(ushort a, ushort b)
        {
            //
            // Disasemble & Code
            // 0x01684C98: AND w8, w1, #0xffff        | W8 = (b & 65535);                       
            ushort val_1 = b & 65535;
            // 0x01684C9C: CMP w8, w2, uxth           | STATE = COMPARE((b & 65535), W2)        
            // 0x01684CA0: CSEL w0, w2, w1, ls        | W0 = val_1 <= W2 ? W2 : b;              
            var val_2 = (val_1 <= W2) ? (W2) : b;
            // 0x01684CA4: RET                        |  return (System.UInt16)val_1 <= W2 ? W2 : b;
            return (ushort)val_2;
            //  |  // // {name=val_0, type=System.UInt16, size=2, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684CA8 (23612584), len: 20  VirtAddr: 0x01684CA8 RVA: 0x01684CA8 token: 100681969 methodIndex: 49860 delegateWrapperIndex: 0 methodInvoker: 0
        public static float Sign(float a)
        {
            //
            // Disasemble & Code
            // 0x01684CA8: FCMP s0, #0.0              | STATE = COMPARE(a, 0)                   
            // 0x01684CAC: FMOV s0, #-1.00000000      | S0 = -1;                                
            // 0x01684CB0: FMOV s1, #1.00000000       | S1 = 1;                                 
            // 0x01684CB4: FCSEL s0, s1, s0, pl       | S0 = a >= 0 ? 1f : -1f;                 
            var val_1 = (a >= 0) ? (1f) : (-1f);
            // 0x01684CB8: RET                        |  return (System.Single)a >= 0 ? 1f : -1f;
            return (float)val_1;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684CBC (23612604), len: 12  VirtAddr: 0x01684CBC RVA: 0x01684CBC token: 100681970 methodIndex: 49861 delegateWrapperIndex: 0 methodInvoker: 0
        public static int Sign(int a)
        {
            //
            // Disasemble & Code
            // 0x01684CBC: ASR w8, w1, #0x1f          | W8 = (W1 >> 31);                        
            var val_1 = W1 >> 31;
            // 0x01684CC0: ORR w0, w8, #1             | W0 = ((W1 >> 31) | 1);                  
            var val_2 = val_1 | 1;
            // 0x01684CC4: RET                        |  return (System.Int32)((W1 >> 31) | 1); 
            return (int)val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684CC8 (23612616), len: 28  VirtAddr: 0x01684CC8 RVA: 0x01684CC8 token: 100681971 methodIndex: 49862 delegateWrapperIndex: 0 methodInvoker: 0
        public static float Clamp(float a, float b, float c)
        {
            //
            // Disasemble & Code
            // 0x01684CC8: FCMP s0, s2                | STATE = COMPARE(a, c)                   
            // 0x01684CCC: B.GT #0x1684cdc            | if (a > c) goto label_0;                
            if(a > c)
            {
                goto label_0;
            }
            // 0x01684CD0: FCMP s0, s1                | STATE = COMPARE(a, b)                   
            // 0x01684CD4: FCSEL s0, s1, s0, mi       | S0 = a < 0 ? b : a;                     
            var val_1 = (a < 0) ? b : a;
            // 0x01684CD8: RET                        |  return (System.Single)a < 0 ? b : a;   
            return (float)val_1;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
            label_0:
            // 0x01684CDC: MOV v0.16b, v2.16b         | V0 = c;//m1                             
            // 0x01684CE0: RET                        |  return (System.Single)c;               
            return (float)c;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684CE4 (23612644), len: 28  VirtAddr: 0x01684CE4 RVA: 0x01684CE4 token: 100681972 methodIndex: 49863 delegateWrapperIndex: 0 methodInvoker: 0
        public static int Clamp(int a, int b, int c)
        {
            //
            // Disasemble & Code
            // 0x01684CE4: CMP w1, w3                 | STATE = COMPARE(b, W3)                  
            // 0x01684CE8: B.LE #0x1684cf4            | if (b <= W3) goto label_0;              
            if(b <= W3)
            {
                goto label_0;
            }
            // 0x01684CEC: MOV w0, w3                 | W0 = W3;//m1                            
            // 0x01684CF0: RET                        |  return (System.Int32)W3;               
            return (int)W3;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_0:
            // 0x01684CF4: CMP w1, w2                 | STATE = COMPARE(b, c)                   
            // 0x01684CF8: CSEL w0, w1, w2, ge        | W0 = b >= c ? b : c;                    
            var val_1 = (b >= c) ? b : c;
            // 0x01684CFC: RET                        |  return (System.Int32)b >= c ? b : c;   
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684D00 (23612672), len: 32  VirtAddr: 0x01684D00 RVA: 0x01684D00 token: 100681973 methodIndex: 49864 delegateWrapperIndex: 0 methodInvoker: 0
        public static float Clamp01(float a)
        {
            //
            // Disasemble & Code
            // 0x01684D00: FMOV s1, #1.00000000       | S1 = 1;                                 
            // 0x01684D04: FCMP s0, s1                | STATE = COMPARE(a, 1)                   
            // 0x01684D08: B.GT #0x1684d18            | if (a > 1f) goto label_0;               
            if(a > 1f)
            {
                goto label_0;
            }
            // 0x01684D0C: FMOV s1, wzr               | S1 = 0f;                                
            // 0x01684D10: FMAX s0, s0, s1            | 
            // 0x01684D14: RET                        |  return (System.Single)a;               
            return (float)a;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
            label_0:
            // 0x01684D18: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x01684D1C: RET                        |  return (System.Single)1;               
            return 1f;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684D20 (23612704), len: 28  VirtAddr: 0x01684D20 RVA: 0x01684D20 token: 100681974 methodIndex: 49865 delegateWrapperIndex: 0 methodInvoker: 0
        public static int Clamp01(int a)
        {
            //
            // Disasemble & Code
            // 0x01684D20: CMP w1, #1                 | STATE = COMPARE(W1, 0x1)                
            // 0x01684D24: B.GT #0x1684d34            | if (W1 > 0x1) goto label_0;             
            if(W1 > 1)
            {
                goto label_0;
            }
            // 0x01684D28: CMP w1, #0                 | STATE = COMPARE(W1, 0x0)                
            // 0x01684D2C: CSEL w0, wzr, w1, lt       | W0 = W1 < 0x0 ? 0 : W1;                 
            var val_1 = (W1 < 0) ? 0 : (W1);
            // 0x01684D30: RET                        |  return (System.Int32)W1 < 0x0 ? 0 : W1;
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_0:
            // 0x01684D34: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x01684D38: RET                        |  return (System.Int32)1;                
            return (int)1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684D3C (23612732), len: 48  VirtAddr: 0x01684D3C RVA: 0x01684D3C token: 100681975 methodIndex: 49866 delegateWrapperIndex: 0 methodInvoker: 0
        public static float Lerp(float a, float b, float t)
        {
            //
            // Disasemble & Code
            //  | 
            float val_1;
            // 0x01684D3C: FSUB s1, s1, s0            | S1 = (b - a);                           
            b = b - a;
            // 0x01684D40: FMOV s3, #1.00000000       | S3 = 1;                                 
            val_1 = 1f;
            // 0x01684D44: FCMP s2, s3                | STATE = COMPARE(t, 1)                   
            // 0x01684D48: B.GT #0x1684d60            | if (t > val_1) goto label_2;            
            if(t > val_1)
            {
                goto label_2;
            }
            // 0x01684D4C: FCMP s2, #0.0              | STATE = COMPARE(t, 0)                   
            // 0x01684D50: B.PL #0x1684d5c            | if (t >= 0) goto label_1;               
            if(t >= 0)
            {
                goto label_1;
            }
            // 0x01684D54: FMOV s3, wzr               | S3 = 0f;                                
            val_1 = 0f;
            // 0x01684D58: B #0x1684d60               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x01684D5C: MOV v3.16b, v2.16b         | V3 = t;//m1                             
            val_1 = t;
            label_2:
            // 0x01684D60: FMUL s1, s1, s3            | S1 = ((b - a) * t);                     
            b = b * val_1;
            // 0x01684D64: FADD s0, s1, s0            | S0 = (((b - a) * t) + a);               
            a = b + a;
            // 0x01684D68: RET                        |  return (System.Single)(((b - a) * t) + a);
            return (float)a;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684D6C (23612780), len: 16  VirtAddr: 0x01684D6C RVA: 0x01684D6C token: 100681976 methodIndex: 49867 delegateWrapperIndex: 0 methodInvoker: 0
        public static int RoundToInt(float v)
        {
            //
            // Disasemble & Code
            // 0x01684D6C: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x01684D70: FADD s0, s0, s1            | S0 = (v + 0.5f);                        
            v = v + 0.5f;
            // 0x01684D74: FCVTZS w0, s0              | W0 = (int)((v + 0.5f));                 
            // 0x01684D78: RET                        |  return (System.Int32)(v + 0.5f);       
            return (int)v;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01684D7C (23612796), len: 16  VirtAddr: 0x01684D7C RVA: 0x01684D7C token: 100681977 methodIndex: 49868 delegateWrapperIndex: 0 methodInvoker: 0
        public static int RoundToInt(double v)
        {
            //
            // Disasemble & Code
            // 0x01684D7C: FMOV d1, #0.50000000       | D1 = 0.5;                               
            // 0x01684D80: FADD d0, d0, d1            | D0 = (v + 0.5);                         
            v = v + 0.5;
            // 0x01684D84: FCVTZS w0, d0              | W0 = (int)((v + 0.5));                  
            // 0x01684D88: RET                        |  return (System.Int32)(v + 0.5);        
            return (int)v;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
    
    }

}
