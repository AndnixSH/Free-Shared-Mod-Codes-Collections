using UnityEngine;

namespace ILRuntime.Runtime.Enviorment
{
    public sealed class CLRCreateDefaultInstanceDelegate : MulticastDelegate
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x028E8D84 (42896772), len: 16  VirtAddr: 0x028E8D84 RVA: 0x028E8D84 token: 100680200 methodIndex: 29535 delegateWrapperIndex: 0 methodInvoker: 0
        public CLRCreateDefaultInstanceDelegate(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x028E8D84: LDR x8, [x2]               | X8 = method;                            
            // 0x028E8D88: STP x1, x2, [x0, #0x20]    | mem[1152921512877175136] = object;  mem[1152921512877175144] = method;  //  dest_result_addr=1152921512877175136 |  dest_result_addr=1152921512877175144
            mem[1152921512877175136] = object;
            mem[1152921512877175144] = method;
            // 0x028E8D8C: STR x8, [x0, #0x10]        | mem[1152921512877175120] = method;       //  dest_result_addr=1152921512877175120
            mem[1152921512877175120] = method;
            // 0x028E8D90: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E8D94 (42896788), len: 504  VirtAddr: 0x028E8D94 RVA: 0x028E8D94 token: 100680201 methodIndex: 29536 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual object Invoke()
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            label_1:
            // 0x028E8D94: STP x22, x21, [sp, #-0x30]! | stack[1152921512877287344] = ???;  stack[1152921512877287352] = ???;  //  dest_result_addr=1152921512877287344 |  dest_result_addr=1152921512877287352
            // 0x028E8D98: STP x20, x19, [sp, #0x10]  | stack[1152921512877287360] = ???;  stack[1152921512877287368] = ???;  //  dest_result_addr=1152921512877287360 |  dest_result_addr=1152921512877287368
            // 0x028E8D9C: STP x29, x30, [sp, #0x20]  | stack[1152921512877287376] = ???;  stack[1152921512877287384] = ???;  //  dest_result_addr=1152921512877287376 |  dest_result_addr=1152921512877287384
            // 0x028E8DA0: ADD x29, sp, #0x20         | X29 = (1152921512877287344 + 32) = 1152921512877287376 (0x10000001ECF4E7D0);
            // 0x028E8DA4: SUB sp, sp, #0x10          | SP = (1152921512877287344 - 16) = 1152921512877287328 (0x10000001ECF4E7A0);
            // 0x028E8DA8: MOV x21, x0                | X21 = 1152921512877299392 (0x10000001ECF516C0);//ML01
            // 0x028E8DAC: LDR x0, [x21, #0x58]       | 
            // 0x028E8DB0: CBZ x0, #0x28e8db8         | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x028E8DB4: BL #0x28e8d94              |  R0 = label_1();                        
            label_0:
            // 0x028E8DB8: LDR x0, [x21, #0x10]       | 
            // 0x028E8DBC: STR x0, [sp, #8]           | stack[1152921512877287336] = this;       //  dest_result_addr=1152921512877287336
            // 0x028E8DC0: LDP x19, x20, [x21, #0x20] |                                          //  | 
            // 0x028E8DC4: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E8DC8: BL #0x2796f94              | X0 = sub_2796F94( ?? X20, ????);        
            // 0x028E8DCC: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E8DD0: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X20, ????);        
            // 0x028E8DD4: AND w8, w0, #1             | W8 = (X20 & 1);                         
            var val_1 = X20 & 1;
            // 0x028E8DD8: TBZ w8, #0, #0x28e8e68     | if (((X20 & 1) & 0x1) == 0) goto label_2;
            if((val_1 & 1) == 0)
            {
                goto label_2;
            }
            // 0x028E8DDC: LDRSH w8, [x20, #0x4c]     | W8 = X20 + 76;                          
            // 0x028E8DE0: CMN w8, #1                 | STATE = COMPARE(X20 + 76, 0x1)          
            // 0x028E8DE4: B.EQ #0x28e8e94            | if (X20 + 76 == 0x1) goto label_6;      
            if((X20 + 76) == 1)
            {
                goto label_6;
            }
            // 0x028E8DE8: CBZ x19, #0x28e8df8        | if (X19 == 0) goto label_4;             
            if(X19 == 0)
            {
                goto label_4;
            }
            // 0x028E8DEC: LDR x8, [x19]              | X8 = X19;                               
            // 0x028E8DF0: LDRB w8, [x8, #0xed]       | W8 = X19 + 237;                         
            // 0x028E8DF4: TBNZ w8, #0, #0x28e8e94    | if ((X19 + 237 & 0x1) != 0) goto label_6;
            if(((X19 + 237) & 1) != 0)
            {
                goto label_6;
            }
            label_4:
            // 0x028E8DF8: LDR x8, [x21, #0x18]       | 
            // 0x028E8DFC: CBZ x8, #0x28e8e94         | if (X19 + 237 == 0) goto label_6;       
            if((X19 + 237) == 0)
            {
                goto label_6;
            }
            // 0x028E8E00: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E8E04: BL #0x27c0990              | X0 = sub_27C0990( ?? X20, ????);        
            // 0x028E8E08: MOV w21, w0                | W21 = X20;//m1                          
            // 0x028E8E0C: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E8E10: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
            UnityEngine.Sprite val_2 = X20.pressedSprite;
            // 0x028E8E14: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
            // 0x028E8E18: TBZ w21, #0, #0x28e8ebc    | if ((X20 & 0x1) == 0) goto label_7;     
            if((X20 & 1) == 0)
            {
                goto label_7;
            }
            // 0x028E8E1C: TBZ w0, #0, #0x28e8f18     | if ((val_2 & 0x1) == 0) goto label_8;   
            if((val_2 & 1) == 0)
            {
                goto label_8;
            }
            // 0x028E8E20: LDR x8, [x19]              | X8 = X19;                               
            var val_11 = X19;
            // 0x028E8E24: LDR x1, [x20, #0x18]       | X1 = X20 + 24;                          
            // 0x028E8E28: LDRH w2, [x20, #0x4c]      | W2 = X20 + 76;                          
            // 0x028E8E2C: LDRH w9, [x8, #0x102]      | W9 = X19 + 258;                         
            // 0x028E8E30: CBZ x9, #0x28e8e5c         | if (X19 + 258 == 0) goto label_9;       
            if((X19 + 258) == 0)
            {
                goto label_9;
            }
            // 0x028E8E34: LDR x10, [x8, #0x98]       | X10 = X19 + 152;                        
            var val_5 = X19 + 152;
            // 0x028E8E38: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x028E8E3C: ADD x10, x10, #8           | X10 = (X19 + 152 + 8);                  
            val_5 = val_5 + 8;
            label_11:
            // 0x028E8E40: LDUR x12, [x10, #-8]       | X12 = (X19 + 152 + 8) + -8;             
            // 0x028E8E44: CMP x12, x1                | STATE = COMPARE((X19 + 152 + 8) + -8, X20 + 24)
            // 0x028E8E48: B.EQ #0x28e8f40            | if ((X19 + 152 + 8) + -8 == X20 + 24) goto label_10;
            if(((X19 + 152 + 8) + -8) == (X20 + 24))
            {
                goto label_10;
            }
            // 0x028E8E4C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x028E8E50: ADD x10, x10, #0x10        | X10 = ((X19 + 152 + 8) + 16);           
            val_5 = val_5 + 16;
            // 0x028E8E54: CMP x11, x9                | STATE = COMPARE((0 + 1), X19 + 258)     
            // 0x028E8E58: B.LO #0x28e8e40            | if (0 < X19 + 258) goto label_11;       
            if(val_6 < (X19 + 258))
            {
                goto label_11;
            }
            label_9:
            // 0x028E8E5C: MOV x0, x19                | X0 = X19;//m1                           
            val_7 = X19;
            // 0x028E8E60: BL #0x2776c24              | X0 = sub_2776C24( ?? X19, ????);        
            // 0x028E8E64: B #0x28e8f50               |  goto label_12;                         
            goto label_12;
            label_2:
            // 0x028E8E68: LDRB w8, [x20, #0x4e]      | W8 = X20 + 78;                          
            // 0x028E8E6C: CBZ w8, #0x28e8e9c         | if (X20 + 78 == 0) goto label_13;       
            if((X20 + 78) == 0)
            {
                goto label_13;
            }
            // 0x028E8E70: LDR x3, [sp, #8]           | X3 = this;                              
            // 0x028E8E74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E8E78: MOV x1, x19                | X1 = X19;//m1                           
            // 0x028E8E7C: MOV x2, x20                | X2 = X20;//m1                           
            // 0x028E8E80: SUB sp, x29, #0x20         | SP = (1152921512877287376 - 32) = 1152921512877287344 (0x10000001ECF4E7B0);
            // 0x028E8E84: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E8E88: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E8E8C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E8E90: BR x3                      | X0 = this( ?? 0x0, ????);               
            label_6:
            // 0x028E8E94: MOV x0, x19                | X0 = X19;//m1                           
            // 0x028E8E98: B #0x28e8ea0               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028E8E9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_14:
            // 0x028E8EA0: LDR x2, [sp, #8]           | X2 = this;                              
            // 0x028E8EA4: MOV x1, x20                | X1 = X20;//m1                           
            label_23:
            // 0x028E8EA8: SUB sp, x29, #0x20         | SP = (1152921512877287376 - 32) = 1152921512877287344 (0x10000001ECF4E7B0);
            // 0x028E8EAC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E8EB0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E8EB4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E8EB8: BR x2                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x028E8EBC: LDRH w21, [x20, #0x4c]     | W21 = X20 + 76;                         
            // 0x028E8EC0: TBZ w0, #0, #0x28e8f2c     | if ((val_2 & 0x1) == 0) goto label_15;  
            if((val_2 & 1) == 0)
            {
                goto label_15;
            }
            // 0x028E8EC4: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E8EC8: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X20.pressedSprite;
            // 0x028E8ECC: LDR x9, [x19]              | X9 = X19;                               
            // 0x028E8ED0: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x028E8ED4: LDRH w10, [x9, #0x102]     | W10 = X19 + 258;                        
            // 0x028E8ED8: CBZ x10, #0x28e8f04        | if (X19 + 258 == 0) goto label_16;      
            if((X19 + 258) == 0)
            {
                goto label_16;
            }
            // 0x028E8EDC: LDR x11, [x9, #0x98]       | X11 = X19 + 152;                        
            var val_7 = X19 + 152;
            // 0x028E8EE0: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x028E8EE4: ADD x11, x11, #8           | X11 = (X19 + 152 + 8);                  
            val_7 = val_7 + 8;
            label_18:
            // 0x028E8EE8: LDUR x13, [x11, #-8]       | X13 = (X19 + 152 + 8) + -8;             
            // 0x028E8EEC: CMP x13, x8                | STATE = COMPARE((X19 + 152 + 8) + -8, val_3)
            // 0x028E8EF0: B.EQ #0x28e8f70            | if ((X19 + 152 + 8) + -8 == val_3) goto label_17;
            if(((X19 + 152 + 8) + -8) == val_3)
            {
                goto label_17;
            }
            // 0x028E8EF4: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x028E8EF8: ADD x11, x11, #0x10        | X11 = ((X19 + 152 + 8) + 16);           
            val_7 = val_7 + 16;
            // 0x028E8EFC: CMP x12, x10               | STATE = COMPARE((0 + 1), X19 + 258)     
            // 0x028E8F00: B.LO #0x28e8ee8            | if (0 < X19 + 258) goto label_18;       
            if(val_8 < (X19 + 258))
            {
                goto label_18;
            }
            label_16:
            // 0x028E8F04: MOV x0, x19                | X0 = X19;//m1                           
            val_8 = X19;
            // 0x028E8F08: MOV x1, x8                 | X1 = val_3;//m1                         
            // 0x028E8F0C: MOV w2, w21                | W2 = X20 + 76;//m1                      
            // 0x028E8F10: BL #0x2776c24              | X0 = sub_2776C24( ?? X19, ????);        
            // 0x028E8F14: B #0x28e8f80               |  goto label_19;                         
            goto label_19;
            label_8:
            // 0x028E8F18: LDRH w8, [x20, #0x4c]      | W8 = X20 + 76;                          
            // 0x028E8F1C: LDR x9, [x19]              | X9 = X19;                               
            // 0x028E8F20: ADD x8, x9, x8, lsl #4     | X8 = (X19 + (X20 + 76) << 4);           
            var val_4 = X19 + ((X20 + 76) << 4);
            // 0x028E8F24: LDR x0, [x8, #0x118]       | X0 = (X19 + (X20 + 76) << 4) + 280;     
            val_9 = mem[(X19 + (X20 + 76) << 4) + 280];
            val_9 = (X19 + (X20 + 76) << 4) + 280;
            // 0x028E8F28: B #0x28e8f54               |  goto label_20;                         
            goto label_20;
            label_15:
            // 0x028E8F2C: LDR x8, [x19]              | X8 = X19;                               
            var val_9 = X19;
            // 0x028E8F30: MOV x0, x19                | X0 = X19;//m1                           
            // 0x028E8F34: ADD x8, x8, w21, uxtw #4   | X8 = (X19 + X20 + 76);                  
            val_9 = val_9 + (X20 + 76);
            // 0x028E8F38: LDP x2, x1, [x8, #0x110]   | X2 = (X19 + X20 + 76) + 272; X1 = (X19 + X20 + 76) + 272 + 8; //  | 
            // 0x028E8F3C: B #0x28e8ea8               |  goto label_23;                         
            goto label_23;
            label_10:
            // 0x028E8F40: LDR w9, [x10]              | W9 = (X19 + 152 + 8);                   
            var val_10 = val_5;
            // 0x028E8F44: ADD w9, w9, w2             | W9 = ((X19 + 152 + 8) + X20 + 76);      
            val_10 = val_10 + (X20 + 76);
            // 0x028E8F48: ADD x8, x8, w9, uxtw #4    | X8 = (X19 + ((X19 + 152 + 8) + X20 + 76));
            val_11 = val_11 + val_10;
            // 0x028E8F4C: ADD x0, x8, #0x110         | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272);
            val_7 = val_11 + 272;
            label_12:
            // 0x028E8F50: LDR x0, [x0, #8]           | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
            val_9 = mem[((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8];
            val_9 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
            label_20:
            // 0x028E8F54: MOV x1, x20                | X1 = X20;//m1                           
            // 0x028E8F58: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8, ????);
            // 0x028E8F5C: MOV x8, x0                 | X8 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
            // 0x028E8F60: LDR x2, [x8]               | X2 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
            // 0x028E8F64: MOV x0, x19                | X0 = X19;//m1                           
            // 0x028E8F68: MOV x1, x8                 | X1 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
            // 0x028E8F6C: B #0x28e8ea8               |  goto label_23;                         
            goto label_23;
            label_17:
            // 0x028E8F70: LDR w8, [x11]              | W8 = (X19 + 152 + 8);                   
            var val_12 = val_7;
            // 0x028E8F74: ADD w8, w8, w21            | W8 = ((X19 + 152 + 8) + X20 + 76);      
            val_12 = val_12 + (X20 + 76);
            // 0x028E8F78: ADD x8, x9, w8, uxtw #4    | X8 = (X19 + ((X19 + 152 + 8) + X20 + 76));
            val_12 = X19 + val_12;
            // 0x028E8F7C: ADD x0, x8, #0x110         | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272);
            val_8 = val_12 + 272;
            label_19:
            // 0x028E8F80: LDP x2, x1, [x0]           | X2 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272); X1 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8; //  | 
            // 0x028E8F84: MOV x0, x19                | X0 = X19;//m1                           
            // 0x028E8F88: B #0x28e8ea8               |  goto label_23;                         
            goto label_23;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E8F8C (42897292), len: 52  VirtAddr: 0x028E8F8C RVA: 0x028E8F8C token: 100680202 methodIndex: 29537 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x028E8F8C: STP x29, x30, [sp, #-0x10]! | stack[1152921512877415760] = ???;  stack[1152921512877415768] = ???;  //  dest_result_addr=1152921512877415760 |  dest_result_addr=1152921512877415768
            // 0x028E8F90: MOV x29, sp                | X29 = 1152921512877415760 (0x10000001ECF6DD50);//ML01
            // 0x028E8F94: SUB sp, sp, #0x10          | SP = (1152921512877415760 - 16) = 1152921512877415744 (0x10000001ECF6DD40);
            // 0x028E8F98: MOV x8, x2                 | X8 = object;//m1                        
            // 0x028E8F9C: MOV x9, x1                 | X9 = callback;//m1                      
            // 0x028E8FA0: ADD x1, sp, #8             | X1 = (1152921512877415744 + 8) = 1152921512877415752 (0x10000001ECF6DD48);
            // 0x028E8FA4: MOV x2, x9                 | X2 = callback;//m1                      
            // 0x028E8FA8: MOV x3, x8                 | X3 = object;//m1                        
            // 0x028E8FAC: STR xzr, [sp, #8]          | stack[1152921512877415752] = 0x0;        //  dest_result_addr=1152921512877415752
            // 0x028E8FB0: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x028E8FB4: MOV sp, x29                | SP = 1152921512877415760 (0x10000001ECF6DD50);//ML01
            // 0x028E8FB8: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x028E8FBC: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028E8FC0 (42897344), len: 16  VirtAddr: 0x028E8FC0 RVA: 0x028E8FC0 token: 100680203 methodIndex: 29538 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual object EndInvoke(System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x028E8FC0: MOV x8, x1                 | X8 = result;//m1                        
            // 0x028E8FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028E8FC8: MOV x0, x8                 | X0 = result;//m1                        
            // 0x028E8FCC: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
        
        }
    
    }

}
