using UnityEngine;
public enum UILabel.Crispness
{
    // Fields
    Never = 0
    ,OnDesktop = 1
    ,Always = 2
    

}
