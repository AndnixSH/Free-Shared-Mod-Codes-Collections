using UnityEngine;
public class ByteWriteArray
{
    // Fields
    private System.IO.MemoryStream m_Stream; //  0x00000010
    private System.IO.BinaryWriter m_Writer; //  0x00000018
    
    // Properties
    public byte[] Buffer { get; }
    public int Length { get; }
    internal System.IO.MemoryStream MemoryStream { get; }
    public int Postion { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA4E48 (12209736), len: 208  VirtAddr: 0x00BA4E48 RVA: 0x00BA4E48 token: 100690751 methodIndex: 25600 delegateWrapperIndex: 0 methodInvoker: 0
    public ByteWriteArray()
    {
        //
        // Disasemble & Code
        // 0x00BA4E48: STP x22, x21, [sp, #-0x30]! | stack[1152921514569703744] = ???;  stack[1152921514569703752] = ???;  //  dest_result_addr=1152921514569703744 |  dest_result_addr=1152921514569703752
        // 0x00BA4E4C: STP x20, x19, [sp, #0x10]  | stack[1152921514569703760] = ???;  stack[1152921514569703768] = ???;  //  dest_result_addr=1152921514569703760 |  dest_result_addr=1152921514569703768
        // 0x00BA4E50: STP x29, x30, [sp, #0x20]  | stack[1152921514569703776] = ???;  stack[1152921514569703784] = ???;  //  dest_result_addr=1152921514569703776 |  dest_result_addr=1152921514569703784
        // 0x00BA4E54: ADD x29, sp, #0x20         | X29 = (1152921514569703744 + 32) = 1152921514569703776 (0x1000000251D52160);
        // 0x00BA4E58: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA4E5C: LDRB w8, [x20, #0xace]     | W8 = (bool)static_value_03733ACE;       
        // 0x00BA4E60: MOV x19, x0                | X19 = 1152921514569715792 (0x1000000251D55050);//ML01
        // 0x00BA4E64: TBNZ w8, #0, #0xba4e80     | if (static_value_03733ACE == true) goto label_0;
        // 0x00BA4E68: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00BA4E6C: LDR x8, [x8, #0x928]       | X8 = 0x2B9001C;                         
        // 0x00BA4E70: LDR w0, [x8]               | W0 = 0x16CB;                            
        // 0x00BA4E74: BL #0x2782188              | X0 = sub_2782188( ?? 0x16CB, ????);     
        // 0x00BA4E78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA4E7C: STRB w8, [x20, #0xace]     | static_value_03733ACE = true;            //  dest_result_addr=57883342
        label_0:
        // 0x00BA4E80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4E84: MOV x0, x19                | X0 = 1152921514569715792 (0x1000000251D55050);//ML01
        // 0x00BA4E88: BL #0x16f59f0              | this..ctor();                           
        // 0x00BA4E8C: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00BA4E90: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
        // 0x00BA4E94: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
        System.IO.MemoryStream val_1 = null;
        // 0x00BA4E98: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
        // 0x00BA4E9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4EA0: MOV x20, x0                | X20 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA4EA4: BL #0x1e762f4              | .ctor();                                
        val_1 = new System.IO.MemoryStream();
        // 0x00BA4EA8: STR x20, [x19, #0x10]      | this.m_Stream = typeof(System.IO.MemoryStream);  //  dest_result_addr=1152921514569715808
        this.m_Stream = val_1;
        // 0x00BA4EAC: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00BA4EB0: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
        // 0x00BA4EB4: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
        // 0x00BA4EB8: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
        // 0x00BA4EBC: TBZ w8, #0, #0xba4ecc      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA4EC0: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
        // 0x00BA4EC4: CBNZ w8, #0xba4ecc         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA4EC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
        label_2:
        // 0x00BA4ECC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA4ED0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4ED4: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_2 = System.Text.Encoding.UTF8;
        // 0x00BA4ED8: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
        // 0x00BA4EDC: LDR x8, [x8, #0xb0]        | X8 = 1152921504620744704;               
        // 0x00BA4EE0: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00BA4EE4: LDR x8, [x8]               | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA4EE8: MOV x0, x8                 | X0 = 1152921504620744704 (0x1000000000D41000);//ML01
        System.IO.BinaryWriter val_3 = null;
        // 0x00BA4EEC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryWriter), ????);
        // 0x00BA4EF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA4EF4: MOV x1, x20                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA4EF8: MOV x2, x21                | X2 = val_2;//m1                         
        // 0x00BA4EFC: MOV x22, x0                | X22 = 1152921504620744704 (0x1000000000D41000);//ML01
        // 0x00BA4F00: BL #0x1e67f58              | .ctor(output:  val_1, encoding:  val_2);
        val_3 = new System.IO.BinaryWriter(output:  val_1, encoding:  val_2);
        // 0x00BA4F04: STR x22, [x19, #0x18]      | this.m_Writer = typeof(System.IO.BinaryWriter);  //  dest_result_addr=1152921514569715816
        this.m_Writer = val_3;
        // 0x00BA4F08: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA4F0C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA4F10: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA4F14: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4F18 (12209944), len: 264  VirtAddr: 0x00BA4F18 RVA: 0x00BA4F18 token: 100690752 methodIndex: 25601 delegateWrapperIndex: 0 methodInvoker: 0
    public static byte[] inverse(byte[] source)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00BA4F18: STP x24, x23, [sp, #-0x40]! | stack[1152921514569856688] = ???;  stack[1152921514569856696] = ???;  //  dest_result_addr=1152921514569856688 |  dest_result_addr=1152921514569856696
        // 0x00BA4F1C: STP x22, x21, [sp, #0x10]  | stack[1152921514569856704] = ???;  stack[1152921514569856712] = ???;  //  dest_result_addr=1152921514569856704 |  dest_result_addr=1152921514569856712
        // 0x00BA4F20: STP x20, x19, [sp, #0x20]  | stack[1152921514569856720] = ???;  stack[1152921514569856728] = ???;  //  dest_result_addr=1152921514569856720 |  dest_result_addr=1152921514569856728
        // 0x00BA4F24: STP x29, x30, [sp, #0x30]  | stack[1152921514569856736] = ???;  stack[1152921514569856744] = ???;  //  dest_result_addr=1152921514569856736 |  dest_result_addr=1152921514569856744
        // 0x00BA4F28: ADD x29, sp, #0x30         | X29 = (1152921514569856688 + 48) = 1152921514569856736 (0x1000000251D776E0);
        // 0x00BA4F2C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA4F30: LDRB w8, [x20, #0xacf]     | W8 = (bool)static_value_03733ACF;       
        // 0x00BA4F34: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00BA4F38: TBNZ w8, #0, #0xba4f54     | if (static_value_03733ACF == true) goto label_0;
        // 0x00BA4F3C: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x00BA4F40: LDR x8, [x8, #0xae0]       | X8 = 0x2B90020;                         
        // 0x00BA4F44: LDR w0, [x8]               | W0 = 0x16CC;                            
        // 0x00BA4F48: BL #0x2782188              | X0 = sub_2782188( ?? 0x16CC, ????);     
        // 0x00BA4F4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA4F50: STRB w8, [x20, #0xacf]     | static_value_03733ACF = true;            //  dest_result_addr=57883343
        label_0:
        // 0x00BA4F54: CBNZ x19, #0xba4f5c        | if (X1 != 0) goto label_1;              
        if(X1 != 0)
        {
            goto label_1;
        }
        // 0x00BA4F58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16CC, ????);     
        label_1:
        // 0x00BA4F5C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00BA4F60: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
        // 0x00BA4F64: LDR w21, [x19, #0x18]      | W21 = X1 + 24;                          
        val_4 = mem[X1 + 24];
        val_4 = X1 + 24;
        // 0x00BA4F68: LDR x20, [x8]              | X20 = typeof(System.Byte[]);            
        // 0x00BA4F6C: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA4F70: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
        // 0x00BA4F74: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA4F78: MOV x1, x21                | X1 = X1 + 24;//m1                       
        // 0x00BA4F7C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        // 0x00BA4F80: MOV x20, x0                | X20 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA4F84: CBNZ x19, #0xba4f8c        | if (X1 != 0) goto label_2;              
        if(X1 != 0)
        {
            goto label_2;
        }
        // 0x00BA4F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        label_2:
        // 0x00BA4F8C: LDR x8, [x19, #0x18]       | X8 = X1 + 24;                           
        // 0x00BA4F90: SUB w9, w8, #1             | W9 = (X1 + 24 - 1);                     
        var val_1 = (X1 + 24) - 1;
        // 0x00BA4F94: TBNZ w9, #0x1f, #0xba5008  | if (((X1 + 24 - 1) & 0x80000000) != 0) goto label_3;
        if((val_1 & 2147483648) != 0)
        {
            goto label_3;
        }
        // 0x00BA4F98: SXTW x21, w9               | X21 = (long)(int)((X1 + 24 - 1));       
        // 0x00BA4F9C: NEG w22, w8                | W22 = -(X1 + 24);                       
        var val_5 = -(X1 + 24);
        label_8:
        // 0x00BA4FA0: CBNZ x19, #0xba4fac        | if (X1 != 0) goto label_4;              
        if(X1 != 0)
        {
            goto label_4;
        }
        // 0x00BA4FA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        // 0x00BA4FA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        label_4:
        // 0x00BA4FAC: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
        var val_4 = X1 + 24;
        // 0x00BA4FB0: ADD w9, w22, w8            | W9 = (X1 + 24 + X1 + 24);               
        var val_2 = val_5 + val_4;
        // 0x00BA4FB4: SXTW x23, w9               | X23 = (long)(int)((X1 + 24 + X1 + 24)); 
        // 0x00BA4FB8: CMP w9, w8                 | STATE = COMPARE((X1 + 24 + X1 + 24), X1 + 24)
        // 0x00BA4FBC: B.LO #0xba4fcc             | if (val_2 < X1 + 24) goto label_5;      
        if(val_2 < val_4)
        {
            goto label_5;
        }
        // 0x00BA4FC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
        // 0x00BA4FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4FC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
        label_5:
        // 0x00BA4FCC: ADD x8, x19, x23           | X8 = (X1 + (long)(int)((X1 + 24 + X1 + 24)));
        val_4 = X1 + (long)val_2;
        // 0x00BA4FD0: LDRB w23, [x8, #0x20]      | W23 = (X1 + (long)(int)((X1 + 24 + X1 + 24))) + 32;
        // 0x00BA4FD4: CBNZ x20, #0xba4fdc        | if ( != null) goto label_6;             
        if(null != null)
        {
            goto label_6;
        }
        // 0x00BA4FD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        label_6:
        // 0x00BA4FDC: LDR w8, [x20, #0x18]       | W8 = System.Byte[].__il2cppRuntimeField_namespaze;
        // 0x00BA4FE0: CMP x21, x8                | STATE = COMPARE((long)(int)((X1 + 24 - 1)), System.Byte[].__il2cppRuntimeField_namespaze)
        // 0x00BA4FE4: B.LO #0xba4ff4             | if ((long)val_1 < System.Byte[].__il2cppRuntimeField_namespaze) goto label_7;
        // 0x00BA4FE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
        // 0x00BA4FEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4FF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
        label_7:
        // 0x00BA4FF4: ADD x8, x20, x21           | X8 = (null + (long)(int)((X1 + 24 - 1)));
        var val_3 = null + (long)val_1;
        // 0x00BA4FF8: SUB x21, x21, #1           | X21 = ((long)(int)((X1 + 24 - 1)) - 1); 
        val_4 = (long)val_1 - 1;
        // 0x00BA4FFC: ADD w22, w22, #1           | W22 = (X1 + 24 + 1);                    
        val_5 = val_5 + 1;
        // 0x00BA5000: STRB w23, [x8, #0x20]      | mem2[0] = (X1 + (long)(int)((X1 + 24 + X1 + 24))) + 32;  //  dest_result_addr=0
        mem2[0] = (X1 + (long)(int)((X1 + 24 + X1 + 24))) + 32;
        // 0x00BA5004: TBZ w21, #0x1f, #0xba4fa0  | if ((((long)(int)((X1 + 24 - 1)) - 1) & 0x80000000) == 0) goto label_8;
        if((val_4 & 2147483648) == 0)
        {
            goto label_8;
        }
        label_3:
        // 0x00BA5008: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA500C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5010: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5014: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA5018: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00BA501C: RET                        |  return (System.Byte[])typeof(System.Byte[]);
        return (System.Byte[])null;
        //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5020 (12210208), len: 92  VirtAddr: 0x00BA5020 RVA: 0x00BA5020 token: 100690753 methodIndex: 25602 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteBoolean(bool value)
    {
        //
        // Disasemble & Code
        // 0x00BA5020: STP x20, x19, [sp, #-0x20]! | stack[1152921514570009680] = ???;  stack[1152921514570009688] = ???;  //  dest_result_addr=1152921514570009680 |  dest_result_addr=1152921514570009688
        // 0x00BA5024: STP x29, x30, [sp, #0x10]  | stack[1152921514570009696] = ???;  stack[1152921514570009704] = ???;  //  dest_result_addr=1152921514570009696 |  dest_result_addr=1152921514570009704
        // 0x00BA5028: ADD x29, sp, #0x10         | X29 = (1152921514570009680 + 16) = 1152921514570009696 (0x1000000251D9CC60);
        // 0x00BA502C: LDR x20, [x0, #0x18]       | X20 = this.m_Writer; //P2               
        // 0x00BA5030: MOV w19, w1                | W19 = value;//m1                        
        // 0x00BA5034: CBNZ x20, #0xba503c        | if (this.m_Writer != null) goto label_0;
        if(this.m_Writer != null)
        {
            goto label_0;
        }
        // 0x00BA5038: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA503C: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5040: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA5044: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_160; X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_168; //  | 
        // 0x00BA5048: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_160();
        // 0x00BA504C: MOV x20, x0                | X20 = this.m_Writer;//m1                
        // 0x00BA5050: AND w19, w19, #1           | W19 = (value & 1);                      
        bool val_1 = value;
        // 0x00BA5054: CBNZ x20, #0xba505c        | if (this.m_Writer != null) goto label_1;
        if(this.m_Writer != null)
        {
            goto label_1;
        }
        // 0x00BA5058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Writer, ????);
        label_1:
        // 0x00BA505C: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5060: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA5064: MOV w1, w19                | W1 = (value & 1);//m1                   
        // 0x00BA5068: LDR x3, [x8, #0x270]       | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
        // 0x00BA506C: LDR x2, [x8, #0x278]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_278;
        // 0x00BA5070: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5074: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5078: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA507C (12210300), len: 88  VirtAddr: 0x00BA507C RVA: 0x00BA507C token: 100690754 methodIndex: 25603 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteByte(byte value)
    {
        //
        // Disasemble & Code
        // 0x00BA507C: STP x20, x19, [sp, #-0x20]! | stack[1152921514570129872] = ???;  stack[1152921514570129880] = ???;  //  dest_result_addr=1152921514570129872 |  dest_result_addr=1152921514570129880
        // 0x00BA5080: STP x29, x30, [sp, #0x10]  | stack[1152921514570129888] = ???;  stack[1152921514570129896] = ???;  //  dest_result_addr=1152921514570129888 |  dest_result_addr=1152921514570129896
        // 0x00BA5084: ADD x29, sp, #0x10         | X29 = (1152921514570129872 + 16) = 1152921514570129888 (0x1000000251DBA1E0);
        // 0x00BA5088: LDR x20, [x0, #0x18]       | X20 = this.m_Writer; //P2               
        // 0x00BA508C: MOV w19, w1                | W19 = value;//m1                        
        // 0x00BA5090: CBNZ x20, #0xba5098        | if (this.m_Writer != null) goto label_0;
        if(this.m_Writer != null)
        {
            goto label_0;
        }
        // 0x00BA5094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA5098: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA509C: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA50A0: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_160; X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_168; //  | 
        // 0x00BA50A4: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_160();
        // 0x00BA50A8: MOV x20, x0                | X20 = this.m_Writer;//m1                
        // 0x00BA50AC: CBNZ x20, #0xba50b4        | if (this.m_Writer != null) goto label_1;
        if(this.m_Writer != null)
        {
            goto label_1;
        }
        // 0x00BA50B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Writer, ????);
        label_1:
        // 0x00BA50B4: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA50B8: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA50BC: MOV w1, w19                | W1 = value;//m1                         
        // 0x00BA50C0: LDR x3, [x8, #0x270]       | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
        // 0x00BA50C4: LDR x2, [x8, #0x278]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_278;
        // 0x00BA50C8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA50CC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA50D0: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA50D4 (12210388), len: 184  VirtAddr: 0x00BA50D4 RVA: 0x00BA50D4 token: 100690755 methodIndex: 25604 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteBytes(byte[] buffer)
    {
        //
        // Disasemble & Code
        // 0x00BA50D4: STP x24, x23, [sp, #-0x40]! | stack[1152921514570286896] = ???;  stack[1152921514570286904] = ???;  //  dest_result_addr=1152921514570286896 |  dest_result_addr=1152921514570286904
        // 0x00BA50D8: STP x22, x21, [sp, #0x10]  | stack[1152921514570286912] = ???;  stack[1152921514570286920] = ???;  //  dest_result_addr=1152921514570286912 |  dest_result_addr=1152921514570286920
        // 0x00BA50DC: STP x20, x19, [sp, #0x20]  | stack[1152921514570286928] = ???;  stack[1152921514570286936] = ???;  //  dest_result_addr=1152921514570286928 |  dest_result_addr=1152921514570286936
        // 0x00BA50E0: STP x29, x30, [sp, #0x30]  | stack[1152921514570286944] = ???;  stack[1152921514570286952] = ???;  //  dest_result_addr=1152921514570286944 |  dest_result_addr=1152921514570286952
        // 0x00BA50E4: ADD x29, sp, #0x30         | X29 = (1152921514570286896 + 48) = 1152921514570286944 (0x1000000251DE0760);
        // 0x00BA50E8: MOV x19, x1                | X19 = buffer;//m1                       
        // 0x00BA50EC: MOV x20, x0                | X20 = 1152921514570298960 (0x1000000251DE3650);//ML01
        // 0x00BA50F0: CBZ x19, #0xba5178         | if (buffer == null) goto label_1;       
        if(buffer == null)
        {
            goto label_1;
        }
        // 0x00BA50F4: LDR w8, [x19, #0x18]       | W8 = buffer.Length; //P2                
        // 0x00BA50F8: CMP w8, #1                 | STATE = COMPARE(buffer.Length, 0x1)     
        // 0x00BA50FC: B.LT #0xba5178             | if (buffer.Length < 1) goto label_1;    
        if(buffer.Length < 1)
        {
            goto label_1;
        }
        // 0x00BA5100: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        var val_2 = 0;
        label_5:
        // 0x00BA5104: LDR x21, [x20, #0x18]      | X21 = this.m_Writer; //P2               
        // 0x00BA5108: CBNZ x21, #0xba5110        | if (this.m_Writer != null) goto label_2;
        if(this.m_Writer != null)
        {
            goto label_2;
        }
        // 0x00BA510C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x00BA5110: LDR x8, [x21]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5114: MOV x0, x21                | X0 = this.m_Writer;//m1                 
        // 0x00BA5118: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_160; X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_168; //  | 
        // 0x00BA511C: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_160();
        // 0x00BA5120: LDR w8, [x19, #0x18]       | W8 = buffer.Length; //P2                
        // 0x00BA5124: MOV x21, x0                | X21 = this.m_Writer;//m1                
        // 0x00BA5128: SXTW x22, w23              | X22 = 0 (0x00000000);                   
        // 0x00BA512C: CMP w23, w8                | STATE = COMPARE(0x0, buffer.Length)     
        // 0x00BA5130: B.LO #0xba5140             | if (0 < buffer.Length) goto label_3;    
        if(val_2 < buffer.Length)
        {
            goto label_3;
        }
        // 0x00BA5134: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Writer, ????);
        // 0x00BA5138: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA513C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Writer, ????);
        label_3:
        // 0x00BA5140: ADD x8, x19, x22           | X8 = buffer[0x0]; //PARR1               
        // 0x00BA5144: LDRB w22, [x8, #0x20]      | W22 = buffer[0x0][0]                    
        byte val_1 = buffer[0];
        // 0x00BA5148: CBNZ x21, #0xba5150        | if (this.m_Writer != null) goto label_4;
        if(this.m_Writer != null)
        {
            goto label_4;
        }
        // 0x00BA514C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Writer, ????);
        label_4:
        // 0x00BA5150: LDR x8, [x21]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5154: MOV x0, x21                | X0 = this.m_Writer;//m1                 
        // 0x00BA5158: MOV w1, w22                | W1 = buffer[0x0][0];//m1                
        // 0x00BA515C: LDR x9, [x8, #0x270]       | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
        // 0x00BA5160: LDR x2, [x8, #0x278]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_278;
        // 0x00BA5164: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270();
        // 0x00BA5168: LDR w8, [x19, #0x18]       | W8 = buffer.Length; //P2                
        // 0x00BA516C: ADD w23, w23, #1           | W23 = (0 + 1);                          
        val_2 = val_2 + 1;
        // 0x00BA5170: CMP w23, w8                | STATE = COMPARE((0 + 1), buffer.Length) 
        // 0x00BA5174: B.LT #0xba5104             | if (0 < buffer.Length) goto label_5;    
        if(val_2 < buffer.Length)
        {
            goto label_5;
        }
        label_1:
        // 0x00BA5178: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA517C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5180: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA5184: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00BA5188: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA518C (12210572), len: 200  VirtAddr: 0x00BA518C RVA: 0x00BA518C token: 100690756 methodIndex: 25605 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteBytes(byte[] bytes, int offset, int length)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00BA518C: STP x26, x25, [sp, #-0x50]! | stack[1152921514570480800] = ???;  stack[1152921514570480808] = ???;  //  dest_result_addr=1152921514570480800 |  dest_result_addr=1152921514570480808
        // 0x00BA5190: STP x24, x23, [sp, #0x10]  | stack[1152921514570480816] = ???;  stack[1152921514570480824] = ???;  //  dest_result_addr=1152921514570480816 |  dest_result_addr=1152921514570480824
        // 0x00BA5194: STP x22, x21, [sp, #0x20]  | stack[1152921514570480832] = ???;  stack[1152921514570480840] = ???;  //  dest_result_addr=1152921514570480832 |  dest_result_addr=1152921514570480840
        // 0x00BA5198: STP x20, x19, [sp, #0x30]  | stack[1152921514570480848] = ???;  stack[1152921514570480856] = ???;  //  dest_result_addr=1152921514570480848 |  dest_result_addr=1152921514570480856
        // 0x00BA519C: STP x29, x30, [sp, #0x40]  | stack[1152921514570480864] = ???;  stack[1152921514570480872] = ???;  //  dest_result_addr=1152921514570480864 |  dest_result_addr=1152921514570480872
        // 0x00BA51A0: ADD x29, sp, #0x40         | X29 = (1152921514570480800 + 64) = 1152921514570480864 (0x1000000251E0FCE0);
        // 0x00BA51A4: MOV w19, w3                | W19 = length;//m1                       
        val_2 = length;
        // 0x00BA51A8: MOV w20, w2                | W20 = offset;//m1                       
        int val_2 = offset;
        // 0x00BA51AC: MOV x21, x1                | X21 = bytes;//m1                        
        // 0x00BA51B0: MOV x22, x0                | X22 = 1152921514570492880 (0x1000000251E12BD0);//ML01
        // 0x00BA51B4: ADD w8, w19, w20           | W8 = (length + offset);                 
        int val_1 = val_2 + val_2;
        // 0x00BA51B8: CMP w8, w20                | STATE = COMPARE((length + offset), offset)
        // 0x00BA51BC: B.LE #0xba523c             | if (val_1 <= offset) goto label_0;      
        if(val_1 <= val_2)
        {
            goto label_0;
        }
        // 0x00BA51C0: ADD x8, x21, w20, sxtw     | X8 = bytes[offset]; //PARR1             
        // 0x00BA51C4: ADD x25, x8, #0x20         | X25 = bytes[offset][0x20]; //PARR1      
        label_5:
        // 0x00BA51C8: LDR x23, [x22, #0x18]      | X23 = this.m_Writer; //P2               
        // 0x00BA51CC: CBNZ x23, #0xba51d4        | if (this.m_Writer != null) goto label_1;
        if(this.m_Writer != null)
        {
            goto label_1;
        }
        // 0x00BA51D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_1:
        // 0x00BA51D4: LDR x8, [x23]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA51D8: MOV x0, x23                | X0 = this.m_Writer;//m1                 
        // 0x00BA51DC: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_160; X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_168; //  | 
        // 0x00BA51E0: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_160();
        // 0x00BA51E4: MOV x23, x0                | X23 = this.m_Writer;//m1                
        // 0x00BA51E8: CBNZ x21, #0xba51f0        | if (bytes != null) goto label_2;        
        if(bytes != null)
        {
            goto label_2;
        }
        // 0x00BA51EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Writer, ????);
        label_2:
        // 0x00BA51F0: LDR w8, [x21, #0x18]       | W8 = bytes.Length; //P2                 
        // 0x00BA51F4: CMP w20, w8                | STATE = COMPARE(offset, bytes.Length)   
        // 0x00BA51F8: B.LO #0xba5208             | if (offset < bytes.Length) goto label_3;
        if(val_2 < bytes.Length)
        {
            goto label_3;
        }
        // 0x00BA51FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Writer, ????);
        // 0x00BA5200: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5204: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Writer, ????);
        label_3:
        // 0x00BA5208: LDRB w24, [x25]            | W24 = typeof(System.Byte[]);            
        // 0x00BA520C: CBNZ x23, #0xba5214        | if (this.m_Writer != null) goto label_4;
        if(this.m_Writer != null)
        {
            goto label_4;
        }
        // 0x00BA5210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Writer, ????);
        label_4:
        // 0x00BA5214: LDR x8, [x23]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5218: MOV x0, x23                | X0 = this.m_Writer;//m1                 
        // 0x00BA521C: MOV w1, w24                | W1 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA5220: LDR x9, [x8, #0x270]       | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
        // 0x00BA5224: LDR x2, [x8, #0x278]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_278;
        // 0x00BA5228: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270();
        // 0x00BA522C: ADD x25, x25, #1           | X25 = bytes[offset][0x20][0x1]; //PARR1 
        // 0x00BA5230: ADD w20, w20, #1           | W20 = (offset + 1);                     
        val_2 = val_2 + 1;
        // 0x00BA5234: SUB w19, w19, #1           | W19 = (length - 1);                     
        val_2 = val_2 - 1;
        // 0x00BA5238: CBNZ w19, #0xba51c8        | if ((length - 1) != 0) goto label_5;    
        if(val_2 != 0)
        {
            goto label_5;
        }
        label_0:
        // 0x00BA523C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5240: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5244: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA5248: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA524C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00BA5250: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5254 (12210772), len: 188  VirtAddr: 0x00BA5254 RVA: 0x00BA5254 token: 100690757 methodIndex: 25606 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteDouble(double value)
    {
        //
        // Disasemble & Code
        // 0x00BA5254: STP d9, d8, [sp, #-0x30]!  | stack[1152921514570711616] = ???;  stack[1152921514570711624] = ???;  //  dest_result_addr=1152921514570711616 |  dest_result_addr=1152921514570711624
        // 0x00BA5258: STP x20, x19, [sp, #0x10]  | stack[1152921514570711632] = ???;  stack[1152921514570711640] = ???;  //  dest_result_addr=1152921514570711632 |  dest_result_addr=1152921514570711640
        // 0x00BA525C: STP x29, x30, [sp, #0x20]  | stack[1152921514570711648] = ???;  stack[1152921514570711656] = ???;  //  dest_result_addr=1152921514570711648 |  dest_result_addr=1152921514570711656
        // 0x00BA5260: ADD x29, sp, #0x20         | X29 = (1152921514570711616 + 32) = 1152921514570711648 (0x1000000251E48260);
        // 0x00BA5264: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA5268: LDRB w8, [x20, #0xad0]     | W8 = (bool)static_value_03733AD0;       
        // 0x00BA526C: MOV v8.16b, v0.16b         | V8 = value;//m1                         
        // 0x00BA5270: MOV x19, x0                | X19 = 1152921514570723664 (0x1000000251E4B150);//ML01
        // 0x00BA5274: TBNZ w8, #0, #0xba5290     | if (static_value_03733AD0 == true) goto label_0;
        // 0x00BA5278: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
        // 0x00BA527C: LDR x8, [x8, #0xb18]       | X8 = 0x2B90024;                         
        // 0x00BA5280: LDR w0, [x8]               | W0 = 0x16CD;                            
        // 0x00BA5284: BL #0x2782188              | X0 = sub_2782188( ?? 0x16CD, ????);     
        // 0x00BA5288: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA528C: STRB w8, [x20, #0xad0]     | static_value_03733AD0 = true;            //  dest_result_addr=57883344
        label_0:
        // 0x00BA5290: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00BA5294: LDR x8, [x8, #0xe08]       | X8 = 1152921504652320768;               
        // 0x00BA5298: LDR x0, [x8]               | X0 = typeof(System.BitConverter);       
        // 0x00BA529C: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
        // 0x00BA52A0: TBZ w8, #0, #0xba52b0      | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA52A4: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
        // 0x00BA52A8: CBNZ w8, #0xba52b0         | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA52AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
        label_2:
        // 0x00BA52B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA52B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA52B8: MOV v0.16b, v8.16b         | V0 = value;//m1                         
        // 0x00BA52BC: BL #0x18d2e60              | X0 = System.BitConverter.GetBytes(value:  value);
        System.Byte[] val_1 = System.BitConverter.GetBytes(value:  value);
        // 0x00BA52C0: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00BA52C4: BL #0xba4f18               | X0 = ByteWriteArray.inverse(source:  System.Byte[] val_1 = System.BitConverter.GetBytes(value:  value));
        System.Byte[] val_2 = ByteWriteArray.inverse(source:  val_1);
        // 0x00BA52C8: MOV x1, x0                 | X1 = val_2;//m1                         
        // 0x00BA52CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA52D0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA52D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA52D8: BL #0x18d302c              | X0 = System.BitConverter.ToInt64(value:  0, startIndex:  val_2);
        long val_3 = System.BitConverter.ToInt64(value:  0, startIndex:  val_2);
        // 0x00BA52DC: LDR x20, [x19, #0x18]      | X20 = this.m_Writer; //P2               
        // 0x00BA52E0: MOV x19, x0                | X19 = val_3;//m1                        
        // 0x00BA52E4: CBNZ x20, #0xba52ec        | if (this.m_Writer != null) goto label_3;
        if(this.m_Writer != null)
        {
            goto label_3;
        }
        // 0x00BA52E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x00BA52EC: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA52F0: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA52F4: MOV x1, x19                | X1 = val_3;//m1                         
        // 0x00BA52F8: LDR x3, [x8, #0x210]       | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_210;
        // 0x00BA52FC: LDR x2, [x8, #0x218]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_218;
        // 0x00BA5300: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5304: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5308: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00BA530C: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_210;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_210;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA534C (12211020), len: 188  VirtAddr: 0x00BA534C RVA: 0x00BA534C token: 100690758 methodIndex: 25607 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteFloat(float value)
    {
        //
        // Disasemble & Code
        // 0x00BA534C: STP d9, d8, [sp, #-0x30]!  | stack[1152921514570979264] = ???;  stack[1152921514570979272] = ???;  //  dest_result_addr=1152921514570979264 |  dest_result_addr=1152921514570979272
        // 0x00BA5350: STP x20, x19, [sp, #0x10]  | stack[1152921514570979280] = ???;  stack[1152921514570979288] = ???;  //  dest_result_addr=1152921514570979280 |  dest_result_addr=1152921514570979288
        // 0x00BA5354: STP x29, x30, [sp, #0x20]  | stack[1152921514570979296] = ???;  stack[1152921514570979304] = ???;  //  dest_result_addr=1152921514570979296 |  dest_result_addr=1152921514570979304
        // 0x00BA5358: ADD x29, sp, #0x20         | X29 = (1152921514570979264 + 32) = 1152921514570979296 (0x1000000251E897E0);
        // 0x00BA535C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA5360: LDRB w8, [x20, #0xad1]     | W8 = (bool)static_value_03733AD1;       
        // 0x00BA5364: MOV v8.16b, v0.16b         | V8 = value;//m1                         
        // 0x00BA5368: MOV x19, x0                | X19 = 1152921514570991312 (0x1000000251E8C6D0);//ML01
        // 0x00BA536C: TBNZ w8, #0, #0xba5388     | if (static_value_03733AD1 == true) goto label_0;
        // 0x00BA5370: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00BA5374: LDR x8, [x8, #0xc8]        | X8 = 0x2B90028;                         
        // 0x00BA5378: LDR w0, [x8]               | W0 = 0x16CE;                            
        // 0x00BA537C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16CE, ????);     
        // 0x00BA5380: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA5384: STRB w8, [x20, #0xad1]     | static_value_03733AD1 = true;            //  dest_result_addr=57883345
        label_0:
        // 0x00BA5388: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00BA538C: LDR x8, [x8, #0xe08]       | X8 = 1152921504652320768;               
        // 0x00BA5390: LDR x0, [x8]               | X0 = typeof(System.BitConverter);       
        // 0x00BA5394: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
        // 0x00BA5398: TBZ w8, #0, #0xba53a8      | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA539C: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
        // 0x00BA53A0: CBNZ w8, #0xba53a8         | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA53A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
        label_2:
        // 0x00BA53A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA53AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA53B0: MOV v0.16b, v8.16b         | V0 = value;//m1                         
        // 0x00BA53B4: BL #0x18d378c              | X0 = System.BitConverter.GetBytes(value:  value);
        System.Byte[] val_1 = System.BitConverter.GetBytes(value:  value);
        // 0x00BA53B8: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00BA53BC: BL #0xba4f18               | X0 = ByteWriteArray.inverse(source:  System.Byte[] val_1 = System.BitConverter.GetBytes(value:  value));
        System.Byte[] val_2 = ByteWriteArray.inverse(source:  val_1);
        // 0x00BA53C0: MOV x1, x0                 | X1 = val_2;//m1                         
        // 0x00BA53C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA53C8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA53CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA53D0: BL #0x18d3a04              | X0 = System.BitConverter.ToInt32(value:  0, startIndex:  val_2);
        int val_3 = System.BitConverter.ToInt32(value:  0, startIndex:  val_2);
        // 0x00BA53D4: LDR x20, [x19, #0x18]      | X20 = this.m_Writer; //P2               
        // 0x00BA53D8: MOV w19, w0                | W19 = val_3;//m1                        
        // 0x00BA53DC: CBNZ x20, #0xba53e4        | if (this.m_Writer != null) goto label_3;
        if(this.m_Writer != null)
        {
            goto label_3;
        }
        // 0x00BA53E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x00BA53E4: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA53E8: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA53EC: MOV w1, w19                | W1 = val_3;//m1                         
        // 0x00BA53F0: LDR x3, [x8, #0x200]       | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_200;
        // 0x00BA53F4: LDR x2, [x8, #0x208]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_208;
        // 0x00BA53F8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA53FC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5400: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00BA5404: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_200;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_200;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5444 (12211268), len: 60  VirtAddr: 0x00BA5444 RVA: 0x00BA5444 token: 100690759 methodIndex: 25608 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteUInt32(uint value)
    {
        //
        // Disasemble & Code
        // 0x00BA5444: STP x20, x19, [sp, #-0x20]! | stack[1152921514571173200] = ???;  stack[1152921514571173208] = ???;  //  dest_result_addr=1152921514571173200 |  dest_result_addr=1152921514571173208
        // 0x00BA5448: STP x29, x30, [sp, #0x10]  | stack[1152921514571173216] = ???;  stack[1152921514571173224] = ???;  //  dest_result_addr=1152921514571173216 |  dest_result_addr=1152921514571173224
        // 0x00BA544C: ADD x29, sp, #0x10         | X29 = (1152921514571173200 + 16) = 1152921514571173216 (0x1000000251EB8D60);
        // 0x00BA5450: LDR x20, [x0, #0x18]       | X20 = this.m_Writer; //P2               
        // 0x00BA5454: MOV w19, w1                | W19 = value;//m1                        
        // 0x00BA5458: CBNZ x20, #0xba5460        | if (this.m_Writer != null) goto label_0;
        if(this.m_Writer != null)
        {
            goto label_0;
        }
        // 0x00BA545C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA5460: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5464: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA5468: MOV w1, w19                | W1 = value;//m1                         
        // 0x00BA546C: LDR x3, [x8, #0x260]       | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_260;
        // 0x00BA5470: LDR x2, [x8, #0x268]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_268;
        // 0x00BA5474: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5478: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA547C: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_260;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_260;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5408 (12211208), len: 60  VirtAddr: 0x00BA5408 RVA: 0x00BA5408 token: 100690760 methodIndex: 25609 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteInt(int value)
    {
        //
        // Disasemble & Code
        // 0x00BA5408: STP x20, x19, [sp, #-0x20]! | stack[1152921514571293392] = ???;  stack[1152921514571293400] = ???;  //  dest_result_addr=1152921514571293392 |  dest_result_addr=1152921514571293400
        // 0x00BA540C: STP x29, x30, [sp, #0x10]  | stack[1152921514571293408] = ???;  stack[1152921514571293416] = ???;  //  dest_result_addr=1152921514571293408 |  dest_result_addr=1152921514571293416
        // 0x00BA5410: ADD x29, sp, #0x10         | X29 = (1152921514571293392 + 16) = 1152921514571293408 (0x1000000251ED62E0);
        // 0x00BA5414: LDR x20, [x0, #0x18]       | X20 = this.m_Writer; //P2               
        // 0x00BA5418: MOV w19, w1                | W19 = value;//m1                        
        // 0x00BA541C: CBNZ x20, #0xba5424        | if (this.m_Writer != null) goto label_0;
        if(this.m_Writer != null)
        {
            goto label_0;
        }
        // 0x00BA5420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA5424: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5428: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA542C: MOV w1, w19                | W1 = value;//m1                         
        // 0x00BA5430: LDR x3, [x8, #0x200]       | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_200;
        // 0x00BA5434: LDR x2, [x8, #0x208]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_208;
        // 0x00BA5438: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA543C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5440: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_200;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_200;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5310 (12210960), len: 60  VirtAddr: 0x00BA5310 RVA: 0x00BA5310 token: 100690761 methodIndex: 25610 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteLong(long value)
    {
        //
        // Disasemble & Code
        // 0x00BA5310: STP x20, x19, [sp, #-0x20]! | stack[1152921514571413584] = ???;  stack[1152921514571413592] = ???;  //  dest_result_addr=1152921514571413584 |  dest_result_addr=1152921514571413592
        // 0x00BA5314: STP x29, x30, [sp, #0x10]  | stack[1152921514571413600] = ???;  stack[1152921514571413608] = ???;  //  dest_result_addr=1152921514571413600 |  dest_result_addr=1152921514571413608
        // 0x00BA5318: ADD x29, sp, #0x10         | X29 = (1152921514571413584 + 16) = 1152921514571413600 (0x1000000251EF3860);
        // 0x00BA531C: LDR x20, [x0, #0x18]       | X20 = this.m_Writer; //P2               
        // 0x00BA5320: MOV x19, x1                | X19 = value;//m1                        
        // 0x00BA5324: CBNZ x20, #0xba532c        | if (this.m_Writer != null) goto label_0;
        if(this.m_Writer != null)
        {
            goto label_0;
        }
        // 0x00BA5328: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA532C: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5330: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA5334: MOV x1, x19                | X1 = value;//m1                         
        // 0x00BA5338: LDR x3, [x8, #0x210]       | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_210;
        // 0x00BA533C: LDR x2, [x8, #0x218]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_218;
        // 0x00BA5340: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5344: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5348: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_210;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_210;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5480 (12211328), len: 60  VirtAddr: 0x00BA5480 RVA: 0x00BA5480 token: 100690762 methodIndex: 25611 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteULong(ulong value)
    {
        //
        // Disasemble & Code
        // 0x00BA5480: STP x20, x19, [sp, #-0x20]! | stack[1152921514571533776] = ???;  stack[1152921514571533784] = ???;  //  dest_result_addr=1152921514571533776 |  dest_result_addr=1152921514571533784
        // 0x00BA5484: STP x29, x30, [sp, #0x10]  | stack[1152921514571533792] = ???;  stack[1152921514571533800] = ???;  //  dest_result_addr=1152921514571533792 |  dest_result_addr=1152921514571533800
        // 0x00BA5488: ADD x29, sp, #0x10         | X29 = (1152921514571533776 + 16) = 1152921514571533792 (0x1000000251F10DE0);
        // 0x00BA548C: LDR x20, [x0, #0x18]       | X20 = this.m_Writer; //P2               
        // 0x00BA5490: MOV x19, x1                | X19 = value;//m1                        
        // 0x00BA5494: CBNZ x20, #0xba549c        | if (this.m_Writer != null) goto label_0;
        if(this.m_Writer != null)
        {
            goto label_0;
        }
        // 0x00BA5498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA549C: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA54A0: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA54A4: MOV x1, x19                | X1 = value;//m1                         
        // 0x00BA54A8: LDR x3, [x8, #0x270]       | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
        // 0x00BA54AC: LDR x2, [x8, #0x278]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_278;
        // 0x00BA54B0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA54B4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA54B8: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_270;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA54BC (12211388), len: 56  VirtAddr: 0x00BA54BC RVA: 0x00BA54BC token: 100690763 methodIndex: 25612 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteShort(short value)
    {
        //
        // Disasemble & Code
        // 0x00BA54BC: STP x20, x19, [sp, #-0x20]! | stack[1152921514571653968] = ???;  stack[1152921514571653976] = ???;  //  dest_result_addr=1152921514571653968 |  dest_result_addr=1152921514571653976
        // 0x00BA54C0: STP x29, x30, [sp, #0x10]  | stack[1152921514571653984] = ???;  stack[1152921514571653992] = ???;  //  dest_result_addr=1152921514571653984 |  dest_result_addr=1152921514571653992
        // 0x00BA54C4: ADD x29, sp, #0x10         | X29 = (1152921514571653968 + 16) = 1152921514571653984 (0x1000000251F2E360);
        // 0x00BA54C8: LDR x20, [x0, #0x18]       | X20 = this.m_Writer; //P2               
        // 0x00BA54CC: MOV w19, w1                | W19 = value;//m1                        
        // 0x00BA54D0: CBNZ x20, #0xba54d8        | if (this.m_Writer != null) goto label_0;
        if(this.m_Writer != null)
        {
            goto label_0;
        }
        // 0x00BA54D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA54D8: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA54DC: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA54E0: MOV w1, w19                | W1 = value;//m1                         
        // 0x00BA54E4: LDP x3, x2, [x8, #0x1f0]   | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F0; X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F8; //  | 
        // 0x00BA54E8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA54EC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA54F0: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F0;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F0;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA54F4 (12211444), len: 56  VirtAddr: 0x00BA54F4 RVA: 0x00BA54F4 token: 100690764 methodIndex: 25613 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteShort(int value)
    {
        //
        // Disasemble & Code
        // 0x00BA54F4: STP x20, x19, [sp, #-0x20]! | stack[1152921514571774160] = ???;  stack[1152921514571774168] = ???;  //  dest_result_addr=1152921514571774160 |  dest_result_addr=1152921514571774168
        // 0x00BA54F8: STP x29, x30, [sp, #0x10]  | stack[1152921514571774176] = ???;  stack[1152921514571774184] = ???;  //  dest_result_addr=1152921514571774176 |  dest_result_addr=1152921514571774184
        // 0x00BA54FC: ADD x29, sp, #0x10         | X29 = (1152921514571774160 + 16) = 1152921514571774176 (0x1000000251F4B8E0);
        // 0x00BA5500: LDR x20, [x0, #0x18]       | X20 = this.m_Writer; //P2               
        // 0x00BA5504: MOV w19, w1                | W19 = value;//m1                        
        // 0x00BA5508: CBNZ x20, #0xba5510        | if (this.m_Writer != null) goto label_0;
        if(this.m_Writer != null)
        {
            goto label_0;
        }
        // 0x00BA550C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA5510: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5514: MOV x0, x20                | X0 = this.m_Writer;//m1                 
        // 0x00BA5518: MOV w1, w19                | W1 = value;//m1                         
        // 0x00BA551C: LDP x3, x2, [x8, #0x1f0]   | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F0; X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F8; //  | 
        // 0x00BA5520: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5524: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5528: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F0;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F0;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA552C (12211500), len: 264  VirtAddr: 0x00BA552C RVA: 0x00BA552C token: 100690765 methodIndex: 25614 delegateWrapperIndex: 0 methodInvoker: 0
    public void WriteUTF(string value)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        System.IO.BinaryWriter val_10;
        // 0x00BA552C: STP x22, x21, [sp, #-0x30]! | stack[1152921514571939392] = ???;  stack[1152921514571939400] = ???;  //  dest_result_addr=1152921514571939392 |  dest_result_addr=1152921514571939400
        // 0x00BA5530: STP x20, x19, [sp, #0x10]  | stack[1152921514571939408] = ???;  stack[1152921514571939416] = ???;  //  dest_result_addr=1152921514571939408 |  dest_result_addr=1152921514571939416
        // 0x00BA5534: STP x29, x30, [sp, #0x20]  | stack[1152921514571939424] = ???;  stack[1152921514571939432] = ???;  //  dest_result_addr=1152921514571939424 |  dest_result_addr=1152921514571939432
        // 0x00BA5538: ADD x29, sp, #0x20         | X29 = (1152921514571939392 + 32) = 1152921514571939424 (0x1000000251F73E60);
        // 0x00BA553C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA5540: LDRB w8, [x21, #0xad2]     | W8 = (bool)static_value_03733AD2;       
        // 0x00BA5544: MOV x20, x1                | X20 = value;//m1                        
        // 0x00BA5548: MOV x19, x0                | X19 = 1152921514571951440 (0x1000000251F76D50);//ML01
        val_9 = this;
        // 0x00BA554C: TBNZ w8, #0, #0xba5568     | if (static_value_03733AD2 == true) goto label_0;
        // 0x00BA5550: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00BA5554: LDR x8, [x8, #0x6a8]       | X8 = 0x2B9002C;                         
        // 0x00BA5558: LDR w0, [x8]               | W0 = 0x16CF;                            
        // 0x00BA555C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16CF, ????);     
        // 0x00BA5560: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA5564: STRB w8, [x21, #0xad2]     | static_value_03733AD2 = true;            //  dest_result_addr=57883346
        label_0:
        // 0x00BA5568: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00BA556C: LDR x8, [x8, #0x9e0]       | X8 = 1152921504649924608;               
        // 0x00BA5570: LDR x0, [x8]               | X0 = typeof(System.Text.UTF8Encoding);  
        System.Text.UTF8Encoding val_1 = null;
        // 0x00BA5574: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.UTF8Encoding), ????);
        // 0x00BA5578: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA557C: MOV x21, x0                | X21 = 1152921504649924608 (0x1000000002915000);//ML01
        // 0x00BA5580: BL #0x1b62a98              | .ctor();                                
        val_1 = new System.Text.UTF8Encoding();
        // 0x00BA5584: CBNZ x21, #0xba558c        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00BA5588: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00BA558C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00BA5590: MOV x0, x21                | X0 = 1152921504649924608 (0x1000000002915000);//ML01
        // 0x00BA5594: MOV x1, x20                | X1 = value;//m1                         
        // 0x00BA5598: LDP x9, x2, [x8, #0x180]   |                                          //  not_find_field!1:384 |  not_find_field!1:392
        // 0x00BA559C: BLR x9                     | X0 = mem[null + 384]();                 
        // 0x00BA55A0: MOV w22, w0                | W22 = 1152921504649924608 (0x1000000002915000);//ML01
        // 0x00BA55A4: CBNZ x21, #0xba55ac        | if ( != 0) goto label_2;                
        if(null != 0)
        {
            goto label_2;
        }
        // 0x00BA55A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Text.UTF8Encoding), ????);
        label_2:
        // 0x00BA55AC: LDR x8, [x21]              | X8 = ;                                  
        // 0x00BA55B0: MOV x0, x21                | X0 = 1152921504649924608 (0x1000000002915000);//ML01
        // 0x00BA55B4: MOV x1, x20                | X1 = value;//m1                         
        // 0x00BA55B8: LDP x9, x2, [x8, #0x1c0]   | X9 = addr_off(public System.Byte[] System.Text.Encoding::GetBytes(string s));   //  |  not_find_field!1:456
        // 0x00BA55BC: BLR x9                     | X0 = GetBytes(s:  value);               
        System.Byte[] val_2 = GetBytes(s:  value);
        // 0x00BA55C0: LDR x21, [x19, #0x18]      | X21 = this.m_Writer; //P2               
        val_10 = this.m_Writer;
        // 0x00BA55C4: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00BA55C8: CBNZ x21, #0xba55d0        | if (this.m_Writer != null) goto label_3;
        if(val_10 != null)
        {
            goto label_3;
        }
        // 0x00BA55CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00BA55D0: LDR x8, [x21]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA55D4: MOV x0, x21                | X0 = this.m_Writer;//m1                 
        // 0x00BA55D8: MOV w1, w22                | W1 = 1152921504649924608 (0x1000000002915000);//ML01
        // 0x00BA55DC: LDP x9, x2, [x8, #0x1f0]   | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F0; X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F8; //  | 
        // 0x00BA55E0: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1F0();
        // 0x00BA55E4: CBNZ x20, #0xba55ec        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00BA55E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Writer, ????);
        label_4:
        // 0x00BA55EC: LDR w8, [x20, #0x18]       | W8 = val_2.Length; //P2                 
        // 0x00BA55F0: CMP w8, #1                 | STATE = COMPARE(val_2.Length, 0x1)      
        // 0x00BA55F4: B.LT #0xba5624             | if (val_2.Length < 1) goto label_5;     
        if(val_2.Length < 1)
        {
            goto label_5;
        }
        // 0x00BA55F8: LDR x19, [x19, #0x18]      | X19 = this.m_Writer; //P2               
        // 0x00BA55FC: CBNZ x19, #0xba5604        | if (this.m_Writer != null) goto label_6;
        if(this.m_Writer != null)
        {
            goto label_6;
        }
        // 0x00BA5600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Writer, ????);
        label_6:
        // 0x00BA5604: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryWriter);    
        // 0x00BA5608: MOV x0, x19                | X0 = this.m_Writer;//m1                 
        // 0x00BA560C: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00BA5610: LDP x3, x2, [x8, #0x1c0]   | X3 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1C0; X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1C8; //  | 
        // 0x00BA5614: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5618: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        val_9 = ???;
        // 0x00BA561C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        val_10 = ???;
        // 0x00BA5620: BR x3                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1C0;
        goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1C0;
        label_5:
        // 0x00BA5624: LDP x29, x30, [sp, #0x20]  | X29 = val_3; X30 = val_4;                //  find_add[1152921514571927440] |  find_add[1152921514571927440]
        // 0x00BA5628: LDP x20, x19, [sp, #0x10]  | X20 = val_5; X19 = val_6;                //  find_add[1152921514571927440] |  find_add[1152921514571927440]
        // 0x00BA562C: LDP x22, x21, [sp], #0x30  | X22 = val_7; X21 = val_8;                //  find_add[1152921514571927440] |  find_add[1152921514571927440]
        // 0x00BA5630: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5634 (12211764), len: 52  VirtAddr: 0x00BA5634 RVA: 0x00BA5634 token: 100690766 methodIndex: 25615 delegateWrapperIndex: 0 methodInvoker: 0
    public byte[] get_Buffer()
    {
        //
        // Disasemble & Code
        // 0x00BA5634: STP x20, x19, [sp, #-0x20]! | stack[1152921514572104656] = ???;  stack[1152921514572104664] = ???;  //  dest_result_addr=1152921514572104656 |  dest_result_addr=1152921514572104664
        // 0x00BA5638: STP x29, x30, [sp, #0x10]  | stack[1152921514572104672] = ???;  stack[1152921514572104680] = ???;  //  dest_result_addr=1152921514572104672 |  dest_result_addr=1152921514572104680
        // 0x00BA563C: ADD x29, sp, #0x10         | X29 = (1152921514572104656 + 16) = 1152921514572104672 (0x1000000251F9C3E0);
        // 0x00BA5640: LDR x19, [x0, #0x10]       | X19 = this.m_Stream; //P2               
        // 0x00BA5644: CBNZ x19, #0xba564c        | if (this.m_Stream != null) goto label_0;
        if(this.m_Stream != null)
        {
            goto label_0;
        }
        // 0x00BA5648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA564C: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA5650: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA5654: LDR x2, [x8, #0x2e0]       | X2 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_2E0;
        // 0x00BA5658: LDR x1, [x8, #0x2e8]       | X1 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_2E8;
        // 0x00BA565C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5660: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5664: BR x2                      | goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_2E0;
        goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_2E0;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5668 (12211816), len: 52  VirtAddr: 0x00BA5668 RVA: 0x00BA5668 token: 100690767 methodIndex: 25616 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_Length()
    {
        //
        // Disasemble & Code
        // 0x00BA5668: STP x20, x19, [sp, #-0x20]! | stack[1152921514572224848] = ???;  stack[1152921514572224856] = ???;  //  dest_result_addr=1152921514572224848 |  dest_result_addr=1152921514572224856
        // 0x00BA566C: STP x29, x30, [sp, #0x10]  | stack[1152921514572224864] = ???;  stack[1152921514572224872] = ???;  //  dest_result_addr=1152921514572224864 |  dest_result_addr=1152921514572224872
        // 0x00BA5670: ADD x29, sp, #0x10         | X29 = (1152921514572224848 + 16) = 1152921514572224864 (0x1000000251FB9960);
        // 0x00BA5674: LDR x19, [x0, #0x10]       | X19 = this.m_Stream; //P2               
        // 0x00BA5678: CBNZ x19, #0xba5680        | if (this.m_Stream != null) goto label_0;
        if(this.m_Stream != null)
        {
            goto label_0;
        }
        // 0x00BA567C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA5680: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA5684: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA5688: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_190; X1 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_198; //  | 
        // 0x00BA568C: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_190();
        // 0x00BA5690: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5694: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5698: RET                        |  return (System.Int32)this.m_Stream;    
        return (int)this.m_Stream;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA569C (12211868), len: 8  VirtAddr: 0x00BA569C RVA: 0x00BA569C token: 100690768 methodIndex: 25617 delegateWrapperIndex: 0 methodInvoker: 0
    internal System.IO.MemoryStream get_MemoryStream()
    {
        //
        // Disasemble & Code
        // 0x00BA569C: LDR x0, [x0, #0x10]        | X0 = this.m_Stream; //P2                
        // 0x00BA56A0: RET                        |  return (System.IO.MemoryStream)this.m_Stream;
        return this.m_Stream;
        //  |  // // {name=val_0, type=System.IO.MemoryStream, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA56A4 (12211876), len: 52  VirtAddr: 0x00BA56A4 RVA: 0x00BA56A4 token: 100690769 methodIndex: 25618 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_Postion()
    {
        //
        // Disasemble & Code
        // 0x00BA56A4: STP x20, x19, [sp, #-0x20]! | stack[1152921514572465232] = ???;  stack[1152921514572465240] = ???;  //  dest_result_addr=1152921514572465232 |  dest_result_addr=1152921514572465240
        // 0x00BA56A8: STP x29, x30, [sp, #0x10]  | stack[1152921514572465248] = ???;  stack[1152921514572465256] = ???;  //  dest_result_addr=1152921514572465248 |  dest_result_addr=1152921514572465256
        // 0x00BA56AC: ADD x29, sp, #0x10         | X29 = (1152921514572465232 + 16) = 1152921514572465248 (0x1000000251FF4460);
        // 0x00BA56B0: LDR x19, [x0, #0x10]       | X19 = this.m_Stream; //P2               
        // 0x00BA56B4: CBNZ x19, #0xba56bc        | if (this.m_Stream != null) goto label_0;
        if(this.m_Stream != null)
        {
            goto label_0;
        }
        // 0x00BA56B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA56BC: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA56C0: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA56C4: LDP x9, x1, [x8, #0x1a0]   | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1A0; X1 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1A8; //  | 
        // 0x00BA56C8: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1A0();
        // 0x00BA56CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA56D0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA56D4: RET                        |  return (System.Int32)this.m_Stream;    
        return (int)this.m_Stream;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA56D8 (12211928), len: 56  VirtAddr: 0x00BA56D8 RVA: 0x00BA56D8 token: 100690770 methodIndex: 25619 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_Postion(int value)
    {
        //
        // Disasemble & Code
        // 0x00BA56D8: STP x20, x19, [sp, #-0x20]! | stack[1152921514572585424] = ???;  stack[1152921514572585432] = ???;  //  dest_result_addr=1152921514572585424 |  dest_result_addr=1152921514572585432
        // 0x00BA56DC: STP x29, x30, [sp, #0x10]  | stack[1152921514572585440] = ???;  stack[1152921514572585448] = ???;  //  dest_result_addr=1152921514572585440 |  dest_result_addr=1152921514572585448
        // 0x00BA56E0: ADD x29, sp, #0x10         | X29 = (1152921514572585424 + 16) = 1152921514572585440 (0x10000002520119E0);
        // 0x00BA56E4: LDR x19, [x0, #0x10]       | X19 = this.m_Stream; //P2               
        // 0x00BA56E8: MOV w20, w1                | W20 = value;//m1                        
        // 0x00BA56EC: CBNZ x19, #0xba56f4        | if (this.m_Stream != null) goto label_0;
        if(this.m_Stream != null)
        {
            goto label_0;
        }
        // 0x00BA56F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA56F4: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA56F8: SXTW x1, w20               | X1 = (long)(int)(value);                
        // 0x00BA56FC: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA5700: LDP x3, x2, [x8, #0x1b0]   | X3 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0; X2 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B8; //  | 
        // 0x00BA5704: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5708: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA570C: BR x3                      | goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0;
        goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0;
    
    }

}
