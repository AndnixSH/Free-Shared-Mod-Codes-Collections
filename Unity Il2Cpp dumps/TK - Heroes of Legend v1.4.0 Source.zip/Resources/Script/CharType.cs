using UnityEngine;

namespace wxb
{
    internal class CharType : Serialize<char>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2F988 (14875016), len: 80  VirtAddr: 0x00E2F988 RVA: 0x00E2F988 token: 100681131 methodIndex: 57317 delegateWrapperIndex: 0 methodInvoker: 0
        public CharType()
        {
            //
            // Disasemble & Code
            // 0x00E2F988: STP x20, x19, [sp, #-0x20]! | stack[1152921513018055104] = ???;  stack[1152921513018055112] = ???;  //  dest_result_addr=1152921513018055104 |  dest_result_addr=1152921513018055112
            // 0x00E2F98C: STP x29, x30, [sp, #0x10]  | stack[1152921513018055120] = ???;  stack[1152921513018055128] = ???;  //  dest_result_addr=1152921513018055120 |  dest_result_addr=1152921513018055128
            // 0x00E2F990: ADD x29, sp, #0x10         | X29 = (1152921513018055104 + 16) = 1152921513018055120 (0x10000001F558D9D0);
            // 0x00E2F994: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2F998: LDRB w8, [x20, #0x93b]     | W8 = (bool)static_value_0373493B;       
            // 0x00E2F99C: MOV x19, x0                | X19 = 1152921513018067136 (0x10000001F55908C0);//ML01
            // 0x00E2F9A0: TBNZ w8, #0, #0xe2f9bc     | if (static_value_0373493B == true) goto label_0;
            // 0x00E2F9A4: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00E2F9A8: LDR x8, [x8, #0x650]       | X8 = 0x2B9066C;                         
            // 0x00E2F9AC: LDR w0, [x8]               | W0 = 0x185F;                            
            // 0x00E2F9B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x185F, ????);     
            // 0x00E2F9B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2F9B8: STRB w8, [x20, #0x93b]     | static_value_0373493B = true;            //  dest_result_addr=57887035
            label_0:
            // 0x00E2F9BC: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x00E2F9C0: LDR x8, [x8, #0x260]       | X8 = 1152921513018042112;               
            // 0x00E2F9C4: MOV x0, x19                | X0 = 1152921513018067136 (0x10000001F55908C0);//ML01
            // 0x00E2F9C8: LDR x1, [x8]               | X1 = System.Void wxb.Serialize<System.Char>::.ctor();
            // 0x00E2F9CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2F9D0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2F9D4: B #0x1d8bc44               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2F9D8 (14875096), len: 8  VirtAddr: 0x00E2F9D8 RVA: 0x00E2F9D8 token: 100681132 methodIndex: 57318 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int CalculateSize(char value)
        {
            //
            // Disasemble & Code
            // 0x00E2F9D8: ORR w0, wzr, #2            | W0 = 2(0x2);                            
            // 0x00E2F9DC: RET                        |  return (System.Int32)2;                
            return (int)2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2F9E0 (14875104), len: 52  VirtAddr: 0x00E2F9E0 RVA: 0x00E2F9E0 token: 100681133 methodIndex: 57319 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, char value)
        {
            //
            // Disasemble & Code
            // 0x00E2F9E0: STP x20, x19, [sp, #-0x20]! | stack[1152921513018283200] = ???;  stack[1152921513018283208] = ???;  //  dest_result_addr=1152921513018283200 |  dest_result_addr=1152921513018283208
            // 0x00E2F9E4: STP x29, x30, [sp, #0x10]  | stack[1152921513018283216] = ???;  stack[1152921513018283224] = ???;  //  dest_result_addr=1152921513018283216 |  dest_result_addr=1152921513018283224
            // 0x00E2F9E8: ADD x29, sp, #0x10         | X29 = (1152921513018283200 + 16) = 1152921513018283216 (0x10000001F55C54D0);
            // 0x00E2F9EC: MOV w19, w2                | W19 = value;//m1                        
            // 0x00E2F9F0: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2F9F4: CBNZ x20, #0xe2f9fc        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2F9F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2F9FC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2FA00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2FA04: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2FA08: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E2FA0C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2FA10: B #0x26a478c               | stream.WriteInt16(value:  value); return;
            stream.WriteInt16(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2FA14 (14875156), len: 44  VirtAddr: 0x00E2FA14 RVA: 0x00E2FA14 token: 100681134 methodIndex: 57320 delegateWrapperIndex: 0 methodInvoker: 0
        protected override char Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2FA14: STP x20, x19, [sp, #-0x20]! | stack[1152921513018403392] = ???;  stack[1152921513018403400] = ???;  //  dest_result_addr=1152921513018403392 |  dest_result_addr=1152921513018403400
            // 0x00E2FA18: STP x29, x30, [sp, #0x10]  | stack[1152921513018403408] = ???;  stack[1152921513018403416] = ???;  //  dest_result_addr=1152921513018403408 |  dest_result_addr=1152921513018403416
            // 0x00E2FA1C: ADD x29, sp, #0x10         | X29 = (1152921513018403392 + 16) = 1152921513018403408 (0x10000001F55E2A50);
            // 0x00E2FA20: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2FA24: CBNZ x19, #0xe2fa2c        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2FA28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2FA2C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2FA30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2FA34: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2FA38: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2FA3C: B #0x269ff60               | return stream.ReadInt16();              
            return stream.ReadInt16();
        
        }
    
    }

}
