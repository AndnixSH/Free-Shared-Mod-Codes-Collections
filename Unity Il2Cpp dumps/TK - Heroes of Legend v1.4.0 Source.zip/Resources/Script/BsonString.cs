using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    internal class BsonString : BsonValue
    {
        // Fields
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285E96C
        private int <ByteCount>k__BackingField; //  0x0000002C
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285E9A8
        private bool <IncludeLength>k__BackingField; //  0x00000030
        
        // Properties
        public int ByteCount { get; set; }
        public bool IncludeLength { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD1D44 (11345220), len: 72  VirtAddr: 0x00AD1D44 RVA: 0x00AD1D44 token: 100684779 methodIndex: 47426 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonString(object value, bool includeLength)
        {
            //
            // Disasemble & Code
            // 0x00AD1D44: STP x22, x21, [sp, #-0x30]! | stack[1152921513724004768] = ???;  stack[1152921513724004776] = ???;  //  dest_result_addr=1152921513724004768 |  dest_result_addr=1152921513724004776
            // 0x00AD1D48: STP x20, x19, [sp, #0x10]  | stack[1152921513724004784] = ???;  stack[1152921513724004792] = ???;  //  dest_result_addr=1152921513724004784 |  dest_result_addr=1152921513724004792
            // 0x00AD1D4C: STP x29, x30, [sp, #0x20]  | stack[1152921513724004800] = ???;  stack[1152921513724004808] = ???;  //  dest_result_addr=1152921513724004800 |  dest_result_addr=1152921513724004808
            // 0x00AD1D50: ADD x29, sp, #0x20         | X29 = (1152921513724004768 + 32) = 1152921513724004800 (0x100000021F6CC9C0);
            // 0x00AD1D54: MOV x20, x1                | X20 = value;//m1                        
            // 0x00AD1D58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1D5C: MOV w19, w2                | W19 = includeLength;//m1                
            // 0x00AD1D60: MOV x21, x0                | X21 = 1152921513724016816 (0x100000021F6CF8B0);//ML01
            // 0x00AD1D64: BL #0x16f59f0              | this..ctor();                           
            val_1 = new System.Object();
            // 0x00AD1D68: AND w9, w19, #1            | W9 = (includeLength & 1);               
            bool val_2 = includeLength;
            // 0x00AD1D6C: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00AD1D70: STRB w9, [x21, #0x30]      | this.<IncludeLength>k__BackingField = (includeLength & 1);  //  dest_result_addr=1152921513724016864
            this.<IncludeLength>k__BackingField = val_2;
            // 0x00AD1D74: STR x20, [x21, #0x20]      | mem[1152921513724016848] = value;        //  dest_result_addr=1152921513724016848
            mem[1152921513724016848] = value;
            // 0x00AD1D78: STRB w8, [x21, #0x28]      | mem[1152921513724016856] = 0x2;          //  dest_result_addr=1152921513724016856
            mem[1152921513724016856] = 2;
            // 0x00AD1D7C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1D80: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD1D84: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD1D88: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1840 (11343936), len: 8  VirtAddr: 0x00AD1840 RVA: 0x00AD1840 token: 100684780 methodIndex: 47427 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_ByteCount()
        {
            //
            // Disasemble & Code
            // 0x00AD1840: LDR w0, [x0, #0x2c]        | W0 = this.<ByteCount>k__BackingField; //P2 
            // 0x00AD1844: RET                        |  return (System.Int32)this.<ByteCount>k__BackingField;
            return this.<ByteCount>k__BackingField;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1B50 (11344720), len: 8  VirtAddr: 0x00AD1B50 RVA: 0x00AD1B50 token: 100684781 methodIndex: 47428 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_ByteCount(int value)
        {
            //
            // Disasemble & Code
            // 0x00AD1B50: STR w1, [x0, #0x2c]        | this.<ByteCount>k__BackingField = value;  //  dest_result_addr=1152921513724244956
            this.<ByteCount>k__BackingField = value;
            // 0x00AD1B54: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1B58 (11344728), len: 8  VirtAddr: 0x00AD1B58 RVA: 0x00AD1B58 token: 100684782 methodIndex: 47429 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IncludeLength()
        {
            //
            // Disasemble & Code
            // 0x00AD1B58: LDRB w0, [x0, #0x30]       | W0 = this.<IncludeLength>k__BackingField; //P2 
            // 0x00AD1B5C: RET                        |  return (System.Boolean)this.<IncludeLength>k__BackingField;
            return this.<IncludeLength>k__BackingField;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD47D0 (11356112), len: 12  VirtAddr: 0x00AD47D0 RVA: 0x00AD47D0 token: 100684783 methodIndex: 47430 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_IncludeLength(bool value)
        {
            //
            // Disasemble & Code
            // 0x00AD47D0: AND w8, w1, #1             | W8 = (value & 1);                       
            bool val_1 = value;
            // 0x00AD47D4: STRB w8, [x0, #0x30]       | this.<IncludeLength>k__BackingField = (value & 1);  //  dest_result_addr=1152921513724468960
            this.<IncludeLength>k__BackingField = val_1;
            // 0x00AD47D8: RET                        |  return;                                
            return;
        
        }
    
    }

}
