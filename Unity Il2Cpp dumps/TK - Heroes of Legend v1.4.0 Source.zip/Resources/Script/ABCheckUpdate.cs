using UnityEngine;
public class ABCheckUpdate
{
    // Fields
    public const string FLOW_CHECK_UPDATE = "FLOW_CHECK_UPDATE";
    public const string REPAIR_ASSET = "REPAIR_ASSET";
    public const string IF_OPEN_REPAIR_ASSET = "IF_OPEN_REPAIR_ASSET";
    public const string IF_OPEN_REPAIR_ASSET_BACK = "IF_OPEN_REPAIR_ASSET_BACK";
    private Filelist<FileInfoCrc> clientCrcList; //  0x00000010
    private Filelist<FileInfoCrc> serverCrcList; //  0x00000018
    private Filelist<FileInfoRes> clientList; //  0x00000020
    private Filelist<FileInfoRes> serverList; //  0x00000028
    private Filelist<FileInfoRes> clientPersistentList; //  0x00000030
    private Filelist<FileInfoRes> clientStreamingList; //  0x00000038
    private HttpDownLoad httpDownLoad; //  0x00000040
    private string updateTargetVS; //  0x00000048
    private bool isRestart; //  0x00000050
    private bool isQuit; //  0x00000051
    public string clientVer; //  0x00000058
    private static ABCheckUpdate _instance; // static_offset: 0x00000000
    private uint curBytes; //  0x00000060
    private int downedNum; //  0x00000064
    private System.Collections.Generic.List<FileInfoRes> removeList; //  0x00000068
    private const int SAVE_NUM = 10;
    private System.Text.StringBuilder sb; //  0x00000070
    public string serverVer; //  0x00000078
    private uint totalBytes; //  0x00000080
    private System.Collections.Generic.List<FileInfoRes> updateList; //  0x00000088
    private System.Collections.Generic.List<FileInfoRes> csscriptList; //  0x00000090
    private int downFileNum; //  0x00000098
    private int downFileCount; //  0x0000009C
    public string DOWNLOAD_URL; //  0x000000A0
    public bool isloadServer; //  0x000000A8
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x2879D80
    private bool <isPkged>k__BackingField; //  0x000000A9
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x2879DBC
    private bool <isVerifyed>k__BackingField; //  0x000000AA
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x2879DF8
    private float <VerifyProgress>k__BackingField; //  0x000000AC
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x2879E34
    private bool <isStartDown>k__BackingField; //  0x000000B0
    private bool isRepairing; //  0x000000B1
    private int localAssetCount; //  0x000000B4
    private int errorAssetCount; //  0x000000B8
    private static System.Action <>f__am$cache0; // static_offset: 0x00000008
    private static AssetDownMgr.SetBytes <>f__am$cache1; // static_offset: 0x00000010
    private static AssetDownMgr.SetBytes <>f__am$cache2; // static_offset: 0x00000018
    private static System.Action <>f__am$cache3; // static_offset: 0x00000020
    private static System.Action <>f__am$cache4; // static_offset: 0x00000028
    private static System.Action <>f__am$cache5; // static_offset: 0x00000030
    
    // Properties
    public string GetUpdateTargetVS { get; }
    public static ABCheckUpdate Instance { get; }
    public string Version { get; }
    public bool IsDownSuccess { get; }
    public float WriteProgress { get; }
    public bool isPkged { get; set; }
    public float PkgProgress { get; }
    public bool isVerifyed { get; set; }
    public float VerifyProgress { get; set; }
    public bool isStartDown { get; set; }
    public float Progress { get; }
    public string ProgressMsg { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B14500 (11617536), len: 208  VirtAddr: 0x00B14500 RVA: 0x00B14500 token: 100694243 methodIndex: 24586 delegateWrapperIndex: 0 methodInvoker: 0
    public ABCheckUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00B14500: STP x20, x19, [sp, #-0x20]! | stack[1152921515138572160] = ???;  stack[1152921515138572168] = ???;  //  dest_result_addr=1152921515138572160 |  dest_result_addr=1152921515138572168
        // 0x00B14504: STP x29, x30, [sp, #0x10]  | stack[1152921515138572176] = ???;  stack[1152921515138572184] = ???;  //  dest_result_addr=1152921515138572176 |  dest_result_addr=1152921515138572184
        // 0x00B14508: ADD x29, sp, #0x10         | X29 = (1152921515138572160 + 16) = 1152921515138572176 (0x1000000273BD5F90);
        // 0x00B1450C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B14510: LDRB w8, [x20, #0x6cc]     | W8 = (bool)static_value_037336CC;       
        // 0x00B14514: MOV x19, x0                | X19 = 1152921515138584192 (0x1000000273BD8E80);//ML01
        // 0x00B14518: TBNZ w8, #0, #0xb14534     | if (static_value_037336CC == true) goto label_0;
        // 0x00B1451C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00B14520: LDR x8, [x8, #0x6a0]       | X8 = 0x2B8A60C;                         
        // 0x00B14524: LDR w0, [x8]               | W0 = 0x41;                              
        // 0x00B14528: BL #0x2782188              | X0 = sub_2782188( ?? 0x41, ????);       
        // 0x00B1452C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B14530: STRB w8, [x20, #0x6cc]     | static_value_037336CC = true;            //  dest_result_addr=57882316
        label_0:
        // 0x00B14534: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00B14538: LDR x8, [x8, #0x940]       | X8 = 1152921504911052800;               
        // 0x00B1453C: LDR x0, [x8]               | X0 = typeof(Filelist<T>);               
        Filelist<FileInfoCrc> val_1 = null;
        // 0x00B14540: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Filelist<T>), ????);
        // 0x00B14544: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B14548: LDR x8, [x8, #0xe08]       | X8 = 1152921514962417424;               
        // 0x00B1454C: MOV x20, x0                | X20 = 1152921504911052800 (0x100000001221D000);//ML01
        // 0x00B14550: LDR x1, [x8]               | X1 = public System.Void Filelist<FileInfoCrc>::.ctor();
        // 0x00B14554: BL #0x19ccf20              | .ctor();                                
        val_1 = new Filelist<FileInfoCrc>();
        // 0x00B14558: STR x20, [x19, #0x18]      | this.serverCrcList = typeof(Filelist<T>);  //  dest_result_addr=1152921515138584216
        this.serverCrcList = val_1;
        // 0x00B1455C: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x00B14560: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x00B14564: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_3 = null;
        // 0x00B14568: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1456C: TBZ w8, #0, #0xb14580      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B14570: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B14574: CBNZ w8, #0xb14580         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B14578: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B1457C: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_3 = null;
        label_2:
        // 0x00B14580: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B14584: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x00B14588: STR x8, [x19, #0x48]       | this.updateTargetVS = System.String.Empty;  //  dest_result_addr=1152921515138584264
        this.updateTargetVS = System.String.Empty;
        // 0x00B1458C: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00B14590: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
        // 0x00B14594: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
        System.Text.StringBuilder val_2 = null;
        // 0x00B14598: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
        // 0x00B1459C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B145A0: MOV x20, x0                | X20 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B145A4: BL #0x1b5a30c              | .ctor();                                
        val_2 = new System.Text.StringBuilder();
        // 0x00B145A8: STR x20, [x19, #0x70]      | this.sb = typeof(System.Text.StringBuilder);  //  dest_result_addr=1152921515138584304
        this.sb = val_2;
        // 0x00B145AC: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B145B0: LDR x8, [x8, #0x9e0]       | X8 = (string**)(1152921509743366224)("false");
        // 0x00B145B4: MOV x0, x19                | X0 = 1152921515138584192 (0x1000000273BD8E80);//ML01
        // 0x00B145B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B145BC: LDR x8, [x8]               | X8 = "false";                           
        // 0x00B145C0: STR x8, [x19, #0xa0]       | this.DOWNLOAD_URL = "false";             //  dest_result_addr=1152921515138584352
        this.DOWNLOAD_URL = "false";
        // 0x00B145C4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B145C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B145CC: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B145D0 (11617744), len: 8  VirtAddr: 0x00B145D0 RVA: 0x00B145D0 token: 100694244 methodIndex: 24587 delegateWrapperIndex: 0 methodInvoker: 0
    public string get_GetUpdateTargetVS()
    {
        //
        // Disasemble & Code
        // 0x00B145D0: LDR x0, [x0, #0x48]        | X0 = this.updateTargetVS; //P2          
        // 0x00B145D4: RET                        |  return (System.String)this.updateTargetVS;
        return this.updateTargetVS;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B145D8 (11617752), len: 128  VirtAddr: 0x00B145D8 RVA: 0x00B145D8 token: 100694245 methodIndex: 24588 delegateWrapperIndex: 0 methodInvoker: 0
    public static ABCheckUpdate get_Instance()
    {
        //
        // Disasemble & Code
        //  | 
        int val_2;
        // 0x00B145D8: STP x20, x19, [sp, #-0x20]! | stack[1152921515138809472] = ???;  stack[1152921515138809480] = ???;  //  dest_result_addr=1152921515138809472 |  dest_result_addr=1152921515138809480
        // 0x00B145DC: STP x29, x30, [sp, #0x10]  | stack[1152921515138809488] = ???;  stack[1152921515138809496] = ???;  //  dest_result_addr=1152921515138809488 |  dest_result_addr=1152921515138809496
        // 0x00B145E0: ADD x29, sp, #0x10         | X29 = (1152921515138809472 + 16) = 1152921515138809488 (0x1000000273C0FE90);
        // 0x00B145E4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B145E8: LDRB w8, [x19, #0x6cd]     | W8 = (bool)static_value_037336CD;       
        // 0x00B145EC: TBNZ w8, #0, #0xb14608     | if (static_value_037336CD == true) goto label_0;
        // 0x00B145F0: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x00B145F4: LDR x8, [x8, #0xb50]       | X8 = 0x2B8A6A8;                         
        // 0x00B145F8: LDR w0, [x8]               | W0 = 0x68;                              
        // 0x00B145FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x68, ????);       
        // 0x00B14600: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B14604: STRB w8, [x19, #0x6cd]     | static_value_037336CD = true;            //  dest_result_addr=57882317
        label_0:
        // 0x00B14608: ADRP x19, #0x365c000       | X19 = 56999936 (0x365C000);             
        // 0x00B1460C: LDR x19, [x19, #0xd68]     | X19 = 1152921504910680064;              
        // 0x00B14610: LDR x8, [x19]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B14614: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B14618: LDR x0, [x8]               | X0 = ABCheckUpdate.SAVE_NUM;            
        val_2 = ABCheckUpdate.SAVE_NUM;
        // 0x00B1461C: CBNZ x0, #0xb1464c         | if (ABCheckUpdate.SAVE_NUM != 0) goto label_1;
        if(val_2 != 0)
        {
            goto label_1;
        }
        // 0x00B14620: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00B14624: LDR x8, [x8, #0xd70]       | X8 = 1152921515138792384;               
        // 0x00B14628: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1462C: LDR x1, [x8]               | X1 = public static ABCheckUpdate System.Activator::CreateInstance<ABCheckUpdate>();
        // 0x00B14630: BL #0xfdef04               | X0 = System.Activator.CreateInstance<ILRuntime.Runtime.Intepreter.ILTypeInstance>();
        ILRuntime.Runtime.Intepreter.ILTypeInstance val_1 = System.Activator.CreateInstance<ILRuntime.Runtime.Intepreter.ILTypeInstance>();
        // 0x00B14634: LDR x8, [x19]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B14638: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1463C: STR x0, [x8]               | ABCheckUpdate.SAVE_NUM = val_1;          //  dest_result_addr=1152921504910684160
        ABCheckUpdate.SAVE_NUM = val_1;
        // 0x00B14640: LDR x8, [x19]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B14644: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B14648: LDR x0, [x8]               | X0 = val_1;                             
        val_2 = ABCheckUpdate.SAVE_NUM;
        label_1:
        // 0x00B1464C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B14650: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B14654: RET                        |  return (ABCheckUpdate)val_1;           
        return (ABCheckUpdate)val_2;
        //  |  // // {name=val_0, type=ABCheckUpdate, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14658 (11617880), len: 148  VirtAddr: 0x00B14658 RVA: 0x00B14658 token: 100694246 methodIndex: 24589 delegateWrapperIndex: 0 methodInvoker: 0
    public string get_Version()
    {
        //
        // Disasemble & Code
        // 0x00B14658: STP x22, x21, [sp, #-0x30]! | stack[1152921515138933744] = ???;  stack[1152921515138933752] = ???;  //  dest_result_addr=1152921515138933744 |  dest_result_addr=1152921515138933752
        // 0x00B1465C: STP x20, x19, [sp, #0x10]  | stack[1152921515138933760] = ???;  stack[1152921515138933768] = ???;  //  dest_result_addr=1152921515138933760 |  dest_result_addr=1152921515138933768
        // 0x00B14660: STP x29, x30, [sp, #0x20]  | stack[1152921515138933776] = ???;  stack[1152921515138933784] = ???;  //  dest_result_addr=1152921515138933776 |  dest_result_addr=1152921515138933784
        // 0x00B14664: ADD x29, sp, #0x20         | X29 = (1152921515138933744 + 32) = 1152921515138933776 (0x1000000273C2E410);
        // 0x00B14668: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1466C: LDRB w8, [x20, #0x6ce]     | W8 = (bool)static_value_037336CE;       
        // 0x00B14670: MOV x19, x0                | X19 = 1152921515138945792 (0x1000000273C31300);//ML01
        // 0x00B14674: TBNZ w8, #0, #0xb14690     | if (static_value_037336CE == true) goto label_0;
        // 0x00B14678: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00B1467C: LDR x8, [x8, #0xef8]       | X8 = 0x2B8A6AC;                         
        // 0x00B14680: LDR w0, [x8]               | W0 = 0x69;                              
        // 0x00B14684: BL #0x2782188              | X0 = sub_2782188( ?? 0x69, ????);       
        // 0x00B14688: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1468C: STRB w8, [x20, #0x6ce]     | static_value_037336CE = true;            //  dest_result_addr=57882318
        label_0:
        // 0x00B14690: LDR x20, [x19, #0x58]!     | X20 = this.clientVer; //P2              
        // 0x00B14694: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B14698: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1469C: MOV x22, x19               | X22 = 1152921515138945880 (0x1000000273C31358);//ML01
        // 0x00B146A0: LDR x21, [x22, #0x20]!     | X21 = this.serverVer; //P2               //  find_add[1152921515138945792]
        // 0x00B146A4: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B146A8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B146AC: TBZ w8, #0, #0xb146bc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B146B0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B146B4: CBNZ w8, #0xb146bc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B146B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_2:
        // 0x00B146BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B146C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B146C4: MOV x1, x20                | X1 = this.clientVer;//m1                
        // 0x00B146C8: MOV x2, x21                | X2 = this.serverVer;//m1                
        // 0x00B146CC: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  this.clientVer);
        bool val_1 = System.String.op_Equality(a:  0, b:  this.clientVer);
        // 0x00B146D0: TST w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x00B146D4: CSEL x8, x19, x22, ne      | X8 = val_1 != true ? 1152921515138945880 : 1152921515138945912;
        var val_2 = (val_1 != true) ? (this.clientVer) : (this.serverVer);
        // 0x00B146D8: LDR x0, [x8]               | X0 = val_1 != true ? 1152921515138945880 : 1152921515138945912;
        // 0x00B146DC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B146E0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B146E4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B146E8: RET                        |  return (System.String)val_1 != true ? 1152921515138945880 : 1152921515138945912;
        return (string)val_2;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B146EC (11618028), len: 652  VirtAddr: 0x00B146EC RVA: 0x00B146EC token: 100694247 methodIndex: 24590 delegateWrapperIndex: 0 methodInvoker: 0
    private void DelOverFile()
    {
        //
        // Disasemble & Code
        //  | 
        var val_10;
        // 0x00B146EC: STP x28, x27, [sp, #-0x60]! | stack[1152921515139120544] = ???;  stack[1152921515139120552] = ???;  //  dest_result_addr=1152921515139120544 |  dest_result_addr=1152921515139120552
        // 0x00B146F0: STP x26, x25, [sp, #0x10]  | stack[1152921515139120560] = ???;  stack[1152921515139120568] = ???;  //  dest_result_addr=1152921515139120560 |  dest_result_addr=1152921515139120568
        // 0x00B146F4: STP x24, x23, [sp, #0x20]  | stack[1152921515139120576] = ???;  stack[1152921515139120584] = ???;  //  dest_result_addr=1152921515139120576 |  dest_result_addr=1152921515139120584
        // 0x00B146F8: STP x22, x21, [sp, #0x30]  | stack[1152921515139120592] = ???;  stack[1152921515139120600] = ???;  //  dest_result_addr=1152921515139120592 |  dest_result_addr=1152921515139120600
        // 0x00B146FC: STP x20, x19, [sp, #0x40]  | stack[1152921515139120608] = ???;  stack[1152921515139120616] = ???;  //  dest_result_addr=1152921515139120608 |  dest_result_addr=1152921515139120616
        // 0x00B14700: STP x29, x30, [sp, #0x50]  | stack[1152921515139120624] = ???;  stack[1152921515139120632] = ???;  //  dest_result_addr=1152921515139120624 |  dest_result_addr=1152921515139120632
        // 0x00B14704: ADD x29, sp, #0x50         | X29 = (1152921515139120544 + 80) = 1152921515139120624 (0x1000000273C5BDF0);
        // 0x00B14708: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1470C: LDRB w8, [x20, #0x6cf]     | W8 = (bool)static_value_037336CF;       
        // 0x00B14710: MOV x19, x0                | X19 = 1152921515139132640 (0x1000000273C5ECE0);//ML01
        // 0x00B14714: TBNZ w8, #0, #0xb14730     | if (static_value_037336CF == true) goto label_0;
        // 0x00B14718: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
        // 0x00B1471C: LDR x8, [x8, #0x908]       | X8 = 0x2B8A6A0;                         
        // 0x00B14720: LDR w0, [x8]               | W0 = 0x66;                              
        // 0x00B14724: BL #0x2782188              | X0 = sub_2782188( ?? 0x66, ????);       
        // 0x00B14728: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1472C: STRB w8, [x20, #0x6cf]     | static_value_037336CF = true;            //  dest_result_addr=57882319
        label_0:
        // 0x00B14730: LDR x20, [x19, #0x68]      | X20 = this.removeList; //P2             
        // 0x00B14734: CBNZ x20, #0xb1473c        | if (this.removeList != null) goto label_1;
        if(this.removeList != null)
        {
            goto label_1;
        }
        // 0x00B14738: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x66, ????);       
        label_1:
        // 0x00B1473C: ADRP x23, #0x35c6000       | X23 = 56385536 (0x35C6000);             
        // 0x00B14740: LDR x23, [x23, #0x5d8]     | X23 = 1152921514959024432;              
        // 0x00B14744: MOV x0, x20                | X0 = this.removeList;//m1               
        // 0x00B14748: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B1474C: BL #0x25ed72c              | X0 = this.removeList.get_Count();       
        int val_1 = this.removeList.Count;
        // 0x00B14750: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x00B14754: B.LT #0xb1495c             | if (val_1 < 1) goto label_2;            
        if(val_1 < 1)
        {
            goto label_2;
        }
        // 0x00B14758: ADRP x24, #0x35cc000       | X24 = 56410112 (0x35CC000);             
        // 0x00B1475C: ADRP x25, #0x3651000       | X25 = 56954880 (0x3651000);             
        // 0x00B14760: ADRP x26, #0x35d6000       | X26 = 56451072 (0x35D6000);             
        // 0x00B14764: ADRP x27, #0x365f000       | X27 = 57012224 (0x365F000);             
        // 0x00B14768: ADRP x28, #0x3618000       | X28 = 56721408 (0x3618000);             
        // 0x00B1476C: LDR x24, [x24, #0x7d8]     | X24 = 1152921514959025456;              
        // 0x00B14770: LDR x25, [x25, #0x6d8]     | X25 = 1152921515139046080;              
        // 0x00B14774: LDR x26, [x26, #0xe38]     | X26 = 1152921504608284672;              
        // 0x00B14778: LDR x27, [x27, #0x278]     | X27 = (string**)(1152921515139047104)("版本更新,删除文件:{0}");
        // 0x00B1477C: LDR x28, [x28, #0x530]     | X28 = 1152921504924098560;              
        // 0x00B14780: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_10 = 0;
        // 0x00B14784: B #0xb1478c                |  goto label_3;                          
        goto label_3;
        label_19:
        // 0x00B14788: ADD w20, w20, #1           | W20 = (val_10 + 1) = val_10 (0x00000001);
        val_10 = 1;
        label_3:
        // 0x00B1478C: LDR x21, [x19, #0x68]      | X21 = this.removeList; //P2             
        // 0x00B14790: CBNZ x21, #0xb14798        | if (this.removeList != null) goto label_4;
        if(this.removeList != null)
        {
            goto label_4;
        }
        // 0x00B14794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B14798: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B1479C: MOV x0, x21                | X0 = this.removeList;//m1               
        // 0x00B147A0: BL #0x25ed72c              | X0 = this.removeList.get_Count();       
        int val_2 = this.removeList.Count;
        // 0x00B147A4: CMP w20, w0                | STATE = COMPARE(0x1, val_2)             
        // 0x00B147A8: B.GE #0xb14918             | if (val_10 >= val_2) goto label_5;      
        if(val_10 >= val_2)
        {
            goto label_5;
        }
        // 0x00B147AC: LDR x21, [x19, #0x20]      | X21 = this.clientList; //P2             
        // 0x00B147B0: LDR x22, [x19, #0x68]      | X22 = this.removeList; //P2             
        // 0x00B147B4: CBNZ x22, #0xb147bc        | if (this.removeList != null) goto label_6;
        if(this.removeList != null)
        {
            goto label_6;
        }
        // 0x00B147B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B147BC: LDR x2, [x24]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B147C0: MOV x0, x22                | X0 = this.removeList;//m1               
        // 0x00B147C4: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B147C8: BL #0x25ed734              | X0 = this.removeList.get_Item(index:  1);
        FileInfoRes val_3 = this.removeList.Item[1];
        // 0x00B147CC: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00B147D0: CBNZ x21, #0xb147d8        | if (this.clientList != null) goto label_7;
        if(this.clientList != null)
        {
            goto label_7;
        }
        // 0x00B147D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00B147D8: LDR x2, [x25]              | X2 = public System.Void Filelist<FileInfoRes>::RemoveResData(FileInfoRes data);
        // 0x00B147DC: MOV x0, x21                | X0 = this.clientList;//m1               
        // 0x00B147E0: MOV x1, x22                | X1 = val_3;//m1                         
        // 0x00B147E4: BL #0x19cd678              | this.clientList.RemoveResData(data:  val_3);
        this.clientList.RemoveResData(data:  val_3);
        // 0x00B147E8: LDR x21, [x19, #0x70]      | X21 = this.sb; //P2                     
        // 0x00B147EC: CBNZ x21, #0xb147f4        | if (this.sb != null) goto label_8;      
        if(this.sb != null)
        {
            goto label_8;
        }
        // 0x00B147F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.clientList, ????);
        label_8:
        // 0x00B147F4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B147F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B147FC: MOV x0, x21                | X0 = this.sb;//m1                       
        // 0x00B14800: BL #0x1b5ac0c              | this.sb.set_Length(value:  0);          
        this.sb.Length = 0;
        // 0x00B14804: LDR x21, [x19, #0x70]      | X21 = this.sb; //P2                     
        // 0x00B14808: BL #0xb14978               | X0 = this.sb.SavePath();                
        string val_4 = this.sb.SavePath();
        // 0x00B1480C: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B14810: CBNZ x21, #0xb14818        | if (this.sb != null) goto label_9;      
        if(this.sb != null)
        {
            goto label_9;
        }
        // 0x00B14814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00B14818: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1481C: MOV x0, x21                | X0 = this.sb;//m1                       
        // 0x00B14820: MOV x1, x22                | X1 = val_4;//m1                         
        // 0x00B14824: BL #0x1b5b818              | X0 = this.sb.Append(value:  val_4);     
        System.Text.StringBuilder val_5 = this.sb.Append(value:  val_4);
        // 0x00B14828: LDR x22, [x19, #0x68]      | X22 = this.removeList; //P2             
        // 0x00B1482C: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B14830: CBNZ x22, #0xb14838        | if (this.removeList != null) goto label_10;
        if(this.removeList != null)
        {
            goto label_10;
        }
        // 0x00B14834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00B14838: LDR x2, [x24]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B1483C: MOV x0, x22                | X0 = this.removeList;//m1               
        // 0x00B14840: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B14844: BL #0x25ed734              | X0 = this.removeList.get_Item(index:  1);
        FileInfoRes val_6 = this.removeList.Item[1];
        // 0x00B14848: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00B1484C: CBNZ x22, #0xb14854        | if (val_6 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x00B14850: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00B14854: LDR x22, [x22, #0x10]      | 
        // 0x00B14858: CBNZ x21, #0xb14860        | if (val_5 != null) goto label_12;       
        if(val_5 != null)
        {
            goto label_12;
        }
        // 0x00B1485C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_12:
        // 0x00B14860: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14864: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B14868: MOV x1, x22                | X1 = val_6;//m1                         
        // 0x00B1486C: BL #0x1b5b818              | X0 = val_5.Append(value:  val_6);       
        System.Text.StringBuilder val_7 = val_5.Append(value:  val_6);
        // 0x00B14870: LDR x21, [x19, #0x70]      | X21 = this.sb; //P2                     
        // 0x00B14874: CBNZ x21, #0xb1487c        | if (this.sb != null) goto label_13;     
        if(this.sb != null)
        {
            goto label_13;
        }
        // 0x00B14878: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_13:
        // 0x00B1487C: LDR x8, [x21]              | X8 = typeof(System.Text.StringBuilder); 
        // 0x00B14880: MOV x0, x21                | X0 = this.sb;//m1                       
        // 0x00B14884: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
        // 0x00B14888: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
        // 0x00B1488C: MOV x21, x0                | X21 = this.sb;//m1                      
        // 0x00B14890: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B14894: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14898: MOV x1, x21                | X1 = this.sb;//m1                       
        // 0x00B1489C: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_8 = System.IO.File.Exists(path:  0);
        // 0x00B148A0: TBZ w0, #0, #0xb14788      | if (val_8 == false) goto label_19;      
        if(val_8 == false)
        {
            goto label_19;
        }
        // 0x00B148A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B148A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B148AC: MOV x1, x21                | X1 = this.sb;//m1                       
        // 0x00B148B0: BL #0x1e6a550              | System.IO.File.Delete(path:  0);        
        System.IO.File.Delete(path:  0);
        // 0x00B148B4: LDR x0, [x26]              | X0 = typeof(System.String);             
        // 0x00B148B8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B148BC: TBZ w8, #0, #0xb148cc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x00B148C0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B148C4: CBNZ w8, #0xb148cc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x00B148C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_16:
        // 0x00B148CC: LDR x1, [x27]              | X1 = "版本更新,删除文件:{0}";                   
        // 0x00B148D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B148D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B148D8: MOV x2, x21                | X2 = this.sb;//m1                       
        // 0x00B148DC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "版本更新,删除文件:{0}");
        string val_9 = System.String.Format(format:  0, arg0:  "版本更新,删除文件:{0}");
        // 0x00B148E0: LDR x8, [x28]              | X8 = typeof(EDebug);                    
        // 0x00B148E4: MOV x21, x0                | X21 = val_9;//m1                        
        // 0x00B148E8: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B148EC: TBZ w9, #0, #0xb14900      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00B148F0: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B148F4: CBNZ w9, #0xb14900         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00B148F8: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B148FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_18:
        // 0x00B14900: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B14904: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B14908: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1490C: MOV x1, x21                | X1 = val_9;//m1                         
        // 0x00B14910: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_9);
        EDebug.Log(message:  0, isShowStack:  val_9);
        // 0x00B14914: B #0xb14788                |  goto label_19;                         
        goto label_19;
        label_5:
        // 0x00B14918: LDR x20, [x19, #0x68]      | X20 = this.removeList; //P2             
        // 0x00B1491C: CBNZ x20, #0xb14924        | if (this.removeList != null) goto label_20;
        if(this.removeList != null)
        {
            goto label_20;
        }
        // 0x00B14920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_20:
        // 0x00B14924: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
        // 0x00B14928: LDR x8, [x8, #0x658]       | X8 = 1152921514963727968;               
        // 0x00B1492C: MOV x0, x20                | X0 = this.removeList;//m1               
        // 0x00B14930: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<FileInfoRes>::Clear();
        // 0x00B14934: BL #0x25ead28              | this.removeList.Clear();                
        this.removeList.Clear();
        // 0x00B14938: LDR x1, [x19, #0x20]       | X1 = this.clientList; //P2              
        // 0x00B1493C: MOV x0, x19                | X0 = 1152921515139132640 (0x1000000273C5ECE0);//ML01
        // 0x00B14940: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B14944: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B14948: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1494C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B14950: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B14954: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B14958: B #0xb149e0                | this.WriteClientVS(fileList:  this.clientList); return;
        this.WriteClientVS(fileList:  this.clientList);
        return;
        label_2:
        // 0x00B1495C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B14960: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B14964: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B14968: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1496C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B14970: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B14974: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14A58 (11618904), len: 496  VirtAddr: 0x00B14A58 RVA: 0x00B14A58 token: 100694248 methodIndex: 24591 delegateWrapperIndex: 0 methodInvoker: 0
    private void DelSubFile(System.Collections.Generic.List<string> delList)
    {
        //
        // Disasemble & Code
        //  | 
        var val_9;
        // 0x00B14A58: STP x28, x27, [sp, #-0x60]! | stack[1152921515139335056] = ???;  stack[1152921515139335064] = ???;  //  dest_result_addr=1152921515139335056 |  dest_result_addr=1152921515139335064
        // 0x00B14A5C: STP x26, x25, [sp, #0x10]  | stack[1152921515139335072] = ???;  stack[1152921515139335080] = ???;  //  dest_result_addr=1152921515139335072 |  dest_result_addr=1152921515139335080
        // 0x00B14A60: STP x24, x23, [sp, #0x20]  | stack[1152921515139335088] = ???;  stack[1152921515139335096] = ???;  //  dest_result_addr=1152921515139335088 |  dest_result_addr=1152921515139335096
        // 0x00B14A64: STP x22, x21, [sp, #0x30]  | stack[1152921515139335104] = ???;  stack[1152921515139335112] = ???;  //  dest_result_addr=1152921515139335104 |  dest_result_addr=1152921515139335112
        // 0x00B14A68: STP x20, x19, [sp, #0x40]  | stack[1152921515139335120] = ???;  stack[1152921515139335128] = ???;  //  dest_result_addr=1152921515139335120 |  dest_result_addr=1152921515139335128
        // 0x00B14A6C: STP x29, x30, [sp, #0x50]  | stack[1152921515139335136] = ???;  stack[1152921515139335144] = ???;  //  dest_result_addr=1152921515139335136 |  dest_result_addr=1152921515139335144
        // 0x00B14A70: ADD x29, sp, #0x50         | X29 = (1152921515139335056 + 80) = 1152921515139335136 (0x1000000273C903E0);
        // 0x00B14A74: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B14A78: LDRB w8, [x21, #0x6d0]     | W8 = (bool)static_value_037336D0;       
        // 0x00B14A7C: MOV x19, x1                | X19 = delList;//m1                      
        // 0x00B14A80: MOV x20, x0                | X20 = 1152921515139347152 (0x1000000273C932D0);//ML01
        // 0x00B14A84: TBNZ w8, #0, #0xb14aa0     | if (static_value_037336D0 == true) goto label_0;
        // 0x00B14A88: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x00B14A8C: LDR x8, [x8, #0x178]       | X8 = 0x2B8A6A4;                         
        // 0x00B14A90: LDR w0, [x8]               | W0 = 0x67;                              
        // 0x00B14A94: BL #0x2782188              | X0 = sub_2782188( ?? 0x67, ????);       
        // 0x00B14A98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B14A9C: STRB w8, [x21, #0x6d0]     | static_value_037336D0 = true;            //  dest_result_addr=57882320
        label_0:
        // 0x00B14AA0: CBNZ x19, #0xb14aa8        | if (delList != null) goto label_1;      
        if(delList != null)
        {
            goto label_1;
        }
        // 0x00B14AA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x67, ????);       
        label_1:
        // 0x00B14AA8: ADRP x24, #0x35fc000       | X24 = 56606720 (0x35FC000);             
        // 0x00B14AAC: LDR x24, [x24, #0xb58]     | X24 = 1152921510022759280;              
        // 0x00B14AB0: MOV x0, x19                | X0 = delList;//m1                       
        // 0x00B14AB4: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B14AB8: BL #0x25ed72c              | X0 = delList.get_Count();               
        int val_1 = delList.Count;
        // 0x00B14ABC: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x00B14AC0: B.LT #0xb14c2c             | if (val_1 < 1) goto label_5;            
        if(val_1 < 1)
        {
            goto label_5;
        }
        // 0x00B14AC4: ADRP x25, #0x35bd000       | X25 = 56348672 (0x35BD000);             
        // 0x00B14AC8: ADRP x26, #0x35d6000       | X26 = 56451072 (0x35D6000);             
        // 0x00B14ACC: ADRP x27, #0x35dd000       | X27 = 56479744 (0x35DD000);             
        // 0x00B14AD0: ADRP x28, #0x3618000       | X28 = 56721408 (0x3618000);             
        // 0x00B14AD4: LDR x25, [x25, #0xb50]     | X25 = 1152921510890998992;              
        // 0x00B14AD8: LDR x26, [x26, #0xe38]     | X26 = 1152921504608284672;              
        // 0x00B14ADC: LDR x27, [x27, #0xd98]     | X27 = (string**)(1152921515139290272)("版本更新,删除分包文件:{0}");
        // 0x00B14AE0: LDR x28, [x28, #0x530]     | X28 = 1152921504924098560;              
        // 0x00B14AE4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_9 = 0;
        // 0x00B14AE8: B #0xb14af0                |  goto label_3;                          
        goto label_3;
        label_16:
        // 0x00B14AEC: ADD w21, w21, #1           | W21 = (val_9 + 1) = val_9 (0x00000001); 
        val_9 = 1;
        label_3:
        // 0x00B14AF0: CBNZ x19, #0xb14af8        | if (delList != null) goto label_4;      
        if(delList != null)
        {
            goto label_4;
        }
        // 0x00B14AF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B14AF8: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B14AFC: MOV x0, x19                | X0 = delList;//m1                       
        // 0x00B14B00: BL #0x25ed72c              | X0 = delList.get_Count();               
        int val_2 = delList.Count;
        // 0x00B14B04: CMP w21, w0                | STATE = COMPARE(0x1, val_2)             
        // 0x00B14B08: B.GE #0xb14c2c             | if (val_9 >= val_2) goto label_5;       
        if(val_9 >= val_2)
        {
            goto label_5;
        }
        // 0x00B14B0C: LDR x22, [x20, #0x70]      | X22 = this.sb; //P2                     
        // 0x00B14B10: CBNZ x22, #0xb14b18        | if (this.sb != null) goto label_6;      
        if(this.sb != null)
        {
            goto label_6;
        }
        // 0x00B14B14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B14B18: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B14B1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14B20: MOV x0, x22                | X0 = this.sb;//m1                       
        // 0x00B14B24: BL #0x1b5ac0c              | this.sb.set_Length(value:  0);          
        this.sb.Length = 0;
        // 0x00B14B28: LDR x22, [x20, #0x70]      | X22 = this.sb; //P2                     
        // 0x00B14B2C: BL #0xb14978               | X0 = this.sb.SavePath();                
        string val_3 = this.sb.SavePath();
        // 0x00B14B30: MOV x23, x0                | X23 = val_3;//m1                        
        // 0x00B14B34: CBNZ x22, #0xb14b3c        | if (this.sb != null) goto label_7;      
        if(this.sb != null)
        {
            goto label_7;
        }
        // 0x00B14B38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00B14B3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14B40: MOV x0, x22                | X0 = this.sb;//m1                       
        // 0x00B14B44: MOV x1, x23                | X1 = val_3;//m1                         
        // 0x00B14B48: BL #0x1b5b818              | X0 = this.sb.Append(value:  val_3);     
        System.Text.StringBuilder val_4 = this.sb.Append(value:  val_3);
        // 0x00B14B4C: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B14B50: CBNZ x19, #0xb14b58        | if (delList != null) goto label_8;      
        if(delList != null)
        {
            goto label_8;
        }
        // 0x00B14B54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x00B14B58: LDR x2, [x25]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B14B5C: MOV x0, x19                | X0 = delList;//m1                       
        // 0x00B14B60: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B14B64: BL #0x25ed734              | X0 = delList.get_Item(index:  1);       
        string val_5 = delList.Item[1];
        // 0x00B14B68: MOV x23, x0                | X23 = val_5;//m1                        
        // 0x00B14B6C: CBNZ x22, #0xb14b74        | if (val_4 != null) goto label_9;        
        if(val_4 != null)
        {
            goto label_9;
        }
        // 0x00B14B70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00B14B74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14B78: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B14B7C: MOV x1, x23                | X1 = val_5;//m1                         
        // 0x00B14B80: BL #0x1b5b818              | X0 = val_4.Append(value:  val_5);       
        System.Text.StringBuilder val_6 = val_4.Append(value:  val_5);
        // 0x00B14B84: LDR x22, [x20, #0x70]      | X22 = this.sb; //P2                     
        // 0x00B14B88: CBNZ x22, #0xb14b90        | if (this.sb != null) goto label_10;     
        if(this.sb != null)
        {
            goto label_10;
        }
        // 0x00B14B8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_10:
        // 0x00B14B90: LDR x8, [x22]              | X8 = typeof(System.Text.StringBuilder); 
        // 0x00B14B94: MOV x0, x22                | X0 = this.sb;//m1                       
        // 0x00B14B98: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
        // 0x00B14B9C: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
        // 0x00B14BA0: MOV x22, x0                | X22 = this.sb;//m1                      
        // 0x00B14BA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B14BA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14BAC: MOV x1, x22                | X1 = this.sb;//m1                       
        // 0x00B14BB0: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_7 = System.IO.File.Exists(path:  0);
        // 0x00B14BB4: TBZ w0, #0, #0xb14aec      | if (val_7 == false) goto label_16;      
        if(val_7 == false)
        {
            goto label_16;
        }
        // 0x00B14BB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B14BBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14BC0: MOV x1, x22                | X1 = this.sb;//m1                       
        // 0x00B14BC4: BL #0x1e6a550              | System.IO.File.Delete(path:  0);        
        System.IO.File.Delete(path:  0);
        // 0x00B14BC8: LDR x0, [x26]              | X0 = typeof(System.String);             
        // 0x00B14BCC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B14BD0: TBZ w8, #0, #0xb14be0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B14BD4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B14BD8: CBNZ w8, #0xb14be0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B14BDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_13:
        // 0x00B14BE0: LDR x1, [x27]              | X1 = "版本更新,删除分包文件:{0}";                 
        // 0x00B14BE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B14BE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B14BEC: MOV x2, x22                | X2 = this.sb;//m1                       
        // 0x00B14BF0: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "版本更新,删除分包文件:{0}");
        string val_8 = System.String.Format(format:  0, arg0:  "版本更新,删除分包文件:{0}");
        // 0x00B14BF4: LDR x8, [x28]              | X8 = typeof(EDebug);                    
        // 0x00B14BF8: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00B14BFC: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B14C00: TBZ w9, #0, #0xb14c14      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00B14C04: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B14C08: CBNZ w9, #0xb14c14         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00B14C0C: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B14C10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_15:
        // 0x00B14C14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B14C18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B14C1C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B14C20: MOV x1, x22                | X1 = val_8;//m1                         
        // 0x00B14C24: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_8);
        EDebug.Log(message:  0, isShowStack:  val_8);
        // 0x00B14C28: B #0xb14aec                |  goto label_16;                         
        goto label_16;
        label_5:
        // 0x00B14C2C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B14C30: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B14C34: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B14C38: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B14C3C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B14C40: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B14C44: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14C48 (11619400), len: 308  VirtAddr: 0x00B14C48 RVA: 0x00B14C48 token: 100694249 methodIndex: 24592 delegateWrapperIndex: 0 methodInvoker: 0
    public void UpdateVersion(VersionInfo vsInfo)
    {
        //
        // Disasemble & Code
        // 0x00B14C48: STP x22, x21, [sp, #-0x30]! | stack[1152921515139492368] = ???;  stack[1152921515139492376] = ???;  //  dest_result_addr=1152921515139492368 |  dest_result_addr=1152921515139492376
        // 0x00B14C4C: STP x20, x19, [sp, #0x10]  | stack[1152921515139492384] = ???;  stack[1152921515139492392] = ???;  //  dest_result_addr=1152921515139492384 |  dest_result_addr=1152921515139492392
        // 0x00B14C50: STP x29, x30, [sp, #0x20]  | stack[1152921515139492400] = ???;  stack[1152921515139492408] = ???;  //  dest_result_addr=1152921515139492400 |  dest_result_addr=1152921515139492408
        // 0x00B14C54: ADD x29, sp, #0x20         | X29 = (1152921515139492368 + 32) = 1152921515139492400 (0x1000000273CB6A30);
        // 0x00B14C58: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B14C5C: LDRB w8, [x21, #0x6d1]     | W8 = (bool)static_value_037336D1;       
        // 0x00B14C60: MOV x20, x1                | X20 = vsInfo;//m1                       
        // 0x00B14C64: MOV x19, x0                | X19 = 1152921515139504416 (0x1000000273CB9920);//ML01
        // 0x00B14C68: TBNZ w8, #0, #0xb14c84     | if (static_value_037336D1 == true) goto label_0;
        // 0x00B14C6C: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
        // 0x00B14C70: LDR x8, [x8, #0x510]       | X8 = 0x2B8A72C;                         
        // 0x00B14C74: LDR w0, [x8]               | W0 = 0x89;                              
        // 0x00B14C78: BL #0x2782188              | X0 = sub_2782188( ?? 0x89, ????);       
        // 0x00B14C7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B14C80: STRB w8, [x21, #0x6d1]     | static_value_037336D1 = true;            //  dest_result_addr=57882321
        label_0:
        // 0x00B14C84: CBNZ x20, #0xb14c8c        | if (vsInfo != null) goto label_1;       
        if(vsInfo != null)
        {
            goto label_1;
        }
        // 0x00B14C88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x89, ????);       
        label_1:
        // 0x00B14C8C: LDR x8, [x20, #0x10]       | X8 = vsInfo.name; //P2                  
        // 0x00B14C90: ADRP x10, #0x35bf000       | X10 = 56356864 (0x35BF000);             
        // 0x00B14C94: LDR x10, [x10, #0x9c0]     | X10 = 1152921504900136960;              
        // 0x00B14C98: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00B14C9C: STR x8, [x19, #0x48]       | this.updateTargetVS = vsInfo.name;       //  dest_result_addr=1152921515139504488
        this.updateTargetVS = vsInfo.name;
        // 0x00B14CA0: STRB w9, [x19, #0x50]      | this.isRestart = true;                   //  dest_result_addr=1152921515139504496
        this.isRestart = true;
        // 0x00B14CA4: LDR x0, [x10]              | X0 = typeof(FlowControl.FlowContainerLine);
        FlowControl.FlowContainerLine val_1 = null;
        // 0x00B14CA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(FlowControl.FlowContainerLine), ????);
        // 0x00B14CAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B14CB0: MOV x19, x0                | X19 = 1152921504900136960 (0x10000000117B4000);//ML01
        // 0x00B14CB4: BL #0xc08478               | .ctor();                                
        val_1 = new FlowControl.FlowContainerLine();
        // 0x00B14CB8: CBNZ x19, #0xb14cc0        | if ( != 0) goto label_2;                
        if(null != 0)
        {
            goto label_2;
        }
        // 0x00B14CBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00B14CC0: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
        // 0x00B14CC4: LDR x8, [x8, #0x9f8]       | X8 = (string**)(1152921515139480208)("Version Update Bus");
        // 0x00B14CC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14CCC: MOV x0, x19                | X0 = 1152921504900136960 (0x10000000117B4000);//ML01
        // 0x00B14CD0: LDR x1, [x8]               | X1 = "Version Update Bus";              
        // 0x00B14CD4: BL #0xc0766c               | set_name(value:  "Version Update Bus"); 
        name = "Version Update Bus";
        // 0x00B14CD8: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
        // 0x00B14CDC: LDR x8, [x8, #0x360]       | X8 = 1152921504900509696;               
        // 0x00B14CE0: LDR x0, [x8]               | X0 = typeof(FlowControl.FlowCheckUpdate);
        FlowControl.FlowCheckUpdate val_2 = null;
        // 0x00B14CE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(FlowControl.FlowCheckUpdate), ????);
        // 0x00B14CE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B14CEC: MOV x20, x0                | X20 = 1152921504900509696 (0x100000001180F000);//ML01
        // 0x00B14CF0: BL #0xc07674               | .ctor();                                
        val_2 = new FlowControl.FlowCheckUpdate();
        // 0x00B14CF4: CBNZ x20, #0xb14cfc        | if ( != 0) goto label_3;                
        if(null != 0)
        {
            goto label_3;
        }
        // 0x00B14CF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_3:
        // 0x00B14CFC: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B14D00: LDR x8, [x8, #0x70]        | X8 = (string**)(1152921515139480320)("Detect Update");
        // 0x00B14D04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14D08: MOV x0, x20                | X0 = 1152921504900509696 (0x100000001180F000);//ML01
        // 0x00B14D0C: LDR x1, [x8]               | X1 = "Detect Update";                   
        // 0x00B14D10: BL #0xc0766c               | set_name(value:  "Detect Update");      
        name = "Detect Update";
        // 0x00B14D14: CBNZ x19, #0xb14d1c        | if ( != 0) goto label_4;                
        if(null != 0)
        {
            goto label_4;
        }
        // 0x00B14D18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(FlowControl.FlowCheckUpdate), ????);
        label_4:
        // 0x00B14D1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14D20: MOV x0, x19                | X0 = 1152921504900136960 (0x10000000117B4000);//ML01
        // 0x00B14D24: MOV x1, x20                | X1 = 1152921504900509696 (0x100000001180F000);//ML01
        // 0x00B14D28: BL #0xc08090               | AddFlow(flow:  val_2);                  
        AddFlow(flow:  val_2);
        // 0x00B14D2C: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x00B14D30: LDR x8, [x8, #0xf38]       | X8 = 1152921504922128384;               
        // 0x00B14D34: LDR x0, [x8]               | X0 = typeof(AllUpdate);                 
        // 0x00B14D38: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
        // 0x00B14D3C: TBZ w8, #0, #0xb14d4c      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B14D40: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B14D44: CBNZ w8, #0xb14d4c         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B14D48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
        label_6:
        // 0x00B14D4C: MOV x1, x19                | X1 = 1152921504900136960 (0x10000000117B4000);//ML01
        // 0x00B14D50: BL #0xb14d7c               | AllUpdate.AddUpdate(update:  null);     
        AllUpdate.AddUpdate(update:  null);
        // 0x00B14D54: CBNZ x19, #0xb14d5c        | if ( != 0) goto label_7;                
        if(null != 0)
        {
            goto label_7;
        }
        // 0x00B14D58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AllUpdate), ????);
        label_7:
        // 0x00B14D5C: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B14D60: MOV x0, x19                | X0 = 1152921504900136960 (0x10000000117B4000);//ML01
        // 0x00B14D64: LDR x2, [x8, #0x240]       |  //  not_find_field!1:576
        // 0x00B14D68: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
        // 0x00B14D6C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B14D70: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B14D74: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B14D78: BR x2                      | goto mem[null + 576];                   
        goto mem[null + 576];
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14DFC (11619836), len: 344  VirtAddr: 0x00B14DFC RVA: 0x00B14DFC token: 100694250 methodIndex: 24593 delegateWrapperIndex: 0 methodInvoker: 0
    public void Start()
    {
        //
        // Disasemble & Code
        // 0x00B14DFC: STP x24, x23, [sp, #-0x40]! | stack[1152921515139622784] = ???;  stack[1152921515139622792] = ???;  //  dest_result_addr=1152921515139622784 |  dest_result_addr=1152921515139622792
        // 0x00B14E00: STP x22, x21, [sp, #0x10]  | stack[1152921515139622800] = ???;  stack[1152921515139622808] = ???;  //  dest_result_addr=1152921515139622800 |  dest_result_addr=1152921515139622808
        // 0x00B14E04: STP x20, x19, [sp, #0x20]  | stack[1152921515139622816] = ???;  stack[1152921515139622824] = ???;  //  dest_result_addr=1152921515139622816 |  dest_result_addr=1152921515139622824
        // 0x00B14E08: STP x29, x30, [sp, #0x30]  | stack[1152921515139622832] = ???;  stack[1152921515139622840] = ???;  //  dest_result_addr=1152921515139622832 |  dest_result_addr=1152921515139622840
        // 0x00B14E0C: ADD x29, sp, #0x30         | X29 = (1152921515139622784 + 48) = 1152921515139622832 (0x1000000273CD67B0);
        // 0x00B14E10: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B14E14: LDRB w8, [x20, #0x6d2]     | W8 = (bool)static_value_037336D2;       
        // 0x00B14E18: MOV x19, x0                | X19 = 1152921515139634848 (0x1000000273CD96A0);//ML01
        // 0x00B14E1C: TBNZ w8, #0, #0xb14e38     | if (static_value_037336D2 == true) goto label_0;
        // 0x00B14E20: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x00B14E24: LDR x8, [x8, #0x1d8]       | X8 = 0x2B8A6F4;                         
        // 0x00B14E28: LDR w0, [x8]               | W0 = 0x7B;                              
        // 0x00B14E2C: BL #0x2782188              | X0 = sub_2782188( ?? 0x7B, ????);       
        // 0x00B14E30: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B14E34: STRB w8, [x20, #0x6d2]     | static_value_037336D2 = true;            //  dest_result_addr=57882322
        label_0:
        // 0x00B14E38: STRB wzr, [x19, #0xaa]     | this.<isVerifyed>k__BackingField = false;  //  dest_result_addr=1152921515139635018
        this.<isVerifyed>k__BackingField = false;
        // 0x00B14E3C: STRB wzr, [x19, #0xb0]     | this.<isStartDown>k__BackingField = false;  //  dest_result_addr=1152921515139635024
        this.<isStartDown>k__BackingField = false;
        // 0x00B14E40: STRB wzr, [x19, #0xa9]     | this.<isPkged>k__BackingField = false;   //  dest_result_addr=1152921515139635017
        this.<isPkged>k__BackingField = false;
        // 0x00B14E44: STR wzr, [x19, #0xac]      | this.<VerifyProgress>k__BackingField = 0;  //  dest_result_addr=1152921515139635020
        this.<VerifyProgress>k__BackingField = 0f;
        // 0x00B14E48: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_1 = AssetDownMgr.Instance;
        // 0x00B14E4C: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B14E50: CBNZ x20, #0xb14e58        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00B14E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B14E58: STR wzr, [x20, #0x50]      | val_1.totalBytes = null;                 //  dest_result_addr=0
        val_1.totalBytes = 0;
        // 0x00B14E5C: STRB wzr, [x20, #0x4c]     | val_1.isStart = false;                   //  dest_result_addr=0
        val_1.isStart = false;
        // 0x00B14E60: STP wzr, wzr, [x20, #0x58] | val_1.totalFileCount = 0;  val_1.curFileCount = 0;  //  dest_result_addr=0 |  dest_result_addr=0
        val_1.totalFileCount = 0;
        val_1.curFileCount = 0;
        // 0x00B14E64: STRB wzr, [x20, #0x88]     | val_1.IsDownSuccess = false;             //  dest_result_addr=0
        val_1.IsDownSuccess = false;
        // 0x00B14E68: STRB wzr, [x20, #0x60]     | val_1.IsWriteFinish = false;             //  dest_result_addr=0
        val_1.IsWriteFinish = false;
        // 0x00B14E6C: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_2 = AssetDownMgr.Instance;
        // 0x00B14E70: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B14E74: CBNZ x20, #0xb14e7c        | if (val_2 != null) goto label_2;        
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00B14E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00B14E7C: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B14E80: BL #0xb15014               | val_2.StartDown();                      
        val_2.StartDown();
        // 0x00B14E84: MOV x0, x19                | X0 = 1152921515139634848 (0x1000000273CD96A0);//ML01
        // 0x00B14E88: BL #0xb15084               | this.LoadClientVer();                   
        this.LoadClientVer();
        // 0x00B14E8C: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B14E90: ADRP x22, #0x3658000       | X22 = 56983552 (0x3658000);             
        // 0x00B14E94: LDR x8, [x8, #0x7e0]       | X8 = 1152921515139608800;               
        // 0x00B14E98: LDR x22, [x22, #0x980]     | X22 = 1152921504898113536;              
        // 0x00B14E9C: LDR x21, [x8]              | X21 = public System.Void ABCheckUpdate::RepairAsset(CEvent.ZEvent e);
        // 0x00B14EA0: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_3 = null;
        // 0x00B14EA4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B14EA8: ADRP x23, #0x367a000       | X23 = 57122816 (0x367A000);             
        // 0x00B14EAC: LDR x23, [x23, #0xc38]     | X23 = 1152921512949758048;              
        // 0x00B14EB0: MOV x1, x19                | X1 = 1152921515139634848 (0x1000000273CD96A0);//ML01
        // 0x00B14EB4: MOV x2, x21                | X2 = 1152921515139608800 (0x1000000273CD30E0);//ML01
        // 0x00B14EB8: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B14EBC: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B14EC0: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void ABCheckUpdate::RepairAsset(CEvent.ZEvent e));
        val_3 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void ABCheckUpdate::RepairAsset(CEvent.ZEvent e));
        // 0x00B14EC4: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B14EC8: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B14ECC: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B14ED0: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B14ED4: TBZ w8, #0, #0xb14ee4      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B14ED8: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B14EDC: CBNZ w8, #0xb14ee4         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B14EE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_4:
        // 0x00B14EE4: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00B14EE8: LDR x8, [x8, #0x9b0]       | X8 = (string**)(1152921510024639776)("REPAIR_ASSET");
        // 0x00B14EEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B14EF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B14EF4: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B14EF8: LDR x1, [x8]               | X1 = "REPAIR_ASSET";                    
        // 0x00B14EFC: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "REPAIR_ASSET");
        CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "REPAIR_ASSET");
        // 0x00B14F00: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x00B14F04: LDR x8, [x8, #0x8d8]       | X8 = 1152921515139609824;               
        // 0x00B14F08: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_4 = null;
        // 0x00B14F0C: LDR x20, [x8]              | X20 = public System.Void ABCheckUpdate::IsOpenRepairAsset(CEvent.ZEvent e);
        // 0x00B14F10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B14F14: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B14F18: MOV x1, x19                | X1 = 1152921515139634848 (0x1000000273CD96A0);//ML01
        // 0x00B14F1C: MOV x2, x20                | X2 = 1152921515139609824 (0x1000000273CD34E0);//ML01
        // 0x00B14F20: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B14F24: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void ABCheckUpdate::IsOpenRepairAsset(CEvent.ZEvent e));
        val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void ABCheckUpdate::IsOpenRepairAsset(CEvent.ZEvent e));
        // 0x00B14F28: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00B14F2C: LDR x8, [x8, #0x28]        | X8 = (string**)(1152921510024640896)("IF_OPEN_REPAIR_ASSET");
        // 0x00B14F30: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B14F34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B14F38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B14F3C: LDR x1, [x8]               | X1 = "IF_OPEN_REPAIR_ASSET";            
        // 0x00B14F40: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B14F44: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B14F48: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B14F4C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B14F50: B #0xd775dc                | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "IF_OPEN_REPAIR_ASSET"); return;
        CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "IF_OPEN_REPAIR_ASSET");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15190 (11620752), len: 196  VirtAddr: 0x00B15190 RVA: 0x00B15190 token: 100694251 methodIndex: 24594 delegateWrapperIndex: 0 methodInvoker: 0
    private void LoadAllVSCfg()
    {
        //
        // Disasemble & Code
        // 0x00B15190: STP x22, x21, [sp, #-0x30]! | stack[1152921515139748112] = ???;  stack[1152921515139748120] = ???;  //  dest_result_addr=1152921515139748112 |  dest_result_addr=1152921515139748120
        // 0x00B15194: STP x20, x19, [sp, #0x10]  | stack[1152921515139748128] = ???;  stack[1152921515139748136] = ???;  //  dest_result_addr=1152921515139748128 |  dest_result_addr=1152921515139748136
        // 0x00B15198: STP x29, x30, [sp, #0x20]  | stack[1152921515139748144] = ???;  stack[1152921515139748152] = ???;  //  dest_result_addr=1152921515139748144 |  dest_result_addr=1152921515139748152
        // 0x00B1519C: ADD x29, sp, #0x20         | X29 = (1152921515139748112 + 32) = 1152921515139748144 (0x1000000273CF5130);
        // 0x00B151A0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B151A4: LDRB w8, [x20, #0x6d3]     | W8 = (bool)static_value_037336D3;       
        // 0x00B151A8: MOV x19, x0                | X19 = 1152921515139760160 (0x1000000273CF8020);//ML01
        // 0x00B151AC: TBNZ w8, #0, #0xb151c8     | if (static_value_037336D3 == true) goto label_0;
        // 0x00B151B0: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
        // 0x00B151B4: LDR x8, [x8, #0x4a8]       | X8 = 0x2B8A6C4;                         
        // 0x00B151B8: LDR w0, [x8]               | W0 = 0x6F;                              
        // 0x00B151BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x6F, ????);       
        // 0x00B151C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B151C4: STRB w8, [x20, #0x6d3]     | static_value_037336D3 = true;            //  dest_result_addr=57882323
        label_0:
        // 0x00B151C8: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B151CC: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B151D0: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B151D4: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B151D8: TBZ w8, #0, #0xb151e8      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B151DC: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B151E0: CBNZ w8, #0xb151e8         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B151E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_2:
        // 0x00B151E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B151EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B151F0: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_1 = VersionMgr.Instance;
        // 0x00B151F4: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
        // 0x00B151F8: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B151FC: LDR x8, [x8, #0xee8]       | X8 = 1152921515139735136;               
        // 0x00B15200: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B15204: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B15208: LDR x22, [x8]              | X22 = System.Void ABCheckUpdate::<LoadAllVSCfg>m__0();
        // 0x00B1520C: LDR x8, [x9]               | X8 = typeof(System.Action);             
        // 0x00B15210: MOV x0, x8                 | X0 = 1152921504687837184 (0x1000000004D3D000);//ML01
        System.Action val_2 = null;
        // 0x00B15214: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B15218: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1521C: MOV x1, x19                | X1 = 1152921515139760160 (0x1000000273CF8020);//ML01
        // 0x00B15220: MOV x2, x22                | X2 = 1152921515139735136 (0x1000000273CF1E60);//ML01
        // 0x00B15224: MOV x21, x0                | X21 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B15228: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ABCheckUpdate::<LoadAllVSCfg>m__0());
        val_2 = new System.Action(object:  this, method:  System.Void ABCheckUpdate::<LoadAllVSCfg>m__0());
        // 0x00B1522C: CBNZ x20, #0xb15234        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B15230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void ABCheckUpdate::<LoadAllVSCfg>m__0()), ????);
        label_3:
        // 0x00B15234: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B15238: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1523C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B15240: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B15244: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B15248: MOV x2, x21                | X2 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1524C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B15250: B #0xe2858c                | val_1.LoadAllVSCfg(type:  0, call:  val_2); return;
        val_1.LoadAllVSCfg(type:  0, call:  val_2);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15254 (11620948), len: 1028  VirtAddr: 0x00B15254 RVA: 0x00B15254 token: 100694252 methodIndex: 24595 delegateWrapperIndex: 0 methodInvoker: 0
    public void RequestCheckUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        var val_19;
        //  | 
        var val_20;
        //  | 
        var val_21;
        // 0x00B15254: STP x24, x23, [sp, #-0x40]! | stack[1152921515140007760] = ???;  stack[1152921515140007768] = ???;  //  dest_result_addr=1152921515140007760 |  dest_result_addr=1152921515140007768
        // 0x00B15258: STP x22, x21, [sp, #0x10]  | stack[1152921515140007776] = ???;  stack[1152921515140007784] = ???;  //  dest_result_addr=1152921515140007776 |  dest_result_addr=1152921515140007784
        // 0x00B1525C: STP x20, x19, [sp, #0x20]  | stack[1152921515140007792] = ???;  stack[1152921515140007800] = ???;  //  dest_result_addr=1152921515140007792 |  dest_result_addr=1152921515140007800
        // 0x00B15260: STP x29, x30, [sp, #0x30]  | stack[1152921515140007808] = ???;  stack[1152921515140007816] = ???;  //  dest_result_addr=1152921515140007808 |  dest_result_addr=1152921515140007816
        // 0x00B15264: ADD x29, sp, #0x30         | X29 = (1152921515140007760 + 48) = 1152921515140007808 (0x1000000273D34780);
        // 0x00B15268: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1526C: LDRB w8, [x20, #0x6d4]     | W8 = (bool)static_value_037336D4;       
        // 0x00B15270: MOV x19, x0                | X19 = 1152921515140019824 (0x1000000273D37670);//ML01
        // 0x00B15274: TBNZ w8, #0, #0xb15290     | if (static_value_037336D4 == true) goto label_0;
        // 0x00B15278: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00B1527C: LDR x8, [x8, #0x710]       | X8 = 0x2B8A6EC;                         
        // 0x00B15280: LDR w0, [x8]               | W0 = 0x79;                              
        // 0x00B15284: BL #0x2782188              | X0 = sub_2782188( ?? 0x79, ????);       
        // 0x00B15288: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1528C: STRB w8, [x20, #0x6d4]     | static_value_037336D4 = true;            //  dest_result_addr=57882324
        label_0:
        // 0x00B15290: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15294: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15298: BL #0x20c6ffc              | X0 = UnityEngine.Application.get_isEditor();
        bool val_1 = UnityEngine.Application.isEditor;
        // 0x00B1529C: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B152A0: TBNZ w8, #0, #0xb155e0     | if ((val_1 & 1) == true) goto label_35; 
        if(val_2 == true)
        {
            goto label_35;
        }
        // 0x00B152A4: ADRP x21, #0x363a000       | X21 = 56860672 (0x363A000);             
        // 0x00B152A8: LDR x21, [x21, #0x420]     | X21 = 1152921504911425536;              
        // 0x00B152AC: LDR x0, [x21]              | X0 = typeof(VersionMgr);                
        // 0x00B152B0: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B152B4: TBZ w8, #0, #0xb152c4      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B152B8: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B152BC: CBNZ w8, #0xb152c4         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B152C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_3:
        // 0x00B152C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B152C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B152CC: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_3 = VersionMgr.Instance;
        // 0x00B152D0: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B152D4: CBNZ x20, #0xb152dc        | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00B152D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00B152DC: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B152E0: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921515139856352)("CheckUpdate");
        // 0x00B152E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B152E8: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B152EC: LDR x1, [x8]               | X1 = "CheckUpdate";                     
        // 0x00B152F0: BL #0xe28220               | X0 = val_3.GetvsInfoByName(name:  "CheckUpdate");
        VersionInfo val_4 = val_3.GetvsInfoByName(name:  "CheckUpdate");
        // 0x00B152F4: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B152F8: CBZ x20, #0xb155f4         | if (val_4 == null) goto label_5;        
        if(val_4 == null)
        {
            goto label_5;
        }
        // 0x00B152FC: LDR x8, [x20, #0x18]       | X8 = val_4.pkgvs; //P2                  
        // 0x00B15300: CBZ x8, #0xb15558          | if (val_4.pkgvs == null) goto label_7;  
        if(val_4.pkgvs == null)
        {
            goto label_7;
        }
        // 0x00B15304: LDR x8, [x20, #0xa8]       | X8 = val_4.sdkinfo; //P2                
        // 0x00B15308: CBZ x8, #0xb15558          | if (val_4.sdkinfo == null) goto label_7;
        if(val_4.sdkinfo == null)
        {
            goto label_7;
        }
        // 0x00B1530C: LDR x0, [x21]              | X0 = typeof(VersionMgr);                
        // 0x00B15310: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B15314: TBZ w8, #0, #0xb15324      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00B15318: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B1531C: CBNZ w8, #0xb15324         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00B15320: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_9:
        // 0x00B15324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15328: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1532C: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_5 = VersionMgr.Instance;
        // 0x00B15330: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B15334: CBNZ x21, #0xb1533c        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00B15338: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00B1533C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15340: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B15344: BL #0xe27dac               | X0 = val_5.get_currentVS();             
        VersionInfo val_6 = val_5.currentVS;
        // 0x00B15348: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00B1534C: CBNZ x21, #0xb15354        | if (val_6 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x00B15350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00B15354: ADRP x23, #0x3627000       | X23 = 56782848 (0x3627000);             
        // 0x00B15358: LDR x21, [x21, #0x18]      | X21 = val_6.pkgvs; //P2                 
        // 0x00B1535C: LDR x23, [x23, #0xd58]     | X23 = 1152921504947213072;              
        // 0x00B15360: LDR x22, [x23]             | X22 = typeof(System.Char[]);            
        // 0x00B15364: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B15368: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00B1536C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B15370: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B15374: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00B15378: MOV x22, x0                | X22 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1537C: CBNZ x22, #0xb15384        | if ( != null) goto label_12;            
        if(null != null)
        {
            goto label_12;
        }
        // 0x00B15380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_12:
        // 0x00B15384: LDR w8, [x22, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00B15388: CBNZ w8, #0xb15398         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_13;
        // 0x00B1538C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00B15390: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15394: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_13:
        // 0x00B15398: MOVZ w8, #0x2e             | W8 = 46 (0x2E);//ML01                   
        // 0x00B1539C: STRH w8, [x22, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x2E;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 46;
        // 0x00B153A0: CBNZ x21, #0xb153a8        | if (val_6.pkgvs != null) goto label_14; 
        if(val_6.pkgvs != null)
        {
            goto label_14;
        }
        // 0x00B153A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_14:
        // 0x00B153A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B153AC: MOV x0, x21                | X0 = val_6.pkgvs;//m1                   
        // 0x00B153B0: MOV x1, x22                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B153B4: BL #0x18a881c              | X0 = val_6.pkgvs.Split(separator:  null);
        System.String[] val_7 = val_6.pkgvs.Split(separator:  null);
        // 0x00B153B8: LDR x23, [x23]             | X23 = typeof(System.Char[]);            
        // 0x00B153BC: LDR x22, [x20, #0x18]      | X22 = val_4.pkgvs; //P2                 
        // 0x00B153C0: MOV x21, x0                | X21 = val_7;//m1                        
        val_19 = val_7;
        // 0x00B153C4: MOV x0, x23                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B153C8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00B153CC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B153D0: MOV x0, x23                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B153D4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00B153D8: MOV x23, x0                | X23 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B153DC: CBNZ x23, #0xb153e4        | if ( != null) goto label_15;            
        if(null != null)
        {
            goto label_15;
        }
        // 0x00B153E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_15:
        // 0x00B153E4: LDR w8, [x23, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00B153E8: CBNZ w8, #0xb153f8         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_16;
        // 0x00B153EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00B153F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B153F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_16:
        // 0x00B153F8: MOVZ w8, #0x2e             | W8 = 46 (0x2E);//ML01                   
        // 0x00B153FC: STRH w8, [x23, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x2E;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 46;
        // 0x00B15400: CBNZ x22, #0xb15408        | if (val_4.pkgvs != null) goto label_17; 
        if(val_4.pkgvs != null)
        {
            goto label_17;
        }
        // 0x00B15404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_17:
        // 0x00B15408: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1540C: MOV x0, x22                | X0 = val_4.pkgvs;//m1                   
        // 0x00B15410: MOV x1, x23                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B15414: BL #0x18a881c              | X0 = val_4.pkgvs.Split(separator:  null);
        System.String[] val_8 = val_4.pkgvs.Split(separator:  null);
        // 0x00B15418: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00B1541C: CBNZ x21, #0xb15424        | if (val_7 != null) goto label_18;       
        if(val_19 != null)
        {
            goto label_18;
        }
        // 0x00B15420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_18:
        // 0x00B15424: LDR w8, [x21, #0x18]       | W8 = val_7.Length; //P2                 
        // 0x00B15428: CBNZ w8, #0xb15438         | if (val_7.Length != 0) goto label_19;   
        if(val_7.Length != 0)
        {
            goto label_19;
        }
        // 0x00B1542C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
        // 0x00B15430: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15434: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        label_19:
        // 0x00B15438: LDR x1, [x21, #0x20]       | X1 = val_7[0]                           
        string val_19 = val_19[0];
        // 0x00B1543C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15440: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15444: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_9 = System.Int32.Parse(s:  0);
        // 0x00B15448: MOV w23, w0                | W23 = val_9;//m1                        
        val_20 = val_9;
        // 0x00B1544C: CBNZ x22, #0xb15454        | if (val_8 != null) goto label_20;       
        if(val_8 != null)
        {
            goto label_20;
        }
        // 0x00B15450: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_20:
        // 0x00B15454: LDR w8, [x22, #0x18]       | W8 = val_8.Length; //P2                 
        // 0x00B15458: CBNZ w8, #0xb15468         | if (val_8.Length != 0) goto label_21;   
        if(val_8.Length != 0)
        {
            goto label_21;
        }
        // 0x00B1545C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
        // 0x00B15460: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15464: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
        label_21:
        // 0x00B15468: LDR x1, [x22, #0x20]       | X1 = val_8[0]                           
        string val_20 = val_8[0];
        // 0x00B1546C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15470: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15474: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_10 = System.Int32.Parse(s:  0);
        // 0x00B15478: CMP w23, w0                | STATE = COMPARE(val_9, val_10)          
        // 0x00B1547C: B.LT #0xb15550             | if (val_20 < val_10) goto label_22;     
        if(val_20 < val_10)
        {
            goto label_22;
        }
        // 0x00B15480: CBNZ x21, #0xb15488        | if (val_7 != null) goto label_23;       
        if(val_19 != null)
        {
            goto label_23;
        }
        // 0x00B15484: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_23:
        // 0x00B15488: LDR w8, [x21, #0x18]       | W8 = val_7.Length; //P2                 
        // 0x00B1548C: CBNZ w8, #0xb1549c         | if (val_7.Length != 0) goto label_24;   
        if(val_7.Length != 0)
        {
            goto label_24;
        }
        // 0x00B15490: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
        // 0x00B15494: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15498: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
        label_24:
        // 0x00B1549C: LDR x1, [x21, #0x20]       | X1 = val_7[0]                           
        string val_21 = val_19[0];
        // 0x00B154A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B154A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B154A8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_11 = System.Int32.Parse(s:  0);
        // 0x00B154AC: MOV w23, w0                | W23 = val_11;//m1                       
        val_20 = val_11;
        // 0x00B154B0: CBNZ x22, #0xb154b8        | if (val_8 != null) goto label_25;       
        if(val_8 != null)
        {
            goto label_25;
        }
        // 0x00B154B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_25:
        // 0x00B154B8: LDR w8, [x22, #0x18]       | W8 = val_8.Length; //P2                 
        // 0x00B154BC: CBNZ w8, #0xb154cc         | if (val_8.Length != 0) goto label_26;   
        if(val_8.Length != 0)
        {
            goto label_26;
        }
        // 0x00B154C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
        // 0x00B154C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B154C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
        label_26:
        // 0x00B154CC: LDR x1, [x22, #0x20]       | X1 = val_8[0]                           
        string val_22 = val_8[0];
        // 0x00B154D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B154D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B154D8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_12 = System.Int32.Parse(s:  0);
        // 0x00B154DC: CMP w23, w0                | STATE = COMPARE(val_11, val_12)         
        // 0x00B154E0: B.NE #0xb155e0             | if (val_20 != val_12) goto label_35;    
        if(val_20 != val_12)
        {
            goto label_35;
        }
        // 0x00B154E4: CBNZ x21, #0xb154ec        | if (val_7 != null) goto label_28;       
        if(val_19 != null)
        {
            goto label_28;
        }
        // 0x00B154E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_28:
        // 0x00B154EC: LDR w8, [x21, #0x18]       | W8 = val_7.Length; //P2                 
        // 0x00B154F0: CMP w8, #1                 | STATE = COMPARE(val_7.Length, 0x1)      
        // 0x00B154F4: B.HI #0xb15504             | if (val_7.Length > 1) goto label_29;    
        if(val_7.Length > 1)
        {
            goto label_29;
        }
        // 0x00B154F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
        // 0x00B154FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15500: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
        label_29:
        // 0x00B15504: LDR x1, [x21, #0x28]       | X1 = val_7[1]                           
        string val_23 = val_19[1];
        // 0x00B15508: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1550C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15510: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_13 = System.Int32.Parse(s:  0);
        // 0x00B15514: MOV w21, w0                | W21 = val_13;//m1                       
        val_19 = val_13;
        // 0x00B15518: CBNZ x22, #0xb15520        | if (val_8 != null) goto label_30;       
        if(val_8 != null)
        {
            goto label_30;
        }
        // 0x00B1551C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_30:
        // 0x00B15520: LDR w8, [x22, #0x18]       | W8 = val_8.Length; //P2                 
        // 0x00B15524: CMP w8, #1                 | STATE = COMPARE(val_8.Length, 0x1)      
        // 0x00B15528: B.HI #0xb15538             | if (val_8.Length > 1) goto label_31;    
        if(val_8.Length > 1)
        {
            goto label_31;
        }
        // 0x00B1552C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
        // 0x00B15530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15534: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
        label_31:
        // 0x00B15538: LDR x1, [x22, #0x28]       | X1 = val_8[1]                           
        string val_24 = val_8[1];
        // 0x00B1553C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15540: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15544: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_14 = System.Int32.Parse(s:  0);
        // 0x00B15548: CMP w21, w0                | STATE = COMPARE(val_13, val_14)         
        // 0x00B1554C: B.GE #0xb155e0             | if (val_19 >= val_14) goto label_35;    
        if(val_19 >= val_14)
        {
            goto label_35;
        }
        label_22:
        // 0x00B15550: LDR x8, [x20, #0x38]       | X8 = val_4.pkgurl; //P2                 
        // 0x00B15554: STR x8, [x19, #0xa0]       | this.DOWNLOAD_URL = val_4.pkgurl;        //  dest_result_addr=1152921515140019984
        this.DOWNLOAD_URL = val_4.pkgurl;
        label_7:
        // 0x00B15558: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
        // 0x00B1555C: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
        val_19 = 1152921504608284672;
        // 0x00B15560: LDR x20, [x19, #0xa0]      | X20 = this.DOWNLOAD_URL; //P2           
        // 0x00B15564: LDR x0, [x21]              | X0 = typeof(System.String);             
        // 0x00B15568: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1556C: TBZ w8, #0, #0xb1557c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_34;
        // 0x00B15570: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B15574: CBNZ w8, #0xb1557c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
        // 0x00B15578: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_34:
        // 0x00B1557C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B15580: LDR x8, [x8, #0x9e0]       | X8 = (string**)(1152921509743366224)("false");
        // 0x00B15584: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15588: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1558C: MOV x1, x20                | X1 = this.DOWNLOAD_URL;//m1             
        // 0x00B15590: LDR x2, [x8]               | X2 = "false";                           
        // 0x00B15594: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  this.DOWNLOAD_URL);
        bool val_15 = System.String.op_Equality(a:  0, b:  this.DOWNLOAD_URL);
        // 0x00B15598: AND w8, w0, #1             | W8 = (val_15 & 1);                      
        bool val_16 = val_15;
        // 0x00B1559C: TBNZ w8, #0, #0xb155e0     | if ((val_15 & 1) == true) goto label_35;
        if(val_16 == true)
        {
            goto label_35;
        }
        // 0x00B155A0: LDR x0, [x21]              | X0 = typeof(System.String);             
        val_21 = null;
        // 0x00B155A4: LDR x20, [x19, #0xa0]      | X20 = this.DOWNLOAD_URL; //P2           
        // 0x00B155A8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B155AC: TBZ w8, #0, #0xb155c0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_37;
        // 0x00B155B0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B155B4: CBNZ w8, #0xb155c0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
        // 0x00B155B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B155BC: LDR x0, [x21]              | X0 = typeof(System.String);             
        val_21 = null;
        label_37:
        // 0x00B155C0: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B155C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B155C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B155CC: MOV x1, x20                | X1 = this.DOWNLOAD_URL;//m1             
        // 0x00B155D0: LDR x2, [x8]               | X2 = System.String.Empty;               
        // 0x00B155D4: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  this.DOWNLOAD_URL);
        bool val_17 = System.String.op_Equality(a:  0, b:  this.DOWNLOAD_URL);
        // 0x00B155D8: AND w8, w0, #1             | W8 = (val_17 & 1);                      
        bool val_18 = val_17;
        // 0x00B155DC: TBZ w8, #0, #0xb15640      | if ((val_17 & 1) == false) goto label_38;
        if(val_18 == false)
        {
            goto label_38;
        }
        label_35:
        // 0x00B155E0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B155E4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B155E8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B155EC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B155F0: RET                        |  return;                                
        return;
        label_5:
        // 0x00B155F4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B155F8: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B155FC: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00B15600: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B15604: TBZ w8, #0, #0xb15614      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_40;
        // 0x00B15608: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B1560C: CBNZ w8, #0xb15614         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
        // 0x00B15610: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_40:
        // 0x00B15614: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B15618: LDR x8, [x8, #0x8b8]       | X8 = (string**)(1152921515139995712)("fanzhong_强制更新失败");
        // 0x00B1561C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15620: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B15624: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B15628: LDR x1, [x8]               | X1 = "fanzhong_强制更新失败";                 
        // 0x00B1562C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B15630: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B15634: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B15638: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B1563C: B #0xb45c10                | EDebug.Log(message:  0, isShowStack:  true); return;
        EDebug.Log(message:  0, isShowStack:  true);
        return;
        label_38:
        // 0x00B15640: MOV x0, x19                | X0 = 1152921515140019824 (0x1000000273D37670);//ML01
        // 0x00B15644: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B15648: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1564C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B15650: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B15654: B #0xb15658                | this.GoToGooglestoreDialog(); return;   
        this.GoToGooglestoreDialog();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15658 (11621976), len: 276  VirtAddr: 0x00B15658 RVA: 0x00B15658 token: 100694253 methodIndex: 24596 delegateWrapperIndex: 0 methodInvoker: 0
    private void GoToGooglestoreDialog()
    {
        //
        // Disasemble & Code
        // 0x00B15658: STP x24, x23, [sp, #-0x40]! | stack[1152921515140269984] = ???;  stack[1152921515140269992] = ???;  //  dest_result_addr=1152921515140269984 |  dest_result_addr=1152921515140269992
        // 0x00B1565C: STP x22, x21, [sp, #0x10]  | stack[1152921515140270000] = ???;  stack[1152921515140270008] = ???;  //  dest_result_addr=1152921515140270000 |  dest_result_addr=1152921515140270008
        // 0x00B15660: STP x20, x19, [sp, #0x20]  | stack[1152921515140270016] = ???;  stack[1152921515140270024] = ???;  //  dest_result_addr=1152921515140270016 |  dest_result_addr=1152921515140270024
        // 0x00B15664: STP x29, x30, [sp, #0x30]  | stack[1152921515140270032] = ???;  stack[1152921515140270040] = ???;  //  dest_result_addr=1152921515140270032 |  dest_result_addr=1152921515140270040
        // 0x00B15668: ADD x29, sp, #0x30         | X29 = (1152921515140269984 + 48) = 1152921515140270032 (0x1000000273D747D0);
        // 0x00B1566C: SUB sp, sp, #0x10          | SP = (1152921515140269984 - 16) = 1152921515140269968 (0x1000000273D74790);
        // 0x00B15670: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B15674: LDRB w8, [x19, #0x6d5]     | W8 = (bool)static_value_037336D5;       
        // 0x00B15678: MOV x21, x0                | X21 = 1152921515140282048 (0x1000000273D776C0);//ML01
        // 0x00B1567C: TBNZ w8, #0, #0xb15698     | if (static_value_037336D5 == true) goto label_0;
        // 0x00B15680: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B15684: LDR x8, [x8, #0x4b0]       | X8 = 0x2B8A6BC;                         
        // 0x00B15688: LDR w0, [x8]               | W0 = 0x6D;                              
        // 0x00B1568C: BL #0x2782188              | X0 = sub_2782188( ?? 0x6D, ????);       
        // 0x00B15690: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15694: STRB w8, [x19, #0x6d5]     | static_value_037336D5 = true;            //  dest_result_addr=57882325
        label_0:
        // 0x00B15698: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1569C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B156A0: BL #0x138e268              | X0 = PluginsSdkMgr.get_Instance();      
        PluginsSdkMgr val_1 = PluginsSdkMgr.Instance;
        // 0x00B156A4: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B156A8: ADRP x24, #0x3679000       | X24 = 57118720 (0x3679000);             
        // 0x00B156AC: LDR x8, [x8, #0x6f0]       | X8 = 1152921515140255280;               
        // 0x00B156B0: LDR x24, [x24, #0xbe0]     | X24 = 1152921504687837184;              
        // 0x00B156B4: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B156B8: LDR x22, [x8]              | X22 = System.Void ABCheckUpdate::GoToGoogleStore();
        // 0x00B156BC: LDR x8, [x24]              | X8 = typeof(System.Action);             
        // 0x00B156C0: MOV x0, x8                 | X0 = 1152921504687837184 (0x1000000004D3D000);//ML01
        System.Action val_2 = null;
        // 0x00B156C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B156C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B156CC: MOV x1, x21                | X1 = 1152921515140282048 (0x1000000273D776C0);//ML01
        // 0x00B156D0: MOV x2, x22                | X2 = 1152921515140255280 (0x1000000273D70E30);//ML01
        // 0x00B156D4: MOV x19, x0                | X19 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B156D8: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ABCheckUpdate::GoToGoogleStore());
        val_2 = new System.Action(object:  this, method:  System.Void ABCheckUpdate::GoToGoogleStore());
        // 0x00B156DC: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B156E0: LDR x8, [x8, #0x6f0]       | X8 = 1152921515140256304;               
        // 0x00B156E4: LDR x0, [x24]              | X0 = typeof(System.Action);             
        System.Action val_3 = null;
        // 0x00B156E8: LDR x23, [x8]              | X23 = System.Void ABCheckUpdate::GoToGoogleStoreAfter();
        // 0x00B156EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B156F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B156F4: MOV x1, x21                | X1 = 1152921515140282048 (0x1000000273D776C0);//ML01
        // 0x00B156F8: MOV x2, x23                | X2 = 1152921515140256304 (0x1000000273D71230);//ML01
        // 0x00B156FC: MOV x22, x0                | X22 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B15700: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ABCheckUpdate::GoToGoogleStoreAfter());
        val_3 = new System.Action(object:  this, method:  System.Void ABCheckUpdate::GoToGoogleStoreAfter());
        // 0x00B15704: CBNZ x20, #0xb1570c        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00B15708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void ABCheckUpdate::GoToGoogleStoreAfter()), ????);
        label_1:
        // 0x00B1570C: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B15710: ADRP x9, #0x3632000        | X9 = 56827904 (0x3632000);              
        // 0x00B15714: ADRP x10, #0x3600000       | X10 = 56623104 (0x3600000);             
        // 0x00B15718: ADRP x11, #0x361b000       | X11 = 56733696 (0x361B000);             
        // 0x00B1571C: LDR x8, [x8, #0x618]       | X8 = (string**)(1152921515140257328)("Software Update");
        // 0x00B15720: LDR x9, [x9, #0x510]       | X9 = (string**)(1152921515140257440)("Dear players, due to the account upgrade, you need to update the client to get a better experience, the system will automatically redirect to the Google download page.If you have any questions, please contact customer service.");
        // 0x00B15724: LDR x10, [x10, #0x3a8]     | X10 = (string**)(1152921510033340128)("Update");
        // 0x00B15728: LDR x11, [x11, #0xfb8]     | X11 = (string**)(1152921515140257968)("Later");
        // 0x00B1572C: LDR x1, [x8]               | X1 = "Software Update";                 
        // 0x00B15730: LDR x2, [x9]               | X2 = "Dear players, due to the account upgrade, you need to update the client to get a better experience, the system will automatically redirect to the Google download page.If you have any questions, please contact customer service.";
        // 0x00B15734: LDR x4, [x10]              | X4 = "Update";                          
        // 0x00B15738: LDR x5, [x11]              | X5 = "Later";                           
        // 0x00B1573C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B15740: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B15744: MOV x6, x19                | X6 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B15748: MOV x7, x22                | X7 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1574C: STR xzr, [sp]              | stack[1152921515140269968] = 0x0;        //  dest_result_addr=1152921515140269968
        // 0x00B15750: BL #0x13a69fc              | val_1.ShowDialog(title:  "Software Update", content:  "Dear players, due to the account upgrade, you need to update the client to get a better experience, the system will automatically redirect to the Google download page.If you have any questions, please contact customer service.", cancelable:  false, okText:  "Update", cancelText:  "Later", OnOK:  val_2, OnCancel:  val_3);
        val_1.ShowDialog(title:  "Software Update", content:  "Dear players, due to the account upgrade, you need to update the client to get a better experience, the system will automatically redirect to the Google download page.If you have any questions, please contact customer service.", cancelable:  false, okText:  "Update", cancelText:  "Later", OnOK:  val_2, OnCancel:  val_3);
        // 0x00B15754: SUB sp, x29, #0x30         | SP = (1152921515140270032 - 48) = 1152921515140269984 (0x1000000273D747A0);
        // 0x00B15758: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1575C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B15760: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B15764: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B15768: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1576C (11622252), len: 184  VirtAddr: 0x00B1576C RVA: 0x00B1576C token: 100694254 methodIndex: 24597 delegateWrapperIndex: 0 methodInvoker: 0
    private void GoToGoogleStore()
    {
        //
        // Disasemble & Code
        // 0x00B1576C: STP x20, x19, [sp, #-0x20]! | stack[1152921515140398400] = ???;  stack[1152921515140398408] = ???;  //  dest_result_addr=1152921515140398400 |  dest_result_addr=1152921515140398408
        // 0x00B15770: STP x29, x30, [sp, #0x10]  | stack[1152921515140398416] = ???;  stack[1152921515140398424] = ???;  //  dest_result_addr=1152921515140398416 |  dest_result_addr=1152921515140398424
        // 0x00B15774: ADD x29, sp, #0x10         | X29 = (1152921515140398400 + 16) = 1152921515140398416 (0x1000000273D93D50);
        // 0x00B15778: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1577C: LDRB w8, [x20, #0x6d6]     | W8 = (bool)static_value_037336D6;       
        // 0x00B15780: MOV x19, x0                | X19 = 1152921515140410432 (0x1000000273D96C40);//ML01
        // 0x00B15784: TBNZ w8, #0, #0xb157a0     | if (static_value_037336D6 == true) goto label_0;
        // 0x00B15788: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00B1578C: LDR x8, [x8, #0x6b8]       | X8 = 0x2B8A6B8;                         
        // 0x00B15790: LDR w0, [x8]               | W0 = 0x6C;                              
        // 0x00B15794: BL #0x2782188              | X0 = sub_2782188( ?? 0x6C, ????);       
        // 0x00B15798: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1579C: STRB w8, [x20, #0x6d6]     | static_value_037336D6 = true;            //  dest_result_addr=57882326
        label_0:
        // 0x00B157A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B157A4: STRB w8, [x19, #0x51]      | this.isQuit = true;                      //  dest_result_addr=1152921515140410513
        this.isQuit = true;
        // 0x00B157A8: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B157AC: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B157B0: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B157B4: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B157B8: TBZ w8, #0, #0xb157c8      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B157BC: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B157C0: CBNZ w8, #0xb157c8         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B157C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_2:
        // 0x00B157C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B157CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B157D0: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_1 = VersionMgr.Instance;
        // 0x00B157D4: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B157D8: CBNZ x20, #0xb157e0        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B157DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B157E0: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B157E4: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921515139856352)("CheckUpdate");
        // 0x00B157E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B157EC: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B157F0: LDR x1, [x8]               | X1 = "CheckUpdate";                     
        // 0x00B157F4: BL #0xe28220               | X0 = val_1.GetvsInfoByName(name:  "CheckUpdate");
        VersionInfo val_2 = val_1.GetvsInfoByName(name:  "CheckUpdate");
        // 0x00B157F8: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B157FC: CBNZ x20, #0xb15804        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B15800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B15804: LDR x1, [x20, #0x38]       | X1 = val_2.pkgurl; //P2                 
        // 0x00B15808: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1580C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15810: BL #0x20c790c              | UnityEngine.Application.OpenURL(url:  0);
        UnityEngine.Application.OpenURL(url:  0);
        // 0x00B15814: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B15818: MOV x0, x19                | X0 = 1152921515140410432 (0x1000000273D96C40);//ML01
        // 0x00B1581C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B15820: B #0xb15658                | this.GoToGooglestoreDialog(); return;   
        this.GoToGooglestoreDialog();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15824 (11622436), len: 20  VirtAddr: 0x00B15824 RVA: 0x00B15824 token: 100694255 methodIndex: 24598 delegateWrapperIndex: 0 methodInvoker: 0
    private void GoToGoogleStoreAfter()
    {
        //
        // Disasemble & Code
        // 0x00B15824: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15828: STRB w8, [x0, #0x51]       | this.isQuit = true;                      //  dest_result_addr=1152921515140534801
        this.isQuit = true;
        // 0x00B1582C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15834: B #0x20c6c2c               | UnityEngine.Application.Quit(); return; 
        UnityEngine.Application.Quit();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15838 (11622456), len: 228  VirtAddr: 0x00B15838 RVA: 0x00B15838 token: 100694256 methodIndex: 24599 delegateWrapperIndex: 0 methodInvoker: 0
    private void GoToAppstoreDialog()
    {
        //
        // Disasemble & Code
        // 0x00B15838: STP x22, x21, [sp, #-0x30]! | stack[1152921515140640416] = ???;  stack[1152921515140640424] = ???;  //  dest_result_addr=1152921515140640416 |  dest_result_addr=1152921515140640424
        // 0x00B1583C: STP x20, x19, [sp, #0x10]  | stack[1152921515140640432] = ???;  stack[1152921515140640440] = ???;  //  dest_result_addr=1152921515140640432 |  dest_result_addr=1152921515140640440
        // 0x00B15840: STP x29, x30, [sp, #0x20]  | stack[1152921515140640448] = ???;  stack[1152921515140640456] = ???;  //  dest_result_addr=1152921515140640448 |  dest_result_addr=1152921515140640456
        // 0x00B15844: ADD x29, sp, #0x20         | X29 = (1152921515140640416 + 32) = 1152921515140640448 (0x1000000273DCEEC0);
        // 0x00B15848: SUB sp, sp, #0x10          | SP = (1152921515140640416 - 16) = 1152921515140640400 (0x1000000273DCEE90);
        // 0x00B1584C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B15850: LDRB w8, [x19, #0x6d7]     | W8 = (bool)static_value_037336D7;       
        // 0x00B15854: MOV x21, x0                | X21 = 1152921515140652464 (0x1000000273DD1DB0);//ML01
        // 0x00B15858: TBNZ w8, #0, #0xb15874     | if (static_value_037336D7 == true) goto label_0;
        // 0x00B1585C: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00B15860: LDR x8, [x8, #0x7c8]       | X8 = 0x2B8A6B4;                         
        // 0x00B15864: LDR w0, [x8]               | W0 = 0x6B;                              
        // 0x00B15868: BL #0x2782188              | X0 = sub_2782188( ?? 0x6B, ????);       
        // 0x00B1586C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15870: STRB w8, [x19, #0x6d7]     | static_value_037336D7 = true;            //  dest_result_addr=57882327
        label_0:
        // 0x00B15874: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1587C: BL #0x138e268              | X0 = PluginsSdkMgr.get_Instance();      
        PluginsSdkMgr val_1 = PluginsSdkMgr.Instance;
        // 0x00B15880: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x00B15884: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B15888: LDR x8, [x8, #0x3e8]       | X8 = 1152921515140626816;               
        // 0x00B1588C: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B15890: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B15894: LDR x22, [x8]              | X22 = System.Void ABCheckUpdate::GoToAppstore();
        // 0x00B15898: LDR x8, [x9]               | X8 = typeof(System.Action);             
        // 0x00B1589C: MOV x0, x8                 | X0 = 1152921504687837184 (0x1000000004D3D000);//ML01
        System.Action val_2 = null;
        // 0x00B158A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B158A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B158A8: MOV x1, x21                | X1 = 1152921515140652464 (0x1000000273DD1DB0);//ML01
        // 0x00B158AC: MOV x2, x22                | X2 = 1152921515140626816 (0x1000000273DCB980);//ML01
        // 0x00B158B0: MOV x19, x0                | X19 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B158B4: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ABCheckUpdate::GoToAppstore());
        val_2 = new System.Action(object:  this, method:  System.Void ABCheckUpdate::GoToAppstore());
        // 0x00B158B8: CBNZ x20, #0xb158c0        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00B158BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void ABCheckUpdate::GoToAppstore()), ????);
        label_1:
        // 0x00B158C0: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B158C4: ADRP x9, #0x3672000        | X9 = 57090048 (0x3672000);              
        // 0x00B158C8: ADRP x10, #0x3600000       | X10 = 56623104 (0x3600000);             
        // 0x00B158CC: ADRP x11, #0x3669000       | X11 = 57053184 (0x3669000);             
        // 0x00B158D0: LDR x8, [x8, #0x618]       | X8 = (string**)(1152921515140257328)("Software Update");
        // 0x00B158D4: LDR x9, [x9, #0xc8]        | X9 = (string**)(1152921515140627840)("Dear player, due to the account system upgrade, you need to update the client before you can enter the game, the system will automatically upgrade your account, after the upgrade is successful, you can contact customer service.");
        // 0x00B158D8: LDR x10, [x10, #0x3a8]     | X10 = (string**)(1152921510033340128)("Update");
        // 0x00B158DC: LDR x11, [x11, #0x238]     | X11 = (string**)(1152921515140628368)("Update Later");
        // 0x00B158E0: LDR x1, [x8]               | X1 = "Software Update";                 
        // 0x00B158E4: LDR x2, [x9]               | X2 = "Dear player, due to the account system upgrade, you need to update the client before you can enter the game, the system will automatically upgrade your account, after the upgrade is successful, you can contact customer service.";
        // 0x00B158E8: LDR x4, [x10]              | X4 = "Update";                          
        // 0x00B158EC: LDR x5, [x11]              | X5 = "Update Later";                    
        // 0x00B158F0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B158F4: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B158F8: MOV x6, x19                | X6 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B158FC: MOV x7, xzr                | X7 = 0 (0x0);//ML01                     
        // 0x00B15900: STR xzr, [sp]              | stack[1152921515140640400] = 0x0;        //  dest_result_addr=1152921515140640400
        // 0x00B15904: BL #0x13a69fc              | val_1.ShowDialog(title:  "Software Update", content:  "Dear player, due to the account system upgrade, you need to update the client before you can enter the game, the system will automatically upgrade your account, after the upgrade is successful, you can contact customer service.", cancelable:  false, okText:  "Update", cancelText:  "Update Later", OnOK:  val_2, OnCancel:  0);
        val_1.ShowDialog(title:  "Software Update", content:  "Dear player, due to the account system upgrade, you need to update the client before you can enter the game, the system will automatically upgrade your account, after the upgrade is successful, you can contact customer service.", cancelable:  false, okText:  "Update", cancelText:  "Update Later", OnOK:  val_2, OnCancel:  0);
        // 0x00B15908: SUB sp, x29, #0x20         | SP = (1152921515140640448 - 32) = 1152921515140640416 (0x1000000273DCEEA0);
        // 0x00B1590C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B15910: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B15914: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B15918: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1591C (11622684), len: 164  VirtAddr: 0x00B1591C RVA: 0x00B1591C token: 100694257 methodIndex: 24600 delegateWrapperIndex: 0 methodInvoker: 0
    private void GoToAppstore()
    {
        //
        // Disasemble & Code
        // 0x00B1591C: STP x20, x19, [sp, #-0x20]! | stack[1152921515140768816] = ???;  stack[1152921515140768824] = ???;  //  dest_result_addr=1152921515140768816 |  dest_result_addr=1152921515140768824
        // 0x00B15920: STP x29, x30, [sp, #0x10]  | stack[1152921515140768832] = ???;  stack[1152921515140768840] = ???;  //  dest_result_addr=1152921515140768832 |  dest_result_addr=1152921515140768840
        // 0x00B15924: ADD x29, sp, #0x10         | X29 = (1152921515140768816 + 16) = 1152921515140768832 (0x1000000273DEE440);
        // 0x00B15928: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1592C: LDRB w8, [x20, #0x6d8]     | W8 = (bool)static_value_037336D8;       
        // 0x00B15930: MOV x19, x0                | X19 = 1152921515140780848 (0x1000000273DF1330);//ML01
        // 0x00B15934: TBNZ w8, #0, #0xb15950     | if (static_value_037336D8 == true) goto label_0;
        // 0x00B15938: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B1593C: LDR x8, [x8, #0xfa0]       | X8 = 0x2B8A6B0;                         
        // 0x00B15940: LDR w0, [x8]               | W0 = 0x6A;                              
        // 0x00B15944: BL #0x2782188              | X0 = sub_2782188( ?? 0x6A, ????);       
        // 0x00B15948: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1594C: STRB w8, [x20, #0x6d8]     | static_value_037336D8 = true;            //  dest_result_addr=57882328
        label_0:
        // 0x00B15950: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B15954: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B15958: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B1595C: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B15960: TBZ w8, #0, #0xb15970      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B15964: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B15968: CBNZ w8, #0xb15970         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1596C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_2:
        // 0x00B15970: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15974: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15978: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_1 = VersionMgr.Instance;
        // 0x00B1597C: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B15980: CBNZ x20, #0xb15988        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B15984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B15988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1598C: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B15990: BL #0xe27dac               | X0 = val_1.get_currentVS();             
        VersionInfo val_2 = val_1.currentVS;
        // 0x00B15994: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B15998: CBNZ x20, #0xb159a0        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B1599C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B159A0: LDR x1, [x20, #0x38]       | X1 = val_2.pkgurl; //P2                 
        // 0x00B159A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B159A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B159AC: BL #0x20c790c              | UnityEngine.Application.OpenURL(url:  0);
        UnityEngine.Application.OpenURL(url:  0);
        // 0x00B159B0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B159B4: MOV x0, x19                | X0 = 1152921515140780848 (0x1000000273DF1330);//ML01
        // 0x00B159B8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B159BC: B #0xb15838                | this.GoToAppstoreDialog(); return;      
        this.GoToAppstoreDialog();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B159C0 (11622848), len: 224  VirtAddr: 0x00B159C0 RVA: 0x00B159C0 token: 100694258 methodIndex: 24601 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnDownLoadAPK()
    {
        //
        // Disasemble & Code
        //  | 
        System.Action val_2;
        // 0x00B159C0: STP x22, x21, [sp, #-0x30]! | stack[1152921515140894112] = ???;  stack[1152921515140894120] = ???;  //  dest_result_addr=1152921515140894112 |  dest_result_addr=1152921515140894120
        // 0x00B159C4: STP x20, x19, [sp, #0x10]  | stack[1152921515140894128] = ???;  stack[1152921515140894136] = ???;  //  dest_result_addr=1152921515140894128 |  dest_result_addr=1152921515140894136
        // 0x00B159C8: STP x29, x30, [sp, #0x20]  | stack[1152921515140894144] = ???;  stack[1152921515140894152] = ???;  //  dest_result_addr=1152921515140894144 |  dest_result_addr=1152921515140894152
        // 0x00B159CC: ADD x29, sp, #0x20         | X29 = (1152921515140894112 + 32) = 1152921515140894144 (0x1000000273E0CDC0);
        // 0x00B159D0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B159D4: LDRB w8, [x20, #0x6d9]     | W8 = (bool)static_value_037336D9;       
        // 0x00B159D8: MOV x19, x0                | X19 = 1152921515140906160 (0x1000000273E0FCB0);//ML01
        // 0x00B159DC: TBNZ w8, #0, #0xb159f8     | if (static_value_037336D9 == true) goto label_0;
        // 0x00B159E0: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
        // 0x00B159E4: LDR x8, [x8, #0x128]       | X8 = 0x2B8A6E0;                         
        // 0x00B159E8: LDR w0, [x8]               | W0 = 0x76;                              
        // 0x00B159EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x76, ????);       
        // 0x00B159F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B159F4: STRB w8, [x20, #0x6d9]     | static_value_037336D9 = true;            //  dest_result_addr=57882329
        label_0:
        // 0x00B159F8: STR xzr, [x19, #0x40]      | this.httpDownLoad = null;                //  dest_result_addr=1152921515140906224
        this.httpDownLoad = 0;
        // 0x00B159FC: ADRP x21, #0x365c000       | X21 = 56999936 (0x365C000);             
        // 0x00B15A00: LDR x21, [x21, #0xd68]     | X21 = 1152921504910680064;              
        // 0x00B15A04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15A08: STRB w8, [x19, #0xa9]      | this.<isPkged>k__BackingField = true;    //  dest_result_addr=1152921515140906329
        this.<isPkged>k__BackingField = true;
        // 0x00B15A0C: LDR x8, [x21]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B15A10: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B15A14: LDR x19, [x8, #8]          | X19 = ABCheckUpdate.<>f__am$cache0;     
        val_2 = ABCheckUpdate.<>f__am$cache0;
        // 0x00B15A18: CBNZ x19, #0xb15a64        | if (ABCheckUpdate.<>f__am$cache0 != null) goto label_1;
        if(val_2 != null)
        {
            goto label_1;
        }
        // 0x00B15A1C: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B15A20: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B15A24: LDR x8, [x8, #0x840]       | X8 = 1152921515140881136;               
        // 0x00B15A28: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B15A2C: LDR x19, [x8]              | X19 = static System.Void ABCheckUpdate::<OnDownLoadAPK>m__1();
        // 0x00B15A30: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_1 = null;
        // 0x00B15A34: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B15A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15A3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B15A40: MOV x2, x19                | X2 = 1152921515140881136 (0x1000000273E09AF0);//ML01
        // 0x00B15A44: MOV x20, x0                | X20 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B15A48: BL #0x26e30f0              | .ctor(object:  0, method:  static System.Void ABCheckUpdate::<OnDownLoadAPK>m__1());
        val_1 = new System.Action(object:  0, method:  static System.Void ABCheckUpdate::<OnDownLoadAPK>m__1());
        // 0x00B15A4C: LDR x8, [x21]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B15A50: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B15A54: STR x20, [x8, #8]          | ABCheckUpdate.<>f__am$cache0 = typeof(System.Action);  //  dest_result_addr=1152921504910684168
        ABCheckUpdate.<>f__am$cache0 = val_1;
        // 0x00B15A58: LDR x8, [x21]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B15A5C: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B15A60: LDR x19, [x8, #8]          | X19 = typeof(System.Action);            
        val_2 = ABCheckUpdate.<>f__am$cache0;
        label_1:
        // 0x00B15A64: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00B15A68: LDR x8, [x8, #0xa8]        | X8 = 1152921504922021888;               
        // 0x00B15A6C: LDR x0, [x8]               | X0 = typeof(WaitMainThread);            
        // 0x00B15A70: LDRB w8, [x0, #0x10a]      | W8 = WaitMainThread.__il2cppRuntimeField_10A;
        // 0x00B15A74: TBZ w8, #0, #0xb15a84      | if (WaitMainThread.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B15A78: LDR w8, [x0, #0xbc]        | W8 = WaitMainThread.__il2cppRuntimeField_cctor_finished;
        // 0x00B15A7C: CBNZ w8, #0xb15a84         | if (WaitMainThread.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B15A80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(WaitMainThread), ????);
        label_3:
        // 0x00B15A84: MOV x1, x19                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B15A88: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B15A8C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B15A90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15A94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15A98: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B15A9C: B #0xe15e48                | WaitMainThread.Wait(waitCallBack:  0); return;
        WaitMainThread.Wait(waitCallBack:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15084 (11620484), len: 268  VirtAddr: 0x00B15084 RVA: 0x00B15084 token: 100694259 methodIndex: 24602 delegateWrapperIndex: 0 methodInvoker: 0
    private void LoadClientVer()
    {
        //
        // Disasemble & Code
        // 0x00B15084: STP x24, x23, [sp, #-0x40]! | stack[1152921515141019408] = ???;  stack[1152921515141019416] = ???;  //  dest_result_addr=1152921515141019408 |  dest_result_addr=1152921515141019416
        // 0x00B15088: STP x22, x21, [sp, #0x10]  | stack[1152921515141019424] = ???;  stack[1152921515141019432] = ???;  //  dest_result_addr=1152921515141019424 |  dest_result_addr=1152921515141019432
        // 0x00B1508C: STP x20, x19, [sp, #0x20]  | stack[1152921515141019440] = ???;  stack[1152921515141019448] = ???;  //  dest_result_addr=1152921515141019440 |  dest_result_addr=1152921515141019448
        // 0x00B15090: STP x29, x30, [sp, #0x30]  | stack[1152921515141019456] = ???;  stack[1152921515141019464] = ???;  //  dest_result_addr=1152921515141019456 |  dest_result_addr=1152921515141019464
        // 0x00B15094: ADD x29, sp, #0x30         | X29 = (1152921515141019408 + 48) = 1152921515141019456 (0x1000000273E2B740);
        // 0x00B15098: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1509C: LDRB w8, [x20, #0x6da]     | W8 = (bool)static_value_037336DA;       
        // 0x00B150A0: MOV x19, x0                | X19 = 1152921515141031472 (0x1000000273E2E630);//ML01
        // 0x00B150A4: TBNZ w8, #0, #0xb150c0     | if (static_value_037336DA == true) goto label_0;
        // 0x00B150A8: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B150AC: LDR x8, [x8, #0x728]       | X8 = 0x2B8A6C8;                         
        // 0x00B150B0: LDR w0, [x8]               | W0 = 0x70;                              
        // 0x00B150B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x70, ????);       
        // 0x00B150B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B150BC: STRB w8, [x20, #0x6da]     | static_value_037336DA = true;            //  dest_result_addr=57882330
        label_0:
        // 0x00B150C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B150C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B150C8: BL #0xdbd3cc               | X0 = LoadingBoardMgr.get_Instance();    
        LoadingBoardMgr val_1 = LoadingBoardMgr.Instance;
        // 0x00B150CC: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B150D0: CBNZ x20, #0xb150d8        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00B150D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B150D8: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
        // 0x00B150DC: LDR x8, [x8, #0xe40]       | X8 = (string**)(1152921510482500256)("Checking for updates...");
        // 0x00B150E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B150E4: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B150E8: LDR x1, [x8]               | X1 = "Checking for updates...";         
        // 0x00B150EC: BL #0xdbdc98               | val_1.SetDescri(value:  "Checking for updates...");
        val_1.SetDescri(value:  "Checking for updates...");
        // 0x00B150F0: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B150F4: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B150F8: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        // 0x00B150FC: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B15100: TBZ w8, #0, #0xb15110      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B15104: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B15108: CBNZ w8, #0xb15110         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B1510C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        label_3:
        // 0x00B15110: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00B15114: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921510473501152)("vsnum.uab");
        // 0x00B15118: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1511C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15120: LDR x1, [x8]               | X1 = "vsnum.uab";                       
        // 0x00B15124: BL #0xdbca3c               | X0 = Loader.PathUtil.CheckPath(path:  0);
        string val_2 = Loader.PathUtil.CheckPath(path:  0);
        // 0x00B15128: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B1512C: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_3 = AssetDownMgr.Instance;
        // 0x00B15130: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x00B15134: ADRP x9, #0x361c000        | X9 = 56737792 (0x361C000);              
        // 0x00B15138: LDR x8, [x8, #0x4c8]       | X8 = 1152921515141006448;               
        // 0x00B1513C: LDR x9, [x9, #0x610]       | X9 = 1152921504910786560;               
        // 0x00B15140: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B15144: LDR x23, [x8]              | X23 = System.Void ABCheckUpdate::<LoadClientVer>m__2(string name, byte[] abBytes);
        // 0x00B15148: LDR x8, [x9]               | X8 = typeof(AssetDownMgr.SetBytes);     
        // 0x00B1514C: MOV x0, x8                 | X0 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B15150: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetDownMgr.SetBytes), ????);
        // 0x00B15154: LDR x8, [x23]              | X8 = System.Void ABCheckUpdate::<LoadClientVer>m__2(string name, byte[] abBytes);
        // 0x00B15158: MOV x22, x0                | X22 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B1515C: STP x19, x23, [x22, #0x20] | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;  typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadClientVer>m__2(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786592 |  dest_result_addr=1152921504910786600
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadClientVer>m__2(string name, byte[] abBytes);
        // 0x00B15160: STR x8, [x22, #0x10]       | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadClientVer>m__2(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786576
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadClientVer>m__2(string name, byte[] abBytes);
        // 0x00B15164: CBNZ x21, #0xb1516c        | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00B15168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AssetDownMgr.SetBytes), ????);
        label_4:
        // 0x00B1516C: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B15170: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00B15174: MOV x2, x22                | X2 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B15178: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1517C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B15180: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B15184: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B15188: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B1518C: B #0xb15ab0                | val_3.AddUpdateData(path:  val_2, downFinishCall:  null, isInsert:  false); return;
        val_3.AddUpdateData(path:  val_2, downFinishCall:  null, isInsert:  false);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15D44 (11623748), len: 476  VirtAddr: 0x00B15D44 RVA: 0x00B15D44 token: 100694260 methodIndex: 24603 delegateWrapperIndex: 0 methodInvoker: 0
    private void LoadServerVer()
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        //  | 
        var val_7;
        // 0x00B15D44: STP x24, x23, [sp, #-0x40]! | stack[1152921515141181584] = ???;  stack[1152921515141181592] = ???;  //  dest_result_addr=1152921515141181584 |  dest_result_addr=1152921515141181592
        // 0x00B15D48: STP x22, x21, [sp, #0x10]  | stack[1152921515141181600] = ???;  stack[1152921515141181608] = ???;  //  dest_result_addr=1152921515141181600 |  dest_result_addr=1152921515141181608
        // 0x00B15D4C: STP x20, x19, [sp, #0x20]  | stack[1152921515141181616] = ???;  stack[1152921515141181624] = ???;  //  dest_result_addr=1152921515141181616 |  dest_result_addr=1152921515141181624
        // 0x00B15D50: STP x29, x30, [sp, #0x30]  | stack[1152921515141181632] = ???;  stack[1152921515141181640] = ???;  //  dest_result_addr=1152921515141181632 |  dest_result_addr=1152921515141181640
        // 0x00B15D54: ADD x29, sp, #0x30         | X29 = (1152921515141181584 + 48) = 1152921515141181632 (0x1000000273E530C0);
        // 0x00B15D58: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B15D5C: LDRB w8, [x20, #0x6db]     | W8 = (bool)static_value_037336DB;       
        // 0x00B15D60: MOV x19, x0                | X19 = 1152921515141193648 (0x1000000273E55FB0);//ML01
        // 0x00B15D64: TBNZ w8, #0, #0xb15d80     | if (static_value_037336DB == true) goto label_0;
        // 0x00B15D68: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00B15D6C: LDR x8, [x8, #0x940]       | X8 = 0x2B8A6D4;                         
        // 0x00B15D70: LDR w0, [x8]               | W0 = 0x73;                              
        // 0x00B15D74: BL #0x2782188              | X0 = sub_2782188( ?? 0x73, ????);       
        // 0x00B15D78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15D7C: STRB w8, [x20, #0x6db]     | static_value_037336DB = true;            //  dest_result_addr=57882331
        label_0:
        // 0x00B15D80: ADRP x20, #0x363a000       | X20 = 56860672 (0x363A000);             
        // 0x00B15D84: LDR x20, [x20, #0x420]     | X20 = 1152921504911425536;              
        // 0x00B15D88: LDR x0, [x20]              | X0 = typeof(VersionMgr);                
        val_6 = null;
        // 0x00B15D8C: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B15D90: TBZ w8, #0, #0xb15da4      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B15D94: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B15D98: CBNZ w8, #0xb15da4         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B15D9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        // 0x00B15DA0: LDR x0, [x20]              | X0 = typeof(VersionMgr);                
        val_6 = null;
        label_2:
        // 0x00B15DA4: LDR x8, [x0, #0xa0]        | X8 = VersionMgr.__il2cppRuntimeField_static_fields;
        // 0x00B15DA8: LDRB w8, [x8, #8]          | W8 = VersionMgr.enabled;                
        // 0x00B15DAC: CBZ w8, #0xb15e14          | if (VersionMgr.enabled == false) goto label_3;
        if(VersionMgr.enabled == false)
        {
            goto label_3;
        }
        // 0x00B15DB0: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B15DB4: TBZ w8, #0, #0xb15dc4      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B15DB8: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B15DBC: CBNZ w8, #0xb15dc4         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B15DC0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_5:
        // 0x00B15DC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15DC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15DCC: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_1 = VersionMgr.Instance;
        // 0x00B15DD0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B15DD4: CBNZ x20, #0xb15ddc        | if (val_1 != null) goto label_6;        
        if(val_1 != null)
        {
            goto label_6;
        }
        // 0x00B15DD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00B15DDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15DE0: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B15DE4: BL #0xe27dac               | X0 = val_1.get_currentVS();             
        VersionInfo val_2 = val_1.currentVS;
        // 0x00B15DE8: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B15DEC: CBNZ x20, #0xb15df4        | if (val_2 != null) goto label_7;        
        if(val_2 != null)
        {
            goto label_7;
        }
        // 0x00B15DF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B15DF4: LDR x8, [x20, #0x40]       | X8 = val_2.assetsvs; //P2               
        // 0x00B15DF8: MOV x0, x19                | X0 = 1152921515141193648 (0x1000000273E55FB0);//ML01
        // 0x00B15DFC: STR x8, [x19, #0x78]       | this.serverVer = val_2.assetsvs;         //  dest_result_addr=1152921515141193768
        this.serverVer = val_2.assetsvs;
        // 0x00B15E00: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B15E04: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B15E08: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B15E0C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B15E10: B #0xb15f20                | this.CheckVer(); return;                
        this.CheckVer();
        return;
        label_3:
        // 0x00B15E14: LDR x20, [x19, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B15E18: CBNZ x20, #0xb15e20        | if (this.sb != null) goto label_8;      
        if(this.sb != null)
        {
            goto label_8;
        }
        // 0x00B15E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(VersionMgr), ????);
        label_8:
        // 0x00B15E20: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B15E24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15E28: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B15E2C: BL #0x1b5ac0c              | this.sb.set_Length(value:  0);          
        this.sb.Length = 0;
        // 0x00B15E30: ADRP x21, #0x35ef000       | X21 = 56553472 (0x35EF000);             
        // 0x00B15E34: LDR x21, [x21, #0xde8]     | X21 = 1152921504911265792;              
        // 0x00B15E38: LDR x20, [x19, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B15E3C: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
        val_7 = null;
        // 0x00B15E40: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B15E44: TBZ w8, #0, #0xb15e58      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B15E48: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B15E4C: CBNZ w8, #0xb15e58         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B15E50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B15E54: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
        val_7 = null;
        label_10:
        // 0x00B15E58: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B15E5C: LDR x21, [x8, #0x70]       | X21 = Loader.PathUtil.SERVER_URL;       
        // 0x00B15E60: CBNZ x20, #0xb15e68        | if (this.sb != null) goto label_11;     
        if(this.sb != null)
        {
            goto label_11;
        }
        // 0x00B15E64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
        label_11:
        // 0x00B15E68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15E6C: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B15E70: MOV x1, x21                | X1 = Loader.PathUtil.SERVER_URL;//m1    
        // 0x00B15E74: BL #0x1b5b818              | X0 = this.sb.Append(value:  Loader.PathUtil.SERVER_URL);
        System.Text.StringBuilder val_3 = this.sb.Append(value:  Loader.PathUtil.SERVER_URL);
        // 0x00B15E78: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B15E7C: CBNZ x20, #0xb15e84        | if (val_3 != null) goto label_12;       
        if(val_3 != null)
        {
            goto label_12;
        }
        // 0x00B15E80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_12:
        // 0x00B15E84: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00B15E88: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921510473501152)("vsnum.uab");
        // 0x00B15E8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15E90: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B15E94: LDR x1, [x8]               | X1 = "vsnum.uab";                       
        // 0x00B15E98: BL #0x1b5b818              | X0 = val_3.Append(value:  "vsnum.uab"); 
        System.Text.StringBuilder val_4 = val_3.Append(value:  "vsnum.uab");
        // 0x00B15E9C: LDR x20, [x19, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B15EA0: CBNZ x20, #0xb15ea8        | if (this.sb != null) goto label_13;     
        if(this.sb != null)
        {
            goto label_13;
        }
        // 0x00B15EA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_13:
        // 0x00B15EA8: LDR x8, [x20]              | X8 = typeof(System.Text.StringBuilder); 
        // 0x00B15EAC: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B15EB0: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
        // 0x00B15EB4: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
        // 0x00B15EB8: MOV x20, x0                | X20 = this.sb;//m1                      
        // 0x00B15EBC: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_5 = AssetDownMgr.Instance;
        // 0x00B15EC0: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00B15EC4: ADRP x9, #0x361c000        | X9 = 56737792 (0x361C000);              
        // 0x00B15EC8: LDR x8, [x8, #0x328]       | X8 = 1152921515141168624;               
        // 0x00B15ECC: LDR x9, [x9, #0x610]       | X9 = 1152921504910786560;               
        // 0x00B15ED0: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B15ED4: LDR x23, [x8]              | X23 = System.Void ABCheckUpdate::<LoadServerVer>m__3(string name, byte[] abBytes);
        // 0x00B15ED8: LDR x8, [x9]               | X8 = typeof(AssetDownMgr.SetBytes);     
        // 0x00B15EDC: MOV x0, x8                 | X0 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B15EE0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetDownMgr.SetBytes), ????);
        // 0x00B15EE4: LDR x8, [x23]              | X8 = System.Void ABCheckUpdate::<LoadServerVer>m__3(string name, byte[] abBytes);
        // 0x00B15EE8: MOV x22, x0                | X22 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B15EEC: STP x19, x23, [x22, #0x20] | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;  typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadServerVer>m__3(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786592 |  dest_result_addr=1152921504910786600
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadServerVer>m__3(string name, byte[] abBytes);
        // 0x00B15EF0: STR x8, [x22, #0x10]       | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadServerVer>m__3(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786576
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadServerVer>m__3(string name, byte[] abBytes);
        // 0x00B15EF4: CBNZ x21, #0xb15efc        | if (val_5 != null) goto label_14;       
        if(val_5 != null)
        {
            goto label_14;
        }
        // 0x00B15EF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AssetDownMgr.SetBytes), ????);
        label_14:
        // 0x00B15EFC: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B15F00: MOV x1, x20                | X1 = this.sb;//m1                       
        // 0x00B15F04: MOV x2, x22                | X2 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B15F08: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B15F0C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B15F10: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B15F14: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B15F18: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B15F1C: B #0xb15ab0                | val_5.AddUpdateData(path:  this.sb, downFinishCall:  null, isInsert:  false); return;
        val_5.AddUpdateData(path:  this.sb, downFinishCall:  null, isInsert:  false);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15F20 (11624224), len: 456  VirtAddr: 0x00B15F20 RVA: 0x00B15F20 token: 100694261 methodIndex: 24604 delegateWrapperIndex: 0 methodInvoker: 0
    private void CheckVer()
    {
        //
        // Disasemble & Code
        // 0x00B15F20: STP x22, x21, [sp, #-0x30]! | stack[1152921515141346992] = ???;  stack[1152921515141347000] = ???;  //  dest_result_addr=1152921515141346992 |  dest_result_addr=1152921515141347000
        // 0x00B15F24: STP x20, x19, [sp, #0x10]  | stack[1152921515141347008] = ???;  stack[1152921515141347016] = ???;  //  dest_result_addr=1152921515141347008 |  dest_result_addr=1152921515141347016
        // 0x00B15F28: STP x29, x30, [sp, #0x20]  | stack[1152921515141347024] = ???;  stack[1152921515141347032] = ???;  //  dest_result_addr=1152921515141347024 |  dest_result_addr=1152921515141347032
        // 0x00B15F2C: ADD x29, sp, #0x20         | X29 = (1152921515141346992 + 32) = 1152921515141347024 (0x1000000273E7B6D0);
        // 0x00B15F30: SUB sp, sp, #0x10          | SP = (1152921515141346992 - 16) = 1152921515141346976 (0x1000000273E7B6A0);
        // 0x00B15F34: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B15F38: LDRB w8, [x20, #0x6dc]     | W8 = (bool)static_value_037336DC;       
        // 0x00B15F3C: MOV x19, x0                | X19 = 1152921515141359040 (0x1000000273E7E5C0);//ML01
        // 0x00B15F40: TBNZ w8, #0, #0xb15f5c     | if (static_value_037336DC == true) goto label_0;
        // 0x00B15F44: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00B15F48: LDR x8, [x8, #0xe60]       | X8 = 0x2B8A69C;                         
        // 0x00B15F4C: LDR w0, [x8]               | W0 = 0x65;                              
        // 0x00B15F50: BL #0x2782188              | X0 = sub_2782188( ?? 0x65, ????);       
        // 0x00B15F54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15F58: STRB w8, [x20, #0x6dc]     | static_value_037336DC = true;            //  dest_result_addr=57882332
        label_0:
        // 0x00B15F5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15F60: STRB w8, [x19, #0xa8]      | this.isloadServer = true;                //  dest_result_addr=1152921515141359208
        this.isloadServer = true;
        // 0x00B15F64: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B15F68: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B15F6C: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x00B15F70: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B15F74: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B15F78: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B15F7C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B15F80: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B15F84: LDR x21, [x19, #0x58]      | X21 = this.clientVer; //P2              
        // 0x00B15F88: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B15F8C: CBNZ x20, #0xb15f94        | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x00B15F90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_1:
        // 0x00B15F94: CBZ x21, #0xb15fb8         | if (this.clientVer == null) goto label_3;
        if(this.clientVer == null)
        {
            goto label_3;
        }
        // 0x00B15F98: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B15F9C: MOV x0, x21                | X0 = this.clientVer;//m1                
        // 0x00B15FA0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B15FA4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.clientVer, ????);
        // 0x00B15FA8: CBNZ x0, #0xb15fb8         | if (this.clientVer != null) goto label_3;
        if(this.clientVer != null)
        {
            goto label_3;
        }
        // 0x00B15FAC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.clientVer, ????);
        // 0x00B15FB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15FB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.clientVer, ????);
        label_3:
        // 0x00B15FB8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B15FBC: CBNZ w8, #0xb15fcc         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_4;
        // 0x00B15FC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.clientVer, ????);
        // 0x00B15FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15FC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.clientVer, ????);
        label_4:
        // 0x00B15FCC: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = this.clientVer;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = this.clientVer;
        // 0x00B15FD0: LDR x21, [x19, #0x78]      | X21 = this.serverVer; //P2              
        // 0x00B15FD4: CBZ x21, #0xb15ff8         | if (this.serverVer == null) goto label_6;
        if(this.serverVer == null)
        {
            goto label_6;
        }
        // 0x00B15FD8: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B15FDC: MOV x0, x21                | X0 = this.serverVer;//m1                
        // 0x00B15FE0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B15FE4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.serverVer, ????);
        // 0x00B15FE8: CBNZ x0, #0xb15ff8         | if (this.serverVer != null) goto label_6;
        if(this.serverVer != null)
        {
            goto label_6;
        }
        // 0x00B15FEC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.serverVer, ????);
        // 0x00B15FF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15FF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.serverVer, ????);
        label_6:
        // 0x00B15FF8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B15FFC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B16000: B.HI #0xb16010             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_7;
        // 0x00B16004: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.serverVer, ????);
        // 0x00B16008: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1600C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.serverVer, ????);
        label_7:
        // 0x00B16010: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = this.serverVer;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = this.serverVer;
        // 0x00B16014: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
        // 0x00B16018: LDRB w8, [x19, #0xa8]      | W8 = this.isloadServer; //P2            
        // 0x00B1601C: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
        // 0x00B16020: ADD x1, sp, #0xf           | X1 = (1152921515141346976 + 15) = 1152921515141346991 (0x1000000273E7B6AF);
        // 0x00B16024: STRB w8, [sp, #0xf]        | stack[1152921515141346991] = this.isloadServer;  //  dest_result_addr=1152921515141346991
        // 0x00B16028: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
        // 0x00B1602C: BL #0x27bc028              | X0 = 1152921515141399232 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), this.isloadServer);
        // 0x00B16030: MOV x21, x0                | X21 = 1152921515141399232 (0x1000000273E882C0);//ML01
        // 0x00B16034: CBZ x21, #0xb16058         | if (this.isloadServer == false) goto label_9;
        if(this.isloadServer == false)
        {
            goto label_9;
        }
        // 0x00B16038: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B1603C: MOV x0, x21                | X0 = 1152921515141399232 (0x1000000273E882C0);//ML01
        // 0x00B16040: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B16044: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.isloadServer, ????);
        // 0x00B16048: CBNZ x0, #0xb16058         | if (this.isloadServer == true) goto label_9;
        if(this.isloadServer == true)
        {
            goto label_9;
        }
        // 0x00B1604C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.isloadServer, ????);
        // 0x00B16050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16054: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.isloadServer, ????);
        label_9:
        // 0x00B16058: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B1605C: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B16060: B.HI #0xb16070             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_10;
        // 0x00B16064: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.isloadServer, ????);
        // 0x00B16068: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1606C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.isloadServer, ????);
        label_10:
        // 0x00B16070: STR x21, [x20, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = this.isloadServer; typeof(System.Object[]).__il2cppRuntimeField_31 = 0x1000000273E882;  //  dest_result_addr=1152921504954501312 dest_result_addr=1152921504954501313
        typeof(System.Object[]).__il2cppRuntimeField_30 = this.isloadServer;
        typeof(System.Object[]).__il2cppRuntimeField_31 = 41150594;
        // 0x00B16074: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
        // 0x00B16078: LDR x8, [x8, #0x858]       | X8 = (string**)(1152921515141330800)("本地版本：{0} 服务器版本：{1} isloadServer:{2}");
        // 0x00B1607C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16080: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B16084: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B16088: LDR x1, [x8]               | X1 = "本地版本：{0} 服务器版本：{1} isloadServer:{2}";
        // 0x00B1608C: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "本地版本：{0} 服务器版本：{1} isloadServer:{2}");
        string val_1 = EString.EFormat(format:  0, args:  "本地版本：{0} 服务器版本：{1} isloadServer:{2}");
        // 0x00B16090: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B16094: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B16098: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B1609C: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B160A0: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B160A4: TBZ w9, #0, #0xb160b8      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B160A8: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B160AC: CBNZ w9, #0xb160b8         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B160B0: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B160B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_12:
        // 0x00B160B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B160BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B160C0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B160C4: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00B160C8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_1);
        EDebug.Log(message:  0, isShowStack:  val_1);
        // 0x00B160CC: MOV x0, x19                | X0 = 1152921515141359040 (0x1000000273E7E5C0);//ML01
        // 0x00B160D0: BL #0xb160e8               | this.LoadClientVS();                    
        this.LoadClientVS();
        // 0x00B160D4: SUB sp, x29, #0x20         | SP = (1152921515141347024 - 32) = 1152921515141346992 (0x1000000273E7B6B0);
        // 0x00B160D8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B160DC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B160E0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B160E4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B160E8 (11624680), len: 220  VirtAddr: 0x00B160E8 RVA: 0x00B160E8 token: 100694262 methodIndex: 24605 delegateWrapperIndex: 0 methodInvoker: 0
    private void LoadClientVS()
    {
        //
        // Disasemble & Code
        // 0x00B160E8: STP x24, x23, [sp, #-0x40]! | stack[1152921515141484576] = ???;  stack[1152921515141484584] = ???;  //  dest_result_addr=1152921515141484576 |  dest_result_addr=1152921515141484584
        // 0x00B160EC: STP x22, x21, [sp, #0x10]  | stack[1152921515141484592] = ???;  stack[1152921515141484600] = ???;  //  dest_result_addr=1152921515141484592 |  dest_result_addr=1152921515141484600
        // 0x00B160F0: STP x20, x19, [sp, #0x20]  | stack[1152921515141484608] = ???;  stack[1152921515141484616] = ???;  //  dest_result_addr=1152921515141484608 |  dest_result_addr=1152921515141484616
        // 0x00B160F4: STP x29, x30, [sp, #0x30]  | stack[1152921515141484624] = ???;  stack[1152921515141484632] = ???;  //  dest_result_addr=1152921515141484624 |  dest_result_addr=1152921515141484632
        // 0x00B160F8: ADD x29, sp, #0x30         | X29 = (1152921515141484576 + 48) = 1152921515141484624 (0x1000000273E9D050);
        // 0x00B160FC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B16100: LDRB w8, [x20, #0x6dd]     | W8 = (bool)static_value_037336DD;       
        // 0x00B16104: MOV x19, x0                | X19 = 1152921515141496640 (0x1000000273E9FF40);//ML01
        // 0x00B16108: TBNZ w8, #0, #0xb16124     | if (static_value_037336DD == true) goto label_0;
        // 0x00B1610C: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00B16110: LDR x8, [x8, #0x900]       | X8 = 0x2B8A6CC;                         
        // 0x00B16114: LDR w0, [x8]               | W0 = 0x71;                              
        // 0x00B16118: BL #0x2782188              | X0 = sub_2782188( ?? 0x71, ????);       
        // 0x00B1611C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B16120: STRB w8, [x20, #0x6dd]     | static_value_037336DD = true;            //  dest_result_addr=57882333
        label_0:
        // 0x00B16124: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B16128: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B1612C: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        // 0x00B16130: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B16134: TBZ w8, #0, #0xb16144      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B16138: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B1613C: CBNZ w8, #0xb16144         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B16140: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        label_2:
        // 0x00B16144: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B16148: LDR x8, [x8, #0x8b8]       | X8 = (string**)(1152921510473621280)("vsconfig.uab");
        // 0x00B1614C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16150: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B16154: LDR x1, [x8]               | X1 = "vsconfig.uab";                    
        // 0x00B16158: BL #0xdbc79c               | X0 = Loader.PathUtil.StreamingAssetsPath(path:  0);
        string val_1 = Loader.PathUtil.StreamingAssetsPath(path:  0);
        // 0x00B1615C: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B16160: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_2 = AssetDownMgr.Instance;
        // 0x00B16164: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B16168: ADRP x9, #0x361c000        | X9 = 56737792 (0x361C000);              
        // 0x00B1616C: LDR x8, [x8, #0xc38]       | X8 = 1152921515141471616;               
        // 0x00B16170: LDR x9, [x9, #0x610]       | X9 = 1152921504910786560;               
        // 0x00B16174: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00B16178: LDR x23, [x8]              | X23 = System.Void ABCheckUpdate::<LoadClientVS>m__4(string name, byte[] abBytes);
        // 0x00B1617C: LDR x8, [x9]               | X8 = typeof(AssetDownMgr.SetBytes);     
        // 0x00B16180: MOV x0, x8                 | X0 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B16184: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetDownMgr.SetBytes), ????);
        // 0x00B16188: LDR x8, [x23]              | X8 = System.Void ABCheckUpdate::<LoadClientVS>m__4(string name, byte[] abBytes);
        // 0x00B1618C: MOV x22, x0                | X22 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B16190: STP x19, x23, [x22, #0x20] | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;  typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadClientVS>m__4(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786592 |  dest_result_addr=1152921504910786600
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadClientVS>m__4(string name, byte[] abBytes);
        // 0x00B16194: STR x8, [x22, #0x10]       | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadClientVS>m__4(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786576
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadClientVS>m__4(string name, byte[] abBytes);
        // 0x00B16198: CBNZ x21, #0xb161a0        | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x00B1619C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AssetDownMgr.SetBytes), ????);
        label_3:
        // 0x00B161A0: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00B161A4: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00B161A8: MOV x2, x22                | X2 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B161AC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B161B0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B161B4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B161B8: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B161BC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B161C0: B #0xb15ab0                | val_2.AddUpdateData(path:  val_1, downFinishCall:  null, isInsert:  false); return;
        val_2.AddUpdateData(path:  val_1, downFinishCall:  null, isInsert:  false);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B161C4 (11624900), len: 568  VirtAddr: 0x00B161C4 RVA: 0x00B161C4 token: 100694263 methodIndex: 24606 delegateWrapperIndex: 0 methodInvoker: 0
    private void LoadServerVS()
    {
        //
        // Disasemble & Code
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        string val_13;
        // 0x00B161C4: STP x24, x23, [sp, #-0x40]! | stack[1152921515141650848] = ???;  stack[1152921515141650856] = ???;  //  dest_result_addr=1152921515141650848 |  dest_result_addr=1152921515141650856
        // 0x00B161C8: STP x22, x21, [sp, #0x10]  | stack[1152921515141650864] = ???;  stack[1152921515141650872] = ???;  //  dest_result_addr=1152921515141650864 |  dest_result_addr=1152921515141650872
        // 0x00B161CC: STP x20, x19, [sp, #0x20]  | stack[1152921515141650880] = ???;  stack[1152921515141650888] = ???;  //  dest_result_addr=1152921515141650880 |  dest_result_addr=1152921515141650888
        // 0x00B161D0: STP x29, x30, [sp, #0x30]  | stack[1152921515141650896] = ???;  stack[1152921515141650904] = ???;  //  dest_result_addr=1152921515141650896 |  dest_result_addr=1152921515141650904
        // 0x00B161D4: ADD x29, sp, #0x30         | X29 = (1152921515141650848 + 48) = 1152921515141650896 (0x1000000273EC59D0);
        // 0x00B161D8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B161DC: LDRB w8, [x20, #0x6de]     | W8 = (bool)static_value_037336DE;       
        // 0x00B161E0: MOV x19, x0                | X19 = 1152921515141662912 (0x1000000273EC88C0);//ML01
        // 0x00B161E4: TBNZ w8, #0, #0xb16200     | if (static_value_037336DE == true) goto label_0;
        // 0x00B161E8: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00B161EC: LDR x8, [x8, #0xb00]       | X8 = 0x2B8A6D8;                         
        // 0x00B161F0: LDR w0, [x8]               | W0 = 0x74;                              
        // 0x00B161F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x74, ????);       
        // 0x00B161F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B161FC: STRB w8, [x20, #0x6de]     | static_value_037336DE = true;            //  dest_result_addr=57882334
        label_0:
        // 0x00B16200: LDR x20, [x19, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B16204: CBNZ x20, #0xb1620c        | if (this.sb != null) goto label_1;      
        if(this.sb != null)
        {
            goto label_1;
        }
        // 0x00B16208: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x74, ????);       
        label_1:
        // 0x00B1620C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B16210: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B16214: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B16218: BL #0x1b5ac0c              | this.sb.set_Length(value:  0);          
        this.sb.Length = 0;
        // 0x00B1621C: ADRP x21, #0x35ef000       | X21 = 56553472 (0x35EF000);             
        // 0x00B16220: LDR x21, [x21, #0xde8]     | X21 = 1152921504911265792;              
        // 0x00B16224: LDR x20, [x19, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B16228: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
        val_11 = null;
        // 0x00B1622C: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B16230: TBZ w8, #0, #0xb16244      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B16234: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B16238: CBNZ w8, #0xb16244         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B1623C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B16240: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
        val_11 = null;
        label_3:
        // 0x00B16244: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B16248: LDR x21, [x8, #0x70]       | X21 = Loader.PathUtil.SERVER_URL;       
        // 0x00B1624C: CBNZ x20, #0xb16254        | if (this.sb != null) goto label_4;      
        if(this.sb != null)
        {
            goto label_4;
        }
        // 0x00B16250: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
        label_4:
        // 0x00B16254: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B16258: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B1625C: MOV x1, x21                | X1 = Loader.PathUtil.SERVER_URL;//m1    
        // 0x00B16260: BL #0x1b5b818              | X0 = this.sb.Append(value:  Loader.PathUtil.SERVER_URL);
        System.Text.StringBuilder val_1 = this.sb.Append(value:  Loader.PathUtil.SERVER_URL);
        // 0x00B16264: ADRP x22, #0x363a000       | X22 = 56860672 (0x363A000);             
        // 0x00B16268: LDR x22, [x22, #0x420]     | X22 = 1152921504911425536;              
        // 0x00B1626C: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B16270: LDR x8, [x22]              | X8 = typeof(VersionMgr);                
        // 0x00B16274: LDRB w9, [x8, #0x10a]      | W9 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B16278: TBZ w9, #0, #0xb1628c      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B1627C: LDR w9, [x8, #0xbc]        | W9 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B16280: CBNZ w9, #0xb1628c         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B16284: MOV x0, x8                 | X0 = 1152921504911425536 (0x1000000012278000);//ML01
        // 0x00B16288: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_6:
        // 0x00B1628C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16290: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16294: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_2 = VersionMgr.Instance;
        // 0x00B16298: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00B1629C: CBNZ x21, #0xb162a4        | if (val_2 != null) goto label_7;        
        if(val_2 != null)
        {
            goto label_7;
        }
        // 0x00B162A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B162A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B162A8: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00B162AC: BL #0xe27dac               | X0 = val_2.get_currentVS();             
        VersionInfo val_3 = val_2.currentVS;
        // 0x00B162B0: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B162B4: CBNZ x21, #0xb162bc        | if (val_3 != null) goto label_8;        
        if(val_3 != null)
        {
            goto label_8;
        }
        // 0x00B162B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B162BC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B162C0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B162C4: LDR x21, [x21, #0xd0]      | X21 = val_3.vscfg; //P2                 
        // 0x00B162C8: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B162CC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B162D0: TBZ w8, #0, #0xb162e0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B162D4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B162D8: CBNZ w8, #0xb162e0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B162DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_10:
        // 0x00B162E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B162E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B162E8: MOV x1, x21                | X1 = val_3.vscfg;//m1                   
        // 0x00B162EC: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_4 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B162F0: TST w0, #1                 | STATE = COMPARE(val_4, 0x1)             
        // 0x00B162F4: CSEL x21, xzr, x20, ne     | X21 = val_4 != true ? 0 : val_1;        
        var val_5 = (val_4 != true) ? 0 : (val_1);
        // 0x00B162F8: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        bool val_6 = val_4;
        // 0x00B162FC: TBZ w8, #0, #0xb16310      | if ((val_4 & 1) == false) goto label_11;
        if(val_6 == false)
        {
            goto label_11;
        }
        // 0x00B16300: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B16304: LDR x8, [x8, #0x8b8]       | X8 = (string**)(1152921510473621280)("vsconfig.uab");
        val_13 = "vsconfig.uab";
        // 0x00B16308: MOV x21, x20               | X21 = val_1;//m1                        
        val_12 = val_1;
        // 0x00B1630C: B #0xb1635c                |  goto label_12;                         
        goto label_12;
        label_11:
        // 0x00B16310: LDR x0, [x22]              | X0 = typeof(VersionMgr);                
        // 0x00B16314: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B16318: TBZ w8, #0, #0xb16328      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B1631C: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B16320: CBNZ w8, #0xb16328         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B16324: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_14:
        // 0x00B16328: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1632C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16330: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_7 = VersionMgr.Instance;
        // 0x00B16334: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B16338: CBNZ x20, #0xb16340        | if (val_7 != null) goto label_15;       
        if(val_7 != null)
        {
            goto label_15;
        }
        // 0x00B1633C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_15:
        // 0x00B16340: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16344: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00B16348: BL #0xe27dac               | X0 = val_7.get_currentVS();             
        VersionInfo val_8 = val_7.currentVS;
        // 0x00B1634C: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B16350: CBNZ x20, #0xb16358        | if (val_8 != null) goto label_16;       
        if(val_8 != null)
        {
            goto label_16;
        }
        // 0x00B16354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_16:
        // 0x00B16358: ADD x8, x20, #0xd0         | X8 = val_8.vscfg;//AP2 res_addr=207     
        val_13 = val_8.vscfg;
        label_12:
        // 0x00B1635C: LDR x20, [x8]              |  //  not_find_field!1:0
        // 0x00B16360: CBNZ x21, #0xb16368        | if (val_4 != true ? 0 : val_1 != 0) goto label_17;
        if(val_5 != 0)
        {
            goto label_17;
        }
        // 0x00B16364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_17:
        // 0x00B16368: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1636C: MOV x0, x21                | X0 = val_4 != true ? 0 : val_1;//m1     
        // 0x00B16370: MOV x1, x20                | X1 = mem[val_8.vscfg];//m1              
        // 0x00B16374: BL #0x1b5b818              | X0 = val_4 != true ? 0 : val_1.Append(value:  mem[val_8.vscfg]);
        System.Text.StringBuilder val_9 = val_5.Append(value:  mem[val_8.vscfg]);
        // 0x00B16378: LDR x20, [x19, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B1637C: CBNZ x20, #0xb16384        | if (this.sb != null) goto label_18;     
        if(this.sb != null)
        {
            goto label_18;
        }
        // 0x00B16380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_18:
        // 0x00B16384: LDR x8, [x20]              | X8 = typeof(System.Text.StringBuilder); 
        // 0x00B16388: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B1638C: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
        // 0x00B16390: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
        // 0x00B16394: MOV x20, x0                | X20 = this.sb;//m1                      
        // 0x00B16398: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_10 = AssetDownMgr.Instance;
        // 0x00B1639C: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x00B163A0: ADRP x9, #0x361c000        | X9 = 56737792 (0x361C000);              
        // 0x00B163A4: LDR x8, [x8, #0x528]       | X8 = 1152921515141637888;               
        // 0x00B163A8: LDR x9, [x9, #0x610]       | X9 = 1152921504910786560;               
        // 0x00B163AC: MOV x21, x0                | X21 = val_10;//m1                       
        // 0x00B163B0: LDR x23, [x8]              | X23 = System.Void ABCheckUpdate::<LoadServerVS>m__5(string name, byte[] abBytes);
        // 0x00B163B4: LDR x8, [x9]               | X8 = typeof(AssetDownMgr.SetBytes);     
        // 0x00B163B8: MOV x0, x8                 | X0 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B163BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetDownMgr.SetBytes), ????);
        // 0x00B163C0: LDR x8, [x23]              | X8 = System.Void ABCheckUpdate::<LoadServerVS>m__5(string name, byte[] abBytes);
        // 0x00B163C4: MOV x22, x0                | X22 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B163C8: STP x19, x23, [x22, #0x20] | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;  typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadServerVS>m__5(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786592 |  dest_result_addr=1152921504910786600
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadServerVS>m__5(string name, byte[] abBytes);
        // 0x00B163CC: STR x8, [x22, #0x10]       | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadServerVS>m__5(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786576
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadServerVS>m__5(string name, byte[] abBytes);
        // 0x00B163D0: CBNZ x21, #0xb163d8        | if (val_10 != null) goto label_19;      
        if(val_10 != null)
        {
            goto label_19;
        }
        // 0x00B163D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AssetDownMgr.SetBytes), ????);
        label_19:
        // 0x00B163D8: MOV x0, x21                | X0 = val_10;//m1                        
        // 0x00B163DC: MOV x1, x20                | X1 = this.sb;//m1                       
        // 0x00B163E0: MOV x2, x22                | X2 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B163E4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B163E8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B163EC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B163F0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B163F4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B163F8: B #0xb15ab0                | val_10.AddUpdateData(path:  this.sb, downFinishCall:  null, isInsert:  false); return;
        val_10.AddUpdateData(path:  this.sb, downFinishCall:  null, isInsert:  false);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B163FC (11625468), len: 4244  VirtAddr: 0x00B163FC RVA: 0x00B163FC token: 100694264 methodIndex: 24607 delegateWrapperIndex: 0 methodInvoker: 0
    private void Check()
    {
        //
        // Disasemble & Code
        //  | 
        var val_85;
        //  | 
        FileInfoCrc val_86;
        //  | 
        var val_87;
        //  | 
        var val_88;
        //  | 
        var val_89;
        //  | 
        var val_90;
        // 0x00B163FC: STP d9, d8, [sp, #-0x70]!  | stack[1152921515142270800] = ???;  stack[1152921515142270808] = ???;  //  dest_result_addr=1152921515142270800 |  dest_result_addr=1152921515142270808
        // 0x00B16400: STP x28, x27, [sp, #0x10]  | stack[1152921515142270816] = ???;  stack[1152921515142270824] = ???;  //  dest_result_addr=1152921515142270816 |  dest_result_addr=1152921515142270824
        // 0x00B16404: STP x26, x25, [sp, #0x20]  | stack[1152921515142270832] = ???;  stack[1152921515142270840] = ???;  //  dest_result_addr=1152921515142270832 |  dest_result_addr=1152921515142270840
        // 0x00B16408: STP x24, x23, [sp, #0x30]  | stack[1152921515142270848] = ???;  stack[1152921515142270856] = ???;  //  dest_result_addr=1152921515142270848 |  dest_result_addr=1152921515142270856
        // 0x00B1640C: STP x22, x21, [sp, #0x40]  | stack[1152921515142270864] = ???;  stack[1152921515142270872] = ???;  //  dest_result_addr=1152921515142270864 |  dest_result_addr=1152921515142270872
        // 0x00B16410: STP x20, x19, [sp, #0x50]  | stack[1152921515142270880] = ???;  stack[1152921515142270888] = ???;  //  dest_result_addr=1152921515142270880 |  dest_result_addr=1152921515142270888
        // 0x00B16414: STP x29, x30, [sp, #0x60]  | stack[1152921515142270896] = ???;  stack[1152921515142270904] = ???;  //  dest_result_addr=1152921515142270896 |  dest_result_addr=1152921515142270904
        // 0x00B16418: ADD x29, sp, #0x60         | X29 = (1152921515142270800 + 96) = 1152921515142270896 (0x1000000273F5CFB0);
        // 0x00B1641C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B16420: LDRB w8, [x20, #0x6df]     | W8 = (bool)static_value_037336DF;       
        // 0x00B16424: MOV x19, x0                | X19 = 1152921515142282912 (0x1000000273F5FEA0);//ML01
        // 0x00B16428: TBNZ w8, #0, #0xb16444     | if (static_value_037336DF == true) goto label_0;
        // 0x00B1642C: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
        // 0x00B16430: LDR x8, [x8, #0x278]       | X8 = 0x2B8A694;                         
        // 0x00B16434: LDR w0, [x8]               | W0 = 0x63;                              
        // 0x00B16438: BL #0x2782188              | X0 = sub_2782188( ?? 0x63, ????);       
        // 0x00B1643C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B16440: STRB w8, [x20, #0x6df]     | static_value_037336DF = true;            //  dest_result_addr=57882335
        label_0:
        // 0x00B16444: ADRP x21, #0x3646000       | X21 = 56909824 (0x3646000);             
        // 0x00B16448: LDR x21, [x21, #0x540]     | X21 = 1152921504616644608;              
        // 0x00B1644C: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        // 0x00B16450: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B16454: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B16458: ADRP x22, #0x3605000       | X22 = 56643584 (0x3605000);             
        // 0x00B1645C: LDR x22, [x22, #0x1b0]     | X22 = 1152921514959159984;              
        // 0x00B16460: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<FileInfoRes>::.ctor();
        // 0x00B16464: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
        System.Collections.Generic.List<FileInfoRes> val_1 = null;
        // 0x00B16468: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<FileInfoRes>();
        // 0x00B1646C: STR x20, [x19, #0x88]      | this.updateList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515142283048
        this.updateList = null;
        // 0x00B16470: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        // 0x00B16474: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B16478: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B1647C: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<FileInfoRes>::.ctor();
        // 0x00B16480: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
        System.Collections.Generic.List<FileInfoRes> val_2 = null;
        // 0x00B16484: BL #0x25e9474              | .ctor();                                
        val_2 = new System.Collections.Generic.List<FileInfoRes>();
        // 0x00B16488: STR x20, [x19, #0x90]      | this.csscriptList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515142283056
        this.csscriptList = null;
        // 0x00B1648C: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        // 0x00B16490: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B16494: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B16498: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<FileInfoRes>::.ctor();
        // 0x00B1649C: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
        System.Collections.Generic.List<FileInfoRes> val_3 = null;
        // 0x00B164A0: BL #0x25e9474              | .ctor();                                
        val_3 = new System.Collections.Generic.List<FileInfoRes>();
        // 0x00B164A4: STR x20, [x19, #0x68]      | this.removeList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515142283016
        this.removeList = null;
        // 0x00B164A8: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x00B164AC: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
        // 0x00B164B0: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        // 0x00B164B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B164B8: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B164BC: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x00B164C0: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
        // 0x00B164C4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
        // 0x00B164C8: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
        System.Collections.Generic.List<System.String> val_4 = null;
        // 0x00B164CC: BL #0x25e9474              | .ctor();                                
        val_4 = new System.Collections.Generic.List<System.String>();
        // 0x00B164D0: MOV x0, x19                | X0 = 1152921515142282912 (0x1000000273F5FEA0);//ML01
        // 0x00B164D4: BL #0xb17490               | this.CheckSOHook();                     
        this.CheckSOHook();
        // 0x00B164D8: LDR x21, [x19, #0x28]      | X21 = this.serverList; //P2             
        // 0x00B164DC: CBNZ x21, #0xb164e4        | if (this.serverList != null) goto label_1;
        if(this.serverList != null)
        {
            goto label_1;
        }
        // 0x00B164E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_1:
        // 0x00B164E4: LDR x21, [x21, #0x10]      | 
        // 0x00B164E8: CBNZ x21, #0xb164f0        | if (this.serverList != null) goto label_2;
        if(this.serverList != null)
        {
            goto label_2;
        }
        // 0x00B164EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x00B164F0: ADRP x26, #0x35fc000       | X26 = 56606720 (0x35FC000);             
        // 0x00B164F4: LDR x26, [x26, #0xb58]     | X26 = 1152921510022759280;              
        // 0x00B164F8: LDR x1, [x26]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B164FC: MOV x0, x21                | X0 = this.serverList;//m1               
        // 0x00B16500: BL #0x25ed72c              | X0 = this.serverList.get_Count();       
        int val_5 = this.serverList.Count;
        // 0x00B16504: MOV w21, w0                | W21 = val_5;//m1                        
        // 0x00B16508: CMP w21, #1                | STATE = COMPARE(val_5, 0x1)             
        // 0x00B1650C: B.LT #0xb17240             | if (val_5 < 1) goto label_133;          
        if(val_5 < 1)
        {
            goto label_133;
        }
        // 0x00B16510: ADRP x27, #0x35bd000       | X27 = 56348672 (0x35BD000);             
        // 0x00B16514: ADRP x28, #0x35cc000       | X28 = 56410112 (0x35CC000);             
        // 0x00B16518: LDR x27, [x27, #0xb50]     | X27 = 1152921510890998992;              
        // 0x00B1651C: LDR x28, [x28, #0x7d8]     | X28 = 1152921514959025456;              
        // 0x00B16520: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        string val_86 = 0;
        // 0x00B16524: SCVTF s8, w21              | S8 = (float)(val_5);                    
        label_132:
        // 0x00B16528: LDR x23, [x19, #0x20]      | X23 = this.clientList; //P2             
        // 0x00B1652C: SCVTF s0, w22              | S0 = 0;                                 
        float val_85 = 0f;
        // 0x00B16530: FDIV s0, s0, s8            | S0 = (0f / val_5);                      
        val_85 = val_85 / (float)val_5;
        // 0x00B16534: STR s0, [x19, #0xac]       | this.<VerifyProgress>k__BackingField = (0f / val_5);  //  dest_result_addr=1152921515142283084
        this.<VerifyProgress>k__BackingField = val_85;
        // 0x00B16538: CBNZ x23, #0xb16540        | if (this.clientList != null) goto label_4;
        if(this.clientList != null)
        {
            goto label_4;
        }
        // 0x00B1653C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_4:
        // 0x00B16540: LDR x23, [x23, #0x10]      | 
        // 0x00B16544: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B16548: CBNZ x24, #0xb16550        | if (this.serverList != null) goto label_5;
        if(this.serverList != null)
        {
            goto label_5;
        }
        // 0x00B1654C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_5:
        // 0x00B16550: LDR x24, [x24, #0x10]      | 
        // 0x00B16554: CBNZ x24, #0xb1655c        | if (this.serverList != null) goto label_6;
        if(this.serverList != null)
        {
            goto label_6;
        }
        // 0x00B16558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x00B1655C: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B16560: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B16564: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16568: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        string val_6 = this.serverList.Item[0];
        // 0x00B1656C: MOV x24, x0                | X24 = val_6;//m1                        
        // 0x00B16570: CBNZ x23, #0xb16578        | if (this.clientList != null) goto label_7;
        if(this.clientList != null)
        {
            goto label_7;
        }
        // 0x00B16574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_7:
        // 0x00B16578: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x00B1657C: LDR x8, [x8, #0xf00]       | X8 = 1152921510891359184;               
        // 0x00B16580: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
        // 0x00B16584: MOV x0, x23                | X0 = this.clientList;//m1               
        // 0x00B16588: MOV x1, x24                | X1 = val_6;//m1                         
        // 0x00B1658C: BL #0x25ead74              | X0 = this.clientList.Contains(item:  val_6);
        bool val_7 = this.clientList.Contains(item:  val_6);
        // 0x00B16590: TBZ w0, #0, #0xb165e8      | if (val_7 == false) goto label_8;       
        if(val_7 == false)
        {
            goto label_8;
        }
        // 0x00B16594: LDP x23, x24, [x19, #0x20] | X23 = this.clientList; //P2  X24 = this.serverList; //P2  //  | 
        // 0x00B16598: CBNZ x24, #0xb165a0        | if (this.serverList != null) goto label_9;
        if(this.serverList != null)
        {
            goto label_9;
        }
        // 0x00B1659C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00B165A0: LDR x24, [x24, #0x10]      | 
        // 0x00B165A4: CBNZ x24, #0xb165ac        | if (this.serverList != null) goto label_10;
        if(this.serverList != null)
        {
            goto label_10;
        }
        // 0x00B165A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_10:
        // 0x00B165AC: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B165B0: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B165B4: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B165B8: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        string val_8 = this.serverList.Item[0];
        // 0x00B165BC: MOV x24, x0                | X24 = val_8;//m1                        
        // 0x00B165C0: CBNZ x23, #0xb165c8        | if (this.clientList != null) goto label_11;
        if(this.clientList != null)
        {
            goto label_11;
        }
        // 0x00B165C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_11:
        // 0x00B165C8: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
        // 0x00B165CC: LDR x8, [x8, #0x518]       | X8 = 1152921515141824640;               
        // 0x00B165D0: LDR x2, [x8]               | X2 = public FileInfoRes Filelist<FileInfoRes>::GetResData(string fileName);
        // 0x00B165D4: MOV x0, x23                | X0 = this.clientList;//m1               
        // 0x00B165D8: MOV x1, x24                | X1 = val_8;//m1                         
        // 0x00B165DC: BL #0x19cd75c              | X0 = this.clientList.GetResData(fileName:  val_8);
        FileInfoRes val_9 = this.clientList.GetResData(fileName:  val_8);
        // 0x00B165E0: MOV x23, x0                | X23 = val_9;//m1                        
        val_85 = val_9;
        // 0x00B165E4: B #0xb165ec                |  goto label_12;                         
        goto label_12;
        label_8:
        // 0x00B165E8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_85 = 0;
        label_12:
        // 0x00B165EC: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B165F0: CBNZ x24, #0xb165f8        | if (this.serverList != null) goto label_13;
        if(this.serverList != null)
        {
            goto label_13;
        }
        // 0x00B165F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_13:
        // 0x00B165F8: LDR x24, [x24, #0x18]      | 
        // 0x00B165FC: CBNZ x24, #0xb16604        | if (this.serverList != null) goto label_14;
        if(this.serverList != null)
        {
            goto label_14;
        }
        // 0x00B16600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_14:
        // 0x00B16604: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B16608: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B1660C: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16610: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_10 = this.serverList.Item[0];
        // 0x00B16614: MOV x24, x0                | X24 = val_10;//m1                       
        // 0x00B16618: CBNZ x24, #0xb16620        | if (val_10 != null) goto label_15;      
        if(val_10 != null)
        {
            goto label_15;
        }
        // 0x00B1661C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_15:
        // 0x00B16620: LDR w8, [x24, #0x30]       | W8 = val_10.loadType; //P2              
        // 0x00B16624: CMP w8, #2                 | STATE = COMPARE(val_10.loadType, 0x2)   
        // 0x00B16628: B.GE #0xb16830             | if (val_10.loadType >= 2) goto label_16;
        if(val_10.loadType >= 2)
        {
            goto label_16;
        }
        // 0x00B1662C: LDR x24, [x19, #0x38]      | X24 = this.clientStreamingList; //P2    
        // 0x00B16630: LDR x25, [x19, #0x28]      | X25 = this.serverList; //P2             
        // 0x00B16634: CBZ x23, #0xb16910         | if (0x0 == 0) goto label_17;            
        if(val_85 == 0)
        {
            goto label_17;
        }
        // 0x00B16638: CBNZ x25, #0xb16640        | if (this.serverList != null) goto label_18;
        if(this.serverList != null)
        {
            goto label_18;
        }
        // 0x00B1663C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_18:
        // 0x00B16640: LDR x23, [x25, #0x10]      | 
        // 0x00B16644: CBNZ x23, #0xb1664c        | if (0x0 != 0) goto label_19;            
        if(val_85 != 0)
        {
            goto label_19;
        }
        // 0x00B16648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_19:
        // 0x00B1664C: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B16650: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B16654: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16658: BL #0x25ed734              | X0 = val_85.get_Item(index:  0);        
        string val_11 = val_85.Item[0];
        // 0x00B1665C: MOV x23, x0                | X23 = val_11;//m1                       
        // 0x00B16660: CBNZ x24, #0xb16668        | if (this.clientStreamingList != null) goto label_20;
        if(this.clientStreamingList != null)
        {
            goto label_20;
        }
        // 0x00B16664: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_20:
        // 0x00B16668: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
        // 0x00B1666C: LDR x8, [x8, #0x518]       | X8 = 1152921515141824640;               
        // 0x00B16670: LDR x2, [x8]               | X2 = public FileInfoRes Filelist<FileInfoRes>::GetResData(string fileName);
        // 0x00B16674: MOV x0, x24                | X0 = this.clientStreamingList;//m1      
        // 0x00B16678: MOV x1, x23                | X1 = val_11;//m1                        
        // 0x00B1667C: BL #0x19cd75c              | X0 = this.clientStreamingList.GetResData(fileName:  val_11);
        FileInfoRes val_12 = this.clientStreamingList.GetResData(fileName:  val_11);
        // 0x00B16680: MOV x23, x0                | X23 = val_12;//m1                       
        // 0x00B16684: CBZ x23, #0xb16708         | if (val_12 == null) goto label_22;      
        if(val_12 == null)
        {
            goto label_22;
        }
        // 0x00B16688: LDR w8, [x23, #0x30]       | W8 = val_12.loadType; //P2              
        // 0x00B1668C: CMP w8, #0                 | STATE = COMPARE(val_12.loadType, 0x0)   
        // 0x00B16690: B.GT #0xb16708             | if (val_12.loadType > 0) goto label_22; 
        if(val_12.loadType > 0)
        {
            goto label_22;
        }
        // 0x00B16694: LDR x24, [x23, #0x18]      | X24 = val_12.mDataMD5; //P2             
        // 0x00B16698: LDR x25, [x19, #0x28]      | X25 = this.serverList; //P2             
        // 0x00B1669C: CBNZ x25, #0xb166a4        | if (this.serverList != null) goto label_23;
        if(this.serverList != null)
        {
            goto label_23;
        }
        // 0x00B166A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_23:
        // 0x00B166A4: LDR x25, [x25, #0x18]      | 
        // 0x00B166A8: CBNZ x25, #0xb166b0        | if (this.serverList != null) goto label_24;
        if(this.serverList != null)
        {
            goto label_24;
        }
        // 0x00B166AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_24:
        // 0x00B166B0: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B166B4: MOV x0, x25                | X0 = this.serverList;//m1               
        // 0x00B166B8: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B166BC: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_13 = this.serverList.Item[0];
        // 0x00B166C0: MOV x25, x0                | X25 = val_13;//m1                       
        // 0x00B166C4: CBNZ x25, #0xb166cc        | if (val_13 != null) goto label_25;      
        if(val_13 != null)
        {
            goto label_25;
        }
        // 0x00B166C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_25:
        // 0x00B166CC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B166D0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B166D4: LDR x25, [x25, #0x18]      | X25 = val_13.mDataMD5; //P2             
        // 0x00B166D8: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B166DC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B166E0: TBZ w8, #0, #0xb166f0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x00B166E4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B166E8: CBNZ w8, #0xb166f0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x00B166EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_27:
        // 0x00B166F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B166F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B166F8: MOV x1, x24                | X1 = val_12.mDataMD5;//m1               
        // 0x00B166FC: MOV x2, x25                | X2 = val_13.mDataMD5;//m1               
        // 0x00B16700: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_12.mDataMD5);
        bool val_14 = System.String.op_Inequality(a:  0, b:  val_12.mDataMD5);
        // 0x00B16704: TBZ w0, #0, #0xb16f4c      | if (val_14 == false) goto label_28;     
        if(val_14 == false)
        {
            goto label_28;
        }
        label_22:
        // 0x00B16708: LDR x8, [x19, #0x30]       | X8 = this.clientPersistentList; //P2    
        // 0x00B1670C: CBZ x8, #0xb169e0          | if (this.clientPersistentList == null) goto label_60;
        if(this.clientPersistentList == null)
        {
            goto label_60;
        }
        // 0x00B16710: BL #0xb14978               | X0 = val_14.SavePath();                 
        string val_15 = val_14.SavePath();
        // 0x00B16714: MOV x23, x0                | X23 = val_15;//m1                       
        // 0x00B16718: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B1671C: CBNZ x24, #0xb16724        | if (this.serverList != null) goto label_30;
        if(this.serverList != null)
        {
            goto label_30;
        }
        // 0x00B16720: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_30:
        // 0x00B16724: LDR x24, [x24, #0x10]      | 
        // 0x00B16728: CBNZ x24, #0xb16730        | if (this.serverList != null) goto label_31;
        if(this.serverList != null)
        {
            goto label_31;
        }
        // 0x00B1672C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_31:
        // 0x00B16730: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B16734: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B16738: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B1673C: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        string val_16 = this.serverList.Item[0];
        // 0x00B16740: MOV x24, x0                | X24 = val_16;//m1                       
        // 0x00B16744: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B16748: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1674C: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B16750: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B16754: TBZ w8, #0, #0xb16764      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_33;
        // 0x00B16758: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1675C: CBNZ w8, #0xb16764         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
        // 0x00B16760: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_33:
        // 0x00B16764: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16768: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1676C: MOV x1, x23                | X1 = val_15;//m1                        
        // 0x00B16770: MOV x2, x24                | X2 = val_16;//m1                        
        // 0x00B16774: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_15);
        string val_17 = System.String.Concat(str0:  0, str1:  val_15);
        // 0x00B16778: MOV x1, x0                 | X1 = val_17;//m1                        
        // 0x00B1677C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16780: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B16784: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_18 = System.IO.File.Exists(path:  0);
        // 0x00B16788: TBZ w0, #0, #0xb169e0      | if (val_18 == false) goto label_60;     
        if(val_18 == false)
        {
            goto label_60;
        }
        // 0x00B1678C: LDP x24, x23, [x19, #0x28] | X24 = this.serverList; //P2  X23 = this.clientPersistentList; //P2  //  | 
        // 0x00B16790: CBNZ x24, #0xb16798        | if (this.serverList != null) goto label_35;
        if(this.serverList != null)
        {
            goto label_35;
        }
        // 0x00B16794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_35:
        // 0x00B16798: LDR x24, [x24, #0x10]      | 
        // 0x00B1679C: CBNZ x24, #0xb167a4        | if (this.serverList != null) goto label_36;
        if(this.serverList != null)
        {
            goto label_36;
        }
        // 0x00B167A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_36:
        // 0x00B167A4: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B167A8: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B167AC: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B167B0: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        string val_19 = this.serverList.Item[0];
        // 0x00B167B4: MOV x24, x0                | X24 = val_19;//m1                       
        // 0x00B167B8: CBNZ x23, #0xb167c0        | if (this.clientPersistentList != null) goto label_37;
        if(this.clientPersistentList != null)
        {
            goto label_37;
        }
        // 0x00B167BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_37:
        // 0x00B167C0: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
        // 0x00B167C4: LDR x8, [x8, #0x518]       | X8 = 1152921515141824640;               
        // 0x00B167C8: LDR x2, [x8]               | X2 = public FileInfoRes Filelist<FileInfoRes>::GetResData(string fileName);
        // 0x00B167CC: MOV x0, x23                | X0 = this.clientPersistentList;//m1     
        // 0x00B167D0: MOV x1, x24                | X1 = val_19;//m1                        
        // 0x00B167D4: BL #0x19cd75c              | X0 = this.clientPersistentList.GetResData(fileName:  val_19);
        FileInfoRes val_20 = this.clientPersistentList.GetResData(fileName:  val_19);
        // 0x00B167D8: CBZ x0, #0xb169e0          | if (val_20 == null) goto label_60;      
        if(val_20 == null)
        {
            goto label_60;
        }
        // 0x00B167DC: LDR x23, [x0, #0x10]       | 
        // 0x00B167E0: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B167E4: CBNZ x24, #0xb167ec        | if (this.serverList != null) goto label_39;
        if(this.serverList != null)
        {
            goto label_39;
        }
        // 0x00B167E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_39:
        // 0x00B167EC: LDR x24, [x24, #0x18]      | 
        // 0x00B167F0: CBNZ x24, #0xb167f8        | if (this.serverList != null) goto label_40;
        if(this.serverList != null)
        {
            goto label_40;
        }
        // 0x00B167F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_40:
        // 0x00B167F8: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B167FC: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B16800: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16804: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_21 = this.serverList.Item[0];
        // 0x00B16808: MOV x24, x0                | X24 = val_21;//m1                       
        // 0x00B1680C: CBNZ x24, #0xb16814        | if (val_21 != null) goto label_41;      
        if(val_21 != null)
        {
            goto label_41;
        }
        // 0x00B16810: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_41:
        // 0x00B16814: LDR x2, [x24, #0x18]       | X2 = val_21.mDataMD5; //P2              
        // 0x00B16818: MOV x0, x19                | X0 = 1152921515142282912 (0x1000000273F5FEA0);//ML01
        // 0x00B1681C: MOV x1, x23                | X1 = this.clientPersistentList;//m1     
        // 0x00B16820: BL #0xb1828c               | X0 = this.VerifyMD5(path:  this.clientPersistentList, md5:  val_21.mDataMD5);
        bool val_22 = this.VerifyMD5(path:  this.clientPersistentList, md5:  val_21.mDataMD5);
        // 0x00B16824: AND w8, w0, #1             | W8 = (val_22 & 1);                      
        bool val_23 = val_22;
        // 0x00B16828: TBNZ w8, #0, #0xb1708c     | if ((val_22 & 1) == true) goto label_140;
        if(val_23 == true)
        {
            goto label_140;
        }
        // 0x00B1682C: B #0xb169e0                |  goto label_60;                         
        goto label_60;
        label_16:
        // 0x00B16830: CBZ x23, #0xb16884         | if (0x0 == 0) goto label_44;            
        if(val_85 == 0)
        {
            goto label_44;
        }
        // 0x00B16834: LDR x24, [x23, #0x10]      | X24 = 0x100B70003;                      
        // 0x00B16838: LDR x25, [x19, #0x28]      | X25 = this.serverList; //P2             
        // 0x00B1683C: CBNZ x25, #0xb16844        | if (this.serverList != null) goto label_45;
        if(this.serverList != null)
        {
            goto label_45;
        }
        // 0x00B16840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_45:
        // 0x00B16844: LDR x25, [x25, #0x18]      | 
        // 0x00B16848: CBNZ x25, #0xb16850        | if (this.serverList != null) goto label_46;
        if(this.serverList != null)
        {
            goto label_46;
        }
        // 0x00B1684C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_46:
        // 0x00B16850: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B16854: MOV x0, x25                | X0 = this.serverList;//m1               
        // 0x00B16858: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B1685C: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_24 = this.serverList.Item[0];
        // 0x00B16860: MOV x25, x0                | X25 = val_24;//m1                       
        // 0x00B16864: CBNZ x25, #0xb1686c        | if (val_24 != null) goto label_47;      
        if(val_24 != null)
        {
            goto label_47;
        }
        // 0x00B16868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_47:
        // 0x00B1686C: LDR x2, [x25, #0x18]       | X2 = val_24.mDataMD5; //P2              
        // 0x00B16870: MOV x0, x19                | X0 = 1152921515142282912 (0x1000000273F5FEA0);//ML01
        // 0x00B16874: MOV x1, x24                | X1 = 4306960387 (0x100B70003);//ML01    
        // 0x00B16878: BL #0xb1828c               | X0 = this.VerifyMD5(path:  11993091, md5:  val_24.mDataMD5);
        bool val_25 = this.VerifyMD5(path:  11993091, md5:  val_24.mDataMD5);
        // 0x00B1687C: AND w8, w0, #1             | W8 = (val_25 & 1);                      
        bool val_26 = val_25;
        // 0x00B16880: TBZ w8, #0, #0xb16f18      | if ((val_25 & 1) == false) goto label_48;
        if(val_26 == false)
        {
            goto label_48;
        }
        label_44:
        // 0x00B16884: LDR x23, [x19, #0x10]      | X23 = this.clientCrcList; //P2          
        // 0x00B16888: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B1688C: CBNZ x24, #0xb16894        | if (this.serverList != null) goto label_49;
        if(this.serverList != null)
        {
            goto label_49;
        }
        // 0x00B16890: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_49:
        // 0x00B16894: LDR x24, [x24, #0x18]      | 
        // 0x00B16898: CBNZ x24, #0xb168a0        | if (this.serverList != null) goto label_50;
        if(this.serverList != null)
        {
            goto label_50;
        }
        // 0x00B1689C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_50:
        // 0x00B168A0: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B168A4: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B168A8: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B168AC: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_27 = this.serverList.Item[0];
        // 0x00B168B0: MOV x24, x0                | X24 = val_27;//m1                       
        // 0x00B168B4: CBNZ x24, #0xb168bc        | if (val_27 != null) goto label_51;      
        if(val_27 != null)
        {
            goto label_51;
        }
        // 0x00B168B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_51:
        // 0x00B168BC: LDR x24, [x24, #0x10]      | 
        // 0x00B168C0: CBNZ x23, #0xb168c8        | if (this.clientCrcList != null) goto label_52;
        if(this.clientCrcList != null)
        {
            goto label_52;
        }
        // 0x00B168C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_52:
        // 0x00B168C8: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B168CC: LDR x8, [x8, #0xdc8]       | X8 = 1152921515141944448;               
        // 0x00B168D0: LDR x2, [x8]               | X2 = public FileInfoCrc Filelist<FileInfoCrc>::GetResData(string fileName);
        // 0x00B168D4: MOV x0, x23                | X0 = this.clientCrcList;//m1            
        // 0x00B168D8: MOV x1, x24                | X1 = val_27;//m1                        
        // 0x00B168DC: BL #0x19cd75c              | X0 = this.clientCrcList.GetResData(fileName:  val_27);
        FileInfoCrc val_28 = this.clientCrcList.GetResData(fileName:  val_27);
        // 0x00B168E0: MOV x23, x0                | X23 = val_28;//m1                       
        val_86 = val_28;
        // 0x00B168E4: CBZ x23, #0xb16f3c         | if (val_28 == null) goto label_164;     
        if(val_86 == null)
        {
            goto label_164;
        }
        // 0x00B168E8: LDR x24, [x19, #0x18]      | X24 = this.serverCrcList; //P2          
        // 0x00B168EC: CBNZ x24, #0xb168f4        | if (this.serverCrcList != null) goto label_54;
        if(this.serverCrcList != null)
        {
            goto label_54;
        }
        // 0x00B168F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_54:
        // 0x00B168F4: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00B168F8: LDR x8, [x8, #0x188]       | X8 = 1152921514966434016;               
        // 0x00B168FC: LDR x2, [x8]               | X2 = public System.Void Filelist<FileInfoCrc>::AddOrReplaceResData(FileInfoCrc data);
        // 0x00B16900: MOV x0, x24                | X0 = this.serverCrcList;//m1            
        // 0x00B16904: MOV x1, x23                | X1 = val_28;//m1                        
        // 0x00B16908: BL #0x19cd1c4              | this.serverCrcList.AddOrReplaceResData(data:  val_86);
        this.serverCrcList.AddOrReplaceResData(data:  val_86);
        // 0x00B1690C: B #0xb16f3c                |  goto label_164;                        
        goto label_164;
        label_17:
        // 0x00B16910: CBNZ x25, #0xb16918        | if (this.serverList != null) goto label_56;
        if(this.serverList != null)
        {
            goto label_56;
        }
        // 0x00B16914: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_56:
        // 0x00B16918: LDR x23, [x25, #0x10]      | 
        // 0x00B1691C: CBNZ x23, #0xb16924        | if (0x0 != 0) goto label_57;            
        if(val_85 != 0)
        {
            goto label_57;
        }
        // 0x00B16920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_57:
        // 0x00B16924: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B16928: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1692C: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16930: BL #0x25ed734              | X0 = val_85.get_Item(index:  0);        
        string val_29 = val_85.Item[0];
        // 0x00B16934: MOV x23, x0                | X23 = val_29;//m1                       
        // 0x00B16938: CBNZ x24, #0xb16940        | if (this.clientStreamingList != null) goto label_58;
        if(this.clientStreamingList != null)
        {
            goto label_58;
        }
        // 0x00B1693C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
        label_58:
        // 0x00B16940: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
        // 0x00B16944: LDR x8, [x8, #0x518]       | X8 = 1152921515141824640;               
        // 0x00B16948: LDR x2, [x8]               | X2 = public FileInfoRes Filelist<FileInfoRes>::GetResData(string fileName);
        // 0x00B1694C: MOV x0, x24                | X0 = this.clientStreamingList;//m1      
        // 0x00B16950: MOV x1, x23                | X1 = val_29;//m1                        
        // 0x00B16954: BL #0x19cd75c              | X0 = this.clientStreamingList.GetResData(fileName:  val_29);
        FileInfoRes val_30 = this.clientStreamingList.GetResData(fileName:  val_29);
        // 0x00B16958: CBZ x0, #0xb169e0          | if (val_30 == null) goto label_60;      
        if(val_30 == null)
        {
            goto label_60;
        }
        // 0x00B1695C: LDR w8, [x0, #0x30]        | W8 = val_30.loadType; //P2              
        // 0x00B16960: CMP w8, #0                 | STATE = COMPARE(val_30.loadType, 0x0)   
        // 0x00B16964: B.GT #0xb169e0             | if (val_30.loadType > 0) goto label_60; 
        if(val_30.loadType > 0)
        {
            goto label_60;
        }
        // 0x00B16968: LDR x23, [x0, #0x18]       | X23 = val_30.mDataMD5; //P2             
        // 0x00B1696C: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B16970: CBNZ x24, #0xb16978        | if (this.serverList != null) goto label_61;
        if(this.serverList != null)
        {
            goto label_61;
        }
        // 0x00B16974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_61:
        // 0x00B16978: LDR x24, [x24, #0x18]      | 
        // 0x00B1697C: CBNZ x24, #0xb16984        | if (this.serverList != null) goto label_62;
        if(this.serverList != null)
        {
            goto label_62;
        }
        // 0x00B16980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_62:
        // 0x00B16984: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B16988: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B1698C: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16990: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_31 = this.serverList.Item[0];
        // 0x00B16994: MOV x24, x0                | X24 = val_31;//m1                       
        // 0x00B16998: CBNZ x24, #0xb169a0        | if (val_31 != null) goto label_63;      
        if(val_31 != null)
        {
            goto label_63;
        }
        // 0x00B1699C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_63:
        // 0x00B169A0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B169A4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B169A8: LDR x24, [x24, #0x18]      | X24 = val_31.mDataMD5; //P2             
        // 0x00B169AC: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B169B0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B169B4: TBZ w8, #0, #0xb169c4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_65;
        // 0x00B169B8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B169BC: CBNZ w8, #0xb169c4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
        // 0x00B169C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_65:
        // 0x00B169C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B169C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B169CC: MOV x1, x23                | X1 = val_30.mDataMD5;//m1               
        // 0x00B169D0: MOV x2, x24                | X2 = val_31.mDataMD5;//m1               
        // 0x00B169D4: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_30.mDataMD5);
        bool val_32 = System.String.op_Inequality(a:  0, b:  val_30.mDataMD5);
        // 0x00B169D8: AND w8, w0, #1             | W8 = (val_32 & 1);                      
        bool val_33 = val_32;
        // 0x00B169DC: TBZ w8, #0, #0xb1708c      | if ((val_32 & 1) == false) goto label_140;
        if(val_33 == false)
        {
            goto label_140;
        }
        label_60:
        // 0x00B169E0: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B169E4: CBNZ x23, #0xb169ec        | if (this.serverList != null) goto label_67;
        if(this.serverList != null)
        {
            goto label_67;
        }
        // 0x00B169E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_67:
        // 0x00B169EC: LDR x23, [x23, #0x18]      | 
        // 0x00B169F0: CBNZ x23, #0xb169f8        | if (this.serverList != null) goto label_68;
        if(this.serverList != null)
        {
            goto label_68;
        }
        // 0x00B169F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_68:
        // 0x00B169F8: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B169FC: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B16A00: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16A04: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_34 = this.serverList.Item[0];
        // 0x00B16A08: MOV x23, x0                | X23 = val_34;//m1                       
        // 0x00B16A0C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B16A10: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B16A14: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        val_87 = null;
        // 0x00B16A18: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B16A1C: TBZ w8, #0, #0xb16a38      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_70;
        // 0x00B16A20: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B16A24: CBNZ w8, #0xb16a38         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_70;
        // 0x00B16A28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B16A2C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B16A30: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B16A34: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        val_87 = null;
        label_70:
        // 0x00B16A38: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B16A3C: LDR x25, [x19, #0x28]      | X25 = this.serverList; //P2             
        // 0x00B16A40: LDR x24, [x8, #0x70]       | X24 = Loader.PathUtil.SERVER_URL;       
        // 0x00B16A44: CBNZ x25, #0xb16a4c        | if (this.serverList != null) goto label_71;
        if(this.serverList != null)
        {
            goto label_71;
        }
        // 0x00B16A48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
        label_71:
        // 0x00B16A4C: LDR x25, [x25, #0x18]      | 
        // 0x00B16A50: CBNZ x25, #0xb16a58        | if (this.serverList != null) goto label_72;
        if(this.serverList != null)
        {
            goto label_72;
        }
        // 0x00B16A54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
        label_72:
        // 0x00B16A58: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B16A5C: MOV x0, x25                | X0 = this.serverList;//m1               
        // 0x00B16A60: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16A64: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_35 = this.serverList.Item[0];
        // 0x00B16A68: MOV x25, x0                | X25 = val_35;//m1                       
        // 0x00B16A6C: CBNZ x25, #0xb16a74        | if (val_35 != null) goto label_73;      
        if(val_35 != null)
        {
            goto label_73;
        }
        // 0x00B16A70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_73:
        // 0x00B16A74: LDR x25, [x25, #0x10]      | 
        // 0x00B16A78: CBNZ x25, #0xb16a80        | if (val_35 != null) goto label_74;      
        if(val_35 != null)
        {
            goto label_74;
        }
        // 0x00B16A7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_74:
        // 0x00B16A80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16A84: MOV x0, x25                | X0 = val_35;//m1                        
        // 0x00B16A88: BL #0x18a946c              | X0 = val_35.Trim();                     
        string val_36 = val_35.Trim();
        // 0x00B16A8C: MOV x25, x0                | X25 = val_36;//m1                       
        // 0x00B16A90: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B16A94: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B16A98: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B16A9C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B16AA0: TBZ w8, #0, #0xb16ab0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_76;
        // 0x00B16AA4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B16AA8: CBNZ w8, #0xb16ab0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_76;
        // 0x00B16AAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_76:
        // 0x00B16AB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16AB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B16AB8: MOV x1, x24                | X1 = Loader.PathUtil.SERVER_URL;//m1    
        // 0x00B16ABC: MOV x2, x25                | X2 = val_36;//m1                        
        // 0x00B16AC0: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.SERVER_URL);
        string val_37 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.SERVER_URL);
        // 0x00B16AC4: MOV x24, x0                | X24 = val_37;//m1                       
        // 0x00B16AC8: CBNZ x23, #0xb16ad0        | if (val_34 != null) goto label_77;      
        if(val_34 != null)
        {
            goto label_77;
        }
        // 0x00B16ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_77:
        // 0x00B16AD0: STR x24, [x23, #0x20]      | val_34.mPath = val_37;                   //  dest_result_addr=0
        val_34.mPath = val_37;
        // 0x00B16AD4: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B16AD8: CBNZ x23, #0xb16ae0        | if (this.serverList != null) goto label_78;
        if(this.serverList != null)
        {
            goto label_78;
        }
        // 0x00B16ADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_78:
        // 0x00B16AE0: LDR x23, [x23, #0x18]      | 
        // 0x00B16AE4: CBNZ x23, #0xb16aec        | if (this.serverList != null) goto label_79;
        if(this.serverList != null)
        {
            goto label_79;
        }
        // 0x00B16AE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_79:
        // 0x00B16AEC: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B16AF0: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B16AF4: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16AF8: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_38 = this.serverList.Item[0];
        // 0x00B16AFC: MOV x23, x0                | X23 = val_38;//m1                       
        // 0x00B16B00: CBNZ x23, #0xb16b08        | if (val_38 != null) goto label_80;      
        if(val_38 != null)
        {
            goto label_80;
        }
        // 0x00B16B04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
        label_80:
        // 0x00B16B08: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00B16B0C: LDR x1, [x23, #0x10]       | 
        // 0x00B16B10: LDR x8, [x8, #0xa88]       | X8 = (string**)(1152921515142011008)("csscript.uab");
        // 0x00B16B14: LDR x2, [x8]               | X2 = "csscript.uab";                    
        // 0x00B16B18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16B1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B16B20: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  0);
        bool val_39 = System.String.op_Equality(a:  0, b:  val_86);
        // 0x00B16B24: TBZ w0, #0, #0xb16c5c      | if (val_39 == false) goto label_96;     
        if(val_39 == false)
        {
            goto label_96;
        }
        // 0x00B16B28: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B16B2C: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B16B30: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B16B34: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B16B38: TBZ w8, #0, #0xb16b48      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_83;
        // 0x00B16B3C: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B16B40: CBNZ w8, #0xb16b48         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_83;
        // 0x00B16B44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_83:
        // 0x00B16B48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16B4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16B50: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_40 = VersionMgr.Instance;
        // 0x00B16B54: MOV x23, x0                | X23 = val_40;//m1                       
        // 0x00B16B58: CBNZ x23, #0xb16b60        | if (val_40 != null) goto label_84;      
        if(val_40 != null)
        {
            goto label_84;
        }
        // 0x00B16B5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_84:
        // 0x00B16B60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16B64: MOV x0, x23                | X0 = val_40;//m1                        
        // 0x00B16B68: BL #0xe27dac               | X0 = val_40.get_currentVS();            
        VersionInfo val_41 = val_40.currentVS;
        // 0x00B16B6C: MOV x23, x0                | X23 = val_41;//m1                       
        // 0x00B16B70: CBNZ x23, #0xb16b78        | if (val_41 != null) goto label_85;      
        if(val_41 != null)
        {
            goto label_85;
        }
        // 0x00B16B74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
        label_85:
        // 0x00B16B78: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B16B7C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B16B80: LDR x23, [x23, #0xe8]      | X23 = val_41.noRestartAssetsvs; //P2    
        // 0x00B16B84: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B16B88: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B16B8C: TBZ w8, #0, #0xb16b9c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_87;
        // 0x00B16B90: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B16B94: CBNZ w8, #0xb16b9c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_87;
        // 0x00B16B98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_87:
        // 0x00B16B9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16BA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B16BA4: MOV x1, x23                | X1 = val_41.noRestartAssetsvs;//m1      
        // 0x00B16BA8: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_42 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B16BAC: AND w8, w0, #1             | W8 = (val_42 & 1);                      
        bool val_43 = val_42;
        // 0x00B16BB0: TBNZ w8, #0, #0xb16c54     | if ((val_42 & 1) == true) goto label_88;
        if(val_43 == true)
        {
            goto label_88;
        }
        // 0x00B16BB4: BL #0xb145d8               | X0 = ABCheckUpdate.get_Instance();      
        ABCheckUpdate val_44 = ABCheckUpdate.Instance;
        // 0x00B16BB8: MOV x23, x0                | X23 = val_44;//m1                       
        // 0x00B16BBC: CBNZ x23, #0xb16bc4        | if (val_44 != null) goto label_89;      
        if(val_44 != null)
        {
            goto label_89;
        }
        // 0x00B16BC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
        label_89:
        // 0x00B16BC4: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B16BC8: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B16BCC: LDR x23, [x23, #0x58]      | X23 = val_44.clientVer; //P2            
        // 0x00B16BD0: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B16BD4: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B16BD8: TBZ w8, #0, #0xb16be8      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_91;
        // 0x00B16BDC: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B16BE0: CBNZ w8, #0xb16be8         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_91;
        // 0x00B16BE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_91:
        // 0x00B16BE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16BEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16BF0: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_45 = VersionMgr.Instance;
        // 0x00B16BF4: MOV x24, x0                | X24 = val_45;//m1                       
        // 0x00B16BF8: CBNZ x24, #0xb16c00        | if (val_45 != null) goto label_92;      
        if(val_45 != null)
        {
            goto label_92;
        }
        // 0x00B16BFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_92:
        // 0x00B16C00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16C04: MOV x0, x24                | X0 = val_45;//m1                        
        // 0x00B16C08: BL #0xe27dac               | X0 = val_45.get_currentVS();            
        VersionInfo val_46 = val_45.currentVS;
        // 0x00B16C0C: MOV x24, x0                | X24 = val_46;//m1                       
        // 0x00B16C10: CBNZ x24, #0xb16c18        | if (val_46 != null) goto label_93;      
        if(val_46 != null)
        {
            goto label_93;
        }
        // 0x00B16C14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
        label_93:
        // 0x00B16C18: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B16C1C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B16C20: LDR x24, [x24, #0xe8]      | X24 = val_46.noRestartAssetsvs; //P2    
        // 0x00B16C24: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B16C28: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B16C2C: TBZ w8, #0, #0xb16c3c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_95;
        // 0x00B16C30: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B16C34: CBNZ w8, #0xb16c3c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_95;
        // 0x00B16C38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_95:
        // 0x00B16C3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16C40: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B16C44: MOV x1, x23                | X1 = val_44.clientVer;//m1              
        // 0x00B16C48: MOV x2, x24                | X2 = val_46.noRestartAssetsvs;//m1      
        // 0x00B16C4C: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_44.clientVer);
        bool val_47 = System.String.op_Inequality(a:  0, b:  val_44.clientVer);
        // 0x00B16C50: TBZ w0, #0, #0xb16c5c      | if (val_47 == false) goto label_96;     
        if(val_47 == false)
        {
            goto label_96;
        }
        label_88:
        // 0x00B16C54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B16C58: STRB w8, [x19, #0x50]      | this.isRestart = true;                   //  dest_result_addr=1152921515142282992
        this.isRestart = true;
        label_96:
        // 0x00B16C5C: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B16C60: CBNZ x23, #0xb16c68        | if (this.serverList != null) goto label_97;
        if(this.serverList != null)
        {
            goto label_97;
        }
        // 0x00B16C64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_97:
        // 0x00B16C68: LDR x23, [x23, #0x18]      | 
        // 0x00B16C6C: CBNZ x23, #0xb16c74        | if (this.serverList != null) goto label_98;
        if(this.serverList != null)
        {
            goto label_98;
        }
        // 0x00B16C70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_98:
        // 0x00B16C74: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B16C78: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B16C7C: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16C80: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_48 = this.serverList.Item[0];
        // 0x00B16C84: MOV x23, x0                | X23 = val_48;//m1                       
        // 0x00B16C88: CBNZ x23, #0xb16c90        | if (val_48 != null) goto label_99;      
        if(val_48 != null)
        {
            goto label_99;
        }
        // 0x00B16C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_99:
        // 0x00B16C90: LDR x23, [x23, #0x10]      | 
        // 0x00B16C94: CBNZ x23, #0xb16c9c        | if (val_48 != null) goto label_100;     
        if(val_48 != null)
        {
            goto label_100;
        }
        // 0x00B16C98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_100:
        // 0x00B16C9C: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B16CA0: LDR x8, [x8, #0xfc8]       | X8 = (string**)(1152921514967116720)("_csscript.uab");
        // 0x00B16CA4: LDR x1, [x8]               | X1 = "_csscript.uab";                   
        // 0x00B16CA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B16CAC: MOV x0, x23                | X0 = val_48;//m1                        
        // 0x00B16CB0: BL #0x18ab0a0              | X0 = val_48.EndsWith(value:  "_csscript.uab");
        bool val_49 = val_48.EndsWith(value:  "_csscript.uab");
        // 0x00B16CB4: TBZ w0, #0, #0xb16ec4      | if (val_49 == false) goto label_123;    
        if(val_49 == false)
        {
            goto label_123;
        }
        // 0x00B16CB8: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B16CBC: CBNZ x23, #0xb16cc4        | if (this.serverList != null) goto label_102;
        if(this.serverList != null)
        {
            goto label_102;
        }
        // 0x00B16CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
        label_102:
        // 0x00B16CC4: LDR x23, [x23, #0x18]      | 
        // 0x00B16CC8: CBNZ x23, #0xb16cd0        | if (this.serverList != null) goto label_103;
        if(this.serverList != null)
        {
            goto label_103;
        }
        // 0x00B16CCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
        label_103:
        // 0x00B16CD0: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B16CD4: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B16CD8: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16CDC: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_50 = this.serverList.Item[0];
        // 0x00B16CE0: MOV x23, x0                | X23 = val_50;//m1                       
        // 0x00B16CE4: CBNZ x23, #0xb16cec        | if (val_50 != null) goto label_104;     
        if(val_50 != null)
        {
            goto label_104;
        }
        // 0x00B16CE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
        label_104:
        // 0x00B16CEC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B16CF0: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B16CF4: LDR x23, [x23, #0x10]      | 
        // 0x00B16CF8: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        val_88 = null;
        // 0x00B16CFC: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B16D00: TBZ w8, #0, #0xb16d1c      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_106;
        // 0x00B16D04: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B16D08: CBNZ w8, #0xb16d1c         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_106;
        // 0x00B16D0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B16D10: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B16D14: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B16D18: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        val_88 = null;
        label_106:
        // 0x00B16D1C: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B16D20: LDR x24, [x8, #0x10]       | X24 = Loader.PathUtil.ARCH_ABI_TYPE;    
        // 0x00B16D24: CBNZ x23, #0xb16d2c        | if (val_50 != null) goto label_107;     
        if(val_50 != null)
        {
            goto label_107;
        }
        // 0x00B16D28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
        label_107:
        // 0x00B16D2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B16D30: MOV x0, x23                | X0 = val_50;//m1                        
        // 0x00B16D34: MOV x1, x24                | X1 = Loader.PathUtil.ARCH_ABI_TYPE;//m1 
        // 0x00B16D38: BL #0x18ad42c              | X0 = val_50.Contains(value:  Loader.PathUtil.ARCH_ABI_TYPE);
        bool val_51 = val_50.Contains(value:  Loader.PathUtil.ARCH_ABI_TYPE);
        // 0x00B16D3C: TBZ w0, #0, #0xb16f3c      | if (val_51 == false) goto label_164;    
        if(val_51 == false)
        {
            goto label_164;
        }
        // 0x00B16D40: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B16D44: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B16D48: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B16D4C: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B16D50: TBZ w8, #0, #0xb16d60      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_110;
        // 0x00B16D54: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B16D58: CBNZ w8, #0xb16d60         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_110;
        // 0x00B16D5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_110:
        // 0x00B16D60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16D64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16D68: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_52 = VersionMgr.Instance;
        // 0x00B16D6C: MOV x23, x0                | X23 = val_52;//m1                       
        // 0x00B16D70: CBNZ x23, #0xb16d78        | if (val_52 != null) goto label_111;     
        if(val_52 != null)
        {
            goto label_111;
        }
        // 0x00B16D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
        label_111:
        // 0x00B16D78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16D7C: MOV x0, x23                | X0 = val_52;//m1                        
        // 0x00B16D80: BL #0xe27dac               | X0 = val_52.get_currentVS();            
        VersionInfo val_53 = val_52.currentVS;
        // 0x00B16D84: MOV x23, x0                | X23 = val_53;//m1                       
        // 0x00B16D88: CBNZ x23, #0xb16d90        | if (val_53 != null) goto label_112;     
        if(val_53 != null)
        {
            goto label_112;
        }
        // 0x00B16D8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_53, ????);     
        label_112:
        // 0x00B16D90: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B16D94: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B16D98: LDR x23, [x23, #0xe8]      | X23 = val_53.noRestartAssetsvs; //P2    
        // 0x00B16D9C: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B16DA0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B16DA4: TBZ w8, #0, #0xb16db4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_114;
        // 0x00B16DA8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B16DAC: CBNZ w8, #0xb16db4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_114;
        // 0x00B16DB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_114:
        // 0x00B16DB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16DB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B16DBC: MOV x1, x23                | X1 = val_53.noRestartAssetsvs;//m1      
        // 0x00B16DC0: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_54 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B16DC4: AND w8, w0, #1             | W8 = (val_54 & 1);                      
        bool val_55 = val_54;
        // 0x00B16DC8: TBNZ w8, #0, #0xb16e6c     | if ((val_54 & 1) == true) goto label_115;
        if(val_55 == true)
        {
            goto label_115;
        }
        // 0x00B16DCC: BL #0xb145d8               | X0 = ABCheckUpdate.get_Instance();      
        ABCheckUpdate val_56 = ABCheckUpdate.Instance;
        // 0x00B16DD0: MOV x23, x0                | X23 = val_56;//m1                       
        // 0x00B16DD4: CBNZ x23, #0xb16ddc        | if (val_56 != null) goto label_116;     
        if(val_56 != null)
        {
            goto label_116;
        }
        // 0x00B16DD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
        label_116:
        // 0x00B16DDC: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B16DE0: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B16DE4: LDR x23, [x23, #0x58]      | X23 = val_56.clientVer; //P2            
        // 0x00B16DE8: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B16DEC: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B16DF0: TBZ w8, #0, #0xb16e00      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_118;
        // 0x00B16DF4: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B16DF8: CBNZ w8, #0xb16e00         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_118;
        // 0x00B16DFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_118:
        // 0x00B16E00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16E04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16E08: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_57 = VersionMgr.Instance;
        // 0x00B16E0C: MOV x24, x0                | X24 = val_57;//m1                       
        // 0x00B16E10: CBNZ x24, #0xb16e18        | if (val_57 != null) goto label_119;     
        if(val_57 != null)
        {
            goto label_119;
        }
        // 0x00B16E14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_57, ????);     
        label_119:
        // 0x00B16E18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B16E1C: MOV x0, x24                | X0 = val_57;//m1                        
        // 0x00B16E20: BL #0xe27dac               | X0 = val_57.get_currentVS();            
        VersionInfo val_58 = val_57.currentVS;
        // 0x00B16E24: MOV x24, x0                | X24 = val_58;//m1                       
        // 0x00B16E28: CBNZ x24, #0xb16e30        | if (val_58 != null) goto label_120;     
        if(val_58 != null)
        {
            goto label_120;
        }
        // 0x00B16E2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_120:
        // 0x00B16E30: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B16E34: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B16E38: LDR x24, [x24, #0xe8]      | X24 = val_58.noRestartAssetsvs; //P2    
        // 0x00B16E3C: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B16E40: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B16E44: TBZ w8, #0, #0xb16e54      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_122;
        // 0x00B16E48: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B16E4C: CBNZ w8, #0xb16e54         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_122;
        // 0x00B16E50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_122:
        // 0x00B16E54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16E58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B16E5C: MOV x1, x23                | X1 = val_56.clientVer;//m1              
        // 0x00B16E60: MOV x2, x24                | X2 = val_58.noRestartAssetsvs;//m1      
        // 0x00B16E64: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_56.clientVer);
        bool val_59 = System.String.op_Inequality(a:  0, b:  val_56.clientVer);
        // 0x00B16E68: TBZ w0, #0, #0xb16ec4      | if (val_59 == false) goto label_123;    
        if(val_59 == false)
        {
            goto label_123;
        }
        label_115:
        // 0x00B16E6C: LDR x23, [x19, #0x90]      | X23 = this.csscriptList; //P2           
        // 0x00B16E70: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B16E74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B16E78: STRB w8, [x19, #0x50]      | this.isRestart = true;                   //  dest_result_addr=1152921515142282992
        this.isRestart = true;
        // 0x00B16E7C: CBNZ x24, #0xb16e84        | if (this.serverList != null) goto label_124;
        if(this.serverList != null)
        {
            goto label_124;
        }
        // 0x00B16E80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_59, ????);     
        label_124:
        // 0x00B16E84: LDR x24, [x24, #0x18]      | 
        // 0x00B16E88: CBNZ x24, #0xb16e90        | if (this.serverList != null) goto label_125;
        if(this.serverList != null)
        {
            goto label_125;
        }
        // 0x00B16E8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_59, ????);     
        label_125:
        // 0x00B16E90: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B16E94: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B16E98: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16E9C: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_60 = this.serverList.Item[0];
        // 0x00B16EA0: MOV x24, x0                | X24 = val_60;//m1                       
        // 0x00B16EA4: CBNZ x23, #0xb16eac        | if (this.csscriptList != null) goto label_126;
        if(this.csscriptList != null)
        {
            goto label_126;
        }
        // 0x00B16EA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_60, ????);     
        label_126:
        // 0x00B16EAC: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
        // 0x00B16EB0: LDR x8, [x8, #0xcc0]       | X8 = 1152921514959166128;               
        // 0x00B16EB4: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<FileInfoRes>::Add(FileInfoRes item);
        // 0x00B16EB8: MOV x0, x23                | X0 = this.csscriptList;//m1             
        // 0x00B16EBC: MOV x1, x24                | X1 = val_60;//m1                        
        // 0x00B16EC0: BL #0x25ea480              | this.csscriptList.Add(item:  val_60);   
        this.csscriptList.Add(item:  val_60);
        label_123:
        // 0x00B16EC4: LDR x23, [x19, #0x88]      | X23 = this.updateList; //P2             
        val_86 = this.updateList;
        // 0x00B16EC8: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B16ECC: CBNZ x24, #0xb16ed4        | if (this.serverList != null) goto label_127;
        if(this.serverList != null)
        {
            goto label_127;
        }
        // 0x00B16ED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.csscriptList, ????);
        label_127:
        // 0x00B16ED4: LDR x24, [x24, #0x18]      | 
        // 0x00B16ED8: CBNZ x24, #0xb16ee0        | if (this.serverList != null) goto label_128;
        if(this.serverList != null)
        {
            goto label_128;
        }
        // 0x00B16EDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.csscriptList, ????);
        label_128:
        // 0x00B16EE0: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B16EE4: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B16EE8: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16EEC: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_61 = this.serverList.Item[0];
        // 0x00B16EF0: MOV x24, x0                | X24 = val_61;//m1                       
        // 0x00B16EF4: CBNZ x23, #0xb16efc        | if (this.updateList != null) goto label_129;
        if(val_86 != null)
        {
            goto label_129;
        }
        // 0x00B16EF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
        label_129:
        // 0x00B16EFC: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
        // 0x00B16F00: LDR x8, [x8, #0xcc0]       | X8 = 1152921514959166128;               
        // 0x00B16F04: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<FileInfoRes>::Add(FileInfoRes item);
        // 0x00B16F08: MOV x0, x23                | X0 = this.updateList;//m1               
        // 0x00B16F0C: MOV x1, x24                | X1 = val_61;//m1                        
        // 0x00B16F10: BL #0x25ea480              | this.updateList.Add(item:  val_61);     
        val_86.Add(item:  val_61);
        // 0x00B16F14: B #0xb16f3c                |  goto label_164;                        
        goto label_164;
        label_48:
        // 0x00B16F18: LDR x23, [x23, #0x10]      | X23 = 0x100B70003;                      
        val_86 = 11993091;
        // 0x00B16F1C: CBNZ x20, #0xb16f24        | if ( != 0) goto label_131;              
        if(null != 0)
        {
            goto label_131;
        }
        // 0x00B16F20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_131:
        // 0x00B16F24: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B16F28: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
        // 0x00B16F2C: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
        // 0x00B16F30: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B16F34: MOV x1, x23                | X1 = 4306960387 (0x100B70003);//ML01    
        // 0x00B16F38: BL #0x25ea480              | Add(item:  val_86);                     
        Add(item:  val_86);
        label_164:
        // 0x00B16F3C: ADD w22, w22, #1           | W22 = (0 + 1);                          
        val_86 = val_86 + 1;
        // 0x00B16F40: CMP w22, w21               | STATE = COMPARE((0 + 1), val_5)         
        // 0x00B16F44: B.LT #0xb16528             | if (0 < val_5) goto label_132;          
        if(val_86 < val_5)
        {
            goto label_132;
        }
        // 0x00B16F48: B #0xb17240                |  goto label_133;                        
        goto label_133;
        label_28:
        // 0x00B16F4C: LDR x24, [x19, #0x20]      | X24 = this.clientList; //P2             
        // 0x00B16F50: CBNZ x24, #0xb16f58        | if (this.clientList != null) goto label_134;
        if(this.clientList != null)
        {
            goto label_134;
        }
        // 0x00B16F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_134:
        // 0x00B16F58: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00B16F5C: LDR x8, [x8, #0xa98]       | X8 = 1152921515142121696;               
        // 0x00B16F60: LDR x2, [x8]               | X2 = public System.Void Filelist<FileInfoRes>::AddOrReplaceResData(FileInfoRes data);
        // 0x00B16F64: MOV x0, x24                | X0 = this.clientList;//m1               
        // 0x00B16F68: MOV x1, x23                | X1 = val_12;//m1                        
        // 0x00B16F6C: BL #0x19cd1c4              | this.clientList.AddOrReplaceResData(data:  val_12);
        this.clientList.AddOrReplaceResData(data:  val_12);
        // 0x00B16F70: LDR x24, [x19, #0x10]      | X24 = this.clientCrcList; //P2          
        // 0x00B16F74: LDR x23, [x23, #0x10]      | 
        // 0x00B16F78: CBNZ x24, #0xb16f80        | if (this.clientCrcList != null) goto label_135;
        if(this.clientCrcList != null)
        {
            goto label_135;
        }
        // 0x00B16F7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.clientList, ????);
        label_135:
        // 0x00B16F80: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00B16F84: LDR x8, [x8, #0x318]       | X8 = 1152921515142126816;               
        // 0x00B16F88: LDR x2, [x8]               | X2 = public System.Void Filelist<FileInfoCrc>::RemoveResData(string dataPath);
        // 0x00B16F8C: MOV x0, x24                | X0 = this.clientCrcList;//m1            
        // 0x00B16F90: MOV x1, x23                | X1 = val_12;//m1                        
        // 0x00B16F94: BL #0x19cd5a0              | this.clientCrcList.RemoveResData(dataPath:  val_12);
        this.clientCrcList.RemoveResData(dataPath:  val_12);
        // 0x00B16F98: BL #0xb14978               | X0 = this.clientCrcList.SavePath();     
        string val_62 = this.clientCrcList.SavePath();
        // 0x00B16F9C: MOV x23, x0                | X23 = val_62;//m1                       
        // 0x00B16FA0: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B16FA4: CBNZ x24, #0xb16fac        | if (this.serverList != null) goto label_136;
        if(this.serverList != null)
        {
            goto label_136;
        }
        // 0x00B16FA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_62, ????);     
        label_136:
        // 0x00B16FAC: LDR x24, [x24, #0x10]      | 
        // 0x00B16FB0: CBNZ x24, #0xb16fb8        | if (this.serverList != null) goto label_137;
        if(this.serverList != null)
        {
            goto label_137;
        }
        // 0x00B16FB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_62, ????);     
        label_137:
        // 0x00B16FB8: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B16FBC: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B16FC0: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B16FC4: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        string val_63 = this.serverList.Item[0];
        // 0x00B16FC8: MOV x24, x0                | X24 = val_63;//m1                       
        // 0x00B16FCC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B16FD0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B16FD4: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B16FD8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B16FDC: TBZ w8, #0, #0xb16fec      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_139;
        // 0x00B16FE0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B16FE4: CBNZ w8, #0xb16fec         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_139;
        // 0x00B16FE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_139:
        // 0x00B16FEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B16FF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B16FF4: MOV x1, x23                | X1 = val_62;//m1                        
        // 0x00B16FF8: MOV x2, x24                | X2 = val_63;//m1                        
        // 0x00B16FFC: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_62);
        string val_64 = System.String.Concat(str0:  0, str1:  val_62);
        // 0x00B17000: MOV x1, x0                 | X1 = val_64;//m1                        
        // 0x00B17004: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17008: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1700C: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_65 = System.IO.File.Exists(path:  0);
        // 0x00B17010: TBZ w0, #0, #0xb1708c      | if (val_65 == false) goto label_140;    
        if(val_65 == false)
        {
            goto label_140;
        }
        // 0x00B17014: BL #0xb14978               | X0 = val_65.SavePath();                 
        string val_66 = val_65.SavePath();
        // 0x00B17018: MOV x23, x0                | X23 = val_66;//m1                       
        // 0x00B1701C: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B17020: CBNZ x24, #0xb17028        | if (this.serverList != null) goto label_141;
        if(this.serverList != null)
        {
            goto label_141;
        }
        // 0x00B17024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_66, ????);     
        label_141:
        // 0x00B17028: LDR x24, [x24, #0x10]      | 
        // 0x00B1702C: CBNZ x24, #0xb17034        | if (this.serverList != null) goto label_142;
        if(this.serverList != null)
        {
            goto label_142;
        }
        // 0x00B17030: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_66, ????);     
        label_142:
        // 0x00B17034: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B17038: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B1703C: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B17040: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        string val_67 = this.serverList.Item[0];
        // 0x00B17044: MOV x24, x0                | X24 = val_67;//m1                       
        // 0x00B17048: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1704C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B17050: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B17054: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B17058: TBZ w8, #0, #0xb17068      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_144;
        // 0x00B1705C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B17060: CBNZ w8, #0xb17068         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_144;
        // 0x00B17064: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_144:
        // 0x00B17068: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1706C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17070: MOV x1, x23                | X1 = val_66;//m1                        
        // 0x00B17074: MOV x2, x24                | X2 = val_67;//m1                        
        // 0x00B17078: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_66);
        string val_68 = System.String.Concat(str0:  0, str1:  val_66);
        // 0x00B1707C: MOV x1, x0                 | X1 = val_68;//m1                        
        // 0x00B17080: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17084: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17088: BL #0x1e6a550              | System.IO.File.Delete(path:  0);        
        System.IO.File.Delete(path:  0);
        label_140:
        // 0x00B1708C: LDR x23, [x19, #0x38]      | X23 = this.clientStreamingList; //P2    
        // 0x00B17090: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B17094: CBNZ x24, #0xb1709c        | if (this.serverList != null) goto label_145;
        if(this.serverList != null)
        {
            goto label_145;
        }
        // 0x00B17098: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_145:
        // 0x00B1709C: LDR x24, [x24, #0x10]      | 
        // 0x00B170A0: CBNZ x24, #0xb170a8        | if (this.serverList != null) goto label_146;
        if(this.serverList != null)
        {
            goto label_146;
        }
        // 0x00B170A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_146:
        // 0x00B170A8: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B170AC: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B170B0: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B170B4: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        string val_69 = this.serverList.Item[0];
        // 0x00B170B8: MOV x24, x0                | X24 = val_69;//m1                       
        // 0x00B170BC: CBNZ x23, #0xb170c4        | if (this.clientStreamingList != null) goto label_147;
        if(this.clientStreamingList != null)
        {
            goto label_147;
        }
        // 0x00B170C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_69, ????);     
        label_147:
        // 0x00B170C4: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
        // 0x00B170C8: LDR x8, [x8, #0x518]       | X8 = 1152921515141824640;               
        // 0x00B170CC: LDR x2, [x8]               | X2 = public FileInfoRes Filelist<FileInfoRes>::GetResData(string fileName);
        // 0x00B170D0: MOV x0, x23                | X0 = this.clientStreamingList;//m1      
        // 0x00B170D4: MOV x1, x24                | X1 = val_69;//m1                        
        // 0x00B170D8: BL #0x19cd75c              | X0 = this.clientStreamingList.GetResData(fileName:  val_69);
        FileInfoRes val_70 = this.clientStreamingList.GetResData(fileName:  val_69);
        // 0x00B170DC: MOV x23, x0                | X23 = val_70;//m1                       
        // 0x00B170E0: CBZ x23, #0xb171b0         | if (val_70 == null) goto label_152;     
        if(val_70 == null)
        {
            goto label_152;
        }
        // 0x00B170E4: LDRB w8, [x23, #0x2c]      | W8 = val_70.isCompress; //P2            
        // 0x00B170E8: CMP w8, #1                 | STATE = COMPARE(val_70.isCompress, 0x1) 
        // 0x00B170EC: B.EQ #0xb171b0             | if (val_70.isCompress == true) goto label_152;
        if(val_70.isCompress == true)
        {
            goto label_152;
        }
        // 0x00B170F0: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B170F4: CBNZ x24, #0xb170fc        | if (this.serverList != null) goto label_150;
        if(this.serverList != null)
        {
            goto label_150;
        }
        // 0x00B170F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        label_150:
        // 0x00B170FC: LDR x24, [x24, #0x10]      | 
        // 0x00B17100: CBNZ x24, #0xb17108        | if (this.serverList != null) goto label_151;
        if(this.serverList != null)
        {
            goto label_151;
        }
        // 0x00B17104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        label_151:
        // 0x00B17108: LDR x2, [x27]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B1710C: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B17110: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B17114: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        string val_71 = this.serverList.Item[0];
        // 0x00B17118: MOV x1, x0                 | X1 = val_71;//m1                        
        // 0x00B1711C: LDR x2, [x23, #0x18]       | X2 = val_70.mDataMD5; //P2              
        // 0x00B17120: MOV x0, x19                | X0 = 1152921515142282912 (0x1000000273F5FEA0);//ML01
        // 0x00B17124: BL #0xb1828c               | X0 = this.VerifyMD5(path:  val_71, md5:  val_70.mDataMD5);
        bool val_72 = this.VerifyMD5(path:  val_71, md5:  val_70.mDataMD5);
        // 0x00B17128: MOV w24, w0                | W24 = val_72;//m1                       
        // 0x00B1712C: AND w8, w24, #1            | W8 = (val_72 & 1);                      
        bool val_73 = val_72;
        // 0x00B17130: TBNZ w8, #0, #0xb171b0     | if ((val_72 & 1) == true) goto label_152;
        if(val_73 == true)
        {
            goto label_152;
        }
        // 0x00B17134: LDR x25, [x23, #0x10]      | 
        // 0x00B17138: CBNZ x25, #0xb17140        | if (val_13.mDataMD5 != null) goto label_153;
        if(val_13.mDataMD5 != null)
        {
            goto label_153;
        }
        // 0x00B1713C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_72, ????);     
        label_153:
        // 0x00B17140: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B17144: MOV x0, x25                | X0 = val_13.mDataMD5;//m1               
        // 0x00B17148: BL #0x18a946c              | X0 = val_13.mDataMD5.Trim();            
        string val_74 = val_13.mDataMD5.Trim();
        // 0x00B1714C: MOV x25, x0                | X25 = val_74;//m1                       
        // 0x00B17150: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B17154: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B17158: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        // 0x00B1715C: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B17160: TBZ w8, #0, #0xb17170      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_155;
        // 0x00B17164: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B17168: CBNZ w8, #0xb17170         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_155;
        // 0x00B1716C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        label_155:
        // 0x00B17170: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17174: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17178: MOV x1, x25                | X1 = val_74;//m1                        
        // 0x00B1717C: BL #0xdbc79c               | X0 = Loader.PathUtil.StreamingAssetsPath(path:  0);
        string val_75 = Loader.PathUtil.StreamingAssetsPath(path:  0);
        // 0x00B17180: STR x0, [x23, #0x20]       | val_70.mPath = val_75;                   //  dest_result_addr=0
        val_70.mPath = val_75;
        // 0x00B17184: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17188: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1718C: BL #0xe156f8               | X0 = UnzipABAsset.get_Instance();       
        UnzipABAsset val_76 = UnzipABAsset.Instance;
        // 0x00B17190: MOV x25, x0                | X25 = val_76;//m1                       
        // 0x00B17194: CBNZ x25, #0xb1719c        | if (val_76 != null) goto label_156;     
        if(val_76 != null)
        {
            goto label_156;
        }
        // 0x00B17198: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
        label_156:
        // 0x00B1719C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B171A0: MOV x0, x25                | X0 = val_76;//m1                        
        // 0x00B171A4: MOV x1, x23                | X1 = val_70;//m1                        
        // 0x00B171A8: BL #0xe15774               | val_76.AddAsset(data:  val_70);         
        val_76.AddAsset(data:  val_70);
        // 0x00B171AC: TBZ w24, #0, #0xb16f3c     | if (val_72 == false) goto label_164;    
        if(val_72 == false)
        {
            goto label_164;
        }
        label_152:
        // 0x00B171B0: LDR x23, [x19, #0x10]      | X23 = this.clientCrcList; //P2          
        // 0x00B171B4: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B171B8: CBNZ x24, #0xb171c0        | if (this.serverList != null) goto label_158;
        if(this.serverList != null)
        {
            goto label_158;
        }
        // 0x00B171BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
        label_158:
        // 0x00B171C0: LDR x24, [x24, #0x18]      | 
        // 0x00B171C4: CBNZ x24, #0xb171cc        | if (this.serverList != null) goto label_159;
        if(this.serverList != null)
        {
            goto label_159;
        }
        // 0x00B171C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
        label_159:
        // 0x00B171CC: LDR x2, [x28]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B171D0: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B171D4: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
        // 0x00B171D8: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_77 = this.serverList.Item[0];
        // 0x00B171DC: MOV x24, x0                | X24 = val_77;//m1                       
        // 0x00B171E0: CBNZ x24, #0xb171e8        | if (val_77 != null) goto label_160;     
        if(val_77 != null)
        {
            goto label_160;
        }
        // 0x00B171E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_77, ????);     
        label_160:
        // 0x00B171E8: LDR x24, [x24, #0x10]      | 
        // 0x00B171EC: CBNZ x23, #0xb171f4        | if (this.clientCrcList != null) goto label_161;
        if(this.clientCrcList != null)
        {
            goto label_161;
        }
        // 0x00B171F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_77, ????);     
        label_161:
        // 0x00B171F4: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B171F8: LDR x8, [x8, #0xdc8]       | X8 = 1152921515141944448;               
        // 0x00B171FC: LDR x2, [x8]               | X2 = public FileInfoCrc Filelist<FileInfoCrc>::GetResData(string fileName);
        // 0x00B17200: MOV x0, x23                | X0 = this.clientCrcList;//m1            
        // 0x00B17204: MOV x1, x24                | X1 = val_77;//m1                        
        // 0x00B17208: BL #0x19cd75c              | X0 = this.clientCrcList.GetResData(fileName:  val_77);
        FileInfoCrc val_78 = this.clientCrcList.GetResData(fileName:  val_77);
        // 0x00B1720C: MOV x23, x0                | X23 = val_78;//m1                       
        // 0x00B17210: CBZ x23, #0xb16f3c         | if (val_78 == null) goto label_164;     
        if(val_78 == null)
        {
            goto label_164;
        }
        // 0x00B17214: LDR x24, [x19, #0x18]      | X24 = this.serverCrcList; //P2          
        // 0x00B17218: CBNZ x24, #0xb17220        | if (this.serverCrcList != null) goto label_163;
        if(this.serverCrcList != null)
        {
            goto label_163;
        }
        // 0x00B1721C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_78, ????);     
        label_163:
        // 0x00B17220: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00B17224: LDR x8, [x8, #0x188]       | X8 = 1152921514966434016;               
        // 0x00B17228: LDR x2, [x8]               | X2 = public System.Void Filelist<FileInfoCrc>::AddOrReplaceResData(FileInfoCrc data);
        // 0x00B1722C: MOV x0, x24                | X0 = this.serverCrcList;//m1            
        // 0x00B17230: MOV x1, x23                | X1 = val_78;//m1                        
        // 0x00B17234: BL #0x19cd1c4              | this.serverCrcList.AddOrReplaceResData(data:  val_78);
        this.serverCrcList.AddOrReplaceResData(data:  val_78);
        // 0x00B17238: B #0xb16f3c                |  goto label_164;                        
        goto label_164;
        // 0x00B1723C: B #0xb17360                |  goto label_185;                        
        goto label_185;
        label_133:
        // 0x00B17240: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17244: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B17248: BL #0xe156f8               | X0 = UnzipABAsset.get_Instance();       
        UnzipABAsset val_79 = UnzipABAsset.Instance;
        // 0x00B1724C: MOV x22, x0                | X22 = val_79;//m1                       
        // 0x00B17250: CBNZ x22, #0xb17258        | if (val_79 != null) goto label_166;     
        if(val_79 != null)
        {
            goto label_166;
        }
        // 0x00B17254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_79, ????);     
        label_166:
        // 0x00B17258: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1725C: ADRP x24, #0x35bd000       | X24 = 56348672 (0x35BD000);             
        // 0x00B17260: ADRP x25, #0x35c7000       | X25 = 56389632 (0x35C7000);             
        // 0x00B17264: ADRP x27, #0x35cc000       | X27 = 56410112 (0x35CC000);             
        // 0x00B17268: LDR x24, [x24, #0xb50]     | X24 = 1152921510890998992;              
        // 0x00B1726C: LDR x25, [x25, #0xf00]     | X25 = 1152921510891359184;              
        // 0x00B17270: LDR x27, [x27, #0x7d8]     | X27 = 1152921514959025456;              
        // 0x00B17274: STRB w8, [x22, #0x31]      | val_79.isChecked = true;                 //  dest_result_addr=0
        val_79.isChecked = true;
        // 0x00B17278: ADRP x28, #0x3660000       | X28 = 57016320 (0x3660000);             
        // 0x00B1727C: LDR x28, [x28, #0xcc0]     | X28 = 1152921514959166128;              
        // 0x00B17280: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_89 = 0;
        // 0x00B17284: B #0xb1728c                |  goto label_167;                        
        goto label_167;
        label_179:
        // 0x00B17288: ADD w21, w21, #1           | W21 = (val_89 + 1) = val_89 (0x00000001);
        val_89 = 1;
        label_167:
        // 0x00B1728C: LDR x22, [x19, #0x20]      | X22 = this.clientList; //P2             
        // 0x00B17290: CBNZ x22, #0xb17298        | if (this.clientList != null) goto label_168;
        if(this.clientList != null)
        {
            goto label_168;
        }
        // 0x00B17294: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_79, ????);     
        label_168:
        // 0x00B17298: LDR x22, [x22, #0x10]      | 
        // 0x00B1729C: CBNZ x22, #0xb172a4        | if (this.clientList != null) goto label_169;
        if(this.clientList != null)
        {
            goto label_169;
        }
        // 0x00B172A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_79, ????);     
        label_169:
        // 0x00B172A4: LDR x1, [x26]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B172A8: MOV x0, x22                | X0 = this.clientList;//m1               
        // 0x00B172AC: BL #0x25ed72c              | X0 = this.clientList.get_Count();       
        int val_80 = this.clientList.Count;
        // 0x00B172B0: CMP w21, w0                | STATE = COMPARE(0x1, val_80)            
        // 0x00B172B4: B.GE #0xb17408             | if (val_89 >= val_80) goto label_170;   
        if(val_89 >= val_80)
        {
            goto label_170;
        }
        // 0x00B172B8: LDR x22, [x19, #0x28]      | X22 = this.serverList; //P2             
        // 0x00B172BC: CBNZ x22, #0xb172c4        | if (this.serverList != null) goto label_171;
        if(this.serverList != null)
        {
            goto label_171;
        }
        // 0x00B172C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
        label_171:
        // 0x00B172C4: LDR x22, [x22, #0x10]      | 
        // 0x00B172C8: LDR x23, [x19, #0x20]      | X23 = this.clientList; //P2             
        // 0x00B172CC: CBNZ x23, #0xb172d4        | if (this.clientList != null) goto label_172;
        if(this.clientList != null)
        {
            goto label_172;
        }
        // 0x00B172D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
        label_172:
        // 0x00B172D4: LDR x23, [x23, #0x10]      | 
        // 0x00B172D8: CBNZ x23, #0xb172e0        | if (this.clientList != null) goto label_173;
        if(this.clientList != null)
        {
            goto label_173;
        }
        // 0x00B172DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
        label_173:
        // 0x00B172E0: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B172E4: MOV x0, x23                | X0 = this.clientList;//m1               
        // 0x00B172E8: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B172EC: BL #0x25ed734              | X0 = this.clientList.get_Item(index:  1);
        string val_81 = this.clientList.Item[1];
        // 0x00B172F0: MOV x23, x0                | X23 = val_81;//m1                       
        // 0x00B172F4: CBNZ x22, #0xb172fc        | if (this.serverList != null) goto label_174;
        if(this.serverList != null)
        {
            goto label_174;
        }
        // 0x00B172F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_81, ????);     
        label_174:
        // 0x00B172FC: LDR x2, [x25]              | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
        // 0x00B17300: MOV x0, x22                | X0 = this.serverList;//m1               
        // 0x00B17304: MOV x1, x23                | X1 = val_81;//m1                        
        // 0x00B17308: BL #0x25ead74              | X0 = this.serverList.Contains(item:  val_81);
        bool val_82 = this.serverList.Contains(item:  val_81);
        // 0x00B1730C: AND w8, w0, #1             | W8 = (val_82 & 1);                      
        bool val_83 = val_82;
        // 0x00B17310: TBNZ w8, #0, #0xb17288     | if ((val_82 & 1) == true) goto label_179;
        if(val_83 == true)
        {
            goto label_179;
        }
        // 0x00B17314: LDR x22, [x19, #0x68]      | X22 = this.removeList; //P2             
        // 0x00B17318: LDR x23, [x19, #0x20]      | X23 = this.clientList; //P2             
        // 0x00B1731C: CBNZ x23, #0xb17324        | if (this.clientList != null) goto label_176;
        if(this.clientList != null)
        {
            goto label_176;
        }
        // 0x00B17320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_82, ????);     
        label_176:
        // 0x00B17324: LDR x23, [x23, #0x18]      | 
        // 0x00B17328: CBNZ x23, #0xb17330        | if (this.clientList != null) goto label_177;
        if(this.clientList != null)
        {
            goto label_177;
        }
        // 0x00B1732C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_82, ????);     
        label_177:
        // 0x00B17330: LDR x2, [x27]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17334: MOV x0, x23                | X0 = this.clientList;//m1               
        // 0x00B17338: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B1733C: BL #0x25ed734              | X0 = this.clientList.get_Item(index:  1);
        FileInfoRes val_84 = this.clientList.Item[1];
        // 0x00B17340: MOV x23, x0                | X23 = val_84;//m1                       
        // 0x00B17344: CBNZ x22, #0xb1734c        | if (this.removeList != null) goto label_178;
        if(this.removeList != null)
        {
            goto label_178;
        }
        // 0x00B17348: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_84, ????);     
        label_178:
        // 0x00B1734C: LDR x2, [x28]              | X2 = public System.Void System.Collections.Generic.List<FileInfoRes>::Add(FileInfoRes item);
        // 0x00B17350: MOV x0, x22                | X0 = this.removeList;//m1               
        // 0x00B17354: MOV x1, x23                | X1 = val_84;//m1                        
        // 0x00B17358: BL #0x25ea480              | this.removeList.Add(item:  val_84);     
        this.removeList.Add(item:  val_84);
        // 0x00B1735C: B #0xb17288                |  goto label_179;                        
        goto label_179;
        label_185:
        // 0x00B17360: MOV x19, x0                | X19 = this.serverCrcList;//m1           
        val_90 = this.serverCrcList;
        // 0x00B17364: CMP w1, #1                 | STATE = COMPARE(val_78, 0x1)            
        // 0x00B17368: B.NE #0xb17484             | if (val_78 != 0x1) goto label_180;      
        if(val_78 != 1)
        {
            goto label_180;
        }
        // 0x00B1736C: MOV x0, x19                | X0 = this.serverCrcList;//m1            
        // 0x00B17370: BL #0x981060               | X0 = sub_981060( ?? this.serverCrcList, ????);
        // 0x00B17374: MOV x20, x0                | X20 = this.serverCrcList;//m1           
        // 0x00B17378: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B1737C: LDR x19, [x20]             | X19 = typeof(Filelist<FileInfoCrc>);    
        // 0x00B17380: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
        // 0x00B17384: LDR x1, [x19]              | X1 = ;                                  
        // 0x00B17388: LDR x0, [x8]               | X0 = typeof(System.Exception);          
        // 0x00B1738C: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
        // 0x00B17390: TBZ w0, #0, #0xb1745c      | if ((typeof(System.Exception) & 0x1) == 0) goto label_181;
        if((null & 1) == 0)
        {
            goto label_181;
        }
        // 0x00B17394: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
        // 0x00B17398: CBNZ x19, #0xb173a0        | if (typeof(Filelist<T>) != null) goto label_182;
        if(null != null)
        {
            goto label_182;
        }
        // 0x00B1739C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Exception), ????);
        label_182:
        // 0x00B173A0: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B173A4: MOV x0, x19                | X0 = 1152921504911052800 (0x100000001221D000);//ML01
        // 0x00B173A8: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
        // 0x00B173AC: BLR x9                     | X0 = mem[null + 320]();                 
        // 0x00B173B0: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B173B4: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B173B8: MOV x19, x0                | X19 = 1152921504911052800 (0x100000001221D000);//ML01
        // 0x00B173BC: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B173C0: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B173C4: TBZ w9, #0, #0xb173d8      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_184;
        // 0x00B173C8: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B173CC: CBNZ w9, #0xb173d8         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_184;
        // 0x00B173D0: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B173D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_184:
        // 0x00B173D8: MOV x1, x19                | X1 = 1152921504911052800 (0x100000001221D000);//ML01
        // 0x00B173DC: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B173E0: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B173E4: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B173E8: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B173EC: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B173F0: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00B173F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B173F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B173FC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B17400: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00B17404: B #0xb5b538                | EDebug.LogError(message:  0, isShowStack:  false); return;
        EDebug.LogError(message:  0, isShowStack:  false);
        return;
        label_170:
        // 0x00B17408: MOV x0, x19                | X0 = 1152921515142282912 (0x1000000273F5FEA0);//ML01
        // 0x00B1740C: BL #0xb146ec               | this.DelOverFile();                     
        this.DelOverFile();
        // 0x00B17410: MOV x0, x19                | X0 = 1152921515142282912 (0x1000000273F5FEA0);//ML01
        // 0x00B17414: MOV x1, x20                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B17418: BL #0xb14a58               | this.DelSubFile(delList:  null);        
        this.DelSubFile(delList:  null);
        // 0x00B1741C: LDR x1, [x19, #0x18]       | X1 = this.serverCrcList; //P2           
        // 0x00B17420: MOV x0, x19                | X0 = 1152921515142282912 (0x1000000273F5FEA0);//ML01
        // 0x00B17424: BL #0xb18964               | this.WriteCrc(fileList:  this.serverCrcList);
        this.WriteCrc(fileList:  this.serverCrcList);
        // 0x00B17428: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00B1742C: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
        // 0x00B17430: STRB w9, [x19, #0xaa]      | this.<isVerifyed>k__BackingField = true;  //  dest_result_addr=1152921515142283082
        this.<isVerifyed>k__BackingField = true;
        // 0x00B17434: STR w8, [x19, #0xac]       | this.<VerifyProgress>k__BackingField = 1;  //  dest_result_addr=1152921515142283084
        this.<VerifyProgress>k__BackingField = 1f;
        // 0x00B17438: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1743C: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B17440: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B17444: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B17448: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1744C: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00B17450: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00B17454: RET                        |  return;                                
        return;
        // 0x00B17458: B #0xb17360                |  goto label_185;                        
        goto label_185;
        label_181:
        // 0x00B1745C: ORR w0, wzr, #8            | W0 = 8(0x8);                            
        // 0x00B17460: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
        // 0x00B17464: LDR x8, [x20]              | X8 = typeof(Filelist<FileInfoCrc>);     
        // 0x00B17468: STR x8, [x0]               | mem[8] = typeof(Filelist<T>);            //  dest_result_addr=8
        mem[8] = null;
        // 0x00B1746C: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
        // 0x00B17470: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17474: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
        // 0x00B17478: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
        // 0x00B1747C: MOV x19, x0                | X19 = 8 (0x8);//ML01                    
        val_90 = 8;
        // 0x00B17480: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
        label_180:
        // 0x00B17484: MOV x0, x19                | X0 = 8 (0x8);//ML01                     
        // 0x00B17488: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
        // 0x00B1748C: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
    
    }
    //
    // Offset in libil2cpp.so: 0x00B17490 (11629712), len: 3580  VirtAddr: 0x00B17490 RVA: 0x00B17490 token: 100694265 methodIndex: 24608 delegateWrapperIndex: 0 methodInvoker: 0
    private void CheckSOHook()
    {
        //
        // Disasemble & Code
        //  | 
        var val_91;
        //  | 
        string val_92;
        //  | 
        var val_93;
        //  | 
        var val_94;
        //  | 
        var val_95;
        //  | 
        var val_96;
        //  | 
        var val_97;
        //  | 
        string val_98;
        //  | 
        string val_99;
        //  | 
        string val_100;
        //  | 
        string val_101;
        //  | 
        System.Byte[] val_102;
        //  | 
        string val_103;
        //  | 
        var val_104;
        //  | 
        var val_105;
        //  | 
        var val_106;
        // 0x00B17490: STP x28, x27, [sp, #-0x60]! | stack[1152921515143476736] = ???;  stack[1152921515143476744] = ???;  //  dest_result_addr=1152921515143476736 |  dest_result_addr=1152921515143476744
        // 0x00B17494: STP x26, x25, [sp, #0x10]  | stack[1152921515143476752] = ???;  stack[1152921515143476760] = ???;  //  dest_result_addr=1152921515143476752 |  dest_result_addr=1152921515143476760
        // 0x00B17498: STP x24, x23, [sp, #0x20]  | stack[1152921515143476768] = ???;  stack[1152921515143476776] = ???;  //  dest_result_addr=1152921515143476768 |  dest_result_addr=1152921515143476776
        // 0x00B1749C: STP x22, x21, [sp, #0x30]  | stack[1152921515143476784] = ???;  stack[1152921515143476792] = ???;  //  dest_result_addr=1152921515143476784 |  dest_result_addr=1152921515143476792
        // 0x00B174A0: STP x20, x19, [sp, #0x40]  | stack[1152921515143476800] = ???;  stack[1152921515143476808] = ???;  //  dest_result_addr=1152921515143476800 |  dest_result_addr=1152921515143476808
        // 0x00B174A4: STP x29, x30, [sp, #0x50]  | stack[1152921515143476816] = ???;  stack[1152921515143476824] = ???;  //  dest_result_addr=1152921515143476816 |  dest_result_addr=1152921515143476824
        // 0x00B174A8: ADD x29, sp, #0x50         | X29 = (1152921515143476736 + 80) = 1152921515143476816 (0x1000000274083650);
        // 0x00B174AC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B174B0: LDRB w8, [x20, #0x6e0]     | W8 = (bool)static_value_037336E0;       
        // 0x00B174B4: MOV x19, x0                | X19 = 1152921515143488832 (0x1000000274086540);//ML01
        // 0x00B174B8: TBNZ w8, #0, #0xb174d4     | if (static_value_037336E0 == true) goto label_0;
        // 0x00B174BC: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x00B174C0: LDR x8, [x8, #0x28]        | X8 = 0x2B8A698;                         
        // 0x00B174C4: LDR w0, [x8]               | W0 = 0x64;                              
        // 0x00B174C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x64, ????);       
        // 0x00B174CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B174D0: STRB w8, [x20, #0x6e0]     | static_value_037336E0 = true;            //  dest_result_addr=57882336
        label_0:
        // 0x00B174D4: LDR x20, [x19, #0x28]      | X20 = this.serverList; //P2             
        // 0x00B174D8: CBNZ x20, #0xb174e0        | if (this.serverList != null) goto label_1;
        if(this.serverList != null)
        {
            goto label_1;
        }
        // 0x00B174DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x64, ????);       
        label_1:
        // 0x00B174E0: LDR x20, [x20, #0x10]      | 
        // 0x00B174E4: CBNZ x20, #0xb174ec        | if (this.serverList != null) goto label_2;
        if(this.serverList != null)
        {
            goto label_2;
        }
        // 0x00B174E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x64, ????);       
        label_2:
        // 0x00B174EC: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B174F0: LDR x8, [x8, #0xb58]       | X8 = 1152921510022759280;               
        // 0x00B174F4: MOV x0, x20                | X0 = this.serverList;//m1               
        // 0x00B174F8: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B174FC: BL #0x25ed72c              | X0 = this.serverList.get_Count();       
        int val_1 = this.serverList.Count;
        // 0x00B17500: MOV w20, w0                | W20 = val_1;//m1                        
        // 0x00B17504: CMP w20, #1                | STATE = COMPARE(val_1, 0x1)             
        // 0x00B17508: B.LT #0xb18270             | if (val_1 < 1) goto label_3;            
        if(val_1 < 1)
        {
            goto label_3;
        }
        // 0x00B1750C: ADRP x25, #0x35cc000       | X25 = 56410112 (0x35CC000);             
        // 0x00B17510: ADRP x28, #0x3632000       | X28 = 56827904 (0x3632000);             
        // 0x00B17514: ADRP x27, #0x35ef000       | X27 = 56553472 (0x35EF000);             
        // 0x00B17518: ADRP x24, #0x3648000       | X24 = 56918016 (0x3648000);             
        // 0x00B1751C: LDR x25, [x25, #0x7d8]     | X25 = 1152921514959025456;              
        // 0x00B17520: LDR x28, [x28, #0xfc8]     | X28 = (string**)(1152921514967116720)("_csscript.uab");
        // 0x00B17524: LDR x27, [x27, #0xde8]     | X27 = 1152921504911265792;              
        val_91 = 1152921504911265792;
        // 0x00B17528: LDR x24, [x24, #0xa8]      | X24 = (string**)(1152921515142833760)("assets_bin_Data");
        // 0x00B1752C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        string val_91 = 0;
        label_132:
        // 0x00B17530: LDR x22, [x19, #0x28]      | X22 = this.serverList; //P2             
        // 0x00B17534: CBNZ x22, #0xb1753c        | if (this.serverList != null) goto label_4;
        if(this.serverList != null)
        {
            goto label_4;
        }
        // 0x00B17538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B1753C: LDR x22, [x22, #0x18]      | 
        // 0x00B17540: CBNZ x22, #0xb17548        | if (this.serverList != null) goto label_5;
        if(this.serverList != null)
        {
            goto label_5;
        }
        // 0x00B17544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00B17548: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B1754C: MOV x0, x22                | X0 = this.serverList;//m1               
        // 0x00B17550: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17554: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_2 = this.serverList.Item[0];
        // 0x00B17558: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00B1755C: CBNZ x22, #0xb17564        | if (val_2 != null) goto label_6;        
        if(val_2 != null)
        {
            goto label_6;
        }
        // 0x00B17560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B17564: LDR x22, [x22, #0x10]      | 
        // 0x00B17568: CBNZ x22, #0xb17570        | if (val_2 != null) goto label_7;        
        if(val_2 != null)
        {
            goto label_7;
        }
        // 0x00B1756C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B17570: LDR x1, [x28]              | X1 = "_csscript.uab";                   
        // 0x00B17574: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17578: MOV x0, x22                | X0 = val_2;//m1                         
        // 0x00B1757C: BL #0x18ab0a0              | X0 = val_2.EndsWith(value:  "_csscript.uab");
        bool val_3 = val_2.EndsWith(value:  "_csscript.uab");
        // 0x00B17580: LDR x22, [x19, #0x28]      | X22 = this.serverList; //P2             
        // 0x00B17584: MOV w23, w0                | W23 = val_3;//m1                        
        val_92 = val_3;
        // 0x00B17588: CBNZ x22, #0xb17590        | if (this.serverList != null) goto label_8;
        if(this.serverList != null)
        {
            goto label_8;
        }
        // 0x00B1758C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B17590: LDR x22, [x22, #0x18]      | 
        // 0x00B17594: CBNZ x22, #0xb1759c        | if (this.serverList != null) goto label_9;
        if(this.serverList != null)
        {
            goto label_9;
        }
        // 0x00B17598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00B1759C: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B175A0: MOV x0, x22                | X0 = this.serverList;//m1               
        // 0x00B175A4: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B175A8: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_4 = this.serverList.Item[0];
        // 0x00B175AC: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B175B0: CBNZ x22, #0xb175b8        | if (val_4 != null) goto label_10;       
        if(val_4 != null)
        {
            goto label_10;
        }
        // 0x00B175B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_10:
        // 0x00B175B8: LDR x22, [x22, #0x10]      | 
        // 0x00B175BC: TBZ w23, #0, #0xb176dc     | if (val_3 == false) goto label_11;      
        if(val_92 == false)
        {
            goto label_11;
        }
        // 0x00B175C0: LDR x0, [x27]              | X0 = typeof(Loader.PathUtil);           
        val_93 = null;
        // 0x00B175C4: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B175C8: TBZ w8, #0, #0xb175dc      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B175CC: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B175D0: CBNZ w8, #0xb175dc         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B175D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B175D8: LDR x0, [x27]              | X0 = typeof(Loader.PathUtil);           
        val_93 = null;
        label_13:
        // 0x00B175DC: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B175E0: LDR x23, [x8, #0x10]       | X23 = Loader.PathUtil.ARCH_ABI_TYPE;    
        val_92 = Loader.PathUtil.ARCH_ABI_TYPE;
        // 0x00B175E4: CBNZ x22, #0xb175ec        | if (val_4 != null) goto label_14;       
        if(val_4 != null)
        {
            goto label_14;
        }
        // 0x00B175E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
        label_14:
        // 0x00B175EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B175F0: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B175F4: MOV x1, x23                | X1 = Loader.PathUtil.ARCH_ABI_TYPE;//m1 
        // 0x00B175F8: BL #0x18ad42c              | X0 = val_4.Contains(value:  val_92);    
        bool val_5 = val_4.Contains(value:  val_92);
        // 0x00B175FC: TBZ w0, #0, #0xb18264      | if (val_5 == false) goto label_126;     
        if(val_5 == false)
        {
            goto label_126;
        }
        // 0x00B17600: BL #0xb14978               | X0 = val_5.SavePath();                  
        string val_6 = val_5.SavePath();
        // 0x00B17604: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17608: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00B1760C: CBNZ x23, #0xb17614        | if (this.serverList != null) goto label_16;
        if(this.serverList != null)
        {
            goto label_16;
        }
        // 0x00B17610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_16:
        // 0x00B17614: LDR x23, [x23, #0x18]      | 
        // 0x00B17618: CBNZ x23, #0xb17620        | if (this.serverList != null) goto label_17;
        if(this.serverList != null)
        {
            goto label_17;
        }
        // 0x00B1761C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_17:
        // 0x00B17620: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17624: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B17628: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B1762C: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_7 = this.serverList.Item[0];
        // 0x00B17630: MOV x23, x0                | X23 = val_7;//m1                        
        // 0x00B17634: CBNZ x23, #0xb1763c        | if (val_7 != null) goto label_18;       
        if(val_7 != null)
        {
            goto label_18;
        }
        // 0x00B17638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_18:
        // 0x00B1763C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B17640: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B17644: LDR x23, [x23, #0x10]      | 
        // 0x00B17648: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B1764C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B17650: TBZ w8, #0, #0xb17660      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B17654: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B17658: CBNZ w8, #0xb17660         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B1765C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_20:
        // 0x00B17660: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17664: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17668: MOV x1, x22                | X1 = val_6;//m1                         
        // 0x00B1766C: MOV x2, x23                | X2 = val_7;//m1                         
        // 0x00B17670: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_6);
        string val_8 = System.String.Concat(str0:  0, str1:  val_6);
        // 0x00B17674: MOV x1, x0                 | X1 = val_8;//m1                         
        // 0x00B17678: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1767C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17680: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_9 = System.IO.File.Exists(path:  0);
        // 0x00B17684: TBZ w0, #0, #0xb18264      | if (val_9 == false) goto label_126;     
        if(val_9 == false)
        {
            goto label_126;
        }
        // 0x00B17688: BL #0xb14978               | X0 = val_9.SavePath();                  
        string val_10 = val_9.SavePath();
        // 0x00B1768C: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17690: MOV x22, x0                | X22 = val_10;//m1                       
        // 0x00B17694: CBNZ x23, #0xb1769c        | if (this.serverList != null) goto label_22;
        if(this.serverList != null)
        {
            goto label_22;
        }
        // 0x00B17698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_22:
        // 0x00B1769C: LDR x23, [x23, #0x18]      | 
        // 0x00B176A0: CBNZ x23, #0xb176a8        | if (this.serverList != null) goto label_23;
        if(this.serverList != null)
        {
            goto label_23;
        }
        // 0x00B176A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_23:
        // 0x00B176A8: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B176AC: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B176B0: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B176B4: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_11 = this.serverList.Item[0];
        // 0x00B176B8: MOV x23, x0                | X23 = val_11;//m1                       
        // 0x00B176BC: CBNZ x23, #0xb176c4        | if (val_11 != null) goto label_24;      
        if(val_11 != null)
        {
            goto label_24;
        }
        // 0x00B176C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_24:
        // 0x00B176C4: LDR x0, [x27]              | X0 = typeof(Loader.PathUtil);           
        val_94 = null;
        // 0x00B176C8: LDR x23, [x23, #0x10]      | 
        // 0x00B176CC: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B176D0: TBNZ w8, #0, #0xb177e8     | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor != 0) goto label_25;
        // 0x00B176D4: MOV x26, x27               | X26 = 57993960 (0x374EAE8);//ML01       
        val_95 = val_91;
        // 0x00B176D8: B #0xb177f4                |  goto label_26;                         
        goto label_26;
        label_11:
        // 0x00B176DC: CBNZ x22, #0xb176e4        | if (val_4 != null) goto label_27;       
        if(val_4 != null)
        {
            goto label_27;
        }
        // 0x00B176E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_27:
        // 0x00B176E4: LDR x1, [x24]              | X1 = "assets_bin_Data";                 
        // 0x00B176E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B176EC: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B176F0: BL #0x18ad42c              | X0 = val_4.Contains(value:  "assets_bin_Data");
        bool val_12 = val_4.Contains(value:  "assets_bin_Data");
        // 0x00B176F4: TBZ w0, #0, #0xb18264      | if (val_12 == false) goto label_126;    
        if(val_12 == false)
        {
            goto label_126;
        }
        // 0x00B176F8: BL #0xb14978               | X0 = val_12.SavePath();                 
        string val_13 = val_12.SavePath();
        // 0x00B176FC: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17700: MOV x22, x0                | X22 = val_13;//m1                       
        // 0x00B17704: CBNZ x23, #0xb1770c        | if (this.serverList != null) goto label_29;
        if(this.serverList != null)
        {
            goto label_29;
        }
        // 0x00B17708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_29:
        // 0x00B1770C: LDR x23, [x23, #0x18]      | 
        // 0x00B17710: CBNZ x23, #0xb17718        | if (this.serverList != null) goto label_30;
        if(this.serverList != null)
        {
            goto label_30;
        }
        // 0x00B17714: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_30:
        // 0x00B17718: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B1771C: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B17720: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17724: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_14 = this.serverList.Item[0];
        // 0x00B17728: MOV x23, x0                | X23 = val_14;//m1                       
        // 0x00B1772C: CBNZ x23, #0xb17734        | if (val_14 != null) goto label_31;      
        if(val_14 != null)
        {
            goto label_31;
        }
        // 0x00B17730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_31:
        // 0x00B17734: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B17738: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1773C: LDR x23, [x23, #0x10]      | 
        // 0x00B17740: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B17744: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B17748: TBZ w8, #0, #0xb17758      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_33;
        // 0x00B1774C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B17750: CBNZ w8, #0xb17758         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
        // 0x00B17754: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_33:
        // 0x00B17758: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1775C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17760: MOV x1, x22                | X1 = val_13;//m1                        
        // 0x00B17764: MOV x2, x23                | X2 = val_14;//m1                        
        // 0x00B17768: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_13);
        string val_15 = System.String.Concat(str0:  0, str1:  val_13);
        // 0x00B1776C: MOV x1, x0                 | X1 = val_15;//m1                        
        // 0x00B17770: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17774: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17778: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_16 = System.IO.File.Exists(path:  0);
        // 0x00B1777C: TBZ w0, #0, #0xb18264      | if (val_16 == false) goto label_126;    
        if(val_16 == false)
        {
            goto label_126;
        }
        // 0x00B17780: BL #0xb14978               | X0 = val_16.SavePath();                 
        string val_17 = val_16.SavePath();
        // 0x00B17784: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17788: MOV x22, x0                | X22 = val_17;//m1                       
        // 0x00B1778C: CBNZ x23, #0xb17794        | if (this.serverList != null) goto label_35;
        if(this.serverList != null)
        {
            goto label_35;
        }
        // 0x00B17790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_35:
        // 0x00B17794: LDR x23, [x23, #0x18]      | 
        // 0x00B17798: CBNZ x23, #0xb177a0        | if (this.serverList != null) goto label_36;
        if(this.serverList != null)
        {
            goto label_36;
        }
        // 0x00B1779C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_36:
        // 0x00B177A0: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B177A4: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B177A8: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B177AC: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_18 = this.serverList.Item[0];
        // 0x00B177B0: MOV x23, x0                | X23 = val_18;//m1                       
        // 0x00B177B4: CBNZ x23, #0xb177bc        | if (val_18 != null) goto label_37;      
        if(val_18 != null)
        {
            goto label_37;
        }
        // 0x00B177B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_37:
        // 0x00B177BC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B177C0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B177C4: LDR x23, [x23, #0x10]      | 
        // 0x00B177C8: LDR x0, [x8]               | X0 = typeof(System.String);             
        val_96 = null;
        // 0x00B177CC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B177D0: TBZ w8, #0, #0xb177dc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_38;
        // 0x00B177D4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B177D8: CBZ w8, #0xb177fc          | if (System.String.__il2cppRuntimeField_cctor_finished == 0) goto label_39;
        label_38:
        // 0x00B177DC: MOV x26, x27               | X26 = 57993960 (0x374EAE8);//ML01       
        val_95 = val_91;
        // 0x00B177E0: MOV x27, x24               | X27 = 58334280 (0x37A1C48);//ML01       
        val_97 = "assets_bin_Data";
        // 0x00B177E4: B #0xb17814                |  goto label_40;                         
        goto label_40;
        label_25:
        // 0x00B177E8: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B177EC: MOV x26, x27               | X26 = 57993960 (0x374EAE8);//ML01       
        val_95 = val_91;
        // 0x00B177F0: CBZ w8, #0xb17d48          | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished == 0) goto label_41;
        label_26:
        // 0x00B177F4: MOV x27, x24               | X27 = 58334280 (0x37A1C48);//ML01       
        val_97 = "assets_bin_Data";
        // 0x00B177F8: B #0xb17d54                |  goto label_42;                         
        goto label_42;
        label_39:
        // 0x00B177FC: MOV x26, x27               | X26 = 57993960 (0x374EAE8);//ML01       
        val_95 = val_91;
        // 0x00B17800: MOV x27, x24               | X27 = 58334280 (0x37A1C48);//ML01       
        val_97 = "assets_bin_Data";
        // 0x00B17804: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B17808: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1780C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B17810: LDR x0, [x8]               | X0 = typeof(System.String);             
        val_96 = null;
        label_40:
        // 0x00B17814: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B17818: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1781C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B17820: MOV x1, x23                | X1 = val_18;//m1                        
        // 0x00B17824: LDR x3, [x8]               | X3 = System.String.Empty;               
        // 0x00B17828: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00B1782C: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921515142907600)(".uab");
        // 0x00B17830: LDR x2, [x8]               | X2 = ".uab";                            
        // 0x00B17834: BL #0x27954f0              | X0 = EString.EReplace(t:  0, oldString:  val_18, newString:  ".uab");
        string val_19 = EString.EReplace(t:  0, oldString:  val_18, newString:  ".uab");
        // 0x00B17838: MOV x2, x0                 | X2 = val_19;//m1                        
        // 0x00B1783C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17840: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17844: MOV x1, x22                | X1 = val_17;//m1                        
        // 0x00B17848: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_17);
        string val_20 = System.String.Concat(str0:  0, str1:  val_17);
        // 0x00B1784C: MOV x1, x0                 | X1 = val_20;//m1                        
        // 0x00B17850: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17854: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17858: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_21 = System.IO.File.Exists(path:  0);
        // 0x00B1785C: MOV w23, w0                | W23 = val_21;//m1                       
        // 0x00B17860: BL #0xb14978               | X0 = val_21.SavePath();                 
        string val_22 = val_21.SavePath();
        // 0x00B17864: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B17868: MOV x22, x0                | X22 = val_22;//m1                       
        // 0x00B1786C: CBNZ x24, #0xb17874        | if (this.serverList != null) goto label_43;
        if(this.serverList != null)
        {
            goto label_43;
        }
        // 0x00B17870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_43:
        // 0x00B17874: LDR x24, [x24, #0x18]      | 
        // 0x00B17878: CBNZ x24, #0xb17880        | if (this.serverList != null) goto label_44;
        if(this.serverList != null)
        {
            goto label_44;
        }
        // 0x00B1787C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_44:
        // 0x00B17880: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17884: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B17888: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B1788C: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_23 = this.serverList.Item[0];
        // 0x00B17890: MOV x24, x0                | X24 = val_23;//m1                       
        // 0x00B17894: CBNZ x24, #0xb1789c        | if (val_23 != null) goto label_45;      
        if(val_23 != null)
        {
            goto label_45;
        }
        // 0x00B17898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_45:
        // 0x00B1789C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B178A0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B178A4: LDR x24, [x24, #0x10]      | 
        // 0x00B178A8: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B178AC: ADD x8, x0, #0x109         | X8 = (null + 265) = 1152921504608284937 (0x100000000015F109);
        // 0x00B178B0: LDRH w8, [x8]              | W8 = System.String.__il2cppRuntimeField_109;
        // 0x00B178B4: AND w8, w8, #0x100         | W8 = (System.String.__il2cppRuntimeField_109 & 256);
        // 0x00B178B8: AND w8, w8, #0xffff        | W8 = ((System.String.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00B178BC: TBZ w23, #0, #0xb17c6c     | if (val_21 == false) goto label_46;     
        if(val_21 == false)
        {
            goto label_46;
        }
        // 0x00B178C0: CBZ w8, #0xb178d0          | if (((System.String.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_48;
        // 0x00B178C4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B178C8: CBNZ w8, #0xb178d0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_48;
        // 0x00B178CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_48:
        // 0x00B178D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B178D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B178D8: MOV x1, x22                | X1 = val_22;//m1                        
        // 0x00B178DC: MOV x2, x24                | X2 = val_23;//m1                        
        // 0x00B178E0: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_22);
        string val_26 = System.String.Concat(str0:  0, str1:  val_22);
        // 0x00B178E4: MOV x1, x0                 | X1 = val_26;//m1                        
        // 0x00B178E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B178EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B178F0: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_27 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B178F4: MOV x1, x0                 | X1 = val_27;//m1                        
        // 0x00B178F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B178FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17900: BL #0xab7c8c               | X0 = Mihua.Assets.UnzipAssetMgr.BZip2DeCompression(bytes:  0);
        System.Byte[] val_28 = Mihua.Assets.UnzipAssetMgr.BZip2DeCompression(bytes:  0);
        // 0x00B17904: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B17908: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B1790C: MOV x22, x0                | X22 = val_28;//m1                       
        // 0x00B17910: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B17914: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B17918: TBZ w9, #0, #0xb1792c      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_50;
        // 0x00B1791C: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B17920: CBNZ w9, #0xb1792c         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_50;
        // 0x00B17924: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B17928: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_50:
        // 0x00B1792C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17930: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17934: MOV x1, x22                | X1 = val_28;//m1                        
        // 0x00B17938: BL #0xac28b4               | X0 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        string val_29 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        // 0x00B1793C: MOV x22, x0                | X22 = val_29;//m1                       
        // 0x00B17940: BL #0xb14978               | X0 = val_29.SavePath();                 
        string val_30 = val_29.SavePath();
        // 0x00B17944: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B17948: MOV x23, x0                | X23 = val_30;//m1                       
        // 0x00B1794C: CBNZ x24, #0xb17954        | if (this.serverList != null) goto label_51;
        if(this.serverList != null)
        {
            goto label_51;
        }
        // 0x00B17950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_51:
        // 0x00B17954: LDR x24, [x24, #0x18]      | 
        // 0x00B17958: CBNZ x24, #0xb17960        | if (this.serverList != null) goto label_52;
        if(this.serverList != null)
        {
            goto label_52;
        }
        // 0x00B1795C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_52:
        // 0x00B17960: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17964: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B17968: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B1796C: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_31 = this.serverList.Item[0];
        // 0x00B17970: MOV x24, x0                | X24 = val_31;//m1                       
        // 0x00B17974: CBNZ x24, #0xb1797c        | if (val_31 != null) goto label_53;      
        if(val_31 != null)
        {
            goto label_53;
        }
        // 0x00B17978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_53:
        // 0x00B1797C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B17980: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B17984: LDR x1, [x24, #0x10]       | 
        // 0x00B17988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1798C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B17990: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B17994: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B17998: LDR x3, [x8]               | X3 = System.String.Empty;               
        // 0x00B1799C: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00B179A0: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921515142907600)(".uab");
        // 0x00B179A4: LDR x2, [x8]               | X2 = ".uab";                            
        // 0x00B179A8: BL #0x27954f0              | X0 = EString.EReplace(t:  0, oldString:  0, newString:  ".uab");
        string val_32 = EString.EReplace(t:  0, oldString:  val_91, newString:  ".uab");
        // 0x00B179AC: MOV x2, x0                 | X2 = val_32;//m1                        
        // 0x00B179B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B179B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B179B8: MOV x1, x23                | X1 = val_30;//m1                        
        // 0x00B179BC: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_30);
        string val_33 = System.String.Concat(str0:  0, str1:  val_30);
        // 0x00B179C0: MOV x1, x0                 | X1 = val_33;//m1                        
        // 0x00B179C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B179C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B179CC: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_34 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B179D0: MOV x1, x0                 | X1 = val_34;//m1                        
        // 0x00B179D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B179D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B179DC: BL #0xac28b4               | X0 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        string val_35 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        // 0x00B179E0: MOV x2, x0                 | X2 = val_35;//m1                        
        // 0x00B179E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B179E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B179EC: MOV x1, x22                | X1 = val_29;//m1                        
        // 0x00B179F0: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_29);
        bool val_36 = System.String.op_Equality(a:  0, b:  val_29);
        // 0x00B179F4: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B179F8: MOV w22, w0                | W22 = val_36;//m1                       
        // 0x00B179FC: CBNZ x23, #0xb17a04        | if (this.serverList != null) goto label_54;
        if(this.serverList != null)
        {
            goto label_54;
        }
        // 0x00B17A00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_54:
        // 0x00B17A04: LDR x23, [x23, #0x18]      | 
        // 0x00B17A08: CBNZ x23, #0xb17a10        | if (this.serverList != null) goto label_55;
        if(this.serverList != null)
        {
            goto label_55;
        }
        // 0x00B17A0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_55:
        // 0x00B17A10: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17A14: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B17A18: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17A1C: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_37 = this.serverList.Item[0];
        // 0x00B17A20: MOV x23, x0                | X23 = val_37;//m1                       
        // 0x00B17A24: CBNZ x23, #0xb17a2c        | if (val_37 != null) goto label_56;      
        if(val_37 != null)
        {
            goto label_56;
        }
        // 0x00B17A28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_56:
        // 0x00B17A2C: LDR x23, [x23, #0x10]      | 
        // 0x00B17A30: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B17A34: CBNZ x24, #0xb17a3c        | if (this.serverList != null) goto label_57;
        if(this.serverList != null)
        {
            goto label_57;
        }
        // 0x00B17A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_57:
        // 0x00B17A3C: LDR x24, [x24, #0x18]      | 
        // 0x00B17A40: CBNZ x24, #0xb17a48        | if (this.serverList != null) goto label_58;
        if(this.serverList != null)
        {
            goto label_58;
        }
        // 0x00B17A44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_58:
        // 0x00B17A48: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17A4C: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B17A50: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17A54: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_38 = this.serverList.Item[0];
        // 0x00B17A58: MOV x24, x0                | X24 = val_38;//m1                       
        // 0x00B17A5C: CBNZ x24, #0xb17a64        | if (val_38 != null) goto label_59;      
        if(val_38 != null)
        {
            goto label_59;
        }
        // 0x00B17A60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
        label_59:
        // 0x00B17A64: LDR x2, [x24, #0x18]       | X2 = val_38.mDataMD5; //P2              
        // 0x00B17A68: MOV x0, x19                | X0 = 1152921515143488832 (0x1000000274086540);//ML01
        // 0x00B17A6C: MOV x1, x23                | X1 = val_37;//m1                        
        // 0x00B17A70: BL #0xb1828c               | X0 = this.VerifyMD5(path:  val_37, md5:  val_38.mDataMD5);
        bool val_39 = this.VerifyMD5(path:  val_37, md5:  val_38.mDataMD5);
        // 0x00B17A74: AND w8, w22, w0            | W8 = (val_36 & val_39);                 
        bool val_40 = val_36 & val_39;
        // 0x00B17A78: MOV x24, x27               | X24 = 58334280 (0x37A1C48);//ML01       
        // 0x00B17A7C: MOV x27, x26               | X27 = 57993960 (0x374EAE8);//ML01       
        val_91 = val_95;
        // 0x00B17A80: AND w8, w8, #1             | W8 = ((val_36 & val_39) & 1);           
        bool val_41 = val_40;
        // 0x00B17A84: TBNZ w8, #0, #0xb18264     | if (((val_36 & val_39) & 1) == true) goto label_126;
        if(val_41 == true)
        {
            goto label_126;
        }
        // 0x00B17A88: BL #0xb14978               | X0 = val_39.SavePath();                 
        string val_42 = val_39.SavePath();
        // 0x00B17A8C: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17A90: MOV x22, x0                | X22 = val_42;//m1                       
        // 0x00B17A94: CBNZ x23, #0xb17a9c        | if (this.serverList != null) goto label_61;
        if(this.serverList != null)
        {
            goto label_61;
        }
        // 0x00B17A98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
        label_61:
        // 0x00B17A9C: LDR x23, [x23, #0x18]      | 
        // 0x00B17AA0: CBNZ x23, #0xb17aa8        | if (this.serverList != null) goto label_62;
        if(this.serverList != null)
        {
            goto label_62;
        }
        // 0x00B17AA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
        label_62:
        // 0x00B17AA8: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17AAC: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B17AB0: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17AB4: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_43 = this.serverList.Item[0];
        // 0x00B17AB8: MOV x23, x0                | X23 = val_43;//m1                       
        // 0x00B17ABC: CBNZ x23, #0xb17ac4        | if (val_43 != null) goto label_63;      
        if(val_43 != null)
        {
            goto label_63;
        }
        // 0x00B17AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
        label_63:
        // 0x00B17AC4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B17AC8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B17ACC: LDR x23, [x23, #0x10]      | 
        // 0x00B17AD0: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B17AD4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B17AD8: TBZ w8, #0, #0xb17ae8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_65;
        // 0x00B17ADC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B17AE0: CBNZ w8, #0xb17ae8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
        // 0x00B17AE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_65:
        // 0x00B17AE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17AEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17AF0: MOV x1, x22                | X1 = val_42;//m1                        
        // 0x00B17AF4: MOV x2, x23                | X2 = val_43;//m1                        
        // 0x00B17AF8: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_42);
        string val_44 = System.String.Concat(str0:  0, str1:  val_42);
        // 0x00B17AFC: MOV x1, x0                 | X1 = val_44;//m1                        
        // 0x00B17B00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17B04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17B08: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_45 = System.IO.File.Exists(path:  0);
        // 0x00B17B0C: TBZ w0, #0, #0xb18264      | if (val_45 == false) goto label_126;    
        if(val_45 == false)
        {
            goto label_126;
        }
        // 0x00B17B10: LDR x22, [x19, #0x28]      | X22 = this.serverList; //P2             
        // 0x00B17B14: CBNZ x22, #0xb17b1c        | if (this.serverList != null) goto label_67;
        if(this.serverList != null)
        {
            goto label_67;
        }
        // 0x00B17B18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_67:
        // 0x00B17B1C: LDR x22, [x22, #0x18]      | 
        // 0x00B17B20: CBNZ x22, #0xb17b28        | if (this.serverList != null) goto label_68;
        if(this.serverList != null)
        {
            goto label_68;
        }
        // 0x00B17B24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_68:
        // 0x00B17B28: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17B2C: MOV x0, x22                | X0 = this.serverList;//m1               
        // 0x00B17B30: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17B34: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_46 = this.serverList.Item[0];
        // 0x00B17B38: MOV x22, x0                | X22 = val_46;//m1                       
        // 0x00B17B3C: CBNZ x22, #0xb17b44        | if (val_46 != null) goto label_69;      
        if(val_46 != null)
        {
            goto label_69;
        }
        // 0x00B17B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
        label_69:
        // 0x00B17B44: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B17B48: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B17B4C: LDR x22, [x22, #0x10]      | 
        // 0x00B17B50: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00B17B54: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B17B58: TBZ w8, #0, #0xb17b68      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_71;
        // 0x00B17B5C: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B17B60: CBNZ w8, #0xb17b68         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_71;
        // 0x00B17B64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_71:
        // 0x00B17B68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17B6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17B70: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B17B74: MOV x1, x22                | X1 = val_46;//m1                        
        // 0x00B17B78: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_46);
        EDebug.Log(message:  0, isShowStack:  val_46);
        // 0x00B17B7C: BL #0xb14978               | X0 = this.SavePath();                   
        string val_47 = this.SavePath();
        // 0x00B17B80: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17B84: MOV x22, x0                | X22 = val_47;//m1                       
        // 0x00B17B88: CBNZ x23, #0xb17b90        | if (this.serverList != null) goto label_72;
        if(this.serverList != null)
        {
            goto label_72;
        }
        // 0x00B17B8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_72:
        // 0x00B17B90: LDR x23, [x23, #0x18]      | 
        // 0x00B17B94: CBNZ x23, #0xb17b9c        | if (this.serverList != null) goto label_73;
        if(this.serverList != null)
        {
            goto label_73;
        }
        // 0x00B17B98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_73:
        // 0x00B17B9C: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17BA0: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B17BA4: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17BA8: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_48 = this.serverList.Item[0];
        // 0x00B17BAC: MOV x23, x0                | X23 = val_48;//m1                       
        // 0x00B17BB0: CBNZ x23, #0xb17bb8        | if (val_48 != null) goto label_74;      
        if(val_48 != null)
        {
            goto label_74;
        }
        // 0x00B17BB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_74:
        // 0x00B17BB8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B17BBC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B17BC0: LDR x23, [x23, #0x10]      | 
        // 0x00B17BC4: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B17BC8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B17BCC: TBZ w8, #0, #0xb17bdc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_76;
        // 0x00B17BD0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B17BD4: CBNZ w8, #0xb17bdc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_76;
        // 0x00B17BD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_76:
        // 0x00B17BDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17BE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17BE4: MOV x1, x22                | X1 = val_47;//m1                        
        // 0x00B17BE8: MOV x2, x23                | X2 = val_48;//m1                        
        // 0x00B17BEC: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_47);
        string val_49 = System.String.Concat(str0:  0, str1:  val_47);
        // 0x00B17BF0: MOV x1, x0                 | X1 = val_49;//m1                        
        // 0x00B17BF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17BF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17BFC: BL #0x1e6a550              | System.IO.File.Delete(path:  0);        
        System.IO.File.Delete(path:  0);
        // 0x00B17C00: BL #0xb14978               | X0 = this.SavePath();                   
        string val_50 = this.SavePath();
        // 0x00B17C04: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17C08: MOV x22, x0                | X22 = val_50;//m1                       
        val_98 = val_50;
        // 0x00B17C0C: CBNZ x23, #0xb17c14        | if (this.serverList != null) goto label_77;
        if(this.serverList != null)
        {
            goto label_77;
        }
        // 0x00B17C10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
        label_77:
        // 0x00B17C14: LDR x23, [x23, #0x18]      | 
        // 0x00B17C18: CBNZ x23, #0xb17c20        | if (this.serverList != null) goto label_78;
        if(this.serverList != null)
        {
            goto label_78;
        }
        // 0x00B17C1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
        label_78:
        // 0x00B17C20: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17C24: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B17C28: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17C2C: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_51 = this.serverList.Item[0];
        // 0x00B17C30: MOV x23, x0                | X23 = val_51;//m1                       
        val_92 = val_51;
        // 0x00B17C34: CBNZ x23, #0xb17c3c        | if (val_51 != null) goto label_79;      
        if(val_92 != null)
        {
            goto label_79;
        }
        // 0x00B17C38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
        label_79:
        // 0x00B17C3C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B17C40: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B17C44: LDR x1, [x23, #0x10]       | 
        // 0x00B17C48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_100 = 0;
        // 0x00B17C4C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B17C50: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B17C54: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B17C58: LDR x3, [x8]               | X3 = System.String.Empty;               
        // 0x00B17C5C: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00B17C60: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921515142907600)(".uab");
        // 0x00B17C64: LDR x2, [x8]               | X2 = ".uab";                            
        val_101 = ".uab";
        // 0x00B17C68: B #0xb18154                |  goto label_80;                         
        goto label_80;
        label_46:
        // 0x00B17C6C: CBZ w8, #0xb17c7c          | if (((System.String.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_82;
        // 0x00B17C70: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B17C74: CBNZ w8, #0xb17c7c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_82;
        // 0x00B17C78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_82:
        // 0x00B17C7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17C80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17C84: MOV x1, x22                | X1 = val_22;//m1                        
        // 0x00B17C88: MOV x2, x24                | X2 = val_23;//m1                        
        // 0x00B17C8C: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_22);
        string val_52 = System.String.Concat(str0:  0, str1:  val_22);
        // 0x00B17C90: MOV x1, x0                 | X1 = val_52;//m1                        
        // 0x00B17C94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17C98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17C9C: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_53 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B17CA0: MOV x1, x0                 | X1 = val_53;//m1                        
        // 0x00B17CA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17CA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17CAC: BL #0xab7c8c               | X0 = Mihua.Assets.UnzipAssetMgr.BZip2DeCompression(bytes:  0);
        System.Byte[] val_54 = Mihua.Assets.UnzipAssetMgr.BZip2DeCompression(bytes:  0);
        // 0x00B17CB0: MOV x22, x0                | X22 = val_54;//m1                       
        // 0x00B17CB4: BL #0xb14978               | X0 = val_54.SavePath();                 
        string val_55 = val_54.SavePath();
        // 0x00B17CB8: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B17CBC: MOV x23, x0                | X23 = val_55;//m1                       
        val_92 = val_55;
        // 0x00B17CC0: CBNZ x24, #0xb17cc8        | if (this.serverList != null) goto label_83;
        if(this.serverList != null)
        {
            goto label_83;
        }
        // 0x00B17CC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_83:
        // 0x00B17CC8: LDR x24, [x24, #0x18]      | 
        // 0x00B17CCC: CBNZ x24, #0xb17cd4        | if (this.serverList != null) goto label_84;
        if(this.serverList != null)
        {
            goto label_84;
        }
        // 0x00B17CD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_84:
        // 0x00B17CD4: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17CD8: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B17CDC: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17CE0: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_56 = this.serverList.Item[0];
        // 0x00B17CE4: MOV x24, x0                | X24 = val_56;//m1                       
        // 0x00B17CE8: CBNZ x24, #0xb17cf0        | if (val_56 != null) goto label_85;      
        if(val_56 != null)
        {
            goto label_85;
        }
        // 0x00B17CEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
        label_85:
        // 0x00B17CF0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B17CF4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B17CF8: LDR x1, [x24, #0x10]       | 
        // 0x00B17CFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17D00: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B17D04: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B17D08: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B17D0C: LDR x3, [x8]               | X3 = System.String.Empty;               
        // 0x00B17D10: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00B17D14: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921515142907600)(".uab");
        // 0x00B17D18: LDR x2, [x8]               | X2 = ".uab";                            
        // 0x00B17D1C: BL #0x27954f0              | X0 = EString.EReplace(t:  0, oldString:  0, newString:  ".uab");
        string val_57 = EString.EReplace(t:  0, oldString:  val_91, newString:  ".uab");
        // 0x00B17D20: MOV x2, x0                 | X2 = val_57;//m1                        
        // 0x00B17D24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17D28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17D2C: MOV x1, x23                | X1 = val_55;//m1                        
        // 0x00B17D30: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_92);
        string val_58 = System.String.Concat(str0:  0, str1:  val_92);
        // 0x00B17D34: MOV x1, x0                 | X1 = val_58;//m1                        
        val_102 = val_58;
        // 0x00B17D38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_103 = 0;
        // 0x00B17D3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17D40: MOV x2, x22                | X2 = val_54;//m1                        
        // 0x00B17D44: B #0xb18258                |  goto label_86;                         
        goto label_86;
        label_41:
        // 0x00B17D48: MOV x27, x24               | X27 = 58334280 (0x37A1C48);//ML01       
        val_97 = "assets_bin_Data";
        // 0x00B17D4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B17D50: LDR x0, [x26]              | X0 = typeof(Loader.PathUtil);           
        val_94 = null;
        label_42:
        // 0x00B17D54: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
        // 0x00B17D58: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B17D5C: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
        // 0x00B17D60: LDR x24, [x8, #0x10]       | X24 = Loader.PathUtil.ARCH_ABI_TYPE;    
        // 0x00B17D64: LDR x0, [x9]               | X0 = typeof(System.String);             
        // 0x00B17D68: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B17D6C: TBZ w8, #0, #0xb17d7c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_88;
        // 0x00B17D70: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B17D74: CBNZ w8, #0xb17d7c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_88;
        // 0x00B17D78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_88:
        // 0x00B17D7C: LDR x2, [x28]              | X2 = "_csscript.uab";                   
        // 0x00B17D80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17D84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17D88: MOV x1, x24                | X1 = Loader.PathUtil.ARCH_ABI_TYPE;//m1 
        // 0x00B17D8C: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.ARCH_ABI_TYPE);
        string val_59 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.ARCH_ABI_TYPE);
        // 0x00B17D90: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00B17D94: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921515143247648)("libil2cpp.so");
        // 0x00B17D98: MOV x2, x0                 | X2 = val_59;//m1                        
        // 0x00B17D9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17DA0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B17DA4: LDR x3, [x8]               | X3 = "libil2cpp.so";                    
        // 0x00B17DA8: MOV x1, x23                | X1 = val_11;//m1                        
        // 0x00B17DAC: BL #0x27954f0              | X0 = EString.EReplace(t:  0, oldString:  val_11, newString:  val_59);
        string val_60 = EString.EReplace(t:  0, oldString:  val_11, newString:  val_59);
        // 0x00B17DB0: MOV x2, x0                 | X2 = val_60;//m1                        
        // 0x00B17DB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17DB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17DBC: MOV x1, x22                | X1 = val_10;//m1                        
        // 0x00B17DC0: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_10);
        string val_61 = System.String.Concat(str0:  0, str1:  val_10);
        // 0x00B17DC4: MOV x1, x0                 | X1 = val_61;//m1                        
        // 0x00B17DC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17DCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17DD0: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_62 = System.IO.File.Exists(path:  0);
        // 0x00B17DD4: MOV w24, w0                | W24 = val_62;//m1                       
        // 0x00B17DD8: BL #0xb14978               | X0 = val_62.SavePath();                 
        string val_63 = val_62.SavePath();
        // 0x00B17DDC: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17DE0: MOV x22, x0                | X22 = val_63;//m1                       
        // 0x00B17DE4: CBNZ x23, #0xb17dec        | if (this.serverList != null) goto label_89;
        if(this.serverList != null)
        {
            goto label_89;
        }
        // 0x00B17DE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_63, ????);     
        label_89:
        // 0x00B17DEC: LDR x23, [x23, #0x18]      | 
        // 0x00B17DF0: CBNZ x23, #0xb17df8        | if (this.serverList != null) goto label_90;
        if(this.serverList != null)
        {
            goto label_90;
        }
        // 0x00B17DF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_63, ????);     
        label_90:
        // 0x00B17DF8: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17DFC: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B17E00: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17E04: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_64 = this.serverList.Item[0];
        // 0x00B17E08: MOV x23, x0                | X23 = val_64;//m1                       
        // 0x00B17E0C: CBNZ x23, #0xb17e14        | if (val_64 != null) goto label_91;      
        if(val_64 != null)
        {
            goto label_91;
        }
        // 0x00B17E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
        label_91:
        // 0x00B17E14: LDR x23, [x23, #0x10]      | 
        // 0x00B17E18: TBZ w24, #0, #0xb18180     | if (val_62 == false) goto label_92;     
        if(val_62 == false)
        {
            goto label_92;
        }
        // 0x00B17E1C: LDR x0, [x26]              | X0 = typeof(Loader.PathUtil);           
        // 0x00B17E20: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B17E24: TBZ w8, #0, #0xb17e38      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_94;
        // 0x00B17E28: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B17E2C: CBNZ w8, #0xb17e38         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_94;
        // 0x00B17E30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B17E34: LDR x0, [x26]              | X0 = typeof(Loader.PathUtil);           
        val_104 = null;
        label_94:
        // 0x00B17E38: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
        // 0x00B17E3C: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B17E40: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
        // 0x00B17E44: LDR x24, [x8, #0x10]       | X24 = Loader.PathUtil.ARCH_ABI_TYPE;    
        // 0x00B17E48: LDR x0, [x9]               | X0 = typeof(System.String);             
        // 0x00B17E4C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B17E50: TBZ w8, #0, #0xb17e60      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_96;
        // 0x00B17E54: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B17E58: CBNZ w8, #0xb17e60         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_96;
        // 0x00B17E5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_96:
        // 0x00B17E60: LDR x2, [x28]              | X2 = "_csscript.uab";                   
        // 0x00B17E64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17E68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17E6C: MOV x1, x24                | X1 = Loader.PathUtil.ARCH_ABI_TYPE;//m1 
        // 0x00B17E70: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.ARCH_ABI_TYPE);
        string val_65 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.ARCH_ABI_TYPE);
        // 0x00B17E74: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00B17E78: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921515143247648)("libil2cpp.so");
        // 0x00B17E7C: MOV x2, x0                 | X2 = val_65;//m1                        
        // 0x00B17E80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17E84: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B17E88: LDR x3, [x8]               | X3 = "libil2cpp.so";                    
        // 0x00B17E8C: MOV x1, x23                | X1 = val_64;//m1                        
        // 0x00B17E90: BL #0x27954f0              | X0 = EString.EReplace(t:  0, oldString:  val_64, newString:  val_65);
        string val_66 = EString.EReplace(t:  0, oldString:  val_64, newString:  val_65);
        // 0x00B17E94: MOV x2, x0                 | X2 = val_66;//m1                        
        // 0x00B17E98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17E9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B17EA0: MOV x1, x22                | X1 = val_63;//m1                        
        // 0x00B17EA4: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_63);
        string val_67 = System.String.Concat(str0:  0, str1:  val_63);
        // 0x00B17EA8: MOV x1, x0                 | X1 = val_67;//m1                        
        // 0x00B17EAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17EB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17EB4: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_68 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B17EB8: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B17EBC: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B17EC0: MOV x22, x0                | X22 = val_68;//m1                       
        // 0x00B17EC4: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B17EC8: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B17ECC: TBZ w9, #0, #0xb17ee0      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_98;
        // 0x00B17ED0: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B17ED4: CBNZ w9, #0xb17ee0         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_98;
        // 0x00B17ED8: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B17EDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_98:
        // 0x00B17EE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B17EE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17EE8: MOV x1, x22                | X1 = val_68;//m1                        
        // 0x00B17EEC: BL #0xac28b4               | X0 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        string val_69 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        // 0x00B17EF0: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17EF4: MOV x22, x0                | X22 = val_69;//m1                       
        // 0x00B17EF8: CBNZ x23, #0xb17f00        | if (this.serverList != null) goto label_99;
        if(this.serverList != null)
        {
            goto label_99;
        }
        // 0x00B17EFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_69, ????);     
        label_99:
        // 0x00B17F00: LDR x23, [x23, #0x18]      | 
        // 0x00B17F04: CBNZ x23, #0xb17f0c        | if (this.serverList != null) goto label_100;
        if(this.serverList != null)
        {
            goto label_100;
        }
        // 0x00B17F08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_69, ????);     
        label_100:
        // 0x00B17F0C: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17F10: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B17F14: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17F18: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_70 = this.serverList.Item[0];
        // 0x00B17F1C: MOV x23, x0                | X23 = val_70;//m1                       
        // 0x00B17F20: CBNZ x23, #0xb17f28        | if (val_70 != null) goto label_101;     
        if(val_70 != null)
        {
            goto label_101;
        }
        // 0x00B17F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        label_101:
        // 0x00B17F28: LDR x23, [x23, #0x10]      | 
        // 0x00B17F2C: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B17F30: CBNZ x24, #0xb17f38        | if (this.serverList != null) goto label_102;
        if(this.serverList != null)
        {
            goto label_102;
        }
        // 0x00B17F34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        label_102:
        // 0x00B17F38: LDR x24, [x24, #0x18]      | 
        // 0x00B17F3C: CBNZ x24, #0xb17f44        | if (this.serverList != null) goto label_103;
        if(this.serverList != null)
        {
            goto label_103;
        }
        // 0x00B17F40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        label_103:
        // 0x00B17F44: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17F48: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B17F4C: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17F50: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_71 = this.serverList.Item[0];
        // 0x00B17F54: MOV x24, x0                | X24 = val_71;//m1                       
        // 0x00B17F58: CBNZ x24, #0xb17f60        | if (val_71 != null) goto label_104;     
        if(val_71 != null)
        {
            goto label_104;
        }
        // 0x00B17F5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_71, ????);     
        label_104:
        // 0x00B17F60: LDR x2, [x24, #0x18]       | X2 = val_71.mDataMD5; //P2              
        // 0x00B17F64: MOV x0, x19                | X0 = 1152921515143488832 (0x1000000274086540);//ML01
        // 0x00B17F68: MOV x1, x23                | X1 = val_70;//m1                        
        // 0x00B17F6C: BL #0xb1828c               | X0 = this.VerifyMD5(path:  val_70, md5:  val_71.mDataMD5);
        bool val_72 = this.VerifyMD5(path:  val_70, md5:  val_71.mDataMD5);
        // 0x00B17F70: MOV x24, x27               | X24 = 58334280 (0x37A1C48);//ML01       
        // 0x00B17F74: MOV x27, x26               | X27 = 57993960 (0x374EAE8);//ML01       
        val_91 = val_95;
        // 0x00B17F78: TBZ w0, #0, #0xb17fd4      | if (val_72 == false) goto label_105;    
        if(val_72 == false)
        {
            goto label_105;
        }
        // 0x00B17F7C: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B17F80: CBNZ x23, #0xb17f88        | if (this.serverList != null) goto label_106;
        if(this.serverList != null)
        {
            goto label_106;
        }
        // 0x00B17F84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_72, ????);     
        label_106:
        // 0x00B17F88: LDR x23, [x23, #0x18]      | 
        // 0x00B17F8C: CBNZ x23, #0xb17f94        | if (this.serverList != null) goto label_107;
        if(this.serverList != null)
        {
            goto label_107;
        }
        // 0x00B17F90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_72, ????);     
        label_107:
        // 0x00B17F94: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17F98: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B17F9C: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17FA0: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_73 = this.serverList.Item[0];
        // 0x00B17FA4: MOV x23, x0                | X23 = val_73;//m1                       
        // 0x00B17FA8: CBNZ x23, #0xb17fb0        | if (val_73 != null) goto label_108;     
        if(val_73 != null)
        {
            goto label_108;
        }
        // 0x00B17FAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_73, ????);     
        label_108:
        // 0x00B17FB0: LDR x23, [x23, #0x18]      | X23 = val_73.mDataMD5; //P2             
        val_92 = val_73.mDataMD5;
        // 0x00B17FB4: CBNZ x22, #0xb17fbc        | if (val_69 != null) goto label_109;     
        if(val_69 != null)
        {
            goto label_109;
        }
        // 0x00B17FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_73, ????);     
        label_109:
        // 0x00B17FBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B17FC0: MOV x0, x22                | X0 = val_69;//m1                        
        // 0x00B17FC4: MOV x1, x23                | X1 = val_73.mDataMD5;//m1               
        // 0x00B17FC8: BL #0x18a8334              | X0 = val_69.Equals(value:  val_92);     
        bool val_74 = val_69.Equals(value:  val_92);
        // 0x00B17FCC: AND w8, w0, #1             | W8 = (val_74 & 1);                      
        bool val_75 = val_74;
        // 0x00B17FD0: TBNZ w8, #0, #0xb18264     | if ((val_74 & 1) == true) goto label_126;
        if(val_75 == true)
        {
            goto label_126;
        }
        label_105:
        // 0x00B17FD4: LDR x22, [x19, #0x28]      | X22 = this.serverList; //P2             
        // 0x00B17FD8: CBNZ x22, #0xb17fe0        | if (this.serverList != null) goto label_111;
        if(this.serverList != null)
        {
            goto label_111;
        }
        // 0x00B17FDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_74, ????);     
        label_111:
        // 0x00B17FE0: LDR x22, [x22, #0x18]      | 
        // 0x00B17FE4: CBNZ x22, #0xb17fec        | if (this.serverList != null) goto label_112;
        if(this.serverList != null)
        {
            goto label_112;
        }
        // 0x00B17FE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_74, ????);     
        label_112:
        // 0x00B17FEC: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B17FF0: MOV x0, x22                | X0 = this.serverList;//m1               
        // 0x00B17FF4: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B17FF8: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_76 = this.serverList.Item[0];
        // 0x00B17FFC: MOV x22, x0                | X22 = val_76;//m1                       
        // 0x00B18000: CBNZ x22, #0xb18008        | if (val_76 != null) goto label_113;     
        if(val_76 != null)
        {
            goto label_113;
        }
        // 0x00B18004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
        label_113:
        // 0x00B18008: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B1800C: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B18010: LDR x22, [x22, #0x10]      | 
        // 0x00B18014: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00B18018: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B1801C: TBZ w8, #0, #0xb1802c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_115;
        // 0x00B18020: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B18024: CBNZ w8, #0xb1802c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_115;
        // 0x00B18028: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_115:
        // 0x00B1802C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18030: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18034: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B18038: MOV x1, x22                | X1 = val_76;//m1                        
        // 0x00B1803C: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_76);
        EDebug.Log(message:  0, isShowStack:  val_76);
        // 0x00B18040: BL #0xb14978               | X0 = this.SavePath();                   
        string val_77 = this.SavePath();
        // 0x00B18044: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B18048: MOV x22, x0                | X22 = val_77;//m1                       
        // 0x00B1804C: CBNZ x23, #0xb18054        | if (this.serverList != null) goto label_116;
        if(this.serverList != null)
        {
            goto label_116;
        }
        // 0x00B18050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_77, ????);     
        label_116:
        // 0x00B18054: LDR x23, [x23, #0x18]      | 
        // 0x00B18058: CBNZ x23, #0xb18060        | if (this.serverList != null) goto label_117;
        if(this.serverList != null)
        {
            goto label_117;
        }
        // 0x00B1805C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_77, ????);     
        label_117:
        // 0x00B18060: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B18064: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B18068: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B1806C: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_78 = this.serverList.Item[0];
        // 0x00B18070: MOV x23, x0                | X23 = val_78;//m1                       
        // 0x00B18074: CBNZ x23, #0xb1807c        | if (val_78 != null) goto label_118;     
        if(val_78 != null)
        {
            goto label_118;
        }
        // 0x00B18078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_78, ????);     
        label_118:
        // 0x00B1807C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B18080: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B18084: LDR x23, [x23, #0x10]      | 
        // 0x00B18088: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B1808C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B18090: TBZ w8, #0, #0xb180a0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_120;
        // 0x00B18094: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B18098: CBNZ w8, #0xb180a0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_120;
        // 0x00B1809C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_120:
        // 0x00B180A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B180A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B180A8: MOV x1, x22                | X1 = val_77;//m1                        
        // 0x00B180AC: MOV x2, x23                | X2 = val_78;//m1                        
        // 0x00B180B0: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_77);
        string val_79 = System.String.Concat(str0:  0, str1:  val_77);
        // 0x00B180B4: MOV x1, x0                 | X1 = val_79;//m1                        
        // 0x00B180B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B180BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B180C0: BL #0x1e6a550              | System.IO.File.Delete(path:  0);        
        System.IO.File.Delete(path:  0);
        // 0x00B180C4: BL #0xb14978               | X0 = this.SavePath();                   
        string val_80 = this.SavePath();
        // 0x00B180C8: LDR x23, [x19, #0x28]      | X23 = this.serverList; //P2             
        // 0x00B180CC: MOV x22, x0                | X22 = val_80;//m1                       
        val_98 = val_80;
        // 0x00B180D0: CBNZ x23, #0xb180d8        | if (this.serverList != null) goto label_121;
        if(this.serverList != null)
        {
            goto label_121;
        }
        // 0x00B180D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
        label_121:
        // 0x00B180D8: LDR x23, [x23, #0x18]      | 
        // 0x00B180DC: CBNZ x23, #0xb180e4        | if (this.serverList != null) goto label_122;
        if(this.serverList != null)
        {
            goto label_122;
        }
        // 0x00B180E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
        label_122:
        // 0x00B180E4: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B180E8: MOV x0, x23                | X0 = this.serverList;//m1               
        // 0x00B180EC: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B180F0: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_81 = this.serverList.Item[0];
        // 0x00B180F4: MOV x23, x0                | X23 = val_81;//m1                       
        // 0x00B180F8: CBNZ x23, #0xb18100        | if (val_81 != null) goto label_123;     
        if(val_81 != null)
        {
            goto label_123;
        }
        // 0x00B180FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_81, ????);     
        label_123:
        // 0x00B18100: LDR x0, [x27]              | X0 = typeof(Loader.PathUtil);           
        val_105 = null;
        // 0x00B18104: LDR x23, [x23, #0x10]      | 
        // 0x00B18108: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B1810C: TBZ w8, #0, #0xb18120      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_125;
        // 0x00B18110: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B18114: CBNZ w8, #0xb18120         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_125;
        // 0x00B18118: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B1811C: LDR x0, [x27]              | X0 = typeof(Loader.PathUtil);           
        val_105 = null;
        label_125:
        // 0x00B18120: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B18124: LDR x2, [x28]              | X2 = "_csscript.uab";                   
        // 0x00B18128: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1812C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18130: LDR x1, [x8, #0x10]        | X1 = Loader.PathUtil.ARCH_ABI_TYPE;     
        // 0x00B18134: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.ARCH_ABI_TYPE);
        string val_82 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.ARCH_ABI_TYPE);
        // 0x00B18138: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00B1813C: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921515143247648)("libil2cpp.so");
        // 0x00B18140: MOV x2, x0                 | X2 = val_82;//m1                        
        val_101 = val_82;
        // 0x00B18144: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_100 = 0;
        // 0x00B18148: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B1814C: LDR x3, [x8]               | X3 = "libil2cpp.so";                    
        // 0x00B18150: MOV x1, x23                | X1 = val_81;//m1                        
        val_99 = val_81;
        label_80:
        // 0x00B18154: BL #0x27954f0              | X0 = EString.EReplace(t:  val_100 = 0, oldString:  val_99 = val_81, newString:  val_101 = val_82);
        string val_83 = EString.EReplace(t:  val_100, oldString:  val_99, newString:  val_101);
        // 0x00B18158: MOV x2, x0                 | X2 = val_83;//m1                        
        // 0x00B1815C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18160: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18164: MOV x1, x22                | X1 = val_80;//m1                        
        // 0x00B18168: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_98);
        string val_84 = System.String.Concat(str0:  0, str1:  val_98);
        // 0x00B1816C: MOV x1, x0                 | X1 = val_84;//m1                        
        // 0x00B18170: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18174: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18178: BL #0x1e6a550              | System.IO.File.Delete(path:  0);        
        System.IO.File.Delete(path:  0);
        // 0x00B1817C: B #0xb18264                |  goto label_126;                        
        goto label_126;
        label_92:
        // 0x00B18180: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B18184: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B18188: LDR x0, [x8]               | X0 = typeof(System.String);             
        val_106 = null;
        // 0x00B1818C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B18190: TBZ w8, #0, #0xb181ac      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_128;
        // 0x00B18194: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B18198: CBNZ w8, #0xb181ac         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_128;
        // 0x00B1819C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B181A0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B181A4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B181A8: LDR x0, [x8]               | X0 = typeof(System.String);             
        val_106 = null;
        label_128:
        // 0x00B181AC: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B181B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B181B4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B181B8: MOV x1, x23                | X1 = val_64;//m1                        
        // 0x00B181BC: LDR x3, [x8]               | X3 = System.String.Empty;               
        // 0x00B181C0: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00B181C4: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921515142907600)(".uab");
        // 0x00B181C8: LDR x2, [x8]               | X2 = ".uab";                            
        // 0x00B181CC: BL #0x27954f0              | X0 = EString.EReplace(t:  0, oldString:  val_64, newString:  ".uab");
        string val_85 = EString.EReplace(t:  0, oldString:  val_64, newString:  ".uab");
        // 0x00B181D0: MOV x2, x0                 | X2 = val_85;//m1                        
        // 0x00B181D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B181D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B181DC: MOV x1, x22                | X1 = val_63;//m1                        
        // 0x00B181E0: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_63);
        string val_86 = System.String.Concat(str0:  0, str1:  val_63);
        // 0x00B181E4: MOV x22, x0                | X22 = val_86;//m1                       
        // 0x00B181E8: BL #0xb14978               | X0 = val_86.SavePath();                 
        string val_87 = val_86.SavePath();
        // 0x00B181EC: LDR x24, [x19, #0x28]      | X24 = this.serverList; //P2             
        // 0x00B181F0: MOV x23, x0                | X23 = val_87;//m1                       
        val_92 = val_87;
        // 0x00B181F4: CBNZ x24, #0xb181fc        | if (this.serverList != null) goto label_129;
        if(this.serverList != null)
        {
            goto label_129;
        }
        // 0x00B181F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_87, ????);     
        label_129:
        // 0x00B181FC: LDR x24, [x24, #0x18]      | 
        // 0x00B18200: CBNZ x24, #0xb18208        | if (this.serverList != null) goto label_130;
        if(this.serverList != null)
        {
            goto label_130;
        }
        // 0x00B18204: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_87, ????);     
        label_130:
        // 0x00B18208: LDR x2, [x25]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B1820C: MOV x0, x24                | X0 = this.serverList;//m1               
        // 0x00B18210: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B18214: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  0);
        FileInfoRes val_88 = this.serverList.Item[0];
        // 0x00B18218: MOV x24, x0                | X24 = val_88;//m1                       
        // 0x00B1821C: CBNZ x24, #0xb18224        | if (val_88 != null) goto label_131;     
        if(val_88 != null)
        {
            goto label_131;
        }
        // 0x00B18220: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_88, ????);     
        label_131:
        // 0x00B18224: LDR x2, [x24, #0x10]       | 
        // 0x00B18228: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1822C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18230: MOV x1, x23                | X1 = val_87;//m1                        
        // 0x00B18234: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_92);
        string val_89 = System.String.Concat(str0:  0, str1:  val_92);
        // 0x00B18238: MOV x1, x0                 | X1 = val_89;//m1                        
        // 0x00B1823C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18240: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18244: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_90 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B18248: MOV x2, x0                 | X2 = val_90;//m1                        
        // 0x00B1824C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_103 = 0;
        // 0x00B18250: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18254: MOV x1, x22                | X1 = val_86;//m1                        
        val_102 = val_86;
        label_86:
        // 0x00B18258: BL #0x1e71f34              | System.IO.File.WriteAllBytes(path:  val_103 = 0, bytes:  val_102 = val_86);
        System.IO.File.WriteAllBytes(path:  val_103, bytes:  val_102);
        // 0x00B1825C: MOV x24, x27               | X24 = 58334280 (0x37A1C48);//ML01       
        // 0x00B18260: MOV x27, x26               | X27 = 57993960 (0x374EAE8);//ML01       
        val_91 = val_95;
        label_126:
        // 0x00B18264: ADD w21, w21, #1           | W21 = (0 + 1);                          
        val_91 = val_91 + 1;
        // 0x00B18268: CMP w20, w21               | STATE = COMPARE(val_1, (0 + 1))         
        // 0x00B1826C: B.NE #0xb17530             | if (val_1 != 0) goto label_132;         
        if(val_1 != val_91)
        {
            goto label_132;
        }
        label_3:
        // 0x00B18270: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B18274: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B18278: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1827C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B18280: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B18284: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B18288: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B189DC (11635164), len: 660  VirtAddr: 0x00B189DC RVA: 0x00B189DC token: 100694266 methodIndex: 24609 delegateWrapperIndex: 0 methodInvoker: 0
    public void StartDown()
    {
        //
        // Disasemble & Code
        //  | 
        SetBytes val_8;
        // 0x00B189DC: STP x24, x23, [sp, #-0x40]! | stack[1152921515144258656] = ???;  stack[1152921515144258664] = ???;  //  dest_result_addr=1152921515144258656 |  dest_result_addr=1152921515144258664
        // 0x00B189E0: STP x22, x21, [sp, #0x10]  | stack[1152921515144258672] = ???;  stack[1152921515144258680] = ???;  //  dest_result_addr=1152921515144258672 |  dest_result_addr=1152921515144258680
        // 0x00B189E4: STP x20, x19, [sp, #0x20]  | stack[1152921515144258688] = ???;  stack[1152921515144258696] = ???;  //  dest_result_addr=1152921515144258688 |  dest_result_addr=1152921515144258696
        // 0x00B189E8: STP x29, x30, [sp, #0x30]  | stack[1152921515144258704] = ???;  stack[1152921515144258712] = ???;  //  dest_result_addr=1152921515144258704 |  dest_result_addr=1152921515144258712
        // 0x00B189EC: ADD x29, sp, #0x30         | X29 = (1152921515144258656 + 48) = 1152921515144258704 (0x1000000274142490);
        // 0x00B189F0: SUB sp, sp, #0x10          | SP = (1152921515144258656 - 16) = 1152921515144258640 (0x1000000274142450);
        // 0x00B189F4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B189F8: LDRB w8, [x20, #0x6e1]     | W8 = (bool)static_value_037336E1;       
        // 0x00B189FC: MOV x19, x0                | X19 = 1152921515144270720 (0x1000000274145380);//ML01
        // 0x00B18A00: TBNZ w8, #0, #0xb18a1c     | if (static_value_037336E1 == true) goto label_0;
        // 0x00B18A04: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x00B18A08: LDR x8, [x8, #0xe98]       | X8 = 0x2B8A6FC;                         
        // 0x00B18A0C: LDR w0, [x8]               | W0 = 0x7D;                              
        // 0x00B18A10: BL #0x2782188              | X0 = sub_2782188( ?? 0x7D, ????);       
        // 0x00B18A14: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B18A18: STRB w8, [x20, #0x6e1]     | static_value_037336E1 = true;            //  dest_result_addr=57882337
        label_0:
        // 0x00B18A1C: LDR x20, [x19, #0x88]      | X20 = this.updateList; //P2             
        // 0x00B18A20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B18A24: STRB w8, [x19, #0xb0]      | this.<isStartDown>k__BackingField = true;  //  dest_result_addr=1152921515144270896
        this.<isStartDown>k__BackingField = true;
        // 0x00B18A28: STR wzr, [x19, #0x98]      | this.downFileNum = 0;                    //  dest_result_addr=1152921515144270872
        this.downFileNum = 0;
        // 0x00B18A2C: CBNZ x20, #0xb18a34        | if (this.updateList != null) goto label_1;
        if(this.updateList != null)
        {
            goto label_1;
        }
        // 0x00B18A30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x7D, ????);       
        label_1:
        // 0x00B18A34: ADRP x21, #0x35c6000       | X21 = 56385536 (0x35C6000);             
        // 0x00B18A38: LDR x21, [x21, #0x5d8]     | X21 = 1152921514959024432;              
        // 0x00B18A3C: MOV x0, x20                | X0 = this.updateList;//m1               
        // 0x00B18A40: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B18A44: BL #0x25ed72c              | X0 = this.updateList.get_Count();       
        int val_1 = this.updateList.Count;
        // 0x00B18A48: LDR x20, [x19, #0x88]      | X20 = this.updateList; //P2             
        // 0x00B18A4C: STR w0, [x19, #0x9c]       | this.downFileCount = val_1;              //  dest_result_addr=1152921515144270876
        this.downFileCount = val_1;
        // 0x00B18A50: CBNZ x20, #0xb18a58        | if (this.updateList != null) goto label_2;
        if(this.updateList != null)
        {
            goto label_2;
        }
        // 0x00B18A54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B18A58: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B18A5C: MOV x0, x20                | X0 = this.updateList;//m1               
        // 0x00B18A60: BL #0x25ed72c              | X0 = this.updateList.get_Count();       
        int val_2 = this.updateList.Count;
        // 0x00B18A64: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
        // 0x00B18A68: B.LT #0xb18c18             | if (val_2 < 1) goto label_3;            
        if(val_2 < 1)
        {
            goto label_3;
        }
        // 0x00B18A6C: LDR x20, [x19, #0x88]      | X20 = this.updateList; //P2             
        // 0x00B18A70: CBNZ x20, #0xb18a78        | if (this.updateList != null) goto label_4;
        if(this.updateList != null)
        {
            goto label_4;
        }
        // 0x00B18A74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B18A78: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B18A7C: MOV x0, x20                | X0 = this.updateList;//m1               
        // 0x00B18A80: BL #0x25ed72c              | X0 = this.updateList.get_Count();       
        int val_3 = this.updateList.Count;
        // 0x00B18A84: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00B18A88: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00B18A8C: STR w0, [sp, #0xc]         | stack[1152921515144258652] = val_3;      //  dest_result_addr=1152921515144258652
        // 0x00B18A90: ADD x1, sp, #0xc           | X1 = (1152921515144258640 + 12) = 1152921515144258652 (0x100000027414245C);
        // 0x00B18A94: LDR x8, [x8]               | X8 = typeof(System.Int32);              
        // 0x00B18A98: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00B18A9C: BL #0x27bc028              | X0 = 1152921515144315008 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_3);
        // 0x00B18AA0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B18AA4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B18AA8: MOV x20, x0                | X20 = 1152921515144315008 (0x1000000274150080);//ML01
        // 0x00B18AAC: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B18AB0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B18AB4: TBZ w9, #0, #0xb18ac8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B18AB8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B18ABC: CBNZ w9, #0xb18ac8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B18AC0: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B18AC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_6:
        // 0x00B18AC8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B18ACC: LDR x8, [x8, #0xd28]       | X8 = (string**)(1152921515144228096)("需要更新{0}个资源");
        // 0x00B18AD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18AD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18AD8: MOV x2, x20                | X2 = 1152921515144315008 (0x1000000274150080);//ML01
        // 0x00B18ADC: LDR x1, [x8]               | X1 = "需要更新{0}个资源";                      
        // 0x00B18AE0: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "需要更新{0}个资源");
        string val_4 = System.String.Format(format:  0, arg0:  "需要更新{0}个资源");
        // 0x00B18AE4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B18AE8: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B18AEC: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B18AF0: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B18AF4: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B18AF8: TBZ w9, #0, #0xb18b0c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B18AFC: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B18B00: CBNZ w9, #0xb18b0c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B18B04: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B18B08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_8:
        // 0x00B18B0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18B10: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18B14: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B18B18: MOV x1, x20                | X1 = val_4;//m1                         
        // 0x00B18B1C: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_4);
        EDebug.Log(message:  0, isShowStack:  val_4);
        // 0x00B18B20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18B24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B18B28: BL #0xdbd3cc               | X0 = LoadingBoardMgr.get_Instance();    
        LoadingBoardMgr val_5 = LoadingBoardMgr.Instance;
        // 0x00B18B2C: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B18B30: CBNZ x20, #0xb18b38        | if (val_5 != null) goto label_9;        
        if(val_5 != null)
        {
            goto label_9;
        }
        // 0x00B18B34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00B18B38: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00B18B3C: LDR x8, [x8, #0x190]       | X8 = (string**)(1152921510482620416)("Updating...");
        // 0x00B18B40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18B44: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00B18B48: LDR x1, [x8]               | X1 = "Updating...";                     
        // 0x00B18B4C: BL #0xdbdc98               | val_5.SetDescri(value:  "Updating..."); 
        val_5.SetDescri(value:  "Updating...");
        // 0x00B18B50: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_6 = AssetDownMgr.Instance;
        // 0x00B18B54: ADRP x23, #0x365c000       | X23 = 56999936 (0x365C000);             
        // 0x00B18B58: LDR x23, [x23, #0xd68]     | X23 = 1152921504910680064;              
        // 0x00B18B5C: LDR x20, [x19, #0x88]      | X20 = this.updateList; //P2             
        // 0x00B18B60: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00B18B64: LDR x8, [x23]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B18B68: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B18B6C: LDR x22, [x8, #0x10]       | X22 = ABCheckUpdate.<>f__am$cache1;     
        val_8 = ABCheckUpdate.<>f__am$cache1;
        // 0x00B18B70: CBNZ x22, #0xb18bb4        | if (ABCheckUpdate.<>f__am$cache1 != null) goto label_10;
        if(val_8 != null)
        {
            goto label_10;
        }
        // 0x00B18B74: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00B18B78: ADRP x9, #0x361c000        | X9 = 56737792 (0x361C000);              
        // 0x00B18B7C: LDR x8, [x8, #0xb48]       | X8 = 1152921515144244576;               
        // 0x00B18B80: LDR x9, [x9, #0x610]       | X9 = 1152921504910786560;               
        // 0x00B18B84: LDR x22, [x8]              | X22 = static System.Void ABCheckUpdate::<StartDown>m__6(string name, byte[] abBytes);
        // 0x00B18B88: LDR x0, [x9]               | X0 = typeof(AssetDownMgr.SetBytes);     
        // 0x00B18B8C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetDownMgr.SetBytes), ????);
        // 0x00B18B90: LDR x8, [x22]              | X8 = static System.Void ABCheckUpdate::<StartDown>m__6(string name, byte[] abBytes);
        // 0x00B18B94: STP xzr, x22, [x0, #0x20]  | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = 0x0;  typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = static System.Void ABCheckUpdate::<StartDown>m__6(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786592 |  dest_result_addr=1152921504910786600
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = 0;
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = static System.Void ABCheckUpdate::<StartDown>m__6(string name, byte[] abBytes);
        // 0x00B18B98: STR x8, [x0, #0x10]        | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = static System.Void ABCheckUpdate::<StartDown>m__6(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786576
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = static System.Void ABCheckUpdate::<StartDown>m__6(string name, byte[] abBytes);
        // 0x00B18B9C: LDR x8, [x23]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B18BA0: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B18BA4: STR x0, [x8, #0x10]        | ABCheckUpdate.<>f__am$cache1 = typeof(AssetDownMgr.SetBytes);  //  dest_result_addr=1152921504910684176
        ABCheckUpdate.<>f__am$cache1 = null;
        // 0x00B18BA8: LDR x8, [x23]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B18BAC: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B18BB0: LDR x22, [x8, #0x10]       | X22 = typeof(AssetDownMgr.SetBytes);    
        val_8 = ABCheckUpdate.<>f__am$cache1;
        label_10:
        // 0x00B18BB4: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
        // 0x00B18BB8: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B18BBC: LDR x8, [x8, #0x900]       | X8 = 1152921515144245600;               
        // 0x00B18BC0: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B18BC4: LDR x24, [x8]              | X24 = System.Void ABCheckUpdate::<StartDown>m__7();
        // 0x00B18BC8: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_7 = null;
        // 0x00B18BCC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B18BD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18BD4: MOV x1, x19                | X1 = 1152921515144270720 (0x1000000274145380);//ML01
        // 0x00B18BD8: MOV x2, x24                | X2 = 1152921515144245600 (0x100000027413F160);//ML01
        // 0x00B18BDC: MOV x23, x0                | X23 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B18BE0: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ABCheckUpdate::<StartDown>m__7());
        val_7 = new System.Action(object:  this, method:  System.Void ABCheckUpdate::<StartDown>m__7());
        // 0x00B18BE4: CBNZ x21, #0xb18bec        | if (val_6 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x00B18BE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void ABCheckUpdate::<StartDown>m__7()), ????);
        label_11:
        // 0x00B18BEC: MOV x0, x21                | X0 = val_6;//m1                         
        // 0x00B18BF0: MOV x1, x20                | X1 = this.updateList;//m1               
        // 0x00B18BF4: MOV x2, x22                | X2 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B18BF8: MOV x3, x23                | X3 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B18BFC: BL #0xb18c70               | val_6.AddUpdateData(updateList:  this.updateList, downFinishCall:  val_8, writeDownFinishCall:  val_7);
        val_6.AddUpdateData(updateList:  this.updateList, downFinishCall:  val_8, writeDownFinishCall:  val_7);
        // 0x00B18C00: SUB sp, x29, #0x30         | SP = (1152921515144258704 - 48) = 1152921515144258656 (0x1000000274142460);
        // 0x00B18C04: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B18C08: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B18C0C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B18C10: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B18C14: RET                        |  return;                                
        return;
        label_3:
        // 0x00B18C18: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B18C1C: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B18C20: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00B18C24: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B18C28: TBZ w8, #0, #0xb18c38      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B18C2C: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B18C30: CBNZ w8, #0xb18c38         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B18C34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_13:
        // 0x00B18C38: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00B18C3C: LDR x8, [x8, #0x88]        | X8 = (string**)(1152921515144246624)("无资源更新，进入游戏");
        // 0x00B18C40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18C44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18C48: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B18C4C: LDR x1, [x8]               | X1 = "无资源更新，进入游戏";                      
        // 0x00B18C50: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00B18C54: MOV x0, x19                | X0 = 1152921515144270720 (0x1000000274145380);//ML01
        // 0x00B18C58: SUB sp, x29, #0x30         | SP = (1152921515144258704 - 48) = 1152921515144258656 (0x1000000274142460);
        // 0x00B18C5C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B18C60: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B18C64: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B18C68: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B18C6C: B #0xb1913c                | this.LoadedAll(); return;               
        this.LoadedAll();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19498 (11637912), len: 660  VirtAddr: 0x00B19498 RVA: 0x00B19498 token: 100694267 methodIndex: 24610 delegateWrapperIndex: 0 methodInvoker: 0
    public void StartCsDown()
    {
        //
        // Disasemble & Code
        //  | 
        SetBytes val_8;
        // 0x00B19498: STP x24, x23, [sp, #-0x40]! | stack[1152921515144438336] = ???;  stack[1152921515144438344] = ???;  //  dest_result_addr=1152921515144438336 |  dest_result_addr=1152921515144438344
        // 0x00B1949C: STP x22, x21, [sp, #0x10]  | stack[1152921515144438352] = ???;  stack[1152921515144438360] = ???;  //  dest_result_addr=1152921515144438352 |  dest_result_addr=1152921515144438360
        // 0x00B194A0: STP x20, x19, [sp, #0x20]  | stack[1152921515144438368] = ???;  stack[1152921515144438376] = ???;  //  dest_result_addr=1152921515144438368 |  dest_result_addr=1152921515144438376
        // 0x00B194A4: STP x29, x30, [sp, #0x30]  | stack[1152921515144438384] = ???;  stack[1152921515144438392] = ???;  //  dest_result_addr=1152921515144438384 |  dest_result_addr=1152921515144438392
        // 0x00B194A8: ADD x29, sp, #0x30         | X29 = (1152921515144438336 + 48) = 1152921515144438384 (0x100000027416E270);
        // 0x00B194AC: SUB sp, sp, #0x10          | SP = (1152921515144438336 - 16) = 1152921515144438320 (0x100000027416E230);
        // 0x00B194B0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B194B4: LDRB w8, [x20, #0x6e2]     | W8 = (bool)static_value_037336E2;       
        // 0x00B194B8: MOV x19, x0                | X19 = 1152921515144450400 (0x1000000274171160);//ML01
        // 0x00B194BC: TBNZ w8, #0, #0xb194d8     | if (static_value_037336E2 == true) goto label_0;
        // 0x00B194C0: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00B194C4: LDR x8, [x8, #0xbc8]       | X8 = 0x2B8A6F8;                         
        // 0x00B194C8: LDR w0, [x8]               | W0 = 0x7C;                              
        // 0x00B194CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x7C, ????);       
        // 0x00B194D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B194D4: STRB w8, [x20, #0x6e2]     | static_value_037336E2 = true;            //  dest_result_addr=57882338
        label_0:
        // 0x00B194D8: LDR x20, [x19, #0x90]      | X20 = this.csscriptList; //P2           
        // 0x00B194DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B194E0: STRB w8, [x19, #0xb0]      | this.<isStartDown>k__BackingField = true;  //  dest_result_addr=1152921515144450576
        this.<isStartDown>k__BackingField = true;
        // 0x00B194E4: STR wzr, [x19, #0x98]      | this.downFileNum = 0;                    //  dest_result_addr=1152921515144450552
        this.downFileNum = 0;
        // 0x00B194E8: CBNZ x20, #0xb194f0        | if (this.csscriptList != null) goto label_1;
        if(this.csscriptList != null)
        {
            goto label_1;
        }
        // 0x00B194EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x7C, ????);       
        label_1:
        // 0x00B194F0: ADRP x21, #0x35c6000       | X21 = 56385536 (0x35C6000);             
        // 0x00B194F4: LDR x21, [x21, #0x5d8]     | X21 = 1152921514959024432;              
        // 0x00B194F8: MOV x0, x20                | X0 = this.csscriptList;//m1             
        // 0x00B194FC: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B19500: BL #0x25ed72c              | X0 = this.csscriptList.get_Count();     
        int val_1 = this.csscriptList.Count;
        // 0x00B19504: LDR x20, [x19, #0x90]      | X20 = this.csscriptList; //P2           
        // 0x00B19508: STR w0, [x19, #0x9c]       | this.downFileCount = val_1;              //  dest_result_addr=1152921515144450556
        this.downFileCount = val_1;
        // 0x00B1950C: CBNZ x20, #0xb19514        | if (this.csscriptList != null) goto label_2;
        if(this.csscriptList != null)
        {
            goto label_2;
        }
        // 0x00B19510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B19514: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B19518: MOV x0, x20                | X0 = this.csscriptList;//m1             
        // 0x00B1951C: BL #0x25ed72c              | X0 = this.csscriptList.get_Count();     
        int val_2 = this.csscriptList.Count;
        // 0x00B19520: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
        // 0x00B19524: B.LT #0xb196d4             | if (val_2 < 1) goto label_3;            
        if(val_2 < 1)
        {
            goto label_3;
        }
        // 0x00B19528: LDR x20, [x19, #0x90]      | X20 = this.csscriptList; //P2           
        // 0x00B1952C: CBNZ x20, #0xb19534        | if (this.csscriptList != null) goto label_4;
        if(this.csscriptList != null)
        {
            goto label_4;
        }
        // 0x00B19530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B19534: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B19538: MOV x0, x20                | X0 = this.csscriptList;//m1             
        // 0x00B1953C: BL #0x25ed72c              | X0 = this.csscriptList.get_Count();     
        int val_3 = this.csscriptList.Count;
        // 0x00B19540: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00B19544: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00B19548: STR w0, [sp, #0xc]         | stack[1152921515144438332] = val_3;      //  dest_result_addr=1152921515144438332
        // 0x00B1954C: ADD x1, sp, #0xc           | X1 = (1152921515144438320 + 12) = 1152921515144438332 (0x100000027416E23C);
        // 0x00B19550: LDR x8, [x8]               | X8 = typeof(System.Int32);              
        // 0x00B19554: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00B19558: BL #0x27bc028              | X0 = 1152921515144494688 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_3);
        // 0x00B1955C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B19560: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B19564: MOV x20, x0                | X20 = 1152921515144494688 (0x100000027417BE60);//ML01
        // 0x00B19568: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B1956C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B19570: TBZ w9, #0, #0xb19584      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B19574: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B19578: CBNZ w9, #0xb19584         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B1957C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B19580: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_6:
        // 0x00B19584: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00B19588: LDR x8, [x8, #0x4c8]       | X8 = (string**)(1152921515144407872)("cs需要更新{0}个资源");
        // 0x00B1958C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19590: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B19594: MOV x2, x20                | X2 = 1152921515144494688 (0x100000027417BE60);//ML01
        // 0x00B19598: LDR x1, [x8]               | X1 = "cs需要更新{0}个资源";                    
        // 0x00B1959C: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "cs需要更新{0}个资源");
        string val_4 = System.String.Format(format:  0, arg0:  "cs需要更新{0}个资源");
        // 0x00B195A0: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B195A4: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B195A8: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B195AC: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B195B0: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B195B4: TBZ w9, #0, #0xb195c8      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B195B8: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B195BC: CBNZ w9, #0xb195c8         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B195C0: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B195C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_8:
        // 0x00B195C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B195CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B195D0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B195D4: MOV x1, x20                | X1 = val_4;//m1                         
        // 0x00B195D8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_4);
        EDebug.Log(message:  0, isShowStack:  val_4);
        // 0x00B195DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B195E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B195E4: BL #0xdbd3cc               | X0 = LoadingBoardMgr.get_Instance();    
        LoadingBoardMgr val_5 = LoadingBoardMgr.Instance;
        // 0x00B195E8: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B195EC: CBNZ x20, #0xb195f4        | if (val_5 != null) goto label_9;        
        if(val_5 != null)
        {
            goto label_9;
        }
        // 0x00B195F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00B195F4: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00B195F8: LDR x8, [x8, #0x190]       | X8 = (string**)(1152921510482620416)("Updating...");
        // 0x00B195FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19600: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00B19604: LDR x1, [x8]               | X1 = "Updating...";                     
        // 0x00B19608: BL #0xdbdc98               | val_5.SetDescri(value:  "Updating..."); 
        val_5.SetDescri(value:  "Updating...");
        // 0x00B1960C: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_6 = AssetDownMgr.Instance;
        // 0x00B19610: ADRP x23, #0x365c000       | X23 = 56999936 (0x365C000);             
        // 0x00B19614: LDR x23, [x23, #0xd68]     | X23 = 1152921504910680064;              
        // 0x00B19618: LDR x20, [x19, #0x90]      | X20 = this.csscriptList; //P2           
        // 0x00B1961C: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00B19620: LDR x8, [x23]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B19624: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B19628: LDR x22, [x8, #0x18]       | X22 = ABCheckUpdate.<>f__am$cache2;     
        val_8 = ABCheckUpdate.<>f__am$cache2;
        // 0x00B1962C: CBNZ x22, #0xb19670        | if (ABCheckUpdate.<>f__am$cache2 != null) goto label_10;
        if(val_8 != null)
        {
            goto label_10;
        }
        // 0x00B19630: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B19634: ADRP x9, #0x361c000        | X9 = 56737792 (0x361C000);              
        // 0x00B19638: LDR x8, [x8, #0x210]       | X8 = 1152921515144424352;               
        // 0x00B1963C: LDR x9, [x9, #0x610]       | X9 = 1152921504910786560;               
        // 0x00B19640: LDR x22, [x8]              | X22 = static System.Void ABCheckUpdate::<StartCsDown>m__8(string name, byte[] abBytes);
        // 0x00B19644: LDR x0, [x9]               | X0 = typeof(AssetDownMgr.SetBytes);     
        // 0x00B19648: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetDownMgr.SetBytes), ????);
        // 0x00B1964C: LDR x8, [x22]              | X8 = static System.Void ABCheckUpdate::<StartCsDown>m__8(string name, byte[] abBytes);
        // 0x00B19650: STP xzr, x22, [x0, #0x20]  | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = 0x0;  typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = static System.Void ABCheckUpdate::<StartCsDown>m__8(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786592 |  dest_result_addr=1152921504910786600
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = 0;
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = static System.Void ABCheckUpdate::<StartCsDown>m__8(string name, byte[] abBytes);
        // 0x00B19654: STR x8, [x0, #0x10]        | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = static System.Void ABCheckUpdate::<StartCsDown>m__8(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786576
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = static System.Void ABCheckUpdate::<StartCsDown>m__8(string name, byte[] abBytes);
        // 0x00B19658: LDR x8, [x23]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B1965C: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B19660: STR x0, [x8, #0x18]        | ABCheckUpdate.<>f__am$cache2 = typeof(AssetDownMgr.SetBytes);  //  dest_result_addr=1152921504910684184
        ABCheckUpdate.<>f__am$cache2 = null;
        // 0x00B19664: LDR x8, [x23]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B19668: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1966C: LDR x22, [x8, #0x18]       | X22 = typeof(AssetDownMgr.SetBytes);    
        val_8 = ABCheckUpdate.<>f__am$cache2;
        label_10:
        // 0x00B19670: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
        // 0x00B19674: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B19678: LDR x8, [x8, #0xbd0]       | X8 = 1152921515144425376;               
        // 0x00B1967C: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B19680: LDR x24, [x8]              | X24 = System.Void ABCheckUpdate::<StartCsDown>m__9();
        // 0x00B19684: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_7 = null;
        // 0x00B19688: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B1968C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B19690: MOV x1, x19                | X1 = 1152921515144450400 (0x1000000274171160);//ML01
        // 0x00B19694: MOV x2, x24                | X2 = 1152921515144425376 (0x100000027416AFA0);//ML01
        // 0x00B19698: MOV x23, x0                | X23 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1969C: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ABCheckUpdate::<StartCsDown>m__9());
        val_7 = new System.Action(object:  this, method:  System.Void ABCheckUpdate::<StartCsDown>m__9());
        // 0x00B196A0: CBNZ x21, #0xb196a8        | if (val_6 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x00B196A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void ABCheckUpdate::<StartCsDown>m__9()), ????);
        label_11:
        // 0x00B196A8: MOV x0, x21                | X0 = val_6;//m1                         
        // 0x00B196AC: MOV x1, x20                | X1 = this.csscriptList;//m1             
        // 0x00B196B0: MOV x2, x22                | X2 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B196B4: MOV x3, x23                | X3 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B196B8: BL #0xb18c70               | val_6.AddUpdateData(updateList:  this.csscriptList, downFinishCall:  val_8, writeDownFinishCall:  val_7);
        val_6.AddUpdateData(updateList:  this.csscriptList, downFinishCall:  val_8, writeDownFinishCall:  val_7);
        // 0x00B196BC: SUB sp, x29, #0x30         | SP = (1152921515144438384 - 48) = 1152921515144438336 (0x100000027416E240);
        // 0x00B196C0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B196C4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B196C8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B196CC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B196D0: RET                        |  return;                                
        return;
        label_3:
        // 0x00B196D4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B196D8: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B196DC: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00B196E0: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B196E4: TBZ w8, #0, #0xb196f4      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B196E8: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B196EC: CBNZ w8, #0xb196f4         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B196F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_13:
        // 0x00B196F4: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00B196F8: LDR x8, [x8, #0x88]        | X8 = (string**)(1152921515144246624)("无资源更新，进入游戏");
        // 0x00B196FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19700: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B19704: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B19708: LDR x1, [x8]               | X1 = "无资源更新，进入游戏";                      
        // 0x00B1970C: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00B19710: MOV x0, x19                | X0 = 1152921515144450400 (0x1000000274171160);//ML01
        // 0x00B19714: SUB sp, x29, #0x30         | SP = (1152921515144438384 - 48) = 1152921515144438336 (0x100000027416E240);
        // 0x00B19718: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1971C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B19720: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B19724: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B19728: B #0xb1913c                | this.LoadedAll(); return;               
        this.LoadedAll();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1828C (11633292), len: 1752  VirtAddr: 0x00B1828C RVA: 0x00B1828C token: 100694268 methodIndex: 24611 delegateWrapperIndex: 0 methodInvoker: 0
    private bool VerifyMD5(string path, string md5)
    {
        //
        // Disasemble & Code
        //  | 
        string val_26;
        //  | 
        string val_27;
        // 0x00B1828C: STP x26, x25, [sp, #-0x50]! | stack[1152921515144741808] = ???;  stack[1152921515144741816] = ???;  //  dest_result_addr=1152921515144741808 |  dest_result_addr=1152921515144741816
        // 0x00B18290: STP x24, x23, [sp, #0x10]  | stack[1152921515144741824] = ???;  stack[1152921515144741832] = ???;  //  dest_result_addr=1152921515144741824 |  dest_result_addr=1152921515144741832
        // 0x00B18294: STP x22, x21, [sp, #0x20]  | stack[1152921515144741840] = ???;  stack[1152921515144741848] = ???;  //  dest_result_addr=1152921515144741840 |  dest_result_addr=1152921515144741848
        // 0x00B18298: STP x20, x19, [sp, #0x30]  | stack[1152921515144741856] = ???;  stack[1152921515144741864] = ???;  //  dest_result_addr=1152921515144741856 |  dest_result_addr=1152921515144741864
        // 0x00B1829C: STP x29, x30, [sp, #0x40]  | stack[1152921515144741872] = ???;  stack[1152921515144741880] = ???;  //  dest_result_addr=1152921515144741872 |  dest_result_addr=1152921515144741880
        // 0x00B182A0: ADD x29, sp, #0x40         | X29 = (1152921515144741808 + 64) = 1152921515144741872 (0x10000002741B83F0);
        // 0x00B182A4: SUB sp, sp, #0x20          | SP = (1152921515144741808 - 32) = 1152921515144741776 (0x10000002741B8390);
        // 0x00B182A8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B182AC: LDRB w8, [x21, #0x6e3]     | W8 = (bool)static_value_037336E3;       
        // 0x00B182B0: MOV x19, x2                | X19 = md5;//m1                          
        // 0x00B182B4: MOV x23, x1                | X23 = path;//m1                         
        // 0x00B182B8: MOV x20, x0                | X20 = 1152921515144753888 (0x10000002741BB2E0);//ML01
        // 0x00B182BC: TBNZ w8, #0, #0xb182d8     | if (static_value_037336E3 == true) goto label_0;
        // 0x00B182C0: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
        // 0x00B182C4: LDR x8, [x8, #0x600]       | X8 = 0x2B8A730;                         
        // 0x00B182C8: LDR w0, [x8]               | W0 = 0x8A;                              
        // 0x00B182CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x8A, ????);       
        // 0x00B182D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B182D4: STRB w8, [x21, #0x6e3]     | static_value_037336E3 = true;            //  dest_result_addr=57882339
        label_0:
        // 0x00B182D8: BL #0xb14978               | X0 = this.SavePath();                   
        string val_1 = this.SavePath();
        // 0x00B182DC: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x00B182E0: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        // 0x00B182E4: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B182E8: LDR x8, [x25]              | X8 = typeof(System.String);             
        // 0x00B182EC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B182F0: TBZ w9, #0, #0xb18304      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B182F4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B182F8: CBNZ w9, #0xb18304         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B182FC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B18300: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_2:
        // 0x00B18304: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18308: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1830C: MOV x1, x21                | X1 = val_1;//m1                         
        // 0x00B18310: MOV x2, x23                | X2 = path;//m1                          
        // 0x00B18314: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_1);
        string val_2 = System.String.Concat(str0:  0, str1:  val_1);
        // 0x00B18318: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00B1831C: LDR x8, [x8, #0x48]        | X8 = 1152921504621170688;               
        // 0x00B18320: MOV x24, x0                | X24 = val_2;//m1                        
        // 0x00B18324: LDR x8, [x8]               | X8 = typeof(System.IO.FileInfo);        
        // 0x00B18328: MOV x0, x8                 | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        System.IO.FileInfo val_3 = null;
        // 0x00B1832C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.FileInfo), ????);
        // 0x00B18330: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18334: MOV x1, x24                | X1 = val_2;//m1                         
        // 0x00B18338: MOV x21, x0                | X21 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B1833C: BL #0x1e6e0a0              | .ctor(fileName:  val_2);                
        val_3 = new System.IO.FileInfo(fileName:  val_2);
        // 0x00B18340: CBNZ x21, #0xb18348        | if ( != 0) goto label_3;                
        if(null != 0)
        {
            goto label_3;
        }
        // 0x00B18344: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(fileName:  val_2), ????);
        label_3:
        // 0x00B18348: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B1834C: MOV x0, x21                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B18350: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
        // 0x00B18354: BLR x9                     | X0 = mem[null + 400]();                 
        // 0x00B18358: TBZ w0, #0, #0xb186dc      | if ((typeof(System.IO.FileInfo) & 0x1) == 0) goto label_22;
        if((val_3 & 1) == 0)
        {
            goto label_22;
        }
        // 0x00B1835C: CBNZ x24, #0xb18364        | if (val_2 != null) goto label_5;        
        if(val_2 != null)
        {
            goto label_5;
        }
        // 0x00B18360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.FileInfo), ????);
        label_5:
        // 0x00B18364: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00B18368: LDR x8, [x8, #0xde8]       | X8 = (string**)(1152921509978841008)("javascript.uab");
        // 0x00B1836C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18370: MOV x0, x24                | X0 = val_2;//m1                         
        // 0x00B18374: LDR x1, [x8]               | X1 = "javascript.uab";                  
        // 0x00B18378: BL #0x18ab0a0              | X0 = val_2.EndsWith(value:  "javascript.uab");
        bool val_4 = val_2.EndsWith(value:  "javascript.uab");
        // 0x00B1837C: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        bool val_5 = val_4;
        // 0x00B18380: TBNZ w8, #0, #0xb183d0     | if ((val_4 & 1) == true) goto label_8;  
        if(val_5 == true)
        {
            goto label_8;
        }
        // 0x00B18384: CBNZ x24, #0xb1838c        | if (val_2 != null) goto label_7;        
        if(val_2 != null)
        {
            goto label_7;
        }
        // 0x00B18388: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B1838C: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B18390: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921510473861536)("config.uab");
        // 0x00B18394: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18398: MOV x0, x24                | X0 = val_2;//m1                         
        // 0x00B1839C: LDR x1, [x8]               | X1 = "config.uab";                      
        // 0x00B183A0: BL #0x18ab0a0              | X0 = val_2.EndsWith(value:  "config.uab");
        bool val_6 = val_2.EndsWith(value:  "config.uab");
        // 0x00B183A4: AND w8, w0, #1             | W8 = (val_6 & 1);                       
        bool val_7 = val_6;
        // 0x00B183A8: TBNZ w8, #0, #0xb183d0     | if ((val_6 & 1) == true) goto label_8;  
        if(val_7 == true)
        {
            goto label_8;
        }
        // 0x00B183AC: CBNZ x24, #0xb183b4        | if (val_2 != null) goto label_9;        
        if(val_2 != null)
        {
            goto label_9;
        }
        // 0x00B183B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_9:
        // 0x00B183B4: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00B183B8: LDR x8, [x8, #0xa88]       | X8 = (string**)(1152921515142011008)("csscript.uab");
        // 0x00B183BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B183C0: MOV x0, x24                | X0 = val_2;//m1                         
        // 0x00B183C4: LDR x1, [x8]               | X1 = "csscript.uab";                    
        // 0x00B183C8: BL #0x18ab0a0              | X0 = val_2.EndsWith(value:  "csscript.uab");
        bool val_8 = val_2.EndsWith(value:  "csscript.uab");
        // 0x00B183CC: TBZ w0, #0, #0xb18464      | if (val_8 == false) goto label_10;      
        if(val_8 == false)
        {
            goto label_10;
        }
        label_8:
        // 0x00B183D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B183D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B183D8: MOV x1, x24                | X1 = val_2;//m1                         
        // 0x00B183DC: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_9 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B183E0: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B183E4: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B183E8: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00B183EC: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B183F0: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B183F4: TBZ w9, #0, #0xb18408      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B183F8: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B183FC: CBNZ w9, #0xb18408         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B18400: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B18404: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_12:
        // 0x00B18408: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1840C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18410: MOV x1, x20                | X1 = val_9;//m1                         
        // 0x00B18414: BL #0xac28b4               | X0 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        string val_10 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        // 0x00B18418: LDR x8, [x25]              | X8 = typeof(System.String);             
        // 0x00B1841C: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B18420: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B18424: TBZ w9, #0, #0xb18438      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B18428: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1842C: CBNZ w9, #0xb18438         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B18430: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B18434: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_14:
        // 0x00B18438: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1843C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18440: MOV x1, x20                | X1 = val_10;//m1                        
        // 0x00B18444: MOV x2, x19                | X2 = md5;//m1                           
        // 0x00B18448: SUB sp, x29, #0x40         | SP = (1152921515144741872 - 64) = 1152921515144741808 (0x10000002741B83B0);
        // 0x00B1844C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B18450: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B18454: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B18458: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1845C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B18460: B #0x18a2cbc               | return System.String.op_Equality(a:  0, b:  val_10);
        return System.String.op_Equality(a:  0, b:  val_10);
        label_10:
        // 0x00B18464: LDR x22, [x20, #0x10]      | X22 = this.clientCrcList; //P2          
        // 0x00B18468: CBNZ x22, #0xb18470        | if (this.clientCrcList != null) goto label_15;
        if(this.clientCrcList != null)
        {
            goto label_15;
        }
        // 0x00B1846C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_15:
        // 0x00B18470: LDR x22, [x22, #0x10]      | 
        // 0x00B18474: CBNZ x22, #0xb1847c        | if (this.clientCrcList != null) goto label_16;
        if(this.clientCrcList != null)
        {
            goto label_16;
        }
        // 0x00B18478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_16:
        // 0x00B1847C: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x00B18480: LDR x8, [x8, #0xf00]       | X8 = 1152921510891359184;               
        // 0x00B18484: MOV x0, x22                | X0 = this.clientCrcList;//m1            
        // 0x00B18488: MOV x1, x23                | X1 = path;//m1                          
        // 0x00B1848C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
        // 0x00B18490: BL #0x25ead74              | X0 = this.clientCrcList.Contains(item:  path);
        bool val_11 = this.clientCrcList.Contains(item:  path);
        // 0x00B18494: TBZ w0, #0, #0xb18700      | if (val_11 == false) goto label_17;     
        if(val_11 == false)
        {
            goto label_17;
        }
        // 0x00B18498: LDR x20, [x20, #0x10]      | X20 = this.clientCrcList; //P2          
        // 0x00B1849C: CBNZ x20, #0xb184a4        | if (this.clientCrcList != null) goto label_18;
        if(this.clientCrcList != null)
        {
            goto label_18;
        }
        // 0x00B184A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_18:
        // 0x00B184A4: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B184A8: LDR x8, [x8, #0xdc8]       | X8 = 1152921515141944448;               
        // 0x00B184AC: MOV x0, x20                | X0 = this.clientCrcList;//m1            
        // 0x00B184B0: MOV x1, x23                | X1 = path;//m1                          
        // 0x00B184B4: LDR x2, [x8]               | X2 = public FileInfoCrc Filelist<FileInfoCrc>::GetResData(string fileName);
        // 0x00B184B8: BL #0x19cd75c              | X0 = this.clientCrcList.GetResData(fileName:  path);
        FileInfoCrc val_12 = this.clientCrcList.GetResData(fileName:  path);
        // 0x00B184BC: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00B184C0: CBNZ x20, #0xb184c8        | if (val_12 != null) goto label_19;      
        if(val_12 != null)
        {
            goto label_19;
        }
        // 0x00B184C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_19:
        // 0x00B184C8: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x00B184CC: LDR x22, [x20, #0x18]      | X22 = val_12.mDataMD5; //P2             
        // 0x00B184D0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B184D4: TBZ w8, #0, #0xb184e4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x00B184D8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B184DC: CBNZ w8, #0xb184e4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x00B184E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_21:
        // 0x00B184E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B184E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B184EC: MOV x1, x22                | X1 = val_12.mDataMD5;//m1               
        // 0x00B184F0: MOV x2, x19                | X2 = md5;//m1                           
        // 0x00B184F4: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_12.mDataMD5);
        bool val_13 = System.String.op_Equality(a:  0, b:  val_12.mDataMD5);
        // 0x00B184F8: TBZ w0, #0, #0xb186dc      | if (val_13 == false) goto label_22;     
        if(val_13 == false)
        {
            goto label_22;
        }
        // 0x00B184FC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B18500: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B18504: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
        // 0x00B18508: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B1850C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B18510: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B18514: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B18518: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B1851C: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B18520: CBNZ x21, #0xb18528        | if ( != 0) goto label_23;               
        if(null != 0)
        {
            goto label_23;
        }
        // 0x00B18524: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_23:
        // 0x00B18528: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1852C: MOV x0, x21                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B18530: BL #0x1e726dc              | X0 = get_Length();                      
        long val_14 = Length;
        // 0x00B18534: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B18538: LDR x8, [x8, #0x4b0]       | X8 = 1152921504607592448;               
        // 0x00B1853C: STR x0, [sp, #0x18]        | stack[1152921515144741800] = val_14;     //  dest_result_addr=1152921515144741800
        // 0x00B18540: ADD x1, sp, #0x18          | X1 = (1152921515144741776 + 24) = 1152921515144741800 (0x10000002741B83A8);
        // 0x00B18544: LDR x8, [x8]               | X8 = typeof(System.Int64);              
        // 0x00B18548: MOV x0, x8                 | X0 = 1152921504607592448 (0x10000000000B6000);//ML01
        // 0x00B1854C: BL #0x27bc028              | X0 = 1152921515144859616 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), val_14);
        // 0x00B18550: MOV x23, x0                | X23 = 1152921515144859616 (0x10000002741D4FE0);//ML01
        // 0x00B18554: CBNZ x22, #0xb1855c        | if ( != null) goto label_24;            
        if(null != null)
        {
            goto label_24;
        }
        // 0x00B18558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_24:
        // 0x00B1855C: CBZ x23, #0xb18580         | if (val_14 == 0) goto label_26;         
        if(val_14 == 0)
        {
            goto label_26;
        }
        // 0x00B18560: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B18564: MOV x0, x23                | X0 = 1152921515144859616 (0x10000002741D4FE0);//ML01
        // 0x00B18568: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B1856C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
        // 0x00B18570: CBNZ x0, #0xb18580         | if (val_14 != 0) goto label_26;         
        if(val_14 != 0)
        {
            goto label_26;
        }
        // 0x00B18574: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_14, ????);     
        // 0x00B18578: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1857C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
        label_26:
        // 0x00B18580: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B18584: CBNZ w8, #0xb18594         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_27;
        // 0x00B18588: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
        // 0x00B1858C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B18590: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
        label_27:
        // 0x00B18594: STR x23, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_14;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_14;
        // 0x00B18598: CBNZ x21, #0xb185a0        | if ( != 0) goto label_28;               
        if(null != 0)
        {
            goto label_28;
        }
        // 0x00B1859C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_28:
        // 0x00B185A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B185A4: MOV x0, x21                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B185A8: BL #0x1e78290              | X0 = get_LastWriteTime();               
        System.DateTime val_15 = LastWriteTime;
        // 0x00B185AC: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B185B0: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
        // 0x00B185B4: LDR x8, [x8]               | X8 = typeof(System.DateTime);           
        // 0x00B185B8: STP x0, x1, [sp, #8]       | stack[1152921515144741784] = val_15.ticks._ticks;  stack[1152921515144741792] = val_15.kind;  //  dest_result_addr=1152921515144741784 |  dest_result_addr=1152921515144741792
        // 0x00B185BC: ADD x1, sp, #8             | X1 = (1152921515144741776 + 8) = 1152921515144741784 (0x10000002741B8398);
        // 0x00B185C0: MOV x0, x8                 | X0 = 1152921504652693504 (0x1000000002BB9000);//ML01
        // 0x00B185C4: BL #0x27bc028              | X0 = 1152921515144864736 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.DateTime), val_15);
        // 0x00B185C8: MOV x21, x0                | X21 = 1152921515144864736 (0x10000002741D63E0);//ML01
        // 0x00B185CC: CBZ x21, #0xb185f0         | if (val_15 == 0) goto label_30;         
        if(val_15 == 0)
        {
            goto label_30;
        }
        // 0x00B185D0: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B185D4: MOV x0, x21                | X0 = 1152921515144864736 (0x10000002741D63E0);//ML01
        // 0x00B185D8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B185DC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
        // 0x00B185E0: CBNZ x0, #0xb185f0         | if (val_15 != 0) goto label_30;         
        if(val_15 != 0)
        {
            goto label_30;
        }
        // 0x00B185E4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
        // 0x00B185E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B185EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
        label_30:
        // 0x00B185F0: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B185F4: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B185F8: B.HI #0xb18608             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_31;
        // 0x00B185FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
        // 0x00B18600: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B18604: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
        label_31:
        // 0x00B18608: STR x21, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_15;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_15;
        // 0x00B1860C: CBZ x19, #0xb18630         | if (md5 == null) goto label_33;         
        if(md5 == null)
        {
            goto label_33;
        }
        // 0x00B18610: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B18614: MOV x0, x19                | X0 = md5;//m1                           
        // 0x00B18618: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B1861C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? md5, ????);        
        // 0x00B18620: CBNZ x0, #0xb18630         | if (md5 != null) goto label_33;         
        if(md5 != null)
        {
            goto label_33;
        }
        // 0x00B18624: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? md5, ????);        
        // 0x00B18628: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1862C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? md5, ????);        
        label_33:
        // 0x00B18630: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B18634: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B18638: B.HI #0xb18648             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_34;
        // 0x00B1863C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? md5, ????);        
        // 0x00B18640: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B18644: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? md5, ????);        
        label_34:
        // 0x00B18648: STR x19, [x22, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = md5;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = md5;
        // 0x00B1864C: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00B18650: LDR x8, [x8, #0x1a8]       | X8 = (string**)(1152921514966421632)("{0}{1}{2}");
        // 0x00B18654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18658: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1865C: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B18660: LDR x1, [x8]               | X1 = "{0}{1}{2}";                       
        // 0x00B18664: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "{0}{1}{2}");
        string val_16 = EString.EFormat(format:  0, args:  "{0}{1}{2}");
        // 0x00B18668: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B1866C: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B18670: MOV x19, x0                | X19 = val_16;//m1                       
        // 0x00B18674: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B18678: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B1867C: TBZ w9, #0, #0xb18690      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_36;
        // 0x00B18680: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B18684: CBNZ w9, #0xb18690         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
        // 0x00B18688: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B1868C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_36:
        // 0x00B18690: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18694: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18698: MOV x1, x19                | X1 = val_16;//m1                        
        // 0x00B1869C: BL #0xabf710               | X0 = Mihua.Update.VSTools.GetCRC32(str:  0);
        string val_17 = Mihua.Update.VSTools.GetCRC32(str:  0);
        // 0x00B186A0: MOV x19, x0                | X19 = val_17;//m1                       
        // 0x00B186A4: CBNZ x20, #0xb186ac        | if (val_12 != null) goto label_37;      
        if(val_12 != null)
        {
            goto label_37;
        }
        // 0x00B186A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_37:
        // 0x00B186AC: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x00B186B0: LDR x20, [x20, #0x20]      | X20 = val_12.mCrc32; //P2               
        // 0x00B186B4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B186B8: TBZ w8, #0, #0xb186c8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_39;
        // 0x00B186BC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B186C0: CBNZ w8, #0xb186c8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_39;
        // 0x00B186C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_39:
        // 0x00B186C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_26 = 0;
        // 0x00B186CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B186D0: MOV x1, x19                | X1 = val_17;//m1                        
        val_27 = val_17;
        // 0x00B186D4: MOV x2, x20                | X2 = val_12.mCrc32;//m1                 
        // 0x00B186D8: B #0xb1895c                |  goto label_40;                         
        goto label_40;
        label_22:
        // 0x00B186DC: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        var val_26 = 0;
        label_61:
        // 0x00B186E0: AND w0, w0, #1             | W0 = (0 & 1);                           
        val_26 = val_26 & 1;
        // 0x00B186E4: SUB sp, x29, #0x40         | SP = (1152921515144741872 - 64) = 1152921515144741808 (0x10000002741B83B0);
        // 0x00B186E8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B186EC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B186F0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B186F4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B186F8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B186FC: RET                        |  return (System.Boolean)(0 & 1);        
        return (bool)val_26;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        label_17:
        // 0x00B18700: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
        // 0x00B18704: LDR x8, [x8, #0xe08]       | X8 = 1152921504910946304;               
        // 0x00B18708: LDR x0, [x8]               | X0 = typeof(FileInfoCrc);               
        FileInfoCrc val_18 = null;
        // 0x00B1870C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(FileInfoCrc), ????);
        // 0x00B18710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B18714: MOV x22, x0                | X22 = 1152921504910946304 (0x1000000012203000);//ML01
        // 0x00B18718: BL #0xed49d4               | .ctor();                                
        val_18 = new FileInfoCrc();
        // 0x00B1871C: CBNZ x22, #0xb18724        | if ( != 0) goto label_41;               
        if(null != 0)
        {
            goto label_41;
        }
        // 0x00B18720: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_41:
        // 0x00B18724: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18728: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1872C: MOV x1, x24                | X1 = val_2;//m1                         
        // 0x00B18730: STR x23, [x22, #0x10]      | typeof(FileInfoCrc).__il2cppRuntimeField_10 = path;  //  dest_result_addr=1152921504910946320
        typeof(FileInfoCrc).__il2cppRuntimeField_10 = path;
        // 0x00B18734: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_19 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B18738: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B1873C: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B18740: MOV x23, x0                | X23 = val_19;//m1                       
        // 0x00B18744: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B18748: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B1874C: TBZ w9, #0, #0xb18760      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_43;
        // 0x00B18750: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B18754: CBNZ w9, #0xb18760         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
        // 0x00B18758: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B1875C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_43:
        // 0x00B18760: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18764: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18768: MOV x1, x23                | X1 = val_19;//m1                        
        // 0x00B1876C: BL #0xabed5c               | X0 = Mihua.Update.VSTools.GetCRC32(bytes:  0);
        string val_20 = Mihua.Update.VSTools.GetCRC32(bytes:  0);
        // 0x00B18770: STR x0, [x22, #0x18]       | typeof(FileInfoCrc).__il2cppRuntimeField_18 = val_20;  //  dest_result_addr=1152921504910946328
        typeof(FileInfoCrc).__il2cppRuntimeField_18 = val_20;
        // 0x00B18774: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B18778: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B1877C: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
        // 0x00B18780: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B18784: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B18788: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B1878C: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B18790: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B18794: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B18798: CBNZ x21, #0xb187a0        | if ( != 0) goto label_44;               
        if(null != 0)
        {
            goto label_44;
        }
        // 0x00B1879C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_44:
        // 0x00B187A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B187A4: MOV x0, x21                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B187A8: BL #0x1e726dc              | X0 = get_Length();                      
        long val_21 = Length;
        // 0x00B187AC: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B187B0: LDR x8, [x8, #0x4b0]       | X8 = 1152921504607592448;               
        // 0x00B187B4: STR x0, [sp, #0x18]        | stack[1152921515144741800] = val_21;     //  dest_result_addr=1152921515144741800
        // 0x00B187B8: ADD x1, sp, #0x18          | X1 = (1152921515144741776 + 24) = 1152921515144741800 (0x10000002741B83A8);
        // 0x00B187BC: LDR x8, [x8]               | X8 = typeof(System.Int64);              
        // 0x00B187C0: MOV x0, x8                 | X0 = 1152921504607592448 (0x10000000000B6000);//ML01
        // 0x00B187C4: BL #0x27bc028              | X0 = 1152921515144922080 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), val_21);
        // 0x00B187C8: MOV x24, x0                | X24 = 1152921515144922080 (0x10000002741E43E0);//ML01
        // 0x00B187CC: CBNZ x23, #0xb187d4        | if ( != null) goto label_45;            
        if(null != null)
        {
            goto label_45;
        }
        // 0x00B187D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_45:
        // 0x00B187D4: CBZ x24, #0xb187f8         | if (val_21 == 0) goto label_47;         
        if(val_21 == 0)
        {
            goto label_47;
        }
        // 0x00B187D8: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B187DC: MOV x0, x24                | X0 = 1152921515144922080 (0x10000002741E43E0);//ML01
        // 0x00B187E0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B187E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_21, ????);     
        // 0x00B187E8: CBNZ x0, #0xb187f8         | if (val_21 != 0) goto label_47;         
        if(val_21 != 0)
        {
            goto label_47;
        }
        // 0x00B187EC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_21, ????);     
        // 0x00B187F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B187F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
        label_47:
        // 0x00B187F8: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B187FC: CBNZ w8, #0xb1880c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_48;
        // 0x00B18800: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_21, ????);     
        // 0x00B18804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B18808: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
        label_48:
        // 0x00B1880C: STR x24, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_21;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_21;
        // 0x00B18810: CBNZ x21, #0xb18818        | if ( != 0) goto label_49;               
        if(null != 0)
        {
            goto label_49;
        }
        // 0x00B18814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_49:
        // 0x00B18818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1881C: MOV x0, x21                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B18820: BL #0x1e78290              | X0 = get_LastWriteTime();               
        System.DateTime val_22 = LastWriteTime;
        // 0x00B18824: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B18828: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
        // 0x00B1882C: LDR x8, [x8]               | X8 = typeof(System.DateTime);           
        // 0x00B18830: STP x0, x1, [sp, #8]       | stack[1152921515144741784] = val_22.ticks._ticks;  stack[1152921515144741792] = val_22.kind;  //  dest_result_addr=1152921515144741784 |  dest_result_addr=1152921515144741792
        // 0x00B18834: ADD x1, sp, #8             | X1 = (1152921515144741776 + 8) = 1152921515144741784 (0x10000002741B8398);
        // 0x00B18838: MOV x0, x8                 | X0 = 1152921504652693504 (0x1000000002BB9000);//ML01
        // 0x00B1883C: BL #0x27bc028              | X0 = 1152921515144927200 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.DateTime), val_22);
        // 0x00B18840: MOV x21, x0                | X21 = 1152921515144927200 (0x10000002741E57E0);//ML01
        // 0x00B18844: CBZ x21, #0xb18868         | if (val_22 == 0) goto label_51;         
        if(val_22 == 0)
        {
            goto label_51;
        }
        // 0x00B18848: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B1884C: MOV x0, x21                | X0 = 1152921515144927200 (0x10000002741E57E0);//ML01
        // 0x00B18850: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B18854: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_22, ????);     
        // 0x00B18858: CBNZ x0, #0xb18868         | if (val_22 != 0) goto label_51;         
        if(val_22 != 0)
        {
            goto label_51;
        }
        // 0x00B1885C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_22, ????);     
        // 0x00B18860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B18864: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
        label_51:
        // 0x00B18868: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B1886C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B18870: B.HI #0xb18880             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_52;
        // 0x00B18874: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_22, ????);     
        // 0x00B18878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1887C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
        label_52:
        // 0x00B18880: STR x21, [x23, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_22;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_22;
        // 0x00B18884: CBNZ x22, #0xb1888c        | if ( != 0) goto label_53;               
        if(null != 0)
        {
            goto label_53;
        }
        // 0x00B18888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_53:
        // 0x00B1888C: LDR x21, [x22, #0x18]      | X21 = val_20;                           
        // 0x00B18890: CBZ x21, #0xb188b4         | if (val_20 == 0) goto label_55;         
        if(typeof(FileInfoCrc).__il2cppRuntimeField_18 == 0)
        {
            goto label_55;
        }
        // 0x00B18894: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B18898: MOV x0, x21                | X0 = val_20;//m1                        
        // 0x00B1889C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B188A0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_20, ????);     
        // 0x00B188A4: CBNZ x0, #0xb188b4         | if (val_20 != 0) goto label_55;         
        if(typeof(FileInfoCrc).__il2cppRuntimeField_18 != 0)
        {
            goto label_55;
        }
        // 0x00B188A8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_20, ????);     
        // 0x00B188AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B188B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
        label_55:
        // 0x00B188B4: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B188B8: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B188BC: B.HI #0xb188cc             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_56;
        // 0x00B188C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_20, ????);     
        // 0x00B188C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B188C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
        label_56:
        // 0x00B188CC: STR x21, [x23, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = val_20;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = typeof(FileInfoCrc).__il2cppRuntimeField_18;
        // 0x00B188D0: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00B188D4: LDR x8, [x8, #0x1a8]       | X8 = (string**)(1152921514966421632)("{0}{1}{2}");
        // 0x00B188D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B188DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B188E0: MOV x2, x23                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B188E4: LDR x1, [x8]               | X1 = "{0}{1}{2}";                       
        // 0x00B188E8: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "{0}{1}{2}");
        string val_23 = EString.EFormat(format:  0, args:  "{0}{1}{2}");
        // 0x00B188EC: MOV x1, x0                 | X1 = val_23;//m1                        
        // 0x00B188F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B188F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B188F8: BL #0xabf710               | X0 = Mihua.Update.VSTools.GetCRC32(str:  0);
        string val_24 = Mihua.Update.VSTools.GetCRC32(str:  0);
        // 0x00B188FC: MOV x21, x0                | X21 = val_24;//m1                       
        // 0x00B18900: CBNZ x22, #0xb18908        | if ( != 0) goto label_57;               
        if(null != 0)
        {
            goto label_57;
        }
        // 0x00B18904: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_57:
        // 0x00B18908: STR x21, [x22, #0x20]      | typeof(FileInfoCrc).__il2cppRuntimeField_20 = val_24;  //  dest_result_addr=1152921504910946336
        typeof(FileInfoCrc).__il2cppRuntimeField_20 = val_24;
        // 0x00B1890C: LDR x20, [x20, #0x10]      | X20 = this.clientCrcList; //P2          
        // 0x00B18910: CBNZ x20, #0xb18918        | if (this.clientCrcList != null) goto label_58;
        if(this.clientCrcList != null)
        {
            goto label_58;
        }
        // 0x00B18914: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_58:
        // 0x00B18918: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00B1891C: LDR x8, [x8, #0x558]       | X8 = 1152921515144728864;               
        // 0x00B18920: MOV x0, x20                | X0 = this.clientCrcList;//m1            
        // 0x00B18924: MOV x1, x22                | X1 = 1152921504910946304 (0x1000000012203000);//ML01
        // 0x00B18928: LDR x2, [x8]               | X2 = public System.Void Filelist<FileInfoCrc>::AddResData(FileInfoCrc data);
        // 0x00B1892C: BL #0x19cd0cc              | this.clientCrcList.AddResData(data:  val_18);
        this.clientCrcList.AddResData(data:  val_18);
        // 0x00B18930: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x00B18934: LDR x20, [x22, #0x18]      | X20 = val_20;                           
        // 0x00B18938: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1893C: TBZ w8, #0, #0xb1894c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_60;
        // 0x00B18940: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B18944: CBNZ w8, #0xb1894c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
        // 0x00B18948: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_60:
        // 0x00B1894C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_26 = 0;
        // 0x00B18950: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B18954: MOV x1, x20                | X1 = val_20;//m1                        
        val_27 = typeof(FileInfoCrc).__il2cppRuntimeField_18;
        // 0x00B18958: MOV x2, x19                | X2 = md5;//m1                           
        label_40:
        // 0x00B1895C: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  val_26 = 0, b:  val_27 = typeof(FileInfoCrc).__il2cppRuntimeField_18);
        bool val_25 = System.String.op_Equality(a:  val_26, b:  val_27);
        // 0x00B18960: B #0xb186e0                |  goto label_61;                         
        goto label_61;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1913C (11637052), len: 860  VirtAddr: 0x00B1913C RVA: 0x00B1913C token: 100694269 methodIndex: 24612 delegateWrapperIndex: 0 methodInvoker: 0
    private void LoadedAll()
    {
        //
        // Disasemble & Code
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        System.Action val_10;
        // 0x00B1913C: STP x26, x25, [sp, #-0x50]! | stack[1152921515145037712] = ???;  stack[1152921515145037720] = ???;  //  dest_result_addr=1152921515145037712 |  dest_result_addr=1152921515145037720
        // 0x00B19140: STP x24, x23, [sp, #0x10]  | stack[1152921515145037728] = ???;  stack[1152921515145037736] = ???;  //  dest_result_addr=1152921515145037728 |  dest_result_addr=1152921515145037736
        // 0x00B19144: STP x22, x21, [sp, #0x20]  | stack[1152921515145037744] = ???;  stack[1152921515145037752] = ???;  //  dest_result_addr=1152921515145037744 |  dest_result_addr=1152921515145037752
        // 0x00B19148: STP x20, x19, [sp, #0x30]  | stack[1152921515145037760] = ???;  stack[1152921515145037768] = ???;  //  dest_result_addr=1152921515145037760 |  dest_result_addr=1152921515145037768
        // 0x00B1914C: STP x29, x30, [sp, #0x40]  | stack[1152921515145037776] = ???;  stack[1152921515145037784] = ???;  //  dest_result_addr=1152921515145037776 |  dest_result_addr=1152921515145037784
        // 0x00B19150: ADD x29, sp, #0x40         | X29 = (1152921515145037712 + 64) = 1152921515145037776 (0x10000002742007D0);
        // 0x00B19154: SUB sp, sp, #0x10          | SP = (1152921515145037712 - 16) = 1152921515145037696 (0x1000000274200780);
        // 0x00B19158: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1915C: LDRB w8, [x20, #0x6e4]     | W8 = (bool)static_value_037336E4;       
        // 0x00B19160: MOV x19, x0                | X19 = 1152921515145049792 (0x10000002742036C0);//ML01
        // 0x00B19164: TBNZ w8, #0, #0xb19180     | if (static_value_037336E4 == true) goto label_0;
        // 0x00B19168: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00B1916C: LDR x8, [x8, #0x98]        | X8 = 0x2B8A6D0;                         
        // 0x00B19170: LDR w0, [x8]               | W0 = 0x72;                              
        // 0x00B19174: BL #0x2782188              | X0 = sub_2782188( ?? 0x72, ????);       
        // 0x00B19178: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1917C: STRB w8, [x20, #0x6e4]     | static_value_037336E4 = true;            //  dest_result_addr=57882340
        label_0:
        // 0x00B19180: ADRP x20, #0x3618000       | X20 = 56721408 (0x3618000);             
        // 0x00B19184: LDR x20, [x20, #0x530]     | X20 = 1152921504924098560;              
        // 0x00B19188: LDR x0, [x20]              | X0 = typeof(EDebug);                    
        // 0x00B1918C: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B19190: TBZ w8, #0, #0xb191a0      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B19194: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B19198: CBNZ w8, #0xb191a0         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1919C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00B191A0: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00B191A4: LDR x8, [x8, #0x798]       | X8 = (string**)(1152921515144999584)("所有资源更新完成，写入新版本配置文件");
        // 0x00B191A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B191AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B191B0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B191B4: LDR x1, [x8]               | X1 = "所有资源更新完成，写入新版本配置文件";              
        // 0x00B191B8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00B191BC: LDR x1, [x19, #0x28]       | X1 = this.serverList; //P2              
        // 0x00B191C0: MOV x0, x19                | X0 = 1152921515145049792 (0x10000002742036C0);//ML01
        // 0x00B191C4: STR x1, [x19, #0x20]       | this.clientList = this.serverList;       //  dest_result_addr=1152921515145049824
        this.clientList = this.serverList;
        // 0x00B191C8: BL #0xb149e0               | this.WriteClientVS(fileList:  this.serverList);
        this.WriteClientVS(fileList:  this.serverList);
        // 0x00B191CC: LDR x8, [x19, #0x78]       | X8 = this.serverVer; //P2               
        // 0x00B191D0: MOV x0, x19                | X0 = 1152921515145049792 (0x10000002742036C0);//ML01
        // 0x00B191D4: STR x8, [x19, #0x58]       | this.clientVer = this.serverVer;         //  dest_result_addr=1152921515145049880
        this.clientVer = this.serverVer;
        // 0x00B191D8: BL #0xb1972c               | this.WriteClientVer();                  
        this.WriteClientVer();
        // 0x00B191DC: LDRB w8, [x19, #0x50]      | W8 = this.isRestart; //P2               
        // 0x00B191E0: CBZ w8, #0xb193f4          | if (this.isRestart == false) goto label_3;
        if(this.isRestart == false)
        {
            goto label_3;
        }
        // 0x00B191E4: ADRP x19, #0x35ef000       | X19 = 56553472 (0x35EF000);             
        // 0x00B191E8: LDR x19, [x19, #0xde8]     | X19 = 1152921504911265792;              
        // 0x00B191EC: LDR x0, [x19]              | X0 = typeof(Loader.PathUtil);           
        val_8 = null;
        // 0x00B191F0: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B191F4: TBZ w8, #0, #0xb19208      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B191F8: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B191FC: CBNZ w8, #0xb19208         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B19200: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B19204: LDR x0, [x19]              | X0 = typeof(Loader.PathUtil);           
        val_8 = null;
        label_5:
        // 0x00B19208: ADRP x9, #0x35ed000        | X9 = 56545280 (0x35ED000);              
        // 0x00B1920C: ADRP x10, #0x366e000       | X10 = 57073664 (0x366E000);             
        // 0x00B19210: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B19214: LDR x9, [x9, #0x8a0]       | X9 = (string**)(1152921515145007888)("allAssets/");
        // 0x00B19218: LDR x10, [x10, #0xe00]     | X10 = (string**)(1152921515145007984)("allAssets");
        // 0x00B1921C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19220: LDR x1, [x8, #0x28]        | X1 = Loader.PathUtil.persistentDataPath;
        // 0x00B19224: LDR x2, [x9]               | X2 = "allAssets/";                      
        // 0x00B19228: LDR x3, [x10]              | X3 = "allAssets";                       
        // 0x00B1922C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B19230: BL #0x27954f0              | X0 = EString.EReplace(t:  0, oldString:  Loader.PathUtil.persistentDataPath, newString:  "allAssets/");
        string val_1 = EString.EReplace(t:  0, oldString:  Loader.PathUtil.persistentDataPath, newString:  "allAssets/");
        // 0x00B19234: LDR x8, [x19]              | X8 = typeof(Loader.PathUtil);           
        // 0x00B19238: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00B1923C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19240: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B19244: LDR x8, [x8, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B19248: LDR x2, [x8, #0x40]        | X2 = Loader.PathUtil.dataPath;          
        // 0x00B1924C: BL #0xb92ea4               | X0 = Bootstrap.use_data_dir(_data_path:  0, _apk_path:  val_1);
        string val_2 = Bootstrap.use_data_dir(_data_path:  0, _apk_path:  val_1);
        // 0x00B19250: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
        // 0x00B19254: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
        // 0x00B19258: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B1925C: LDR x8, [x21]              | X8 = typeof(System.String);             
        // 0x00B19260: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B19264: TBZ w9, #0, #0xb19278      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B19268: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1926C: CBNZ w9, #0xb19278         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B19270: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B19274: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_7:
        // 0x00B19278: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1927C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19280: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00B19284: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_3 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B19288: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00B1928C: TBNZ w8, #0, #0xb192ec     | if ((val_3 & 1) == true) goto label_8;  
        if(val_4 == true)
        {
            goto label_8;
        }
        // 0x00B19290: LDR x0, [x20]              | X0 = typeof(EDebug);                    
        // 0x00B19294: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B19298: TBZ w8, #0, #0xb192a8      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B1929C: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B192A0: CBNZ w8, #0xb192a8         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B192A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_10:
        // 0x00B192A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B192AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B192B0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B192B4: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00B192B8: BL #0xb5b538               | EDebug.LogError(message:  0, isShowStack:  val_2);
        EDebug.LogError(message:  0, isShowStack:  val_2);
        // 0x00B192BC: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00B192C0: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00B192C4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
        // 0x00B192C8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B192CC: TBZ w8, #0, #0xb192dc      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B192D0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B192D4: CBNZ w8, #0xb192dc         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B192D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_12:
        // 0x00B192DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B192E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B192E4: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00B192E8: BL #0x1a5d504              | UnityEngine.Debug.LogError(message:  0);
        UnityEngine.Debug.LogError(message:  0);
        label_8:
        // 0x00B192EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B192F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B192F4: BL #0x138e268              | X0 = PluginsSdkMgr.get_Instance();      
        PluginsSdkMgr val_5 = PluginsSdkMgr.Instance;
        // 0x00B192F8: LDR x8, [x21]              | X8 = typeof(System.String);             
        val_9 = null;
        // 0x00B192FC: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00B19300: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B19304: TBZ w9, #0, #0xb1931c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B19308: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1930C: CBNZ w9, #0xb1931c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B19310: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B19314: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B19318: LDR x8, [x21]              | X8 = typeof(System.String);             
        val_9 = null;
        label_14:
        // 0x00B1931C: ADRP x26, #0x365c000       | X26 = 56999936 (0x365C000);             
        // 0x00B19320: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B19324: LDR x26, [x26, #0xd68]     | X26 = 1152921504910680064;              
        // 0x00B19328: ADRP x10, #0x35e1000       | X10 = 56496128 (0x35E1000);             
        // 0x00B1932C: ADRP x11, #0x35fa000       | X11 = 56598528 (0x35FA000);             
        // 0x00B19330: ADRP x12, #0x3680000       | X12 = 57147392 (0x3680000);             
        // 0x00B19334: LDR x9, [x26]              | X9 = typeof(ABCheckUpdate);             
        // 0x00B19338: LDR x10, [x10, #0x4d8]     | X10 = (string**)(1152921514955921760)("Confirm");
        // 0x00B1933C: LDR x11, [x11, #0xdc8]     | X11 = (string**)(1152921515145020368)("Resource update completed, requires restarting the game");
        // 0x00B19340: LDR x12, [x12, #0x100]     | X12 = (string**)(1152921515145020560)("Update Complete");
        // 0x00B19344: LDR x9, [x9, #0xa0]        | X9 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B19348: LDR x21, [x10]             | X21 = "Confirm";                        
        // 0x00B1934C: LDR x22, [x11]             | X22 = "Resource update completed, requires restarting the game";
        // 0x00B19350: LDR x20, [x8]              | X20 = System.String.Empty;              
        // 0x00B19354: LDR x24, [x9, #0x20]       | X24 = ABCheckUpdate.<>f__am$cache3;     
        val_10 = ABCheckUpdate.<>f__am$cache3;
        // 0x00B19358: LDR x23, [x12]             | X23 = "Update Complete";                
        // 0x00B1935C: CBNZ x24, #0xb193a8        | if (ABCheckUpdate.<>f__am$cache3 != null) goto label_15;
        if(val_10 != null)
        {
            goto label_15;
        }
        // 0x00B19360: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00B19364: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B19368: LDR x8, [x8, #0x490]       | X8 = 1152921515145020672;               
        // 0x00B1936C: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B19370: LDR x24, [x8]              | X24 = static System.Void ABCheckUpdate::<LoadedAll>m__A();
        // 0x00B19374: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_6 = null;
        // 0x00B19378: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B1937C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19380: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B19384: MOV x2, x24                | X2 = 1152921515145020672 (0x10000002741FC500);//ML01
        // 0x00B19388: MOV x25, x0                | X25 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1938C: BL #0x26e30f0              | .ctor(object:  0, method:  static System.Void ABCheckUpdate::<LoadedAll>m__A());
        val_6 = new System.Action(object:  0, method:  static System.Void ABCheckUpdate::<LoadedAll>m__A());
        // 0x00B19390: LDR x8, [x26]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B19394: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B19398: STR x25, [x8, #0x20]       | ABCheckUpdate.<>f__am$cache3 = typeof(System.Action);  //  dest_result_addr=1152921504910684192
        ABCheckUpdate.<>f__am$cache3 = val_6;
        // 0x00B1939C: LDR x8, [x26]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B193A0: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B193A4: LDR x24, [x8, #0x20]       | X24 = typeof(System.Action);            
        val_10 = ABCheckUpdate.<>f__am$cache3;
        label_15:
        // 0x00B193A8: CBNZ x19, #0xb193b0        | if (val_5 != null) goto label_16;       
        if(val_5 != null)
        {
            goto label_16;
        }
        // 0x00B193AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ABCheckUpdate::<LoadedAll>m__A()), ????);
        label_16:
        // 0x00B193B0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B193B4: MOV x0, x19                | X0 = val_5;//m1                         
        // 0x00B193B8: MOV x1, x23                | X1 = 1152921515145020560 (0x10000002741FC490);//ML01
        // 0x00B193BC: MOV x2, x22                | X2 = 1152921515145020368 (0x10000002741FC3D0);//ML01
        // 0x00B193C0: MOV x4, x21                | X4 = 1152921514955921760 (0x1000000268DA5960);//ML01
        // 0x00B193C4: MOV x5, x20                | X5 = System.String.Empty;//m1           
        // 0x00B193C8: MOV x6, x24                | X6 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B193CC: MOV x7, xzr                | X7 = 0 (0x0);//ML01                     
        // 0x00B193D0: STR xzr, [sp]              | stack[1152921515145037696] = 0x0;        //  dest_result_addr=1152921515145037696
        // 0x00B193D4: BL #0x13a69fc              | val_5.ShowDialog(title:  "Update Complete", content:  "Resource update completed, requires restarting the game", cancelable:  false, okText:  "Confirm", cancelText:  System.String.Empty, OnOK:  val_10, OnCancel:  0);
        val_5.ShowDialog(title:  "Update Complete", content:  "Resource update completed, requires restarting the game", cancelable:  false, okText:  "Confirm", cancelText:  System.String.Empty, OnOK:  val_10, OnCancel:  0);
        // 0x00B193D8: SUB sp, x29, #0x40         | SP = (1152921515145037776 - 64) = 1152921515145037712 (0x1000000274200790);
        // 0x00B193DC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B193E0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B193E4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B193E8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B193EC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B193F0: RET                        |  return;                                
        return;
        label_3:
        // 0x00B193F4: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x00B193F8: LDR x8, [x8, #0xf30]       | X8 = 1152921504903544832;               
        // 0x00B193FC: LDR x19, [x19, #0x20]      | X19 = this.clientList; //P2             
        // 0x00B19400: LDR x0, [x8]               | X0 = typeof(Mihua.Assets.AssetUtil);    
        // 0x00B19404: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
        // 0x00B19408: TBZ w8, #0, #0xb19418      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00B1940C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B19410: CBNZ w8, #0xb19418         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00B19414: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
        label_18:
        // 0x00B19418: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1941C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19420: MOV x1, x19                | X1 = this.clientList;//m1               
        // 0x00B19424: BL #0xab7204               | Mihua.Assets.AssetUtil.SetAssetCfg(fileList:  0);
        Mihua.Assets.AssetUtil.SetAssetCfg(fileList:  0);
        // 0x00B19428: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B1942C: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00B19430: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
        CEvent.ZEvent val_7 = null;
        // 0x00B19434: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00B19438: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
        // 0x00B1943C: LDR x8, [x8, #0xb00]       | X8 = (string**)(1152921510024638640)("FLOW_CHECK_UPDATE");
        // 0x00B19440: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19444: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B19448: LDR x1, [x8]               | X1 = "FLOW_CHECK_UPDATE";               
        // 0x00B1944C: BL #0xd80ce8               | .ctor(name:  "FLOW_CHECK_UPDATE");      
        val_7 = new CEvent.ZEvent(name:  "FLOW_CHECK_UPDATE");
        // 0x00B19450: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B19454: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B19458: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B1945C: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B19460: TBZ w8, #0, #0xb19470      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B19464: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B19468: CBNZ w8, #0xb19470         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B1946C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_20:
        // 0x00B19470: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19474: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19478: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B1947C: SUB sp, x29, #0x40         | SP = (1152921515145037776 - 64) = 1152921515145037712 (0x1000000274200790);
        // 0x00B19480: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19484: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B19488: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1948C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B19490: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B19494: B #0xd7de90                | CEvent.ZEventCenter.DispatchEvent(ev:  0); return;
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14978 (11618680), len: 104  VirtAddr: 0x00B14978 RVA: 0x00B14978 token: 100694270 methodIndex: 24613 delegateWrapperIndex: 0 methodInvoker: 0
    private string SavePath()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00B14978: STP x20, x19, [sp, #-0x20]! | stack[1152921515145174336] = ???;  stack[1152921515145174344] = ???;  //  dest_result_addr=1152921515145174336 |  dest_result_addr=1152921515145174344
        // 0x00B1497C: STP x29, x30, [sp, #0x10]  | stack[1152921515145174352] = ???;  stack[1152921515145174360] = ???;  //  dest_result_addr=1152921515145174352 |  dest_result_addr=1152921515145174360
        // 0x00B14980: ADD x29, sp, #0x10         | X29 = (1152921515145174336 + 16) = 1152921515145174352 (0x1000000274221D50);
        // 0x00B14984: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B14988: LDRB w8, [x19, #0x6e5]     | W8 = (bool)static_value_037336E5;       
        // 0x00B1498C: TBNZ w8, #0, #0xb149a8     | if (static_value_037336E5 == true) goto label_0;
        // 0x00B14990: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x00B14994: LDR x8, [x8, #0x2c8]       | X8 = 0x2B8A6F0;                         
        // 0x00B14998: LDR w0, [x8]               | W0 = 0x7A;                              
        // 0x00B1499C: BL #0x2782188              | X0 = sub_2782188( ?? 0x7A, ????);       
        // 0x00B149A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B149A4: STRB w8, [x19, #0x6e5]     | static_value_037336E5 = true;            //  dest_result_addr=57882341
        label_0:
        // 0x00B149A8: ADRP x19, #0x35ef000       | X19 = 56553472 (0x35EF000);             
        // 0x00B149AC: LDR x19, [x19, #0xde8]     | X19 = 1152921504911265792;              
        // 0x00B149B0: LDR x0, [x19]              | X0 = typeof(Loader.PathUtil);           
        val_1 = null;
        // 0x00B149B4: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B149B8: TBZ w8, #0, #0xb149cc      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B149BC: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B149C0: CBNZ w8, #0xb149cc         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B149C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B149C8: LDR x0, [x19]              | X0 = typeof(Loader.PathUtil);           
        val_1 = null;
        label_2:
        // 0x00B149CC: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B149D0: LDR x0, [x8, #0x28]        | X0 = Loader.PathUtil.persistentDataPath;
        // 0x00B149D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B149D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B149DC: RET                        |  return (System.String)Loader.PathUtil.persistentDataPath;
        return Loader.PathUtil.persistentDataPath;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1979C (11638684), len: 308  VirtAddr: 0x00B1979C RVA: 0x00B1979C token: 100694271 methodIndex: 24614 delegateWrapperIndex: 0 methodInvoker: 0
    private void WriteByteFile(string key, byte[] abBytes)
    {
        //
        // Disasemble & Code
        // 0x00B1979C: STP x24, x23, [sp, #-0x40]! | stack[1152921515145355936] = ???;  stack[1152921515145355944] = ???;  //  dest_result_addr=1152921515145355936 |  dest_result_addr=1152921515145355944
        // 0x00B197A0: STP x22, x21, [sp, #0x10]  | stack[1152921515145355952] = ???;  stack[1152921515145355960] = ???;  //  dest_result_addr=1152921515145355952 |  dest_result_addr=1152921515145355960
        // 0x00B197A4: STP x20, x19, [sp, #0x20]  | stack[1152921515145355968] = ???;  stack[1152921515145355976] = ???;  //  dest_result_addr=1152921515145355968 |  dest_result_addr=1152921515145355976
        // 0x00B197A8: STP x29, x30, [sp, #0x30]  | stack[1152921515145355984] = ???;  stack[1152921515145355992] = ???;  //  dest_result_addr=1152921515145355984 |  dest_result_addr=1152921515145355992
        // 0x00B197AC: ADD x29, sp, #0x30         | X29 = (1152921515145355936 + 48) = 1152921515145355984 (0x100000027424E2D0);
        // 0x00B197B0: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B197B4: LDRB w8, [x22, #0x6e6]     | W8 = (bool)static_value_037336E6;       
        // 0x00B197B8: MOV x19, x2                | X19 = abBytes;//m1                      
        // 0x00B197BC: MOV x21, x1                | X21 = key;//m1                          
        // 0x00B197C0: MOV x20, x0                | X20 = 1152921515145368000 (0x10000002742511C0);//ML01
        // 0x00B197C4: TBNZ w8, #0, #0xb197e0     | if (static_value_037336E6 == true) goto label_0;
        // 0x00B197C8: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
        // 0x00B197CC: LDR x8, [x8, #0xd58]       | X8 = 0x2B8A734;                         
        // 0x00B197D0: LDR w0, [x8]               | W0 = 0x8B;                              
        // 0x00B197D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x8B, ????);       
        // 0x00B197D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B197DC: STRB w8, [x22, #0x6e6]     | static_value_037336E6 = true;            //  dest_result_addr=57882342
        label_0:
        // 0x00B197E0: LDR x22, [x20, #0x70]      | X22 = this.sb; //P2                     
        // 0x00B197E4: CBNZ x22, #0xb197ec        | if (this.sb != null) goto label_1;      
        if(this.sb != null)
        {
            goto label_1;
        }
        // 0x00B197E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x8B, ????);       
        label_1:
        // 0x00B197EC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B197F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B197F4: MOV x0, x22                | X0 = this.sb;//m1                       
        // 0x00B197F8: BL #0x1b5ac0c              | this.sb.set_Length(value:  0);          
        this.sb.Length = 0;
        // 0x00B197FC: LDR x22, [x20, #0x70]      | X22 = this.sb; //P2                     
        // 0x00B19800: BL #0xb14978               | X0 = this.sb.SavePath();                
        string val_1 = this.sb.SavePath();
        // 0x00B19804: MOV x23, x0                | X23 = val_1;//m1                        
        // 0x00B19808: CBNZ x22, #0xb19810        | if (this.sb != null) goto label_2;      
        if(this.sb != null)
        {
            goto label_2;
        }
        // 0x00B1980C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B19810: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19814: MOV x0, x22                | X0 = this.sb;//m1                       
        // 0x00B19818: MOV x1, x23                | X1 = val_1;//m1                         
        // 0x00B1981C: BL #0x1b5b818              | X0 = this.sb.Append(value:  val_1);     
        System.Text.StringBuilder val_2 = this.sb.Append(value:  val_1);
        // 0x00B19820: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00B19824: CBNZ x22, #0xb1982c        | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x00B19828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00B1982C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19830: MOV x0, x22                | X0 = val_2;//m1                         
        // 0x00B19834: MOV x1, x21                | X1 = key;//m1                           
        // 0x00B19838: BL #0x1b5b818              | X0 = val_2.Append(value:  key);         
        System.Text.StringBuilder val_3 = val_2.Append(value:  key);
        // 0x00B1983C: LDR x20, [x20, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B19840: CBNZ x20, #0xb19848        | if (this.sb != null) goto label_4;      
        if(this.sb != null)
        {
            goto label_4;
        }
        // 0x00B19844: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00B19848: LDR x8, [x20]              | X8 = typeof(System.Text.StringBuilder); 
        // 0x00B1984C: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B19850: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
        // 0x00B19854: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
        // 0x00B19858: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00B1985C: LDR x8, [x8, #0x48]        | X8 = 1152921504621170688;               
        // 0x00B19860: MOV x20, x0                | X20 = this.sb;//m1                      
        // 0x00B19864: LDR x8, [x8]               | X8 = typeof(System.IO.FileInfo);        
        // 0x00B19868: MOV x0, x8                 | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        System.IO.FileInfo val_4 = null;
        // 0x00B1986C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.FileInfo), ????);
        // 0x00B19870: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19874: MOV x1, x20                | X1 = this.sb;//m1                       
        // 0x00B19878: MOV x21, x0                | X21 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B1987C: BL #0x1e6e0a0              | .ctor(fileName:  this.sb);              
        val_4 = new System.IO.FileInfo(fileName:  this.sb);
        // 0x00B19880: CBNZ x21, #0xb19888        | if ( != 0) goto label_5;                
        if(null != 0)
        {
            goto label_5;
        }
        // 0x00B19884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(fileName:  this.sb), ????);
        label_5:
        // 0x00B19888: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1988C: MOV x0, x21                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B19890: BL #0x1e72848              | X0 = get_Directory();                   
        System.IO.DirectoryInfo val_5 = Directory;
        // 0x00B19894: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B19898: CBNZ x21, #0xb198a0        | if (val_5 != null) goto label_6;        
        if(val_5 != null)
        {
            goto label_6;
        }
        // 0x00B1989C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x00B198A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B198A4: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B198A8: BL #0x1e698c4              | val_5.Create();                         
        val_5.Create();
        // 0x00B198AC: MOV x1, x20                | X1 = this.sb;//m1                       
        // 0x00B198B0: MOV x2, x19                | X2 = abBytes;//m1                       
        // 0x00B198B4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B198B8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B198BC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B198C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B198C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B198C8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B198CC: B #0x1e71f34               | System.IO.File.WriteAllBytes(path:  0, bytes:  this.sb); return;
        System.IO.File.WriteAllBytes(path:  0, bytes:  this.sb);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1972C (11638572), len: 112  VirtAddr: 0x00B1972C RVA: 0x00B1972C token: 100694272 methodIndex: 24615 delegateWrapperIndex: 0 methodInvoker: 0
    private void WriteClientVer()
    {
        //
        // Disasemble & Code
        // 0x00B1972C: STP x20, x19, [sp, #-0x20]! | stack[1152921515145541696] = ???;  stack[1152921515145541704] = ???;  //  dest_result_addr=1152921515145541696 |  dest_result_addr=1152921515145541704
        // 0x00B19730: STP x29, x30, [sp, #0x10]  | stack[1152921515145541712] = ???;  stack[1152921515145541720] = ???;  //  dest_result_addr=1152921515145541712 |  dest_result_addr=1152921515145541720
        // 0x00B19734: ADD x29, sp, #0x10         | X29 = (1152921515145541696 + 16) = 1152921515145541712 (0x100000027427B850);
        // 0x00B19738: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1973C: LDRB w8, [x20, #0x6e7]     | W8 = (bool)static_value_037336E7;       
        // 0x00B19740: MOV x19, x0                | X19 = 1152921515145553728 (0x100000027427E740);//ML01
        // 0x00B19744: TBNZ w8, #0, #0xb19760     | if (static_value_037336E7 == true) goto label_0;
        // 0x00B19748: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1974C: LDR x8, [x8, #0xaf0]       | X8 = 0x2B8A738;                         
        // 0x00B19750: LDR w0, [x8]               | W0 = 0x8C;                              
        // 0x00B19754: BL #0x2782188              | X0 = sub_2782188( ?? 0x8C, ????);       
        // 0x00B19758: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1975C: STRB w8, [x20, #0x6e7]     | static_value_037336E7 = true;            //  dest_result_addr=57882343
        label_0:
        // 0x00B19760: LDR x20, [x19, #0x58]      | X20 = this.clientVer; //P2              
        // 0x00B19764: CBNZ x20, #0xb1976c        | if (this.clientVer != null) goto label_1;
        if(this.clientVer != null)
        {
            goto label_1;
        }
        // 0x00B19768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x8C, ????);       
        label_1:
        // 0x00B1976C: LDR x8, [x20]              | X8 = typeof(System.String);             
        // 0x00B19770: MOV x0, x20                | X0 = this.clientVer;//m1                
        // 0x00B19774: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.String).__il2cppRuntimeField_140; X1 = typeof(System.String).__il2cppRuntimeField_148; //  | 
        // 0x00B19778: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_140();
        // 0x00B1977C: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00B19780: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921510473501152)("vsnum.uab");
        // 0x00B19784: MOV x2, x0                 | X2 = this.clientVer;//m1                
        // 0x00B19788: MOV x0, x19                | X0 = 1152921515145553728 (0x100000027427E740);//ML01
        // 0x00B1978C: LDR x1, [x8]               | X1 = "vsnum.uab";                       
        // 0x00B19790: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19794: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B19798: B #0xb198d0                | this.WriteTextFile(key:  "vsnum.uab", text:  this.clientVer); return;
        this.WriteTextFile(key:  "vsnum.uab", text:  this.clientVer);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B149E0 (11618784), len: 120  VirtAddr: 0x00B149E0 RVA: 0x00B149E0 token: 100694273 methodIndex: 24616 delegateWrapperIndex: 0 methodInvoker: 0
    private void WriteClientVS(Filelist<FileInfoRes> fileList)
    {
        //
        // Disasemble & Code
        // 0x00B149E0: STP x22, x21, [sp, #-0x30]! | stack[1152921515145661872] = ???;  stack[1152921515145661880] = ???;  //  dest_result_addr=1152921515145661872 |  dest_result_addr=1152921515145661880
        // 0x00B149E4: STP x20, x19, [sp, #0x10]  | stack[1152921515145661888] = ???;  stack[1152921515145661896] = ???;  //  dest_result_addr=1152921515145661888 |  dest_result_addr=1152921515145661896
        // 0x00B149E8: STP x29, x30, [sp, #0x20]  | stack[1152921515145661904] = ???;  stack[1152921515145661912] = ???;  //  dest_result_addr=1152921515145661904 |  dest_result_addr=1152921515145661912
        // 0x00B149EC: ADD x29, sp, #0x20         | X29 = (1152921515145661872 + 32) = 1152921515145661904 (0x1000000274298DD0);
        // 0x00B149F0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B149F4: LDRB w8, [x21, #0x6e8]     | W8 = (bool)static_value_037336E8;       
        // 0x00B149F8: MOV x20, x1                | X20 = fileList;//m1                     
        // 0x00B149FC: MOV x19, x0                | X19 = 1152921515145673920 (0x100000027429BCC0);//ML01
        // 0x00B14A00: TBNZ w8, #0, #0xb14a1c     | if (static_value_037336E8 == true) goto label_0;
        // 0x00B14A04: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B14A08: LDR x8, [x8, #0x7c0]       | X8 = 0x2B8A73C;                         
        // 0x00B14A0C: LDR w0, [x8]               | W0 = 0x8D;                              
        // 0x00B14A10: BL #0x2782188              | X0 = sub_2782188( ?? 0x8D, ????);       
        // 0x00B14A14: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B14A18: STRB w8, [x21, #0x6e8]     | static_value_037336E8 = true;            //  dest_result_addr=57882344
        label_0:
        // 0x00B14A1C: CBNZ x20, #0xb14a24        | if (fileList != null) goto label_1;     
        if(fileList != null)
        {
            goto label_1;
        }
        // 0x00B14A20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x8D, ????);       
        label_1:
        // 0x00B14A24: LDR x8, [x20]              | X8 = typeof(Filelist<FileInfoRes>);     
        // 0x00B14A28: MOV x0, x20                | X0 = fileList;//m1                      
        // 0x00B14A2C: LDP x9, x1, [x8, #0x140]   | X9 = typeof(Filelist<T>).__il2cppRuntimeField_140; X1 = typeof(Filelist<T>).__il2cppRuntimeField_148; //  | 
        // 0x00B14A30: BLR x9                     | X0 = typeof(Filelist<T>).__il2cppRuntimeField_140();
        // 0x00B14A34: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B14A38: LDR x8, [x8, #0x8b8]       | X8 = (string**)(1152921510473621280)("vsconfig.uab");
        // 0x00B14A3C: MOV x2, x0                 | X2 = fileList;//m1                      
        // 0x00B14A40: MOV x0, x19                | X0 = 1152921515145673920 (0x100000027429BCC0);//ML01
        // 0x00B14A44: LDR x1, [x8]               | X1 = "vsconfig.uab";                    
        // 0x00B14A48: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B14A4C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B14A50: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B14A54: B #0xb198d0                | this.WriteTextFile(key:  "vsconfig.uab", text:  fileList); return;
        this.WriteTextFile(key:  "vsconfig.uab", text:  fileList);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B18964 (11635044), len: 120  VirtAddr: 0x00B18964 RVA: 0x00B18964 token: 100694274 methodIndex: 24617 delegateWrapperIndex: 0 methodInvoker: 0
    private void WriteCrc(Filelist<FileInfoCrc> fileList)
    {
        //
        // Disasemble & Code
        // 0x00B18964: STP x22, x21, [sp, #-0x30]! | stack[1152921515145782064] = ???;  stack[1152921515145782072] = ???;  //  dest_result_addr=1152921515145782064 |  dest_result_addr=1152921515145782072
        // 0x00B18968: STP x20, x19, [sp, #0x10]  | stack[1152921515145782080] = ???;  stack[1152921515145782088] = ???;  //  dest_result_addr=1152921515145782080 |  dest_result_addr=1152921515145782088
        // 0x00B1896C: STP x29, x30, [sp, #0x20]  | stack[1152921515145782096] = ???;  stack[1152921515145782104] = ???;  //  dest_result_addr=1152921515145782096 |  dest_result_addr=1152921515145782104
        // 0x00B18970: ADD x29, sp, #0x20         | X29 = (1152921515145782064 + 32) = 1152921515145782096 (0x10000002742B6350);
        // 0x00B18974: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B18978: LDRB w8, [x21, #0x6e9]     | W8 = (bool)static_value_037336E9;       
        // 0x00B1897C: MOV x20, x1                | X20 = fileList;//m1                     
        // 0x00B18980: MOV x19, x0                | X19 = 1152921515145794112 (0x10000002742B9240);//ML01
        // 0x00B18984: TBNZ w8, #0, #0xb189a0     | if (static_value_037336E9 == true) goto label_0;
        // 0x00B18988: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
        // 0x00B1898C: LDR x8, [x8, #0xa38]       | X8 = 0x2B8A740;                         
        // 0x00B18990: LDR w0, [x8]               | W0 = 0x8E;                              
        // 0x00B18994: BL #0x2782188              | X0 = sub_2782188( ?? 0x8E, ????);       
        // 0x00B18998: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1899C: STRB w8, [x21, #0x6e9]     | static_value_037336E9 = true;            //  dest_result_addr=57882345
        label_0:
        // 0x00B189A0: CBNZ x20, #0xb189a8        | if (fileList != null) goto label_1;     
        if(fileList != null)
        {
            goto label_1;
        }
        // 0x00B189A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x8E, ????);       
        label_1:
        // 0x00B189A8: LDR x8, [x20]              | X8 = typeof(Filelist<FileInfoCrc>);     
        // 0x00B189AC: MOV x0, x20                | X0 = fileList;//m1                      
        // 0x00B189B0: LDP x9, x1, [x8, #0x140]   | X9 = typeof(Filelist<T>).__il2cppRuntimeField_140; X1 = typeof(Filelist<T>).__il2cppRuntimeField_148; //  | 
        // 0x00B189B4: BLR x9                     | X0 = typeof(Filelist<T>).__il2cppRuntimeField_140();
        // 0x00B189B8: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00B189BC: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921510474838464)("eff_crc.uab");
        // 0x00B189C0: MOV x2, x0                 | X2 = fileList;//m1                      
        // 0x00B189C4: MOV x0, x19                | X0 = 1152921515145794112 (0x10000002742B9240);//ML01
        // 0x00B189C8: LDR x1, [x8]               | X1 = "eff_crc.uab";                     
        // 0x00B189CC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B189D0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B189D4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B189D8: B #0xb198d0                | this.WriteTextFile(key:  "eff_crc.uab", text:  fileList); return;
        this.WriteTextFile(key:  "eff_crc.uab", text:  fileList);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B198D0 (11638992), len: 168  VirtAddr: 0x00B198D0 RVA: 0x00B198D0 token: 100694275 methodIndex: 24618 delegateWrapperIndex: 0 methodInvoker: 0
    private void WriteTextFile(string key, string text)
    {
        //
        // Disasemble & Code
        // 0x00B198D0: STP x22, x21, [sp, #-0x30]! | stack[1152921515145910448] = ???;  stack[1152921515145910456] = ???;  //  dest_result_addr=1152921515145910448 |  dest_result_addr=1152921515145910456
        // 0x00B198D4: STP x20, x19, [sp, #0x10]  | stack[1152921515145910464] = ???;  stack[1152921515145910472] = ???;  //  dest_result_addr=1152921515145910464 |  dest_result_addr=1152921515145910472
        // 0x00B198D8: STP x29, x30, [sp, #0x20]  | stack[1152921515145910480] = ???;  stack[1152921515145910488] = ???;  //  dest_result_addr=1152921515145910480 |  dest_result_addr=1152921515145910488
        // 0x00B198DC: ADD x29, sp, #0x20         | X29 = (1152921515145910448 + 32) = 1152921515145910480 (0x10000002742D58D0);
        // 0x00B198E0: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B198E4: LDRB w8, [x22, #0x6ea]     | W8 = (bool)static_value_037336EA;       
        // 0x00B198E8: MOV x21, x2                | X21 = text;//m1                         
        // 0x00B198EC: MOV x19, x1                | X19 = key;//m1                          
        // 0x00B198F0: MOV x20, x0                | X20 = 1152921515145922496 (0x10000002742D87C0);//ML01
        // 0x00B198F4: TBNZ w8, #0, #0xb19910     | if (static_value_037336EA == true) goto label_0;
        // 0x00B198F8: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00B198FC: LDR x8, [x8, #0x2b0]       | X8 = 0x2B8A744;                         
        // 0x00B19900: LDR w0, [x8]               | W0 = 0x8F;                              
        // 0x00B19904: BL #0x2782188              | X0 = sub_2782188( ?? 0x8F, ????);       
        // 0x00B19908: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1990C: STRB w8, [x22, #0x6ea]     | static_value_037336EA = true;            //  dest_result_addr=57882346
        label_0:
        // 0x00B19910: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00B19914: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
        // 0x00B19918: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
        // 0x00B1991C: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
        // 0x00B19920: TBZ w8, #0, #0xb19930      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B19924: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
        // 0x00B19928: CBNZ w8, #0xb19930         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1992C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
        label_2:
        // 0x00B19930: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19938: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_1 = System.Text.Encoding.UTF8;
        // 0x00B1993C: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00B19940: CBNZ x22, #0xb19948        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B19944: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B19948: LDR x8, [x22]              | X8 = typeof(System.Text.Encoding);      
        // 0x00B1994C: MOV x0, x22                | X0 = val_1;//m1                         
        // 0x00B19950: MOV x1, x21                | X1 = text;//m1                          
        // 0x00B19954: LDP x9, x2, [x8, #0x1c0]   | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_1C0; X2 = typeof(System.Text.Encoding).__il2cppRuntimeField_1C8; //  | 
        // 0x00B19958: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_1C0();
        // 0x00B1995C: MOV x2, x0                 | X2 = val_1;//m1                         
        // 0x00B19960: MOV x0, x20                | X0 = 1152921515145922496 (0x10000002742D87C0);//ML01
        // 0x00B19964: MOV x1, x19                | X1 = key;//m1                           
        // 0x00B19968: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1996C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B19970: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B19974: B #0xb1979c                | this.WriteByteFile(key:  key, abBytes:  val_1); return;
        this.WriteByteFile(key:  key, abBytes:  val_1);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19978 (11639160), len: 348  VirtAddr: 0x00B19978 RVA: 0x00B19978 token: 100694276 methodIndex: 24619 delegateWrapperIndex: 0 methodInvoker: 0
    public static string BytesToString(byte[] bytes, System.Text.Encoding encoding)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00B19978: STP x22, x21, [sp, #-0x30]! | stack[1152921515146075696] = ???;  stack[1152921515146075704] = ???;  //  dest_result_addr=1152921515146075696 |  dest_result_addr=1152921515146075704
        // 0x00B1997C: STP x20, x19, [sp, #0x10]  | stack[1152921515146075712] = ???;  stack[1152921515146075720] = ???;  //  dest_result_addr=1152921515146075712 |  dest_result_addr=1152921515146075720
        // 0x00B19980: STP x29, x30, [sp, #0x20]  | stack[1152921515146075728] = ???;  stack[1152921515146075736] = ???;  //  dest_result_addr=1152921515146075728 |  dest_result_addr=1152921515146075736
        // 0x00B19984: ADD x29, sp, #0x20         | X29 = (1152921515146075696 + 32) = 1152921515146075728 (0x10000002742FDE50);
        // 0x00B19988: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1998C: LDRB w8, [x21, #0x6eb]     | W8 = (bool)static_value_037336EB;       
        // 0x00B19990: MOV x20, x2                | X20 = X2;//m1                           
        // 0x00B19994: MOV x19, x1                | X19 = encoding;//m1                     
        // 0x00B19998: TBNZ w8, #0, #0xb199b4     | if (static_value_037336EB == true) goto label_0;
        // 0x00B1999C: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
        // 0x00B199A0: LDR x8, [x8, #0x930]       | X8 = 0x2B8A690;                         
        // 0x00B199A4: LDR w0, [x8]               | W0 = 0x62;                              
        // 0x00B199A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x62, ????);       
        // 0x00B199AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B199B0: STRB w8, [x21, #0x6eb]     | static_value_037336EB = true;            //  dest_result_addr=57882347
        label_0:
        // 0x00B199B4: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00B199B8: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
        // 0x00B199BC: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
        System.IO.MemoryStream val_1 = null;
        // 0x00B199C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
        // 0x00B199C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B199C8: MOV x1, x19                | X1 = encoding;//m1                      
        // 0x00B199CC: MOV x21, x0                | X21 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00B199D0: BL #0x1e78658              | .ctor(buffer:  encoding);               
        val_1 = new System.IO.MemoryStream(buffer:  encoding);
        // 0x00B199D4: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00B199D8: LDR x8, [x8, #0x6a8]       | X8 = 1152921504622501888;               
        // 0x00B199DC: LDR x0, [x8]               | X0 = typeof(System.IO.StreamReader);    
        System.IO.StreamReader val_2 = null;
        // 0x00B199E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.StreamReader), ????);
        // 0x00B199E4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B199E8: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x00B199EC: ORR w4, wzr, #0x400        | W4 = 1024(0x400);                       
        // 0x00B199F0: MOV x1, x21                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00B199F4: MOV x2, x20                | X2 = X2;//m1                            
        // 0x00B199F8: MOV x19, x0                | X19 = 1152921504622501888 (0x1000000000EEE000);//ML01
        // 0x00B199FC: BL #0x1e7d52c              | .ctor(stream:  val_1, encoding:  X2, detectEncodingFromByteOrderMarks:  true, bufferSize:  1024);
        val_2 = new System.IO.StreamReader(stream:  val_1, encoding:  X2, detectEncodingFromByteOrderMarks:  true, bufferSize:  1024);
        // 0x00B19A00: CBNZ x19, #0xb19a08        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B19A04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(stream:  val_1, encoding:  X2, detectEncodingFromByteOrderMarks:  true, bufferSize:  1024), ????);
        label_1:
        // 0x00B19A08: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B19A0C: LDP x9, x1, [x8, #0x1c0]   |                                          //  not_find_field!1:448 |  not_find_field!1:456
        // 0x00B19A10: MOV x0, x19                | X0 = 1152921504622501888 (0x1000000000EEE000);//ML01
        // 0x00B19A14: BLR x9                     | X0 = mem[null + 448]();                 
        // 0x00B19A18: MOV x20, x0                | X20 = 1152921504622501888 (0x1000000000EEE000);//ML01
        // 0x00B19A1C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        // 0x00B19A20: MOVZ w22, #0x2e            | W22 = 46 (0x2E);//ML01                  
        label_9:
        // 0x00B19A24: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B19A28: LDR x8, [x19]              | X8 = ;                                  
        System.IO.StreamReader val_5 = null;
        // 0x00B19A2C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B19A30: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B19A34: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00B19A38: CBZ x9, #0xb19a64          | if (mem[null + 258] == 0) goto label_2; 
        if((mem[null + 258]) == 0)
        {
            goto label_2;
        }
        // 0x00B19A3C: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_3 = mem[null + 152];
        // 0x00B19A40: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_4 = 0;
        // 0x00B19A44: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_3 = val_3 + 8;
        label_4:
        // 0x00B19A48: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00B19A4C: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00B19A50: B.EQ #0xb19a74             | if ((mem[null + 152] + 8) + -8 == null) goto label_3;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_3;
        }
        // 0x00B19A54: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_4 = val_4 + 1;
        // 0x00B19A58: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_3 = val_3 + 16;
        // 0x00B19A5C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00B19A60: B.LO #0xb19a48             | if (0 < mem[null + 258]) goto label_4;  
        if(val_4 < (mem[null + 258]))
        {
            goto label_4;
        }
        label_2:
        // 0x00B19A64: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B19A68: MOV x0, x19                | X0 = 1152921504622501888 (0x1000000000EEE000);//ML01
        val_3 = val_2;
        // 0x00B19A6C: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.StreamReader), ????);
        // 0x00B19A70: B #0xb19a80                |  goto label_5;                          
        goto label_5;
        label_3:
        // 0x00B19A74: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00B19A78: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_5 = val_5 + (((mem[null + 152] + 8)) << 4);
        // 0x00B19A7C: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_5:
        // 0x00B19A80: LDP x8, x1, [x0]           | X8 = ; X1 = System.IO.StreamReader.__il2cppRuntimeField_gc_desc; //  | 
        // 0x00B19A84: MOV x0, x19                | X0 = 1152921504622501888 (0x1000000000EEE000);//ML01
        // 0x00B19A88: BLR x8                     | X0 = x8();                              
        label_8:
        // 0x00B19A8C: CBZ x21, #0xb19aa4         | if (0x0 == 0) goto label_7;             
        if(0 == 0)
        {
            goto label_7;
        }
        // 0x00B19A90: CMP w22, #0x2e             | STATE = COMPARE(0x2E, 0x2E)             
        // 0x00B19A94: B.EQ #0xb19aa4             | if (0x2E == 0x2E) goto label_7;         
        if(46 == 46)
        {
            goto label_7;
        }
        // 0x00B19A98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19A9C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B19AA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_7:
        // 0x00B19AA4: MOV x0, x20                | X0 = 1152921504622501888 (0x1000000000EEE000);//ML01
        // 0x00B19AA8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19AAC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B19AB0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B19AB4: RET                        |  return (System.String)typeof(System.IO.StreamReader);
        return (string)val_2;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        // 0x00B19AB8: BL #0x981060               | 
        // 0x00B19ABC: LDR x21, [x0]              | 
        // 0x00B19AC0: BL #0x980920               | 
        // 0x00B19AC4: MOV x20, xzr               | 
        // 0x00B19AC8: MOV w22, wzr               | 
        // 0x00B19ACC: CBZ x19, #0xb19a8c         | 
        // 0x00B19AD0: B #0xb19a24                | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19AD4 (11639508), len: 44  VirtAddr: 0x00B19AD4 RVA: 0x00B19AD4 token: 100694277 methodIndex: 24620 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_IsDownSuccess()
    {
        //
        // Disasemble & Code
        // 0x00B19AD4: STP x20, x19, [sp, #-0x20]! | stack[1152921515146232768] = ???;  stack[1152921515146232776] = ???;  //  dest_result_addr=1152921515146232768 |  dest_result_addr=1152921515146232776
        // 0x00B19AD8: STP x29, x30, [sp, #0x10]  | stack[1152921515146232784] = ???;  stack[1152921515146232792] = ???;  //  dest_result_addr=1152921515146232784 |  dest_result_addr=1152921515146232792
        // 0x00B19ADC: ADD x29, sp, #0x10         | X29 = (1152921515146232768 + 16) = 1152921515146232784 (0x10000002743243D0);
        // 0x00B19AE0: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_1 = AssetDownMgr.Instance;
        // 0x00B19AE4: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B19AE8: CBNZ x19, #0xb19af0        | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x00B19AEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x00B19AF0: LDRB w0, [x19, #0x88]      | W0 = val_1.IsDownSuccess; //P2          
        // 0x00B19AF4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19AF8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B19AFC: RET                        |  return (System.Boolean)val_1.IsDownSuccess;
        return val_1.IsDownSuccess;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19B00 (11639552), len: 72  VirtAddr: 0x00B19B00 RVA: 0x00B19B00 token: 100694278 methodIndex: 24621 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_WriteProgress()
    {
        //
        // Disasemble & Code
        // 0x00B19B00: STP x20, x19, [sp, #-0x20]! | stack[1152921515146352960] = ???;  stack[1152921515146352968] = ???;  //  dest_result_addr=1152921515146352960 |  dest_result_addr=1152921515146352968
        // 0x00B19B04: STP x29, x30, [sp, #0x10]  | stack[1152921515146352976] = ???;  stack[1152921515146352984] = ???;  //  dest_result_addr=1152921515146352976 |  dest_result_addr=1152921515146352984
        // 0x00B19B08: ADD x29, sp, #0x10         | X29 = (1152921515146352960 + 16) = 1152921515146352976 (0x1000000274341950);
        // 0x00B19B0C: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_1 = AssetDownMgr.Instance;
        // 0x00B19B10: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B19B14: CBNZ x19, #0xb19b1c        | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x00B19B18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x00B19B1C: LDR x8, [x19, #0x58]       | X8 = val_1.totalFileCount; //P2         
        // 0x00B19B20: CBZ w8, #0xb19b38          | if (val_1.totalFileCount == 0) goto label_1;
        if(val_1.totalFileCount == 0)
        {
            goto label_1;
        }
        // 0x00B19B24: LSR x9, x8, #0x20          | X9 = (val_1.totalFileCount >> 32);      
        int val_2 = val_1.totalFileCount >> 32;
        // 0x00B19B28: SCVTF s0, w9               | S0 = (float)((val_1.totalFileCount >> 32));
        float val_3 = (float)val_2;
        // 0x00B19B2C: SCVTF s1, w8               | S1 = (float)(val_1.totalFileCount);     
        // 0x00B19B30: FDIV s0, s0, s1            | S0 = ((val_1.totalFileCount >> 32) / val_1.totalFileCount);
        val_3 = val_3 / (float)val_1.totalFileCount;
        // 0x00B19B34: B #0xb19b3c                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00B19B38: FMOV s0, wzr               | S0 = 0f;                                
        label_2:
        // 0x00B19B3C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19B40: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B19B44: RET                        |  return (System.Single)0;               
        return (float)0f;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19B6C (11639660), len: 8  VirtAddr: 0x00B19B6C RVA: 0x00B19B6C token: 100694279 methodIndex: 24622 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_isPkged()
    {
        //
        // Disasemble & Code
        // 0x00B19B6C: LDRB w0, [x0, #0xa9]       | W0 = this.<isPkged>k__BackingField; //P2 
        // 0x00B19B70: RET                        |  return (System.Boolean)this.<isPkged>k__BackingField;
        return this.<isPkged>k__BackingField;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14F6C (11620204), len: 12  VirtAddr: 0x00B14F6C RVA: 0x00B14F6C token: 100694280 methodIndex: 24623 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_isPkged(bool value)
    {
        //
        // Disasemble & Code
        // 0x00B14F6C: AND w8, w1, #1             | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00B14F70: STRB w8, [x0, #0xa9]       | this.<isPkged>k__BackingField = (value & 1);  //  dest_result_addr=1152921515146593257
        this.<isPkged>k__BackingField = val_1;
        // 0x00B14F74: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19B74 (11639668), len: 24  VirtAddr: 0x00B19B74 RVA: 0x00B19B74 token: 100694281 methodIndex: 24624 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_PkgProgress()
    {
        //
        // Disasemble & Code
        // 0x00B19B74: LDR x0, [x0, #0x40]        | X0 = this.httpDownLoad; //P2            
        // 0x00B19B78: CBZ x0, #0xb19b84          | if (this.httpDownLoad == null) goto label_0;
        if(this.httpDownLoad == null)
        {
            goto label_0;
        }
        // 0x00B19B7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19B80: B #0x28a33ec               | return this.httpDownLoad.get_progress();
        return this.httpDownLoad.progress;
        label_0:
        // 0x00B19B84: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B19B88: RET                        |  return (System.Single)0;               
        return (float)0f;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19B8C (11639692), len: 8  VirtAddr: 0x00B19B8C RVA: 0x00B19B8C token: 100694282 methodIndex: 24625 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_isVerifyed()
    {
        //
        // Disasemble & Code
        // 0x00B19B8C: LDRB w0, [x0, #0xaa]       | W0 = this.<isVerifyed>k__BackingField; //P2 
        // 0x00B19B90: RET                        |  return (System.Boolean)this.<isVerifyed>k__BackingField;
        return this.<isVerifyed>k__BackingField;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14F54 (11620180), len: 12  VirtAddr: 0x00B14F54 RVA: 0x00B14F54 token: 100694283 methodIndex: 24626 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_isVerifyed(bool value)
    {
        //
        // Disasemble & Code
        // 0x00B14F54: AND w8, w1, #1             | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00B14F58: STRB w8, [x0, #0xaa]       | this.<isVerifyed>k__BackingField = (value & 1);  //  dest_result_addr=1152921515146937450
        this.<isVerifyed>k__BackingField = val_1;
        // 0x00B14F5C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19B94 (11639700), len: 8  VirtAddr: 0x00B19B94 RVA: 0x00B19B94 token: 100694284 methodIndex: 24627 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_VerifyProgress()
    {
        //
        // Disasemble & Code
        // 0x00B19B94: LDR s0, [x0, #0xac]        | S0 = this.<VerifyProgress>k__BackingField; //P2 
        // 0x00B19B98: RET                        |  return (System.Single)this.<VerifyProgress>k__BackingField;
        return this.<VerifyProgress>k__BackingField;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14F78 (11620216), len: 8  VirtAddr: 0x00B14F78 RVA: 0x00B14F78 token: 100694285 methodIndex: 24628 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_VerifyProgress(float value)
    {
        //
        // Disasemble & Code
        // 0x00B14F78: STR s0, [x0, #0xac]        | this.<VerifyProgress>k__BackingField = value;  //  dest_result_addr=1152921515147161452
        this.<VerifyProgress>k__BackingField = value;
        // 0x00B14F7C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19B9C (11639708), len: 8  VirtAddr: 0x00B19B9C RVA: 0x00B19B9C token: 100694286 methodIndex: 24629 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_isStartDown()
    {
        //
        // Disasemble & Code
        // 0x00B19B9C: LDRB w0, [x0, #0xb0]       | W0 = this.<isStartDown>k__BackingField; //P2 
        // 0x00B19BA0: RET                        |  return (System.Boolean)this.<isStartDown>k__BackingField;
        return this.<isStartDown>k__BackingField;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14F60 (11620192), len: 12  VirtAddr: 0x00B14F60 RVA: 0x00B14F60 token: 100694287 methodIndex: 24630 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_isStartDown(bool value)
    {
        //
        // Disasemble & Code
        // 0x00B14F60: AND w8, w1, #1             | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00B14F64: STRB w8, [x0, #0xb0]       | this.<isStartDown>k__BackingField = (value & 1);  //  dest_result_addr=1152921515147385456
        this.<isStartDown>k__BackingField = val_1;
        // 0x00B14F68: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19BA4 (11639716), len: 80  VirtAddr: 0x00B19BA4 RVA: 0x00B19BA4 token: 100694288 methodIndex: 24631 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_Progress()
    {
        //
        // Disasemble & Code
        // 0x00B19BA4: STP x20, x19, [sp, #-0x20]! | stack[1152921515147489344] = ???;  stack[1152921515147489352] = ???;  //  dest_result_addr=1152921515147489344 |  dest_result_addr=1152921515147489352
        // 0x00B19BA8: STP x29, x30, [sp, #0x10]  | stack[1152921515147489360] = ???;  stack[1152921515147489368] = ???;  //  dest_result_addr=1152921515147489360 |  dest_result_addr=1152921515147489368
        // 0x00B19BAC: ADD x29, sp, #0x10         | X29 = (1152921515147489344 + 16) = 1152921515147489360 (0x1000000274457050);
        // 0x00B19BB0: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_1 = AssetDownMgr.Instance;
        // 0x00B19BB4: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B19BB8: CBNZ x19, #0xb19bc0        | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x00B19BBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x00B19BC0: LDR x8, [x19, #0x50]       | X8 = val_1.totalBytes; //P2             
        // 0x00B19BC4: CBZ w8, #0xb19be4          | if (val_1.totalBytes == 0) goto label_1;
        if(val_1.totalBytes == 0)
        {
            goto label_1;
        }
        // 0x00B19BC8: LSR x9, x8, #0x20          | X9 = (val_1.totalBytes >> 32);          
        uint val_2 = val_1.totalBytes >> 32;
        // 0x00B19BCC: UCVTF d0, w8               | D0 = (double)(val_1.totalBytes);        
        // 0x00B19BD0: UCVTF d1, w9               | D1 = (double)((val_1.totalBytes >> 32));
        // 0x00B19BD4: FCVT s1, d1                | S1 = (float)(val_1.totalBytes >> 32));  
        // 0x00B19BD8: FCVT s0, d0                | S0 = (float)val_1.totalBytes);          
        float val_3 = (float)(double)val_1.totalBytes;
        // 0x00B19BDC: FDIV s0, s1, s0            | S0 = ((val_1.totalBytes >> 32) / val_1.totalBytes);
        val_3 = (float)(double)val_2 / val_3;
        // 0x00B19BE0: B #0xb19be8                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00B19BE4: FMOV s0, wzr               | S0 = 0f;                                
        label_2:
        // 0x00B19BE8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19BEC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B19BF0: RET                        |  return (System.Single)0;               
        return (float)0f;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19C20 (11639840), len: 44  VirtAddr: 0x00B19C20 RVA: 0x00B19C20 token: 100694289 methodIndex: 24632 delegateWrapperIndex: 0 methodInvoker: 0
    public string get_ProgressMsg()
    {
        //
        // Disasemble & Code
        // 0x00B19C20: STP x20, x19, [sp, #-0x20]! | stack[1152921515147609536] = ???;  stack[1152921515147609544] = ???;  //  dest_result_addr=1152921515147609536 |  dest_result_addr=1152921515147609544
        // 0x00B19C24: STP x29, x30, [sp, #0x10]  | stack[1152921515147609552] = ???;  stack[1152921515147609560] = ???;  //  dest_result_addr=1152921515147609552 |  dest_result_addr=1152921515147609560
        // 0x00B19C28: ADD x29, sp, #0x10         | X29 = (1152921515147609536 + 16) = 1152921515147609552 (0x10000002744745D0);
        // 0x00B19C2C: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_1 = AssetDownMgr.Instance;
        // 0x00B19C30: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B19C34: CBNZ x19, #0xb19c3c        | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x00B19C38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x00B19C3C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19C40: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B19C44: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B19C48: B #0xb19c4c                | return val_1.get_ProgressMsg();         
        return val_1.ProgressMsg;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19D24 (11640100), len: 144  VirtAddr: 0x00B19D24 RVA: 0x00B19D24 token: 100694290 methodIndex: 24633 delegateWrapperIndex: 0 methodInvoker: 0
    public void IsOpenRepairAsset(CEvent.ZEvent e)
    {
        //
        // Disasemble & Code
        // 0x00B19D24: STP x20, x19, [sp, #-0x20]! | stack[1152921515147729728] = ???;  stack[1152921515147729736] = ???;  //  dest_result_addr=1152921515147729728 |  dest_result_addr=1152921515147729736
        // 0x00B19D28: STP x29, x30, [sp, #0x10]  | stack[1152921515147729744] = ???;  stack[1152921515147729752] = ???;  //  dest_result_addr=1152921515147729744 |  dest_result_addr=1152921515147729752
        // 0x00B19D2C: ADD x29, sp, #0x10         | X29 = (1152921515147729728 + 16) = 1152921515147729744 (0x1000000274491B50);
        // 0x00B19D30: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B19D34: LDRB w8, [x19, #0x6ec]     | W8 = (bool)static_value_037336EC;       
        // 0x00B19D38: TBNZ w8, #0, #0xb19d54     | if (static_value_037336EC == true) goto label_0;
        // 0x00B19D3C: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00B19D40: LDR x8, [x8, #0x130]       | X8 = 0x2B8A6C0;                         
        // 0x00B19D44: LDR w0, [x8]               | W0 = 0x6E;                              
        // 0x00B19D48: BL #0x2782188              | X0 = sub_2782188( ?? 0x6E, ????);       
        // 0x00B19D4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B19D50: STRB w8, [x19, #0x6ec]     | static_value_037336EC = true;            //  dest_result_addr=57882348
        label_0:
        // 0x00B19D54: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B19D58: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00B19D5C: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
        CEvent.ZEvent val_1 = null;
        // 0x00B19D60: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00B19D64: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
        // 0x00B19D68: LDR x8, [x8, #0x4d0]       | X8 = (string**)(1152921510024642032)("IF_OPEN_REPAIR_ASSET_BACK");
        // 0x00B19D6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19D70: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B19D74: LDR x1, [x8]               | X1 = "IF_OPEN_REPAIR_ASSET_BACK";       
        // 0x00B19D78: BL #0xd80ce8               | .ctor(name:  "IF_OPEN_REPAIR_ASSET_BACK");
        val_1 = new CEvent.ZEvent(name:  "IF_OPEN_REPAIR_ASSET_BACK");
        // 0x00B19D7C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B19D80: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B19D84: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B19D88: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B19D8C: TBZ w8, #0, #0xb19d9c      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B19D90: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B19D94: CBNZ w8, #0xb19d9c         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B19D98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00B19D9C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19DA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19DA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19DA8: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B19DAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B19DB0: B #0xd7de90                | CEvent.ZEventCenter.DispatchEvent(ev:  0); return;
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19DB4 (11640244), len: 608  VirtAddr: 0x00B19DB4 RVA: 0x00B19DB4 token: 100694291 methodIndex: 24634 delegateWrapperIndex: 0 methodInvoker: 0
    public void RepairAsset(CEvent.ZEvent e)
    {
        //
        // Disasemble & Code
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        string val_13;
        // 0x00B19DB4: STP x24, x23, [sp, #-0x40]! | stack[1152921515147895968] = ???;  stack[1152921515147895976] = ???;  //  dest_result_addr=1152921515147895968 |  dest_result_addr=1152921515147895976
        // 0x00B19DB8: STP x22, x21, [sp, #0x10]  | stack[1152921515147895984] = ???;  stack[1152921515147895992] = ???;  //  dest_result_addr=1152921515147895984 |  dest_result_addr=1152921515147895992
        // 0x00B19DBC: STP x20, x19, [sp, #0x20]  | stack[1152921515147896000] = ???;  stack[1152921515147896008] = ???;  //  dest_result_addr=1152921515147896000 |  dest_result_addr=1152921515147896008
        // 0x00B19DC0: STP x29, x30, [sp, #0x30]  | stack[1152921515147896016] = ???;  stack[1152921515147896024] = ???;  //  dest_result_addr=1152921515147896016 |  dest_result_addr=1152921515147896024
        // 0x00B19DC4: ADD x29, sp, #0x30         | X29 = (1152921515147895968 + 48) = 1152921515147896016 (0x10000002744BA4D0);
        // 0x00B19DC8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B19DCC: LDRB w8, [x20, #0x6ed]     | W8 = (bool)static_value_037336ED;       
        // 0x00B19DD0: MOV x19, x0                | X19 = 1152921515147908032 (0x10000002744BD3C0);//ML01
        // 0x00B19DD4: TBNZ w8, #0, #0xb19df0     | if (static_value_037336ED == true) goto label_0;
        // 0x00B19DD8: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00B19DDC: LDR x8, [x8, #0x6c0]       | X8 = 0x2B8A6E4;                         
        // 0x00B19DE0: LDR w0, [x8]               | W0 = 0x77;                              
        // 0x00B19DE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x77, ????);       
        // 0x00B19DE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B19DEC: STRB w8, [x20, #0x6ed]     | static_value_037336ED = true;            //  dest_result_addr=57882349
        label_0:
        // 0x00B19DF0: LDRB w8, [x19, #0xb1]      | W8 = this.isRepairing; //P2             
        // 0x00B19DF4: STUR xzr, [x19, #0xb4]     | this.localAssetCount = 0; this.errorAssetCount = 0;  //  dest_result_addr=1152921515147908212 dest_result_addr=1152921515147908216
        this.localAssetCount = 0;
        this.errorAssetCount = 0;
        // 0x00B19DF8: CBZ w8, #0xb19e10          | if (this.isRepairing == false) goto label_1;
        if(this.isRepairing == false)
        {
            goto label_1;
        }
        // 0x00B19DFC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19E00: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B19E04: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B19E08: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B19E0C: RET                        |  return;                                
        return;
        label_1:
        // 0x00B19E10: LDR x20, [x19, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B19E14: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B19E18: STRB w8, [x19, #0xb1]      | this.isRepairing = true;                 //  dest_result_addr=1152921515147908209
        this.isRepairing = true;
        // 0x00B19E1C: CBNZ x20, #0xb19e24        | if (this.sb != null) goto label_2;      
        if(this.sb != null)
        {
            goto label_2;
        }
        // 0x00B19E20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x77, ????);       
        label_2:
        // 0x00B19E24: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B19E28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19E2C: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B19E30: BL #0x1b5ac0c              | this.sb.set_Length(value:  0);          
        this.sb.Length = 0;
        // 0x00B19E34: ADRP x21, #0x35ef000       | X21 = 56553472 (0x35EF000);             
        // 0x00B19E38: LDR x21, [x21, #0xde8]     | X21 = 1152921504911265792;              
        // 0x00B19E3C: LDR x20, [x19, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B19E40: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
        val_11 = null;
        // 0x00B19E44: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B19E48: TBZ w8, #0, #0xb19e5c      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B19E4C: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B19E50: CBNZ w8, #0xb19e5c         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B19E54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B19E58: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
        val_11 = null;
        label_4:
        // 0x00B19E5C: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B19E60: LDR x21, [x8, #0x70]       | X21 = Loader.PathUtil.SERVER_URL;       
        // 0x00B19E64: CBNZ x20, #0xb19e6c        | if (this.sb != null) goto label_5;      
        if(this.sb != null)
        {
            goto label_5;
        }
        // 0x00B19E68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
        label_5:
        // 0x00B19E6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19E70: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B19E74: MOV x1, x21                | X1 = Loader.PathUtil.SERVER_URL;//m1    
        // 0x00B19E78: BL #0x1b5b818              | X0 = this.sb.Append(value:  Loader.PathUtil.SERVER_URL);
        System.Text.StringBuilder val_1 = this.sb.Append(value:  Loader.PathUtil.SERVER_URL);
        // 0x00B19E7C: ADRP x22, #0x363a000       | X22 = 56860672 (0x363A000);             
        // 0x00B19E80: LDR x22, [x22, #0x420]     | X22 = 1152921504911425536;              
        // 0x00B19E84: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B19E88: LDR x8, [x22]              | X8 = typeof(VersionMgr);                
        // 0x00B19E8C: LDRB w9, [x8, #0x10a]      | W9 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B19E90: TBZ w9, #0, #0xb19ea4      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B19E94: LDR w9, [x8, #0xbc]        | W9 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B19E98: CBNZ w9, #0xb19ea4         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B19E9C: MOV x0, x8                 | X0 = 1152921504911425536 (0x1000000012278000);//ML01
        // 0x00B19EA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_7:
        // 0x00B19EA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19EA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19EAC: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_2 = VersionMgr.Instance;
        // 0x00B19EB0: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00B19EB4: CBNZ x21, #0xb19ebc        | if (val_2 != null) goto label_8;        
        if(val_2 != null)
        {
            goto label_8;
        }
        // 0x00B19EB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00B19EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19EC0: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00B19EC4: BL #0xe27dac               | X0 = val_2.get_currentVS();             
        VersionInfo val_3 = val_2.currentVS;
        // 0x00B19EC8: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B19ECC: CBNZ x21, #0xb19ed4        | if (val_3 != null) goto label_9;        
        if(val_3 != null)
        {
            goto label_9;
        }
        // 0x00B19ED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00B19ED4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B19ED8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B19EDC: LDR x21, [x21, #0xd0]      | X21 = val_3.vscfg; //P2                 
        // 0x00B19EE0: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B19EE4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B19EE8: TBZ w8, #0, #0xb19ef8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B19EEC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B19EF0: CBNZ w8, #0xb19ef8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B19EF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_11:
        // 0x00B19EF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19EFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19F00: MOV x1, x21                | X1 = val_3.vscfg;//m1                   
        // 0x00B19F04: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_4 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B19F08: TST w0, #1                 | STATE = COMPARE(val_4, 0x1)             
        // 0x00B19F0C: CSEL x21, xzr, x20, ne     | X21 = val_4 != true ? 0 : val_1;        
        var val_5 = (val_4 != true) ? 0 : (val_1);
        // 0x00B19F10: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        bool val_6 = val_4;
        // 0x00B19F14: TBZ w8, #0, #0xb19f28      | if ((val_4 & 1) == false) goto label_12;
        if(val_6 == false)
        {
            goto label_12;
        }
        // 0x00B19F18: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B19F1C: LDR x8, [x8, #0x8b8]       | X8 = (string**)(1152921510473621280)("vsconfig.uab");
        val_13 = "vsconfig.uab";
        // 0x00B19F20: MOV x21, x20               | X21 = val_1;//m1                        
        val_12 = val_1;
        // 0x00B19F24: B #0xb19f74                |  goto label_13;                         
        goto label_13;
        label_12:
        // 0x00B19F28: LDR x0, [x22]              | X0 = typeof(VersionMgr);                
        // 0x00B19F2C: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B19F30: TBZ w8, #0, #0xb19f40      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00B19F34: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B19F38: CBNZ w8, #0xb19f40         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00B19F3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_15:
        // 0x00B19F40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19F44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19F48: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_7 = VersionMgr.Instance;
        // 0x00B19F4C: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B19F50: CBNZ x20, #0xb19f58        | if (val_7 != null) goto label_16;       
        if(val_7 != null)
        {
            goto label_16;
        }
        // 0x00B19F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_16:
        // 0x00B19F58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19F5C: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00B19F60: BL #0xe27dac               | X0 = val_7.get_currentVS();             
        VersionInfo val_8 = val_7.currentVS;
        // 0x00B19F64: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B19F68: CBNZ x20, #0xb19f70        | if (val_8 != null) goto label_17;       
        if(val_8 != null)
        {
            goto label_17;
        }
        // 0x00B19F6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_17:
        // 0x00B19F70: ADD x8, x20, #0xd0         | X8 = val_8.vscfg;//AP2 res_addr=207     
        val_13 = val_8.vscfg;
        label_13:
        // 0x00B19F74: LDR x20, [x8]              |  //  not_find_field!1:0
        // 0x00B19F78: CBNZ x21, #0xb19f80        | if (val_4 != true ? 0 : val_1 != 0) goto label_18;
        if(val_5 != 0)
        {
            goto label_18;
        }
        // 0x00B19F7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_18:
        // 0x00B19F80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19F84: MOV x0, x21                | X0 = val_4 != true ? 0 : val_1;//m1     
        // 0x00B19F88: MOV x1, x20                | X1 = mem[val_8.vscfg];//m1              
        // 0x00B19F8C: BL #0x1b5b818              | X0 = val_4 != true ? 0 : val_1.Append(value:  mem[val_8.vscfg]);
        System.Text.StringBuilder val_9 = val_5.Append(value:  mem[val_8.vscfg]);
        // 0x00B19F90: LDR x20, [x19, #0x70]      | X20 = this.sb; //P2                     
        // 0x00B19F94: CBNZ x20, #0xb19f9c        | if (this.sb != null) goto label_19;     
        if(this.sb != null)
        {
            goto label_19;
        }
        // 0x00B19F98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_19:
        // 0x00B19F9C: LDR x8, [x20]              | X8 = typeof(System.Text.StringBuilder); 
        // 0x00B19FA0: MOV x0, x20                | X0 = this.sb;//m1                       
        // 0x00B19FA4: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
        // 0x00B19FA8: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
        // 0x00B19FAC: MOV x20, x0                | X20 = this.sb;//m1                      
        // 0x00B19FB0: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_10 = AssetDownMgr.Instance;
        // 0x00B19FB4: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
        // 0x00B19FB8: ADRP x9, #0x361c000        | X9 = 56737792 (0x361C000);              
        // 0x00B19FBC: LDR x8, [x8, #0x140]       | X8 = 1152921515147883008;               
        // 0x00B19FC0: LDR x9, [x9, #0x610]       | X9 = 1152921504910786560;               
        // 0x00B19FC4: MOV x21, x0                | X21 = val_10;//m1                       
        // 0x00B19FC8: LDR x23, [x8]              | X23 = System.Void ABCheckUpdate::<RepairAsset>m__B(string name, byte[] abBytes);
        // 0x00B19FCC: LDR x8, [x9]               | X8 = typeof(AssetDownMgr.SetBytes);     
        // 0x00B19FD0: MOV x0, x8                 | X0 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B19FD4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetDownMgr.SetBytes), ????);
        // 0x00B19FD8: LDR x8, [x23]              | X8 = System.Void ABCheckUpdate::<RepairAsset>m__B(string name, byte[] abBytes);
        // 0x00B19FDC: MOV x22, x0                | X22 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B19FE0: STP x19, x23, [x22, #0x20] | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;  typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<RepairAsset>m__B(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786592 |  dest_result_addr=1152921504910786600
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<RepairAsset>m__B(string name, byte[] abBytes);
        // 0x00B19FE4: STR x8, [x22, #0x10]       | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<RepairAsset>m__B(string name, byte[] abBytes);  //  dest_result_addr=1152921504910786576
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<RepairAsset>m__B(string name, byte[] abBytes);
        // 0x00B19FE8: CBNZ x21, #0xb19ff0        | if (val_10 != null) goto label_20;      
        if(val_10 != null)
        {
            goto label_20;
        }
        // 0x00B19FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AssetDownMgr.SetBytes), ????);
        label_20:
        // 0x00B19FF0: MOV x0, x21                | X0 = val_10;//m1                        
        // 0x00B19FF4: MOV x1, x20                | X1 = this.sb;//m1                       
        // 0x00B19FF8: MOV x2, x22                | X2 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B19FFC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1A000: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1A004: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1A008: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B1A00C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B1A010: B #0xb15ab0                | val_10.AddUpdateData(path:  this.sb, downFinishCall:  null, isInsert:  false); return;
        val_10.AddUpdateData(path:  this.sb, downFinishCall:  null, isInsert:  false);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1A014 (11640852), len: 656  VirtAddr: 0x00B1A014 RVA: 0x00B1A014 token: 100694292 methodIndex: 24635 delegateWrapperIndex: 0 methodInvoker: 0
    private void RepairAssetShowDialog()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        System.Action val_5;
        // 0x00B1A014: STP x26, x25, [sp, #-0x50]! | stack[1152921515148074896] = ???;  stack[1152921515148074904] = ???;  //  dest_result_addr=1152921515148074896 |  dest_result_addr=1152921515148074904
        // 0x00B1A018: STP x24, x23, [sp, #0x10]  | stack[1152921515148074912] = ???;  stack[1152921515148074920] = ???;  //  dest_result_addr=1152921515148074912 |  dest_result_addr=1152921515148074920
        // 0x00B1A01C: STP x22, x21, [sp, #0x20]  | stack[1152921515148074928] = ???;  stack[1152921515148074936] = ???;  //  dest_result_addr=1152921515148074928 |  dest_result_addr=1152921515148074936
        // 0x00B1A020: STP x20, x19, [sp, #0x30]  | stack[1152921515148074944] = ???;  stack[1152921515148074952] = ???;  //  dest_result_addr=1152921515148074944 |  dest_result_addr=1152921515148074952
        // 0x00B1A024: STP x29, x30, [sp, #0x40]  | stack[1152921515148074960] = ???;  stack[1152921515148074968] = ???;  //  dest_result_addr=1152921515148074960 |  dest_result_addr=1152921515148074968
        // 0x00B1A028: ADD x29, sp, #0x40         | X29 = (1152921515148074896 + 64) = 1152921515148074960 (0x10000002744E5FD0);
        // 0x00B1A02C: SUB sp, sp, #0x10          | SP = (1152921515148074896 - 16) = 1152921515148074880 (0x10000002744E5F80);
        // 0x00B1A030: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B1A034: LDRB w8, [x19, #0x6ee]     | W8 = (bool)static_value_037336EE;       
        // 0x00B1A038: MOV x20, x0                | X20 = 1152921515148086976 (0x10000002744E8EC0);//ML01
        // 0x00B1A03C: TBNZ w8, #0, #0xb1a058     | if (static_value_037336EE == true) goto label_0;
        // 0x00B1A040: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
        // 0x00B1A044: LDR x8, [x8, #0xb00]       | X8 = 0x2B8A6E8;                         
        // 0x00B1A048: LDR w0, [x8]               | W0 = 0x78;                              
        // 0x00B1A04C: BL #0x2782188              | X0 = sub_2782188( ?? 0x78, ????);       
        // 0x00B1A050: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1A054: STRB w8, [x19, #0x6ee]     | static_value_037336EE = true;            //  dest_result_addr=57882350
        label_0:
        // 0x00B1A058: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B1A05C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B1A060: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
        // 0x00B1A064: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B1A068: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B1A06C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B1A070: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B1A074: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B1A078: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x00B1A07C: LDR w9, [x20, #0xb4]       | W9 = this.localAssetCount; //P2         
        // 0x00B1A080: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
        // 0x00B1A084: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B1A088: ADD x1, sp, #0xc           | X1 = (1152921515148074880 + 12) = 1152921515148074892 (0x10000002744E5F8C);
        // 0x00B1A08C: STR w9, [sp, #0xc]         | stack[1152921515148074892] = this.localAssetCount;  //  dest_result_addr=1152921515148074892
        // 0x00B1A090: LDR x8, [x22]              | X8 = typeof(System.Int32);              
        // 0x00B1A094: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00B1A098: BL #0x27bc028              | X0 = 1152921515148118976 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.localAssetCount);
        // 0x00B1A09C: MOV x21, x0                | X21 = 1152921515148118976 (0x10000002744F0BC0);//ML01
        // 0x00B1A0A0: CBNZ x19, #0xb1a0a8        | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x00B1A0A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.localAssetCount, ????);
        label_1:
        // 0x00B1A0A8: CBZ x21, #0xb1a0cc         | if (this.localAssetCount == 0) goto label_3;
        if(this.localAssetCount == 0)
        {
            goto label_3;
        }
        // 0x00B1A0AC: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B1A0B0: MOV x0, x21                | X0 = 1152921515148118976 (0x10000002744F0BC0);//ML01
        // 0x00B1A0B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B1A0B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.localAssetCount, ????);
        // 0x00B1A0BC: CBNZ x0, #0xb1a0cc         | if (this.localAssetCount != 0) goto label_3;
        if(this.localAssetCount != 0)
        {
            goto label_3;
        }
        // 0x00B1A0C0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.localAssetCount, ????);
        // 0x00B1A0C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A0C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.localAssetCount, ????);
        label_3:
        // 0x00B1A0CC: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B1A0D0: CBNZ w8, #0xb1a0e0         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_4;
        // 0x00B1A0D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.localAssetCount, ????);
        // 0x00B1A0D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A0DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.localAssetCount, ????);
        label_4:
        // 0x00B1A0E0: STR x21, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = this.localAssetCount; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = this.localAssetCount;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00B1A0E4: LDR w8, [x20, #0xb8]       | W8 = this.errorAssetCount; //P2         
        // 0x00B1A0E8: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00B1A0EC: ADD x1, sp, #8             | X1 = (1152921515148074880 + 8) = 1152921515148074888 (0x10000002744E5F88);
        // 0x00B1A0F0: STR w8, [sp, #8]           | stack[1152921515148074888] = this.errorAssetCount;  //  dest_result_addr=1152921515148074888
        // 0x00B1A0F4: BL #0x27bc028              | X0 = 1152921515148123072 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.errorAssetCount);
        // 0x00B1A0F8: MOV x20, x0                | X20 = 1152921515148123072 (0x10000002744F1BC0);//ML01
        // 0x00B1A0FC: CBZ x20, #0xb1a120         | if (this.errorAssetCount == 0) goto label_6;
        if(this.errorAssetCount == 0)
        {
            goto label_6;
        }
        // 0x00B1A100: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B1A104: MOV x0, x20                | X0 = 1152921515148123072 (0x10000002744F1BC0);//ML01
        // 0x00B1A108: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B1A10C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.errorAssetCount, ????);
        // 0x00B1A110: CBNZ x0, #0xb1a120         | if (this.errorAssetCount != 0) goto label_6;
        if(this.errorAssetCount != 0)
        {
            goto label_6;
        }
        // 0x00B1A114: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.errorAssetCount, ????);
        // 0x00B1A118: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A11C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.errorAssetCount, ????);
        label_6:
        // 0x00B1A120: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B1A124: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B1A128: B.HI #0xb1a138             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_7;
        // 0x00B1A12C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.errorAssetCount, ????);
        // 0x00B1A130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A134: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.errorAssetCount, ????);
        label_7:
        // 0x00B1A138: STR x20, [x19, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = this.errorAssetCount; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
        typeof(System.Object[]).__il2cppRuntimeField_28 = this.errorAssetCount;
        typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
        // 0x00B1A13C: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00B1A140: LDR x8, [x8, #0x4d8]       | X8 = (string**)(1152921515148053376)("缓存资源个数{0}，问题资源个数{1}");
        // 0x00B1A144: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A148: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1A14C: MOV x2, x19                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B1A150: LDR x1, [x8]               | X1 = "缓存资源个数{0}，问题资源个数{1}";             
        // 0x00B1A154: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "缓存资源个数{0}，问题资源个数{1}");
        string val_1 = EString.EFormat(format:  0, args:  "缓存资源个数{0}，问题资源个数{1}");
        // 0x00B1A158: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B1A15C: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B1A160: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B1A164: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B1A168: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B1A16C: TBZ w9, #0, #0xb1a180      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00B1A170: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A174: CBNZ w9, #0xb1a180         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00B1A178: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B1A17C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_9:
        // 0x00B1A180: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A184: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1A188: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1A18C: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00B1A190: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_1);
        EDebug.Log(message:  0, isShowStack:  val_1);
        // 0x00B1A194: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A198: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A19C: BL #0x138e268              | X0 = PluginsSdkMgr.get_Instance();      
        PluginsSdkMgr val_2 = PluginsSdkMgr.Instance;
        // 0x00B1A1A0: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x00B1A1A4: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x00B1A1A8: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B1A1AC: LDR x8, [x20]              | X8 = typeof(System.String);             
        val_4 = null;
        // 0x00B1A1B0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1A1B4: TBZ w9, #0, #0xb1a1cc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B1A1B8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A1BC: CBNZ w9, #0xb1a1cc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B1A1C0: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B1A1C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B1A1C8: LDR x8, [x20]              | X8 = typeof(System.String);             
        val_4 = null;
        label_11:
        // 0x00B1A1CC: ADRP x26, #0x365c000       | X26 = 56999936 (0x365C000);             
        // 0x00B1A1D0: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B1A1D4: LDR x26, [x26, #0xd68]     | X26 = 1152921504910680064;              
        // 0x00B1A1D8: ADRP x10, #0x35e1000       | X10 = 56496128 (0x35E1000);             
        // 0x00B1A1DC: ADRP x11, #0x35d7000       | X11 = 56455168 (0x35D7000);             
        // 0x00B1A1E0: ADRP x12, #0x3648000       | X12 = 56918016 (0x3648000);             
        // 0x00B1A1E4: LDR x9, [x26]              | X9 = typeof(ABCheckUpdate);             
        // 0x00B1A1E8: LDR x10, [x10, #0x4d8]     | X10 = (string**)(1152921514955921760)("Confirm");
        // 0x00B1A1EC: LDR x11, [x11, #0x720]     | X11 = (string**)(1152921515148061680)("Client repairing completed, please restart the game");
        // 0x00B1A1F0: LDR x12, [x12, #0x948]     | X12 = (string**)(1152921515148061856)("Check Complete");
        // 0x00B1A1F4: LDR x9, [x9, #0xa0]        | X9 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1A1F8: LDR x21, [x10]             | X21 = "Confirm";                        
        // 0x00B1A1FC: LDR x22, [x11]             | X22 = "Client repairing completed, please restart the game";
        // 0x00B1A200: LDR x20, [x8]              | X20 = System.String.Empty;              
        // 0x00B1A204: LDR x24, [x9, #0x28]       | X24 = ABCheckUpdate.<>f__am$cache4;     
        val_5 = ABCheckUpdate.<>f__am$cache4;
        // 0x00B1A208: LDR x23, [x12]             | X23 = "Check Complete";                 
        // 0x00B1A20C: CBNZ x24, #0xb1a258        | if (ABCheckUpdate.<>f__am$cache4 != null) goto label_12;
        if(val_5 != null)
        {
            goto label_12;
        }
        // 0x00B1A210: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B1A214: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B1A218: LDR x8, [x8, #0x458]       | X8 = 1152921515148061952;               
        // 0x00B1A21C: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B1A220: LDR x24, [x8]              | X24 = static System.Void ABCheckUpdate::<RepairAssetShowDialog>m__C();
        // 0x00B1A224: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_3 = null;
        // 0x00B1A228: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B1A22C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A230: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1A234: MOV x2, x24                | X2 = 1152921515148061952 (0x10000002744E2D00);//ML01
        // 0x00B1A238: MOV x25, x0                | X25 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1A23C: BL #0x26e30f0              | .ctor(object:  0, method:  static System.Void ABCheckUpdate::<RepairAssetShowDialog>m__C());
        val_3 = new System.Action(object:  0, method:  static System.Void ABCheckUpdate::<RepairAssetShowDialog>m__C());
        // 0x00B1A240: LDR x8, [x26]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B1A244: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1A248: STR x25, [x8, #0x28]       | ABCheckUpdate.<>f__am$cache4 = typeof(System.Action);  //  dest_result_addr=1152921504910684200
        ABCheckUpdate.<>f__am$cache4 = val_3;
        // 0x00B1A24C: LDR x8, [x26]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B1A250: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1A254: LDR x24, [x8, #0x28]       | X24 = typeof(System.Action);            
        val_5 = ABCheckUpdate.<>f__am$cache4;
        label_12:
        // 0x00B1A258: CBNZ x19, #0xb1a260        | if (val_2 != null) goto label_13;       
        if(val_2 != null)
        {
            goto label_13;
        }
        // 0x00B1A25C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ABCheckUpdate::<RepairAssetShowDialog>m__C()), ????);
        label_13:
        // 0x00B1A260: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B1A264: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00B1A268: MOV x1, x23                | X1 = 1152921515148061856 (0x10000002744E2CA0);//ML01
        // 0x00B1A26C: MOV x2, x22                | X2 = 1152921515148061680 (0x10000002744E2BF0);//ML01
        // 0x00B1A270: MOV x4, x21                | X4 = 1152921514955921760 (0x1000000268DA5960);//ML01
        // 0x00B1A274: MOV x5, x20                | X5 = System.String.Empty;//m1           
        // 0x00B1A278: MOV x6, x24                | X6 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1A27C: MOV x7, xzr                | X7 = 0 (0x0);//ML01                     
        // 0x00B1A280: STR xzr, [sp]              | stack[1152921515148074880] = 0x0;        //  dest_result_addr=1152921515148074880
        // 0x00B1A284: BL #0x13a69fc              | val_2.ShowDialog(title:  "Check Complete", content:  "Client repairing completed, please restart the game", cancelable:  false, okText:  "Confirm", cancelText:  System.String.Empty, OnOK:  val_5, OnCancel:  0);
        val_2.ShowDialog(title:  "Check Complete", content:  "Client repairing completed, please restart the game", cancelable:  false, okText:  "Confirm", cancelText:  System.String.Empty, OnOK:  val_5, OnCancel:  0);
        // 0x00B1A288: SUB sp, x29, #0x40         | SP = (1152921515148074960 - 64) = 1152921515148074896 (0x10000002744E5F90);
        // 0x00B1A28C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1A290: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1A294: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1A298: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1A29C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B1A2A0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1A2A4 (11641508), len: 528  VirtAddr: 0x00B1A2A4 RVA: 0x00B1A2A4 token: 100694293 methodIndex: 24636 delegateWrapperIndex: 0 methodInvoker: 0
    private bool LocalVerifyMD5(string fullPath, string md5)
    {
        //
        // Disasemble & Code
        //  | 
        string val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        // 0x00B1A2A4: STP x22, x21, [sp, #-0x30]! | stack[1152921515148293424] = ???;  stack[1152921515148293432] = ???;  //  dest_result_addr=1152921515148293424 |  dest_result_addr=1152921515148293432
        // 0x00B1A2A8: STP x20, x19, [sp, #0x10]  | stack[1152921515148293440] = ???;  stack[1152921515148293448] = ???;  //  dest_result_addr=1152921515148293440 |  dest_result_addr=1152921515148293448
        // 0x00B1A2AC: STP x29, x30, [sp, #0x20]  | stack[1152921515148293456] = ???;  stack[1152921515148293464] = ???;  //  dest_result_addr=1152921515148293456 |  dest_result_addr=1152921515148293464
        // 0x00B1A2B0: ADD x29, sp, #0x20         | X29 = (1152921515148293424 + 32) = 1152921515148293456 (0x100000027451B550);
        // 0x00B1A2B4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1A2B8: LDRB w8, [x21, #0x6ef]     | W8 = (bool)static_value_037336EF;       
        // 0x00B1A2BC: MOV x19, x2                | X19 = md5;//m1                          
        // 0x00B1A2C0: MOV x20, x1                | X20 = fullPath;//m1                     
        // 0x00B1A2C4: TBNZ w8, #0, #0xb1a2e0     | if (static_value_037336EF == true) goto label_0;
        // 0x00B1A2C8: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
        // 0x00B1A2CC: LDR x8, [x8, #0xc80]       | X8 = 0x2B8A6DC;                         
        // 0x00B1A2D0: LDR w0, [x8]               | W0 = 0x75;                              
        // 0x00B1A2D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x75, ????);       
        // 0x00B1A2D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1A2DC: STRB w8, [x21, #0x6ef]     | static_value_037336EF = true;            //  dest_result_addr=57882351
        label_0:
        // 0x00B1A2E0: CBNZ x20, #0xb1a2e8        | if (fullPath != null) goto label_1;     
        if(fullPath != null)
        {
            goto label_1;
        }
        // 0x00B1A2E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x75, ????);       
        label_1:
        // 0x00B1A2E8: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00B1A2EC: LDR x8, [x8, #0xde8]       | X8 = (string**)(1152921509978841008)("javascript.uab");
        // 0x00B1A2F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A2F4: MOV x0, x20                | X0 = fullPath;//m1                      
        // 0x00B1A2F8: LDR x1, [x8]               | X1 = "javascript.uab";                  
        // 0x00B1A2FC: BL #0x18ab0a0              | X0 = fullPath.EndsWith(value:  "javascript.uab");
        bool val_1 = fullPath.EndsWith(value:  "javascript.uab");
        // 0x00B1A300: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B1A304: TBNZ w8, #0, #0xb1a3c0     | if ((val_1 & 1) == true) goto label_6;  
        if(val_2 == true)
        {
            goto label_6;
        }
        // 0x00B1A308: CBNZ x20, #0xb1a310        | if (fullPath != null) goto label_3;     
        if(fullPath != null)
        {
            goto label_3;
        }
        // 0x00B1A30C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B1A310: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B1A314: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921510473861536)("config.uab");
        // 0x00B1A318: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A31C: MOV x0, x20                | X0 = fullPath;//m1                      
        // 0x00B1A320: LDR x1, [x8]               | X1 = "config.uab";                      
        // 0x00B1A324: BL #0x18ab0a0              | X0 = fullPath.EndsWith(value:  "config.uab");
        bool val_3 = fullPath.EndsWith(value:  "config.uab");
        // 0x00B1A328: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00B1A32C: TBNZ w8, #0, #0xb1a3c0     | if ((val_3 & 1) == true) goto label_6;  
        if(val_4 == true)
        {
            goto label_6;
        }
        // 0x00B1A330: CBNZ x20, #0xb1a338        | if (fullPath != null) goto label_5;     
        if(fullPath != null)
        {
            goto label_5;
        }
        // 0x00B1A334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B1A338: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00B1A33C: LDR x8, [x8, #0xa88]       | X8 = (string**)(1152921515142011008)("csscript.uab");
        // 0x00B1A340: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A344: MOV x0, x20                | X0 = fullPath;//m1                      
        // 0x00B1A348: LDR x1, [x8]               | X1 = "csscript.uab";                    
        // 0x00B1A34C: BL #0x18ab0a0              | X0 = fullPath.EndsWith(value:  "csscript.uab");
        bool val_5 = fullPath.EndsWith(value:  "csscript.uab");
        // 0x00B1A350: TBNZ w0, #0, #0xb1a3c0     | if (val_5 == true) goto label_6;        
        if(val_5 == true)
        {
            goto label_6;
        }
        // 0x00B1A354: CBNZ x20, #0xb1a35c        | if (fullPath != null) goto label_7;     
        if(fullPath != null)
        {
            goto label_7;
        }
        // 0x00B1A358: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00B1A35C: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B1A360: LDR x8, [x8, #0xfc8]       | X8 = (string**)(1152921514967116720)("_csscript.uab");
        // 0x00B1A364: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A368: MOV x0, x20                | X0 = fullPath;//m1                      
        // 0x00B1A36C: LDR x1, [x8]               | X1 = "_csscript.uab";                   
        // 0x00B1A370: BL #0x18ab0a0              | X0 = fullPath.EndsWith(value:  "_csscript.uab");
        bool val_6 = fullPath.EndsWith(value:  "_csscript.uab");
        // 0x00B1A374: TBZ w0, #0, #0xb1a468      | if (val_6 == false) goto label_8;       
        if(val_6 == false)
        {
            goto label_8;
        }
        // 0x00B1A378: ADRP x21, #0x35ef000       | X21 = 56553472 (0x35EF000);             
        // 0x00B1A37C: LDR x21, [x21, #0xde8]     | X21 = 1152921504911265792;              
        // 0x00B1A380: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
        val_15 = null;
        // 0x00B1A384: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B1A388: TBZ w8, #0, #0xb1a39c      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B1A38C: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A390: CBNZ w8, #0xb1a39c         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B1A394: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B1A398: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
        val_15 = null;
        label_10:
        // 0x00B1A39C: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B1A3A0: LDR x21, [x8, #0x10]       | X21 = Loader.PathUtil.ARCH_ABI_TYPE;    
        val_14 = Loader.PathUtil.ARCH_ABI_TYPE;
        // 0x00B1A3A4: CBNZ x20, #0xb1a3ac        | if (fullPath != null) goto label_11;    
        if(fullPath != null)
        {
            goto label_11;
        }
        // 0x00B1A3A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
        label_11:
        // 0x00B1A3AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A3B0: MOV x0, x20                | X0 = fullPath;//m1                      
        // 0x00B1A3B4: MOV x1, x21                | X1 = Loader.PathUtil.ARCH_ABI_TYPE;//m1 
        // 0x00B1A3B8: BL #0x18ad42c              | X0 = fullPath.Contains(value:  val_14); 
        bool val_7 = fullPath.Contains(value:  val_14);
        // 0x00B1A3BC: TBZ w0, #0, #0xb1a454      | if (val_7 == false) goto label_17;      
        if(val_7 == false)
        {
            goto label_17;
        }
        label_6:
        // 0x00B1A3C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A3C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A3C8: MOV x1, x20                | X1 = fullPath;//m1                      
        // 0x00B1A3CC: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_8 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B1A3D0: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B1A3D4: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B1A3D8: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B1A3DC: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B1A3E0: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B1A3E4: TBZ w9, #0, #0xb1a3f8      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B1A3E8: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A3EC: CBNZ w9, #0xb1a3f8         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B1A3F0: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B1A3F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_14:
        // 0x00B1A3F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A3FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A400: MOV x1, x20                | X1 = val_8;//m1                         
        // 0x00B1A404: BL #0xac28b4               | X0 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        string val_9 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        label_21:
        // 0x00B1A408: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1A40C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1A410: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00B1A414: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B1A418: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1A41C: TBZ w9, #0, #0xb1a430      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x00B1A420: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A424: CBNZ w9, #0xb1a430         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x00B1A428: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B1A42C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_16:
        // 0x00B1A430: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A434: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1A438: MOV x1, x20                | X1 = val_9;//m1                         
        // 0x00B1A43C: MOV x2, x19                | X2 = md5;//m1                           
        // 0x00B1A440: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_9);
        bool val_10 = System.String.op_Inequality(a:  0, b:  val_9);
        // 0x00B1A444: AND w8, w0, #1             | W8 = (val_10 & 1);                      
        bool val_11 = val_10;
        // 0x00B1A448: TBZ w8, #0, #0xb1a454      | if ((val_10 & 1) == false) goto label_17;
        if(val_11 == false)
        {
            goto label_17;
        }
        // 0x00B1A44C: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_16 = 0;
        // 0x00B1A450: B #0xb1a458                |  goto label_18;                         
        goto label_18;
        label_17:
        // 0x00B1A454: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        val_16 = 1;
        label_18:
        // 0x00B1A458: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1A45C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1A460: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1A464: RET                        |  return (System.Boolean)true;           
        return (bool)val_16;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        label_8:
        // 0x00B1A468: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A46C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A470: MOV x1, x20                | X1 = fullPath;//m1                      
        // 0x00B1A474: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_12 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B1A478: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B1A47C: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B1A480: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00B1A484: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B1A488: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B1A48C: TBZ w9, #0, #0xb1a4a0      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B1A490: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A494: CBNZ w9, #0xb1a4a0         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B1A498: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B1A49C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_20:
        // 0x00B1A4A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A4A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A4A8: MOV x1, x20                | X1 = val_12;//m1                        
        // 0x00B1A4AC: BL #0xabed5c               | X0 = Mihua.Update.VSTools.GetCRC32(bytes:  0);
        string val_13 = Mihua.Update.VSTools.GetCRC32(bytes:  0);
        // 0x00B1A4B0: B #0xb1a408                |  goto label_21;                         
        goto label_21;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1A4B4 (11642036), len: 1088  VirtAddr: 0x00B1A4B4 RVA: 0x00B1A4B4 token: 100694294 methodIndex: 24637 delegateWrapperIndex: 0 methodInvoker: 0
    private void <LoadAllVSCfg>m__0()
    {
        //
        // Disasemble & Code
        //  | 
        var val_18;
        //  | 
        System.Char[] val_19;
        //  | 
        var val_20;
        //  | 
        System.Action val_21;
        // 0x00B1A4B4: STP x28, x27, [sp, #-0x60]! | stack[1152921515148555200] = ???;  stack[1152921515148555208] = ???;  //  dest_result_addr=1152921515148555200 |  dest_result_addr=1152921515148555208
        // 0x00B1A4B8: STP x26, x25, [sp, #0x10]  | stack[1152921515148555216] = ???;  stack[1152921515148555224] = ???;  //  dest_result_addr=1152921515148555216 |  dest_result_addr=1152921515148555224
        // 0x00B1A4BC: STP x24, x23, [sp, #0x20]  | stack[1152921515148555232] = ???;  stack[1152921515148555240] = ???;  //  dest_result_addr=1152921515148555232 |  dest_result_addr=1152921515148555240
        // 0x00B1A4C0: STP x22, x21, [sp, #0x30]  | stack[1152921515148555248] = ???;  stack[1152921515148555256] = ???;  //  dest_result_addr=1152921515148555248 |  dest_result_addr=1152921515148555256
        // 0x00B1A4C4: STP x20, x19, [sp, #0x40]  | stack[1152921515148555264] = ???;  stack[1152921515148555272] = ???;  //  dest_result_addr=1152921515148555264 |  dest_result_addr=1152921515148555272
        // 0x00B1A4C8: STP x29, x30, [sp, #0x50]  | stack[1152921515148555280] = ???;  stack[1152921515148555288] = ???;  //  dest_result_addr=1152921515148555280 |  dest_result_addr=1152921515148555288
        // 0x00B1A4CC: ADD x29, sp, #0x50         | X29 = (1152921515148555200 + 80) = 1152921515148555280 (0x100000027455B410);
        // 0x00B1A4D0: SUB sp, sp, #0x10          | SP = (1152921515148555200 - 16) = 1152921515148555184 (0x100000027455B3B0);
        // 0x00B1A4D4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1A4D8: LDRB w8, [x20, #0x6f0]     | W8 = (bool)static_value_037336F0;       
        // 0x00B1A4DC: MOV x19, x0                | X19 = 1152921515148567296 (0x100000027455E300);//ML01
        // 0x00B1A4E0: TBNZ w8, #0, #0xb1a4fc     | if (static_value_037336F0 == true) goto label_0;
        // 0x00B1A4E4: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B1A4E8: LDR x8, [x8, #0x700]       | X8 = 0x2B8A700;                         
        // 0x00B1A4EC: LDR w0, [x8]               | W0 = 0x7E;                              
        // 0x00B1A4F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x7E, ????);       
        // 0x00B1A4F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1A4F8: STRB w8, [x20, #0x6f0]     | static_value_037336F0 = true;            //  dest_result_addr=57882352
        label_0:
        // 0x00B1A4FC: ADRP x23, #0x363a000       | X23 = 56860672 (0x363A000);             
        // 0x00B1A500: LDR x23, [x23, #0x420]     | X23 = 1152921504911425536;              
        // 0x00B1A504: LDR x0, [x23]              | X0 = typeof(VersionMgr);                
        val_18 = null;
        // 0x00B1A508: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B1A50C: TBZ w8, #0, #0xb1a520      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1A510: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A514: CBNZ w8, #0xb1a520         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1A518: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        // 0x00B1A51C: LDR x0, [x23]              | X0 = typeof(VersionMgr);                
        val_18 = null;
        label_2:
        // 0x00B1A520: LDR x8, [x0, #0xa0]        | X8 = VersionMgr.__il2cppRuntimeField_static_fields;
        // 0x00B1A524: LDRB w8, [x8, #8]          | W8 = VersionMgr.enabled;                
        // 0x00B1A528: CBZ w8, #0xb1a8a4          | if (VersionMgr.enabled == false) goto label_30;
        if(VersionMgr.enabled == false)
        {
            goto label_30;
        }
        // 0x00B1A52C: MOV x0, x19                | X0 = 1152921515148567296 (0x100000027455E300);//ML01
        // 0x00B1A530: BL #0xb15254               | this.RequestCheckUpdate();              
        this.RequestCheckUpdate();
        // 0x00B1A534: LDR x0, [x23]              | X0 = typeof(VersionMgr);                
        // 0x00B1A538: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B1A53C: TBZ w8, #0, #0xb1a54c      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B1A540: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A544: CBNZ w8, #0xb1a54c         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B1A548: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_5:
        // 0x00B1A54C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A554: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_1 = VersionMgr.Instance;
        // 0x00B1A558: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B1A55C: CBNZ x20, #0xb1a564        | if (val_1 != null) goto label_6;        
        if(val_1 != null)
        {
            goto label_6;
        }
        // 0x00B1A560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00B1A564: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A568: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B1A56C: BL #0xe27dac               | X0 = val_1.get_currentVS();             
        VersionInfo val_2 = val_1.currentVS;
        // 0x00B1A570: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B1A574: CBNZ x20, #0xb1a57c        | if (val_2 != null) goto label_7;        
        if(val_2 != null)
        {
            goto label_7;
        }
        // 0x00B1A578: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B1A57C: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
        // 0x00B1A580: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
        val_19 = 1152921504608284672;
        // 0x00B1A584: LDR x20, [x20, #0x38]      | X20 = val_2.pkgurl; //P2                
        // 0x00B1A588: LDR x0, [x21]              | X0 = typeof(System.String);             
        val_20 = null;
        // 0x00B1A58C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1A590: TBZ w8, #0, #0xb1a5a4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00B1A594: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A598: CBNZ w8, #0xb1a5a4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00B1A59C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B1A5A0: LDR x0, [x21]              | X0 = typeof(System.String);             
        val_20 = null;
        label_9:
        // 0x00B1A5A4: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B1A5A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A5AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1A5B0: MOV x1, x20                | X1 = val_2.pkgurl;//m1                  
        // 0x00B1A5B4: LDR x2, [x8]               | X2 = System.String.Empty;               
        // 0x00B1A5B8: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_2.pkgurl);
        bool val_3 = System.String.op_Inequality(a:  0, b:  val_2.pkgurl);
        // 0x00B1A5BC: TBZ w0, #0, #0xb1a810      | if (val_3 == false) goto label_17;      
        if(val_3 == false)
        {
            goto label_17;
        }
        // 0x00B1A5C0: LDR x0, [x23]              | X0 = typeof(VersionMgr);                
        // 0x00B1A5C4: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B1A5C8: TBZ w8, #0, #0xb1a5d8      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B1A5CC: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A5D0: CBNZ w8, #0xb1a5d8         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B1A5D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_12:
        // 0x00B1A5D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A5DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A5E0: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_4 = VersionMgr.Instance;
        // 0x00B1A5E4: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B1A5E8: CBNZ x20, #0xb1a5f0        | if (val_4 != null) goto label_13;       
        if(val_4 != null)
        {
            goto label_13;
        }
        // 0x00B1A5EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_13:
        // 0x00B1A5F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A5F4: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B1A5F8: BL #0xe27dac               | X0 = val_4.get_currentVS();             
        VersionInfo val_5 = val_4.currentVS;
        // 0x00B1A5FC: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B1A600: CBNZ x20, #0xb1a608        | if (val_5 != null) goto label_14;       
        if(val_5 != null)
        {
            goto label_14;
        }
        // 0x00B1A604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_14:
        // 0x00B1A608: LDR x20, [x20, #0x18]      | X20 = val_5.pkgvs; //P2                 
        // 0x00B1A60C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A610: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A614: BL #0x20c75c4              | X0 = UnityEngine.Application.get_version();
        string val_6 = UnityEngine.Application.version;
        // 0x00B1A618: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00B1A61C: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
        // 0x00B1A620: MOV x21, x0                | X21 = val_6;//m1                        
        val_19 = val_6;
        // 0x00B1A624: LDR x22, [x8]              | X22 = typeof(System.Char[]);            
        // 0x00B1A628: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1A62C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00B1A630: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B1A634: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1A638: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00B1A63C: MOV x22, x0                | X22 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1A640: CBNZ x22, #0xb1a648        | if ( != null) goto label_15;            
        if(null != null)
        {
            goto label_15;
        }
        // 0x00B1A644: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_15:
        // 0x00B1A648: LDR w8, [x22, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00B1A64C: CBNZ w8, #0xb1a65c         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_16;
        // 0x00B1A650: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00B1A654: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A658: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_16:
        // 0x00B1A65C: MOVZ w8, #0x2e             | W8 = 46 (0x2E);//ML01                   
        // 0x00B1A660: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A664: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B1A668: MOV x1, x20                | X1 = val_5.pkgvs;//m1                   
        // 0x00B1A66C: MOV x2, x21                | X2 = val_6;//m1                         
        // 0x00B1A670: MOV x3, x22                | X3 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1A674: STRH w8, [x22, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x2E;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 46;
        // 0x00B1A678: BL #0x2795738              | X0 = EString.ECompareOrdinal(strA:  0, strB:  val_5.pkgvs, separator:  val_19);
        int val_7 = EString.ECompareOrdinal(strA:  0, strB:  val_5.pkgvs, separator:  val_19);
        // 0x00B1A67C: CMP w0, #1                 | STATE = COMPARE(val_7, 0x1)             
        // 0x00B1A680: B.LT #0xb1a810             | if (val_7 < 1) goto label_17;           
        if(val_7 < 1)
        {
            goto label_17;
        }
        // 0x00B1A684: LDR x0, [x23]              | X0 = typeof(VersionMgr);                
        // 0x00B1A688: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B1A68C: TBZ w8, #0, #0xb1a69c      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00B1A690: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A694: CBNZ w8, #0xb1a69c         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00B1A698: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_19:
        // 0x00B1A69C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A6A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A6A4: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_8 = VersionMgr.Instance;
        // 0x00B1A6A8: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B1A6AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A6B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A6B4: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_9 = VersionMgr.Instance;
        // 0x00B1A6B8: MOV x21, x0                | X21 = val_9;//m1                        
        // 0x00B1A6BC: CBNZ x21, #0xb1a6c4        | if (val_9 != null) goto label_20;       
        if(val_9 != null)
        {
            goto label_20;
        }
        // 0x00B1A6C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_20:
        // 0x00B1A6C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A6C8: MOV x0, x21                | X0 = val_9;//m1                         
        // 0x00B1A6CC: BL #0xe27dac               | X0 = val_9.get_currentVS();             
        VersionInfo val_10 = val_9.currentVS;
        // 0x00B1A6D0: MOV x21, x0                | X21 = val_10;//m1                       
        // 0x00B1A6D4: CBNZ x20, #0xb1a6dc        | if (val_8 != null) goto label_21;       
        if(val_8 != null)
        {
            goto label_21;
        }
        // 0x00B1A6D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_21:
        // 0x00B1A6DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A6E0: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00B1A6E4: MOV x1, x21                | X1 = val_10;//m1                        
        // 0x00B1A6E8: BL #0xe282c0               | X0 = val_8.NeedDownloadSize(vsInfo:  val_10);
        long val_11 = val_8.NeedDownloadSize(vsInfo:  val_10);
        // 0x00B1A6EC: CMP x0, #1                 | STATE = COMPARE(val_11, 0x1)            
        // 0x00B1A6F0: B.LT #0xb1a8d0             | if (val_11 < 1) goto label_22;          
        if(val_11 < 1)
        {
            goto label_22;
        }
        // 0x00B1A6F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A6F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A6FC: BL #0x138e268              | X0 = PluginsSdkMgr.get_Instance();      
        PluginsSdkMgr val_12 = PluginsSdkMgr.Instance;
        // 0x00B1A700: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00B1A704: ADRP x26, #0x3679000       | X26 = 57118720 (0x3679000);             
        // 0x00B1A708: LDR x8, [x8, #0xd60]       | X8 = 1152921515148528640;               
        // 0x00B1A70C: LDR x26, [x26, #0xbe0]     | X26 = 1152921504687837184;              
        // 0x00B1A710: MOV x21, x0                | X21 = val_12;//m1                       
        // 0x00B1A714: LDR x22, [x8]              | X22 = System.Void ABCheckUpdate::<LoadAllVSCfg>m__D();
        // 0x00B1A718: LDR x8, [x26]              | X8 = typeof(System.Action);             
        // 0x00B1A71C: MOV x0, x8                 | X0 = 1152921504687837184 (0x1000000004D3D000);//ML01
        System.Action val_13 = null;
        // 0x00B1A720: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B1A724: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1A728: MOV x1, x19                | X1 = 1152921515148567296 (0x100000027455E300);//ML01
        // 0x00B1A72C: MOV x2, x22                | X2 = 1152921515148528640 (0x1000000274554C00);//ML01
        // 0x00B1A730: MOV x20, x0                | X20 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1A734: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ABCheckUpdate::<LoadAllVSCfg>m__D());
        val_13 = new System.Action(object:  this, method:  System.Void ABCheckUpdate::<LoadAllVSCfg>m__D());
        // 0x00B1A738: ADRP x27, #0x365c000       | X27 = 56999936 (0x365C000);             
        // 0x00B1A73C: LDR x27, [x27, #0xd68]     | X27 = 1152921504910680064;              
        // 0x00B1A740: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00B1A744: LDR x8, [x8, #0x238]       | X8 = (string**)(1152921515140628368)("Update Later");
        // 0x00B1A748: ADRP x10, #0x3600000       | X10 = 56623104 (0x3600000);             
        // 0x00B1A74C: LDR x9, [x27]              | X9 = typeof(ABCheckUpdate);             
        // 0x00B1A750: ADRP x11, #0x3666000       | X11 = 57040896 (0x3666000);             
        // 0x00B1A754: ADRP x12, #0x35fc000       | X12 = 56606720 (0x35FC000);             
        // 0x00B1A758: LDR x10, [x10, #0x3a8]     | X10 = (string**)(1152921510033340128)("Update");
        // 0x00B1A75C: LDR x11, [x11, #0x928]     | X11 = (string**)(1152921515148529664)("Update detected, requires updating the version to continue to play the game");
        // 0x00B1A760: LDR x12, [x12, #0x618]     | X12 = (string**)(1152921515140257328)("Software Update");
        // 0x00B1A764: LDR x9, [x9, #0xa0]        | X9 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1A768: LDR x19, [x8]              | X19 = "Update Later";                   
        // 0x00B1A76C: LDR x22, [x10]             | X22 = "Update";                         
        // 0x00B1A770: LDR x23, [x11]             | X23 = "Update detected, requires updating the version to continue to play the game";
        // 0x00B1A774: LDR x25, [x9, #0x30]       | X25 = ABCheckUpdate.<>f__am$cache5;     
        val_21 = ABCheckUpdate.<>f__am$cache5;
        // 0x00B1A778: LDR x24, [x12]             | X24 = "Software Update";                
        // 0x00B1A77C: CBNZ x25, #0xb1a7c0        | if (ABCheckUpdate.<>f__am$cache5 != null) goto label_23;
        if(val_21 != null)
        {
            goto label_23;
        }
        // 0x00B1A780: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
        // 0x00B1A784: LDR x8, [x8, #0x528]       | X8 = 1152921515148529888;               
        // 0x00B1A788: LDR x0, [x26]              | X0 = typeof(System.Action);             
        System.Action val_14 = null;
        // 0x00B1A78C: LDR x25, [x8]              | X25 = static System.Void ABCheckUpdate::<LoadAllVSCfg>m__E();
        // 0x00B1A790: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B1A794: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A798: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1A79C: MOV x2, x25                | X2 = 1152921515148529888 (0x10000002745550E0);//ML01
        // 0x00B1A7A0: MOV x26, x0                | X26 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1A7A4: BL #0x26e30f0              | .ctor(object:  0, method:  static System.Void ABCheckUpdate::<LoadAllVSCfg>m__E());
        val_14 = new System.Action(object:  0, method:  static System.Void ABCheckUpdate::<LoadAllVSCfg>m__E());
        // 0x00B1A7A8: LDR x8, [x27]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B1A7AC: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1A7B0: STR x26, [x8, #0x30]       | ABCheckUpdate.<>f__am$cache5 = typeof(System.Action);  //  dest_result_addr=1152921504910684208
        ABCheckUpdate.<>f__am$cache5 = val_14;
        // 0x00B1A7B4: LDR x8, [x27]              | X8 = typeof(ABCheckUpdate);             
        // 0x00B1A7B8: LDR x8, [x8, #0xa0]        | X8 = ABCheckUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1A7BC: LDR x25, [x8, #0x30]       | X25 = typeof(System.Action);            
        val_21 = ABCheckUpdate.<>f__am$cache5;
        label_23:
        // 0x00B1A7C0: CBNZ x21, #0xb1a7c8        | if (val_12 != null) goto label_24;      
        if(val_12 != null)
        {
            goto label_24;
        }
        // 0x00B1A7C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ABCheckUpdate::<LoadAllVSCfg>m__E()), ????);
        label_24:
        // 0x00B1A7C8: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x00B1A7CC: MOV x0, x21                | X0 = val_12;//m1                        
        // 0x00B1A7D0: MOV x1, x24                | X1 = 1152921515140257328 (0x1000000273D71630);//ML01
        // 0x00B1A7D4: MOV x2, x23                | X2 = 1152921515148529664 (0x1000000274555000);//ML01
        // 0x00B1A7D8: MOV x4, x22                | X4 = 1152921510033340128 (0x100000014371B6E0);//ML01
        // 0x00B1A7DC: MOV x5, x19                | X5 = 1152921515140628368 (0x1000000273DCBF90);//ML01
        // 0x00B1A7E0: MOV x6, x20                | X6 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1A7E4: MOV x7, x25                | X7 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1A7E8: STR xzr, [sp]              | stack[1152921515148555184] = 0x0;        //  dest_result_addr=1152921515148555184
        // 0x00B1A7EC: BL #0x13a69fc              | val_12.ShowDialog(title:  "Software Update", content:  "Update detected, requires updating the version to continue to play the game", cancelable:  true, okText:  "Update", cancelText:  "Update Later", OnOK:  val_13, OnCancel:  val_21);
        val_12.ShowDialog(title:  "Software Update", content:  "Update detected, requires updating the version to continue to play the game", cancelable:  true, okText:  "Update", cancelText:  "Update Later", OnOK:  val_13, OnCancel:  val_21);
        // 0x00B1A7F0: SUB sp, x29, #0x50         | SP = (1152921515148555280 - 80) = 1152921515148555200 (0x100000027455B3C0);
        // 0x00B1A7F4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1A7F8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1A7FC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1A800: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1A804: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1A808: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B1A80C: RET                        |  return;                                
        return;
        label_17:
        // 0x00B1A810: LDR x0, [x23]              | X0 = typeof(VersionMgr);                
        // 0x00B1A814: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B1A818: TBZ w8, #0, #0xb1a828      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_26;
        // 0x00B1A81C: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A820: CBNZ w8, #0xb1a828         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
        // 0x00B1A824: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_26:
        // 0x00B1A828: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A82C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A830: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_15 = VersionMgr.Instance;
        // 0x00B1A834: MOV x20, x0                | X20 = val_15;//m1                       
        // 0x00B1A838: CBNZ x20, #0xb1a840        | if (val_15 != null) goto label_27;      
        if(val_15 != null)
        {
            goto label_27;
        }
        // 0x00B1A83C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_27:
        // 0x00B1A840: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A844: MOV x0, x20                | X0 = val_15;//m1                        
        // 0x00B1A848: BL #0xe27dac               | X0 = val_15.get_currentVS();            
        VersionInfo val_16 = val_15.currentVS;
        // 0x00B1A84C: MOV x20, x0                | X20 = val_16;//m1                       
        // 0x00B1A850: CBNZ x20, #0xb1a858        | if (val_16 != null) goto label_28;      
        if(val_16 != null)
        {
            goto label_28;
        }
        // 0x00B1A854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_28:
        // 0x00B1A858: LDR x20, [x20, #0xa8]      | X20 = val_16.sdkinfo; //P2              
        // 0x00B1A85C: CBNZ x20, #0xb1a864        | if (val_16.sdkinfo != null) goto label_29;
        if(val_16.sdkinfo != null)
        {
            goto label_29;
        }
        // 0x00B1A860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_29:
        // 0x00B1A864: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00B1A868: LDR x8, [x8, #0x810]       | X8 = (string**)(1152921515148543200)("JumpToNewUrl");
        // 0x00B1A86C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A870: MOV x0, x20                | X0 = val_16.sdkinfo;//m1                
        // 0x00B1A874: LDR x1, [x8]               | X1 = "JumpToNewUrl";                    
        // 0x00B1A878: BL #0x18ad42c              | X0 = val_16.sdkinfo.Contains(value:  "JumpToNewUrl");
        bool val_17 = val_16.sdkinfo.Contains(value:  "JumpToNewUrl");
        // 0x00B1A87C: TBZ w0, #0, #0xb1a8a4      | if (val_17 == false) goto label_30;     
        if(val_17 == false)
        {
            goto label_30;
        }
        // 0x00B1A880: MOV x0, x19                | X0 = 1152921515148567296 (0x100000027455E300);//ML01
        // 0x00B1A884: SUB sp, x29, #0x50         | SP = (1152921515148555280 - 80) = 1152921515148555200 (0x100000027455B3C0);
        // 0x00B1A888: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1A88C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1A890: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1A894: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1A898: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1A89C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B1A8A0: B #0xb15838                | this.GoToAppstoreDialog(); return;      
        this.GoToAppstoreDialog();
        return;
        label_30:
        // 0x00B1A8A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1A8A8: STRB w8, [x19, #0xa9]      | this.<isPkged>k__BackingField = true;    //  dest_result_addr=1152921515148567465
        this.<isPkged>k__BackingField = true;
        // 0x00B1A8AC: MOV x0, x19                | X0 = 1152921515148567296 (0x100000027455E300);//ML01
        // 0x00B1A8B0: SUB sp, x29, #0x50         | SP = (1152921515148555280 - 80) = 1152921515148555200 (0x100000027455B3C0);
        // 0x00B1A8B4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1A8B8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1A8BC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1A8C0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1A8C4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1A8C8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B1A8CC: B #0xb15d44                | this.LoadServerVer(); return;           
        this.LoadServerVer();
        return;
        label_22:
        // 0x00B1A8D0: MOV x0, x19                | X0 = 1152921515148567296 (0x100000027455E300);//ML01
        // 0x00B1A8D4: SUB sp, x29, #0x50         | SP = (1152921515148555280 - 80) = 1152921515148555200 (0x100000027455B3C0);
        // 0x00B1A8D8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1A8DC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1A8E0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1A8E4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1A8E8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1A8EC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B1A8F0: B #0xb159c0                | this.OnDownLoadAPK(); return;           
        this.OnDownLoadAPK();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1A8F4 (11643124), len: 472  VirtAddr: 0x00B1A8F4 RVA: 0x00B1A8F4 token: 100694295 methodIndex: 24638 delegateWrapperIndex: 0 methodInvoker: 0
    private static void <OnDownLoadAPK>m__1()
    {
        //
        // Disasemble & Code
        // 0x00B1A8F4: STP x22, x21, [sp, #-0x30]! | stack[1152921515148757552] = ???;  stack[1152921515148757560] = ???;  //  dest_result_addr=1152921515148757552 |  dest_result_addr=1152921515148757560
        // 0x00B1A8F8: STP x20, x19, [sp, #0x10]  | stack[1152921515148757568] = ???;  stack[1152921515148757576] = ???;  //  dest_result_addr=1152921515148757568 |  dest_result_addr=1152921515148757576
        // 0x00B1A8FC: STP x29, x30, [sp, #0x20]  | stack[1152921515148757584] = ???;  stack[1152921515148757592] = ???;  //  dest_result_addr=1152921515148757584 |  dest_result_addr=1152921515148757592
        // 0x00B1A900: ADD x29, sp, #0x20         | X29 = (1152921515148757552 + 32) = 1152921515148757584 (0x100000027458CA50);
        // 0x00B1A904: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B1A908: LDRB w8, [x19, #0x6f1]     | W8 = (bool)static_value_037336F1;       
        // 0x00B1A90C: TBNZ w8, #0, #0xb1a928     | if (static_value_037336F1 == true) goto label_0;
        // 0x00B1A910: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00B1A914: LDR x8, [x8, #0x50]        | X8 = 0x2B8A71C;                         
        // 0x00B1A918: LDR w0, [x8]               | W0 = 0x85;                              
        // 0x00B1A91C: BL #0x2782188              | X0 = sub_2782188( ?? 0x85, ????);       
        // 0x00B1A920: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1A924: STRB w8, [x19, #0x6f1]     | static_value_037336F1 = true;            //  dest_result_addr=57882353
        label_0:
        // 0x00B1A928: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00B1A92C: LDR x8, [x8, #0xf50]       | X8 = 1152921504652480512;               
        // 0x00B1A930: LDR x0, [x8]               | X0 = typeof(System.Console);            
        // 0x00B1A934: LDRB w8, [x0, #0x10a]      | W8 = System.Console.__il2cppRuntimeField_10A;
        // 0x00B1A938: TBZ w8, #0, #0xb1a948      | if (System.Console.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1A93C: LDR w8, [x0, #0xbc]        | W8 = System.Console.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A940: CBNZ w8, #0xb1a948         | if (System.Console.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1A944: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Console), ????);
        label_2:
        // 0x00B1A948: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00B1A94C: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921515148712640)("OnDownLoadAPK");
        // 0x00B1A950: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A954: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1A958: LDR x1, [x8]               | X1 = "OnDownLoadAPK";                   
        // 0x00B1A95C: BL #0x1ba1554              | System.Console.WriteLine(value:  0);    
        System.Console.WriteLine(value:  0);
        // 0x00B1A960: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A964: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A968: BL #0x138e268              | X0 = PluginsSdkMgr.get_Instance();      
        PluginsSdkMgr val_1 = PluginsSdkMgr.Instance;
        // 0x00B1A96C: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B1A970: CBNZ x19, #0xb1a978        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B1A974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B1A978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A97C: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B1A980: BL #0x137b0bc              | X0 = val_1.get_androidJavaObject();     
        UnityEngine.AndroidJavaObject val_2 = val_1.androidJavaObject;
        // 0x00B1A984: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B1A988: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B1A98C: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B1A990: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x00B1A994: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B1A998: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B1A99C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B1A9A0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B1A9A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B1A9A8: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B1A9AC: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B1A9B0: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B1A9B4: LDR x8, [x8]               | X8 = typeof(VersionMgr);                
        // 0x00B1A9B8: LDRB w9, [x8, #0x10a]      | W9 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B1A9BC: TBZ w9, #0, #0xb1a9d0      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B1A9C0: LDR w9, [x8, #0xbc]        | W9 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B1A9C4: CBNZ w9, #0xb1a9d0         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B1A9C8: MOV x0, x8                 | X0 = 1152921504911425536 (0x1000000012278000);//ML01
        // 0x00B1A9CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_5:
        // 0x00B1A9D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A9D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A9D8: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_3 = VersionMgr.Instance;
        // 0x00B1A9DC: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B1A9E0: CBNZ x21, #0xb1a9e8        | if (val_3 != null) goto label_6;        
        if(val_3 != null)
        {
            goto label_6;
        }
        // 0x00B1A9E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B1A9E8: LDR x21, [x21, #0x28]      | X21 = val_3.pkgSavePath; //P2           
        // 0x00B1A9EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1A9F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1A9F4: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_4 = VersionMgr.Instance;
        // 0x00B1A9F8: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B1A9FC: CBNZ x22, #0xb1aa04        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B1AA00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B1AA04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1AA08: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B1AA0C: BL #0xe27dac               | X0 = val_4.get_currentVS();             
        VersionInfo val_5 = val_4.currentVS;
        // 0x00B1AA10: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00B1AA14: CBNZ x22, #0xb1aa1c        | if (val_5 != null) goto label_8;        
        if(val_5 != null)
        {
            goto label_8;
        }
        // 0x00B1AA18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B1AA1C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1AA20: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1AA24: LDR x22, [x22, #0x28]      | X22 = val_5.pkgmd5; //P2                
        // 0x00B1AA28: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B1AA2C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1AA30: TBZ w8, #0, #0xb1aa40      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B1AA34: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1AA38: CBNZ w8, #0xb1aa40         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B1AA3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_10:
        // 0x00B1AA40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AA44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1AA48: MOV x1, x21                | X1 = val_3.pkgSavePath;//m1             
        // 0x00B1AA4C: MOV x2, x22                | X2 = val_5.pkgmd5;//m1                  
        // 0x00B1AA50: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_3.pkgSavePath);
        string val_6 = System.String.Concat(str0:  0, str1:  val_3.pkgSavePath);
        // 0x00B1AA54: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00B1AA58: CBNZ x20, #0xb1aa60        | if ( != null) goto label_11;            
        if(null != null)
        {
            goto label_11;
        }
        // 0x00B1AA5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00B1AA60: CBZ x21, #0xb1aa84         | if (val_6 == null) goto label_13;       
        if(val_6 == null)
        {
            goto label_13;
        }
        // 0x00B1AA64: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B1AA68: MOV x0, x21                | X0 = val_6;//m1                         
        // 0x00B1AA6C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B1AA70: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
        // 0x00B1AA74: CBNZ x0, #0xb1aa84         | if (val_6 != null) goto label_13;       
        if(val_6 != null)
        {
            goto label_13;
        }
        // 0x00B1AA78: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
        // 0x00B1AA7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1AA80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_13:
        // 0x00B1AA84: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B1AA88: CBNZ w8, #0xb1aa98         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_14;
        // 0x00B1AA8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
        // 0x00B1AA90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1AA94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_14:
        // 0x00B1AA98: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_6;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_6;
        // 0x00B1AA9C: CBNZ x19, #0xb1aaa4        | if (val_2 != null) goto label_15;       
        if(val_2 != null)
        {
            goto label_15;
        }
        // 0x00B1AAA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_15:
        // 0x00B1AAA4: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00B1AAA8: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921515148745504)("installApk");
        // 0x00B1AAAC: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00B1AAB0: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B1AAB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1AAB8: LDR x1, [x8]               | X1 = "installApk";                      
        // 0x00B1AABC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1AAC0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1AAC4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1AAC8: B #0x20bdbd4               | val_2.Call(methodName:  "installApk", args:  null); return;
        val_2.Call(methodName:  "installApk", args:  null);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1AACC (11643596), len: 708  VirtAddr: 0x00B1AACC RVA: 0x00B1AACC token: 100694296 methodIndex: 24639 delegateWrapperIndex: 0 methodInvoker: 0
    private void <LoadClientVer>m__2(string name, byte[] abBytes)
    {
        //
        // Disasemble & Code
        // 0x00B1AACC: STP x22, x21, [sp, #-0x30]! | stack[1152921515148951552] = ???;  stack[1152921515148951560] = ???;  //  dest_result_addr=1152921515148951552 |  dest_result_addr=1152921515148951560
        // 0x00B1AAD0: STP x20, x19, [sp, #0x10]  | stack[1152921515148951568] = ???;  stack[1152921515148951576] = ???;  //  dest_result_addr=1152921515148951568 |  dest_result_addr=1152921515148951576
        // 0x00B1AAD4: STP x29, x30, [sp, #0x20]  | stack[1152921515148951584] = ???;  stack[1152921515148951592] = ???;  //  dest_result_addr=1152921515148951584 |  dest_result_addr=1152921515148951592
        // 0x00B1AAD8: ADD x29, sp, #0x20         | X29 = (1152921515148951552 + 32) = 1152921515148951584 (0x10000002745BC020);
        // 0x00B1AADC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1AAE0: LDRB w8, [x21, #0x6f2]     | W8 = (bool)static_value_037336F2;       
        // 0x00B1AAE4: MOV x20, x2                | X20 = abBytes;//m1                      
        // 0x00B1AAE8: MOV x19, x0                | X19 = 1152921515148963600 (0x10000002745BEF10);//ML01
        // 0x00B1AAEC: TBNZ w8, #0, #0xb1ab08     | if (static_value_037336F2 == true) goto label_0;
        // 0x00B1AAF0: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B1AAF4: LDR x8, [x8, #0x1c8]       | X8 = 0x2B8A708;                         
        // 0x00B1AAF8: LDR w0, [x8]               | W0 = 0x80;                              
        // 0x00B1AAFC: BL #0x2782188              | X0 = sub_2782188( ?? 0x80, ????);       
        // 0x00B1AB00: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1AB04: STRB w8, [x21, #0x6f2]     | static_value_037336F2 = true;            //  dest_result_addr=57882354
        label_0:
        // 0x00B1AB08: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00B1AB0C: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
        // 0x00B1AB10: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
        // 0x00B1AB14: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
        // 0x00B1AB18: TBZ w8, #0, #0xb1ab28      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1AB1C: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
        // 0x00B1AB20: CBNZ w8, #0xb1ab28         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1AB24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
        label_2:
        // 0x00B1AB28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AB2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1AB30: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_1 = System.Text.Encoding.UTF8;
        // 0x00B1AB34: MOV x1, x20                | X1 = abBytes;//m1                       
        // 0x00B1AB38: MOV x2, x0                 | X2 = val_1;//m1                         
        // 0x00B1AB3C: BL #0xb19978               | X0 = ABCheckUpdate.BytesToString(bytes:  System.Text.Encoding val_1 = System.Text.Encoding.UTF8, encoding:  abBytes);
        string val_2 = ABCheckUpdate.BytesToString(bytes:  val_1, encoding:  abBytes);
        // 0x00B1AB40: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B1AB44: STR x20, [x19, #0x58]      | this.clientVer = val_2;                  //  dest_result_addr=1152921515148963688
        this.clientVer = val_2;
        // 0x00B1AB48: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00B1AB4C: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
        // 0x00B1AB50: LDR x21, [x8]              | X21 = typeof(System.Char[]);            
        // 0x00B1AB54: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1AB58: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00B1AB5C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B1AB60: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1AB64: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00B1AB68: MOV x21, x0                | X21 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1AB6C: CBNZ x21, #0xb1ab74        | if ( != null) goto label_3;             
        if(null != null)
        {
            goto label_3;
        }
        // 0x00B1AB70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_3:
        // 0x00B1AB74: LDR w8, [x21, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00B1AB78: CBNZ w8, #0xb1ab88         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_4;
        // 0x00B1AB7C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00B1AB80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1AB84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_4:
        // 0x00B1AB88: MOVZ w8, #0x2e             | W8 = 46 (0x2E);//ML01                   
        // 0x00B1AB8C: STRH w8, [x21, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x2E;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 46;
        // 0x00B1AB90: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x00B1AB94: LDR x8, [x8, #0xdb0]       | X8 = (string**)(1152921515148939520)("1.0.0");
        // 0x00B1AB98: LDR x2, [x8]               | X2 = "1.0.0";                           
        // 0x00B1AB9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1ABA0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B1ABA4: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00B1ABA8: MOV x3, x21                | X3 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00B1ABAC: BL #0x2795738              | X0 = EString.ECompareOrdinal(strA:  0, strB:  val_2, separator:  "1.0.0");
        int val_3 = EString.ECompareOrdinal(strA:  0, strB:  val_2, separator:  "1.0.0");
        // 0x00B1ABB0: MOV x0, x19                | X0 = 1152921515148963600 (0x10000002745BEF10);//ML01
        // 0x00B1ABB4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1ABB8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1ABBC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1ABC0: B #0xb15190                | this.LoadAllVSCfg(); return;            
        this.LoadAllVSCfg();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1AD90 (11644304), len: 140  VirtAddr: 0x00B1AD90 RVA: 0x00B1AD90 token: 100694297 methodIndex: 24640 delegateWrapperIndex: 0 methodInvoker: 0
    private void <LoadServerVer>m__3(string name, byte[] abBytes)
    {
        //
        // Disasemble & Code
        // 0x00B1AD90: STP x22, x21, [sp, #-0x30]! | stack[1152921515149161856] = ???;  stack[1152921515149161864] = ???;  //  dest_result_addr=1152921515149161856 |  dest_result_addr=1152921515149161864
        // 0x00B1AD94: STP x20, x19, [sp, #0x10]  | stack[1152921515149161872] = ???;  stack[1152921515149161880] = ???;  //  dest_result_addr=1152921515149161872 |  dest_result_addr=1152921515149161880
        // 0x00B1AD98: STP x29, x30, [sp, #0x20]  | stack[1152921515149161888] = ???;  stack[1152921515149161896] = ???;  //  dest_result_addr=1152921515149161888 |  dest_result_addr=1152921515149161896
        // 0x00B1AD9C: ADD x29, sp, #0x20         | X29 = (1152921515149161856 + 32) = 1152921515149161888 (0x10000002745EF5A0);
        // 0x00B1ADA0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1ADA4: LDRB w8, [x21, #0x6f3]     | W8 = (bool)static_value_037336F3;       
        // 0x00B1ADA8: MOV x20, x2                | X20 = abBytes;//m1                      
        // 0x00B1ADAC: MOV x19, x0                | X19 = 1152921515149173904 (0x10000002745F2490);//ML01
        // 0x00B1ADB0: TBNZ w8, #0, #0xb1adcc     | if (static_value_037336F3 == true) goto label_0;
        // 0x00B1ADB4: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
        // 0x00B1ADB8: LDR x8, [x8, #0xe18]       | X8 = 0x2B8A714;                         
        // 0x00B1ADBC: LDR w0, [x8]               | W0 = 0x83;                              
        // 0x00B1ADC0: BL #0x2782188              | X0 = sub_2782188( ?? 0x83, ????);       
        // 0x00B1ADC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1ADC8: STRB w8, [x21, #0x6f3]     | static_value_037336F3 = true;            //  dest_result_addr=57882355
        label_0:
        // 0x00B1ADCC: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00B1ADD0: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
        // 0x00B1ADD4: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
        // 0x00B1ADD8: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
        // 0x00B1ADDC: TBZ w8, #0, #0xb1adec      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1ADE0: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
        // 0x00B1ADE4: CBNZ w8, #0xb1adec         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1ADE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
        label_2:
        // 0x00B1ADEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1ADF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1ADF4: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_1 = System.Text.Encoding.UTF8;
        // 0x00B1ADF8: MOV x1, x20                | X1 = abBytes;//m1                       
        // 0x00B1ADFC: MOV x2, x0                 | X2 = val_1;//m1                         
        // 0x00B1AE00: BL #0xb19978               | X0 = ABCheckUpdate.BytesToString(bytes:  System.Text.Encoding val_1 = System.Text.Encoding.UTF8, encoding:  abBytes);
        string val_2 = ABCheckUpdate.BytesToString(bytes:  val_1, encoding:  abBytes);
        // 0x00B1AE04: STR x0, [x19, #0x78]       | this.serverVer = val_2;                  //  dest_result_addr=1152921515149174024
        this.serverVer = val_2;
        // 0x00B1AE08: MOV x0, x19                | X0 = 1152921515149173904 (0x10000002745F2490);//ML01
        // 0x00B1AE0C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1AE10: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1AE14: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1AE18: B #0xb15f20                | this.CheckVer(); return;                
        this.CheckVer();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1AE1C (11644444), len: 596  VirtAddr: 0x00B1AE1C RVA: 0x00B1AE1C token: 100694298 methodIndex: 24641 delegateWrapperIndex: 0 methodInvoker: 0
    private void <LoadClientVS>m__4(string name, byte[] abBytes)
    {
        //
        // Disasemble & Code
        //  | 
        var val_11;
        //  | 
        var val_12;
        // 0x00B1AE1C: STP x24, x23, [sp, #-0x40]! | stack[1152921515149431536] = ???;  stack[1152921515149431544] = ???;  //  dest_result_addr=1152921515149431536 |  dest_result_addr=1152921515149431544
        // 0x00B1AE20: STP x22, x21, [sp, #0x10]  | stack[1152921515149431552] = ???;  stack[1152921515149431560] = ???;  //  dest_result_addr=1152921515149431552 |  dest_result_addr=1152921515149431560
        // 0x00B1AE24: STP x20, x19, [sp, #0x20]  | stack[1152921515149431568] = ???;  stack[1152921515149431576] = ???;  //  dest_result_addr=1152921515149431568 |  dest_result_addr=1152921515149431576
        // 0x00B1AE28: STP x29, x30, [sp, #0x30]  | stack[1152921515149431584] = ???;  stack[1152921515149431592] = ???;  //  dest_result_addr=1152921515149431584 |  dest_result_addr=1152921515149431592
        // 0x00B1AE2C: ADD x29, sp, #0x30         | X29 = (1152921515149431536 + 48) = 1152921515149431584 (0x1000000274631320);
        // 0x00B1AE30: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1AE34: LDRB w8, [x21, #0x6f4]     | W8 = (bool)static_value_037336F4;       
        // 0x00B1AE38: MOV x20, x2                | X20 = abBytes;//m1                      
        // 0x00B1AE3C: MOV x19, x0                | X19 = 1152921515149443600 (0x1000000274634210);//ML01
        // 0x00B1AE40: TBNZ w8, #0, #0xb1ae5c     | if (static_value_037336F4 == true) goto label_0;
        // 0x00B1AE44: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
        // 0x00B1AE48: LDR x8, [x8, #0x158]       | X8 = 0x2B8A70C;                         
        // 0x00B1AE4C: LDR w0, [x8]               | W0 = 0x81;                              
        // 0x00B1AE50: BL #0x2782188              | X0 = sub_2782188( ?? 0x81, ????);       
        // 0x00B1AE54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1AE58: STRB w8, [x21, #0x6f4]     | static_value_037336F4 = true;            //  dest_result_addr=57882356
        label_0:
        // 0x00B1AE5C: ADRP x22, #0x35ef000       | X22 = 56553472 (0x35EF000);             
        // 0x00B1AE60: LDR x22, [x22, #0xde8]     | X22 = 1152921504911265792;              
        // 0x00B1AE64: LDR x0, [x22]              | X0 = typeof(Loader.PathUtil);           
        val_11 = null;
        // 0x00B1AE68: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B1AE6C: TBZ w8, #0, #0xb1ae80      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1AE70: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B1AE74: CBNZ w8, #0xb1ae80         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1AE78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B1AE7C: LDR x0, [x22]              | X0 = typeof(Loader.PathUtil);           
        val_11 = null;
        label_2:
        // 0x00B1AE80: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
        // 0x00B1AE84: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B1AE88: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
        // 0x00B1AE8C: LDR x21, [x8, #0x28]       | X21 = Loader.PathUtil.persistentDataPath;
        // 0x00B1AE90: LDR x0, [x23]              | X0 = typeof(System.String);             
        // 0x00B1AE94: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1AE98: TBZ w8, #0, #0xb1aea8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B1AE9C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1AEA0: CBNZ w8, #0xb1aea8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B1AEA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_4:
        // 0x00B1AEA8: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00B1AEAC: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921510474838464)("eff_crc.uab");
        // 0x00B1AEB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AEB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1AEB8: MOV x1, x21                | X1 = Loader.PathUtil.persistentDataPath;//m1
        // 0x00B1AEBC: LDR x2, [x8]               | X2 = "eff_crc.uab";                     
        // 0x00B1AEC0: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        string val_1 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        // 0x00B1AEC4: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B1AEC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AECC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1AED0: MOV x1, x21                | X1 = val_1;//m1                         
        // 0x00B1AED4: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_2 = System.IO.File.Exists(path:  0);
        // 0x00B1AED8: TBZ w0, #0, #0xb1af0c      | if (val_2 == false) goto label_5;       
        if(val_2 == false)
        {
            goto label_5;
        }
        // 0x00B1AEDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AEE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1AEE4: MOV x1, x21                | X1 = val_1;//m1                         
        // 0x00B1AEE8: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_3 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B1AEEC: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x00B1AEF0: LDR x8, [x8, #0xd0]        | X8 = 1152921514962412304;               
        // 0x00B1AEF4: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00B1AEF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AEFC: LDR x2, [x8]               | X2 = public static Filelist<T> Filelist<FileInfoCrc>::CreatFromBytes(byte[] bytes);
        // 0x00B1AF00: BL #0x19ccffc              | X0 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        Filelist<T> val_4 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        // 0x00B1AF04: STR x0, [x19, #0x10]       | this.clientCrcList = val_4;              //  dest_result_addr=1152921515149443616
        this.clientCrcList = val_4;
        // 0x00B1AF08: B #0xb1af34                |  goto label_6;                          
        goto label_6;
        label_5:
        // 0x00B1AF0C: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00B1AF10: LDR x8, [x8, #0x940]       | X8 = 1152921504911052800;               
        // 0x00B1AF14: LDR x0, [x8]               | X0 = typeof(Filelist<T>);               
        Filelist<FileInfoCrc> val_5 = null;
        // 0x00B1AF18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Filelist<T>), ????);
        // 0x00B1AF1C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B1AF20: LDR x8, [x8, #0xe08]       | X8 = 1152921514962417424;               
        // 0x00B1AF24: MOV x21, x0                | X21 = 1152921504911052800 (0x100000001221D000);//ML01
        // 0x00B1AF28: LDR x1, [x8]               | X1 = public System.Void Filelist<FileInfoCrc>::.ctor();
        // 0x00B1AF2C: BL #0x19ccf20              | .ctor();                                
        val_5 = new Filelist<FileInfoCrc>();
        // 0x00B1AF30: STR x21, [x19, #0x10]      | this.clientCrcList = typeof(Filelist<T>);  //  dest_result_addr=1152921515149443616
        this.clientCrcList = val_5;
        label_6:
        // 0x00B1AF34: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00B1AF38: LDR x8, [x8, #0xbe0]       | X8 = 1152921515149397072;               
        // 0x00B1AF3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AF40: MOV x1, x20                | X1 = abBytes;//m1                       
        // 0x00B1AF44: LDR x2, [x8]               | X2 = public static Filelist<T> Filelist<FileInfoRes>::CreatFromBytes(byte[] bytes);
        // 0x00B1AF48: BL #0x19ccffc              | X0 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        Filelist<T> val_6 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        // 0x00B1AF4C: STR x0, [x19, #0x38]       | this.clientStreamingList = val_6;        //  dest_result_addr=1152921515149443656
        this.clientStreamingList = val_6;
        // 0x00B1AF50: LDR x0, [x22]              | X0 = typeof(Loader.PathUtil);           
        val_12 = null;
        // 0x00B1AF54: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B1AF58: TBZ w8, #0, #0xb1af6c      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B1AF5C: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B1AF60: CBNZ w8, #0xb1af6c         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B1AF64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B1AF68: LDR x0, [x22]              | X0 = typeof(Loader.PathUtil);           
        val_12 = null;
        label_8:
        // 0x00B1AF6C: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B1AF70: LDR x0, [x23]              | X0 = typeof(System.String);             
        // 0x00B1AF74: LDR x20, [x8, #0x28]       | X20 = Loader.PathUtil.persistentDataPath;
        // 0x00B1AF78: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1AF7C: TBZ w8, #0, #0xb1af8c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B1AF80: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1AF84: CBNZ w8, #0xb1af8c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B1AF88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_10:
        // 0x00B1AF8C: ADRP x21, #0x363f000       | X21 = 56881152 (0x363F000);             
        // 0x00B1AF90: LDR x21, [x21, #0x8b8]     | X21 = (string**)(1152921510473621280)("vsconfig.uab");
        // 0x00B1AF94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AF98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1AF9C: MOV x1, x20                | X1 = Loader.PathUtil.persistentDataPath;//m1
        // 0x00B1AFA0: LDR x2, [x21]              | X2 = "vsconfig.uab";                    
        // 0x00B1AFA4: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        string val_7 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        // 0x00B1AFA8: MOV x1, x0                 | X1 = val_7;//m1                         
        // 0x00B1AFAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AFB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1AFB4: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_8 = System.IO.File.Exists(path:  0);
        // 0x00B1AFB8: TBZ w0, #0, #0xb1b04c      | if (val_8 == false) goto label_11;      
        if(val_8 == false)
        {
            goto label_11;
        }
        // 0x00B1AFBC: LDR x0, [x22]              | X0 = typeof(Loader.PathUtil);           
        // 0x00B1AFC0: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B1AFC4: TBZ w8, #0, #0xb1afd4      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B1AFC8: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B1AFCC: CBNZ w8, #0xb1afd4         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B1AFD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        label_13:
        // 0x00B1AFD4: LDR x1, [x21]              | X1 = "vsconfig.uab";                    
        // 0x00B1AFD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1AFDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1AFE0: BL #0xdbc91c               | X0 = Loader.PathUtil.PersistentDataPath(path:  0);
        string val_9 = Loader.PathUtil.PersistentDataPath(path:  0);
        // 0x00B1AFE4: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00B1AFE8: BL #0xb14f80               | X0 = AssetDownMgr.get_Instance();       
        AssetDownMgr val_10 = AssetDownMgr.Instance;
        // 0x00B1AFEC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B1AFF0: ADRP x9, #0x361c000        | X9 = 56737792 (0x361C000);              
        // 0x00B1AFF4: LDR x8, [x8, #0x90]        | X8 = 1152921515149414480;               
        // 0x00B1AFF8: LDR x9, [x9, #0x610]       | X9 = 1152921504910786560;               
        // 0x00B1AFFC: MOV x21, x0                | X21 = val_10;//m1                       
        // 0x00B1B000: LDR x23, [x8]              | X23 = System.Void ABCheckUpdate::<LoadClientVS>m__F(string name1, byte[] abBytes1);
        // 0x00B1B004: LDR x8, [x9]               | X8 = typeof(AssetDownMgr.SetBytes);     
        // 0x00B1B008: MOV x0, x8                 | X0 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B1B00C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetDownMgr.SetBytes), ????);
        // 0x00B1B010: LDR x8, [x23]              | X8 = System.Void ABCheckUpdate::<LoadClientVS>m__F(string name1, byte[] abBytes1);
        // 0x00B1B014: MOV x22, x0                | X22 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B1B018: STP x19, x23, [x22, #0x20] | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;  typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadClientVS>m__F(string name1, byte[] abBytes1);  //  dest_result_addr=1152921504910786592 |  dest_result_addr=1152921504910786600
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_20 = this;
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_28 = System.Void ABCheckUpdate::<LoadClientVS>m__F(string name1, byte[] abBytes1);
        // 0x00B1B01C: STR x8, [x22, #0x10]       | typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadClientVS>m__F(string name1, byte[] abBytes1);  //  dest_result_addr=1152921504910786576
        typeof(AssetDownMgr.SetBytes).__il2cppRuntimeField_10 = System.Void ABCheckUpdate::<LoadClientVS>m__F(string name1, byte[] abBytes1);
        // 0x00B1B020: CBNZ x21, #0xb1b028        | if (val_10 != null) goto label_14;      
        if(val_10 != null)
        {
            goto label_14;
        }
        // 0x00B1B024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AssetDownMgr.SetBytes), ????);
        label_14:
        // 0x00B1B028: MOV x0, x21                | X0 = val_10;//m1                        
        // 0x00B1B02C: MOV x1, x20                | X1 = val_9;//m1                         
        // 0x00B1B030: MOV x2, x22                | X2 = 1152921504910786560 (0x10000000121DC000);//ML01
        // 0x00B1B034: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B038: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1B03C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1B040: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B1B044: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B1B048: B #0xb15ab0                | val_10.AddUpdateData(path:  val_9, downFinishCall:  null, isInsert:  false); return;
        val_10.AddUpdateData(path:  val_9, downFinishCall:  null, isInsert:  false);
        return;
        label_11:
        // 0x00B1B04C: LDR x8, [x19, #0x38]       | X8 = this.clientStreamingList; //P2     
        // 0x00B1B050: STR xzr, [x19, #0x30]      | this.clientPersistentList = null;        //  dest_result_addr=1152921515149443648
        this.clientPersistentList = 0;
        // 0x00B1B054: MOV x0, x19                | X0 = 1152921515149443600 (0x1000000274634210);//ML01
        // 0x00B1B058: STR x8, [x19, #0x20]       | this.clientList = this.clientStreamingList;  //  dest_result_addr=1152921515149443632
        this.clientList = this.clientStreamingList;
        // 0x00B1B05C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B060: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1B064: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1B068: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B1B06C: B #0xb161c4                | this.LoadServerVS(); return;            
        this.LoadServerVS();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B070 (11645040), len: 328  VirtAddr: 0x00B1B070 RVA: 0x00B1B070 token: 100694299 methodIndex: 24642 delegateWrapperIndex: 0 methodInvoker: 0
    private void <LoadServerVS>m__5(string name, byte[] abBytes)
    {
        //
        // Disasemble & Code
        // 0x00B1B070: STP x22, x21, [sp, #-0x30]! | stack[1152921515149696128] = ???;  stack[1152921515149696136] = ???;  //  dest_result_addr=1152921515149696128 |  dest_result_addr=1152921515149696136
        // 0x00B1B074: STP x20, x19, [sp, #0x10]  | stack[1152921515149696144] = ???;  stack[1152921515149696152] = ???;  //  dest_result_addr=1152921515149696144 |  dest_result_addr=1152921515149696152
        // 0x00B1B078: STP x29, x30, [sp, #0x20]  | stack[1152921515149696160] = ???;  stack[1152921515149696168] = ???;  //  dest_result_addr=1152921515149696160 |  dest_result_addr=1152921515149696168
        // 0x00B1B07C: ADD x29, sp, #0x20         | X29 = (1152921515149696128 + 32) = 1152921515149696160 (0x1000000274671CA0);
        // 0x00B1B080: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1B084: LDRB w8, [x21, #0x6f5]     | W8 = (bool)static_value_037336F5;       
        // 0x00B1B088: MOV x20, x2                | X20 = abBytes;//m1                      
        // 0x00B1B08C: MOV x19, x0                | X19 = 1152921515149708176 (0x1000000274674B90);//ML01
        // 0x00B1B090: TBNZ w8, #0, #0xb1b0ac     | if (static_value_037336F5 == true) goto label_0;
        // 0x00B1B094: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00B1B098: LDR x8, [x8, #0xa18]       | X8 = 0x2B8A718;                         
        // 0x00B1B09C: LDR w0, [x8]               | W0 = 0x84;                              
        // 0x00B1B0A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x84, ????);       
        // 0x00B1B0A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1B0A8: STRB w8, [x21, #0x6f5]     | static_value_037336F5 = true;            //  dest_result_addr=57882357
        label_0:
        // 0x00B1B0AC: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00B1B0B0: LDR x8, [x8, #0xbe0]       | X8 = 1152921515149397072;               
        // 0x00B1B0B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B0B8: MOV x1, x20                | X1 = abBytes;//m1                       
        // 0x00B1B0BC: LDR x2, [x8]               | X2 = public static Filelist<T> Filelist<FileInfoRes>::CreatFromBytes(byte[] bytes);
        // 0x00B1B0C0: BL #0x19ccffc              | X0 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        Filelist<T> val_1 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        // 0x00B1B0C4: STR x0, [x19, #0x28]       | this.serverList = val_1;                 //  dest_result_addr=1152921515149708216
        this.serverList = val_1;
        // 0x00B1B0C8: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B1B0CC: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
        // 0x00B1B0D0: LDR x8, [x8, #0xd18]       | X8 = 1152921515149683152;               
        // 0x00B1B0D4: LDR x9, [x9, #0x840]       | X9 = 1152921504657805312;               
        // 0x00B1B0D8: LDR x20, [x8]              | X20 = System.Void ABCheckUpdate::Check();
        // 0x00B1B0DC: LDR x0, [x9]               | X0 = typeof(System.Threading.ThreadStart);
        System.Threading.ThreadStart val_2 = null;
        // 0x00B1B0E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Threading.ThreadStart), ????);
        // 0x00B1B0E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1B0E8: MOV x1, x19                | X1 = 1152921515149708176 (0x1000000274674B90);//ML01
        // 0x00B1B0EC: MOV x2, x20                | X2 = 1152921515149683152 (0x100000027466E9D0);//ML01
        // 0x00B1B0F0: MOV x21, x0                | X21 = 1152921504657805312 (0x1000000003099000);//ML01
        // 0x00B1B0F4: BL #0x1b67778              | .ctor(object:  this, method:  System.Void ABCheckUpdate::Check());
        val_2 = new System.Threading.ThreadStart(object:  this, method:  System.Void ABCheckUpdate::Check());
        // 0x00B1B0F8: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00B1B0FC: LDR x8, [x8, #0x490]       | X8 = 1152921504650829824;               
        // 0x00B1B100: LDR x0, [x8]               | X0 = typeof(System.Threading.Thread);   
        System.Threading.Thread val_3 = null;
        // 0x00B1B104: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Threading.Thread), ????);
        // 0x00B1B108: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B10C: MOV x1, x21                | X1 = 1152921504657805312 (0x1000000003099000);//ML01
        // 0x00B1B110: MOV x19, x0                | X19 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00B1B114: BL #0x1b66890              | .ctor(start:  val_2);                   
        val_3 = new System.Threading.Thread(start:  val_2);
        // 0x00B1B118: CBZ x19, #0xb1b158         | if ( == 0) goto label_1;                
        if(null == 0)
        {
            goto label_1;
        }
        // 0x00B1B11C: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B1B120: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921515139856352)("CheckUpdate");
        // 0x00B1B124: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B128: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00B1B12C: LDR x1, [x8]               | X1 = "CheckUpdate";                     
        // 0x00B1B130: BL #0x1b67218              | set_Name(value:  "CheckUpdate");        
        Name = "CheckUpdate";
        // 0x00B1B134: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B138: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00B1B13C: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00B1B140: BL #0x1b6721c              | set_Priority(value:  4);                
        Priority = 4;
        // 0x00B1B144: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B148: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B1B14C: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00B1B150: BL #0x1b671f8              | set_IsBackground(value:  true);         
        IsBackground = true;
        // 0x00B1B154: B #0xb1b1a0                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00B1B158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(start:  val_2), ????);
        // 0x00B1B15C: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B1B160: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921515139856352)("CheckUpdate");
        // 0x00B1B164: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B168: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00B1B16C: LDR x1, [x8]               | X1 = "CheckUpdate";                     
        // 0x00B1B170: BL #0x1b67218              | set_Name(value:  "CheckUpdate");        
        Name = "CheckUpdate";
        // 0x00B1B174: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Threading.Thread), ????);
        // 0x00B1B178: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B17C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00B1B180: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00B1B184: BL #0x1b6721c              | set_Priority(value:  4);                
        Priority = 4;
        // 0x00B1B188: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Threading.Thread), ????);
        // 0x00B1B18C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B190: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B1B194: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00B1B198: BL #0x1b671f8              | set_IsBackground(value:  true);         
        IsBackground = true;
        // 0x00B1B19C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Threading.Thread), ????);
        label_2:
        // 0x00B1B1A0: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00B1B1A4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B1A8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1B1AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B1B0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1B1B4: B #0x1b672dc               | Start(); return;                        
        Start();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B1B8 (11645368), len: 164  VirtAddr: 0x00B1B1B8 RVA: 0x00B1B1B8 token: 100694300 methodIndex: 24643 delegateWrapperIndex: 0 methodInvoker: 0
    private static void <StartDown>m__6(string name, byte[] abBytes)
    {
        //
        // Disasemble & Code
        // 0x00B1B1B8: STP x20, x19, [sp, #-0x20]! | stack[1152921515149898336] = ???;  stack[1152921515149898344] = ???;  //  dest_result_addr=1152921515149898336 |  dest_result_addr=1152921515149898344
        // 0x00B1B1BC: STP x29, x30, [sp, #0x10]  | stack[1152921515149898352] = ???;  stack[1152921515149898360] = ???;  //  dest_result_addr=1152921515149898352 |  dest_result_addr=1152921515149898360
        // 0x00B1B1C0: ADD x29, sp, #0x10         | X29 = (1152921515149898336 + 16) = 1152921515149898352 (0x10000002746A3270);
        // 0x00B1B1C4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B1B1C8: LDRB w8, [x19, #0x6f6]     | W8 = (bool)static_value_037336F6;       
        // 0x00B1B1CC: TBNZ w8, #0, #0xb1b1e8     | if (static_value_037336F6 == true) goto label_0;
        // 0x00B1B1D0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B1B1D4: LDR x8, [x8, #0x118]       | X8 = 0x2B8A728;                         
        // 0x00B1B1D8: LDR w0, [x8]               | W0 = 0x88;                              
        // 0x00B1B1DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x88, ????);       
        // 0x00B1B1E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1B1E4: STRB w8, [x19, #0x6f6]     | static_value_037336F6 = true;            //  dest_result_addr=57882358
        label_0:
        // 0x00B1B1E8: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B1B1EC: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B1B1F0: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00B1B1F4: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B1B1F8: TBZ w8, #0, #0xb1b208      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1B1FC: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B1B200: CBNZ w8, #0xb1b208         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1B204: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00B1B208: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x00B1B20C: LDR x8, [x8, #0xff8]       | X8 = (string**)(1152921515149882192)("资源下载完成");
        // 0x00B1B210: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B214: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1B218: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1B21C: LDR x1, [x8]               | X1 = "资源下载完成";                          
        // 0x00B1B220: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00B1B224: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B22C: BL #0xdbd3cc               | X0 = LoadingBoardMgr.get_Instance();    
        LoadingBoardMgr val_1 = LoadingBoardMgr.Instance;
        // 0x00B1B230: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B1B234: CBNZ x19, #0xb1b23c        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B1B238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B1B23C: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00B1B240: LDR x8, [x8, #0x4a0]       | X8 = (string**)(1152921510482740544)("Resources being processed...");
        // 0x00B1B244: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B248: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B1B24C: LDR x1, [x8]               | X1 = "Resources being processed...";    
        // 0x00B1B250: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B254: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1B258: B #0xdbdc98                | val_1.SetDescri(value:  "Resources being processed..."); return;
        val_1.SetDescri(value:  "Resources being processed...");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B25C (11645532), len: 4  VirtAddr: 0x00B1B25C RVA: 0x00B1B25C token: 100694301 methodIndex: 24644 delegateWrapperIndex: 0 methodInvoker: 0
    private void <StartDown>m__7()
    {
        //
        // Disasemble & Code
        // 0x00B1B25C: B #0xb1913c                | this.LoadedAll(); return;               
        this.LoadedAll();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B260 (11645536), len: 164  VirtAddr: 0x00B1B260 RVA: 0x00B1B260 token: 100694302 methodIndex: 24645 delegateWrapperIndex: 0 methodInvoker: 0
    private static void <StartCsDown>m__8(string name, byte[] abBytes)
    {
        //
        // Disasemble & Code
        // 0x00B1B260: STP x20, x19, [sp, #-0x20]! | stack[1152921515150212544] = ???;  stack[1152921515150212552] = ???;  //  dest_result_addr=1152921515150212544 |  dest_result_addr=1152921515150212552
        // 0x00B1B264: STP x29, x30, [sp, #0x10]  | stack[1152921515150212560] = ???;  stack[1152921515150212568] = ???;  //  dest_result_addr=1152921515150212560 |  dest_result_addr=1152921515150212568
        // 0x00B1B268: ADD x29, sp, #0x10         | X29 = (1152921515150212544 + 16) = 1152921515150212560 (0x10000002746EFDD0);
        // 0x00B1B26C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B1B270: LDRB w8, [x19, #0x6f7]     | W8 = (bool)static_value_037336F7;       
        // 0x00B1B274: TBNZ w8, #0, #0xb1b290     | if (static_value_037336F7 == true) goto label_0;
        // 0x00B1B278: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00B1B27C: LDR x8, [x8, #0x748]       | X8 = 0x2B8A724;                         
        // 0x00B1B280: LDR w0, [x8]               | W0 = 0x87;                              
        // 0x00B1B284: BL #0x2782188              | X0 = sub_2782188( ?? 0x87, ????);       
        // 0x00B1B288: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1B28C: STRB w8, [x19, #0x6f7]     | static_value_037336F7 = true;            //  dest_result_addr=57882359
        label_0:
        // 0x00B1B290: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B1B294: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B1B298: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00B1B29C: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B1B2A0: TBZ w8, #0, #0xb1b2b0      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1B2A4: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B1B2A8: CBNZ w8, #0xb1b2b0         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1B2AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00B1B2B0: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x00B1B2B4: LDR x8, [x8, #0x9b0]       | X8 = (string**)(1152921515150196384)("cs资源下载完成");
        // 0x00B1B2B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B2BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1B2C0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1B2C4: LDR x1, [x8]               | X1 = "cs资源下载完成";                        
        // 0x00B1B2C8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00B1B2CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B2D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B2D4: BL #0xdbd3cc               | X0 = LoadingBoardMgr.get_Instance();    
        LoadingBoardMgr val_1 = LoadingBoardMgr.Instance;
        // 0x00B1B2D8: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B1B2DC: CBNZ x19, #0xb1b2e4        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B1B2E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B1B2E4: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00B1B2E8: LDR x8, [x8, #0x4a0]       | X8 = (string**)(1152921510482740544)("Resources being processed...");
        // 0x00B1B2EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B2F0: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B1B2F4: LDR x1, [x8]               | X1 = "Resources being processed...";    
        // 0x00B1B2F8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B2FC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1B300: B #0xdbdc98                | val_1.SetDescri(value:  "Resources being processed..."); return;
        val_1.SetDescri(value:  "Resources being processed...");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B304 (11645700), len: 4  VirtAddr: 0x00B1B304 RVA: 0x00B1B304 token: 100694303 methodIndex: 24646 delegateWrapperIndex: 0 methodInvoker: 0
    private void <StartCsDown>m__9()
    {
        //
        // Disasemble & Code
        // 0x00B1B304: B #0xb1913c                | this.LoadedAll(); return;               
        this.LoadedAll();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B308 (11645704), len: 12  VirtAddr: 0x00B1B308 RVA: 0x00B1B308 token: 100694304 methodIndex: 24647 delegateWrapperIndex: 0 methodInvoker: 0
    private static void <LoadedAll>m__A()
    {
        //
        // Disasemble & Code
        // 0x00B1B308: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B30C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B310: B #0x20c6c2c               | UnityEngine.Application.Quit(); return; 
        UnityEngine.Application.Quit();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B314 (11645716), len: 720  VirtAddr: 0x00B1B314 RVA: 0x00B1B314 token: 100694305 methodIndex: 24648 delegateWrapperIndex: 0 methodInvoker: 0
    private void <RepairAsset>m__B(string name, byte[] abBytes)
    {
        //
        // Disasemble & Code
        //  | 
        Filelist<FileInfoRes> val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        // 0x00B1B314: STP x28, x27, [sp, #-0x60]! | stack[1152921515150675536] = ???;  stack[1152921515150675544] = ???;  //  dest_result_addr=1152921515150675536 |  dest_result_addr=1152921515150675544
        // 0x00B1B318: STP x26, x25, [sp, #0x10]  | stack[1152921515150675552] = ???;  stack[1152921515150675560] = ???;  //  dest_result_addr=1152921515150675552 |  dest_result_addr=1152921515150675560
        // 0x00B1B31C: STP x24, x23, [sp, #0x20]  | stack[1152921515150675568] = ???;  stack[1152921515150675576] = ???;  //  dest_result_addr=1152921515150675568 |  dest_result_addr=1152921515150675576
        // 0x00B1B320: STP x22, x21, [sp, #0x30]  | stack[1152921515150675584] = ???;  stack[1152921515150675592] = ???;  //  dest_result_addr=1152921515150675584 |  dest_result_addr=1152921515150675592
        // 0x00B1B324: STP x20, x19, [sp, #0x40]  | stack[1152921515150675600] = ???;  stack[1152921515150675608] = ???;  //  dest_result_addr=1152921515150675600 |  dest_result_addr=1152921515150675608
        // 0x00B1B328: STP x29, x30, [sp, #0x50]  | stack[1152921515150675616] = ???;  stack[1152921515150675624] = ???;  //  dest_result_addr=1152921515150675616 |  dest_result_addr=1152921515150675624
        // 0x00B1B32C: ADD x29, sp, #0x50         | X29 = (1152921515150675536 + 80) = 1152921515150675616 (0x1000000274760EA0);
        // 0x00B1B330: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1B334: LDRB w8, [x21, #0x6f8]     | W8 = (bool)static_value_037336F8;       
        // 0x00B1B338: MOV x20, x2                | X20 = abBytes;//m1                      
        // 0x00B1B33C: MOV x19, x0                | X19 = 1152921515150687632 (0x1000000274763D90);//ML01
        // 0x00B1B340: TBNZ w8, #0, #0xb1b35c     | if (static_value_037336F8 == true) goto label_0;
        // 0x00B1B344: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
        // 0x00B1B348: LDR x8, [x8, #0xda8]       | X8 = 0x2B8A720;                         
        // 0x00B1B34C: LDR w0, [x8]               | W0 = 0x86;                              
        // 0x00B1B350: BL #0x2782188              | X0 = sub_2782188( ?? 0x86, ????);       
        // 0x00B1B354: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1B358: STRB w8, [x21, #0x6f8]     | static_value_037336F8 = true;            //  dest_result_addr=57882360
        label_0:
        // 0x00B1B35C: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00B1B360: LDR x8, [x8, #0xbe0]       | X8 = 1152921515149397072;               
        // 0x00B1B364: LDR x2, [x8]               | X2 = public static Filelist<T> Filelist<FileInfoRes>::CreatFromBytes(byte[] bytes);
        // 0x00B1B368: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B36C: MOV x1, x20                | X1 = abBytes;//m1                       
        // 0x00B1B370: BL #0x19ccffc              | X0 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        Filelist<T> val_1 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        // 0x00B1B374: MOV x21, x0                | X21 = val_1;//m1                        
        val_13 = val_1;
        // 0x00B1B378: STR x21, [x19, #0x28]      | this.serverList = val_1;                 //  dest_result_addr=1152921515150687672
        this.serverList = val_13;
        // 0x00B1B37C: ADRP x23, #0x35fc000       | X23 = 56606720 (0x35FC000);             
        // 0x00B1B380: ADRP x24, #0x35bd000       | X24 = 56348672 (0x35BD000);             
        // 0x00B1B384: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x00B1B388: ADRP x26, #0x366d000       | X26 = 57069568 (0x366D000);             
        // 0x00B1B38C: ADRP x27, #0x35cc000       | X27 = 56410112 (0x35CC000);             
        // 0x00B1B390: LDR x23, [x23, #0xb58]     | X23 = 1152921510022759280;              
        // 0x00B1B394: LDR x24, [x24, #0xb50]     | X24 = 1152921510890998992;              
        // 0x00B1B398: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        // 0x00B1B39C: LDR x26, [x26, #0xc08]     | X26 = (string**)(1152921510473501152)("vsnum.uab");
        // 0x00B1B3A0: LDR x27, [x27, #0x7d8]     | X27 = 1152921514959025456;              
        // 0x00B1B3A4: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_14 = 0;
        // 0x00B1B3A8: B #0xb1b3b4                |  goto label_1;                          
        goto label_1;
        label_16:
        // 0x00B1B3AC: LDR x21, [x19, #0x28]      | X21 = this.serverList; //P2             
        val_13 = this.serverList;
        // 0x00B1B3B0: ADD w20, w20, #1           | W20 = (val_14 + 1) = val_14 (0x00000001);
        val_14 = 1;
        label_1:
        // 0x00B1B3B4: CBNZ x21, #0xb1b3bc        | if (this.serverList != null) goto label_2;
        if(val_13 != null)
        {
            goto label_2;
        }
        // 0x00B1B3B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B1B3BC: LDR x21, [x21, #0x10]      | 
        // 0x00B1B3C0: CBNZ x21, #0xb1b3c8        | if (this.serverList != null) goto label_3;
        if(val_13 != null)
        {
            goto label_3;
        }
        // 0x00B1B3C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B1B3C8: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B1B3CC: MOV x0, x21                | X0 = this.serverList;//m1               
        // 0x00B1B3D0: BL #0x25ed72c              | X0 = this.serverList.get_Count();       
        int val_2 = val_13.Count;
        // 0x00B1B3D4: CMP w20, w0                | STATE = COMPARE(0x1, val_2)             
        // 0x00B1B3D8: B.GE #0xb1b570             | if (val_14 >= val_2) goto label_4;      
        if(val_14 >= val_2)
        {
            goto label_4;
        }
        // 0x00B1B3DC: BL #0xb14978               | X0 = val_2.SavePath();                  
        string val_3 = val_2.SavePath();
        // 0x00B1B3E0: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B1B3E4: LDR x22, [x19, #0x28]      | X22 = this.serverList; //P2             
        // 0x00B1B3E8: CBNZ x22, #0xb1b3f0        | if (this.serverList != null) goto label_5;
        if(this.serverList != null)
        {
            goto label_5;
        }
        // 0x00B1B3EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B1B3F0: LDR x22, [x22, #0x10]      | 
        // 0x00B1B3F4: CBNZ x22, #0xb1b3fc        | if (this.serverList != null) goto label_6;
        if(this.serverList != null)
        {
            goto label_6;
        }
        // 0x00B1B3F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B1B3FC: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B1B400: MOV x0, x22                | X0 = this.serverList;//m1               
        // 0x00B1B404: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B1B408: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  1);
        string val_4 = this.serverList.Item[1];
        // 0x00B1B40C: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B1B410: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x00B1B414: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1B418: TBZ w8, #0, #0xb1b428      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B1B41C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1B420: CBNZ w8, #0xb1b428         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B1B424: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_8:
        // 0x00B1B428: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B42C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1B430: MOV x1, x21                | X1 = val_3;//m1                         
        // 0x00B1B434: MOV x2, x22                | X2 = val_4;//m1                         
        // 0x00B1B438: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_3);
        string val_5 = System.String.Concat(str0:  0, str1:  val_3);
        // 0x00B1B43C: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B1B440: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B444: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B448: MOV x1, x21                | X1 = val_5;//m1                         
        // 0x00B1B44C: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_6 = System.IO.File.Exists(path:  0);
        // 0x00B1B450: TBZ w0, #0, #0xb1b3ac      | if (val_6 == false) goto label_16;      
        if(val_6 == false)
        {
            goto label_16;
        }
        // 0x00B1B454: LDR w8, [x19, #0xb4]       | W8 = this.localAssetCount; //P2         
        int val_13 = this.localAssetCount;
        // 0x00B1B458: ADD w8, w8, #1             | W8 = (this.localAssetCount + 1);        
        val_13 = val_13 + 1;
        // 0x00B1B45C: STR w8, [x19, #0xb4]       | this.localAssetCount = (this.localAssetCount + 1);  //  dest_result_addr=1152921515150687812
        this.localAssetCount = val_13;
        // 0x00B1B460: CBNZ x21, #0xb1b468        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00B1B464: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_10:
        // 0x00B1B468: LDR x1, [x26]              | X1 = "vsnum.uab";                       
        // 0x00B1B46C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B470: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B1B474: BL #0x18ab0a0              | X0 = val_5.EndsWith(value:  "vsnum.uab");
        bool val_7 = val_5.EndsWith(value:  "vsnum.uab");
        // 0x00B1B478: AND w8, w0, #1             | W8 = (val_7 & 1);                       
        bool val_8 = val_7;
        // 0x00B1B47C: TBNZ w8, #0, #0xb1b3ac     | if ((val_7 & 1) == true) goto label_16; 
        if(val_8 == true)
        {
            goto label_16;
        }
        // 0x00B1B480: LDR x22, [x19, #0x28]      | X22 = this.serverList; //P2             
        // 0x00B1B484: CBNZ x22, #0xb1b48c        | if (this.serverList != null) goto label_12;
        if(this.serverList != null)
        {
            goto label_12;
        }
        // 0x00B1B488: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_12:
        // 0x00B1B48C: LDR x22, [x22, #0x18]      | 
        // 0x00B1B490: CBNZ x22, #0xb1b498        | if (this.serverList != null) goto label_13;
        if(this.serverList != null)
        {
            goto label_13;
        }
        // 0x00B1B494: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_13:
        // 0x00B1B498: LDR x2, [x27]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B1B49C: MOV x0, x22                | X0 = this.serverList;//m1               
        // 0x00B1B4A0: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B1B4A4: BL #0x25ed734              | X0 = this.serverList.get_Item(index:  1);
        FileInfoRes val_9 = this.serverList.Item[1];
        // 0x00B1B4A8: MOV x22, x0                | X22 = val_9;//m1                        
        // 0x00B1B4AC: CBNZ x22, #0xb1b4b4        | if (val_9 != null) goto label_14;       
        if(val_9 != null)
        {
            goto label_14;
        }
        // 0x00B1B4B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_14:
        // 0x00B1B4B4: LDR x2, [x22, #0x18]       | X2 = val_9.mDataMD5; //P2               
        // 0x00B1B4B8: MOV x1, x21                | X1 = val_5;//m1                         
        // 0x00B1B4BC: BL #0xb1a2a4               | X0 = val_9.LocalVerifyMD5(fullPath:  val_5, md5:  val_9.mDataMD5);
        bool val_10 = val_9.LocalVerifyMD5(fullPath:  val_5, md5:  val_9.mDataMD5);
        // 0x00B1B4C0: AND w8, w0, #1             | W8 = (val_10 & 1);                      
        bool val_11 = val_10;
        // 0x00B1B4C4: TBNZ w8, #0, #0xb1b3ac     | if ((val_10 & 1) == true) goto label_16;
        if(val_11 == true)
        {
            goto label_16;
        }
        // 0x00B1B4C8: LDR w8, [x19, #0xb8]       | W8 = this.errorAssetCount; //P2         
        int val_14 = this.errorAssetCount;
        // 0x00B1B4CC: ADD w8, w8, #1             | W8 = (this.errorAssetCount + 1);        
        val_14 = val_14 + 1;
        // 0x00B1B4D0: STR w8, [x19, #0xb8]       | this.errorAssetCount = (this.errorAssetCount + 1);  //  dest_result_addr=1152921515150687816
        this.errorAssetCount = val_14;
        // 0x00B1B4D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B4D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B4DC: MOV x1, x21                | X1 = val_5;//m1                         
        // 0x00B1B4E0: BL #0x1e6a550              | System.IO.File.Delete(path:  0);        
        System.IO.File.Delete(path:  0);
        // 0x00B1B4E4: B #0xb1b3ac                |  goto label_16;                         
        goto label_16;
        label_19:
        // 0x00B1B4E8: MOV x20, x0                | X20 = 0 (0x0);//ML01                    
        val_16 = 0;
        // 0x00B1B4EC: CMP w1, #1                 | STATE = COMPARE(val_5, 0x1)             
        // 0x00B1B4F0: B.NE #0xb1b5d8             | if (val_5 != 0x1) goto label_17;        
        if(val_5 != 1)
        {
            goto label_17;
        }
        // 0x00B1B4F4: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B4F8: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
        // 0x00B1B4FC: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
        val_15 = val_16;
        // 0x00B1B500: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B1B504: LDR x20, [x21]             | X20 = 0x10102464C457F;                  
        // 0x00B1B508: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
        // 0x00B1B50C: LDR x1, [x20]              | X1 = mem[282584257676671];              
        // 0x00B1B510: LDR x0, [x8]               | X0 = typeof(System.Exception);          
        // 0x00B1B514: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
        // 0x00B1B518: TBZ w0, #0, #0xb1b5ac      | if ((typeof(System.Exception) & 0x1) == 0) goto label_18;
        if((null & 1) == 0)
        {
            goto label_18;
        }
        // 0x00B1B51C: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
        // 0x00B1B520: BL #0xb14978               | X0 = SavePath();                        
        string val_12 = SavePath();
        // 0x00B1B524: MOV x1, x0                 | X1 = val_12;//m1                        
        // 0x00B1B528: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B52C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1B530: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1B534: BL #0x1e6a8e0              | System.IO.Directory.Delete(path:  0, recursive:  val_12);
        System.IO.Directory.Delete(path:  0, recursive:  val_12);
        // 0x00B1B538: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
        // 0x00B1B53C: STR w8, [x19, #0xb8]       | this.errorAssetCount = 0;                //  dest_result_addr=1152921515150687816
        this.errorAssetCount = 0;
        // 0x00B1B540: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B1B544: LDR x8, [x8, #0x40]        | X8 = (string**)(1152921515150663552)("0.0.0");
        // 0x00B1B548: MOV x0, x19                | X0 = 1152921515150687632 (0x1000000274763D90);//ML01
        // 0x00B1B54C: LDR x8, [x8]               | X8 = "0.0.0";                           
        // 0x00B1B550: STR x8, [x19, #0x58]       | this.clientVer = "0.0.0";                //  dest_result_addr=1152921515150687720
        this.clientVer = "0.0.0";
        // 0x00B1B554: BL #0xb1972c               | this.WriteClientVer();                  
        this.WriteClientVer();
        // 0x00B1B558: MOV x0, x19                | X0 = 1152921515150687632 (0x1000000274763D90);//ML01
        // 0x00B1B55C: BL #0xb1a014               | this.RepairAssetShowDialog();           
        this.RepairAssetShowDialog();
        // 0x00B1B560: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B564: MOV x0, x20                | X0 = 282584257676671 (0x10102464C457F);//ML01
        // 0x00B1B568: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10102464C457F, ????);
        // 0x00B1B56C: BL #0xb1b5e4               | ABCheckUpdate.<RepairAssetShowDialog>m__C();
        ABCheckUpdate.<RepairAssetShowDialog>m__C();
        label_4:
        // 0x00B1B570: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B1B574: LDR x8, [x8, #0x40]        | X8 = (string**)(1152921515150663552)("0.0.0");
        // 0x00B1B578: LDR x8, [x8]               | X8 = "0.0.0";                           
        // 0x00B1B57C: STR x8, [x19, #0x58]       | this.clientVer = "0.0.0";                //  dest_result_addr=1152921515150687720
        this.clientVer = "0.0.0";
        // 0x00B1B580: MOV x0, x19                | X0 = 1152921515150687632 (0x1000000274763D90);//ML01
        // 0x00B1B584: BL #0xb1972c               | this.WriteClientVer();                  
        this.WriteClientVer();
        // 0x00B1B588: MOV x0, x19                | X0 = 1152921515150687632 (0x1000000274763D90);//ML01
        // 0x00B1B58C: BL #0xb1a014               | this.RepairAssetShowDialog();           
        this.RepairAssetShowDialog();
        // 0x00B1B590: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B594: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1B598: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1B59C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1B5A0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1B5A4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B1B5A8: RET                        |  return;                                
        return;
        label_18:
        // 0x00B1B5AC: ORR w0, wzr, #8            | W0 = 8(0x8);                            
        // 0x00B1B5B0: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
        // 0x00B1B5B4: LDR x8, [x21]              | X8 = 0x10102464C457F;                   
        // 0x00B1B5B8: STR x8, [x0]               | mem[8] = 0x10102464C457F;                //  dest_result_addr=8
        mem[8] = 1179403647;
        // 0x00B1B5BC: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
        // 0x00B1B5C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B5C4: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
        // 0x00B1B5C8: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
        // 0x00B1B5CC: B #0xb1b4e8                |  goto label_19;                         
        goto label_19;
        // 0x00B1B5D0: MOV x20, x0                | X20 = 8 (0x8);//ML01                    
        val_16 = 8;
        // 0x00B1B5D4: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
        label_17:
        // 0x00B1B5D8: MOV x0, x20                | X0 = 8 (0x8);//ML01                     
        // 0x00B1B5DC: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
        // 0x00B1B5E0: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B5E4 (11646436), len: 12  VirtAddr: 0x00B1B5E4 RVA: 0x00B1B5E4 token: 100694306 methodIndex: 24649 delegateWrapperIndex: 0 methodInvoker: 0
    private static void <RepairAssetShowDialog>m__C()
    {
        //
        // Disasemble & Code
        // 0x00B1B5E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B5E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B5EC: B #0x20c6c2c               | UnityEngine.Application.Quit(); return; 
        UnityEngine.Application.Quit();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B5F0 (11646448), len: 480  VirtAddr: 0x00B1B5F0 RVA: 0x00B1B5F0 token: 100694307 methodIndex: 24650 delegateWrapperIndex: 0 methodInvoker: 0
    private void <LoadAllVSCfg>m__D()
    {
        //
        // Disasemble & Code
        // 0x00B1B5F0: STP x24, x23, [sp, #-0x40]! | stack[1152921515151027568] = ???;  stack[1152921515151027576] = ???;  //  dest_result_addr=1152921515151027568 |  dest_result_addr=1152921515151027576
        // 0x00B1B5F4: STP x22, x21, [sp, #0x10]  | stack[1152921515151027584] = ???;  stack[1152921515151027592] = ???;  //  dest_result_addr=1152921515151027584 |  dest_result_addr=1152921515151027592
        // 0x00B1B5F8: STP x20, x19, [sp, #0x20]  | stack[1152921515151027600] = ???;  stack[1152921515151027608] = ???;  //  dest_result_addr=1152921515151027600 |  dest_result_addr=1152921515151027608
        // 0x00B1B5FC: STP x29, x30, [sp, #0x30]  | stack[1152921515151027616] = ???;  stack[1152921515151027624] = ???;  //  dest_result_addr=1152921515151027616 |  dest_result_addr=1152921515151027624
        // 0x00B1B600: ADD x29, sp, #0x30         | X29 = (1152921515151027568 + 48) = 1152921515151027616 (0x10000002747B6DA0);
        // 0x00B1B604: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1B608: LDRB w8, [x20, #0x6f9]     | W8 = (bool)static_value_037336F9;       
        // 0x00B1B60C: MOV x19, x0                | X19 = 1152921515151039632 (0x10000002747B9C90);//ML01
        // 0x00B1B610: TBNZ w8, #0, #0xb1b62c     | if (static_value_037336F9 == true) goto label_0;
        // 0x00B1B614: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
        // 0x00B1B618: LDR x8, [x8, #0x190]       | X8 = 0x2B8A704;                         
        // 0x00B1B61C: LDR w0, [x8]               | W0 = 0x7F;                              
        // 0x00B1B620: BL #0x2782188              | X0 = sub_2782188( ?? 0x7F, ????);       
        // 0x00B1B624: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1B628: STRB w8, [x20, #0x6f9]     | static_value_037336F9 = true;            //  dest_result_addr=57882361
        label_0:
        // 0x00B1B62C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B634: BL #0xdbd3cc               | X0 = LoadingBoardMgr.get_Instance();    
        LoadingBoardMgr val_1 = LoadingBoardMgr.Instance;
        // 0x00B1B638: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B1B63C: CBNZ x20, #0xb1b644        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00B1B640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B1B644: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B1B648: LDR x8, [x8, #0x670]       | X8 = (string**)(1152921510483941840)("Downloading...");
        // 0x00B1B64C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1B650: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B1B654: LDR x1, [x8]               | X1 = "Downloading...";                  
        // 0x00B1B658: BL #0xdbdc98               | val_1.SetDescri(value:  "Downloading...");
        val_1.SetDescri(value:  "Downloading...");
        // 0x00B1B65C: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00B1B660: LDR x8, [x8, #0x288]       | X8 = 1152921504911106048;               
        // 0x00B1B664: LDR x0, [x8]               | X0 = typeof(HttpDownLoad);              
        HttpDownLoad val_2 = null;
        // 0x00B1B668: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(HttpDownLoad), ????);
        // 0x00B1B66C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B670: MOV x20, x0                | X20 = 1152921504911106048 (0x100000001222A000);//ML01
        // 0x00B1B674: BL #0x28a33dc              | .ctor();                                
        val_2 = new HttpDownLoad();
        // 0x00B1B678: STR x20, [x19, #0x40]      | this.httpDownLoad = typeof(HttpDownLoad);  //  dest_result_addr=1152921515151039696
        this.httpDownLoad = val_2;
        // 0x00B1B67C: CBNZ x20, #0xb1b684        | if ( != 0) goto label_2;                
        if(null != 0)
        {
            goto label_2;
        }
        // 0x00B1B680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00B1B684: MOVZ w8, #0x5              | W8 = 5 (0x5);//ML01                     
        // 0x00B1B688: STR w8, [x20, #0x14]       | typeof(HttpDownLoad).__il2cppRuntimeField_14 = 0x5;  //  dest_result_addr=1152921504911106068
        typeof(HttpDownLoad).__il2cppRuntimeField_14 = 5;
        // 0x00B1B68C: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B1B690: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B1B694: LDR x20, [x19, #0x40]      | X20 = this.httpDownLoad; //P2           
        // 0x00B1B698: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B1B69C: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B1B6A0: TBZ w8, #0, #0xb1b6b0      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B1B6A4: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B1B6A8: CBNZ w8, #0xb1b6b0         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B1B6AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_4:
        // 0x00B1B6B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B6B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B6B8: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_3 = VersionMgr.Instance;
        // 0x00B1B6BC: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B1B6C0: CBNZ x21, #0xb1b6c8        | if (val_3 != null) goto label_5;        
        if(val_3 != null)
        {
            goto label_5;
        }
        // 0x00B1B6C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B1B6C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B6CC: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B1B6D0: BL #0xe27dac               | X0 = val_3.get_currentVS();             
        VersionInfo val_4 = val_3.currentVS;
        // 0x00B1B6D4: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00B1B6D8: CBNZ x21, #0xb1b6e0        | if (val_4 != null) goto label_6;        
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00B1B6DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x00B1B6E0: LDR x21, [x21, #0x38]      | X21 = val_4.pkgurl; //P2                
        // 0x00B1B6E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B6E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B6EC: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_5 = VersionMgr.Instance;
        // 0x00B1B6F0: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00B1B6F4: CBNZ x22, #0xb1b6fc        | if (val_5 != null) goto label_7;        
        if(val_5 != null)
        {
            goto label_7;
        }
        // 0x00B1B6F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00B1B6FC: LDR x22, [x22, #0x28]      | X22 = val_5.pkgSavePath; //P2           
        // 0x00B1B700: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B704: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B708: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_6 = VersionMgr.Instance;
        // 0x00B1B70C: MOV x23, x0                | X23 = val_6;//m1                        
        // 0x00B1B710: CBNZ x23, #0xb1b718        | if (val_6 != null) goto label_8;        
        if(val_6 != null)
        {
            goto label_8;
        }
        // 0x00B1B714: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_8:
        // 0x00B1B718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B71C: MOV x0, x23                | X0 = val_6;//m1                         
        // 0x00B1B720: BL #0xe27dac               | X0 = val_6.get_currentVS();             
        VersionInfo val_7 = val_6.currentVS;
        // 0x00B1B724: MOV x23, x0                | X23 = val_7;//m1                        
        // 0x00B1B728: CBNZ x23, #0xb1b730        | if (val_7 != null) goto label_9;        
        if(val_7 != null)
        {
            goto label_9;
        }
        // 0x00B1B72C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00B1B730: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1B734: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1B738: LDR x23, [x23, #0x28]      | X23 = val_7.pkgmd5; //P2                
        // 0x00B1B73C: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B1B740: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1B744: TBZ w8, #0, #0xb1b754      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B1B748: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1B74C: CBNZ w8, #0xb1b754         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B1B750: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_11:
        // 0x00B1B754: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B758: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1B75C: MOV x1, x22                | X1 = val_5.pkgSavePath;//m1             
        // 0x00B1B760: MOV x2, x23                | X2 = val_7.pkgmd5;//m1                  
        // 0x00B1B764: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_5.pkgSavePath);
        string val_8 = System.String.Concat(str0:  0, str1:  val_5.pkgSavePath);
        // 0x00B1B768: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B1B76C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B1B770: LDR x8, [x8, #0x7f8]       | X8 = 1152921515151014608;               
        // 0x00B1B774: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B1B778: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00B1B77C: LDR x24, [x8]              | X24 = System.Void ABCheckUpdate::OnDownLoadAPK();
        // 0x00B1B780: LDR x8, [x9]               | X8 = typeof(System.Action);             
        // 0x00B1B784: MOV x0, x8                 | X0 = 1152921504687837184 (0x1000000004D3D000);//ML01
        System.Action val_9 = null;
        // 0x00B1B788: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B1B78C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1B790: MOV x1, x19                | X1 = 1152921515151039632 (0x10000002747B9C90);//ML01
        // 0x00B1B794: MOV x2, x24                | X2 = 1152921515151014608 (0x10000002747B3AD0);//ML01
        // 0x00B1B798: MOV x23, x0                | X23 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1B79C: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ABCheckUpdate::OnDownLoadAPK());
        val_9 = new System.Action(object:  this, method:  System.Void ABCheckUpdate::OnDownLoadAPK());
        // 0x00B1B7A0: CBNZ x20, #0xb1b7a8        | if (this.httpDownLoad != null) goto label_12;
        if(this.httpDownLoad != null)
        {
            goto label_12;
        }
        // 0x00B1B7A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void ABCheckUpdate::OnDownLoadAPK()), ????);
        label_12:
        // 0x00B1B7A8: MOV x0, x20                | X0 = this.httpDownLoad;//m1             
        // 0x00B1B7AC: MOV x1, x21                | X1 = val_4.pkgurl;//m1                  
        // 0x00B1B7B0: MOV x2, x22                | X2 = val_8;//m1                         
        // 0x00B1B7B4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B7B8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1B7BC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1B7C0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B1B7C4: MOV x3, x23                | X3 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1B7C8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B1B7CC: B #0x28a3410               | this.httpDownLoad.DownLoad(url:  val_4.pkgurl, saveFullPath:  val_8, callBack:  val_9); return;
        this.httpDownLoad.DownLoad(url:  val_4.pkgurl, saveFullPath:  val_8, callBack:  val_9);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B7D0 (11646928), len: 12  VirtAddr: 0x00B1B7D0 RVA: 0x00B1B7D0 token: 100694308 methodIndex: 24651 delegateWrapperIndex: 0 methodInvoker: 0
    private static void <LoadAllVSCfg>m__E()
    {
        //
        // Disasemble & Code
        // 0x00B1B7D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B7D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1B7D8: B #0x20c6c2c               | UnityEngine.Application.Quit(); return; 
        UnityEngine.Application.Quit();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1B7DC (11646940), len: 112  VirtAddr: 0x00B1B7DC RVA: 0x00B1B7DC token: 100694309 methodIndex: 24652 delegateWrapperIndex: 0 methodInvoker: 0
    private void <LoadClientVS>m__F(string name1, byte[] abBytes1)
    {
        //
        // Disasemble & Code
        // 0x00B1B7DC: STP x22, x21, [sp, #-0x30]! | stack[1152921515151341696] = ???;  stack[1152921515151341704] = ???;  //  dest_result_addr=1152921515151341696 |  dest_result_addr=1152921515151341704
        // 0x00B1B7E0: STP x20, x19, [sp, #0x10]  | stack[1152921515151341712] = ???;  stack[1152921515151341720] = ???;  //  dest_result_addr=1152921515151341712 |  dest_result_addr=1152921515151341720
        // 0x00B1B7E4: STP x29, x30, [sp, #0x20]  | stack[1152921515151341728] = ???;  stack[1152921515151341736] = ???;  //  dest_result_addr=1152921515151341728 |  dest_result_addr=1152921515151341736
        // 0x00B1B7E8: ADD x29, sp, #0x20         | X29 = (1152921515151341696 + 32) = 1152921515151341728 (0x10000002748038A0);
        // 0x00B1B7EC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1B7F0: LDRB w8, [x21, #0x6fa]     | W8 = (bool)static_value_037336FA;       
        // 0x00B1B7F4: MOV x20, x2                | X20 = abBytes1;//m1                     
        // 0x00B1B7F8: MOV x19, x0                | X19 = 1152921515151353744 (0x1000000274806790);//ML01
        // 0x00B1B7FC: TBNZ w8, #0, #0xb1b818     | if (static_value_037336FA == true) goto label_0;
        // 0x00B1B800: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
        // 0x00B1B804: LDR x8, [x8, #0x470]       | X8 = 0x2B8A710;                         
        // 0x00B1B808: LDR w0, [x8]               | W0 = 0x82;                              
        // 0x00B1B80C: BL #0x2782188              | X0 = sub_2782188( ?? 0x82, ????);       
        // 0x00B1B810: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1B814: STRB w8, [x21, #0x6fa]     | static_value_037336FA = true;            //  dest_result_addr=57882362
        label_0:
        // 0x00B1B818: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00B1B81C: LDR x8, [x8, #0xbe0]       | X8 = 1152921515149397072;               
        // 0x00B1B820: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1B824: MOV x1, x20                | X1 = abBytes1;//m1                      
        // 0x00B1B828: LDR x2, [x8]               | X2 = public static Filelist<T> Filelist<FileInfoRes>::CreatFromBytes(byte[] bytes);
        // 0x00B1B82C: BL #0x19ccffc              | X0 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        Filelist<T> val_1 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        // 0x00B1B830: STR x0, [x19, #0x20]       | this.clientList = val_1;                 //  dest_result_addr=1152921515151353776
        this.clientList = val_1;
        // 0x00B1B834: STR x0, [x19, #0x30]       | this.clientPersistentList = val_1;       //  dest_result_addr=1152921515151353792
        this.clientPersistentList = val_1;
        // 0x00B1B838: MOV x0, x19                | X0 = 1152921515151353744 (0x1000000274806790);//ML01
        // 0x00B1B83C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1B840: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1B844: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1B848: B #0xb161c4                | this.LoadServerVS(); return;            
        this.LoadServerVS();
        return;
    
    }

}
