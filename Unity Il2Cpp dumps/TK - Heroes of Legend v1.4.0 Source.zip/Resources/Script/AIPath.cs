using UnityEngine;
[UnityEngine.RequireComponent] // 0x2859F54
[UnityEngine.AddComponentMenu] // 0x2859F54
public class AIPath : MonoBehaviour
{
    // Fields
    public uint AIId; //  0x00000018
    public float repathRate; //  0x0000001C
    public UnityEngine.Transform target; //  0x00000020
    public bool canSearch; //  0x00000028
    private bool _canMove; //  0x00000029
    public bool canMoveNextWaypoint; //  0x0000002A
    public float speed; //  0x0000002C
    public float turningSpeed; //  0x00000030
    public float slowdownDistance; //  0x00000034
    public float pickNextWaypointDist; //  0x00000038
    public float forwardLook; //  0x0000003C
    public float endReachedDistance; //  0x00000040
    public bool closestOnPathCheck; //  0x00000044
    protected float minMoveScale; //  0x00000048
    protected Seeker seeker; //  0x00000050
    public UnityEngine.Transform tr; //  0x00000058
    protected float lastRepath; //  0x00000060
    protected Pathfinding.Path path; //  0x00000068
    protected UnityEngine.CharacterController controller; //  0x00000070
    protected NavmeshController navController; //  0x00000078
    protected Pathfinding.RVO.RVOController rvoController; //  0x00000080
    protected UnityEngine.Rigidbody rigid; //  0x00000088
    protected int currentWaypointIndex; //  0x00000090
    protected bool targetReached; //  0x00000094
    protected bool canSearchAgain; //  0x00000095
    protected UnityEngine.Vector3 lastFoundWaypointPosition; //  0x00000098
    protected float lastFoundWaypointTime; //  0x000000A4
    private bool startHasRun; //  0x000000A8
    public bool IsSearchPathing; //  0x000000A9
    public UnityEngine.Vector3 targetPoint; //  0x000000AC
    protected UnityEngine.Vector3 targetDirection; //  0x000000B8
    
    // Properties
    public virtual bool canMove { get; set; }
    public bool TargetReached { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B241E0 (11682272), len: 100  VirtAddr: 0x00B241E0 RVA: 0x00B241E0 token: 100681718 methodIndex: 24741 delegateWrapperIndex: 0 methodInvoker: 0
    public AIPath()
    {
        //
        // Disasemble & Code
        // 0x00B241E0: ORR w8, wzr, #0x3f000000   | W8 = 1056964608(0x3F000000);            
        // 0x00B241E4: STR w8, [x0, #0x1c]        | this.repathRate = 0.5;                   //  dest_result_addr=1152921513114502828
        this.repathRate = 0.5f;
        // 0x00B241E8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B241EC: LDR q0, [x8, #0xaf0]       | Q0 = ;                                  
        // 0x00B241F0: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
        // 0x00B241F4: STR w8, [x0, #0x3c]        | this.forwardLook = 1;                    //  dest_result_addr=1152921513114502860
        this.forwardLook = 1f;
        // 0x00B241F8: MOVZ w8, #0x3e4c, lsl #16  | W8 = 1045168128 (0x3E4C0000);//ML01     
        // 0x00B241FC: MOVK w8, #0xcccd           | W8 = 1045220557 (0x3E4CCCCD);           
        // 0x00B24200: STR w8, [x0, #0x40]        | this.endReachedDistance = 0.2;           //  dest_result_addr=1152921513114502864
        this.endReachedDistance = 0.2f;
        // 0x00B24204: MOVZ w8, #0x3d4c, lsl #16  | W8 = 1028390912 (0x3D4C0000);//ML01     
        // 0x00B24208: MOVK w8, #0xcccd           | W8 = 1028443341 (0x3D4CCCCD);           
        // 0x00B2420C: STR w8, [x0, #0x48]        | this.minMoveScale = 0.05;                //  dest_result_addr=1152921513114502872
        this.minMoveScale = 0.05f;
        // 0x00B24210: MOVZ w8, #0xc61c, lsl #16  | W8 = 3323723776 (0xC61C0000);//ML01     
        // 0x00B24214: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00B24218: MOVK w8, #0x3c00           | W8 = 3323739136 (0xC61C3C00);           
        // 0x00B2421C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24220: STRB w9, [x0, #0x28]       | this.canSearch = true;                   //  dest_result_addr=1152921513114502840
        this.canSearch = true;
        // 0x00B24224: STRB w9, [x0, #0x29]       | this._canMove = true;                    //  dest_result_addr=1152921513114502841
        this._canMove = true;
        // 0x00B24228: STRB w9, [x0, #0x2a]       | this.canMoveNextWaypoint = true;         //  dest_result_addr=1152921513114502842
        this.canMoveNextWaypoint = true;
        // 0x00B2422C: STRB w9, [x0, #0x44]       | this.closestOnPathCheck = true;          //  dest_result_addr=1152921513114502868
        this.closestOnPathCheck = true;
        // 0x00B24230: STR w8, [x0, #0x60]        | this.lastRepath = -9999;                 //  dest_result_addr=1152921513114502896
        this.lastRepath = -9999f;
        // 0x00B24234: STRB w9, [x0, #0x95]       | this.canSearchAgain = true;              //  dest_result_addr=1152921513114502949
        this.canSearchAgain = true;
        // 0x00B24238: STUR q0, [x0, #0x2c]       | this.speed = ; this.turningSpeed = ; this.slowdownDistance = 0.6; this.pickNextWaypointDist = 2;  //  dest_result_addr=1152921513114502844 dest_result_addr=1152921513114502848 dest_result_addr=1152921513114502852 dest_result_addr=1152921513114502856
        this.speed = ;
        this.turningSpeed = ;
        this.slowdownDistance = 0.6f;
        this.pickNextWaypointDist = 2f;
        // 0x00B2423C: STR w8, [x0, #0xa4]        | this.lastFoundWaypointTime = -9999;      //  dest_result_addr=1152921513114502964
        this.lastFoundWaypointTime = -9999f;
        // 0x00B24240: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B24244 (11682372), len: 8  VirtAddr: 0x00B24244 RVA: 0x00B24244 token: 100681719 methodIndex: 24742 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual bool get_canMove()
    {
        //
        // Disasemble & Code
        // 0x00B24244: LDRB w0, [x0, #0x29]       | W0 = this._canMove; //P2                
        // 0x00B24248: RET                        |  return (System.Boolean)this._canMove;  
        return this._canMove;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2424C (11682380), len: 12  VirtAddr: 0x00B2424C RVA: 0x00B2424C token: 100681720 methodIndex: 24743 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void set_canMove(bool value)
    {
        //
        // Disasemble & Code
        // 0x00B2424C: AND w8, w1, #1             | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00B24250: STRB w8, [x0, #0x29]       | this._canMove = (value & 1);             //  dest_result_addr=1152921513114726841
        this._canMove = val_1;
        // 0x00B24254: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B24258 (11682392), len: 8  VirtAddr: 0x00B24258 RVA: 0x00B24258 token: 100681721 methodIndex: 24744 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_TargetReached()
    {
        //
        // Disasemble & Code
        // 0x00B24258: LDRB w0, [x0, #0x94]       | W0 = this.targetReached; //P2           
        // 0x00B2425C: RET                        |  return (System.Boolean)this.targetReached;
        return this.targetReached;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B24260 (11682400), len: 276  VirtAddr: 0x00B24260 RVA: 0x00B24260 token: 100681722 methodIndex: 24745 delegateWrapperIndex: 0 methodInvoker: 0
    protected virtual void Awake()
    {
        //
        // Disasemble & Code
        // 0x00B24260: STP x20, x19, [sp, #-0x20]! | stack[1152921513114971536] = ???;  stack[1152921513114971544] = ???;  //  dest_result_addr=1152921513114971536 |  dest_result_addr=1152921513114971544
        // 0x00B24264: STP x29, x30, [sp, #0x10]  | stack[1152921513114971552] = ???;  stack[1152921513114971560] = ???;  //  dest_result_addr=1152921513114971552 |  dest_result_addr=1152921513114971560
        // 0x00B24268: ADD x29, sp, #0x10         | X29 = (1152921513114971536 + 16) = 1152921513114971552 (0x10000001FB1FADA0);
        // 0x00B2426C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B24270: LDRB w8, [x20, #0x731]     | W8 = (bool)static_value_03733731;       
        // 0x00B24274: MOV x19, x0                | X19 = 1152921513114983568 (0x10000001FB1FDC90);//ML01
        // 0x00B24278: TBNZ w8, #0, #0xb24294     | if (static_value_03733731 == true) goto label_0;
        // 0x00B2427C: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
        // 0x00B24280: LDR x8, [x8, #0xc80]       | X8 = 0x2B8AB1C;                         
        // 0x00B24284: LDR w0, [x8]               | W0 = 0x185;                             
        // 0x00B24288: BL #0x2782188              | X0 = sub_2782188( ?? 0x185, ????);      
        // 0x00B2428C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B24290: STRB w8, [x20, #0x731]     | static_value_03733731 = true;            //  dest_result_addr=57882417
        label_0:
        // 0x00B24294: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B24298: LDR x8, [x8, #0x600]       | X8 = 1152921513114926800;               
        // 0x00B2429C: MOV x0, x19                | X0 = 1152921513114983568 (0x10000001FB1FDC90);//ML01
        // 0x00B242A0: LDR x1, [x8]               | X1 = public Seeker UnityEngine.Component::GetComponent<Seeker>();
        // 0x00B242A4: BL #0x23d5410              | X0 = this.GetComponent<Seeker>();       
        Seeker val_1 = this.GetComponent<Seeker>();
        // 0x00B242A8: STR x0, [x19, #0x50]       | this.seeker = val_1;                     //  dest_result_addr=1152921513114983648
        this.seeker = val_1;
        // 0x00B242AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B242B0: MOV x0, x19                | X0 = 1152921513114983568 (0x10000001FB1FDC90);//ML01
        // 0x00B242B4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_2 = this.transform;
        // 0x00B242B8: STR x0, [x19, #0x58]       | this.tr = val_2;                         //  dest_result_addr=1152921513114983656
        this.tr = val_2;
        // 0x00B242BC: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B242C0: LDR x8, [x8, #0xe38]       | X8 = 1152921513114936016;               
        // 0x00B242C4: MOV x0, x19                | X0 = 1152921513114983568 (0x10000001FB1FDC90);//ML01
        // 0x00B242C8: LDR x1, [x8]               | X1 = public UnityEngine.CharacterController UnityEngine.Component::GetComponent<UnityEngine.CharacterController>();
        // 0x00B242CC: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.CharacterController>();
        UnityEngine.CharacterController val_3 = this.GetComponent<UnityEngine.CharacterController>();
        // 0x00B242D0: STR x0, [x19, #0x70]       | this.controller = val_3;                 //  dest_result_addr=1152921513114983680
        this.controller = val_3;
        // 0x00B242D4: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B242D8: LDR x8, [x8, #0x7e0]       | X8 = 1152921513114941136;               
        // 0x00B242DC: MOV x0, x19                | X0 = 1152921513114983568 (0x10000001FB1FDC90);//ML01
        // 0x00B242E0: LDR x1, [x8]               | X1 = public NavmeshController UnityEngine.Component::GetComponent<NavmeshController>();
        // 0x00B242E4: BL #0x23d5410              | X0 = this.GetComponent<NavmeshController>();
        NavmeshController val_4 = this.GetComponent<NavmeshController>();
        // 0x00B242E8: STR x0, [x19, #0x78]       | this.navController = val_4;              //  dest_result_addr=1152921513114983688
        this.navController = val_4;
        // 0x00B242EC: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
        // 0x00B242F0: LDR x8, [x8, #0x5b8]       | X8 = 1152921513114946256;               
        // 0x00B242F4: MOV x0, x19                | X0 = 1152921513114983568 (0x10000001FB1FDC90);//ML01
        // 0x00B242F8: LDR x1, [x8]               | X1 = public Pathfinding.RVO.RVOController UnityEngine.Component::GetComponent<Pathfinding.RVO.RVOController>();
        // 0x00B242FC: BL #0x23d5410              | X0 = this.GetComponent<Pathfinding.RVO.RVOController>();
        Pathfinding.RVO.RVOController val_5 = this.GetComponent<Pathfinding.RVO.RVOController>();
        // 0x00B24300: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B24304: STR x20, [x19, #0x80]      | this.rvoController = val_5;              //  dest_result_addr=1152921513114983696
        this.rvoController = val_5;
        // 0x00B24308: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B2430C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B24310: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B24314: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B24318: TBZ w8, #0, #0xb24328      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B2431C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B24320: CBNZ w8, #0xb24328         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B24324: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B24328: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2432C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B24330: MOV x1, x20                | X1 = val_5;//m1                         
        // 0x00B24334: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B24338: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_5);
        bool val_6 = UnityEngine.Object.op_Inequality(x:  0, y:  val_5);
        // 0x00B2433C: TBZ w0, #0, #0xb24350      | if (val_6 == false) goto label_3;       
        if(val_6 == false)
        {
            goto label_3;
        }
        // 0x00B24340: LDR x20, [x19, #0x80]      | X20 = this.rvoController; //P2          
        // 0x00B24344: CBNZ x20, #0xb2434c        | if (this.rvoController != null) goto label_4;
        if(this.rvoController != null)
        {
            goto label_4;
        }
        // 0x00B24348: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_4:
        // 0x00B2434C: STRB wzr, [x20, #0x60]     | this.rvoController.enableRotation = false;  //  dest_result_addr=0
        this.rvoController.enableRotation = false;
        label_3:
        // 0x00B24350: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
        // 0x00B24354: LDR x8, [x8, #0x1b8]       | X8 = 1152921509973334064;               
        // 0x00B24358: MOV x0, x19                | X0 = 1152921513114983568 (0x10000001FB1FDC90);//ML01
        // 0x00B2435C: LDR x1, [x8]               | X1 = public UnityEngine.Rigidbody UnityEngine.Component::GetComponent<UnityEngine.Rigidbody>();
        // 0x00B24360: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Rigidbody>();
        UnityEngine.Rigidbody val_7 = this.GetComponent<UnityEngine.Rigidbody>();
        // 0x00B24364: STR x0, [x19, #0x88]       | this.rigid = val_7;                      //  dest_result_addr=1152921513114983704
        this.rigid = val_7;
        // 0x00B24368: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2436C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B24370: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B24374 (11682676), len: 20  VirtAddr: 0x00B24374 RVA: 0x00B24374 token: 100681723 methodIndex: 24746 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void Start()
    {
        //
        // Disasemble & Code
        // 0x00B24374: LDR x9, [x0]               | X9 = typeof(AIPath);                    
        // 0x00B24378: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2437C: STRB w8, [x0, #0xa8]       | this.startHasRun = true;                 //  dest_result_addr=1152921513115124408
        this.startHasRun = true;
        // 0x00B24380: LDP x2, x1, [x9, #0x190]   | X2 = typeof(AIPath).__il2cppRuntimeField_190; X1 = typeof(AIPath).__il2cppRuntimeField_198; //  | 
        // 0x00B24384: BR x2                      | goto typeof(AIPath).__il2cppRuntimeField_190;
        goto typeof(AIPath).__il2cppRuntimeField_190;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B24388 (11682696), len: 340  VirtAddr: 0x00B24388 RVA: 0x00B24388 token: 100681724 methodIndex: 24747 delegateWrapperIndex: 0 methodInvoker: 0
    protected virtual void OnEnable()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        OnPathDelegate val_6;
        // 0x00B24388: STP x24, x23, [sp, #-0x40]! | stack[1152921513115244656] = ???;  stack[1152921513115244664] = ???;  //  dest_result_addr=1152921513115244656 |  dest_result_addr=1152921513115244664
        // 0x00B2438C: STP x22, x21, [sp, #0x10]  | stack[1152921513115244672] = ???;  stack[1152921513115244680] = ???;  //  dest_result_addr=1152921513115244672 |  dest_result_addr=1152921513115244680
        // 0x00B24390: STP x20, x19, [sp, #0x20]  | stack[1152921513115244688] = ???;  stack[1152921513115244696] = ???;  //  dest_result_addr=1152921513115244688 |  dest_result_addr=1152921513115244696
        // 0x00B24394: STP x29, x30, [sp, #0x30]  | stack[1152921513115244704] = ???;  stack[1152921513115244712] = ???;  //  dest_result_addr=1152921513115244704 |  dest_result_addr=1152921513115244712
        // 0x00B24398: ADD x29, sp, #0x30         | X29 = (1152921513115244656 + 48) = 1152921513115244704 (0x10000001FB23D8A0);
        // 0x00B2439C: SUB sp, sp, #0x10          | SP = (1152921513115244656 - 16) = 1152921513115244640 (0x10000001FB23D860);
        // 0x00B243A0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B243A4: LDRB w8, [x20, #0x732]     | W8 = (bool)static_value_03733732;       
        // 0x00B243A8: MOV x19, x0                | X19 = 1152921513115256720 (0x10000001FB240790);//ML01
        // 0x00B243AC: TBNZ w8, #0, #0xb243c8     | if (static_value_03733732 == true) goto label_0;
        // 0x00B243B0: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x00B243B4: LDR x8, [x8, #0x9e0]       | X8 = 0x2B8ABD8;                         
        // 0x00B243B8: LDR w0, [x8]               | W0 = 0x1B4;                             
        // 0x00B243BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B4, ????);      
        // 0x00B243C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B243C4: STRB w8, [x20, #0x732]     | static_value_03733732 = true;            //  dest_result_addr=57882418
        label_0:
        // 0x00B243C8: LDR x9, [x19]              | X9 = typeof(AIPath);                    
        // 0x00B243CC: MOVZ w8, #0xc61c, lsl #16  | W8 = 3323723776 (0xC61C0000);//ML01     
        // 0x00B243D0: ORR w10, wzr, #1           | W10 = 1(0x1);                           
        // 0x00B243D4: MOVK w8, #0x3c00           | W8 = 3323739136 (0xC61C3C00);           
        // 0x00B243D8: STRB w10, [x19, #0x95]     | this.canSearchAgain = true;              //  dest_result_addr=1152921513115256869
        this.canSearchAgain = true;
        // 0x00B243DC: STR w8, [x19, #0x60]       | this.lastRepath = -9999;                 //  dest_result_addr=1152921513115256816
        this.lastRepath = -9999f;
        // 0x00B243E0: LDP x8, x1, [x9, #0x1d0]   | X8 = typeof(AIPath).__il2cppRuntimeField_1D0; X1 = typeof(AIPath).__il2cppRuntimeField_1D8; //  | 
        // 0x00B243E4: MOV x0, x19                | X0 = 1152921513115256720 (0x10000001FB240790);//ML01
        // 0x00B243E8: BLR x8                     | X0 = typeof(AIPath).__il2cppRuntimeField_1D0();
        // 0x00B243EC: LDRB w8, [x19, #0xa8]      | W8 = this.startHasRun; //P2             
        // 0x00B243F0: STP s0, s1, [x19, #0x98]   | this.lastFoundWaypointPosition = ;  mem[1152921513115256876] = ???;  //  dest_result_addr=1152921513115256872 |  dest_result_addr=1152921513115256876
        this.lastFoundWaypointPosition = new UnityEngine.Vector3();
        mem[1152921513115256876] = ???;
        // 0x00B243F4: STR s2, [x19, #0xa0]       | mem[1152921513115256880] = ???;          //  dest_result_addr=1152921513115256880
        mem[1152921513115256880] = ???;
        // 0x00B243F8: CBZ w8, #0xb244b0          | if (this.startHasRun == false) goto label_1;
        if(this.startHasRun == false)
        {
            goto label_1;
        }
        // 0x00B243FC: LDR x23, [x19, #0x50]      | X23 = this.seeker; //P2                 
        // 0x00B24400: CBNZ x23, #0xb24408        | if (this.seeker != null) goto label_2;  
        if(this.seeker != null)
        {
            goto label_2;
        }
        // 0x00B24404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x00B24408: ADRP x24, #0x35fa000       | X24 = 56598528 (0x35FA000);             
        // 0x00B2440C: LDR x8, [x19]              | X8 = typeof(AIPath);                    
        // 0x00B24410: LDR x20, [x23, #0x38]      | X20 = this.seeker.pathCallback; //P2    
        // 0x00B24414: LDR x24, [x24, #0x288]     | X24 = 1152921504836718592;              
        // 0x00B24418: LDR x21, [x8, #0x1c8]      | X21 = typeof(AIPath).__il2cppRuntimeField_1C8;
        // 0x00B2441C: LDR x0, [x24]              | X0 = typeof(OnPathDelegate);            
        OnPathDelegate val_1 = null;
        // 0x00B24420: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(OnPathDelegate), ????);
        // 0x00B24424: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B24428: MOV x1, x19                | X1 = 1152921513115256720 (0x10000001FB240790);//ML01
        // 0x00B2442C: MOV x2, x21                | X2 = typeof(AIPath).__il2cppRuntimeField_1C8;//m1
        // 0x00B24430: MOV x22, x0                | X22 = 1152921504836718592 (0x100000000DB39000);//ML01
        // 0x00B24434: BL #0xd1b25c               | .ctor(object:  this, method:  typeof(AIPath).__il2cppRuntimeField_1C8);
        val_1 = new OnPathDelegate(object:  this, method:  typeof(AIPath).__il2cppRuntimeField_1C8);
        // 0x00B24438: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2443C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B24440: MOV x1, x20                | X1 = this.seeker.pathCallback;//m1      
        // 0x00B24444: MOV x2, x22                | X2 = 1152921504836718592 (0x100000000DB39000);//ML01
        // 0x00B24448: BL #0x1c34bb4              | X0 = System.Delegate.Combine(a:  0, b:  this.seeker.pathCallback);
        System.Delegate val_2 = System.Delegate.Combine(a:  0, b:  this.seeker.pathCallback);
        // 0x00B2444C: MOV x20, x0                | X20 = val_2;//m1                        
        val_6 = val_2;
        // 0x00B24450: CBNZ x23, #0xb24458        | if (this.seeker != null) goto label_3;  
        if(this.seeker != null)
        {
            goto label_3;
        }
        // 0x00B24454: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00B24458: CBZ x20, #0xb24490         | if (val_2 == null) goto label_4;        
        if(val_6 == null)
        {
            goto label_4;
        }
        // 0x00B2445C: LDR x1, [x24]              | X1 = typeof(OnPathDelegate);            
        // 0x00B24460: LDR x8, [x20]              | X8 = typeof(System.Delegate);           
        // 0x00B24464: CMP x8, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(OnPathDelegate))
        // 0x00B24468: B.EQ #0xb24494             | if (typeof(System.Delegate) == null) goto label_5;
        if(null == null)
        {
            goto label_5;
        }
        // 0x00B2446C: LDR x0, [x8, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
        // 0x00B24470: ADD x8, sp, #8             | X8 = (1152921513115244640 + 8) = 1152921513115244648 (0x10000001FB23D868);
        // 0x00B24474: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
        // 0x00B24478: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921513115232720]
        // 0x00B2447C: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
        // 0x00B24480: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24484: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00B24488: ADD x0, sp, #8             | X0 = (1152921513115244640 + 8) = 1152921513115244648 (0x10000001FB23D868);
        // 0x00B2448C: BL #0x299a140              | 
        label_4:
        // 0x00B24490: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        val_6 = 0;
        label_5:
        // 0x00B24494: MOV x0, x19                | X0 = 1152921513115256720 (0x10000001FB240790);//ML01
        // 0x00B24498: STR x20, [x23, #0x38]      | this.seeker.pathCallback = null;         //  dest_result_addr=0
        this.seeker.pathCallback = val_6;
        // 0x00B2449C: BL #0xb244dc               | X0 = this.RepeatTrySearchPath();        
        System.Collections.IEnumerator val_4 = this.RepeatTrySearchPath();
        // 0x00B244A0: MOV x1, x0                 | X1 = val_4;//m1                         
        // 0x00B244A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B244A8: MOV x0, x19                | X0 = 1152921513115256720 (0x10000001FB240790);//ML01
        // 0x00B244AC: BL #0x1b772bc              | X0 = this.StartCoroutine(routine:  val_4);
        UnityEngine.Coroutine val_5 = this.StartCoroutine(routine:  val_4);
        label_1:
        // 0x00B244B0: SUB sp, x29, #0x30         | SP = (1152921513115244704 - 48) = 1152921513115244656 (0x10000001FB23D870);
        // 0x00B244B4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B244B8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B244BC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B244C0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B244C4: RET                        |  return;                                
        return;
        // 0x00B244C8: MOV x19, x0                | 
        // 0x00B244CC: ADD x0, sp, #8             | 
        // 0x00B244D0: BL #0x299a140              | 
        // 0x00B244D4: MOV x0, x19                | 
        // 0x00B244D8: BL #0x980800               | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B24548 (11683144), len: 424  VirtAddr: 0x00B24548 RVA: 0x00B24548 token: 100681725 methodIndex: 24748 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnDisable()
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        OnPathDelegate val_8;
        // 0x00B24548: STP x24, x23, [sp, #-0x40]! | stack[1152921513115409904] = ???;  stack[1152921513115409912] = ???;  //  dest_result_addr=1152921513115409904 |  dest_result_addr=1152921513115409912
        // 0x00B2454C: STP x22, x21, [sp, #0x10]  | stack[1152921513115409920] = ???;  stack[1152921513115409928] = ???;  //  dest_result_addr=1152921513115409920 |  dest_result_addr=1152921513115409928
        // 0x00B24550: STP x20, x19, [sp, #0x20]  | stack[1152921513115409936] = ???;  stack[1152921513115409944] = ???;  //  dest_result_addr=1152921513115409936 |  dest_result_addr=1152921513115409944
        // 0x00B24554: STP x29, x30, [sp, #0x30]  | stack[1152921513115409952] = ???;  stack[1152921513115409960] = ???;  //  dest_result_addr=1152921513115409952 |  dest_result_addr=1152921513115409960
        // 0x00B24558: ADD x29, sp, #0x30         | X29 = (1152921513115409904 + 48) = 1152921513115409952 (0x10000001FB265E20);
        // 0x00B2455C: SUB sp, sp, #0x10          | SP = (1152921513115409904 - 16) = 1152921513115409888 (0x10000001FB265DE0);
        // 0x00B24560: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B24564: LDRB w8, [x20, #0x733]     | W8 = (bool)static_value_03733733;       
        // 0x00B24568: MOV x19, x0                | X19 = 1152921513115421968 (0x10000001FB268D10);//ML01
        // 0x00B2456C: TBNZ w8, #0, #0xb24588     | if (static_value_03733733 == true) goto label_0;
        // 0x00B24570: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x00B24574: LDR x8, [x8, #0x920]       | X8 = 0x2B8ABD4;                         
        // 0x00B24578: LDR w0, [x8]               | W0 = 0x1B3;                             
        // 0x00B2457C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B3, ????);      
        // 0x00B24580: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B24584: STRB w8, [x20, #0x733]     | static_value_03733733 = true;            //  dest_result_addr=57882419
        label_0:
        // 0x00B24588: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B2458C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B24590: LDR x20, [x19, #0x50]      | X20 = this.seeker; //P2                 
        // 0x00B24594: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B24598: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B2459C: TBZ w8, #0, #0xb245ac      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B245A0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B245A4: CBNZ w8, #0xb245ac         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B245A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B245AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B245B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B245B4: MOV x1, x20                | X1 = this.seeker;//m1                   
        // 0x00B245B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B245BC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.seeker);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.seeker);
        // 0x00B245C0: TBZ w0, #0, #0xb24614      | if (val_1 == false) goto label_5;       
        if(val_1 == false)
        {
            goto label_5;
        }
        // 0x00B245C4: LDR x20, [x19, #0x50]      | X20 = this.seeker; //P2                 
        // 0x00B245C8: CBNZ x20, #0xb245d0        | if (this.seeker != null) goto label_4;  
        if(this.seeker != null)
        {
            goto label_4;
        }
        // 0x00B245CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B245D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B245D4: MOV x0, x20                | X0 = this.seeker;//m1                   
        // 0x00B245D8: BL #0xca5740               | X0 = this.seeker.IsDone();              
        bool val_2 = this.seeker.IsDone();
        // 0x00B245DC: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B245E0: TBNZ w8, #0, #0xb24614     | if ((val_2 & 1) == true) goto label_5;  
        if(val_3 == true)
        {
            goto label_5;
        }
        // 0x00B245E4: LDR x20, [x19, #0x50]      | X20 = this.seeker; //P2                 
        // 0x00B245E8: CBNZ x20, #0xb245f0        | if (this.seeker != null) goto label_6;  
        if(this.seeker != null)
        {
            goto label_6;
        }
        // 0x00B245EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B245F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B245F4: MOV x0, x20                | X0 = this.seeker;//m1                   
        // 0x00B245F8: BL #0xca4afc               | X0 = this.seeker.GetCurrentPath();      
        Pathfinding.Path val_4 = this.seeker.GetCurrentPath();
        // 0x00B245FC: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B24600: CBNZ x20, #0xb24608        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B24604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B24608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2460C: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B24610: BL #0x14035e8              | val_4.Error();                          
        val_4.Error();
        label_5:
        // 0x00B24614: LDR x0, [x19, #0x68]       | X0 = this.path; //P2                    
        // 0x00B24618: CBZ x0, #0xb24628          | if (this.path == null) goto label_8;    
        if(this.path == null)
        {
            goto label_8;
        }
        // 0x00B2461C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B24620: MOV x1, x19                | X1 = 1152921513115421968 (0x10000001FB268D10);//ML01
        // 0x00B24624: BL #0x1404008              | this.path.Release(o:  this);            
        this.path.Release(o:  this);
        label_8:
        // 0x00B24628: LDR x23, [x19, #0x50]      | X23 = this.seeker; //P2                 
        // 0x00B2462C: STR xzr, [x19, #0x68]      | this.path = null;                        //  dest_result_addr=1152921513115422072
        this.path = 0;
        // 0x00B24630: CBNZ x23, #0xb24638        | if (this.seeker != null) goto label_9;  
        if(this.seeker != null)
        {
            goto label_9;
        }
        // 0x00B24634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.path, ????);  
        label_9:
        // 0x00B24638: ADRP x24, #0x35fa000       | X24 = 56598528 (0x35FA000);             
        // 0x00B2463C: LDR x8, [x19]              | X8 = typeof(AIPath);                    
        // 0x00B24640: LDR x20, [x23, #0x38]      | X20 = this.seeker.pathCallback; //P2    
        // 0x00B24644: LDR x24, [x24, #0x288]     | X24 = 1152921504836718592;              
        // 0x00B24648: LDR x21, [x8, #0x1c8]      | X21 = typeof(AIPath).__il2cppRuntimeField_1C8;
        // 0x00B2464C: LDR x0, [x24]              | X0 = typeof(OnPathDelegate);            
        OnPathDelegate val_5 = null;
        // 0x00B24650: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(OnPathDelegate), ????);
        // 0x00B24654: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B24658: MOV x1, x19                | X1 = 1152921513115421968 (0x10000001FB268D10);//ML01
        // 0x00B2465C: MOV x2, x21                | X2 = typeof(AIPath).__il2cppRuntimeField_1C8;//m1
        // 0x00B24660: MOV x22, x0                | X22 = 1152921504836718592 (0x100000000DB39000);//ML01
        // 0x00B24664: BL #0xd1b25c               | .ctor(object:  this, method:  typeof(AIPath).__il2cppRuntimeField_1C8);
        val_5 = new OnPathDelegate(object:  this, method:  typeof(AIPath).__il2cppRuntimeField_1C8);
        // 0x00B24668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2466C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B24670: MOV x1, x20                | X1 = this.seeker.pathCallback;//m1      
        // 0x00B24674: MOV x2, x22                | X2 = 1152921504836718592 (0x100000000DB39000);//ML01
        // 0x00B24678: BL #0x1c34dc4              | X0 = System.Delegate.Remove(source:  0, value:  this.seeker.pathCallback);
        System.Delegate val_6 = System.Delegate.Remove(source:  0, value:  this.seeker.pathCallback);
        // 0x00B2467C: MOV x8, xzr                | X8 = 0 (0x0);//ML01                     
        val_8 = 0;
        // 0x00B24680: CBZ x0, #0xb246c0          | if (val_6 == null) goto label_11;       
        if(val_6 == null)
        {
            goto label_11;
        }
        // 0x00B24684: LDR x1, [x24]              | X1 = typeof(OnPathDelegate);            
        // 0x00B24688: LDR x9, [x0]               | X9 = typeof(System.Delegate);           
        // 0x00B2468C: CMP x9, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(OnPathDelegate))
        // 0x00B24690: MOV x8, x0                 | X8 = val_6;//m1                         
        val_8 = val_6;
        // 0x00B24694: B.EQ #0xb246c0             | if (typeof(System.Delegate) == null) goto label_11;
        if(null == null)
        {
            goto label_11;
        }
        // 0x00B24698: LDR x0, [x9, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
        // 0x00B2469C: ADD x8, sp, #8             | X8 = (1152921513115409888 + 8) = 1152921513115409896 (0x10000001FB265DE8);
        // 0x00B246A0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
        // 0x00B246A4: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921513115397968]
        // 0x00B246A8: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
        // 0x00B246AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B246B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        // 0x00B246B4: ADD x0, sp, #8             | X0 = (1152921513115409888 + 8) = 1152921513115409896 (0x10000001FB265DE8);
        // 0x00B246B8: BL #0x299a140              | 
        // 0x00B246BC: MOV x8, xzr                | X8 = 0 (0x0);//ML01                     
        val_8 = 0;
        label_11:
        // 0x00B246C0: STR x8, [x23, #0x38]       | this.seeker.pathCallback = null;         //  dest_result_addr=0
        this.seeker.pathCallback = val_8;
        // 0x00B246C4: SUB sp, x29, #0x30         | SP = (1152921513115409952 - 48) = 1152921513115409904 (0x10000001FB265DF0);
        // 0x00B246C8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B246CC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B246D0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B246D4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B246D8: RET                        |  return;                                
        return;
        // 0x00B246DC: MOV x19, x0                | 
        // 0x00B246E0: ADD x0, sp, #8             | 
        // 0x00B246E4: BL #0x299a140              | 
        // 0x00B246E8: MOV x0, x19                | 
        // 0x00B246EC: BL #0x980800               | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B244DC (11683036), len: 108  VirtAddr: 0x00B244DC RVA: 0x00B244DC token: 100681726 methodIndex: 24749 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x2859FDC
    protected System.Collections.IEnumerator RepeatTrySearchPath()
    {
        //
        // Disasemble & Code
        // 0x00B244DC: STP x20, x19, [sp, #-0x20]! | stack[1152921513115554704] = ???;  stack[1152921513115554712] = ???;  //  dest_result_addr=1152921513115554704 |  dest_result_addr=1152921513115554712
        // 0x00B244E0: STP x29, x30, [sp, #0x10]  | stack[1152921513115554720] = ???;  stack[1152921513115554728] = ???;  //  dest_result_addr=1152921513115554720 |  dest_result_addr=1152921513115554728
        // 0x00B244E4: ADD x29, sp, #0x10         | X29 = (1152921513115554704 + 16) = 1152921513115554720 (0x10000001FB2893A0);
        // 0x00B244E8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B244EC: LDRB w8, [x20, #0x734]     | W8 = (bool)static_value_03733734;       
        // 0x00B244F0: MOV x19, x0                | X19 = 1152921513115566736 (0x10000001FB28C290);//ML01
        // 0x00B244F4: TBNZ w8, #0, #0xb24510     | if (static_value_03733734 == true) goto label_0;
        // 0x00B244F8: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00B244FC: LDR x8, [x8, #0x180]       | X8 = 0x2B8ABE0;                         
        // 0x00B24500: LDR w0, [x8]               | W0 = 0x1B6;                             
        // 0x00B24504: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B6, ????);      
        // 0x00B24508: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2450C: STRB w8, [x20, #0x734]     | static_value_03733734 = true;            //  dest_result_addr=57882420
        label_0:
        // 0x00B24510: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00B24514: LDR x8, [x8, #0x678]       | X8 = 1152921504835280896;               
        // 0x00B24518: LDR x0, [x8]               | X0 = typeof(AIPath.<RepeatTrySearchPath>c__Iterator0);
        object val_1 = null;
        // 0x00B2451C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AIPath.<RepeatTrySearchPath>c__Iterator0), ????);
        // 0x00B24520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24524: MOV x20, x0                | X20 = 1152921504835280896 (0x100000000D9DA000);//ML01
        // 0x00B24528: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00B2452C: CBNZ x20, #0xb24534        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B24530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00B24534: STR x19, [x20, #0x18]      | typeof(AIPath.<RepeatTrySearchPath>c__Iterator0).__il2cppRuntimeField_18 = this;  //  dest_result_addr=1152921504835280920
        typeof(AIPath.<RepeatTrySearchPath>c__Iterator0).__il2cppRuntimeField_18 = this;
        // 0x00B24538: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2453C: MOV x0, x20                | X0 = 1152921504835280896 (0x100000000D9DA000);//ML01
        // 0x00B24540: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B24544: RET                        |  return (System.Collections.IEnumerator)typeof(AIPath.<RepeatTrySearchPath>c__Iterator0);
        return (System.Collections.IEnumerator)val_1;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B246F8 (11683576), len: 244  VirtAddr: 0x00B246F8 RVA: 0x00B246F8 token: 100681727 methodIndex: 24750 delegateWrapperIndex: 0 methodInvoker: 0
    public float TrySearchPath()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        float val_6;
        // 0x00B246F8: STP d9, d8, [sp, #-0x30]!  | stack[1152921513115670784] = ???;  stack[1152921513115670792] = ???;  //  dest_result_addr=1152921513115670784 |  dest_result_addr=1152921513115670792
        // 0x00B246FC: STP x20, x19, [sp, #0x10]  | stack[1152921513115670800] = ???;  stack[1152921513115670808] = ???;  //  dest_result_addr=1152921513115670800 |  dest_result_addr=1152921513115670808
        // 0x00B24700: STP x29, x30, [sp, #0x20]  | stack[1152921513115670816] = ???;  stack[1152921513115670824] = ???;  //  dest_result_addr=1152921513115670816 |  dest_result_addr=1152921513115670824
        // 0x00B24704: ADD x29, sp, #0x20         | X29 = (1152921513115670784 + 32) = 1152921513115670816 (0x10000001FB2A5920);
        // 0x00B24708: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B2470C: LDRB w8, [x20, #0x735]     | W8 = (bool)static_value_03733735;       
        // 0x00B24710: MOV x19, x0                | X19 = 1152921513115682832 (0x10000001FB2A8810);//ML01
        // 0x00B24714: TBNZ w8, #0, #0xb24730     | if (static_value_03733735 == true) goto label_0;
        // 0x00B24718: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00B2471C: LDR x8, [x8, #0xa68]       | X8 = 0x2B8ABF0;                         
        // 0x00B24720: LDR w0, [x8]               | W0 = 0x1BA;                             
        // 0x00B24724: BL #0x2782188              | X0 = sub_2782188( ?? 0x1BA, ????);      
        // 0x00B24728: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2472C: STRB w8, [x20, #0x735]     | static_value_03733735 = true;            //  dest_result_addr=57882421
        label_0:
        // 0x00B24730: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24738: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_1 = UnityEngine.Time.time;
        // 0x00B2473C: LDR s1, [x19, #0x60]       | S1 = this.lastRepath; //P2              
        // 0x00B24740: LDR s8, [x19, #0x1c]       | S8 = this.repathRate; //P2              
        val_6 = this.repathRate;
        // 0x00B24744: FSUB s0, s0, s1            | S0 = (val_1 - this.lastRepath);         
        val_1 = val_1 - this.lastRepath;
        // 0x00B24748: FCMP s0, s8                | STATE = COMPARE((val_1 - this.lastRepath), this.repathRate)
        // 0x00B2474C: B.LT #0xb247bc             | if (val_1 < val_6) goto label_3;        
        if(val_1 < val_6)
        {
            goto label_3;
        }
        // 0x00B24750: LDRB w8, [x19, #0x95]      | W8 = this.canSearchAgain; //P2          
        // 0x00B24754: CBZ w8, #0xb247bc          | if (this.canSearchAgain == false) goto label_3;
        if(this.canSearchAgain == false)
        {
            goto label_3;
        }
        // 0x00B24758: LDRB w8, [x19, #0x28]      | W8 = this.canSearch; //P2               
        // 0x00B2475C: CBZ w8, #0xb247bc          | if (this.canSearch == false) goto label_3;
        if(this.canSearch == false)
        {
            goto label_3;
        }
        // 0x00B24760: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B24764: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B24768: LDR x20, [x19, #0x20]      | X20 = this.target; //P2                 
        // 0x00B2476C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B24770: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B24774: TBZ w8, #0, #0xb24784      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B24778: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B2477C: CBNZ w8, #0xb24784         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B24780: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x00B24784: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24788: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2478C: MOV x1, x20                | X1 = this.target;//m1                   
        // 0x00B24790: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B24794: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.target);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.target);
        // 0x00B24798: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B2479C: TBZ w8, #0, #0xb247b8      | if ((val_2 & 1) == false) goto label_6; 
        if(val_3 == false)
        {
            goto label_6;
        }
        // 0x00B247A0: LDR x8, [x19]              | X8 = typeof(AIPath);                    
        // 0x00B247A4: MOV x0, x19                | X0 = 1152921513115682832 (0x10000001FB2A8810);//ML01
        // 0x00B247A8: LDP x9, x1, [x8, #0x1a0]   | X9 = typeof(AIPath).__il2cppRuntimeField_1A0; X1 = typeof(AIPath).__il2cppRuntimeField_1A8; //  | 
        // 0x00B247AC: BLR x9                     | X0 = typeof(AIPath).__il2cppRuntimeField_1A0();
        // 0x00B247B0: LDR s0, [x19, #0x1c]       | S0 = this.repathRate; //P2              
        // 0x00B247B4: B #0xb247dc                |  goto label_7;                          
        goto label_7;
        label_6:
        // 0x00B247B8: LDR s8, [x19, #0x1c]       | S8 = this.repathRate; //P2              
        val_6 = this.repathRate;
        label_3:
        // 0x00B247BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B247C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B247C4: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_4 = UnityEngine.Time.time;
        // 0x00B247C8: LDR s1, [x19, #0x60]       | S1 = this.lastRepath; //P2              
        // 0x00B247CC: FSUB s0, s0, s1            | S0 = (val_4 - this.lastRepath);         
        val_4 = val_4 - this.lastRepath;
        // 0x00B247D0: FSUB s0, s8, s0            | S0 = (this.repathRate - (val_4 - this.lastRepath));
        val_4 = val_6 - val_4;
        // 0x00B247D4: FMOV s1, wzr               | S1 = 0f;                                
        // 0x00B247D8: FMAX s0, s0, s1            | 
        label_7:
        // 0x00B247DC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B247E0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B247E4: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B247E8: RET                        |  return (System.Single)(this.repathRate - (val_4 - this.lastRepath));
        return (float)val_4;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B247EC (11683820), len: 384  VirtAddr: 0x00B247EC RVA: 0x00B247EC token: 100681728 methodIndex: 24751 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual Pathfinding.Path SearchPath()
    {
        //
        // Disasemble & Code
        // 0x00B247EC: STP d13, d12, [sp, #-0x50]! | stack[1152921513115804352] = ???;  stack[1152921513115804360] = ???;  //  dest_result_addr=1152921513115804352 |  dest_result_addr=1152921513115804360
        // 0x00B247F0: STP d11, d10, [sp, #0x10]  | stack[1152921513115804368] = ???;  stack[1152921513115804376] = ???;  //  dest_result_addr=1152921513115804368 |  dest_result_addr=1152921513115804376
        // 0x00B247F4: STP d9, d8, [sp, #0x20]    | stack[1152921513115804384] = ???;  stack[1152921513115804392] = ???;  //  dest_result_addr=1152921513115804384 |  dest_result_addr=1152921513115804392
        // 0x00B247F8: STP x20, x19, [sp, #0x30]  | stack[1152921513115804400] = ???;  stack[1152921513115804408] = ???;  //  dest_result_addr=1152921513115804400 |  dest_result_addr=1152921513115804408
        // 0x00B247FC: STP x29, x30, [sp, #0x40]  | stack[1152921513115804416] = ???;  stack[1152921513115804424] = ???;  //  dest_result_addr=1152921513115804416 |  dest_result_addr=1152921513115804424
        // 0x00B24800: ADD x29, sp, #0x40         | X29 = (1152921513115804352 + 64) = 1152921513115804416 (0x10000001FB2C6300);
        // 0x00B24804: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B24808: LDRB w8, [x20, #0x736]     | W8 = (bool)static_value_03733736;       
        // 0x00B2480C: MOV x19, x0                | X19 = 1152921513115816432 (0x10000001FB2C91F0);//ML01
        // 0x00B24810: TBNZ w8, #0, #0xb2482c     | if (static_value_03733736 == true) goto label_0;
        // 0x00B24814: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00B24818: LDR x8, [x8, #0x8f0]       | X8 = 0x2B8ABE8;                         
        // 0x00B2481C: LDR w0, [x8]               | W0 = 0x1B8;                             
        // 0x00B24820: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B8, ????);      
        // 0x00B24824: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B24828: STRB w8, [x20, #0x736]     | static_value_03733736 = true;            //  dest_result_addr=57882422
        label_0:
        // 0x00B2482C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B24830: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B24834: LDR x20, [x19, #0x20]      | X20 = this.target; //P2                 
        // 0x00B24838: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B2483C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B24840: TBZ w8, #0, #0xb24850      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B24844: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B24848: CBNZ w8, #0xb24850         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B2484C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B24850: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24854: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B24858: MOV x1, x20                | X1 = this.target;//m1                   
        // 0x00B2485C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B24860: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.target);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.target);
        // 0x00B24864: TBNZ w0, #0, #0xb2492c     | if (val_1 == true) goto label_3;        
        if(val_1 == true)
        {
            goto label_3;
        }
        // 0x00B24868: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2486C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24870: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_2 = UnityEngine.Time.time;
        // 0x00B24874: LDR x20, [x19, #0x20]      | X20 = this.target; //P2                 
        // 0x00B24878: STR s0, [x19, #0x60]       | this.lastRepath = val_2;                 //  dest_result_addr=1152921513115816528
        this.lastRepath = val_2;
        // 0x00B2487C: CBNZ x20, #0xb24884        | if (this.target != null) goto label_4;  
        if(this.target != null)
        {
            goto label_4;
        }
        // 0x00B24880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_4:
        // 0x00B24884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24888: MOV x0, x20                | X0 = this.target;//m1                   
        // 0x00B2488C: BL #0x2693510              | X0 = this.target.get_position();        
        UnityEngine.Vector3 val_3 = this.target.position;
        // 0x00B24890: LDR x8, [x19]              | X8 = typeof(AIPath);                    
        // 0x00B24894: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00B24898: STRB w9, [x19, #0xa9]      | this.IsSearchPathing = true;             //  dest_result_addr=1152921513115816601
        this.IsSearchPathing = true;
        // 0x00B2489C: STRB wzr, [x19, #0x95]     | this.canSearchAgain = false;             //  dest_result_addr=1152921513115816581
        this.canSearchAgain = false;
        // 0x00B248A0: LDR x20, [x19, #0x50]      | X20 = this.seeker; //P2                 
        // 0x00B248A4: LDP x9, x1, [x8, #0x1d0]   | X9 = typeof(AIPath).__il2cppRuntimeField_1D0; X1 = typeof(AIPath).__il2cppRuntimeField_1D8; //  | 
        // 0x00B248A8: MOV x0, x19                | X0 = 1152921513115816432 (0x10000001FB2C91F0);//ML01
        // 0x00B248AC: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        // 0x00B248B0: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x00B248B4: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
        // 0x00B248B8: BLR x9                     | X0 = typeof(AIPath).__il2cppRuntimeField_1D0();
        // 0x00B248BC: MOV v11.16b, v0.16b        | V11 = val_3.x;//m1                      
        // 0x00B248C0: MOV v12.16b, v1.16b        | V12 = val_3.y;//m1                      
        // 0x00B248C4: MOV v13.16b, v2.16b        | V13 = val_3.z;//m1                      
        // 0x00B248C8: CBNZ x20, #0xb248d0        | if (this.seeker != null) goto label_5;  
        if(this.seeker != null)
        {
            goto label_5;
        }
        // 0x00B248CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_5:
        // 0x00B248D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B248D4: MOV x0, x20                | X0 = this.seeker;//m1                   
        // 0x00B248D8: MOV v0.16b, v11.16b        | V0 = val_3.x;//m1                       
        // 0x00B248DC: MOV v1.16b, v12.16b        | V1 = val_3.y;//m1                       
        // 0x00B248E0: MOV v2.16b, v13.16b        | V2 = val_3.z;//m1                       
        // 0x00B248E4: MOV v3.16b, v8.16b         | V3 = val_3.x;//m1                       
        // 0x00B248E8: MOV v4.16b, v9.16b         | V4 = val_3.y;//m1                       
        // 0x00B248EC: MOV v5.16b, v10.16b        | V5 = val_3.z;//m1                       
        // 0x00B248F0: BL #0xca5968               | X0 = this.seeker.StartPath(start:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, end:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
        Pathfinding.Path val_4 = this.seeker.StartPath(start:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, end:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
        // 0x00B248F4: MOV x19, x0                | X19 = val_4;//m1                        
        // 0x00B248F8: CBNZ x19, #0xb24900        | if (val_4 != null) goto label_6;        
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00B248FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x00B24900: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B24904: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B24908: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x00B2490C: BL #0x1402be8              | val_4.set_id(value:  0);                
        val_4.id = 0;
        // 0x00B24910: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x00B24914: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B24918: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2491C: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B24920: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B24924: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
        // 0x00B24928: RET                        |  return (Pathfinding.Path)val_4;        
        return (Pathfinding.Path)val_4;
        //  |  // // {name=val_0, type=Pathfinding.Path, size=8, nGRN=0 }
        label_3:
        // 0x00B2492C: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00B24930: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
        // 0x00B24934: LDR x0, [x8]               | X0 = typeof(System.InvalidOperationException);
        System.InvalidOperationException val_5 = null;
        // 0x00B24938: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
        // 0x00B2493C: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00B24940: LDR x8, [x8, #0xa8]        | X8 = (string**)(1152921513115791312)("Target is null");
        // 0x00B24944: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B24948: MOV x19, x0                | X19 = 1152921504654397440 (0x1000000002D59000);//ML01
        // 0x00B2494C: LDR x1, [x8]               | X1 = "Target is null";                  
        // 0x00B24950: BL #0x1e6648c              | .ctor(message:  "Target is null");      
        val_5 = new System.InvalidOperationException(message:  "Target is null");
        // 0x00B24954: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00B24958: LDR x8, [x8, #0x5f0]       | X8 = 1152921513115791408;               
        // 0x00B2495C: MOV x0, x19                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
        // 0x00B24960: LDR x1, [x8]               | X1 = public Pathfinding.Path AIPath::SearchPath();
        // 0x00B24964: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
        // 0x00B24968: BL #0xb1b5e4               | ABCheckUpdate.<RepairAssetShowDialog>m__C();
        ABCheckUpdate.<RepairAssetShowDialog>m__C();
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2496C (11684204), len: 4  VirtAddr: 0x00B2496C RVA: 0x00B2496C token: 100681729 methodIndex: 24752 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void OnTargetReached()
    {
        //
        // Disasemble & Code
        // 0x00B2496C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B24970 (11684208), len: 976  VirtAddr: 0x00B24970 RVA: 0x00B24970 token: 100681730 methodIndex: 24753 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void OnPathComplete(Pathfinding.Path _p)
    {
        //
        // Disasemble & Code
        //  | 
        int val_11;
        //  | 
        object val_12;
        //  | 
        UnityEngine.Vector3 val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        float val_16;
        // 0x00B24970: STP d13, d12, [sp, #-0x60]! | stack[1152921513116066544] = ???;  stack[1152921513116066552] = ???;  //  dest_result_addr=1152921513116066544 |  dest_result_addr=1152921513116066552
        // 0x00B24974: STP d11, d10, [sp, #0x10]  | stack[1152921513116066560] = ???;  stack[1152921513116066568] = ???;  //  dest_result_addr=1152921513116066560 |  dest_result_addr=1152921513116066568
        // 0x00B24978: STP d9, d8, [sp, #0x20]    | stack[1152921513116066576] = ???;  stack[1152921513116066584] = ???;  //  dest_result_addr=1152921513116066576 |  dest_result_addr=1152921513116066584
        // 0x00B2497C: STP x22, x21, [sp, #0x30]  | stack[1152921513116066592] = ???;  stack[1152921513116066600] = ???;  //  dest_result_addr=1152921513116066592 |  dest_result_addr=1152921513116066600
        // 0x00B24980: STP x20, x19, [sp, #0x40]  | stack[1152921513116066608] = ???;  stack[1152921513116066616] = ???;  //  dest_result_addr=1152921513116066608 |  dest_result_addr=1152921513116066616
        // 0x00B24984: STP x29, x30, [sp, #0x50]  | stack[1152921513116066624] = ???;  stack[1152921513116066632] = ???;  //  dest_result_addr=1152921513116066624 |  dest_result_addr=1152921513116066632
        // 0x00B24988: ADD x29, sp, #0x50         | X29 = (1152921513116066544 + 80) = 1152921513116066624 (0x10000001FB306340);
        // 0x00B2498C: SUB sp, sp, #0x10          | SP = (1152921513116066544 - 16) = 1152921513116066528 (0x10000001FB3062E0);
        // 0x00B24990: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B24994: LDRB w8, [x21, #0x737]     | W8 = (bool)static_value_03733737;       
        // 0x00B24998: MOV x20, x1                | X20 = _p;//m1                           
        // 0x00B2499C: MOV x19, x0                | X19 = 1152921513116078640 (0x10000001FB309230);//ML01
        val_12 = this;
        // 0x00B249A0: TBNZ w8, #0, #0xb249bc     | if (static_value_03733737 == true) goto label_0;
        // 0x00B249A4: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B249A8: LDR x8, [x8, #0xaa8]       | X8 = 0x2B8ABDC;                         
        // 0x00B249AC: LDR w0, [x8]               | W0 = 0x1B5;                             
        // 0x00B249B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B5, ????);      
        // 0x00B249B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B249B8: STRB w8, [x21, #0x737]     | static_value_03733737 = true;            //  dest_result_addr=57882423
        label_0:
        // 0x00B249BC: STR wzr, [sp, #8]          | stack[1152921513116066536] = 0x0;        //  dest_result_addr=1152921513116066536
        // 0x00B249C0: STR xzr, [sp]              | stack[1152921513116066528] = 0x0;        //  dest_result_addr=1152921513116066528
        // 0x00B249C4: CBZ x20, #0xb24d00         | if (_p == null) goto label_3;           
        if(_p == null)
        {
            goto label_3;
        }
        // 0x00B249C8: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B249CC: LDR x8, [x8, #0x7c8]       | X8 = 1152921504849764352;               
        // 0x00B249D0: LDR x9, [x20]              | X9 = typeof(Pathfinding.Path);          
        // 0x00B249D4: LDR x8, [x8]               | X8 = typeof(Pathfinding.ABPath);        
        // 0x00B249D8: LDRB w11, [x9, #0x104]     | W11 = Pathfinding.Path.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x00B249DC: LDRB w10, [x8, #0x104]     | W10 = Pathfinding.ABPath.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x00B249E0: CMP w11, w10               | STATE = COMPARE(Pathfinding.Path.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.ABPath.__il2cppRuntimeField_typeHierarchyDepth)
        // 0x00B249E4: B.LO #0xb24d00             | if (Pathfinding.Path.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.ABPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_3;
        // 0x00B249E8: LDR x9, [x9, #0xb0]        | X9 = Pathfinding.Path.__il2cppRuntimeField_typeHierarchy;
        // 0x00B249EC: ADD x9, x9, x10, lsl #3    | X9 = (Pathfinding.Path.__il2cppRuntimeField_typeHierarchy + (Pathfinding.ABPath.__il2cppRuntimeField
        // 0x00B249F0: LDUR x9, [x9, #-8]         | X9 = (Pathfinding.Path.__il2cppRuntimeField_typeHierarchy + (Pathfinding.ABPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
        // 0x00B249F4: CMP x9, x8                 | STATE = COMPARE((Pathfinding.Path.__il2cppRuntimeField_typeHierarchy + (Pathfinding.ABPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.ABPath))
        // 0x00B249F8: B.NE #0xb24d00             | if ((Pathfinding.Path.__il2cppRuntimeField_typeHierarchy + (Pathfinding.ABPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_3;
        // 0x00B249FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B24A00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B24A04: MOV x0, x20                | X0 = _p;//m1                            
        // 0x00B24A08: MOV x1, x19                | X1 = 1152921513116078640 (0x10000001FB309230);//ML01
        // 0x00B24A0C: STRB w8, [x19, #0x95]      | this.canSearchAgain = true;              //  dest_result_addr=1152921513116078789
        this.canSearchAgain = true;
        // 0x00B24A10: BL #0x1403bbc              | _p.Claim(o:  this);                     
        _p.Claim(o:  this);
        // 0x00B24A14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24A18: MOV x0, x20                | X0 = _p;//m1                            
        // 0x00B24A1C: BL #0x1402c00              | X0 = _p.get_error();                    
        bool val_1 = _p.error;
        // 0x00B24A20: TBZ w0, #0, #0xb24b58      | if (val_1 == false) goto label_4;       
        if(val_1 == false)
        {
            goto label_4;
        }
        // 0x00B24A24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B24A28: MOV x0, x20                | X0 = _p;//m1                            
        // 0x00B24A2C: MOV x1, x19                | X1 = 1152921513116078640 (0x10000001FB309230);//ML01
        // 0x00B24A30: BL #0x1404008              | _p.Release(o:  this);                   
        _p.Release(o:  this);
        // 0x00B24A34: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B24A38: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B24A3C: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x00B24A40: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B24A44: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B24A48: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B24A4C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B24A50: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B24A54: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_11 = null;
        // 0x00B24A58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24A5C: MOV x0, x19                | X0 = 1152921513116078640 (0x10000001FB309230);//ML01
        // 0x00B24A60: BL #0x1b759fc              | X0 = this.get_name();                   
        string val_2 = this.name;
        // 0x00B24A64: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B24A68: CBNZ x21, #0xb24a70        | if ( != null) goto label_5;             
        if(null != null)
        {
            goto label_5;
        }
        // 0x00B24A6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B24A70: CBZ x19, #0xb24a94         | if (val_2 == null) goto label_7;        
        if(val_2 == null)
        {
            goto label_7;
        }
        // 0x00B24A74: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B24A78: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00B24A7C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B24A80: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B24A84: CBNZ x0, #0xb24a94         | if (val_2 != null) goto label_7;        
        if(val_2 != null)
        {
            goto label_7;
        }
        // 0x00B24A88: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00B24A8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24A90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_7:
        // 0x00B24A94: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B24A98: CBNZ w8, #0xb24aa8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x00B24A9C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00B24AA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24AA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_8:
        // 0x00B24AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24AAC: MOV x0, x20                | X0 = _p;//m1                            
        // 0x00B24AB0: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00B24AB4: BL #0x1402c10              | X0 = _p.get_errorLog();                 
        string val_3 = _p.errorLog;
        // 0x00B24AB8: MOV x19, x0                | X19 = val_3;//m1                        
        // 0x00B24ABC: CBZ x19, #0xb24ae0         | if (val_3 == null) goto label_10;       
        if(val_3 == null)
        {
            goto label_10;
        }
        // 0x00B24AC0: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B24AC4: MOV x0, x19                | X0 = val_3;//m1                         
        // 0x00B24AC8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B24ACC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
        // 0x00B24AD0: CBNZ x0, #0xb24ae0         | if (val_3 != null) goto label_10;       
        if(val_3 != null)
        {
            goto label_10;
        }
        // 0x00B24AD4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
        // 0x00B24AD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24ADC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_10:
        // 0x00B24AE0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B24AE4: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B24AE8: B.HI #0xb24af8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_11;
        // 0x00B24AEC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B24AF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24AF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_11:
        // 0x00B24AF8: STR x19, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_3;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_3;
        // 0x00B24AFC: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
        // 0x00B24B00: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921513116045104)("{0} path error:{1}");
        // 0x00B24B04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24B08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B24B0C: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B24B10: LDR x1, [x8]               | X1 = "{0} path error:{1}";              
        // 0x00B24B14: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "{0} path error:{1}");
        string val_4 = EString.EFormat(format:  0, args:  "{0} path error:{1}");
        // 0x00B24B18: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B24B1C: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B24B20: MOV x19, x0                | X19 = val_4;//m1                        
        val_12 = val_4;
        // 0x00B24B24: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B24B28: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B24B2C: TBZ w9, #0, #0xb24b40      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B24B30: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B24B34: CBNZ w9, #0xb24b40         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B24B38: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B24B3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_13:
        // 0x00B24B40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24B44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B24B48: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B24B4C: MOV x1, x19                | X1 = val_4;//m1                         
        // 0x00B24B50: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_12);
        EDebug.Log(message:  0, isShowStack:  val_12);
        // 0x00B24B54: B #0xb24ce0                |  goto label_21;                         
        goto label_21;
        label_4:
        // 0x00B24B58: LDR x0, [x19, #0x68]       | X0 = this.path; //P2                    
        // 0x00B24B5C: CBZ x0, #0xb24b6c          | if (this.path == null) goto label_15;   
        if(this.path == null)
        {
            goto label_15;
        }
        // 0x00B24B60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B24B64: MOV x1, x19                | X1 = 1152921513116078640 (0x10000001FB309230);//ML01
        // 0x00B24B68: BL #0x1404008              | this.path.Release(o:  this);            
        this.path.Release(o:  this);
        label_15:
        // 0x00B24B6C: LDRB w8, [x19, #0x44]      | W8 = this.closestOnPathCheck; //P2      
        // 0x00B24B70: STR x20, [x19, #0x68]      | this.path = _p;                          //  dest_result_addr=1152921513116078744
        this.path = _p;
        // 0x00B24B74: STRB wzr, [x19, #0xa9]     | this.IsSearchPathing = false;            //  dest_result_addr=1152921513116078809
        this.IsSearchPathing = false;
        // 0x00B24B78: STR wzr, [x19, #0x90]      | this.currentWaypointIndex = 0;           //  dest_result_addr=1152921513116078784
        this.currentWaypointIndex = 0;
        // 0x00B24B7C: STRB wzr, [x19, #0x94]     | this.targetReached = false;              //  dest_result_addr=1152921513116078788
        this.targetReached = false;
        // 0x00B24B80: CBZ w8, #0xb24ce0          | if (this.closestOnPathCheck == false) goto label_21;
        if(this.closestOnPathCheck == false)
        {
            goto label_21;
        }
        // 0x00B24B84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24B88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24B8C: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_5 = UnityEngine.Time.time;
        // 0x00B24B90: LDR s1, [x19, #0xa4]       | S1 = this.lastFoundWaypointTime; //P2   
        // 0x00B24B94: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B24B98: LDR s2, [x8, #0x934]       | S2 = 0.3;                               
        // 0x00B24B9C: FSUB s0, s0, s1            | S0 = (val_5 - this.lastFoundWaypointTime);
        val_5 = val_5 - this.lastFoundWaypointTime;
        // 0x00B24BA0: FCMP s0, s2                | STATE = COMPARE((val_5 - this.lastFoundWaypointTime), 0.300000011920929)
        // 0x00B24BA4: B.PL #0xb24bb4             | if (val_5 >= 0) goto label_17;          
        if(val_5 >= 0)
        {
            goto label_17;
        }
        // 0x00B24BA8: LDP s8, s9, [x19, #0x98]   | S8 = this.lastFoundWaypointPosition; //P2   //  | 
        val_13 = this.lastFoundWaypointPosition;
        // 0x00B24BAC: LDR s10, [x19, #0xa0]      | 
        // 0x00B24BB0: B #0xb24bc0                |  goto label_18;                         
        goto label_18;
        label_17:
        // 0x00B24BB4: LDR s8, [x20, #0x130]      | 
        // 0x00B24BB8: LDR s9, [x20, #0x134]      | 
        // 0x00B24BBC: LDR s10, [x20, #0x138]     | 
        label_18:
        // 0x00B24BC0: LDR x8, [x19]              | X8 = typeof(AIPath);                    
        // 0x00B24BC4: MOV x0, x19                | X0 = 1152921513116078640 (0x10000001FB309230);//ML01
        // 0x00B24BC8: LDP x9, x1, [x8, #0x1d0]   | X9 = typeof(AIPath).__il2cppRuntimeField_1D0; X1 = typeof(AIPath).__il2cppRuntimeField_1D8; //  | 
        // 0x00B24BCC: BLR x9                     | X0 = typeof(AIPath).__il2cppRuntimeField_1D0();
        // 0x00B24BD0: ADRP x20, #0x3673000       | X20 = 57094144 (0x3673000);             
        // 0x00B24BD4: LDR x20, [x20, #0x488]     | X20 = 1152921504695078912;              
        // 0x00B24BD8: MOV v11.16b, v0.16b        | V11 = (val_5 - this.lastFoundWaypointTime);//m1
        // 0x00B24BDC: MOV v12.16b, v1.16b        | V12 = this.lastFoundWaypointTime;//m1   
        val_16 = this.lastFoundWaypointTime;
        // 0x00B24BE0: MOV v13.16b, v2.16b        | V13 = 0.300000011920929;//m1            
        // 0x00B24BE4: LDR x0, [x20]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B24BE8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B24BEC: TBZ w8, #0, #0xb24bfc      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B24BF0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B24BF4: CBNZ w8, #0xb24bfc         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B24BF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_20:
        // 0x00B24BFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24C00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24C04: MOV v0.16b, v11.16b        | V0 = (val_5 - this.lastFoundWaypointTime);//m1
        // 0x00B24C08: MOV v1.16b, v12.16b        | V1 = this.lastFoundWaypointTime;//m1    
        // 0x00B24C0C: MOV v2.16b, v13.16b        | V2 = 0.300000011920929;//m1             
        // 0x00B24C10: MOV v3.16b, v8.16b         | V3 = V8.16B;//m1                        
        // 0x00B24C14: MOV v4.16b, v9.16b         | V4 = V9.16B;//m1                        
        // 0x00B24C18: MOV v5.16b, v10.16b        | V5 = V10.16B;//m1                       
        // 0x00B24C1C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_5, y = val_16, z = 0.3f}, b:  new UnityEngine.Vector3() {x = V8.16B, y = V9.16B, z = V10.16B});
        UnityEngine.Vector3 val_6 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_5, y = val_16, z = 0.3f}, b:  new UnityEngine.Vector3() {x = V8.16B, y = V9.16B, z = V10.16B});
        // 0x00B24C20: MOV x0, sp                 | X0 = 1152921513116066528 (0x10000001FB3062E0);//ML01
        // 0x00B24C24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24C28: STP s0, s1, [sp]           | stack[1152921513116066528] = val_6.x;  stack[1152921513116066532] = val_6.y;  //  dest_result_addr=1152921513116066528 |  dest_result_addr=1152921513116066532
        // 0x00B24C2C: STR s2, [sp, #8]           | stack[1152921513116066536] = val_6.z;    //  dest_result_addr=1152921513116066536
        // 0x00B24C30: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
        // 0x00B24C34: LDP s3, s1, [sp]           | S3 = val_6.x; S1 = val_6.y;              //  | 
        // 0x00B24C38: LDR s2, [sp, #8]           | S2 = val_6.z;                           
        // 0x00B24C3C: MOV v11.16b, v0.16b        | V11 = val_6.x;//m1                      
        // 0x00B24C40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24C44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24C48: MOV v0.16b, v3.16b         | V0 = val_6.x;//m1                       
        // 0x00B24C4C: MOV v3.16b, v11.16b        | V3 = val_6.x;//m1                       
        // 0x00B24C50: BL #0x2699130              | X0 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, d:  val_6.x);
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, d:  val_6.x);
        // 0x00B24C54: STP s0, s1, [sp]           | stack[1152921513116066528] = val_7.x;  stack[1152921513116066532] = val_7.y;  //  dest_result_addr=1152921513116066528 |  dest_result_addr=1152921513116066532
        // 0x00B24C58: STR s2, [sp, #8]           | stack[1152921513116066536] = val_7.z;    //  dest_result_addr=1152921513116066536
        // 0x00B24C5C: LDR s0, [x19, #0x38]       | S0 = this.pickNextWaypointDist; //P2    
        float val_11 = this.pickNextWaypointDist;
        // 0x00B24C60: FDIV s0, s11, s0           | S0 = (val_6.x / this.pickNextWaypointDist);
        val_11 = val_6.x / val_11;
        // 0x00B24C64: FCVTZS w21, s0             | W21 = (int)((val_6.x / this.pickNextWaypointDist));
        val_11 = (int)val_11;
        // 0x00B24C68: TBNZ w21, #0x1f, #0xb24ce0 | if (((val_6.x / this.pickNextWaypointDist) & 0x80000000) != 0) goto label_21;
        if((val_11 & 2147483648) != 0)
        {
            goto label_21;
        }
        // 0x00B24C6C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        var val_12 = 0;
        label_24:
        // 0x00B24C70: MOV x0, x19                | X0 = 1152921513116078640 (0x10000001FB309230);//ML01
        // 0x00B24C74: MOV v0.16b, v8.16b         | V0 = V8.16B;//m1                        
        // 0x00B24C78: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00B24C7C: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00B24C80: BL #0xb24d40               | X0 = this.CalculateVelocity(currentPosition:  new UnityEngine.Vector3() {x = V8.16B, y = V9.16B, z = V10.16B});
        UnityEngine.Vector3 val_8 = this.CalculateVelocity(currentPosition:  new UnityEngine.Vector3() {x = V8.16B, y = V9.16B, z = V10.16B});
        // 0x00B24C84: LDR x0, [x20]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B24C88: LDP s13, s12, [sp]         | S13 = val_7.x; S12 = val_7.y;            //  | 
        val_16 = val_7.y;
        // 0x00B24C8C: LDR s11, [sp, #8]          | S11 = val_7.z;                          
        // 0x00B24C90: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B24C94: TBZ w8, #0, #0xb24ca4      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_23;
        // 0x00B24C98: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B24C9C: CBNZ w8, #0xb24ca4         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
        // 0x00B24CA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_23:
        // 0x00B24CA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24CA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24CAC: MOV v0.16b, v8.16b         | V0 = V8.16B;//m1                        
        // 0x00B24CB0: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00B24CB4: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00B24CB8: MOV v3.16b, v13.16b        | V3 = val_7.x;//m1                       
        // 0x00B24CBC: MOV v4.16b, v12.16b        | V4 = val_7.y;//m1                       
        // 0x00B24CC0: MOV v5.16b, v11.16b        | V5 = val_7.z;//m1                       
        // 0x00B24CC4: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = V8.16B, y = V9.16B, z = V10.16B}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_16, z = val_7.z});
        UnityEngine.Vector3 val_9 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = V8.16B, y = V9.16B, z = V10.16B}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_16, z = val_7.z});
        // 0x00B24CC8: MOV v8.16b, v0.16b         | V8 = val_9.x;//m1                       
        val_13 = val_9.x;
        // 0x00B24CCC: MOV v9.16b, v1.16b         | V9 = val_9.y;//m1                       
        // 0x00B24CD0: MOV v10.16b, v2.16b        | V10 = val_9.z;//m1                      
        val_15 = val_9.z;
        // 0x00B24CD4: ADD w22, w22, #1           | W22 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x00B24CD8: CMP w22, w21               | STATE = COMPARE((0 + 1), (val_6.x / this.pickNextWaypointDist))
        // 0x00B24CDC: B.LE #0xb24c70             | if (0 <= val_11) goto label_24;         
        if(val_12 <= val_11)
        {
            goto label_24;
        }
        label_21:
        // 0x00B24CE0: SUB sp, x29, #0x50         | SP = (1152921513116066624 - 80) = 1152921513116066544 (0x10000001FB3062F0);
        // 0x00B24CE4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B24CE8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B24CEC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B24CF0: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B24CF4: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B24CF8: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
        // 0x00B24CFC: RET                        |  return;                                
        return;
        label_3:
        // 0x00B24D00: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B24D04: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
        // 0x00B24D08: LDR x0, [x8]               | X0 = typeof(System.Exception);          
        System.Exception val_10 = null;
        // 0x00B24D0C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
        // 0x00B24D10: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00B24D14: LDR x8, [x8, #0xb98]       | X8 = (string**)(1152921513116053408)("This function only handles ABPaths, do not use special path types");
        // 0x00B24D18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B24D1C: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
        // 0x00B24D20: LDR x1, [x8]               | X1 = "This function only handles ABPaths, do not use special path types";
        // 0x00B24D24: BL #0x1c32b48              | .ctor(message:  "This function only handles ABPaths, do not use special path types");
        val_10 = new System.Exception(message:  "This function only handles ABPaths, do not use special path types");
        // 0x00B24D28: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B24D2C: LDR x8, [x8, #0xc48]       | X8 = 1152921513116053616;               
        // 0x00B24D30: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
        // 0x00B24D34: LDR x1, [x8]               | X1 = public System.Void AIPath::OnPathComplete(Pathfinding.Path _p);
        // 0x00B24D38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
        // 0x00B24D3C: BL #0xb1b5e4               | ABCheckUpdate.<RepairAssetShowDialog>m__C();
        ABCheckUpdate.<RepairAssetShowDialog>m__C();
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2527C (11686524), len: 420  VirtAddr: 0x00B2527C RVA: 0x00B2527C token: 100681731 methodIndex: 24754 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual UnityEngine.Vector3 GetFeetPosition()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Transform val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        float val_16;
        //  | 
        float val_17;
        //  | 
        float val_18;
        //  | 
        float val_19;
        //  | 
        float val_20;
        //  | 
        float val_21;
        // 0x00B2527C: STP d11, d10, [sp, #-0x50]! | stack[1152921513116215424] = ???;  stack[1152921513116215432] = ???;  //  dest_result_addr=1152921513116215424 |  dest_result_addr=1152921513116215432
        // 0x00B25280: STP d9, d8, [sp, #0x10]    | stack[1152921513116215440] = ???;  stack[1152921513116215448] = ???;  //  dest_result_addr=1152921513116215440 |  dest_result_addr=1152921513116215448
        // 0x00B25284: STP x22, x21, [sp, #0x20]  | stack[1152921513116215456] = ???;  stack[1152921513116215464] = ???;  //  dest_result_addr=1152921513116215456 |  dest_result_addr=1152921513116215464
        // 0x00B25288: STP x20, x19, [sp, #0x30]  | stack[1152921513116215472] = ???;  stack[1152921513116215480] = ???;  //  dest_result_addr=1152921513116215472 |  dest_result_addr=1152921513116215480
        // 0x00B2528C: STP x29, x30, [sp, #0x40]  | stack[1152921513116215488] = ???;  stack[1152921513116215496] = ???;  //  dest_result_addr=1152921513116215488 |  dest_result_addr=1152921513116215496
        // 0x00B25290: ADD x29, sp, #0x40         | X29 = (1152921513116215424 + 64) = 1152921513116215488 (0x10000001FB32A8C0);
        // 0x00B25294: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B25298: LDRB w8, [x20, #0x738]     | W8 = (bool)static_value_03733738;       
        // 0x00B2529C: MOV x19, x0                | X19 = 1152921513116227504 (0x10000001FB32D7B0);//ML01
        // 0x00B252A0: TBNZ w8, #0, #0xb252bc     | if (static_value_03733738 == true) goto label_0;
        // 0x00B252A4: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00B252A8: LDR x8, [x8, #0x350]       | X8 = 0x2B8ABD0;                         
        // 0x00B252AC: LDR w0, [x8]               | W0 = 0x1B2;                             
        // 0x00B252B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B2, ????);      
        // 0x00B252B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B252B8: STRB w8, [x20, #0x738]     | static_value_03733738 = true;            //  dest_result_addr=57882424
        label_0:
        // 0x00B252BC: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B252C0: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x00B252C4: LDR x20, [x19, #0x80]      | X20 = this.rvoController; //P2          
        // 0x00B252C8: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B252CC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B252D0: TBZ w8, #0, #0xb252e0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B252D4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B252D8: CBNZ w8, #0xb252e0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B252DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B252E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B252E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B252E8: MOV x1, x20                | X1 = this.rvoController;//m1            
        // 0x00B252EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B252F0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.rvoController);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.rvoController);
        // 0x00B252F4: TBZ w0, #0, #0xb25334      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B252F8: LDR x19, [x19, #0x58]      | X19 = this.tr; //P2                     
        val_8 = this.tr;
        // 0x00B252FC: CBNZ x19, #0xb25304        | if (this.tr != null) goto label_4;      
        if(val_8 != null)
        {
            goto label_4;
        }
        // 0x00B25300: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B25304: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25308: MOV x0, x19                | X0 = this.tr;//m1                       
        // 0x00B2530C: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_2 = val_8.position;
        // 0x00B25310: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B25314: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B25318: MOV v8.16b, v0.16b         | V8 = val_2.x;//m1                       
        val_9 = val_2.x;
        // 0x00B2531C: MOV v9.16b, v1.16b         | V9 = val_2.y;//m1                       
        val_10 = val_2.y;
        // 0x00B25320: MOV v10.16b, v2.16b        | V10 = val_2.z;//m1                      
        val_11 = val_2.z;
        // 0x00B25324: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        val_12 = null;
        // 0x00B25328: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B2532C: TBNZ w8, #0, #0xb253a4     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor != 0) goto label_5;
        // 0x00B25330: B #0xb253b0                |  goto label_12;                         
        goto label_12;
        label_3:
        // 0x00B25334: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B25338: LDR x20, [x19, #0x70]      | X20 = this.controller; //P2             
        // 0x00B2533C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B25340: TBZ w8, #0, #0xb25350      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B25344: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B25348: CBNZ w8, #0xb25350         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B2534C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_8:
        // 0x00B25350: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25354: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B25358: MOV x1, x20                | X1 = this.controller;//m1               
        // 0x00B2535C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B25360: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.controller);
        bool val_3 = UnityEngine.Object.op_Inequality(x:  0, y:  this.controller);
        // 0x00B25364: LDR x20, [x19, #0x58]      | X20 = this.tr; //P2                     
        // 0x00B25368: MOV w19, w0                | W19 = val_3;//m1                        
        val_8 = val_3;
        // 0x00B2536C: CBNZ x20, #0xb25374        | if (this.tr != null) goto label_9;      
        if(this.tr != null)
        {
            goto label_9;
        }
        // 0x00B25370: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00B25374: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25378: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B2537C: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_4 = this.tr.position;
        // 0x00B25380: MOV v8.16b, v0.16b         | V8 = val_4.x;//m1                       
        val_16 = val_4.x;
        // 0x00B25384: MOV v9.16b, v1.16b         | V9 = val_4.y;//m1                       
        val_17 = val_4.y;
        // 0x00B25388: MOV v10.16b, v2.16b        | V10 = val_4.z;//m1                      
        val_18 = val_4.z;
        // 0x00B2538C: TBZ w19, #0, #0xb253fc     | if (val_3 == false) goto label_10;      
        if(val_8 == false)
        {
            goto label_10;
        }
        // 0x00B25390: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B25394: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B25398: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        val_12 = null;
        // 0x00B2539C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B253A0: TBZ w8, #0, #0xb253b0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        label_5:
        // 0x00B253A4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B253A8: CBNZ w8, #0xb253b0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B253AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_12:
        // 0x00B253B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B253B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B253B8: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.up;
        // 0x00B253BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B253C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B253C4: FMOV s3, #0.50000000       | S3 = 0.5;                               
        // 0x00B253C8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, d:  0.5f);
        UnityEngine.Vector3 val_6 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, d:  0.5f);
        // 0x00B253CC: MOV v3.16b, v0.16b         | V3 = val_6.x;//m1                       
        // 0x00B253D0: MOV v4.16b, v1.16b         | V4 = val_6.y;//m1                       
        // 0x00B253D4: MOV v5.16b, v2.16b         | V5 = val_6.z;//m1                       
        // 0x00B253D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B253DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B253E0: MOV v0.16b, v8.16b         | V0 = val_4.x;//m1                       
        // 0x00B253E4: MOV v1.16b, v9.16b         | V1 = val_4.y;//m1                       
        // 0x00B253E8: MOV v2.16b, v10.16b        | V2 = val_4.z;//m1                       
        // 0x00B253EC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_16, y = val_17, z = val_18}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_16, y = val_17, z = val_18}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        // 0x00B253F0: MOV v8.16b, v0.16b         | V8 = val_7.x;//m1                       
        val_19 = val_7.x;
        // 0x00B253F4: MOV v9.16b, v1.16b         | V9 = val_7.y;//m1                       
        val_20 = val_7.y;
        // 0x00B253F8: MOV v10.16b, v2.16b        | V10 = val_7.z;//m1                      
        val_21 = val_7.z;
        label_10:
        // 0x00B253FC: MOV v0.16b, v8.16b         | V0 = val_7.x;//m1                       
        // 0x00B25400: MOV v1.16b, v9.16b         | V1 = val_7.y;//m1                       
        // 0x00B25404: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B25408: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2540C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B25410: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B25414: MOV v2.16b, v10.16b        | V2 = val_7.z;//m1                       
        // 0x00B25418: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00B2541C: RET                        |  return new UnityEngine.Vector3() {x = val_19, y = val_20, z = val_21};
        return new UnityEngine.Vector3() {x = val_19, y = val_20, z = val_21};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B25420 (11686944), len: 4  VirtAddr: 0x00B25420 RVA: 0x00B25420 token: 100681732 methodIndex: 24755 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void Update()
    {
        //
        // Disasemble & Code
        // 0x00B25420: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B25424 (11686948), len: 24  VirtAddr: 0x00B25424 RVA: 0x00B25424 token: 100681733 methodIndex: 24756 delegateWrapperIndex: 0 methodInvoker: 0
    protected float XZSqrMagnitude(UnityEngine.Vector3 a, UnityEngine.Vector3 b)
    {
        //
        // Disasemble & Code
        // 0x00B25424: FSUB s0, s3, s0            | S0 = (b.x - a.x);                       
        a.x = b.x - a.x;
        // 0x00B25428: FSUB s1, s5, s2            | S1 = (b.z - a.z);                       
        float val_1 = b.z - a.z;
        // 0x00B2542C: FMUL s0, s0, s0            | S0 = ((b.x - a.x) * (b.x - a.x));       
        a.x = a.x * a.x;
        // 0x00B25430: FMUL s1, s1, s1            | S1 = ((b.z - a.z) * (b.z - a.z));       
        val_1 = val_1 * val_1;
        // 0x00B25434: FADD s0, s0, s1            | S0 = (((b.x - a.x) * (b.x - a.x)) + ((b.z - a.z) * (b.z - a.z)));
        a.x = a.x + val_1;
        // 0x00B25438: RET                        |  return (System.Single)(((b.x - a.x) * (b.x - a.x)) + ((b.z - a.z) * (b.z - a.z)));
        return (float)a.x;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B24D40 (11685184), len: 1340  VirtAddr: 0x00B24D40 RVA: 0x00B24D40 token: 100681734 methodIndex: 24757 delegateWrapperIndex: 0 methodInvoker: 0
    protected UnityEngine.Vector3 CalculateVelocity(UnityEngine.Vector3 currentPosition)
    {
        //
        // Disasemble & Code
        //  | 
        float val_37;
        //  | 
        float val_38;
        //  | 
        float val_39;
        //  | 
        int val_40;
        //  | 
        float val_41;
        //  | 
        float val_42;
        //  | 
        var val_43;
        // 0x00B24D40: STP d15, d14, [sp, #-0x80]! | stack[1152921513116589264] = ???;  stack[1152921513116589272] = ???;  //  dest_result_addr=1152921513116589264 |  dest_result_addr=1152921513116589272
        // 0x00B24D44: STP d13, d12, [sp, #0x10]  | stack[1152921513116589280] = ???;  stack[1152921513116589288] = ???;  //  dest_result_addr=1152921513116589280 |  dest_result_addr=1152921513116589288
        // 0x00B24D48: STP d11, d10, [sp, #0x20]  | stack[1152921513116589296] = ???;  stack[1152921513116589304] = ???;  //  dest_result_addr=1152921513116589296 |  dest_result_addr=1152921513116589304
        // 0x00B24D4C: STP d9, d8, [sp, #0x30]    | stack[1152921513116589312] = ???;  stack[1152921513116589320] = ???;  //  dest_result_addr=1152921513116589312 |  dest_result_addr=1152921513116589320
        // 0x00B24D50: STP x24, x23, [sp, #0x40]  | stack[1152921513116589328] = ???;  stack[1152921513116589336] = ???;  //  dest_result_addr=1152921513116589328 |  dest_result_addr=1152921513116589336
        // 0x00B24D54: STP x22, x21, [sp, #0x50]  | stack[1152921513116589344] = ???;  stack[1152921513116589352] = ???;  //  dest_result_addr=1152921513116589344 |  dest_result_addr=1152921513116589352
        // 0x00B24D58: STP x20, x19, [sp, #0x60]  | stack[1152921513116589360] = ???;  stack[1152921513116589368] = ???;  //  dest_result_addr=1152921513116589360 |  dest_result_addr=1152921513116589368
        // 0x00B24D5C: STP x29, x30, [sp, #0x70]  | stack[1152921513116589376] = ???;  stack[1152921513116589384] = ???;  //  dest_result_addr=1152921513116589376 |  dest_result_addr=1152921513116589384
        // 0x00B24D60: ADD x29, sp, #0x70         | X29 = (1152921513116589264 + 112) = 1152921513116589376 (0x10000001FB385D40);
        // 0x00B24D64: SUB sp, sp, #0x20          | SP = (1152921513116589264 - 32) = 1152921513116589232 (0x10000001FB385CB0);
        // 0x00B24D68: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B24D6C: LDRB w8, [x20, #0x739]     | W8 = (bool)static_value_03733739;       
        // 0x00B24D70: MOV v8.16b, v2.16b         | V8 = currentPosition.z;//m1             
        // 0x00B24D74: MOV v9.16b, v1.16b         | V9 = currentPosition.y;//m1             
        // 0x00B24D78: MOV v10.16b, v0.16b        | V10 = currentPosition.x;//m1            
        // 0x00B24D7C: MOV x19, x0                | X19 = 1152921513116601392 (0x10000001FB388C30);//ML01
        // 0x00B24D80: TBNZ w8, #0, #0xb24d9c     | if (static_value_03733739 == true) goto label_0;
        // 0x00B24D84: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B24D88: LDR x8, [x8, #0x7c8]       | X8 = 0x2B8ABCC;                         
        // 0x00B24D8C: LDR w0, [x8]               | W0 = 0x1B1;                             
        // 0x00B24D90: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B1, ????);      
        // 0x00B24D94: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B24D98: STRB w8, [x20, #0x739]     | static_value_03733739 = true;            //  dest_result_addr=57882425
        label_0:
        // 0x00B24D9C: STR wzr, [sp, #0x18]       | stack[1152921513116589256] = 0x0;        //  dest_result_addr=1152921513116589256
        // 0x00B24DA0: STR xzr, [sp, #0x10]       | stack[1152921513116589248] = 0x0;        //  dest_result_addr=1152921513116589248
        // 0x00B24DA4: LDR x8, [x19, #0x68]       | X8 = this.path; //P2                    
        // 0x00B24DA8: CBZ x8, #0xb24e48          | if (this.path == null) goto label_3;    
        if(this.path == null)
        {
            goto label_3;
        }
        // 0x00B24DAC: LDR x0, [x8, #0x68]        | X0 = this.path.vectorPath; //P2         
        // 0x00B24DB0: CBZ x0, #0xb24e48          | if (this.path.vectorPath == null) goto label_3;
        if(this.path.vectorPath == null)
        {
            goto label_3;
        }
        // 0x00B24DB4: ADRP x22, #0x35fc000       | X22 = 56606720 (0x35FC000);             
        // 0x00B24DB8: LDR x22, [x22, #0x5e0]     | X22 = 1152921510909311600;              
        // 0x00B24DBC: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B24DC0: BL #0x2643344              | X0 = this.path.vectorPath.get_Count();  
        int val_1 = this.path.vectorPath.Count;
        // 0x00B24DC4: CBZ w0, #0xb24e48          | if (val_1 == 0) goto label_3;           
        if(val_1 == 0)
        {
            goto label_3;
        }
        // 0x00B24DC8: LDR x20, [x19, #0x68]      | X20 = this.path; //P2                   
        // 0x00B24DCC: CBNZ x20, #0xb24dd4        | if (this.path != null) goto label_4;    
        if(this.path != null)
        {
            goto label_4;
        }
        // 0x00B24DD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B24DD4: LDR x20, [x20, #0x68]      | X20 = this.path.vectorPath; //P2        
        // 0x00B24DD8: CBNZ x20, #0xb24de0        | if (this.path.vectorPath != null) goto label_5;
        if(this.path.vectorPath != null)
        {
            goto label_5;
        }
        // 0x00B24DDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00B24DE0: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B24DE4: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B24DE8: BL #0x2643344              | X0 = this.path.vectorPath.get_Count();  
        int val_2 = this.path.vectorPath.Count;
        // 0x00B24DEC: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
        // 0x00B24DF0: B.NE #0xb24e20             | if (val_2 != 1) goto label_6;           
        if(val_2 != 1)
        {
            goto label_6;
        }
        // 0x00B24DF4: CBNZ x20, #0xb24dfc        | if (this.path.vectorPath != null) goto label_7;
        if(this.path.vectorPath != null)
        {
            goto label_7;
        }
        // 0x00B24DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B24DFC: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00B24E00: LDR x8, [x8, #0x1c0]       | X8 = 1152921513116572272;               
        // 0x00B24E04: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B24E08: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B24E0C: MOV v0.16b, v10.16b        | V0 = currentPosition.x;//m1             
        val_37 = currentPosition.x;
        // 0x00B24E10: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Insert(int index, UnityEngine.Vector3 item);
        // 0x00B24E14: MOV v1.16b, v9.16b         | V1 = currentPosition.y;//m1             
        val_38 = currentPosition.y;
        // 0x00B24E18: MOV v2.16b, v8.16b         | V2 = currentPosition.z;//m1             
        val_39 = currentPosition.z;
        // 0x00B24E1C: BL #0x2641e14              | this.path.vectorPath.Insert(index:  0, item:  new UnityEngine.Vector3() {x = val_37, y = val_38, z = val_39});
        this.path.vectorPath.Insert(index:  0, item:  new UnityEngine.Vector3() {x = val_37, y = val_38, z = val_39});
        label_6:
        // 0x00B24E20: LDR w21, [x19, #0x90]      | W21 = this.currentWaypointIndex; //P2   
        // 0x00B24E24: CBNZ x20, #0xb24e2c        | if (this.path.vectorPath != null) goto label_8;
        if(this.path.vectorPath != null)
        {
            goto label_8;
        }
        // 0x00B24E28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.path.vectorPath, ????);
        label_8:
        // 0x00B24E2C: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B24E30: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B24E34: BL #0x2643344              | X0 = this.path.vectorPath.get_Count();  
        int val_3 = this.path.vectorPath.Count;
        // 0x00B24E38: CMP w21, w0                | STATE = COMPARE(this.currentWaypointIndex, val_3)
        // 0x00B24E3C: B.GE #0xb24e9c             | if (this.currentWaypointIndex >= val_3) goto label_9;
        if(this.currentWaypointIndex >= val_3)
        {
            goto label_9;
        }
        // 0x00B24E40: LDR w21, [x19, #0x90]      | W21 = this.currentWaypointIndex; //P2   
        val_40 = this.currentWaypointIndex;
        // 0x00B24E44: B #0xb24eb8                |  goto label_10;                         
        goto label_10;
        label_3:
        // 0x00B24E48: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B24E4C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B24E50: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        label_41:
        // 0x00B24E54: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B24E58: TBZ w8, #0, #0xb24e68      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B24E5C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B24E60: CBNZ w8, #0xb24e68         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B24E64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_12:
        // 0x00B24E68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24E6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24E70: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.zero;
        label_39:
        // 0x00B24E74: SUB sp, x29, #0x70         | SP = (1152921513116589376 - 112) = 1152921513116589264 (0x10000001FB385CD0);
        // 0x00B24E78: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00B24E7C: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00B24E80: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00B24E84: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00B24E88: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B24E8C: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B24E90: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B24E94: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00B24E98: RET                        |  return new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z};
        return new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        label_9:
        // 0x00B24E9C: CBNZ x20, #0xb24ea4        | if (this.path.vectorPath != null) goto label_13;
        if(this.path.vectorPath != null)
        {
            goto label_13;
        }
        // 0x00B24EA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_13:
        // 0x00B24EA4: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B24EA8: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B24EAC: BL #0x2643344              | X0 = this.path.vectorPath.get_Count();  
        int val_5 = this.path.vectorPath.Count;
        // 0x00B24EB0: SUB w21, w0, #1            | W21 = (val_5 - 1);                      
        val_40 = val_5 - 1;
        // 0x00B24EB4: STR w21, [x19, #0x90]      | this.currentWaypointIndex = (val_5 - 1);  //  dest_result_addr=1152921513116601536
        this.currentWaypointIndex = val_40;
        label_10:
        // 0x00B24EB8: CMP w21, #1                | STATE = COMPARE((val_5 - 1), 0x1)       
        // 0x00B24EBC: B.GT #0xb24ec8             | if (val_40 > 1) goto label_14;          
        if(val_40 > 1)
        {
            goto label_14;
        }
        // 0x00B24EC0: ORR w21, wzr, #1           | W21 = 1(0x1);                           
        val_40 = 1;
        // 0x00B24EC4: STR w21, [x19, #0x90]      | this.currentWaypointIndex = 1;           //  dest_result_addr=1152921513116601536
        this.currentWaypointIndex = val_40;
        label_14:
        // 0x00B24EC8: ADRP x24, #0x363e000       | X24 = 56877056 (0x363E000);             
        // 0x00B24ECC: LDR x24, [x24, #0x1f0]     | X24 = 1152921510909481968;              
        // 0x00B24ED0: B #0xb24ef8                |  goto label_15;                         
        goto label_15;
        label_19:
        // 0x00B24ED4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24ED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24EDC: STP s10, s9, [x19, #0x98]  | this.lastFoundWaypointPosition = currentPosition;  mem[1152921513116601548] = currentPosition.y;  //  dest_result_addr=1152921513116601544 |  dest_result_addr=1152921513116601548
        this.lastFoundWaypointPosition = currentPosition;
        mem[1152921513116601548] = currentPosition.y;
        // 0x00B24EE0: STR s8, [x19, #0xa0]       | mem[1152921513116601552] = currentPosition.z;  //  dest_result_addr=1152921513116601552
        mem[1152921513116601552] = currentPosition.z;
        // 0x00B24EE4: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_6 = UnityEngine.Time.time;
        // 0x00B24EE8: LDR w8, [x19, #0x90]       | W8 = this.currentWaypointIndex; //P2    
        // 0x00B24EEC: STR s0, [x19, #0xa4]       | this.lastFoundWaypointTime = val_6;      //  dest_result_addr=1152921513116601556
        this.lastFoundWaypointTime = val_6;
        // 0x00B24EF0: ADD w21, w8, #1            | W21 = (this.currentWaypointIndex + 1);  
        val_40 = this.currentWaypointIndex + 1;
        // 0x00B24EF4: STR w21, [x19, #0x90]      | this.currentWaypointIndex = (this.currentWaypointIndex + 1);  //  dest_result_addr=1152921513116601536
        this.currentWaypointIndex = val_40;
        label_15:
        // 0x00B24EF8: CBNZ x20, #0xb24f00        | if (this.path.vectorPath != null) goto label_16;
        if(this.path.vectorPath != null)
        {
            goto label_16;
        }
        // 0x00B24EFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_16:
        // 0x00B24F00: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B24F04: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B24F08: BL #0x2643344              | X0 = this.path.vectorPath.get_Count();  
        int val_7 = this.path.vectorPath.Count;
        // 0x00B24F0C: SUB w8, w0, #1             | W8 = (val_7 - 1);                       
        int val_8 = val_7 - 1;
        // 0x00B24F10: CMP w21, w8                | STATE = COMPARE((this.currentWaypointIndex + 1), (val_7 - 1))
        // 0x00B24F14: B.GE #0xb24f58             | if (val_40 >= val_8) goto label_17;     
        if(val_40 >= val_8)
        {
            goto label_17;
        }
        // 0x00B24F18: LDR w21, [x19, #0x90]      | W21 = this.currentWaypointIndex; //P2   
        // 0x00B24F1C: CBNZ x20, #0xb24f24        | if (this.path.vectorPath != null) goto label_18;
        if(this.path.vectorPath != null)
        {
            goto label_18;
        }
        // 0x00B24F20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_18:
        // 0x00B24F24: LDR x2, [x24]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00B24F28: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B24F2C: MOV w1, w21                | W1 = this.currentWaypointIndex;//m1     
        // 0x00B24F30: BL #0x264334c              | X0 = this.path.vectorPath.get_Item(index:  this.currentWaypointIndex);
        UnityEngine.Vector3 val_9 = this.path.vectorPath.Item[this.currentWaypointIndex];
        // 0x00B24F34: FSUB s1, s8, s2            | S1 = (currentPosition.z - val_9.z);     
        float val_10 = currentPosition.z - val_9.z;
        // 0x00B24F38: LDR s2, [x19, #0x38]       | S2 = this.pickNextWaypointDist; //P2    
        val_39 = this.pickNextWaypointDist;
        // 0x00B24F3C: FSUB s0, s10, s0           | S0 = (currentPosition.x - val_9.x);     
        val_9.x = currentPosition.x - val_9.x;
        // 0x00B24F40: FMUL s0, s0, s0            | S0 = ((currentPosition.x - val_9.x) * (currentPosition.x - val_9.x));
        val_9.x = val_9.x * val_9.x;
        // 0x00B24F44: FMUL s1, s1, s1            | S1 = ((currentPosition.z - val_9.z) * (currentPosition.z - val_9.z));
        val_10 = val_10 * val_10;
        // 0x00B24F48: FADD s0, s0, s1            | S0 = (((currentPosition.x - val_9.x) * (currentPosition.x - val_9.x)) + ((currentPosition.z - val_9.z) * (currentPosition.z - val_9.z)));
        val_37 = val_9.x + val_10;
        // 0x00B24F4C: FMUL s1, s2, s2            | S1 = (this.pickNextWaypointDist * this.pickNextWaypointDist);
        val_38 = val_39 * val_39;
        // 0x00B24F50: FCMP s0, s1                | STATE = COMPARE((((currentPosition.x - val_9.x) * (currentPosition.x - val_9.x)) + ((currentPosition.z - val_9.z) * (currentPosition.z - val_9.z))), (this.pickNextWaypointDist * this.pickNextWaypointDist))
        // 0x00B24F54: B.MI #0xb24ed4             | if (val_37 < 0) goto label_19;          
        if(val_37 < 0)
        {
            goto label_19;
        }
        label_17:
        // 0x00B24F58: LDR w21, [x19, #0x90]      | W21 = this.currentWaypointIndex; //P2   
        // 0x00B24F5C: CBNZ x20, #0xb24f64        | if (this.path.vectorPath != null) goto label_20;
        if(this.path.vectorPath != null)
        {
            goto label_20;
        }
        // 0x00B24F60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.path.vectorPath, ????);
        label_20:
        // 0x00B24F64: LDR x2, [x24]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00B24F68: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B24F6C: MOV w1, w21                | W1 = this.currentWaypointIndex;//m1     
        // 0x00B24F70: BL #0x264334c              | X0 = this.path.vectorPath.get_Item(index:  this.currentWaypointIndex);
        UnityEngine.Vector3 val_11 = this.path.vectorPath.Item[this.currentWaypointIndex];
        // 0x00B24F74: LDR w21, [x19, #0x90]      | W21 = this.currentWaypointIndex; //P2   
        // 0x00B24F78: MOV v12.16b, v1.16b        | V12 = val_11.y;//m1                     
        // 0x00B24F7C: MOV v13.16b, v2.16b        | V13 = val_11.z;//m1                     
        // 0x00B24F80: STR s0, [sp, #0xc]         | stack[1152921513116589244] = val_11.x;   //  dest_result_addr=1152921513116589244
        // 0x00B24F84: CBNZ x20, #0xb24f8c        | if (this.path.vectorPath != null) goto label_21;
        if(this.path.vectorPath != null)
        {
            goto label_21;
        }
        // 0x00B24F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.path.vectorPath, ????);
        label_21:
        // 0x00B24F8C: LDR x2, [x24]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00B24F90: SUB w1, w21, #1            | W1 = (this.currentWaypointIndex - 1);   
        int val_12 = this.currentWaypointIndex - 1;
        // 0x00B24F94: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B24F98: BL #0x264334c              | X0 = this.path.vectorPath.get_Item(index:  int val_12 = this.currentWaypointIndex - 1);
        UnityEngine.Vector3 val_13 = this.path.vectorPath.Item[val_12];
        // 0x00B24F9C: ADRP x23, #0x3673000       | X23 = 57094144 (0x3673000);             
        // 0x00B24FA0: LDR x23, [x23, #0x488]     | X23 = 1152921504695078912;              
        // 0x00B24FA4: MOV v14.16b, v0.16b        | V14 = val_13.x;//m1                     
        // 0x00B24FA8: MOV v15.16b, v1.16b        | V15 = val_13.y;//m1                     
        // 0x00B24FAC: MOV v11.16b, v2.16b        | V11 = val_13.z;//m1                     
        // 0x00B24FB0: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B24FB4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B24FB8: TBZ w8, #0, #0xb24fc8      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_23;
        // 0x00B24FBC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B24FC0: CBNZ w8, #0xb24fc8         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
        // 0x00B24FC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_23:
        // 0x00B24FC8: LDR s0, [sp, #0xc]         | S0 = val_11.x;                          
        // 0x00B24FCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24FD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24FD4: MOV v1.16b, v12.16b        | V1 = val_11.y;//m1                      
        // 0x00B24FD8: MOV v2.16b, v13.16b        | V2 = val_11.z;//m1                      
        // 0x00B24FDC: MOV v3.16b, v14.16b        | V3 = val_13.x;//m1                      
        // 0x00B24FE0: MOV v4.16b, v15.16b        | V4 = val_13.y;//m1                      
        // 0x00B24FE4: MOV v5.16b, v11.16b        | V5 = val_13.z;//m1                      
        // 0x00B24FE8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, b:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z});
        UnityEngine.Vector3 val_14 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, b:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z});
        // 0x00B24FEC: STP s0, s1, [sp, #0x10]    | stack[1152921513116589248] = val_14.x;  stack[1152921513116589252] = val_14.y;  //  dest_result_addr=1152921513116589248 |  dest_result_addr=1152921513116589252
        // 0x00B24FF0: STR s2, [sp, #0x18]        | stack[1152921513116589256] = val_14.z;   //  dest_result_addr=1152921513116589256
        // 0x00B24FF4: LDR w21, [x19, #0x90]      | W21 = this.currentWaypointIndex; //P2   
        // 0x00B24FF8: CBNZ x20, #0xb25000        | if (this.path.vectorPath != null) goto label_24;
        if(this.path.vectorPath != null)
        {
            goto label_24;
        }
        // 0x00B24FFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_24:
        // 0x00B25000: LDR x2, [x24]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00B25004: SUB w1, w21, #1            | W1 = (this.currentWaypointIndex - 1);   
        int val_15 = this.currentWaypointIndex - 1;
        // 0x00B25008: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B2500C: BL #0x264334c              | X0 = this.path.vectorPath.get_Item(index:  int val_15 = this.currentWaypointIndex - 1);
        UnityEngine.Vector3 val_16 = this.path.vectorPath.Item[val_15];
        // 0x00B25010: LDR w21, [x19, #0x90]      | W21 = this.currentWaypointIndex; //P2   
        // 0x00B25014: MOV v11.16b, v0.16b        | V11 = val_16.x;//m1                     
        // 0x00B25018: MOV v12.16b, v1.16b        | V12 = val_16.y;//m1                     
        // 0x00B2501C: MOV v13.16b, v2.16b        | V13 = val_16.z;//m1                     
        // 0x00B25020: CBNZ x20, #0xb25028        | if (this.path.vectorPath != null) goto label_25;
        if(this.path.vectorPath != null)
        {
            goto label_25;
        }
        // 0x00B25024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.path.vectorPath, ????);
        label_25:
        // 0x00B25028: LDR x2, [x24]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00B2502C: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B25030: MOV w1, w21                | W1 = this.currentWaypointIndex;//m1     
        // 0x00B25034: BL #0x264334c              | X0 = this.path.vectorPath.get_Item(index:  this.currentWaypointIndex);
        UnityEngine.Vector3 val_17 = this.path.vectorPath.Item[this.currentWaypointIndex];
        // 0x00B25038: STP s1, s2, [sp, #4]       | stack[1152921513116589236] = val_17.y;  stack[1152921513116589240] = val_17.z;  //  dest_result_addr=1152921513116589236 |  dest_result_addr=1152921513116589240
        // 0x00B2503C: STR s0, [sp]               | stack[1152921513116589232] = val_17.x;   //  dest_result_addr=1152921513116589232
        // 0x00B25040: MOV x0, x19                | X0 = 1152921513116601392 (0x10000001FB388C30);//ML01
        // 0x00B25044: MOV v0.16b, v10.16b        | V0 = currentPosition.x;//m1             
        // 0x00B25048: MOV v1.16b, v9.16b         | V1 = currentPosition.y;//m1             
        // 0x00B2504C: MOV v2.16b, v8.16b         | V2 = currentPosition.z;//m1             
        // 0x00B25050: MOV v3.16b, v11.16b        | V3 = val_16.x;//m1                      
        // 0x00B25054: MOV v4.16b, v12.16b        | V4 = val_16.y;//m1                      
        // 0x00B25058: MOV v5.16b, v13.16b        | V5 = val_16.z;//m1                      
        // 0x00B2505C: BL #0xb2543c               | X0 = this.CalculateTargetPoint(p:  new UnityEngine.Vector3() {x = currentPosition.x, y = currentPosition.y, z = currentPosition.z}, a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.z, z = val_14.x});
        UnityEngine.Vector3 val_18 = this.CalculateTargetPoint(p:  new UnityEngine.Vector3() {x = currentPosition.x, y = currentPosition.y, z = currentPosition.z}, a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.z, z = val_14.x});
        // 0x00B25060: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25064: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25068: MOV v3.16b, v10.16b        | V3 = currentPosition.x;//m1             
        // 0x00B2506C: MOV v4.16b, v9.16b         | V4 = currentPosition.y;//m1             
        // 0x00B25070: MOV v5.16b, v8.16b         | V5 = currentPosition.z;//m1             
        // 0x00B25074: MOV v12.16b, v0.16b        | V12 = val_18.x;//m1                     
        // 0x00B25078: MOV v14.16b, v1.16b        | V14 = val_18.y;//m1                     
        // 0x00B2507C: MOV v11.16b, v2.16b        | V11 = val_18.z;//m1                     
        // 0x00B25080: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = currentPosition.x, y = currentPosition.y, z = currentPosition.z});
        UnityEngine.Vector3 val_19 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = currentPosition.x, y = currentPosition.y, z = currentPosition.z});
        // 0x00B25084: ADD x0, sp, #0x10          | X0 = (1152921513116589232 + 16) = 1152921513116589248 (0x10000001FB385CC0);
        // 0x00B25088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2508C: STR s0, [sp, #0x10]        | stack[1152921513116589248] = val_19.x;   //  dest_result_addr=1152921513116589248
        // 0x00B25090: STR s2, [sp, #0x18]        | stack[1152921513116589256] = val_19.z;   //  dest_result_addr=1152921513116589256
        // 0x00B25094: STR wzr, [sp, #0x14]       | stack[1152921513116589252] = 0x0;        //  dest_result_addr=1152921513116589252
        // 0x00B25098: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
        // 0x00B2509C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B250A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B250A4: MOV v8.16b, v0.16b         | V8 = val_19.x;//m1                      
        // 0x00B250A8: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_20 = UnityEngine.Time.deltaTime;
        // 0x00B250AC: ADRP x24, #0x363f000       | X24 = 56881152 (0x363F000);             
        // 0x00B250B0: LDR x24, [x24, #0x3b0]     | X24 = 1152921504695345152;              
        // 0x00B250B4: LDR s9, [x19, #0x34]       | S9 = this.slowdownDistance; //P2        
        // 0x00B250B8: MOV v13.16b, v0.16b        | V13 = val_20;//m1                       
        float val_34 = val_20;
        // 0x00B250BC: LDR x0, [x24]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B250C0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B250C4: TBZ w8, #0, #0xb250d4      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x00B250C8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B250CC: CBNZ w8, #0xb250d4         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x00B250D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_27:
        // 0x00B250D4: FDIV s0, s8, s9            | S0 = (val_19.x / this.slowdownDistance);
        float val_21 = val_19.x / this.slowdownDistance;
        // 0x00B250D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B250DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B250E0: BL #0x1a7dd00              | X0 = UnityEngine.Mathf.Clamp01(value:  float val_21 = val_19.x / this.slowdownDistance);
        float val_22 = UnityEngine.Mathf.Clamp01(value:  val_21);
        // 0x00B250E4: LDP w8, w9, [sp, #0x10]    | W8 = val_19.x; W9 = 0x0;                 //  | 
        // 0x00B250E8: LDR w10, [sp, #0x18]       | W10 = val_19.z;                         
        // 0x00B250EC: STP s12, s14, [x19, #0xac] | this.targetPoint = val_18;  mem[1152921513116601568] = val_18.y;  //  dest_result_addr=1152921513116601564 |  dest_result_addr=1152921513116601568
        this.targetPoint = val_18;
        mem[1152921513116601568] = val_18.y;
        // 0x00B250F0: LDR x21, [x19, #0x58]      | X21 = this.tr; //P2                     
        // 0x00B250F4: MOV v15.16b, v0.16b        | V15 = val_22;//m1                       
        // 0x00B250F8: STP w8, w9, [x19, #0xb8]   | this.targetDirection = val_19;  mem[1152921513116601580] = 0x0;  //  dest_result_addr=1152921513116601576 |  dest_result_addr=1152921513116601580
        this.targetDirection = val_19;
        mem[1152921513116601580] = 0;
        // 0x00B250FC: STR w10, [x19, #0xc0]      | mem[1152921513116601584] = val_19.z;     //  dest_result_addr=1152921513116601584
        mem[1152921513116601584] = val_19.z;
        // 0x00B25100: STR s11, [x19, #0xb4]      | mem[1152921513116601572] = val_18.z;     //  dest_result_addr=1152921513116601572
        mem[1152921513116601572] = val_18.z;
        // 0x00B25104: CBNZ x21, #0xb2510c        | if (this.tr != null) goto label_28;     
        if(this.tr != null)
        {
            goto label_28;
        }
        // 0x00B25108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_28:
        // 0x00B2510C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25110: MOV x0, x21                | X0 = this.tr;//m1                       
        // 0x00B25114: BL #0x2693ec0              | X0 = this.tr.get_forward();             
        UnityEngine.Vector3 val_23 = this.tr.forward;
        // 0x00B25118: ADD x0, sp, #0x10          | X0 = (1152921513116589232 + 16) = 1152921513116589248 (0x10000001FB385CC0);
        // 0x00B2511C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25120: MOV v9.16b, v0.16b         | V9 = val_23.x;//m1                      
        // 0x00B25124: MOV v10.16b, v1.16b        | V10 = val_23.y;//m1                     
        // 0x00B25128: MOV v11.16b, v2.16b        | V11 = val_23.z;//m1                     
        // 0x00B2512C: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00B25130: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25134: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25138: MOV v3.16b, v9.16b         | V3 = val_23.x;//m1                      
        // 0x00B2513C: MOV v4.16b, v10.16b        | V4 = val_23.y;//m1                      
        // 0x00B25140: MOV v5.16b, v11.16b        | V5 = val_23.z;//m1                      
        // 0x00B25144: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, rhs:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z});
        float val_24 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, rhs:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z});
        // 0x00B25148: LDR s1, [x19, #0x48]       | S1 = this.minMoveScale; //P2            
        // 0x00B2514C: LDR s12, [x19, #0x2c]      | S12 = this.speed; //P2                  
        // 0x00B25150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25154: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25158: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  float val_24 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, rhs:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}), b:  this.minMoveScale);
        float val_25 = UnityEngine.Mathf.Max(a:  val_24, b:  this.minMoveScale);
        // 0x00B2515C: FMUL s0, s12, s0           | S0 = (this.speed * val_25);             
        val_41 = this.speed * val_25;
        // 0x00B25160: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25164: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25168: FMUL s12, s15, s0          | S12 = (val_22 * (this.speed * val_25)); 
        val_42 = val_22 * val_41;
        // 0x00B2516C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_26 = UnityEngine.Time.deltaTime;
        // 0x00B25170: FCMP s0, #0.0              | STATE = COMPARE(val_26, 0)              
        // 0x00B25174: B.LE #0xb251b4             | if (val_26 <= 0) goto label_29;         
        if(val_26 <= 0f)
        {
            goto label_29;
        }
        // 0x00B25178: LDR x0, [x24]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B2517C: FDIV s0, s8, s13           | S0 = (val_19.x / val_20);               
        float val_27 = val_19.x / val_34;
        // 0x00B25180: FADD s13, s0, s0           | S13 = ((val_19.x / val_20) + (val_19.x / val_20));
        val_34 = val_27 + val_27;
        // 0x00B25184: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B25188: TBZ w8, #0, #0xb25198      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_31;
        // 0x00B2518C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B25190: CBNZ w8, #0xb25198         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
        // 0x00B25194: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_31:
        // 0x00B25198: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2519C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B251A0: FMOV s1, wzr               | S1 = 0f;                                
        // 0x00B251A4: MOV v0.16b, v12.16b        | V0 = (val_22 * (this.speed * val_25));//m1
        val_41 = val_42;
        // 0x00B251A8: MOV v2.16b, v13.16b        | V2 = ((val_19.x / val_20) + (val_19.x / val_20));//m1
        // 0x00B251AC: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  val_41 = val_42, min:  0f, max:  val_20);
        float val_28 = UnityEngine.Mathf.Clamp(value:  val_41, min:  0f, max:  val_34);
        // 0x00B251B0: MOV v12.16b, v0.16b        | V12 = val_28;//m1                       
        val_42 = val_28;
        label_29:
        // 0x00B251B4: LDR w24, [x19, #0x90]      | W24 = this.currentWaypointIndex; //P2   
        // 0x00B251B8: CBNZ x20, #0xb251c0        | if (this.path.vectorPath != null) goto label_32;
        if(this.path.vectorPath != null)
        {
            goto label_32;
        }
        // 0x00B251BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_32:
        // 0x00B251C0: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B251C4: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B251C8: BL #0x2643344              | X0 = this.path.vectorPath.get_Count();  
        int val_29 = this.path.vectorPath.Count;
        // 0x00B251CC: MOV w21, w0                | W21 = val_29;//m1                       
        // 0x00B251D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B251D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_43 = 0;
        // 0x00B251D8: BL #0x2691094              | X0 = UnityEngine.Time.get_timeScale();  
        float val_30 = UnityEngine.Time.timeScale;
        // 0x00B251DC: FCVTZS w8, s0              | W8 = (int)(val_30);                     
        int val_35 = (int)val_30;
        // 0x00B251E0: SUB w8, w21, w8            | W8 = (val_29 - val_30);                 
        val_35 = val_29 - val_35;
        // 0x00B251E4: CMP w24, w8                | STATE = COMPARE(this.currentWaypointIndex, (val_29 - val_30))
        // 0x00B251E8: B.GE #0xb25210             | if (this.currentWaypointIndex >= (int)val_30) goto label_33;
        if(this.currentWaypointIndex >= val_35)
        {
            goto label_33;
        }
        // 0x00B251EC: LDR w21, [x19, #0x90]      | W21 = this.currentWaypointIndex; //P2   
        // 0x00B251F0: CBNZ x20, #0xb251f8        | if (this.path.vectorPath != null) goto label_34;
        if(this.path.vectorPath != null)
        {
            goto label_34;
        }
        // 0x00B251F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_34:
        // 0x00B251F8: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        val_43 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B251FC: MOV x0, x20                | X0 = this.path.vectorPath;//m1          
        // 0x00B25200: BL #0x2643344              | X0 = this.path.vectorPath.get_Count();  
        int val_31 = this.path.vectorPath.Count;
        // 0x00B25204: SUB w8, w0, #1             | W8 = (val_31 - 1);                      
        int val_32 = val_31 - 1;
        // 0x00B25208: CMP w21, w8                | STATE = COMPARE(this.currentWaypointIndex, (val_31 - 1))
        // 0x00B2520C: B.GT #0xb2521c             | if (this.currentWaypointIndex > val_32) goto label_35;
        if(this.currentWaypointIndex > val_32)
        {
            goto label_35;
        }
        label_33:
        // 0x00B25210: LDR s0, [x19, #0x40]       | S0 = this.endReachedDistance; //P2      
        // 0x00B25214: FCMP s8, s0                | STATE = COMPARE(val_19.x, this.endReachedDistance)
        // 0x00B25218: B.LS #0xb25254             | if (val_19.x <= this.endReachedDistance) goto label_36;
        if(val_19.x <= this.endReachedDistance)
        {
            goto label_36;
        }
        label_35:
        // 0x00B2521C: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B25220: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B25224: TBZ w8, #0, #0xb25234      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_38;
        // 0x00B25228: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B2522C: CBNZ w8, #0xb25234         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
        // 0x00B25230: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_38:
        // 0x00B25234: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25238: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2523C: MOV v0.16b, v9.16b         | V0 = val_23.x;//m1                      
        // 0x00B25240: MOV v1.16b, v10.16b        | V1 = val_23.y;//m1                      
        // 0x00B25244: MOV v2.16b, v11.16b        | V2 = val_23.z;//m1                      
        // 0x00B25248: MOV v3.16b, v12.16b        | V3 = val_28;//m1                        
        // 0x00B2524C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, d:  val_42);
        UnityEngine.Vector3 val_33 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, d:  val_42);
        // 0x00B25250: B #0xb24e74                |  goto label_39;                         
        goto label_39;
        label_36:
        // 0x00B25254: LDRB w8, [x19, #0x94]      | W8 = this.targetReached; //P2           
        // 0x00B25258: CBNZ w8, #0xb25274         | if (this.targetReached == true) goto label_40;
        if(this.targetReached == true)
        {
            goto label_40;
        }
        // 0x00B2525C: LDR x8, [x19]              | X8 = typeof(AIPath);                    
        // 0x00B25260: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00B25264: STRB w9, [x19, #0x94]      | this.targetReached = true;               //  dest_result_addr=1152921513116601540
        this.targetReached = true;
        // 0x00B25268: MOV x0, x19                | X0 = 1152921513116601392 (0x10000001FB388C30);//ML01
        // 0x00B2526C: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(AIPath).__il2cppRuntimeField_1B0; X1 = typeof(AIPath).__il2cppRuntimeField_1B8; //  | 
        // 0x00B25270: BLR x9                     | X0 = typeof(AIPath).__il2cppRuntimeField_1B0();
        label_40:
        // 0x00B25274: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B25278: B #0xb24e54                |  goto label_41;                         
        goto label_41;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B256CC (11687628), len: 500  VirtAddr: 0x00B256CC RVA: 0x00B256CC token: 100681735 methodIndex: 24758 delegateWrapperIndex: 0 methodInvoker: 0
    protected virtual void RotateTowards(UnityEngine.Vector3 dir)
    {
        //
        // Disasemble & Code
        //  | 
        float val_9;
        //  | 
        float val_10;
        //  | 
        UnityEngine.Transform val_11;
        // 0x00B256CC: STP d15, d14, [sp, #-0x60]! | stack[1152921513116729968] = ???;  stack[1152921513116729976] = ???;  //  dest_result_addr=1152921513116729968 |  dest_result_addr=1152921513116729976
        // 0x00B256D0: STP d13, d12, [sp, #0x10]  | stack[1152921513116729984] = ???;  stack[1152921513116729992] = ???;  //  dest_result_addr=1152921513116729984 |  dest_result_addr=1152921513116729992
        // 0x00B256D4: STP d11, d10, [sp, #0x20]  | stack[1152921513116730000] = ???;  stack[1152921513116730008] = ???;  //  dest_result_addr=1152921513116730000 |  dest_result_addr=1152921513116730008
        // 0x00B256D8: STP d9, d8, [sp, #0x30]    | stack[1152921513116730016] = ???;  stack[1152921513116730024] = ???;  //  dest_result_addr=1152921513116730016 |  dest_result_addr=1152921513116730024
        // 0x00B256DC: STP x20, x19, [sp, #0x40]  | stack[1152921513116730032] = ???;  stack[1152921513116730040] = ???;  //  dest_result_addr=1152921513116730032 |  dest_result_addr=1152921513116730040
        // 0x00B256E0: STP x29, x30, [sp, #0x50]  | stack[1152921513116730048] = ???;  stack[1152921513116730056] = ???;  //  dest_result_addr=1152921513116730048 |  dest_result_addr=1152921513116730056
        // 0x00B256E4: ADD x29, sp, #0x50         | X29 = (1152921513116729968 + 80) = 1152921513116730048 (0x10000001FB3A82C0);
        // 0x00B256E8: SUB sp, sp, #0x20          | SP = (1152921513116729968 - 32) = 1152921513116729936 (0x10000001FB3A8250);
        // 0x00B256EC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B256F0: LDRB w8, [x20, #0x73a]     | W8 = (bool)static_value_0373373A;       
        // 0x00B256F4: MOV v8.16b, v2.16b         | V8 = dir.z;//m1                         
        val_9 = dir.z;
        // 0x00B256F8: MOV v9.16b, v1.16b         | V9 = dir.y;//m1                         
        // 0x00B256FC: MOV v10.16b, v0.16b        | V10 = dir.x;//m1                        
        val_10 = dir.x;
        // 0x00B25700: MOV x19, x0                | X19 = 1152921513116742064 (0x10000001FB3AB1B0);//ML01
        val_11 = this;
        // 0x00B25704: TBNZ w8, #0, #0xb25720     | if (static_value_0373373A == true) goto label_0;
        // 0x00B25708: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00B2570C: LDR x8, [x8, #0xde8]       | X8 = 0x2B8ABE4;                         
        // 0x00B25710: LDR w0, [x8]               | W0 = 0x1B7;                             
        // 0x00B25714: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B7, ????);      
        // 0x00B25718: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2571C: STRB w8, [x20, #0x73a]     | static_value_0373373A = true;            //  dest_result_addr=57882426
        label_0:
        // 0x00B25720: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B25724: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B25728: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B2572C: STP xzr, xzr, [sp, #0x10]  | stack[1152921513116729952] = 0x0;  stack[1152921513116729960] = 0x0;  //  dest_result_addr=1152921513116729952 |  dest_result_addr=1152921513116729960
        // 0x00B25730: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B25734: TBZ w8, #0, #0xb25744      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B25738: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B2573C: CBNZ w8, #0xb25744         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B25740: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_2:
        // 0x00B25744: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2574C: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_1 = UnityEngine.Vector3.zero;
        // 0x00B25750: MOV v3.16b, v0.16b         | V3 = val_1.x;//m1                       
        // 0x00B25754: MOV v4.16b, v1.16b         | V4 = val_1.y;//m1                       
        // 0x00B25758: MOV v5.16b, v2.16b         | V5 = val_1.z;//m1                       
        // 0x00B2575C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25760: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25764: MOV v0.16b, v10.16b        | V0 = dir.x;//m1                         
        // 0x00B25768: MOV v1.16b, v9.16b         | V1 = dir.y;//m1                         
        // 0x00B2576C: MOV v2.16b, v8.16b         | V2 = dir.z;//m1                         
        // 0x00B25770: BL #0x269a824              | X0 = UnityEngine.Vector3.op_Equality(lhs:  new UnityEngine.Vector3() {x = val_10, y = dir.y, z = val_9}, rhs:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z});
        bool val_2 = UnityEngine.Vector3.op_Equality(lhs:  new UnityEngine.Vector3() {x = val_10, y = dir.y, z = val_9}, rhs:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z});
        // 0x00B25774: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B25778: TBNZ w8, #0, #0xb258a0     | if ((val_2 & 1) == true) goto label_3;  
        if(val_3 == true)
        {
            goto label_3;
        }
        // 0x00B2577C: LDR x20, [x19, #0x58]      | X20 = this.tr; //P2                     
        // 0x00B25780: CBNZ x20, #0xb25788        | if (this.tr != null) goto label_4;      
        if(this.tr != null)
        {
            goto label_4;
        }
        // 0x00B25784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B25788: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2578C: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B25790: BL #0x26937d8              | X0 = this.tr.get_rotation();            
        UnityEngine.Quaternion val_4 = this.tr.rotation;
        // 0x00B25794: STP s0, s0, [sp, #0xc]     | stack[1152921513116729948] = val_4.x;  stack[1152921513116729952] = val_4.x;  //  dest_result_addr=1152921513116729948 |  dest_result_addr=1152921513116729952
        // 0x00B25798: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B2579C: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00B257A0: MOV v12.16b, v1.16b        | V12 = val_4.y;//m1                      
        // 0x00B257A4: MOV v13.16b, v2.16b        | V13 = val_4.z;//m1                      
        // 0x00B257A8: MOV v14.16b, v3.16b        | V14 = val_4.w;//m1                      
        // 0x00B257AC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00B257B0: STP s12, s13, [sp, #0x14]  | stack[1152921513116729956] = val_4.y;  stack[1152921513116729960] = val_4.z;  //  dest_result_addr=1152921513116729956 |  dest_result_addr=1152921513116729960
        // 0x00B257B4: STR s14, [sp, #0x1c]       | stack[1152921513116729964] = val_4.w;    //  dest_result_addr=1152921513116729964
        // 0x00B257B8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00B257BC: TBZ w8, #0, #0xb257cc      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B257C0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00B257C4: CBNZ w8, #0xb257cc         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B257C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_6:
        // 0x00B257CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B257D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B257D4: MOV v0.16b, v10.16b        | V0 = dir.x;//m1                         
        // 0x00B257D8: MOV v1.16b, v9.16b         | V1 = dir.y;//m1                         
        // 0x00B257DC: MOV v2.16b, v8.16b         | V2 = dir.z;//m1                         
        // 0x00B257E0: BL #0x1b7e8c4              | X0 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_10, y = dir.y, z = val_9});
        UnityEngine.Quaternion val_5 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_10, y = dir.y, z = val_9});
        // 0x00B257E4: LDR s11, [x19, #0x30]      | S11 = this.turningSpeed; //P2           
        // 0x00B257E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B257EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B257F0: MOV v8.16b, v0.16b         | V8 = val_5.x;//m1                       
        // 0x00B257F4: MOV v9.16b, v1.16b         | V9 = val_5.y;//m1                       
        // 0x00B257F8: MOV v10.16b, v2.16b        | V10 = val_5.z;//m1                      
        // 0x00B257FC: MOV v15.16b, v3.16b        | V15 = val_5.w;//m1                      
        // 0x00B25800: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_6 = UnityEngine.Time.deltaTime;
        // 0x00B25804: FMUL s0, s11, s0           | S0 = (this.turningSpeed * val_6);       
        val_6 = this.turningSpeed * val_6;
        // 0x00B25808: STR s0, [sp]               | stack[1152921513116729936] = (this.turningSpeed * val_6);  //  dest_result_addr=1152921513116729936
        // 0x00B2580C: LDR s0, [sp, #0xc]         | S0 = val_4.x;                           
        // 0x00B25810: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25814: MOV v1.16b, v12.16b        | V1 = val_4.y;//m1                       
        // 0x00B25818: MOV v2.16b, v13.16b        | V2 = val_4.z;//m1                       
        // 0x00B2581C: MOV v3.16b, v14.16b        | V3 = val_4.w;//m1                       
        // 0x00B25820: MOV v4.16b, v8.16b         | V4 = val_5.x;//m1                       
        // 0x00B25824: MOV v5.16b, v9.16b         | V5 = val_5.y;//m1                       
        // 0x00B25828: MOV v6.16b, v10.16b        | V6 = val_5.z;//m1                       
        // 0x00B2582C: MOV v7.16b, v15.16b        | V7 = val_5.w;//m1                       
        // 0x00B25830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25834: BL #0x1b7e988              | X0 = UnityEngine.Quaternion.Slerp(a:  new UnityEngine.Quaternion() {x = val_4.x, y = val_4.y, z = val_4.z, w = val_4.w}, b:  new UnityEngine.Quaternion() {x = val_5.x, y = val_5.y, z = val_5.z, w = val_5.w}, t:  val_6);
        UnityEngine.Quaternion val_7 = UnityEngine.Quaternion.Slerp(a:  new UnityEngine.Quaternion() {x = val_4.x, y = val_4.y, z = val_4.z, w = val_4.w}, b:  new UnityEngine.Quaternion() {x = val_5.x, y = val_5.y, z = val_5.z, w = val_5.w}, t:  val_6);
        // 0x00B25838: ADD x0, sp, #0x10          | X0 = (1152921513116729936 + 16) = 1152921513116729952 (0x10000001FB3A8260);
        // 0x00B2583C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25840: STP s0, s1, [sp, #0x10]    | stack[1152921513116729952] = val_7.x;  stack[1152921513116729956] = val_7.y;  //  dest_result_addr=1152921513116729952 |  dest_result_addr=1152921513116729956
        // 0x00B25844: STP s2, s3, [sp, #0x18]    | stack[1152921513116729960] = val_7.z;  stack[1152921513116729964] = val_7.w;  //  dest_result_addr=1152921513116729960 |  dest_result_addr=1152921513116729964
        // 0x00B25848: BL #0x1b7f1cc              | X0 = label_UnityEngine_Quaternion_INTERNAL_CALL_Inverse_GL01B7F1CC();
        // 0x00B2584C: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B25850: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25854: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25858: MOV v2.16b, v0.16b         | V2 = 0;//m1                             
        // 0x00B2585C: BL #0x1b7f628              | X0 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = 0f, y = val_7.y, z = 0f});
        UnityEngine.Quaternion val_8 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = 0f, y = val_7.y, z = 0f});
        // 0x00B25860: MOV v8.16b, v0.16b         | V8 = val_8.x;//m1                       
        val_9 = val_8.x;
        // 0x00B25864: MOV v9.16b, v1.16b         | V9 = val_8.y;//m1                       
        // 0x00B25868: MOV v10.16b, v2.16b        | V10 = val_8.z;//m1                      
        val_10 = val_8.z;
        // 0x00B2586C: MOV v11.16b, v3.16b        | V11 = val_8.w;//m1                      
        // 0x00B25870: STP s8, s9, [sp, #0x10]    | stack[1152921513116729952] = val_8.x;  stack[1152921513116729956] = val_8.y;  //  dest_result_addr=1152921513116729952 |  dest_result_addr=1152921513116729956
        // 0x00B25874: STP s10, s11, [sp, #0x18]  | stack[1152921513116729960] = val_8.z;  stack[1152921513116729964] = val_8.w;  //  dest_result_addr=1152921513116729960 |  dest_result_addr=1152921513116729964
        // 0x00B25878: LDR x19, [x19, #0x58]      | X19 = this.tr; //P2                     
        val_11 = this.tr;
        // 0x00B2587C: CBNZ x19, #0xb25884        | if (this.tr != null) goto label_7;      
        if(val_11 != null)
        {
            goto label_7;
        }
        // 0x00B25880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_7:
        // 0x00B25884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25888: MOV x0, x19                | X0 = this.tr;//m1                       
        // 0x00B2588C: MOV v0.16b, v8.16b         | V0 = val_8.x;//m1                       
        // 0x00B25890: MOV v1.16b, v9.16b         | V1 = val_8.y;//m1                       
        // 0x00B25894: MOV v2.16b, v10.16b        | V2 = val_8.z;//m1                       
        // 0x00B25898: MOV v3.16b, v11.16b        | V3 = val_8.w;//m1                       
        // 0x00B2589C: BL #0x26938b0              | this.tr.set_rotation(value:  new UnityEngine.Quaternion() {x = val_9, y = val_8.y, z = val_10, w = val_8.w});
        val_11.rotation = new UnityEngine.Quaternion() {x = val_9, y = val_8.y, z = val_10, w = val_8.w};
        label_3:
        // 0x00B258A0: SUB sp, x29, #0x50         | SP = (1152921513116730048 - 80) = 1152921513116729968 (0x10000001FB3A8270);
        // 0x00B258A4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B258A8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B258AC: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B258B0: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B258B4: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B258B8: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
        // 0x00B258BC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2543C (11686972), len: 656  VirtAddr: 0x00B2543C RVA: 0x00B2543C token: 100681736 methodIndex: 24759 delegateWrapperIndex: 0 methodInvoker: 0
    protected UnityEngine.Vector3 CalculateTargetPoint(UnityEngine.Vector3 p, UnityEngine.Vector3 a, UnityEngine.Vector3 b)
    {
        //
        // Disasemble & Code
        //  | 
        float val_13;
        //  | 
        float val_14;
        //  | 
        float val_15;
        //  | 
        float val_16;
        //  | 
        var val_17;
        //  | 
        var val_18;
        //  | 
        var val_19;
        // 0x00B2543C: STP d15, d14, [sp, #-0x60]! | stack[1152921513116850160] = ???;  stack[1152921513116850168] = ???;  //  dest_result_addr=1152921513116850160 |  dest_result_addr=1152921513116850168
        // 0x00B25440: STP d13, d12, [sp, #0x10]  | stack[1152921513116850176] = ???;  stack[1152921513116850184] = ???;  //  dest_result_addr=1152921513116850176 |  dest_result_addr=1152921513116850184
        // 0x00B25444: STP d11, d10, [sp, #0x20]  | stack[1152921513116850192] = ???;  stack[1152921513116850200] = ???;  //  dest_result_addr=1152921513116850192 |  dest_result_addr=1152921513116850200
        // 0x00B25448: STP d9, d8, [sp, #0x30]    | stack[1152921513116850208] = ???;  stack[1152921513116850216] = ???;  //  dest_result_addr=1152921513116850208 |  dest_result_addr=1152921513116850216
        // 0x00B2544C: STP x20, x19, [sp, #0x40]  | stack[1152921513116850224] = ???;  stack[1152921513116850232] = ???;  //  dest_result_addr=1152921513116850224 |  dest_result_addr=1152921513116850232
        // 0x00B25450: STP x29, x30, [sp, #0x50]  | stack[1152921513116850240] = ???;  stack[1152921513116850248] = ???;  //  dest_result_addr=1152921513116850240 |  dest_result_addr=1152921513116850248
        // 0x00B25454: ADD x29, sp, #0x50         | X29 = (1152921513116850160 + 80) = 1152921513116850240 (0x10000001FB3C5840);
        // 0x00B25458: SUB sp, sp, #0x30          | SP = (1152921513116850160 - 48) = 1152921513116850112 (0x10000001FB3C57C0);
        // 0x00B2545C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B25460: LDRB w8, [x20, #0x73b]     | W8 = (bool)static_value_0373373B;       
        // 0x00B25464: MOV v8.16b, v5.16b         | V8 = a.z;//m1                           
        val_13 = a.z;
        // 0x00B25468: MOV v9.16b, v3.16b         | V9 = a.x;//m1                           
        val_14 = a.x;
        // 0x00B2546C: MOV v13.16b, v2.16b        | V13 = p.z;//m1                          
        // 0x00B25470: MOV v10.16b, v1.16b        | V10 = p.y;//m1                          
        val_15 = p.y;
        // 0x00B25474: MOV v14.16b, v0.16b        | V14 = p.x;//m1                          
        val_16 = p.x;
        // 0x00B25478: MOV x19, x0                | X19 = 1152921513116862256 (0x10000001FB3C8730);//ML01
        // 0x00B2547C: TBNZ w8, #0, #0xb25498     | if (static_value_0373373B == true) goto label_0;
        // 0x00B25480: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B25484: LDR x8, [x8, #0x238]       | X8 = 0x2B8ABC8;                         
        // 0x00B25488: LDR w0, [x8]               | W0 = 0x1B0;                             
        // 0x00B2548C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B0, ????);      
        // 0x00B25490: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B25494: STRB w8, [x20, #0x73b]     | static_value_0373373B = true;            //  dest_result_addr=57882427
        label_0:
        // 0x00B25498: ADRP x20, #0x3673000       | X20 = 57094144 (0x3673000);             
        // 0x00B2549C: STR wzr, [sp, #0x28]       | stack[1152921513116850152] = 0x0;        //  dest_result_addr=1152921513116850152
        // 0x00B254A0: LDR x20, [x20, #0x488]     | X20 = 1152921504695078912;              
        // 0x00B254A4: LDR s11, [x29, #0x18]      | S11 = b.y;                              
        // 0x00B254A8: LDR s12, [x29, #0x10]      | S12 = b.x;                              
        // 0x00B254AC: STR xzr, [sp, #0x20]       | stack[1152921513116850144] = 0x0;        //  dest_result_addr=1152921513116850144
        // 0x00B254B0: LDR x0, [x20]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B254B4: STR wzr, [sp, #0x18]       | stack[1152921513116850136] = 0x0;        //  dest_result_addr=1152921513116850136
        // 0x00B254B8: STR xzr, [sp, #0x10]       | stack[1152921513116850128] = 0x0;        //  dest_result_addr=1152921513116850128
        // 0x00B254BC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B254C0: TBZ w8, #0, #0xb254d0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B254C4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B254C8: CBNZ w8, #0xb254d0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B254CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_2:
        // 0x00B254D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B254D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B254D8: MOV v0.16b, v9.16b         | V0 = a.x;//m1                           
        // 0x00B254DC: MOV v1.16b, v10.16b        | V1 = p.y;//m1                           
        // 0x00B254E0: MOV v2.16b, v8.16b         | V2 = a.z;//m1                           
        // 0x00B254E4: MOV v3.16b, v12.16b        | V3 = b.x;//m1                           
        // 0x00B254E8: MOV v4.16b, v10.16b        | V4 = p.y;//m1                           
        // 0x00B254EC: MOV v5.16b, v11.16b        | V5 = b.y;//m1                           
        // 0x00B254F0: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13}, b:  new UnityEngine.Vector3() {x = b.x, y = val_15, z = b.y});
        UnityEngine.Vector3 val_1 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13}, b:  new UnityEngine.Vector3() {x = b.x, y = val_15, z = b.y});
        // 0x00B254F4: ADD x0, sp, #0x20          | X0 = (1152921513116850112 + 32) = 1152921513116850144 (0x10000001FB3C57E0);
        // 0x00B254F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B254FC: STP s0, s1, [sp, #0x20]    | stack[1152921513116850144] = val_1.x;  stack[1152921513116850148] = val_1.y;  //  dest_result_addr=1152921513116850144 |  dest_result_addr=1152921513116850148
        // 0x00B25500: STR s2, [sp, #0x28]        | stack[1152921513116850152] = val_1.z;    //  dest_result_addr=1152921513116850152
        // 0x00B25504: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
        // 0x00B25508: MOV v15.16b, v0.16b        | V15 = val_1.x;//m1                      
        // 0x00B2550C: FCMP s15, #0.0             | STATE = COMPARE(val_1.x, 0)             
        // 0x00B25510: B.EQ #0xb256a0             | if (val_1.x == 0) goto label_3;         
        if(val_1.x == 0f)
        {
            goto label_3;
        }
        // 0x00B25514: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25518: MOV v0.16b, v9.16b         | V0 = a.x;//m1                           
        // 0x00B2551C: MOV v1.16b, v10.16b        | V1 = p.y;//m1                           
        // 0x00B25520: MOV v2.16b, v8.16b         | V2 = a.z;//m1                           
        // 0x00B25524: MOV v3.16b, v12.16b        | V3 = b.x;//m1                           
        // 0x00B25528: MOV v4.16b, v10.16b        | V4 = p.y;//m1                           
        // 0x00B2552C: MOV v5.16b, v11.16b        | V5 = b.y;//m1                           
        // 0x00B25530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25534: STP s14, s10, [sp]         | stack[1152921513116850112] = p.x;  stack[1152921513116850116] = p.y;  //  dest_result_addr=1152921513116850112 |  dest_result_addr=1152921513116850116
        // 0x00B25538: STR s13, [sp, #8]          | stack[1152921513116850120] = p.z;        //  dest_result_addr=1152921513116850120
        // 0x00B2553C: BL #0x1683574              | X0 = Pathfinding.AstarMath.NearestPointFactor(lineStart:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13}, lineEnd:  new UnityEngine.Vector3() {x = b.x, y = val_15, z = b.y}, point:  new UnityEngine.Vector3() {x = val_16, y = p.z, z = 0f});
        float val_2 = Pathfinding.AstarMath.NearestPointFactor(lineStart:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13}, lineEnd:  new UnityEngine.Vector3() {x = b.x, y = val_15, z = b.y}, point:  new UnityEngine.Vector3() {x = val_16, y = p.z, z = 0f});
        // 0x00B25540: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25548: BL #0x1684d00              | X0 = Pathfinding.AstarMath.Clamp01(a:  float val_2 = Pathfinding.AstarMath.NearestPointFactor(lineStart:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13}, lineEnd:  new UnityEngine.Vector3() {x = b.x, y = val_15, z = b.y}, point:  new UnityEngine.Vector3() {x = val_16, y = p.z, z = 0f}));
        float val_3 = Pathfinding.AstarMath.Clamp01(a:  val_2);
        // 0x00B2554C: LDR x0, [x20]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B25550: STR s0, [sp, #0xc]         | stack[1152921513116850124] = val_3;      //  dest_result_addr=1152921513116850124
        // 0x00B25554: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B25558: TBZ w8, #0, #0xb25568      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B2555C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B25560: CBNZ w8, #0xb25568         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B25564: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_5:
        // 0x00B25568: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2556C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25570: MOV v0.16b, v12.16b        | V0 = b.x;//m1                           
        // 0x00B25574: MOV v1.16b, v10.16b        | V1 = p.y;//m1                           
        // 0x00B25578: MOV v2.16b, v11.16b        | V2 = b.y;//m1                           
        // 0x00B2557C: MOV v3.16b, v9.16b         | V3 = a.x;//m1                           
        // 0x00B25580: MOV v4.16b, v10.16b        | V4 = p.y;//m1                           
        // 0x00B25584: MOV v5.16b, v8.16b         | V5 = a.z;//m1                           
        // 0x00B25588: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = b.x, y = val_15, z = b.y}, b:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13});
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = b.x, y = val_15, z = b.y}, b:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13});
        // 0x00B2558C: LDR s3, [sp, #0xc]         | S3 = val_3;                             
        // 0x00B25590: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25594: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25598: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, d:  val_3);
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, d:  val_3);
        // 0x00B2559C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B255A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B255A4: MOV v3.16b, v9.16b         | V3 = a.x;//m1                           
        // 0x00B255A8: MOV v4.16b, v10.16b        | V4 = p.y;//m1                           
        // 0x00B255AC: MOV v5.16b, v8.16b         | V5 = a.z;//m1                           
        // 0x00B255B0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13});
        UnityEngine.Vector3 val_6 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13});
        // 0x00B255B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B255B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B255BC: MOV v3.16b, v14.16b        | V3 = p.x;//m1                           
        // 0x00B255C0: MOV v4.16b, v10.16b        | V4 = p.y;//m1                           
        // 0x00B255C4: MOV v5.16b, v13.16b        | V5 = p.z;//m1                           
        // 0x00B255C8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = val_16, y = val_15, z = p.z});
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = val_16, y = val_15, z = p.z});
        // 0x00B255CC: ADD x0, sp, #0x10          | X0 = (1152921513116850112 + 16) = 1152921513116850128 (0x10000001FB3C57D0);
        // 0x00B255D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B255D4: STP s0, s1, [sp, #0x10]    | stack[1152921513116850128] = val_7.x;  stack[1152921513116850132] = val_7.y;  //  dest_result_addr=1152921513116850128 |  dest_result_addr=1152921513116850132
        // 0x00B255D8: STR s2, [sp, #0x18]        | stack[1152921513116850136] = val_7.z;    //  dest_result_addr=1152921513116850136
        // 0x00B255DC: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
        // 0x00B255E0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B255E4: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00B255E8: LDR s13, [x19, #0x3c]      | S13 = this.forwardLook; //P2            
        // 0x00B255EC: MOV v14.16b, v0.16b        | V14 = val_7.x;//m1                      
        // 0x00B255F0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B255F4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B255F8: TBZ w8, #0, #0xb25608      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B255FC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B25600: CBNZ w8, #0xb25608         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B25604: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_7:
        // 0x00B25608: FSUB s0, s13, s14          | S0 = (this.forwardLook - val_7.x);      
        val_7.x = this.forwardLook - val_7.x;
        // 0x00B2560C: FMOV s14, wzr              | S14 = 0f;                               
        val_16 = 0f;
        // 0x00B25610: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25614: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25618: MOV v1.16b, v14.16b        | V1 = 0;//m1                             
        // 0x00B2561C: MOV v2.16b, v13.16b        | V2 = this.forwardLook;//m1              
        // 0x00B25620: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  val_7.x = this.forwardLook - val_7.x, min:  val_16, max:  this.forwardLook);
        float val_8 = UnityEngine.Mathf.Clamp(value:  val_7.x, min:  val_16, max:  this.forwardLook);
        // 0x00B25624: LDR s1, [sp, #0xc]         | S1 = val_3;                             
        // 0x00B25628: FDIV s0, s0, s15           | S0 = (val_8 / val_1.x);                 
        val_8 = val_8 / val_1.x;
        // 0x00B2562C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25634: FADD s0, s1, s0            | S0 = (val_3 + (val_8 / val_1.x));       
        val_8 = val_3 + val_8;
        // 0x00B25638: FMOV s2, #1.00000000       | S2 = 1;                                 
        // 0x00B2563C: MOV v1.16b, v14.16b        | V1 = 0;//m1                             
        // 0x00B25640: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  val_8 = val_3 + val_8, min:  val_16, max:  1f);
        float val_9 = UnityEngine.Mathf.Clamp(value:  val_8, min:  val_16, max:  1f);
        // 0x00B25644: MOV v13.16b, v0.16b        | V13 = val_9;//m1                        
        // 0x00B25648: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2564C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25650: MOV v0.16b, v12.16b        | V0 = b.x;//m1                           
        // 0x00B25654: MOV v1.16b, v10.16b        | V1 = p.y;//m1                           
        // 0x00B25658: MOV v2.16b, v11.16b        | V2 = b.y;//m1                           
        // 0x00B2565C: MOV v3.16b, v9.16b         | V3 = a.x;//m1                           
        // 0x00B25660: MOV v4.16b, v10.16b        | V4 = p.y;//m1                           
        // 0x00B25664: MOV v5.16b, v8.16b         | V5 = a.z;//m1                           
        // 0x00B25668: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = b.x, y = val_15, z = b.y}, b:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13});
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = b.x, y = val_15, z = b.y}, b:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13});
        // 0x00B2566C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25670: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25674: MOV v3.16b, v13.16b        | V3 = val_9;//m1                         
        // 0x00B25678: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, d:  val_9);
        UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, d:  val_9);
        // 0x00B2567C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25680: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25684: MOV v3.16b, v9.16b         | V3 = a.x;//m1                           
        // 0x00B25688: MOV v4.16b, v10.16b        | V4 = p.y;//m1                           
        // 0x00B2568C: MOV v5.16b, v8.16b         | V5 = a.z;//m1                           
        // 0x00B25690: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, b:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13});
        UnityEngine.Vector3 val_12 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, b:  new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13});
        // 0x00B25694: MOV v9.16b, v0.16b         | V9 = val_12.x;//m1                      
        val_14 = val_12.x;
        // 0x00B25698: MOV v10.16b, v1.16b        | V10 = val_12.y;//m1                     
        val_15 = val_12.y;
        // 0x00B2569C: MOV v8.16b, v2.16b         | V8 = val_12.z;//m1                      
        val_13 = val_12.z;
        label_3:
        // 0x00B256A0: MOV v0.16b, v9.16b         | V0 = val_12.x;//m1                      
        // 0x00B256A4: MOV v1.16b, v10.16b        | V1 = val_12.y;//m1                      
        // 0x00B256A8: MOV v2.16b, v8.16b         | V2 = val_12.z;//m1                      
        // 0x00B256AC: SUB sp, x29, #0x50         | SP = (1152921513116850240 - 80) = 1152921513116850160 (0x10000001FB3C57F0);
        // 0x00B256B0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B256B4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B256B8: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B256BC: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B256C0: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B256C4: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
        // 0x00B256C8: RET                        |  return new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13};
        return new UnityEngine.Vector3() {x = val_14, y = val_15, z = val_13};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
    
    }

}
