using UnityEngine;
private class iTween.CRSpline
{
    // Fields
    public UnityEngine.Vector3[] pts; //  0x00000010
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D9D3CC (14275532), len: 168  VirtAddr: 0x00D9D3CC RVA: 0x00D9D3CC token: 100684699 methodIndex: 46282 delegateWrapperIndex: 0 methodInvoker: 0
    public iTween.CRSpline(UnityEngine.Vector3[] pts)
    {
        //
        // Disasemble & Code
        // 0x00D9D3CC: STP x22, x21, [sp, #-0x30]! | stack[1152921513708167920] = ???;  stack[1152921513708167928] = ???;  //  dest_result_addr=1152921513708167920 |  dest_result_addr=1152921513708167928
        // 0x00D9D3D0: STP x20, x19, [sp, #0x10]  | stack[1152921513708167936] = ???;  stack[1152921513708167944] = ???;  //  dest_result_addr=1152921513708167936 |  dest_result_addr=1152921513708167944
        // 0x00D9D3D4: STP x29, x30, [sp, #0x20]  | stack[1152921513708167952] = ???;  stack[1152921513708167960] = ???;  //  dest_result_addr=1152921513708167952 |  dest_result_addr=1152921513708167960
        // 0x00D9D3D8: ADD x29, sp, #0x20         | X29 = (1152921513708167920 + 32) = 1152921513708167952 (0x100000021E7B2310);
        // 0x00D9D3DC: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D9D3E0: LDRB w8, [x21, #0x50e]     | W8 = (bool)static_value_0373450E;       
        // 0x00D9D3E4: MOV x19, x1                | X19 = pts;//m1                          
        // 0x00D9D3E8: MOV x20, x0                | X20 = 1152921513708179968 (0x100000021E7B5200);//ML01
        // 0x00D9D3EC: TBNZ w8, #0, #0xd9d408     | if (static_value_0373450E == true) goto label_0;
        // 0x00D9D3F0: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00D9D3F4: LDR x8, [x8, #0x9f8]       | X8 = 0x2B92E88;                         
        // 0x00D9D3F8: LDR w0, [x8]               | W0 = 0x2267;                            
        // 0x00D9D3FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2267, ????);     
        // 0x00D9D400: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D9D404: STRB w8, [x21, #0x50e]     | static_value_0373450E = true;            //  dest_result_addr=57885966
        label_0:
        // 0x00D9D408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D40C: MOV x0, x20                | X0 = 1152921513708179968 (0x100000021E7B5200);//ML01
        // 0x00D9D410: BL #0x16f59f0              | this..ctor();                           
        // 0x00D9D414: CBNZ x19, #0xd9d41c        | if (pts != null) goto label_1;          
        if(pts != null)
        {
            goto label_1;
        }
        // 0x00D9D418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_1:
        // 0x00D9D41C: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00D9D420: LDR x8, [x8, #0xf20]       | X8 = 1152921505026973680;               
        // 0x00D9D424: LDR w22, [x19, #0x18]      | W22 = pts.Length; //P2                  
        // 0x00D9D428: LDR x21, [x8]              | X21 = typeof(UnityEngine.Vector3[]);    
        // 0x00D9D42C: MOV x0, x21                | X0 = 1152921505026973680 (0x10000000190A9FF0);//ML01
        // 0x00D9D430: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.Vector3[]), ????);
        // 0x00D9D434: MOV x0, x21                | X0 = 1152921505026973680 (0x10000000190A9FF0);//ML01
        // 0x00D9D438: MOV x1, x22                | X1 = pts.Length;//m1                    
        // 0x00D9D43C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.Vector3[]), ????);
        // 0x00D9D440: MOV x21, x0                | X21 = 1152921505026973680 (0x10000000190A9FF0);//ML01
        // 0x00D9D444: STR x21, [x20, #0x10]      | this.pts = typeof(UnityEngine.Vector3[]);  //  dest_result_addr=1152921513708179984
        this.pts = null;
        // 0x00D9D448: CBNZ x19, #0xd9d450        | if (pts != null) goto label_2;          
        if(pts != null)
        {
            goto label_2;
        }
        // 0x00D9D44C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Vector3[]), ????);
        label_2:
        // 0x00D9D450: LDR w3, [x19, #0x18]       | W3 = pts.Length; //P2                   
        // 0x00D9D454: MOV x1, x19                | X1 = pts;//m1                           
        // 0x00D9D458: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D9D45C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D9D460: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D464: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00D9D468: MOV x2, x21                | X2 = 1152921505026973680 (0x10000000190A9FF0);//ML01
        // 0x00D9D46C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D9D470: B #0x18c753c               | System.Array.Copy(sourceArray:  0, destinationArray:  pts, length:  420126704); return;
        System.Array.Copy(sourceArray:  0, destinationArray:  pts, length:  420126704);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D9D474 (14275700), len: 1276  VirtAddr: 0x00D9D474 RVA: 0x00D9D474 token: 100684700 methodIndex: 46283 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Vector3 Interp(float t)
    {
        //
        // Disasemble & Code
        // 0x00D9D474: STP d15, d14, [sp, #-0x70]! | stack[1152921513708501040] = ???;  stack[1152921513708501048] = ???;  //  dest_result_addr=1152921513708501040 |  dest_result_addr=1152921513708501048
        // 0x00D9D478: STP d13, d12, [sp, #0x10]  | stack[1152921513708501056] = ???;  stack[1152921513708501064] = ???;  //  dest_result_addr=1152921513708501056 |  dest_result_addr=1152921513708501064
        // 0x00D9D47C: STP d11, d10, [sp, #0x20]  | stack[1152921513708501072] = ???;  stack[1152921513708501080] = ???;  //  dest_result_addr=1152921513708501072 |  dest_result_addr=1152921513708501080
        // 0x00D9D480: STP d9, d8, [sp, #0x30]    | stack[1152921513708501088] = ???;  stack[1152921513708501096] = ???;  //  dest_result_addr=1152921513708501088 |  dest_result_addr=1152921513708501096
        // 0x00D9D484: STP x22, x21, [sp, #0x40]  | stack[1152921513708501104] = ???;  stack[1152921513708501112] = ???;  //  dest_result_addr=1152921513708501104 |  dest_result_addr=1152921513708501112
        // 0x00D9D488: STP x20, x19, [sp, #0x50]  | stack[1152921513708501120] = ???;  stack[1152921513708501128] = ???;  //  dest_result_addr=1152921513708501120 |  dest_result_addr=1152921513708501128
        // 0x00D9D48C: STP x29, x30, [sp, #0x60]  | stack[1152921513708501136] = ???;  stack[1152921513708501144] = ???;  //  dest_result_addr=1152921513708501136 |  dest_result_addr=1152921513708501144
        // 0x00D9D490: ADD x29, sp, #0x60         | X29 = (1152921513708501040 + 96) = 1152921513708501136 (0x100000021E803890);
        // 0x00D9D494: SUB sp, sp, #0x50          | SP = (1152921513708501040 - 80) = 1152921513708500960 (0x100000021E8037E0);
        // 0x00D9D498: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D9D49C: LDRB w8, [x20, #0x50f]     | W8 = (bool)static_value_0373450F;       
        // 0x00D9D4A0: MOV v8.16b, v0.16b         | V8 = t;//m1                             
        // 0x00D9D4A4: MOV x19, x0                | X19 = 1152921513708513152 (0x100000021E806780);//ML01
        // 0x00D9D4A8: TBNZ w8, #0, #0xd9d4c4     | if (static_value_0373450F == true) goto label_0;
        // 0x00D9D4AC: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00D9D4B0: LDR x8, [x8, #0xbc8]       | X8 = 0x2B92E8C;                         
        // 0x00D9D4B4: LDR w0, [x8]               | W0 = 0x2268;                            
        // 0x00D9D4B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2268, ????);     
        // 0x00D9D4BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D9D4C0: STRB w8, [x20, #0x50f]     | static_value_0373450F = true;            //  dest_result_addr=57885967
        label_0:
        // 0x00D9D4C4: LDR x20, [x19, #0x10]      | X20 = this.pts; //P2                    
        // 0x00D9D4C8: CBNZ x20, #0xd9d4d0        | if (this.pts != null) goto label_1;     
        if(this.pts != null)
        {
            goto label_1;
        }
        // 0x00D9D4CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2268, ????);     
        label_1:
        // 0x00D9D4D0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D9D4D4: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D9D4D8: LDR w20, [x20, #0x18]      | W20 = this.pts.Length; //P2             
        // 0x00D9D4DC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D9D4E0: SUB w21, w20, #3           | W21 = (this.pts.Length - 3);            
        int val_1 = this.pts.Length - 3;
        // 0x00D9D4E4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D9D4E8: TBZ w8, #0, #0xd9d4f8      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00D9D4EC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D9D4F0: CBNZ w8, #0xd9d4f8         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00D9D4F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_3:
        // 0x00D9D4F8: SCVTF s0, w21              | S0 = (float)((this.pts.Length - 3));    
        // 0x00D9D4FC: FMUL s10, s0, s8           | S10 = ((this.pts.Length - 3) * t);      
        float val_2 = (float)val_1 * t;
        // 0x00D9D500: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D504: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D508: MOV v0.16b, v10.16b        | V0 = ((this.pts.Length - 3) * t);//m1   
        // 0x00D9D50C: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  val_2);
        int val_3 = UnityEngine.Mathf.FloorToInt(f:  val_2);
        // 0x00D9D510: MOV w1, w0                 | W1 = val_3;//m1                         
        // 0x00D9D514: SUB w2, w20, #4            | W2 = (this.pts.Length - 4);             
        int val_4 = this.pts.Length - 4;
        // 0x00D9D518: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D51C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D9D520: BL #0x1a6e2fc              | X0 = UnityEngine.Mathf.Min(a:  0, b:  val_3);
        int val_5 = UnityEngine.Mathf.Min(a:  0, b:  val_3);
        // 0x00D9D524: LDR x21, [x19, #0x10]      | X21 = this.pts; //P2                    
        // 0x00D9D528: MOV w20, w0                | W20 = val_5;//m1                        
        // 0x00D9D52C: CBNZ x21, #0xd9d534        | if (this.pts != null) goto label_4;     
        if(this.pts != null)
        {
            goto label_4;
        }
        // 0x00D9D530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_4:
        // 0x00D9D534: LDR w8, [x21, #0x18]       | W8 = this.pts.Length; //P2              
        // 0x00D9D538: SXTW x22, w20              | X22 = (long)(int)(val_5);               
        // 0x00D9D53C: CMP w20, w8                | STATE = COMPARE(val_5, this.pts.Length) 
        // 0x00D9D540: B.LO #0xd9d550             | if (val_5 < this.pts.Length) goto label_5;
        if(val_5 < this.pts.Length)
        {
            goto label_5;
        }
        // 0x00D9D544: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
        // 0x00D9D548: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D54C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_5:
        // 0x00D9D550: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_32 = 12;
        // 0x00D9D554: MADD x8, x22, x8, x21      | X8 = ((long)(int)(val_5) * 12) + this.pts;
        val_32 = this.pts + ((long)val_5 * val_32);
        // 0x00D9D558: LDP s9, s14, [x8, #0x20]   | S9 = ((long)(int)(val_5) * 12) + this.pts + 32; S14 = ((long)(int)(val_5) * 12) + this.pts + 32 + 4; //  | 
        // 0x00D9D55C: LDR s15, [x8, #0x28]       | S15 = ((long)(int)(val_5) * 12) + this.pts + 40;
        // 0x00D9D560: LDR x21, [x19, #0x10]      | X21 = this.pts; //P2                    
        // 0x00D9D564: CBNZ x21, #0xd9d56c        | if (this.pts != null) goto label_6;     
        if(this.pts != null)
        {
            goto label_6;
        }
        // 0x00D9D568: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x00D9D56C: LDR w8, [x21, #0x18]       | W8 = this.pts.Length; //P2              
        // 0x00D9D570: ADD w9, w20, #1            | W9 = (val_5 + 1);                       
        int val_6 = val_5 + 1;
        // 0x00D9D574: SXTW x22, w9               | X22 = (long)(int)((val_5 + 1));         
        // 0x00D9D578: CMP w9, w8                 | STATE = COMPARE((val_5 + 1), this.pts.Length)
        // 0x00D9D57C: B.LO #0xd9d58c             | if (val_6 < this.pts.Length) goto label_7;
        if(val_6 < this.pts.Length)
        {
            goto label_7;
        }
        // 0x00D9D580: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
        // 0x00D9D584: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D588: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_7:
        // 0x00D9D58C: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_33 = 12;
        // 0x00D9D590: MADD x8, x22, x8, x21      | X8 = ((long)(int)((val_5 + 1)) * 12) + this.pts;
        val_33 = this.pts + ((long)val_6 * val_33);
        // 0x00D9D594: LDP s11, s12, [x8, #0x20]  | S11 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32; S12 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4; //  | 
        // 0x00D9D598: LDR s0, [x8, #0x28]        | S0 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40;
        // 0x00D9D59C: STR s0, [sp, #0x4c]        | stack[1152921513708501036] = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40;  //  dest_result_addr=1152921513708501036
        // 0x00D9D5A0: LDR x21, [x19, #0x10]      | X21 = this.pts; //P2                    
        // 0x00D9D5A4: CBNZ x21, #0xd9d5ac        | if (this.pts != null) goto label_8;     
        if(this.pts != null)
        {
            goto label_8;
        }
        // 0x00D9D5A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00D9D5AC: LDR w8, [x21, #0x18]       | W8 = this.pts.Length; //P2              
        // 0x00D9D5B0: ADD w9, w20, #2            | W9 = (val_5 + 2);                       
        int val_7 = val_5 + 2;
        // 0x00D9D5B4: SXTW x22, w9               | X22 = (long)(int)((val_5 + 2));         
        // 0x00D9D5B8: CMP w9, w8                 | STATE = COMPARE((val_5 + 2), this.pts.Length)
        // 0x00D9D5BC: B.LO #0xd9d5cc             | if (val_7 < this.pts.Length) goto label_9;
        if(val_7 < this.pts.Length)
        {
            goto label_9;
        }
        // 0x00D9D5C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
        // 0x00D9D5C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D5C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_9:
        // 0x00D9D5CC: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_34 = 12;
        // 0x00D9D5D0: MADD x8, x22, x8, x21      | X8 = ((long)(int)((val_5 + 2)) * 12) + this.pts;
        val_34 = this.pts + ((long)val_7 * val_34);
        // 0x00D9D5D4: LDR s0, [x8, #0x20]        | S0 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32;
        // 0x00D9D5D8: STR s0, [sp, #0x3c]        | stack[1152921513708501020] = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32;  //  dest_result_addr=1152921513708501020
        // 0x00D9D5DC: LDR s0, [x8, #0x24]        | S0 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36;
        // 0x00D9D5E0: STR s0, [sp, #0x48]        | stack[1152921513708501032] = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36;  //  dest_result_addr=1152921513708501032
        // 0x00D9D5E4: LDR s0, [x8, #0x28]        | S0 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40;
        // 0x00D9D5E8: STR s0, [sp, #0x44]        | stack[1152921513708501028] = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40;  //  dest_result_addr=1152921513708501028
        // 0x00D9D5EC: LDR x19, [x19, #0x10]      | X19 = this.pts; //P2                    
        // 0x00D9D5F0: CBNZ x19, #0xd9d5f8        | if (this.pts != null) goto label_10;    
        if(this.pts != null)
        {
            goto label_10;
        }
        // 0x00D9D5F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00D9D5F8: LDR w8, [x19, #0x18]       | W8 = this.pts.Length; //P2              
        // 0x00D9D5FC: ADD w9, w20, #3            | W9 = (val_5 + 3);                       
        int val_8 = val_5 + 3;
        // 0x00D9D600: SCVTF s8, w20              | S8 = (float)(val_5);                    
        // 0x00D9D604: SXTW x20, w9               | X20 = (long)(int)((val_5 + 3));         
        // 0x00D9D608: CMP w9, w8                 | STATE = COMPARE((val_5 + 3), this.pts.Length)
        // 0x00D9D60C: B.LO #0xd9d61c             | if (val_8 < this.pts.Length) goto label_11;
        if(val_8 < this.pts.Length)
        {
            goto label_11;
        }
        // 0x00D9D610: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
        // 0x00D9D614: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D618: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_11:
        // 0x00D9D61C: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_35 = 12;
        // 0x00D9D620: ADRP x9, #0x3673000        | X9 = 57094144 (0x3673000);              
        // 0x00D9D624: MADD x8, x20, x8, x19      | X8 = ((long)(int)((val_5 + 3)) * 12) + this.pts;
        val_35 = this.pts + ((long)val_8 * val_35);
        // 0x00D9D628: LDR x9, [x9, #0x488]       | X9 = 1152921504695078912;               
        // 0x00D9D62C: LDR s0, [x8, #0x20]        | S0 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 32;
        // 0x00D9D630: LDR x0, [x9]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D9D634: STR s0, [sp, #0x28]        | stack[1152921513708501000] = ((long)(int)((val_5 + 3)) * 12) + this.pts + 32;  //  dest_result_addr=1152921513708501000
        // 0x00D9D638: LDR s0, [x8, #0x24]        | S0 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 36;
        // 0x00D9D63C: STR s0, [sp, #0x38]        | stack[1152921513708501016] = ((long)(int)((val_5 + 3)) * 12) + this.pts + 36;  //  dest_result_addr=1152921513708501016
        // 0x00D9D640: LDR s0, [x8, #0x28]        | S0 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 40;
        // 0x00D9D644: STR s0, [sp, #0x2c]        | stack[1152921513708501004] = ((long)(int)((val_5 + 3)) * 12) + this.pts + 40;  //  dest_result_addr=1152921513708501004
        // 0x00D9D648: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D9D64C: FSUB s0, s10, s8           | S0 = (((this.pts.Length - 3) * t) - val_5);
        float val_9 = val_2 - (float)val_5;
        // 0x00D9D650: STR s0, [sp, #0x40]        | stack[1152921513708501024] = (((this.pts.Length - 3) * t) - val_5);  //  dest_result_addr=1152921513708501024
        // 0x00D9D654: TBZ w8, #0, #0xd9d664      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00D9D658: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D9D65C: CBNZ w8, #0xd9d664         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00D9D660: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_13:
        // 0x00D9D664: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D668: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D66C: MOV v0.16b, v9.16b         | V0 = ((long)(int)(val_5) * 12) + this.pts + 32;//m1
        // 0x00D9D670: MOV v1.16b, v14.16b        | V1 = ((long)(int)(val_5) * 12) + this.pts + 32 + 4;//m1
        // 0x00D9D674: MOV v2.16b, v15.16b        | V2 = ((long)(int)(val_5) * 12) + this.pts + 40;//m1
        // 0x00D9D678: BL #0x269a814              | X0 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = ((long)(int)(val_5) * 12) + this.pts + 32, y = ((long)(int)(val_5) * 12) + this.pts + 32 + 4, z = ((long)(int)(val_5) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = ((long)(int)(val_5) * 12) + this.pts + 32, y = ((long)(int)(val_5) * 12) + this.pts + 32 + 4, z = ((long)(int)(val_5) * 12) + this.pts + 40});
        // 0x00D9D67C: MOV v10.16b, v11.16b       | V10 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32;//m1
        // 0x00D9D680: MOV v11.16b, v12.16b       | V11 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4;//m1
        // 0x00D9D684: STP s14, s15, [sp, #0x30]  | stack[1152921513708501008] = ((long)(int)(val_5) * 12) + this.pts + 32 + 4;  stack[1152921513708501012] = ((long)(int)(val_5) * 12) + this.pts + 40;  //  dest_result_addr=1152921513708501008 |  dest_result_addr=1152921513708501012
        // 0x00D9D688: STR s10, [sp, #0x24]       | stack[1152921513708500996] = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32;  //  dest_result_addr=1152921513708500996
        // 0x00D9D68C: STP s9, s11, [sp, #0x1c]   | stack[1152921513708500988] = ((long)(int)(val_5) * 12) + this.pts + 32;  stack[1152921513708500992] = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4;  //  dest_result_addr=1152921513708500988 |  dest_result_addr=1152921513708500992
        // 0x00D9D690: LDR s12, [sp, #0x4c]       | S12 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40;
        // 0x00D9D694: FMOV s15, #3.00000000      | S15 = 3;                                
        // 0x00D9D698: MOV v8.16b, v0.16b         | V8 = val_10.x;//m1                      
        // 0x00D9D69C: MOV v13.16b, v1.16b        | V13 = val_10.y;//m1                     
        // 0x00D9D6A0: MOV v14.16b, v2.16b        | V14 = val_10.z;//m1                     
        // 0x00D9D6A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D6A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D6AC: MOV v0.16b, v15.16b        | V0 = 3;//m1                             
        // 0x00D9D6B0: MOV v1.16b, v10.16b        | V1 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32;//m1
        // 0x00D9D6B4: MOV v2.16b, v11.16b        | V2 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4;//m1
        // 0x00D9D6B8: MOV v3.16b, v12.16b        | V3 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40;//m1
        // 0x00D9D6BC: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  3f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4, z = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Multiply(d:  3f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4, z = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40});
        // 0x00D9D6C0: MOV v3.16b, v0.16b         | V3 = val_11.x;//m1                      
        // 0x00D9D6C4: MOV v4.16b, v1.16b         | V4 = val_11.y;//m1                      
        // 0x00D9D6C8: MOV v5.16b, v2.16b         | V5 = val_11.z;//m1                      
        // 0x00D9D6CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D6D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D6D4: MOV v0.16b, v8.16b         | V0 = val_10.x;//m1                      
        // 0x00D9D6D8: MOV v1.16b, v13.16b        | V1 = val_10.y;//m1                      
        // 0x00D9D6DC: MOV v2.16b, v14.16b        | V2 = val_10.z;//m1                      
        // 0x00D9D6E0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
        UnityEngine.Vector3 val_12 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
        // 0x00D9D6E4: MOV v13.16b, v1.16b        | V13 = val_12.y;//m1                     
        // 0x00D9D6E8: MOV v14.16b, v2.16b        | V14 = val_12.z;//m1                     
        // 0x00D9D6EC: LDR s1, [sp, #0x3c]        | S1 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32;
        // 0x00D9D6F0: LDP s3, s2, [sp, #0x44]    | S3 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40; S2 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36; //  | 
        // 0x00D9D6F4: MOV v8.16b, v0.16b         | V8 = val_12.x;//m1                      
        // 0x00D9D6F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D6FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D700: MOV v0.16b, v15.16b        | V0 = 3;//m1                             
        // 0x00D9D704: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  3f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_13 = UnityEngine.Vector3.op_Multiply(d:  3f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40});
        // 0x00D9D708: MOV v3.16b, v0.16b         | V3 = val_13.x;//m1                      
        // 0x00D9D70C: MOV v4.16b, v1.16b         | V4 = val_13.y;//m1                      
        // 0x00D9D710: MOV v5.16b, v2.16b         | V5 = val_13.z;//m1                      
        // 0x00D9D714: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D71C: MOV v0.16b, v8.16b         | V0 = val_12.x;//m1                      
        // 0x00D9D720: MOV v1.16b, v13.16b        | V1 = val_12.y;//m1                      
        // 0x00D9D724: MOV v2.16b, v14.16b        | V2 = val_12.z;//m1                      
        // 0x00D9D728: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z});
        UnityEngine.Vector3 val_14 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z});
        // 0x00D9D72C: LDP s15, s8, [sp, #0x28]   | S15 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 32; S8 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 40; //  | 
        // 0x00D9D730: LDR s4, [sp, #0x38]        | S4 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 36;
        // 0x00D9D734: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D738: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D73C: MOV v3.16b, v15.16b        | V3 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 32;//m1
        // 0x00D9D740: MOV v5.16b, v8.16b         | V5 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 40;//m1
        // 0x00D9D744: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, b:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 3)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 3)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 3)) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_15 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, b:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 3)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 3)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 3)) * 12) + this.pts + 40});
        // 0x00D9D748: LDR s3, [sp, #0x40]        | S3 = (((this.pts.Length - 3) * t) - val_5);
        float val_36 = val_9;
        // 0x00D9D74C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D750: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D754: FMUL s4, s3, s3            | S4 = ((((this.pts.Length - 3) * t) - val_5) * (((this.pts.Length - 3) * t) - val_5));
        float val_16 = val_36 * val_36;
        // 0x00D9D758: FMUL s3, s3, s4            | S3 = ((((this.pts.Length - 3) * t) - val_5) * ((((this.pts.Length - 3) * t) - val_5) * (((this.pts.Length - 3) * t) - val_5)));
        val_36 = val_36 * val_16;
        // 0x00D9D75C: STR s4, [sp, #0x18]        | stack[1152921513708500984] = ((((this.pts.Length - 3) * t) - val_5) * (((this.pts.Length - 3) * t) - val_5));  //  dest_result_addr=1152921513708500984
        // 0x00D9D760: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z}, d:  val_9 = val_9 * val_16);
        UnityEngine.Vector3 val_17 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z}, d:  val_36);
        // 0x00D9D764: STP s1, s0, [sp, #0x10]    | stack[1152921513708500976] = val_17.y;  stack[1152921513708500980] = val_17.x;  //  dest_result_addr=1152921513708500976 |  dest_result_addr=1152921513708500980
        // 0x00D9D768: STR s2, [sp, #0xc]         | stack[1152921513708500972] = val_17.z;   //  dest_result_addr=1152921513708500972
        // 0x00D9D76C: LDP s2, s3, [sp, #0x30]    | S2 = ((long)(int)(val_5) * 12) + this.pts + 32 + 4; S3 = ((long)(int)(val_5) * 12) + this.pts + 40; //  | 
        // 0x00D9D770: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D774: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D778: FMOV s0, #2.00000000       | S0 = 2;                                 
        // 0x00D9D77C: MOV v1.16b, v9.16b         | V1 = ((long)(int)(val_5) * 12) + this.pts + 32;//m1
        // 0x00D9D780: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  2f, a:  new UnityEngine.Vector3() {x = ((long)(int)(val_5) * 12) + this.pts + 32, y = ((long)(int)(val_5) * 12) + this.pts + 32 + 4, z = ((long)(int)(val_5) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_18 = UnityEngine.Vector3.op_Multiply(d:  2f, a:  new UnityEngine.Vector3() {x = ((long)(int)(val_5) * 12) + this.pts + 32, y = ((long)(int)(val_5) * 12) + this.pts + 32 + 4, z = ((long)(int)(val_5) * 12) + this.pts + 40});
        // 0x00D9D784: MOV v5.16b, v10.16b        | V5 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32;//m1
        // 0x00D9D788: MOV v4.16b, v11.16b        | V4 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4;//m1
        // 0x00D9D78C: MOV v10.16b, v0.16b        | V10 = val_18.x;//m1                     
        // 0x00D9D790: MOV v11.16b, v1.16b        | V11 = val_18.y;//m1                     
        // 0x00D9D794: MOV v3.16b, v12.16b        | V3 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40;//m1
        // 0x00D9D798: MOV v12.16b, v2.16b        | V12 = val_18.z;//m1                     
        // 0x00D9D79C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D7A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D7A4: FMOV s0, #5.00000000       | S0 = 5;                                 
        // 0x00D9D7A8: MOV v1.16b, v5.16b         | V1 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32;//m1
        // 0x00D9D7AC: MOV v2.16b, v4.16b         | V2 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4;//m1
        // 0x00D9D7B0: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  5f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4, z = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_19 = UnityEngine.Vector3.op_Multiply(d:  5f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4, z = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40});
        // 0x00D9D7B4: MOV v3.16b, v0.16b         | V3 = val_19.x;//m1                      
        // 0x00D9D7B8: MOV v4.16b, v1.16b         | V4 = val_19.y;//m1                      
        // 0x00D9D7BC: MOV v5.16b, v2.16b         | V5 = val_19.z;//m1                      
        // 0x00D9D7C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D7C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D7C8: MOV v0.16b, v10.16b        | V0 = val_18.x;//m1                      
        // 0x00D9D7CC: MOV v1.16b, v11.16b        | V1 = val_18.y;//m1                      
        // 0x00D9D7D0: MOV v2.16b, v12.16b        | V2 = val_18.z;//m1                      
        // 0x00D9D7D4: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z});
        UnityEngine.Vector3 val_20 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z});
        // 0x00D9D7D8: LDR s9, [sp, #0x3c]        | S9 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32;
        // 0x00D9D7DC: LDP s14, s13, [sp, #0x44]  | S14 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40; S13 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36; //  | 
        // 0x00D9D7E0: MOV v10.16b, v0.16b        | V10 = val_20.x;//m1                     
        // 0x00D9D7E4: MOV v11.16b, v1.16b        | V11 = val_20.y;//m1                     
        // 0x00D9D7E8: MOV v12.16b, v2.16b        | V12 = val_20.z;//m1                     
        // 0x00D9D7EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D7F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D7F4: FMOV s0, #4.00000000       | S0 = 4;                                 
        // 0x00D9D7F8: MOV v1.16b, v9.16b         | V1 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32;//m1
        // 0x00D9D7FC: MOV v2.16b, v13.16b        | V2 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36;//m1
        // 0x00D9D800: MOV v3.16b, v14.16b        | V3 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40;//m1
        // 0x00D9D804: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  4f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_21 = UnityEngine.Vector3.op_Multiply(d:  4f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40});
        // 0x00D9D808: MOV v3.16b, v0.16b         | V3 = val_21.x;//m1                      
        // 0x00D9D80C: MOV v4.16b, v1.16b         | V4 = val_21.y;//m1                      
        // 0x00D9D810: MOV v5.16b, v2.16b         | V5 = val_21.z;//m1                      
        // 0x00D9D814: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D81C: MOV v0.16b, v10.16b        | V0 = val_20.x;//m1                      
        // 0x00D9D820: MOV v1.16b, v11.16b        | V1 = val_20.y;//m1                      
        // 0x00D9D824: MOV v2.16b, v12.16b        | V2 = val_20.z;//m1                      
        // 0x00D9D828: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_20.x, y = val_20.y, z = val_20.z}, b:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        UnityEngine.Vector3 val_22 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_20.x, y = val_20.y, z = val_20.z}, b:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        // 0x00D9D82C: LDR s4, [sp, #0x38]        | S4 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 36;
        // 0x00D9D830: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D834: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D838: MOV v3.16b, v15.16b        | V3 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 32;//m1
        // 0x00D9D83C: MOV v5.16b, v8.16b         | V5 = ((long)(int)((val_5 + 3)) * 12) + this.pts + 40;//m1
        // 0x00D9D840: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z}, b:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 3)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 3)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 3)) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_23 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z}, b:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 3)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 3)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 3)) * 12) + this.pts + 40});
        // 0x00D9D844: LDR s3, [sp, #0x18]        | S3 = ((((this.pts.Length - 3) * t) - val_5) * (((this.pts.Length - 3) * t) - val_5));
        // 0x00D9D848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D84C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D850: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, d:  val_16);
        UnityEngine.Vector3 val_24 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, d:  val_16);
        // 0x00D9D854: MOV v3.16b, v0.16b         | V3 = val_24.x;//m1                      
        // 0x00D9D858: MOV v4.16b, v1.16b         | V4 = val_24.y;//m1                      
        // 0x00D9D85C: MOV v5.16b, v2.16b         | V5 = val_24.z;//m1                      
        // 0x00D9D860: LDP s1, s0, [sp, #0x10]    | S1 = val_17.y; S0 = val_17.x;            //  | 
        // 0x00D9D864: LDR s2, [sp, #0xc]         | S2 = val_17.z;                          
        // 0x00D9D868: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D86C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D870: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z}, b:  new UnityEngine.Vector3() {x = val_24.x, y = val_24.y, z = val_24.z});
        UnityEngine.Vector3 val_25 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z}, b:  new UnityEngine.Vector3() {x = val_24.x, y = val_24.y, z = val_24.z});
        // 0x00D9D874: MOV v8.16b, v0.16b         | V8 = val_25.x;//m1                      
        // 0x00D9D878: MOV v10.16b, v1.16b        | V10 = val_25.y;//m1                     
        // 0x00D9D87C: MOV v11.16b, v2.16b        | V11 = val_25.z;//m1                     
        // 0x00D9D880: LDR s0, [sp, #0x1c]        | S0 = ((long)(int)(val_5) * 12) + this.pts + 32;
        // 0x00D9D884: LDP s1, s2, [sp, #0x30]    | S1 = ((long)(int)(val_5) * 12) + this.pts + 32 + 4; S2 = ((long)(int)(val_5) * 12) + this.pts + 40; //  | 
        // 0x00D9D888: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D88C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D890: BL #0x269a814              | X0 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = ((long)(int)(val_5) * 12) + this.pts + 32, y = ((long)(int)(val_5) * 12) + this.pts + 32 + 4, z = ((long)(int)(val_5) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_26 = UnityEngine.Vector3.op_UnaryNegation(a:  new UnityEngine.Vector3() {x = ((long)(int)(val_5) * 12) + this.pts + 32, y = ((long)(int)(val_5) * 12) + this.pts + 32 + 4, z = ((long)(int)(val_5) * 12) + this.pts + 40});
        // 0x00D9D894: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D898: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D89C: MOV v3.16b, v9.16b         | V3 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32;//m1
        // 0x00D9D8A0: MOV v4.16b, v13.16b        | V4 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36;//m1
        // 0x00D9D8A4: MOV v5.16b, v14.16b        | V5 = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40;//m1
        // 0x00D9D8A8: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z}, b:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_27 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z}, b:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 2)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 2)) * 12) + this.pts + 36, z = ((long)(int)((val_5 + 2)) * 12) + this.pts + 40});
        // 0x00D9D8AC: LDR s3, [sp, #0x40]        | S3 = (((this.pts.Length - 3) * t) - val_5);
        // 0x00D9D8B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D8B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D8B8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z}, d:  val_9);
        UnityEngine.Vector3 val_28 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z}, d:  val_9);
        // 0x00D9D8BC: MOV v3.16b, v0.16b         | V3 = val_28.x;//m1                      
        // 0x00D9D8C0: MOV v4.16b, v1.16b         | V4 = val_28.y;//m1                      
        // 0x00D9D8C4: MOV v5.16b, v2.16b         | V5 = val_28.z;//m1                      
        // 0x00D9D8C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D8CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D8D0: MOV v0.16b, v8.16b         | V0 = val_25.x;//m1                      
        // 0x00D9D8D4: MOV v1.16b, v10.16b        | V1 = val_25.y;//m1                      
        // 0x00D9D8D8: MOV v2.16b, v11.16b        | V2 = val_25.z;//m1                      
        // 0x00D9D8DC: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z}, b:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_28.z});
        UnityEngine.Vector3 val_29 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z}, b:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_28.z});
        // 0x00D9D8E0: MOV v9.16b, v1.16b         | V9 = val_29.y;//m1                      
        // 0x00D9D8E4: MOV v10.16b, v2.16b        | V10 = val_29.z;//m1                     
        // 0x00D9D8E8: LDP s2, s1, [sp, #0x20]    | S2 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4; S1 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32; //  | 
        // 0x00D9D8EC: LDR s3, [sp, #0x4c]        | S3 = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40;
        // 0x00D9D8F0: MOV v8.16b, v0.16b         | V8 = val_29.x;//m1                      
        // 0x00D9D8F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D8F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D8FC: FMOV s0, #2.00000000       | S0 = 2;                                 
        // 0x00D9D900: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  2f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4, z = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40});
        UnityEngine.Vector3 val_30 = UnityEngine.Vector3.op_Multiply(d:  2f, a:  new UnityEngine.Vector3() {x = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32, y = ((long)(int)((val_5 + 1)) * 12) + this.pts + 32 + 4, z = ((long)(int)((val_5 + 1)) * 12) + this.pts + 40});
        // 0x00D9D904: MOV v3.16b, v0.16b         | V3 = val_30.x;//m1                      
        // 0x00D9D908: MOV v4.16b, v1.16b         | V4 = val_30.y;//m1                      
        // 0x00D9D90C: MOV v5.16b, v2.16b         | V5 = val_30.z;//m1                      
        // 0x00D9D910: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D918: MOV v0.16b, v8.16b         | V0 = val_29.x;//m1                      
        // 0x00D9D91C: MOV v1.16b, v9.16b         | V1 = val_29.y;//m1                      
        // 0x00D9D920: MOV v2.16b, v10.16b        | V2 = val_29.z;//m1                      
        // 0x00D9D924: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_29.x, y = val_29.y, z = val_29.z}, b:  new UnityEngine.Vector3() {x = val_30.x, y = val_30.y, z = val_30.z});
        UnityEngine.Vector3 val_31 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_29.x, y = val_29.y, z = val_29.z}, b:  new UnityEngine.Vector3() {x = val_30.x, y = val_30.y, z = val_30.z});
        // 0x00D9D928: MOV v3.16b, v0.16b         | V3 = val_31.x;//m1                      
        // 0x00D9D92C: MOV v4.16b, v1.16b         | V4 = val_31.y;//m1                      
        // 0x00D9D930: MOV v5.16b, v2.16b         | V5 = val_31.z;//m1                      
        // 0x00D9D934: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D9D938: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D9D93C: FMOV s0, #0.50000000       | S0 = 0.5;                               
        // 0x00D9D940: MOV v1.16b, v3.16b         | V1 = val_31.x;//m1                      
        // 0x00D9D944: MOV v2.16b, v4.16b         | V2 = val_31.y;//m1                      
        // 0x00D9D948: MOV v3.16b, v5.16b         | V3 = val_31.z;//m1                      
        // 0x00D9D94C: SUB sp, x29, #0x60         | SP = (1152921513708501136 - 96) = 1152921513708501040 (0x100000021E803830);
        // 0x00D9D950: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00D9D954: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00D9D958: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00D9D95C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00D9D960: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00D9D964: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00D9D968: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00D9D96C: B #0x2699650               | return UnityEngine.Vector3.op_Multiply(d:  0.5f, a:  new UnityEngine.Vector3() {x = val_31.x, y = val_31.y, z = val_31.z});
        return UnityEngine.Vector3.op_Multiply(d:  0.5f, a:  new UnityEngine.Vector3() {x = val_31.x, y = val_31.y, z = val_31.z});
    
    }

}
