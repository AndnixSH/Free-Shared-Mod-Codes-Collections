using UnityEngine;
public class CameraAnimationMgr : MonoBehaviour
{
    // Fields
    public const string PATH = "Misc/patrolCamera/{0}.prefab";
    public const string CAMERA_PATROL_PLAY_START = "CAMERA_PATROL_PLAY_START";
    public const string CAMERA_PATROL_PLAY_END = "CAMERA_PATROL_PLAY_END";
    public UnityEngine.GameObject gameObject; //  0x00000018
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x28784C0
    private bool <IsPlaying>k__BackingField; //  0x00000020
    private System.Collections.Generic.List<BAMCameras> cameraList; //  0x00000028
    private UnityEngine.GameObject objAnimator; //  0x00000030
    
    // Properties
    public bool IsPlaying { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA7224 (12218916), len: 112  VirtAddr: 0x00BA7224 RVA: 0x00BA7224 token: 100693316 methodIndex: 25656 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraAnimationMgr()
    {
        //
        // Disasemble & Code
        // 0x00BA7224: STP x20, x19, [sp, #-0x20]! | stack[1152921514970456704] = ???;  stack[1152921514970456712] = ???;  //  dest_result_addr=1152921514970456704 |  dest_result_addr=1152921514970456712
        // 0x00BA7228: STP x29, x30, [sp, #0x10]  | stack[1152921514970456720] = ???;  stack[1152921514970456728] = ???;  //  dest_result_addr=1152921514970456720 |  dest_result_addr=1152921514970456728
        // 0x00BA722C: ADD x29, sp, #0x10         | X29 = (1152921514970456704 + 16) = 1152921514970456720 (0x1000000269B82290);
        // 0x00BA7230: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA7234: LDRB w8, [x20, #0xae6]     | W8 = (bool)static_value_03733AE6;       
        // 0x00BA7238: MOV x19, x0                | X19 = 1152921514970468736 (0x1000000269B85180);//ML01
        // 0x00BA723C: TBNZ w8, #0, #0xba7258     | if (static_value_03733AE6 == true) goto label_0;
        // 0x00BA7240: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
        // 0x00BA7244: LDR x8, [x8, #0xde0]       | X8 = 0x2B9014C;                         
        // 0x00BA7248: LDR w0, [x8]               | W0 = 0x1717;                            
        // 0x00BA724C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1717, ????);     
        // 0x00BA7250: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA7254: STRB w8, [x20, #0xae6]     | static_value_03733AE6 = true;            //  dest_result_addr=57883366
        label_0:
        // 0x00BA7258: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00BA725C: LDR x8, [x8, #0x318]       | X8 = 1152921504616644608;               
        // 0x00BA7260: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<BAMCameras> val_1 = null;
        // 0x00BA7264: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7268: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00BA726C: LDR x8, [x8, #0x5f8]       | X8 = 1152921514482383104;               
        // 0x00BA7270: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7274: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<BAMCameras>::.ctor();
        // 0x00BA7278: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<BAMCameras>();
        // 0x00BA727C: STR x20, [x19, #0x28]      | this.cameraList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514970468776
        this.cameraList = val_1;
        // 0x00BA7280: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7284: MOV x0, x19                | X0 = 1152921514970468736 (0x1000000269B85180);//ML01
        // 0x00BA7288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA728C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA7290: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA7294 (12219028), len: 12  VirtAddr: 0x00BA7294 RVA: 0x00BA7294 token: 100693317 methodIndex: 25657 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_IsPlaying(bool value)
    {
        //
        // Disasemble & Code
        // 0x00BA7294: AND w8, w1, #1             | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00BA7298: STRB w8, [x0, #0x20]       | this.<IsPlaying>k__BackingField = (value & 1);  //  dest_result_addr=1152921514970580768
        this.<IsPlaying>k__BackingField = val_1;
        // 0x00BA729C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA72A0 (12219040), len: 8  VirtAddr: 0x00BA72A0 RVA: 0x00BA72A0 token: 100693318 methodIndex: 25658 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_IsPlaying()
    {
        //
        // Disasemble & Code
        // 0x00BA72A0: LDRB w0, [x0, #0x20]       | W0 = this.<IsPlaying>k__BackingField; //P2 
        // 0x00BA72A4: RET                        |  return (System.Boolean)this.<IsPlaying>k__BackingField;
        return this.<IsPlaying>k__BackingField;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA72A8 (12219048), len: 536  VirtAddr: 0x00BA72A8 RVA: 0x00BA72A8 token: 100693319 methodIndex: 25659 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnAwake(UnityEngine.GameObject go, string aniName)
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        // 0x00BA72A8: STP x28, x27, [sp, #-0x60]! | stack[1152921514970866608] = ???;  stack[1152921514970866616] = ???;  //  dest_result_addr=1152921514970866608 |  dest_result_addr=1152921514970866616
        // 0x00BA72AC: STP x26, x25, [sp, #0x10]  | stack[1152921514970866624] = ???;  stack[1152921514970866632] = ???;  //  dest_result_addr=1152921514970866624 |  dest_result_addr=1152921514970866632
        // 0x00BA72B0: STP x24, x23, [sp, #0x20]  | stack[1152921514970866640] = ???;  stack[1152921514970866648] = ???;  //  dest_result_addr=1152921514970866640 |  dest_result_addr=1152921514970866648
        // 0x00BA72B4: STP x22, x21, [sp, #0x30]  | stack[1152921514970866656] = ???;  stack[1152921514970866664] = ???;  //  dest_result_addr=1152921514970866656 |  dest_result_addr=1152921514970866664
        // 0x00BA72B8: STP x20, x19, [sp, #0x40]  | stack[1152921514970866672] = ???;  stack[1152921514970866680] = ???;  //  dest_result_addr=1152921514970866672 |  dest_result_addr=1152921514970866680
        // 0x00BA72BC: STP x29, x30, [sp, #0x50]  | stack[1152921514970866688] = ???;  stack[1152921514970866696] = ???;  //  dest_result_addr=1152921514970866688 |  dest_result_addr=1152921514970866696
        // 0x00BA72C0: ADD x29, sp, #0x50         | X29 = (1152921514970866608 + 80) = 1152921514970866688 (0x1000000269BE6400);
        // 0x00BA72C4: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00BA72C8: LDRB w8, [x22, #0xae7]     | W8 = (bool)static_value_03733AE7;       
        // 0x00BA72CC: MOV x20, x2                | X20 = aniName;//m1                      
        // 0x00BA72D0: MOV x21, x1                | X21 = go;//m1                           
        // 0x00BA72D4: MOV x19, x0                | X19 = 1152921514970878704 (0x1000000269BE92F0);//ML01
        // 0x00BA72D8: TBNZ w8, #0, #0xba72f4     | if (static_value_03733AE7 == true) goto label_0;
        // 0x00BA72DC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
        // 0x00BA72E0: LDR x8, [x8, #0x258]       | X8 = 0x2B90150;                         
        // 0x00BA72E4: LDR w0, [x8]               | W0 = 0x1718;                            
        // 0x00BA72E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1718, ????);     
        // 0x00BA72EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA72F0: STRB w8, [x22, #0xae7]     | static_value_03733AE7 = true;            //  dest_result_addr=57883367
        label_0:
        // 0x00BA72F4: STR x21, [x19, #0x18]      | this.gameObject = go;                    //  dest_result_addr=1152921514970878728
        this.gameObject = go;
        // 0x00BA72F8: CBNZ x21, #0xba7300        | if (go != null) goto label_1;           
        if(go != null)
        {
            goto label_1;
        }
        // 0x00BA72FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1718, ????);     
        label_1:
        // 0x00BA7300: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x00BA7304: LDR x8, [x8, #0x838]       | X8 = (string**)(1152921514970788928)("CameraAniamtionMgr");
        // 0x00BA7308: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA730C: MOV x0, x21                | X0 = go;//m1                            
        // 0x00BA7310: LDR x1, [x8]               | X1 = "CameraAniamtionMgr";              
        // 0x00BA7314: BL #0x1b78c7c              | go.set_name(value:  "CameraAniamtionMgr");
        go.name = "CameraAniamtionMgr";
        // 0x00BA7318: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BA731C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BA7320: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BA7324: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BA7328: TBZ w8, #0, #0xba7338      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00BA732C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BA7330: CBNZ w8, #0xba7338         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00BA7334: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00BA7338: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
        // 0x00BA733C: LDR x8, [x8, #0x2a0]       | X8 = 1152921514482929488;               
        // 0x00BA7340: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7344: LDR x1, [x8]               | X1 = public static T[] UnityEngine.Object::FindObjectsOfType<UnityEngine.Camera>();
        // 0x00BA7348: BL #0x23d99ec              | X0 = UnityEngine.Object.FindObjectsOfType<UnityEngine.Camera>();
        T[] val_1 = UnityEngine.Object.FindObjectsOfType<UnityEngine.Camera>();
        // 0x00BA734C: ADRP x26, #0x3661000       | X26 = 57020416 (0x3661000);             
        // 0x00BA7350: ADRP x27, #0x360a000       | X27 = 56664064 (0x360A000);             
        // 0x00BA7354: LDR x26, [x26, #0x8f0]     | X26 = 1152921504887570432;              
        // 0x00BA7358: LDR x27, [x27, #0xf60]     | X27 = 1152921514482967376;              
        // 0x00BA735C: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00BA7360: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        val_6 = 0;
        // 0x00BA7364: B #0xba737c                |  goto label_4;                          
        goto label_4;
        label_9:
        // 0x00BA7368: LDR x2, [x27]              | X2 = public System.Void System.Collections.Generic.List<BAMCameras>::Add(BAMCameras item);
        // 0x00BA736C: MOV x0, x22                | X0 = 57880576 (0x3733000);//ML01        
        // 0x00BA7370: MOV x1, x23                | X1 = X23;//m1                           
        // 0x00BA7374: BL #0x25ea480              | Add(item:  X23);                        
        Add(item:  X23);
        // 0x00BA7378: ADD w25, w25, #1           | W25 = (val_6 + 1) = val_6 (0x00000001); 
        val_6 = 1;
        label_4:
        // 0x00BA737C: CBNZ x21, #0xba7384        | if (val_1 != null) goto label_5;        
        if(val_1 != null)
        {
            goto label_5;
        }
        // 0x00BA7380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3733000, ????);  
        label_5:
        // 0x00BA7384: LDR w8, [x21, #0x18]       | W8 = val_1.Length; //P2                 
        // 0x00BA7388: CMP w25, w8                | STATE = COMPARE(0x1, val_1.Length)      
        // 0x00BA738C: B.GE #0xba73d4             | if (val_6 >= val_1.Length) goto label_6;
        if(val_6 >= val_1.Length)
        {
            goto label_6;
        }
        // 0x00BA7390: LDR x22, [x19, #0x28]      | X22 = this.cameraList; //P2             
        // 0x00BA7394: SXTW x23, w25              | X23 = 1 (0x00000001);                   
        // 0x00BA7398: CMP w25, w8                | STATE = COMPARE(0x1, val_1.Length)      
        // 0x00BA739C: B.LO #0xba73ac             | if (val_6 < val_1.Length) goto label_7; 
        if(val_6 < val_1.Length)
        {
            goto label_7;
        }
        // 0x00BA73A0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x3733000, ????);  
        // 0x00BA73A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA73A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x3733000, ????);  
        label_7:
        // 0x00BA73AC: ADD x8, x21, x23, lsl #3   | X8 = val_1[0x1]; //PARR1                
        // 0x00BA73B0: LDR x0, [x26]              | X0 = typeof(BAMCameras);                
        BAMCameras val_2 = null;
        // 0x00BA73B4: LDR x24, [x8, #0x20]       | X24 = val_1[0x1][0]                     
        T val_6 = val_1[1];
        // 0x00BA73B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BAMCameras), ????);
        // 0x00BA73BC: MOV x1, x24                | X1 = val_1[0x1][0];//m1                 
        // 0x00BA73C0: MOV x23, x0                | X23 = 1152921504887570432 (0x1000000010BB8000);//ML01
        // 0x00BA73C4: BL #0xb8cb34               | .ctor(camera:  val_1[1]);               
        val_2 = new BAMCameras(camera:  val_6);
        // 0x00BA73C8: CBNZ x22, #0xba7368        | if (this.cameraList != null) goto label_9;
        if(this.cameraList != null)
        {
            goto label_9;
        }
        // 0x00BA73CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(camera:  val_1[1]), ????);
        // 0x00BA73D0: B #0xba7368                |  goto label_9;                          
        goto label_9;
        label_6:
        // 0x00BA73D4: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00BA73D8: LDR x8, [x8, #0xfd8]       | X8 = (string**)(1152921514970830000)("Misc/patrolCamera/{0}.prefab");
        // 0x00BA73DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA73E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA73E4: MOV x2, x20                | X2 = aniName;//m1                       
        // 0x00BA73E8: LDR x1, [x8]               | X1 = "Misc/patrolCamera/{0}.prefab";    
        // 0x00BA73EC: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "Misc/patrolCamera/{0}.prefab");
        string val_3 = EString.EFormat(format:  0, arg0:  "Misc/patrolCamera/{0}.prefab");
        // 0x00BA73F0: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00BA73F4: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
        // 0x00BA73F8: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00BA73FC: LDR x8, [x8]               | X8 = typeof(Mihua.Asset.AssetMgr);      
        // 0x00BA7400: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
        // 0x00BA7404: TBZ w9, #0, #0xba7418      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00BA7408: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00BA740C: CBNZ w9, #0xba7418         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00BA7410: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
        // 0x00BA7414: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
        label_11:
        // 0x00BA7418: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
        // 0x00BA741C: LDR x8, [x8, #0xff8]       | X8 = 1152921510507425072;               
        // 0x00BA7420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7424: MOV x1, x20                | X1 = val_3;//m1                         
        // 0x00BA7428: LDR x2, [x8]               | X2 = public static UnityEngine.GameObject Mihua.Asset.AssetMgr::GetLoadedAsset<UnityEngine.GameObject>(string assetName);
        // 0x00BA742C: BL #0xfd8bec               | X0 = Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
        UnityEngine.Object val_4 = Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
        // 0x00BA7430: MOV x1, x0                 | X1 = val_4;//m1                         
        // 0x00BA7434: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7438: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA743C: BL #0xbf74bc               | X0 = GameObject_Instantiate.Instantiate(_this:  0);
        UnityEngine.GameObject val_5 = GameObject_Instantiate.Instantiate(_this:  0);
        // 0x00BA7440: LDR x2, [x19, #0x18]       | X2 = this.gameObject; //P2              
        // 0x00BA7444: MOV x8, x0                 | X8 = val_5;//m1                         
        // 0x00BA7448: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA744C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA7450: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x00BA7454: MOV x1, x8                 | X1 = val_5;//m1                         
        // 0x00BA7458: STR x8, [x19, #0x30]       | this.objAnimator = val_5;                //  dest_result_addr=1152921514970878752
        this.objAnimator = val_5;
        // 0x00BA745C: BL #0xbf7570               | GameObject_Hierarchy.ChangeParent(_this:  0, parent:  val_5, resetMat:  this.gameObject);
        GameObject_Hierarchy.ChangeParent(_this:  0, parent:  val_5, resetMat:  this.gameObject);
        // 0x00BA7460: LDR x20, [x19, #0x30]      | X20 = this.objAnimator; //P2            
        // 0x00BA7464: CBNZ x20, #0xba746c        | if (this.objAnimator != null) goto label_12;
        if(this.objAnimator != null)
        {
            goto label_12;
        }
        // 0x00BA7468: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_12:
        // 0x00BA746C: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00BA7470: LDR x8, [x8, #0x28]        | X8 = (string**)(1152921514497841280)("Camera");
        // 0x00BA7474: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA7478: MOV x0, x20                | X0 = this.objAnimator;//m1              
        // 0x00BA747C: LDR x1, [x8]               | X1 = "Camera";                          
        // 0x00BA7480: BL #0x1b78c7c              | this.objAnimator.set_name(value:  "Camera");
        this.objAnimator.name = "Camera";
        // 0x00BA7484: LDR x20, [x19, #0x30]      | X20 = this.objAnimator; //P2            
        // 0x00BA7488: CBNZ x20, #0xba7490        | if (this.objAnimator != null) goto label_13;
        if(this.objAnimator != null)
        {
            goto label_13;
        }
        // 0x00BA748C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.objAnimator, ????);
        label_13:
        // 0x00BA7490: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA7494: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA7498: MOV x0, x20                | X0 = this.objAnimator;//m1              
        // 0x00BA749C: BL #0x1a62d64              | this.objAnimator.SetActive(value:  false);
        this.objAnimator.SetActive(value:  false);
        // 0x00BA74A0: STRB wzr, [x19, #0x20]     | this.<IsPlaying>k__BackingField = false;  //  dest_result_addr=1152921514970878736
        this.<IsPlaying>k__BackingField = false;
        // 0x00BA74A4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA74A8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA74AC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA74B0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA74B4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00BA74B8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00BA74BC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA74C0 (12219584), len: 80  VirtAddr: 0x00BA74C0 RVA: 0x00BA74C0 token: 100693320 methodIndex: 25660 delegateWrapperIndex: 0 methodInvoker: 0
    public void Play()
    {
        //
        // Disasemble & Code
        // 0x00BA74C0: STP x22, x21, [sp, #-0x30]! | stack[1152921514971056480] = ???;  stack[1152921514971056488] = ???;  //  dest_result_addr=1152921514971056480 |  dest_result_addr=1152921514971056488
        // 0x00BA74C4: STP x20, x19, [sp, #0x10]  | stack[1152921514971056496] = ???;  stack[1152921514971056504] = ???;  //  dest_result_addr=1152921514971056496 |  dest_result_addr=1152921514971056504
        // 0x00BA74C8: STP x29, x30, [sp, #0x20]  | stack[1152921514971056512] = ???;  stack[1152921514971056520] = ???;  //  dest_result_addr=1152921514971056512 |  dest_result_addr=1152921514971056520
        // 0x00BA74CC: ADD x29, sp, #0x20         | X29 = (1152921514971056480 + 32) = 1152921514971056512 (0x1000000269C14980);
        // 0x00BA74D0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA74D4: MOV x19, x0                | X19 = 1152921514971068528 (0x1000000269C17870);//ML01
        // 0x00BA74D8: BL #0xba7510               | this.SetCameraState(state:  false);     
        this.SetCameraState(state:  false);
        // 0x00BA74DC: LDR x20, [x19, #0x30]      | X20 = this.objAnimator; //P2            
        // 0x00BA74E0: CBNZ x20, #0xba74e8        | if (this.objAnimator != null) goto label_0;
        if(this.objAnimator != null)
        {
            goto label_0;
        }
        // 0x00BA74E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA74E8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA74EC: MOV x0, x20                | X0 = this.objAnimator;//m1              
        // 0x00BA74F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA74F4: ORR w21, wzr, #1           | W21 = 1(0x1);                           
        // 0x00BA74F8: BL #0x1a62d64              | this.objAnimator.SetActive(value:  true);
        this.objAnimator.SetActive(value:  true);
        // 0x00BA74FC: STRB w21, [x19, #0x20]     | this.<IsPlaying>k__BackingField = true;  //  dest_result_addr=1152921514971068560
        this.<IsPlaying>k__BackingField = true;
        // 0x00BA7500: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7504: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA7508: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA750C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA76A0 (12220064), len: 68  VirtAddr: 0x00BA76A0 RVA: 0x00BA76A0 token: 100693321 methodIndex: 25661 delegateWrapperIndex: 0 methodInvoker: 0
    public void Stop()
    {
        //
        // Disasemble & Code
        // 0x00BA76A0: STP x20, x19, [sp, #-0x20]! | stack[1152921514971176688] = ???;  stack[1152921514971176696] = ???;  //  dest_result_addr=1152921514971176688 |  dest_result_addr=1152921514971176696
        // 0x00BA76A4: STP x29, x30, [sp, #0x10]  | stack[1152921514971176704] = ???;  stack[1152921514971176712] = ???;  //  dest_result_addr=1152921514971176704 |  dest_result_addr=1152921514971176712
        // 0x00BA76A8: ADD x29, sp, #0x10         | X29 = (1152921514971176688 + 16) = 1152921514971176704 (0x1000000269C31F00);
        // 0x00BA76AC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA76B0: MOV x19, x0                | X19 = 1152921514971188720 (0x1000000269C34DF0);//ML01
        // 0x00BA76B4: BL #0xba7510               | this.SetCameraState(state:  true);      
        this.SetCameraState(state:  true);
        // 0x00BA76B8: LDR x20, [x19, #0x30]      | X20 = this.objAnimator; //P2            
        // 0x00BA76BC: CBNZ x20, #0xba76c4        | if (this.objAnimator != null) goto label_0;
        if(this.objAnimator != null)
        {
            goto label_0;
        }
        // 0x00BA76C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA76C4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA76C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA76CC: MOV x0, x20                | X0 = this.objAnimator;//m1              
        // 0x00BA76D0: BL #0x1a62d64              | this.objAnimator.SetActive(value:  false);
        this.objAnimator.SetActive(value:  false);
        // 0x00BA76D4: STRB wzr, [x19, #0x20]     | this.<IsPlaying>k__BackingField = false;  //  dest_result_addr=1152921514971188752
        this.<IsPlaying>k__BackingField = false;
        // 0x00BA76D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA76DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA76E0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA76E4 (12220132), len: 152  VirtAddr: 0x00BA76E4 RVA: 0x00BA76E4 token: 100693322 methodIndex: 25662 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnDestroy()
    {
        //
        // Disasemble & Code
        // 0x00BA76E4: STP x20, x19, [sp, #-0x20]! | stack[1152921514971300976] = ???;  stack[1152921514971300984] = ???;  //  dest_result_addr=1152921514971300976 |  dest_result_addr=1152921514971300984
        // 0x00BA76E8: STP x29, x30, [sp, #0x10]  | stack[1152921514971300992] = ???;  stack[1152921514971301000] = ???;  //  dest_result_addr=1152921514971300992 |  dest_result_addr=1152921514971301000
        // 0x00BA76EC: ADD x29, sp, #0x10         | X29 = (1152921514971300976 + 16) = 1152921514971300992 (0x1000000269C50480);
        // 0x00BA76F0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA76F4: LDRB w8, [x20, #0xae8]     | W8 = (bool)static_value_03733AE8;       
        // 0x00BA76F8: MOV x19, x0                | X19 = 1152921514971313008 (0x1000000269C53370);//ML01
        // 0x00BA76FC: TBNZ w8, #0, #0xba7718     | if (static_value_03733AE8 == true) goto label_0;
        // 0x00BA7700: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00BA7704: LDR x8, [x8, #0x5e0]       | X8 = 0x2B90154;                         
        // 0x00BA7708: LDR w0, [x8]               | W0 = 0x1719;                            
        // 0x00BA770C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1719, ????);     
        // 0x00BA7710: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA7714: STRB w8, [x20, #0xae8]     | static_value_03733AE8 = true;            //  dest_result_addr=57883368
        label_0:
        // 0x00BA7718: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BA771C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BA7720: LDR x20, [x19, #0x18]      | X20 = this.gameObject; //P2             
        // 0x00BA7724: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BA7728: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BA772C: TBZ w8, #0, #0xba773c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA7730: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BA7734: CBNZ w8, #0xba773c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA7738: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00BA773C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7740: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA7744: MOV x1, x20                | X1 = this.gameObject;//m1               
        // 0x00BA7748: BL #0x1b78acc              | UnityEngine.Object.Destroy(obj:  0);    
        UnityEngine.Object.Destroy(obj:  0);
        // 0x00BA774C: LDR x20, [x19, #0x28]      | X20 = this.cameraList; //P2             
        // 0x00BA7750: STR xzr, [x19, #0x18]      | this.gameObject = null;                  //  dest_result_addr=1152921514971313032
        this.gameObject = 0;
        // 0x00BA7754: STR xzr, [x19, #0x30]      | this.objAnimator = null;                 //  dest_result_addr=1152921514971313056
        this.objAnimator = 0;
        // 0x00BA7758: CBNZ x20, #0xba7760        | if (this.cameraList != null) goto label_3;
        if(this.cameraList != null)
        {
            goto label_3;
        }
        // 0x00BA775C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00BA7760: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00BA7764: LDR x8, [x8, #0x3f8]       | X8 = 1152921514483231952;               
        // 0x00BA7768: MOV x0, x20                | X0 = this.cameraList;//m1               
        // 0x00BA776C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<BAMCameras>::Clear();
        // 0x00BA7770: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7774: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA7778: B #0x25ead28               | this.cameraList.Clear(); return;        
        this.cameraList.Clear();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA7510 (12219664), len: 400  VirtAddr: 0x00BA7510 RVA: 0x00BA7510 token: 100693323 methodIndex: 25663 delegateWrapperIndex: 0 methodInvoker: 0
    private void SetCameraState(bool state)
    {
        //
        // Disasemble & Code
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        System.Collections.Generic.List<BAMCameras> val_11;
        //  | 
        var val_12;
        // 0x00BA7510: STP x24, x23, [sp, #-0x40]! | stack[1152921514971462096] = ???;  stack[1152921514971462104] = ???;  //  dest_result_addr=1152921514971462096 |  dest_result_addr=1152921514971462104
        // 0x00BA7514: STP x22, x21, [sp, #0x10]  | stack[1152921514971462112] = ???;  stack[1152921514971462120] = ???;  //  dest_result_addr=1152921514971462112 |  dest_result_addr=1152921514971462120
        // 0x00BA7518: STP x20, x19, [sp, #0x20]  | stack[1152921514971462128] = ???;  stack[1152921514971462136] = ???;  //  dest_result_addr=1152921514971462128 |  dest_result_addr=1152921514971462136
        // 0x00BA751C: STP x29, x30, [sp, #0x30]  | stack[1152921514971462144] = ???;  stack[1152921514971462152] = ???;  //  dest_result_addr=1152921514971462144 |  dest_result_addr=1152921514971462152
        // 0x00BA7520: ADD x29, sp, #0x30         | X29 = (1152921514971462096 + 48) = 1152921514971462144 (0x1000000269C77A00);
        // 0x00BA7524: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA7528: LDRB w8, [x20, #0xae9]     | W8 = (bool)static_value_03733AE9;       
        // 0x00BA752C: MOV w21, w1                | W21 = state;//m1                        
        // 0x00BA7530: MOV x19, x0                | X19 = 1152921514971474160 (0x1000000269C7A8F0);//ML01
        // 0x00BA7534: TBNZ w8, #0, #0xba7550     | if (static_value_03733AE9 == true) goto label_0;
        // 0x00BA7538: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
        // 0x00BA753C: LDR x8, [x8, #0x5a0]       | X8 = 0x2B90158;                         
        // 0x00BA7540: LDR w0, [x8]               | W0 = 0x171A;                            
        // 0x00BA7544: BL #0x2782188              | X0 = sub_2782188( ?? 0x171A, ????);     
        // 0x00BA7548: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA754C: STRB w8, [x20, #0xae9]     | static_value_03733AE9 = true;            //  dest_result_addr=57883369
        label_0:
        // 0x00BA7550: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_8 = 0;
        // 0x00BA7554: AND w8, w21, #1            | W8 = (state & 1);                       
        bool val_1 = state;
        // 0x00BA7558: TBZ w8, #0, #0xba760c      | if ((state & 1) == false) goto label_1; 
        if(val_1 == false)
        {
            goto label_1;
        }
        // 0x00BA755C: ADRP x23, #0x364a000       | X23 = 56926208 (0x364A000);             
        // 0x00BA7560: ADRP x24, #0x3634000       | X24 = 56836096 (0x3634000);             
        // 0x00BA7564: LDR x23, [x23, #0x7c8]     | X23 = 1152921514485381488;              
        val_9 = 1152921514485381488;
        // 0x00BA7568: LDR x24, [x24, #0x130]     | X24 = 1152921514485382512;              
        // 0x00BA756C: B #0xba7588                |  goto label_2;                          
        goto label_2;
        label_10:
        // 0x00BA7570: CMP w22, #0                | STATE = COMPARE(W22, 0x0)               
        // 0x00BA7574: CSET w1, ne                | W1 = W22 != 0x0 ? 1 : 0;                
        bool val_2 = (W22 != 0) ? 1 : 0;
        // 0x00BA7578: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA757C: MOV x0, x21                | X0 = state;//m1                         
        // 0x00BA7580: BL #0x20cb458              | state.set_enabled(value:  bool val_2 = (W22 != 0) ? 1 : 0);
        state.enabled = val_2;
        // 0x00BA7584: ADD w20, w20, #1           | W20 = (val_8 + 1) = val_10 (0x00000001);
        val_10 = 1;
        label_2:
        // 0x00BA7588: LDR x21, [x19, #0x28]      | X21 = this.cameraList; //P2             
        val_11 = this.cameraList;
        // 0x00BA758C: CBNZ x21, #0xba7594        | if (this.cameraList != null) goto label_3;
        if(val_11 != null)
        {
            goto label_3;
        }
        // 0x00BA7590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? state, ????);      
        label_3:
        // 0x00BA7594: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<BAMCameras>::get_Count();
        // 0x00BA7598: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00BA759C: BL #0x25ed72c              | X0 = this.cameraList.get_Count();       
        int val_3 = val_11.Count;
        // 0x00BA75A0: CMP w20, w0                | STATE = COMPARE(0x1, val_3)             
        // 0x00BA75A4: B.GE #0xba768c             | if (val_10 >= val_3) goto label_13;     
        if(val_10 >= val_3)
        {
            goto label_13;
        }
        // 0x00BA75A8: LDR x21, [x19, #0x28]      | X21 = this.cameraList; //P2             
        // 0x00BA75AC: CBNZ x21, #0xba75b4        | if (this.cameraList != null) goto label_5;
        if(this.cameraList != null)
        {
            goto label_5;
        }
        // 0x00BA75B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00BA75B4: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00BA75B8: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00BA75BC: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00BA75C0: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  1);
        BAMCameras val_4 = this.cameraList.Item[1];
        // 0x00BA75C4: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00BA75C8: CBNZ x21, #0xba75d0        | if (val_4 != null) goto label_6;        
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00BA75CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x00BA75D0: LDR x21, [x21, #0x10]      | X21 = val_4.camera; //P2                
        // 0x00BA75D4: LDR x22, [x19, #0x28]      | X22 = this.cameraList; //P2             
        // 0x00BA75D8: CBNZ x22, #0xba75e0        | if (this.cameraList != null) goto label_7;
        if(this.cameraList != null)
        {
            goto label_7;
        }
        // 0x00BA75DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00BA75E0: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00BA75E4: MOV x0, x22                | X0 = this.cameraList;//m1               
        // 0x00BA75E8: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00BA75EC: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  1);
        BAMCameras val_5 = this.cameraList.Item[1];
        // 0x00BA75F0: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00BA75F4: CBNZ x22, #0xba75fc        | if (val_5 != null) goto label_8;        
        if(val_5 != null)
        {
            goto label_8;
        }
        // 0x00BA75F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00BA75FC: LDRB w22, [x22, #0x18]     | W22 = val_5.initEnable; //P2            
        // 0x00BA7600: CBNZ x21, #0xba7570        | if (val_4.camera != null) goto label_10;
        if(val_4.camera != null)
        {
            goto label_10;
        }
        // 0x00BA7604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        // 0x00BA7608: B #0xba7570                |  goto label_10;                         
        goto label_10;
        label_1:
        // 0x00BA760C: ADRP x22, #0x364a000       | X22 = 56926208 (0x364A000);             
        // 0x00BA7610: ADRP x23, #0x3634000       | X23 = 56836096 (0x3634000);             
        // 0x00BA7614: LDR x22, [x22, #0x7c8]     | X22 = 1152921514485381488;              
        // 0x00BA7618: LDR x23, [x23, #0x130]     | X23 = 1152921514485382512;              
        val_9 = 1152921514485382512;
        // 0x00BA761C: B #0xba7634                |  goto label_11;                         
        goto label_11;
        label_17:
        // 0x00BA7620: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA7624: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA7628: MOV x0, x21                | X0 = state;//m1                         
        // 0x00BA762C: BL #0x20cb458              | state.set_enabled(value:  false);       
        state.enabled = false;
        // 0x00BA7630: ADD w20, w20, #1           | W20 = (val_8 + 1) = val_12 (0x00000001);
        val_12 = 1;
        label_11:
        // 0x00BA7634: LDR x21, [x19, #0x28]      | X21 = this.cameraList; //P2             
        val_11 = this.cameraList;
        // 0x00BA7638: CBNZ x21, #0xba7640        | if (this.cameraList != null) goto label_12;
        if(val_11 != null)
        {
            goto label_12;
        }
        // 0x00BA763C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? state, ????);      
        label_12:
        // 0x00BA7640: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<BAMCameras>::get_Count();
        // 0x00BA7644: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00BA7648: BL #0x25ed72c              | X0 = this.cameraList.get_Count();       
        int val_6 = val_11.Count;
        // 0x00BA764C: CMP w20, w0                | STATE = COMPARE(0x1, val_6)             
        // 0x00BA7650: B.GE #0xba768c             | if (val_12 >= val_6) goto label_13;     
        if(val_12 >= val_6)
        {
            goto label_13;
        }
        // 0x00BA7654: LDR x21, [x19, #0x28]      | X21 = this.cameraList; //P2             
        // 0x00BA7658: CBNZ x21, #0xba7660        | if (this.cameraList != null) goto label_14;
        if(this.cameraList != null)
        {
            goto label_14;
        }
        // 0x00BA765C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_14:
        // 0x00BA7660: LDR x2, [x23]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00BA7664: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00BA7668: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00BA766C: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  1);
        BAMCameras val_7 = this.cameraList.Item[1];
        // 0x00BA7670: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x00BA7674: CBNZ x21, #0xba767c        | if (val_7 != null) goto label_15;       
        if(val_7 != null)
        {
            goto label_15;
        }
        // 0x00BA7678: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_15:
        // 0x00BA767C: LDR x21, [x21, #0x10]      | X21 = val_7.camera; //P2                
        // 0x00BA7680: CBNZ x21, #0xba7620        | if (val_7.camera != null) goto label_17;
        if(val_7.camera != null)
        {
            goto label_17;
        }
        // 0x00BA7684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        // 0x00BA7688: B #0xba7620                |  goto label_17;                         
        goto label_17;
        label_13:
        // 0x00BA768C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7690: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA7694: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA7698: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00BA769C: RET                        |  return;                                
        return;
    
    }

}
