using UnityEngine;

namespace Pathfinding.Util
{
    public class Checksum
    {
        // Fields
        private static readonly uint[] CRCTable; // static_offset: 0x00000000
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x028CE2CC (42787532), len: 8  VirtAddr: 0x028CE2CC RVA: 0x028CE2CC token: 100683722 methodIndex: 51306 delegateWrapperIndex: 0 methodInvoker: 0
        public Checksum()
        {
            //
            // Disasemble & Code
            // 0x028CE2CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028CE2D0: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028CE2D4 (42787540), len: 104  VirtAddr: 0x028CE2D4 RVA: 0x028CE2D4 token: 100683723 methodIndex: 51307 delegateWrapperIndex: 0 methodInvoker: 0
        public static uint GetChecksum(byte[] Value)
        {
            //
            // Disasemble & Code
            // 0x028CE2D4: STP x20, x19, [sp, #-0x20]! | stack[1152921513532628768] = ???;  stack[1152921513532628776] = ???;  //  dest_result_addr=1152921513532628768 |  dest_result_addr=1152921513532628776
            // 0x028CE2D8: STP x29, x30, [sp, #0x10]  | stack[1152921513532628784] = ???;  stack[1152921513532628792] = ???;  //  dest_result_addr=1152921513532628784 |  dest_result_addr=1152921513532628792
            // 0x028CE2DC: ADD x29, sp, #0x10         | X29 = (1152921513532628768 + 16) = 1152921513532628784 (0x1000000214049F30);
            // 0x028CE2E0: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028CE2E4: LDRB w8, [x20, #0x990]     | W8 = (bool)static_value_037B8990;       
            // 0x028CE2E8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028CE2EC: TBNZ w8, #0, #0x28ce308    | if (static_value_037B8990 == true) goto label_0;
            // 0x028CE2F0: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x028CE2F4: LDR x8, [x8, #0x900]       | X8 = 0x2B90A78;                         
            // 0x028CE2F8: LDR w0, [x8]               | W0 = 0x1962;                            
            // 0x028CE2FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1962, ????);     
            // 0x028CE300: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028CE304: STRB w8, [x20, #0x990]     | static_value_037B8990 = true;            //  dest_result_addr=58427792
            label_0:
            // 0x028CE308: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x028CE30C: LDR x8, [x8, #0x660]       | X8 = 1152921504850776064;               
            // 0x028CE310: LDR x0, [x8]               | X0 = typeof(Pathfinding.Util.Checksum); 
            // 0x028CE314: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.Checksum.__il2cppRuntimeField_10A;
            // 0x028CE318: TBZ w8, #0, #0x28ce328     | if (Pathfinding.Util.Checksum.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028CE31C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.Checksum.__il2cppRuntimeField_cctor_finished;
            // 0x028CE320: CBNZ w8, #0x28ce328        | if (Pathfinding.Util.Checksum.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028CE324: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.Checksum), ????);
            label_2:
            // 0x028CE328: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028CE32C: MOVN w2, #0                | W2 = 0 (0x0);//ML01                     
            // 0x028CE330: MOV x1, x19                | X1 = X1;//m1                            
            // 0x028CE334: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028CE338: B #0x28bdd04               | return Pathfinding.Util.Checksum.GetChecksum(Value:  null, CRCVal:  X1);
            return Pathfinding.Util.Checksum.GetChecksum(Value:  null, CRCVal:  X1);
        
        }
        //
        // Offset in libil2cpp.so: 0x028BDD04 (42720516), len: 256  VirtAddr: 0x028BDD04 RVA: 0x028BDD04 token: 100683724 methodIndex: 51308 delegateWrapperIndex: 0 methodInvoker: 0
        public static uint GetChecksum(byte[] Value, uint CRCVal)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x028BDD04: STP x24, x23, [sp, #-0x40]! | stack[1152921513532814464] = ???;  stack[1152921513532814472] = ???;  //  dest_result_addr=1152921513532814464 |  dest_result_addr=1152921513532814472
            // 0x028BDD08: STP x22, x21, [sp, #0x10]  | stack[1152921513532814480] = ???;  stack[1152921513532814488] = ???;  //  dest_result_addr=1152921513532814480 |  dest_result_addr=1152921513532814488
            // 0x028BDD0C: STP x20, x19, [sp, #0x20]  | stack[1152921513532814496] = ???;  stack[1152921513532814504] = ???;  //  dest_result_addr=1152921513532814496 |  dest_result_addr=1152921513532814504
            // 0x028BDD10: STP x29, x30, [sp, #0x30]  | stack[1152921513532814512] = ???;  stack[1152921513532814520] = ???;  //  dest_result_addr=1152921513532814512 |  dest_result_addr=1152921513532814520
            // 0x028BDD14: ADD x29, sp, #0x30         | X29 = (1152921513532814464 + 48) = 1152921513532814512 (0x10000002140774B0);
            // 0x028BDD18: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028BDD1C: LDRB w8, [x21, #0x991]     | W8 = (bool)static_value_037B8991;       
            // 0x028BDD20: MOV w19, w2                | W19 = W2;//m1                           
            val_4 = W2;
            // 0x028BDD24: MOV x20, x1                | X20 = CRCVal;//m1                       
            // 0x028BDD28: TBNZ w8, #0, #0x28bdd44    | if (static_value_037B8991 == true) goto label_0;
            // 0x028BDD2C: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x028BDD30: LDR x8, [x8, #0xf38]       | X8 = 0x2B90A74;                         
            // 0x028BDD34: LDR w0, [x8]               | W0 = 0x1961;                            
            // 0x028BDD38: BL #0x2782188              | X0 = sub_2782188( ?? 0x1961, ????);     
            // 0x028BDD3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BDD40: STRB w8, [x21, #0x991]     | static_value_037B8991 = true;            //  dest_result_addr=58427793
            label_0:
            // 0x028BDD44: ADRP x22, #0x35ba000       | X22 = 56336384 (0x35BA000);             
            // 0x028BDD48: LDR x22, [x22, #0x660]     | X22 = 1152921504850776064;              
            // 0x028BDD4C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x028BDD50: B #0x28bdd64               |  goto label_1;                          
            goto label_1;
            label_9:
            // 0x028BDD54: ADD x8, x23, x24, lsl #2   | X8 = (X23 + (X24) << 2);                
            var val_1 = X23 + ((X24) << 2);
            // 0x028BDD58: LDR w8, [x8, #0x20]        | W8 = (X23 + (X24) << 2) + 32;           
            // 0x028BDD5C: ADD w21, w21, #1           | W21 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            // 0x028BDD60: EOR w19, w8, w19, lsr #8   | W19 = ((X23 + (X24) << 2) + 32 ^ (W2) >> 8);
            val_4 = ((X23 + (X24) << 2) + 32) ^ (val_4 >> 8);
            label_1:
            // 0x028BDD64: CBNZ x20, #0x28bdd6c       | if (CRCVal != 0) goto label_2;          
            if(CRCVal != 0)
            {
                goto label_2;
            }
            // 0x028BDD68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1961, ????);     
            label_2:
            // 0x028BDD6C: LDR x8, [x20, #0x18]       | X8 = CRCVal + 24;                       
            val_6 = mem[CRCVal + 24];
            val_6 = CRCVal + 24;
            // 0x028BDD70: CMP w21, w8                | STATE = COMPARE(0x1, CRCVal + 24)       
            // 0x028BDD74: B.GE #0x28bddec            | if (val_5 >= val_6) goto label_3;       
            if(val_5 >= val_6)
            {
                goto label_3;
            }
            // 0x028BDD78: LDR x0, [x22]              | X0 = typeof(Pathfinding.Util.Checksum); 
            val_7 = null;
            // 0x028BDD7C: LDRB w9, [x0, #0x10a]      | W9 = Pathfinding.Util.Checksum.__il2cppRuntimeField_10A;
            // 0x028BDD80: TBZ w9, #0, #0x28bdd98     | if (Pathfinding.Util.Checksum.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028BDD84: LDR w9, [x0, #0xbc]        | W9 = Pathfinding.Util.Checksum.__il2cppRuntimeField_cctor_finished;
            // 0x028BDD88: CBNZ w9, #0x28bdd98        | if (Pathfinding.Util.Checksum.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028BDD8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.Checksum), ????);
            // 0x028BDD90: LDR x0, [x22]              | X0 = typeof(Pathfinding.Util.Checksum); 
            val_7 = null;
            // 0x028BDD94: LDR x8, [x20, #0x18]       | X8 = CRCVal + 24;                       
            val_6 = mem[CRCVal + 24];
            val_6 = CRCVal + 24;
            label_5:
            // 0x028BDD98: LDR x9, [x0, #0xa0]        | X9 = Pathfinding.Util.Checksum.__il2cppRuntimeField_static_fields;
            // 0x028BDD9C: SXTW x24, w21              | X24 = 1 (0x00000001);                   
            // 0x028BDDA0: CMP w21, w8                | STATE = COMPARE(0x1, CRCVal + 24)       
            // 0x028BDDA4: LDR x23, [x9]              | X23 = Pathfinding.Util.Checksum.CRCTable;
            // 0x028BDDA8: B.LO #0x28bddb8            | if (val_5 < val_6) goto label_6;        
            if(val_5 < val_6)
            {
                goto label_6;
            }
            // 0x028BDDAC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Util.Checksum), ????);
            // 0x028BDDB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDDB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Util.Checksum), ????);
            label_6:
            // 0x028BDDB8: ADD x8, x20, x24           | X8 = (CRCVal + 1);                      
            uint val_2 = CRCVal + 1;
            // 0x028BDDBC: LDRB w24, [x8, #0x20]      | W24 = (CRCVal + 1) + 32;                
            var val_4 = (CRCVal + 1) + 32;
            // 0x028BDDC0: CBNZ x23, #0x28bddc8       | if (Pathfinding.Util.Checksum.CRCTable != null) goto label_7;
            if(Pathfinding.Util.Checksum.CRCTable != null)
            {
                goto label_7;
            }
            // 0x028BDDC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Util.Checksum), ????);
            label_7:
            // 0x028BDDC8: LDR w8, [x23, #0x18]       | W8 = Pathfinding.Util.Checksum.CRCTable.Length;
            // 0x028BDDCC: AND w9, w19, #0xff         | W9 = (((X23 + (X24) << 2) + 32 ^ (W2) >> 8) & 255);
            var val_3 = val_4 & 255;
            // 0x028BDDD0: EOR w24, w24, w9           | W24 = ((CRCVal + 1) + 32 ^ (((X23 + (X24) << 2) + 32 ^ (W2) >> 8) & 255));
            val_4 = val_4 ^ val_3;
            // 0x028BDDD4: CMP w24, w8                | STATE = COMPARE(((CRCVal + 1) + 32 ^ (((X23 + (X24) << 2) + 32 ^ (W2) >> 8) & 255)), Pathfinding.Util.Checksum.CRCTable.Length)
            // 0x028BDDD8: B.LO #0x28bdd54            | if ((CRCVal + 1) + 32 < Pathfinding.Util.Checksum.CRCTable.Length) goto label_9;
            if(val_4 < Pathfinding.Util.Checksum.CRCTable.Length)
            {
                goto label_9;
            }
            // 0x028BDDDC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Util.Checksum), ????);
            // 0x028BDDE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDDE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Util.Checksum), ????);
            // 0x028BDDE8: B #0x28bdd54               |  goto label_9;                          
            goto label_9;
            label_3:
            // 0x028BDDEC: MOV w0, w19                | W0 = ((X23 + (X24) << 2) + 32 ^ (W2) >> 8);//m1
            // 0x028BDDF0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028BDDF4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028BDDF8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028BDDFC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028BDE00: RET                        |  return (System.UInt32)((X23 + (X24) << 2) + 32 ^ (W2) >> 8);
            return (uint)val_4;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028CE33C (42787644), len: 724  VirtAddr: 0x028CE33C RVA: 0x028CE33C token: 100683725 methodIndex: 51309 delegateWrapperIndex: 0 methodInvoker: 0
        private static Checksum()
        {
            //
            // Disasemble & Code
            // 0x028CE33C: STP x20, x19, [sp, #-0x20]! | stack[1152921513532968480] = ???;  stack[1152921513532968488] = ???;  //  dest_result_addr=1152921513532968480 |  dest_result_addr=1152921513532968488
            // 0x028CE340: STP x29, x30, [sp, #0x10]  | stack[1152921513532968496] = ???;  stack[1152921513532968504] = ???;  //  dest_result_addr=1152921513532968496 |  dest_result_addr=1152921513532968504
            // 0x028CE344: ADD x29, sp, #0x10         | X29 = (1152921513532968480 + 16) = 1152921513532968496 (0x100000021409CE30);
            // 0x028CE348: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028CE34C: LDRB w8, [x19, #0x992]     | W8 = (bool)static_value_037B8992;       
            // 0x028CE350: TBNZ w8, #0, #0x28ce36c    | if (static_value_037B8992 == true) goto label_0;
            // 0x028CE354: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x028CE358: LDR x8, [x8, #0xf98]       | X8 = 0x2B90A70;                         
            // 0x028CE35C: LDR w0, [x8]               | W0 = 0x1960;                            
            // 0x028CE360: BL #0x2782188              | X0 = sub_2782188( ?? 0x1960, ????);     
            // 0x028CE364: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028CE368: STRB w8, [x19, #0x992]     | static_value_037B8992 = true;            //  dest_result_addr=58427794
            label_0:
            // 0x028CE36C: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x028CE370: LDR x8, [x8, #0x1b8]       | X8 = 1152921505007033440;               
            // 0x028CE374: LDR x19, [x8]              | X19 = typeof(System.UInt32[]);          
            // 0x028CE378: MOV x0, x19                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x028CE37C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.UInt32[]), ????);
            // 0x028CE380: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
            // 0x028CE384: MOV x0, x19                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x028CE388: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.UInt32[]), ????);
            // 0x028CE38C: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x028CE390: LDR x8, [x8, #0x738]       | X8 = 1152921513532951392;               
            // 0x028CE394: MOV x19, x0                | X19 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x028CE398: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028CE39C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028CE3A0: LDR x2, [x8]               | X2 = System.Byte[];                     
            // 0x028CE3A4: MOV x1, x19                | X1 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x028CE3A8: BL #0x13caf10              | X0 = new [] {}                          
            // 0x028CE3AC: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x028CE3B0: LDR x8, [x8, #0x660]       | X8 = 1152921504850776064;               
            // 0x028CE3B4: LDR x8, [x8]               | X8 = typeof(Pathfinding.Util.Checksum); 
            // 0x028CE3B8: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.Util.Checksum.__il2cppRuntimeField_static_fields;
            // 0x028CE3BC: STR x19, [x8]              | Pathfinding.Util.Checksum.CRCTable = typeof(System.UInt32[]);  //  dest_result_addr=1152921504850780160
            Pathfinding.Util.Checksum.CRCTable = null;
            // 0x028CE3C0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028CE3C4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028CE3C8: RET                        |  return;                                
            return;
        
        }
    
    }

}
