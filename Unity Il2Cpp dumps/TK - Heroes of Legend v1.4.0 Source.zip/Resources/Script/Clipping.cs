using UnityEngine;
public enum UIDrawCall.Clipping
{
    // Fields
    None = 0
    ,TextureMask = 1
    ,SoftClip = 3
    ,ConstrainButDontClip = 4
    

}
