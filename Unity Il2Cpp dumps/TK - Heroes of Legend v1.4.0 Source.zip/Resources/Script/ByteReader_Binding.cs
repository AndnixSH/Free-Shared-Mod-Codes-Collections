using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class ByteReader_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache0; // static_offset: 0x00000040
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01429EE0 (21143264), len: 8  VirtAddr: 0x01429EE0 RVA: 0x01429EE0 token: 100664111 methodIndex: 30156 delegateWrapperIndex: 0 methodInvoker: 0
        public ByteReader_Binding()
        {
            //
            // Disasemble & Code
            // 0x01429EE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429EE4: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01429EE8 (21143272), len: 2304  VirtAddr: 0x01429EE8 RVA: 0x01429EE8 token: 100664112 methodIndex: 30157 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_23;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_24;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_26;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_27;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_28;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_29;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_30;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_31;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_32;
            // 0x01429EE8: STP x28, x27, [sp, #-0x60]! | stack[1152921510103475056] = ???;  stack[1152921510103475064] = ???;  //  dest_result_addr=1152921510103475056 |  dest_result_addr=1152921510103475064
            // 0x01429EEC: STP x26, x25, [sp, #0x10]  | stack[1152921510103475072] = ???;  stack[1152921510103475080] = ???;  //  dest_result_addr=1152921510103475072 |  dest_result_addr=1152921510103475080
            // 0x01429EF0: STP x24, x23, [sp, #0x20]  | stack[1152921510103475088] = ???;  stack[1152921510103475096] = ???;  //  dest_result_addr=1152921510103475088 |  dest_result_addr=1152921510103475096
            // 0x01429EF4: STP x22, x21, [sp, #0x30]  | stack[1152921510103475104] = ???;  stack[1152921510103475112] = ???;  //  dest_result_addr=1152921510103475104 |  dest_result_addr=1152921510103475112
            // 0x01429EF8: STP x20, x19, [sp, #0x40]  | stack[1152921510103475120] = ???;  stack[1152921510103475128] = ???;  //  dest_result_addr=1152921510103475120 |  dest_result_addr=1152921510103475128
            // 0x01429EFC: STP x29, x30, [sp, #0x50]  | stack[1152921510103475136] = ???;  stack[1152921510103475144] = ???;  //  dest_result_addr=1152921510103475136 |  dest_result_addr=1152921510103475144
            // 0x01429F00: ADD x29, sp, #0x50         | X29 = (1152921510103475056 + 80) = 1152921510103475136 (0x10000001479FE3C0);
            // 0x01429F04: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01429F08: LDRB w8, [x20, #0x11]      | W8 = (bool)static_value_03737011;       
            // 0x01429F0C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01429F10: TBNZ w8, #0, #0x1429f2c    | if (static_value_03737011 == true) goto label_0;
            // 0x01429F14: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x01429F18: LDR x8, [x8, #0xb08]       | X8 = 0x2B8FFEC;                         
            // 0x01429F1C: LDR w0, [x8]               | W0 = 0x16BF;                            
            // 0x01429F20: BL #0x2782188              | X0 = sub_2782188( ?? 0x16BF, ????);     
            // 0x01429F24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01429F28: STRB w8, [x20, #0x11]      | static_value_03737011 = true;            //  dest_result_addr=57896977
            label_0:
            // 0x01429F2C: ADRP x24, #0x3620000       | X24 = 56754176 (0x3620000);             
            // 0x01429F30: LDR x24, [x24, #0x340]     | X24 = 1152921504609562624;              
            // 0x01429F34: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
            // 0x01429F38: LDR x0, [x24]              | X0 = typeof(System.Type);               
            // 0x01429F3C: LDR x8, [x8, #0x400]       | X8 = 1152921504876068864;               
            // 0x01429F40: LDR x20, [x8]              | X20 = typeof(ByteReader);               
            // 0x01429F44: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01429F48: TBZ w8, #0, #0x1429f58     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01429F4C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01429F50: CBNZ w8, #0x1429f58        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01429F54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01429F58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01429F5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01429F60: MOV x1, x20                | X1 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x01429F64: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01429F68: ADRP x26, #0x35ef000       | X26 = 56553472 (0x35EF000);             
            // 0x01429F6C: LDR x26, [x26, #0xff0]     | X26 = 1152921504987155056;              
            // 0x01429F70: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01429F74: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x01429F78: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01429F7C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01429F80: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01429F84: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01429F88: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01429F8C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x01429F90: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x01429F94: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01429F98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01429F9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01429FA0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01429FA4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01429FA8: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x01429FAC: CBNZ x21, #0x1429fb4       | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x01429FB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x01429FB4: CBZ x22, #0x1429fd8        | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x01429FB8: LDR x8, [x21]              | X8 = ;                                  
            // 0x01429FBC: MOV x0, x22                | X0 = val_2;//m1                         
            // 0x01429FC0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01429FC4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x01429FC8: CBNZ x0, #0x1429fd8        | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x01429FCC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x01429FD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429FD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_5:
            // 0x01429FD8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01429FDC: CBNZ w8, #0x1429fec        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x01429FE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x01429FE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429FE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x01429FEC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;
            // 0x01429FF0: CBNZ x20, #0x1429ff8       | if (val_1 != null) goto label_7;        
            if(val_1 != null)
            {
                goto label_7;
            }
            // 0x01429FF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x01429FF8: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x01429FFC: LDR x8, [x8, #0x6f0]       | X8 = (string**)(1152921510103408416)("Open");
            // 0x0142A000: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A004: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142A008: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142A00C: LDR x1, [x8]               | X1 = "Open";                            
            // 0x0142A010: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142A014: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A018: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142A01C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Open", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_3 = val_1.GetMethod(name:  "Open", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142A020: ADRP x25, #0x3649000       | X25 = 56922112 (0x3649000);             
            // 0x0142A024: LDR x25, [x25, #0xc30]     | X25 = 1152921504783470592;              
            // 0x0142A028: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x0142A02C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A030: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A034: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache0;
            val_23 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache0;
            // 0x0142A038: CBNZ x22, #0x142a084       | if (ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache0 != null) goto label_8;
            if(val_23 != null)
            {
                goto label_8;
            }
            // 0x0142A03C: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
            // 0x0142A040: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142A044: LDR x8, [x8, #0x4d8]       | X8 = 1152921510103412592;               
            // 0x0142A048: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142A04C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Open_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142A050: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_4 = null;
            // 0x0142A054: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142A058: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A05C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A060: MOV x2, x22                | X2 = 1152921510103412592 (0x10000001479EEF70);//ML01
            // 0x0142A064: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_24 = val_4;
            // 0x0142A068: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Open_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Open_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142A06C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A070: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A074: STR x23, [x8]              | ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783474688
            ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache0 = val_24;
            // 0x0142A078: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A07C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A080: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_23 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache0;
            label_8:
            // 0x0142A084: CBNZ x19, #0x142a08c       | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x0142A088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Open_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_9:
            // 0x0142A08C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A090: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142A094: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x0142A098: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142A09C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_3, func:  val_23);
            X1.RegisterCLRMethodRedirection(mi:  val_3, func:  val_23);
            // 0x0142A0A0: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0142A0A4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A0A8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142A0AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A0B0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A0B4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142A0B8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A0BC: CBNZ x20, #0x142a0c4       | if (val_1 != null) goto label_10;       
            if(val_1 != null)
            {
                goto label_10;
            }
            // 0x0142A0C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_10:
            // 0x0142A0C4: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x0142A0C8: LDR x8, [x8, #0xc88]       | X8 = (string**)(1152921510103413616)("get_canRead");
            // 0x0142A0CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A0D0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142A0D4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142A0D8: LDR x1, [x8]               | X1 = "get_canRead";                     
            // 0x0142A0DC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142A0E0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A0E4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142A0E8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_canRead", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_5 = val_1.GetMethod(name:  "get_canRead", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142A0EC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A0F0: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x0142A0F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A0F8: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache1;
            val_25 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache1;
            // 0x0142A0FC: CBNZ x22, #0x142a148       | if (ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache1 != null) goto label_11;
            if(val_25 != null)
            {
                goto label_11;
            }
            // 0x0142A100: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x0142A104: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142A108: LDR x8, [x8, #0x388]       | X8 = 1152921510103417808;               
            // 0x0142A10C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142A110: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::get_canRead_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142A114: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_6 = null;
            // 0x0142A118: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142A11C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A120: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A124: MOV x2, x22                | X2 = 1152921510103417808 (0x10000001479F03D0);//ML01
            // 0x0142A128: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_24 = val_6;
            // 0x0142A12C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::get_canRead_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::get_canRead_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142A130: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A134: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A138: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783474696
            ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache1 = val_24;
            // 0x0142A13C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A140: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A144: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_25 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache1;
            label_11:
            // 0x0142A148: CBNZ x19, #0x142a150       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x0142A14C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::get_canRead_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_12:
            // 0x0142A150: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A154: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142A158: MOV x1, x21                | X1 = val_5;//m1                         
            // 0x0142A15C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142A160: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_5, func:  val_25);
            X1.RegisterCLRMethodRedirection(mi:  val_5, func:  val_25);
            // 0x0142A164: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0142A168: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A16C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142A170: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A174: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A178: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142A17C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A180: CBNZ x20, #0x142a188       | if (val_1 != null) goto label_13;       
            if(val_1 != null)
            {
                goto label_13;
            }
            // 0x0142A184: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_13:
            // 0x0142A188: ADRP x27, #0x367a000       | X27 = 57122816 (0x367A000);             
            // 0x0142A18C: LDR x27, [x27, #0xc08]     | X27 = (string**)(1152921510103418832)("ReadLine");
            // 0x0142A190: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A194: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142A198: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142A19C: LDR x1, [x27]              | X1 = "ReadLine";                        
            // 0x0142A1A0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142A1A4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A1A8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142A1AC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ReadLine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_7 = val_1.GetMethod(name:  "ReadLine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142A1B0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A1B4: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x0142A1B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A1BC: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache2;
            val_26 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache2;
            // 0x0142A1C0: CBNZ x22, #0x142a20c       | if (ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache2 != null) goto label_14;
            if(val_26 != null)
            {
                goto label_14;
            }
            // 0x0142A1C4: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x0142A1C8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142A1CC: LDR x8, [x8, #0x488]       | X8 = 1152921510103423024;               
            // 0x0142A1D0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142A1D4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadLine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142A1D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_8 = null;
            // 0x0142A1DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142A1E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A1E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A1E8: MOV x2, x22                | X2 = 1152921510103423024 (0x10000001479F1830);//ML01
            // 0x0142A1EC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_24 = val_8;
            // 0x0142A1F0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadLine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_8 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadLine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142A1F4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A1F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A1FC: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783474704
            ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache2 = val_24;
            // 0x0142A200: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A204: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A208: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_26 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache2;
            label_14:
            // 0x0142A20C: CBNZ x19, #0x142a214       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x0142A210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadLine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_15:
            // 0x0142A214: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A218: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142A21C: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x0142A220: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142A224: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_7, func:  val_26);
            X1.RegisterCLRMethodRedirection(mi:  val_7, func:  val_26);
            // 0x0142A228: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0142A22C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A230: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142A234: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0142A238: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A23C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142A240: ADRP x9, #0x365e000        | X9 = 57008128 (0x365E000);              
            // 0x0142A244: LDR x8, [x24]              | X8 = typeof(System.Type);               
            // 0x0142A248: LDR x9, [x9, #0xcb8]       | X9 = 1152921504608604160;               
            // 0x0142A24C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A250: LDR x22, [x9]              | X22 = typeof(System.Boolean);           
            // 0x0142A254: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142A258: TBZ w9, #0, #0x142a26c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x0142A25C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142A260: CBNZ w9, #0x142a26c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x0142A264: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142A268: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_17:
            // 0x0142A26C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142A270: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142A274: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x0142A278: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142A27C: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x0142A280: CBNZ x21, #0x142a288       | if ( != null) goto label_18;            
            if(null != null)
            {
                goto label_18;
            }
            // 0x0142A284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_18:
            // 0x0142A288: CBZ x22, #0x142a2ac        | if (val_9 == null) goto label_20;       
            if(val_9 == null)
            {
                goto label_20;
            }
            // 0x0142A28C: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142A290: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x0142A294: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142A298: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x0142A29C: CBNZ x0, #0x142a2ac        | if (val_9 != null) goto label_20;       
            if(val_9 != null)
            {
                goto label_20;
            }
            // 0x0142A2A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x0142A2A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A2A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_20:
            // 0x0142A2AC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142A2B0: CBNZ w8, #0x142a2c0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_21;
            // 0x0142A2B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x0142A2B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A2BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_21:
            // 0x0142A2C0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;
            // 0x0142A2C4: CBNZ x20, #0x142a2cc       | if (val_1 != null) goto label_22;       
            if(val_1 != null)
            {
                goto label_22;
            }
            // 0x0142A2C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_22:
            // 0x0142A2CC: LDR x1, [x27]              | X1 = "ReadLine";                        
            // 0x0142A2D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A2D4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142A2D8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142A2DC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142A2E0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A2E4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142A2E8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ReadLine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_10 = val_1.GetMethod(name:  "ReadLine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142A2EC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A2F0: MOV x21, x0                | X21 = val_10;//m1                       
            // 0x0142A2F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A2F8: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache3;
            val_27 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache3;
            // 0x0142A2FC: CBNZ x22, #0x142a348       | if (ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache3 != null) goto label_23;
            if(val_27 != null)
            {
                goto label_23;
            }
            // 0x0142A300: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x0142A304: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142A308: LDR x8, [x8, #0x370]       | X8 = 1152921510103432240;               
            // 0x0142A30C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142A310: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadLine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142A314: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_11 = null;
            // 0x0142A318: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142A31C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A320: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A324: MOV x2, x22                | X2 = 1152921510103432240 (0x10000001479F3C30);//ML01
            // 0x0142A328: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_24 = val_11;
            // 0x0142A32C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadLine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_11 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadLine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142A330: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A334: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A338: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783474712
            ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache3 = val_24;
            // 0x0142A33C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A340: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A344: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_27 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache3;
            label_23:
            // 0x0142A348: CBNZ x19, #0x142a350       | if (X1 != 0) goto label_24;             
            if(X1 != 0)
            {
                goto label_24;
            }
            // 0x0142A34C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadLine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_24:
            // 0x0142A350: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A354: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142A358: MOV x1, x21                | X1 = val_10;//m1                        
            // 0x0142A35C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142A360: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_27);
            X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_27);
            // 0x0142A364: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0142A368: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A36C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142A370: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A374: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A378: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142A37C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A380: CBNZ x20, #0x142a388       | if (val_1 != null) goto label_25;       
            if(val_1 != null)
            {
                goto label_25;
            }
            // 0x0142A384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_25:
            // 0x0142A388: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x0142A38C: LDR x8, [x8, #0x8f8]       | X8 = (string**)(1152921510103433264)("ReadDictionary");
            // 0x0142A390: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A394: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142A398: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142A39C: LDR x1, [x8]               | X1 = "ReadDictionary";                  
            // 0x0142A3A0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142A3A4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A3A8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142A3AC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ReadDictionary", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_12 = val_1.GetMethod(name:  "ReadDictionary", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142A3B0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A3B4: MOV x21, x0                | X21 = val_12;//m1                       
            // 0x0142A3B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A3BC: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache4;
            val_28 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache4;
            // 0x0142A3C0: CBNZ x22, #0x142a40c       | if (ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache4 != null) goto label_26;
            if(val_28 != null)
            {
                goto label_26;
            }
            // 0x0142A3C4: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x0142A3C8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142A3CC: LDR x8, [x8, #0x408]       | X8 = 1152921510103437456;               
            // 0x0142A3D0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142A3D4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadDictionary_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142A3D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13 = null;
            // 0x0142A3DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142A3E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A3E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A3E8: MOV x2, x22                | X2 = 1152921510103437456 (0x10000001479F5090);//ML01
            // 0x0142A3EC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_24 = val_13;
            // 0x0142A3F0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadDictionary_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_13 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadDictionary_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142A3F4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A3F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A3FC: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783474720
            ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache4 = val_24;
            // 0x0142A400: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A404: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A408: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_28 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache4;
            label_26:
            // 0x0142A40C: CBNZ x19, #0x142a414       | if (X1 != 0) goto label_27;             
            if(X1 != 0)
            {
                goto label_27;
            }
            // 0x0142A410: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadDictionary_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_27:
            // 0x0142A414: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A418: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142A41C: MOV x1, x21                | X1 = val_12;//m1                        
            // 0x0142A420: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142A424: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_28);
            X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_28);
            // 0x0142A428: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0142A42C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A430: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142A434: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A438: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A43C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142A440: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A444: CBNZ x20, #0x142a44c       | if (val_1 != null) goto label_28;       
            if(val_1 != null)
            {
                goto label_28;
            }
            // 0x0142A448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_28:
            // 0x0142A44C: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x0142A450: LDR x8, [x8, #0x88]        | X8 = (string**)(1152921510103438480)("ReadCSV");
            // 0x0142A454: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A458: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142A45C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142A460: LDR x1, [x8]               | X1 = "ReadCSV";                         
            // 0x0142A464: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142A468: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A46C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142A470: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ReadCSV", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_14 = val_1.GetMethod(name:  "ReadCSV", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142A474: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A478: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x0142A47C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A480: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache5;
            val_29 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache5;
            // 0x0142A484: CBNZ x22, #0x142a4d0       | if (ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache5 != null) goto label_29;
            if(val_29 != null)
            {
                goto label_29;
            }
            // 0x0142A488: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0142A48C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142A490: LDR x8, [x8, #0xc50]       | X8 = 1152921510103442672;               
            // 0x0142A494: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142A498: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadCSV_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142A49C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_15 = null;
            // 0x0142A4A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142A4A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A4A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A4AC: MOV x2, x22                | X2 = 1152921510103442672 (0x10000001479F64F0);//ML01
            // 0x0142A4B0: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_24 = val_15;
            // 0x0142A4B4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadCSV_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadCSV_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142A4B8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A4BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A4C0: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783474728
            ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache5 = val_24;
            // 0x0142A4C4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A4C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A4CC: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_29 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache5;
            label_29:
            // 0x0142A4D0: CBNZ x19, #0x142a4d8       | if (X1 != 0) goto label_30;             
            if(X1 != 0)
            {
                goto label_30;
            }
            // 0x0142A4D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::ReadCSV_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_30:
            // 0x0142A4D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A4DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142A4E0: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x0142A4E4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142A4E8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_29);
            X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_29);
            // 0x0142A4EC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A4F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A4F4: LDR x21, [x8, #0x40]       | X21 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__am$cache0;
            val_30 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__am$cache0;
            // 0x0142A4F8: CBNZ x21, #0x142a544       | if (ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__am$cache0 != null) goto label_31;
            if(val_30 != null)
            {
                goto label_31;
            }
            // 0x0142A4FC: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x0142A500: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x0142A504: LDR x8, [x8, #0xdd0]       | X8 = 1152921510103443696;               
            // 0x0142A508: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x0142A50C: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.ByteReader_Binding::<Register>m__0(int s);
            // 0x0142A510: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_16 = null;
            // 0x0142A514: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x0142A518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A51C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A520: MOV x2, x21                | X2 = 1152921510103443696 (0x10000001479F68F0);//ML01
            // 0x0142A524: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x0142A528: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ByteReader_Binding::<Register>m__0(int s));
            val_16 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ByteReader_Binding::<Register>m__0(int s));
            // 0x0142A52C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A530: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A534: STR x22, [x8, #0x40]       | ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504783474752
            ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__am$cache0 = val_16;
            // 0x0142A538: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A53C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A540: LDR x21, [x8, #0x40]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_30 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__am$cache0;
            label_31:
            // 0x0142A544: CBNZ x19, #0x142a54c       | if (X1 != 0) goto label_32;             
            if(X1 != 0)
            {
                goto label_32;
            }
            // 0x0142A548: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ByteReader_Binding::<Register>m__0(int s)), ????);
            label_32:
            // 0x0142A54C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A550: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142A554: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x0142A558: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x0142A55C: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_30);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_30);
            // 0x0142A560: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0142A564: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A568: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142A56C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0142A570: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A574: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142A578: ADRP x9, #0x3616000        | X9 = 56713216 (0x3616000);              
            // 0x0142A57C: LDR x8, [x24]              | X8 = typeof(System.Type);               
            // 0x0142A580: LDR x9, [x9, #0x888]       | X9 = 1152921504996170800;               
            // 0x0142A584: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A588: LDR x22, [x9]              | X22 = typeof(System.Byte[]);            
            // 0x0142A58C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142A590: TBZ w9, #0, #0x142a5a4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x0142A594: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142A598: CBNZ w9, #0x142a5a4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x0142A59C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142A5A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x0142A5A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142A5A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142A5AC: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142A5B0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_17 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142A5B4: MOV x22, x0                | X22 = val_17;//m1                       
            // 0x0142A5B8: CBNZ x21, #0x142a5c0       | if ( != null) goto label_35;            
            if(null != null)
            {
                goto label_35;
            }
            // 0x0142A5BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_35:
            // 0x0142A5C0: CBZ x22, #0x142a5e4        | if (val_17 == null) goto label_37;      
            if(val_17 == null)
            {
                goto label_37;
            }
            // 0x0142A5C4: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142A5C8: MOV x0, x22                | X0 = val_17;//m1                        
            // 0x0142A5CC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142A5D0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x0142A5D4: CBNZ x0, #0x142a5e4        | if (val_17 != null) goto label_37;      
            if(val_17 != null)
            {
                goto label_37;
            }
            // 0x0142A5D8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
            // 0x0142A5DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A5E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_37:
            // 0x0142A5E4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142A5E8: CBNZ w8, #0x142a5f8        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_38;
            // 0x0142A5EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
            // 0x0142A5F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A5F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_38:
            // 0x0142A5F8: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_17;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_17;
            // 0x0142A5FC: CBNZ x20, #0x142a604       | if (val_1 != null) goto label_39;       
            if(val_1 != null)
            {
                goto label_39;
            }
            // 0x0142A600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_39:
            // 0x0142A604: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142A608: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142A60C: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x0142A610: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142A614: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A618: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142A61C: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_18 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142A620: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A624: MOV x21, x0                | X21 = val_18;//m1                       
            // 0x0142A628: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A62C: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache6;
            val_31 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache6;
            // 0x0142A630: CBNZ x22, #0x142a67c       | if (ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache6 != null) goto label_40;
            if(val_31 != null)
            {
                goto label_40;
            }
            // 0x0142A634: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x0142A638: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142A63C: LDR x8, [x8, #0x3b8]       | X8 = 1152921510103452912;               
            // 0x0142A640: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142A644: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142A648: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_19 = null;
            // 0x0142A64C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142A650: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A654: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A658: MOV x2, x22                | X2 = 1152921510103452912 (0x10000001479F8CF0);//ML01
            // 0x0142A65C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_24 = val_19;
            // 0x0142A660: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_19 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142A664: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A668: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A66C: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783474736
            ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache6 = val_24;
            // 0x0142A670: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A674: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A678: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_31 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache6;
            label_40:
            // 0x0142A67C: CBNZ x19, #0x142a684       | if (X1 != 0) goto label_41;             
            if(X1 != 0)
            {
                goto label_41;
            }
            // 0x0142A680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_41:
            // 0x0142A684: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A688: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142A68C: MOV x1, x21                | X1 = val_18;//m1                        
            // 0x0142A690: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142A694: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_18, func:  val_31);
            X1.RegisterCLRMethodRedirection(mi:  val_18, func:  val_31);
            // 0x0142A698: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0142A69C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A6A0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142A6A4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0142A6A8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A6AC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142A6B0: ADRP x9, #0x360d000        | X9 = 56676352 (0x360D000);              
            // 0x0142A6B4: LDR x8, [x24]              | X8 = typeof(System.Type);               
            // 0x0142A6B8: LDR x9, [x9, #0xd08]       | X9 = 1152921504696995840;               
            // 0x0142A6BC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A6C0: LDR x22, [x9]              | X22 = typeof(UnityEngine.TextAsset);    
            // 0x0142A6C4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142A6C8: TBZ w9, #0, #0x142a6dc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_43;
            // 0x0142A6CC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142A6D0: CBNZ w9, #0x142a6dc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
            // 0x0142A6D4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142A6D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_43:
            // 0x0142A6DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142A6E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142A6E4: MOV x1, x22                | X1 = 1152921504696995840 (0x10000000055F9000);//ML01
            // 0x0142A6E8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_20 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142A6EC: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x0142A6F0: CBNZ x21, #0x142a6f8       | if ( != null) goto label_44;            
            if(null != null)
            {
                goto label_44;
            }
            // 0x0142A6F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_44:
            // 0x0142A6F8: CBZ x22, #0x142a71c        | if (val_20 == null) goto label_46;      
            if(val_20 == null)
            {
                goto label_46;
            }
            // 0x0142A6FC: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142A700: MOV x0, x22                | X0 = val_20;//m1                        
            // 0x0142A704: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142A708: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_20, ????);     
            // 0x0142A70C: CBNZ x0, #0x142a71c        | if (val_20 != null) goto label_46;      
            if(val_20 != null)
            {
                goto label_46;
            }
            // 0x0142A710: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_20, ????);     
            // 0x0142A714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A718: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_46:
            // 0x0142A71C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142A720: CBNZ w8, #0x142a730        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_47;
            // 0x0142A724: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_20, ????);     
            // 0x0142A728: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A72C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_47:
            // 0x0142A730: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_20;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_20;
            // 0x0142A734: CBNZ x20, #0x142a73c       | if (val_1 != null) goto label_48;       
            if(val_1 != null)
            {
                goto label_48;
            }
            // 0x0142A738: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_48:
            // 0x0142A73C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142A740: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142A744: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x0142A748: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142A74C: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142A750: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142A754: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_21 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142A758: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A75C: MOV x20, x0                | X20 = val_21;//m1                       
            // 0x0142A760: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A764: LDR x21, [x8, #0x38]       | X21 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache7;
            val_32 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache7;
            // 0x0142A768: CBNZ x21, #0x142a7b4       | if (ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache7 != null) goto label_49;
            if(val_32 != null)
            {
                goto label_49;
            }
            // 0x0142A76C: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x0142A770: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142A774: LDR x8, [x8, #0x7f8]       | X8 = 1152921510103462128;               
            // 0x0142A778: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142A77C: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142A780: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_22 = null;
            // 0x0142A784: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142A788: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A78C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A790: MOV x2, x21                | X2 = 1152921510103462128 (0x10000001479FB0F0);//ML01
            // 0x0142A794: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142A798: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_22 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142A79C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A7A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A7A4: STR x22, [x8, #0x38]       | ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783474744
            ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache7 = val_22;
            // 0x0142A7A8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.ByteReader_Binding);
            // 0x0142A7AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ByteReader_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142A7B0: LDR x21, [x8, #0x38]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_32 = ILRuntime.Runtime.Generated.ByteReader_Binding.<>f__mg$cache7;
            label_49:
            // 0x0142A7B4: CBNZ x19, #0x142a7bc       | if (X1 != 0) goto label_50;             
            if(X1 != 0)
            {
                goto label_50;
            }
            // 0x0142A7B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ByteReader_Binding::Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_50:
            // 0x0142A7BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142A7C0: MOV x1, x20                | X1 = val_21;//m1                        
            // 0x0142A7C4: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142A7C8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0142A7CC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0142A7D0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0142A7D4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0142A7D8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0142A7DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A7E0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0142A7E4: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_21, func:  val_32); return;
            X1.RegisterCLRMethodRedirection(mi:  val_21, func:  val_32);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0142A7E8 (21145576), len: 876  VirtAddr: 0x0142A7E8 RVA: 0x0142A7E8 token: 100664113 methodIndex: 30158 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Open_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x0142A7E8: STP x24, x23, [sp, #-0x40]! | stack[1152921510103677200] = ???;  stack[1152921510103677208] = ???;  //  dest_result_addr=1152921510103677200 |  dest_result_addr=1152921510103677208
            // 0x0142A7EC: STP x22, x21, [sp, #0x10]  | stack[1152921510103677216] = ???;  stack[1152921510103677224] = ???;  //  dest_result_addr=1152921510103677216 |  dest_result_addr=1152921510103677224
            // 0x0142A7F0: STP x20, x19, [sp, #0x20]  | stack[1152921510103677232] = ???;  stack[1152921510103677240] = ???;  //  dest_result_addr=1152921510103677232 |  dest_result_addr=1152921510103677240
            // 0x0142A7F4: STP x29, x30, [sp, #0x30]  | stack[1152921510103677248] = ???;  stack[1152921510103677256] = ???;  //  dest_result_addr=1152921510103677248 |  dest_result_addr=1152921510103677256
            // 0x0142A7F8: ADD x29, sp, #0x30         | X29 = (1152921510103677200 + 48) = 1152921510103677248 (0x1000000147A2F940);
            // 0x0142A7FC: SUB sp, sp, #0x20          | SP = (1152921510103677200 - 32) = 1152921510103677168 (0x1000000147A2F8F0);
            // 0x0142A800: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142A804: LDRB w8, [x20, #0x12]      | W8 = (bool)static_value_03737012;       
            // 0x0142A808: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142A80C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142A810: MOV x21, x1                | X21 = X1;//m1                           
            val_13 = X1;
            // 0x0142A814: TBNZ w8, #0, #0x142a830    | if (static_value_03737012 == true) goto label_0;
            // 0x0142A818: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x0142A81C: LDR x8, [x8, #0x208]       | X8 = 0x2B8FFD8;                         
            // 0x0142A820: LDR w0, [x8]               | W0 = 0x16BA;                            
            // 0x0142A824: BL #0x2782188              | X0 = sub_2782188( ?? 0x16BA, ????);     
            // 0x0142A828: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142A82C: STRB w8, [x20, #0x12]      | static_value_03737012 = true;            //  dest_result_addr=57896978
            label_0:
            // 0x0142A830: CBNZ x21, #0x142a838       | if (X1 != 0) goto label_1;              
            if(val_13 != 0)
            {
                goto label_1;
            }
            // 0x0142A834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16BA, ????);     
            label_1:
            // 0x0142A838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A83C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142A840: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_13.AppDomain;
            // 0x0142A844: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142A848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142A84C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A850: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142A854: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142A858: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142A85C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142A860: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142A864: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A868: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142A86C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142A870: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142A874: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142A878: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142A87C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x0142A880: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0142A884: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142A888: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x0142A88C: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x0142A890: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142A894: TBZ w9, #0, #0x142a8a8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142A898: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142A89C: CBNZ w9, #0x142a8a8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142A8A0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142A8A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142A8A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142A8AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142A8B0: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0142A8B4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142A8B8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142A8BC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142A8C0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142A8C4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142A8C8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142A8CC: TBZ w9, #0, #0x142a8e0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142A8D0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142A8D4: CBNZ w9, #0x142a8e0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142A8D8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142A8DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142A8E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142A8E4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142A8E8: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142A8EC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142A8F0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142A8F4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x0142A8F8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142A8FC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142A900: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x0142A904: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142A908: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142A90C: TBZ w9, #0, #0x142a920     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142A910: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142A914: CBNZ w9, #0x142a920        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142A918: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142A91C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142A920: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142A924: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142A928: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142A92C: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x0142A930: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142A934: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x0142A938: CBZ x0, #0x142a980         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0142A93C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0142A940: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0142A944: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142A948: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142A94C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0142A950: MOV x23, x0                | X23 = val_6;//m1                        
            val_14 = val_6;
            // 0x0142A954: B.EQ #0x142a980            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x0142A958: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142A95C: ADD x8, sp, #8             | X8 = (1152921510103677168 + 8) = 1152921510103677176 (0x1000000147A2F8F8);
            // 0x0142A960: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142A964: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510103665264]
            // 0x0142A968: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0142A96C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142A970: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0142A974: ADD x0, sp, #8             | X0 = (1152921510103677168 + 8) = 1152921510103677176 (0x1000000147A2F8F8);
            // 0x0142A978: BL #0x299a140              | 
            // 0x0142A97C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_9:
            // 0x0142A980: CBNZ x21, #0x142a988       | if (X1 != 0) goto label_10;             
            if(val_13 != 0)
            {
                goto label_10;
            }
            // 0x0142A984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147A2F8F8, ????);
            label_10:
            // 0x0142A988: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142A98C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142A990: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142A994: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_13.Free(esp:  null);
            // 0x0142A998: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x0142A99C: LDR x8, [x8, #0x30]        | X8 = 1152921504876068864;               
            // 0x0142A9A0: LDR x0, [x8]               | X0 = typeof(ByteReader);                
            // 0x0142A9A4: LDRB w8, [x0, #0x10a]      | W8 = ByteReader.__il2cppRuntimeField_10A;
            // 0x0142A9A8: TBZ w8, #0, #0x142a9b8     | if (ByteReader.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x0142A9AC: LDR w8, [x0, #0xbc]        | W8 = ByteReader.__il2cppRuntimeField_cctor_finished;
            // 0x0142A9B0: CBNZ w8, #0x142a9b8        | if (ByteReader.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x0142A9B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReader), ????);
            label_12:
            // 0x0142A9B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142A9BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142A9C0: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0142A9C4: BL #0xba4360               | X0 = ByteReader.Open(path:  0);         
            ByteReader val_8 = ByteReader.Open(path:  0);
            // 0x0142A9C8: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x0142A9CC: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_15 = 1152921504824418304;
            // 0x0142A9D0: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0142A9D4: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_16 = null;
            // 0x0142A9D8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x0142A9DC: CBZ x0, #0x142aa70         | if (val_8 == null) goto label_13;       
            if(val_8 == null)
            {
                goto label_13;
            }
            // 0x0142A9E0: CBZ x22, #0x142aa88        | if (val_8 == null) goto label_14;       
            if(val_8 == null)
            {
                goto label_14;
            }
            // 0x0142A9E4: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x0142A9E8: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x0142A9EC: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142A9F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x0142A9F4: CBNZ x0, #0x142aa28        | if (val_8 != null) goto label_15;       
            if(val_8 != null)
            {
                goto label_15;
            }
            // 0x0142A9F8: LDR x8, [x22]              | X8 = typeof(ByteReader);                
            // 0x0142A9FC: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142AA00: LDR x0, [x8, #0x30]        | X0 = ByteReader.__il2cppRuntimeField_element_class;
            // 0x0142AA04: ADD x8, sp, #0x10          | X8 = (1152921510103677168 + 16) = 1152921510103677184 (0x1000000147A2F900);
            // 0x0142AA08: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ByteReader.__il2cppRuntimeField_element_class, ????);
            // 0x0142AA0C: LDR x0, [sp, #0x10]        | X0 = val_9;                              //  find_add[1152921510103665264]
            // 0x0142AA10: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x0142AA14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142AA18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x0142AA1C: ADD x0, sp, #0x10          | X0 = (1152921510103677168 + 16) = 1152921510103677184 (0x1000000147A2F900);
            // 0x0142AA20: BL #0x299a140              | 
            // 0x0142AA24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147A2F900, ????);
            label_15:
            // 0x0142AA28: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_13 = null;
            // 0x0142AA2C: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x0142AA30: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_16 = val_13;
            // 0x0142AA34: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x0142AA38: MOV x23, x0                | X23 = val_8;//m1                        
            val_15 = val_8;
            // 0x0142AA3C: CBNZ x23, #0x142aa94       | if (val_8 != null) goto label_16;       
            if(val_15 != null)
            {
                goto label_16;
            }
            // 0x0142AA40: LDR x8, [x22]              | X8 = typeof(ByteReader);                
            // 0x0142AA44: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142AA48: LDR x0, [x8, #0x30]        | X0 = ByteReader.__il2cppRuntimeField_element_class;
            // 0x0142AA4C: ADD x8, sp, #0x18          | X8 = (1152921510103677168 + 24) = 1152921510103677192 (0x1000000147A2F908);
            // 0x0142AA50: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ByteReader.__il2cppRuntimeField_element_class, ????);
            // 0x0142AA54: LDR x0, [sp, #0x18]        | X0 = val_10;                             //  find_add[1152921510103665264]
            // 0x0142AA58: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x0142AA5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_16 = 0;
            // 0x0142AA60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x0142AA64: ADD x0, sp, #0x18          | X0 = (1152921510103677168 + 24) = 1152921510103677192 (0x1000000147A2F908);
            // 0x0142AA68: BL #0x299a140              | 
            // 0x0142AA6C: B #0x142aa90               |  goto label_17;                         
            goto label_17;
            label_13:
            // 0x0142AA70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AA74: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142AA78: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142AA7C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142AA80: MOV x3, x22                | X3 = val_8;//m1                         
            // 0x0142AA84: B #0x142ab08               |  goto label_18;                         
            goto label_18;
            label_14:
            // 0x0142AA88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            // 0x0142AA8C: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_13 = null;
            label_17:
            // 0x0142AA90: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_16:
            // 0x0142AA94: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x0142AA98: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x0142AA9C: CBZ x9, #0x142aac8         | if (mem[282584257676929] == 0) goto label_19;
            if(mem[282584257676929] == 0)
            {
                goto label_19;
            }
            // 0x0142AAA0: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_12 = mem[282584257676823];
            // 0x0142AAA4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x0142AAA8: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_12 = val_12 + 8;
            label_21:
            // 0x0142AAAC: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x0142AAB0: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x0142AAB4: B.EQ #0x142aadc            | if ((mem[282584257676823] + 8) + -8 == val_13) goto label_20;
            if(((mem[282584257676823] + 8) + -8) == val_13)
            {
                goto label_20;
            }
            // 0x0142AAB8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x0142AABC: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_12 = val_12 + 16;
            // 0x0142AAC0: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x0142AAC4: B.LO #0x142aaac            | if (0 < mem[282584257676929]) goto label_21;
            if(val_13 < mem[282584257676929])
            {
                goto label_21;
            }
            label_19:
            // 0x0142AAC8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0142AACC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_17 = val_15;
            // 0x0142AAD0: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_16 = val_13;
            // 0x0142AAD4: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x0142AAD8: B #0x142aae8               |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x0142AADC: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x0142AAE0: ADD x8, x8, x9, lsl #4     | X8 = (val_15 + ((mem[282584257676823] + 8)) << 4);
            val_15 = val_15 + (((mem[282584257676823] + 8)) << 4);
            // 0x0142AAE4: ADD x0, x8, #0x110         | X0 = ((val_15 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_17 = val_15 + 272;
            label_22:
            // 0x0142AAE8: LDP x8, x1, [x0]           | X8 = ((val_15 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_15 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x0142AAEC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0142AAF0: BLR x8                     | X0 = ((val_15 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x0142AAF4: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x0142AAF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AAFC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142AB00: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142AB04: MOV x2, x19                | X2 = X3;//m1                            
            label_18:
            // 0x0142AB08: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142AB0C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_11 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x0142AB10: SUB sp, x29, #0x30         | SP = (1152921510103677248 - 48) = 1152921510103677200 (0x1000000147A2F910);
            // 0x0142AB14: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0142AB18: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0142AB1C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0142AB20: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0142AB24: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_11;
            return val_11;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142AB28: MOV x19, x0                | 
            // 0x0142AB2C: ADD x0, sp, #8             | 
            // 0x0142AB30: B #0x142ab48               | 
            // 0x0142AB34: MOV x19, x0                | 
            // 0x0142AB38: ADD x0, sp, #0x10          | 
            // 0x0142AB3C: B #0x142ab48               | 
            // 0x0142AB40: MOV x19, x0                | 
            // 0x0142AB44: ADD x0, sp, #0x18          | 
            label_24:
            // 0x0142AB48: BL #0x299a140              | 
            // 0x0142AB4C: MOV x0, x19                | 
            // 0x0142AB50: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142AB54 (21146452), len: 612  VirtAddr: 0x0142AB54 RVA: 0x0142AB54 token: 100664114 methodIndex: 30159 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_canRead_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x0142AB54: STP x26, x25, [sp, #-0x50]! | stack[1152921510103850624] = ???;  stack[1152921510103850632] = ???;  //  dest_result_addr=1152921510103850624 |  dest_result_addr=1152921510103850632
            // 0x0142AB58: STP x24, x23, [sp, #0x10]  | stack[1152921510103850640] = ???;  stack[1152921510103850648] = ???;  //  dest_result_addr=1152921510103850640 |  dest_result_addr=1152921510103850648
            // 0x0142AB5C: STP x22, x21, [sp, #0x20]  | stack[1152921510103850656] = ???;  stack[1152921510103850664] = ???;  //  dest_result_addr=1152921510103850656 |  dest_result_addr=1152921510103850664
            // 0x0142AB60: STP x20, x19, [sp, #0x30]  | stack[1152921510103850672] = ???;  stack[1152921510103850680] = ???;  //  dest_result_addr=1152921510103850672 |  dest_result_addr=1152921510103850680
            // 0x0142AB64: STP x29, x30, [sp, #0x40]  | stack[1152921510103850688] = ???;  stack[1152921510103850696] = ???;  //  dest_result_addr=1152921510103850688 |  dest_result_addr=1152921510103850696
            // 0x0142AB68: ADD x29, sp, #0x40         | X29 = (1152921510103850624 + 64) = 1152921510103850688 (0x1000000147A59EC0);
            // 0x0142AB6C: SUB sp, sp, #0x10          | SP = (1152921510103850624 - 16) = 1152921510103850608 (0x1000000147A59E70);
            // 0x0142AB70: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x0142AB74: LDRB w8, [x19, #0x13]      | W8 = (bool)static_value_03737013;       
            // 0x0142AB78: MOV x22, x3                | X22 = X3;//m1                           
            // 0x0142AB7C: MOV x21, x2                | X21 = X2;//m1                           
            // 0x0142AB80: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142AB84: TBNZ w8, #0, #0x142aba0    | if (static_value_03737013 == true) goto label_0;
            // 0x0142AB88: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x0142AB8C: LDR x8, [x8, #0x418]       | X8 = 0x2B8FFD4;                         
            // 0x0142AB90: LDR w0, [x8]               | W0 = 0x16B9;                            
            // 0x0142AB94: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B9, ????);     
            // 0x0142AB98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142AB9C: STRB w8, [x19, #0x13]      | static_value_03737013 = true;            //  dest_result_addr=57896979
            label_0:
            // 0x0142ABA0: CBNZ x20, #0x142aba8       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142ABA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16B9, ????);     
            label_1:
            // 0x0142ABA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142ABAC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142ABB0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142ABB4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142ABB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142ABBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142ABC0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142ABC4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x0142ABC8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142ABCC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x0142ABD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142ABD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142ABD8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142ABDC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x0142ABE0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142ABE4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142ABE8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142ABEC: ADRP x9, #0x364e000        | X9 = 56942592 (0x364E000);              
            // 0x0142ABF0: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x0142ABF4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142ABF8: LDR x9, [x9, #0x400]       | X9 = 1152921504876068864;               
            // 0x0142ABFC: LDR x24, [x9]              | X24 = typeof(ByteReader);               
            // 0x0142AC00: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142AC04: TBZ w9, #0, #0x142ac18     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142AC08: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142AC0C: CBNZ w9, #0x142ac18        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142AC10: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142AC14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142AC18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AC1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142AC20: MOV x1, x24                | X1 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x0142AC24: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142AC28: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x0142AC2C: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x0142AC30: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142AC34: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142AC38: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142AC3C: TBZ w9, #0, #0x142ac50     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142AC40: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142AC44: CBNZ w9, #0x142ac50        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142AC48: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142AC4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142AC50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AC54: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142AC58: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x0142AC5C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142AC60: MOV x3, x22                | X3 = X3;//m1                            
            // 0x0142AC64: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142AC68: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142AC6C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142AC70: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x0142AC74: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142AC78: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142AC7C: TBZ w9, #0, #0x142ac90     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142AC80: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142AC84: CBNZ w9, #0x142ac90        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142AC88: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142AC8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142AC90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AC94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142AC98: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142AC9C: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x0142ACA0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142ACA4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x0142ACA8: CBZ x0, #0x142ad0c         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x0142ACAC: ADRP x9, #0x3636000        | X9 = 56844288 (0x3636000);              
            // 0x0142ACB0: LDR x9, [x9, #0x30]        | X9 = 1152921504876068864;               
            // 0x0142ACB4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142ACB8: LDR x1, [x9]               | X1 = typeof(ByteReader);                
            // 0x0142ACBC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142ACC0: LDRB w9, [x1, #0x104]      | W9 = ByteReader.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142ACC4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ByteReader.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142ACC8: B.LO #0x142ace4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ByteReader.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x0142ACCC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142ACD0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierar
            // 0x0142ACD4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142ACD8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ByteReader))
            // 0x0142ACDC: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x0142ACE0: B.EQ #0x142ad0c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x0142ACE4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142ACE8: ADD x8, sp, #8             | X8 = (1152921510103850608 + 8) = 1152921510103850616 (0x1000000147A59E78);
            // 0x0142ACEC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142ACF0: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510103838704]
            // 0x0142ACF4: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0142ACF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142ACFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x0142AD00: ADD x0, sp, #8             | X0 = (1152921510103850608 + 8) = 1152921510103850616 (0x1000000147A59E78);
            // 0x0142AD04: BL #0x299a140              | 
            // 0x0142AD08: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x0142AD0C: CBNZ x20, #0x142ad14       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x0142AD10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147A59E78, ????);
            label_11:
            // 0x0142AD14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142AD18: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142AD1C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x0142AD20: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142AD24: CBNZ x22, #0x142ad2c       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x0142AD28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x0142AD2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142AD30: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x0142AD34: BL #0xba4490               | X0 = val_13.get_canRead();              
            bool val_9 = val_13.canRead;
            // 0x0142AD38: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x0142AD3C: CBZ x19, #0x142ad50        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x0142AD40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142AD44: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x0142AD48: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x0142AD4C: B #0x142ad64               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x0142AD50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x0142AD54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142AD58: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x0142AD5C: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x0142AD60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x0142AD64: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x0142AD68: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142AD6C: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x0142AD70: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x0142AD74: TBZ w9, #0, #0x142ad84     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x0142AD78: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x0142AD7C: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x0142AD80: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x0142AD84: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x0142AD88: SUB sp, x29, #0x40         | SP = (1152921510103850688 - 64) = 1152921510103850624 (0x1000000147A59E80);
            // 0x0142AD8C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142AD90: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142AD94: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142AD98: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142AD9C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142ADA0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142ADA4: MOV x19, x0                | 
            // 0x0142ADA8: ADD x0, sp, #8             | 
            // 0x0142ADAC: BL #0x299a140              | 
            // 0x0142ADB0: MOV x0, x19                | 
            // 0x0142ADB4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142ADB8 (21147064), len: 552  VirtAddr: 0x0142ADB8 RVA: 0x0142ADB8 token: 100664115 methodIndex: 30160 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ReadLine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            // 0x0142ADB8: STP x24, x23, [sp, #-0x40]! | stack[1152921510104024080] = ???;  stack[1152921510104024088] = ???;  //  dest_result_addr=1152921510104024080 |  dest_result_addr=1152921510104024088
            // 0x0142ADBC: STP x22, x21, [sp, #0x10]  | stack[1152921510104024096] = ???;  stack[1152921510104024104] = ???;  //  dest_result_addr=1152921510104024096 |  dest_result_addr=1152921510104024104
            // 0x0142ADC0: STP x20, x19, [sp, #0x20]  | stack[1152921510104024112] = ???;  stack[1152921510104024120] = ???;  //  dest_result_addr=1152921510104024112 |  dest_result_addr=1152921510104024120
            // 0x0142ADC4: STP x29, x30, [sp, #0x30]  | stack[1152921510104024128] = ???;  stack[1152921510104024136] = ???;  //  dest_result_addr=1152921510104024128 |  dest_result_addr=1152921510104024136
            // 0x0142ADC8: ADD x29, sp, #0x30         | X29 = (1152921510104024080 + 48) = 1152921510104024128 (0x1000000147A84440);
            // 0x0142ADCC: SUB sp, sp, #0x10          | SP = (1152921510104024080 - 16) = 1152921510104024064 (0x1000000147A84400);
            // 0x0142ADD0: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142ADD4: LDRB w8, [x21, #0x14]      | W8 = (bool)static_value_03737014;       
            // 0x0142ADD8: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142ADDC: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142ADE0: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142ADE4: TBNZ w8, #0, #0x142ae00    | if (static_value_03737014 == true) goto label_0;
            // 0x0142ADE8: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x0142ADEC: LDR x8, [x8, #0x7d0]       | X8 = 0x2B8FFE4;                         
            // 0x0142ADF0: LDR w0, [x8]               | W0 = 0x16BD;                            
            // 0x0142ADF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x16BD, ????);     
            // 0x0142ADF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142ADFC: STRB w8, [x21, #0x14]      | static_value_03737014 = true;            //  dest_result_addr=57896980
            label_0:
            // 0x0142AE00: CBNZ x20, #0x142ae08       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142AE04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16BD, ????);     
            label_1:
            // 0x0142AE08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142AE0C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142AE10: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142AE14: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142AE18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AE1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142AE20: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142AE24: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142AE28: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142AE2C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0142AE30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AE34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142AE38: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142AE3C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142AE40: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142AE44: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142AE48: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142AE4C: ADRP x9, #0x364e000        | X9 = 56942592 (0x364E000);              
            // 0x0142AE50: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0142AE54: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142AE58: LDR x9, [x9, #0x400]       | X9 = 1152921504876068864;               
            // 0x0142AE5C: LDR x24, [x9]              | X24 = typeof(ByteReader);               
            // 0x0142AE60: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142AE64: TBZ w9, #0, #0x142ae78     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142AE68: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142AE6C: CBNZ w9, #0x142ae78        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142AE70: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142AE74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142AE78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AE7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142AE80: MOV x1, x24                | X1 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x0142AE84: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142AE88: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142AE8C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142AE90: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142AE94: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142AE98: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142AE9C: TBZ w9, #0, #0x142aeb0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142AEA0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142AEA4: CBNZ w9, #0x142aeb0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142AEA8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142AEAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142AEB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AEB4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142AEB8: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142AEBC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142AEC0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142AEC4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142AEC8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142AECC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142AED0: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x0142AED4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142AED8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142AEDC: TBZ w9, #0, #0x142aef0     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142AEE0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142AEE4: CBNZ w9, #0x142aef0        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142AEE8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142AEEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142AEF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AEF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142AEF8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142AEFC: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x0142AF00: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142AF04: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x0142AF08: CBZ x0, #0x142af6c         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x0142AF0C: ADRP x9, #0x3636000        | X9 = 56844288 (0x3636000);              
            // 0x0142AF10: LDR x9, [x9, #0x30]        | X9 = 1152921504876068864;               
            // 0x0142AF14: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142AF18: LDR x1, [x9]               | X1 = typeof(ByteReader);                
            // 0x0142AF1C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142AF20: LDRB w9, [x1, #0x104]      | W9 = ByteReader.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142AF24: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ByteReader.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142AF28: B.LO #0x142af44            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ByteReader.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x0142AF2C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142AF30: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierar
            // 0x0142AF34: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142AF38: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ByteReader))
            // 0x0142AF3C: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x0142AF40: B.EQ #0x142af6c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x0142AF44: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142AF48: ADD x8, sp, #8             | X8 = (1152921510104024064 + 8) = 1152921510104024072 (0x1000000147A84408);
            // 0x0142AF4C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142AF50: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510104012144]
            // 0x0142AF54: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0142AF58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142AF5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x0142AF60: ADD x0, sp, #8             | X0 = (1152921510104024064 + 8) = 1152921510104024072 (0x1000000147A84408);
            // 0x0142AF64: BL #0x299a140              | 
            // 0x0142AF68: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x0142AF6C: CBNZ x20, #0x142af74       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x0142AF70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147A84408, ????);
            label_11:
            // 0x0142AF74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142AF78: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142AF7C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142AF80: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142AF84: CBNZ x23, #0x142af8c       | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x0142AF88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x0142AF8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142AF90: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0142AF94: BL #0xba4558               | X0 = val_11.ReadLine();                 
            string val_9 = val_11.ReadLine();
            // 0x0142AF98: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x0142AF9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142AFA0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142AFA4: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0142AFA8: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142AFAC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142AFB0: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0142AFB4: SUB sp, x29, #0x30         | SP = (1152921510104024128 - 48) = 1152921510104024080 (0x1000000147A84410);
            // 0x0142AFB8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0142AFBC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0142AFC0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0142AFC4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0142AFC8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142AFCC: MOV x19, x0                | 
            // 0x0142AFD0: ADD x0, sp, #8             | 
            // 0x0142AFD4: BL #0x299a140              | 
            // 0x0142AFD8: MOV x0, x19                | 
            // 0x0142AFDC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142AFE0 (21147616), len: 604  VirtAddr: 0x0142AFE0 RVA: 0x0142AFE0 token: 100664116 methodIndex: 30161 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ReadLine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_13;
            // 0x0142AFE0: STP x26, x25, [sp, #-0x50]! | stack[1152921510104201600] = ???;  stack[1152921510104201608] = ???;  //  dest_result_addr=1152921510104201600 |  dest_result_addr=1152921510104201608
            // 0x0142AFE4: STP x24, x23, [sp, #0x10]  | stack[1152921510104201616] = ???;  stack[1152921510104201624] = ???;  //  dest_result_addr=1152921510104201616 |  dest_result_addr=1152921510104201624
            // 0x0142AFE8: STP x22, x21, [sp, #0x20]  | stack[1152921510104201632] = ???;  stack[1152921510104201640] = ???;  //  dest_result_addr=1152921510104201632 |  dest_result_addr=1152921510104201640
            // 0x0142AFEC: STP x20, x19, [sp, #0x30]  | stack[1152921510104201648] = ???;  stack[1152921510104201656] = ???;  //  dest_result_addr=1152921510104201648 |  dest_result_addr=1152921510104201656
            // 0x0142AFF0: STP x29, x30, [sp, #0x40]  | stack[1152921510104201664] = ???;  stack[1152921510104201672] = ???;  //  dest_result_addr=1152921510104201664 |  dest_result_addr=1152921510104201672
            // 0x0142AFF4: ADD x29, sp, #0x40         | X29 = (1152921510104201600 + 64) = 1152921510104201664 (0x1000000147AAF9C0);
            // 0x0142AFF8: SUB sp, sp, #0x10          | SP = (1152921510104201600 - 16) = 1152921510104201584 (0x1000000147AAF970);
            // 0x0142AFFC: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142B000: LDRB w8, [x21, #0x15]      | W8 = (bool)static_value_03737015;       
            // 0x0142B004: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142B008: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142B00C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142B010: TBNZ w8, #0, #0x142b02c    | if (static_value_03737015 == true) goto label_0;
            // 0x0142B014: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x0142B018: LDR x8, [x8, #0xec8]       | X8 = 0x2B8FFE8;                         
            // 0x0142B01C: LDR w0, [x8]               | W0 = 0x16BE;                            
            // 0x0142B020: BL #0x2782188              | X0 = sub_2782188( ?? 0x16BE, ????);     
            // 0x0142B024: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142B028: STRB w8, [x21, #0x15]      | static_value_03737015 = true;            //  dest_result_addr=57896981
            label_0:
            // 0x0142B02C: CBNZ x20, #0x142b034       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142B030: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16BE, ????);     
            label_1:
            // 0x0142B034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B038: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142B03C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142B040: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142B044: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B048: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B04C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142B050: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142B054: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142B058: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0142B05C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B060: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B064: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142B068: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142B06C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142B070: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x0142B074: CBNZ x24, #0x142b07c       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x0142B078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x0142B07C: LDR w25, [x24, #4]         | W25 = val_3 + 4;                        
            // 0x0142B080: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B084: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B088: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142B08C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142B090: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142B094: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142B098: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142B09C: ADRP x9, #0x364e000        | X9 = 56942592 (0x364E000);              
            // 0x0142B0A0: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x0142B0A4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142B0A8: LDR x9, [x9, #0x400]       | X9 = 1152921504876068864;               
            // 0x0142B0AC: LDR x24, [x9]              | X24 = typeof(ByteReader);               
            // 0x0142B0B0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142B0B4: TBZ w9, #0, #0x142b0c8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x0142B0B8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142B0BC: CBNZ w9, #0x142b0c8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x0142B0C0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142B0C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x0142B0C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B0CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142B0D0: MOV x1, x24                | X1 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x0142B0D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142B0D8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142B0DC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142B0E0: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x0142B0E4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142B0E8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142B0EC: TBZ w9, #0, #0x142b100     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x0142B0F0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142B0F4: CBNZ w9, #0x142b100        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x0142B0F8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142B0FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x0142B100: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B104: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142B108: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x0142B10C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142B110: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142B114: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142B118: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142B11C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142B120: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x0142B124: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142B128: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142B12C: TBZ w9, #0, #0x142b140     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x0142B130: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142B134: CBNZ w9, #0x142b140        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0142B138: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142B13C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x0142B140: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B144: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B148: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x0142B14C: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x0142B150: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x0142B154: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x0142B158: CBZ x0, #0x142b1bc         | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x0142B15C: ADRP x9, #0x3636000        | X9 = 56844288 (0x3636000);              
            // 0x0142B160: LDR x9, [x9, #0x30]        | X9 = 1152921504876068864;               
            // 0x0142B164: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142B168: LDR x1, [x9]               | X1 = typeof(ByteReader);                
            // 0x0142B16C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142B170: LDRB w9, [x1, #0x104]      | W9 = ByteReader.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142B174: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ByteReader.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142B178: B.LO #0x142b194            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ByteReader.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x0142B17C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142B180: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierar
            // 0x0142B184: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142B188: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ByteReader))
            // 0x0142B18C: MOV x23, x0                | X23 = val_7;//m1                        
            val_13 = val_7;
            // 0x0142B190: B.EQ #0x142b1bc            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x0142B194: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142B198: ADD x8, sp, #8             | X8 = (1152921510104201584 + 8) = 1152921510104201592 (0x1000000147AAF978);
            // 0x0142B19C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142B1A0: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510104189680]
            // 0x0142B1A4: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x0142B1A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B1AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x0142B1B0: ADD x0, sp, #8             | X0 = (1152921510104201584 + 8) = 1152921510104201592 (0x1000000147AAF978);
            // 0x0142B1B4: BL #0x299a140              | 
            // 0x0142B1B8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_11:
            // 0x0142B1BC: CBNZ x20, #0x142b1c4       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x0142B1C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147AAF978, ????);
            label_12:
            // 0x0142B1C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142B1C8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142B1CC: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x0142B1D0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142B1D4: CBNZ x23, #0x142b1dc       | if (0x0 != 0) goto label_13;            
            if(val_13 != 0)
            {
                goto label_13;
            }
            // 0x0142B1D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x0142B1DC: CMP w25, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x0142B1E0: CSET w1, eq                | W1 = val_3 + 4 == 0x1 ? 1 : 0;          
            bool val_10 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x0142B1E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142B1E8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0142B1EC: BL #0xba4560               | X0 = val_13.ReadLine(skipEmptyLines:  bool val_10 = ((val_3 + 4) == 1) ? 1 : 0);
            string val_11 = val_13.ReadLine(skipEmptyLines:  val_10);
            // 0x0142B1F0: MOV x3, x0                 | X3 = val_11;//m1                        
            // 0x0142B1F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B1F8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142B1FC: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0142B200: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142B204: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142B208: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0142B20C: SUB sp, x29, #0x40         | SP = (1152921510104201664 - 64) = 1152921510104201600 (0x1000000147AAF980);
            // 0x0142B210: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142B214: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142B218: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142B21C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142B220: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142B224: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_12;
            return val_12;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142B228: MOV x19, x0                | 
            // 0x0142B22C: ADD x0, sp, #8             | 
            // 0x0142B230: BL #0x299a140              | 
            // 0x0142B234: MOV x0, x19                | 
            // 0x0142B238: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142B23C (21148220), len: 876  VirtAddr: 0x0142B23C RVA: 0x0142B23C token: 100664117 methodIndex: 30162 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ReadDictionary_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            // 0x0142B23C: STP x24, x23, [sp, #-0x40]! | stack[1152921510104379152] = ???;  stack[1152921510104379160] = ???;  //  dest_result_addr=1152921510104379152 |  dest_result_addr=1152921510104379160
            // 0x0142B240: STP x22, x21, [sp, #0x10]  | stack[1152921510104379168] = ???;  stack[1152921510104379176] = ???;  //  dest_result_addr=1152921510104379168 |  dest_result_addr=1152921510104379176
            // 0x0142B244: STP x20, x19, [sp, #0x20]  | stack[1152921510104379184] = ???;  stack[1152921510104379192] = ???;  //  dest_result_addr=1152921510104379184 |  dest_result_addr=1152921510104379192
            // 0x0142B248: STP x29, x30, [sp, #0x30]  | stack[1152921510104379200] = ???;  stack[1152921510104379208] = ???;  //  dest_result_addr=1152921510104379200 |  dest_result_addr=1152921510104379208
            // 0x0142B24C: ADD x29, sp, #0x30         | X29 = (1152921510104379152 + 48) = 1152921510104379200 (0x1000000147ADAF40);
            // 0x0142B250: SUB sp, sp, #0x20          | SP = (1152921510104379152 - 32) = 1152921510104379120 (0x1000000147ADAEF0);
            // 0x0142B254: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142B258: LDRB w8, [x20, #0x16]      | W8 = (bool)static_value_03737016;       
            // 0x0142B25C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142B260: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142B264: MOV x21, x1                | X21 = X1;//m1                           
            val_14 = X1;
            // 0x0142B268: TBNZ w8, #0, #0x142b284    | if (static_value_03737016 == true) goto label_0;
            // 0x0142B26C: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x0142B270: LDR x8, [x8, #0xe60]       | X8 = 0x2B8FFE0;                         
            // 0x0142B274: LDR w0, [x8]               | W0 = 0x16BC;                            
            // 0x0142B278: BL #0x2782188              | X0 = sub_2782188( ?? 0x16BC, ????);     
            // 0x0142B27C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142B280: STRB w8, [x20, #0x16]      | static_value_03737016 = true;            //  dest_result_addr=57896982
            label_0:
            // 0x0142B284: CBNZ x21, #0x142b28c       | if (X1 != 0) goto label_1;              
            if(val_14 != 0)
            {
                goto label_1;
            }
            // 0x0142B288: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16BC, ????);     
            label_1:
            // 0x0142B28C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B290: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142B294: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_14.AppDomain;
            // 0x0142B298: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142B29C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B2A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B2A4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142B2A8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142B2AC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142B2B0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142B2B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B2B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B2BC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142B2C0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142B2C4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142B2C8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142B2CC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142B2D0: ADRP x9, #0x364e000        | X9 = 56942592 (0x364E000);              
            // 0x0142B2D4: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0142B2D8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142B2DC: LDR x9, [x9, #0x400]       | X9 = 1152921504876068864;               
            // 0x0142B2E0: LDR x24, [x9]              | X24 = typeof(ByteReader);               
            // 0x0142B2E4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142B2E8: TBZ w9, #0, #0x142b2fc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142B2EC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142B2F0: CBNZ w9, #0x142b2fc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142B2F4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142B2F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142B2FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B300: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142B304: MOV x1, x24                | X1 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x0142B308: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142B30C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142B310: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142B314: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142B318: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142B31C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142B320: TBZ w9, #0, #0x142b334     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142B324: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142B328: CBNZ w9, #0x142b334        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142B32C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142B330: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142B334: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B338: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142B33C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142B340: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142B344: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142B348: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x0142B34C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142B350: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142B354: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x0142B358: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142B35C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142B360: TBZ w9, #0, #0x142b374     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142B364: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142B368: CBNZ w9, #0x142b374        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142B36C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142B370: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142B374: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B378: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B37C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142B380: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x0142B384: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142B388: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x0142B38C: CBZ x0, #0x142b3f0         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x0142B390: ADRP x9, #0x3636000        | X9 = 56844288 (0x3636000);              
            // 0x0142B394: LDR x9, [x9, #0x30]        | X9 = 1152921504876068864;               
            // 0x0142B398: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142B39C: LDR x1, [x9]               | X1 = typeof(ByteReader);                
            // 0x0142B3A0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142B3A4: LDRB w9, [x1, #0x104]      | W9 = ByteReader.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142B3A8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ByteReader.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142B3AC: B.LO #0x142b3c8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ByteReader.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x0142B3B0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142B3B4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierar
            // 0x0142B3B8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142B3BC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ByteReader))
            // 0x0142B3C0: MOV x23, x0                | X23 = val_6;//m1                        
            val_15 = val_6;
            // 0x0142B3C4: B.EQ #0x142b3f0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x0142B3C8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142B3CC: ADD x8, sp, #8             | X8 = (1152921510104379120 + 8) = 1152921510104379128 (0x1000000147ADAEF8);
            // 0x0142B3D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142B3D4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510104367216]
            // 0x0142B3D8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0142B3DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B3E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x0142B3E4: ADD x0, sp, #8             | X0 = (1152921510104379120 + 8) = 1152921510104379128 (0x1000000147ADAEF8);
            // 0x0142B3E8: BL #0x299a140              | 
            // 0x0142B3EC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x0142B3F0: CBNZ x21, #0x142b3f8       | if (X1 != 0) goto label_11;             
            if(val_14 != 0)
            {
                goto label_11;
            }
            // 0x0142B3F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147ADAEF8, ????);
            label_11:
            // 0x0142B3F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142B3FC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142B400: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142B404: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_14.Free(esp:  null);
            // 0x0142B408: CBNZ x23, #0x142b410       | if (0x0 != 0) goto label_12;            
            if(val_15 != 0)
            {
                goto label_12;
            }
            // 0x0142B40C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x0142B410: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B414: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0142B418: BL #0xba46d0               | X0 = val_15.ReadDictionary();           
            System.Collections.Generic.Dictionary<System.String, System.String> val_9 = val_15.ReadDictionary();
            // 0x0142B41C: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x0142B420: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_16 = 1152921504824418304;
            // 0x0142B424: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x0142B428: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_17 = null;
            // 0x0142B42C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x0142B430: CBZ x0, #0x142b4c4         | if (val_9 == null) goto label_13;       
            if(val_9 == null)
            {
                goto label_13;
            }
            // 0x0142B434: CBZ x22, #0x142b4dc        | if (val_9 == null) goto label_14;       
            if(val_9 == null)
            {
                goto label_14;
            }
            // 0x0142B438: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x0142B43C: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x0142B440: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142B444: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x0142B448: CBNZ x0, #0x142b47c        | if (val_9 != null) goto label_15;       
            if(val_9 != null)
            {
                goto label_15;
            }
            // 0x0142B44C: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.Dictionary<System.String, System.String>);
            // 0x0142B450: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142B454: LDR x0, [x8, #0x30]        | X0 = System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_element_class;
            // 0x0142B458: ADD x8, sp, #0x10          | X8 = (1152921510104379120 + 16) = 1152921510104379136 (0x1000000147ADAF00);
            // 0x0142B45C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_element_class, ????);
            // 0x0142B460: LDR x0, [sp, #0x10]        | X0 = val_10;                             //  find_add[1152921510104367216]
            // 0x0142B464: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x0142B468: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B46C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x0142B470: ADD x0, sp, #0x10          | X0 = (1152921510104379120 + 16) = 1152921510104379136 (0x1000000147ADAF00);
            // 0x0142B474: BL #0x299a140              | 
            // 0x0142B478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147ADAF00, ????);
            label_15:
            // 0x0142B47C: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_14 = null;
            // 0x0142B480: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x0142B484: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_14;
            // 0x0142B488: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x0142B48C: MOV x23, x0                | X23 = val_9;//m1                        
            val_16 = val_9;
            // 0x0142B490: CBNZ x23, #0x142b4e8       | if (val_9 != null) goto label_16;       
            if(val_16 != null)
            {
                goto label_16;
            }
            // 0x0142B494: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.Dictionary<System.String, System.String>);
            // 0x0142B498: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142B49C: LDR x0, [x8, #0x30]        | X0 = System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_element_class;
            // 0x0142B4A0: ADD x8, sp, #0x18          | X8 = (1152921510104379120 + 24) = 1152921510104379144 (0x1000000147ADAF08);
            // 0x0142B4A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_element_class, ????);
            // 0x0142B4A8: LDR x0, [sp, #0x18]        | X0 = val_11;                             //  find_add[1152921510104367216]
            // 0x0142B4AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x0142B4B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x0142B4B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x0142B4B8: ADD x0, sp, #0x18          | X0 = (1152921510104379120 + 24) = 1152921510104379144 (0x1000000147ADAF08);
            // 0x0142B4BC: BL #0x299a140              | 
            // 0x0142B4C0: B #0x142b4e4               |  goto label_17;                         
            goto label_17;
            label_13:
            // 0x0142B4C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B4C8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142B4CC: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142B4D0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142B4D4: MOV x3, x22                | X3 = val_9;//m1                         
            // 0x0142B4D8: B #0x142b55c               |  goto label_18;                         
            goto label_18;
            label_14:
            // 0x0142B4DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x0142B4E0: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_14 = null;
            label_17:
            // 0x0142B4E4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_16:
            // 0x0142B4E8: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x0142B4EC: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x0142B4F0: CBZ x9, #0x142b51c         | if (mem[282584257676929] == 0) goto label_19;
            if(mem[282584257676929] == 0)
            {
                goto label_19;
            }
            // 0x0142B4F4: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_13 = mem[282584257676823];
            // 0x0142B4F8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_14 = 0;
            // 0x0142B4FC: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_13 = val_13 + 8;
            label_21:
            // 0x0142B500: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x0142B504: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x0142B508: B.EQ #0x142b530            | if ((mem[282584257676823] + 8) + -8 == val_14) goto label_20;
            if(((mem[282584257676823] + 8) + -8) == val_14)
            {
                goto label_20;
            }
            // 0x0142B50C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_14 = val_14 + 1;
            // 0x0142B510: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_13 = val_13 + 16;
            // 0x0142B514: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x0142B518: B.LO #0x142b500            | if (0 < mem[282584257676929]) goto label_21;
            if(val_14 < mem[282584257676929])
            {
                goto label_21;
            }
            label_19:
            // 0x0142B51C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0142B520: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_18 = val_16;
            // 0x0142B524: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_14;
            // 0x0142B528: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x0142B52C: B #0x142b53c               |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x0142B530: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x0142B534: ADD x8, x8, x9, lsl #4     | X8 = (val_16 + ((mem[282584257676823] + 8)) << 4);
            val_16 = val_16 + (((mem[282584257676823] + 8)) << 4);
            // 0x0142B538: ADD x0, x8, #0x110         | X0 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_18 = val_16 + 272;
            label_22:
            // 0x0142B53C: LDP x8, x1, [x0]           | X8 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x0142B540: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0142B544: BLR x8                     | X0 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x0142B548: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x0142B54C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B550: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142B554: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142B558: MOV x2, x19                | X2 = X3;//m1                            
            label_18:
            // 0x0142B55C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142B560: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x0142B564: SUB sp, x29, #0x30         | SP = (1152921510104379200 - 48) = 1152921510104379152 (0x1000000147ADAF10);
            // 0x0142B568: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0142B56C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0142B570: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0142B574: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0142B578: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_12;
            return val_12;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142B57C: MOV x19, x0                | 
            // 0x0142B580: ADD x0, sp, #8             | 
            // 0x0142B584: B #0x142b59c               | 
            // 0x0142B588: MOV x19, x0                | 
            // 0x0142B58C: ADD x0, sp, #0x10          | 
            // 0x0142B590: B #0x142b59c               | 
            // 0x0142B594: MOV x19, x0                | 
            // 0x0142B598: ADD x0, sp, #0x18          | 
            label_24:
            // 0x0142B59C: BL #0x299a140              | 
            // 0x0142B5A0: MOV x0, x19                | 
            // 0x0142B5A4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142B5A8 (21149096), len: 876  VirtAddr: 0x0142B5A8 RVA: 0x0142B5A8 token: 100664118 methodIndex: 30163 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ReadCSV_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            // 0x0142B5A8: STP x24, x23, [sp, #-0x40]! | stack[1152921510104556688] = ???;  stack[1152921510104556696] = ???;  //  dest_result_addr=1152921510104556688 |  dest_result_addr=1152921510104556696
            // 0x0142B5AC: STP x22, x21, [sp, #0x10]  | stack[1152921510104556704] = ???;  stack[1152921510104556712] = ???;  //  dest_result_addr=1152921510104556704 |  dest_result_addr=1152921510104556712
            // 0x0142B5B0: STP x20, x19, [sp, #0x20]  | stack[1152921510104556720] = ???;  stack[1152921510104556728] = ???;  //  dest_result_addr=1152921510104556720 |  dest_result_addr=1152921510104556728
            // 0x0142B5B4: STP x29, x30, [sp, #0x30]  | stack[1152921510104556736] = ???;  stack[1152921510104556744] = ???;  //  dest_result_addr=1152921510104556736 |  dest_result_addr=1152921510104556744
            // 0x0142B5B8: ADD x29, sp, #0x30         | X29 = (1152921510104556688 + 48) = 1152921510104556736 (0x1000000147B064C0);
            // 0x0142B5BC: SUB sp, sp, #0x20          | SP = (1152921510104556688 - 32) = 1152921510104556656 (0x1000000147B06470);
            // 0x0142B5C0: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142B5C4: LDRB w8, [x20, #0x17]      | W8 = (bool)static_value_03737017;       
            // 0x0142B5C8: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142B5CC: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142B5D0: MOV x21, x1                | X21 = X1;//m1                           
            val_14 = X1;
            // 0x0142B5D4: TBNZ w8, #0, #0x142b5f0    | if (static_value_03737017 == true) goto label_0;
            // 0x0142B5D8: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x0142B5DC: LDR x8, [x8, #0x568]       | X8 = 0x2B8FFDC;                         
            // 0x0142B5E0: LDR w0, [x8]               | W0 = 0x16BB;                            
            // 0x0142B5E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x16BB, ????);     
            // 0x0142B5E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142B5EC: STRB w8, [x20, #0x17]      | static_value_03737017 = true;            //  dest_result_addr=57896983
            label_0:
            // 0x0142B5F0: CBNZ x21, #0x142b5f8       | if (X1 != 0) goto label_1;              
            if(val_14 != 0)
            {
                goto label_1;
            }
            // 0x0142B5F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16BB, ????);     
            label_1:
            // 0x0142B5F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B5FC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142B600: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_14.AppDomain;
            // 0x0142B604: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142B608: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B60C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B610: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142B614: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142B618: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142B61C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142B620: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B624: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B628: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142B62C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142B630: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142B634: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142B638: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142B63C: ADRP x9, #0x364e000        | X9 = 56942592 (0x364E000);              
            // 0x0142B640: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0142B644: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142B648: LDR x9, [x9, #0x400]       | X9 = 1152921504876068864;               
            // 0x0142B64C: LDR x24, [x9]              | X24 = typeof(ByteReader);               
            // 0x0142B650: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142B654: TBZ w9, #0, #0x142b668     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142B658: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142B65C: CBNZ w9, #0x142b668        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142B660: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142B664: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142B668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B66C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142B670: MOV x1, x24                | X1 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x0142B674: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142B678: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142B67C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142B680: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142B684: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142B688: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142B68C: TBZ w9, #0, #0x142b6a0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142B690: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142B694: CBNZ w9, #0x142b6a0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142B698: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142B69C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142B6A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B6A4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142B6A8: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142B6AC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142B6B0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142B6B4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x0142B6B8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142B6BC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142B6C0: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x0142B6C4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142B6C8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142B6CC: TBZ w9, #0, #0x142b6e0     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142B6D0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142B6D4: CBNZ w9, #0x142b6e0        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142B6D8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142B6DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142B6E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B6E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B6E8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142B6EC: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x0142B6F0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142B6F4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x0142B6F8: CBZ x0, #0x142b75c         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x0142B6FC: ADRP x9, #0x3636000        | X9 = 56844288 (0x3636000);              
            // 0x0142B700: LDR x9, [x9, #0x30]        | X9 = 1152921504876068864;               
            // 0x0142B704: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142B708: LDR x1, [x9]               | X1 = typeof(ByteReader);                
            // 0x0142B70C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142B710: LDRB w9, [x1, #0x104]      | W9 = ByteReader.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142B714: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ByteReader.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142B718: B.LO #0x142b734            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ByteReader.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x0142B71C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142B720: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierar
            // 0x0142B724: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142B728: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ByteReader))
            // 0x0142B72C: MOV x23, x0                | X23 = val_6;//m1                        
            val_15 = val_6;
            // 0x0142B730: B.EQ #0x142b75c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ByteReader.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x0142B734: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142B738: ADD x8, sp, #8             | X8 = (1152921510104556656 + 8) = 1152921510104556664 (0x1000000147B06478);
            // 0x0142B73C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142B740: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510104544752]
            // 0x0142B744: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0142B748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B74C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x0142B750: ADD x0, sp, #8             | X0 = (1152921510104556656 + 8) = 1152921510104556664 (0x1000000147B06478);
            // 0x0142B754: BL #0x299a140              | 
            // 0x0142B758: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x0142B75C: CBNZ x21, #0x142b764       | if (X1 != 0) goto label_11;             
            if(val_14 != 0)
            {
                goto label_11;
            }
            // 0x0142B760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147B06478, ????);
            label_11:
            // 0x0142B764: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142B768: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142B76C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142B770: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_14.Free(esp:  null);
            // 0x0142B774: CBNZ x23, #0x142b77c       | if (0x0 != 0) goto label_12;            
            if(val_15 != 0)
            {
                goto label_12;
            }
            // 0x0142B778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x0142B77C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B780: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0142B784: BL #0xba48c8               | X0 = val_15.ReadCSV();                  
            BetterList<System.String> val_9 = val_15.ReadCSV();
            // 0x0142B788: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x0142B78C: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_16 = 1152921504824418304;
            // 0x0142B790: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x0142B794: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_17 = null;
            // 0x0142B798: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x0142B79C: CBZ x0, #0x142b830         | if (val_9 == null) goto label_13;       
            if(val_9 == null)
            {
                goto label_13;
            }
            // 0x0142B7A0: CBZ x22, #0x142b848        | if (val_9 == null) goto label_14;       
            if(val_9 == null)
            {
                goto label_14;
            }
            // 0x0142B7A4: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x0142B7A8: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x0142B7AC: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142B7B0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x0142B7B4: CBNZ x0, #0x142b7e8        | if (val_9 != null) goto label_15;       
            if(val_9 != null)
            {
                goto label_15;
            }
            // 0x0142B7B8: LDR x8, [x22]              | X8 = typeof(BetterList<System.String>); 
            // 0x0142B7BC: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142B7C0: LDR x0, [x8, #0x30]        | X0 = BetterList<T>.__il2cppRuntimeField_element_class;
            // 0x0142B7C4: ADD x8, sp, #0x10          | X8 = (1152921510104556656 + 16) = 1152921510104556672 (0x1000000147B06480);
            // 0x0142B7C8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? BetterList<T>.__il2cppRuntimeField_element_class, ????);
            // 0x0142B7CC: LDR x0, [sp, #0x10]        | X0 = val_10;                             //  find_add[1152921510104544752]
            // 0x0142B7D0: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x0142B7D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B7D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x0142B7DC: ADD x0, sp, #0x10          | X0 = (1152921510104556656 + 16) = 1152921510104556672 (0x1000000147B06480);
            // 0x0142B7E0: BL #0x299a140              | 
            // 0x0142B7E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147B06480, ????);
            label_15:
            // 0x0142B7E8: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_14 = null;
            // 0x0142B7EC: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x0142B7F0: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_14;
            // 0x0142B7F4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x0142B7F8: MOV x23, x0                | X23 = val_9;//m1                        
            val_16 = val_9;
            // 0x0142B7FC: CBNZ x23, #0x142b854       | if (val_9 != null) goto label_16;       
            if(val_16 != null)
            {
                goto label_16;
            }
            // 0x0142B800: LDR x8, [x22]              | X8 = typeof(BetterList<System.String>); 
            // 0x0142B804: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142B808: LDR x0, [x8, #0x30]        | X0 = BetterList<T>.__il2cppRuntimeField_element_class;
            // 0x0142B80C: ADD x8, sp, #0x18          | X8 = (1152921510104556656 + 24) = 1152921510104556680 (0x1000000147B06488);
            // 0x0142B810: BL #0x27d96d4              | X0 = sub_27D96D4( ?? BetterList<T>.__il2cppRuntimeField_element_class, ????);
            // 0x0142B814: LDR x0, [sp, #0x18]        | X0 = val_11;                             //  find_add[1152921510104544752]
            // 0x0142B818: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x0142B81C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x0142B820: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x0142B824: ADD x0, sp, #0x18          | X0 = (1152921510104556656 + 24) = 1152921510104556680 (0x1000000147B06488);
            // 0x0142B828: BL #0x299a140              | 
            // 0x0142B82C: B #0x142b850               |  goto label_17;                         
            goto label_17;
            label_13:
            // 0x0142B830: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B834: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142B838: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142B83C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142B840: MOV x3, x22                | X3 = val_9;//m1                         
            // 0x0142B844: B #0x142b8c8               |  goto label_18;                         
            goto label_18;
            label_14:
            // 0x0142B848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x0142B84C: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_14 = null;
            label_17:
            // 0x0142B850: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_16:
            // 0x0142B854: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x0142B858: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x0142B85C: CBZ x9, #0x142b888         | if (mem[282584257676929] == 0) goto label_19;
            if(mem[282584257676929] == 0)
            {
                goto label_19;
            }
            // 0x0142B860: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_13 = mem[282584257676823];
            // 0x0142B864: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_14 = 0;
            // 0x0142B868: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_13 = val_13 + 8;
            label_21:
            // 0x0142B86C: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x0142B870: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x0142B874: B.EQ #0x142b89c            | if ((mem[282584257676823] + 8) + -8 == val_14) goto label_20;
            if(((mem[282584257676823] + 8) + -8) == val_14)
            {
                goto label_20;
            }
            // 0x0142B878: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_14 = val_14 + 1;
            // 0x0142B87C: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_13 = val_13 + 16;
            // 0x0142B880: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x0142B884: B.LO #0x142b86c            | if (0 < mem[282584257676929]) goto label_21;
            if(val_14 < mem[282584257676929])
            {
                goto label_21;
            }
            label_19:
            // 0x0142B888: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0142B88C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_18 = val_16;
            // 0x0142B890: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_14;
            // 0x0142B894: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x0142B898: B #0x142b8a8               |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x0142B89C: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x0142B8A0: ADD x8, x8, x9, lsl #4     | X8 = (val_16 + ((mem[282584257676823] + 8)) << 4);
            val_16 = val_16 + (((mem[282584257676823] + 8)) << 4);
            // 0x0142B8A4: ADD x0, x8, #0x110         | X0 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_18 = val_16 + 272;
            label_22:
            // 0x0142B8A8: LDP x8, x1, [x0]           | X8 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x0142B8AC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0142B8B0: BLR x8                     | X0 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x0142B8B4: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x0142B8B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B8BC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142B8C0: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142B8C4: MOV x2, x19                | X2 = X3;//m1                            
            label_18:
            // 0x0142B8C8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142B8CC: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x0142B8D0: SUB sp, x29, #0x30         | SP = (1152921510104556736 - 48) = 1152921510104556688 (0x1000000147B06490);
            // 0x0142B8D4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0142B8D8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0142B8DC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0142B8E0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0142B8E4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_12;
            return val_12;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142B8E8: MOV x19, x0                | 
            // 0x0142B8EC: ADD x0, sp, #8             | 
            // 0x0142B8F0: B #0x142b908               | 
            // 0x0142B8F4: MOV x19, x0                | 
            // 0x0142B8F8: ADD x0, sp, #0x10          | 
            // 0x0142B8FC: B #0x142b908               | 
            // 0x0142B900: MOV x19, x0                | 
            // 0x0142B904: ADD x0, sp, #0x18          | 
            label_24:
            // 0x0142B908: BL #0x299a140              | 
            // 0x0142B90C: MOV x0, x19                | 
            // 0x0142B910: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142B914 (21149972), len: 560  VirtAddr: 0x0142B914 RVA: 0x0142B914 token: 100664119 methodIndex: 30164 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            System.Byte[] val_10;
            // 0x0142B914: STP x26, x25, [sp, #-0x50]! | stack[1152921510104730112] = ???;  stack[1152921510104730120] = ???;  //  dest_result_addr=1152921510104730112 |  dest_result_addr=1152921510104730120
            // 0x0142B918: STP x24, x23, [sp, #0x10]  | stack[1152921510104730128] = ???;  stack[1152921510104730136] = ???;  //  dest_result_addr=1152921510104730128 |  dest_result_addr=1152921510104730136
            // 0x0142B91C: STP x22, x21, [sp, #0x20]  | stack[1152921510104730144] = ???;  stack[1152921510104730152] = ???;  //  dest_result_addr=1152921510104730144 |  dest_result_addr=1152921510104730152
            // 0x0142B920: STP x20, x19, [sp, #0x30]  | stack[1152921510104730160] = ???;  stack[1152921510104730168] = ???;  //  dest_result_addr=1152921510104730160 |  dest_result_addr=1152921510104730168
            // 0x0142B924: STP x29, x30, [sp, #0x40]  | stack[1152921510104730176] = ???;  stack[1152921510104730184] = ???;  //  dest_result_addr=1152921510104730176 |  dest_result_addr=1152921510104730184
            // 0x0142B928: ADD x29, sp, #0x40         | X29 = (1152921510104730112 + 64) = 1152921510104730176 (0x1000000147B30A40);
            // 0x0142B92C: SUB sp, sp, #0x10          | SP = (1152921510104730112 - 16) = 1152921510104730096 (0x1000000147B309F0);
            // 0x0142B930: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142B934: LDRB w8, [x21, #0x18]      | W8 = (bool)static_value_03737018;       
            // 0x0142B938: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142B93C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142B940: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142B944: TBNZ w8, #0, #0x142b960    | if (static_value_03737018 == true) goto label_0;
            // 0x0142B948: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x0142B94C: LDR x8, [x8, #0x7f0]       | X8 = 0x2B8FFCC;                         
            // 0x0142B950: LDR w0, [x8]               | W0 = 0x16B7;                            
            // 0x0142B954: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B7, ????);     
            // 0x0142B958: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142B95C: STRB w8, [x21, #0x18]      | static_value_03737018 = true;            //  dest_result_addr=57896984
            label_0:
            // 0x0142B960: CBNZ x20, #0x142b968       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142B964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16B7, ????);     
            label_1:
            // 0x0142B968: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142B96C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142B970: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142B974: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142B978: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B97C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B980: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142B984: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142B988: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142B98C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0142B990: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B994: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142B998: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142B99C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142B9A0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142B9A4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142B9A8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142B9AC: ADRP x9, #0x3616000        | X9 = 56713216 (0x3616000);              
            // 0x0142B9B0: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0142B9B4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142B9B8: LDR x9, [x9, #0x888]       | X9 = 1152921504996170800;               
            // 0x0142B9BC: LDR x24, [x9]              | X24 = typeof(System.Byte[]);            
            // 0x0142B9C0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142B9C4: TBZ w9, #0, #0x142b9d8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142B9C8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142B9CC: CBNZ w9, #0x142b9d8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142B9D0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142B9D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142B9D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142B9DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142B9E0: MOV x1, x24                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142B9E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142B9E8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142B9EC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142B9F0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142B9F4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142B9F8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142B9FC: TBZ w9, #0, #0x142ba10     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142BA00: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142BA04: CBNZ w9, #0x142ba10        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142BA08: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142BA0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142BA10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BA14: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142BA18: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142BA1C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142BA20: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142BA24: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142BA28: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142BA2C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142BA30: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x0142BA34: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142BA38: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142BA3C: TBZ w9, #0, #0x142ba50     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142BA40: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142BA44: CBNZ w9, #0x142ba50        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142BA48: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142BA4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142BA50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BA54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142BA58: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142BA5C: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x0142BA60: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142BA64: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x0142BA68: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x0142BA6C: CBZ x24, #0x142bac0        | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0142BA70: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x0142BA74: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x0142BA78: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x0142BA7C: LDR x25, [x8]              | X25 = typeof(System.Byte[]);            
            // 0x0142BA80: MOV x1, x25                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142BA84: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x0142BA88: MOV x23, x0                | X23 = val_6;//m1                        
            val_10 = val_6;
            // 0x0142BA8C: CBNZ x23, #0x142bac0       | if (val_6 != null) goto label_9;        
            if(val_10 != null)
            {
                goto label_9;
            }
            // 0x0142BA90: LDR x8, [x24]              | X8 = typeof(System.Object);             
            // 0x0142BA94: MOV x1, x25                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142BA98: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142BA9C: ADD x8, sp, #8             | X8 = (1152921510104730096 + 8) = 1152921510104730104 (0x1000000147B309F8);
            // 0x0142BAA0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142BAA4: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510104718192]
            // 0x0142BAA8: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0142BAAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142BAB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0142BAB4: ADD x0, sp, #8             | X0 = (1152921510104730096 + 8) = 1152921510104730104 (0x1000000147B309F8);
            // 0x0142BAB8: BL #0x299a140              | 
            // 0x0142BABC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_9:
            // 0x0142BAC0: CBNZ x20, #0x142bac8       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0142BAC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147B309F8, ????);
            label_10:
            // 0x0142BAC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142BACC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142BAD0: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142BAD4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142BAD8: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x0142BADC: LDR x8, [x8, #0x30]        | X8 = 1152921504876068864;               
            // 0x0142BAE0: LDR x0, [x8]               | X0 = typeof(ByteReader);                
            ByteReader val_8 = null;
            // 0x0142BAE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ByteReader), ????);
            // 0x0142BAE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142BAEC: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0142BAF0: MOV x20, x0                | X20 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x0142BAF4: BL #0xba42f4               | .ctor(bytes:  val_10);                  
            val_8 = new ByteReader(bytes:  val_10);
            // 0x0142BAF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BAFC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142BB00: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0142BB04: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142BB08: MOV x3, x20                | X3 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x0142BB0C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142BB10: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0142BB14: SUB sp, x29, #0x40         | SP = (1152921510104730176 - 64) = 1152921510104730112 (0x1000000147B30A00);
            // 0x0142BB18: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142BB1C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142BB20: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142BB24: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142BB28: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142BB2C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_9;
            return val_9;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142BB30: MOV x19, x0                | 
            // 0x0142BB34: ADD x0, sp, #8             | 
            // 0x0142BB38: BL #0x299a140              | 
            // 0x0142BB3C: MOV x0, x19                | 
            // 0x0142BB40: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142BB44 (21150532), len: 564  VirtAddr: 0x0142BB44 RVA: 0x0142BB44 token: 100664120 methodIndex: 30165 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            UnityEngine.TextAsset val_11;
            // 0x0142BB44: STP x24, x23, [sp, #-0x40]! | stack[1152921510104899472] = ???;  stack[1152921510104899480] = ???;  //  dest_result_addr=1152921510104899472 |  dest_result_addr=1152921510104899480
            // 0x0142BB48: STP x22, x21, [sp, #0x10]  | stack[1152921510104899488] = ???;  stack[1152921510104899496] = ???;  //  dest_result_addr=1152921510104899488 |  dest_result_addr=1152921510104899496
            // 0x0142BB4C: STP x20, x19, [sp, #0x20]  | stack[1152921510104899504] = ???;  stack[1152921510104899512] = ???;  //  dest_result_addr=1152921510104899504 |  dest_result_addr=1152921510104899512
            // 0x0142BB50: STP x29, x30, [sp, #0x30]  | stack[1152921510104899520] = ???;  stack[1152921510104899528] = ???;  //  dest_result_addr=1152921510104899520 |  dest_result_addr=1152921510104899528
            // 0x0142BB54: ADD x29, sp, #0x30         | X29 = (1152921510104899472 + 48) = 1152921510104899520 (0x1000000147B59FC0);
            // 0x0142BB58: SUB sp, sp, #0x10          | SP = (1152921510104899472 - 16) = 1152921510104899456 (0x1000000147B59F80);
            // 0x0142BB5C: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142BB60: LDRB w8, [x21, #0x19]      | W8 = (bool)static_value_03737019;       
            // 0x0142BB64: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142BB68: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142BB6C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142BB70: TBNZ w8, #0, #0x142bb8c    | if (static_value_03737019 == true) goto label_0;
            // 0x0142BB74: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x0142BB78: LDR x8, [x8, #0x658]       | X8 = 0x2B8FFD0;                         
            // 0x0142BB7C: LDR w0, [x8]               | W0 = 0x16B8;                            
            // 0x0142BB80: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B8, ????);     
            // 0x0142BB84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142BB88: STRB w8, [x21, #0x19]      | static_value_03737019 = true;            //  dest_result_addr=57896985
            label_0:
            // 0x0142BB8C: CBNZ x20, #0x142bb94       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142BB90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16B8, ????);     
            label_1:
            // 0x0142BB94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142BB98: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142BB9C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142BBA0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142BBA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BBA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142BBAC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142BBB0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142BBB4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142BBB8: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0142BBBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BBC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142BBC4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142BBC8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142BBCC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142BBD0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142BBD4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142BBD8: ADRP x9, #0x360d000        | X9 = 56676352 (0x360D000);              
            // 0x0142BBDC: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0142BBE0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142BBE4: LDR x9, [x9, #0xd08]       | X9 = 1152921504696995840;               
            // 0x0142BBE8: LDR x24, [x9]              | X24 = typeof(UnityEngine.TextAsset);    
            // 0x0142BBEC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142BBF0: TBZ w9, #0, #0x142bc04     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142BBF4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142BBF8: CBNZ w9, #0x142bc04        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142BBFC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142BC00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142BC04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BC08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142BC0C: MOV x1, x24                | X1 = 1152921504696995840 (0x10000000055F9000);//ML01
            // 0x0142BC10: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142BC14: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142BC18: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142BC1C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142BC20: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142BC24: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142BC28: TBZ w9, #0, #0x142bc3c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142BC2C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142BC30: CBNZ w9, #0x142bc3c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142BC34: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142BC38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142BC3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BC40: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142BC44: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142BC48: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142BC4C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142BC50: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142BC54: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142BC58: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142BC5C: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x0142BC60: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142BC64: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142BC68: TBZ w9, #0, #0x142bc7c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142BC6C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142BC70: CBNZ w9, #0x142bc7c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142BC74: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142BC78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142BC7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BC80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142BC84: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142BC88: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x0142BC8C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142BC90: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x0142BC94: CBZ x0, #0x142bcf8         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x0142BC98: ADRP x9, #0x365a000        | X9 = 56991744 (0x365A000);              
            // 0x0142BC9C: LDR x9, [x9, #0xd60]       | X9 = 1152921504696995840;               
            // 0x0142BCA0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142BCA4: LDR x1, [x9]               | X1 = typeof(UnityEngine.TextAsset);     
            // 0x0142BCA8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142BCAC: LDRB w9, [x1, #0x104]      | W9 = UnityEngine.TextAsset.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142BCB0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, UnityEngine.TextAsset.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142BCB4: B.LO #0x142bcd0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < UnityEngine.TextAsset.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x0142BCB8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142BCBC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.TextAsset.__il2cppRuntimeField
            // 0x0142BCC0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.TextAsset.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142BCC4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.TextAsset.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.TextAsset))
            // 0x0142BCC8: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x0142BCCC: B.EQ #0x142bcf8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.TextAsset.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x0142BCD0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142BCD4: ADD x8, sp, #8             | X8 = (1152921510104899456 + 8) = 1152921510104899464 (0x1000000147B59F88);
            // 0x0142BCD8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142BCDC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510104887536]
            // 0x0142BCE0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0142BCE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142BCE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x0142BCEC: ADD x0, sp, #8             | X0 = (1152921510104899456 + 8) = 1152921510104899464 (0x1000000147B59F88);
            // 0x0142BCF0: BL #0x299a140              | 
            // 0x0142BCF4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x0142BCF8: CBNZ x20, #0x142bd00       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x0142BCFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147B59F88, ????);
            label_11:
            // 0x0142BD00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142BD04: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142BD08: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142BD0C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142BD10: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x0142BD14: LDR x8, [x8, #0x30]        | X8 = 1152921504876068864;               
            // 0x0142BD18: LDR x0, [x8]               | X0 = typeof(ByteReader);                
            ByteReader val_9 = null;
            // 0x0142BD1C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ByteReader), ????);
            // 0x0142BD20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142BD24: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0142BD28: MOV x20, x0                | X20 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x0142BD2C: BL #0xba4320               | .ctor(asset:  val_11);                  
            val_9 = new ByteReader(asset:  val_11);
            // 0x0142BD30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BD34: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142BD38: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0142BD3C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142BD40: MOV x3, x20                | X3 = 1152921504876068864 (0x10000000100C0000);//ML01
            // 0x0142BD44: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142BD48: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0142BD4C: SUB sp, x29, #0x30         | SP = (1152921510104899520 - 48) = 1152921510104899472 (0x1000000147B59F90);
            // 0x0142BD50: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0142BD54: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0142BD58: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0142BD5C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0142BD60: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142BD64: MOV x19, x0                | 
            // 0x0142BD68: ADD x0, sp, #8             | 
            // 0x0142BD6C: BL #0x299a140              | 
            // 0x0142BD70: MOV x0, x19                | 
            // 0x0142BD74: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142BD78 (21151096), len: 92  VirtAddr: 0x0142BD78 RVA: 0x0142BD78 token: 100664121 methodIndex: 30166 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0(int s)
        {
            //
            // Disasemble & Code
            // 0x0142BD78: STP x20, x19, [sp, #-0x20]! | stack[1152921510105044272] = ???;  stack[1152921510105044280] = ???;  //  dest_result_addr=1152921510105044272 |  dest_result_addr=1152921510105044280
            // 0x0142BD7C: STP x29, x30, [sp, #0x10]  | stack[1152921510105044288] = ???;  stack[1152921510105044296] = ???;  //  dest_result_addr=1152921510105044288 |  dest_result_addr=1152921510105044296
            // 0x0142BD80: ADD x29, sp, #0x10         | X29 = (1152921510105044272 + 16) = 1152921510105044288 (0x1000000147B7D540);
            // 0x0142BD84: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142BD88: LDRB w8, [x20, #0x1a]      | W8 = (bool)static_value_0373701A;       
            // 0x0142BD8C: MOV w19, w1                | W19 = W1;//m1                           
            // 0x0142BD90: TBNZ w8, #0, #0x142bdac    | if (static_value_0373701A == true) goto label_0;
            // 0x0142BD94: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x0142BD98: LDR x8, [x8, #0xdf8]       | X8 = 0x2B8FFF0;                         
            // 0x0142BD9C: LDR w0, [x8]               | W0 = 0x16C0;                            
            // 0x0142BDA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C0, ????);     
            // 0x0142BDA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142BDA8: STRB w8, [x20, #0x1a]      | static_value_0373701A = true;            //  dest_result_addr=57896986
            label_0:
            // 0x0142BDAC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x0142BDB0: LDR x8, [x8, #0xa70]       | X8 = 1152921510105028208;               
            // 0x0142BDB4: LDR x20, [x8]              | X20 = typeof(ByteReader[]);             
            // 0x0142BDB8: MOV x0, x20                | X0 = 1152921510105028208 (0x1000000147B79670);//ML01
            // 0x0142BDBC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ByteReader[]), ????);
            // 0x0142BDC0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0142BDC4: MOV w1, w19                | W1 = W1;//m1                            
            // 0x0142BDC8: MOV x0, x20                | X0 = 1152921510105028208 (0x1000000147B79670);//ML01
            // 0x0142BDCC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0142BDD0: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(ByteReader[]), ????);
        
        }
    
    }

}
