using UnityEngine;

namespace ILRuntime.CLR.TypeSystem
{
    public class CLRType : IType
    {
        // Fields
        private System.Type clrType; //  0x00000010
        private bool isPrimitive; //  0x00000018
        private bool isValueType; //  0x00000019
        private bool isEnum; //  0x0000001A
        private System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>> methods; //  0x00000020
        private ILRuntime.Runtime.Enviorment.AppDomain appdomain; //  0x00000028
        private System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> constructors; //  0x00000030
        private System.Collections.Generic.KeyValuePair<string, ILRuntime.CLR.TypeSystem.IType>[] genericArguments; //  0x00000038
        private System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.CLRType> genericInstances; //  0x00000040
        private System.Collections.Generic.Dictionary<string, int> fieldMapping; //  0x00000048
        private System.Collections.Generic.Dictionary<int, System.Reflection.FieldInfo> fieldInfoCache; //  0x00000050
        private System.Collections.Generic.Dictionary<int, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate> fieldGetterCache; //  0x00000058
        private System.Collections.Generic.Dictionary<int, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate> fieldSetterCache; //  0x00000060
        private System.Collections.Generic.Dictionary<int, int> fieldIdxMapping; //  0x00000068
        private ILRuntime.CLR.TypeSystem.IType[] orderedFieldTypes; //  0x00000070
        private ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate memberwiseCloneDelegate; //  0x00000078
        private ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate createDefaultInstanceDelegate; //  0x00000080
        private ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate createArrayInstanceDelegate; //  0x00000088
        private System.Collections.Generic.Dictionary<int, int> fieldTokenMapping; //  0x00000090
        private ILRuntime.CLR.TypeSystem.IType byRefType; //  0x00000098
        private ILRuntime.CLR.TypeSystem.IType elementType; //  0x000000A0
        private System.Collections.Generic.Dictionary<int, ILRuntime.CLR.TypeSystem.IType> arrayTypes; //  0x000000A8
        private ILRuntime.CLR.TypeSystem.IType[] interfaces; //  0x000000B0
        private bool isDelegate; //  0x000000B8
        private ILRuntime.CLR.TypeSystem.IType baseType; //  0x000000C0
        private bool isBaseTypeInitialized; //  0x000000C8
        private bool interfaceInitialized; //  0x000000C9
        private bool valueTypeBinderGot; //  0x000000CA
        private ILRuntime.Reflection.ILRuntimeWrapperType wraperType; //  0x000000D0
        private ILRuntime.Runtime.Enviorment.ValueTypeBinder valueTypeBinder; //  0x000000D8
        private int hashCode; //  0x000000E0
        private static int instance_id; // static_offset: 0x00000000
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x281B9A0
        private bool <IsArray>k__BackingField; //  0x000000E4
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x281B9DC
        private int <ArrayRank>k__BackingField; //  0x000000E8
        
        // Properties
        public System.Collections.Generic.Dictionary<int, System.Reflection.FieldInfo> Fields { get; }
        public System.Collections.Generic.Dictionary<int, int> FieldIndexMapping { get; }
        public ILRuntime.CLR.TypeSystem.IType[] OrderedFieldTypes { get; }
        public int TotalFieldCount { get; }
        public ILRuntime.Runtime.Enviorment.AppDomain AppDomain { get; }
        public bool IsGenericInstance { get; }
        public System.Collections.Generic.KeyValuePair<string, ILRuntime.CLR.TypeSystem.IType>[] GenericArguments { get; }
        public ILRuntime.CLR.TypeSystem.IType ElementType { get; }
        public bool HasGenericParameter { get; }
        public bool IsGenericParameter { get; }
        public bool IsInterface { get; }
        public System.Type TypeForCLR { get; }
        public System.Type ReflectionType { get; }
        public ILRuntime.CLR.TypeSystem.IType ByRefType { get; }
        public ILRuntime.CLR.TypeSystem.IType ArrayType { get; }
        public bool IsArray { get; set; }
        public int ArrayRank { get; set; }
        public bool IsValueType { get; }
        public bool IsByRef { get; }
        public bool IsDelegate { get; }
        public bool IsPrimitive { get; }
        public bool IsEnum { get; }
        public string FullName { get; }
        public string Name { get; }
        public ILRuntime.CLR.TypeSystem.IType BaseType { get; }
        public ILRuntime.CLR.TypeSystem.IType[] Implements { get; }
        public ILRuntime.Runtime.Enviorment.ValueTypeBinder ValueTypeBinder { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x010F2A28 (17771048), len: 340  VirtAddr: 0x010F2A28 RVA: 0x010F2A28 token: 100663412 methodIndex: 28845 delegateWrapperIndex: 0 methodInvoker: 0
        public CLRType(System.Type clrType, ILRuntime.Runtime.Enviorment.AppDomain appdomain)
        {
            //
            // Disasemble & Code
            // 0x010F2A28: STP x22, x21, [sp, #-0x30]! | stack[1152921509994470496] = ???;  stack[1152921509994470504] = ???;  //  dest_result_addr=1152921509994470496 |  dest_result_addr=1152921509994470504
            // 0x010F2A2C: STP x20, x19, [sp, #0x10]  | stack[1152921509994470512] = ???;  stack[1152921509994470520] = ???;  //  dest_result_addr=1152921509994470512 |  dest_result_addr=1152921509994470520
            // 0x010F2A30: STP x29, x30, [sp, #0x20]  | stack[1152921509994470528] = ???;  stack[1152921509994470536] = ???;  //  dest_result_addr=1152921509994470528 |  dest_result_addr=1152921509994470536
            // 0x010F2A34: ADD x29, sp, #0x20         | X29 = (1152921509994470496 + 32) = 1152921509994470528 (0x1000000141209C80);
            // 0x010F2A38: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
            // 0x010F2A3C: LDRB w8, [x22, #0xaf6]     | W8 = (bool)static_value_03735AF6;       
            // 0x010F2A40: MOV x21, x2                | X21 = appdomain;//m1                    
            // 0x010F2A44: MOV x20, x1                | X20 = clrType;//m1                      
            // 0x010F2A48: MOV x19, x0                | X19 = 1152921509994482544 (0x100000014120CB70);//ML01
            // 0x010F2A4C: TBNZ w8, #0, #0x10f2a68    | if (static_value_03735AF6 == true) goto label_0;
            // 0x010F2A50: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x010F2A54: LDR x8, [x8, #0xb78]       | X8 = 0x2B90D00;                         
            // 0x010F2A58: LDR w0, [x8]               | W0 = 0x1A04;                            
            // 0x010F2A5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A04, ????);     
            // 0x010F2A60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F2A64: STRB w8, [x22, #0xaf6]     | static_value_03735AF6 = true;            //  dest_result_addr=57891574
            label_0:
            // 0x010F2A68: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x010F2A6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2A70: MOV x0, x19                | X0 = 1152921509994482544 (0x100000014120CB70);//ML01
            // 0x010F2A74: STR w8, [x19, #0xe0]       | this.hashCode = 0;                       //  dest_result_addr=1152921509994482768
            this.hashCode = 0;
            // 0x010F2A78: BL #0x16f59f0              | appdomain..ctor();                      
            val_1 = new System.Object();
            // 0x010F2A7C: STR x20, [x19, #0x10]      | this.clrType = clrType;                  //  dest_result_addr=1152921509994482560
            this.clrType = clrType;
            // 0x010F2A80: STR x21, [x19, #0x28]      | this.appdomain = appdomain;              //  dest_result_addr=1152921509994482584
            this.appdomain = val_1;
            // 0x010F2A84: CBZ x20, #0x10f2aa0        | if (clrType == null) goto label_1;      
            if(clrType == null)
            {
                goto label_1;
            }
            // 0x010F2A88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2A8C: MOV x0, x20                | X0 = clrType;//m1                       
            // 0x010F2A90: BL #0x1b6d41c              | X0 = clrType.get_IsPrimitive();         
            bool val_2 = clrType.IsPrimitive;
            // 0x010F2A94: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x010F2A98: STRB w8, [x19, #0x18]      | this.isPrimitive = (val_2 & 1);          //  dest_result_addr=1152921509994482568
            this.isPrimitive = val_3;
            // 0x010F2A9C: B #0x10f2abc               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x010F2AA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? appdomain..ctor(), ????);
            // 0x010F2AA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F2AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2AAC: BL #0x1b6d41c              | X0 = 0.get_IsPrimitive();               
            bool val_4 = 0.IsPrimitive;
            // 0x010F2AB0: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x010F2AB4: STRB w8, [x19, #0x18]      | this.isPrimitive = (val_4 & 1);          //  dest_result_addr=1152921509994482568
            this.isPrimitive = val_5;
            // 0x010F2AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_2:
            // 0x010F2ABC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2AC0: MOV x0, x20                | X0 = clrType;//m1                       
            // 0x010F2AC4: BL #0x1b6d294              | X0 = clrType.get_IsEnum();              
            bool val_6 = clrType.IsEnum;
            // 0x010F2AC8: AND w8, w0, #1             | W8 = (val_6 & 1);                       
            bool val_7 = val_6;
            // 0x010F2ACC: STRB w8, [x19, #0x1a]      | this.isEnum = (val_6 & 1);               //  dest_result_addr=1152921509994482570
            this.isEnum = val_7;
            // 0x010F2AD0: CBZ x20, #0x10f2aec        | if (clrType == null) goto label_3;      
            if(clrType == null)
            {
                goto label_3;
            }
            // 0x010F2AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2AD8: MOV x0, x20                | X0 = clrType;//m1                       
            // 0x010F2ADC: BL #0x1b6d264              | X0 = clrType.get_IsValueType();         
            bool val_8 = clrType.IsValueType;
            // 0x010F2AE0: AND w8, w0, #1             | W8 = (val_8 & 1);                       
            bool val_9 = val_8;
            // 0x010F2AE4: STRB w8, [x19, #0x19]      | this.isValueType = (val_8 & 1);          //  dest_result_addr=1152921509994482569
            this.isValueType = val_9;
            // 0x010F2AE8: B #0x10f2b08               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x010F2AEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x010F2AF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F2AF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2AF8: BL #0x1b6d264              | X0 = 0.get_IsValueType();               
            bool val_10 = 0.IsValueType;
            // 0x010F2AFC: AND w8, w0, #1             | W8 = (val_10 & 1);                      
            bool val_11 = val_10;
            // 0x010F2B00: STRB w8, [x19, #0x19]      | this.isValueType = (val_10 & 1);         //  dest_result_addr=1152921509994482569
            this.isValueType = val_11;
            // 0x010F2B04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_4:
            // 0x010F2B08: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x010F2B0C: MOV x0, x20                | X0 = clrType;//m1                       
            // 0x010F2B10: LDR x9, [x8, #0x220]       | X9 = typeof(System.Type).__il2cppRuntimeField_220;
            // 0x010F2B14: LDR x1, [x8, #0x228]       | X1 = typeof(System.Type).__il2cppRuntimeField_228;
            // 0x010F2B18: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_220();
            // 0x010F2B1C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x010F2B20: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x010F2B24: ADRP x9, #0x35cc000        | X9 = 56410112 (0x35CC000);              
            // 0x010F2B28: MOV x20, x0                | X20 = clrType;//m1                      
            // 0x010F2B2C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x010F2B30: LDR x9, [x9, #0xb00]       | X9 = 1152921504608817152;               
            // 0x010F2B34: LDR x21, [x9]              | X21 = typeof(System.MulticastDelegate); 
            // 0x010F2B38: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x010F2B3C: TBZ w9, #0, #0x10f2b50     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x010F2B40: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x010F2B44: CBNZ w9, #0x10f2b50        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x010F2B48: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x010F2B4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_6:
            // 0x010F2B50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F2B54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F2B58: MOV x1, x21                | X1 = 1152921504608817152 (0x10000000001E1000);//ML01
            // 0x010F2B5C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x010F2B60: CMP x20, x0                | STATE = COMPARE(clrType, val_12)        
            // 0x010F2B64: CSET w8, eq                | W8 = clrType == val_12 ? 1 : 0;         
            bool val_13 = (clrType == val_12) ? 1 : 0;
            // 0x010F2B68: STRB w8, [x19, #0xb8]      | this.isDelegate = clrType == val_12 ? 1 : 0;  //  dest_result_addr=1152921509994482728
            this.isDelegate = val_13;
            // 0x010F2B6C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F2B70: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F2B74: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F2B78: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F2B7C (17771388), len: 48  VirtAddr: 0x010F2B7C RVA: 0x010F2B7C token: 100663413 methodIndex: 28846 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.Dictionary<int, System.Reflection.FieldInfo> get_Fields()
        {
            //
            // Disasemble & Code
            // 0x010F2B7C: STP x20, x19, [sp, #-0x20]! | stack[1152921509994602992] = ???;  stack[1152921509994603000] = ???;  //  dest_result_addr=1152921509994602992 |  dest_result_addr=1152921509994603000
            // 0x010F2B80: STP x29, x30, [sp, #0x10]  | stack[1152921509994603008] = ???;  stack[1152921509994603016] = ???;  //  dest_result_addr=1152921509994603008 |  dest_result_addr=1152921509994603016
            // 0x010F2B84: ADD x29, sp, #0x10         | X29 = (1152921509994602992 + 16) = 1152921509994603008 (0x100000014122A200);
            // 0x010F2B88: MOV x19, x0                | X19 = 1152921509994615024 (0x100000014122D0F0);//ML01
            // 0x010F2B8C: LDR x8, [x19, #0x48]       | X8 = this.fieldMapping; //P2            
            // 0x010F2B90: CBNZ x8, #0x10f2b9c        | if (this.fieldMapping != null) goto label_0;
            if(this.fieldMapping != null)
            {
                goto label_0;
            }
            // 0x010F2B94: MOV x0, x19                | X0 = 1152921509994615024 (0x100000014122D0F0);//ML01
            // 0x010F2B98: BL #0x10f2bac              | this.InitializeFields();                
            this.InitializeFields();
            label_0:
            // 0x010F2B9C: LDR x0, [x19, #0x50]       | X0 = this.fieldInfoCache; //P2          
            // 0x010F2BA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F2BA4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F2BA8: RET                        |  return (System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>)this.fieldInfoCache;
            return this.fieldInfoCache;
            //  |  // // {name=val_0, type=System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3098 (17772696), len: 8  VirtAddr: 0x010F3098 RVA: 0x010F3098 token: 100663414 methodIndex: 28847 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.Dictionary<int, int> get_FieldIndexMapping()
        {
            //
            // Disasemble & Code
            // 0x010F3098: LDR x0, [x0, #0x68]        | X0 = this.fieldIdxMapping; //P2         
            // 0x010F309C: RET                        |  return (System.Collections.Generic.Dictionary<System.Int32, System.Int32>)this.fieldIdxMapping;
            return this.fieldIdxMapping;
            //  |  // // {name=val_0, type=System.Collections.Generic.Dictionary<System.Int32, System.Int32>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F30A0 (17772704), len: 48  VirtAddr: 0x010F30A0 RVA: 0x010F30A0 token: 100663415 methodIndex: 28848 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType[] get_OrderedFieldTypes()
        {
            //
            // Disasemble & Code
            // 0x010F30A0: STP x20, x19, [sp, #-0x20]! | stack[1152921509994884336] = ???;  stack[1152921509994884344] = ???;  //  dest_result_addr=1152921509994884336 |  dest_result_addr=1152921509994884344
            // 0x010F30A4: STP x29, x30, [sp, #0x10]  | stack[1152921509994884352] = ???;  stack[1152921509994884360] = ???;  //  dest_result_addr=1152921509994884352 |  dest_result_addr=1152921509994884360
            // 0x010F30A8: ADD x29, sp, #0x10         | X29 = (1152921509994884336 + 16) = 1152921509994884352 (0x100000014126ED00);
            // 0x010F30AC: MOV x19, x0                | X19 = 1152921509994896368 (0x1000000141271BF0);//ML01
            // 0x010F30B0: LDR x8, [x19, #0x48]       | X8 = this.fieldMapping; //P2            
            // 0x010F30B4: CBNZ x8, #0x10f30c0        | if (this.fieldMapping != null) goto label_0;
            if(this.fieldMapping != null)
            {
                goto label_0;
            }
            // 0x010F30B8: MOV x0, x19                | X0 = 1152921509994896368 (0x1000000141271BF0);//ML01
            // 0x010F30BC: BL #0x10f2bac              | this.InitializeFields();                
            this.InitializeFields();
            label_0:
            // 0x010F30C0: LDR x0, [x19, #0x70]       | X0 = this.orderedFieldTypes; //P2       
            // 0x010F30C4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F30C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F30CC: RET                        |  return (ILRuntime.CLR.TypeSystem.IType[])this.orderedFieldTypes;
            return this.orderedFieldTypes;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F30D0 (17772752), len: 264  VirtAddr: 0x010F30D0 RVA: 0x010F30D0 token: 100663416 methodIndex: 28849 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_TotalFieldCount()
        {
            //
            // Disasemble & Code
            // 0x010F30D0: STP x20, x19, [sp, #-0x20]! | stack[1152921509995055872] = ???;  stack[1152921509995055880] = ???;  //  dest_result_addr=1152921509995055872 |  dest_result_addr=1152921509995055880
            // 0x010F30D4: STP x29, x30, [sp, #0x10]  | stack[1152921509995055888] = ???;  stack[1152921509995055896] = ???;  //  dest_result_addr=1152921509995055888 |  dest_result_addr=1152921509995055896
            // 0x010F30D8: ADD x29, sp, #0x10         | X29 = (1152921509995055872 + 16) = 1152921509995055888 (0x1000000141298B10);
            // 0x010F30DC: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F30E0: LDRB w8, [x20, #0xaf7]     | W8 = (bool)static_value_03735AF7;       
            // 0x010F30E4: MOV x19, x0                | X19 = 1152921509995067904 (0x100000014129BA00);//ML01
            // 0x010F30E8: TBNZ w8, #0, #0x10f3104    | if (static_value_03735AF7 == true) goto label_0;
            // 0x010F30EC: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x010F30F0: LDR x8, [x8, #0xc0]        | X8 = 0x2B90D20;                         
            // 0x010F30F4: LDR w0, [x8]               | W0 = 0x1A0C;                            
            // 0x010F30F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A0C, ????);     
            // 0x010F30FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3100: STRB w8, [x20, #0xaf7]     | static_value_03735AF7 = true;            //  dest_result_addr=57891575
            label_0:
            // 0x010F3104: LDR x8, [x19, #0x48]       | X8 = this.fieldMapping; //P2            
            // 0x010F3108: CBNZ x8, #0x10f3114        | if (this.fieldMapping != null) goto label_1;
            if(this.fieldMapping != null)
            {
                goto label_1;
            }
            // 0x010F310C: MOV x0, x19                | X0 = 1152921509995067904 (0x100000014129BA00);//ML01
            // 0x010F3110: BL #0x10f2bac              | this.InitializeFields();                
            this.InitializeFields();
            label_1:
            // 0x010F3114: LDR x0, [x19, #0x68]       | X0 = this.fieldIdxMapping; //P2         
            // 0x010F3118: CBZ x0, #0x10f3134         | if (this.fieldIdxMapping == null) goto label_2;
            if(this.fieldIdxMapping == null)
            {
                goto label_2;
            }
            // 0x010F311C: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x010F3120: LDR x8, [x8, #0x5e0]       | X8 = 1152921509995033520;               
            // 0x010F3124: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.Dictionary<System.Int32, System.Int32>::get_Count();
            // 0x010F3128: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F312C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F3130: B #0x240c528               | return this.fieldIdxMapping.get_Count();
            return this.fieldIdxMapping.Count;
            label_2:
            // 0x010F3134: LDR x19, [x19, #0x10]      | X19 = this.clrType; //P2                
            // 0x010F3138: CBNZ x19, #0x10f3140       | if (this.clrType != null) goto label_3; 
            if(this.clrType != null)
            {
                goto label_3;
            }
            // 0x010F313C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.fieldIdxMapping, ????);
            label_3:
            // 0x010F3140: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x010F3144: MOV x0, x19                | X0 = this.clrType;//m1                  
            // 0x010F3148: LDR x9, [x8, #0x230]       | X9 = typeof(System.Type).__il2cppRuntimeField_230;
            // 0x010F314C: LDR x1, [x8, #0x238]       | X1 = typeof(System.Type).__il2cppRuntimeField_238;
            // 0x010F3150: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_230();
            // 0x010F3154: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x010F3158: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x010F315C: MOV x19, x0                | X19 = this.clrType;//m1                 
            // 0x010F3160: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x010F3164: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x010F3168: TBZ w9, #0, #0x10f317c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x010F316C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x010F3170: CBNZ w9, #0x10f317c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x010F3174: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x010F3178: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_5:
            // 0x010F317C: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x010F3180: LDR x8, [x8, #0xc80]       | X8 = (string**)(1152921509995038640)("Cannot find ValueTypeBinder for type:");
            // 0x010F3184: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F3188: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F318C: MOV x2, x19                | X2 = this.clrType;//m1                  
            // 0x010F3190: LDR x1, [x8]               | X1 = "Cannot find ValueTypeBinder for type:";
            // 0x010F3194: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "Cannot find ValueTypeBinder for type:");
            string val_1 = System.String.Concat(str0:  0, str1:  "Cannot find ValueTypeBinder for type:");
            // 0x010F3198: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x010F319C: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x010F31A0: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x010F31A4: LDR x8, [x8]               | X8 = typeof(System.NotSupportedException);
            // 0x010F31A8: MOV x0, x8                 | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            System.NotSupportedException val_2 = null;
            // 0x010F31AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x010F31B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F31B4: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x010F31B8: MOV x20, x0                | X20 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x010F31BC: BL #0x16f7cac              | .ctor(message:  val_1);                 
            val_2 = new System.NotSupportedException(message:  val_1);
            // 0x010F31C0: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x010F31C4: LDR x8, [x8, #0x900]       | X8 = 1152921509995042880;               
            // 0x010F31C8: MOV x0, x20                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_3 = val_2;
            // 0x010F31CC: LDR x1, [x8]               | X1 = public System.Int32 ILRuntime.CLR.TypeSystem.CLRType::get_TotalFieldCount();
            // 0x010F31D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x010F31D4: BL #0x10ec5ac              | .ctor(def:  public System.Int32 ILRuntime.CLR.TypeSystem.CLRType::get_TotalFieldCount(), type:  0, domain:  0);
            val_3 = new ILRuntime.CLR.Method.CLRMethod(def:  public System.Int32 ILRuntime.CLR.TypeSystem.CLRType::get_TotalFieldCount(), type:  0, domain:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x010F31D8 (17773016), len: 8  VirtAddr: 0x010F31D8 RVA: 0x010F31D8 token: 100663417 methodIndex: 28850 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Runtime.Enviorment.AppDomain get_AppDomain()
        {
            //
            // Disasemble & Code
            // 0x010F31D8: LDR x0, [x0, #0x28]        | X0 = this.appdomain; //P2               
            // 0x010F31DC: RET                        |  return (ILRuntime.Runtime.Enviorment.AppDomain)this.appdomain;
            return this.appdomain;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Enviorment.AppDomain, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F31E0 (17773024), len: 16  VirtAddr: 0x010F31E0 RVA: 0x010F31E0 token: 100663418 methodIndex: 28851 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsGenericInstance()
        {
            //
            // Disasemble & Code
            // 0x010F31E0: LDR x8, [x0, #0x38]        | X8 = this.genericArguments; //P2        
            // 0x010F31E4: CMP x8, #0                 | STATE = COMPARE(this.genericArguments, 0x0)
            // 0x010F31E8: CSET w0, ne                | W0 = this.genericArguments != null ? 1 : 0;
            var val_1 = (this.genericArguments != null) ? 1 : 0;
            // 0x010F31EC: RET                        |  return (System.Boolean)this.genericArguments != null ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F31F0 (17773040), len: 8  VirtAddr: 0x010F31F0 RVA: 0x010F31F0 token: 100663419 methodIndex: 28852 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.KeyValuePair<string, ILRuntime.CLR.TypeSystem.IType>[] get_GenericArguments()
        {
            //
            // Disasemble & Code
            // 0x010F31F0: LDR x0, [x0, #0x38]        | X0 = this.genericArguments; //P2        
            // 0x010F31F4: RET                        |  return (System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[])this.genericArguments;
            return this.genericArguments;
            //  |  // // {name=val_0, type=System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F31F8 (17773048), len: 8  VirtAddr: 0x010F31F8 RVA: 0x010F31F8 token: 100663420 methodIndex: 28853 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_ElementType()
        {
            //
            // Disasemble & Code
            // 0x010F31F8: LDR x0, [x0, #0xa0]        | X0 = this.elementType; //P2             
            // 0x010F31FC: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)this.elementType;
            return this.elementType;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3200 (17773056), len: 436  VirtAddr: 0x010F3200 RVA: 0x010F3200 token: 100663421 methodIndex: 28854 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_HasGenericParameter()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x010F3200: STP x26, x25, [sp, #-0x50]! | stack[1152921509995837008] = ???;  stack[1152921509995837016] = ???;  //  dest_result_addr=1152921509995837008 |  dest_result_addr=1152921509995837016
            // 0x010F3204: STP x24, x23, [sp, #0x10]  | stack[1152921509995837024] = ???;  stack[1152921509995837032] = ???;  //  dest_result_addr=1152921509995837024 |  dest_result_addr=1152921509995837032
            // 0x010F3208: STP x22, x21, [sp, #0x20]  | stack[1152921509995837040] = ???;  stack[1152921509995837048] = ???;  //  dest_result_addr=1152921509995837040 |  dest_result_addr=1152921509995837048
            // 0x010F320C: STP x20, x19, [sp, #0x30]  | stack[1152921509995837056] = ???;  stack[1152921509995837064] = ???;  //  dest_result_addr=1152921509995837056 |  dest_result_addr=1152921509995837064
            // 0x010F3210: STP x29, x30, [sp, #0x40]  | stack[1152921509995837072] = ???;  stack[1152921509995837080] = ???;  //  dest_result_addr=1152921509995837072 |  dest_result_addr=1152921509995837080
            // 0x010F3214: ADD x29, sp, #0x40         | X29 = (1152921509995837008 + 64) = 1152921509995837072 (0x1000000141357690);
            // 0x010F3218: SUB sp, sp, #0x10          | SP = (1152921509995837008 - 16) = 1152921509995836992 (0x1000000141357640);
            // 0x010F321C: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F3220: LDRB w8, [x20, #0xaf8]     | W8 = (bool)static_value_03735AF8;       
            // 0x010F3224: MOV x19, x0                | X19 = 1152921509995849088 (0x100000014135A580);//ML01
            // 0x010F3228: TBNZ w8, #0, #0x10f3244    | if (static_value_03735AF8 == true) goto label_0;
            // 0x010F322C: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x010F3230: LDR x8, [x8, #0x7d0]       | X8 = 0x2B90D18;                         
            // 0x010F3234: LDR w0, [x8]               | W0 = 0x1A0A;                            
            // 0x010F3238: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A0A, ????);     
            // 0x010F323C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3240: STRB w8, [x20, #0xaf8]     | static_value_03735AF8 = true;            //  dest_result_addr=57891576
            label_0:
            // 0x010F3244: STP xzr, xzr, [sp]         | stack[1152921509995836992] = 0x0;  stack[1152921509995837000] = 0x0;  //  dest_result_addr=1152921509995836992 |  dest_result_addr=1152921509995837000
            // 0x010F3248: LDR x21, [x19, #0x38]      | X21 = this.genericArguments; //P2       
            // 0x010F324C: CBZ x21, #0x10f336c        | if (this.genericArguments == null) goto label_2;
            if(this.genericArguments == null)
            {
                goto label_2;
            }
            // 0x010F3250: LDR w8, [x21, #0x18]       | W8 = this.genericArguments.Length; //P2 
            // 0x010F3254: CMP w8, #1                 | STATE = COMPARE(this.genericArguments.Length, 0x1)
            // 0x010F3258: B.LT #0x10f336c            | if (this.genericArguments.Length < 1) goto label_2;
            if(this.genericArguments.Length < 1)
            {
                goto label_2;
            }
            // 0x010F325C: ADRP x22, #0x3648000       | X22 = 56918016 (0x3648000);             
            // 0x010F3260: ADRP x23, #0x366d000       | X23 = 57069568 (0x366D000);             
            // 0x010F3264: ADRP x24, #0x3679000       | X24 = 57118720 (0x3679000);             
            // 0x010F3268: LDR x22, [x22, #0xa88]     | X22 = 1152921509989983296;              
            // 0x010F326C: LDR x23, [x23, #0x108]     | X23 = 1152921504782192640;              
            // 0x010F3270: LDR x24, [x24, #0xdf8]     | X24 = 1152921504782245888;              
            // 0x010F3274: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
            label_13:
            // 0x010F3278: SXTW x25, w9               | X25 = 0 (0x00000000);                   
            // 0x010F327C: CMP w9, w8                 | STATE = COMPARE(0x0, this.genericArguments.Length)
            // 0x010F3280: B.LO #0x10f3290            | if (0 < this.genericArguments.Length) goto label_3;
            if(0 < this.genericArguments.Length)
            {
                goto label_3;
            }
            // 0x010F3284: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1A0A, ????);     
            // 0x010F3288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F328C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1A0A, ????);     
            label_3:
            // 0x010F3290: ADD x8, x21, x25, lsl #4   | X8 = this.genericArguments[0x0]; //PARR1 
            // 0x010F3294: LDR q0, [x8, #0x20]        | Q0 = this.genericArguments[0x0][0]      
            System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType> val_2 = this.genericArguments[0];
            // 0x010F3298: LDR x1, [x22]              | X1 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>::get_Value();
            // 0x010F329C: MOV x0, sp                 | X0 = 1152921509995836992 (0x1000000141357640);//ML01
            // 0x010F32A0: STR q0, [sp]               | stack[1152921509995836992] = this.genericArguments[0x0][0];  //  dest_result_addr=1152921509995836992
            // 0x010F32A4: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x010F32A8: CBZ x0, #0x10f335c         | if (this.genericArguments[0x0][0] == 0) goto label_6;
            if(val_2 == 0)
            {
                goto label_6;
            }
            // 0x010F32AC: LDR x9, [x0]               | X9 = this.genericArguments[0x0][0];     
            // 0x010F32B0: LDR x8, [x23]              | X8 = typeof(ILRuntime.CLR.TypeSystem.ILType);
            // 0x010F32B4: LDRB w11, [x9, #0x104]     | W11 = this.genericArguments[0x0][0] + 260;
            // 0x010F32B8: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F32BC: CMP w11, w10               | STATE = COMPARE(this.genericArguments[0x0][0] + 260, ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F32C0: B.LO #0x10f335c            | if (this.genericArguments[0x0][0] + 260 < ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) goto label_6;
            // 0x010F32C4: LDR x9, [x9, #0xb0]        | X9 = this.genericArguments[0x0][0] + 176;
            // 0x010F32C8: ADD x9, x9, x10, lsl #3    | X9 = (this.genericArguments[0x0][0] + 176 + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_ty
            // 0x010F32CC: LDUR x9, [x9, #-8]         | X9 = (this.genericArguments[0x0][0] + 176 + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F32D0: CMP x9, x8                 | STATE = COMPARE((this.genericArguments[0x0][0] + 176 + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.ILType))
            // 0x010F32D4: B.NE #0x10f335c            | if ((this.genericArguments[0x0][0] + 176 + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_6;
            // 0x010F32D8: LDR x1, [x22]              | X1 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>::get_Value();
            // 0x010F32DC: MOV x0, sp                 | X0 = 1152921509995836992 (0x1000000141357640);//ML01
            // 0x010F32E0: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x010F32E4: MOV x20, x0                | X20 = 1152921509995836992 (0x1000000141357640);//ML01
            // 0x010F32E8: CBNZ x20, #0x10f32f0       | if (this.genericArguments[0x0][0] != 0) goto label_7;
            if(val_2 != 0)
            {
                goto label_7;
            }
            // 0x010F32EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000141357640, ????);
            label_7:
            // 0x010F32F0: LDR x8, [x20]              | X8 = this.genericArguments[0x0][0];     
            System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType> val_6 = val_2;
            // 0x010F32F4: LDR x1, [x24]              | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F32F8: LDRH w9, [x8, #0x102]      | W9 = this.genericArguments[0x0][0] + 258;
            // 0x010F32FC: CBZ x9, #0x10f3328         | if (this.genericArguments[0x0][0] + 258 == 0) goto label_8;
            if((this.genericArguments[0x0][0] + 258) == 0)
            {
                goto label_8;
            }
            // 0x010F3300: LDR x10, [x8, #0x98]       | X10 = this.genericArguments[0x0][0] + 152;
            var val_3 = this.genericArguments[0x0][0] + 152;
            // 0x010F3304: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x010F3308: ADD x10, x10, #8           | X10 = (this.genericArguments[0x0][0] + 152 + 8);
            val_3 = val_3 + 8;
            label_10:
            // 0x010F330C: LDUR x12, [x10, #-8]       | X12 = (this.genericArguments[0x0][0] + 152 + 8) + -8;
            // 0x010F3310: CMP x12, x1                | STATE = COMPARE((this.genericArguments[0x0][0] + 152 + 8) + -8, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F3314: B.EQ #0x10f3338            | if ((this.genericArguments[0x0][0] + 152 + 8) + -8 == null) goto label_9;
            if(((this.genericArguments[0x0][0] + 152 + 8) + -8) == null)
            {
                goto label_9;
            }
            // 0x010F3318: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x010F331C: ADD x10, x10, #0x10        | X10 = ((this.genericArguments[0x0][0] + 152 + 8) + 16);
            val_3 = val_3 + 16;
            // 0x010F3320: CMP x11, x9                | STATE = COMPARE((0 + 1), this.genericArguments[0x0][0] + 258)
            // 0x010F3324: B.LO #0x10f330c            | if (0 < this.genericArguments[0x0][0] + 258) goto label_10;
            if(val_4 < (this.genericArguments[0x0][0] + 258))
            {
                goto label_10;
            }
            label_8:
            // 0x010F3328: MOVZ w2, #0x13             | W2 = 19 (0x13);//ML01                   
            // 0x010F332C: MOV x0, x20                | X0 = 1152921509995836992 (0x1000000141357640);//ML01
            val_2 = ;
            // 0x010F3330: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x1000000141357640, ????);
            // 0x010F3334: B #0x10f3348               |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x010F3338: LDR w9, [x10]              | W9 = (this.genericArguments[0x0][0] + 152 + 8);
            var val_5 = val_3;
            // 0x010F333C: ADD w9, w9, #0x13          | W9 = ((this.genericArguments[0x0][0] + 152 + 8) + 19);
            val_5 = val_5 + 19;
            // 0x010F3340: ADD x8, x8, w9, uxtw #4    | X8 = (this.genericArguments[0x0][0] + ((this.genericArguments[0x0][0] + 152 + 8) + 19));
            val_6 = val_6 + val_5;
            // 0x010F3344: ADD x0, x8, #0x110         | X0 = ((this.genericArguments[0x0][0] + ((this.genericArguments[0x0][0] + 152 + 8) + 19)) + 272);
            val_2 = val_6 + 272;
            label_11:
            // 0x010F3348: LDP x8, x1, [x0]           | X8 = ((this.genericArguments[0x0][0] + ((this.genericArguments[0x0][0] + 152 + 8) + 19)) + 272); X1 = ((this.genericArguments[0x0][0] + ((this.genericArguments[0x0][0] + 152 + 8) + 19)) + 272) + 8; //  | 
            // 0x010F334C: MOV x0, x20                | X0 = 1152921509995836992 (0x1000000141357640);//ML01
            // 0x010F3350: BLR x8                     | X0 = ((this.genericArguments[0x0][0] + ((this.genericArguments[0x0][0] + 152 + 8) + 19)) + 272)();
            // 0x010F3354: AND w8, w0, #1             | W8 = ( & 1) = 0 (0x00000000);           
            // 0x010F3358: TBNZ w8, #0, #0x10f33ac    | if ((0x0 & 0x1) != 0) goto label_12;    
            if((0 & 1) != 0)
            {
                goto label_12;
            }
            label_6:
            // 0x010F335C: LDR w8, [x21, #0x18]       | W8 = this.genericArguments.Length; //P2 
            // 0x010F3360: ADD w9, w25, #1            | W9 = (0 + 1);                           
            var val_1 = 0 + 1;
            // 0x010F3364: CMP w9, w8                 | STATE = COMPARE((0 + 1), this.genericArguments.Length)
            // 0x010F3368: B.LT #0x10f3278            | if (val_1 < this.genericArguments.Length) goto label_13;
            if(val_1 < this.genericArguments.Length)
            {
                goto label_13;
            }
            label_2:
            // 0x010F336C: LDR x19, [x19, #0x10]      | X19 = this.clrType; //P2                
            // 0x010F3370: CBNZ x19, #0x10f3378       | if (this.clrType != null) goto label_14;
            if(this.clrType != null)
            {
                goto label_14;
            }
            // 0x010F3374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000141357640, ????);
            label_14:
            // 0x010F3378: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x010F337C: MOV x0, x19                | X0 = this.clrType;//m1                  
            var val_7 = this.clrType;
            // 0x010F3380: LDR x9, [x8, #0x730]       | X9 = typeof(System.Type).__il2cppRuntimeField_730;
            // 0x010F3384: LDR x1, [x8, #0x738]       | X1 = typeof(System.Type).__il2cppRuntimeField_738;
            // 0x010F3388: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_730();
            label_15:
            // 0x010F338C: AND w0, w0, #1             | W0 = (this.clrType & 1);                
            val_7 = val_7 & 1;
            // 0x010F3390: SUB sp, x29, #0x40         | SP = (1152921509995837072 - 64) = 1152921509995837008 (0x1000000141357650);
            // 0x010F3394: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3398: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x010F339C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x010F33A0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x010F33A4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x010F33A8: RET                        |  return (System.Boolean)(this.clrType & 1);
            return (bool)val_7;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_12:
            // 0x010F33AC: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x010F33B0: B #0x10f338c               |  goto label_15;                         
            goto label_15;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F33B4 (17773492), len: 52  VirtAddr: 0x010F33B4 RVA: 0x010F33B4 token: 100663422 methodIndex: 28855 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsGenericParameter()
        {
            //
            // Disasemble & Code
            // 0x010F33B4: STP x20, x19, [sp, #-0x20]! | stack[1152921509995994112] = ???;  stack[1152921509995994120] = ???;  //  dest_result_addr=1152921509995994112 |  dest_result_addr=1152921509995994120
            // 0x010F33B8: STP x29, x30, [sp, #0x10]  | stack[1152921509995994128] = ???;  stack[1152921509995994136] = ???;  //  dest_result_addr=1152921509995994128 |  dest_result_addr=1152921509995994136
            // 0x010F33BC: ADD x29, sp, #0x10         | X29 = (1152921509995994112 + 16) = 1152921509995994128 (0x100000014137DC10);
            // 0x010F33C0: LDR x19, [x0, #0x10]       | X19 = this.clrType; //P2                
            // 0x010F33C4: CBNZ x19, #0x10f33cc       | if (this.clrType != null) goto label_0; 
            if(this.clrType != null)
            {
                goto label_0;
            }
            // 0x010F33C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x010F33CC: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x010F33D0: MOV x0, x19                | X0 = this.clrType;//m1                  
            // 0x010F33D4: LDR x2, [x8, #0x780]       | X2 = typeof(System.Type).__il2cppRuntimeField_780;
            // 0x010F33D8: LDR x1, [x8, #0x788]       | X1 = typeof(System.Type).__il2cppRuntimeField_788;
            // 0x010F33DC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F33E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F33E4: BR x2                      | goto typeof(System.Type).__il2cppRuntimeField_780;
            goto typeof(System.Type).__il2cppRuntimeField_780;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F33E8 (17773544), len: 44  VirtAddr: 0x010F33E8 RVA: 0x010F33E8 token: 100663423 methodIndex: 28856 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsInterface()
        {
            //
            // Disasemble & Code
            // 0x010F33E8: STP x20, x19, [sp, #-0x20]! | stack[1152921509996114304] = ???;  stack[1152921509996114312] = ???;  //  dest_result_addr=1152921509996114304 |  dest_result_addr=1152921509996114312
            // 0x010F33EC: STP x29, x30, [sp, #0x10]  | stack[1152921509996114320] = ???;  stack[1152921509996114328] = ???;  //  dest_result_addr=1152921509996114320 |  dest_result_addr=1152921509996114328
            // 0x010F33F0: ADD x29, sp, #0x10         | X29 = (1152921509996114304 + 16) = 1152921509996114320 (0x100000014139B190);
            // 0x010F33F4: LDR x19, [x0, #0x10]       | X19 = this.clrType; //P2                
            // 0x010F33F8: CBNZ x19, #0x10f3400       | if (this.clrType != null) goto label_0; 
            if(this.clrType != null)
            {
                goto label_0;
            }
            // 0x010F33FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x010F3400: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F3408: MOV x0, x19                | X0 = this.clrType;//m1                  
            // 0x010F340C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F3410: B #0x1b6d240               | return this.clrType.get_IsInterface();  
            return this.clrType.IsInterface;
        
        }
        //
        // Offset in libil2cpp.so: 0x010EE250 (17752656), len: 8  VirtAddr: 0x010EE250 RVA: 0x010EE250 token: 100663424 methodIndex: 28857 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type get_TypeForCLR()
        {
            //
            // Disasemble & Code
            // 0x010EE250: LDR x0, [x0, #0x10]        | X0 = this.clrType; //P2                 
            // 0x010EE254: RET                        |  return (System.Type)this.clrType;      
            return this.clrType;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3414 (17773588), len: 108  VirtAddr: 0x010F3414 RVA: 0x010F3414 token: 100663425 methodIndex: 28858 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type get_ReflectionType()
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Reflection.ILRuntimeWrapperType val_2;
            // 0x010F3414: STP x20, x19, [sp, #-0x20]! | stack[1152921509996354688] = ???;  stack[1152921509996354696] = ???;  //  dest_result_addr=1152921509996354688 |  dest_result_addr=1152921509996354696
            // 0x010F3418: STP x29, x30, [sp, #0x10]  | stack[1152921509996354704] = ???;  stack[1152921509996354712] = ???;  //  dest_result_addr=1152921509996354704 |  dest_result_addr=1152921509996354712
            // 0x010F341C: ADD x29, sp, #0x10         | X29 = (1152921509996354688 + 16) = 1152921509996354704 (0x10000001413D5C90);
            // 0x010F3420: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F3424: LDRB w8, [x20, #0xaf9]     | W8 = (bool)static_value_03735AF9;       
            // 0x010F3428: MOV x19, x0                | X19 = 1152921509996366720 (0x10000001413D8B80);//ML01
            // 0x010F342C: TBNZ w8, #0, #0x10f3448    | if (static_value_03735AF9 == true) goto label_0;
            // 0x010F3430: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x010F3434: LDR x8, [x8, #0xdd8]       | X8 = 0x2B90D1C;                         
            // 0x010F3438: LDR w0, [x8]               | W0 = 0x1A0B;                            
            // 0x010F343C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A0B, ????);     
            // 0x010F3440: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3444: STRB w8, [x20, #0xaf9]     | static_value_03735AF9 = true;            //  dest_result_addr=57891577
            label_0:
            // 0x010F3448: LDR x20, [x19, #0xd0]      | X20 = this.wraperType; //P2             
            val_2 = this.wraperType;
            // 0x010F344C: CBNZ x20, #0x10f3470       | if (this.wraperType != null) goto label_1;
            if(val_2 != null)
            {
                goto label_1;
            }
            // 0x010F3450: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x010F3454: LDR x8, [x8, #0xc30]       | X8 = 1152921504821649408;               
            // 0x010F3458: LDR x0, [x8]               | X0 = typeof(ILRuntime.Reflection.ILRuntimeWrapperType);
            ILRuntime.Reflection.ILRuntimeWrapperType val_1 = null;
            // 0x010F345C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Reflection.ILRuntimeWrapperType), ????);
            // 0x010F3460: MOV x1, x19                | X1 = 1152921509996366720 (0x10000001413D8B80);//ML01
            // 0x010F3464: MOV x20, x0                | X20 = 1152921504821649408 (0x100000000CCDA000);//ML01
            val_2 = val_1;
            // 0x010F3468: BL #0x10f3480              | .ctor(t:  this);                        
            val_1 = new ILRuntime.Reflection.ILRuntimeWrapperType(t:  this);
            // 0x010F346C: STR x20, [x19, #0xd0]      | this.wraperType = typeof(ILRuntime.Reflection.ILRuntimeWrapperType);  //  dest_result_addr=1152921509996366928
            this.wraperType = val_2;
            label_1:
            // 0x010F3470: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3474: MOV x0, x20                | X0 = 1152921504821649408 (0x100000000CCDA000);//ML01
            // 0x010F3478: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F347C: RET                        |  return (System.Type)typeof(ILRuntime.Reflection.ILRuntimeWrapperType);
            return (System.Type)val_2;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F350C (17773836), len: 8  VirtAddr: 0x010F350C RVA: 0x010F350C token: 100663426 methodIndex: 28859 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_ByRefType()
        {
            //
            // Disasemble & Code
            // 0x010F350C: LDR x0, [x0, #0x98]        | X0 = this.byRefType; //P2               
            // 0x010F3510: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)this.byRefType;
            return this.byRefType;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3514 (17773844), len: 104  VirtAddr: 0x010F3514 RVA: 0x010F3514 token: 100663427 methodIndex: 28860 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_ArrayType()
        {
            //
            // Disasemble & Code
            // 0x010F3514: STP x20, x19, [sp, #-0x20]! | stack[1152921509996596096] = ???;  stack[1152921509996596104] = ???;  //  dest_result_addr=1152921509996596096 |  dest_result_addr=1152921509996596104
            // 0x010F3518: STP x29, x30, [sp, #0x10]  | stack[1152921509996596112] = ???;  stack[1152921509996596120] = ???;  //  dest_result_addr=1152921509996596112 |  dest_result_addr=1152921509996596120
            // 0x010F351C: ADD x29, sp, #0x10         | X29 = (1152921509996596096 + 16) = 1152921509996596112 (0x1000000141410B90);
            // 0x010F3520: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F3524: LDRB w8, [x20, #0xafa]     | W8 = (bool)static_value_03735AFA;       
            // 0x010F3528: MOV x19, x0                | X19 = 1152921509996608128 (0x1000000141413A80);//ML01
            // 0x010F352C: TBNZ w8, #0, #0x10f3548    | if (static_value_03735AFA == true) goto label_0;
            // 0x010F3530: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x010F3534: LDR x8, [x8, #0x5a0]       | X8 = 0x2B90D14;                         
            // 0x010F3538: LDR w0, [x8]               | W0 = 0x1A09;                            
            // 0x010F353C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A09, ????);     
            // 0x010F3540: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3544: STRB w8, [x20, #0xafa]     | static_value_03735AFA = true;            //  dest_result_addr=57891578
            label_0:
            // 0x010F3548: LDR x0, [x19, #0xa8]       | X0 = this.arrayTypes; //P2              
            // 0x010F354C: CBZ x0, #0x10f356c         | if (this.arrayTypes == null) goto label_1;
            if(this.arrayTypes == null)
            {
                goto label_1;
            }
            // 0x010F3550: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x010F3554: LDR x8, [x8, #0x9d0]       | X8 = 1152921509996583104;               
            // 0x010F3558: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x010F355C: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.Dictionary<System.Int32, ILRuntime.CLR.TypeSystem.IType>::get_Item(System.Int32 key);
            // 0x010F3560: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3564: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F3568: B #0x24144f0               | return this.arrayTypes.get_Item(key:  1);
            return this.arrayTypes.Item[1];
            label_1:
            // 0x010F356C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3570: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F3574: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F3578: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)null;
            return (ILRuntime.CLR.TypeSystem.IType)0;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F357C (17773948), len: 8  VirtAddr: 0x010F357C RVA: 0x010F357C token: 100663428 methodIndex: 28861 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsArray()
        {
            //
            // Disasemble & Code
            // 0x010F357C: LDRB w0, [x0, #0xe4]       | W0 = this.<IsArray>k__BackingField; //P2 
            // 0x010F3580: RET                        |  return (System.Boolean)this.<IsArray>k__BackingField;
            return this.<IsArray>k__BackingField;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3584 (17773956), len: 12  VirtAddr: 0x010F3584 RVA: 0x010F3584 token: 100663429 methodIndex: 28862 delegateWrapperIndex: 0 methodInvoker: 0
        private void set_IsArray(bool value)
        {
            //
            // Disasemble & Code
            // 0x010F3584: AND w8, w1, #1             | W8 = (value & 1);                       
            bool val_1 = value;
            // 0x010F3588: STRB w8, [x0, #0xe4]       | this.<IsArray>k__BackingField = (value & 1);  //  dest_result_addr=1152921509996836452
            this.<IsArray>k__BackingField = val_1;
            // 0x010F358C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3590 (17773968), len: 8  VirtAddr: 0x010F3590 RVA: 0x010F3590 token: 100663430 methodIndex: 28863 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_ArrayRank()
        {
            //
            // Disasemble & Code
            // 0x010F3590: LDR w0, [x0, #0xe8]        | W0 = this.<ArrayRank>k__BackingField; //P2 
            // 0x010F3594: RET                        |  return (System.Int32)this.<ArrayRank>k__BackingField;
            return this.<ArrayRank>k__BackingField;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3598 (17773976), len: 8  VirtAddr: 0x010F3598 RVA: 0x010F3598 token: 100663431 methodIndex: 28864 delegateWrapperIndex: 0 methodInvoker: 0
        private void set_ArrayRank(int value)
        {
            //
            // Disasemble & Code
            // 0x010F3598: STR w1, [x0, #0xe8]        | this.<ArrayRank>k__BackingField = value;  //  dest_result_addr=1152921509997060456
            this.<ArrayRank>k__BackingField = value;
            // 0x010F359C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010EEAE4 (17754852), len: 8  VirtAddr: 0x010EEAE4 RVA: 0x010EEAE4 token: 100663432 methodIndex: 28865 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsValueType()
        {
            //
            // Disasemble & Code
            // 0x010EEAE4: LDRB w0, [x0, #0x19]       | W0 = this.isValueType; //P2             
            // 0x010EEAE8: RET                        |  return (System.Boolean)this.isValueType;
            return this.isValueType;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F35A0 (17773984), len: 44  VirtAddr: 0x010F35A0 RVA: 0x010F35A0 token: 100663433 methodIndex: 28866 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsByRef()
        {
            //
            // Disasemble & Code
            // 0x010F35A0: STP x20, x19, [sp, #-0x20]! | stack[1152921509997276288] = ???;  stack[1152921509997276296] = ???;  //  dest_result_addr=1152921509997276288 |  dest_result_addr=1152921509997276296
            // 0x010F35A4: STP x29, x30, [sp, #0x10]  | stack[1152921509997276304] = ???;  stack[1152921509997276312] = ???;  //  dest_result_addr=1152921509997276304 |  dest_result_addr=1152921509997276312
            // 0x010F35A8: ADD x29, sp, #0x10         | X29 = (1152921509997276288 + 16) = 1152921509997276304 (0x10000001414B6C90);
            // 0x010F35AC: LDR x19, [x0, #0x10]       | X19 = this.clrType; //P2                
            // 0x010F35B0: CBNZ x19, #0x10f35b8       | if (this.clrType != null) goto label_0; 
            if(this.clrType != null)
            {
                goto label_0;
            }
            // 0x010F35B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x010F35B8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F35BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F35C0: MOV x0, x19                | X0 = this.clrType;//m1                  
            // 0x010F35C4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F35C8: B #0x1b6d1dc               | return this.clrType.get_IsByRef();      
            return this.clrType.IsByRef;
        
        }
        //
        // Offset in libil2cpp.so: 0x010EC8D0 (17746128), len: 8  VirtAddr: 0x010EC8D0 RVA: 0x010EC8D0 token: 100663434 methodIndex: 28867 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsDelegate()
        {
            //
            // Disasemble & Code
            // 0x010EC8D0: LDRB w0, [x0, #0xb8]       | W0 = this.isDelegate; //P2              
            // 0x010EC8D4: RET                        |  return (System.Boolean)this.isDelegate;
            return this.isDelegate;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F35CC (17774028), len: 8  VirtAddr: 0x010F35CC RVA: 0x010F35CC token: 100663435 methodIndex: 28868 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsPrimitive()
        {
            //
            // Disasemble & Code
            // 0x010F35CC: LDRB w0, [x0, #0x18]       | W0 = this.isPrimitive; //P2             
            // 0x010F35D0: RET                        |  return (System.Boolean)this.isPrimitive;
            return this.isPrimitive;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F35D4 (17774036), len: 8  VirtAddr: 0x010F35D4 RVA: 0x010F35D4 token: 100663436 methodIndex: 28869 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsEnum()
        {
            //
            // Disasemble & Code
            // 0x010F35D4: LDRB w0, [x0, #0x1a]       | W0 = this.isEnum; //P2                  
            // 0x010F35D8: RET                        |  return (System.Boolean)this.isEnum;    
            return this.isEnum;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F35DC (17774044), len: 52  VirtAddr: 0x010F35DC RVA: 0x010F35DC token: 100663437 methodIndex: 28870 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_FullName()
        {
            //
            // Disasemble & Code
            // 0x010F35DC: STP x20, x19, [sp, #-0x20]! | stack[1152921509997732480] = ???;  stack[1152921509997732488] = ???;  //  dest_result_addr=1152921509997732480 |  dest_result_addr=1152921509997732488
            // 0x010F35E0: STP x29, x30, [sp, #0x10]  | stack[1152921509997732496] = ???;  stack[1152921509997732504] = ???;  //  dest_result_addr=1152921509997732496 |  dest_result_addr=1152921509997732504
            // 0x010F35E4: ADD x29, sp, #0x10         | X29 = (1152921509997732480 + 16) = 1152921509997732496 (0x1000000141526290);
            // 0x010F35E8: LDR x19, [x0, #0x10]       | X19 = this.clrType; //P2                
            // 0x010F35EC: CBNZ x19, #0x10f35f4       | if (this.clrType != null) goto label_0; 
            if(this.clrType != null)
            {
                goto label_0;
            }
            // 0x010F35F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x010F35F4: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x010F35F8: MOV x0, x19                | X0 = this.clrType;//m1                  
            // 0x010F35FC: LDR x2, [x8, #0x230]       | X2 = typeof(System.Type).__il2cppRuntimeField_230;
            // 0x010F3600: LDR x1, [x8, #0x238]       | X1 = typeof(System.Type).__il2cppRuntimeField_238;
            // 0x010F3604: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3608: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F360C: BR x2                      | goto typeof(System.Type).__il2cppRuntimeField_230;
            goto typeof(System.Type).__il2cppRuntimeField_230;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3610 (17774096), len: 48  VirtAddr: 0x010F3610 RVA: 0x010F3610 token: 100663438 methodIndex: 28871 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_Name()
        {
            //
            // Disasemble & Code
            // 0x010F3610: STP x20, x19, [sp, #-0x20]! | stack[1152921509997852672] = ???;  stack[1152921509997852680] = ???;  //  dest_result_addr=1152921509997852672 |  dest_result_addr=1152921509997852680
            // 0x010F3614: STP x29, x30, [sp, #0x10]  | stack[1152921509997852688] = ???;  stack[1152921509997852696] = ???;  //  dest_result_addr=1152921509997852688 |  dest_result_addr=1152921509997852696
            // 0x010F3618: ADD x29, sp, #0x10         | X29 = (1152921509997852672 + 16) = 1152921509997852688 (0x1000000141543810);
            // 0x010F361C: LDR x19, [x0, #0x10]       | X19 = this.clrType; //P2                
            // 0x010F3620: CBNZ x19, #0x10f3628       | if (this.clrType != null) goto label_0; 
            if(this.clrType != null)
            {
                goto label_0;
            }
            // 0x010F3624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x010F3628: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x010F362C: MOV x0, x19                | X0 = this.clrType;//m1                  
            // 0x010F3630: LDP x2, x1, [x8, #0x190]   | X2 = typeof(System.Type).__il2cppRuntimeField_190; X1 = typeof(System.Type).__il2cppRuntimeField_198; //  | 
            // 0x010F3634: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3638: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F363C: BR x2                      | goto typeof(System.Type).__il2cppRuntimeField_190;
            goto typeof(System.Type).__il2cppRuntimeField_190;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3640 (17774144), len: 48  VirtAddr: 0x010F3640 RVA: 0x010F3640 token: 100663439 methodIndex: 28872 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_BaseType()
        {
            //
            // Disasemble & Code
            // 0x010F3640: STP x20, x19, [sp, #-0x20]! | stack[1152921509997972864] = ???;  stack[1152921509997972872] = ???;  //  dest_result_addr=1152921509997972864 |  dest_result_addr=1152921509997972872
            // 0x010F3644: STP x29, x30, [sp, #0x10]  | stack[1152921509997972880] = ???;  stack[1152921509997972888] = ???;  //  dest_result_addr=1152921509997972880 |  dest_result_addr=1152921509997972888
            // 0x010F3648: ADD x29, sp, #0x10         | X29 = (1152921509997972864 + 16) = 1152921509997972880 (0x1000000141560D90);
            // 0x010F364C: MOV x19, x0                | X19 = 1152921509997984896 (0x1000000141563C80);//ML01
            // 0x010F3650: LDRB w8, [x19, #0xc8]      | W8 = this.isBaseTypeInitialized; //P2   
            // 0x010F3654: CBNZ w8, #0x10f3660        | if (this.isBaseTypeInitialized == true) goto label_0;
            if(this.isBaseTypeInitialized == true)
            {
                goto label_0;
            }
            // 0x010F3658: MOV x0, x19                | X0 = 1152921509997984896 (0x1000000141563C80);//ML01
            // 0x010F365C: BL #0x10f3670              | this.InitializeBaseType();              
            this.InitializeBaseType();
            label_0:
            // 0x010F3660: LDR x0, [x19, #0xc0]       | X0 = this.baseType; //P2                
            // 0x010F3664: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3668: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F366C: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)this.baseType;
            return this.baseType;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F39E8 (17775080), len: 48  VirtAddr: 0x010F39E8 RVA: 0x010F39E8 token: 100663440 methodIndex: 28873 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType[] get_Implements()
        {
            //
            // Disasemble & Code
            // 0x010F39E8: STP x20, x19, [sp, #-0x20]! | stack[1152921509998125824] = ???;  stack[1152921509998125832] = ???;  //  dest_result_addr=1152921509998125824 |  dest_result_addr=1152921509998125832
            // 0x010F39EC: STP x29, x30, [sp, #0x10]  | stack[1152921509998125840] = ???;  stack[1152921509998125848] = ???;  //  dest_result_addr=1152921509998125840 |  dest_result_addr=1152921509998125848
            // 0x010F39F0: ADD x29, sp, #0x10         | X29 = (1152921509998125824 + 16) = 1152921509998125840 (0x1000000141586310);
            // 0x010F39F4: MOV x19, x0                | X19 = 1152921509998137856 (0x1000000141589200);//ML01
            // 0x010F39F8: LDRB w8, [x19, #0xc9]      | W8 = this.interfaceInitialized; //P2    
            // 0x010F39FC: CBNZ w8, #0x10f3a08        | if (this.interfaceInitialized == true) goto label_0;
            if(this.interfaceInitialized == true)
            {
                goto label_0;
            }
            // 0x010F3A00: MOV x0, x19                | X0 = 1152921509998137856 (0x1000000141589200);//ML01
            // 0x010F3A04: BL #0x10f3a18              | this.InitializeInterfaces();            
            this.InitializeInterfaces();
            label_0:
            // 0x010F3A08: LDR x0, [x19, #0xb0]       | X0 = this.interfaces; //P2              
            // 0x010F3A0C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3A10: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F3A14: RET                        |  return (ILRuntime.CLR.TypeSystem.IType[])this.interfaces;
            return this.interfaces;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3B9C (17775516), len: 208  VirtAddr: 0x010F3B9C RVA: 0x010F3B9C token: 100663441 methodIndex: 28874 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Runtime.Enviorment.ValueTypeBinder get_ValueTypeBinder()
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.ValueTypeBinder val_5;
            //  | 
            var val_6;
            // 0x010F3B9C: STP x22, x21, [sp, #-0x30]! | stack[1152921509998292080] = ???;  stack[1152921509998292088] = ???;  //  dest_result_addr=1152921509998292080 |  dest_result_addr=1152921509998292088
            // 0x010F3BA0: STP x20, x19, [sp, #0x10]  | stack[1152921509998292096] = ???;  stack[1152921509998292104] = ???;  //  dest_result_addr=1152921509998292096 |  dest_result_addr=1152921509998292104
            // 0x010F3BA4: STP x29, x30, [sp, #0x20]  | stack[1152921509998292112] = ???;  stack[1152921509998292120] = ???;  //  dest_result_addr=1152921509998292112 |  dest_result_addr=1152921509998292120
            // 0x010F3BA8: ADD x29, sp, #0x20         | X29 = (1152921509998292080 + 32) = 1152921509998292112 (0x10000001415AEC90);
            // 0x010F3BAC: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F3BB0: LDRB w8, [x20, #0xafb]     | W8 = (bool)static_value_03735AFB;       
            // 0x010F3BB4: MOV x19, x0                | X19 = 1152921509998304128 (0x10000001415B1B80);//ML01
            val_5 = this;
            // 0x010F3BB8: TBNZ w8, #0, #0x10f3bd4    | if (static_value_03735AFB == true) goto label_0;
            // 0x010F3BBC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x010F3BC0: LDR x8, [x8, #0x398]       | X8 = 0x2B90D24;                         
            // 0x010F3BC4: LDR w0, [x8]               | W0 = 0x1A0D;                            
            // 0x010F3BC8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A0D, ????);     
            // 0x010F3BCC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3BD0: STRB w8, [x20, #0xafb]     | static_value_03735AFB = true;            //  dest_result_addr=57891579
            label_0:
            // 0x010F3BD4: LDR x20, [x19, #0x10]      | X20 = this.clrType; //P2                
            // 0x010F3BD8: CBNZ x20, #0x10f3be0       | if (this.clrType != null) goto label_1; 
            if(this.clrType != null)
            {
                goto label_1;
            }
            // 0x010F3BDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A0D, ????);     
            label_1:
            // 0x010F3BE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F3BE4: MOV x0, x20                | X0 = this.clrType;//m1                  
            // 0x010F3BE8: BL #0x1b6d264              | X0 = this.clrType.get_IsValueType();    
            bool val_1 = this.clrType.IsValueType;
            // 0x010F3BEC: MOV w8, w0                 | W8 = val_1;//m1                         
            // 0x010F3BF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_6 = 0;
            // 0x010F3BF4: TBZ w8, #0, #0x10f3c5c     | if (val_1 == false) goto label_2;       
            if(val_1 == false)
            {
                goto label_2;
            }
            // 0x010F3BF8: LDRB w8, [x19, #0xca]      | W8 = this.valueTypeBinderGot; //P2      
            // 0x010F3BFC: CBZ w8, #0x10f3c08         | if (this.valueTypeBinderGot == false) goto label_3;
            if(this.valueTypeBinderGot == false)
            {
                goto label_3;
            }
            // 0x010F3C00: ADD x19, x19, #0xd8        | X19 = this.valueTypeBinder;//AP2 res_addr=1152921509998304344
            val_5 = this.valueTypeBinder;
            // 0x010F3C04: B #0x10f3c58               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x010F3C08: LDR x20, [x19, #0x28]      | X20 = this.appdomain; //P2              
            // 0x010F3C0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3C10: STRB w8, [x19, #0xca]      | this.valueTypeBinderGot = true;          //  dest_result_addr=1152921509998304330
            this.valueTypeBinderGot = true;
            // 0x010F3C14: CBNZ x20, #0x10f3c1c       | if (this.appdomain != null) goto label_5;
            if(this.appdomain != null)
            {
                goto label_5;
            }
            // 0x010F3C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_5:
            // 0x010F3C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F3C20: MOV x0, x20                | X0 = this.appdomain;//m1                
            // 0x010F3C24: BL #0x28e4370              | X0 = this.appdomain.get_ValueTypeBinders();
            System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.ValueTypeBinder> val_2 = this.appdomain.ValueTypeBinders;
            // 0x010F3C28: LDR x20, [x19, #0x10]      | X20 = this.clrType; //P2                
            // 0x010F3C2C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x010F3C30: ADD x19, x19, #0xd8        | X19 = this.valueTypeBinder;//AP2 res_addr=1152921509998304344
            val_5 = this.valueTypeBinder;
            // 0x010F3C34: CBNZ x21, #0x10f3c3c       | if (val_2 != null) goto label_6;        
            if(val_2 != null)
            {
                goto label_6;
            }
            // 0x010F3C38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x010F3C3C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x010F3C40: LDR x8, [x8, #0x140]       | X8 = 1152921509998279104;               
            // 0x010F3C44: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x010F3C48: MOV x1, x20                | X1 = this.clrType;//m1                  
            // 0x010F3C4C: MOV x2, x19                | X2 = this.valueTypeBinder;//m1          
            ILRuntime.Runtime.Enviorment.ValueTypeBinder val_3 = val_5;
            // 0x010F3C50: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.ValueTypeBinder>::TryGetValue(System.Type key, out ILRuntime.Runtime.Enviorment.ValueTypeBinder value);
            // 0x010F3C54: BL #0x23fe7ec              | X0 = val_2.TryGetValue(key:  this.clrType, value: out  ILRuntime.Runtime.Enviorment.ValueTypeBinder val_3 = val_5);
            bool val_4 = val_2.TryGetValue(key:  this.clrType, value: out  val_3);
            label_4:
            // 0x010F3C58: LDR x0, [x19]              |  //  not_find_field!1:0
            val_6 = mem[this.valueTypeBinder];
            label_2:
            // 0x010F3C5C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3C60: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F3C64: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F3C68: RET                        |  return (ILRuntime.Runtime.Enviorment.ValueTypeBinder)mem[this.valueTypeBinder];
            return (ILRuntime.Runtime.Enviorment.ValueTypeBinder)val_6;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Enviorment.ValueTypeBinder, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3C6C (17775724), len: 536  VirtAddr: 0x010F3C6C RVA: 0x010F3C6C token: 100663442 methodIndex: 28875 delegateWrapperIndex: 0 methodInvoker: 0
        public object PerformMemberwiseClone(object target)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate val_12;
            //  | 
            System.Type val_13;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate val_14;
            //  | 
            System.Reflection.MethodInfo val_15;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate val_16;
            // 0x010F3C6C: STP x24, x23, [sp, #-0x40]! | stack[1152921509998464736] = ???;  stack[1152921509998464744] = ???;  //  dest_result_addr=1152921509998464736 |  dest_result_addr=1152921509998464744
            // 0x010F3C70: STP x22, x21, [sp, #0x10]  | stack[1152921509998464752] = ???;  stack[1152921509998464760] = ???;  //  dest_result_addr=1152921509998464752 |  dest_result_addr=1152921509998464760
            // 0x010F3C74: STP x20, x19, [sp, #0x20]  | stack[1152921509998464768] = ???;  stack[1152921509998464776] = ???;  //  dest_result_addr=1152921509998464768 |  dest_result_addr=1152921509998464776
            // 0x010F3C78: STP x29, x30, [sp, #0x30]  | stack[1152921509998464784] = ???;  stack[1152921509998464792] = ???;  //  dest_result_addr=1152921509998464784 |  dest_result_addr=1152921509998464792
            // 0x010F3C7C: ADD x29, sp, #0x30         | X29 = (1152921509998464736 + 48) = 1152921509998464784 (0x10000001415D8F10);
            // 0x010F3C80: SUB sp, sp, #0x10          | SP = (1152921509998464736 - 16) = 1152921509998464720 (0x10000001415D8ED0);
            // 0x010F3C84: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x010F3C88: LDRB w8, [x19, #0xafc]     | W8 = (bool)static_value_03735AFC;       
            // 0x010F3C8C: MOV x20, x0                | X20 = 1152921509998476800 (0x10000001415DBE00);//ML01
            // 0x010F3C90: STR x1, [sp, #8]           | stack[1152921509998464728] = target;     //  dest_result_addr=1152921509998464728
            object val_6 = target;
            // 0x010F3C94: TBNZ w8, #0, #0x10f3cb0    | if (static_value_03735AFC == true) goto label_0;
            // 0x010F3C98: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x010F3C9C: LDR x8, [x8, #0x3f0]       | X8 = 0x2B90D70;                         
            // 0x010F3CA0: LDR w0, [x8]               | W0 = 0x1A20;                            
            // 0x010F3CA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A20, ????);     
            // 0x010F3CA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3CAC: STRB w8, [x19, #0xafc]     | static_value_03735AFC = true;            //  dest_result_addr=57891580
            label_0:
            // 0x010F3CB0: MOV x19, x20               | X19 = 1152921509998476800 (0x10000001415DBE00);//ML01
            // 0x010F3CB4: LDR x22, [x19, #0x78]!     | X22 = this.memberwiseCloneDelegate; //P2 
            val_12 = this.memberwiseCloneDelegate;
            // 0x010F3CB8: CBNZ x22, #0x10f3db8       | if (this.memberwiseCloneDelegate != null) goto label_10;
            if(val_12 != null)
            {
                goto label_10;
            }
            // 0x010F3CBC: LDR x21, [x20, #0x28]      | X21 = this.appdomain; //P2              
            // 0x010F3CC0: CBNZ x21, #0x10f3cc8       | if (this.appdomain != null) goto label_2;
            if(this.appdomain != null)
            {
                goto label_2;
            }
            // 0x010F3CC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A20, ????);     
            label_2:
            // 0x010F3CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F3CCC: MOV x0, x21                | X0 = this.appdomain;//m1                
            // 0x010F3CD0: BL #0x28e4350              | X0 = this.appdomain.get_MemberwiseCloneMap();
            System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate> val_1 = this.appdomain.MemberwiseCloneMap;
            // 0x010F3CD4: LDR x21, [x20, #0x10]      | X21 = this.clrType; //P2                
            val_13 = this.clrType;
            // 0x010F3CD8: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x010F3CDC: CBNZ x22, #0x10f3ce4       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x010F3CE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x010F3CE4: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x010F3CE8: LDR x8, [x8, #0x528]       | X8 = 1152921509998428992;               
            // 0x010F3CEC: MOV x0, x22                | X0 = val_1;//m1                         
            // 0x010F3CF0: MOV x1, x21                | X1 = this.clrType;//m1                  
            // 0x010F3CF4: MOV x2, x19                | X2 = 1152921509998476920 (0x10000001415DBE78);//ML01
            // 0x010F3CF8: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate>::TryGetValue(System.Type key, out ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate value);
            // 0x010F3CFC: BL #0x23fe7ec              | X0 = val_1.TryGetValue(key:  val_13, value: out  val_12 = this.memberwiseCloneDelegate);
            bool val_2 = val_1.TryGetValue(key:  val_13, value: out  val_12);
            // 0x010F3D00: TBZ w0, #0, #0x10f3d0c     | if (val_2 == false) goto label_4;       
            if(val_2 == false)
            {
                goto label_4;
            }
            // 0x010F3D04: LDR x22, [x19]             | X22 = this.memberwiseCloneDelegate;     
            val_14 = val_12;
            // 0x010F3D08: B #0x10f3dac               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x010F3D0C: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x010F3D10: LDR x8, [x8, #0x10]        | X8 = 1152921504782086144;               
            // 0x010F3D14: LDR x0, [x8]               | X0 = typeof(CLRType.<PerformMemberwiseClone>c__AnonStorey0);
            object val_3 = null;
            // 0x010F3D18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CLRType.<PerformMemberwiseClone>c__AnonStorey0), ????);
            // 0x010F3D1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F3D20: MOV x21, x0                | X21 = 1152921504782086144 (0x100000000A71F000);//ML01
            val_13 = val_3;
            // 0x010F3D24: BL #0x16f59f0              | .ctor();                                
            val_3 = new System.Object();
            // 0x010F3D28: LDR x22, [x20, #0x10]      | X22 = this.clrType; //P2                
            // 0x010F3D2C: CBNZ x22, #0x10f3d34       | if (this.clrType != null) goto label_6; 
            if(this.clrType != null)
            {
                goto label_6;
            }
            // 0x010F3D30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_6:
            // 0x010F3D34: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x010F3D38: LDR x8, [x8, #0xc58]       | X8 = (string**)(1152921509998434112)("MemberwiseClone");
            // 0x010F3D3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F3D40: MOVZ w2, #0x24             | W2 = 36 (0x24);//ML01                   
            // 0x010F3D44: MOV x0, x22                | X0 = this.clrType;//m1                  
            // 0x010F3D48: LDR x1, [x8]               | X1 = "MemberwiseClone";                 
            // 0x010F3D4C: BL #0x1b6e098              | X0 = this.clrType.GetMethod(name:  "MemberwiseClone", bindingAttr:  36);
            System.Reflection.MethodInfo val_4 = this.clrType.GetMethod(name:  "MemberwiseClone", bindingAttr:  36);
            // 0x010F3D50: MOV x22, x0                | X22 = val_4;//m1                        
            val_15 = val_4;
            // 0x010F3D54: CBZ x21, #0x10f3d60        | if ( == 0) goto label_7;                
            if(null == 0)
            {
                goto label_7;
            }
            // 0x010F3D58: STR x22, [x21, #0x10]      | typeof(CLRType.<PerformMemberwiseClone>c__AnonStorey0).__il2cppRuntimeField_10 = val_4;  //  dest_result_addr=1152921504782086160
            typeof(CLRType.<PerformMemberwiseClone>c__AnonStorey0).__il2cppRuntimeField_10 = val_15;
            // 0x010F3D5C: B #0x10f3d74               |  goto label_8;                          
            goto label_8;
            label_7:
            // 0x010F3D60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x010F3D64: ORR w23, wzr, #0x10        | W23 = 16(0x10);                         
            // 0x010F3D68: STR x22, [x23]             | mem[16] = val_4;                         //  dest_result_addr=16
            mem[16] = val_15;
            // 0x010F3D6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x010F3D70: LDR x22, [x23]             | X22 = val_4;                            
            val_15 = mem[16];
            label_8:
            // 0x010F3D74: CBZ x22, #0x10f3de0        | if (val_4 == 0) goto label_9;           
            if(val_15 == 0)
            {
                goto label_9;
            }
            // 0x010F3D78: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x010F3D7C: ADRP x9, #0x35fd000        | X9 = 56610816 (0x35FD000);              
            // 0x010F3D80: LDR x8, [x8, #0xe10]       | X8 = 1152921509998438320;               
            // 0x010F3D84: LDR x9, [x9, #0xf08]       | X9 = 1152921504824098816;               
            // 0x010F3D88: LDR x20, [x8]              | X20 = System.Object CLRType.<PerformMemberwiseClone>c__AnonStorey0::<>m__0(ref object t);
            // 0x010F3D8C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate);
            ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate val_5 = null;
            // 0x010F3D90: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate), ????);
            // 0x010F3D94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F3D98: MOV x1, x21                | X1 = 1152921504782086144 (0x100000000A71F000);//ML01
            // 0x010F3D9C: MOV x2, x20                | X2 = 1152921509998438320 (0x10000001415D27B0);//ML01
            // 0x010F3DA0: MOV x22, x0                | X22 = 1152921504824098816 (0x100000000CF30000);//ML01
            val_16 = val_5;
            // 0x010F3DA4: BL #0x28e94e4              | .ctor(object:  val_13, method:  System.Object CLRType.<PerformMemberwiseClone>c__AnonStorey0::<>m__0(ref object t));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate(object:  val_13, method:  System.Object CLRType.<PerformMemberwiseClone>c__AnonStorey0::<>m__0(ref object t));
            // 0x010F3DA8: STR x22, [x19]             | this.memberwiseCloneDelegate = typeof(ILRuntime.Runtime.Enviorment.CLRMemberwiseCloneDelegate);  //  dest_result_addr=1152921509998476920
            this.memberwiseCloneDelegate = val_16;
            label_5:
            // 0x010F3DAC: CBNZ x22, #0x10f3db8       | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x010F3DB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_13, method:  System.Object CLRType.<PerformMemberwiseClone>c__AnonStorey0::<>m__0(ref object t)), ????);
            // 0x010F3DB4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_12 = 0;
            label_10:
            // 0x010F3DB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F3DBC: ADD x1, sp, #8             | X1 = (1152921509998464720 + 8) = 1152921509998464728 (0x10000001415D8ED8);
            // 0x010F3DC0: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x010F3DC4: BL #0x28e94f4              | X0 = val_12.Invoke(target: ref  object val_6 = target);
            object val_7 = val_12.Invoke(target: ref  val_6);
            // 0x010F3DC8: SUB sp, x29, #0x30         | SP = (1152921509998464784 - 48) = 1152921509998464736 (0x10000001415D8EE0);
            // 0x010F3DCC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3DD0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010F3DD4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010F3DD8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010F3DDC: RET                        |  return (System.Object)val_7;           
            return val_7;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_9:
            // 0x010F3DE0: LDR x19, [x20, #0x10]      | X19 = this.clrType; //P2                
            // 0x010F3DE4: CBNZ x19, #0x10f3dec       | if (this.clrType != null) goto label_11;
            if(this.clrType != null)
            {
                goto label_11;
            }
            // 0x010F3DE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_11:
            // 0x010F3DEC: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x010F3DF0: MOV x0, x19                | X0 = this.clrType;//m1                  
            // 0x010F3DF4: LDR x9, [x8, #0x230]       | X9 = typeof(System.Type).__il2cppRuntimeField_230;
            // 0x010F3DF8: LDR x1, [x8, #0x238]       | X1 = typeof(System.Type).__il2cppRuntimeField_238;
            // 0x010F3DFC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_230();
            // 0x010F3E00: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x010F3E04: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x010F3E08: MOV x19, x0                | X19 = this.clrType;//m1                 
            // 0x010F3E0C: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x010F3E10: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x010F3E14: TBZ w9, #0, #0x10f3e28     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x010F3E18: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x010F3E1C: CBNZ w9, #0x10f3e28        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x010F3E20: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x010F3E24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_13:
            // 0x010F3E28: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x010F3E2C: LDR x8, [x8, #0xb0]        | X8 = (string**)(1152921509998447536)("Memberwise clone method not found for ");
            // 0x010F3E30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F3E34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F3E38: MOV x2, x19                | X2 = this.clrType;//m1                  
            // 0x010F3E3C: LDR x1, [x8]               | X1 = "Memberwise clone method not found for ";
            // 0x010F3E40: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "Memberwise clone method not found for ");
            string val_8 = System.String.Concat(str0:  0, str1:  "Memberwise clone method not found for ");
            // 0x010F3E44: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x010F3E48: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x010F3E4C: MOV x19, x0                | X19 = val_8;//m1                        
            // 0x010F3E50: LDR x8, [x8]               | X8 = typeof(System.InvalidOperationException);
            // 0x010F3E54: MOV x0, x8                 | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            System.InvalidOperationException val_9 = null;
            // 0x010F3E58: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x010F3E5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F3E60: MOV x1, x19                | X1 = val_8;//m1                         
            // 0x010F3E64: MOV x20, x0                | X20 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x010F3E68: BL #0x1e6648c              | .ctor(message:  val_8);                 
            val_9 = new System.InvalidOperationException(message:  val_8);
            // 0x010F3E6C: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x010F3E70: LDR x8, [x8, #0xaa8]       | X8 = 1152921509998451776;               
            // 0x010F3E74: MOV x0, x20                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_10 = val_9;
            // 0x010F3E78: LDR x1, [x8]               | X1 = public System.Object ILRuntime.CLR.TypeSystem.CLRType::PerformMemberwiseClone(object target);
            // 0x010F3E7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x010F3E80: BL #0x10ec5ac              | .ctor(def:  public System.Object ILRuntime.CLR.TypeSystem.CLRType::PerformMemberwiseClone(object target), type:  0, domain:  0);
            val_10 = new ILRuntime.CLR.Method.CLRMethod(def:  public System.Object ILRuntime.CLR.TypeSystem.CLRType::PerformMemberwiseClone(object target), type:  0, domain:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3670 (17774192), len: 888  VirtAddr: 0x010F3670 RVA: 0x010F3670 token: 100663443 methodIndex: 28876 delegateWrapperIndex: 0 methodInvoker: 0
        private void InitializeBaseType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x010F3670: STP x24, x23, [sp, #-0x40]! | stack[1152921509998658656] = ???;  stack[1152921509998658664] = ???;  //  dest_result_addr=1152921509998658656 |  dest_result_addr=1152921509998658664
            // 0x010F3674: STP x22, x21, [sp, #0x10]  | stack[1152921509998658672] = ???;  stack[1152921509998658680] = ???;  //  dest_result_addr=1152921509998658672 |  dest_result_addr=1152921509998658680
            // 0x010F3678: STP x20, x19, [sp, #0x20]  | stack[1152921509998658688] = ???;  stack[1152921509998658696] = ???;  //  dest_result_addr=1152921509998658688 |  dest_result_addr=1152921509998658696
            // 0x010F367C: STP x29, x30, [sp, #0x30]  | stack[1152921509998658704] = ???;  stack[1152921509998658712] = ???;  //  dest_result_addr=1152921509998658704 |  dest_result_addr=1152921509998658712
            // 0x010F3680: ADD x29, sp, #0x30         | X29 = (1152921509998658656 + 48) = 1152921509998658704 (0x1000000141608490);
            // 0x010F3684: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F3688: LDRB w8, [x20, #0xafd]     | W8 = (bool)static_value_03735AFD;       
            // 0x010F368C: MOV x19, x0                | X19 = 1152921509998670720 (0x100000014160B380);//ML01
            // 0x010F3690: TBNZ w8, #0, #0x10f36ac    | if (static_value_03735AFD == true) goto label_0;
            // 0x010F3694: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x010F3698: LDR x8, [x8, #0xd18]       | X8 = 0x2B90D50;                         
            // 0x010F369C: LDR w0, [x8]               | W0 = 0x1A18;                            
            // 0x010F36A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A18, ????);     
            // 0x010F36A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F36A8: STRB w8, [x20, #0xafd]     | static_value_03735AFD = true;            //  dest_result_addr=57891581
            label_0:
            // 0x010F36AC: LDR x20, [x19, #0x28]      | X20 = this.appdomain; //P2              
            // 0x010F36B0: LDR x21, [x19, #0x10]      | X21 = this.clrType; //P2                
            // 0x010F36B4: CBNZ x21, #0x10f36bc       | if (this.clrType != null) goto label_1; 
            if(this.clrType != null)
            {
                goto label_1;
            }
            // 0x010F36B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A18, ????);     
            label_1:
            // 0x010F36BC: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x010F36C0: MOV x0, x21                | X0 = this.clrType;//m1                  
            // 0x010F36C4: LDR x9, [x8, #0x220]       | X9 = typeof(System.Type).__il2cppRuntimeField_220;
            // 0x010F36C8: LDR x1, [x8, #0x228]       | X1 = typeof(System.Type).__il2cppRuntimeField_228;
            // 0x010F36CC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_220();
            // 0x010F36D0: MOV x21, x0                | X21 = this.clrType;//m1                 
            // 0x010F36D4: CBNZ x20, #0x10f36dc       | if (this.appdomain != null) goto label_2;
            if(this.appdomain != null)
            {
                goto label_2;
            }
            // 0x010F36D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.clrType, ????);
            label_2:
            // 0x010F36DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F36E0: MOV x0, x20                | X0 = this.appdomain;//m1                
            // 0x010F36E4: MOV x1, x21                | X1 = this.clrType;//m1                  
            // 0x010F36E8: BL #0x28e5da8              | X0 = this.appdomain.GetType(t:  this.clrType);
            ILRuntime.CLR.TypeSystem.IType val_1 = this.appdomain.GetType(t:  this.clrType);
            // 0x010F36EC: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x010F36F0: STR x20, [x19, #0xc0]      | this.baseType = val_1;                   //  dest_result_addr=1152921509998670912
            this.baseType = val_1;
            // 0x010F36F4: CBNZ x20, #0x10f36fc       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x010F36F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x010F36FC: ADRP x22, #0x3679000       | X22 = 57118720 (0x3679000);             
            // 0x010F3700: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F3704: LDR x22, [x22, #0xdf8]     | X22 = 1152921504782245888;              
            // 0x010F3708: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F370C: LDR x1, [x22]              | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F3710: CBZ x9, #0x10f373c         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_4;
            // 0x010F3714: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F3718: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x010F371C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_6:
            // 0x010F3720: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F3724: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F3728: B.EQ #0x10f374c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_5;
            // 0x010F372C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x010F3730: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F3734: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F3738: B.LO #0x10f3720            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_6;
            label_4:
            // 0x010F373C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F3740: MOV x0, x20                | X0 = val_1;//m1                         
            val_10 = val_1;
            // 0x010F3744: BL #0x2776c24              | X0 = sub_2776C24( ?? val_1, ????);      
            // 0x010F3748: B #0x10f375c               |  goto label_7;                          
            goto label_7;
            label_5:
            // 0x010F374C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F3750: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F3754: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F3758: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_7:
            // 0x010F375C: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F3760: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x010F3764: BLR x8                     | X0 = sub_100000000A746000( ?? val_1, ????);
            // 0x010F3768: ADRP x23, #0x3620000       | X23 = 56754176 (0x3620000);             
            // 0x010F376C: LDR x23, [x23, #0x340]     | X23 = 1152921504609562624;              
            // 0x010F3770: ADRP x24, #0x35c8000       | X24 = 56393728 (0x35C8000);             
            // 0x010F3774: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x010F3778: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F377C: LDR x24, [x24, #0x728]     | X24 = 1152921504608923648;              
            // 0x010F3780: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x010F3784: LDR x21, [x24]             | X21 = typeof(System.Enum);              
            val_11 = null;
            // 0x010F3788: TBZ w9, #0, #0x10f379c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x010F378C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x010F3790: CBNZ w9, #0x10f379c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x010F3794: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x010F3798: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_9:
            // 0x010F379C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F37A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F37A4: MOV x1, x21                | X1 = 1152921504608923648 (0x10000000001FB000);//ML01
            // 0x010F37A8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x010F37AC: CMP x20, x0                | STATE = COMPARE(val_1, val_3)           
            // 0x010F37B0: B.EQ #0x10f39c8            | if (val_1 == val_3) goto label_26;      
            if(val_1 == val_3)
            {
                goto label_26;
            }
            // 0x010F37B4: LDR x20, [x19, #0xc0]      | X20 = this.baseType; //P2               
            // 0x010F37B8: CBNZ x20, #0x10f37c0       | if (this.baseType != null) goto label_11;
            if(this.baseType != null)
            {
                goto label_11;
            }
            // 0x010F37BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_11:
            // 0x010F37C0: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F37C4: LDR x1, [x22]              | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F37C8: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F37CC: CBZ x9, #0x10f37f8         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_12;
            // 0x010F37D0: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F37D4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_11 = 0;
            // 0x010F37D8: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_14:
            // 0x010F37DC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F37E0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F37E4: B.EQ #0x10f3808            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_13;
            // 0x010F37E8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x010F37EC: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F37F0: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F37F4: B.LO #0x10f37dc            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_14;
            label_12:
            // 0x010F37F8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F37FC: MOV x0, x20                | X0 = this.baseType;//m1                 
            val_12 = this.baseType;
            // 0x010F3800: BL #0x2776c24              | X0 = sub_2776C24( ?? this.baseType, ????);
            // 0x010F3804: B #0x10f3818               |  goto label_15;                         
            goto label_15;
            label_13:
            // 0x010F3808: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F380C: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F3810: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F3814: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_15:
            // 0x010F3818: LDP x8, x1, [x0]           | X8 = typeof(System.Type);                //  | 
            // 0x010F381C: MOV x0, x20                | X0 = this.baseType;//m1                 
            // 0x010F3820: BLR x8                     | X0 = sub_1000000000297000( ?? this.baseType, ????);
            // 0x010F3824: ADRP x9, #0x363f000        | X9 = 56881152 (0x363F000);              
            // 0x010F3828: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F382C: LDR x9, [x9, #0xa88]       | X9 = 1152921504606900224;               
            // 0x010F3830: MOV x20, x0                | X20 = this.baseType;//m1                
            // 0x010F3834: LDR x21, [x9]              | X21 = typeof(System.Object);            
            val_11 = null;
            // 0x010F3838: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x010F383C: TBZ w9, #0, #0x10f3850     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x010F3840: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x010F3844: CBNZ w9, #0x10f3850        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x010F3848: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x010F384C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_17:
            // 0x010F3850: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F3854: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F3858: MOV x1, x21                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x010F385C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x010F3860: CMP x20, x0                | STATE = COMPARE(this.baseType, val_5)   
            // 0x010F3864: B.EQ #0x10f39c8            | if (this.baseType == val_5) goto label_26;
            if(this.baseType == val_5)
            {
                goto label_26;
            }
            // 0x010F3868: LDR x20, [x19, #0xc0]      | X20 = this.baseType; //P2               
            // 0x010F386C: CBNZ x20, #0x10f3874       | if (this.baseType != null) goto label_19;
            if(this.baseType != null)
            {
                goto label_19;
            }
            // 0x010F3870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_19:
            // 0x010F3874: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F3878: LDR x1, [x22]              | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F387C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F3880: CBZ x9, #0x10f38ac         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_20;
            // 0x010F3884: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F3888: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x010F388C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_22:
            // 0x010F3890: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F3894: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F3898: B.EQ #0x10f38bc            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_21;
            // 0x010F389C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x010F38A0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F38A4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F38A8: B.LO #0x10f3890            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_22;
            label_20:
            // 0x010F38AC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F38B0: MOV x0, x20                | X0 = this.baseType;//m1                 
            val_13 = this.baseType;
            // 0x010F38B4: BL #0x2776c24              | X0 = sub_2776C24( ?? this.baseType, ????);
            // 0x010F38B8: B #0x10f38cc               |  goto label_23;                         
            goto label_23;
            label_21:
            // 0x010F38BC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F38C0: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F38C4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F38C8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_23:
            // 0x010F38CC: LDP x8, x1, [x0]           | X8 = typeof(System.Type);                //  | 
            // 0x010F38D0: MOV x0, x20                | X0 = this.baseType;//m1                 
            // 0x010F38D4: BLR x8                     | X0 = sub_1000000000297000( ?? this.baseType, ????);
            // 0x010F38D8: ADRP x9, #0x35be000        | X9 = 56352768 (0x35BE000);              
            // 0x010F38DC: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F38E0: LDR x9, [x9, #0xf10]       | X9 = 1152921504606953472;               
            // 0x010F38E4: MOV x20, x0                | X20 = this.baseType;//m1                
            // 0x010F38E8: LDR x21, [x9]              | X21 = typeof(System.ValueType);         
            val_11 = null;
            // 0x010F38EC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x010F38F0: TBZ w9, #0, #0x10f3904     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x010F38F4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x010F38F8: CBNZ w9, #0x10f3904        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x010F38FC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x010F3900: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_25:
            // 0x010F3904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F3908: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F390C: MOV x1, x21                | X1 = 1152921504606953472 (0x100000000001A000);//ML01
            // 0x010F3910: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x010F3914: CMP x20, x0                | STATE = COMPARE(this.baseType, val_7)   
            // 0x010F3918: B.EQ #0x10f39c8            | if (this.baseType == val_7) goto label_26;
            if(this.baseType == val_7)
            {
                goto label_26;
            }
            // 0x010F391C: LDR x20, [x19, #0xc0]      | X20 = this.baseType; //P2               
            // 0x010F3920: CBNZ x20, #0x10f3928       | if (this.baseType != null) goto label_27;
            if(this.baseType != null)
            {
                goto label_27;
            }
            // 0x010F3924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_27:
            // 0x010F3928: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F392C: LDR x1, [x22]              | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F3930: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F3934: CBZ x9, #0x10f3960         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_28;
            // 0x010F3938: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F393C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x010F3940: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_30:
            // 0x010F3944: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F3948: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F394C: B.EQ #0x10f3970            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_29;
            // 0x010F3950: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x010F3954: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F3958: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F395C: B.LO #0x10f3944            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_30;
            label_28:
            // 0x010F3960: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F3964: MOV x0, x20                | X0 = this.baseType;//m1                 
            val_14 = this.baseType;
            // 0x010F3968: BL #0x2776c24              | X0 = sub_2776C24( ?? this.baseType, ????);
            // 0x010F396C: B #0x10f3980               |  goto label_31;                         
            goto label_31;
            label_29:
            // 0x010F3970: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F3974: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F3978: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F397C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_31:
            // 0x010F3980: LDP x8, x1, [x0]           | X8 = typeof(System.Type);                //  | 
            // 0x010F3984: MOV x0, x20                | X0 = this.baseType;//m1                 
            // 0x010F3988: BLR x8                     | X0 = sub_1000000000297000( ?? this.baseType, ????);
            // 0x010F398C: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F3990: LDR x21, [x24]             | X21 = typeof(System.Enum);              
            val_11 = null;
            // 0x010F3994: MOV x20, x0                | X20 = this.baseType;//m1                
            // 0x010F3998: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x010F399C: TBZ w9, #0, #0x10f39b0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x010F39A0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x010F39A4: CBNZ w9, #0x10f39b0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x010F39A8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x010F39AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_33:
            // 0x010F39B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F39B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F39B8: MOV x1, x21                | X1 = 1152921504608923648 (0x10000000001FB000);//ML01
            // 0x010F39BC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x010F39C0: CMP x20, x0                | STATE = COMPARE(this.baseType, val_9)   
            // 0x010F39C4: B.NE #0x10f39cc            | if (this.baseType != val_9) goto label_34;
            if(this.baseType != val_9)
            {
                goto label_34;
            }
            label_26:
            // 0x010F39C8: STR xzr, [x19, #0xc0]      | this.baseType = null;                    //  dest_result_addr=1152921509998670912
            this.baseType = 0;
            label_34:
            // 0x010F39CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F39D0: STRB w8, [x19, #0xc8]      | this.isBaseTypeInitialized = true;       //  dest_result_addr=1152921509998670920
            this.isBaseTypeInitialized = true;
            // 0x010F39D4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010F39D8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010F39DC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010F39E0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010F39E4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3A18 (17775128), len: 388  VirtAddr: 0x010F3A18 RVA: 0x010F3A18 token: 100663444 methodIndex: 28877 delegateWrapperIndex: 0 methodInvoker: 0
        private void InitializeInterfaces()
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.CLR.TypeSystem.IType[] val_4;
            //  | 
            var val_5;
            // 0x010F3A18: STP x26, x25, [sp, #-0x50]! | stack[1152921509998897616] = ???;  stack[1152921509998897624] = ???;  //  dest_result_addr=1152921509998897616 |  dest_result_addr=1152921509998897624
            // 0x010F3A1C: STP x24, x23, [sp, #0x10]  | stack[1152921509998897632] = ???;  stack[1152921509998897640] = ???;  //  dest_result_addr=1152921509998897632 |  dest_result_addr=1152921509998897640
            // 0x010F3A20: STP x22, x21, [sp, #0x20]  | stack[1152921509998897648] = ???;  stack[1152921509998897656] = ???;  //  dest_result_addr=1152921509998897648 |  dest_result_addr=1152921509998897656
            // 0x010F3A24: STP x20, x19, [sp, #0x30]  | stack[1152921509998897664] = ???;  stack[1152921509998897672] = ???;  //  dest_result_addr=1152921509998897664 |  dest_result_addr=1152921509998897672
            // 0x010F3A28: STP x29, x30, [sp, #0x40]  | stack[1152921509998897680] = ???;  stack[1152921509998897688] = ???;  //  dest_result_addr=1152921509998897680 |  dest_result_addr=1152921509998897688
            // 0x010F3A2C: ADD x29, sp, #0x40         | X29 = (1152921509998897616 + 64) = 1152921509998897680 (0x1000000141642A10);
            // 0x010F3A30: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F3A34: LDRB w8, [x20, #0xafe]     | W8 = (bool)static_value_03735AFE;       
            // 0x010F3A38: MOV x19, x0                | X19 = 1152921509998909696 (0x1000000141645900);//ML01
            // 0x010F3A3C: TBNZ w8, #0, #0x10f3a58    | if (static_value_03735AFE == true) goto label_0;
            // 0x010F3A40: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x010F3A44: LDR x8, [x8, #0x8c0]       | X8 = 0x2B90D58;                         
            // 0x010F3A48: LDR w0, [x8]               | W0 = 0x1A1A;                            
            // 0x010F3A4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A1A, ????);     
            // 0x010F3A50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3A54: STRB w8, [x20, #0xafe]     | static_value_03735AFE = true;            //  dest_result_addr=57891582
            label_0:
            // 0x010F3A58: LDR x20, [x19, #0x10]      | X20 = this.clrType; //P2                
            // 0x010F3A5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3A60: STRB w8, [x19, #0xc9]      | this.interfaceInitialized = true;        //  dest_result_addr=1152921509998909897
            this.interfaceInitialized = true;
            // 0x010F3A64: CBNZ x20, #0x10f3a6c       | if (this.clrType != null) goto label_1; 
            if(this.clrType != null)
            {
                goto label_1;
            }
            // 0x010F3A68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A1A, ????);     
            label_1:
            // 0x010F3A6C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x010F3A70: MOV x0, x20                | X0 = this.clrType;//m1                  
            // 0x010F3A74: LDR x9, [x8, #0x3d0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3D0;
            // 0x010F3A78: LDR x1, [x8, #0x3d8]       | X1 = typeof(System.Type).__il2cppRuntimeField_3D8;
            // 0x010F3A7C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3D0();
            // 0x010F3A80: MOV x20, x0                | X20 = this.clrType;//m1                 
            // 0x010F3A84: CBNZ x20, #0x10f3a8c       | if (this.clrType != null) goto label_2; 
            if(this.clrType != null)
            {
                goto label_2;
            }
            // 0x010F3A88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.clrType, ????);
            label_2:
            // 0x010F3A8C: LDR w21, [x20, #0x18]      | 
            // 0x010F3A90: CMP w21, #1                | STATE = COMPARE(W21, 0x1)               
            // 0x010F3A94: B.LT #0x10f3b84            | if (W21 < 0x1) goto label_6;            
            if(W21 < 1)
            {
                goto label_6;
            }
            // 0x010F3A98: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x010F3A9C: LDR x8, [x8, #0x8a0]       | X8 = 1152921506369643984;               
            // 0x010F3AA0: LDR x22, [x8]              | X22 = typeof(ILRuntime.CLR.TypeSystem.IType[]);
            // 0x010F3AA4: MOV x0, x22                | X0 = 1152921506369643984 (0x10000000691225D0);//ML01
            // 0x010F3AA8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ILRuntime.CLR.TypeSystem.IType[]), ????);
            // 0x010F3AAC: MOV x0, x22                | X0 = 1152921506369643984 (0x10000000691225D0);//ML01
            // 0x010F3AB0: MOV x1, x21                | X1 = X21;//m1                           
            // 0x010F3AB4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(ILRuntime.CLR.TypeSystem.IType[]), ????);
            // 0x010F3AB8: MOV x21, x0                | X21 = 1152921506369643984 (0x10000000691225D0);//ML01
            val_4 = null;
            // 0x010F3ABC: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x010F3AC0: STR x21, [x19, #0xb0]      | this.interfaces = typeof(ILRuntime.CLR.TypeSystem.IType[]);  //  dest_result_addr=1152921509998909872
            this.interfaces = val_4;
            // 0x010F3AC4: B #0x10f3ad8               |  goto label_4;                          
            goto label_4;
            label_14:
            // 0x010F3AC8: ADD x8, x24, x25, lsl #3   | X8 = (X24 + (X25) << 3);                
            var val_1 = X24 + ((X25) << 3);
            // 0x010F3ACC: STR x21, [x8, #0x20]       | mem2[0] = typeof(ILRuntime.CLR.TypeSystem.IType[]);  //  dest_result_addr=0
            mem2[0] = val_4;
            // 0x010F3AD0: LDR x21, [x19, #0xb0]      | X21 = this.interfaces; //P2             
            val_4 = this.interfaces;
            // 0x010F3AD4: ADD w23, w23, #1           | W23 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            label_4:
            // 0x010F3AD8: CBNZ x21, #0x10f3ae0       | if (this.interfaces != null) goto label_5;
            if(val_4 != null)
            {
                goto label_5;
            }
            // 0x010F3ADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.CLR.TypeSystem.IType[]), ????);
            label_5:
            // 0x010F3AE0: LDR w8, [x21, #0x18]       | W8 = this.interfaces.Length; //P2       
            // 0x010F3AE4: CMP w23, w8                | STATE = COMPARE(0x1, this.interfaces.Length)
            // 0x010F3AE8: B.GE #0x10f3b84            | if (val_5 >= this.interfaces.Length) goto label_6;
            if(val_5 >= this.interfaces.Length)
            {
                goto label_6;
            }
            // 0x010F3AEC: LDR x24, [x19, #0xb0]      | X24 = this.interfaces; //P2             
            // 0x010F3AF0: LDR x21, [x19, #0x28]      | X21 = this.appdomain; //P2              
            // 0x010F3AF4: CBNZ x20, #0x10f3afc       | if (this.clrType != null) goto label_7; 
            if(this.clrType != null)
            {
                goto label_7;
            }
            // 0x010F3AF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.CLR.TypeSystem.IType[]), ????);
            label_7:
            // 0x010F3AFC: LDR w8, [x20, #0x18]       | 
            // 0x010F3B00: SXTW x25, w23              | X25 = 1 (0x00000001);                   
            // 0x010F3B04: CMP w23, w8                | STATE = COMPARE(0x1, this.interfaces.Length)
            // 0x010F3B08: B.LO #0x10f3b18            | if (val_5 < this.interfaces.Length) goto label_8;
            if(val_5 < this.interfaces.Length)
            {
                goto label_8;
            }
            // 0x010F3B0C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ILRuntime.CLR.TypeSystem.IType[]), ????);
            // 0x010F3B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F3B14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ILRuntime.CLR.TypeSystem.IType[]), ????);
            label_8:
            // 0x010F3B18: ADD x8, x20, x25, lsl #3   | X8 = (this.clrType + 8);                
            System.Type val_2 = this.clrType + 8;
            // 0x010F3B1C: LDR x22, [x8, #0x20]       | 
            // 0x010F3B20: CBNZ x21, #0x10f3b28       | if (this.appdomain != null) goto label_9;
            if(this.appdomain != null)
            {
                goto label_9;
            }
            // 0x010F3B24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.CLR.TypeSystem.IType[]), ????);
            label_9:
            // 0x010F3B28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F3B2C: MOV x0, x21                | X0 = this.appdomain;//m1                
            // 0x010F3B30: MOV x1, x22                | X1 = 1152921506369643984 (0x10000000691225D0);//ML01
            // 0x010F3B34: BL #0x28e5da8              | X0 = this.appdomain.GetType(t:  null);  
            ILRuntime.CLR.TypeSystem.IType val_3 = this.appdomain.GetType(t:  null);
            // 0x010F3B38: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x010F3B3C: CBNZ x24, #0x10f3b44       | if (this.interfaces != null) goto label_10;
            if(this.interfaces != null)
            {
                goto label_10;
            }
            // 0x010F3B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x010F3B44: CBZ x21, #0x10f3b68        | if (val_3 == null) goto label_12;       
            if(val_3 == null)
            {
                goto label_12;
            }
            // 0x010F3B48: LDR x8, [x24]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType[]);
            // 0x010F3B4C: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x010F3B50: LDR x1, [x8, #0x30]        | X1 = ILRuntime.CLR.TypeSystem.IType[].__il2cppRuntimeField_element_class;
            // 0x010F3B54: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x010F3B58: CBNZ x0, #0x10f3b68        | if (val_3 != null) goto label_12;       
            if(val_3 != null)
            {
                goto label_12;
            }
            // 0x010F3B5C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
            // 0x010F3B60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F3B64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_12:
            // 0x010F3B68: LDR w8, [x24, #0x18]       | W8 = this.interfaces.Length; //P2       
            // 0x010F3B6C: CMP w23, w8                | STATE = COMPARE(0x1, this.interfaces.Length)
            // 0x010F3B70: B.LO #0x10f3ac8            | if (val_5 < this.interfaces.Length) goto label_14;
            if(val_5 < this.interfaces.Length)
            {
                goto label_14;
            }
            // 0x010F3B74: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x010F3B78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F3B7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x010F3B80: B #0x10f3ac8               |  goto label_14;                         
            goto label_14;
            label_6:
            // 0x010F3B84: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3B88: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x010F3B8C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x010F3B90: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x010F3B94: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x010F3B98: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3E8C (17776268), len: 160  VirtAddr: 0x010F3E8C RVA: 0x010F3E8C token: 100663445 methodIndex: 28878 delegateWrapperIndex: 0 methodInvoker: 0
        public object GetFieldValue(int hash, object target)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            object val_7;
            //  | 
            int val_8;
            //  | 
            var val_9;
            // 0x010F3E8C: STP x22, x21, [sp, #-0x30]! | stack[1152921509999116144] = ???;  stack[1152921509999116152] = ???;  //  dest_result_addr=1152921509999116144 |  dest_result_addr=1152921509999116152
            // 0x010F3E90: STP x20, x19, [sp, #0x10]  | stack[1152921509999116160] = ???;  stack[1152921509999116168] = ???;  //  dest_result_addr=1152921509999116160 |  dest_result_addr=1152921509999116168
            // 0x010F3E94: STP x29, x30, [sp, #0x20]  | stack[1152921509999116176] = ???;  stack[1152921509999116184] = ???;  //  dest_result_addr=1152921509999116176 |  dest_result_addr=1152921509999116184
            // 0x010F3E98: ADD x29, sp, #0x20         | X29 = (1152921509999116144 + 32) = 1152921509999116176 (0x1000000141677F90);
            // 0x010F3E9C: SUB sp, sp, #0x10          | SP = (1152921509999116144 - 16) = 1152921509999116128 (0x1000000141677F60);
            // 0x010F3EA0: MOV x19, x2                | X19 = target;//m1                       
            val_7 = target;
            // 0x010F3EA4: MOV x20, x0                | X20 = 1152921509999128192 (0x100000014167AE80);//ML01
            // 0x010F3EA8: STR x19, [sp, #8]          | stack[1152921509999116136] = target;     //  dest_result_addr=1152921509999116136
            object val_2 = val_7;
            // 0x010F3EAC: LDR x8, [x20, #0x48]       | X8 = this.fieldMapping; //P2            
            // 0x010F3EB0: MOV w21, w1                | W21 = hash;//m1                         
            val_8 = hash;
            // 0x010F3EB4: CBNZ x8, #0x10f3ec0        | if (this.fieldMapping != null) goto label_0;
            if(this.fieldMapping != null)
            {
                goto label_0;
            }
            // 0x010F3EB8: MOV x0, x20                | X0 = 1152921509999128192 (0x100000014167AE80);//ML01
            // 0x010F3EBC: BL #0x10f2bac              | this.InitializeFields();                
            this.InitializeFields();
            label_0:
            // 0x010F3EC0: MOV x0, x20                | X0 = 1152921509999128192 (0x100000014167AE80);//ML01
            // 0x010F3EC4: MOV w1, w21                | W1 = hash;//m1                          
            // 0x010F3EC8: BL #0x10f3f2c              | X0 = this.GetFieldGetter(hash:  val_8); 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_1 = this.GetFieldGetter(hash:  val_8);
            // 0x010F3ECC: CBZ x0, #0x10f3ee0         | if (val_1 == null) goto label_1;        
            if(val_1 == null)
            {
                goto label_1;
            }
            // 0x010F3ED0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F3ED4: ADD x1, sp, #8             | X1 = (1152921509999116128 + 8) = 1152921509999116136 (0x1000000141677F68);
            // 0x010F3ED8: BL #0x28e8fe0              | X0 = val_1.Invoke(target: ref  object val_2 = val_7);
            object val_3 = val_1.Invoke(target: ref  val_2);
            // 0x010F3EDC: B #0x10f3f18               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x010F3EE0: MOV x0, x20                | X0 = 1152921509999128192 (0x100000014167AE80);//ML01
            // 0x010F3EE4: MOV w1, w21                | W1 = hash;//m1                          
            // 0x010F3EE8: BL #0x10eeaec              | X0 = this.GetField(hash:  val_8);       
            System.Reflection.FieldInfo val_4 = this.GetField(hash:  val_8);
            // 0x010F3EEC: CBZ x0, #0x10f3f14         | if (val_4 == null) goto label_3;        
            if(val_4 == null)
            {
                goto label_3;
            }
            // 0x010F3EF0: LDR x8, [x0]               | X8 = typeof(System.Reflection.FieldInfo);
            // 0x010F3EF4: MOV x1, x19                | X1 = target;//m1                        
            // 0x010F3EF8: LDR x3, [x8, #0x220]       | X3 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_220;
            // 0x010F3EFC: LDR x2, [x8, #0x228]       | X2 = typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_228;
            // 0x010F3F00: SUB sp, x29, #0x20         | SP = (1152921509999116176 - 32) = 1152921509999116144 (0x1000000141677F70);
            // 0x010F3F04: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            val_6 = ???;
            // 0x010F3F08: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            val_7 = ???;
            // 0x010F3F0C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            val_8 = ???;
            // 0x010F3F10: BR x3                      | goto typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_220;
            goto typeof(System.Reflection.FieldInfo).__il2cppRuntimeField_220;
            label_3:
            // 0x010F3F14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_9 = 0;
            label_2:
            // 0x010F3F18: SUB sp, x29, #0x20         | SP = (val_6 - 32);                      
            var val_5 = val_6 - 32;
            // 0x010F3F1C: LDP x29, x30, [sp, #0x20]  | X29 = (val_6 - 32) + 32; X30 = (val_6 - 32) + 32 + 8; //  | 
            // 0x010F3F20: LDP x20, x19, [sp, #0x10]  | X20 = (val_6 - 32) + 16; X19 = (val_6 - 32) + 16 + 8; //  | 
            // 0x010F3F24: LDP x22, x21, [sp], #0x30  | X22 = (val_6 - 32); X21 = (val_6 - 32) + 8; //  | 
            // 0x010F3F28: RET                        |  return (System.Object)null;            
            return (object)val_9;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010EECE4 (17755364), len: 144  VirtAddr: 0x010EECE4 RVA: 0x010EECE4 token: 100663446 methodIndex: 28879 delegateWrapperIndex: 0 methodInvoker: 0
        public void SetStaticFieldValue(int hash, object value)
        {
            //
            // Disasemble & Code
            // 0x010EECE4: STP x22, x21, [sp, #-0x30]! | stack[1152921509999265008] = ???;  stack[1152921509999265016] = ???;  //  dest_result_addr=1152921509999265008 |  dest_result_addr=1152921509999265016
            // 0x010EECE8: STP x20, x19, [sp, #0x10]  | stack[1152921509999265024] = ???;  stack[1152921509999265032] = ???;  //  dest_result_addr=1152921509999265024 |  dest_result_addr=1152921509999265032
            // 0x010EECEC: STP x29, x30, [sp, #0x20]  | stack[1152921509999265040] = ???;  stack[1152921509999265048] = ???;  //  dest_result_addr=1152921509999265040 |  dest_result_addr=1152921509999265048
            // 0x010EECF0: ADD x29, sp, #0x20         | X29 = (1152921509999265008 + 32) = 1152921509999265040 (0x100000014169C510);
            // 0x010EECF4: SUB sp, sp, #0x10          | SP = (1152921509999265008 - 16) = 1152921509999264992 (0x100000014169C4E0);
            // 0x010EECF8: MOV x20, x0                | X20 = 1152921509999277056 (0x100000014169F400);//ML01
            // 0x010EECFC: STR xzr, [sp, #8]          | stack[1152921509999265000] = 0x0;        //  dest_result_addr=1152921509999265000
            // 0x010EED00: LDR x8, [x20, #0x48]       | X8 = this.fieldMapping; //P2            
            // 0x010EED04: MOV x19, x2                | X19 = value;//m1                        
            // 0x010EED08: MOV w21, w1                | W21 = hash;//m1                         
            // 0x010EED0C: CBNZ x8, #0x10eed18        | if (this.fieldMapping != null) goto label_0;
            if(this.fieldMapping != null)
            {
                goto label_0;
            }
            // 0x010EED10: MOV x0, x20                | X0 = 1152921509999277056 (0x100000014169F400);//ML01
            // 0x010EED14: BL #0x10f2bac              | this.InitializeFields();                
            this.InitializeFields();
            label_0:
            // 0x010EED18: MOV x0, x20                | X0 = 1152921509999277056 (0x100000014169F400);//ML01
            // 0x010EED1C: MOV w1, w21                | W1 = hash;//m1                          
            // 0x010EED20: BL #0x10f40cc              | X0 = this.GetFieldSetter(hash:  hash);  
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_1 = this.GetFieldSetter(hash:  hash);
            // 0x010EED24: STR xzr, [sp, #8]          | stack[1152921509999265000] = 0x0;        //  dest_result_addr=1152921509999265000
            object val_2 = 0;
            // 0x010EED28: CBZ x0, #0x10eed40         | if (val_1 == null) goto label_1;        
            if(val_1 == null)
            {
                goto label_1;
            }
            // 0x010EED2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010EED30: ADD x1, sp, #8             | X1 = (1152921509999264992 + 8) = 1152921509999265000 (0x100000014169C4E8);
            // 0x010EED34: MOV x2, x19                | X2 = value;//m1                         
            // 0x010EED38: BL #0x28e9250              | val_1.Invoke(target: ref  object val_2 = 0, value:  value);
            val_1.Invoke(target: ref  val_2, value:  value);
            // 0x010EED3C: B #0x10eed60               |  goto label_3;                          
            goto label_3;
            label_1:
            // 0x010EED40: MOV x0, x20                | X0 = 1152921509999277056 (0x100000014169F400);//ML01
            // 0x010EED44: MOV w1, w21                | W1 = hash;//m1                          
            // 0x010EED48: BL #0x10eeaec              | X0 = this.GetField(hash:  hash);        
            System.Reflection.FieldInfo val_3 = this.GetField(hash:  hash);
            // 0x010EED4C: CBZ x0, #0x10eed60         | if (val_3 == null) goto label_3;        
            if(val_3 == null)
            {
                goto label_3;
            }
            // 0x010EED50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EED54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010EED58: MOV x2, x19                | X2 = value;//m1                         
            // 0x010EED5C: BL #0x13bd088              | val_3.SetValue(obj:  0, value:  value); 
            val_3.SetValue(obj:  0, value:  value);
            label_3:
            // 0x010EED60: SUB sp, x29, #0x20         | SP = (1152921509999265040 - 32) = 1152921509999265008 (0x100000014169C4F0);
            // 0x010EED64: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010EED68: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010EED6C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010EED70: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F426C (17777260), len: 152  VirtAddr: 0x010F426C RVA: 0x010F426C token: 100663447 methodIndex: 28880 delegateWrapperIndex: 0 methodInvoker: 0
        public void SetFieldValue(int hash, ref object target, object value)
        {
            //
            // Disasemble & Code
            // 0x010F426C: STP x22, x21, [sp, #-0x30]! | stack[1152921509999413808] = ???;  stack[1152921509999413816] = ???;  //  dest_result_addr=1152921509999413808 |  dest_result_addr=1152921509999413816
            // 0x010F4270: STP x20, x19, [sp, #0x10]  | stack[1152921509999413824] = ???;  stack[1152921509999413832] = ???;  //  dest_result_addr=1152921509999413824 |  dest_result_addr=1152921509999413832
            // 0x010F4274: STP x29, x30, [sp, #0x20]  | stack[1152921509999413840] = ???;  stack[1152921509999413848] = ???;  //  dest_result_addr=1152921509999413840 |  dest_result_addr=1152921509999413848
            // 0x010F4278: ADD x29, sp, #0x20         | X29 = (1152921509999413808 + 32) = 1152921509999413840 (0x10000001416C0A50);
            // 0x010F427C: MOV x21, x0                | X21 = 1152921509999425856 (0x10000001416C3940);//ML01
            // 0x010F4280: LDR x8, [x21, #0x48]       | X8 = this.fieldMapping; //P2            
            // 0x010F4284: MOV x19, x3                | X19 = value;//m1                        
            // 0x010F4288: MOV x20, x2                | X20 = 1152921509999457856 (0x10000001416CB640);//ML01
            // 0x010F428C: MOV w22, w1                | W22 = hash;//m1                         
            // 0x010F4290: CBNZ x8, #0x10f429c        | if (this.fieldMapping != null) goto label_0;
            if(this.fieldMapping != null)
            {
                goto label_0;
            }
            // 0x010F4294: MOV x0, x21                | X0 = 1152921509999425856 (0x10000001416C3940);//ML01
            // 0x010F4298: BL #0x10f2bac              | this.InitializeFields();                
            this.InitializeFields();
            label_0:
            // 0x010F429C: MOV x0, x21                | X0 = 1152921509999425856 (0x10000001416C3940);//ML01
            // 0x010F42A0: MOV w1, w22                | W1 = hash;//m1                          
            // 0x010F42A4: BL #0x10f40cc              | X0 = this.GetFieldSetter(hash:  hash);  
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_1 = this.GetFieldSetter(hash:  hash);
            // 0x010F42A8: CBZ x0, #0x10f42c8         | if (val_1 == null) goto label_1;        
            if(val_1 == null)
            {
                goto label_1;
            }
            // 0x010F42AC: MOV x1, x20                | X1 = 1152921509999457856 (0x10000001416CB640);//ML01
            // 0x010F42B0: MOV x2, x19                | X2 = value;//m1                         
            // 0x010F42B4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F42B8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F42BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F42C0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F42C4: B #0x28e9250               | val_1.Invoke(target: ref  object val_2 = target, value:  value); return;
            val_1.Invoke(target: ref  object val_2 = target, value:  value);
            return;
            label_1:
            // 0x010F42C8: MOV x0, x21                | X0 = 1152921509999425856 (0x10000001416C3940);//ML01
            // 0x010F42CC: MOV w1, w22                | W1 = hash;//m1                          
            // 0x010F42D0: BL #0x10eeaec              | X0 = this.GetField(hash:  hash);        
            System.Reflection.FieldInfo val_3 = this.GetField(hash:  hash);
            // 0x010F42D4: CBZ x0, #0x10f42f4         | if (val_3 == null) goto label_2;        
            if(val_3 == null)
            {
                goto label_2;
            }
            // 0x010F42D8: LDR x1, [x20]              | X1 = target;                            
            // 0x010F42DC: MOV x2, x19                | X2 = value;//m1                         
            // 0x010F42E0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F42E4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F42E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F42EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F42F0: B #0x13bd088               | val_3.SetValue(obj:  val_2, value:  value); return;
            val_3.SetValue(obj:  val_2, value:  value);
            return;
            label_2:
            // 0x010F42F4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F42F8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F42FC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F4300: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F3F2C (17776428), len: 416  VirtAddr: 0x010F3F2C RVA: 0x010F3F2C token: 100663448 methodIndex: 28881 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate GetFieldGetter(int hash)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_9;
            label_14:
            // 0x010F3F2C: STP x22, x21, [sp, #-0x30]! | stack[1152921509999559536] = ???;  stack[1152921509999559544] = ???;  //  dest_result_addr=1152921509999559536 |  dest_result_addr=1152921509999559544
            // 0x010F3F30: STP x20, x19, [sp, #0x10]  | stack[1152921509999559552] = ???;  stack[1152921509999559560] = ???;  //  dest_result_addr=1152921509999559552 |  dest_result_addr=1152921509999559560
            // 0x010F3F34: STP x29, x30, [sp, #0x20]  | stack[1152921509999559568] = ???;  stack[1152921509999559576] = ???;  //  dest_result_addr=1152921509999559568 |  dest_result_addr=1152921509999559576
            // 0x010F3F38: ADD x29, sp, #0x20         | X29 = (1152921509999559536 + 32) = 1152921509999559568 (0x10000001416E4390);
            // 0x010F3F3C: SUB sp, sp, #0x20          | SP = (1152921509999559536 - 32) = 1152921509999559504 (0x10000001416E4350);
            // 0x010F3F40: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F3F44: LDRB w8, [x20, #0xaff]     | W8 = (bool)static_value_03735AFF;       
            // 0x010F3F48: MOV w19, w1                | W19 = hash;//m1                         
            // 0x010F3F4C: MOV x21, x0                | X21 = 1152921509999571584 (0x10000001416E7280);//ML01
            val_7 = this;
            // 0x010F3F50: TBNZ w8, #0, #0x10f3f6c    | if (static_value_03735AFF == true) goto label_0;
            // 0x010F3F54: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x010F3F58: LDR x8, [x8, #0xe48]       | X8 = 0x2B90D30;                         
            // 0x010F3F5C: LDR w0, [x8]               | W0 = 0x1A10;                            
            // 0x010F3F60: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A10, ????);     
            // 0x010F3F64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F3F68: STRB w8, [x20, #0xaff]     | static_value_03735AFF = true;            //  dest_result_addr=57891583
            label_0:
            // 0x010F3F6C: STR xzr, [sp, #8]          | stack[1152921509999559512] = 0x0;        //  dest_result_addr=1152921509999559512
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_1 = 0;
            // 0x010F3F70: LDR x0, [x21, #0x58]       | X0 = this.fieldGetterCache; //P2        
            // 0x010F3F74: CBZ x0, #0x10f3f9c         | if (this.fieldGetterCache == null) goto label_2;
            if(this.fieldGetterCache == null)
            {
                goto label_2;
            }
            // 0x010F3F78: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x010F3F7C: LDR x8, [x8, #0x738]       | X8 = 1152921509999538368;               
            // 0x010F3F80: ADD x2, sp, #8             | X2 = (1152921509999559504 + 8) = 1152921509999559512 (0x10000001416E4358);
            // 0x010F3F84: MOV w1, w19                | W1 = hash;//m1                          
            // 0x010F3F88: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate>::TryGetValue(System.Int32 key, out ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate value);
            // 0x010F3F8C: BL #0x2416950              | X0 = this.fieldGetterCache.TryGetValue(key:  hash, value: out  ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_1 = 0);
            bool val_2 = this.fieldGetterCache.TryGetValue(key:  hash, value: out  val_1);
            // 0x010F3F90: TBZ w0, #0, #0x10f3f9c     | if (val_2 == false) goto label_2;       
            if(val_2 == false)
            {
                goto label_2;
            }
            // 0x010F3F94: LDR x0, [sp, #8]           | X0 = 0x0;                               
            val_8 = val_1;
            // 0x010F3F98: B #0x10f4098               |  goto label_13;                         
            goto label_13;
            label_2:
            // 0x010F3F9C: LDRB w8, [x21, #0xc8]      | W8 = this.isBaseTypeInitialized; //P2   
            // 0x010F3FA0: CBNZ w8, #0x10f3fac        | if (this.isBaseTypeInitialized == true) goto label_4;
            if(this.isBaseTypeInitialized == true)
            {
                goto label_4;
            }
            // 0x010F3FA4: MOV x0, x21                | X0 = 1152921509999571584 (0x10000001416E7280);//ML01
            // 0x010F3FA8: BL #0x10f3670              | this.InitializeBaseType();              
            this.InitializeBaseType();
            label_4:
            // 0x010F3FAC: LDR x20, [x21, #0xc0]      | X20 = this.baseType; //P2               
            val_9 = this.baseType;
            // 0x010F3FB0: CBZ x20, #0x10f407c        | if (this.baseType == null) goto label_5;
            if(val_9 == null)
            {
                goto label_5;
            }
            // 0x010F3FB4: LDRB w8, [x21, #0xc8]      | W8 = this.isBaseTypeInitialized; //P2   
            // 0x010F3FB8: CBNZ w8, #0x10f3fcc        | if (this.isBaseTypeInitialized == true) goto label_6;
            if(this.isBaseTypeInitialized == true)
            {
                goto label_6;
            }
            // 0x010F3FBC: MOV x0, x21                | X0 = 1152921509999571584 (0x10000001416E7280);//ML01
            // 0x010F3FC0: BL #0x10f3670              | this.InitializeBaseType();              
            this.InitializeBaseType();
            // 0x010F3FC4: LDR x20, [x21, #0xc0]      | X20 = this.baseType; //P2               
            val_9 = this.baseType;
            // 0x010F3FC8: CBZ x20, #0x10f4084        | if (this.baseType == null) goto label_7;
            if(val_9 == null)
            {
                goto label_7;
            }
            label_6:
            // 0x010F3FCC: ADRP x21, #0x35c2000       | X21 = 56369152 (0x35C2000);             
            // 0x010F3FD0: LDR x21, [x21, #0x290]     | X21 = 1152921504782032896;              
            val_7 = 1152921504782032896;
            // 0x010F3FD4: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F3FD8: LDR x1, [x21]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F3FDC: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F3FE0: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F3FE4: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F3FE8: B.LO #0x10f4000            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x010F3FEC: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010F3FF0: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010F3FF4: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F3FF8: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F3FFC: B.EQ #0x10f4028            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x010F4000: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x010F4004: ADD x8, sp, #0x10          | X8 = (1152921509999559504 + 16) = 1152921509999559520 (0x10000001416E4360);
            // 0x010F4008: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x010F400C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921509999547584]
            // 0x010F4010: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x010F4014: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F4018: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x010F401C: ADD x0, sp, #0x10          | X0 = (1152921509999559504 + 16) = 1152921509999559520 (0x10000001416E4360);
            // 0x010F4020: BL #0x299a140              | 
            // 0x010F4024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001416E4360, ????);
            label_9:
            // 0x010F4028: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F402C: LDR x1, [x21]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F4030: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F4034: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F4038: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F403C: B.LO #0x10f4054            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x010F4040: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010F4044: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010F4048: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F404C: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F4050: B.EQ #0x10f408c            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x010F4054: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x010F4058: ADD x8, sp, #0x18          | X8 = (1152921509999559504 + 24) = 1152921509999559528 (0x10000001416E4368);
            // 0x010F405C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x010F4060: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921509999547584]
            // 0x010F4064: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x010F4068: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F406C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x010F4070: ADD x0, sp, #0x18          | X0 = (1152921509999559504 + 24) = 1152921509999559528 (0x10000001416E4368);
            // 0x010F4074: BL #0x299a140              | 
            // 0x010F4078: B #0x10f4088               |  goto label_12;                         
            goto label_12;
            label_5:
            // 0x010F407C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x010F4080: B #0x10f4098               |  goto label_13;                         
            goto label_13;
            label_7:
            // 0x010F4084: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_12:
            // 0x010F4088: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_11:
            // 0x010F408C: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            val_8 = val_9;
            // 0x010F4090: MOV w1, w19                | W1 = hash;//m1                          
            // 0x010F4094: BL #0x10f3f2c              |  R0 = label_14();                       
            label_13:
            // 0x010F4098: SUB sp, x29, #0x20         | SP = (1152921509999559568 - 32) = 1152921509999559536 (0x10000001416E4370);
            // 0x010F409C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F40A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F40A4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F40A8: RET                        |  return (ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate)null;
            return (ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate)val_8;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate, size=8, nGRN=0 }
            // 0x010F40AC: MOV x19, x0                | 
            // 0x010F40B0: ADD x0, sp, #0x10          | 
            // 0x010F40B4: B #0x10f40c0               | 
            // 0x010F40B8: MOV x19, x0                | 
            // 0x010F40BC: ADD x0, sp, #0x18          | 
            label_15:
            // 0x010F40C0: BL #0x299a140              | 
            // 0x010F40C4: MOV x0, x19                | 
            // 0x010F40C8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x010F40CC (17776844), len: 416  VirtAddr: 0x010F40CC RVA: 0x010F40CC token: 100663449 methodIndex: 28882 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate GetFieldSetter(int hash)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_9;
            label_14:
            // 0x010F40CC: STP x22, x21, [sp, #-0x30]! | stack[1152921509999697136] = ???;  stack[1152921509999697144] = ???;  //  dest_result_addr=1152921509999697136 |  dest_result_addr=1152921509999697144
            // 0x010F40D0: STP x20, x19, [sp, #0x10]  | stack[1152921509999697152] = ???;  stack[1152921509999697160] = ???;  //  dest_result_addr=1152921509999697152 |  dest_result_addr=1152921509999697160
            // 0x010F40D4: STP x29, x30, [sp, #0x20]  | stack[1152921509999697168] = ???;  stack[1152921509999697176] = ???;  //  dest_result_addr=1152921509999697168 |  dest_result_addr=1152921509999697176
            // 0x010F40D8: ADD x29, sp, #0x20         | X29 = (1152921509999697136 + 32) = 1152921509999697168 (0x1000000141705D10);
            // 0x010F40DC: SUB sp, sp, #0x20          | SP = (1152921509999697136 - 32) = 1152921509999697104 (0x1000000141705CD0);
            // 0x010F40E0: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F40E4: LDRB w8, [x20, #0xb00]     | W8 = (bool)static_value_03735B00;       
            // 0x010F40E8: MOV w19, w1                | W19 = hash;//m1                         
            // 0x010F40EC: MOV x21, x0                | X21 = 1152921509999709184 (0x1000000141708C00);//ML01
            val_7 = this;
            // 0x010F40F0: TBNZ w8, #0, #0x10f410c    | if (static_value_03735B00 == true) goto label_0;
            // 0x010F40F4: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x010F40F8: LDR x8, [x8, #0x70]        | X8 = 0x2B90D38;                         
            // 0x010F40FC: LDR w0, [x8]               | W0 = 0x1A12;                            
            // 0x010F4100: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A12, ????);     
            // 0x010F4104: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F4108: STRB w8, [x20, #0xb00]     | static_value_03735B00 = true;            //  dest_result_addr=57891584
            label_0:
            // 0x010F410C: STR xzr, [sp, #8]          | stack[1152921509999697112] = 0x0;        //  dest_result_addr=1152921509999697112
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_1 = 0;
            // 0x010F4110: LDR x0, [x21, #0x60]       | X0 = this.fieldSetterCache; //P2        
            // 0x010F4114: CBZ x0, #0x10f413c         | if (this.fieldSetterCache == null) goto label_2;
            if(this.fieldSetterCache == null)
            {
                goto label_2;
            }
            // 0x010F4118: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x010F411C: LDR x8, [x8, #0xea0]       | X8 = 1152921509999675968;               
            // 0x010F4120: ADD x2, sp, #8             | X2 = (1152921509999697104 + 8) = 1152921509999697112 (0x1000000141705CD8);
            // 0x010F4124: MOV w1, w19                | W1 = hash;//m1                          
            // 0x010F4128: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate>::TryGetValue(System.Int32 key, out ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate value);
            // 0x010F412C: BL #0x2416950              | X0 = this.fieldSetterCache.TryGetValue(key:  hash, value: out  ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_1 = 0);
            bool val_2 = this.fieldSetterCache.TryGetValue(key:  hash, value: out  val_1);
            // 0x010F4130: TBZ w0, #0, #0x10f413c     | if (val_2 == false) goto label_2;       
            if(val_2 == false)
            {
                goto label_2;
            }
            // 0x010F4134: LDR x0, [sp, #8]           | X0 = 0x0;                               
            val_8 = val_1;
            // 0x010F4138: B #0x10f4238               |  goto label_13;                         
            goto label_13;
            label_2:
            // 0x010F413C: LDRB w8, [x21, #0xc8]      | W8 = this.isBaseTypeInitialized; //P2   
            // 0x010F4140: CBNZ w8, #0x10f414c        | if (this.isBaseTypeInitialized == true) goto label_4;
            if(this.isBaseTypeInitialized == true)
            {
                goto label_4;
            }
            // 0x010F4144: MOV x0, x21                | X0 = 1152921509999709184 (0x1000000141708C00);//ML01
            // 0x010F4148: BL #0x10f3670              | this.InitializeBaseType();              
            this.InitializeBaseType();
            label_4:
            // 0x010F414C: LDR x20, [x21, #0xc0]      | X20 = this.baseType; //P2               
            val_9 = this.baseType;
            // 0x010F4150: CBZ x20, #0x10f421c        | if (this.baseType == null) goto label_5;
            if(val_9 == null)
            {
                goto label_5;
            }
            // 0x010F4154: LDRB w8, [x21, #0xc8]      | W8 = this.isBaseTypeInitialized; //P2   
            // 0x010F4158: CBNZ w8, #0x10f416c        | if (this.isBaseTypeInitialized == true) goto label_6;
            if(this.isBaseTypeInitialized == true)
            {
                goto label_6;
            }
            // 0x010F415C: MOV x0, x21                | X0 = 1152921509999709184 (0x1000000141708C00);//ML01
            // 0x010F4160: BL #0x10f3670              | this.InitializeBaseType();              
            this.InitializeBaseType();
            // 0x010F4164: LDR x20, [x21, #0xc0]      | X20 = this.baseType; //P2               
            val_9 = this.baseType;
            // 0x010F4168: CBZ x20, #0x10f4224        | if (this.baseType == null) goto label_7;
            if(val_9 == null)
            {
                goto label_7;
            }
            label_6:
            // 0x010F416C: ADRP x21, #0x35c2000       | X21 = 56369152 (0x35C2000);             
            // 0x010F4170: LDR x21, [x21, #0x290]     | X21 = 1152921504782032896;              
            val_7 = 1152921504782032896;
            // 0x010F4174: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4178: LDR x1, [x21]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F417C: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F4180: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F4184: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F4188: B.LO #0x10f41a0            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x010F418C: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010F4190: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010F4194: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F4198: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F419C: B.EQ #0x10f41c8            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x010F41A0: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x010F41A4: ADD x8, sp, #0x10          | X8 = (1152921509999697104 + 16) = 1152921509999697120 (0x1000000141705CE0);
            // 0x010F41A8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x010F41AC: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921509999685184]
            // 0x010F41B0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x010F41B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F41B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x010F41BC: ADD x0, sp, #0x10          | X0 = (1152921509999697104 + 16) = 1152921509999697120 (0x1000000141705CE0);
            // 0x010F41C0: BL #0x299a140              | 
            // 0x010F41C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000141705CE0, ????);
            label_9:
            // 0x010F41C8: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F41CC: LDR x1, [x21]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F41D0: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F41D4: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F41D8: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F41DC: B.LO #0x10f41f4            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x010F41E0: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010F41E4: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010F41E8: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F41EC: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F41F0: B.EQ #0x10f422c            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x010F41F4: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x010F41F8: ADD x8, sp, #0x18          | X8 = (1152921509999697104 + 24) = 1152921509999697128 (0x1000000141705CE8);
            // 0x010F41FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x010F4200: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921509999685184]
            // 0x010F4204: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x010F4208: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F420C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x010F4210: ADD x0, sp, #0x18          | X0 = (1152921509999697104 + 24) = 1152921509999697128 (0x1000000141705CE8);
            // 0x010F4214: BL #0x299a140              | 
            // 0x010F4218: B #0x10f4228               |  goto label_12;                         
            goto label_12;
            label_5:
            // 0x010F421C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x010F4220: B #0x10f4238               |  goto label_13;                         
            goto label_13;
            label_7:
            // 0x010F4224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_12:
            // 0x010F4228: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_11:
            // 0x010F422C: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            val_8 = val_9;
            // 0x010F4230: MOV w1, w19                | W1 = hash;//m1                          
            // 0x010F4234: BL #0x10f40cc              |  R0 = label_14();                       
            label_13:
            // 0x010F4238: SUB sp, x29, #0x20         | SP = (1152921509999697168 - 32) = 1152921509999697136 (0x1000000141705CF0);
            // 0x010F423C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F4240: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F4244: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F4248: RET                        |  return (ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate)null;
            return (ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate)val_8;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate, size=8, nGRN=0 }
            // 0x010F424C: MOV x19, x0                | 
            // 0x010F4250: ADD x0, sp, #0x10          | 
            // 0x010F4254: B #0x10f4260               | 
            // 0x010F4258: MOV x19, x0                | 
            // 0x010F425C: ADD x0, sp, #0x18          | 
            label_15:
            // 0x010F4260: BL #0x299a140              | 
            // 0x010F4264: MOV x0, x19                | 
            // 0x010F4268: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x010EEAEC (17754860), len: 440  VirtAddr: 0x010EEAEC RVA: 0x010EEAEC token: 100663450 methodIndex: 28883 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.FieldInfo GetField(int hash)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_9;
            label_15:
            // 0x010EEAEC: STP x22, x21, [sp, #-0x30]! | stack[1152921509999838832] = ???;  stack[1152921509999838840] = ???;  //  dest_result_addr=1152921509999838832 |  dest_result_addr=1152921509999838840
            // 0x010EEAF0: STP x20, x19, [sp, #0x10]  | stack[1152921509999838848] = ???;  stack[1152921509999838856] = ???;  //  dest_result_addr=1152921509999838848 |  dest_result_addr=1152921509999838856
            // 0x010EEAF4: STP x29, x30, [sp, #0x20]  | stack[1152921509999838864] = ???;  stack[1152921509999838872] = ???;  //  dest_result_addr=1152921509999838864 |  dest_result_addr=1152921509999838872
            // 0x010EEAF8: ADD x29, sp, #0x20         | X29 = (1152921509999838832 + 32) = 1152921509999838864 (0x1000000141728690);
            // 0x010EEAFC: SUB sp, sp, #0x20          | SP = (1152921509999838832 - 32) = 1152921509999838800 (0x1000000141728650);
            // 0x010EEB00: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010EEB04: LDRB w8, [x20, #0xb01]     | W8 = (bool)static_value_03735B01;       
            // 0x010EEB08: MOV w19, w1                | W19 = hash;//m1                         
            // 0x010EEB0C: MOV x21, x0                | X21 = 1152921509999850880 (0x100000014172B580);//ML01
            val_7 = this;
            // 0x010EEB10: TBNZ w8, #0, #0x10eeb2c    | if (static_value_03735B01 == true) goto label_0;
            // 0x010EEB14: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x010EEB18: LDR x8, [x8, #0x48]        | X8 = 0x2B90D2C;                         
            // 0x010EEB1C: LDR w0, [x8]               | W0 = 0x1A0F;                            
            // 0x010EEB20: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A0F, ????);     
            // 0x010EEB24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010EEB28: STRB w8, [x20, #0xb01]     | static_value_03735B01 = true;            //  dest_result_addr=57891585
            label_0:
            // 0x010EEB2C: STR xzr, [sp, #8]          | stack[1152921509999838808] = 0x0;        //  dest_result_addr=1152921509999838808
            System.Reflection.FieldInfo val_1 = 0;
            // 0x010EEB30: LDR x8, [x21, #0x48]       | X8 = this.fieldMapping; //P2            
            // 0x010EEB34: CBNZ x8, #0x10eeb40        | if (this.fieldMapping != null) goto label_1;
            if(this.fieldMapping != null)
            {
                goto label_1;
            }
            // 0x010EEB38: MOV x0, x21                | X0 = 1152921509999850880 (0x100000014172B580);//ML01
            // 0x010EEB3C: BL #0x10f2bac              | this.InitializeFields();                
            this.InitializeFields();
            label_1:
            // 0x010EEB40: LDR x20, [x21, #0x50]      | X20 = this.fieldInfoCache; //P2         
            // 0x010EEB44: CBNZ x20, #0x10eeb4c       | if (this.fieldInfoCache != null) goto label_2;
            if(this.fieldInfoCache != null)
            {
                goto label_2;
            }
            // 0x010EEB48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x010EEB4C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x010EEB50: LDR x8, [x8, #0xe20]       | X8 = 1152921509999817664;               
            // 0x010EEB54: ADD x2, sp, #8             | X2 = (1152921509999838800 + 8) = 1152921509999838808 (0x1000000141728658);
            // 0x010EEB58: MOV x0, x20                | X0 = this.fieldInfoCache;//m1           
            // 0x010EEB5C: MOV w1, w19                | W1 = hash;//m1                          
            // 0x010EEB60: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>::TryGetValue(System.Int32 key, out System.Reflection.FieldInfo value);
            // 0x010EEB64: BL #0x2416950              | X0 = this.fieldInfoCache.TryGetValue(key:  hash, value: out  System.Reflection.FieldInfo val_1 = 0);
            bool val_2 = this.fieldInfoCache.TryGetValue(key:  hash, value: out  val_1);
            // 0x010EEB68: TBZ w0, #0, #0x10eeb74     | if (val_2 == false) goto label_3;       
            if(val_2 == false)
            {
                goto label_3;
            }
            // 0x010EEB6C: LDR x0, [sp, #8]           | X0 = 0x0;                               
            val_8 = val_1;
            // 0x010EEB70: B #0x10eec70               |  goto label_14;                         
            goto label_14;
            label_3:
            // 0x010EEB74: LDRB w8, [x21, #0xc8]      | W8 = this.isBaseTypeInitialized; //P2   
            // 0x010EEB78: CBNZ w8, #0x10eeb84        | if (this.isBaseTypeInitialized == true) goto label_5;
            if(this.isBaseTypeInitialized == true)
            {
                goto label_5;
            }
            // 0x010EEB7C: MOV x0, x21                | X0 = 1152921509999850880 (0x100000014172B580);//ML01
            // 0x010EEB80: BL #0x10f3670              | this.InitializeBaseType();              
            this.InitializeBaseType();
            label_5:
            // 0x010EEB84: LDR x20, [x21, #0xc0]      | X20 = this.baseType; //P2               
            val_9 = this.baseType;
            // 0x010EEB88: CBZ x20, #0x10eec54        | if (this.baseType == null) goto label_6;
            if(val_9 == null)
            {
                goto label_6;
            }
            // 0x010EEB8C: LDRB w8, [x21, #0xc8]      | W8 = this.isBaseTypeInitialized; //P2   
            // 0x010EEB90: CBNZ w8, #0x10eeba4        | if (this.isBaseTypeInitialized == true) goto label_7;
            if(this.isBaseTypeInitialized == true)
            {
                goto label_7;
            }
            // 0x010EEB94: MOV x0, x21                | X0 = 1152921509999850880 (0x100000014172B580);//ML01
            // 0x010EEB98: BL #0x10f3670              | this.InitializeBaseType();              
            this.InitializeBaseType();
            // 0x010EEB9C: LDR x20, [x21, #0xc0]      | X20 = this.baseType; //P2               
            val_9 = this.baseType;
            // 0x010EEBA0: CBZ x20, #0x10eec5c        | if (this.baseType == null) goto label_8;
            if(val_9 == null)
            {
                goto label_8;
            }
            label_7:
            // 0x010EEBA4: ADRP x21, #0x35c2000       | X21 = 56369152 (0x35C2000);             
            // 0x010EEBA8: LDR x21, [x21, #0x290]     | X21 = 1152921504782032896;              
            val_7 = 1152921504782032896;
            // 0x010EEBAC: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010EEBB0: LDR x1, [x21]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010EEBB4: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EEBB8: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EEBBC: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EEBC0: B.LO #0x10eebd8            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x010EEBC4: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010EEBC8: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010EEBCC: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010EEBD0: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010EEBD4: B.EQ #0x10eec00            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x010EEBD8: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x010EEBDC: ADD x8, sp, #0x10          | X8 = (1152921509999838800 + 16) = 1152921509999838816 (0x1000000141728660);
            // 0x010EEBE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x010EEBE4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921509999826880]
            // 0x010EEBE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x010EEBEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EEBF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x010EEBF4: ADD x0, sp, #0x10          | X0 = (1152921509999838800 + 16) = 1152921509999838816 (0x1000000141728660);
            // 0x010EEBF8: BL #0x299a140              | 
            // 0x010EEBFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000141728660, ????);
            label_10:
            // 0x010EEC00: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010EEC04: LDR x1, [x21]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010EEC08: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EEC0C: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EEC10: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EEC14: B.LO #0x10eec2c            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_11;
            // 0x010EEC18: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010EEC1C: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010EEC20: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010EEC24: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010EEC28: B.EQ #0x10eec64            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_12;
            label_11:
            // 0x010EEC2C: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x010EEC30: ADD x8, sp, #0x18          | X8 = (1152921509999838800 + 24) = 1152921509999838824 (0x1000000141728668);
            // 0x010EEC34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x010EEC38: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921509999826880]
            // 0x010EEC3C: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x010EEC40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EEC44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x010EEC48: ADD x0, sp, #0x18          | X0 = (1152921509999838800 + 24) = 1152921509999838824 (0x1000000141728668);
            // 0x010EEC4C: BL #0x299a140              | 
            // 0x010EEC50: B #0x10eec60               |  goto label_13;                         
            goto label_13;
            label_6:
            // 0x010EEC54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x010EEC58: B #0x10eec70               |  goto label_14;                         
            goto label_14;
            label_8:
            // 0x010EEC5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_13:
            // 0x010EEC60: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_12:
            // 0x010EEC64: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            val_8 = val_9;
            // 0x010EEC68: MOV w1, w19                | W1 = hash;//m1                          
            // 0x010EEC6C: BL #0x10eeaec              |  R0 = label_15();                       
            label_14:
            // 0x010EEC70: SUB sp, x29, #0x20         | SP = (1152921509999838864 - 32) = 1152921509999838832 (0x1000000141728670);
            // 0x010EEC74: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010EEC78: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010EEC7C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010EEC80: RET                        |  return (System.Reflection.FieldInfo)null;
            return (System.Reflection.FieldInfo)val_8;
            //  |  // // {name=val_0, type=System.Reflection.FieldInfo, size=8, nGRN=0 }
            // 0x010EEC84: MOV x19, x0                | 
            // 0x010EEC88: ADD x0, sp, #0x10          | 
            // 0x010EEC8C: B #0x10eec98               | 
            // 0x010EEC90: MOV x19, x0                | 
            // 0x010EEC94: ADD x0, sp, #0x18          | 
            label_16:
            // 0x010EEC98: BL #0x299a140              | 
            // 0x010EEC9C: MOV x0, x19                | 
            // 0x010EECA0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x010F4304 (17777412), len: 740  VirtAddr: 0x010F4304 RVA: 0x010F4304 token: 100663451 methodIndex: 28884 delegateWrapperIndex: 0 methodInvoker: 0
        private void InitializeMethods()
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x010F4304: STP x28, x27, [sp, #-0x60]! | stack[1152921510000041920] = ???;  stack[1152921510000041928] = ???;  //  dest_result_addr=1152921510000041920 |  dest_result_addr=1152921510000041928
            // 0x010F4308: STP x26, x25, [sp, #0x10]  | stack[1152921510000041936] = ???;  stack[1152921510000041944] = ???;  //  dest_result_addr=1152921510000041936 |  dest_result_addr=1152921510000041944
            // 0x010F430C: STP x24, x23, [sp, #0x20]  | stack[1152921510000041952] = ???;  stack[1152921510000041960] = ???;  //  dest_result_addr=1152921510000041952 |  dest_result_addr=1152921510000041960
            // 0x010F4310: STP x22, x21, [sp, #0x30]  | stack[1152921510000041968] = ???;  stack[1152921510000041976] = ???;  //  dest_result_addr=1152921510000041968 |  dest_result_addr=1152921510000041976
            // 0x010F4314: STP x20, x19, [sp, #0x40]  | stack[1152921510000041984] = ???;  stack[1152921510000041992] = ???;  //  dest_result_addr=1152921510000041984 |  dest_result_addr=1152921510000041992
            // 0x010F4318: STP x29, x30, [sp, #0x50]  | stack[1152921510000042000] = ???;  stack[1152921510000042008] = ???;  //  dest_result_addr=1152921510000042000 |  dest_result_addr=1152921510000042008
            // 0x010F431C: ADD x29, sp, #0x50         | X29 = (1152921510000041920 + 80) = 1152921510000042000 (0x100000014175A010);
            // 0x010F4320: SUB sp, sp, #0x10          | SP = (1152921510000041920 - 16) = 1152921510000041904 (0x1000000141759FB0);
            // 0x010F4324: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F4328: LDRB w8, [x20, #0xb02]     | W8 = (bool)static_value_03735B02;       
            // 0x010F432C: MOV x19, x0                | X19 = 1152921510000054016 (0x100000014175CF00);//ML01
            // 0x010F4330: TBNZ w8, #0, #0x10f434c    | if (static_value_03735B02 == true) goto label_0;
            // 0x010F4334: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x010F4338: LDR x8, [x8, #0x8d0]       | X8 = 0x2B90D5C;                         
            // 0x010F433C: LDR w0, [x8]               | W0 = 0x1A1B;                            
            // 0x010F4340: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A1B, ????);     
            // 0x010F4344: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F4348: STRB w8, [x20, #0xb02]     | static_value_03735B02 = true;            //  dest_result_addr=57891586
            label_0:
            // 0x010F434C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x010F4350: LDR x8, [x8, #0x158]       | X8 = 1152921504615792640;               
            // 0x010F4354: STR xzr, [sp, #8]          | stack[1152921510000041912] = 0x0;        //  dest_result_addr=1152921510000041912
            System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> val_6 = 0;
            // 0x010F4358: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>> val_1 = null;
            // 0x010F435C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x010F4360: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x010F4364: LDR x8, [x8, #0x150]       | X8 = 1152921509999955264;               
            // 0x010F4368: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x010F436C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::.ctor();
            // 0x010F4370: BL #0x23fb0c4              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>();
            // 0x010F4374: STR x20, [x19, #0x20]      | this.methods = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921510000054048
            this.methods = val_1;
            // 0x010F4378: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x010F437C: LDR x8, [x8, #0xcf8]       | X8 = 1152921504616644608;               
            // 0x010F4380: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> val_2 = null;
            // 0x010F4384: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010F4388: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x010F438C: LDR x8, [x8, #0x1a8]       | X8 = 1152921509999956288;               
            // 0x010F4390: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010F4394: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>::.ctor();
            // 0x010F4398: BL #0x25e9474              | .ctor();                                
            val_2 = new System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>();
            // 0x010F439C: LDR x20, [x19, #0x10]      | X20 = this.clrType; //P2                
            // 0x010F43A0: STR x21, [x19, #0x30]      | this.constructors = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921510000054064
            this.constructors = val_2;
            // 0x010F43A4: CBNZ x20, #0x10f43ac       | if (this.clrType != null) goto label_1; 
            if(this.clrType != null)
            {
                goto label_1;
            }
            // 0x010F43A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_1:
            // 0x010F43AC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x010F43B0: ORR w1, wzr, #0x3c         | W1 = 60(0x3C);                          
            // 0x010F43B4: MOV x0, x20                | X0 = this.clrType;//m1                  
            // 0x010F43B8: LDR x9, [x8, #0x540]       | X9 = typeof(System.Type).__il2cppRuntimeField_540;
            // 0x010F43BC: LDR x2, [x8, #0x548]       | X2 = typeof(System.Type).__il2cppRuntimeField_548;
            // 0x010F43C0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_540();
            // 0x010F43C4: ADRP x28, #0x360e000       | X28 = 56680448 (0x360E000);             
            // 0x010F43C8: ADRP x25, #0x3619000       | X25 = 56725504 (0x3619000);             
            // 0x010F43CC: ADRP x26, #0x3607000       | X26 = 56651776 (0x3607000);             
            // 0x010F43D0: LDR x28, [x28, #0x9c0]     | X28 = 1152921509999961408;              
            // 0x010F43D4: LDR x25, [x25, #0xe08]     | X25 = 1152921504781766656;              
            // 0x010F43D8: LDR x26, [x26, #0x838]     | X26 = 1152921509999962432;              
            // 0x010F43DC: MOV x20, x0                | X20 = this.clrType;//m1                 
            // 0x010F43E0: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x010F43E4: B #0x10f43ec               |  goto label_2;                          
            goto label_2;
            label_14:
            // 0x010F43E8: ADD w27, w27, #1           | W27 = (val_13 + 1) = val_13 (0x00000001);
            val_13 = 1;
            label_2:
            // 0x010F43EC: CBNZ x20, #0x10f43f4       | if (this.clrType != null) goto label_3; 
            if(this.clrType != null)
            {
                goto label_3;
            }
            // 0x010F43F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.clrType, ????);
            label_3:
            // 0x010F43F4: LDR w8, [x20, #0x18]       | 
            // 0x010F43F8: CMP w27, w8                | STATE = COMPARE(0x1, typeof(System.Type))
            // 0x010F43FC: B.GE #0x10f4530            | if (val_13 >= typeof(System.Type)) goto label_4;
            if(val_13 >= null)
            {
                goto label_4;
            }
            // 0x010F4400: SXTW x21, w27              | X21 = 1 (0x00000001);                   
            // 0x010F4404: CMP w27, w8                | STATE = COMPARE(0x1, typeof(System.Type))
            // 0x010F4408: B.LO #0x10f4418            | if (val_13 < typeof(System.Type)) goto label_5;
            if(val_13 < null)
            {
                goto label_5;
            }
            // 0x010F440C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.clrType, ????);
            // 0x010F4410: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F4414: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.clrType, ????);
            label_5:
            // 0x010F4418: ADD x8, x20, x21, lsl #3   | X8 = (this.clrType + 8);                
            System.Type val_3 = this.clrType + 8;
            // 0x010F441C: LDR x21, [x8, #0x20]       | 
            // 0x010F4420: CBNZ x21, #0x10f4428       | if (0x1 != 0) goto label_6;             
            if(1 != 0)
            {
                goto label_6;
            }
            // 0x010F4424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.clrType, ????);
            label_6:
            // 0x010F4428: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F442C: MOV x0, x21                | X0 = 1 (0x1);//ML01                     
            // 0x010F4430: BL #0x13be7c0              | X0 = 1.get_IsPrivate();                 
            bool val_4 = 1.IsPrivate;
            // 0x010F4434: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x010F4438: TBNZ w8, #0, #0x10f43e8    | if ((val_4 & 1) == true) goto label_14; 
            if(val_5 == true)
            {
                goto label_14;
            }
            // 0x010F443C: LDR x22, [x19, #0x20]      | X22 = this.methods; //P2                
            // 0x010F4440: CBNZ x21, #0x10f4448       | if (0x1 != 0) goto label_8;             
            if(1 != 0)
            {
                goto label_8;
            }
            // 0x010F4444: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_8:
            // 0x010F4448: LDR x8, [x21]              | X8 = 0x10102464C45;                     
            // 0x010F444C: MOV x0, x21                | X0 = 1 (0x1);//ML01                     
            // 0x010F4450: LDP x9, x1, [x8, #0x190]   | X9 = mem[1103844756949]; X1 = mem[1103844756957]; //  | 
            // 0x010F4454: BLR x9                     | X0 = mem[1103844756949]();              
            // 0x010F4458: MOV x23, x0                | X23 = 1 (0x1);//ML01                    
            // 0x010F445C: CBNZ x22, #0x10f4464       | if (this.methods != null) goto label_9; 
            if(this.methods != null)
            {
                goto label_9;
            }
            // 0x010F4460: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1, ????);        
            label_9:
            // 0x010F4464: LDR x3, [x28]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::TryGetValue(System.String key, out System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> value);
            // 0x010F4468: ADD x2, sp, #8             | X2 = (1152921510000041904 + 8) = 1152921510000041912 (0x1000000141759FB8);
            // 0x010F446C: MOV x0, x22                | X0 = this.methods;//m1                  
            // 0x010F4470: MOV x1, x23                | X1 = 1 (0x1);//ML01                     
            // 0x010F4474: BL #0x23fe7ec              | X0 = this.methods.TryGetValue(key:  1, value: out  System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> val_6 = 0);
            bool val_7 = this.methods.TryGetValue(key:  1, value: out  val_6);
            // 0x010F4478: AND w8, w0, #1             | W8 = (val_7 & 1);                       
            bool val_8 = val_7;
            // 0x010F447C: TBNZ w8, #0, #0x10f44f0    | if ((val_7 & 1) == true) goto label_10; 
            if(val_8 == true)
            {
                goto label_10;
            }
            // 0x010F4480: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x010F4484: LDR x8, [x8, #0xcf8]       | X8 = 1152921504616644608;               
            // 0x010F4488: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> val_9 = null;
            // 0x010F448C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010F4490: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x010F4494: LDR x8, [x8, #0x1a8]       | X8 = 1152921509999956288;               
            // 0x010F4498: MOV x22, x0                | X22 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010F449C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>::.ctor();
            // 0x010F44A0: BL #0x25e9474              | .ctor();                                
            val_9 = new System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>();
            // 0x010F44A4: STR x22, [sp, #8]          | stack[1152921510000041912] = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921510000041912
            // 0x010F44A8: LDR x22, [x19, #0x20]      | X22 = this.methods; //P2                
            // 0x010F44AC: CBNZ x21, #0x10f44b4       | if (0x1 != 0) goto label_11;            
            if(1 != 0)
            {
                goto label_11;
            }
            // 0x010F44B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_11:
            // 0x010F44B4: LDR x8, [x21]              | X8 = 0x10102464C45;                     
            // 0x010F44B8: MOV x0, x21                | X0 = 1 (0x1);//ML01                     
            // 0x010F44BC: LDP x9, x1, [x8, #0x190]   | X9 = mem[1103844756949]; X1 = mem[1103844756957]; //  | 
            // 0x010F44C0: BLR x9                     | X0 = mem[1103844756949]();              
            // 0x010F44C4: LDR x23, [sp, #8]          | X23 = typeof(System.Collections.Generic.List<T>);
            // 0x010F44C8: MOV x24, x0                | X24 = 1 (0x1);//ML01                    
            // 0x010F44CC: CBNZ x22, #0x10f44d4       | if (this.methods != null) goto label_12;
            if(this.methods != null)
            {
                goto label_12;
            }
            // 0x010F44D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1, ????);        
            label_12:
            // 0x010F44D4: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x010F44D8: LDR x8, [x8, #0x718]       | X8 = 1152921509999971648;               
            // 0x010F44DC: MOV x0, x22                | X0 = this.methods;//m1                  
            // 0x010F44E0: MOV x1, x24                | X1 = 1 (0x1);//ML01                     
            // 0x010F44E4: MOV x2, x23                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010F44E8: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::set_Item(System.String key, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> value);
            // 0x010F44EC: BL #0x23fc55c              | this.methods.set_Item(key:  1, value:  val_9);
            this.methods.set_Item(key:  1, value:  val_9);
            label_10:
            // 0x010F44F0: LDR x0, [x25]              | X0 = typeof(ILRuntime.CLR.Method.CLRMethod);
            ILRuntime.CLR.Method.CLRMethod val_10 = null;
            // 0x010F44F4: LDR x22, [sp, #8]          | X22 = typeof(System.Collections.Generic.List<T>);
            // 0x010F44F8: LDR x24, [x19, #0x28]      | X24 = this.appdomain; //P2              
            // 0x010F44FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.CLR.Method.CLRMethod), ????);
            // 0x010F4500: MOV x1, x21                | X1 = 1 (0x1);//ML01                     
            // 0x010F4504: MOV x2, x19                | X2 = 1152921510000054016 (0x100000014175CF00);//ML01
            // 0x010F4508: MOV x3, x24                | X3 = this.appdomain;//m1                
            // 0x010F450C: MOV x23, x0                | X23 = 1152921504781766656 (0x100000000A6D1000);//ML01
            // 0x010F4510: BL #0x10ec5ac              | .ctor(def:  1, type:  this, domain:  this.appdomain);
            val_10 = new ILRuntime.CLR.Method.CLRMethod(def:  1, type:  this, domain:  this.appdomain);
            // 0x010F4514: CBNZ x22, #0x10f451c       | if ( != 0) goto label_13;               
            if(null != 0)
            {
                goto label_13;
            }
            // 0x010F4518: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(def:  1, type:  this, domain:  this.appdomain), ????);
            label_13:
            // 0x010F451C: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>::Add(ILRuntime.CLR.Method.CLRMethod item);
            // 0x010F4520: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010F4524: MOV x1, x23                | X1 = 1152921504781766656 (0x100000000A6D1000);//ML01
            // 0x010F4528: BL #0x25ea480              | Add(item:  val_10);                     
            Add(item:  val_10);
            // 0x010F452C: B #0x10f43e8               |  goto label_14;                         
            goto label_14;
            label_4:
            // 0x010F4530: LDR x20, [x19, #0x10]      | X20 = this.clrType; //P2                
            // 0x010F4534: CBNZ x20, #0x10f453c       | if (this.clrType != null) goto label_15;
            if(this.clrType != null)
            {
                goto label_15;
            }
            // 0x010F4538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.clrType, ????);
            label_15:
            // 0x010F453C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F4540: MOV x0, x20                | X0 = this.clrType;//m1                  
            // 0x010F4544: BL #0x1b6ea28              | X0 = this.clrType.GetConstructors();    
            System.Reflection.ConstructorInfo[] val_11 = this.clrType.GetConstructors();
            // 0x010F4548: MOV x20, x0                | X20 = val_11;//m1                       
            // 0x010F454C: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x010F4550: B #0x10f4568               |  goto label_16;                         
            goto label_16;
            label_21:
            // 0x010F4554: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>::Add(ILRuntime.CLR.Method.CLRMethod item);
            // 0x010F4558: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010F455C: MOV x1, x22                | X1 = X22;//m1                           
            // 0x010F4560: BL #0x25ea480              | Add(item:  X22);                        
            Add(item:  X22);
            // 0x010F4564: ADD w27, w27, #1           | W27 = (val_14 + 1) = val_14 (0x00000001);
            val_14 = 1;
            label_16:
            // 0x010F4568: CBNZ x20, #0x10f4570       | if (val_11 != null) goto label_17;      
            if(val_11 != null)
            {
                goto label_17;
            }
            // 0x010F456C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_17:
            // 0x010F4570: LDR w8, [x20, #0x18]       | W8 = val_11.Length; //P2                
            // 0x010F4574: CMP w27, w8                | STATE = COMPARE(0x1, val_11.Length)     
            // 0x010F4578: B.GE #0x10f45c8            | if (val_14 >= val_11.Length) goto label_18;
            if(val_14 >= val_11.Length)
            {
                goto label_18;
            }
            // 0x010F457C: SXTW x21, w27              | X21 = 1 (0x00000001);                   
            // 0x010F4580: CMP w27, w8                | STATE = COMPARE(0x1, val_11.Length)     
            // 0x010F4584: B.LO #0x10f4594            | if (val_14 < val_11.Length) goto label_19;
            if(val_14 < val_11.Length)
            {
                goto label_19;
            }
            // 0x010F4588: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010F458C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F4590: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_19:
            // 0x010F4594: ADD x8, x20, x21, lsl #3   | X8 = val_11[0x1]; //PARR1               
            // 0x010F4598: LDP x23, x21, [x19, #0x28] | X23 = this.appdomain; //P2  X21 = this.constructors; //P2  //  | 
            // 0x010F459C: LDR x0, [x25]              | X0 = typeof(ILRuntime.CLR.Method.CLRMethod);
            ILRuntime.CLR.Method.CLRMethod val_12 = null;
            // 0x010F45A0: LDR x24, [x8, #0x20]       | X24 = val_11[0x1][0]                    
            System.Reflection.ConstructorInfo val_13 = val_11[1];
            // 0x010F45A4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.CLR.Method.CLRMethod), ????);
            // 0x010F45A8: MOV x1, x24                | X1 = val_11[0x1][0];//m1                
            // 0x010F45AC: MOV x2, x19                | X2 = 1152921510000054016 (0x100000014175CF00);//ML01
            // 0x010F45B0: MOV x3, x23                | X3 = this.appdomain;//m1                
            // 0x010F45B4: MOV x22, x0                | X22 = 1152921504781766656 (0x100000000A6D1000);//ML01
            // 0x010F45B8: BL #0x10ec8d8              | .ctor(def:  val_11[1], type:  this, domain:  this.appdomain);
            val_12 = new ILRuntime.CLR.Method.CLRMethod(def:  val_13, type:  this, domain:  this.appdomain);
            // 0x010F45BC: CBNZ x21, #0x10f4554       | if (this.constructors != null) goto label_21;
            if(this.constructors != null)
            {
                goto label_21;
            }
            // 0x010F45C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(def:  val_11[1], type:  this, domain:  this.appdomain), ????);
            // 0x010F45C4: B #0x10f4554               |  goto label_21;                         
            goto label_21;
            label_18:
            // 0x010F45C8: SUB sp, x29, #0x50         | SP = (1152921510000042000 - 80) = 1152921510000041920 (0x1000000141759FC0);
            // 0x010F45CC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x010F45D0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x010F45D4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x010F45D8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x010F45DC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x010F45E0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x010F45E4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F45E8 (17778152), len: 616  VirtAddr: 0x010F45E8 RVA: 0x010F45E8 token: 100663452 methodIndex: 28885 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.List<ILRuntime.CLR.Method.IMethod> GetMethods()
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            System.Collections.Generic.List<T> val_8;
            //  | 
            var val_9;
            // 0x010F45E8: STP x28, x27, [sp, #-0x60]! | stack[1152921510000247104] = ???;  stack[1152921510000247112] = ???;  //  dest_result_addr=1152921510000247104 |  dest_result_addr=1152921510000247112
            // 0x010F45EC: STP x26, x25, [sp, #0x10]  | stack[1152921510000247120] = ???;  stack[1152921510000247128] = ???;  //  dest_result_addr=1152921510000247120 |  dest_result_addr=1152921510000247128
            // 0x010F45F0: STP x24, x23, [sp, #0x20]  | stack[1152921510000247136] = ???;  stack[1152921510000247144] = ???;  //  dest_result_addr=1152921510000247136 |  dest_result_addr=1152921510000247144
            // 0x010F45F4: STP x22, x21, [sp, #0x30]  | stack[1152921510000247152] = ???;  stack[1152921510000247160] = ???;  //  dest_result_addr=1152921510000247152 |  dest_result_addr=1152921510000247160
            // 0x010F45F8: STP x20, x19, [sp, #0x40]  | stack[1152921510000247168] = ???;  stack[1152921510000247176] = ???;  //  dest_result_addr=1152921510000247168 |  dest_result_addr=1152921510000247176
            // 0x010F45FC: STP x29, x30, [sp, #0x50]  | stack[1152921510000247184] = ???;  stack[1152921510000247192] = ???;  //  dest_result_addr=1152921510000247184 |  dest_result_addr=1152921510000247192
            // 0x010F4600: ADD x29, sp, #0x50         | X29 = (1152921510000247104 + 80) = 1152921510000247184 (0x100000014178C190);
            // 0x010F4604: SUB sp, sp, #0x70          | SP = (1152921510000247104 - 112) = 1152921510000246992 (0x100000014178C0D0);
            // 0x010F4608: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x010F460C: LDRB w8, [x19, #0xb03]     | W8 = (bool)static_value_03735B03;       
            // 0x010F4610: MOV x20, x0                | X20 = 1152921510000259200 (0x100000014178F080);//ML01
            // 0x010F4614: TBNZ w8, #0, #0x10f4630    | if (static_value_03735B03 == true) goto label_0;
            // 0x010F4618: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x010F461C: LDR x8, [x8, #0x390]       | X8 = 0x2B90D48;                         
            // 0x010F4620: LDR w0, [x8]               | W0 = 0x1A16;                            
            // 0x010F4624: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A16, ????);     
            // 0x010F4628: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F462C: STRB w8, [x19, #0xb03]     | static_value_03735B03 = true;            //  dest_result_addr=57891587
            label_0:
            // 0x010F4630: STP xzr, xzr, [sp, #0x60]  | stack[1152921510000247088] = 0x0;  stack[1152921510000247096] = 0x0;  //  dest_result_addr=1152921510000247088 |  dest_result_addr=1152921510000247096
            // 0x010F4634: STP xzr, xzr, [sp, #0x50]  | stack[1152921510000247072] = 0x0;  stack[1152921510000247080] = 0x0;  //  dest_result_addr=1152921510000247072 |  dest_result_addr=1152921510000247080
            // 0x010F4638: STP xzr, xzr, [sp, #0x40]  | stack[1152921510000247056] = 0x0;  stack[1152921510000247064] = 0x0;  //  dest_result_addr=1152921510000247056 |  dest_result_addr=1152921510000247064
            // 0x010F463C: STP xzr, xzr, [sp, #0x28]  | stack[1152921510000247032] = 0x0;  stack[1152921510000247040] = 0x0;  //  dest_result_addr=1152921510000247032 |  dest_result_addr=1152921510000247040
            // 0x010F4640: STR xzr, [sp, #0x20]       | stack[1152921510000247024] = 0x0;        //  dest_result_addr=1152921510000247024
            // 0x010F4644: LDR x8, [x20, #0x20]       | X8 = this.methods; //P2                 
            // 0x010F4648: CBNZ x8, #0x10f4654        | if (this.methods != null) goto label_1; 
            if(this.methods != null)
            {
                goto label_1;
            }
            // 0x010F464C: MOV x0, x20                | X0 = 1152921510000259200 (0x100000014178F080);//ML01
            // 0x010F4650: BL #0x10f4304              | this.InitializeMethods();               
            this.InitializeMethods();
            label_1:
            // 0x010F4654: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x010F4658: LDR x8, [x8, #0x228]       | X8 = 1152921504616644608;               
            // 0x010F465C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<ILRuntime.CLR.Method.IMethod> val_1 = null;
            // 0x010F4660: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010F4664: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x010F4668: LDR x8, [x8, #0x2c0]       | X8 = 1152921510000215744;               
            // 0x010F466C: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010F4670: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.Method.IMethod>::.ctor();
            // 0x010F4674: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<ILRuntime.CLR.Method.IMethod>();
            // 0x010F4678: LDR x20, [x20, #0x20]      | X20 = this.methods; //P2                
            // 0x010F467C: CBNZ x20, #0x10f4684       | if (this.methods != null) goto label_2; 
            if(this.methods != null)
            {
                goto label_2;
            }
            // 0x010F4680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x010F4684: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x010F4688: LDR x8, [x8, #0xbb0]       | X8 = 1152921510000220864;               
            // 0x010F468C: MOV x0, x20                | X0 = this.methods;//m1                  
            // 0x010F4690: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::GetEnumerator();
            // 0x010F4694: ADD x8, sp, #0x40          | X8 = (1152921510000246992 + 64) = 1152921510000247056 (0x100000014178C110);
            // 0x010F4698: BL #0x23ff0fc              | X0 = this.methods.GetEnumerator();      
            Dictionary.Enumerator<TKey, TValue> val_2 = this.methods.GetEnumerator();
            // 0x010F469C: ADRP x23, #0x3679000       | X23 = 57118720 (0x3679000);             
            // 0x010F46A0: ADRP x24, #0x35fb000       | X24 = 56602624 (0x35FB000);             
            // 0x010F46A4: ADRP x27, #0x35e4000       | X27 = 56508416 (0x35E4000);             
            // 0x010F46A8: ADRP x28, #0x3667000       | X28 = 57044992 (0x3667000);             
            // 0x010F46AC: ADRP x26, #0x35ea000       | X26 = 56532992 (0x35EA000);             
            // 0x010F46B0: LDR x23, [x23, #0xd28]     | X23 = 1152921510000221888;              
            // 0x010F46B4: LDR x24, [x24, #0x650]     | X24 = 1152921510000222912;              
            // 0x010F46B8: LDR x27, [x27, #0x468]     | X27 = 1152921510000223936;              
            // 0x010F46BC: LDR x28, [x28, #0x380]     | X28 = 1152921510000224960;              
            // 0x010F46C0: LDR x26, [x26, #0xb80]     | X26 = 1152921510000225984;              
            // 0x010F46C4: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            // 0x010F46C8: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            label_12:
            // 0x010F46CC: LDR x1, [x23]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::MoveNext();
            // 0x010F46D0: ADD x0, sp, #0x40          | X0 = (1152921510000246992 + 64) = 1152921510000247056 (0x100000014178C110);
            // 0x010F46D4: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x010F46D8: AND w8, w0, #1             | W8 = (1152921510000247056 & 1) = 0 (0x00000000);
            // 0x010F46DC: TBZ w8, #0, #0x10f4848     | if ((0x0 & 0x1) == 0) goto label_3;     
            if((0 & 1) == 0)
            {
                goto label_3;
            }
            // 0x010F46E0: LDR x1, [x24]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::get_Current();
            // 0x010F46E4: ADD x0, sp, #0x40          | X0 = (1152921510000246992 + 64) = 1152921510000247056 (0x100000014178C110);
            // 0x010F46E8: BL #0xf3ac3c               | X0 = null.GetHandle();                  
            UnityEngine.Playables.PlayableHandle val_3 = 0.GetHandle();
            // 0x010F46EC: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x010F46F0: LDR x8, [x8, #0x3b8]       | X8 = 1152921510000227008;               
            // 0x010F46F4: LDR x8, [x8]               | X8 = public System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> System.Collections.Generic.KeyValuePair<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::get_Value();
            // 0x010F46F8: STP x0, x1, [sp, #0x60]    | stack[1152921510000247088] = val_3.m_Handle;  stack[1152921510000247096] = val_3.m_Version;  //  dest_result_addr=1152921510000247088 |  dest_result_addr=1152921510000247096
            // 0x010F46FC: ADD x0, sp, #0x60          | X0 = (1152921510000246992 + 96) = 1152921510000247088 (0x100000014178C130);
            // 0x010F4700: MOV x1, x8                 | X1 = 1152921510000227008 (0x10000001417872C0);//ML01
            // 0x010F4704: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x010F4708: MOV x21, x0                | X21 = 1152921510000247088 (0x100000014178C130);//ML01
            // 0x010F470C: CBNZ x21, #0x10f4714       | if (val_3.m_Handle != 0) goto label_4;  
            if(val_3.m_Handle != 0)
            {
                goto label_4;
            }
            // 0x010F4710: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014178C130, ????);
            label_4:
            // 0x010F4714: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x010F4718: LDR x8, [x8, #0x360]       | X8 = 1152921510000228032;               
            // 0x010F471C: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>::GetEnumerator();
            // 0x010F4720: ADD x8, sp, #8             | X8 = (1152921510000246992 + 8) = 1152921510000247000 (0x100000014178C0D8);
            // 0x010F4724: MOV x0, x21                | X0 = 1152921510000247088 (0x100000014178C130);//ML01
            // 0x010F4728: BL #0x25ebf2c              | X0 = val_3.m_Handle.GetEnumerator();    
            List.Enumerator<T> val_4 = val_3.m_Handle.GetEnumerator();
            // 0x010F472C: LDR x8, [sp, #0x18]        | X8 = val_5;                              //  find_add[1152921510000235200]
            // 0x010F4730: LDUR q0, [sp, #8]          | Q0 = val_6;                              //  find_add[1152921510000235200]
            // 0x010F4734: STR x8, [sp, #0x30]        | stack[1152921510000247040] = val_5;      //  dest_result_addr=1152921510000247040
            // 0x010F4738: STR q0, [sp, #0x20]        | stack[1152921510000247024] = val_6;      //  dest_result_addr=1152921510000247024
            label_7:
            // 0x010F473C: LDR x1, [x27]              | X1 = public System.Boolean List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::MoveNext();
            // 0x010F4740: ADD x0, sp, #0x20          | X0 = (1152921510000246992 + 32) = 1152921510000247024 (0x100000014178C0F0);
            // 0x010F4744: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x010F4748: AND w8, w0, #1             | W8 = (1152921510000247024 & 1) = 0 (0x00000000);
            // 0x010F474C: TBZ w8, #0, #0x10f4798     | if ((0x0 & 0x1) == 0) goto label_5;     
            if((0 & 1) == 0)
            {
                goto label_5;
            }
            // 0x010F4750: LDR x1, [x28]              | X1 = public ILRuntime.CLR.Method.CLRMethod List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::get_Current();
            // 0x010F4754: ADD x0, sp, #0x20          | X0 = (1152921510000246992 + 32) = 1152921510000247024 (0x100000014178C0F0);
            // 0x010F4758: BL #0x13372d8              | X0 = val_6.get_InitialType();           
            System.Type val_7 = val_6.InitialType;
            // 0x010F475C: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x010F4760: CBNZ x19, #0x10f4768       | if ( != 0) goto label_6;                
            if(null != 0)
            {
                goto label_6;
            }
            // 0x010F4764: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_6:
            // 0x010F4768: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.Method.IMethod>::Add(ILRuntime.CLR.Method.IMethod item);
            // 0x010F476C: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010F4770: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x010F4774: BL #0x25ea480              | Add(item:  val_7);                      
            Add(item:  val_7);
            // 0x010F4778: B #0x10f473c               |  goto label_7;                          
            goto label_7;
            // 0x010F477C: CMP w1, #1                 | STATE = COMPARE(val_7, 0x1)             
            // 0x010F4780: B.NE #0x10f47ec            | if (val_7 != 0x1) goto label_8;         
            if(val_7 != 1)
            {
                goto label_8;
            }
            // 0x010F4784: BL #0x981060               | X0 = sub_981060( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010F4788: LDR x21, [x0]              | X21 = ;                                 
            val_8 = null;
            // 0x010F478C: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010F4790: MOV w22, w25               | W22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x010F4794: B #0x10f47a0               |  goto label_9;                          
            goto label_9;
            label_5:
            // 0x010F4798: MOVZ w22, #0x71            | W22 = 113 (0x71);//ML01                 
            val_9 = 113;
            // 0x010F479C: MOV x21, x20               | X21 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x010F47A0: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F47A4: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F47A8: MOV w25, w22               | W25 = 113 (0x71);//ML01                 
            // 0x010F47AC: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F47B0: ADD x0, sp, #0x20          | X0 = (1152921510000246992 + 32) = 1152921510000247024 (0x100000014178C0F0);
            // 0x010F47B4: BL #0x13371f4              | val_6.Dispose();                        
            val_6.Dispose();
            // 0x010F47B8: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            // 0x010F47BC: CMP w22, #0x71             | STATE = COMPARE(0x71, 0x71)             
            // 0x010F47C0: MOV x20, x21               | X20 = 0 (0x0);//ML01                    
            // 0x010F47C4: B.EQ #0x10f46cc            | if (0x71 == 0x71) goto label_12;        
            if(113 == 113)
            {
                goto label_12;
            }
            // 0x010F47C8: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x010F47CC: MOV w25, w22               | W25 = 113 (0x71);//ML01                 
            // 0x010F47D0: CBZ x21, #0x10f46cc        | if (0x0 == 0) goto label_12;            
            if(val_8 == 0)
            {
                goto label_12;
            }
            // 0x010F47D4: MOV w25, w22               | W25 = 113 (0x71);//ML01                 
            // 0x010F47D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F47DC: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x010F47E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x010F47E4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x010F47E8: B #0x10f46cc               |  goto label_12;                         
            goto label_12;
            label_8:
            // 0x010F47EC: BL #0x981060               | X0 = sub_981060( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010F47F0: LDR x20, [x0]              | X20 = ;                                 
            // 0x010F47F4: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_15:
            // 0x010F47F8: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x010F47FC: LDR x8, [x8, #0xb98]       | X8 = 1152921510000234176;               
            // 0x010F4800: ADD x0, sp, #0x40          | X0 = (1152921510000246992 + 64) = 1152921510000247056 (0x100000014178C110);
            // 0x010F4804: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::Dispose();
            // 0x010F4808: BL #0xf3acac               | null.Dispose();                         
            0.Dispose();
            // 0x010F480C: CMP w25, #0x90             | STATE = COMPARE(0x0, 0x90)              
            // 0x010F4810: B.EQ #0x10f4824            | if (0 == 0x90) goto label_14;           
            if(0 == 144)
            {
                goto label_14;
            }
            // 0x010F4814: CBZ x20, #0x10f4824        | if ( == 0) goto label_14;               
            if(null == 0)
            {
                goto label_14;
            }
            // 0x010F4818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F481C: MOV x0, x20                | X0 = X20;//m1                           
            // 0x010F4820: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
            label_14:
            // 0x010F4824: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010F4828: SUB sp, x29, #0x50         | SP = (1152921510000247184 - 80) = 1152921510000247104 (0x100000014178C140);
            // 0x010F482C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x010F4830: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x010F4834: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x010F4838: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x010F483C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x010F4840: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x010F4844: RET                        |  return (System.Collections.Generic.List<ILRuntime.CLR.Method.IMethod>)typeof(System.Collections.Generic.List<T>);
            return (System.Collections.Generic.List<ILRuntime.CLR.Method.IMethod>)val_1;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<ILRuntime.CLR.Method.IMethod>, size=8, nGRN=0 }
            label_3:
            // 0x010F4848: MOVZ w25, #0x90            | W25 = 144 (0x90);//ML01                 
            // 0x010F484C: B #0x10f47f8               |  goto label_15;                         
            goto label_15;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F4850 (17778768), len: 456  VirtAddr: 0x010F4850 RVA: 0x010F4850 token: 100663453 methodIndex: 28886 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.Method.IMethod GetVirtualMethod(ILRuntime.CLR.Method.IMethod method)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x010F4850: STP x24, x23, [sp, #-0x40]! | stack[1152921510000379616] = ???;  stack[1152921510000379624] = ???;  //  dest_result_addr=1152921510000379616 |  dest_result_addr=1152921510000379624
            // 0x010F4854: STP x22, x21, [sp, #0x10]  | stack[1152921510000379632] = ???;  stack[1152921510000379640] = ???;  //  dest_result_addr=1152921510000379632 |  dest_result_addr=1152921510000379640
            // 0x010F4858: STP x20, x19, [sp, #0x20]  | stack[1152921510000379648] = ???;  stack[1152921510000379656] = ???;  //  dest_result_addr=1152921510000379648 |  dest_result_addr=1152921510000379656
            // 0x010F485C: STP x29, x30, [sp, #0x30]  | stack[1152921510000379664] = ???;  stack[1152921510000379672] = ???;  //  dest_result_addr=1152921510000379664 |  dest_result_addr=1152921510000379672
            // 0x010F4860: ADD x29, sp, #0x30         | X29 = (1152921510000379616 + 48) = 1152921510000379664 (0x10000001417AC710);
            // 0x010F4864: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010F4868: LDRB w8, [x21, #0xb04]     | W8 = (bool)static_value_03735B04;       
            // 0x010F486C: MOV x19, x1                | X19 = method;//m1                       
            // 0x010F4870: MOV x20, x0                | X20 = 1152921510000391680 (0x10000001417AF600);//ML01
            // 0x010F4874: TBNZ w8, #0, #0x10f4890    | if (static_value_03735B04 == true) goto label_0;
            // 0x010F4878: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x010F487C: LDR x8, [x8, #0xf88]       | X8 = 0x2B90D4C;                         
            // 0x010F4880: LDR w0, [x8]               | W0 = 0x1A17;                            
            // 0x010F4884: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A17, ????);     
            // 0x010F4888: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F488C: STRB w8, [x21, #0xb04]     | static_value_03735B04 = true;            //  dest_result_addr=57891588
            label_0:
            // 0x010F4890: CBNZ x19, #0x10f4898       | if (method != null) goto label_1;       
            if(method != null)
            {
                goto label_1;
            }
            // 0x010F4894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A17, ????);     
            label_1:
            // 0x010F4898: ADRP x23, #0x35b7000       | X23 = 56324096 (0x35B7000);             
            // 0x010F489C: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.Method.IMethod);
            // 0x010F48A0: LDR x23, [x23, #0xbe0]     | X23 = 1152921504781979648;              
            // 0x010F48A4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F48A8: LDR x1, [x23]              | X1 = typeof(ILRuntime.CLR.Method.IMethod);
            // 0x010F48AC: CBZ x9, #0x10f48d8         | if (ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x010F48B0: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F48B4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x010F48B8: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782016520 (0x100000000A70E008);
            label_4:
            // 0x010F48BC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F48C0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.Method.IMethod))
            // 0x010F48C4: B.EQ #0x10f48e8            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x010F48C8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x010F48CC: ADD x10, x10, #0x10        | X10 = (1152921504782016520 + 16) = 1152921504782016536 (0x100000000A70E018);
            // 0x010F48D0: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F48D4: B.LO #0x10f48bc            | if (0 < ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x010F48D8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x010F48DC: MOV x0, x19                | X0 = method;//m1                        
            val_6 = method;
            // 0x010F48E0: BL #0x2776c24              | X0 = sub_2776C24( ?? method, ????);     
            // 0x010F48E4: B #0x10f48f4               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x010F48E8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F48EC: ADD x8, x8, x9, lsl #4     | X8 = (1152921504781979648 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x010F48F0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504781979648 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_5:
            // 0x010F48F4: LDP x8, x1, [x0]           | X8 = 0x0; X1 = 0x0;                      //  | 
            // 0x010F48F8: MOV x0, x19                | X0 = method;//m1                        
            // 0x010F48FC: BLR x8                     | X0 = x8();                              
            // 0x010F4900: MOV x21, x0                | X21 = method;//m1                       
            // 0x010F4904: CBNZ x19, #0x10f490c       | if (method != null) goto label_6;       
            if(method != null)
            {
                goto label_6;
            }
            // 0x010F4908: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? method, ????);     
            label_6:
            // 0x010F490C: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.Method.IMethod);
            // 0x010F4910: LDR x1, [x23]              | X1 = typeof(ILRuntime.CLR.Method.IMethod);
            // 0x010F4914: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F4918: CBZ x9, #0x10f4944         | if (ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count == 0) goto label_7;
            // 0x010F491C: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F4920: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x010F4924: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782016520 (0x100000000A70E008);
            label_9:
            // 0x010F4928: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F492C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.Method.IMethod))
            // 0x010F4930: B.EQ #0x10f4954            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_8;
            // 0x010F4934: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x010F4938: ADD x10, x10, #0x10        | X10 = (1152921504782016520 + 16) = 1152921504782016536 (0x100000000A70E018);
            // 0x010F493C: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F4940: B.LO #0x10f4928            | if (0 < ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count) goto label_9;
            label_7:
            // 0x010F4944: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x010F4948: MOV x0, x19                | X0 = method;//m1                        
            val_7 = method;
            // 0x010F494C: BL #0x2776c24              | X0 = sub_2776C24( ?? method, ????);     
            // 0x010F4950: B #0x10f4964               |  goto label_10;                         
            goto label_10;
            label_8:
            // 0x010F4954: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F4958: ADD w9, w9, #5             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 5);
            // 0x010F495C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504781979648 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 5));
            // 0x010F4960: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504781979648 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 5)).272
            label_10:
            // 0x010F4964: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.Method.IMethod);  //  | 
            // 0x010F4968: MOV x0, x19                | X0 = method;//m1                        
            // 0x010F496C: BLR x8                     | X0 = sub_100000000A705000( ?? method, ????);
            // 0x010F4970: MOV x22, x0                | X22 = method;//m1                       
            // 0x010F4974: CBNZ x19, #0x10f497c       | if (method != null) goto label_11;      
            if(method != null)
            {
                goto label_11;
            }
            // 0x010F4978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? method, ????);     
            label_11:
            // 0x010F497C: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.Method.IMethod);
            // 0x010F4980: LDR x1, [x23]              | X1 = typeof(ILRuntime.CLR.Method.IMethod);
            // 0x010F4984: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F4988: CBZ x9, #0x10f49b4         | if (ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count == 0) goto label_12;
            // 0x010F498C: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F4990: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x010F4994: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782016520 (0x100000000A70E008);
            label_14:
            // 0x010F4998: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F499C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.Method.IMethod))
            // 0x010F49A0: B.EQ #0x10f49c4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_13;
            // 0x010F49A4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x010F49A8: ADD x10, x10, #0x10        | X10 = (1152921504782016520 + 16) = 1152921504782016536 (0x100000000A70E018);
            // 0x010F49AC: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F49B0: B.LO #0x10f4998            | if (0 < ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_interface_offsets_count) goto label_14;
            label_12:
            // 0x010F49B4: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x010F49B8: MOV x0, x19                | X0 = method;//m1                        
            val_8 = method;
            // 0x010F49BC: BL #0x2776c24              | X0 = sub_2776C24( ?? method, ????);     
            // 0x010F49C0: B #0x10f49d4               |  goto label_15;                         
            goto label_15;
            label_13:
            // 0x010F49C4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F49C8: ADD w9, w9, #4             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4);
            // 0x010F49CC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504781979648 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4));
            // 0x010F49D0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504781979648 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4)).272
            label_15:
            // 0x010F49D4: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.Method.IMethod);  //  | 
            // 0x010F49D8: MOV x0, x19                | X0 = method;//m1                        
            // 0x010F49DC: BLR x8                     | X0 = sub_100000000A705000( ?? method, ????);
            // 0x010F49E0: MOV x4, x0                 | X4 = method;//m1                        
            // 0x010F49E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F49E8: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x010F49EC: MOV x0, x20                | X0 = 1152921510000391680 (0x10000001417AF600);//ML01
            // 0x010F49F0: MOV x1, x21                | X1 = method;//m1                        
            // 0x010F49F4: MOV x2, x22                | X2 = method;//m1                        
            // 0x010F49F8: BL #0x10f4a18              | X0 = this.GetMethod(name:  method, param:  method, genericArguments:  0, returnType:  method, declaredOnly:  false);
            ILRuntime.CLR.Method.IMethod val_4 = this.GetMethod(name:  method, param:  method, genericArguments:  0, returnType:  method, declaredOnly:  false);
            // 0x010F49FC: CMP x0, #0                 | STATE = COMPARE(val_4, 0x0)             
            // 0x010F4A00: CSEL x0, x0, x19, ne       | X0 = val_4 != null ? val_4 : method;    
            var val_5 = (val_4 != 0) ? (val_4) : (method);
            // 0x010F4A04: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010F4A08: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010F4A0C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010F4A10: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010F4A14: RET                        |  return (ILRuntime.CLR.Method.IMethod)val_4 != null ? val_4 : method;
            return (ILRuntime.CLR.Method.IMethod)val_5;
            //  |  // // {name=val_0, type=ILRuntime.CLR.Method.IMethod, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F2BAC (17771436), len: 1260  VirtAddr: 0x010F2BAC RVA: 0x010F2BAC token: 100663454 methodIndex: 28887 delegateWrapperIndex: 0 methodInvoker: 0
        private void InitializeFields()
        {
            //
            // Disasemble & Code
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            ILRuntime.Runtime.Enviorment.ValueTypeBinder val_23;
            //  | 
            System.Type val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate> val_29;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_30;
            //  | 
            System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate> val_31;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_32;
            // 0x010F2BAC: STP x28, x27, [sp, #-0x60]! | stack[1152921510000598080] = ???;  stack[1152921510000598088] = ???;  //  dest_result_addr=1152921510000598080 |  dest_result_addr=1152921510000598088
            // 0x010F2BB0: STP x26, x25, [sp, #0x10]  | stack[1152921510000598096] = ???;  stack[1152921510000598104] = ???;  //  dest_result_addr=1152921510000598096 |  dest_result_addr=1152921510000598104
            // 0x010F2BB4: STP x24, x23, [sp, #0x20]  | stack[1152921510000598112] = ???;  stack[1152921510000598120] = ???;  //  dest_result_addr=1152921510000598112 |  dest_result_addr=1152921510000598120
            // 0x010F2BB8: STP x22, x21, [sp, #0x30]  | stack[1152921510000598128] = ???;  stack[1152921510000598136] = ???;  //  dest_result_addr=1152921510000598128 |  dest_result_addr=1152921510000598136
            // 0x010F2BBC: STP x20, x19, [sp, #0x40]  | stack[1152921510000598144] = ???;  stack[1152921510000598152] = ???;  //  dest_result_addr=1152921510000598144 |  dest_result_addr=1152921510000598152
            // 0x010F2BC0: STP x29, x30, [sp, #0x50]  | stack[1152921510000598160] = ???;  stack[1152921510000598168] = ???;  //  dest_result_addr=1152921510000598160 |  dest_result_addr=1152921510000598168
            // 0x010F2BC4: ADD x29, sp, #0x50         | X29 = (1152921510000598080 + 80) = 1152921510000598160 (0x10000001417E1C90);
            // 0x010F2BC8: SUB sp, sp, #0x30          | SP = (1152921510000598080 - 48) = 1152921510000598032 (0x10000001417E1C10);
            // 0x010F2BCC: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F2BD0: LDRB w8, [x20, #0xb05]     | W8 = (bool)static_value_03735B05;       
            // 0x010F2BD4: MOV x19, x0                | X19 = 1152921510000610176 (0x10000001417E4B80);//ML01
            // 0x010F2BD8: TBNZ w8, #0, #0x10f2bf4    | if (static_value_03735B05 == true) goto label_0;
            // 0x010F2BDC: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x010F2BE0: LDR x8, [x8, #0xb8]        | X8 = 0x2B90D54;                         
            // 0x010F2BE4: LDR w0, [x8]               | W0 = 0x1A19;                            
            // 0x010F2BE8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A19, ????);     
            // 0x010F2BEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F2BF0: STRB w8, [x20, #0xb05]     | static_value_03735B05 = true;            //  dest_result_addr=57891589
            label_0:
            // 0x010F2BF4: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x010F2BF8: LDR x8, [x8, #0x610]       | X8 = 1152921504615792640;               
            // 0x010F2BFC: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.Int32> val_1 = null;
            // 0x010F2C00: STP xzr, xzr, [sp, #0x20]  | stack[1152921510000598064] = 0x0;  stack[1152921510000598072] = 0x0;  //  dest_result_addr=1152921510000598064 |  dest_result_addr=1152921510000598072
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_18 = 0;
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_14 = 0;
            // 0x010F2C04: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x010F2C08: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x010F2C0C: LDR x8, [x8, #0x6d8]       | X8 = 1152921510000487872;               
            // 0x010F2C10: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x010F2C14: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::.ctor();
            // 0x010F2C18: BL #0x23f2edc              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.String, System.Int32>();
            // 0x010F2C1C: STR x20, [x19, #0x48]      | this.fieldMapping = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921510000610248
            this.fieldMapping = val_1;
            // 0x010F2C20: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x010F2C24: LDR x8, [x8, #0x510]       | X8 = 1152921504615792640;               
            // 0x010F2C28: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo> val_2 = null;
            // 0x010F2C2C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x010F2C30: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x010F2C34: LDR x8, [x8, #0x1c0]       | X8 = 1152921510000488896;               
            // 0x010F2C38: MOV x21, x0                | X21 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x010F2C3C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>::.ctor();
            // 0x010F2C40: BL #0x2413320              | .ctor();                                
            val_2 = new System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>();
            // 0x010F2C44: LDR x20, [x19, #0x10]      | X20 = this.clrType; //P2                
            // 0x010F2C48: STR x21, [x19, #0x50]      | this.fieldInfoCache = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921510000610256
            this.fieldInfoCache = val_2;
            // 0x010F2C4C: CBNZ x20, #0x10f2c54       | if (this.clrType != null) goto label_1; 
            if(this.clrType != null)
            {
                goto label_1;
            }
            // 0x010F2C50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_1:
            // 0x010F2C54: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x010F2C58: ORR w1, wzr, #0x3c         | W1 = 60(0x3C);                          
            val_21 = 60;
            // 0x010F2C5C: MOV x0, x20                | X0 = this.clrType;//m1                  
            // 0x010F2C60: LDR x9, [x8, #0x490]       | X9 = typeof(System.Type).__il2cppRuntimeField_490;
            // 0x010F2C64: LDR x2, [x8, #0x498]       | X2 = typeof(System.Type).__il2cppRuntimeField_498;
            // 0x010F2C68: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_490();
            // 0x010F2C6C: MOV x20, x0                | X20 = this.clrType;//m1                 
            val_22 = this.clrType;
            // 0x010F2C70: MOV x0, x19                | X0 = 1152921510000610176 (0x10000001417E4B80);//ML01
            // 0x010F2C74: BL #0x10f3b9c              | X0 = this.get_ValueTypeBinder();        
            ILRuntime.Runtime.Enviorment.ValueTypeBinder val_3 = this.ValueTypeBinder;
            // 0x010F2C78: MOV x21, x0                | X21 = val_3;//m1                        
            val_23 = val_3;
            // 0x010F2C7C: STR x21, [sp, #0x10]       | stack[1152921510000598048] = val_3;      //  dest_result_addr=1152921510000598048
            // 0x010F2C80: CBZ x21, #0x10f2cec        | if (val_3 == null) goto label_2;        
            if(val_23 == null)
            {
                goto label_2;
            }
            // 0x010F2C84: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x010F2C88: LDR x8, [x8, #0x940]       | X8 = 1152921504615792640;               
            // 0x010F2C8C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.Int32, System.Int32> val_4 = null;
            // 0x010F2C90: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x010F2C94: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x010F2C98: LDR x8, [x8, #0xb20]       | X8 = 1152921510000498112;               
            // 0x010F2C9C: MOV x22, x0                | X22 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x010F2CA0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Int32>::.ctor();
            // 0x010F2CA4: BL #0x240b344              | .ctor();                                
            val_4 = new System.Collections.Generic.Dictionary<System.Int32, System.Int32>();
            // 0x010F2CA8: MOV x8, x19                | X8 = 1152921510000610176 (0x10000001417E4B80);//ML01
            // 0x010F2CAC: STR x22, [x8, #0x68]!      | this.fieldIdxMapping = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921510000610280
            this.fieldIdxMapping = val_4;
            // 0x010F2CB0: STR x8, [sp]               | stack[1152921510000598032] = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921510000598032
            // 0x010F2CB4: CBNZ x20, #0x10f2cbc       | if (this.clrType != null) goto label_3; 
            if(val_22 != null)
            {
                goto label_3;
            }
            // 0x010F2CB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x010F2CBC: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x010F2CC0: LDR x8, [x8, #0x8a0]       | X8 = 1152921506369643984;               
            // 0x010F2CC4: MOV x28, x20               | X28 = this.clrType;//m1                 
            val_24 = val_22;
            // 0x010F2CC8: LDR x22, [x8]              | X22 = typeof(ILRuntime.CLR.TypeSystem.IType[]);
            // 0x010F2CCC: LDR w23, [x28, #0x18]!     | 
            // 0x010F2CD0: MOV x0, x22                | X0 = 1152921506369643984 (0x10000000691225D0);//ML01
            // 0x010F2CD4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ILRuntime.CLR.TypeSystem.IType[]), ????);
            // 0x010F2CD8: MOV x0, x22                | X0 = 1152921506369643984 (0x10000000691225D0);//ML01
            // 0x010F2CDC: MOV x1, x23                | X1 = X23;//m1                           
            val_21 = X23;
            // 0x010F2CE0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(ILRuntime.CLR.TypeSystem.IType[]), ????);
            // 0x010F2CE4: STR x0, [x19, #0x70]       | this.orderedFieldTypes = typeof(ILRuntime.CLR.TypeSystem.IType[]);  //  dest_result_addr=1152921510000610288
            this.orderedFieldTypes = null;
            // 0x010F2CE8: B #0x10f2cf8               |  goto label_4;                          
            goto label_4;
            label_2:
            // 0x010F2CEC: ADD x8, x19, #0x68         | X8 = this.fieldIdxMapping;//AP2 res_addr=1152921510000610280
            // 0x010F2CF0: ADD x28, x20, #0x18        | X28 = (this.clrType + 24);              
            val_24 = val_22 + 24;
            // 0x010F2CF4: STR x8, [sp]               | stack[1152921510000598032] = this.fieldIdxMapping;  //  dest_result_addr=1152921510000598032
            label_4:
            // 0x010F2CF8: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
            // 0x010F2CFC: ADRP x22, #0x3630000       | X22 = 56819712 (0x3630000);             
            // 0x010F2D00: STR x28, [sp, #8]          | stack[1152921510000598040] = (this.clrType + 24);  //  dest_result_addr=1152921510000598040
            // 0x010F2D04: STR x8, [sp, #0x18]        | stack[1152921510000598056] = 0x0;        //  dest_result_addr=1152921510000598056
            // 0x010F2D08: LDR x22, [x22, #0x6b0]     | X22 = 1152921510000499136;              
            val_25 = 1152921510000499136;
            // 0x010F2D0C: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_26 = 0;
            // 0x010F2D10: B #0x10f2d18               |  goto label_5;                          
            goto label_5;
            label_40:
            // 0x010F2D14: ADD w27, w27, #1           | W27 = (val_26 + 1) = val_26 (0x00000001);
            val_26 = 1;
            label_5:
            // 0x010F2D18: CBNZ x20, #0x10f2d20       | if (this.clrType != null) goto label_6; 
            if(val_22 != null)
            {
                goto label_6;
            }
            // 0x010F2D1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_6:
            // 0x010F2D20: LDR w8, [x28]              | W8 = typeof(System.Type);               
            // 0x010F2D24: CMP w27, w8                | STATE = COMPARE(0x1, typeof(System.Type))
            // 0x010F2D28: B.GE #0x10f3078            | if (val_26 >= typeof(System.Type)) goto label_7;
            if(val_26 >= null)
            {
                goto label_7;
            }
            // 0x010F2D2C: SXTW x23, w27              | X23 = 1 (0x00000001);                   
            // 0x010F2D30: CMP w27, w8                | STATE = COMPARE(0x1, typeof(System.Type))
            // 0x010F2D34: B.LO #0x10f2d44            | if (val_26 < typeof(System.Type)) goto label_8;
            if(val_26 < null)
            {
                goto label_8;
            }
            // 0x010F2D38: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x010F2D3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_21 = 0;
            // 0x010F2D40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_8:
            // 0x010F2D44: ADD x8, x20, x23, lsl #3   | X8 = (this.clrType + 8);                
            System.Type val_5 = val_22 + 8;
            // 0x010F2D48: LDR x24, [x8, #0x20]       | 
            // 0x010F2D4C: CBNZ x24, #0x10f2d54       | if (X24 != 0) goto label_9;             
            if(X24 != 0)
            {
                goto label_9;
            }
            // 0x010F2D50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x010F2D54: LDR x8, [x24]              | X8 = X24;                               
            // 0x010F2D58: MOV x0, x24                | X0 = X24;//m1                           
            // 0x010F2D5C: LDP x9, x1, [x8, #0x130]   | X9 = X24 + 304; X1 = X24 + 304 + 8;      //  | 
            // 0x010F2D60: BLR x9                     | X0 = X24 + 304();                       
            // 0x010F2D64: MOV w23, w0                | W23 = X24;//m1                          
            // 0x010F2D68: CBNZ x24, #0x10f2d70       | if (X24 != 0) goto label_10;            
            if(X24 != 0)
            {
                goto label_10;
            }
            // 0x010F2D6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X24, ????);        
            label_10:
            // 0x010F2D70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_27 = 0;
            // 0x010F2D74: MOV x0, x24                | X0 = X24;//m1                           
            // 0x010F2D78: BL #0x13bcfd0              | X0 = X24.get_IsPublic();                
            bool val_6 = X24.IsPublic;
            // 0x010F2D7C: AND w8, w0, #1             | W8 = (val_6 & 1);                       
            bool val_7 = val_6;
            // 0x010F2D80: TBNZ w8, #0, #0x10f2da0    | if ((val_6 & 1) == true) goto label_13; 
            if(val_7 == true)
            {
                goto label_13;
            }
            // 0x010F2D84: CBNZ x24, #0x10f2d8c       | if (X24 != 0) goto label_12;            
            if(X24 != 0)
            {
                goto label_12;
            }
            // 0x010F2D88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_12:
            // 0x010F2D8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_27 = 0;
            // 0x010F2D90: MOV x0, x24                | X0 = X24;//m1                           
            // 0x010F2D94: BL #0x13bd020              | X0 = X24.get_IsFamily();                
            bool val_8 = X24.IsFamily;
            // 0x010F2D98: CBNZ x21, #0x10f2da0       | if (val_3 != null) goto label_13;       
            if(val_23 != null)
            {
                goto label_13;
            }
            // 0x010F2D9C: TBZ w0, #0, #0x10f2e04     | if (val_8 == false) goto label_14;      
            if(val_8 == false)
            {
                goto label_14;
            }
            label_13:
            // 0x010F2DA0: LDR x25, [x19, #0x48]      | X25 = this.fieldMapping; //P2           
            // 0x010F2DA4: CBNZ x24, #0x10f2dac       | if (X24 != 0) goto label_15;            
            if(X24 != 0)
            {
                goto label_15;
            }
            // 0x010F2DA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_15:
            // 0x010F2DAC: LDR x8, [x24]              | X8 = X24;                               
            // 0x010F2DB0: MOV x0, x24                | X0 = X24;//m1                           
            // 0x010F2DB4: LDP x9, x1, [x8, #0x190]   | X9 = X24 + 400; X1 = X24 + 400 + 8;      //  | 
            // 0x010F2DB8: BLR x9                     | X0 = X24 + 400();                       
            // 0x010F2DBC: MOV x26, x0                | X26 = X24;//m1                          
            // 0x010F2DC0: CBNZ x25, #0x10f2dc8       | if (this.fieldMapping != null) goto label_16;
            if(this.fieldMapping != null)
            {
                goto label_16;
            }
            // 0x010F2DC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X24, ????);        
            label_16:
            // 0x010F2DC8: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::set_Item(System.String key, System.Int32 value);
            // 0x010F2DCC: MOV x0, x25                | X0 = this.fieldMapping;//m1             
            // 0x010F2DD0: MOV x1, x26                | X1 = X24;//m1                           
            // 0x010F2DD4: MOV w2, w23                | W2 = X24;//m1                           
            // 0x010F2DD8: BL #0x23f4398              | this.fieldMapping.set_Item(key:  X24, value:  X24);
            this.fieldMapping.set_Item(key:  X24, value:  X24);
            // 0x010F2DDC: LDR x25, [x19, #0x50]      | X25 = this.fieldInfoCache; //P2         
            // 0x010F2DE0: CBNZ x25, #0x10f2de8       | if (this.fieldInfoCache != null) goto label_17;
            if(this.fieldInfoCache != null)
            {
                goto label_17;
            }
            // 0x010F2DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.fieldMapping, ????);
            label_17:
            // 0x010F2DE8: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x010F2DEC: LDR x8, [x8, #0x58]        | X8 = 1152921510000508352;               
            // 0x010F2DF0: MOV x0, x25                | X0 = this.fieldInfoCache;//m1           
            // 0x010F2DF4: MOV w1, w23                | W1 = X24;//m1                           
            // 0x010F2DF8: MOV x2, x24                | X2 = X24;//m1                           
            // 0x010F2DFC: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>::set_Item(System.Int32 key, System.Reflection.FieldInfo value);
            // 0x010F2E00: BL #0x24147b0              | this.fieldInfoCache.set_Item(key:  X24, value:  X24);
            this.fieldInfoCache.set_Item(key:  X24, value:  X24);
            label_14:
            // 0x010F2E04: CBZ x21, #0x10f2f24        | if (val_3 == null) goto label_20;       
            if(val_23 == null)
            {
                goto label_20;
            }
            // 0x010F2E08: CBNZ x24, #0x10f2e10       | if (X24 != 0) goto label_19;            
            if(X24 != 0)
            {
                goto label_19;
            }
            // 0x010F2E0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.fieldInfoCache, ????);
            label_19:
            // 0x010F2E10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2E14: MOV x0, x24                | X0 = X24;//m1                           
            // 0x010F2E18: BL #0x13bb7ac              | X0 = X24.get_IsStatic();                
            bool val_9 = X24.IsStatic;
            // 0x010F2E1C: AND w8, w0, #1             | W8 = (val_9 & 1);                       
            bool val_10 = val_9;
            // 0x010F2E20: TBNZ w8, #0, #0x10f2f24    | if ((val_9 & 1) == true) goto label_20; 
            if(val_10 == true)
            {
                goto label_20;
            }
            // 0x010F2E24: LDR x28, [x19, #0x70]      | X28 = this.orderedFieldTypes; //P2      
            // 0x010F2E28: LDR x25, [x19, #0x28]      | X25 = this.appdomain; //P2              
            // 0x010F2E2C: CBNZ x24, #0x10f2e34       | if (X24 != 0) goto label_21;            
            if(X24 != 0)
            {
                goto label_21;
            }
            // 0x010F2E30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_21:
            // 0x010F2E34: LDR x8, [x24]              | X8 = X24;                               
            // 0x010F2E38: MOV x0, x24                | X0 = X24;//m1                           
            // 0x010F2E3C: LDR x9, [x8, #0x210]       | X9 = X24 + 528;                         
            // 0x010F2E40: LDR x1, [x8, #0x218]       | X1 = X24 + 536;                         
            // 0x010F2E44: BLR x9                     | X0 = X24 + 528();                       
            // 0x010F2E48: MOV x26, x0                | X26 = X24;//m1                          
            // 0x010F2E4C: CBNZ x25, #0x10f2e54       | if (this.appdomain != null) goto label_22;
            if(this.appdomain != null)
            {
                goto label_22;
            }
            // 0x010F2E50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X24, ????);        
            label_22:
            // 0x010F2E54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F2E58: MOV x0, x25                | X0 = this.appdomain;//m1                
            // 0x010F2E5C: MOV x1, x26                | X1 = X24;//m1                           
            // 0x010F2E60: BL #0x28e5da8              | X0 = this.appdomain.GetType(t:  X24);   
            ILRuntime.CLR.TypeSystem.IType val_11 = this.appdomain.GetType(t:  X24);
            // 0x010F2E64: MOV x25, x0                | X25 = val_11;//m1                       
            // 0x010F2E68: CBNZ x28, #0x10f2e70       | if (this.orderedFieldTypes != null) goto label_23;
            if(this.orderedFieldTypes != null)
            {
                goto label_23;
            }
            // 0x010F2E6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_23:
            // 0x010F2E70: CBZ x25, #0x10f2e94        | if (val_11 == null) goto label_25;      
            if(val_11 == null)
            {
                goto label_25;
            }
            // 0x010F2E74: LDR x8, [x28]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType[]);
            // 0x010F2E78: MOV x0, x25                | X0 = val_11;//m1                        
            // 0x010F2E7C: LDR x1, [x8, #0x30]        | X1 = ILRuntime.CLR.TypeSystem.IType[].__il2cppRuntimeField_element_class;
            // 0x010F2E80: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
            // 0x010F2E84: CBNZ x0, #0x10f2e94        | if (val_11 != null) goto label_25;      
            if(val_11 != null)
            {
                goto label_25;
            }
            // 0x010F2E88: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
            // 0x010F2E8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2E90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_25:
            // 0x010F2E94: LDR x2, [sp, #0x18]        | X2 = 0x0;                               
            val_28 = 0;
            // 0x010F2E98: LDR w8, [x28, #0x18]       | W8 = this.orderedFieldTypes.Length; //P2 
            // 0x010F2E9C: SXTW x26, w2               | X26 = 0 (0x00000000);                   
            // 0x010F2EA0: CMP w2, w8                 | STATE = COMPARE(0x0, this.orderedFieldTypes.Length)
            // 0x010F2EA4: B.LO #0x10f2ecc            | if (val_28 < this.orderedFieldTypes.Length) goto label_26;
            if(0 < this.orderedFieldTypes.Length)
            {
                goto label_26;
            }
            // 0x010F2EA8: MOV x21, x22               | X21 = 58058848 (0x375E860);//ML01       
            val_23 = val_25;
            // 0x010F2EAC: MOV x22, x20               | X22 = this.clrType;//m1                 
            // 0x010F2EB0: MOV x20, x2                | X20 = 0 (0x0);//ML01                    
            // 0x010F2EB4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
            // 0x010F2EB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2EBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x010F2EC0: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            val_28 = val_28;
            // 0x010F2EC4: MOV x20, x22               | X20 = this.clrType;//m1                 
            val_22 = val_22;
            // 0x010F2EC8: MOV x22, x21               | X22 = 58058848 (0x375E860);//ML01       
            val_25 = val_23;
            label_26:
            // 0x010F2ECC: ADD x8, x28, x26, lsl #3   | X8 = this.orderedFieldTypes[0x0]; //PARR1 
            // 0x010F2ED0: STR x25, [x8, #0x20]       | this.orderedFieldTypes[0x0][0] = val_11;  //  dest_result_addr=0
            this.orderedFieldTypes[0] = val_11;
            // 0x010F2ED4: LDR x8, [sp]               | X8 = this.fieldIdxMapping;              
            // 0x010F2ED8: ADD w26, w2, #1            | W26 = (val_28 + 1);                     
            var val_12 = val_28 + 1;
            // 0x010F2EDC: LDR x25, [x8]              | X25 = this.fieldIdxMapping;             
            // 0x010F2EE0: CBNZ x25, #0x10f2f00       | if (this.fieldIdxMapping != 0) goto label_27;
            if(this.fieldIdxMapping != 0)
            {
                goto label_27;
            }
            // 0x010F2EE4: MOV x21, x22               | X21 = 58058848 (0x375E860);//ML01       
            val_23 = val_25;
            // 0x010F2EE8: MOV x22, x20               | X22 = this.clrType;//m1                 
            // 0x010F2EEC: MOV x20, x2                | X20 = 0 (0x0);//ML01                    
            // 0x010F2EF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            // 0x010F2EF4: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            val_28 = val_28;
            // 0x010F2EF8: MOV x20, x22               | X20 = this.clrType;//m1                 
            // 0x010F2EFC: MOV x22, x21               | X22 = 58058848 (0x375E860);//ML01       
            label_27:
            // 0x010F2F00: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x010F2F04: LDR x8, [x8, #0xa48]       | X8 = 1152921510000554432;               
            // 0x010F2F08: MOV x0, x25                | X0 = this.fieldIdxMapping;//m1          
            // 0x010F2F0C: MOV w1, w23                | W1 = X24;//m1                           
            // 0x010F2F10: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Int32>::set_Item(System.Int32 key, System.Int32 value);
            // 0x010F2F14: BL #0x240c7f0              | this.fieldIdxMapping.set_Item(key:  X24, value:  0);
            this.fieldIdxMapping.set_Item(key:  X24, value:  0);
            // 0x010F2F18: MOV w8, w26                | W8 = (val_28 + 1);//m1                  
            // 0x010F2F1C: STR x8, [sp, #0x18]        | stack[1152921510000598056] = (val_28 + 1);  //  dest_result_addr=1152921510000598056
            // 0x010F2F20: LDP x28, x21, [sp, #8]     | X28 = (this.clrType + 24); X21 = val_3;  //  | 
            label_20:
            // 0x010F2F24: LDR x25, [x19, #0x28]      | X25 = this.appdomain; //P2              
            // 0x010F2F28: CBNZ x25, #0x10f2f30       | if (this.appdomain != null) goto label_28;
            if(this.appdomain != null)
            {
                goto label_28;
            }
            // 0x010F2F2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.fieldIdxMapping, ????);
            label_28:
            // 0x010F2F30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2F34: MOV x0, x25                | X0 = this.appdomain;//m1                
            // 0x010F2F38: BL #0x28e4340              | X0 = this.appdomain.get_FieldGetterMap();
            System.Collections.Generic.Dictionary<System.Reflection.FieldInfo, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate> val_13 = this.appdomain.FieldGetterMap;
            // 0x010F2F3C: MOV x25, x0                | X25 = val_13;//m1                       
            // 0x010F2F40: CBNZ x25, #0x10f2f48       | if (val_13 != null) goto label_29;      
            if(val_13 != null)
            {
                goto label_29;
            }
            // 0x010F2F44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_29:
            // 0x010F2F48: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x010F2F4C: LDR x8, [x8, #0xe90]       | X8 = 1152921510000563648;               
            // 0x010F2F50: ADD x2, sp, #0x28          | X2 = (1152921510000598032 + 40) = 1152921510000598072 (0x10000001417E1C38);
            // 0x010F2F54: MOV x0, x25                | X0 = val_13;//m1                        
            // 0x010F2F58: MOV x1, x24                | X1 = X24;//m1                           
            // 0x010F2F5C: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Reflection.FieldInfo, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate>::TryGetValue(System.Reflection.FieldInfo key, out ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate value);
            // 0x010F2F60: BL #0x23fe7ec              | X0 = val_13.TryGetValue(key:  X24, value: out  ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_14 = 0);
            bool val_15 = val_13.TryGetValue(key:  X24, value: out  val_14);
            // 0x010F2F64: TBZ w0, #0, #0x10f2fcc     | if (val_15 == false) goto label_30;     
            if(val_15 == false)
            {
                goto label_30;
            }
            // 0x010F2F68: LDR x25, [x19, #0x58]      | X25 = this.fieldGetterCache; //P2       
            val_29 = this.fieldGetterCache;
            // 0x010F2F6C: CBZ x25, #0x10f2f78        | if (this.fieldGetterCache == null) goto label_31;
            if(val_29 == null)
            {
                goto label_31;
            }
            // 0x010F2F70: LDR x26, [sp, #0x28]       | X26 = 0x0;                              
            val_30 = val_14;
            // 0x010F2F74: B #0x10f2fb0               |  goto label_33;                         
            goto label_33;
            label_31:
            // 0x010F2F78: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x010F2F7C: LDR x8, [x8, #0x368]       | X8 = 1152921504615792640;               
            // 0x010F2F80: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate> val_16 = null;
            // 0x010F2F84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x010F2F88: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x010F2F8C: LDR x8, [x8, #0xcb0]       | X8 = 1152921510000568768;               
            // 0x010F2F90: MOV x25, x0                | X25 = 1152921504615792640 (0x1000000000888000);//ML01
            val_29 = val_16;
            // 0x010F2F94: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate>::.ctor();
            // 0x010F2F98: BL #0x2413320              | .ctor();                                
            val_16 = new System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate>();
            // 0x010F2F9C: STR x25, [x19, #0x58]      | this.fieldGetterCache = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921510000610264
            this.fieldGetterCache = val_29;
            // 0x010F2FA0: LDR x26, [sp, #0x28]       | X26 = 0x0;                              
            val_30 = val_14;
            // 0x010F2FA4: CBNZ x25, #0x10f2fb0       | if ( != 0) goto label_33;               
            if(null != 0)
            {
                goto label_33;
            }
            // 0x010F2FA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x010F2FAC: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_29 = 0;
            label_33:
            // 0x010F2FB0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x010F2FB4: LDR x8, [x8, #0x8f0]       | X8 = 1152921510000569792;               
            // 0x010F2FB8: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            // 0x010F2FBC: MOV w1, w23                | W1 = X24;//m1                           
            // 0x010F2FC0: MOV x2, x26                | X2 = 0 (0x0);//ML01                     
            // 0x010F2FC4: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate>::set_Item(System.Int32 key, ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate value);
            // 0x010F2FC8: BL #0x24147b0              | val_29.set_Item(key:  X24, value:  val_30);
            val_29.set_Item(key:  X24, value:  val_30);
            label_30:
            // 0x010F2FCC: LDR x25, [x19, #0x28]      | X25 = this.appdomain; //P2              
            // 0x010F2FD0: CBNZ x25, #0x10f2fd8       | if (this.appdomain != null) goto label_34;
            if(this.appdomain != null)
            {
                goto label_34;
            }
            // 0x010F2FD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_34:
            // 0x010F2FD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F2FDC: MOV x0, x25                | X0 = this.appdomain;//m1                
            // 0x010F2FE0: BL #0x28e4348              | X0 = this.appdomain.get_FieldSetterMap();
            System.Collections.Generic.Dictionary<System.Reflection.FieldInfo, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate> val_17 = this.appdomain.FieldSetterMap;
            // 0x010F2FE4: MOV x25, x0                | X25 = val_17;//m1                       
            // 0x010F2FE8: CBNZ x25, #0x10f2ff0       | if (val_17 != null) goto label_35;      
            if(val_17 != null)
            {
                goto label_35;
            }
            // 0x010F2FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_35:
            // 0x010F2FF0: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x010F2FF4: LDR x8, [x8, #0x3b8]       | X8 = 1152921510000579008;               
            // 0x010F2FF8: ADD x2, sp, #0x20          | X2 = (1152921510000598032 + 32) = 1152921510000598064 (0x10000001417E1C30);
            // 0x010F2FFC: MOV x0, x25                | X0 = val_17;//m1                        
            // 0x010F3000: MOV x1, x24                | X1 = X24;//m1                           
            // 0x010F3004: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Reflection.FieldInfo, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate>::TryGetValue(System.Reflection.FieldInfo key, out ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate value);
            // 0x010F3008: BL #0x23fe7ec              | X0 = val_17.TryGetValue(key:  X24, value: out  ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_18 = 0);
            bool val_19 = val_17.TryGetValue(key:  X24, value: out  val_18);
            // 0x010F300C: TBZ w0, #0, #0x10f2d14     | if (val_19 == false) goto label_40;     
            if(val_19 == false)
            {
                goto label_40;
            }
            // 0x010F3010: LDR x24, [x19, #0x60]      | X24 = this.fieldSetterCache; //P2       
            val_31 = this.fieldSetterCache;
            // 0x010F3014: CBZ x24, #0x10f3020        | if (this.fieldSetterCache == null) goto label_37;
            if(val_31 == null)
            {
                goto label_37;
            }
            // 0x010F3018: LDR x25, [sp, #0x20]       | X25 = 0x0;                              
            val_32 = val_18;
            // 0x010F301C: B #0x10f3058               |  goto label_39;                         
            goto label_39;
            label_37:
            // 0x010F3020: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x010F3024: LDR x8, [x8, #0xf8]        | X8 = 1152921504615792640;               
            // 0x010F3028: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate> val_20 = null;
            // 0x010F302C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x010F3030: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x010F3034: LDR x8, [x8, #0x18]        | X8 = 1152921510000584128;               
            // 0x010F3038: MOV x24, x0                | X24 = 1152921504615792640 (0x1000000000888000);//ML01
            val_31 = val_20;
            // 0x010F303C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate>::.ctor();
            // 0x010F3040: BL #0x2413320              | .ctor();                                
            val_20 = new System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate>();
            // 0x010F3044: STR x24, [x19, #0x60]      | this.fieldSetterCache = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921510000610272
            this.fieldSetterCache = val_31;
            // 0x010F3048: LDR x25, [sp, #0x20]       | X25 = 0x0;                              
            val_32 = val_18;
            // 0x010F304C: CBNZ x24, #0x10f3058       | if ( != 0) goto label_39;               
            if(null != 0)
            {
                goto label_39;
            }
            // 0x010F3050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x010F3054: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_31 = 0;
            label_39:
            // 0x010F3058: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x010F305C: LDR x8, [x8, #0x8b8]       | X8 = 1152921510000585152;               
            // 0x010F3060: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x010F3064: MOV w1, w23                | W1 = X24;//m1                           
            // 0x010F3068: MOV x2, x25                | X2 = 0 (0x0);//ML01                     
            // 0x010F306C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate>::set_Item(System.Int32 key, ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate value);
            // 0x010F3070: BL #0x24147b0              | val_31.set_Item(key:  X24, value:  val_32);
            val_31.set_Item(key:  X24, value:  val_32);
            // 0x010F3074: B #0x10f2d14               |  goto label_40;                         
            goto label_40;
            label_7:
            // 0x010F3078: SUB sp, x29, #0x50         | SP = (1152921510000598160 - 80) = 1152921510000598080 (0x10000001417E1C40);
            // 0x010F307C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x010F3080: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x010F3084: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x010F3088: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x010F308C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x010F3090: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x010F3094: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F5748 (17782600), len: 404  VirtAddr: 0x010F5748 RVA: 0x010F5748 token: 100663455 methodIndex: 28888 delegateWrapperIndex: 0 methodInvoker: 0
        public int GetFieldIndex(object token)
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.Dictionary<System.Int32, System.Int32> val_5;
            //  | 
            System.Collections.Generic.Dictionary<System.Int32, System.Int32> val_6;
            //  | 
            var val_7;
            // 0x010F5748: STP x22, x21, [sp, #-0x30]! | stack[1152921510000817648] = ???;  stack[1152921510000817656] = ???;  //  dest_result_addr=1152921510000817648 |  dest_result_addr=1152921510000817656
            // 0x010F574C: STP x20, x19, [sp, #0x10]  | stack[1152921510000817664] = ???;  stack[1152921510000817672] = ???;  //  dest_result_addr=1152921510000817664 |  dest_result_addr=1152921510000817672
            // 0x010F5750: STP x29, x30, [sp, #0x20]  | stack[1152921510000817680] = ???;  stack[1152921510000817688] = ???;  //  dest_result_addr=1152921510000817680 |  dest_result_addr=1152921510000817688
            // 0x010F5754: ADD x29, sp, #0x20         | X29 = (1152921510000817648 + 32) = 1152921510000817680 (0x1000000141817610);
            // 0x010F5758: SUB sp, sp, #0x10          | SP = (1152921510000817648 - 16) = 1152921510000817632 (0x10000001418175E0);
            // 0x010F575C: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010F5760: LDRB w8, [x21, #0xb06]     | W8 = (bool)static_value_03735B06;       
            // 0x010F5764: MOV x20, x1                | X20 = token;//m1                        
            // 0x010F5768: MOV x19, x0                | X19 = 1152921510000829696 (0x100000014181A500);//ML01
            val_5 = this;
            // 0x010F576C: TBNZ w8, #0, #0x10f5788    | if (static_value_03735B06 == true) goto label_0;
            // 0x010F5770: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x010F5774: LDR x8, [x8, #0x570]       | X8 = 0x2B90D34;                         
            // 0x010F5778: LDR w0, [x8]               | W0 = 0x1A11;                            
            // 0x010F577C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A11, ????);     
            // 0x010F5780: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F5784: STRB w8, [x21, #0xb06]     | static_value_03735B06 = true;            //  dest_result_addr=57891590
            label_0:
            // 0x010F5788: STR wzr, [sp, #0xc]        | stack[1152921510000817644] = 0x0;        //  dest_result_addr=1152921510000817644
            int val_2 = 0;
            // 0x010F578C: LDR x8, [x19, #0x48]       | X8 = this.fieldMapping; //P2            
            // 0x010F5790: CBNZ x8, #0x10f579c        | if (this.fieldMapping != null) goto label_1;
            if(this.fieldMapping != null)
            {
                goto label_1;
            }
            // 0x010F5794: MOV x0, x19                | X0 = 1152921510000829696 (0x100000014181A500);//ML01
            // 0x010F5798: BL #0x10f2bac              | this.InitializeFields();                
            this.InitializeFields();
            label_1:
            // 0x010F579C: CBNZ x20, #0x10f57a4       | if (token != null) goto label_2;        
            if(token != null)
            {
                goto label_2;
            }
            // 0x010F57A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x010F57A4: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x010F57A8: MOV x0, x20                | X0 = token;//m1                         
            // 0x010F57AC: LDP x9, x1, [x8, #0x130]   | X9 = typeof(System.Object).__il2cppRuntimeField_130; X1 = typeof(System.Object).__il2cppRuntimeField_138; //  | 
            // 0x010F57B0: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_130();
            // 0x010F57B4: LDR x22, [x19, #0x90]      | X22 = this.fieldTokenMapping; //P2      
            val_6 = this.fieldTokenMapping;
            // 0x010F57B8: MOV w21, w0                | W21 = token;//m1                        
            // 0x010F57BC: CBNZ x22, #0x10f57f4       | if (this.fieldTokenMapping != null) goto label_4;
            if(val_6 != null)
            {
                goto label_4;
            }
            // 0x010F57C0: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x010F57C4: LDR x8, [x8, #0x940]       | X8 = 1152921504615792640;               
            // 0x010F57C8: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.Int32, System.Int32> val_1 = null;
            // 0x010F57CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x010F57D0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x010F57D4: LDR x8, [x8, #0xb20]       | X8 = 1152921510000498112;               
            // 0x010F57D8: MOV x22, x0                | X22 = 1152921504615792640 (0x1000000000888000);//ML01
            val_6 = val_1;
            // 0x010F57DC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Int32>::.ctor();
            // 0x010F57E0: BL #0x240b344              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.Int32, System.Int32>();
            // 0x010F57E4: STR x22, [x19, #0x90]      | this.fieldTokenMapping = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921510000829840
            this.fieldTokenMapping = val_6;
            // 0x010F57E8: CBNZ x22, #0x10f57f4       | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x010F57EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x010F57F0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_4:
            // 0x010F57F4: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x010F57F8: LDR x8, [x8, #0xc00]       | X8 = 1152921510000796480;               
            // 0x010F57FC: ADD x2, sp, #0xc           | X2 = (1152921510000817632 + 12) = 1152921510000817644 (0x10000001418175EC);
            // 0x010F5800: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x010F5804: MOV w1, w21                | W1 = token;//m1                         
            // 0x010F5808: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, System.Int32>::TryGetValue(System.Int32 key, out System.Int32 value);
            // 0x010F580C: BL #0x240e994              | X0 = val_6.TryGetValue(key:  token, value: out  int val_2 = 0);
            bool val_3 = val_6.TryGetValue(key:  token, value: out  val_2);
            // 0x010F5810: TBNZ w0, #0, #0x10f58b8    | if (val_3 == true) goto label_5;        
            if(val_3 == true)
            {
                goto label_5;
            }
            // 0x010F5814: CBZ x20, #0x10f58d8        | if (token == null) goto label_8;        
            if(token == null)
            {
                goto label_8;
            }
            // 0x010F5818: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x010F581C: LDR x8, [x8, #0x390]       | X8 = 1152921504739008512;               
            // 0x010F5820: LDR x9, [x20]              | X9 = typeof(System.Object);             
            // 0x010F5824: LDR x8, [x8]               | X8 = typeof(ILRuntime.Mono.Cecil.FieldReference);
            // 0x010F5828: LDRB w11, [x9, #0x104]     | W11 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F582C: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.Mono.Cecil.FieldReference.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F5830: CMP w11, w10               | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Mono.Cecil.FieldReference.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F5834: B.LO #0x10f58d8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Mono.Cecil.FieldReference.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x010F5838: LDR x9, [x9, #0xb0]        | X9 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x010F583C: ADD x9, x9, x10, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Mono.Cecil.FieldReference.__il2c
            // 0x010F5840: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Mono.Cecil.FieldReference.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F5844: CMP x9, x8                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Mono.Cecil.FieldReference.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Mono.Cecil.FieldReference))
            // 0x010F5848: B.NE #0x10f58d8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Mono.Cecil.FieldReference.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_8;
            // 0x010F584C: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x010F5850: LDR x22, [x19, #0x48]      | X22 = this.fieldMapping; //P2           
            // 0x010F5854: MOV x0, x20                | X0 = token;//m1                         
            // 0x010F5858: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.Object).__il2cppRuntimeField_160; X1 = typeof(System.Object).__il2cppRuntimeField_168; //  | 
            // 0x010F585C: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_160();
            // 0x010F5860: MOV x20, x0                | X20 = token;//m1                        
            // 0x010F5864: CBNZ x22, #0x10f586c       | if (this.fieldMapping != null) goto label_9;
            if(this.fieldMapping != null)
            {
                goto label_9;
            }
            // 0x010F5868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? token, ????);      
            label_9:
            // 0x010F586C: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x010F5870: LDR x8, [x8, #0xe40]       | X8 = 1152921509743371216;               
            // 0x010F5874: ADD x2, sp, #0xc           | X2 = (1152921510000817632 + 12) = 1152921510000817644 (0x10000001418175EC);
            // 0x010F5878: MOV x0, x22                | X0 = this.fieldMapping;//m1             
            // 0x010F587C: MOV x1, x20                | X1 = token;//m1                         
            // 0x010F5880: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Int32>::TryGetValue(System.String key, out System.Int32 value);
            // 0x010F5884: BL #0x23f6628              | X0 = this.fieldMapping.TryGetValue(key:  token, value: out  val_2);
            bool val_4 = this.fieldMapping.TryGetValue(key:  token, value: out  val_2);
            // 0x010F5888: TBZ w0, #0, #0x10f58c0     | if (val_4 == false) goto label_10;      
            if(val_4 == false)
            {
                goto label_10;
            }
            // 0x010F588C: LDR x19, [x19, #0x90]      | X19 = this.fieldTokenMapping; //P2      
            val_5 = this.fieldTokenMapping;
            // 0x010F5890: LDR w20, [sp, #0xc]        | W20 = 0x0;                              
            // 0x010F5894: CBNZ x19, #0x10f589c       | if (this.fieldTokenMapping != null) goto label_11;
            if(val_5 != null)
            {
                goto label_11;
            }
            // 0x010F5898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_11:
            // 0x010F589C: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x010F58A0: LDR x8, [x8, #0xa48]       | X8 = 1152921510000554432;               
            // 0x010F58A4: MOV x0, x19                | X0 = this.fieldTokenMapping;//m1        
            // 0x010F58A8: MOV w1, w21                | W1 = token;//m1                         
            // 0x010F58AC: MOV w2, w20                | W2 = 0 (0x0);//ML01                     
            // 0x010F58B0: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Int32>::set_Item(System.Int32 key, System.Int32 value);
            // 0x010F58B4: BL #0x240c7f0              | this.fieldTokenMapping.set_Item(key:  token, value:  0);
            val_5.set_Item(key:  token, value:  0);
            label_5:
            // 0x010F58B8: LDR w0, [sp, #0xc]         | W0 = 0x0;                               
            val_7 = val_2;
            // 0x010F58BC: B #0x10f58c4               |  goto label_12;                         
            goto label_12;
            label_10:
            // 0x010F58C0: MOVN w0, #0                | W0 = 0 (0x0);//ML01                     
            val_7 = 0;
            label_12:
            // 0x010F58C4: SUB sp, x29, #0x20         | SP = (1152921510000817680 - 32) = 1152921510000817648 (0x10000001418175F0);
            // 0x010F58C8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F58CC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F58D0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F58D4: RET                        |  return (System.Int32)0;                
            return (int)val_7;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_8:
            // 0x010F58D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x010F58DC (17783004), len: 276  VirtAddr: 0x010F58DC RVA: 0x010F58DC token: 100663456 methodIndex: 28889 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType FindGenericArgument(string key)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x010F58DC: STP x24, x23, [sp, #-0x40]! | stack[1152921510000995168] = ???;  stack[1152921510000995176] = ???;  //  dest_result_addr=1152921510000995168 |  dest_result_addr=1152921510000995176
            // 0x010F58E0: STP x22, x21, [sp, #0x10]  | stack[1152921510000995184] = ???;  stack[1152921510000995192] = ???;  //  dest_result_addr=1152921510000995184 |  dest_result_addr=1152921510000995192
            // 0x010F58E4: STP x20, x19, [sp, #0x20]  | stack[1152921510000995200] = ???;  stack[1152921510000995208] = ???;  //  dest_result_addr=1152921510000995200 |  dest_result_addr=1152921510000995208
            // 0x010F58E8: STP x29, x30, [sp, #0x30]  | stack[1152921510000995216] = ???;  stack[1152921510000995224] = ???;  //  dest_result_addr=1152921510000995216 |  dest_result_addr=1152921510000995224
            // 0x010F58EC: ADD x29, sp, #0x30         | X29 = (1152921510000995168 + 48) = 1152921510000995216 (0x1000000141842B90);
            // 0x010F58F0: SUB sp, sp, #0x10          | SP = (1152921510000995168 - 16) = 1152921510000995152 (0x1000000141842B50);
            // 0x010F58F4: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010F58F8: LDRB w8, [x21, #0xb07]     | W8 = (bool)static_value_03735B07;       
            // 0x010F58FC: MOV x19, x1                | X19 = key;//m1                          
            // 0x010F5900: MOV x20, x0                | X20 = 1152921510001007232 (0x1000000141845A80);//ML01
            // 0x010F5904: TBNZ w8, #0, #0x10f5920    | if (static_value_03735B07 == true) goto label_0;
            // 0x010F5908: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x010F590C: LDR x8, [x8, #0xee8]       | X8 = 0x2B90D10;                         
            // 0x010F5910: LDR w0, [x8]               | W0 = 0x1A08;                            
            // 0x010F5914: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A08, ????);     
            // 0x010F5918: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F591C: STRB w8, [x21, #0xb07]     | static_value_03735B07 = true;            //  dest_result_addr=57891591
            label_0:
            // 0x010F5920: STP xzr, xzr, [sp]         | stack[1152921510000995152] = 0x0;  stack[1152921510000995160] = 0x0;  //  dest_result_addr=1152921510000995152 |  dest_result_addr=1152921510000995160
            // 0x010F5924: LDR x21, [x20, #0x38]      | X21 = this.genericArguments; //P2       
            // 0x010F5928: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_3 = 0;
            // 0x010F592C: CBZ x21, #0x10f59d8        | if (this.genericArguments == null) goto label_7;
            if(this.genericArguments == null)
            {
                goto label_7;
            }
            // 0x010F5930: ADRP x23, #0x361e000       | X23 = 56745984 (0x361E000);             
            // 0x010F5934: ADRP x24, #0x35d6000       | X24 = 56451072 (0x35D6000);             
            // 0x010F5938: LDR x23, [x23, #0x1f0]     | X23 = 1152921509989978176;              
            // 0x010F593C: LDR x24, [x24, #0xe38]     | X24 = 1152921504608284672;              
            // 0x010F5940: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            var val_4 = 0;
            label_6:
            // 0x010F5944: LDR w8, [x21, #0x18]       | W8 = this.genericArguments.Length; //P2 
            // 0x010F5948: CMP w22, w8                | STATE = COMPARE(0x0, this.genericArguments.Length)
            // 0x010F594C: B.GE #0x10f59d4            | if (0 >= this.genericArguments.Length) goto label_2;
            if(val_4 >= this.genericArguments.Length)
            {
                goto label_2;
            }
            // 0x010F5950: SXTW x20, w22              | X20 = 0 (0x00000000);                   
            // 0x010F5954: CMP w22, w8                | STATE = COMPARE(0x0, this.genericArguments.Length)
            // 0x010F5958: B.LO #0x10f5968            | if (0 < this.genericArguments.Length) goto label_3;
            if(val_4 < this.genericArguments.Length)
            {
                goto label_3;
            }
            // 0x010F595C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x010F5960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5964: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_3:
            // 0x010F5968: ADD x8, x21, x20, lsl #4   | X8 = this.genericArguments[0x0]; //PARR1 
            // 0x010F596C: LDR q0, [x8, #0x20]        | Q0 = this.genericArguments[0x0][0]      
            System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType> val_3 = this.genericArguments[0];
            // 0x010F5970: LDR x1, [x23]              | X1 = public System.String System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>::get_Key();
            // 0x010F5974: MOV x0, sp                 | X0 = 1152921510000995152 (0x1000000141842B50);//ML01
            // 0x010F5978: STR q0, [sp]               | stack[1152921510000995152] = this.genericArguments[0x0][0];  //  dest_result_addr=1152921510000995152
            // 0x010F597C: BL #0x1dc9dd4              | X0 = this.genericArguments[0x0][0].get_InitialType();
            System.Type val_1 = val_3.InitialType;
            // 0x010F5980: LDR x8, [x24]              | X8 = typeof(System.String);             
            // 0x010F5984: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x010F5988: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x010F598C: TBZ w9, #0, #0x10f59a0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x010F5990: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x010F5994: CBNZ w9, #0x10f59a0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x010F5998: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x010F599C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_5:
            // 0x010F59A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F59A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F59A8: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x010F59AC: MOV x2, x19                | X2 = key;//m1                           
            // 0x010F59B0: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_1);
            bool val_2 = System.String.op_Equality(a:  0, b:  val_1);
            // 0x010F59B4: ADD w22, w22, #1           | W22 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x010F59B8: TBZ w0, #0, #0x10f5944     | if (val_2 == false) goto label_6;       
            if(val_2 == false)
            {
                goto label_6;
            }
            // 0x010F59BC: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x010F59C0: LDR x8, [x8, #0xa88]       | X8 = 1152921509989983296;               
            // 0x010F59C4: MOV x0, sp                 | X0 = 1152921510000995152 (0x1000000141842B50);//ML01
            val_3;
            // 0x010F59C8: LDR x1, [x8]               | X1 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>::get_Value();
            // 0x010F59CC: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x010F59D0: B #0x10f59d8               |  goto label_7;                          
            goto label_7;
            label_2:
            // 0x010F59D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_3 = 0;
            label_7:
            // 0x010F59D8: SUB sp, x29, #0x30         | SP = (1152921510000995216 - 48) = 1152921510000995168 (0x1000000141842B60);
            // 0x010F59DC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010F59E0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010F59E4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010F59E8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010F59EC: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)null;
            return (ILRuntime.CLR.TypeSystem.IType)val_3;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F59F0 (17783280), len: 384  VirtAddr: 0x010F59F0 RVA: 0x010F59F0 token: 100663457 methodIndex: 28890 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.Method.IMethod GetMethod(string name, int paramCount, bool declaredOnly = False)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>> val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x010F59F0: STP x22, x21, [sp, #-0x30]! | stack[1152921510001168624] = ???;  stack[1152921510001168632] = ???;  //  dest_result_addr=1152921510001168624 |  dest_result_addr=1152921510001168632
            // 0x010F59F4: STP x20, x19, [sp, #0x10]  | stack[1152921510001168640] = ???;  stack[1152921510001168648] = ???;  //  dest_result_addr=1152921510001168640 |  dest_result_addr=1152921510001168648
            // 0x010F59F8: STP x29, x30, [sp, #0x20]  | stack[1152921510001168656] = ???;  stack[1152921510001168664] = ???;  //  dest_result_addr=1152921510001168656 |  dest_result_addr=1152921510001168664
            // 0x010F59FC: ADD x29, sp, #0x20         | X29 = (1152921510001168624 + 32) = 1152921510001168656 (0x100000014186D110);
            // 0x010F5A00: SUB sp, sp, #0x20          | SP = (1152921510001168624 - 32) = 1152921510001168592 (0x100000014186D0D0);
            // 0x010F5A04: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
            // 0x010F5A08: LDRB w8, [x22, #0xb08]     | W8 = (bool)static_value_03735B08;       
            // 0x010F5A0C: MOV w19, w2                | W19 = paramCount;//m1                   
            val_5 = paramCount;
            // 0x010F5A10: MOV x20, x1                | X20 = name;//m1                         
            // 0x010F5A14: MOV x21, x0                | X21 = 1152921510001180672 (0x1000000141870000);//ML01
            val_6 = this;
            // 0x010F5A18: TBNZ w8, #0, #0x10f5a34    | if (static_value_03735B08 == true) goto label_0;
            // 0x010F5A1C: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x010F5A20: LDR x8, [x8, #0x610]       | X8 = 0x2B90D44;                         
            // 0x010F5A24: LDR w0, [x8]               | W0 = 0x1A15;                            
            // 0x010F5A28: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A15, ????);     
            // 0x010F5A2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F5A30: STRB w8, [x22, #0xb08]     | static_value_03735B08 = true;            //  dest_result_addr=57891592
            label_0:
            // 0x010F5A34: STP xzr, xzr, [sp, #0x10]  | stack[1152921510001168608] = 0x0;  stack[1152921510001168616] = 0x0;  //  dest_result_addr=1152921510001168608 |  dest_result_addr=1152921510001168616
            System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> val_1 = 0;
            // 0x010F5A38: STP xzr, xzr, [sp]         | stack[1152921510001168592] = 0x0;  stack[1152921510001168600] = 0x0;  //  dest_result_addr=1152921510001168592 |  dest_result_addr=1152921510001168600
            // 0x010F5A3C: LDR x0, [x21, #0x20]       | X0 = this.methods; //P2                 
            val_7 = this.methods;
            // 0x010F5A40: CBNZ x0, #0x10f5a5c        | if (this.methods != null) goto label_2; 
            if(val_7 != null)
            {
                goto label_2;
            }
            // 0x010F5A44: MOV x0, x21                | X0 = 1152921510001180672 (0x1000000141870000);//ML01
            // 0x010F5A48: BL #0x10f4304              | this.InitializeMethods();               
            this.InitializeMethods();
            // 0x010F5A4C: LDR x0, [x21, #0x20]       | X0 = this.methods; //P2                 
            val_7 = this.methods;
            // 0x010F5A50: CBNZ x0, #0x10f5a5c        | if (this.methods != null) goto label_2; 
            if(val_7 != null)
            {
                goto label_2;
            }
            // 0x010F5A54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.methods, ????);
            // 0x010F5A58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_7 = 0;
            label_2:
            // 0x010F5A5C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x010F5A60: LDR x8, [x8, #0x9c0]       | X8 = 1152921509999961408;               
            // 0x010F5A64: ADD x2, sp, #0x18          | X2 = (1152921510001168592 + 24) = 1152921510001168616 (0x100000014186D0E8);
            // 0x010F5A68: MOV x1, x20                | X1 = name;//m1                          
            // 0x010F5A6C: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::TryGetValue(System.String key, out System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> value);
            // 0x010F5A70: BL #0x23fe7ec              | X0 = val_7.TryGetValue(key:  name, value: out  System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> val_1 = 0);
            bool val_2 = val_7.TryGetValue(key:  name, value: out  val_1);
            // 0x010F5A74: TBZ w0, #0, #0x10f5b54     | if (val_2 == false) goto label_12;      
            if(val_2 == false)
            {
                goto label_12;
            }
            // 0x010F5A78: LDR x20, [sp, #0x18]       | X20 = 0x0;                              
            // 0x010F5A7C: CBNZ x20, #0x10f5a84       | if (0x0 != 0) goto label_4;             
            if(val_1 != 0)
            {
                goto label_4;
            }
            // 0x010F5A80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x010F5A84: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x010F5A88: LDR x8, [x8, #0x360]       | X8 = 1152921510000228032;               
            // 0x010F5A8C: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x010F5A90: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>::GetEnumerator();
            // 0x010F5A94: MOV x8, sp                 | X8 = 1152921510001168592 (0x100000014186D0D0);//ML01
            // 0x010F5A98: BL #0x25ebf2c              | X0 = val_1.GetEnumerator();             
            List.Enumerator<T> val_3 = val_1.GetEnumerator();
            // 0x010F5A9C: ADRP x21, #0x35e4000       | X21 = 56508416 (0x35E4000);             
            // 0x010F5AA0: ADRP x22, #0x3667000       | X22 = 57044992 (0x3667000);             
            // 0x010F5AA4: LDR x21, [x21, #0x468]     | X21 = 1152921510000223936;              
            val_6 = 1152921510000223936;
            // 0x010F5AA8: LDR x22, [x22, #0x380]     | X22 = 1152921510000224960;              
            label_9:
            // 0x010F5AAC: LDR x1, [x21]              | X1 = public System.Boolean List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::MoveNext();
            // 0x010F5AB0: MOV x0, sp                 | X0 = 1152921510001168592 (0x100000014186D0D0);//ML01
            // 0x010F5AB4: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x010F5AB8: AND w8, w0, #1             | W8 = ( & 1) = 0 (0x00000000);           
            // 0x010F5ABC: TBZ w8, #0, #0x10f5b40     | if ((0x0 & 0x1) == 0) goto label_5;     
            if((0 & 1) == 0)
            {
                goto label_5;
            }
            // 0x010F5AC0: LDR x1, [x22]              | X1 = public ILRuntime.CLR.Method.CLRMethod List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::get_Current();
            // 0x010F5AC4: MOV x0, sp                 | X0 = 1152921510001168592 (0x100000014186D0D0);//ML01
            // 0x010F5AC8: BL #0x13372d8              | X0 = null.get_InitialType();            
            System.Type val_4 = 0.InitialType;
            // 0x010F5ACC: MOV x20, x0                | X20 = val_4;//m1                        
            val_8 = val_4;
            // 0x010F5AD0: CBNZ x20, #0x10f5ad8       | if (val_4 != null) goto label_6;        
            if(val_8 != null)
            {
                goto label_6;
            }
            // 0x010F5AD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_6:
            // 0x010F5AD8: LDR x8, [x20, #0x40]       | 
            // 0x010F5ADC: CBZ x8, #0x10f5ae8         | if (0x464C457F == 0) goto label_7;      
            if(1179403647 == 0)
            {
                goto label_7;
            }
            // 0x010F5AE0: LDR w8, [x8, #0x18]        | W8 = 0x9814C0;                          
            val_9 = 9966784;
            // 0x010F5AE4: B #0x10f5aec               |  goto label_8;                          
            goto label_8;
            label_7:
            // 0x010F5AE8: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
            val_9 = 0;
            label_8:
            // 0x010F5AEC: CMP w8, w19                | STATE = COMPARE(0x0, paramCount)        
            // 0x010F5AF0: B.NE #0x10f5aac            | if (val_9 != val_5) goto label_9;       
            if(val_9 != val_5)
            {
                goto label_9;
            }
            // 0x010F5AF4: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F5AF8: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F5AFC: MOV x0, sp                 | X0 = 1152921510001168592 (0x100000014186D0D0);//ML01
            // 0x010F5B00: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F5B04: BL #0x13371f4              | null.Dispose();                         
            0.Dispose();
            // 0x010F5B08: B #0x10f5b58               |  goto label_10;                         
            goto label_10;
            // 0x010F5B0C: BL #0x981060               | X0 = sub_981060( ?? 0x100000014186D0D0, ????);
            // 0x010F5B10: LDR x19, [x0]              | X19 = 0x0;                              
            val_5 = 0;
            // 0x010F5B14: BL #0x980920               | X0 = sub_980920( ?? 0x100000014186D0D0, ????);
            // 0x010F5B18: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F5B1C: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F5B20: MOV x0, sp                 | X0 = 1152921510001168592 (0x100000014186D0D0);//ML01
            // 0x010F5B24: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F5B28: BL #0x13371f4              | null.Dispose();                         
            0.Dispose();
            // 0x010F5B2C: CBZ x19, #0x10f5b54        | if (0x0 == 0) goto label_12;            
            if(val_5 == 0)
            {
                goto label_12;
            }
            // 0x010F5B30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5B34: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x010F5B38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x010F5B3C: B #0x10f5b54               |  goto label_12;                         
            goto label_12;
            label_5:
            // 0x010F5B40: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F5B44: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F5B48: MOV x0, sp                 | X0 = 1152921510001168592 (0x100000014186D0D0);//ML01
            // 0x010F5B4C: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F5B50: BL #0x13371f4              | null.Dispose();                         
            0.Dispose();
            label_12:
            // 0x010F5B54: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_10:
            // 0x010F5B58: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x010F5B5C: SUB sp, x29, #0x20         | SP = (1152921510001168656 - 32) = 1152921510001168624 (0x100000014186D0F0);
            // 0x010F5B60: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F5B64: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F5B68: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F5B6C: RET                        |  return (ILRuntime.CLR.Method.IMethod)null;
            return (ILRuntime.CLR.Method.IMethod)val_8;
            //  |  // // {name=val_0, type=ILRuntime.CLR.Method.IMethod, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F5B70 (17783664), len: 960  VirtAddr: 0x010F5B70 RVA: 0x010F5B70 token: 100663458 methodIndex: 28891 delegateWrapperIndex: 0 methodInvoker: 0
        private bool MatchGenericParameters(System.Type[] args, System.Type type, System.Type q, ILRuntime.CLR.TypeSystem.IType[] genericArguments)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            label_43:
            // 0x010F5B70: STP x26, x25, [sp, #-0x50]! | stack[1152921510001388112] = ???;  stack[1152921510001388120] = ???;  //  dest_result_addr=1152921510001388112 |  dest_result_addr=1152921510001388120
            // 0x010F5B74: STP x24, x23, [sp, #0x10]  | stack[1152921510001388128] = ???;  stack[1152921510001388136] = ???;  //  dest_result_addr=1152921510001388128 |  dest_result_addr=1152921510001388136
            // 0x010F5B78: STP x22, x21, [sp, #0x20]  | stack[1152921510001388144] = ???;  stack[1152921510001388152] = ???;  //  dest_result_addr=1152921510001388144 |  dest_result_addr=1152921510001388152
            // 0x010F5B7C: STP x20, x19, [sp, #0x30]  | stack[1152921510001388160] = ???;  stack[1152921510001388168] = ???;  //  dest_result_addr=1152921510001388160 |  dest_result_addr=1152921510001388168
            // 0x010F5B80: STP x29, x30, [sp, #0x40]  | stack[1152921510001388176] = ???;  stack[1152921510001388184] = ???;  //  dest_result_addr=1152921510001388176 |  dest_result_addr=1152921510001388184
            // 0x010F5B84: ADD x29, sp, #0x40         | X29 = (1152921510001388112 + 64) = 1152921510001388176 (0x10000001418A2A90);
            // 0x010F5B88: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x010F5B8C: LDR x8, [x8, #0x248]       | X8 = 0x2B90D6C;                         
            // 0x010F5B90: MOV x19, x4                | X19 = genericArguments;//m1             
            val_9 = genericArguments;
            // 0x010F5B94: MOV x21, x3                | X21 = q;//m1                            
            val_10 = q;
            // 0x010F5B98: MOV x23, x2                | X23 = type;//m1                         
            // 0x010F5B9C: LDR w24, [x8]              | W24 = 0x1A1F;                           
            // 0x010F5BA0: MOV x20, x1                | X20 = args;//m1                         
            // 0x010F5BA4: MOV x22, x0                | X22 = 1152921510001400192 (0x10000001418A5980);//ML01
            // 0x010F5BA8: ADRP x25, #0x3735000       | X25 = 57888768 (0x3735000);             
            // 0x010F5BAC: ORR w26, wzr, #1           | W26 = 1(0x1);                           
            // 0x010F5BB0: B #0x10f5bcc               |  goto label_0;                          
            goto label_0;
            label_13:
            // 0x010F5BB4: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x010F5BB8: MOV x0, x21                | X0 = q;//m1                             
            // 0x010F5BBC: LDR x9, [x8, #0x410]       | X9 = typeof(System.Type).__il2cppRuntimeField_410;
            // 0x010F5BC0: LDR x1, [x8, #0x418]       | X1 = typeof(System.Type).__il2cppRuntimeField_418;
            // 0x010F5BC4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_410();
            // 0x010F5BC8: MOV x21, x0                | X21 = q;//m1                            
            val_10 = val_10;
            label_0:
            // 0x010F5BCC: LDRB w8, [x25, #0xb09]     | W8 = (bool)static_value_03735B09;       
            // 0x010F5BD0: TBNZ w8, #0, #0x10f5be0    | if (static_value_03735B09 == true) goto label_1;
            // 0x010F5BD4: MOV w0, w24                | W0 = 6687 (0x1A1F);//ML01               
            // 0x010F5BD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A1F, ????);     
            // 0x010F5BDC: STRB w26, [x25, #0xb09]    | static_value_03735B09 = true;            //  dest_result_addr=57891593
            label_1:
            // 0x010F5BE0: CBNZ x23, #0x10f5be8       | if (type != null) goto label_2;         
            if(type != null)
            {
                goto label_2;
            }
            // 0x010F5BE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A1F, ????);     
            label_2:
            // 0x010F5BE8: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F5BEC: MOV x0, x23                | X0 = type;//m1                          
            // 0x010F5BF0: LDR x9, [x8, #0x780]       | X9 = typeof(System.Type).__il2cppRuntimeField_780;
            // 0x010F5BF4: LDR x1, [x8, #0x788]       | X1 = typeof(System.Type).__il2cppRuntimeField_788;
            // 0x010F5BF8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_780();
            // 0x010F5BFC: TBNZ w0, #0, #0x10f5c80    | if ((type & 0x1) != 0) goto label_3;    
            if((type & 1) != 0)
            {
                goto label_3;
            }
            // 0x010F5C00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5C04: MOV x0, x23                | X0 = type;//m1                          
            // 0x010F5C08: BL #0x1b6d1cc              | X0 = type.get_IsArray();                
            bool val_1 = type.IsArray;
            // 0x010F5C0C: TBZ w0, #0, #0x10f5c2c     | if (val_1 == false) goto label_4;       
            if(val_1 == false)
            {
                goto label_4;
            }
            // 0x010F5C10: CBNZ x21, #0x10f5c18       | if (q != null) goto label_5;            
            if(val_10 != null)
            {
                goto label_5;
            }
            // 0x010F5C14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x010F5C18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5C1C: MOV x0, x21                | X0 = q;//m1                             
            // 0x010F5C20: BL #0x1b6d1cc              | X0 = q.get_IsArray();                   
            bool val_2 = val_10.IsArray;
            // 0x010F5C24: TBNZ w0, #0, #0x10f5c54    | if (val_2 == true) goto label_6;        
            if(val_2 == true)
            {
                goto label_6;
            }
            // 0x010F5C28: B #0x10f5dc4               |  goto label_28;                         
            goto label_28;
            label_4:
            // 0x010F5C2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5C30: MOV x0, x23                | X0 = type;//m1                          
            // 0x010F5C34: BL #0x1b6d1dc              | X0 = type.get_IsByRef();                
            bool val_3 = type.IsByRef;
            // 0x010F5C38: TBZ w0, #0, #0x10f5d48     | if (val_3 == false) goto label_8;       
            if(val_3 == false)
            {
                goto label_8;
            }
            // 0x010F5C3C: CBNZ x21, #0x10f5c44       | if (q != null) goto label_9;            
            if(val_10 != null)
            {
                goto label_9;
            }
            // 0x010F5C40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x010F5C44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5C48: MOV x0, x21                | X0 = q;//m1                             
            // 0x010F5C4C: BL #0x1b6d1dc              | X0 = q.get_IsByRef();                   
            bool val_4 = val_10.IsByRef;
            // 0x010F5C50: TBZ w0, #0, #0x10f5dc4     | if (val_4 == false) goto label_28;      
            if(val_4 == false)
            {
                goto label_28;
            }
            label_6:
            // 0x010F5C54: CBNZ x23, #0x10f5c5c       | if (type != null) goto label_11;        
            if(type != null)
            {
                goto label_11;
            }
            // 0x010F5C58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_11:
            // 0x010F5C5C: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F5C60: MOV x0, x23                | X0 = type;//m1                          
            // 0x010F5C64: LDR x9, [x8, #0x410]       | X9 = typeof(System.Type).__il2cppRuntimeField_410;
            // 0x010F5C68: LDR x1, [x8, #0x418]       | X1 = typeof(System.Type).__il2cppRuntimeField_418;
            // 0x010F5C6C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_410();
            // 0x010F5C70: MOV x23, x0                | X23 = type;//m1                         
            // 0x010F5C74: CBNZ x21, #0x10f5bb4       | if (q != null) goto label_13;           
            if(val_10 != null)
            {
                goto label_13;
            }
            // 0x010F5C78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type, ????);       
            // 0x010F5C7C: B #0x10f5bb4               |  goto label_13;                         
            goto label_13;
            label_3:
            // 0x010F5C80: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x010F5C84: B #0x10f5c8c               |  goto label_14;                         
            goto label_14;
            label_18:
            // 0x010F5C88: ADD w22, w22, #1           | W22 = (val_11 + 1) = val_11 (0x00000001);
            val_11 = 1;
            label_14:
            // 0x010F5C8C: CBNZ x20, #0x10f5c94       | if (args != null) goto label_15;        
            if(args != null)
            {
                goto label_15;
            }
            // 0x010F5C90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type, ????);       
            label_15:
            // 0x010F5C94: LDR w8, [x20, #0x18]       | W8 = args.Length; //P2                  
            // 0x010F5C98: CMP w22, w8                | STATE = COMPARE(0x1, args.Length)       
            // 0x010F5C9C: B.GE #0x10f5efc            | if (val_11 >= args.Length) goto label_16;
            if(val_11 >= args.Length)
            {
                goto label_16;
            }
            // 0x010F5CA0: SXTW x24, w22              | X24 = 1 (0x00000001);                   
            // 0x010F5CA4: CMP w22, w8                | STATE = COMPARE(0x1, args.Length)       
            // 0x010F5CA8: B.LO #0x10f5cb8            | if (val_11 < args.Length) goto label_17;
            if(val_11 < args.Length)
            {
                goto label_17;
            }
            // 0x010F5CAC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? type, ????);       
            // 0x010F5CB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5CB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? type, ????);       
            label_17:
            // 0x010F5CB8: ADD x8, x20, x24, lsl #3   | X8 = args[0x1]; //PARR1                 
            // 0x010F5CBC: LDR x8, [x8, #0x20]        | X8 = args[0x1][0]                       
            System.Type val_9 = args[1];
            // 0x010F5CC0: CMP x8, x23                | STATE = COMPARE(args[0x1][0], type)     
            // 0x010F5CC4: B.NE #0x10f5c88            | if (args[1] != type) goto label_18;     
            if(val_9 != type)
            {
                goto label_18;
            }
            // 0x010F5CC8: CBNZ x19, #0x10f5cd0       | if (genericArguments != null) goto label_19;
            if(val_9 != null)
            {
                goto label_19;
            }
            // 0x010F5CCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type, ????);       
            label_19:
            // 0x010F5CD0: LDR w8, [x19, #0x18]       | W8 = genericArguments.Length; //P2      
            // 0x010F5CD4: CMP w22, w8                | STATE = COMPARE(0x1, genericArguments.Length)
            // 0x010F5CD8: B.LO #0x10f5ce8            | if (val_11 < genericArguments.Length) goto label_20;
            if(val_11 < genericArguments.Length)
            {
                goto label_20;
            }
            // 0x010F5CDC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? type, ????);       
            // 0x010F5CE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5CE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? type, ????);       
            label_20:
            // 0x010F5CE8: ADD x8, x19, x24, lsl #3   | X8 = genericArguments[0x1]; //PARR1     
            // 0x010F5CEC: LDR x19, [x8, #0x20]       | X19 = genericArguments[0x1][0]          
            val_9 = val_9[1];
            // 0x010F5CF0: CBNZ x19, #0x10f5cf8       | if (genericArguments[0x1][0] != null) goto label_21;
            if(val_9 != null)
            {
                goto label_21;
            }
            // 0x010F5CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type, ????);       
            label_21:
            // 0x010F5CF8: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F5CFC: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5D00: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F5D04: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5D08: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F5D0C: CBZ x9, #0x10f5d38         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
            // 0x010F5D10: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F5D14: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x010F5D18: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_24:
            // 0x010F5D1C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F5D20: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F5D24: B.EQ #0x10f5dcc            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_23;
            // 0x010F5D28: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x010F5D2C: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F5D30: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F5D34: B.LO #0x10f5d1c            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_24;
            label_22:
            // 0x010F5D38: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F5D3C: MOV x0, x19                | X0 = genericArguments[0x1][0];//m1      
            val_12 = val_9;
            // 0x010F5D40: BL #0x2776c24              | X0 = sub_2776C24( ?? genericArguments[0x1][0], ????);
            // 0x010F5D44: B #0x10f5ddc               |  goto label_25;                         
            goto label_25;
            label_8:
            // 0x010F5D48: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F5D4C: MOV x0, x23                | X0 = type;//m1                          
            // 0x010F5D50: LDR x9, [x8, #0x760]       | X9 = typeof(System.Type).__il2cppRuntimeField_760;
            // 0x010F5D54: LDR x1, [x8, #0x768]       | X1 = typeof(System.Type).__il2cppRuntimeField_768;
            // 0x010F5D58: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_760();
            // 0x010F5D5C: TBZ w0, #0, #0x10f5df0     | if ((type & 0x1) == 0) goto label_26;   
            if((type & 1) == 0)
            {
                goto label_26;
            }
            // 0x010F5D60: CBNZ x21, #0x10f5d68       | if (q != null) goto label_27;           
            if(val_10 != null)
            {
                goto label_27;
            }
            // 0x010F5D64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type, ????);       
            label_27:
            // 0x010F5D68: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x010F5D6C: MOV x0, x21                | X0 = q;//m1                             
            // 0x010F5D70: LDR x9, [x8, #0x760]       | X9 = typeof(System.Type).__il2cppRuntimeField_760;
            // 0x010F5D74: LDR x1, [x8, #0x768]       | X1 = typeof(System.Type).__il2cppRuntimeField_768;
            // 0x010F5D78: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_760();
            // 0x010F5D7C: TBZ w0, #0, #0x10f5dc4     | if ((q & 0x1) == 0) goto label_28;      
            if((val_10 & 1) == 0)
            {
                goto label_28;
            }
            // 0x010F5D80: CBNZ x23, #0x10f5d88       | if (type != null) goto label_29;        
            if(type != null)
            {
                goto label_29;
            }
            // 0x010F5D84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? q, ????);          
            label_29:
            // 0x010F5D88: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F5D8C: MOV x0, x23                | X0 = type;//m1                          
            // 0x010F5D90: LDR x9, [x8, #0x750]       | X9 = typeof(System.Type).__il2cppRuntimeField_750;
            // 0x010F5D94: LDR x1, [x8, #0x758]       | X1 = typeof(System.Type).__il2cppRuntimeField_758;
            // 0x010F5D98: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_750();
            // 0x010F5D9C: MOV x24, x0                | X24 = type;//m1                         
            // 0x010F5DA0: CBNZ x23, #0x10f5da8       | if (type != null) goto label_30;        
            if(type != null)
            {
                goto label_30;
            }
            // 0x010F5DA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type, ????);       
            label_30:
            // 0x010F5DA8: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F5DAC: MOV x0, x23                | X0 = type;//m1                          
            // 0x010F5DB0: LDR x9, [x8, #0x750]       | X9 = typeof(System.Type).__il2cppRuntimeField_750;
            // 0x010F5DB4: LDR x1, [x8, #0x758]       | X1 = typeof(System.Type).__il2cppRuntimeField_758;
            // 0x010F5DB8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_750();
            // 0x010F5DBC: CMP x24, x0                | STATE = COMPARE(type, type)             
            // 0x010F5DC0: B.EQ #0x10f5e10            | if (type == type) goto label_31;        
            if(type == type)
            {
                goto label_31;
            }
            label_28:
            // 0x010F5DC4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_13 = 0;
            // 0x010F5DC8: B #0x10f5df8               |  goto label_46;                         
            goto label_46;
            label_23:
            // 0x010F5DCC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F5DD0: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F5DD4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F5DD8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_25:
            // 0x010F5DDC: LDP x8, x1, [x0]           | X8 = typeof(System.Type);                //  | 
            // 0x010F5DE0: MOV x0, x19                | X0 = genericArguments[0x1][0];//m1      
            // 0x010F5DE4: BLR x8                     | X0 = sub_1000000000297000( ?? genericArguments[0x1][0], ????);
            // 0x010F5DE8: CMP x0, x21                | STATE = COMPARE(genericArguments[0x1][0], q)
            // 0x010F5DEC: B #0x10f5df4               |  goto label_33;                         
            goto label_33;
            label_26:
            // 0x010F5DF0: CMP x23, x21               | STATE = COMPARE(type, q)                
            label_33:
            // 0x010F5DF4: CSET w0, eq                | W0 = type == val_10 ? 1 : 0;            
            var val_6 = (type == val_10) ? 1 : 0;
            label_46:
            // 0x010F5DF8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x010F5DFC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x010F5E00: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x010F5E04: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x010F5E08: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x010F5E0C: RET                        |  return (System.Boolean)type == val_10 ? 1 : 0;
            return (bool)val_6;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_31:
            // 0x010F5E10: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x010F5E14: MOV x0, x23                | X0 = type;//m1                          
            // 0x010F5E18: LDR x9, [x8, #0x720]       | X9 = typeof(System.Type).__il2cppRuntimeField_720;
            // 0x010F5E1C: LDR x1, [x8, #0x728]       | X1 = typeof(System.Type).__il2cppRuntimeField_728;
            // 0x010F5E20: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_720();
            // 0x010F5E24: MOV x23, x0                | X23 = type;//m1                         
            // 0x010F5E28: CBNZ x21, #0x10f5e30       | if (q != null) goto label_34;           
            if(val_10 != null)
            {
                goto label_34;
            }
            // 0x010F5E2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type, ????);       
            label_34:
            // 0x010F5E30: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x010F5E34: MOV x0, x21                | X0 = q;//m1                             
            // 0x010F5E38: LDR x9, [x8, #0x720]       | X9 = typeof(System.Type).__il2cppRuntimeField_720;
            // 0x010F5E3C: LDR x1, [x8, #0x728]       | X1 = typeof(System.Type).__il2cppRuntimeField_728;
            // 0x010F5E40: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_720();
            // 0x010F5E44: MOV x21, x0                | X21 = q;//m1                            
            // 0x010F5E48: CBNZ x23, #0x10f5e50       | if (type != null) goto label_35;        
            if(type != null)
            {
                goto label_35;
            }
            // 0x010F5E4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? q, ????);          
            label_35:
            // 0x010F5E50: CBNZ x21, #0x10f5e58       | if (q != null) goto label_36;           
            if(val_10 != null)
            {
                goto label_36;
            }
            // 0x010F5E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? q, ????);          
            label_36:
            // 0x010F5E58: LDR w8, [x23, #0x18]       | 
            // 0x010F5E5C: LDR w9, [x21, #0x18]       | 
            // 0x010F5E60: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x010F5E64: CMP w8, w9                 | STATE = COMPARE(typeof(System.Type), typeof(System.Type).__il2cppRuntimeField_720)
            // 0x010F5E68: B.NE #0x10f5df8            | if (typeof(System.Type) != typeof(System.Type).__il2cppRuntimeField_720) goto label_46;
            // 0x010F5E6C: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            var val_11 = 0;
            label_44:
            // 0x010F5E70: CBNZ x23, #0x10f5e78       | if (type != null) goto label_38;        
            if(type != null)
            {
                goto label_38;
            }
            // 0x010F5E74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_38:
            // 0x010F5E78: LDR w8, [x23, #0x18]       | 
            // 0x010F5E7C: CMP w25, w8                | STATE = COMPARE(0x0, typeof(System.Type))
            // 0x010F5E80: B.GE #0x10f5ef4            | if (0 >= typeof(System.Type)) goto label_39;
            if(val_11 >= null)
            {
                goto label_39;
            }
            // 0x010F5E84: SXTW x26, w25              | X26 = 0 (0x00000000);                   
            // 0x010F5E88: CMP w25, w8                | STATE = COMPARE(0x0, typeof(System.Type))
            // 0x010F5E8C: B.LO #0x10f5e9c            | if (0 < typeof(System.Type)) goto label_40;
            if(val_11 < null)
            {
                goto label_40;
            }
            // 0x010F5E90: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x010F5E94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5E98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_40:
            // 0x010F5E9C: ADD x8, x23, x26, lsl #3   | X8 = typeof(System.Type);//AP1          
            // 0x010F5EA0: LDR x24, [x8, #0x20]       | X24 = System.Type.__il2cppRuntimeField_byval_arg;
            // 0x010F5EA4: CBNZ x21, #0x10f5eac       | if (q != null) goto label_41;           
            if(val_10 != null)
            {
                goto label_41;
            }
            // 0x010F5EA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_41:
            // 0x010F5EAC: LDR w8, [x21, #0x18]       | 
            // 0x010F5EB0: CMP w25, w8                | STATE = COMPARE(0x0, typeof(System.Type))
            // 0x010F5EB4: B.LO #0x10f5ec4            | if (0 < typeof(System.Type)) goto label_42;
            if(val_11 < null)
            {
                goto label_42;
            }
            // 0x010F5EB8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x010F5EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5EC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_42:
            // 0x010F5EC4: ADD x8, x21, x26, lsl #3   | X8 = typeof(System.Type);//AP1          
            // 0x010F5EC8: LDR x3, [x8, #0x20]        | X3 = System.Type.__il2cppRuntimeField_byval_arg;
            // 0x010F5ECC: MOV x0, x22                | X0 = 1152921510001400192 (0x10000001418A5980);//ML01
            // 0x010F5ED0: MOV x1, x20                | X1 = args;//m1                          
            // 0x010F5ED4: MOV x2, x24                | X2 = System.Type.__il2cppRuntimeField_byval_arg;//m1
            // 0x010F5ED8: MOV x4, x19                | X4 = genericArguments;//m1              
            // 0x010F5EDC: BL #0x10f5b70              |  R0 = label_43();                       
            // 0x010F5EE0: MOV w8, w0                 | W8 = 1152921510001400192 (0x10000001418A5980);//ML01
            // 0x010F5EE4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x010F5EE8: ADD w25, w25, #1           | W25 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x010F5EEC: TBNZ w8, #0, #0x10f5e70    | if ((this & 0x1) != 0) goto label_44;   
            if((this & 1) != 0)
            {
                goto label_44;
            }
            // 0x010F5EF0: B #0x10f5df8               |  goto label_46;                         
            goto label_46;
            label_39:
            // 0x010F5EF4: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x010F5EF8: B #0x10f5df8               |  goto label_46;                         
            goto label_46;
            label_16:
            // 0x010F5EFC: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x010F5F00: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x010F5F04: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
            System.NotSupportedException val_7 = null;
            // 0x010F5F08: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x010F5F0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5F10: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x010F5F14: BL #0x1701574              | .ctor();                                
            val_7 = new System.NotSupportedException();
            // 0x010F5F18: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x010F5F1C: LDR x8, [x8, #0x7a0]       | X8 = 1152921510001375168;               
            // 0x010F5F20: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_8 = val_7;
            // 0x010F5F24: LDR x1, [x8]               | X1 = System.Boolean ILRuntime.CLR.TypeSystem.CLRType::MatchGenericParameters(System.Type[] args, System.Type type, System.Type q, ILRuntime.CLR.TypeSystem.IType[] genericArguments);
            // 0x010F5F28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x010F5F2C: BL #0x10ec5ac              | .ctor(def:  System.Boolean ILRuntime.CLR.TypeSystem.CLRType::MatchGenericParameters(System.Type[] args, System.Type type, System.Type q, ILRuntime.CLR.TypeSystem.IType[] genericArguments), type:  type, domain:  q);
            val_8 = new ILRuntime.CLR.Method.CLRMethod(def:  System.Boolean ILRuntime.CLR.TypeSystem.CLRType::MatchGenericParameters(System.Type[] args, System.Type type, System.Type q, ILRuntime.CLR.TypeSystem.IType[] genericArguments), type:  type, domain:  q);
        
        }
        //
        // Offset in libil2cpp.so: 0x010F4A18 (17779224), len: 3376  VirtAddr: 0x010F4A18 RVA: 0x010F4A18 token: 100663459 methodIndex: 28892 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.Method.IMethod GetMethod(string name, System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType> param, ILRuntime.CLR.TypeSystem.IType[] genericArguments, ILRuntime.CLR.TypeSystem.IType returnType, bool declaredOnly = False)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_39;
            //  | 
            object val_41;
            //  | 
            ILRuntime.CLR.TypeSystem.IType[] val_42;
            //  | 
            System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>> val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            var val_55;
            //  | 
            var val_56;
            //  | 
            var val_57;
            //  | 
            var val_58;
            //  | 
            var val_59;
            //  | 
            var val_60;
            //  | 
            var val_61;
            //  | 
            var val_62;
            //  | 
            var val_63;
            //  | 
            var val_64;
            //  | 
            var val_65;
            //  | 
            var val_66;
            //  | 
            ILRuntime.CLR.Method.CLRMethod val_67;
            // 0x010F4A18: STP x28, x27, [sp, #-0x60]! | stack[1152921510001770432] = ???;  stack[1152921510001770440] = ???;  //  dest_result_addr=1152921510001770432 |  dest_result_addr=1152921510001770440
            // 0x010F4A1C: STP x26, x25, [sp, #0x10]  | stack[1152921510001770448] = ???;  stack[1152921510001770456] = ???;  //  dest_result_addr=1152921510001770448 |  dest_result_addr=1152921510001770456
            // 0x010F4A20: STP x24, x23, [sp, #0x20]  | stack[1152921510001770464] = ???;  stack[1152921510001770472] = ???;  //  dest_result_addr=1152921510001770464 |  dest_result_addr=1152921510001770472
            // 0x010F4A24: STP x22, x21, [sp, #0x30]  | stack[1152921510001770480] = ???;  stack[1152921510001770488] = ???;  //  dest_result_addr=1152921510001770480 |  dest_result_addr=1152921510001770488
            // 0x010F4A28: STP x20, x19, [sp, #0x40]  | stack[1152921510001770496] = ???;  stack[1152921510001770504] = ???;  //  dest_result_addr=1152921510001770496 |  dest_result_addr=1152921510001770504
            // 0x010F4A2C: STP x29, x30, [sp, #0x50]  | stack[1152921510001770512] = ???;  stack[1152921510001770520] = ???;  //  dest_result_addr=1152921510001770512 |  dest_result_addr=1152921510001770520
            // 0x010F4A30: ADD x29, sp, #0x50         | X29 = (1152921510001770432 + 80) = 1152921510001770512 (0x1000000141900010);
            // 0x010F4A34: MOV x28, x4                | X28 = returnType;//m1                   
            // 0x010F4A38: STR x28, [sp, #-0x50]!     | stack[1152921510001770352] = returnType;  //  dest_result_addr=1152921510001770352
            // 0x010F4A3C: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010F4A40: LDRB w8, [x21, #0xb0a]     | W8 = (bool)static_value_03735B0A;       
            // 0x010F4A44: MOV x19, x3                | X19 = genericArguments;//m1             
            val_42 = genericArguments;
            // 0x010F4A48: MOV x22, x2                | X22 = param;//m1                        
            // 0x010F4A4C: MOV x20, x1                | X20 = name;//m1                         
            // 0x010F4A50: MOV x23, x0                | X23 = 1152921510001782528 (0x1000000141902F00);//ML01
            // 0x010F4A54: TBNZ w8, #0, #0x10f4a70    | if (static_value_03735B0A == true) goto label_0;
            // 0x010F4A58: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x010F4A5C: LDR x8, [x8, #0x988]       | X8 = 0x2B90D40;                         
            // 0x010F4A60: LDR w0, [x8]               | W0 = 0x1A14;                            
            // 0x010F4A64: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A14, ????);     
            // 0x010F4A68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F4A6C: STRB w8, [x21, #0xb0a]     | static_value_03735B0A = true;            //  dest_result_addr=57891594
            label_0:
            // 0x010F4A70: STR xzr, [sp, #0x40]       | stack[1152921510001770416] = 0x0;        //  dest_result_addr=1152921510001770416
            System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> val_1 = 0;
            // 0x010F4A74: STP xzr, xzr, [sp, #0x28]  | stack[1152921510001770392] = 0x0;  stack[1152921510001770400] = 0x0;  //  dest_result_addr=1152921510001770392 |  dest_result_addr=1152921510001770400
            // 0x010F4A78: STR xzr, [sp, #0x20]       | stack[1152921510001770384] = 0x0;        //  dest_result_addr=1152921510001770384
            // 0x010F4A7C: LDR x0, [x23, #0x20]       | X0 = this.methods; //P2                 
            val_43 = this.methods;
            // 0x010F4A80: CBNZ x0, #0x10f4a9c        | if (this.methods != null) goto label_2; 
            if(val_43 != null)
            {
                goto label_2;
            }
            // 0x010F4A84: MOV x0, x23                | X0 = 1152921510001782528 (0x1000000141902F00);//ML01
            // 0x010F4A88: BL #0x10f4304              | this.InitializeMethods();               
            this.InitializeMethods();
            // 0x010F4A8C: LDR x0, [x23, #0x20]       | X0 = this.methods; //P2                 
            val_43 = this.methods;
            // 0x010F4A90: CBNZ x0, #0x10f4a9c        | if (this.methods != null) goto label_2; 
            if(val_43 != null)
            {
                goto label_2;
            }
            // 0x010F4A94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.methods, ????);
            // 0x010F4A98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_43 = 0;
            label_2:
            // 0x010F4A9C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x010F4AA0: LDR x8, [x8, #0x9c0]       | X8 = 1152921509999961408;               
            // 0x010F4AA4: ADD x2, sp, #0x40          | X2 = (1152921510001770352 + 64) = 1152921510001770416 (0x10000001418FFFB0);
            // 0x010F4AA8: MOV x1, x20                | X1 = name;//m1                          
            // 0x010F4AAC: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::TryGetValue(System.String key, out System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> value);
            // 0x010F4AB0: BL #0x23fe7ec              | X0 = val_43.TryGetValue(key:  name, value: out  System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod> val_1 = 0);
            bool val_2 = val_43.TryGetValue(key:  name, value: out  val_1);
            // 0x010F4AB4: TBZ w0, #0, #0x10f4b0c     | if (val_2 == false) goto label_3;       
            if(val_2 == false)
            {
                goto label_3;
            }
            // 0x010F4AB8: LDR x20, [sp, #0x40]       | X20 = 0x0;                              
            // 0x010F4ABC: CBNZ x20, #0x10f4ac4       | if (0x0 != 0) goto label_4;             
            if(val_1 != 0)
            {
                goto label_4;
            }
            // 0x010F4AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x010F4AC4: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x010F4AC8: LDR x8, [x8, #0x360]       | X8 = 1152921510000228032;               
            // 0x010F4ACC: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x010F4AD0: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>::GetEnumerator();
            // 0x010F4AD4: ADD x8, sp, #8             | X8 = (1152921510001770352 + 8) = 1152921510001770360 (0x10000001418FFF78);
            // 0x010F4AD8: BL #0x25ebf2c              | X0 = val_1.GetEnumerator();             
            List.Enumerator<T> val_3 = val_1.GetEnumerator();
            // 0x010F4ADC: ADRP x26, #0x35e4000       | X26 = 56508416 (0x35E4000);             
            // 0x010F4AE0: ADRP x27, #0x3667000       | X27 = 57044992 (0x3667000);             
            // 0x010F4AE4: ADRP x21, #0x3613000       | X21 = 56700928 (0x3613000);             
            // 0x010F4AE8: LDR x8, [sp, #0x18]        | X8 = val_4;                              //  find_add[1152921510001758528]
            // 0x010F4AEC: LDUR q0, [sp, #8]          | Q0 = val_5;                              //  find_add[1152921510001758528]
            // 0x010F4AF0: LDR x26, [x26, #0x468]     | X26 = 1152921510000223936;              
            val_44 = 1152921510000223936;
            // 0x010F4AF4: LDR x27, [x27, #0x380]     | X27 = 1152921510000224960;              
            val_45 = 1152921510000224960;
            // 0x010F4AF8: LDR x21, [x21, #0x400]     | X21 = 1152921509994002736;              
            // 0x010F4AFC: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x010F4B00: STR x8, [sp, #0x30]        | stack[1152921510001770400] = val_4;      //  dest_result_addr=1152921510001770400
            // 0x010F4B04: STR q0, [sp, #0x20]        | stack[1152921510001770384] = val_5;      //  dest_result_addr=1152921510001770384
            // 0x010F4B08: B #0x10f4b24               |  goto label_125;                        
            goto label_125;
            label_3:
            // 0x010F4B0C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_46 = 0;
            // 0x010F4B10: B #0x10f56a4               |  goto label_154;                        
            goto label_154;
            label_132:
            // 0x010F4B14: ADRP x26, #0x35e4000       | X26 = 56508416 (0x35E4000);             
            // 0x010F4B18: ADRP x27, #0x3667000       | X27 = 57044992 (0x3667000);             
            // 0x010F4B1C: LDR x26, [x26, #0x468]     | X26 = 1152921510000223936;              
            val_44 = 1152921510000223936;
            // 0x010F4B20: LDR x27, [x27, #0x380]     | X27 = 1152921510000224960;              
            val_45 = 1152921510000224960;
            label_125:
            // 0x010F4B24: LDR x1, [x26]              | X1 = public System.Boolean List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::MoveNext();
            // 0x010F4B28: ADD x0, sp, #0x20          | X0 = (1152921510001770352 + 32) = 1152921510001770384 (0x10000001418FFF90);
            // 0x010F4B2C: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x010F4B30: AND w8, w0, #1             | W8 = (1152921510001770384 & 1) = 0 (0x00000000);
            // 0x010F4B34: TBZ w8, #0, #0x10f56c8     | if ((0x0 & 0x1) == 0) goto label_7;     
            if((0 & 1) == 0)
            {
                goto label_7;
            }
            // 0x010F4B38: LDR x1, [x27]              | X1 = public ILRuntime.CLR.Method.CLRMethod List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::get_Current();
            // 0x010F4B3C: ADD x0, sp, #0x20          | X0 = (1152921510001770352 + 32) = 1152921510001770384 (0x10000001418FFF90);
            // 0x010F4B40: BL #0x13372d8              | X0 = val_5.get_InitialType();           
            System.Type val_6 = val_5.InitialType;
            // 0x010F4B44: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x010F4B48: CBNZ x24, #0x10f4b50       | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x010F4B4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x010F4B50: LDR x8, [x24, #0x40]       | 
            // 0x010F4B54: CBZ x8, #0x10f4b60         | if (0x464C457F == 0) goto label_9;      
            if(1179403647 == 0)
            {
                goto label_9;
            }
            // 0x010F4B58: LDR w25, [x8, #0x18]       | W25 = 0x9814C0;                         
            val_47 = 9966784;
            // 0x010F4B5C: B #0x10f4b64               |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x010F4B60: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_47 = 0;
            label_10:
            // 0x010F4B64: CBNZ x22, #0x10f4b6c       | if (param != null) goto label_11;       
            if(param != null)
            {
                goto label_11;
            }
            // 0x010F4B68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_11:
            // 0x010F4B6C: LDR x1, [x21]              | X1 = mem[57888768];                     
            // 0x010F4B70: MOV x0, x22                | X0 = param;//m1                         
            // 0x010F4B74: BL #0x25ed72c              | X0 = param.get_Count();                 
            int val_7 = param.Count;
            // 0x010F4B78: CMP w25, w0                | STATE = COMPARE(0x0, val_7)             
            // 0x010F4B7C: B.NE #0x10f4b24            | if (val_47 != val_7) goto label_125;    
            if(val_47 != val_7)
            {
                goto label_125;
            }
            // 0x010F4B80: CBZ x19, #0x10f4e68        | if (genericArguments == null) goto label_13;
            if(val_42 == null)
            {
                goto label_13;
            }
            // 0x010F4B84: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x010F4B88: BL #0x10eca68              | X0 = val_6.get_GenericParameterCount(); 
            int val_8 = val_6.GenericParameterCount;
            // 0x010F4B8C: LDR w8, [x19, #0x18]       | W8 = genericArguments.Length; //P2      
            // 0x010F4B90: CMP w0, w8                 | STATE = COMPARE(val_8, genericArguments.Length)
            // 0x010F4B94: B.NE #0x10f4e74            | if (val_8 != genericArguments.Length) goto label_14;
            if(val_8 != genericArguments.Length)
            {
                goto label_14;
            }
            // 0x010F4B98: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_48 = 0;
            // 0x010F4B9C: B #0x10f4ba4               |  goto label_15;                         
            goto label_15;
            label_48:
            // 0x010F4BA0: ADD w25, w25, #1           | W25 = (val_48 + 1) = val_48 (0x00000001);
            val_48 = 1;
            label_15:
            // 0x010F4BA4: CBNZ x22, #0x10f4bac       | if (param != null) goto label_16;       
            if(param != null)
            {
                goto label_16;
            }
            // 0x010F4BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_16:
            // 0x010F4BAC: LDR x1, [x21]              | X1 = mem[57888768];                     
            // 0x010F4BB0: MOV x0, x22                | X0 = param;//m1                         
            // 0x010F4BB4: BL #0x25ed72c              | X0 = param.get_Count();                 
            int val_9 = param.Count;
            // 0x010F4BB8: CMP w25, w0                | STATE = COMPARE(0x1, val_9)             
            // 0x010F4BBC: B.GE #0x10f5330            | if (val_48 >= val_9) goto label_17;     
            if(val_48 >= val_9)
            {
                goto label_17;
            }
            // 0x010F4BC0: CBNZ x24, #0x10f4bc8       | if (val_6 != null) goto label_18;       
            if(val_6 != null)
            {
                goto label_18;
            }
            // 0x010F4BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_18:
            // 0x010F4BC8: LDR x0, [x24, #0x20]       | 
            // 0x010F4BCC: CBNZ x0, #0x10f4be8        | if (val_9 != 0) goto label_20;          
            if(val_9 != 0)
            {
                goto label_20;
            }
            // 0x010F4BD0: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x010F4BD4: BL #0x10ecc24              | val_6.InitParameters();                 
            val_6.InitParameters();
            // 0x010F4BD8: LDR x0, [x24, #0x20]       | 
            // 0x010F4BDC: CBNZ x0, #0x10f4be8        | if (val_6 != null) goto label_20;       
            if(val_6 != null)
            {
                goto label_20;
            }
            // 0x010F4BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x010F4BE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_20:
            // 0x010F4BE8: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x010F4BEC: LDR x8, [x8, #0xe90]       | X8 = 1152921509993964848;               
            // 0x010F4BF0: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F4BF4: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
            // 0x010F4BF8: BL #0x25ed734              | X0 = 0.get_Item(index:  1);             
            ILRuntime.CLR.TypeSystem.IType val_10 = 0.Item[1];
            // 0x010F4BFC: MOV x26, x0                | X26 = val_10;//m1                       
            // 0x010F4C00: CBNZ x26, #0x10f4c08       | if (val_10 != null) goto label_21;      
            if(val_10 != null)
            {
                goto label_21;
            }
            // 0x010F4C04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_21:
            // 0x010F4C08: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F4C0C: LDR x8, [x26]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4C10: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F4C14: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4C18: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F4C1C: CBZ x9, #0x10f4c48         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
            // 0x010F4C20: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F4C24: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_40 = 0;
            // 0x010F4C28: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_24:
            // 0x010F4C2C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F4C30: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F4C34: B.EQ #0x10f4c58            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_23;
            // 0x010F4C38: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_40 = val_40 + 1;
            // 0x010F4C3C: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F4C40: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F4C44: B.LO #0x10f4c2c            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_24;
            label_22:
            // 0x010F4C48: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F4C4C: MOV x0, x26                | X0 = val_10;//m1                        
            val_49 = val_10;
            // 0x010F4C50: BL #0x2776c24              | X0 = sub_2776C24( ?? val_10, ????);     
            // 0x010F4C54: B #0x10f4c68               |  goto label_25;                         
            goto label_25;
            label_23:
            // 0x010F4C58: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F4C5C: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F4C60: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F4C64: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_25:
            // 0x010F4C68: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F4C6C: MOV x0, x26                | X0 = val_10;//m1                        
            // 0x010F4C70: BLR x8                     | X0 = sub_100000000A746000( ?? val_10, ????);
            // 0x010F4C74: MOV x27, x0                | X27 = val_10;//m1                       
            // 0x010F4C78: CBNZ x22, #0x10f4c80       | if (param != null) goto label_26;       
            if(param != null)
            {
                goto label_26;
            }
            // 0x010F4C7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_26:
            // 0x010F4C80: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x010F4C84: LDR x8, [x8, #0xe90]       | X8 = 1152921509993964848;               
            // 0x010F4C88: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F4C8C: MOV x0, x22                | X0 = param;//m1                         
            // 0x010F4C90: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
            // 0x010F4C94: BL #0x25ed734              | X0 = param.get_Item(index:  1);         
            ILRuntime.CLR.TypeSystem.IType val_12 = param.Item[1];
            // 0x010F4C98: MOV x26, x0                | X26 = val_12;//m1                       
            // 0x010F4C9C: CBNZ x26, #0x10f4ca4       | if (val_12 != null) goto label_27;      
            if(val_12 != null)
            {
                goto label_27;
            }
            // 0x010F4CA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_27:
            // 0x010F4CA4: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F4CA8: LDR x8, [x26]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4CAC: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F4CB0: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4CB4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F4CB8: CBZ x9, #0x10f4ce4         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_28;
            // 0x010F4CBC: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F4CC0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_41 = 0;
            // 0x010F4CC4: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_30:
            // 0x010F4CC8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F4CCC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F4CD0: B.EQ #0x10f4cf4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_29;
            // 0x010F4CD4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_41 = val_41 + 1;
            // 0x010F4CD8: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F4CDC: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F4CE0: B.LO #0x10f4cc8            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_30;
            label_28:
            // 0x010F4CE4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F4CE8: MOV x0, x26                | X0 = val_12;//m1                        
            val_50 = val_12;
            // 0x010F4CEC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_12, ????);     
            // 0x010F4CF0: B #0x10f4d04               |  goto label_31;                         
            goto label_31;
            label_29:
            // 0x010F4CF4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F4CF8: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F4CFC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F4D00: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_31:
            // 0x010F4D04: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F4D08: MOV x0, x26                | X0 = val_12;//m1                        
            // 0x010F4D0C: BLR x8                     | X0 = sub_100000000A746000( ?? val_12, ????);
            // 0x010F4D10: MOV x26, x0                | X26 = val_12;//m1                       
            // 0x010F4D14: CBNZ x24, #0x10f4d1c       | if (val_6 != null) goto label_32;       
            if(val_6 != null)
            {
                goto label_32;
            }
            // 0x010F4D18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_32:
            // 0x010F4D1C: LDR x0, [x24, #0x20]       | 
            // 0x010F4D20: CBNZ x0, #0x10f4d3c        | if (val_12 != null) goto label_34;      
            if(val_12 != null)
            {
                goto label_34;
            }
            // 0x010F4D24: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x010F4D28: BL #0x10ecc24              | val_6.InitParameters();                 
            val_6.InitParameters();
            // 0x010F4D2C: LDR x0, [x24, #0x20]       | 
            // 0x010F4D30: CBNZ x0, #0x10f4d3c        | if (val_6 != null) goto label_34;       
            if(val_6 != null)
            {
                goto label_34;
            }
            // 0x010F4D34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x010F4D38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_34:
            // 0x010F4D3C: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x010F4D40: LDR x8, [x8, #0xe90]       | X8 = 1152921509993964848;               
            // 0x010F4D44: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F4D48: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
            // 0x010F4D4C: BL #0x25ed734              | X0 = 0.get_Item(index:  1);             
            ILRuntime.CLR.TypeSystem.IType val_14 = 0.Item[1];
            // 0x010F4D50: MOV x28, x0                | X28 = val_14;//m1                       
            // 0x010F4D54: CBNZ x28, #0x10f4d5c       | if (val_14 != null) goto label_35;      
            if(val_14 != null)
            {
                goto label_35;
            }
            // 0x010F4D58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_35:
            // 0x010F4D5C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F4D60: LDR x8, [x28]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4D64: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F4D68: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4D6C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F4D70: CBZ x9, #0x10f4d9c         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_36;
            // 0x010F4D74: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F4D78: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_42 = 0;
            // 0x010F4D7C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_38:
            // 0x010F4D80: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F4D84: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F4D88: B.EQ #0x10f4dac            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_37;
            // 0x010F4D8C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_42 = val_42 + 1;
            // 0x010F4D90: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F4D94: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F4D98: B.LO #0x10f4d80            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_38;
            label_36:
            // 0x010F4D9C: MOVZ w2, #0x13             | W2 = 19 (0x13);//ML01                   
            // 0x010F4DA0: MOV x0, x28                | X0 = val_14;//m1                        
            val_51 = val_14;
            // 0x010F4DA4: BL #0x2776c24              | X0 = sub_2776C24( ?? val_14, ????);     
            // 0x010F4DA8: B #0x10f4dbc               |  goto label_39;                         
            goto label_39;
            label_37:
            // 0x010F4DAC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F4DB0: ADD w9, w9, #0x13          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 19);
            // 0x010F4DB4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 19));
            // 0x010F4DB8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 19)).272
            label_39:
            // 0x010F4DBC: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F4DC0: MOV x0, x28                | X0 = val_14;//m1                        
            // 0x010F4DC4: BLR x8                     | X0 = sub_100000000A746000( ?? val_14, ????);
            // 0x010F4DC8: TBZ w0, #0, #0x10f4e5c     | if ((val_14 & 0x1) == 0) goto label_40; 
            if((val_14 & 1) == 0)
            {
                goto label_40;
            }
            // 0x010F4DCC: CBNZ x24, #0x10f4dd4       | if (val_6 != null) goto label_41;       
            if(val_6 != null)
            {
                goto label_41;
            }
            // 0x010F4DD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_41:
            // 0x010F4DD4: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x010F4DD8: BL #0x10ecb7c              | X0 = val_6.get_GenericArgumentsCLR();   
            System.Type[] val_16 = val_6.GenericArgumentsCLR;
            // 0x010F4DDC: MOV x27, x0                | X27 = val_16;//m1                       
            // 0x010F4DE0: CBNZ x24, #0x10f4de8       | if (val_6 != null) goto label_42;       
            if(val_6 != null)
            {
                goto label_42;
            }
            // 0x010F4DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_42:
            // 0x010F4DE8: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x010F4DEC: BL #0x10ed0a4              | X0 = val_6.get_ParametersCLR();         
            System.Reflection.ParameterInfo[] val_17 = val_6.ParametersCLR;
            // 0x010F4DF0: MOV x28, x0                | X28 = val_17;//m1                       
            // 0x010F4DF4: CBNZ x28, #0x10f4dfc       | if (val_17 != null) goto label_43;      
            if(val_17 != null)
            {
                goto label_43;
            }
            // 0x010F4DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_43:
            // 0x010F4DFC: LDR w8, [x28, #0x18]       | W8 = val_17.Length; //P2                
            // 0x010F4E00: CMP w25, w8                | STATE = COMPARE(0x1, val_17.Length)     
            // 0x010F4E04: B.LO #0x10f4e14            | if (val_48 < val_17.Length) goto label_44;
            if(val_48 < val_17.Length)
            {
                goto label_44;
            }
            // 0x010F4E08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
            // 0x010F4E0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_52 = 0;
            // 0x010F4E10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_44:
            // 0x010F4E14: SXTW x8, w25               | X8 = 1 (0x00000001);                    
            // 0x010F4E18: ADD x8, x28, x8, lsl #3    | X8 = val_17[0x1]; //PARR1               
            // 0x010F4E1C: LDR x28, [x8, #0x20]       | X28 = val_17[0x1][0]                    
            System.Reflection.ParameterInfo val_43 = val_17[1];
            // 0x010F4E20: CBNZ x28, #0x10f4e28       | if (val_17[0x1][0] != null) goto label_45;
            if(val_43 != null)
            {
                goto label_45;
            }
            // 0x010F4E24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_45:
            // 0x010F4E28: LDR x8, [x28]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010F4E2C: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010F4E30: MOV x0, x28                | X0 = val_17[0x1][0];//m1                
            // 0x010F4E34: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010F4E38: MOV x2, x0                 | X2 = val_17[0x1][0];//m1                
            // 0x010F4E3C: MOV x0, x23                | X0 = 1152921510001782528 (0x1000000141902F00);//ML01
            // 0x010F4E40: MOV x1, x27                | X1 = val_16;//m1                        
            // 0x010F4E44: MOV x3, x26                | X3 = val_12;//m1                        
            // 0x010F4E48: MOV x4, x19                | X4 = genericArguments;//m1              
            // 0x010F4E4C: BL #0x10f5b70              | X0 = this.MatchGenericParameters(args:  val_16, type:  val_17[1], q:  val_12, genericArguments:  val_42);
            bool val_18 = this.MatchGenericParameters(args:  val_16, type:  val_43, q:  val_12, genericArguments:  val_42);
            // 0x010F4E50: AND w8, w0, #1             | W8 = (val_18 & 1);                      
            bool val_19 = val_18;
            // 0x010F4E54: TBNZ w8, #0, #0x10f4ba0    | if ((val_18 & 1) == true) goto label_48;
            if(val_19 == true)
            {
                goto label_48;
            }
            // 0x010F4E58: B #0x10f5338               |  goto label_49;                         
            goto label_49;
            label_40:
            // 0x010F4E5C: CMP x26, x27               | STATE = COMPARE(val_12, val_10)         
            // 0x010F4E60: B.EQ #0x10f4ba0            | if (val_12 == val_10) goto label_48;    
            if(val_12 == val_10)
            {
                goto label_48;
            }
            // 0x010F4E64: B #0x10f5338               |  goto label_49;                         
            goto label_49;
            label_13:
            // 0x010F4E68: LDR x8, [x24, #0x58]       | 
            // 0x010F4E6C: CBNZ x8, #0x10f4b24        | if (0x464C457F != 0) goto label_125;    
            if(1179403647 != 0)
            {
                goto label_125;
            }
            // 0x010F4E70: B #0x10f4e94               |  goto label_51;                         
            goto label_51;
            label_14:
            // 0x010F4E74: CBNZ x24, #0x10f4e7c       | if (val_6 != null) goto label_52;       
            if(val_6 != null)
            {
                goto label_52;
            }
            // 0x010F4E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_52:
            // 0x010F4E7C: LDR x8, [x24, #0x58]       | 
            // 0x010F4E80: CBZ x8, #0x10f4b24         | if (genericArguments.Length == 0) goto label_125;
            if(genericArguments.Length == 0)
            {
                goto label_125;
            }
            // 0x010F4E84: LDR w8, [x8, #0x18]        | W8 = genericArguments.Length + 24;      
            // 0x010F4E88: LDR w9, [x19, #0x18]       | W9 = genericArguments.Length; //P2      
            // 0x010F4E8C: CMP w8, w9                 | STATE = COMPARE(genericArguments.Length + 24, genericArguments.Length)
            // 0x010F4E90: B.NE #0x10f4b24            | if (genericArguments.Length + 24 != genericArguments.Length) goto label_125;
            if((genericArguments.Length + 24) != genericArguments.Length)
            {
                goto label_125;
            }
            label_51:
            // 0x010F4E94: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            var val_50 = 0;
            label_107:
            // 0x010F4E98: CBNZ x22, #0x10f4ea0       | if (param != null) goto label_55;       
            if(param != null)
            {
                goto label_55;
            }
            // 0x010F4E9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_55:
            // 0x010F4EA0: LDR x1, [x21]              | X1 = mem[57888768];                     
            // 0x010F4EA4: MOV x0, x22                | X0 = param;//m1                         
            // 0x010F4EA8: BL #0x25ed72c              | X0 = param.get_Count();                 
            int val_20 = param.Count;
            // 0x010F4EAC: CMP w25, w0                | STATE = COMPARE(0x0, val_20)            
            // 0x010F4EB0: B.GE #0x10f5340            | if (0 >= val_20) goto label_56;         
            if(val_50 >= val_20)
            {
                goto label_56;
            }
            // 0x010F4EB4: CBNZ x22, #0x10f4ebc       | if (param != null) goto label_57;       
            if(param != null)
            {
                goto label_57;
            }
            // 0x010F4EB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_57:
            // 0x010F4EBC: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x010F4EC0: LDR x8, [x8, #0xe90]       | X8 = 1152921509993964848;               
            // 0x010F4EC4: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F4EC8: MOV x0, x22                | X0 = param;//m1                         
            // 0x010F4ECC: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
            // 0x010F4ED0: BL #0x25ed734              | X0 = param.get_Item(index:  0);         
            ILRuntime.CLR.TypeSystem.IType val_21 = param.Item[0];
            // 0x010F4ED4: MOV x26, x0                | X26 = val_21;//m1                       
            // 0x010F4ED8: CBNZ x26, #0x10f4ee0       | if (val_21 != null) goto label_58;      
            if(val_21 != null)
            {
                goto label_58;
            }
            // 0x010F4EDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_58:
            // 0x010F4EE0: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F4EE4: LDR x8, [x26]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4EE8: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F4EEC: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4EF0: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F4EF4: CBZ x9, #0x10f4f20         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_59;
            // 0x010F4EF8: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F4EFC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_44 = 0;
            // 0x010F4F00: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_61:
            // 0x010F4F04: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F4F08: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F4F0C: B.EQ #0x10f4f30            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_60;
            // 0x010F4F10: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_44 = val_44 + 1;
            // 0x010F4F14: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F4F18: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F4F1C: B.LO #0x10f4f04            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_61;
            label_59:
            // 0x010F4F20: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F4F24: MOV x0, x26                | X0 = val_21;//m1                        
            val_53 = val_21;
            // 0x010F4F28: BL #0x2776c24              | X0 = sub_2776C24( ?? val_21, ????);     
            // 0x010F4F2C: B #0x10f4f40               |  goto label_62;                         
            goto label_62;
            label_60:
            // 0x010F4F30: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F4F34: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F4F38: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F4F3C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_62:
            // 0x010F4F40: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F4F44: MOV x0, x26                | X0 = val_21;//m1                        
            // 0x010F4F48: BLR x8                     | X0 = sub_100000000A746000( ?? val_21, ????);
            // 0x010F4F4C: MOV x26, x0                | X26 = val_21;//m1                       
            // 0x010F4F50: CBNZ x26, #0x10f4f58       | if (val_21 != null) goto label_63;      
            if(val_21 != null)
            {
                goto label_63;
            }
            // 0x010F4F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_63:
            // 0x010F4F58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F4F5C: MOV x0, x26                | X0 = val_21;//m1                        
            // 0x010F4F60: BL #0x1b6d1dc              | X0 = val_21.get_IsByRef();              
            bool val_23 = val_21.IsByRef;
            // 0x010F4F64: TBZ w0, #0, #0x10f4fe4     | if (val_23 == false) goto label_64;     
            if(val_23 == false)
            {
                goto label_64;
            }
            // 0x010F4F68: CBNZ x22, #0x10f4f70       | if (param != null) goto label_65;       
            if(param != null)
            {
                goto label_65;
            }
            // 0x010F4F6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_65:
            // 0x010F4F70: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x010F4F74: LDR x8, [x8, #0xe90]       | X8 = 1152921509993964848;               
            // 0x010F4F78: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F4F7C: MOV x0, x22                | X0 = param;//m1                         
            // 0x010F4F80: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
            // 0x010F4F84: BL #0x25ed734              | X0 = param.get_Item(index:  0);         
            ILRuntime.CLR.TypeSystem.IType val_24 = param.Item[0];
            // 0x010F4F88: MOV x26, x0                | X26 = val_24;//m1                       
            // 0x010F4F8C: CBNZ x26, #0x10f4f94       | if (val_24 != null) goto label_66;      
            if(val_24 != null)
            {
                goto label_66;
            }
            // 0x010F4F90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_66:
            // 0x010F4F94: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F4F98: LDR x8, [x26]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4F9C: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F4FA0: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F4FA4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F4FA8: CBZ x9, #0x10f4fd4         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_67;
            // 0x010F4FAC: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F4FB0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_45 = 0;
            // 0x010F4FB4: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_69:
            // 0x010F4FB8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F4FBC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F4FC0: B.EQ #0x10f5060            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_68;
            // 0x010F4FC4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_45 = val_45 + 1;
            // 0x010F4FC8: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F4FCC: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F4FD0: B.LO #0x10f4fb8            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_69;
            label_67:
            // 0x010F4FD4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F4FD8: MOV x0, x26                | X0 = val_24;//m1                        
            val_54 = val_24;
            // 0x010F4FDC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_24, ????);     
            // 0x010F4FE0: B #0x10f5070               |  goto label_70;                         
            goto label_70;
            label_64:
            // 0x010F4FE4: CBNZ x22, #0x10f4fec       | if (param != null) goto label_71;       
            if(param != null)
            {
                goto label_71;
            }
            // 0x010F4FE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_71:
            // 0x010F4FEC: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x010F4FF0: LDR x8, [x8, #0xe90]       | X8 = 1152921509993964848;               
            // 0x010F4FF4: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F4FF8: MOV x0, x22                | X0 = param;//m1                         
            // 0x010F4FFC: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
            // 0x010F5000: BL #0x25ed734              | X0 = param.get_Item(index:  0);         
            ILRuntime.CLR.TypeSystem.IType val_25 = param.Item[0];
            // 0x010F5004: MOV x26, x0                | X26 = val_25;//m1                       
            // 0x010F5008: CBNZ x26, #0x10f5010       | if (val_25 != null) goto label_72;      
            if(val_25 != null)
            {
                goto label_72;
            }
            // 0x010F500C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_72:
            // 0x010F5010: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F5014: LDR x8, [x26]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5018: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F501C: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5020: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F5024: CBZ x9, #0x10f5050         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_73;
            // 0x010F5028: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F502C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_46 = 0;
            // 0x010F5030: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_75:
            // 0x010F5034: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F5038: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F503C: B.EQ #0x10f50a4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_74;
            // 0x010F5040: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_46 = val_46 + 1;
            // 0x010F5044: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F5048: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F504C: B.LO #0x10f5034            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_75;
            label_73:
            // 0x010F5050: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F5054: MOV x0, x26                | X0 = val_25;//m1                        
            val_55 = val_25;
            // 0x010F5058: BL #0x2776c24              | X0 = sub_2776C24( ?? val_25, ????);     
            // 0x010F505C: B #0x10f50b4               |  goto label_76;                         
            goto label_76;
            label_68:
            // 0x010F5060: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F5064: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F5068: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F506C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_70:
            // 0x010F5070: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F5074: MOV x0, x26                | X0 = val_24;//m1                        
            // 0x010F5078: BLR x8                     | X0 = sub_100000000A746000( ?? val_24, ????);
            // 0x010F507C: MOV x26, x0                | X26 = val_24;//m1                       
            // 0x010F5080: CBNZ x26, #0x10f5088       | if (val_24 != null) goto label_77;      
            if(val_24 != null)
            {
                goto label_77;
            }
            // 0x010F5084: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_77:
            // 0x010F5088: LDR x8, [x26]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F508C: LDR x1, [x8, #0x418]       | X1 = typeof(ILRuntime.CLR.TypeSystem.IType).__il2cppRuntimeField_418;
            // 0x010F5090: LDR x9, [x8, #0x410]       | X9 = typeof(ILRuntime.CLR.TypeSystem.IType).__il2cppRuntimeField_410;
            // 0x010F5094: MOV x0, x26                | X0 = val_24;//m1                        
            // 0x010F5098: BLR x9                     | X0 = typeof(ILRuntime.CLR.TypeSystem.IType).__il2cppRuntimeField_410();
            // 0x010F509C: MOV x26, x0                | X26 = val_24;//m1                       
            val_56 = val_24;
            // 0x010F50A0: B #0x10f50c4               |  goto label_78;                         
            goto label_78;
            label_74:
            // 0x010F50A4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F50A8: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F50AC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F50B0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_76:
            // 0x010F50B4: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F50B8: MOV x0, x26                | X0 = val_25;//m1                        
            // 0x010F50BC: BLR x8                     | X0 = sub_100000000A746000( ?? val_25, ????);
            // 0x010F50C0: MOV x26, x0                | X26 = val_25;//m1                       
            val_56 = val_25;
            label_78:
            // 0x010F50C4: CBNZ x24, #0x10f50cc       | if (val_6 != null) goto label_79;       
            if(val_6 != null)
            {
                goto label_79;
            }
            // 0x010F50C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_79:
            // 0x010F50CC: LDR x0, [x24, #0x20]       | 
            // 0x010F50D0: CBNZ x0, #0x10f50ec        | if (val_25 != null) goto label_81;      
            if(val_25 != null)
            {
                goto label_81;
            }
            // 0x010F50D4: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x010F50D8: BL #0x10ecc24              | val_6.InitParameters();                 
            val_6.InitParameters();
            // 0x010F50DC: LDR x0, [x24, #0x20]       | 
            // 0x010F50E0: CBNZ x0, #0x10f50ec        | if (val_6 != null) goto label_81;       
            if(val_6 != null)
            {
                goto label_81;
            }
            // 0x010F50E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x010F50E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_81:
            // 0x010F50EC: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x010F50F0: LDR x8, [x8, #0xe90]       | X8 = 1152921509993964848;               
            // 0x010F50F4: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F50F8: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
            // 0x010F50FC: BL #0x25ed734              | X0 = 0.get_Item(index:  0);             
            ILRuntime.CLR.TypeSystem.IType val_28 = 0.Item[0];
            // 0x010F5100: MOV x27, x0                | X27 = val_28;//m1                       
            // 0x010F5104: CBNZ x27, #0x10f510c       | if (val_28 != null) goto label_82;      
            if(val_28 != null)
            {
                goto label_82;
            }
            // 0x010F5108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_82:
            // 0x010F510C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F5110: LDR x8, [x27]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5114: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F5118: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F511C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F5120: CBZ x9, #0x10f514c         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_83;
            // 0x010F5124: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F5128: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_47 = 0;
            // 0x010F512C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_85:
            // 0x010F5130: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F5134: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F5138: B.EQ #0x10f515c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_84;
            // 0x010F513C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_47 = val_47 + 1;
            // 0x010F5140: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F5144: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F5148: B.LO #0x10f5130            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_85;
            label_83:
            // 0x010F514C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F5150: MOV x0, x27                | X0 = val_28;//m1                        
            val_57 = val_28;
            // 0x010F5154: BL #0x2776c24              | X0 = sub_2776C24( ?? val_28, ????);     
            // 0x010F5158: B #0x10f516c               |  goto label_86;                         
            goto label_86;
            label_84:
            // 0x010F515C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F5160: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F5164: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F5168: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_86:
            // 0x010F516C: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F5170: MOV x0, x27                | X0 = val_28;//m1                        
            // 0x010F5174: BLR x8                     | X0 = sub_100000000A746000( ?? val_28, ????);
            // 0x010F5178: MOV x27, x0                | X27 = val_28;//m1                       
            // 0x010F517C: CBNZ x27, #0x10f5184       | if (val_28 != null) goto label_87;      
            if(val_28 != null)
            {
                goto label_87;
            }
            // 0x010F5180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_87:
            // 0x010F5184: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5188: MOV x0, x27                | X0 = val_28;//m1                        
            // 0x010F518C: BL #0x1b6d1dc              | X0 = val_28.get_IsByRef();              
            bool val_30 = val_28.IsByRef;
            // 0x010F5190: TBZ w0, #0, #0x10f522c     | if (val_30 == false) goto label_88;     
            if(val_30 == false)
            {
                goto label_88;
            }
            // 0x010F5194: CBNZ x24, #0x10f519c       | if (val_6 != null) goto label_89;       
            if(val_6 != null)
            {
                goto label_89;
            }
            // 0x010F5198: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
            label_89:
            // 0x010F519C: LDR x0, [x24, #0x20]       | 
            // 0x010F51A0: CBNZ x0, #0x10f51bc        | if (val_30 == true) goto label_91;      
            if(val_30 == true)
            {
                goto label_91;
            }
            // 0x010F51A4: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x010F51A8: BL #0x10ecc24              | val_6.InitParameters();                 
            val_6.InitParameters();
            // 0x010F51AC: LDR x0, [x24, #0x20]       | 
            // 0x010F51B0: CBNZ x0, #0x10f51bc        | if (val_6 != null) goto label_91;       
            if(val_6 != null)
            {
                goto label_91;
            }
            // 0x010F51B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x010F51B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_91:
            // 0x010F51BC: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x010F51C0: LDR x8, [x8, #0xe90]       | X8 = 1152921509993964848;               
            // 0x010F51C4: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F51C8: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
            // 0x010F51CC: BL #0x25ed734              | X0 = 0.get_Item(index:  0);             
            ILRuntime.CLR.TypeSystem.IType val_31 = 0.Item[0];
            // 0x010F51D0: MOV x27, x0                | X27 = val_31;//m1                       
            // 0x010F51D4: CBNZ x27, #0x10f51dc       | if (val_31 != null) goto label_92;      
            if(val_31 != null)
            {
                goto label_92;
            }
            // 0x010F51D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_92:
            // 0x010F51DC: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F51E0: LDR x8, [x27]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F51E4: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F51E8: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F51EC: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F51F0: CBZ x9, #0x10f521c         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_93;
            // 0x010F51F4: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F51F8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_48 = 0;
            // 0x010F51FC: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_95:
            // 0x010F5200: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F5204: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F5208: B.EQ #0x10f52c4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_94;
            // 0x010F520C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_48 = val_48 + 1;
            // 0x010F5210: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F5214: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F5218: B.LO #0x10f5200            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_95;
            label_93:
            // 0x010F521C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F5220: MOV x0, x27                | X0 = val_31;//m1                        
            val_58 = val_31;
            // 0x010F5224: BL #0x2776c24              | X0 = sub_2776C24( ?? val_31, ????);     
            // 0x010F5228: B #0x10f52d4               |  goto label_96;                         
            goto label_96;
            label_88:
            // 0x010F522C: CBNZ x24, #0x10f5234       | if (val_6 != null) goto label_97;       
            if(val_6 != null)
            {
                goto label_97;
            }
            // 0x010F5230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
            label_97:
            // 0x010F5234: LDR x0, [x24, #0x20]       | 
            // 0x010F5238: CBNZ x0, #0x10f5254        | if (val_30 == true) goto label_99;      
            if(val_30 == true)
            {
                goto label_99;
            }
            // 0x010F523C: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x010F5240: BL #0x10ecc24              | val_6.InitParameters();                 
            val_6.InitParameters();
            // 0x010F5244: LDR x0, [x24, #0x20]       | 
            // 0x010F5248: CBNZ x0, #0x10f5254        | if (val_6 != null) goto label_99;       
            if(val_6 != null)
            {
                goto label_99;
            }
            // 0x010F524C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x010F5250: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_99:
            // 0x010F5254: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x010F5258: LDR x8, [x8, #0xe90]       | X8 = 1152921509993964848;               
            // 0x010F525C: LDR x2, [x8]               | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F5260: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
            // 0x010F5264: BL #0x25ed734              | X0 = 0.get_Item(index:  0);             
            ILRuntime.CLR.TypeSystem.IType val_32 = 0.Item[0];
            // 0x010F5268: MOV x27, x0                | X27 = val_32;//m1                       
            // 0x010F526C: CBNZ x27, #0x10f5274       | if (val_32 != null) goto label_100;     
            if(val_32 != null)
            {
                goto label_100;
            }
            // 0x010F5270: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_100:
            // 0x010F5274: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F5278: LDR x8, [x27]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F527C: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F5280: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5284: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F5288: CBZ x9, #0x10f52b4         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_101;
            // 0x010F528C: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F5290: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_49 = 0;
            // 0x010F5294: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_103:
            // 0x010F5298: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F529C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F52A0: B.EQ #0x10f5304            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_102;
            // 0x010F52A4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_49 = val_49 + 1;
            // 0x010F52A8: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F52AC: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F52B0: B.LO #0x10f5298            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_103;
            label_101:
            // 0x010F52B4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F52B8: MOV x0, x27                | X0 = val_32;//m1                        
            val_59 = val_32;
            // 0x010F52BC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_32, ????);     
            // 0x010F52C0: B #0x10f5314               |  goto label_104;                        
            goto label_104;
            label_94:
            // 0x010F52C4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F52C8: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F52CC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F52D0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_96:
            // 0x010F52D4: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F52D8: MOV x0, x27                | X0 = val_31;//m1                        
            // 0x010F52DC: BLR x8                     | X0 = sub_100000000A746000( ?? val_31, ????);
            // 0x010F52E0: MOV x27, x0                | X27 = val_31;//m1                       
            // 0x010F52E4: CBNZ x27, #0x10f52ec       | if (val_31 != null) goto label_105;     
            if(val_31 != null)
            {
                goto label_105;
            }
            // 0x010F52E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_105:
            // 0x010F52EC: LDR x8, [x27]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F52F0: LDR x1, [x8, #0x418]       | X1 = typeof(ILRuntime.CLR.TypeSystem.IType).__il2cppRuntimeField_418;
            // 0x010F52F4: LDR x9, [x8, #0x410]       | X9 = typeof(ILRuntime.CLR.TypeSystem.IType).__il2cppRuntimeField_410;
            // 0x010F52F8: MOV x0, x27                | X0 = val_31;//m1                        
            val_60 = val_31;
            // 0x010F52FC: BLR x9                     | X0 = typeof(ILRuntime.CLR.TypeSystem.IType).__il2cppRuntimeField_410();
            // 0x010F5300: B #0x10f5320               |  goto label_106;                        
            goto label_106;
            label_102:
            // 0x010F5304: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F5308: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F530C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F5310: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_104:
            // 0x010F5314: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F5318: MOV x0, x27                | X0 = val_32;//m1                        
            val_60 = val_32;
            // 0x010F531C: BLR x8                     | X0 = sub_100000000A746000( ?? val_32, ????);
            label_106:
            // 0x010F5320: ADD w25, w25, #1           | W25 = (0 + 1);                          
            val_50 = val_50 + 1;
            // 0x010F5324: CMP x26, x0                | STATE = COMPARE(val_25, val_32)         
            // 0x010F5328: B.EQ #0x10f4e98            | if (val_56 == val_60) goto label_107;   
            if(val_56 == val_60)
            {
                goto label_107;
            }
            // 0x010F532C: B #0x10f4b14               |  goto label_132;                        
            goto label_132;
            label_17:
            // 0x010F5330: CMP x20, #0                | STATE = COMPARE(name, 0x0)              
            // 0x010F5334: CSEL x20, x24, x20, eq     | X20 = name == null ? val_6 : name;      
            var val_35 = (name == null) ? (val_6) : (name);
            label_49:
            // 0x010F5338: LDR x28, [sp]              | X28 = returnType;                       
            // 0x010F533C: B #0x10f4b14               |  goto label_132;                        
            goto label_132;
            label_56:
            // 0x010F5340: ADRP x26, #0x35e4000       | X26 = 56508416 (0x35E4000);             
            // 0x010F5344: ADRP x27, #0x3667000       | X27 = 57044992 (0x3667000);             
            // 0x010F5348: LDR x26, [x26, #0x468]     | X26 = 1152921510000223936;              
            // 0x010F534C: LDR x27, [x27, #0x380]     | X27 = 1152921510000224960;              
            // 0x010F5350: CBZ x28, #0x10f5448        | if (returnType == null) goto label_137; 
            if(returnType == null)
            {
                goto label_137;
            }
            // 0x010F5354: CBNZ x24, #0x10f535c       | if (val_6 != null) goto label_111;      
            if(val_6 != null)
            {
                goto label_111;
            }
            // 0x010F5358: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_111:
            // 0x010F535C: LDR x25, [x24, #0x78]      | 
            // 0x010F5360: CBZ x25, #0x10f4b24        | if (0x0 == 0) goto label_125;           
            if(val_50 == 0)
            {
                goto label_125;
            }
            // 0x010F5364: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F5368: LDR x8, [x25]              | X8 = 0x10102464C457F;                   
            var val_54 = 1179403647;
            // 0x010F536C: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F5370: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5374: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x010F5378: CBZ x9, #0x10f53a4         | if (mem[282584257676929] == 0) goto label_113;
            if(mem[282584257676929] == 0)
            {
                goto label_113;
            }
            // 0x010F537C: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_51 = mem[282584257676823];
            // 0x010F5380: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_52 = 0;
            // 0x010F5384: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_51 = val_51 + 8;
            label_115:
            // 0x010F5388: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x010F538C: CMP x12, x1                | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F5390: B.EQ #0x10f53b4            | if ((mem[282584257676823] + 8) + -8 == null) goto label_114;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_114;
            }
            // 0x010F5394: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_52 = val_52 + 1;
            // 0x010F5398: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_51 = val_51 + 16;
            // 0x010F539C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x010F53A0: B.LO #0x10f5388            | if (0 < mem[282584257676929]) goto label_115;
            if(val_52 < mem[282584257676929])
            {
                goto label_115;
            }
            label_113:
            // 0x010F53A4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F53A8: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            val_61 = val_50;
            // 0x010F53AC: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x010F53B0: B #0x10f53c4               |  goto label_116;                        
            goto label_116;
            label_114:
            // 0x010F53B4: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_53 = val_51;
            // 0x010F53B8: ADD w9, w9, #2             | W9 = ((mem[282584257676823] + 8) + 2);  
            val_53 = val_53 + 2;
            // 0x010F53BC: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 2));
            val_54 = val_54 + val_53;
            // 0x010F53C0: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 2)) + 272);
            val_61 = val_54 + 272;
            label_116:
            // 0x010F53C4: LDP x8, x1, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 2)) + 272); X1 = ((1179403647 + ((mem[282584257676823] + 8) + 2)) + 272) + 8; //  | 
            // 0x010F53C8: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            // 0x010F53CC: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 2)) + 272)();
            // 0x010F53D0: MOV x25, x0                | X25 = 0 (0x0);//ML01                    
            // 0x010F53D4: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F53D8: LDR x8, [x28]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F53DC: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F53E0: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F53E4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F53E8: CBZ x9, #0x10f5414         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_117;
            // 0x010F53EC: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F53F0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_55 = 0;
            // 0x010F53F4: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_119:
            // 0x010F53F8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F53FC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F5400: B.EQ #0x10f5424            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_118;
            // 0x010F5404: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_55 = val_55 + 1;
            // 0x010F5408: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F540C: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F5410: B.LO #0x10f53f8            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_119;
            label_117:
            // 0x010F5414: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F5418: MOV x0, x28                | X0 = returnType;//m1                    
            val_62 = returnType;
            // 0x010F541C: BL #0x2776c24              | X0 = sub_2776C24( ?? returnType, ????); 
            // 0x010F5420: B #0x10f5434               |  goto label_120;                        
            goto label_120;
            label_118:
            // 0x010F5424: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F5428: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F542C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F5430: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_120:
            // 0x010F5434: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
            // 0x010F5438: MOV x0, x28                | X0 = returnType;//m1                    
            // 0x010F543C: BLR x8                     | X0 = sub_10102464C457F( ?? returnType, ????);
            // 0x010F5440: CMP x25, x0                | STATE = COMPARE(0x0, returnType)        
            // 0x010F5444: B.NE #0x10f4b24            | if (0 != returnType) goto label_125;    
            if(val_50 != returnType)
            {
                goto label_125;
            }
            label_137:
            // 0x010F5448: CBNZ x24, #0x10f5450       | if (val_6 != null) goto label_122;      
            if(val_6 != null)
            {
                goto label_122;
            }
            // 0x010F544C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? returnType, ????); 
            label_122:
            // 0x010F5450: LDR x25, [x24, #0x58]      | 
            // 0x010F5454: CBZ x25, #0x10f56e4        | if (0x0 == 0) goto label_134;           
            if(val_50 == 0)
            {
                goto label_134;
            }
            // 0x010F5458: CBNZ x19, #0x10f5460       | if (genericArguments != null) goto label_124;
            if(val_42 != null)
            {
                goto label_124;
            }
            // 0x010F545C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? returnType, ????); 
            label_124:
            // 0x010F5460: LDR w8, [x25, #0x18]       | W8 = 0x9814C0;                          
            // 0x010F5464: LDR w9, [x19, #0x18]       | W9 = genericArguments.Length; //P2      
            // 0x010F5468: CMP w8, w9                 | STATE = COMPARE(0x9814C0, genericArguments.Length)
            // 0x010F546C: B.NE #0x10f4b24            | if (9966784 != genericArguments.Length) goto label_125;
            if(9966784 != genericArguments.Length)
            {
                goto label_125;
            }
            // 0x010F5470: CMP w8, #1                 | STATE = COMPARE(0x9814C0, 0x1)          
            // 0x010F5474: B.LT #0x10f56e4            | if (9966784 < 0x1) goto label_134;      
            if(9966784 < 1)
            {
                goto label_134;
            }
            // 0x010F5478: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            var val_57 = 0;
            label_133:
            // 0x010F547C: CBNZ x24, #0x10f5484       | if (val_6 != null) goto label_127;      
            if(val_6 != null)
            {
                goto label_127;
            }
            // 0x010F5480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? returnType, ????); 
            label_127:
            // 0x010F5484: LDR x26, [x24, #0x58]      | 
            // 0x010F5488: CBNZ x26, #0x10f5490       | if (public System.Boolean List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::MoveNext() != 0) goto label_128;
            if((public System.Boolean List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::MoveNext()) != 0)
            {
                goto label_128;
            }
            // 0x010F548C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? returnType, ????); 
            label_128:
            // 0x010F5490: LDR w8, [x26, #0x18]       | W8 = public System.Void Dictionary.Enumerator<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::Dispose();
            // 0x010F5494: CMP w25, w8                | STATE = COMPARE(0x0, public System.Void Dictionary.Enumerator<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::Dispose())
            // 0x010F5498: B.LO #0x10f54a8            | if (0 < public System.Void Dictionary.Enumerator<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::Dispose()) goto label_129;
            if(val_57 < (public System.Void Dictionary.Enumerator<System.String, System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>>::Dispose()))
            {
                goto label_129;
            }
            // 0x010F549C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? returnType, ????); 
            // 0x010F54A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F54A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? returnType, ????); 
            label_129:
            // 0x010F54A8: SXTW x27, w25              | X27 = 0 (0x00000000);                   
            // 0x010F54AC: ADD x8, x26, x27, lsl #3   | X8 = (1152921510000223936 + 0) = 58068296 (0x03760D48);
            // 0x010F54B0: LDR x26, [x8, #0x20]       | X26 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>::.ctor();
            // 0x010F54B4: CBNZ x19, #0x10f54bc       | if (genericArguments != null) goto label_130;
            if(val_42 != null)
            {
                goto label_130;
            }
            // 0x010F54B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? returnType, ????); 
            label_130:
            // 0x010F54BC: LDR w8, [x19, #0x18]       | W8 = genericArguments.Length; //P2      
            // 0x010F54C0: CMP w25, w8                | STATE = COMPARE(0x0, genericArguments.Length)
            // 0x010F54C4: B.LO #0x10f54d4            | if (0 < genericArguments.Length) goto label_131;
            if(val_57 < genericArguments.Length)
            {
                goto label_131;
            }
            // 0x010F54C8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? returnType, ????); 
            // 0x010F54CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F54D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? returnType, ????); 
            label_131:
            // 0x010F54D4: ADD x8, x19, x27, lsl #3   | X8 = genericArguments[0x0]; //PARR1     
            // 0x010F54D8: LDR x8, [x8, #0x20]        | X8 = genericArguments[0x0][0]           
            ILRuntime.CLR.TypeSystem.IType val_56 = val_42[0];
            // 0x010F54DC: CMP x26, x8                | STATE = COMPARE(public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>::.ctor(), genericArguments[0x0][0])
            // 0x010F54E0: B.NE #0x10f4b14            | if (public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>::.ctor() != val_42[0]) goto label_132;
            if((public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Reflection.FieldInfo>::.ctor()) != val_56)
            {
                goto label_132;
            }
            // 0x010F54E4: LDR w8, [x19, #0x18]       | W8 = genericArguments.Length; //P2      
            // 0x010F54E8: ADD w25, w25, #1           | W25 = (0 + 1);                          
            val_57 = val_57 + 1;
            // 0x010F54EC: CMP w25, w8                | STATE = COMPARE((0 + 1), genericArguments.Length)
            // 0x010F54F0: B.LT #0x10f547c            | if (0 < genericArguments.Length) goto label_133;
            if(val_57 < genericArguments.Length)
            {
                goto label_133;
            }
            // 0x010F54F4: B #0x10f56e4               |  goto label_134;                        
            goto label_134;
            // 0x010F54F8: MOV x26, x1                | X26 = 0 (0x0);//ML01                    
            val_63 = 0;
            // 0x010F54FC: MOV x25, x0                | X25 = returnType;//m1                   
            val_64 = returnType;
            // 0x010F5500: ORR w27, wzr, #1           | W27 = 1(0x1);                           
            val_65 = 1;
            // 0x010F5504: CMP w26, #1                | STATE = COMPARE(0x0, 0x1)               
            // 0x010F5508: B.NE #0x10f5560            | if (val_63 != 0x1) goto label_155;      
            if(val_63 != 1)
            {
                goto label_155;
            }
            // 0x010F550C: MOV x0, x25                | X0 = returnType;//m1                    
            // 0x010F5510: BL #0x981060               | X0 = sub_981060( ?? returnType, ????);  
            // 0x010F5514: MOV x25, x0                | X25 = returnType;//m1                   
            // 0x010F5518: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x010F551C: LDR x8, [x25]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5520: LDR x9, [x9, #0xf90]       | X9 = 1152921504606900224;               
            // 0x010F5524: LDR x1, [x8]               | X1 = ;                                  
            // 0x010F5528: LDR x0, [x9]               | X0 = typeof(System.Object);             
            // 0x010F552C: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Object), ????);
            // 0x010F5530: TBZ w0, #0, #0x10f5724     | if ((typeof(System.Object) & 0x1) == 0) goto label_136;
            if((null & 1) == 0)
            {
                goto label_136;
            }
            // 0x010F5534: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Object), ????);
            // 0x010F5538: ADRP x26, #0x35e4000       | X26 = 56508416 (0x35E4000);             
            // 0x010F553C: ADRP x27, #0x3667000       | X27 = 57044992 (0x3667000);             
            // 0x010F5540: LDR x26, [x26, #0x468]     | X26 = 1152921510000223936;              
            // 0x010F5544: LDR x27, [x27, #0x380]     | X27 = 1152921510000224960;              
            // 0x010F5548: B #0x10f5448               |  goto label_137;                        
            goto label_137;
            // 0x010F554C: B #0x10f5554               |  goto label_153;                        
            goto label_153;
            // 0x010F5550: B #0x10f5554               |  goto label_153;                        
            goto label_153;
            label_153:
            // 0x010F5554: MOV x26, x1                | X26 = X1;//m1                           
            val_63 = null;
            // 0x010F5558: MOV x25, x0                | X25 = 1152921504606900224 (0x100000000000D000);//ML01
            val_64 = null;
            // 0x010F555C: ORR w27, wzr, #1           | W27 = 1(0x1);                           
            val_65 = 1;
            label_155:
            // 0x010F5560: CMP w26, w27               | STATE = COMPARE(, 0x1)                  
            // 0x010F5564: B.NE #0x10f5708            | if (val_63 != val_65) goto label_140;   
            if(val_63 != val_65)
            {
                goto label_140;
            }
            // 0x010F5568: MOV x0, x25                | X0 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x010F556C: BL #0x981060               | X0 = sub_981060( ?? typeof(System.Object), ????);
            // 0x010F5570: LDR x21, [x0]              | X21 = ;                                 
            val_41 = null;
            // 0x010F5574: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Object), ????);
            // 0x010F5578: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F557C: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F5580: ADD x0, sp, #0x20          | X0 = (1152921510001770352 + 32) = 1152921510001770384 (0x10000001418FFF90);
            // 0x010F5584: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F5588: BL #0x13371f4              | val_5.Dispose();                        
            val_5.Dispose();
            // 0x010F558C: CBZ x21, #0x10f559c        | if ( == 0) goto label_152;              
            if(val_41 == 0)
            {
                goto label_152;
            }
            // 0x010F5590: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F5594: MOV x0, x21                | X0 = X21;//m1                           
            // 0x010F5598: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
            label_152:
            // 0x010F559C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_46 = 0;
            // 0x010F55A0: CBZ x19, #0x10f56a4        | if (genericArguments == null) goto label_154;
            if(val_42 == null)
            {
                goto label_154;
            }
            // 0x010F55A4: CBZ x20, #0x10f56a4        | if (name == null) goto label_154;       
            if(name == null)
            {
                goto label_154;
            }
            // 0x010F55A8: ADRP x9, #0x35b7000        | X9 = 56324096 (0x35B7000);              
            // 0x010F55AC: LDR x8, [x20]              | X8 = typeof(System.String);             
            // 0x010F55B0: LDR x9, [x9, #0xbe0]       | X9 = 1152921504781979648;               
            // 0x010F55B4: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.Method.IMethod);
            // 0x010F55B8: LDRH w9, [x8, #0x102]      | W9 = System.String.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F55BC: CBZ x9, #0x10f55e8         | if (System.String.__il2cppRuntimeField_interface_offsets_count == 0) goto label_144;
            // 0x010F55C0: LDR x10, [x8, #0x98]       | X10 = System.String.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F55C4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_58 = 0;
            // 0x010F55C8: ADD x10, x10, #8           | X10 = (System.String.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608321544 (0x1000000000168008);
            label_146:
            // 0x010F55CC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F55D0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.Method.IMethod))
            // 0x010F55D4: B.EQ #0x10f55f8            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_145;
            // 0x010F55D8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_58 = val_58 + 1;
            // 0x010F55DC: ADD x10, x10, #0x10        | X10 = (1152921504608321544 + 16) = 1152921504608321560 (0x1000000000168018);
            // 0x010F55E0: CMP x11, x9                | STATE = COMPARE((0 + 1), System.String.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F55E4: B.LO #0x10f55cc            | if (0 < System.String.__il2cppRuntimeField_interface_offsets_count) goto label_146;
            label_144:
            // 0x010F55E8: MOVZ w2, #0xb              | W2 = 11 (0xB);//ML01                    
            // 0x010F55EC: MOV x0, x20                | X0 = name;//m1                          
            val_66 = name;
            // 0x010F55F0: BL #0x2776c24              | X0 = sub_2776C24( ?? name, ????);       
            // 0x010F55F4: B #0x10f5608               |  goto label_147;                        
            goto label_147;
            label_145:
            // 0x010F55F8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F55FC: ADD w9, w9, #0xb           | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 11);
            // 0x010F5600: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608284672 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 11));
            // 0x010F5604: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608284672 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 11)).272
            label_147:
            // 0x010F5608: LDP x8, x2, [x0]           |                                          //  not_find_field!1:0 |  not_find_field!1:8
            // 0x010F560C: MOV x0, x20                | X0 = name;//m1                          
            // 0x010F5610: MOV x1, x19                | X1 = genericArguments;//m1              
            // 0x010F5614: BLR x8                     | X0 = mem[val_41]();                     
            // 0x010F5618: LDR x19, [sp, #0x40]       | X19 = 0x0;                              
            val_42 = val_1;
            // 0x010F561C: MOV x24, x0                | X24 = name;//m1                         
            val_46 = name;
            // 0x010F5620: CBNZ x19, #0x10f5628       | if (0x0 != 0) goto label_148;           
            if(val_42 != 0)
            {
                goto label_148;
            }
            // 0x010F5624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? name, ????);       
            label_148:
            // 0x010F5628: CBZ x24, #0x10f5688        | if (name == null) goto label_149;       
            if(val_46 == null)
            {
                goto label_149;
            }
            // 0x010F562C: ADRP x9, #0x3619000        | X9 = 56725504 (0x3619000);              
            // 0x010F5630: LDR x9, [x9, #0xe08]       | X9 = 1152921504781766656;               
            // 0x010F5634: LDR x8, [x24]              | X8 = typeof(System.String);             
            // 0x010F5638: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.Method.CLRMethod);
            // 0x010F563C: LDRB w10, [x8, #0x104]     | W10 = System.String.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F5640: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F5644: CMP w10, w9                | STATE = COMPARE(System.String.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F5648: B.LO #0x10f5664            | if (System.String.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_typeHierarchyDepth) goto label_150;
            // 0x010F564C: LDR x10, [x8, #0xb0]       | X10 = System.String.__il2cppRuntimeField_typeHierarchy;
            // 0x010F5650: ADD x9, x10, x9, lsl #3    | X9 = (System.String.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.Method.CLRMethod.__il2cppRun
            // 0x010F5654: LDUR x9, [x9, #-8]         | X9 = (System.String.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F5658: CMP x9, x1                 | STATE = COMPARE((System.String.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.Method.CLRMethod))
            // 0x010F565C: MOV x3, x24                | X3 = name;//m1                          
            val_67 = val_46;
            // 0x010F5660: B.EQ #0x10f568c            | if ((System.String.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_151;
            label_150:
            // 0x010F5664: LDR x0, [x8, #0x30]        | X0 = System.String.__il2cppRuntimeField_element_class;
            // 0x010F5668: ADD x8, sp, #0x48          | X8 = (1152921510001770352 + 72) = 1152921510001770424 (0x10000001418FFFB8);
            // 0x010F566C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.String.__il2cppRuntimeField_element_class, ????);
            // 0x010F5670: LDR x0, [sp, #0x48]        | X0 = val_39;                             //  find_add[1152921510001758528]
            // 0x010F5674: BL #0x27af090              | X0 = sub_27AF090( ?? val_39, ????);     
            // 0x010F5678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F567C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_39, ????);     
            // 0x010F5680: ADD x0, sp, #0x48          | X0 = (1152921510001770352 + 72) = 1152921510001770424 (0x10000001418FFFB8);
            // 0x010F5684: BL #0x299a140              | 
            label_149:
            // 0x010F5688: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            val_67 = 0;
            label_151:
            // 0x010F568C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x010F5690: LDR x8, [x8, #0x838]       | X8 = 1152921509999962432;               
            // 0x010F5694: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x010F5698: MOV x1, x3                 | X1 = 0 (0x0);//ML01                     
            // 0x010F569C: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>::Add(ILRuntime.CLR.Method.CLRMethod item);
            // 0x010F56A0: BL #0x25ea480              | val_42.Add(item:  val_67);              
            val_42.Add(item:  val_67);
            label_154:
            // 0x010F56A4: MOV x0, x24                | X0 = name;//m1                          
            // 0x010F56A8: SUB sp, x29, #0x50         | SP = (1152921510001770512 - 80) = 1152921510001770432 (0x10000001418FFFC0);
            // 0x010F56AC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x010F56B0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x010F56B4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x010F56B8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x010F56BC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x010F56C0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x010F56C4: RET                        |  return (ILRuntime.CLR.Method.IMethod)name;
            return (ILRuntime.CLR.Method.IMethod)val_46;
            //  |  // // {name=val_0, type=ILRuntime.CLR.Method.IMethod, size=8, nGRN=0 }
            label_7:
            // 0x010F56C8: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F56CC: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F56D0: ADD x0, sp, #0x20          | X0 = (1152921510001770352 + 32) = 1152921510001770384 (0x10000001418FFF90);
            // 0x010F56D4: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F56D8: BL #0x13371f4              | val_5.Dispose();                        
            val_5.Dispose();
            // 0x010F56DC: B #0x10f559c               |  goto label_152;                        
            goto label_152;
            // 0x010F56E0: B #0x10f5554               |  goto label_153;                        
            goto label_153;
            label_134:
            // 0x010F56E4: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F56E8: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F56EC: ADD x0, sp, #0x20          | X0 = (1152921510001770352 + 32) = 1152921510001770384 (0x10000001418FFF90);
            // 0x010F56F0: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F56F4: BL #0x13371f4              | val_5.Dispose();                        
            val_5.Dispose();
            // 0x010F56F8: B #0x10f56a4               |  goto label_154;                        
            goto label_154;
            // 0x010F56FC: MOV x25, x0                | X25 = 1152921510001770384 (0x10000001418FFF90);//ML01
            val_64;
            // 0x010F5700: ADD x0, sp, #0x48          | X0 = (1152921510001770352 + 72) = 1152921510001770424 (0x10000001418FFFB8);
            // 0x010F5704: BL #0x299a140              | 
            label_140:
            // 0x010F5708: MOV x0, x25                | X0 = 1152921510001770384 (0x10000001418FFF90);//ML01
            // 0x010F570C: BL #0x980800               | X0 = sub_980800( ?? 0x10000001418FFF90, ????);
            label_156:
            // 0x010F5710: MOV x26, x1                | X26 = 1152921510000233152 (0x1000000141788AC0);//ML01
            // 0x010F5714: MOV x25, x0                | X25 = 1152921510001770384 (0x10000001418FFF90);//ML01
            // 0x010F5718: BL #0x980920               | X0 = sub_980920( ?? 0x10000001418FFF90, ????);
            // 0x010F571C: B #0x10f5560               |  goto label_155;                        
            goto label_155;
            // 0x010F5720: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
            label_136:
            // 0x010F5724: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x010F5728: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x010F572C: LDR x8, [x25]              | X8 = val_5;                             
            // 0x010F5730: STR x8, [x0]               | mem[8] = val_5;                          //  dest_result_addr=8
            mem[8] = val_5;
            // 0x010F5734: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x010F5738: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F573C: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x010F5740: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            // 0x010F5744: B #0x10f5710               |  goto label_156;                        
            goto label_156;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F5F30 (17784624), len: 372  VirtAddr: 0x010F5F30 RVA: 0x010F5F30 token: 100663460 methodIndex: 28893 delegateWrapperIndex: 0 methodInvoker: 0
        public bool CanAssignTo(ILRuntime.CLR.TypeSystem.IType type)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x010F5F30: STP x22, x21, [sp, #-0x30]! | stack[1152921510002074992] = ???;  stack[1152921510002075000] = ???;  //  dest_result_addr=1152921510002074992 |  dest_result_addr=1152921510002075000
            // 0x010F5F34: STP x20, x19, [sp, #0x10]  | stack[1152921510002075008] = ???;  stack[1152921510002075016] = ???;  //  dest_result_addr=1152921510002075008 |  dest_result_addr=1152921510002075016
            // 0x010F5F38: STP x29, x30, [sp, #0x20]  | stack[1152921510002075024] = ???;  stack[1152921510002075032] = ???;  //  dest_result_addr=1152921510002075024 |  dest_result_addr=1152921510002075032
            // 0x010F5F3C: ADD x29, sp, #0x20         | X29 = (1152921510002074992 + 32) = 1152921510002075024 (0x100000014194A590);
            // 0x010F5F40: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010F5F44: LDRB w8, [x21, #0xb0b]     | W8 = (bool)static_value_03735B0B;       
            // 0x010F5F48: MOV x20, x1                | X20 = type;//m1                         
            // 0x010F5F4C: MOV x19, x0                | X19 = 1152921510002087040 (0x100000014194D480);//ML01
            val_11 = this;
            // 0x010F5F50: TBNZ w8, #0, #0x10f5f6c    | if (static_value_03735B0B == true) goto label_0;
            // 0x010F5F54: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x010F5F58: LDR x8, [x8, #0x8f0]       | X8 = 0x2B90D04;                         
            // 0x010F5F5C: LDR w0, [x8]               | W0 = 0x1A05;                            
            // 0x010F5F60: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A05, ????);     
            // 0x010F5F64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F5F68: STRB w8, [x21, #0xb0b]     | static_value_03735B0B = true;            //  dest_result_addr=57891595
            label_0:
            // 0x010F5F6C: CMP x19, x20               | STATE = COMPARE(this, type)             
            // 0x010F5F70: B.EQ #0x10f5ff8            | if (val_11 == type) goto label_1;       
            if(val_11 == type)
            {
                goto label_1;
            }
            // 0x010F5F74: CBZ x20, #0x10f6000        | if (type == null) goto label_2;         
            if(type == null)
            {
                goto label_2;
            }
            // 0x010F5F78: ADRP x9, #0x366d000        | X9 = 57069568 (0x366D000);              
            // 0x010F5F7C: LDR x9, [x9, #0x108]       | X9 = 1152921504782192640;               
            // 0x010F5F80: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5F84: LDR x9, [x9]               | X9 = typeof(ILRuntime.CLR.TypeSystem.ILType);
            // 0x010F5F88: LDRB w11, [x8, #0x104]     | W11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F5F8C: LDRB w10, [x9, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F5F90: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F5F94: B.LO #0x10f5fac            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) goto label_3;
            // 0x010F5F98: LDR x11, [x8, #0xb0]       | X11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010F5F9C: ADD x10, x11, x10, lsl #3  | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem
            // 0x010F5FA0: LDUR x10, [x10, #-8]       | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F5FA4: CMP x10, x9                | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.ILType))
            // 0x010F5FA8: B.EQ #0x10f6090            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_4;
            label_3:
            // 0x010F5FAC: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F5FB0: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F5FB4: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F5FB8: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F5FBC: CBZ x9, #0x10f5fe8         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_5;
            // 0x010F5FC0: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F5FC4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x010F5FC8: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_7:
            // 0x010F5FCC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F5FD0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F5FD4: B.EQ #0x10f6040            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_6;
            // 0x010F5FD8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x010F5FDC: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F5FE0: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F5FE4: B.LO #0x10f5fcc            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_7;
            label_5:
            // 0x010F5FE8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F5FEC: MOV x0, x20                | X0 = type;//m1                          
            val_12 = type;
            // 0x010F5FF0: BL #0x2776c24              | X0 = sub_2776C24( ?? type, ????);       
            // 0x010F5FF4: B #0x10f6050               |  goto label_8;                          
            goto label_8;
            label_1:
            // 0x010F5FF8: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_13 = 1;
            // 0x010F5FFC: B #0x10f6094               |  goto label_9;                          
            goto label_9;
            label_2:
            // 0x010F6000: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x010F6004: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x010F6008: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x010F600C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x010F6010: LDR x8, [x8, #0xa88]       | X8 = 1152921504606900224;               
            // 0x010F6014: LDR x20, [x8]              | X20 = typeof(System.Object);            
            // 0x010F6018: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x010F601C: TBZ w8, #0, #0x10f602c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x010F6020: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x010F6024: CBNZ w8, #0x10f602c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x010F6028: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_11:
            // 0x010F602C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F6030: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F6034: MOV x1, x20                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x010F6038: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x010F603C: B #0x10f605c               |  goto label_12;                         
            goto label_12;
            label_6:
            // 0x010F6040: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F6044: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F6048: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F604C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_8:
            // 0x010F6050: LDP x8, x1, [x0]           | X8 = 0x4000000; X1 = 0x120000416D000000; //  | 
            // 0x010F6054: MOV x0, x20                | X0 = type;//m1                          
            val_14 = type;
            // 0x010F6058: BLR x8                     | X0 = sub_4000000( ?? type, ????);       
            label_12:
            // 0x010F605C: LDR x19, [x19, #0x10]      | X19 = this.clrType; //P2                
            // 0x010F6060: MOV x20, x0                | X20 = type;//m1                         
            // 0x010F6064: CBNZ x19, #0x10f606c       | if (this.clrType != null) goto label_13;
            if(this.clrType != null)
            {
                goto label_13;
            }
            // 0x010F6068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type, ????);       
            label_13:
            // 0x010F606C: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x010F6070: MOV x0, x19                | X0 = this.clrType;//m1                  
            // 0x010F6074: MOV x1, x20                | X1 = type;//m1                          
            // 0x010F6078: LDR x3, [x8, #0x3e0]       | X3 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x010F607C: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x010F6080: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F6084: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            val_11 = ???;
            // 0x010F6088: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            val_10 = ???;
            // 0x010F608C: BR x3                      | goto typeof(System.Type).__il2cppRuntimeField_3E0;
            goto typeof(System.Type).__il2cppRuntimeField_3E0;
            label_4:
            // 0x010F6090: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_13 = 0;
            label_9:
            // 0x010F6094: LDP x29, x30, [sp, #0x20]  | X29 = val_4; X30 = val_5;                //  find_add[1152921510002063040] |  find_add[1152921510002063040]
            // 0x010F6098: LDP x20, x19, [sp, #0x10]  | X20 = val_6; X19 = val_7;                //  find_add[1152921510002063040] |  find_add[1152921510002063040]
            // 0x010F609C: LDP x22, x21, [sp], #0x30  | X22 = val_8; X21 = val_9;                //  find_add[1152921510002063040] |  find_add[1152921510002063040]
            // 0x010F60A0: RET                        |  return (System.Boolean)false;          
            return (bool)val_13;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F60A4 (17784996), len: 776  VirtAddr: 0x010F60A4 RVA: 0x010F60A4 token: 100663461 methodIndex: 28894 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.Method.IMethod GetConstructor(System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType> param)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x010F60A4: STP x28, x27, [sp, #-0x60]! | stack[1152921510002223808] = ???;  stack[1152921510002223816] = ???;  //  dest_result_addr=1152921510002223808 |  dest_result_addr=1152921510002223816
            // 0x010F60A8: STP x26, x25, [sp, #0x10]  | stack[1152921510002223824] = ???;  stack[1152921510002223832] = ???;  //  dest_result_addr=1152921510002223824 |  dest_result_addr=1152921510002223832
            // 0x010F60AC: STP x24, x23, [sp, #0x20]  | stack[1152921510002223840] = ???;  stack[1152921510002223848] = ???;  //  dest_result_addr=1152921510002223840 |  dest_result_addr=1152921510002223848
            // 0x010F60B0: STP x22, x21, [sp, #0x30]  | stack[1152921510002223856] = ???;  stack[1152921510002223864] = ???;  //  dest_result_addr=1152921510002223856 |  dest_result_addr=1152921510002223864
            // 0x010F60B4: STP x20, x19, [sp, #0x40]  | stack[1152921510002223872] = ???;  stack[1152921510002223880] = ???;  //  dest_result_addr=1152921510002223872 |  dest_result_addr=1152921510002223880
            // 0x010F60B8: STP x29, x30, [sp, #0x50]  | stack[1152921510002223888] = ???;  stack[1152921510002223896] = ???;  //  dest_result_addr=1152921510002223888 |  dest_result_addr=1152921510002223896
            // 0x010F60BC: ADD x29, sp, #0x50         | X29 = (1152921510002223808 + 80) = 1152921510002223888 (0x100000014196EB10);
            // 0x010F60C0: SUB sp, sp, #0x40          | SP = (1152921510002223808 - 64) = 1152921510002223744 (0x100000014196EA80);
            // 0x010F60C4: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010F60C8: LDRB w8, [x21, #0xb0c]     | W8 = (bool)static_value_03735B0C;       
            // 0x010F60CC: MOV x19, x1                | X19 = param;//m1                        
            val_12 = param;
            // 0x010F60D0: MOV x20, x0                | X20 = 1152921510002235904 (0x1000000141971A00);//ML01
            // 0x010F60D4: TBNZ w8, #0, #0x10f60f0    | if (static_value_03735B0C == true) goto label_0;
            // 0x010F60D8: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x010F60DC: LDR x8, [x8, #0xee8]       | X8 = 0x2B90D28;                         
            // 0x010F60E0: LDR w0, [x8]               | W0 = 0x1A0E;                            
            // 0x010F60E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A0E, ????);     
            // 0x010F60E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F60EC: STRB w8, [x21, #0xb0c]     | static_value_03735B0C = true;            //  dest_result_addr=57891596
            label_0:
            // 0x010F60F0: STP xzr, xzr, [sp, #0x28]  | stack[1152921510002223784] = 0x0;  stack[1152921510002223792] = 0x0;  //  dest_result_addr=1152921510002223784 |  dest_result_addr=1152921510002223792
            // 0x010F60F4: STR xzr, [sp, #0x20]       | stack[1152921510002223776] = 0x0;        //  dest_result_addr=1152921510002223776
            // 0x010F60F8: LDR x0, [x20, #0x30]       | X0 = this.constructors; //P2            
            // 0x010F60FC: CBNZ x0, #0x10f6118        | if (this.constructors != null) goto label_2;
            if(this.constructors != null)
            {
                goto label_2;
            }
            // 0x010F6100: MOV x0, x20                | X0 = 1152921510002235904 (0x1000000141971A00);//ML01
            // 0x010F6104: BL #0x10f4304              | this.InitializeMethods();               
            this.InitializeMethods();
            // 0x010F6108: LDR x0, [x20, #0x30]       | X0 = this.constructors; //P2            
            // 0x010F610C: CBNZ x0, #0x10f6118        | if (this.constructors != null) goto label_2;
            if(this.constructors != null)
            {
                goto label_2;
            }
            // 0x010F6110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.constructors, ????);
            // 0x010F6114: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_2:
            // 0x010F6118: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x010F611C: LDR x8, [x8, #0x360]       | X8 = 1152921510000228032;               
            // 0x010F6120: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<ILRuntime.CLR.Method.CLRMethod>::GetEnumerator();
            // 0x010F6124: ADD x8, sp, #8             | X8 = (1152921510002223744 + 8) = 1152921510002223752 (0x100000014196EA88);
            // 0x010F6128: BL #0x25ebf2c              | X0 = 0.GetEnumerator();                 
            List.Enumerator<T> val_1 = 0.GetEnumerator();
            // 0x010F612C: LDR x8, [sp, #0x18]        | X8 = val_2;                              //  find_add[1152921510002211904]
            // 0x010F6130: LDUR q0, [sp, #8]          | Q0 = val_3;                              //  find_add[1152921510002211904]
            // 0x010F6134: ADRP x24, #0x35e4000       | X24 = 56508416 (0x35E4000);             
            // 0x010F6138: ADRP x25, #0x3667000       | X25 = 57044992 (0x3667000);             
            // 0x010F613C: ADRP x26, #0x3613000       | X26 = 56700928 (0x3613000);             
            // 0x010F6140: ADRP x27, #0x3663000       | X27 = 57028608 (0x3663000);             
            // 0x010F6144: ADRP x28, #0x3679000       | X28 = 57118720 (0x3679000);             
            // 0x010F6148: LDR x24, [x24, #0x468]     | X24 = 1152921510000223936;              
            // 0x010F614C: LDR x25, [x25, #0x380]     | X25 = 1152921510000224960;              
            // 0x010F6150: LDR x26, [x26, #0x400]     | X26 = 1152921509994002736;              
            // 0x010F6154: LDR x27, [x27, #0xe90]     | X27 = 1152921509993964848;              
            // 0x010F6158: STR x8, [sp, #0x30]        | stack[1152921510002223792] = val_2;      //  dest_result_addr=1152921510002223792
            // 0x010F615C: STR q0, [sp, #0x20]        | stack[1152921510002223776] = val_3;      //  dest_result_addr=1152921510002223776
            // 0x010F6160: LDR x28, [x28, #0xdf8]     | X28 = 1152921504782245888;              
            // 0x010F6164: B #0x10f630c               |  goto label_8;                          
            goto label_8;
            label_26:
            // 0x010F6168: LDR x1, [x25]              | X1 = public ILRuntime.CLR.Method.CLRMethod List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::get_Current();
            // 0x010F616C: ADD x0, sp, #0x20          | X0 = (1152921510002223744 + 32) = 1152921510002223776 (0x100000014196EAA0);
            // 0x010F6170: BL #0x13372d8              | X0 = val_3.get_InitialType();           
            System.Type val_4 = val_3.InitialType;
            // 0x010F6174: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x010F6178: CBNZ x20, #0x10f6180       | if (val_4 != null) goto label_4;        
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x010F617C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_4:
            // 0x010F6180: LDR x8, [x20, #0x40]       | 
            // 0x010F6184: CBZ x8, #0x10f6190         | if (val_2 == 0) goto label_5;           
            if(val_2 == 0)
            {
                goto label_5;
            }
            // 0x010F6188: LDR w21, [x8, #0x18]       | W21 = val_2 + 24;                       
            val_11 = mem[val_2 + 24];
            val_11 = val_2 + 24;
            // 0x010F618C: B #0x10f6194               |  goto label_6;                          
            goto label_6;
            label_5:
            // 0x010F6190: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_6:
            // 0x010F6194: CBNZ x19, #0x10f619c       | if (param != null) goto label_7;        
            if(val_12 != null)
            {
                goto label_7;
            }
            // 0x010F6198: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_7:
            // 0x010F619C: LDR x1, [x26]              | X1 = public System.Int32 System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Count();
            // 0x010F61A0: MOV x0, x19                | X0 = param;//m1                         
            // 0x010F61A4: BL #0x25ed72c              | X0 = param.get_Count();                 
            int val_5 = val_12.Count;
            // 0x010F61A8: CMP w21, w0                | STATE = COMPARE(0x0, val_5)             
            // 0x010F61AC: B.NE #0x10f630c            | if (val_11 != val_5) goto label_8;      
            if(val_11 != val_5)
            {
                goto label_8;
            }
            // 0x010F61B0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            label_25:
            // 0x010F61B4: CBNZ x19, #0x10f61bc       | if (param != null) goto label_9;        
            if(val_12 != null)
            {
                goto label_9;
            }
            // 0x010F61B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_9:
            // 0x010F61BC: LDR x1, [x26]              | X1 = public System.Int32 System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Count();
            // 0x010F61C0: MOV x0, x19                | X0 = param;//m1                         
            // 0x010F61C4: BL #0x25ed72c              | X0 = param.get_Count();                 
            int val_6 = val_12.Count;
            // 0x010F61C8: CMP w21, w0                | STATE = COMPARE(0x0, val_6)             
            // 0x010F61CC: B.GE #0x10f6394            | if (0 >= val_6) goto label_10;          
            if(0 >= val_6)
            {
                goto label_10;
            }
            // 0x010F61D0: CBNZ x19, #0x10f61d8       | if (param != null) goto label_11;       
            if(val_12 != null)
            {
                goto label_11;
            }
            // 0x010F61D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_11:
            // 0x010F61D8: LDR x2, [x27]              | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F61DC: MOV x0, x19                | X0 = param;//m1                         
            // 0x010F61E0: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x010F61E4: BL #0x25ed734              | X0 = param.get_Item(index:  0);         
            ILRuntime.CLR.TypeSystem.IType val_7 = val_12.Item[0];
            // 0x010F61E8: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x010F61EC: CBNZ x22, #0x10f61f4       | if (val_7 != null) goto label_12;       
            if(val_7 != null)
            {
                goto label_12;
            }
            // 0x010F61F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_12:
            // 0x010F61F4: LDR x8, [x22]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F61F8: LDR x1, [x28]              | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F61FC: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F6200: CBZ x9, #0x10f622c         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_13;
            // 0x010F6204: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F6208: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_11 = 0;
            // 0x010F620C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_15:
            // 0x010F6210: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F6214: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F6218: B.EQ #0x10f623c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_14;
            // 0x010F621C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x010F6220: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F6224: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F6228: B.LO #0x10f6210            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_15;
            label_13:
            // 0x010F622C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F6230: MOV x0, x22                | X0 = val_7;//m1                         
            val_13 = val_7;
            // 0x010F6234: BL #0x2776c24              | X0 = sub_2776C24( ?? val_7, ????);      
            // 0x010F6238: B #0x10f624c               |  goto label_16;                         
            goto label_16;
            label_14:
            // 0x010F623C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F6240: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F6244: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F6248: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_16:
            // 0x010F624C: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F6250: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x010F6254: BLR x8                     | X0 = sub_100000000A746000( ?? val_7, ????);
            // 0x010F6258: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x010F625C: CBNZ x20, #0x10f6264       | if (val_4 != null) goto label_17;       
            if(val_4 != null)
            {
                goto label_17;
            }
            // 0x010F6260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_17:
            // 0x010F6264: LDR x0, [x20, #0x20]       | 
            // 0x010F6268: CBNZ x0, #0x10f6284        | if (val_7 != null) goto label_19;       
            if(val_7 != null)
            {
                goto label_19;
            }
            // 0x010F626C: MOV x0, x20                | X0 = val_4;//m1                         
            // 0x010F6270: BL #0x10ecc24              | val_4.InitParameters();                 
            val_4.InitParameters();
            // 0x010F6274: LDR x0, [x20, #0x20]       | 
            // 0x010F6278: CBNZ x0, #0x10f6284        | if (val_4 != null) goto label_19;       
            if(val_4 != null)
            {
                goto label_19;
            }
            // 0x010F627C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x010F6280: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_19:
            // 0x010F6284: LDR x2, [x27]              | X2 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::get_Item(int index);
            // 0x010F6288: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x010F628C: BL #0x25ed734              | X0 = 0.get_Item(index:  0);             
            ILRuntime.CLR.TypeSystem.IType val_9 = 0.Item[0];
            // 0x010F6290: MOV x23, x0                | X23 = val_9;//m1                        
            // 0x010F6294: CBNZ x23, #0x10f629c       | if (val_9 != null) goto label_20;       
            if(val_9 != null)
            {
                goto label_20;
            }
            // 0x010F6298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_20:
            // 0x010F629C: LDR x8, [x23]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F62A0: LDR x1, [x28]              | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F62A4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010F62A8: CBZ x9, #0x10f62d4         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_21;
            // 0x010F62AC: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010F62B0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x010F62B4: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_23:
            // 0x010F62B8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010F62BC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F62C0: B.EQ #0x10f62e4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_22;
            // 0x010F62C4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x010F62C8: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010F62CC: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010F62D0: B.LO #0x10f62b8            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_23;
            label_21:
            // 0x010F62D4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F62D8: MOV x0, x23                | X0 = val_9;//m1                         
            val_14 = val_9;
            // 0x010F62DC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_9, ????);      
            // 0x010F62E0: B #0x10f62f4               |  goto label_24;                         
            goto label_24;
            label_22:
            // 0x010F62E4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010F62E8: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010F62EC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010F62F0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_24:
            // 0x010F62F4: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x010F62F8: MOV x0, x23                | X0 = val_9;//m1                         
            // 0x010F62FC: BLR x8                     | X0 = sub_100000000A746000( ?? val_9, ????);
            // 0x010F6300: ADD w21, w21, #1           | W21 = (0 + 1);                          
            val_11 = 0 + 1;
            // 0x010F6304: CMP x22, x0                | STATE = COMPARE(val_7, val_9)           
            // 0x010F6308: B.EQ #0x10f61b4            | if (val_7 == val_9) goto label_25;      
            if(val_7 == val_9)
            {
                goto label_25;
            }
            label_8:
            // 0x010F630C: LDR x1, [x24]              | X1 = public System.Boolean List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::MoveNext();
            // 0x010F6310: ADD x0, sp, #0x20          | X0 = (1152921510002223744 + 32) = 1152921510002223776 (0x100000014196EAA0);
            // 0x010F6314: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x010F6318: AND w8, w0, #1             | W8 = (1152921510002223776 & 1) = 0 (0x00000000);
            // 0x010F631C: TBNZ w8, #0, #0x10f6168    | if ((0x0 & 0x1) != 0) goto label_26;    
            if((0 & 1) != 0)
            {
                goto label_26;
            }
            // 0x010F6320: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F6324: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F6328: ADD x0, sp, #0x20          | X0 = (1152921510002223744 + 32) = 1152921510002223776 (0x100000014196EAA0);
            // 0x010F632C: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F6330: BL #0x13371f4              | val_3.Dispose();                        
            val_3.Dispose();
            // 0x010F6334: B #0x10f636c               |  goto label_29;                         
            goto label_29;
            // 0x010F6338: B #0x10f633c               |  goto label_28;                         
            goto label_28;
            label_28:
            // 0x010F633C: BL #0x981060               | X0 = sub_981060( ?? 0x100000014196EAA0, ????);
            // 0x010F6340: LDR x19, [x0]              | X19 = val_3;                            
            val_12 = val_3;
            // 0x010F6344: BL #0x980920               | X0 = sub_980920( ?? 0x100000014196EAA0, ????);
            // 0x010F6348: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F634C: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F6350: ADD x0, sp, #0x20          | X0 = (1152921510002223744 + 32) = 1152921510002223776 (0x100000014196EAA0);
            // 0x010F6354: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F6358: BL #0x13371f4              | val_3.Dispose();                        
            val_3.Dispose();
            // 0x010F635C: CBZ x19, #0x10f636c        | if (val_3 == 0) goto label_29;          
            if(val_12 == 0)
            {
                goto label_29;
            }
            // 0x010F6360: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6364: MOV x0, x19                | X0 = val_3;//m1                         
            // 0x010F6368: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_29:
            // 0x010F636C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            label_30:
            // 0x010F6370: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x010F6374: SUB sp, x29, #0x50         | SP = (1152921510002223888 - 80) = 1152921510002223808 (0x100000014196EAC0);
            // 0x010F6378: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x010F637C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x010F6380: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x010F6384: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x010F6388: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x010F638C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x010F6390: RET                        |  return (ILRuntime.CLR.Method.IMethod)null;
            return (ILRuntime.CLR.Method.IMethod)0;
            //  |  // // {name=val_0, type=ILRuntime.CLR.Method.IMethod, size=8, nGRN=0 }
            label_10:
            // 0x010F6394: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F6398: LDR x8, [x8, #0x958]       | X8 = 1152921510000233152;               
            // 0x010F639C: ADD x0, sp, #0x20          | X0 = (1152921510002223744 + 32) = 1152921510002223776 (0x100000014196EAA0);
            // 0x010F63A0: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.Method.CLRMethod>::Dispose();
            // 0x010F63A4: BL #0x13371f4              | val_3.Dispose();                        
            val_3.Dispose();
            // 0x010F63A8: B #0x10f6370               |  goto label_30;                         
            goto label_30;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F63AC (17785772), len: 1160  VirtAddr: 0x010F63AC RVA: 0x010F63AC token: 100663462 methodIndex: 28895 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType MakeGenericInstance(System.Collections.Generic.KeyValuePair<string, ILRuntime.CLR.TypeSystem.IType>[] genericArguments)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.CLRType> val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            // 0x010F63AC: STP x28, x27, [sp, #-0x60]! | stack[1152921510002423872] = ???;  stack[1152921510002423880] = ???;  //  dest_result_addr=1152921510002423872 |  dest_result_addr=1152921510002423880
            // 0x010F63B0: STP x26, x25, [sp, #0x10]  | stack[1152921510002423888] = ???;  stack[1152921510002423896] = ???;  //  dest_result_addr=1152921510002423888 |  dest_result_addr=1152921510002423896
            // 0x010F63B4: STP x24, x23, [sp, #0x20]  | stack[1152921510002423904] = ???;  stack[1152921510002423912] = ???;  //  dest_result_addr=1152921510002423904 |  dest_result_addr=1152921510002423912
            // 0x010F63B8: STP x22, x21, [sp, #0x30]  | stack[1152921510002423920] = ???;  stack[1152921510002423928] = ???;  //  dest_result_addr=1152921510002423920 |  dest_result_addr=1152921510002423928
            // 0x010F63BC: STP x20, x19, [sp, #0x40]  | stack[1152921510002423936] = ???;  stack[1152921510002423944] = ???;  //  dest_result_addr=1152921510002423936 |  dest_result_addr=1152921510002423944
            // 0x010F63C0: STP x29, x30, [sp, #0x50]  | stack[1152921510002423952] = ???;  stack[1152921510002423960] = ???;  //  dest_result_addr=1152921510002423952 |  dest_result_addr=1152921510002423960
            // 0x010F63C4: ADD x29, sp, #0x50         | X29 = (1152921510002423872 + 80) = 1152921510002423952 (0x100000014199F890);
            // 0x010F63C8: SUB sp, sp, #0x40          | SP = (1152921510002423872 - 64) = 1152921510002423808 (0x100000014199F800);
            // 0x010F63CC: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010F63D0: LDRB w8, [x21, #0xb0d]     | W8 = (bool)static_value_03735B0D;       
            // 0x010F63D4: MOV x20, x1                | X20 = genericArguments;//m1             
            // 0x010F63D8: MOV x19, x0                | X19 = 1152921510002435968 (0x10000001419A2780);//ML01
            // 0x010F63DC: TBNZ w8, #0, #0x10f63f8    | if (static_value_03735B0D == true) goto label_0;
            // 0x010F63E0: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x010F63E4: LDR x8, [x8, #0x468]       | X8 = 0x2B90D68;                         
            // 0x010F63E8: LDR w0, [x8]               | W0 = 0x1A1E;                            
            // 0x010F63EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A1E, ????);     
            // 0x010F63F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F63F4: STRB w8, [x21, #0xb0d]     | static_value_03735B0D = true;            //  dest_result_addr=57891597
            label_0:
            // 0x010F63F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F63FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F6400: MOV x1, x19                | X1 = 1152921510002435968 (0x10000001419A2780);//ML01
            // 0x010F6404: STP xzr, xzr, [sp, #0x28]  | stack[1152921510002423848] = 0x0;  stack[1152921510002423856] = 0x0;  //  dest_result_addr=1152921510002423848 |  dest_result_addr=1152921510002423856
            // 0x010F6408: STR xzr, [sp, #0x20]       | stack[1152921510002423840] = 0x0;        //  dest_result_addr=1152921510002423840
            // 0x010F640C: BL #0x1b557bc              | System.Threading.Monitor.Enter(obj:  0);
            System.Threading.Monitor.Enter(obj:  0);
            // 0x010F6410: LDR x22, [x19, #0x40]      | X22 = this.genericInstances; //P2       
            val_9 = this.genericInstances;
            // 0x010F6414: CBNZ x22, #0x10f6468       | if (this.genericInstances != null) goto label_2;
            if(val_9 != null)
            {
                goto label_2;
            }
            // 0x010F6418: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x010F641C: LDR x8, [x8, #0x230]       | X8 = 1152921504616644608;               
            // 0x010F6420: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x010F6424: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            // 0x010F6428: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            // 0x010F642C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010F6430: MOV x22, x0                | X22 = 1152921504616644608 (0x1000000000958000);//ML01
            val_9 = null;
            // 0x010F6434: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x010F6438: LDR x8, [x8, #0x648]       | X8 = 1152921510002389440;               
            // 0x010F643C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x010F6440: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.CLRType>::.ctor();
            // 0x010F6444: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.CLRType> val_1 = val_9;
            // 0x010F6448: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            // 0x010F644C: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.CLRType>();
            // 0x010F6450: STR x22, [x19, #0x40]      | this.genericInstances = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921510002436032
            this.genericInstances = val_9;
            // 0x010F6454: CBNZ x22, #0x10f6468       | if ( != 0) goto label_2;                
            if(null != 0)
            {
                goto label_2;
            }
            // 0x010F6458: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x010F645C: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            // 0x010F6460: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x010F6464: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_2:
            // 0x010F6468: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x010F646C: LDR x8, [x8, #0x5a8]       | X8 = 1152921510002390464;               
            // 0x010F6470: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x010F6474: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.CLRType>::GetEnumerator();
            // 0x010F6478: ADD x8, sp, #8             | X8 = (1152921510002423808 + 8) = 1152921510002423816 (0x100000014199F808);
            // 0x010F647C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x010F6480: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            // 0x010F6484: BL #0x25ebf2c              | X0 = val_9.GetEnumerator();             
            List.Enumerator<T> val_2 = val_9.GetEnumerator();
            // 0x010F6488: LDR x8, [sp, #0x18]        | X8 = val_3;                              //  find_add[1152921510002411968]
            // 0x010F648C: LDUR q0, [sp, #8]          | Q0 = val_4;                              //  find_add[1152921510002411968]
            // 0x010F6490: ADRP x23, #0x3681000       | X23 = 57151488 (0x3681000);             
            // 0x010F6494: ADRP x24, #0x3684000       | X24 = 57163776 (0x3684000);             
            // 0x010F6498: ADRP x25, #0x3648000       | X25 = 56918016 (0x3648000);             
            // 0x010F649C: LDR x23, [x23, #0xc80]     | X23 = 1152921510002391488;              
            // 0x010F64A0: LDR x24, [x24, #0x2d8]     | X24 = 1152921510002392512;              
            // 0x010F64A4: STR x8, [sp, #0x30]        | stack[1152921510002423856] = val_3;      //  dest_result_addr=1152921510002423856
            // 0x010F64A8: STR q0, [sp, #0x20]        | stack[1152921510002423840] = val_4;      //  dest_result_addr=1152921510002423840
            // 0x010F64AC: LDR x25, [x25, #0xa88]     | X25 = 1152921509989983296;              
            // 0x010F64B0: B #0x10f655c               |  goto label_3;                          
            goto label_3;
            label_12:
            // 0x010F64B4: LDR x1, [x24]              | X1 = public ILRuntime.CLR.TypeSystem.CLRType List.Enumerator<ILRuntime.CLR.TypeSystem.CLRType>::get_Current();
            // 0x010F64B8: ADD x0, sp, #0x20          | X0 = (1152921510002423808 + 32) = 1152921510002423840 (0x100000014199F820);
            // 0x010F64BC: BL #0x13372d8              | X0 = val_4.get_InitialType();           
            System.Type val_5 = val_4.InitialType;
            // 0x010F64C0: MOV x21, x0                | X21 = val_5;//m1                        
            val_10 = val_5;
            // 0x010F64C4: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            var val_11 = 0;
            label_11:
            // 0x010F64C8: CBNZ x20, #0x10f64d0       | if (genericArguments != null) goto label_4;
            if(genericArguments != null)
            {
                goto label_4;
            }
            // 0x010F64CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_4:
            // 0x010F64D0: LDR w8, [x20, #0x18]       | W8 = genericArguments.Length; //P2      
            // 0x010F64D4: CMP w26, w8                | STATE = COMPARE(0x0, genericArguments.Length)
            // 0x010F64D8: B.GE #0x10f65ac            | if (0 >= genericArguments.Length) goto label_5;
            if(val_11 >= genericArguments.Length)
            {
                goto label_5;
            }
            // 0x010F64DC: CBNZ x21, #0x10f64e4       | if (val_5 != null) goto label_6;        
            if(val_10 != null)
            {
                goto label_6;
            }
            // 0x010F64E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_6:
            // 0x010F64E4: LDR x22, [x21, #0x38]      | 
            // 0x010F64E8: CBNZ x22, #0x10f64f0       | if (0x0 != 0) goto label_7;             
            if(val_9 != 0)
            {
                goto label_7;
            }
            // 0x010F64EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_7:
            // 0x010F64F0: LDR w8, [x22, #0x18]       | W8 = 0x9814C0;                          
            // 0x010F64F4: CMP w26, w8                | STATE = COMPARE(0x0, 0x9814C0)          
            // 0x010F64F8: B.LO #0x10f6508            | if (0 < 9966784) goto label_8;          
            if(val_11 < 9966784)
            {
                goto label_8;
            }
            // 0x010F64FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x010F6500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6504: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_8:
            // 0x010F6508: LDR x1, [x25]              | X1 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>::get_Value();
            // 0x010F650C: SXTW x27, w26              | X27 = 0 (0x00000000);                   
            // 0x010F6510: ADD x8, x22, x27, lsl #4   | X8 = (val_9 + 0);                       
            var val_6 = val_9 + 0;
            // 0x010F6514: ADD x0, x8, #0x20          | X0 = ((val_9 + 0) + 32);                
            var val_7 = val_6 + 32;
            // 0x010F6518: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x010F651C: MOV x22, x0                | X22 = ((val_9 + 0) + 32);//m1           
            // 0x010F6520: CBNZ x20, #0x10f6528       | if (genericArguments != null) goto label_9;
            if(genericArguments != null)
            {
                goto label_9;
            }
            // 0x010F6524: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ((val_9 + 0) + 32), ????);
            label_9:
            // 0x010F6528: LDR w8, [x20, #0x18]       | W8 = genericArguments.Length; //P2      
            // 0x010F652C: CMP w26, w8                | STATE = COMPARE(0x0, genericArguments.Length)
            // 0x010F6530: B.LO #0x10f6540            | if (0 < genericArguments.Length) goto label_10;
            if(val_11 < genericArguments.Length)
            {
                goto label_10;
            }
            // 0x010F6534: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ((val_9 + 0) + 32), ????);
            // 0x010F6538: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F653C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_9 + 0) + 32), ????);
            label_10:
            // 0x010F6540: LDR x1, [x25]              | X1 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>::get_Value();
            // 0x010F6544: ADD x8, x20, x27, lsl #4   | X8 = genericArguments[0x0]; //PARR1     
            // 0x010F6548: ADD x0, x8, #0x20          | X0 = genericArguments[0x0][0x20]; //PARR1 
            // 0x010F654C: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x010F6550: ADD w26, w26, #1           | W26 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x010F6554: CMP x22, x0                | STATE = COMPARE(((val_9 + 0) + 32), genericArguments[0x0][0x20])
            // 0x010F6558: B.EQ #0x10f64c8            | if (val_7 == genericArguments[0][32]) goto label_11;
            if(val_7 == genericArguments[0][32])
            {
                goto label_11;
            }
            label_3:
            // 0x010F655C: LDR x1, [x23]              | X1 = public System.Boolean List.Enumerator<ILRuntime.CLR.TypeSystem.CLRType>::MoveNext();
            // 0x010F6560: ADD x0, sp, #0x20          | X0 = (1152921510002423808 + 32) = 1152921510002423840 (0x100000014199F820);
            // 0x010F6564: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x010F6568: AND w8, w0, #1             | W8 = (1152921510002423840 & 1) = 0 (0x00000000);
            // 0x010F656C: TBNZ w8, #0, #0x10f64b4    | if ((0x0 & 0x1) != 0) goto label_12;    
            if((0 & 1) != 0)
            {
                goto label_12;
            }
            // 0x010F6570: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x010F6574: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x010F6578: MOVZ w26, #0xa9            | W26 = 169 (0xA9);//ML01                 
            val_12 = 169;
            // 0x010F657C: B #0x10f65b4               |  goto label_15;                         
            goto label_15;
            label_40:
            // 0x010F6580: CMP w1, #1                 | STATE = COMPARE(public System.Boolean List.Enumerator<ILRuntime.CLR.TypeSystem.CLRType>::MoveNext(), 0x1)
            // 0x010F6584: B.NE #0x10f65a0            | if (public System.Boolean List.Enumerator<ILRuntime.CLR.TypeSystem.CLRType>::MoveNext() != 0x1) goto label_14;
            if((public System.Boolean List.Enumerator<ILRuntime.CLR.TypeSystem.CLRType>::MoveNext()) != 1)
            {
                goto label_14;
            }
            // 0x010F6588: BL #0x981060               | X0 = sub_981060( ?? 0x100000014199F820, ????);
            // 0x010F658C: LDR x22, [x0]              | X22 = val_4;                            
            val_11 = val_4;
            // 0x010F6590: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x010F6594: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x010F6598: BL #0x980920               | X0 = sub_980920( ?? 0x100000014199F820, ????);
            // 0x010F659C: B #0x10f65b4               |  goto label_15;                         
            goto label_15;
            label_14:
            // 0x010F65A0: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x010F65A4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x010F65A8: B #0x10f6748               |  goto label_45;                         
            goto label_45;
            label_5:
            // 0x010F65AC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x010F65B0: MOVZ w26, #0x125           | W26 = 293 (0x125);//ML01                
            val_12 = 293;
            label_15:
            // 0x010F65B4: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x010F65B8: LDR x8, [x8, #0x108]       | X8 = 1152921510002397632;               
            // 0x010F65BC: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<ILRuntime.CLR.TypeSystem.CLRType>::Dispose();
            // 0x010F65C0: ADD x0, sp, #0x20          | X0 = (1152921510002423808 + 32) = 1152921510002423840 (0x100000014199F820);
            // 0x010F65C4: BL #0x13371f4              | val_4.Dispose();                        
            val_4.Dispose();
            // 0x010F65C8: CMP w26, #0xa9             | STATE = COMPARE(0x125, 0xA9)            
            // 0x010F65CC: B.EQ #0x10f65e0            | if (0x125 == 0xA9) goto label_17;       
            if(293 == 169)
            {
                goto label_17;
            }
            // 0x010F65D0: CMP w26, #0x125            | STATE = COMPARE(0x125, 0x125)           
            // 0x010F65D4: B.NE #0x10f65e8            | if (0x125 != 0x125) goto label_18;      
            if(293 != 293)
            {
                goto label_18;
            }
            // 0x010F65D8: MOVZ w26, #0x125           | W26 = 293 (0x125);//ML01                
            val_13 = 293;
            // 0x010F65DC: B #0x10f6754               |  goto label_44;                         
            goto label_44;
            label_17:
            // 0x010F65E0: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            // 0x010F65E4: B #0x10f6604               |  goto label_22;                         
            goto label_22;
            label_18:
            // 0x010F65E8: CBZ x22, #0x10f6600        | if (0x0 == 0) goto label_21;            
            if(val_11 == 0)
            {
                goto label_21;
            }
            // 0x010F65EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F65F0: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x010F65F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x010F65F8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            // 0x010F65FC: B #0x10f6604               |  goto label_22;                         
            goto label_22;
            label_21:
            // 0x010F6600: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            label_22:
            // 0x010F6604: CBNZ x20, #0x10f660c       | if (genericArguments != null) goto label_23;
            if(genericArguments != null)
            {
                goto label_23;
            }
            // 0x010F6608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014199F820, ????);
            label_23:
            // 0x010F660C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x010F6610: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x010F6614: LDR w24, [x20, #0x18]      | W24 = genericArguments.Length; //P2     
            // 0x010F6618: LDR x23, [x8]              | X23 = typeof(System.Type[]);            
            // 0x010F661C: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x010F6620: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x010F6624: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x010F6628: MOV x1, x24                | X1 = genericArguments.Length;//m1       
            // 0x010F662C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x010F6630: MOV x23, x0                | X23 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x010F6634: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x010F6638: B #0x10f6648               |  goto label_24;                         
            goto label_24;
            label_37:
            // 0x010F663C: ADD x8, x23, x28, lsl #3   | X8 = (null + (X28) << 3);               
            var val_8 = null + ((X28) << 3);
            // 0x010F6640: ADD w27, w27, #1           | W27 = (val_14 + 1) = val_14 (0x00000001);
            val_14 = 1;
            // 0x010F6644: STR x24, [x8, #0x20]       | mem2[0] = genericArguments.Length;       //  dest_result_addr=0
            mem2[0] = genericArguments.Length;
            label_24:
            // 0x010F6648: CBNZ x20, #0x10f6650       | if (genericArguments != null) goto label_25;
            if(genericArguments != null)
            {
                goto label_25;
            }
            // 0x010F664C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_25:
            // 0x010F6650: LDR w8, [x20, #0x18]       | W8 = genericArguments.Length; //P2      
            // 0x010F6654: CMP w27, w8                | STATE = COMPARE(0x1, genericArguments.Length)
            // 0x010F6658: B.GE #0x10f67a4            | if (val_14 >= genericArguments.Length) goto label_26;
            if(val_14 >= genericArguments.Length)
            {
                goto label_26;
            }
            // 0x010F665C: CMP w27, w8                | STATE = COMPARE(0x1, genericArguments.Length)
            // 0x010F6660: B.LO #0x10f6670            | if (val_14 < genericArguments.Length) goto label_27;
            if(val_14 < genericArguments.Length)
            {
                goto label_27;
            }
            // 0x010F6664: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Type[]), ????);
            // 0x010F6668: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F666C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Type[]), ????);
            label_27:
            // 0x010F6670: LDR x1, [x25]              | X1 = public ILRuntime.CLR.TypeSystem.IType System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>::get_Value();
            // 0x010F6674: SXTW x28, w27              | X28 = 1 (0x00000001);                   
            // 0x010F6678: ADD x8, x20, x28, lsl #4   | X8 = genericArguments[0x10]; //PARR1    
            // 0x010F667C: ADD x0, x8, #0x20          | X0 = genericArguments[0x10][0x20]; //PARR1 
            // 0x010F6680: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x010F6684: MOV x24, x0                | X24 = genericArguments[0x10][0x20];//m1 
            var val_12 = genericArguments[16][32];
            // 0x010F6688: CBNZ x24, #0x10f6690       | if (genericArguments[0x10][0x20] != null) goto label_28;
            if(val_12 != null)
            {
                goto label_28;
            }
            // 0x010F668C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? genericArguments[0x10][0x20], ????);
            label_28:
            // 0x010F6690: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x010F6694: LDR x8, [x24]              | X8 = typeof(System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[]);
            // 0x010F6698: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x010F669C: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010F66A0: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__il2cppRuntimeField_interface_offsets_count;
            // 0x010F66A4: CBZ x9, #0x10f66d0         | if (System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__il2cppRuntimeField_interface_offsets_count == 0) goto label_29;
            // 0x010F66A8: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__il2cppRuntimeField_interfaceOffsets;
            // 0x010F66AC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x010F66B0: ADD x10, x10, #8           | X10 = (System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__il
            label_31:
            // 0x010F66B4: LDUR x12, [x10, #-8]       | X12 = (System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__il2cppRuntimeField_interfaceOffsets + 8) + -8;
            // 0x010F66B8: CMP x12, x1                | STATE = COMPARE((System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__il2cppRuntimeField_interfaceOffsets + 8) + -8, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010F66BC: B.EQ #0x10f66e0            | if ((System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__il2cppRuntimeField_interfaceOffsets + 8) + -8 == null) goto label_30;
            // 0x010F66C0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x010F66C4: ADD x10, x10, #0x10        | X10 = ((System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__i
            // 0x010F66C8: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__il2cppRuntimeField_interface_offsets_count)
            // 0x010F66CC: B.LO #0x10f66b4            | if (0 < System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[].__il2cppRuntimeField_interface_offsets_count) goto label_31;
            label_29:
            // 0x010F66D0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010F66D4: MOV x0, x24                | X0 = genericArguments[0x10][0x20];//m1  
            val_15 = val_12;
            // 0x010F66D8: BL #0x2776c24              | X0 = sub_2776C24( ?? genericArguments[0x10][0x20], ????);
            // 0x010F66DC: B #0x10f66f0               |  goto label_32;                         
            goto label_32;
            label_30:
            // 0x010F66E0: LDR w9, [x10]              | W9 =  typeof(Il2CppRuntimeInterfaceOffsetPair*);
            // 0x010F66E4: ADD w9, w9, #2             | W9 = (__il2cppRuntimeField_interfaceOffsets + 2) = 2 (0x00000002);
            // 0x010F66E8: ADD x8, x8, w9, uxtw #4    |  //  not_find_field:typeof(System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[]).2
            // 0x010F66EC: ADD x0, x8, #0x110         |  //  not_find_field:typeof(System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[]).272
            label_32:
            // 0x010F66F0: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.KeyValuePair<System.String, ILRuntime.CLR.TypeSystem.IType>[]);  //  | 
            // 0x010F66F4: MOV x0, x24                | X0 = genericArguments[0x10][0x20];//m1  
            // 0x010F66F8: BLR x8                     | X0 = sub_100000006935EE90( ?? genericArguments[0x10][0x20], ????);
            // 0x010F66FC: MOV x24, x0                | X24 = genericArguments[0x10][0x20];//m1 
            // 0x010F6700: CBNZ x23, #0x10f6708       | if ( != null) goto label_33;            
            if(null != null)
            {
                goto label_33;
            }
            // 0x010F6704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? genericArguments[0x10][0x20], ????);
            label_33:
            // 0x010F6708: CBZ x24, #0x10f672c        | if (genericArguments[0x10][0x20] == null) goto label_35;
            if(val_12 == null)
            {
                goto label_35;
            }
            // 0x010F670C: LDR x8, [x23]              | X8 = ;                                  
            // 0x010F6710: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x010F6714: MOV x0, x24                | X0 = genericArguments[0x10][0x20];//m1  
            // 0x010F6718: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? genericArguments[0x10][0x20], ????);
            // 0x010F671C: CBNZ x0, #0x10f672c        | if (genericArguments[0x10][0x20] != null) goto label_35;
            if(val_12 != null)
            {
                goto label_35;
            }
            // 0x010F6720: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? genericArguments[0x10][0x20], ????);
            // 0x010F6724: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6728: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? genericArguments[0x10][0x20], ????);
            label_35:
            // 0x010F672C: LDR w8, [x23, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x010F6730: CMP w27, w8                | STATE = COMPARE(0x1, System.Type[].__il2cppRuntimeField_namespaze)
            // 0x010F6734: B.LO #0x10f663c            | if (val_14 < System.Type[].__il2cppRuntimeField_namespaze) goto label_37;
            // 0x010F6738: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? genericArguments[0x10][0x20], ????);
            // 0x010F673C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6740: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? genericArguments[0x10][0x20], ????);
            // 0x010F6744: B #0x10f663c               |  goto label_37;                         
            goto label_37;
            label_45:
            // 0x010F6748: BL #0x981060               | X0 = sub_981060( ?? 0x100000014199F820, ????);
            // 0x010F674C: LDR x22, [x0]              | X22 = val_4;                            
            val_11 = val_4;
            // 0x010F6750: BL #0x980920               | X0 = sub_980920( ?? 0x100000014199F820, ????);
            label_44:
            // 0x010F6754: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F6758: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F675C: MOV x1, x19                | X1 = 1152921510002435968 (0x10000001419A2780);//ML01
            // 0x010F6760: BL #0x1b557c4              | System.Threading.Monitor.Exit(obj:  0); 
            System.Threading.Monitor.Exit(obj:  0);
            // 0x010F6764: CMP w26, #0x125            | STATE = COMPARE(0x0, 0x125)             
            // 0x010F6768: B.EQ #0x10f677c            | if (val_13 == 0x125) goto label_39;     
            if(val_13 == 293)
            {
                goto label_39;
            }
            // 0x010F676C: CBZ x22, #0x10f677c        | if (val_4 == 0) goto label_39;          
            if(val_11 == 0)
            {
                goto label_39;
            }
            // 0x010F6770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6774: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x010F6778: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_39:
            // 0x010F677C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x010F6780: SUB sp, x29, #0x50         | SP = (1152921510002423952 - 80) = 1152921510002423872 (0x100000014199F840);
            // 0x010F6784: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x010F6788: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x010F678C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x010F6790: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x010F6794: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x010F6798: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x010F679C: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)null;
            return (ILRuntime.CLR.TypeSystem.IType)val_10;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
            // 0x010F67A0: B #0x10f6580               |  goto label_40;                         
            goto label_40;
            label_26:
            // 0x010F67A4: LDR x24, [x19, #0x10]      | X24 = this.clrType; //P2                
            // 0x010F67A8: CBNZ x24, #0x10f67b0       | if (this.clrType != null) goto label_41;
            if(this.clrType != null)
            {
                goto label_41;
            }
            // 0x010F67AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_41:
            // 0x010F67B0: LDR x8, [x24]              | X8 = typeof(System.Type);               
            // 0x010F67B4: LDR x9, [x8, #0x770]       | X9 = typeof(System.Type).__il2cppRuntimeField_770;
            // 0x010F67B8: LDR x2, [x8, #0x778]       | X2 = typeof(System.Type).__il2cppRuntimeField_778;
            // 0x010F67BC: MOV x0, x24                | X0 = this.clrType;//m1                  
            // 0x010F67C0: MOV x1, x23                | X1 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x010F67C4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_770();
            // 0x010F67C8: MOV x24, x0                | X24 = this.clrType;//m1                 
            // 0x010F67CC: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x010F67D0: LDR x25, [x19, #0x28]      | X25 = this.appdomain; //P2              
            // 0x010F67D4: LDR x8, [x8, #0x290]       | X8 = 1152921504782032896;               
            // 0x010F67D8: LDR x0, [x8]               | X0 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F67DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.CLR.TypeSystem.CLRType), ????);
            // 0x010F67E0: MOV x23, x0                | X23 = 1152921504782032896 (0x100000000A712000);//ML01
            // 0x010F67E4: MOV x0, x23                | X0 = 1152921504782032896 (0x100000000A712000);//ML01
            ILRuntime.CLR.TypeSystem.CLRType val_10 = null;
            // 0x010F67E8: MOV x1, x24                | X1 = this.clrType;//m1                  
            // 0x010F67EC: MOV x2, x25                | X2 = this.appdomain;//m1                
            // 0x010F67F0: BL #0x10f2a28              | .ctor(clrType:  this.clrType, appdomain:  this.appdomain);
            val_10 = new ILRuntime.CLR.TypeSystem.CLRType(clrType:  this.clrType, appdomain:  this.appdomain);
            // 0x010F67F4: CBNZ x23, #0x10f67fc       | if ( != 0) goto label_42;               
            if(null != 0)
            {
                goto label_42;
            }
            // 0x010F67F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(clrType:  this.clrType, appdomain:  this.appdomain), ????);
            label_42:
            // 0x010F67FC: STR x20, [x23, #0x38]      | typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_38 = genericArguments;  //  dest_result_addr=1152921504782032952
            typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_38 = genericArguments;
            // 0x010F6800: LDR x20, [x19, #0x40]      | X20 = this.genericInstances; //P2       
            // 0x010F6804: CBNZ x20, #0x10f680c       | if (this.genericInstances != null) goto label_43;
            if(this.genericInstances != null)
            {
                goto label_43;
            }
            // 0x010F6808: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(clrType:  this.clrType, appdomain:  this.appdomain), ????);
            label_43:
            // 0x010F680C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x010F6810: LDR x8, [x8, #0x828]       | X8 = 1152921510002410944;               
            // 0x010F6814: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.CLRType>::Add(ILRuntime.CLR.TypeSystem.CLRType item);
            // 0x010F6818: MOV x0, x20                | X0 = this.genericInstances;//m1         
            // 0x010F681C: MOV x1, x23                | X1 = 1152921504782032896 (0x100000000A712000);//ML01
            // 0x010F6820: BL #0x25ea480              | this.genericInstances.Add(item:  null); 
            this.genericInstances.Add(item:  null);
            // 0x010F6824: MOVZ w26, #0x125           | W26 = 293 (0x125);//ML01                
            // 0x010F6828: MOV x21, x23               | X21 = 1152921504782032896 (0x100000000A712000);//ML01
            // 0x010F682C: B #0x10f6754               |  goto label_44;                         
            goto label_44;
            // 0x010F6830: B #0x10f6748               |  goto label_45;                         
            goto label_45;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F6834 (17786932), len: 236  VirtAddr: 0x010F6834 RVA: 0x010F6834 token: 100663463 methodIndex: 28896 delegateWrapperIndex: 0 methodInvoker: 0
        public object CreateDefaultInstance()
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_5;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_6;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_7;
            // 0x010F6834: STP x22, x21, [sp, #-0x30]! | stack[1152921510002611696] = ???;  stack[1152921510002611704] = ???;  //  dest_result_addr=1152921510002611696 |  dest_result_addr=1152921510002611704
            // 0x010F6838: STP x20, x19, [sp, #0x10]  | stack[1152921510002611712] = ???;  stack[1152921510002611720] = ???;  //  dest_result_addr=1152921510002611712 |  dest_result_addr=1152921510002611720
            // 0x010F683C: STP x29, x30, [sp, #0x20]  | stack[1152921510002611728] = ???;  stack[1152921510002611736] = ???;  //  dest_result_addr=1152921510002611728 |  dest_result_addr=1152921510002611736
            // 0x010F6840: ADD x29, sp, #0x20         | X29 = (1152921510002611696 + 32) = 1152921510002611728 (0x10000001419CD610);
            // 0x010F6844: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F6848: LDRB w8, [x20, #0xb0e]     | W8 = (bool)static_value_03735B0E;       
            // 0x010F684C: MOV x19, x0                | X19 = 1152921510002623744 (0x10000001419D0500);//ML01
            // 0x010F6850: TBNZ w8, #0, #0x10f686c    | if (static_value_03735B0E == true) goto label_0;
            // 0x010F6854: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x010F6858: LDR x8, [x8, #0x958]       | X8 = 0x2B90D0C;                         
            // 0x010F685C: LDR w0, [x8]               | W0 = 0x1A07;                            
            // 0x010F6860: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A07, ????);     
            // 0x010F6864: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F6868: STRB w8, [x20, #0xb0e]     | static_value_03735B0E = true;            //  dest_result_addr=57891598
            label_0:
            // 0x010F686C: MOV x20, x19               | X20 = 1152921510002623744 (0x10000001419D0500);//ML01
            // 0x010F6870: LDR x21, [x20, #0x80]!     | X21 = this.createDefaultInstanceDelegate; //P2 
            val_5 = this.createDefaultInstanceDelegate;
            // 0x010F6874: CBNZ x21, #0x10f6908       | if (this.createDefaultInstanceDelegate != null) goto label_6;
            if(val_5 != null)
            {
                goto label_6;
            }
            // 0x010F6878: LDR x21, [x19, #0x28]      | X21 = this.appdomain; //P2              
            // 0x010F687C: CBNZ x21, #0x10f6884       | if (this.appdomain != null) goto label_2;
            if(this.appdomain != null)
            {
                goto label_2;
            }
            // 0x010F6880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A07, ????);     
            label_2:
            // 0x010F6884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6888: MOV x0, x21                | X0 = this.appdomain;//m1                
            // 0x010F688C: BL #0x28e4358              | X0 = this.appdomain.get_CreateDefaultInstanceMap();
            System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate> val_1 = this.appdomain.CreateDefaultInstanceMap;
            // 0x010F6890: LDR x21, [x19, #0x10]      | X21 = this.clrType; //P2                
            // 0x010F6894: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x010F6898: CBNZ x22, #0x10f68a0       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x010F689C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x010F68A0: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x010F68A4: LDR x8, [x8, #0xf70]       | X8 = 1152921510002597696;               
            // 0x010F68A8: MOV x0, x22                | X0 = val_1;//m1                         
            // 0x010F68AC: MOV x1, x21                | X1 = this.clrType;//m1                  
            // 0x010F68B0: MOV x2, x20                | X2 = 1152921510002623872 (0x10000001419D0580);//ML01
            // 0x010F68B4: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate>::TryGetValue(System.Type key, out ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate value);
            // 0x010F68B8: BL #0x23fe7ec              | X0 = val_1.TryGetValue(key:  this.clrType, value: out  val_5 = this.createDefaultInstanceDelegate);
            bool val_2 = val_1.TryGetValue(key:  this.clrType, value: out  val_5);
            // 0x010F68BC: TBZ w0, #0, #0x10f68c8     | if (val_2 == false) goto label_4;       
            if(val_2 == false)
            {
                goto label_4;
            }
            // 0x010F68C0: LDR x21, [x20]             | X21 = this.createDefaultInstanceDelegate;
            val_6 = val_5;
            // 0x010F68C4: B #0x10f68fc               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x010F68C8: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x010F68CC: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x010F68D0: LDR x8, [x8, #0x2f0]       | X8 = 1152921510002598720;               
            // 0x010F68D4: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x010F68D8: LDR x20, [x8]              | X20 = System.Object ILRuntime.CLR.TypeSystem.CLRType::<CreateDefaultInstance>m__0();
            // 0x010F68DC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_3 = null;
            // 0x010F68E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x010F68E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F68E8: MOV x1, x19                | X1 = 1152921510002623744 (0x10000001419D0500);//ML01
            // 0x010F68EC: MOV x2, x20                | X2 = 1152921510002598720 (0x10000001419CA340);//ML01
            // 0x010F68F0: MOV x21, x0                | X21 = 1152921504824152064 (0x100000000CF3D000);//ML01
            val_7 = val_3;
            // 0x010F68F4: BL #0x28e8d84              | .ctor(object:  this, method:  System.Object ILRuntime.CLR.TypeSystem.CLRType::<CreateDefaultInstance>m__0());
            val_3 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  this, method:  System.Object ILRuntime.CLR.TypeSystem.CLRType::<CreateDefaultInstance>m__0());
            // 0x010F68F8: STR x21, [x19, #0x80]      | this.createDefaultInstanceDelegate = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921510002623872
            this.createDefaultInstanceDelegate = val_7;
            label_5:
            // 0x010F68FC: CBNZ x21, #0x10f6908       | if ( != 0) goto label_6;                
            if(null != 0)
            {
                goto label_6;
            }
            // 0x010F6900: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Object ILRuntime.CLR.TypeSystem.CLRType::<CreateDefaultInstance>m__0()), ????);
            // 0x010F6904: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_5 = 0;
            label_6:
            // 0x010F6908: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010F690C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010F6910: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6914: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x010F6918: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010F691C: B #0x28e8d94               | return val_5.Invoke();                  
            return val_5.Invoke();
        
        }
        //
        // Offset in libil2cpp.so: 0x010F6920 (17787168), len: 252  VirtAddr: 0x010F6920 RVA: 0x010F6920 token: 100663464 methodIndex: 28897 delegateWrapperIndex: 0 methodInvoker: 0
        public object CreateArrayInstance(int size)
        {
            //
            // Disasemble & Code
            //  | 
            IntPtr val_5;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_6;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_7;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_8;
            // 0x010F6920: STP x24, x23, [sp, #-0x40]! | stack[1152921510002758496] = ???;  stack[1152921510002758504] = ???;  //  dest_result_addr=1152921510002758496 |  dest_result_addr=1152921510002758504
            // 0x010F6924: STP x22, x21, [sp, #0x10]  | stack[1152921510002758512] = ???;  stack[1152921510002758520] = ???;  //  dest_result_addr=1152921510002758512 |  dest_result_addr=1152921510002758520
            // 0x010F6928: STP x20, x19, [sp, #0x20]  | stack[1152921510002758528] = ???;  stack[1152921510002758536] = ???;  //  dest_result_addr=1152921510002758528 |  dest_result_addr=1152921510002758536
            // 0x010F692C: STP x29, x30, [sp, #0x30]  | stack[1152921510002758544] = ???;  stack[1152921510002758552] = ???;  //  dest_result_addr=1152921510002758544 |  dest_result_addr=1152921510002758552
            // 0x010F6930: ADD x29, sp, #0x30         | X29 = (1152921510002758496 + 48) = 1152921510002758544 (0x10000001419F1390);
            // 0x010F6934: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010F6938: LDRB w8, [x21, #0xb0f]     | W8 = (bool)static_value_03735B0F;       
            // 0x010F693C: MOV w19, w1                | W19 = size;//m1                         
            // 0x010F6940: MOV x20, x0                | X20 = 1152921510002770560 (0x10000001419F4280);//ML01
            // 0x010F6944: TBNZ w8, #0, #0x10f6960    | if (static_value_03735B0F == true) goto label_0;
            // 0x010F6948: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x010F694C: LDR x8, [x8, #0xc10]       | X8 = 0x2B90D08;                         
            // 0x010F6950: LDR w0, [x8]               | W0 = 0x1A06;                            
            // 0x010F6954: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A06, ????);     
            // 0x010F6958: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F695C: STRB w8, [x21, #0xb0f]     | static_value_03735B0F = true;            //  dest_result_addr=57891599
            label_0:
            // 0x010F6960: MOV x21, x20               | X21 = 1152921510002770560 (0x10000001419F4280);//ML01
            val_5 = this;
            // 0x010F6964: LDR x22, [x21, #0x88]!     | X22 = this.createArrayInstanceDelegate; //P2 
            val_6 = this.createArrayInstanceDelegate;
            // 0x010F6968: CBNZ x22, #0x10f69fc       | if (this.createArrayInstanceDelegate != null) goto label_6;
            if(val_6 != null)
            {
                goto label_6;
            }
            // 0x010F696C: LDR x22, [x20, #0x28]      | X22 = this.appdomain; //P2              
            // 0x010F6970: CBNZ x22, #0x10f6978       | if (this.appdomain != null) goto label_2;
            if(this.appdomain != null)
            {
                goto label_2;
            }
            // 0x010F6974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A06, ????);     
            label_2:
            // 0x010F6978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F697C: MOV x0, x22                | X0 = this.appdomain;//m1                
            // 0x010F6980: BL #0x28e4360              | X0 = this.appdomain.get_CreateArrayInstanceMap();
            System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate> val_1 = this.appdomain.CreateArrayInstanceMap;
            // 0x010F6984: LDR x22, [x20, #0x10]      | X22 = this.clrType; //P2                
            // 0x010F6988: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x010F698C: CBNZ x23, #0x10f6994       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x010F6990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x010F6994: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x010F6998: LDR x8, [x8, #0x270]       | X8 = 1152921510002744512;               
            // 0x010F699C: MOV x0, x23                | X0 = val_1;//m1                         
            // 0x010F69A0: MOV x1, x22                | X1 = this.clrType;//m1                  
            // 0x010F69A4: MOV x2, x21                | X2 = 1152921510002770696 (0x10000001419F4308);//ML01
            // 0x010F69A8: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate>::TryGetValue(System.Type key, out ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate value);
            // 0x010F69AC: BL #0x23fe7ec              | X0 = val_1.TryGetValue(key:  this.clrType, value: out  val_6 = this.createArrayInstanceDelegate);
            bool val_2 = val_1.TryGetValue(key:  this.clrType, value: out  val_6);
            // 0x010F69B0: TBZ w0, #0, #0x10f69bc     | if (val_2 == false) goto label_4;       
            if(val_2 == false)
            {
                goto label_4;
            }
            // 0x010F69B4: LDR x22, [x21]             | X22 = this.createArrayInstanceDelegate; 
            val_7 = val_6;
            // 0x010F69B8: B #0x10f69f0               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x010F69BC: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x010F69C0: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x010F69C4: LDR x8, [x8, #0xf00]       | X8 = 1152921510002745536;               
            // 0x010F69C8: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x010F69CC: LDR x21, [x8]              | X21 = System.Object ILRuntime.CLR.TypeSystem.CLRType::<CreateArrayInstance>m__1(int s);
            val_5 = System.Object ILRuntime.CLR.TypeSystem.CLRType::<CreateArrayInstance>m__1(int s);
            // 0x010F69D0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_3 = null;
            // 0x010F69D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x010F69D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F69DC: MOV x1, x20                | X1 = 1152921510002770560 (0x10000001419F4280);//ML01
            // 0x010F69E0: MOV x2, x21                | X2 = 1152921510002745536 (0x10000001419EE0C0);//ML01
            // 0x010F69E4: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            val_8 = val_3;
            // 0x010F69E8: BL #0x28e8ac8              | .ctor(object:  this, method:  val_5);   
            val_3 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  this, method:  val_5);
            // 0x010F69EC: STR x22, [x20, #0x88]      | this.createArrayInstanceDelegate = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921510002770696
            this.createArrayInstanceDelegate = val_8;
            label_5:
            // 0x010F69F0: CBNZ x22, #0x10f69fc       | if ( != 0) goto label_6;                
            if(null != 0)
            {
                goto label_6;
            }
            // 0x010F69F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  val_5), ????);
            // 0x010F69F8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_6:
            // 0x010F69FC: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x010F6A00: MOV w1, w19                | W1 = size;//m1                          
            // 0x010F6A04: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010F6A08: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010F6A0C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010F6A10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F6A14: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010F6A18: B #0x28e8ad8               | return val_6.Invoke(size:  size);       
            return val_6.Invoke(size:  size);
        
        }
        //
        // Offset in libil2cpp.so: 0x010F6A1C (17787420), len: 384  VirtAddr: 0x010F6A1C RVA: 0x010F6A1C token: 100663465 methodIndex: 28898 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType MakeByRefType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_5;
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_6;
            // 0x010F6A1C: STP x24, x23, [sp, #-0x40]! | stack[1152921510002903264] = ???;  stack[1152921510002903272] = ???;  //  dest_result_addr=1152921510002903264 |  dest_result_addr=1152921510002903272
            // 0x010F6A20: STP x22, x21, [sp, #0x10]  | stack[1152921510002903280] = ???;  stack[1152921510002903288] = ???;  //  dest_result_addr=1152921510002903280 |  dest_result_addr=1152921510002903288
            // 0x010F6A24: STP x20, x19, [sp, #0x20]  | stack[1152921510002903296] = ???;  stack[1152921510002903304] = ???;  //  dest_result_addr=1152921510002903296 |  dest_result_addr=1152921510002903304
            // 0x010F6A28: STP x29, x30, [sp, #0x30]  | stack[1152921510002903312] = ???;  stack[1152921510002903320] = ???;  //  dest_result_addr=1152921510002903312 |  dest_result_addr=1152921510002903320
            // 0x010F6A2C: ADD x29, sp, #0x30         | X29 = (1152921510002903264 + 48) = 1152921510002903312 (0x1000000141A14910);
            // 0x010F6A30: SUB sp, sp, #0x10          | SP = (1152921510002903264 - 16) = 1152921510002903248 (0x1000000141A148D0);
            // 0x010F6A34: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F6A38: LDRB w8, [x20, #0xb10]     | W8 = (bool)static_value_03735B10;       
            // 0x010F6A3C: MOV x19, x0                | X19 = 1152921510002915328 (0x1000000141A17800);//ML01
            // 0x010F6A40: TBNZ w8, #0, #0x10f6a5c    | if (static_value_03735B10 == true) goto label_0;
            // 0x010F6A44: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x010F6A48: LDR x8, [x8, #0x2a0]       | X8 = 0x2B90D64;                         
            // 0x010F6A4C: LDR w0, [x8]               | W0 = 0x1A1D;                            
            // 0x010F6A50: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A1D, ????);     
            // 0x010F6A54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F6A58: STRB w8, [x20, #0xb10]     | static_value_03735B10 = true;            //  dest_result_addr=57891600
            label_0:
            // 0x010F6A5C: LDR x0, [x19, #0x98]       | X0 = this.byRefType; //P2               
            val_6 = this.byRefType;
            // 0x010F6A60: CBNZ x0, #0x10f6b40        | if (this.byRefType != null) goto label_1;
            if(val_6 != null)
            {
                goto label_1;
            }
            // 0x010F6A64: LDR x20, [x19, #0x10]      | X20 = this.clrType; //P2                
            // 0x010F6A68: CBNZ x20, #0x10f6a70       | if (this.clrType != null) goto label_2; 
            if(this.clrType != null)
            {
                goto label_2;
            }
            // 0x010F6A6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.byRefType, ????);
            label_2:
            // 0x010F6A70: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x010F6A74: MOV x0, x20                | X0 = this.clrType;//m1                  
            // 0x010F6A78: LDR x9, [x8, #0x7b0]       | X9 = typeof(System.Type).__il2cppRuntimeField_7B0;
            // 0x010F6A7C: LDR x1, [x8, #0x7b8]       | X1 = typeof(System.Type).__il2cppRuntimeField_7B8;
            // 0x010F6A80: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_7B0();
            // 0x010F6A84: ADRP x23, #0x35c2000       | X23 = 56369152 (0x35C2000);             
            // 0x010F6A88: LDR x21, [x19, #0x28]      | X21 = this.appdomain; //P2              
            // 0x010F6A8C: LDR x23, [x23, #0x290]     | X23 = 1152921504782032896;              
            // 0x010F6A90: MOV x22, x0                | X22 = this.clrType;//m1                 
            // 0x010F6A94: LDR x8, [x23]              | X8 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6A98: MOV x0, x8                 | X0 = 1152921504782032896 (0x100000000A712000);//ML01
            ILRuntime.CLR.TypeSystem.CLRType val_1 = null;
            // 0x010F6A9C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.CLR.TypeSystem.CLRType), ????);
            // 0x010F6AA0: MOV x1, x22                | X1 = this.clrType;//m1                  
            // 0x010F6AA4: MOV x2, x21                | X2 = this.appdomain;//m1                
            // 0x010F6AA8: MOV x20, x0                | X20 = 1152921504782032896 (0x100000000A712000);//ML01
            // 0x010F6AAC: BL #0x10f2a28              | .ctor(clrType:  this.clrType, appdomain:  this.appdomain);
            val_1 = new ILRuntime.CLR.TypeSystem.CLRType(clrType:  this.clrType, appdomain:  this.appdomain);
            // 0x010F6AB0: STR x20, [x19, #0x98]      | this.byRefType = typeof(ILRuntime.CLR.TypeSystem.CLRType);  //  dest_result_addr=1152921510002915480
            this.byRefType = val_1;
            // 0x010F6AB4: CBZ x20, #0x10f6b08        | if ( == 0) goto label_3;                
            if(null == 0)
            {
                goto label_3;
            }
            // 0x010F6AB8: LDR x8, [x20]              | X8 = ;                                  
            // 0x010F6ABC: LDR x1, [x23]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6AC0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x010F6AC4: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F6AC8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F6ACC: B.LO #0x10f6ae4            | if (mem[null + 260] < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x010F6AD0: LDR x10, [x8, #0xb0]       | X10 = .interfaces;                      
            // 0x010F6AD4: ADD x9, x10, x9, lsl #3    | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3)
            // 0x010F6AD8: LDUR x9, [x9, #-8]         | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F6ADC: CMP x9, x1                 | STATE = COMPARE((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F6AE0: B.EQ #0x10f6b0c            | if ((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x010F6AE4: LDR x0, [x8, #0x30]        | X0 = .constructors;                     
            // 0x010F6AE8: ADD x8, sp, #8             | X8 = (1152921510002903248 + 8) = 1152921510002903256 (0x1000000141A148D8);
            // 0x010F6AEC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? .constructors, ????);
            // 0x010F6AF0: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921510002891328]
            // 0x010F6AF4: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x010F6AF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6AFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x010F6B00: ADD x0, sp, #8             | X0 = (1152921510002903248 + 8) = 1152921510002903256 (0x1000000141A148D8);
            // 0x010F6B04: BL #0x299a140              | 
            label_3:
            // 0x010F6B08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000141A148D8, ????);
            label_5:
            // 0x010F6B0C: LDR x8, [x20]              | X8 = ;                                  
            // 0x010F6B10: LDR x1, [x23]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6B14: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x010F6B18: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F6B1C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F6B20: B.LO #0x10f6b58            | if (mem[null + 260] < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_7;
            // 0x010F6B24: LDR x10, [x8, #0xb0]       | X10 = .interfaces;                      
            // 0x010F6B28: ADD x9, x10, x9, lsl #3    | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3)
            // 0x010F6B2C: LDUR x9, [x9, #-8]         | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F6B30: CMP x9, x1                 | STATE = COMPARE((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F6B34: B.NE #0x10f6b58            | if ((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_7;
            // 0x010F6B38: STR x19, [x20, #0xa0]      | typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_A0 = this;  //  dest_result_addr=1152921504782033056
            typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_A0 = this;
            // 0x010F6B3C: LDR x0, [x19, #0x98]       | X0 = this.byRefType; //P2               
            val_6 = this.byRefType;
            label_1:
            // 0x010F6B40: SUB sp, x29, #0x30         | SP = (1152921510002903312 - 48) = 1152921510002903264 (0x1000000141A148E0);
            // 0x010F6B44: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010F6B48: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010F6B4C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010F6B50: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010F6B54: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)this.byRefType;
            return val_6;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
            label_7:
            // 0x010F6B58: LDR x0, [x8, #0x30]        | X0 = .constructors;                     
            // 0x010F6B5C: MOV x8, sp                 | X8 = 1152921510002903248 (0x1000000141A148D0);//ML01
            // 0x010F6B60: BL #0x27d96d4              | X0 = sub_27D96D4( ?? .constructors, ????);
            // 0x010F6B64: LDR x0, [sp]               | X0 = val_5;                              //  find_add[1152921510002891328]
            // 0x010F6B68: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x010F6B6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6B70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x010F6B74: MOV x0, sp                 | X0 = 1152921510002903248 (0x1000000141A148D0);//ML01
            // 0x010F6B78: BL #0x299a140              | 
            // 0x010F6B7C: MOV x19, x0                | X19 = 1152921510002903248 (0x1000000141A148D0);//ML01
            // 0x010F6B80: ADD x0, sp, #8             | X0 = (1152921510002903248 + 8) = 1152921510002903256 (0x1000000141A148D8);
            label_8:
            // 0x010F6B84: BL #0x299a140              | 
            // 0x010F6B88: MOV x0, x19                | X0 = 1152921510002903248 (0x1000000141A148D0);//ML01
            // 0x010F6B8C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000141A148D0, ????);
            // 0x010F6B90: MOV x19, x0                | X19 = 1152921510002903248 (0x1000000141A148D0);//ML01
            // 0x010F6B94: MOV x0, sp                 | X0 = 1152921510002903248 (0x1000000141A148D0);//ML01
            // 0x010F6B98: B #0x10f6b84               |  goto label_8;                          
            goto label_8;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F6B9C (17787804), len: 956  VirtAddr: 0x010F6B9C RVA: 0x010F6B9C token: 100663466 methodIndex: 28899 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType MakeArrayType(int rank)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_10;
            //  | 
            var val_13;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            System.Collections.Generic.Dictionary<System.Int32, ILRuntime.CLR.TypeSystem.IType> val_18;
            //  | 
            System.Type val_19;
            //  | 
            ILRuntime.CLR.TypeSystem.CLRType val_20;
            //  | 
            ILRuntime.CLR.TypeSystem.CLRType val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            // 0x010F6B9C: STP x24, x23, [sp, #-0x40]! | stack[1152921510003051104] = ???;  stack[1152921510003051112] = ???;  //  dest_result_addr=1152921510003051104 |  dest_result_addr=1152921510003051112
            // 0x010F6BA0: STP x22, x21, [sp, #0x10]  | stack[1152921510003051120] = ???;  stack[1152921510003051128] = ???;  //  dest_result_addr=1152921510003051120 |  dest_result_addr=1152921510003051128
            // 0x010F6BA4: STP x20, x19, [sp, #0x20]  | stack[1152921510003051136] = ???;  stack[1152921510003051144] = ???;  //  dest_result_addr=1152921510003051136 |  dest_result_addr=1152921510003051144
            // 0x010F6BA8: STP x29, x30, [sp, #0x30]  | stack[1152921510003051152] = ???;  stack[1152921510003051160] = ???;  //  dest_result_addr=1152921510003051152 |  dest_result_addr=1152921510003051160
            // 0x010F6BAC: ADD x29, sp, #0x30         | X29 = (1152921510003051104 + 48) = 1152921510003051152 (0x1000000141A38A90);
            // 0x010F6BB0: SUB sp, sp, #0x40          | SP = (1152921510003051104 - 64) = 1152921510003051040 (0x1000000141A38A20);
            // 0x010F6BB4: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010F6BB8: LDRB w8, [x21, #0xb11]     | W8 = (bool)static_value_03735B11;       
            // 0x010F6BBC: MOV w19, w1                | W19 = rank;//m1                         
            // 0x010F6BC0: MOV x20, x0                | X20 = 1152921510003063168 (0x1000000141A3B980);//ML01
            // 0x010F6BC4: TBNZ w8, #0, #0x10f6be0    | if (static_value_03735B11 == true) goto label_0;
            // 0x010F6BC8: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x010F6BCC: LDR x8, [x8, #0xd78]       | X8 = 0x2B90D60;                         
            // 0x010F6BD0: LDR w0, [x8]               | W0 = 0x1A1C;                            
            // 0x010F6BD4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A1C, ????);     
            // 0x010F6BD8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F6BDC: STRB w8, [x21, #0xb11]     | static_value_03735B11 = true;            //  dest_result_addr=57891601
            label_0:
            // 0x010F6BE0: STR xzr, [sp, #8]          | stack[1152921510003051048] = 0x0;        //  dest_result_addr=1152921510003051048
            ILRuntime.CLR.TypeSystem.IType val_2 = 0;
            // 0x010F6BE4: LDR x21, [x20, #0xa8]      | X21 = this.arrayTypes; //P2             
            val_18 = this.arrayTypes;
            // 0x010F6BE8: CBNZ x21, #0x10f6c20       | if (this.arrayTypes != null) goto label_2;
            if(val_18 != null)
            {
                goto label_2;
            }
            // 0x010F6BEC: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x010F6BF0: LDR x8, [x8, #0xde8]       | X8 = 1152921504615792640;               
            // 0x010F6BF4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.Int32, ILRuntime.CLR.TypeSystem.IType> val_1 = null;
            // 0x010F6BF8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x010F6BFC: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x010F6C00: LDR x8, [x8, #0x700]       | X8 = 1152921510003023808;               
            // 0x010F6C04: MOV x21, x0                | X21 = 1152921504615792640 (0x1000000000888000);//ML01
            val_18 = val_1;
            // 0x010F6C08: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, ILRuntime.CLR.TypeSystem.IType>::.ctor();
            // 0x010F6C0C: BL #0x2413320              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.Int32, ILRuntime.CLR.TypeSystem.IType>();
            // 0x010F6C10: STR x21, [x20, #0xa8]      | this.arrayTypes = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921510003063336
            this.arrayTypes = val_18;
            // 0x010F6C14: CBNZ x21, #0x10f6c20       | if ( != 0) goto label_2;                
            if(null != 0)
            {
                goto label_2;
            }
            // 0x010F6C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x010F6C1C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_2:
            // 0x010F6C20: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x010F6C24: LDR x8, [x8, #0x3b0]       | X8 = 1152921510003024832;               
            // 0x010F6C28: ADD x2, sp, #8             | X2 = (1152921510003051040 + 8) = 1152921510003051048 (0x1000000141A38A28);
            // 0x010F6C2C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x010F6C30: MOV w1, w19                | W1 = rank;//m1                          
            // 0x010F6C34: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, ILRuntime.CLR.TypeSystem.IType>::TryGetValue(System.Int32 key, out ILRuntime.CLR.TypeSystem.IType value);
            // 0x010F6C38: BL #0x2416950              | X0 = val_18.TryGetValue(key:  rank, value: out  ILRuntime.CLR.TypeSystem.IType val_2 = 0);
            bool val_3 = val_18.TryGetValue(key:  rank, value: out  val_2);
            // 0x010F6C3C: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x010F6C40: TBNZ w8, #0, #0x10f6e80    | if ((val_3 & 1) == true) goto label_3;  
            if(val_4 == true)
            {
                goto label_3;
            }
            // 0x010F6C44: LDR x21, [x20, #0x10]      | X21 = this.clrType; //P2                
            // 0x010F6C48: CBNZ x21, #0x10f6c50       | if (this.clrType != null) goto label_4; 
            if(this.clrType != null)
            {
                goto label_4;
            }
            // 0x010F6C4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_4:
            // 0x010F6C50: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x010F6C54: CMP w19, #2                | STATE = COMPARE(rank, 0x2)              
            // 0x010F6C58: B.GE #0x10f6c70            | if (rank >= 2) goto label_5;            
            if(rank >= 2)
            {
                goto label_5;
            }
            // 0x010F6C5C: LDR x9, [x8, #0x790]       | X9 = typeof(System.Type).__il2cppRuntimeField_790;
            // 0x010F6C60: LDR x1, [x8, #0x798]       | X1 = typeof(System.Type).__il2cppRuntimeField_798;
            // 0x010F6C64: MOV x0, x21                | X0 = this.clrType;//m1                  
            val_19 = this.clrType;
            // 0x010F6C68: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_790();
            // 0x010F6C6C: B #0x10f6c84               |  goto label_6;                          
            goto label_6;
            label_5:
            // 0x010F6C70: LDR x9, [x8, #0x7a0]       | X9 = typeof(System.Type).__il2cppRuntimeField_7A0;
            // 0x010F6C74: LDR x2, [x8, #0x7a8]       | X2 = typeof(System.Type).__il2cppRuntimeField_7A8;
            // 0x010F6C78: MOV x0, x21                | X0 = this.clrType;//m1                  
            val_19 = this.clrType;
            // 0x010F6C7C: MOV w1, w19                | W1 = rank;//m1                          
            // 0x010F6C80: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_7A0();
            label_6:
            // 0x010F6C84: ADRP x24, #0x35c2000       | X24 = 56369152 (0x35C2000);             
            // 0x010F6C88: LDR x23, [x20, #0x28]      | X23 = this.appdomain; //P2              
            // 0x010F6C8C: LDR x24, [x24, #0x290]     | X24 = 1152921504782032896;              
            // 0x010F6C90: MOV x22, x0                | X22 = this.clrType;//m1                 
            // 0x010F6C94: LDR x0, [x24]              | X0 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            ILRuntime.CLR.TypeSystem.CLRType val_5 = null;
            // 0x010F6C98: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.CLR.TypeSystem.CLRType), ????);
            // 0x010F6C9C: MOV x1, x22                | X1 = this.clrType;//m1                  
            // 0x010F6CA0: MOV x2, x23                | X2 = this.appdomain;//m1                
            // 0x010F6CA4: MOV x21, x0                | X21 = 1152921504782032896 (0x100000000A712000);//ML01
            // 0x010F6CA8: BL #0x10f2a28              | .ctor(clrType:  val_19, appdomain:  this.appdomain);
            val_5 = new ILRuntime.CLR.TypeSystem.CLRType(clrType:  val_19, appdomain:  this.appdomain);
            // 0x010F6CAC: STR x21, [sp, #8]          | stack[1152921510003051048] = typeof(ILRuntime.CLR.TypeSystem.CLRType);  //  dest_result_addr=1152921510003051048
            // 0x010F6CB0: CBZ x21, #0x10f6d04        | if ( == 0) goto label_7;                
            if(null == 0)
            {
                goto label_7;
            }
            // 0x010F6CB4: LDR x8, [x21]              | X8 = ;                                  
            // 0x010F6CB8: LDR x1, [x24]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6CBC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x010F6CC0: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F6CC4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F6CC8: B.LO #0x10f6ce0            | if (mem[null + 260] < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x010F6CCC: LDR x10, [x8, #0xb0]       | X10 = .interfaces;                      
            // 0x010F6CD0: ADD x9, x10, x9, lsl #3    | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3)
            // 0x010F6CD4: LDUR x9, [x9, #-8]         | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F6CD8: CMP x9, x1                 | STATE = COMPARE((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F6CDC: B.EQ #0x10f6d08            | if ((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x010F6CE0: LDR x0, [x8, #0x30]        | X0 = .constructors;                     
            // 0x010F6CE4: ADD x8, sp, #0x18          | X8 = (1152921510003051040 + 24) = 1152921510003051064 (0x1000000141A38A38);
            // 0x010F6CE8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? .constructors, ????);
            // 0x010F6CEC: LDR x0, [sp, #0x18]        | X0 = val_7;                              //  find_add[1152921510003039168]
            // 0x010F6CF0: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x010F6CF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6CF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x010F6CFC: ADD x0, sp, #0x18          | X0 = (1152921510003051040 + 24) = 1152921510003051064 (0x1000000141A38A38);
            // 0x010F6D00: BL #0x299a140              | 
            label_7:
            // 0x010F6D04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000141A38A38, ????);
            label_9:
            // 0x010F6D08: LDR x8, [x21]              | X8 = ;                                  
            // 0x010F6D0C: LDR x1, [x24]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6D10: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x010F6D14: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F6D18: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F6D1C: B.LO #0x10f6e9c            | if (mem[null + 260] < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_11;
            // 0x010F6D20: LDR x10, [x8, #0xb0]       | X10 = .interfaces;                      
            // 0x010F6D24: ADD x9, x10, x9, lsl #3    | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3)
            // 0x010F6D28: LDUR x9, [x9, #-8]         | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F6D2C: CMP x9, x1                 | STATE = COMPARE((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F6D30: B.NE #0x10f6e9c            | if ((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_11;
            // 0x010F6D34: STR x20, [x21, #0xa0]      | typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_A0 = this;  //  dest_result_addr=1152921504782033056
            typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_A0 = this;
            // 0x010F6D38: LDR x21, [sp, #8]          | X21 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6D3C: CBZ x21, #0x10f6d90        | if ( == 0) goto label_12;               
            if(null == 0)
            {
                goto label_12;
            }
            // 0x010F6D40: LDR x8, [x21]              | X8 = ;                                  
            // 0x010F6D44: LDR x1, [x24]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6D48: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x010F6D4C: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F6D50: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F6D54: B.LO #0x10f6d6c            | if (mem[null + 260] < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x010F6D58: LDR x10, [x8, #0xb0]       | X10 = .interfaces;                      
            // 0x010F6D5C: ADD x9, x10, x9, lsl #3    | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3)
            // 0x010F6D60: LDUR x9, [x9, #-8]         | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F6D64: CMP x9, x1                 | STATE = COMPARE((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F6D68: B.EQ #0x10f6d94            | if ((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x010F6D6C: LDR x0, [x8, #0x30]        | X0 = .constructors;                     
            // 0x010F6D70: ADD x8, sp, #0x28          | X8 = (1152921510003051040 + 40) = 1152921510003051080 (0x1000000141A38A48);
            // 0x010F6D74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? .constructors, ????);
            // 0x010F6D78: LDR x0, [sp, #0x28]        | X0 = val_10;                             //  find_add[1152921510003039168]
            // 0x010F6D7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x010F6D80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6D84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x010F6D88: ADD x0, sp, #0x28          | X0 = (1152921510003051040 + 40) = 1152921510003051080 (0x1000000141A38A48);
            // 0x010F6D8C: BL #0x299a140              | 
            label_12:
            // 0x010F6D90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000141A38A48, ????);
            label_14:
            // 0x010F6D94: LDR x8, [x21]              | X8 = ;                                  
            val_20 = null;
            // 0x010F6D98: LDR x1, [x24]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6D9C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x010F6DA0: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F6DA4: CMP w10, w9                | STATE = COMPARE(mem[val_20 + 260], ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F6DA8: B.LO #0x10f6ec0            | if (mem[val_20 + 260] < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x010F6DAC: LDR x10, [x8, #0xb0]       | X10 = .interfaces;                      
            // 0x010F6DB0: ADD x9, x10, x9, lsl #3    | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3)
            // 0x010F6DB4: LDUR x9, [x9, #-8]         | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F6DB8: CMP x9, x1                 | STATE = COMPARE((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F6DBC: B.NE #0x10f6ec0            | if ((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_16;
            // 0x010F6DC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F6DC4: STRB w8, [x21, #0xe4]      | typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_E4 = 0x1;  //  dest_result_addr=1152921504782033124
            typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_E4 = 1;
            // 0x010F6DC8: LDR x21, [sp, #8]          | X21 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6DCC: CBZ x21, #0x10f6e20        | if ( == 0) goto label_17;               
            if(null == 0)
            {
                goto label_17;
            }
            // 0x010F6DD0: LDR x8, [x21]              | X8 = ;                                  
            // 0x010F6DD4: LDR x1, [x24]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6DD8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x010F6DDC: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F6DE0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F6DE4: B.LO #0x10f6dfc            | if (mem[null + 260] < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_18;
            // 0x010F6DE8: LDR x10, [x8, #0xb0]       | X10 = .interfaces;                      
            // 0x010F6DEC: ADD x9, x10, x9, lsl #3    | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3)
            // 0x010F6DF0: LDUR x9, [x9, #-8]         | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F6DF4: CMP x9, x1                 | STATE = COMPARE((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F6DF8: B.EQ #0x10f6e24            | if ((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_19;
            label_18:
            // 0x010F6DFC: LDR x0, [x8, #0x30]        | X0 = .constructors;                     
            // 0x010F6E00: ADD x8, sp, #0x38          | X8 = (1152921510003051040 + 56) = 1152921510003051096 (0x1000000141A38A58);
            // 0x010F6E04: BL #0x27d96d4              | X0 = sub_27D96D4( ?? .constructors, ????);
            // 0x010F6E08: LDR x0, [sp, #0x38]        | X0 = val_13;                             //  find_add[1152921510003039168]
            // 0x010F6E0C: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x010F6E10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6E14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x010F6E18: ADD x0, sp, #0x38          | X0 = (1152921510003051040 + 56) = 1152921510003051096 (0x1000000141A38A58);
            // 0x010F6E1C: BL #0x299a140              | 
            label_17:
            // 0x010F6E20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000141A38A58, ????);
            label_19:
            // 0x010F6E24: LDR x8, [x21]              | X8 = ;                                  
            val_21 = null;
            // 0x010F6E28: LDR x1, [x24]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6E2C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x010F6E30: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010F6E34: CMP w10, w9                | STATE = COMPARE(mem[val_21 + 260], ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010F6E38: B.LO #0x10f6ee4            | if (mem[val_21 + 260] < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_21;
            // 0x010F6E3C: LDR x10, [x8, #0xb0]       | X10 = .interfaces;                      
            // 0x010F6E40: ADD x9, x10, x9, lsl #3    | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3)
            // 0x010F6E44: LDUR x9, [x9, #-8]         | X9 = (.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010F6E48: CMP x9, x1                 | STATE = COMPARE((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010F6E4C: B.NE #0x10f6ee4            | if ((.interfaces + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_21;
            // 0x010F6E50: STR w19, [x21, #0xe8]      | typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_E8 = rank;  //  dest_result_addr=1152921504782033128
            typeof(ILRuntime.CLR.TypeSystem.CLRType).__il2cppRuntimeField_E8 = rank;
            // 0x010F6E54: LDR x20, [x20, #0xa8]      | X20 = this.arrayTypes; //P2             
            // 0x010F6E58: LDR x21, [sp, #8]          | X21 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            val_18 = val_5;
            // 0x010F6E5C: CBNZ x20, #0x10f6e64       | if (this.arrayTypes != null) goto label_22;
            if(this.arrayTypes != null)
            {
                goto label_22;
            }
            // 0x010F6E60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000141A38A58, ????);
            label_22:
            // 0x010F6E64: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x010F6E68: LDR x8, [x8, #0x820]       | X8 = 1152921510003038144;               
            // 0x010F6E6C: MOV x0, x20                | X0 = this.arrayTypes;//m1               
            // 0x010F6E70: MOV w1, w19                | W1 = rank;//m1                          
            // 0x010F6E74: MOV x2, x21                | X2 = 1152921504782032896 (0x100000000A712000);//ML01
            // 0x010F6E78: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, ILRuntime.CLR.TypeSystem.IType>::set_Item(System.Int32 key, ILRuntime.CLR.TypeSystem.IType value);
            // 0x010F6E7C: BL #0x24147b0              | this.arrayTypes.set_Item(key:  rank, value:  val_18);
            this.arrayTypes.set_Item(key:  rank, value:  val_18);
            label_3:
            // 0x010F6E80: LDR x0, [sp, #8]           | X0 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F6E84: SUB sp, x29, #0x30         | SP = (1152921510003051152 - 48) = 1152921510003051104 (0x1000000141A38A60);
            // 0x010F6E88: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010F6E8C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010F6E90: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010F6E94: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010F6E98: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)typeof(ILRuntime.CLR.TypeSystem.CLRType);
            return (ILRuntime.CLR.TypeSystem.IType)val_5;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
            label_11:
            // 0x010F6E9C: LDR x0, [x8, #0x30]        | X0 = .constructors;                     
            // 0x010F6EA0: ADD x8, sp, #0x20          | X8 = (1152921510003051040 + 32) = 1152921510003051072 (0x1000000141A38A40);
            // 0x010F6EA4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? .constructors, ????);
            // 0x010F6EA8: LDR x0, [sp, #0x20]        | X0 = val_15;                             //  find_add[1152921510003039168]
            // 0x010F6EAC: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x010F6EB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6EB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x010F6EB8: ADD x0, sp, #0x20          | X0 = (1152921510003051040 + 32) = 1152921510003051072 (0x1000000141A38A40);
            // 0x010F6EBC: BL #0x299a140              | 
            label_16:
            // 0x010F6EC0: LDR x0, [x8, #0x30]        | X0 = ;                                  
            // 0x010F6EC4: ADD x8, sp, #0x30          | X8 = (1152921510003051040 + 48) = 1152921510003051088 (0x1000000141A38A50);
            // 0x010F6EC8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? , ????);           
            // 0x010F6ECC: LDR x0, [sp, #0x30]        | X0 = val_16;                             //  find_add[1152921510003039168]
            // 0x010F6ED0: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x010F6ED4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6ED8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x010F6EDC: ADD x0, sp, #0x30          | X0 = (1152921510003051040 + 48) = 1152921510003051088 (0x1000000141A38A50);
            // 0x010F6EE0: BL #0x299a140              | 
            label_21:
            // 0x010F6EE4: LDR x0, [x8, #0x30]        | X0 = ;                                  
            // 0x010F6EE8: ADD x8, sp, #0x10          | X8 = (1152921510003051040 + 16) = 1152921510003051056 (0x1000000141A38A30);
            // 0x010F6EEC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? , ????);           
            // 0x010F6EF0: LDR x0, [sp, #0x10]        | X0 = val_17;                             //  find_add[1152921510003039168]
            // 0x010F6EF4: BL #0x27af090              | X0 = sub_27AF090( ?? val_17, ????);     
            // 0x010F6EF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6EFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            // 0x010F6F00: ADD x0, sp, #0x10          | X0 = (1152921510003051040 + 16) = 1152921510003051056 (0x1000000141A38A30);
            // 0x010F6F04: BL #0x299a140              | 
            // 0x010F6F08: MOV x19, x0                | X19 = 1152921510003051056 (0x1000000141A38A30);//ML01
            val_22;
            // 0x010F6F0C: ADD x0, sp, #0x18          | X0 = (1152921510003051040 + 24) = 1152921510003051064 (0x1000000141A38A38);
            // 0x010F6F10: B #0x10f6f28               |  goto label_27;                         
            goto label_27;
            // 0x010F6F14: MOV x19, x0                | X19 = 1152921510003051064 (0x1000000141A38A38);//ML01
            val_22;
            // 0x010F6F18: ADD x0, sp, #0x28          | X0 = (1152921510003051040 + 40) = 1152921510003051080 (0x1000000141A38A48);
            // 0x010F6F1C: B #0x10f6f28               |  goto label_27;                         
            goto label_27;
            // 0x010F6F20: MOV x19, x0                | X19 = 1152921510003051080 (0x1000000141A38A48);//ML01
            val_22;
            // 0x010F6F24: ADD x0, sp, #0x38          | X0 = (1152921510003051040 + 56) = 1152921510003051096 (0x1000000141A38A58);
            label_27:
            // 0x010F6F28: BL #0x299a140              | 
            // 0x010F6F2C: MOV x0, x19                | X0 = 1152921510003051080 (0x1000000141A38A48);//ML01
            // 0x010F6F30: BL #0x980800               | X0 = sub_980800( ?? 0x1000000141A38A48, ????);
            // 0x010F6F34: MOV x19, x0                | X19 = 1152921510003051080 (0x1000000141A38A48);//ML01
            // 0x010F6F38: ADD x0, sp, #0x20          | X0 = (1152921510003051040 + 32) = 1152921510003051072 (0x1000000141A38A40);
            // 0x010F6F3C: B #0x10f6f28               |  goto label_27;                         
            goto label_27;
            // 0x010F6F40: MOV x19, x0                | X19 = 1152921510003051072 (0x1000000141A38A40);//ML01
            // 0x010F6F44: ADD x0, sp, #0x30          | X0 = (1152921510003051040 + 48) = 1152921510003051088 (0x1000000141A38A50);
            // 0x010F6F48: B #0x10f6f28               |  goto label_27;                         
            goto label_27;
            // 0x010F6F4C: MOV x19, x0                | X19 = 1152921510003051088 (0x1000000141A38A50);//ML01
            // 0x010F6F50: ADD x0, sp, #0x10          | X0 = (1152921510003051040 + 16) = 1152921510003051056 (0x1000000141A38A30);
            // 0x010F6F54: B #0x10f6f28               |  goto label_27;                         
            goto label_27;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F6F58 (17788760), len: 100  VirtAddr: 0x010F6F58 RVA: 0x010F6F58 token: 100663467 methodIndex: 28900 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType ResolveGenericType(ILRuntime.CLR.TypeSystem.IType contextType)
        {
            //
            // Disasemble & Code
            // 0x010F6F58: STP x20, x19, [sp, #-0x20]! | stack[1152921510003184640] = ???;  stack[1152921510003184648] = ???;  //  dest_result_addr=1152921510003184640 |  dest_result_addr=1152921510003184648
            // 0x010F6F5C: STP x29, x30, [sp, #0x10]  | stack[1152921510003184656] = ???;  stack[1152921510003184664] = ???;  //  dest_result_addr=1152921510003184656 |  dest_result_addr=1152921510003184664
            // 0x010F6F60: ADD x29, sp, #0x10         | X29 = (1152921510003184640 + 16) = 1152921510003184656 (0x1000000141A59410);
            // 0x010F6F64: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x010F6F68: LDRB w8, [x19, #0xb12]     | W8 = (bool)static_value_03735B12;       
            // 0x010F6F6C: TBNZ w8, #0, #0x10f6f88    | if (static_value_03735B12 == true) goto label_0;
            // 0x010F6F70: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x010F6F74: LDR x8, [x8, #0x340]       | X8 = 0x2B90D74;                         
            // 0x010F6F78: LDR w0, [x8]               | W0 = 0x1A21;                            
            // 0x010F6F7C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A21, ????);     
            // 0x010F6F80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F6F84: STRB w8, [x19, #0xb12]     | static_value_03735B12 = true;            //  dest_result_addr=57891602
            label_0:
            // 0x010F6F88: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x010F6F8C: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x010F6F90: LDR x0, [x8]               | X0 = typeof(System.NotImplementedException);
            System.NotImplementedException val_1 = null;
            // 0x010F6F94: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x010F6F98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010F6F9C: MOV x19, x0                | X19 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x010F6FA0: BL #0x17014c0              | .ctor();                                
            val_1 = new System.NotImplementedException();
            // 0x010F6FA4: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x010F6FA8: LDR x8, [x8, #0x910]       | X8 = 1152921510003171648;               
            // 0x010F6FAC: MOV x0, x19                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_2 = val_1;
            // 0x010F6FB0: LDR x1, [x8]               | X1 = public ILRuntime.CLR.TypeSystem.IType ILRuntime.CLR.TypeSystem.CLRType::ResolveGenericType(ILRuntime.CLR.TypeSystem.IType contextType);
            // 0x010F6FB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x010F6FB8: BL #0x10ec5ac              | .ctor(def:  public ILRuntime.CLR.TypeSystem.IType ILRuntime.CLR.TypeSystem.CLRType::ResolveGenericType(ILRuntime.CLR.TypeSystem.IType contextType), type:  null, domain:  null);
            val_2 = new ILRuntime.CLR.Method.CLRMethod(def:  public ILRuntime.CLR.TypeSystem.IType ILRuntime.CLR.TypeSystem.CLRType::ResolveGenericType(ILRuntime.CLR.TypeSystem.IType contextType), type:  null, domain:  null);
        
        }
        //
        // Offset in libil2cpp.so: 0x010F6FBC (17788860), len: 136  VirtAddr: 0x010F6FBC RVA: 0x010F6FBC token: 100663468 methodIndex: 28901 delegateWrapperIndex: 0 methodInvoker: 0
        public override int GetHashCode()
        {
            //
            // Disasemble & Code
            //  | 
            int val_3;
            //  | 
            var val_4;
            // 0x010F6FBC: STP x20, x19, [sp, #-0x20]! | stack[1152921510003300736] = ???;  stack[1152921510003300744] = ???;  //  dest_result_addr=1152921510003300736 |  dest_result_addr=1152921510003300744
            // 0x010F6FC0: STP x29, x30, [sp, #0x10]  | stack[1152921510003300752] = ???;  stack[1152921510003300760] = ???;  //  dest_result_addr=1152921510003300752 |  dest_result_addr=1152921510003300760
            // 0x010F6FC4: ADD x29, sp, #0x10         | X29 = (1152921510003300736 + 16) = 1152921510003300752 (0x1000000141A75990);
            // 0x010F6FC8: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010F6FCC: LDRB w8, [x20, #0xb13]     | W8 = (bool)static_value_03735B13;       
            // 0x010F6FD0: MOV x19, x0                | X19 = 1152921510003312768 (0x1000000141A78880);//ML01
            // 0x010F6FD4: TBNZ w8, #0, #0x10f6ff0    | if (static_value_03735B13 == true) goto label_0;
            // 0x010F6FD8: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x010F6FDC: LDR x8, [x8, #0x190]       | X8 = 0x2B90D3C;                         
            // 0x010F6FE0: LDR w0, [x8]               | W0 = 0x1A13;                            
            // 0x010F6FE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A13, ????);     
            // 0x010F6FE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F6FEC: STRB w8, [x20, #0xb13]     | static_value_03735B13 = true;            //  dest_result_addr=57891603
            label_0:
            // 0x010F6FF0: LDR w0, [x19, #0xe0]       | W0 = this.hashCode; //P2                
            val_3 = this.hashCode;
            // 0x010F6FF4: CMN w0, #1                 | STATE = COMPARE(this.hashCode, 0x1)     
            // 0x010F6FF8: B.NE #0x10f7038            | if (val_3 != 1) goto label_1;           
            if(val_3 != 1)
            {
                goto label_1;
            }
            // 0x010F6FFC: ADRP x20, #0x35c2000       | X20 = 56369152 (0x35C2000);             
            // 0x010F7000: LDR x20, [x20, #0x290]     | X20 = 1152921504782032896;              
            // 0x010F7004: LDR x0, [x20]              | X0 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            val_4 = null;
            // 0x010F7008: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_10A;
            // 0x010F700C: TBZ w8, #0, #0x10f7020     | if (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x010F7010: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_cctor_finished;
            // 0x010F7014: CBNZ w8, #0x10f7020        | if (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x010F7018: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.TypeSystem.CLRType), ????);
            // 0x010F701C: LDR x0, [x20]              | X0 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            val_4 = null;
            label_3:
            // 0x010F7020: LDR x1, [x0, #0xa0]        | X1 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_static_fields;
            // 0x010F7024: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_3 = 0;
            // 0x010F7028: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F702C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x010F7030: BL #0x1b65adc              | X0 = System.Threading.Interlocked.Add(location1: ref  val_3 = 0, value:  175190016);
            int val_1 = System.Threading.Interlocked.Add(location1: ref  val_3, value:  175190016);
            // 0x010F7034: STR w0, [x19, #0xe0]       | this.hashCode = val_1;                   //  dest_result_addr=1152921510003312992
            this.hashCode = val_1;
            label_1:
            // 0x010F7038: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F703C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F7040: RET                        |  return (System.Int32)val_1;            
            return val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010F7044 (17788996), len: 48  VirtAddr: 0x010F7044 RVA: 0x010F7044 token: 100663469 methodIndex: 28902 delegateWrapperIndex: 0 methodInvoker: 0
        public override string ToString()
        {
            //
            // Disasemble & Code
            // 0x010F7044: STP x20, x19, [sp, #-0x20]! | stack[1152921510003416832] = ???;  stack[1152921510003416840] = ???;  //  dest_result_addr=1152921510003416832 |  dest_result_addr=1152921510003416840
            // 0x010F7048: STP x29, x30, [sp, #0x10]  | stack[1152921510003416848] = ???;  stack[1152921510003416856] = ???;  //  dest_result_addr=1152921510003416848 |  dest_result_addr=1152921510003416856
            // 0x010F704C: ADD x29, sp, #0x10         | X29 = (1152921510003416832 + 16) = 1152921510003416848 (0x1000000141A91F10);
            // 0x010F7050: LDR x19, [x0, #0x10]       | X19 = this.clrType; //P2                
            // 0x010F7054: CBNZ x19, #0x10f705c       | if (this.clrType != null) goto label_0; 
            if(this.clrType != null)
            {
                goto label_0;
            }
            // 0x010F7058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x010F705C: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x010F7060: MOV x0, x19                | X0 = this.clrType;//m1                  
            // 0x010F7064: LDP x2, x1, [x8, #0x140]   | X2 = typeof(System.Type).__il2cppRuntimeField_140; X1 = typeof(System.Type).__il2cppRuntimeField_148; //  | 
            // 0x010F7068: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F706C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F7070: BR x2                      | goto typeof(System.Type).__il2cppRuntimeField_140;
            goto typeof(System.Type).__il2cppRuntimeField_140;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F7074 (17789044), len: 84  VirtAddr: 0x010F7074 RVA: 0x010F7074 token: 100663470 methodIndex: 28903 delegateWrapperIndex: 0 methodInvoker: 0
        private static CLRType()
        {
            //
            // Disasemble & Code
            // 0x010F7074: STP x20, x19, [sp, #-0x20]! | stack[1152921510003532928] = ???;  stack[1152921510003532936] = ???;  //  dest_result_addr=1152921510003532928 |  dest_result_addr=1152921510003532936
            // 0x010F7078: STP x29, x30, [sp, #0x10]  | stack[1152921510003532944] = ???;  stack[1152921510003532952] = ???;  //  dest_result_addr=1152921510003532944 |  dest_result_addr=1152921510003532952
            // 0x010F707C: ADD x29, sp, #0x10         | X29 = (1152921510003532928 + 16) = 1152921510003532944 (0x1000000141AAE490);
            // 0x010F7080: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x010F7084: LDRB w8, [x19, #0xb14]     | W8 = (bool)static_value_03735B14;       
            // 0x010F7088: TBNZ w8, #0, #0x10f70a4    | if (static_value_03735B14 == true) goto label_0;
            // 0x010F708C: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x010F7090: LDR x8, [x8, #0x9c8]       | X8 = 0x2B90CFC;                         
            // 0x010F7094: LDR w0, [x8]               | W0 = 0x1A03;                            
            // 0x010F7098: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A03, ????);     
            // 0x010F709C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010F70A0: STRB w8, [x19, #0xb14]     | static_value_03735B14 = true;            //  dest_result_addr=57891604
            label_0:
            // 0x010F70A4: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x010F70A8: LDR x8, [x8, #0x290]       | X8 = 1152921504782032896;               
            // 0x010F70AC: ORR w9, wzr, #0x20000000   | W9 = 536870912(0x20000000);             
            // 0x010F70B0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010F70B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_static_fields;
            // 0x010F70B8: STR w9, [x8]               | ILRuntime.CLR.TypeSystem.CLRType.instance_id = 536870912;  //  dest_result_addr=1152921504782036992
            ILRuntime.CLR.TypeSystem.CLRType.instance_id = 536870912;
            // 0x010F70BC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010F70C0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010F70C4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010F70C8 (17789128), len: 20  VirtAddr: 0x010F70C8 RVA: 0x010F70C8 token: 100663471 methodIndex: 28904 delegateWrapperIndex: 0 methodInvoker: 0
        private object <CreateDefaultInstance>m__0()
        {
            //
            // Disasemble & Code
            // 0x010F70C8: MOV x8, x0                 | X8 = 1152921510003661056 (0x1000000141ACD900);//ML01
            // 0x010F70CC: LDR x1, [x8, #0x10]        | X1 = this.clrType; //P2                 
            // 0x010F70D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F70D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010F70D8: B #0x18c8eb0               | return System.Activator.CreateInstance(type:  0);
            return System.Activator.CreateInstance(type:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x010F70DC (17789148), len: 28  VirtAddr: 0x010F70DC RVA: 0x010F70DC token: 100663472 methodIndex: 28905 delegateWrapperIndex: 0 methodInvoker: 0
        private object <CreateArrayInstance>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x010F70DC: LDR x8, [x0, #0x10]        | X8 = this.clrType; //P2                 
            // 0x010F70E0: MOV w9, w1                 | W9 = s;//m1                             
            // 0x010F70E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010F70E8: MOV w2, w9                 | W2 = s;//m1                             
            // 0x010F70EC: MOV x1, x8                 | X1 = this.clrType;//m1                  
            // 0x010F70F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010F70F4: B #0x18cd230               | return System.Array.CreateInstance(elementType:  0, length:  this.clrType);
            return System.Array.CreateInstance(elementType:  0, length:  this.clrType);
        
        }
    
    }

}
