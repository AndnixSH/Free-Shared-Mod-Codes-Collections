using UnityEngine;
public enum Portal.BrushEnemyTheway
{
    // Fields
    BET_time = 1
    ,BET_die = 2
    

}
