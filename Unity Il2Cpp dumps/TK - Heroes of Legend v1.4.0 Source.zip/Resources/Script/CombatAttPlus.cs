using UnityEngine;
public class CombatAttPlus
{
    // Fields
    private CombatAttPlus.FightPlusAtt plusAtt; //  0x00000010
    private static System.Collections.Generic.Dictionary<string, int> <>f__switch$map4; // static_offset: 0x00000000
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D86804 (14182404), len: 104  VirtAddr: 0x00D86804 RVA: 0x00D86804 token: 100691637 methodIndex: 26004 delegateWrapperIndex: 0 methodInvoker: 0
    public CombatAttPlus()
    {
        //
        // Disasemble & Code
        // 0x00D86804: STP x20, x19, [sp, #-0x20]! | stack[1152921514686507984] = ???;  stack[1152921514686507992] = ???;  //  dest_result_addr=1152921514686507984 |  dest_result_addr=1152921514686507992
        // 0x00D86808: STP x29, x30, [sp, #0x10]  | stack[1152921514686508000] = ???;  stack[1152921514686508008] = ???;  //  dest_result_addr=1152921514686508000 |  dest_result_addr=1152921514686508008
        // 0x00D8680C: ADD x29, sp, #0x10         | X29 = (1152921514686507984 + 16) = 1152921514686508000 (0x1000000258CB6BE0);
        // 0x00D86810: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D86814: LDRB w8, [x20, #0x442]     | W8 = (bool)static_value_03734442;       
        // 0x00D86818: MOV x19, x0                | X19 = 1152921514686520016 (0x1000000258CB9AD0);//ML01
        // 0x00D8681C: TBNZ w8, #0, #0xd86838     | if (static_value_03734442 == true) goto label_0;
        // 0x00D86820: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00D86824: LDR x8, [x8, #0xd10]       | X8 = 0x2B91754;                         
        // 0x00D86828: LDR w0, [x8]               | W0 = 0x1C9A;                            
        // 0x00D8682C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C9A, ????);     
        // 0x00D86830: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D86834: STRB w8, [x20, #0x442]     | static_value_03734442 = true;            //  dest_result_addr=57885762
        label_0:
        // 0x00D86838: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00D8683C: LDR x8, [x8, #0xbf8]       | X8 = 1152921504894119936;               
        // 0x00D86840: LDR x0, [x8]               | X0 = typeof(CombatAttPlus.FightPlusAtt);
        object val_1 = null;
        // 0x00D86844: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CombatAttPlus.FightPlusAtt), ????);
        // 0x00D86848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8684C: MOV x20, x0                | X20 = 1152921504894119936 (0x10000000111F7000);//ML01
        // 0x00D86850: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00D86854: STR x20, [x19, #0x10]      | this.plusAtt = typeof(CombatAttPlus.FightPlusAtt);  //  dest_result_addr=1152921514686520032
        this.plusAtt = val_1;
        // 0x00D86858: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D8685C: MOV x0, x19                | X0 = 1152921514686520016 (0x1000000258CB9AD0);//ML01
        // 0x00D86860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86864: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D86868: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D86874 (14182516), len: 2684  VirtAddr: 0x00D86874 RVA: 0x00D86874 token: 100691638 methodIndex: 26005 delegateWrapperIndex: 0 methodInvoker: 0
    public void AddPlusAttribute(string key, uint value, uint valuePer)
    {
        //
        // Disasemble & Code
        //  | 
        System.Collections.Generic.Dictionary<System.String, System.Int32> val_57;
        //  | 
        FightPlusAtt val_58;
        //  | 
        var val_59;
        //  | 
        System.Collections.Generic.Dictionary<System.String, System.Int32> val_60;
        //  | 
        var val_61;
        //  | 
        uint val_62;
        //  | 
        uint val_63;
        //  | 
        uint val_64;
        //  | 
        uint val_65;
        //  | 
        uint val_66;
        //  | 
        uint val_67;
        //  | 
        uint val_68;
        //  | 
        uint val_69;
        //  | 
        uint val_70;
        //  | 
        uint val_71;
        //  | 
        uint val_72;
        //  | 
        uint val_73;
        //  | 
        uint val_74;
        // 0x00D86874: STP x26, x25, [sp, #-0x50]! | stack[1152921514686730528] = ???;  stack[1152921514686730536] = ???;  //  dest_result_addr=1152921514686730528 |  dest_result_addr=1152921514686730536
        // 0x00D86878: STP x24, x23, [sp, #0x10]  | stack[1152921514686730544] = ???;  stack[1152921514686730552] = ???;  //  dest_result_addr=1152921514686730544 |  dest_result_addr=1152921514686730552
        // 0x00D8687C: STP x22, x21, [sp, #0x20]  | stack[1152921514686730560] = ???;  stack[1152921514686730568] = ???;  //  dest_result_addr=1152921514686730560 |  dest_result_addr=1152921514686730568
        // 0x00D86880: STP x20, x19, [sp, #0x30]  | stack[1152921514686730576] = ???;  stack[1152921514686730584] = ???;  //  dest_result_addr=1152921514686730576 |  dest_result_addr=1152921514686730584
        // 0x00D86884: STP x29, x30, [sp, #0x40]  | stack[1152921514686730592] = ???;  stack[1152921514686730600] = ???;  //  dest_result_addr=1152921514686730592 |  dest_result_addr=1152921514686730600
        // 0x00D86888: ADD x29, sp, #0x40         | X29 = (1152921514686730528 + 64) = 1152921514686730592 (0x1000000258CED160);
        // 0x00D8688C: SUB sp, sp, #0x10          | SP = (1152921514686730528 - 16) = 1152921514686730512 (0x1000000258CED110);
        // 0x00D86890: ADRP x23, #0x3734000       | X23 = 57884672 (0x3734000);             
        // 0x00D86894: LDRB w8, [x23, #0x443]     | W8 = (bool)static_value_03734443;       
        // 0x00D86898: MOV w19, w3                | W19 = valuePer;//m1                     
        val_58 = valuePer;
        // 0x00D8689C: MOV w20, w2                | W20 = value;//m1                        
        // 0x00D868A0: MOV x22, x1                | X22 = key;//m1                          
        // 0x00D868A4: MOV x21, x0                | X21 = 1152921514686742608 (0x1000000258CF0050);//ML01
        val_59 = this;
        // 0x00D868A8: TBNZ w8, #0, #0xd868c4     | if (static_value_03734443 == true) goto label_0;
        // 0x00D868AC: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
        // 0x00D868B0: LDR x8, [x8, #0x9b8]       | X8 = 0x2B91758;                         
        // 0x00D868B4: LDR w0, [x8]               | W0 = 0x1C9B;                            
        // 0x00D868B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C9B, ????);     
        // 0x00D868BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D868C0: STRB w8, [x23, #0x443]     | static_value_03734443 = true;            //  dest_result_addr=57885763
        label_0:
        // 0x00D868C4: STR wzr, [sp, #0xc]        | stack[1152921514686730524] = 0x0;        //  dest_result_addr=1152921514686730524
        int val_2 = 0;
        // 0x00D868C8: CBZ x22, #0xd872d4         | if (key == null) goto label_71;         
        if(key == null)
        {
            goto label_71;
        }
        // 0x00D868CC: ADRP x24, #0x364f000       | X24 = 56946688 (0x364F000);             
        // 0x00D868D0: LDR x24, [x24, #0x470]     | X24 = 1152921504894066688;              
        // 0x00D868D4: LDR x8, [x24]              | X8 = typeof(CombatAttPlus);             
        // 0x00D868D8: LDR x8, [x8, #0xa0]        | X8 = CombatAttPlus.__il2cppRuntimeField_static_fields;
        // 0x00D868DC: LDR x0, [x8]               | X0 = CombatAttPlus.<>f__switch$map4;    
        val_60 = CombatAttPlus.<>f__switch$map4;
        // 0x00D868E0: CBNZ x0, #0xd86c40         | if (CombatAttPlus.<>f__switch$map4 != null) goto label_5;
        if(val_60 != null)
        {
            goto label_5;
        }
        // 0x00D868E4: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
        // 0x00D868E8: LDR x8, [x8, #0x610]       | X8 = 1152921504615792640;               
        // 0x00D868EC: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.Int32> val_1 = null;
        // 0x00D868F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D868F4: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x00D868F8: LDR x8, [x8, #0x2a8]       | X8 = 1152921509743364176;               
        // 0x00D868FC: MOVZ w1, #0xd              | W1 = 13 (0xD);//ML01                    
        // 0x00D86900: MOV x23, x0                | X23 = 1152921504615792640 (0x1000000000888000);//ML01
        val_57 = val_1;
        // 0x00D86904: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::.ctor(int capacity);
        // 0x00D86908: BL #0x23f3000              | .ctor(capacity:  13);                   
        val_1 = new System.Collections.Generic.Dictionary<System.String, System.Int32>(capacity:  13);
        // 0x00D8690C: CBZ x23, #0xd86a6c         | if ( == 0) goto label_3;                
        if(null == 0)
        {
            goto label_3;
        }
        // 0x00D86910: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00D86914: ADRP x25, #0x35c3000       | X25 = 56373248 (0x35C3000);             
        // 0x00D86918: LDR x8, [x8, #0xbe8]       | X8 = (string**)(1152921510047656800)("attack");
        // 0x00D8691C: LDR x25, [x25, #0xfb0]     | X25 = 1152921509743365200;              
        val_61 = 1152921509743365200;
        // 0x00D86920: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00D86924: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86928: LDR x1, [x8]               | X1 = "attack";                          
        // 0x00D8692C: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86930: BL #0x23f5288              | Add(key:  "attack", value:  0);         
        Add(key:  "attack", value:  0);
        // 0x00D86934: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
        // 0x00D86938: LDR x8, [x8, #0x990]       | X8 = (string**)(1152921510348696608)("hp");
        // 0x00D8693C: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86940: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D86944: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86948: LDR x1, [x8]               | X1 = "hp";                              
        // 0x00D8694C: BL #0x23f5288              | Add(key:  "hp", value:  1);             
        Add(key:  "hp", value:  1);
        // 0x00D86950: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00D86954: LDR x8, [x8, #0xc90]       | X8 = (string**)(1152921510348700784)("phy_def");
        // 0x00D86958: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D8695C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
        // 0x00D86960: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86964: LDR x1, [x8]               | X1 = "phy_def";                         
        // 0x00D86968: BL #0x23f5288              | Add(key:  "phy_def", value:  2);        
        Add(key:  "phy_def", value:  2);
        // 0x00D8696C: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
        // 0x00D86970: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921510348702928)("mag_def");
        // 0x00D86974: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86978: ORR w2, wzr, #3            | W2 = 3(0x3);                            
        // 0x00D8697C: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86980: LDR x1, [x8]               | X1 = "mag_def";                         
        // 0x00D86984: BL #0x23f5288              | Add(key:  "mag_def", value:  3);        
        Add(key:  "mag_def", value:  3);
        // 0x00D86988: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
        // 0x00D8698C: LDR x8, [x8, #0x698]       | X8 = (string**)(1152921510681027456)("hitrate");
        // 0x00D86990: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86994: ORR w2, wzr, #4            | W2 = 4(0x4);                            
        // 0x00D86998: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D8699C: LDR x1, [x8]               | X1 = "hitrate";                         
        // 0x00D869A0: BL #0x23f5288              | Add(key:  "hitrate", value:  4);        
        Add(key:  "hitrate", value:  4);
        // 0x00D869A4: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
        // 0x00D869A8: LDR x8, [x8, #0xf38]       | X8 = (string**)(1152921514535346192)("dodge");
        // 0x00D869AC: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D869B0: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
        // 0x00D869B4: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D869B8: LDR x1, [x8]               | X1 = "dodge";                           
        // 0x00D869BC: BL #0x23f5288              | Add(key:  "dodge", value:  5);          
        Add(key:  "dodge", value:  5);
        // 0x00D869C0: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00D869C4: LDR x8, [x8, #0x878]       | X8 = (string**)(1152921514535350368)("destory");
        // 0x00D869C8: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D869CC: ORR w2, wzr, #6            | W2 = 6(0x6);                            
        // 0x00D869D0: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D869D4: LDR x1, [x8]               | X1 = "destory";                         
        // 0x00D869D8: BL #0x23f5288              | Add(key:  "destory", value:  6);        
        Add(key:  "destory", value:  6);
        // 0x00D869DC: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x00D869E0: LDR x8, [x8, #0x6d8]       | X8 = (string**)(1152921514535358656)("block");
        // 0x00D869E4: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D869E8: ORR w2, wzr, #7            | W2 = 7(0x7);                            
        // 0x00D869EC: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D869F0: LDR x1, [x8]               | X1 = "block";                           
        // 0x00D869F4: BL #0x23f5288              | Add(key:  "block", value:  7);          
        Add(key:  "block", value:  7);
        // 0x00D869F8: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00D869FC: LDR x8, [x8, #0x800]       | X8 = (string**)(1152921514535362832)("crit");
        // 0x00D86A00: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86A04: ORR w2, wzr, #8            | W2 = 8(0x8);                            
        // 0x00D86A08: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86A0C: LDR x1, [x8]               | X1 = "crit";                            
        // 0x00D86A10: BL #0x23f5288              | Add(key:  "crit", value:  8);           
        Add(key:  "crit", value:  8);
        // 0x00D86A14: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00D86A18: LDR x8, [x8, #0x8d0]       | X8 = (string**)(1152921514535375296)("anticrit");
        // 0x00D86A1C: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86A20: MOVZ w2, #0x9              | W2 = 9 (0x9);//ML01                     
        // 0x00D86A24: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86A28: LDR x1, [x8]               | X1 = "anticrit";                        
        // 0x00D86A2C: BL #0x23f5288              | Add(key:  "anticrit", value:  9);       
        Add(key:  "anticrit", value:  9);
        // 0x00D86A30: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00D86A34: LDR x8, [x8, #0x3c0]       | X8 = (string**)(1152921514535396064)("damage_bonus");
        // 0x00D86A38: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86A3C: MOVZ w2, #0xa              | W2 = 10 (0xA);//ML01                    
        // 0x00D86A40: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86A44: LDR x1, [x8]               | X1 = "damage_bonus";                    
        // 0x00D86A48: BL #0x23f5288              | Add(key:  "damage_bonus", value:  10);  
        Add(key:  "damage_bonus", value:  10);
        // 0x00D86A4C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00D86A50: LDR x8, [x8, #0x688]       | X8 = (string**)(1152921514535400256)("damage_reduce");
        // 0x00D86A54: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86A58: MOVZ w2, #0xb              | W2 = 11 (0xB);//ML01                    
        // 0x00D86A5C: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86A60: LDR x1, [x8]               | X1 = "damage_reduce";                   
        // 0x00D86A64: BL #0x23f5288              | Add(key:  "damage_reduce", value:  11); 
        Add(key:  "damage_reduce", value:  11);
        // 0x00D86A68: B #0xd86bf8                |  goto label_4;                          
        goto label_4;
        label_3:
        // 0x00D86A6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(capacity:  13), ????);
        // 0x00D86A70: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00D86A74: ADRP x25, #0x35c3000       | X25 = 56373248 (0x35C3000);             
        // 0x00D86A78: LDR x8, [x8, #0xbe8]       | X8 = (string**)(1152921510047656800)("attack");
        // 0x00D86A7C: LDR x25, [x25, #0xfb0]     | X25 = 1152921509743365200;              
        val_61 = 1152921509743365200;
        // 0x00D86A80: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00D86A84: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86A88: LDR x1, [x8]               | X1 = "attack";                          
        // 0x00D86A8C: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86A90: BL #0x23f5288              | Add(key:  "attack", value:  0);         
        Add(key:  "attack", value:  0);
        // 0x00D86A94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86A98: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
        // 0x00D86A9C: LDR x8, [x8, #0x990]       | X8 = (string**)(1152921510348696608)("hp");
        // 0x00D86AA0: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86AA4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D86AA8: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86AAC: LDR x1, [x8]               | X1 = "hp";                              
        // 0x00D86AB0: BL #0x23f5288              | Add(key:  "hp", value:  1);             
        Add(key:  "hp", value:  1);
        // 0x00D86AB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86AB8: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00D86ABC: LDR x8, [x8, #0xc90]       | X8 = (string**)(1152921510348700784)("phy_def");
        // 0x00D86AC0: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86AC4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
        // 0x00D86AC8: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86ACC: LDR x1, [x8]               | X1 = "phy_def";                         
        // 0x00D86AD0: BL #0x23f5288              | Add(key:  "phy_def", value:  2);        
        Add(key:  "phy_def", value:  2);
        // 0x00D86AD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86AD8: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
        // 0x00D86ADC: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921510348702928)("mag_def");
        // 0x00D86AE0: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86AE4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
        // 0x00D86AE8: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86AEC: LDR x1, [x8]               | X1 = "mag_def";                         
        // 0x00D86AF0: BL #0x23f5288              | Add(key:  "mag_def", value:  3);        
        Add(key:  "mag_def", value:  3);
        // 0x00D86AF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86AF8: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
        // 0x00D86AFC: LDR x8, [x8, #0x698]       | X8 = (string**)(1152921510681027456)("hitrate");
        // 0x00D86B00: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86B04: ORR w2, wzr, #4            | W2 = 4(0x4);                            
        // 0x00D86B08: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86B0C: LDR x1, [x8]               | X1 = "hitrate";                         
        // 0x00D86B10: BL #0x23f5288              | Add(key:  "hitrate", value:  4);        
        Add(key:  "hitrate", value:  4);
        // 0x00D86B14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86B18: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
        // 0x00D86B1C: LDR x8, [x8, #0xf38]       | X8 = (string**)(1152921514535346192)("dodge");
        // 0x00D86B20: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86B24: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
        // 0x00D86B28: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86B2C: LDR x1, [x8]               | X1 = "dodge";                           
        // 0x00D86B30: BL #0x23f5288              | Add(key:  "dodge", value:  5);          
        Add(key:  "dodge", value:  5);
        // 0x00D86B34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86B38: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00D86B3C: LDR x8, [x8, #0x878]       | X8 = (string**)(1152921514535350368)("destory");
        // 0x00D86B40: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86B44: ORR w2, wzr, #6            | W2 = 6(0x6);                            
        // 0x00D86B48: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86B4C: LDR x1, [x8]               | X1 = "destory";                         
        // 0x00D86B50: BL #0x23f5288              | Add(key:  "destory", value:  6);        
        Add(key:  "destory", value:  6);
        // 0x00D86B54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86B58: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x00D86B5C: LDR x8, [x8, #0x6d8]       | X8 = (string**)(1152921514535358656)("block");
        // 0x00D86B60: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86B64: ORR w2, wzr, #7            | W2 = 7(0x7);                            
        // 0x00D86B68: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86B6C: LDR x1, [x8]               | X1 = "block";                           
        // 0x00D86B70: BL #0x23f5288              | Add(key:  "block", value:  7);          
        Add(key:  "block", value:  7);
        // 0x00D86B74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86B78: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00D86B7C: LDR x8, [x8, #0x800]       | X8 = (string**)(1152921514535362832)("crit");
        // 0x00D86B80: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86B84: ORR w2, wzr, #8            | W2 = 8(0x8);                            
        // 0x00D86B88: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86B8C: LDR x1, [x8]               | X1 = "crit";                            
        // 0x00D86B90: BL #0x23f5288              | Add(key:  "crit", value:  8);           
        Add(key:  "crit", value:  8);
        // 0x00D86B94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86B98: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00D86B9C: LDR x8, [x8, #0x8d0]       | X8 = (string**)(1152921514535375296)("anticrit");
        // 0x00D86BA0: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86BA4: MOVZ w2, #0x9              | W2 = 9 (0x9);//ML01                     
        // 0x00D86BA8: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86BAC: LDR x1, [x8]               | X1 = "anticrit";                        
        // 0x00D86BB0: BL #0x23f5288              | Add(key:  "anticrit", value:  9);       
        Add(key:  "anticrit", value:  9);
        // 0x00D86BB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86BB8: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00D86BBC: LDR x8, [x8, #0x3c0]       | X8 = (string**)(1152921514535396064)("damage_bonus");
        // 0x00D86BC0: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86BC4: MOVZ w2, #0xa              | W2 = 10 (0xA);//ML01                    
        // 0x00D86BC8: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86BCC: LDR x1, [x8]               | X1 = "damage_bonus";                    
        // 0x00D86BD0: BL #0x23f5288              | Add(key:  "damage_bonus", value:  10);  
        Add(key:  "damage_bonus", value:  10);
        // 0x00D86BD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86BD8: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00D86BDC: LDR x8, [x8, #0x688]       | X8 = (string**)(1152921514535400256)("damage_reduce");
        // 0x00D86BE0: LDR x3, [x25]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86BE4: MOVZ w2, #0xb              | W2 = 11 (0xB);//ML01                    
        // 0x00D86BE8: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86BEC: LDR x1, [x8]               | X1 = "damage_reduce";                   
        // 0x00D86BF0: BL #0x23f5288              | Add(key:  "damage_reduce", value:  11); 
        Add(key:  "damage_reduce", value:  11);
        // 0x00D86BF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_4:
        // 0x00D86BF8: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00D86BFC: ADRP x9, #0x35c3000        | X9 = 56373248 (0x35C3000);              
        // 0x00D86C00: LDR x8, [x8, #0xec8]       | X8 = (string**)(1152921514535371104)("crit_hurt");
        // 0x00D86C04: LDR x9, [x9, #0xfb0]       | X9 = 1152921509743365200;               
        // 0x00D86C08: ORR w2, wzr, #0xc          | W2 = 12(0xC);                           
        // 0x00D86C0C: MOV x0, x23                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D86C10: LDR x1, [x8]               | X1 = "crit_hurt";                       
        // 0x00D86C14: LDR x3, [x9]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00D86C18: BL #0x23f5288              | Add(key:  "crit_hurt", value:  12);     
        Add(key:  "crit_hurt", value:  12);
        // 0x00D86C1C: LDR x8, [x24]              | X8 = typeof(CombatAttPlus);             
        // 0x00D86C20: LDR x8, [x8, #0xa0]        | X8 = CombatAttPlus.__il2cppRuntimeField_static_fields;
        // 0x00D86C24: STR x23, [x8]              | CombatAttPlus.<>f__switch$map4 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504894070784
        CombatAttPlus.<>f__switch$map4 = val_57;
        // 0x00D86C28: LDR x8, [x24]              | X8 = typeof(CombatAttPlus);             
        // 0x00D86C2C: LDR x8, [x8, #0xa0]        | X8 = CombatAttPlus.__il2cppRuntimeField_static_fields;
        // 0x00D86C30: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        val_60 = CombatAttPlus.<>f__switch$map4;
        // 0x00D86C34: CBNZ x0, #0xd86c40         | if ( != 0) goto label_5;                
        if(null != 0)
        {
            goto label_5;
        }
        // 0x00D86C38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D86C3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_60 = 0;
        label_5:
        // 0x00D86C40: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00D86C44: LDR x8, [x8, #0xe40]       | X8 = 1152921509743371216;               
        // 0x00D86C48: ADD x2, sp, #0xc           | X2 = (1152921514686730512 + 12) = 1152921514686730524 (0x1000000258CED11C);
        // 0x00D86C4C: MOV x1, x22                | X1 = key;//m1                           
        // 0x00D86C50: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Int32>::TryGetValue(System.String key, out System.Int32 value);
        // 0x00D86C54: BL #0x23f6628              | X0 = val_60.TryGetValue(key:  key, value: out  int val_2 = 0);
        bool val_3 = val_60.TryGetValue(key:  key, value: out  val_2);
        // 0x00D86C58: TBZ w0, #0, #0xd872d4      | if (val_3 == false) goto label_71;      
        if(val_3 == false)
        {
            goto label_71;
        }
        // 0x00D86C5C: LDR w8, [sp, #0xc]         | W8 = 0x0;                               
        // 0x00D86C60: ADD w9, w8, #5             | W9 = (val_2 + 5) = 5 (0x00000005);      
        // 0x00D86C64: CMP w8, #0xd               | STATE = COMPARE(0x0, 0xD)               
        // 0x00D86C68: CSEL w8, w9, wzr, lo       | W8 = val_2 < 0xD ? 5 : 0;               
        var val_4 = (val_2 < 13) ? (5) : 0;
        // 0x00D86C6C: SUB w8, w8, #5             | W8 = (val_2 < 0xD ? 5 : 0 - 5);         
        val_4 = val_4 - 5;
        // 0x00D86C70: CMP w8, #0xc               | STATE = COMPARE((val_2 < 0xD ? 5 : 0 - 5), 0xC)
        // 0x00D86C74: B.HI #0xd872d4             | if (val_4 > 0xC) goto label_71;         
        if(val_4 > 12)
        {
            goto label_71;
        }
        // 0x00D86C78: ADRP x9, #0x2a97000        | X9 = 44658688 (0x2A97000);              
        // 0x00D86C7C: ADD x9, x9, #0x228         | X9 = (44658688 + 552) = 44659240 (0x02A97228);
        // 0x00D86C80: LDRSW x8, [x9, x8, lsl #2] | X8 = 44659240 + ((val_2 < 0xD ? 5 : 0 - 5)) << 2;
        var val_31 = 44659240 + ((val_2 < 0xD ? 5 : 0 - 5)) << 2;
        // 0x00D86C84: ADD x8, x8, x9             | X8 = (44659240 + ((val_2 < 0xD ? 5 : 0 - 5)) << 2 + 44659240);
        val_31 = val_31 + 44659240;
        // 0x00D86C88: BR x8                      | goto (44659240 + ((val_2 < 0xD ? 5 : 0 - 5)) << 2 + 44659240);
        goto (44659240 + ((val_2 < 0xD ? 5 : 0 - 5)) << 2 + 44659240);
        // 0x00D86C8C: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86C90: CBZ x22, #0xd86d90         | if (this.plusAtt == null) goto label_8; 
        if(this.plusAtt == null)
        {
            goto label_8;
        }
        // 0x00D86C94: LDP w8, w9, [x22, #0x60]   | W8 = this.plusAtt.ac_attack; //P2  W9 = this.plusAtt._attack; //P2  //  | 
        val_62 = this.plusAtt._attack;
        // 0x00D86C98: SUB w23, w9, w8            | W23 = (this.plusAtt._attack - this.plusAtt.ac_attack);
        val_57 = val_62 - this.plusAtt.ac_attack;
        // 0x00D86C9C: B #0xd86dac                |  goto label_9;                          
        goto label_9;
        // 0x00D86CA0: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86CA4: CBZ x22, #0xd86dcc         | if (this.plusAtt == null) goto label_10;
        if(this.plusAtt == null)
        {
            goto label_10;
        }
        // 0x00D86CA8: LDP w8, w9, [x22, #0x78]   | W8 = this.plusAtt.ac_hp; //P2  W9 = this.plusAtt._hp; //P2  //  | 
        val_63 = this.plusAtt._hp;
        // 0x00D86CAC: SUB w23, w9, w8            | W23 = (this.plusAtt._hp - this.plusAtt.ac_hp);
        val_57 = val_63 - this.plusAtt.ac_hp;
        // 0x00D86CB0: B #0xd86de8                |  goto label_11;                         
        goto label_11;
        // 0x00D86CB4: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86CB8: CBZ x22, #0xd86e08         | if (this.plusAtt == null) goto label_12;
        if(this.plusAtt == null)
        {
            goto label_12;
        }
        // 0x00D86CBC: LDP w8, w9, [x22, #0x68]   | W8 = this.plusAtt.ac_phy_def; //P2  W9 = this.plusAtt._phy_def; //P2  //  | 
        val_64 = this.plusAtt._phy_def;
        // 0x00D86CC0: SUB w23, w9, w8            | W23 = (this.plusAtt._phy_def - this.plusAtt.ac_phy_def);
        val_57 = val_64 - this.plusAtt.ac_phy_def;
        // 0x00D86CC4: B #0xd86e24                |  goto label_13;                         
        goto label_13;
        // 0x00D86CC8: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86CCC: CBZ x22, #0xd86e44         | if (this.plusAtt == null) goto label_14;
        if(this.plusAtt == null)
        {
            goto label_14;
        }
        // 0x00D86CD0: LDP w8, w9, [x22, #0x70]   | W8 = this.plusAtt.ac_mag_def; //P2  W9 = this.plusAtt._mag_def; //P2  //  | 
        val_65 = this.plusAtt._mag_def;
        // 0x00D86CD4: SUB w23, w9, w8            | W23 = (this.plusAtt._mag_def - this.plusAtt.ac_mag_def);
        val_57 = val_65 - this.plusAtt.ac_mag_def;
        // 0x00D86CD8: B #0xd86e60                |  goto label_15;                         
        goto label_15;
        // 0x00D86CDC: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86CE0: CBZ x22, #0xd86e80         | if (this.plusAtt == null) goto label_16;
        if(this.plusAtt == null)
        {
            goto label_16;
        }
        // 0x00D86CE4: LDP w8, w9, [x22, #0x30]   | W8 = this.plusAtt.ac_hitrate_per; //P2  W9 = this.plusAtt._hitrate_per; //P2  //  | 
        val_66 = this.plusAtt._hitrate_per;
        // 0x00D86CE8: SUB w23, w9, w8            | W23 = (this.plusAtt._hitrate_per - this.plusAtt.ac_hitrate_per);
        val_57 = val_66 - this.plusAtt.ac_hitrate_per;
        // 0x00D86CEC: B #0xd86e9c                |  goto label_17;                         
        goto label_17;
        // 0x00D86CF0: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86CF4: CBZ x22, #0xd86ebc         | if (this.plusAtt == null) goto label_18;
        if(this.plusAtt == null)
        {
            goto label_18;
        }
        // 0x00D86CF8: LDP w8, w9, [x22, #0x38]   | W8 = this.plusAtt.ac_dodge_per; //P2  W9 = this.plusAtt._dodge_per; //P2  //  | 
        val_67 = this.plusAtt._dodge_per;
        // 0x00D86CFC: SUB w23, w9, w8            | W23 = (this.plusAtt._dodge_per - this.plusAtt.ac_dodge_per);
        val_57 = val_67 - this.plusAtt.ac_dodge_per;
        // 0x00D86D00: B #0xd86ed8                |  goto label_19;                         
        goto label_19;
        // 0x00D86D04: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86D08: CBZ x22, #0xd86ef8         | if (this.plusAtt == null) goto label_20;
        if(this.plusAtt == null)
        {
            goto label_20;
        }
        // 0x00D86D0C: LDP w8, w9, [x22, #0x40]   | W8 = this.plusAtt.ac_destroy_per; //P2  W9 = this.plusAtt._destroy_per; //P2  //  | 
        val_68 = this.plusAtt._destroy_per;
        // 0x00D86D10: SUB w23, w9, w8            | W23 = (this.plusAtt._destroy_per - this.plusAtt.ac_destroy_per);
        val_57 = val_68 - this.plusAtt.ac_destroy_per;
        // 0x00D86D14: B #0xd86f14                |  goto label_21;                         
        goto label_21;
        // 0x00D86D18: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86D1C: CBZ x22, #0xd86f34         | if (this.plusAtt == null) goto label_22;
        if(this.plusAtt == null)
        {
            goto label_22;
        }
        // 0x00D86D20: LDP w8, w9, [x22, #0x48]   | W8 = this.plusAtt.ac_block_per; //P2  W9 = this.plusAtt._block_per; //P2  //  | 
        val_69 = this.plusAtt._block_per;
        // 0x00D86D24: SUB w23, w9, w8            | W23 = (this.plusAtt._block_per - this.plusAtt.ac_block_per);
        val_57 = val_69 - this.plusAtt.ac_block_per;
        // 0x00D86D28: B #0xd86f50                |  goto label_23;                         
        goto label_23;
        // 0x00D86D2C: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86D30: CBZ x22, #0xd86f70         | if (this.plusAtt == null) goto label_24;
        if(this.plusAtt == null)
        {
            goto label_24;
        }
        // 0x00D86D34: LDP w8, w9, [x22, #0x50]   | W8 = this.plusAtt.ac_crit_per; //P2  W9 = this.plusAtt._crit_per; //P2  //  | 
        val_70 = this.plusAtt._crit_per;
        // 0x00D86D38: SUB w23, w9, w8            | W23 = (this.plusAtt._crit_per - this.plusAtt.ac_crit_per);
        val_57 = val_70 - this.plusAtt.ac_crit_per;
        // 0x00D86D3C: B #0xd86f8c                |  goto label_25;                         
        goto label_25;
        // 0x00D86D40: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86D44: CBZ x22, #0xd86fac         | if (this.plusAtt == null) goto label_26;
        if(this.plusAtt == null)
        {
            goto label_26;
        }
        // 0x00D86D48: LDP w8, w9, [x22, #0x58]   | W8 = this.plusAtt.ac_anticrit_per; //P2  W9 = this.plusAtt._anticrit_per; //P2  //  | 
        val_71 = this.plusAtt._anticrit_per;
        // 0x00D86D4C: SUB w23, w9, w8            | W23 = (this.plusAtt._anticrit_per - this.plusAtt.ac_anticrit_per);
        val_57 = val_71 - this.plusAtt.ac_anticrit_per;
        // 0x00D86D50: B #0xd86fc8                |  goto label_27;                         
        goto label_27;
        // 0x00D86D54: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86D58: CBZ x22, #0xd86fe8         | if (this.plusAtt == null) goto label_28;
        if(this.plusAtt == null)
        {
            goto label_28;
        }
        // 0x00D86D5C: LDP w8, w9, [x22, #0xb0]   | W8 = this.plusAtt.ac_damage_bonus; //P2  W9 = this.plusAtt._damage_bonus; //P2  //  | 
        val_72 = this.plusAtt._damage_bonus;
        // 0x00D86D60: SUB w23, w9, w8            | W23 = (this.plusAtt._damage_bonus - this.plusAtt.ac_damage_bonus);
        val_57 = val_72 - this.plusAtt.ac_damage_bonus;
        // 0x00D86D64: B #0xd87004                |  goto label_29;                         
        goto label_29;
        // 0x00D86D68: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86D6C: CBZ x22, #0xd87024         | if (this.plusAtt == null) goto label_30;
        if(this.plusAtt == null)
        {
            goto label_30;
        }
        // 0x00D86D70: LDP w8, w9, [x22, #0xb8]   | W8 = this.plusAtt.ac_damage_reduce; //P2  W9 = this.plusAtt._damage_reduce; //P2  //  | 
        val_73 = this.plusAtt._damage_reduce;
        // 0x00D86D74: SUB w23, w9, w8            | W23 = (this.plusAtt._damage_reduce - this.plusAtt.ac_damage_reduce);
        val_57 = val_73 - this.plusAtt.ac_damage_reduce;
        // 0x00D86D78: B #0xd87040                |  goto label_31;                         
        goto label_31;
        // 0x00D86D7C: LDR x22, [x21, #0x10]      | X22 = this.plusAtt; //P2                
        // 0x00D86D80: CBZ x22, #0xd87060         | if (this.plusAtt == null) goto label_32;
        if(this.plusAtt == null)
        {
            goto label_32;
        }
        // 0x00D86D84: LDP w8, w9, [x22, #0xc0]   | W8 = this.plusAtt.ac_crit_hurt; //P2  W9 = this.plusAtt._crit_hurt; //P2  //  | 
        val_74 = this.plusAtt._crit_hurt;
        // 0x00D86D88: SUB w23, w9, w8            | W23 = (this.plusAtt._crit_hurt - this.plusAtt.ac_crit_hurt);
        val_57 = val_74 - this.plusAtt.ac_crit_hurt;
        // 0x00D86D8C: B #0xd8707c                |  goto label_33;                         
        goto label_33;
        label_8:
        // 0x00D86D90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86D94: MOVZ w8, #0x64             | W8 = 100 (0x64);//ML01                  
        // 0x00D86D98: ORR w9, wzr, #0x60         | W9 = 96(0x60);                          
        // 0x00D86D9C: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D86DA0: LDR w9, [x9]               | W9 = 0x33644C8;                         
        val_62 = 53888200;
        // 0x00D86DA4: SUB w23, w8, w9            | W23 = (0 - val_62) = val_57 (0xFFFFFFFFFCC9BB38);
        val_57 = -53888200;
        // 0x00D86DA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00D86DAC: ADD w1, w23, w20           | W1 = (val_57 + value);                  
        uint val_5 = val_57 + value;
        // 0x00D86DB0: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86DB4: BL #0xd872fc               | this.plusAtt.set_attack(value:  uint val_5 = val_57 + value);
        this.plusAtt.attack = val_5;
        // 0x00D86DB8: LDR x20, [x21, #0x10]      | X20 = this.plusAtt; //P2                
        // 0x00D86DBC: CBZ x20, #0xd8709c         | if (this.plusAtt == null) goto label_34;
        if(this.plusAtt == null)
        {
            goto label_34;
        }
        // 0x00D86DC0: LDP w8, w9, [x20, #0x10]   | W8 = this.plusAtt.ac_attack_per; //P2  W9 = this.plusAtt._attack_per; //P2  //  | 
        // 0x00D86DC4: SUB w21, w9, w8            | W21 = (this.plusAtt._attack_per - this.plusAtt.ac_attack_per);
        val_59 = this.plusAtt._attack_per - this.plusAtt.ac_attack_per;
        // 0x00D86DC8: B #0xd870b8                |  goto label_35;                         
        goto label_35;
        label_10:
        // 0x00D86DCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86DD0: ORR w8, wzr, #0x7c         | W8 = 124(0x7C);                         
        // 0x00D86DD4: ORR w9, wzr, #0x78         | W9 = 120(0x78);                         
        // 0x00D86DD8: LDR w8, [x8]               | W8 = 0x6;                               
        // 0x00D86DDC: LDR w9, [x9]               | W9 = 0x1;                               
        val_63 = 1;
        // 0x00D86DE0: SUB w23, w8, w9            | W23 = (6 - val_63) = val_57 (0x00000005);
        val_57 = 5;
        // 0x00D86DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_11:
        // 0x00D86DE8: ADD w1, w23, w20           | W1 = (val_57 + value);                  
        uint val_6 = val_57 + value;
        // 0x00D86DEC: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86DF0: BL #0xd87414               | this.plusAtt.set_hp(value:  uint val_6 = val_57 + value);
        this.plusAtt.hp = val_6;
        // 0x00D86DF4: LDR x20, [x21, #0x10]      | X20 = this.plusAtt; //P2                
        // 0x00D86DF8: CBZ x20, #0xd870c8         | if (this.plusAtt == null) goto label_36;
        if(this.plusAtt == null)
        {
            goto label_36;
        }
        // 0x00D86DFC: LDP w8, w9, [x20, #0x28]   | W8 = this.plusAtt.ac_hp_per; //P2  W9 = this.plusAtt._hp_per; //P2  //  | 
        // 0x00D86E00: SUB w21, w9, w8            | W21 = (this.plusAtt._hp_per - this.plusAtt.ac_hp_per);
        val_59 = this.plusAtt._hp_per - this.plusAtt.ac_hp_per;
        // 0x00D86E04: B #0xd870e4                |  goto label_37;                         
        goto label_37;
        label_12:
        // 0x00D86E08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86E0C: MOVZ w8, #0x6c             | W8 = 108 (0x6C);//ML01                  
        // 0x00D86E10: MOVZ w9, #0x68             | W9 = 104 (0x68);//ML01                  
        // 0x00D86E14: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D86E18: LDR w9, [x9]               | W9 = 0x33644C8;                         
        val_64 = 53888200;
        // 0x00D86E1C: SUB w23, w8, w9            | W23 = (0 - val_64) = val_57 (0xFFFFFFFFFCC9BB38);
        val_57 = -53888200;
        // 0x00D86E20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_13:
        // 0x00D86E24: ADD w1, w23, w20           | W1 = (val_57 + value);                  
        uint val_7 = val_57 + value;
        // 0x00D86E28: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86E2C: BL #0xd8752c               | this.plusAtt.set_phy_def(value:  uint val_7 = val_57 + value);
        this.plusAtt.phy_def = val_7;
        // 0x00D86E30: LDR x20, [x21, #0x10]      | X20 = this.plusAtt; //P2                
        // 0x00D86E34: CBZ x20, #0xd870f4         | if (this.plusAtt == null) goto label_38;
        if(this.plusAtt == null)
        {
            goto label_38;
        }
        // 0x00D86E38: LDP w8, w9, [x20, #0x18]   | W8 = this.plusAtt.ac_phy_def_per; //P2  W9 = this.plusAtt._phy_def_per; //P2  //  | 
        // 0x00D86E3C: SUB w21, w9, w8            | W21 = (this.plusAtt._phy_def_per - this.plusAtt.ac_phy_def_per);
        val_59 = this.plusAtt._phy_def_per - this.plusAtt.ac_phy_def_per;
        // 0x00D86E40: B #0xd87110                |  goto label_39;                         
        goto label_39;
        label_14:
        // 0x00D86E44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86E48: MOVZ w8, #0x74             | W8 = 116 (0x74);//ML01                  
        // 0x00D86E4C: ORR w9, wzr, #0x70         | W9 = 112(0x70);                         
        // 0x00D86E50: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D86E54: LDR w9, [x9]               | W9 = 0x10000;                           
        val_65 = 65536;
        // 0x00D86E58: SUB w23, w8, w9            | W23 = (0 - val_65) = val_57 (0xFFFFFFFFFFFF0000);
        val_57 = -65536;
        // 0x00D86E5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_15:
        // 0x00D86E60: ADD w1, w23, w20           | W1 = (val_57 + value);                  
        uint val_8 = val_57 + value;
        // 0x00D86E64: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86E68: BL #0xd87644               | this.plusAtt.set_mag_def(value:  uint val_8 = val_57 + value);
        this.plusAtt.mag_def = val_8;
        // 0x00D86E6C: LDR x20, [x21, #0x10]      | X20 = this.plusAtt; //P2                
        // 0x00D86E70: CBZ x20, #0xd87120         | if (this.plusAtt == null) goto label_40;
        if(this.plusAtt == null)
        {
            goto label_40;
        }
        // 0x00D86E74: LDP w8, w9, [x20, #0x20]   | W8 = this.plusAtt.ac_mag_def_per; //P2  W9 = this.plusAtt._mag_def_per; //P2  //  | 
        // 0x00D86E78: SUB w21, w9, w8            | W21 = (this.plusAtt._mag_def_per - this.plusAtt.ac_mag_def_per);
        val_59 = this.plusAtt._mag_def_per - this.plusAtt.ac_mag_def_per;
        // 0x00D86E7C: B #0xd8713c                |  goto label_41;                         
        goto label_41;
        label_16:
        // 0x00D86E80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86E84: MOVZ w8, #0x34             | W8 = 52 (0x34);//ML01                   
        // 0x00D86E88: ORR w9, wzr, #0x30         | W9 = 48(0x30);                          
        // 0x00D86E8C: LDR w8, [x8]               | W8 = 0x380040;                          
        // 0x00D86E90: LDR w9, [x9]               | W9 = 0x0;                               
        val_66 = 0;
        // 0x00D86E94: SUB w23, w8, w9            | W23 = (3670080 - val_66) = val_57 (0x00380040);
        val_57 = 3670080;
        // 0x00D86E98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_17:
        // 0x00D86E9C: ADD w1, w23, w19           | W1 = (val_57 + valuePer);               
        uint val_9 = val_57 + val_58;
        // 0x00D86EA0: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86EA4: BL #0xd8775c               | this.plusAtt.set_hitrate_per(value:  uint val_9 = val_57 + val_58);
        this.plusAtt.hitrate_per = val_9;
        // 0x00D86EA8: LDR x19, [x21, #0x10]      | X19 = this.plusAtt; //P2                
        val_58 = this.plusAtt;
        // 0x00D86EAC: CBZ x19, #0xd8714c         | if (this.plusAtt == null) goto label_42;
        if(val_58 == null)
        {
            goto label_42;
        }
        // 0x00D86EB0: LDP w8, w9, [x19, #0x80]   | W8 = this.plusAtt.ac_hitrate; //P2  W9 = this.plusAtt._hitrate; //P2  //  | 
        // 0x00D86EB4: SUB w21, w9, w8            | W21 = (this.plusAtt._hitrate - this.plusAtt.ac_hitrate);
        val_59 = this.plusAtt._hitrate - this.plusAtt.ac_hitrate;
        // 0x00D86EB8: B #0xd87168                |  goto label_43;                         
        goto label_43;
        label_18:
        // 0x00D86EBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86EC0: ORR w8, wzr, #0x3c         | W8 = 60(0x3C);                          
        // 0x00D86EC4: ORR w9, wzr, #0x38         | W9 = 56(0x38);                          
        // 0x00D86EC8: LDR w8, [x8]               | W8 = 0x19001A;                          
        // 0x00D86ECC: LDR w9, [x9]               | W9 = 0x400006;                          
        val_67 = 4194310;
        // 0x00D86ED0: SUB w23, w8, w9            | W23 = (1638426 - val_67) = val_57 (0xFFFFFFFFFFD90014);
        val_57 = -2555884;
        // 0x00D86ED4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_19:
        // 0x00D86ED8: ADD w1, w23, w19           | W1 = (val_57 + valuePer);               
        uint val_10 = val_57 + val_58;
        // 0x00D86EDC: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86EE0: BL #0xd87874               | this.plusAtt.set_dodge_per(value:  uint val_10 = val_57 + val_58);
        this.plusAtt.dodge_per = val_10;
        // 0x00D86EE4: LDR x19, [x21, #0x10]      | X19 = this.plusAtt; //P2                
        val_58 = this.plusAtt;
        // 0x00D86EE8: CBZ x19, #0xd87178         | if (this.plusAtt == null) goto label_44;
        if(val_58 == null)
        {
            goto label_44;
        }
        // 0x00D86EEC: LDP w8, w9, [x19, #0x88]   | W8 = this.plusAtt.ac_dodge; //P2  W9 = this.plusAtt._dodge; //P2  //  | 
        // 0x00D86EF0: SUB w21, w9, w8            | W21 = (this.plusAtt._dodge - this.plusAtt.ac_dodge);
        val_59 = this.plusAtt._dodge - this.plusAtt.ac_dodge;
        // 0x00D86EF4: B #0xd87194                |  goto label_45;                         
        goto label_45;
        label_20:
        // 0x00D86EF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86EFC: MOVZ w8, #0x44             | W8 = 68 (0x44);//ML01                   
        // 0x00D86F00: ORR w9, wzr, #0x40         | W9 = 64(0x40);                          
        // 0x00D86F04: LDR w8, [x8]               | W8 = 0x5;                               
        // 0x00D86F08: LDR w9, [x9]               | W9 = 0x1;                               
        val_68 = 1;
        // 0x00D86F0C: SUB w23, w8, w9            | W23 = (5 - val_68) = val_57 (0x00000004);
        val_57 = 4;
        // 0x00D86F10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_21:
        // 0x00D86F14: ADD w1, w23, w19           | W1 = (val_57 + valuePer);               
        uint val_11 = val_57 + val_58;
        // 0x00D86F18: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86F1C: BL #0xd8798c               | this.plusAtt.set_destroy_per(value:  uint val_11 = val_57 + val_58);
        this.plusAtt.destroy_per = val_11;
        // 0x00D86F20: LDR x19, [x21, #0x10]      | X19 = this.plusAtt; //P2                
        val_58 = this.plusAtt;
        // 0x00D86F24: CBZ x19, #0xd871a4         | if (this.plusAtt == null) goto label_46;
        if(val_58 == null)
        {
            goto label_46;
        }
        // 0x00D86F28: LDP w8, w9, [x19, #0x90]   | W8 = this.plusAtt.ac_destroy; //P2  W9 = this.plusAtt._destroy; //P2  //  | 
        // 0x00D86F2C: SUB w21, w9, w8            | W21 = (this.plusAtt._destroy - this.plusAtt.ac_destroy);
        val_59 = this.plusAtt._destroy - this.plusAtt.ac_destroy;
        // 0x00D86F30: B #0xd871c0                |  goto label_47;                         
        goto label_47;
        label_22:
        // 0x00D86F34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86F38: MOVZ w8, #0x4c             | W8 = 76 (0x4C);//ML01                   
        // 0x00D86F3C: MOVZ w9, #0x48             | W9 = 72 (0x48);//ML01                   
        // 0x00D86F40: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D86F44: LDR w9, [x9]               | W9 = 0x0;                               
        val_69 = 0;
        // 0x00D86F48: SUB w23, w8, w9            | W23 = (0 - val_69) = val_57 (0x00000000);
        val_57 = 0;
        // 0x00D86F4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_23:
        // 0x00D86F50: ADD w1, w23, w19           | W1 = (val_57 + valuePer);               
        uint val_12 = val_57 + val_58;
        // 0x00D86F54: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86F58: BL #0xd87aa4               | this.plusAtt.set_block_per(value:  uint val_12 = val_57 + val_58);
        this.plusAtt.block_per = val_12;
        // 0x00D86F5C: LDR x19, [x21, #0x10]      | X19 = this.plusAtt; //P2                
        val_58 = this.plusAtt;
        // 0x00D86F60: CBZ x19, #0xd871d0         | if (this.plusAtt == null) goto label_48;
        if(val_58 == null)
        {
            goto label_48;
        }
        // 0x00D86F64: LDP w8, w9, [x19, #0x98]   | W8 = this.plusAtt.ac_block; //P2  W9 = this.plusAtt._block; //P2  //  | 
        // 0x00D86F68: SUB w21, w9, w8            | W21 = (this.plusAtt._block - this.plusAtt.ac_block);
        val_59 = this.plusAtt._block - this.plusAtt.ac_block;
        // 0x00D86F6C: B #0xd871ec                |  goto label_49;                         
        goto label_49;
        label_24:
        // 0x00D86F70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86F74: MOVZ w8, #0x54             | W8 = 84 (0x54);//ML01                   
        // 0x00D86F78: MOVZ w9, #0x50             | W9 = 80 (0x50);//ML01                   
        // 0x00D86F7C: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D86F80: LDR w9, [x9]               | W9 = 0x0;                               
        val_70 = 0;
        // 0x00D86F84: SUB w23, w8, w9            | W23 = (0 - val_70) = val_57 (0x00000000);
        val_57 = 0;
        // 0x00D86F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_25:
        // 0x00D86F8C: ADD w1, w23, w19           | W1 = (val_57 + valuePer);               
        uint val_13 = val_57 + val_58;
        // 0x00D86F90: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86F94: BL #0xd87bbc               | this.plusAtt.set_crit_per(value:  uint val_13 = val_57 + val_58);
        this.plusAtt.crit_per = val_13;
        // 0x00D86F98: LDR x19, [x21, #0x10]      | X19 = this.plusAtt; //P2                
        val_58 = this.plusAtt;
        // 0x00D86F9C: CBZ x19, #0xd871fc         | if (this.plusAtt == null) goto label_50;
        if(val_58 == null)
        {
            goto label_50;
        }
        // 0x00D86FA0: LDP w8, w9, [x19, #0xa0]   | W8 = this.plusAtt.ac_crit; //P2  W9 = this.plusAtt._crit; //P2  //  | 
        // 0x00D86FA4: SUB w21, w9, w8            | W21 = (this.plusAtt._crit - this.plusAtt.ac_crit);
        val_59 = this.plusAtt._crit - this.plusAtt.ac_crit;
        // 0x00D86FA8: B #0xd87218                |  goto label_51;                         
        goto label_51;
        label_26:
        // 0x00D86FAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86FB0: MOVZ w8, #0x5c             | W8 = 92 (0x5C);//ML01                   
        // 0x00D86FB4: MOVZ w9, #0x58             | W9 = 88 (0x58);//ML01                   
        // 0x00D86FB8: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D86FBC: LDR w9, [x9]               | W9 = 0x0;                               
        val_71 = 0;
        // 0x00D86FC0: SUB w23, w8, w9            | W23 = (0 - val_71) = val_57 (0x00000000);
        val_57 = 0;
        // 0x00D86FC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_27:
        // 0x00D86FC8: ADD w1, w23, w19           | W1 = (val_57 + valuePer);               
        uint val_14 = val_57 + val_58;
        // 0x00D86FCC: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D86FD0: BL #0xd87cd4               | this.plusAtt.set_anticrit_per(value:  uint val_14 = val_57 + val_58);
        this.plusAtt.anticrit_per = val_14;
        // 0x00D86FD4: LDR x19, [x21, #0x10]      | X19 = this.plusAtt; //P2                
        val_58 = this.plusAtt;
        // 0x00D86FD8: CBZ x19, #0xd87228         | if (this.plusAtt == null) goto label_52;
        if(val_58 == null)
        {
            goto label_52;
        }
        // 0x00D86FDC: LDP w8, w9, [x19, #0xa8]   | W8 = this.plusAtt.ac_anticrit; //P2  W9 = this.plusAtt._anticrit; //P2  //  | 
        // 0x00D86FE0: SUB w21, w9, w8            | W21 = (this.plusAtt._anticrit - this.plusAtt.ac_anticrit);
        val_59 = this.plusAtt._anticrit - this.plusAtt.ac_anticrit;
        // 0x00D86FE4: B #0xd87244                |  goto label_53;                         
        goto label_53;
        label_28:
        // 0x00D86FE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D86FEC: MOVZ w8, #0xb4             | W8 = 180 (0xB4);//ML01                  
        // 0x00D86FF0: MOVZ w9, #0xb0             | W9 = 176 (0xB0);//ML01                  
        // 0x00D86FF4: LDR w8, [x8]               | W8 = 0x6;                               
        // 0x00D86FF8: LDR w9, [x9]               | W9 = 0x2;                               
        val_72 = 2;
        // 0x00D86FFC: SUB w23, w8, w9            | W23 = (6 - val_72) = val_57 (0x00000004);
        val_57 = 4;
        // 0x00D87000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_29:
        // 0x00D87004: ADD w1, w23, w20           | W1 = (val_57 + value);                  
        uint val_15 = val_57 + value;
        // 0x00D87008: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D8700C: BL #0xd87dec               | this.plusAtt.set_damage_bonus(value:  uint val_15 = val_57 + value);
        this.plusAtt.damage_bonus = val_15;
        // 0x00D87010: LDR x20, [x21, #0x10]      | X20 = this.plusAtt; //P2                
        // 0x00D87014: CBZ x20, #0xd87254         | if (this.plusAtt == null) goto label_54;
        if(this.plusAtt == null)
        {
            goto label_54;
        }
        // 0x00D87018: LDP w8, w9, [x20, #0xb0]   | W8 = this.plusAtt.ac_damage_bonus; //P2  W9 = this.plusAtt._damage_bonus; //P2  //  | 
        // 0x00D8701C: SUB w21, w9, w8            | W21 = (this.plusAtt._damage_bonus - this.plusAtt.ac_damage_bonus);
        val_59 = this.plusAtt._damage_bonus - this.plusAtt.ac_damage_bonus;
        // 0x00D87020: B #0xd87270                |  goto label_55;                         
        goto label_55;
        label_30:
        // 0x00D87024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D87028: MOVZ w8, #0xbc             | W8 = 188 (0xBC);//ML01                  
        // 0x00D8702C: MOVZ w9, #0xb8             | W9 = 184 (0xB8);//ML01                  
        // 0x00D87030: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D87034: LDR w9, [x9]               | W9 = 0x35A78C0;                         
        val_73 = 56260800;
        // 0x00D87038: SUB w23, w8, w9            | W23 = (0 - val_73) = val_57 (0xFFFFFFFFFCA58740);
        val_57 = -56260800;
        // 0x00D8703C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_31:
        // 0x00D87040: ADD w1, w23, w20           | W1 = (val_57 + value);                  
        uint val_16 = val_57 + value;
        // 0x00D87044: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D87048: BL #0xd87e78               | this.plusAtt.set_damage_reduce(value:  uint val_16 = val_57 + value);
        this.plusAtt.damage_reduce = val_16;
        // 0x00D8704C: LDR x20, [x21, #0x10]      | X20 = this.plusAtt; //P2                
        // 0x00D87050: CBZ x20, #0xd87280         | if (this.plusAtt == null) goto label_56;
        if(this.plusAtt == null)
        {
            goto label_56;
        }
        // 0x00D87054: LDP w8, w9, [x20, #0xb8]   | W8 = this.plusAtt.ac_damage_reduce; //P2  W9 = this.plusAtt._damage_reduce; //P2  //  | 
        // 0x00D87058: SUB w21, w9, w8            | W21 = (this.plusAtt._damage_reduce - this.plusAtt.ac_damage_reduce);
        val_59 = this.plusAtt._damage_reduce - this.plusAtt.ac_damage_reduce;
        // 0x00D8705C: B #0xd8729c                |  goto label_57;                         
        goto label_57;
        label_32:
        // 0x00D87060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00D87064: MOVZ w8, #0xc4             | W8 = 196 (0xC4);//ML01                  
        // 0x00D87068: ORR w9, wzr, #0xc0         | W9 = 192(0xC0);                         
        // 0x00D8706C: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D87070: LDR w9, [x9]               | W9 = 0x35B78C0;                         
        val_74 = 56326336;
        // 0x00D87074: SUB w23, w8, w9            | W23 = (0 - val_74) = val_57 (0xFFFFFFFFFCA48740);
        val_57 = -56326336;
        // 0x00D87078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_33:
        // 0x00D8707C: ADD w1, w23, w20           | W1 = (val_57 + value);                  
        uint val_17 = val_57 + value;
        // 0x00D87080: MOV x0, x22                | X0 = this.plusAtt;//m1                  
        // 0x00D87084: BL #0xd87f04               | this.plusAtt.set_crit_hurt(value:  uint val_17 = val_57 + value);
        this.plusAtt.crit_hurt = val_17;
        // 0x00D87088: LDR x20, [x21, #0x10]      | X20 = this.plusAtt; //P2                
        // 0x00D8708C: CBZ x20, #0xd872ac         | if (this.plusAtt == null) goto label_58;
        if(this.plusAtt == null)
        {
            goto label_58;
        }
        // 0x00D87090: LDP w8, w9, [x20, #0xc0]   | W8 = this.plusAtt.ac_crit_hurt; //P2  W9 = this.plusAtt._crit_hurt; //P2  //  | 
        // 0x00D87094: SUB w21, w9, w8            | W21 = (this.plusAtt._crit_hurt - this.plusAtt.ac_crit_hurt);
        val_59 = this.plusAtt._crit_hurt - this.plusAtt.ac_crit_hurt;
        // 0x00D87098: B #0xd872c8                |  goto label_59;                         
        goto label_59;
        label_34:
        // 0x00D8709C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D870A0: MOVZ w8, #0x14             | W8 = 20 (0x14);//ML01                   
        // 0x00D870A4: ORR w9, wzr, #0x10         | W9 = 16(0x10);                          
        // 0x00D870A8: LDR w8, [x8]               | W8 = 0x1;                               
        // 0x00D870AC: LDR w9, [x9]               | W9 = 0xB70003;                          
        // 0x00D870B0: SUB w21, w8, w9            | W21 = (1 - 11993091) = val_59 (0xFFFFFFFFFF48FFFE);
        val_59 = -11993090;
        // 0x00D870B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_35:
        // 0x00D870B8: ADD w1, w21, w19           | W1 = (val_59 + valuePer);               
        uint val_18 = val_59 + val_58;
        // 0x00D870BC: MOV x0, x20                | X0 = this.plusAtt;//m1                  
        // 0x00D870C0: BL #0xd87388               | this.plusAtt.set_attack_per(value:  uint val_18 = val_59 + val_58);
        this.plusAtt.attack_per = val_18;
        // 0x00D870C4: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_36:
        // 0x00D870C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D870CC: MOVZ w8, #0x2c             | W8 = 44 (0x2C);//ML01                   
        // 0x00D870D0: MOVZ w9, #0x28             | W9 = 40 (0x28);//ML01                   
        // 0x00D870D4: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D870D8: LDR w9, [x9]               | W9 = 0x3723290;                         
        // 0x00D870DC: SUB w21, w8, w9            | W21 = (0 - 57815696) = val_59 (0xFFFFFFFFFC8DCD70);
        val_59 = -57815696;
        // 0x00D870E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_37:
        // 0x00D870E4: ADD w1, w21, w19           | W1 = (val_59 + valuePer);               
        uint val_19 = val_59 + val_58;
        // 0x00D870E8: MOV x0, x20                | X0 = this.plusAtt;//m1                  
        // 0x00D870EC: BL #0xd874a0               | this.plusAtt.set_hp_per(value:  uint val_19 = val_59 + val_58);
        this.plusAtt.hp_per = val_19;
        // 0x00D870F0: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_38:
        // 0x00D870F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D870F8: ORR w8, wzr, #0x1c         | W8 = 28(0x1C);                          
        // 0x00D870FC: ORR w9, wzr, #0x18         | W9 = 24(0x18);                          
        // 0x00D87100: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D87104: LDR w9, [x9]               | W9 = 0x9814C0;                          
        // 0x00D87108: SUB w21, w8, w9            | W21 = (0 - 9966784) = val_59 (0xFFFFFFFFFF67EB40);
        val_59 = -9966784;
        // 0x00D8710C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_39:
        // 0x00D87110: ADD w1, w21, w19           | W1 = (val_59 + valuePer);               
        uint val_20 = val_59 + val_58;
        // 0x00D87114: MOV x0, x20                | X0 = this.plusAtt;//m1                  
        // 0x00D87118: BL #0xd875b8               | this.plusAtt.set_phy_def_per(value:  uint val_20 = val_59 + val_58);
        this.plusAtt.phy_def_per = val_20;
        // 0x00D8711C: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_40:
        // 0x00D87120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D87124: MOVZ w8, #0x24             | W8 = 36 (0x24);//ML01                   
        // 0x00D87128: ORR w9, wzr, #0x20         | W9 = 32(0x20);                          
        // 0x00D8712C: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D87130: LDR w9, [x9]               | W9 = 0x40;                              
        // 0x00D87134: SUB w21, w8, w9            | W21 = (0 - 64) = val_59 (0xFFFFFFFFFFFFFFC0);
        val_59 = -64;
        // 0x00D87138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_41:
        // 0x00D8713C: ADD w1, w21, w19           | W1 = (val_59 + valuePer);               
        uint val_21 = val_59 + val_58;
        // 0x00D87140: MOV x0, x20                | X0 = this.plusAtt;//m1                  
        // 0x00D87144: BL #0xd876d0               | this.plusAtt.set_mag_def_per(value:  uint val_21 = val_59 + val_58);
        this.plusAtt.mag_def_per = val_21;
        // 0x00D87148: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_42:
        // 0x00D8714C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D87150: MOVZ w8, #0x84             | W8 = 132 (0x84);//ML01                  
        // 0x00D87154: ORR w9, wzr, #0x80         | W9 = 128(0x80);                         
        // 0x00D87158: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D8715C: LDR w9, [x9]               | W9 = 0x33644C8;                         
        // 0x00D87160: SUB w21, w8, w9            | W21 = (0 - 53888200) = val_59 (0xFFFFFFFFFCC9BB38);
        val_59 = -53888200;
        // 0x00D87164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_43:
        // 0x00D87168: ADD w1, w21, w20           | W1 = (val_59 + value);                  
        uint val_22 = val_59 + value;
        // 0x00D8716C: MOV x0, x19                | X0 = this.plusAtt;//m1                  
        // 0x00D87170: BL #0xd877e8               | this.plusAtt.set_hitrate(value:  uint val_22 = val_59 + value);
        val_58.hitrate = val_22;
        // 0x00D87174: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_44:
        // 0x00D87178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D8717C: MOVZ w8, #0x8c             | W8 = 140 (0x8C);//ML01                  
        // 0x00D87180: MOVZ w9, #0x88             | W9 = 136 (0x88);//ML01                  
        // 0x00D87184: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D87188: LDR w9, [x9]               | W9 = 0x33744C8;                         
        // 0x00D8718C: SUB w21, w8, w9            | W21 = (0 - 53953736) = val_59 (0xFFFFFFFFFCC8BB38);
        val_59 = -53953736;
        // 0x00D87190: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_45:
        // 0x00D87194: ADD w1, w21, w20           | W1 = (val_59 + value);                  
        uint val_23 = val_59 + value;
        // 0x00D87198: MOV x0, x19                | X0 = this.plusAtt;//m1                  
        // 0x00D8719C: BL #0xd87900               | this.plusAtt.set_dodge(value:  uint val_23 = val_59 + value);
        val_58.dodge = val_23;
        // 0x00D871A0: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_46:
        // 0x00D871A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D871A8: MOVZ w8, #0x94             | W8 = 148 (0x94);//ML01                  
        // 0x00D871AC: MOVZ w9, #0x90             | W9 = 144 (0x90);//ML01                  
        // 0x00D871B0: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D871B4: LDR w9, [x9]               | W9 = 0x33744C8;                         
        // 0x00D871B8: SUB w21, w8, w9            | W21 = (0 - 53953736) = val_59 (0xFFFFFFFFFCC8BB38);
        val_59 = -53953736;
        // 0x00D871BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_47:
        // 0x00D871C0: ADD w1, w21, w20           | W1 = (val_59 + value);                  
        uint val_24 = val_59 + value;
        // 0x00D871C4: MOV x0, x19                | X0 = this.plusAtt;//m1                  
        // 0x00D871C8: BL #0xd87a18               | this.plusAtt.set_destroy(value:  uint val_24 = val_59 + value);
        val_58.destroy = val_24;
        // 0x00D871CC: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_48:
        // 0x00D871D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D871D4: MOVZ w8, #0x9c             | W8 = 156 (0x9C);//ML01                  
        // 0x00D871D8: MOVZ w9, #0x98             | W9 = 152 (0x98);//ML01                  
        // 0x00D871DC: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D871E0: LDR w9, [x9]               | W9 = 0x3BEC50;                          
        // 0x00D871E4: SUB w21, w8, w9            | W21 = (0 - 3927120) = val_59 (0xFFFFFFFFFFC413B0);
        val_59 = -3927120;
        // 0x00D871E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_49:
        // 0x00D871EC: ADD w1, w21, w20           | W1 = (val_59 + value);                  
        uint val_25 = val_59 + value;
        // 0x00D871F0: MOV x0, x19                | X0 = this.plusAtt;//m1                  
        // 0x00D871F4: BL #0xd87b30               | this.plusAtt.set_block(value:  uint val_25 = val_59 + value);
        val_58.block = val_25;
        // 0x00D871F8: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_50:
        // 0x00D871FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D87200: MOVZ w8, #0xa4             | W8 = 164 (0xA4);//ML01                  
        // 0x00D87204: MOVZ w9, #0xa0             | W9 = 160 (0xA0);//ML01                  
        // 0x00D87208: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D8720C: LDR w9, [x9]               | W9 = 0x4CA558;                          
        // 0x00D87210: SUB w21, w8, w9            | W21 = (0 - 5023064) = val_59 (0xFFFFFFFFFFB35AA8);
        val_59 = -5023064;
        // 0x00D87214: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_51:
        // 0x00D87218: ADD w1, w21, w20           | W1 = (val_59 + value);                  
        uint val_26 = val_59 + value;
        // 0x00D8721C: MOV x0, x19                | X0 = this.plusAtt;//m1                  
        // 0x00D87220: BL #0xd87c48               | this.plusAtt.set_crit(value:  uint val_26 = val_59 + value);
        val_58.crit = val_26;
        // 0x00D87224: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_52:
        // 0x00D87228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D8722C: MOVZ w8, #0xac             | W8 = 172 (0xAC);//ML01                  
        // 0x00D87230: MOVZ w9, #0xa8             | W9 = 168 (0xA8);//ML01                  
        // 0x00D87234: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D87238: LDR w9, [x9]               | W9 = 0x10000;                           
        // 0x00D8723C: SUB w21, w8, w9            | W21 = (0 - 65536) = val_59 (0xFFFFFFFFFFFF0000);
        val_59 = -65536;
        // 0x00D87240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_53:
        // 0x00D87244: ADD w1, w21, w20           | W1 = (val_59 + value);                  
        uint val_27 = val_59 + value;
        // 0x00D87248: MOV x0, x19                | X0 = this.plusAtt;//m1                  
        // 0x00D8724C: BL #0xd87d60               | this.plusAtt.set_anticrit(value:  uint val_27 = val_59 + value);
        val_58.anticrit = val_27;
        // 0x00D87250: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_54:
        // 0x00D87254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D87258: MOVZ w8, #0xb4             | W8 = 180 (0xB4);//ML01                  
        // 0x00D8725C: MOVZ w9, #0xb0             | W9 = 176 (0xB0);//ML01                  
        // 0x00D87260: LDR w8, [x8]               | W8 = 0x6;                               
        // 0x00D87264: LDR w9, [x9]               | W9 = 0x2;                               
        // 0x00D87268: SUB w21, w8, w9            | W21 = (6 - 2) = val_59 (0x00000004);    
        val_59 = 4;
        // 0x00D8726C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_55:
        // 0x00D87270: ADD w1, w21, w19           | W1 = (val_59 + valuePer);               
        uint val_28 = val_59 + val_58;
        // 0x00D87274: MOV x0, x20                | X0 = this.plusAtt;//m1                  
        // 0x00D87278: BL #0xd87dec               | this.plusAtt.set_damage_bonus(value:  uint val_28 = val_59 + val_58);
        this.plusAtt.damage_bonus = val_28;
        // 0x00D8727C: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_56:
        // 0x00D87280: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D87284: MOVZ w8, #0xbc             | W8 = 188 (0xBC);//ML01                  
        // 0x00D87288: MOVZ w9, #0xb8             | W9 = 184 (0xB8);//ML01                  
        // 0x00D8728C: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D87290: LDR w9, [x9]               | W9 = 0x35A78C0;                         
        // 0x00D87294: SUB w21, w8, w9            | W21 = (0 - 56260800) = val_59 (0xFFFFFFFFFCA58740);
        val_59 = -56260800;
        // 0x00D87298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_57:
        // 0x00D8729C: ADD w1, w21, w19           | W1 = (val_59 + valuePer);               
        uint val_29 = val_59 + val_58;
        // 0x00D872A0: MOV x0, x20                | X0 = this.plusAtt;//m1                  
        // 0x00D872A4: BL #0xd87e78               | this.plusAtt.set_damage_reduce(value:  uint val_29 = val_59 + val_58);
        this.plusAtt.damage_reduce = val_29;
        // 0x00D872A8: B #0xd872d4                |  goto label_71;                         
        goto label_71;
        label_58:
        // 0x00D872AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        // 0x00D872B0: MOVZ w8, #0xc4             | W8 = 196 (0xC4);//ML01                  
        // 0x00D872B4: ORR w9, wzr, #0xc0         | W9 = 192(0xC0);                         
        // 0x00D872B8: LDR w8, [x8]               | W8 = 0x0;                               
        // 0x00D872BC: LDR w9, [x9]               | W9 = 0x35B78C0;                         
        // 0x00D872C0: SUB w21, w8, w9            | W21 = (0 - 56326336) = val_59 (0xFFFFFFFFFCA48740);
        val_59 = -56326336;
        // 0x00D872C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.plusAtt, ????);
        label_59:
        // 0x00D872C8: ADD w1, w21, w19           | W1 = (val_59 + valuePer);               
        uint val_30 = val_59 + val_58;
        // 0x00D872CC: MOV x0, x20                | X0 = this.plusAtt;//m1                  
        // 0x00D872D0: BL #0xd87f04               | this.plusAtt.set_crit_hurt(value:  uint val_30 = val_59 + val_58);
        this.plusAtt.crit_hurt = val_30;
        label_71:
        // 0x00D872D4: SUB sp, x29, #0x40         | SP = (1152921514686730592 - 64) = 1152921514686730528 (0x1000000258CED120);
        // 0x00D872D8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00D872DC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00D872E0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00D872E4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00D872E8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00D872EC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D87F84 (14188420), len: 2444  VirtAddr: 0x00D87F84 RVA: 0x00D87F84 token: 100691639 methodIndex: 26006 delegateWrapperIndex: 0 methodInvoker: 0
    private uint GetAttribute(HERO_ATT_KEY key, float basicsAtt)
    {
        //
        // Disasemble & Code
        //  | 
        var val_46;
        //  | 
        var val_47;
        //  | 
        bool val_48;
        //  | 
        var val_49;
        //  | 
        float val_50;
        //  | 
        var val_51;
        //  | 
        var val_52;
        //  | 
        var val_53;
        //  | 
        var val_54;
        //  | 
        var val_55;
        //  | 
        var val_56;
        //  | 
        var val_57;
        //  | 
        var val_58;
        //  | 
        var val_59;
        //  | 
        var val_60;
        //  | 
        var val_61;
        //  | 
        var val_62;
        //  | 
        var val_63;
        //  | 
        var val_64;
        //  | 
        var val_65;
        // 0x00D87F84: STP d11, d10, [sp, #-0x50]! | stack[1152921514687047472] = ???;  stack[1152921514687047480] = ???;  //  dest_result_addr=1152921514687047472 |  dest_result_addr=1152921514687047480
        // 0x00D87F88: STP d9, d8, [sp, #0x10]    | stack[1152921514687047488] = ???;  stack[1152921514687047496] = ???;  //  dest_result_addr=1152921514687047488 |  dest_result_addr=1152921514687047496
        // 0x00D87F8C: STP x22, x21, [sp, #0x20]  | stack[1152921514687047504] = ???;  stack[1152921514687047512] = ???;  //  dest_result_addr=1152921514687047504 |  dest_result_addr=1152921514687047512
        // 0x00D87F90: STP x20, x19, [sp, #0x30]  | stack[1152921514687047520] = ???;  stack[1152921514687047528] = ???;  //  dest_result_addr=1152921514687047520 |  dest_result_addr=1152921514687047528
        // 0x00D87F94: STP x29, x30, [sp, #0x40]  | stack[1152921514687047536] = ???;  stack[1152921514687047544] = ???;  //  dest_result_addr=1152921514687047536 |  dest_result_addr=1152921514687047544
        // 0x00D87F98: ADD x29, sp, #0x40         | X29 = (1152921514687047472 + 64) = 1152921514687047536 (0x1000000258D3A770);
        // 0x00D87F9C: SUB sp, sp, #0x10          | SP = (1152921514687047472 - 16) = 1152921514687047456 (0x1000000258D3A720);
        // 0x00D87FA0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D87FA4: LDRB w8, [x21, #0x444]     | W8 = (bool)static_value_03734444;       
        // 0x00D87FA8: MOV v8.16b, v0.16b         | V8 = basicsAtt;//m1                     
        // 0x00D87FAC: MOV w20, w1                | W20 = key;//m1                          
        // 0x00D87FB0: MOV x19, x0                | X19 = 1152921514687059552 (0x1000000258D3D660);//ML01
        val_47 = this;
        // 0x00D87FB4: TBNZ w8, #0, #0xd87fd0     | if (static_value_03734444 == true) goto label_0;
        // 0x00D87FB8: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
        // 0x00D87FBC: LDR x8, [x8, #0xd18]       | X8 = 0x2B91760;                         
        // 0x00D87FC0: LDR w0, [x8]               | W0 = 0x1C9D;                            
        // 0x00D87FC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C9D, ????);     
        // 0x00D87FC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D87FCC: STRB w8, [x21, #0x444]     | static_value_03734444 = true;            //  dest_result_addr=57885764
        label_0:
        // 0x00D87FD0: ADD w8, w20, #3            | W8 = (key + 3);                         
        HERO_ATT_KEY val_1 = key + 3;
        // 0x00D87FD4: CMP w20, #0x19             | STATE = COMPARE(key, 0x19)              
        // 0x00D87FD8: CSEL w8, w8, wzr, lo       | W8 = key < 0x19 ? (key + 3) : 0;        
        var val_2 = (key < 25) ? (val_1) : 0;
        // 0x00D87FDC: SUB w8, w8, #3             | W8 = (key < 0x19 ? (key + 3) : 0 - 3);  
        val_2 = val_2 - 3;
        // 0x00D87FE0: CMP w8, #0x18              | STATE = COMPARE((key < 0x19 ? (key + 3) : 0 - 3), 0x18)
        // 0x00D87FE4: B.HI #0xd8802c             | if (val_2 > 0x18) goto label_1;         
        if(val_2 > 24)
        {
            goto label_1;
        }
        // 0x00D87FE8: ADRP x9, #0x2a97000        | X9 = 44658688 (0x2A97000);              
        // 0x00D87FEC: ADD x9, x9, #0x25c         | X9 = (44658688 + 604) = 44659292 (0x02A9725C);
        // 0x00D87FF0: LDRSW x8, [x9, x8, lsl #2] | X8 = 44659292 + ((key < 0x19 ? (key + 3) : 0 - 3)) << 2;
        var val_45 = 44659292 + ((key < 0x19 ? (key + 3) : 0 - 3)) << 2;
        // 0x00D87FF4: ADD x8, x8, x9             | X8 = (44659292 + ((key < 0x19 ? (key + 3) : 0 - 3)) << 2 + 44659292);
        val_45 = val_45 + 44659292;
        // 0x00D87FF8: BR x8                      | goto (44659292 + ((key < 0x19 ? (key + 3) : 0 - 3)) << 2 + 44659292);
        goto (44659292 + ((key < 0x19 ? (key + 3) : 0 - 3)) << 2 + 44659292);
        // 0x00D87FFC: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D88000: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D88004: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D88008: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D8800C: TBZ w8, #0, #0xd8801c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00D88010: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D88014: CBNZ w8, #0xd8801c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00D88018: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_3:
        // 0x00D8801C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88020: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88024: MOV v0.16b, v8.16b         | V0 = basicsAtt;//m1                     
        // 0x00D88028: B #0xd888f4                |  goto label_4;                          
        goto label_4;
        label_1:
        // 0x00D8802C: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00D88030: LDR x8, [x8, #0xbc8]       | X8 = 1152921504894013440;               
        // 0x00D88034: ADD x1, sp, #0xc           | X1 = (1152921514687047456 + 12) = 1152921514687047468 (0x1000000258D3A72C);
        // 0x00D88038: STR w20, [sp, #0xc]        | stack[1152921514687047468] = key;        //  dest_result_addr=1152921514687047468
        // 0x00D8803C: LDR x0, [x8]               | X0 = typeof(HERO_ATT_KEY);              
        // 0x00D88040: BL #0x27bc028              | X0 = 1152921514687095648 = (Il2CppObject*)Box((RuntimeClass*)typeof(HERO_ATT_KEY), key);
        // 0x00D88044: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00D88048: LDR x8, [x8, #0x40]        | X8 = (string**)(1152921514686949392)("enmu(HERO_ATT_KEY)没有类型{0}的对应值.......");
        // 0x00D8804C: MOV x2, x0                 | X2 = 1152921514687095648 (0x1000000258D46360);//ML01
        // 0x00D88050: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88054: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D88058: LDR x1, [x8]               | X1 = "enmu(HERO_ATT_KEY)没有类型{0}的对应值.......";
        // 0x00D8805C: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "enmu(HERO_ATT_KEY)没有类型{0}的对应值.......");
        string val_3 = EString.EFormat(format:  0, arg0:  "enmu(HERO_ATT_KEY)没有类型{0}的对应值.......");
        // 0x00D88060: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D88064: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D88068: MOV x19, x0                | X19 = val_3;//m1                        
        val_48 = val_3;
        // 0x00D8806C: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00D88070: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D88074: TBZ w9, #0, #0xd88088      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00D88078: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D8807C: CBNZ w9, #0xd88088         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00D88080: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00D88084: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_6:
        // 0x00D88088: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8808C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D88090: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D88094: MOV x1, x19                | X1 = val_3;//m1                         
        // 0x00D88098: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_48);
        EDebug.Log(message:  0, isShowStack:  val_48);
        // 0x00D8809C: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_49 = 0;
        // 0x00D880A0: B #0xd88850                |  goto label_7;                          
        goto label_7;
        // 0x00D880A4: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D880A8: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D880AC: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D880B0: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D880B4: TBZ w8, #0, #0xd880c4      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00D880B8: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D880BC: CBNZ w8, #0xd880c4         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00D880C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_9:
        // 0x00D880C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D880C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D880CC: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_4 = ZMG.CombatValueMgr;
        // 0x00D880D0: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00D880D4: CBNZ x20, #0xd880dc        | if (val_4 != null) goto label_10;       
        if(val_4 != null)
        {
            goto label_10;
        }
        // 0x00D880D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_10:
        // 0x00D880DC: LDR s9, [x20, #0x18]       | S9 = val_4.value03; //P2                
        // 0x00D880E0: LDR x20, [x19, #0x10]      | X20 = val_3.length; //P2                
        // 0x00D880E4: CBNZ x20, #0xd880ec        | if (val_3.length != 0) goto label_11;   
        if(val_3.length != 0)
        {
            goto label_11;
        }
        // 0x00D880E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_11:
        // 0x00D880EC: LDP w21, w22, [x20, #0x10] | W21 = val_3.length + 16; W22 = val_3.length + 16 + 4; //  | 
        val_46 = mem[val_3.length + 16];
        val_46 = val_3.length + 16;
        // 0x00D880F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D880F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D880F8: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_5 = ZMG.CombatValueMgr;
        // 0x00D880FC: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00D88100: CBNZ x20, #0xd88108        | if (val_5 != null) goto label_12;       
        if(val_5 != null)
        {
            goto label_12;
        }
        // 0x00D88104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_12:
        // 0x00D88108: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D8810C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D88110: LDR s10, [x20, #0x10]      | S10 = val_5.value01; //P2               
        val_50 = val_5.value01;
        // 0x00D88114: SUB w20, w22, w21          | W20 = (val_3.length + 16 + 4 - val_3.length + 16);
        var val_6 = (val_3.length + 16 + 4) - val_46;
        // 0x00D88118: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D8811C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D88120: TBZ w8, #0, #0xd88130      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00D88124: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D88128: CBNZ w8, #0xd88130         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00D8812C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_14:
        // 0x00D88130: UCVTF d0, w20              | D0 = (double)((val_3.length + 16 + 4 - val_3.length + 16));
        // 0x00D88134: FCVT s0, d0                | S0 = (float)(val_3.length + 16 + 4 - val_3.length + 16));
        float val_46 = (float)(double)val_6;
        // 0x00D88138: FMUL s0, s0, s10           | S0 = ((val_3.length + 16 + 4 - val_3.length + 16) * val_5.value01);
        val_46 = val_46 * val_50;
        // 0x00D8813C: FADD s0, s9, s0            | S0 = (val_4.value03 + ((val_3.length + 16 + 4 - val_3.length + 16) * val_5.value01));
        val_46 = val_4.value03 + val_46;
        // 0x00D88140: FMUL s0, s0, s8            | S0 = ((val_4.value03 + ((val_3.length + 16 + 4 - val_3.length + 16) * val_5.value01)) * basicsAtt);
        val_46 = val_46 * basicsAtt;
        // 0x00D88144: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8814C: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_6 = (float)(double)val_6 * basicsAtt);
        int val_7 = UnityEngine.Mathf.FloorToInt(f:  val_46);
        // 0x00D88150: LDR x20, [x19, #0x10]      | X20 = val_3.length; //P2                
        // 0x00D88154: MOV w19, w0                | W19 = val_7;//m1                        
        val_48 = val_7;
        // 0x00D88158: CBNZ x20, #0xd88160        | if (val_3.length != 0) goto label_15;   
        if(val_3.length != 0)
        {
            goto label_15;
        }
        // 0x00D8815C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_15:
        // 0x00D88160: LDP w9, w8, [x20, #0x60]   | W9 = val_3.length + 96; W8 = val_3.length + 96 + 4; //  | 
        val_53 = mem[val_3.length + 96];
        val_53 = val_3.length + 96;
        val_52 = mem[val_3.length + 96 + 4];
        val_52 = val_3.length + 96 + 4;
        // 0x00D88164: B #0xd88848                |  goto label_88;                         
        goto label_88;
        // 0x00D88168: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D8816C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D88170: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D88174: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D88178: TBZ w8, #0, #0xd88188      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00D8817C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D88180: CBNZ w8, #0xd88188         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00D88184: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_18:
        // 0x00D88188: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8818C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88190: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_8 = ZMG.CombatValueMgr;
        // 0x00D88194: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00D88198: CBNZ x20, #0xd881a0        | if (val_8 != null) goto label_19;       
        if(val_8 != null)
        {
            goto label_19;
        }
        // 0x00D8819C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_19:
        // 0x00D881A0: LDR s9, [x20, #0x18]       | S9 = val_8.value03; //P2                
        // 0x00D881A4: LDR x20, [x19, #0x10]      | X20 = val_7 + 16;                       
        // 0x00D881A8: CBNZ x20, #0xd881b0        | if (val_7 + 16 != 0) goto label_20;     
        if((val_7 + 16) != 0)
        {
            goto label_20;
        }
        // 0x00D881AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_20:
        // 0x00D881B0: LDP w21, w22, [x20, #0x18] | W21 = val_7 + 16 + 24; W22 = val_7 + 16 + 24 + 4; //  | 
        val_46 = mem[val_7 + 16 + 24];
        val_46 = val_7 + 16 + 24;
        // 0x00D881B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D881B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D881BC: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_9 = ZMG.CombatValueMgr;
        // 0x00D881C0: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00D881C4: CBNZ x20, #0xd881cc        | if (val_9 != null) goto label_21;       
        if(val_9 != null)
        {
            goto label_21;
        }
        // 0x00D881C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_21:
        // 0x00D881CC: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D881D0: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D881D4: LDR s10, [x20, #0x10]      | S10 = val_9.value01; //P2               
        val_50 = val_9.value01;
        // 0x00D881D8: SUB w20, w22, w21          | W20 = (val_7 + 16 + 24 + 4 - val_7 + 16 + 24);
        var val_10 = (val_7 + 16 + 24 + 4) - val_46;
        // 0x00D881DC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D881E0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D881E4: TBZ w8, #0, #0xd881f4      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_23;
        // 0x00D881E8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D881EC: CBNZ w8, #0xd881f4         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
        // 0x00D881F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_23:
        // 0x00D881F4: UCVTF d0, w20              | D0 = (double)((val_7 + 16 + 24 + 4 - val_7 + 16 + 24));
        // 0x00D881F8: FCVT s0, d0                | S0 = (float)(val_7 + 16 + 24 + 4 - val_7 + 16 + 24));
        float val_47 = (float)(double)val_10;
        // 0x00D881FC: FMUL s0, s0, s10           | S0 = ((val_7 + 16 + 24 + 4 - val_7 + 16 + 24) * val_9.value01);
        val_47 = val_47 * val_50;
        // 0x00D88200: FADD s0, s9, s0            | S0 = (val_8.value03 + ((val_7 + 16 + 24 + 4 - val_7 + 16 + 24) * val_9.value01));
        val_47 = val_8.value03 + val_47;
        // 0x00D88204: FMUL s0, s0, s8            | S0 = ((val_8.value03 + ((val_7 + 16 + 24 + 4 - val_7 + 16 + 24) * val_9.value01)) * basicsAtt);
        val_47 = val_47 * basicsAtt;
        // 0x00D88208: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8820C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88210: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_10 = (float)(double)val_10 * basicsAtt);
        int val_11 = UnityEngine.Mathf.FloorToInt(f:  val_47);
        // 0x00D88214: LDR x20, [x19, #0x10]      | X20 = val_7 + 16;                       
        // 0x00D88218: MOV w19, w0                | W19 = val_11;//m1                       
        val_48 = val_11;
        // 0x00D8821C: CBNZ x20, #0xd88224        | if (val_7 + 16 != 0) goto label_24;     
        if((val_7 + 16) != 0)
        {
            goto label_24;
        }
        // 0x00D88220: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_24:
        // 0x00D88224: LDP w9, w8, [x20, #0x68]   | W9 = val_7 + 16 + 104; W8 = val_7 + 16 + 104 + 4; //  | 
        val_53 = mem[val_7 + 16 + 104];
        val_53 = val_7 + 16 + 104;
        val_52 = mem[val_7 + 16 + 104 + 4];
        val_52 = val_7 + 16 + 104 + 4;
        // 0x00D88228: B #0xd88848                |  goto label_88;                         
        goto label_88;
        // 0x00D8822C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D88230: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D88234: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D88238: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D8823C: TBZ w8, #0, #0xd8824c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x00D88240: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D88244: CBNZ w8, #0xd8824c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x00D88248: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_27:
        // 0x00D8824C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88250: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88254: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_12 = ZMG.CombatValueMgr;
        // 0x00D88258: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00D8825C: CBNZ x20, #0xd88264        | if (val_12 != null) goto label_28;      
        if(val_12 != null)
        {
            goto label_28;
        }
        // 0x00D88260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_28:
        // 0x00D88264: LDR s9, [x20, #0x18]       | S9 = val_12.value03; //P2               
        // 0x00D88268: LDR x20, [x19, #0x10]      | X20 = val_11 + 16;                      
        // 0x00D8826C: CBNZ x20, #0xd88274        | if (val_11 + 16 != 0) goto label_29;    
        if((val_11 + 16) != 0)
        {
            goto label_29;
        }
        // 0x00D88270: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_29:
        // 0x00D88274: LDP w21, w22, [x20, #0x20] | W21 = val_11 + 16 + 32; W22 = val_11 + 16 + 32 + 4; //  | 
        val_46 = mem[val_11 + 16 + 32];
        val_46 = val_11 + 16 + 32;
        // 0x00D88278: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8827C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88280: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_13 = ZMG.CombatValueMgr;
        // 0x00D88284: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x00D88288: CBNZ x20, #0xd88290        | if (val_13 != null) goto label_30;      
        if(val_13 != null)
        {
            goto label_30;
        }
        // 0x00D8828C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_30:
        // 0x00D88290: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D88294: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D88298: LDR s10, [x20, #0x10]      | S10 = val_13.value01; //P2              
        val_50 = val_13.value01;
        // 0x00D8829C: SUB w20, w22, w21          | W20 = (val_11 + 16 + 32 + 4 - val_11 + 16 + 32);
        var val_14 = (val_11 + 16 + 32 + 4) - val_46;
        // 0x00D882A0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D882A4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D882A8: TBZ w8, #0, #0xd882b8      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_32;
        // 0x00D882AC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D882B0: CBNZ w8, #0xd882b8         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
        // 0x00D882B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_32:
        // 0x00D882B8: UCVTF d0, w20              | D0 = (double)((val_11 + 16 + 32 + 4 - val_11 + 16 + 32));
        // 0x00D882BC: FCVT s0, d0                | S0 = (float)(val_11 + 16 + 32 + 4 - val_11 + 16 + 32));
        float val_48 = (float)(double)val_14;
        // 0x00D882C0: FMUL s0, s0, s10           | S0 = ((val_11 + 16 + 32 + 4 - val_11 + 16 + 32) * val_13.value01);
        val_48 = val_48 * val_50;
        // 0x00D882C4: FADD s0, s9, s0            | S0 = (val_12.value03 + ((val_11 + 16 + 32 + 4 - val_11 + 16 + 32) * val_13.value01));
        val_48 = val_12.value03 + val_48;
        // 0x00D882C8: FMUL s0, s0, s8            | S0 = ((val_12.value03 + ((val_11 + 16 + 32 + 4 - val_11 + 16 + 32) * val_13.value01)) * basicsAtt);
        val_48 = val_48 * basicsAtt;
        // 0x00D882CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D882D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D882D4: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_14 = (float)(double)val_14 * basicsAtt);
        int val_15 = UnityEngine.Mathf.FloorToInt(f:  val_48);
        // 0x00D882D8: LDR x20, [x19, #0x10]      | X20 = val_11 + 16;                      
        // 0x00D882DC: MOV w19, w0                | W19 = val_15;//m1                       
        val_48 = val_15;
        // 0x00D882E0: CBNZ x20, #0xd882e8        | if (val_11 + 16 != 0) goto label_33;    
        if((val_11 + 16) != 0)
        {
            goto label_33;
        }
        // 0x00D882E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_33:
        // 0x00D882E8: LDP w9, w8, [x20, #0x70]   | W9 = val_11 + 16 + 112; W8 = val_11 + 16 + 112 + 4; //  | 
        val_53 = mem[val_11 + 16 + 112];
        val_53 = val_11 + 16 + 112;
        val_52 = mem[val_11 + 16 + 112 + 4];
        val_52 = val_11 + 16 + 112 + 4;
        // 0x00D882EC: B #0xd88848                |  goto label_88;                         
        goto label_88;
        // 0x00D882F0: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D882F4: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D882F8: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D882FC: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D88300: TBZ w8, #0, #0xd88310      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_36;
        // 0x00D88304: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D88308: CBNZ w8, #0xd88310         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
        // 0x00D8830C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_36:
        // 0x00D88310: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88314: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88318: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_16 = ZMG.CombatValueMgr;
        // 0x00D8831C: MOV x20, x0                | X20 = val_16;//m1                       
        // 0x00D88320: CBNZ x20, #0xd88328        | if (val_16 != null) goto label_37;      
        if(val_16 != null)
        {
            goto label_37;
        }
        // 0x00D88324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_37:
        // 0x00D88328: LDR s9, [x20, #0x18]       | S9 = val_16.value03; //P2               
        // 0x00D8832C: LDR x20, [x19, #0x10]      | X20 = val_15 + 16;                      
        // 0x00D88330: CBNZ x20, #0xd88338        | if (val_15 + 16 != 0) goto label_38;    
        if((val_15 + 16) != 0)
        {
            goto label_38;
        }
        // 0x00D88334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_38:
        // 0x00D88338: LDP w21, w22, [x20, #0x28] | W21 = val_15 + 16 + 40; W22 = val_15 + 16 + 40 + 4; //  | 
        val_46 = mem[val_15 + 16 + 40];
        val_46 = val_15 + 16 + 40;
        // 0x00D8833C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88340: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88344: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_17 = ZMG.CombatValueMgr;
        // 0x00D88348: MOV x20, x0                | X20 = val_17;//m1                       
        // 0x00D8834C: CBNZ x20, #0xd88354        | if (val_17 != null) goto label_39;      
        if(val_17 != null)
        {
            goto label_39;
        }
        // 0x00D88350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_39:
        // 0x00D88354: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D88358: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D8835C: LDR s10, [x20, #0x10]      | S10 = val_17.value01; //P2              
        val_50 = val_17.value01;
        // 0x00D88360: SUB w20, w22, w21          | W20 = (val_15 + 16 + 40 + 4 - val_15 + 16 + 40);
        var val_18 = (val_15 + 16 + 40 + 4) - val_46;
        // 0x00D88364: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D88368: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D8836C: TBZ w8, #0, #0xd8837c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_41;
        // 0x00D88370: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D88374: CBNZ w8, #0xd8837c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
        // 0x00D88378: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_41:
        // 0x00D8837C: UCVTF d0, w20              | D0 = (double)((val_15 + 16 + 40 + 4 - val_15 + 16 + 40));
        // 0x00D88380: FCVT s0, d0                | S0 = (float)(val_15 + 16 + 40 + 4 - val_15 + 16 + 40));
        float val_49 = (float)(double)val_18;
        // 0x00D88384: FMUL s0, s0, s10           | S0 = ((val_15 + 16 + 40 + 4 - val_15 + 16 + 40) * val_17.value01);
        val_49 = val_49 * val_50;
        // 0x00D88388: FADD s0, s9, s0            | S0 = (val_16.value03 + ((val_15 + 16 + 40 + 4 - val_15 + 16 + 40) * val_17.value01));
        val_49 = val_16.value03 + val_49;
        // 0x00D8838C: FMUL s0, s0, s8            | S0 = ((val_16.value03 + ((val_15 + 16 + 40 + 4 - val_15 + 16 + 40) * val_17.value01)) * basicsAtt);
        val_49 = val_49 * basicsAtt;
        // 0x00D88390: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88398: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_18 = (float)(double)val_18 * basicsAtt);
        int val_19 = UnityEngine.Mathf.FloorToInt(f:  val_49);
        // 0x00D8839C: LDR x20, [x19, #0x10]      | X20 = val_15 + 16;                      
        // 0x00D883A0: MOV w19, w0                | W19 = val_19;//m1                       
        val_48 = val_19;
        // 0x00D883A4: CBNZ x20, #0xd883ac        | if (val_15 + 16 != 0) goto label_42;    
        if((val_15 + 16) != 0)
        {
            goto label_42;
        }
        // 0x00D883A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_42:
        // 0x00D883AC: LDP w9, w8, [x20, #0x78]   | W9 = val_15 + 16 + 120; W8 = val_15 + 16 + 120 + 4; //  | 
        val_53 = mem[val_15 + 16 + 120];
        val_53 = val_15 + 16 + 120;
        val_52 = mem[val_15 + 16 + 120 + 4];
        val_52 = val_15 + 16 + 120 + 4;
        // 0x00D883B0: B #0xd88848                |  goto label_88;                         
        goto label_88;
        // 0x00D883B4: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D883B8: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D883BC: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D883C0: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D883C4: TBZ w8, #0, #0xd883d4      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_45;
        // 0x00D883C8: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D883CC: CBNZ w8, #0xd883d4         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
        // 0x00D883D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_45:
        // 0x00D883D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D883D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D883DC: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_20 = ZMG.CombatValueMgr;
        // 0x00D883E0: MOV x20, x0                | X20 = val_20;//m1                       
        // 0x00D883E4: CBNZ x20, #0xd883ec        | if (val_20 != null) goto label_46;      
        if(val_20 != null)
        {
            goto label_46;
        }
        // 0x00D883E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_46:
        // 0x00D883EC: LDR s9, [x20, #0x18]       | S9 = val_20.value03; //P2               
        // 0x00D883F0: LDR x20, [x19, #0x10]      | X20 = val_19 + 16;                      
        // 0x00D883F4: CBNZ x20, #0xd883fc        | if (val_19 + 16 != 0) goto label_47;    
        if((val_19 + 16) != 0)
        {
            goto label_47;
        }
        // 0x00D883F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_47:
        // 0x00D883FC: LDP w21, w22, [x20, #0x30] | W21 = val_19 + 16 + 48; W22 = val_19 + 16 + 48 + 4; //  | 
        val_46 = mem[val_19 + 16 + 48];
        val_46 = val_19 + 16 + 48;
        // 0x00D88400: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88408: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_21 = ZMG.CombatValueMgr;
        // 0x00D8840C: MOV x20, x0                | X20 = val_21;//m1                       
        // 0x00D88410: CBNZ x20, #0xd88418        | if (val_21 != null) goto label_48;      
        if(val_21 != null)
        {
            goto label_48;
        }
        // 0x00D88414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_48:
        // 0x00D88418: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D8841C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D88420: LDR s10, [x20, #0x10]      | S10 = val_21.value01; //P2              
        val_50 = val_21.value01;
        // 0x00D88424: SUB w20, w22, w21          | W20 = (val_19 + 16 + 48 + 4 - val_19 + 16 + 48);
        var val_22 = (val_19 + 16 + 48 + 4) - val_46;
        // 0x00D88428: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D8842C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D88430: TBZ w8, #0, #0xd88440      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_50;
        // 0x00D88434: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D88438: CBNZ w8, #0xd88440         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_50;
        // 0x00D8843C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_50:
        // 0x00D88440: UCVTF d0, w20              | D0 = (double)((val_19 + 16 + 48 + 4 - val_19 + 16 + 48));
        // 0x00D88444: FCVT s0, d0                | S0 = (float)(val_19 + 16 + 48 + 4 - val_19 + 16 + 48));
        float val_50 = (float)(double)val_22;
        // 0x00D88448: FMUL s0, s0, s10           | S0 = ((val_19 + 16 + 48 + 4 - val_19 + 16 + 48) * val_21.value01);
        val_50 = val_50 * val_50;
        // 0x00D8844C: FADD s0, s9, s0            | S0 = (val_20.value03 + ((val_19 + 16 + 48 + 4 - val_19 + 16 + 48) * val_21.value01));
        val_50 = val_20.value03 + val_50;
        // 0x00D88450: FMUL s0, s0, s8            | S0 = ((val_20.value03 + ((val_19 + 16 + 48 + 4 - val_19 + 16 + 48) * val_21.value01)) * basicsAtt);
        val_50 = val_50 * basicsAtt;
        // 0x00D88454: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88458: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8845C: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_22 = (float)(double)val_22 * basicsAtt);
        int val_23 = UnityEngine.Mathf.FloorToInt(f:  val_50);
        // 0x00D88460: LDR x20, [x19, #0x10]      | X20 = val_19 + 16;                      
        // 0x00D88464: MOV w19, w0                | W19 = val_23;//m1                       
        val_48 = val_23;
        // 0x00D88468: CBNZ x20, #0xd88470        | if (val_19 + 16 != 0) goto label_51;    
        if((val_19 + 16) != 0)
        {
            goto label_51;
        }
        // 0x00D8846C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_51:
        // 0x00D88470: LDP w9, w8, [x20, #0x80]   | W9 = val_19 + 16 + 128; W8 = val_19 + 16 + 128 + 4; //  | 
        val_53 = mem[val_19 + 16 + 128];
        val_53 = val_19 + 16 + 128;
        val_52 = mem[val_19 + 16 + 128 + 4];
        val_52 = val_19 + 16 + 128 + 4;
        // 0x00D88474: B #0xd88848                |  goto label_88;                         
        goto label_88;
        // 0x00D88478: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D8847C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D88480: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D88484: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D88488: TBZ w8, #0, #0xd88498      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_54;
        // 0x00D8848C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D88490: CBNZ w8, #0xd88498         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_54;
        // 0x00D88494: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_54:
        // 0x00D88498: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8849C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D884A0: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_24 = ZMG.CombatValueMgr;
        // 0x00D884A4: MOV x20, x0                | X20 = val_24;//m1                       
        // 0x00D884A8: CBNZ x20, #0xd884b0        | if (val_24 != null) goto label_55;      
        if(val_24 != null)
        {
            goto label_55;
        }
        // 0x00D884AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_55:
        // 0x00D884B0: LDR s9, [x20, #0x18]       | S9 = val_24.value03; //P2               
        // 0x00D884B4: LDR x20, [x19, #0x10]      | X20 = val_23 + 16;                      
        // 0x00D884B8: CBNZ x20, #0xd884c0        | if (val_23 + 16 != 0) goto label_56;    
        if((val_23 + 16) != 0)
        {
            goto label_56;
        }
        // 0x00D884BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_56:
        // 0x00D884C0: LDP w21, w22, [x20, #0x38] | W21 = val_23 + 16 + 56; W22 = val_23 + 16 + 56 + 4; //  | 
        val_46 = mem[val_23 + 16 + 56];
        val_46 = val_23 + 16 + 56;
        // 0x00D884C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D884C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D884CC: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_25 = ZMG.CombatValueMgr;
        // 0x00D884D0: MOV x20, x0                | X20 = val_25;//m1                       
        // 0x00D884D4: CBNZ x20, #0xd884dc        | if (val_25 != null) goto label_57;      
        if(val_25 != null)
        {
            goto label_57;
        }
        // 0x00D884D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_57:
        // 0x00D884DC: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D884E0: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D884E4: LDR s10, [x20, #0x10]      | S10 = val_25.value01; //P2              
        val_50 = val_25.value01;
        // 0x00D884E8: SUB w20, w22, w21          | W20 = (val_23 + 16 + 56 + 4 - val_23 + 16 + 56);
        var val_26 = (val_23 + 16 + 56 + 4) - val_46;
        // 0x00D884EC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D884F0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D884F4: TBZ w8, #0, #0xd88504      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_59;
        // 0x00D884F8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D884FC: CBNZ w8, #0xd88504         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_59;
        // 0x00D88500: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_59:
        // 0x00D88504: UCVTF d0, w20              | D0 = (double)((val_23 + 16 + 56 + 4 - val_23 + 16 + 56));
        // 0x00D88508: FCVT s0, d0                | S0 = (float)(val_23 + 16 + 56 + 4 - val_23 + 16 + 56));
        float val_51 = (float)(double)val_26;
        // 0x00D8850C: FMUL s0, s0, s10           | S0 = ((val_23 + 16 + 56 + 4 - val_23 + 16 + 56) * val_25.value01);
        val_51 = val_51 * val_50;
        // 0x00D88510: FADD s0, s9, s0            | S0 = (val_24.value03 + ((val_23 + 16 + 56 + 4 - val_23 + 16 + 56) * val_25.value01));
        val_51 = val_24.value03 + val_51;
        // 0x00D88514: FMUL s0, s0, s8            | S0 = ((val_24.value03 + ((val_23 + 16 + 56 + 4 - val_23 + 16 + 56) * val_25.value01)) * basicsAtt);
        val_51 = val_51 * basicsAtt;
        // 0x00D88518: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8851C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88520: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_26 = (float)(double)val_26 * basicsAtt);
        int val_27 = UnityEngine.Mathf.FloorToInt(f:  val_51);
        // 0x00D88524: LDR x20, [x19, #0x10]      | X20 = val_23 + 16;                      
        // 0x00D88528: MOV w19, w0                | W19 = val_27;//m1                       
        val_48 = val_27;
        // 0x00D8852C: CBNZ x20, #0xd88534        | if (val_23 + 16 != 0) goto label_60;    
        if((val_23 + 16) != 0)
        {
            goto label_60;
        }
        // 0x00D88530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_60:
        // 0x00D88534: LDP w9, w8, [x20, #0x88]   | W9 = val_23 + 16 + 136; W8 = val_23 + 16 + 136 + 4; //  | 
        val_53 = mem[val_23 + 16 + 136];
        val_53 = val_23 + 16 + 136;
        val_52 = mem[val_23 + 16 + 136 + 4];
        val_52 = val_23 + 16 + 136 + 4;
        // 0x00D88538: B #0xd88848                |  goto label_88;                         
        goto label_88;
        // 0x00D8853C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D88540: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D88544: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D88548: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D8854C: TBZ w8, #0, #0xd8855c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_63;
        // 0x00D88550: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D88554: CBNZ w8, #0xd8855c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_63;
        // 0x00D88558: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_63:
        // 0x00D8855C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88560: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88564: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_28 = ZMG.CombatValueMgr;
        // 0x00D88568: MOV x20, x0                | X20 = val_28;//m1                       
        // 0x00D8856C: CBNZ x20, #0xd88574        | if (val_28 != null) goto label_64;      
        if(val_28 != null)
        {
            goto label_64;
        }
        // 0x00D88570: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_64:
        // 0x00D88574: LDR s9, [x20, #0x18]       | S9 = val_28.value03; //P2               
        // 0x00D88578: LDR x20, [x19, #0x10]      | X20 = val_27 + 16;                      
        // 0x00D8857C: CBNZ x20, #0xd88584        | if (val_27 + 16 != 0) goto label_65;    
        if((val_27 + 16) != 0)
        {
            goto label_65;
        }
        // 0x00D88580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_65:
        // 0x00D88584: LDP w21, w22, [x20, #0x40] | W21 = val_27 + 16 + 64; W22 = val_27 + 16 + 64 + 4; //  | 
        val_46 = mem[val_27 + 16 + 64];
        val_46 = val_27 + 16 + 64;
        // 0x00D88588: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8858C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88590: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_29 = ZMG.CombatValueMgr;
        // 0x00D88594: MOV x20, x0                | X20 = val_29;//m1                       
        // 0x00D88598: CBNZ x20, #0xd885a0        | if (val_29 != null) goto label_66;      
        if(val_29 != null)
        {
            goto label_66;
        }
        // 0x00D8859C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
        label_66:
        // 0x00D885A0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D885A4: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D885A8: LDR s10, [x20, #0x10]      | S10 = val_29.value01; //P2              
        val_50 = val_29.value01;
        // 0x00D885AC: SUB w20, w22, w21          | W20 = (val_27 + 16 + 64 + 4 - val_27 + 16 + 64);
        var val_30 = (val_27 + 16 + 64 + 4) - val_46;
        // 0x00D885B0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D885B4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D885B8: TBZ w8, #0, #0xd885c8      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_68;
        // 0x00D885BC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D885C0: CBNZ w8, #0xd885c8         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_68;
        // 0x00D885C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_68:
        // 0x00D885C8: UCVTF d0, w20              | D0 = (double)((val_27 + 16 + 64 + 4 - val_27 + 16 + 64));
        // 0x00D885CC: FCVT s0, d0                | S0 = (float)(val_27 + 16 + 64 + 4 - val_27 + 16 + 64));
        float val_52 = (float)(double)val_30;
        // 0x00D885D0: FMUL s0, s0, s10           | S0 = ((val_27 + 16 + 64 + 4 - val_27 + 16 + 64) * val_29.value01);
        val_52 = val_52 * val_50;
        // 0x00D885D4: FADD s0, s9, s0            | S0 = (val_28.value03 + ((val_27 + 16 + 64 + 4 - val_27 + 16 + 64) * val_29.value01));
        val_52 = val_28.value03 + val_52;
        // 0x00D885D8: FMUL s0, s0, s8            | S0 = ((val_28.value03 + ((val_27 + 16 + 64 + 4 - val_27 + 16 + 64) * val_29.value01)) * basicsAtt);
        val_52 = val_52 * basicsAtt;
        // 0x00D885DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D885E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D885E4: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_30 = (float)(double)val_30 * basicsAtt);
        int val_31 = UnityEngine.Mathf.FloorToInt(f:  val_52);
        // 0x00D885E8: LDR x20, [x19, #0x10]      | X20 = val_27 + 16;                      
        // 0x00D885EC: MOV w19, w0                | W19 = val_31;//m1                       
        val_48 = val_31;
        // 0x00D885F0: CBNZ x20, #0xd885f8        | if (val_27 + 16 != 0) goto label_69;    
        if((val_27 + 16) != 0)
        {
            goto label_69;
        }
        // 0x00D885F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_69:
        // 0x00D885F8: LDP w9, w8, [x20, #0x90]   | W9 = val_27 + 16 + 144; W8 = val_27 + 16 + 144 + 4; //  | 
        val_53 = mem[val_27 + 16 + 144];
        val_53 = val_27 + 16 + 144;
        val_52 = mem[val_27 + 16 + 144 + 4];
        val_52 = val_27 + 16 + 144 + 4;
        // 0x00D885FC: B #0xd88848                |  goto label_88;                         
        goto label_88;
        // 0x00D88600: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D88604: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D88608: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D8860C: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D88610: TBZ w8, #0, #0xd88620      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_72;
        // 0x00D88614: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D88618: CBNZ w8, #0xd88620         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
        // 0x00D8861C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_72:
        // 0x00D88620: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88628: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_32 = ZMG.CombatValueMgr;
        // 0x00D8862C: MOV x20, x0                | X20 = val_32;//m1                       
        // 0x00D88630: CBNZ x20, #0xd88638        | if (val_32 != null) goto label_73;      
        if(val_32 != null)
        {
            goto label_73;
        }
        // 0x00D88634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_73:
        // 0x00D88638: LDR s9, [x20, #0x18]       | S9 = val_32.value03; //P2               
        // 0x00D8863C: LDR x20, [x19, #0x10]      | X20 = val_31 + 16;                      
        // 0x00D88640: CBNZ x20, #0xd88648        | if (val_31 + 16 != 0) goto label_74;    
        if((val_31 + 16) != 0)
        {
            goto label_74;
        }
        // 0x00D88644: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_74:
        // 0x00D88648: LDP w21, w22, [x20, #0x48] | W21 = val_31 + 16 + 72; W22 = val_31 + 16 + 72 + 4; //  | 
        val_46 = mem[val_31 + 16 + 72];
        val_46 = val_31 + 16 + 72;
        // 0x00D8864C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88650: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88654: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_33 = ZMG.CombatValueMgr;
        // 0x00D88658: MOV x20, x0                | X20 = val_33;//m1                       
        // 0x00D8865C: CBNZ x20, #0xd88664        | if (val_33 != null) goto label_75;      
        if(val_33 != null)
        {
            goto label_75;
        }
        // 0x00D88660: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
        label_75:
        // 0x00D88664: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D88668: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D8866C: LDR s10, [x20, #0x10]      | S10 = val_33.value01; //P2              
        val_50 = val_33.value01;
        // 0x00D88670: SUB w20, w22, w21          | W20 = (val_31 + 16 + 72 + 4 - val_31 + 16 + 72);
        var val_34 = (val_31 + 16 + 72 + 4) - val_46;
        // 0x00D88674: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D88678: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D8867C: TBZ w8, #0, #0xd8868c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_77;
        // 0x00D88680: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D88684: CBNZ w8, #0xd8868c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_77;
        // 0x00D88688: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_77:
        // 0x00D8868C: UCVTF d0, w20              | D0 = (double)((val_31 + 16 + 72 + 4 - val_31 + 16 + 72));
        // 0x00D88690: FCVT s0, d0                | S0 = (float)(val_31 + 16 + 72 + 4 - val_31 + 16 + 72));
        float val_53 = (float)(double)val_34;
        // 0x00D88694: FMUL s0, s0, s10           | S0 = ((val_31 + 16 + 72 + 4 - val_31 + 16 + 72) * val_33.value01);
        val_53 = val_53 * val_50;
        // 0x00D88698: FADD s0, s9, s0            | S0 = (val_32.value03 + ((val_31 + 16 + 72 + 4 - val_31 + 16 + 72) * val_33.value01));
        val_53 = val_32.value03 + val_53;
        // 0x00D8869C: FMUL s0, s0, s8            | S0 = ((val_32.value03 + ((val_31 + 16 + 72 + 4 - val_31 + 16 + 72) * val_33.value01)) * basicsAtt);
        val_53 = val_53 * basicsAtt;
        // 0x00D886A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D886A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D886A8: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_34 = (float)(double)val_34 * basicsAtt);
        int val_35 = UnityEngine.Mathf.FloorToInt(f:  val_53);
        // 0x00D886AC: LDR x20, [x19, #0x10]      | X20 = val_31 + 16;                      
        // 0x00D886B0: MOV w19, w0                | W19 = val_35;//m1                       
        val_48 = val_35;
        // 0x00D886B4: CBNZ x20, #0xd886bc        | if (val_31 + 16 != 0) goto label_78;    
        if((val_31 + 16) != 0)
        {
            goto label_78;
        }
        // 0x00D886B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_78:
        // 0x00D886BC: LDP w9, w8, [x20, #0x98]   | W9 = val_31 + 16 + 152; W8 = val_31 + 16 + 152 + 4; //  | 
        val_53 = mem[val_31 + 16 + 152];
        val_53 = val_31 + 16 + 152;
        val_52 = mem[val_31 + 16 + 152 + 4];
        val_52 = val_31 + 16 + 152 + 4;
        // 0x00D886C0: B #0xd88848                |  goto label_88;                         
        goto label_88;
        // 0x00D886C4: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D886C8: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D886CC: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D886D0: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D886D4: TBZ w8, #0, #0xd886e4      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_81;
        // 0x00D886D8: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D886DC: CBNZ w8, #0xd886e4         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_81;
        // 0x00D886E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_81:
        // 0x00D886E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D886E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D886EC: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_36 = ZMG.CombatValueMgr;
        // 0x00D886F0: MOV x20, x0                | X20 = val_36;//m1                       
        // 0x00D886F4: CBNZ x20, #0xd886fc        | if (val_36 != null) goto label_82;      
        if(val_36 != null)
        {
            goto label_82;
        }
        // 0x00D886F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_82:
        // 0x00D886FC: LDR s9, [x20, #0x18]       | S9 = val_36.value03; //P2               
        // 0x00D88700: LDR x20, [x19, #0x10]      | X20 = val_35 + 16;                      
        // 0x00D88704: CBNZ x20, #0xd8870c        | if (val_35 + 16 != 0) goto label_83;    
        if((val_35 + 16) != 0)
        {
            goto label_83;
        }
        // 0x00D88708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_83:
        // 0x00D8870C: LDP w21, w22, [x20, #0x50] | W21 = val_35 + 16 + 80; W22 = val_35 + 16 + 80 + 4; //  | 
        val_46 = mem[val_35 + 16 + 80];
        val_46 = val_35 + 16 + 80;
        // 0x00D88710: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88718: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_37 = ZMG.CombatValueMgr;
        // 0x00D8871C: MOV x20, x0                | X20 = val_37;//m1                       
        // 0x00D88720: CBNZ x20, #0xd88728        | if (val_37 != null) goto label_84;      
        if(val_37 != null)
        {
            goto label_84;
        }
        // 0x00D88724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_84:
        // 0x00D88728: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D8872C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D88730: LDR s10, [x20, #0x10]      | S10 = val_37.value01; //P2              
        val_50 = val_37.value01;
        // 0x00D88734: SUB w20, w22, w21          | W20 = (val_35 + 16 + 80 + 4 - val_35 + 16 + 80);
        var val_38 = (val_35 + 16 + 80 + 4) - val_46;
        // 0x00D88738: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D8873C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D88740: TBZ w8, #0, #0xd88750      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_86;
        // 0x00D88744: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D88748: CBNZ w8, #0xd88750         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_86;
        // 0x00D8874C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_86:
        // 0x00D88750: UCVTF d0, w20              | D0 = (double)((val_35 + 16 + 80 + 4 - val_35 + 16 + 80));
        // 0x00D88754: FCVT s0, d0                | S0 = (float)(val_35 + 16 + 80 + 4 - val_35 + 16 + 80));
        float val_54 = (float)(double)val_38;
        // 0x00D88758: FMUL s0, s0, s10           | S0 = ((val_35 + 16 + 80 + 4 - val_35 + 16 + 80) * val_37.value01);
        val_54 = val_54 * val_50;
        // 0x00D8875C: FADD s0, s9, s0            | S0 = (val_36.value03 + ((val_35 + 16 + 80 + 4 - val_35 + 16 + 80) * val_37.value01));
        val_54 = val_36.value03 + val_54;
        // 0x00D88760: FMUL s0, s0, s8            | S0 = ((val_36.value03 + ((val_35 + 16 + 80 + 4 - val_35 + 16 + 80) * val_37.value01)) * basicsAtt);
        val_54 = val_54 * basicsAtt;
        // 0x00D88764: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88768: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8876C: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_38 = (float)(double)val_38 * basicsAtt);
        int val_39 = UnityEngine.Mathf.FloorToInt(f:  val_54);
        // 0x00D88770: LDR x20, [x19, #0x10]      | X20 = val_35 + 16;                      
        // 0x00D88774: MOV w19, w0                | W19 = val_39;//m1                       
        val_48 = val_39;
        // 0x00D88778: CBNZ x20, #0xd88780        | if (val_35 + 16 != 0) goto label_87;    
        if((val_35 + 16) != 0)
        {
            goto label_87;
        }
        // 0x00D8877C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_87:
        // 0x00D88780: LDP w9, w8, [x20, #0xa0]   | W9 = val_35 + 16 + 160; W8 = val_35 + 16 + 160 + 4; //  | 
        val_53 = mem[val_35 + 16 + 160];
        val_53 = val_35 + 16 + 160;
        val_52 = mem[val_35 + 16 + 160 + 4];
        val_52 = val_35 + 16 + 160 + 4;
        // 0x00D88784: B #0xd88848                |  goto label_88;                         
        goto label_88;
        // 0x00D88788: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D8878C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D88790: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D88794: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D88798: TBZ w8, #0, #0xd887a8      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_90;
        // 0x00D8879C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D887A0: CBNZ w8, #0xd887a8         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_90;
        // 0x00D887A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_90:
        // 0x00D887A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D887AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D887B0: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_40 = ZMG.CombatValueMgr;
        // 0x00D887B4: MOV x20, x0                | X20 = val_40;//m1                       
        // 0x00D887B8: CBNZ x20, #0xd887c0        | if (val_40 != null) goto label_91;      
        if(val_40 != null)
        {
            goto label_91;
        }
        // 0x00D887BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_91:
        // 0x00D887C0: LDR s9, [x20, #0x18]       | S9 = val_40.value03; //P2               
        // 0x00D887C4: LDR x20, [x19, #0x10]      | X20 = val_39 + 16;                      
        // 0x00D887C8: CBNZ x20, #0xd887d0        | if (val_39 + 16 != 0) goto label_92;    
        if((val_39 + 16) != 0)
        {
            goto label_92;
        }
        // 0x00D887CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_92:
        // 0x00D887D0: LDP w21, w22, [x20, #0x58] | W21 = val_39 + 16 + 88; W22 = val_39 + 16 + 88 + 4; //  | 
        val_46 = mem[val_39 + 16 + 88];
        val_46 = val_39 + 16 + 88;
        // 0x00D887D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D887D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D887DC: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_41 = ZMG.CombatValueMgr;
        // 0x00D887E0: MOV x20, x0                | X20 = val_41;//m1                       
        // 0x00D887E4: CBNZ x20, #0xd887ec        | if (val_41 != null) goto label_93;      
        if(val_41 != null)
        {
            goto label_93;
        }
        // 0x00D887E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
        label_93:
        // 0x00D887EC: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D887F0: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D887F4: LDR s10, [x20, #0x10]      | S10 = val_41.value01; //P2              
        val_50 = val_41.value01;
        // 0x00D887F8: SUB w20, w22, w21          | W20 = (val_39 + 16 + 88 + 4 - val_39 + 16 + 88);
        var val_42 = (val_39 + 16 + 88 + 4) - val_46;
        // 0x00D887FC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D88800: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D88804: TBZ w8, #0, #0xd88814      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_95;
        // 0x00D88808: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D8880C: CBNZ w8, #0xd88814         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_95;
        // 0x00D88810: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_95:
        // 0x00D88814: UCVTF d0, w20              | D0 = (double)((val_39 + 16 + 88 + 4 - val_39 + 16 + 88));
        // 0x00D88818: FCVT s0, d0                | S0 = (float)(val_39 + 16 + 88 + 4 - val_39 + 16 + 88));
        float val_55 = (float)(double)val_42;
        // 0x00D8881C: FMUL s0, s0, s10           | S0 = ((val_39 + 16 + 88 + 4 - val_39 + 16 + 88) * val_41.value01);
        val_55 = val_55 * val_50;
        // 0x00D88820: FADD s0, s9, s0            | S0 = (val_40.value03 + ((val_39 + 16 + 88 + 4 - val_39 + 16 + 88) * val_41.value01));
        val_55 = val_40.value03 + val_55;
        // 0x00D88824: FMUL s0, s0, s8            | S0 = ((val_40.value03 + ((val_39 + 16 + 88 + 4 - val_39 + 16 + 88) * val_41.value01)) * basicsAtt);
        val_55 = val_55 * basicsAtt;
        // 0x00D88828: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8882C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88830: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)(double)val_42 = (float)(double)val_42 * basicsAtt);
        int val_43 = UnityEngine.Mathf.FloorToInt(f:  val_55);
        // 0x00D88834: LDR x20, [x19, #0x10]      | X20 = val_39 + 16;                      
        // 0x00D88838: MOV w19, w0                | W19 = val_43;//m1                       
        val_48 = val_43;
        // 0x00D8883C: CBNZ x20, #0xd88844        | if (val_39 + 16 != 0) goto label_96;    
        if((val_39 + 16) != 0)
        {
            goto label_96;
        }
        // 0x00D88840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
        label_96:
        // 0x00D88844: LDP w9, w8, [x20, #0xa8]   | W9 = val_39 + 16 + 168; W8 = val_39 + 16 + 168 + 4; //  | 
        val_53 = mem[val_39 + 16 + 168];
        val_53 = val_39 + 16 + 168;
        val_52 = mem[val_39 + 16 + 168 + 4];
        val_52 = val_39 + 16 + 168 + 4;
        label_88:
        // 0x00D88848: ADD w8, w8, w19            | W8 = (val_39 + 16 + 168 + 4 + val_43);  
        val_52 = val_52 + val_48;
        // 0x00D8884C: SUB w0, w8, w9             | W0 = ((val_39 + 16 + 168 + 4 + val_43) - val_39 + 16 + 168);
        val_49 = val_52 - val_53;
        label_7:
        // 0x00D88850: SUB sp, x29, #0x40         | SP = (1152921514687047536 - 64) = 1152921514687047472 (0x1000000258D3A730);
        // 0x00D88854: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00D88858: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00D8885C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00D88860: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00D88864: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00D88868: RET                        |  return (System.UInt32)((val_39 + 16 + 168 + 4 + val_43) - val_39 + 16 + 168);
        return (uint)val_49;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        // 0x00D8886C: LDR x19, [x19, #0x10]      | X19 = ??? + 16;                         
        // 0x00D88870: CBNZ x19, #0xd88878        | if (??? + 16 != 0) goto label_97;       
        if((??? + 16) != 0)
        {
            goto label_97;
        }
        // 0x00D88874: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ((val_39 + 16 + 168 + 4 + val_43) - val_39 + 16 + 168), ????);
        label_97:
        // 0x00D88878: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D8887C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D88880: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        val_63 = null;
        // 0x00D88884: LDP w8, w9, [x19, #0xb0]   | W8 = ??? + 16 + 176; W9 = ??? + 16 + 176 + 4; //  | 
        val_65 = mem[??? + 16 + 176];
        val_65 = ??? + 16 + 176;
        val_64 = mem[??? + 16 + 176 + 4];
        val_64 = ??? + 16 + 176 + 4;
        // 0x00D88888: B #0xd888c8                |  goto label_100;                        
        goto label_100;
        // 0x00D8888C: LDR x19, [x19, #0x10]      | X19 = ??? + 16 + 16;                    
        // 0x00D88890: CBNZ x19, #0xd88898        | if (??? + 16 + 16 != 0) goto label_99;  
        if((??? + 16 + 16) != 0)
        {
            goto label_99;
        }
        // 0x00D88894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_99:
        // 0x00D88898: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D8889C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D888A0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        val_63 = null;
        // 0x00D888A4: LDP w8, w9, [x19, #0xb8]   | W8 = ??? + 16 + 16 + 184; W9 = ??? + 16 + 16 + 184 + 4; //  | 
        val_65 = mem[??? + 16 + 16 + 184];
        val_65 = ??? + 16 + 16 + 184;
        val_64 = mem[??? + 16 + 16 + 184 + 4];
        val_64 = ??? + 16 + 16 + 184 + 4;
        // 0x00D888A8: B #0xd888c8                |  goto label_100;                        
        goto label_100;
        // 0x00D888AC: LDR x19, [x19, #0x10]      | X19 = ??? + 16 + 16 + 16;               
        // 0x00D888B0: CBNZ x19, #0xd888b8        | if (??? + 16 + 16 + 16 != 0) goto label_101;
        if((??? + 16 + 16 + 16) != 0)
        {
            goto label_101;
        }
        // 0x00D888B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_101:
        // 0x00D888B8: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D888BC: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D888C0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        val_63 = null;
        // 0x00D888C4: LDP w8, w9, [x19, #0xc0]   | W8 = ??? + 16 + 16 + 16 + 192; W9 = ??? + 16 + 16 + 16 + 192 + 4; //  | 
        val_65 = mem[??? + 16 + 16 + 16 + 192];
        val_65 = ??? + 16 + 16 + 16 + 192;
        val_64 = mem[??? + 16 + 16 + 16 + 192 + 4];
        val_64 = ??? + 16 + 16 + 16 + 192 + 4;
        label_100:
        // 0x00D888C8: LDRB w10, [x0, #0x10a]     | W10 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D888CC: SUB w19, w9, w8            | W19 = (??? + 16 + 16 + 16 + 192 + 4 - ??? + 16 + 16 + 16 + 192);
        val_47 = val_64 - val_65;
        // 0x00D888D0: TBZ w10, #0, #0xd888e0     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_103;
        // 0x00D888D4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D888D8: CBNZ w8, #0xd888e0         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_103;
        // 0x00D888DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_103:
        // 0x00D888E0: UCVTF d0, w19              | D0 = (double)((??? + 16 + 16 + 16 + 192 + 4 - ??? + 16 + 16 + 16 + 192));
        // 0x00D888E4: FCVT s0, d0                | S0 = (float)(??? + 16 + 16 + 16 + 192 + 4 - ??? + 16 + 16 + 16 + 192));
        float val_56 = (float)(double)val_47;
        // 0x00D888E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D888EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D888F0: FADD s0, s0, s8            | S0 = ((??? + 16 + 16 + 16 + 192 + 4 - ??? + 16 + 16 + 16 + 192) + ???);
        val_56 = val_56 + (???);
        label_4:
        // 0x00D888F4: SUB sp, x29, #0x40         | SP = (??? - 64);                        
        var val_44 = (???) - 64;
        // 0x00D888F8: LDP x29, x30, [sp, #0x40]  | X29 = (??? - 64) + 64; X30 = (??? - 64) + 64 + 8; //  | 
        // 0x00D888FC: LDP x20, x19, [sp, #0x30]  | X20 = (??? - 64) + 48; X19 = (??? - 64) + 48 + 8; //  | 
        // 0x00D88900: LDP x22, x21, [sp, #0x20]  | X22 = (??? - 64) + 32; X21 = (??? - 64) + 32 + 8; //  | 
        // 0x00D88904: LDP d9, d8, [sp, #0x10]    | D9 = (??? - 64) + 16; D8 = (??? - 64) + 16 + 8; //  | 
        // 0x00D88908: LDP d11, d10, [sp], #0x50  | D11 = (??? - 64); D10 = (??? - 64) + 8;  //  | 
        // 0x00D8890C: B #0x1a7dc18               | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00D88910 (14190864), len: 620  VirtAddr: 0x00D88910 RVA: 0x00D88910 token: 100691640 methodIndex: 26007 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetHeroAttr(HERO_ATT_KEY key, uint basicsAtt)
    {
        //
        // Disasemble & Code
        // 0x00D88910: STP d9, d8, [sp, #-0x60]!  | stack[1152921514687339680] = ???;  stack[1152921514687339688] = ???;  //  dest_result_addr=1152921514687339680 |  dest_result_addr=1152921514687339688
        // 0x00D88914: STP x26, x25, [sp, #0x10]  | stack[1152921514687339696] = ???;  stack[1152921514687339704] = ???;  //  dest_result_addr=1152921514687339696 |  dest_result_addr=1152921514687339704
        // 0x00D88918: STP x24, x23, [sp, #0x20]  | stack[1152921514687339712] = ???;  stack[1152921514687339720] = ???;  //  dest_result_addr=1152921514687339712 |  dest_result_addr=1152921514687339720
        // 0x00D8891C: STP x22, x21, [sp, #0x30]  | stack[1152921514687339728] = ???;  stack[1152921514687339736] = ???;  //  dest_result_addr=1152921514687339728 |  dest_result_addr=1152921514687339736
        // 0x00D88920: STP x20, x19, [sp, #0x40]  | stack[1152921514687339744] = ???;  stack[1152921514687339752] = ???;  //  dest_result_addr=1152921514687339744 |  dest_result_addr=1152921514687339752
        // 0x00D88924: STP x29, x30, [sp, #0x50]  | stack[1152921514687339760] = ???;  stack[1152921514687339768] = ???;  //  dest_result_addr=1152921514687339760 |  dest_result_addr=1152921514687339768
        // 0x00D88928: ADD x29, sp, #0x50         | X29 = (1152921514687339680 + 80) = 1152921514687339760 (0x1000000258D81CF0);
        // 0x00D8892C: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
        // 0x00D88930: LDRB w8, [x22, #0x445]     | W8 = (bool)static_value_03734445;       
        // 0x00D88934: MOV w21, w2                | W21 = basicsAtt;//m1                    
        // 0x00D88938: MOV w19, w1                | W19 = key;//m1                          
        // 0x00D8893C: MOV x20, x0                | X20 = 1152921514687351776 (0x1000000258D84BE0);//ML01
        // 0x00D88940: TBNZ w8, #0, #0xd8895c     | if (static_value_03734445 == true) goto label_0;
        // 0x00D88944: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x00D88948: LDR x8, [x8, #0xfc0]       | X8 = 0x2B91768;                         
        // 0x00D8894C: LDR w0, [x8]               | W0 = 0x1C9F;                            
        // 0x00D88950: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C9F, ????);     
        // 0x00D88954: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D88958: STRB w8, [x22, #0x445]     | static_value_03734445 = true;            //  dest_result_addr=57885765
        label_0:
        // 0x00D8895C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D88960: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D88964: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D88968: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D8896C: TBZ w8, #0, #0xd8897c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D88970: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D88974: CBNZ w8, #0xd8897c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D88978: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00D8897C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88980: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88984: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_1 = ZMG.CSGameDataMgr;
        // 0x00D88988: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00D8898C: CBNZ x22, #0xd88994        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00D88990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D88994: LDR x22, [x22, #0x20]      | X22 = val_1.heroData; //P2              
        // 0x00D88998: CBNZ x22, #0xd889a0        | if (val_1.heroData != null) goto label_4;
        if(val_1.heroData != null)
        {
            goto label_4;
        }
        // 0x00D8899C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00D889A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D889A4: MOV x0, x22                | X0 = val_1.heroData;//m1                
        // 0x00D889A8: BL #0xb4c338               | X0 = val_1.heroData.GetLeaderPlusAtt(); 
        System.Collections.Generic.List<CSPlusAtt> val_2 = val_1.heroData.GetLeaderPlusAtt();
        // 0x00D889AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D889B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D889B4: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_3 = ZMG.CSGameDataMgr;
        // 0x00D889B8: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00D889BC: CBNZ x22, #0xd889c4        | if (val_3 != null) goto label_5;        
        if(val_3 != null)
        {
            goto label_5;
        }
        // 0x00D889C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00D889C4: LDR x22, [x22, #0x20]      | X22 = val_3.heroData; //P2              
        // 0x00D889C8: CBNZ x22, #0xd889d0        | if (val_3.heroData != null) goto label_6;
        if(val_3.heroData != null)
        {
            goto label_6;
        }
        // 0x00D889CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00D889D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D889D4: MOV x0, x22                | X0 = val_3.heroData;//m1                
        // 0x00D889D8: BL #0xb4c754               | X0 = val_3.heroData.GetReinPlusAtts();  
        System.Collections.Generic.List<CSPlusAtt> val_4 = val_3.heroData.GetReinPlusAtts();
        // 0x00D889DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D889E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D889E4: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_5 = ZMG.CSGameDataMgr;
        // 0x00D889E8: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00D889EC: CBNZ x22, #0xd889f4        | if (val_5 != null) goto label_7;        
        if(val_5 != null)
        {
            goto label_7;
        }
        // 0x00D889F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00D889F4: LDR x22, [x22, #0x20]      | X22 = val_5.heroData; //P2              
        // 0x00D889F8: MOV w1, w19                | W1 = key;//m1                           
        // 0x00D889FC: BL #0xd88b7c               | X0 = val_5.EnemyToString(key:  key);    
        string val_6 = val_5.EnemyToString(key:  key);
        // 0x00D88A00: MOV x23, x0                | X23 = val_6;//m1                        
        // 0x00D88A04: CBNZ x22, #0xd88a0c        | if (val_5.heroData != null) goto label_8;
        if(val_5.heroData != null)
        {
            goto label_8;
        }
        // 0x00D88A08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_8:
        // 0x00D88A0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D88A10: MOV x0, x22                | X0 = val_5.heroData;//m1                
        // 0x00D88A14: MOV x1, x23                | X1 = val_6;//m1                         
        // 0x00D88A18: BL #0xb4cebc               | X0 = val_5.heroData.GetLearerAttUnit(key:  val_6);
        CSPlusAtt val_7 = val_5.heroData.GetLearerAttUnit(key:  val_6);
        // 0x00D88A1C: MOV x22, x0                | X22 = val_7;//m1                        
        // 0x00D88A20: CBNZ x22, #0xd88a28        | if (val_7 != null) goto label_9;        
        if(val_7 != null)
        {
            goto label_9;
        }
        // 0x00D88A24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00D88A28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88A2C: MOV x0, x22                | X0 = val_7;//m1                         
        // 0x00D88A30: BL #0xb5250c               | X0 = val_7.get_value();                 
        uint val_8 = val_7.value;
        // 0x00D88A34: MOV w22, w0                | W22 = val_8;//m1                        
        // 0x00D88A38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88A3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88A40: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_9 = ZMG.CSGameDataMgr;
        // 0x00D88A44: MOV x23, x0                | X23 = val_9;//m1                        
        // 0x00D88A48: CBNZ x23, #0xd88a50        | if (val_9 != null) goto label_10;       
        if(val_9 != null)
        {
            goto label_10;
        }
        // 0x00D88A4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_10:
        // 0x00D88A50: LDR x23, [x23, #0x20]      | X23 = val_9.heroData; //P2              
        // 0x00D88A54: MOV w1, w19                | W1 = key;//m1                           
        // 0x00D88A58: BL #0xd88b7c               | X0 = val_9.EnemyToString(key:  key);    
        string val_10 = val_9.EnemyToString(key:  key);
        // 0x00D88A5C: MOV x24, x0                | X24 = val_10;//m1                       
        // 0x00D88A60: CBNZ x23, #0xd88a68        | if (val_9.heroData != null) goto label_11;
        if(val_9.heroData != null)
        {
            goto label_11;
        }
        // 0x00D88A64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_11:
        // 0x00D88A68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D88A6C: MOV x0, x23                | X0 = val_9.heroData;//m1                
        // 0x00D88A70: MOV x1, x24                | X1 = val_10;//m1                        
        // 0x00D88A74: BL #0xb4cebc               | X0 = val_9.heroData.GetLearerAttUnit(key:  val_10);
        CSPlusAtt val_11 = val_9.heroData.GetLearerAttUnit(key:  val_10);
        // 0x00D88A78: MOV x23, x0                | X23 = val_11;//m1                       
        // 0x00D88A7C: CBNZ x23, #0xd88a84        | if (val_11 != null) goto label_12;      
        if(val_11 != null)
        {
            goto label_12;
        }
        // 0x00D88A80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_12:
        // 0x00D88A84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88A88: MOV x0, x23                | X0 = val_11;//m1                        
        // 0x00D88A8C: BL #0xb5238c               | X0 = val_11.get_valuePer();             
        uint val_12 = val_11.valuePer;
        // 0x00D88A90: MOV w23, w0                | W23 = val_12;//m1                       
        // 0x00D88A94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88A98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88A9C: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_13 = ZMG.CSGameDataMgr;
        // 0x00D88AA0: MOV x24, x0                | X24 = val_13;//m1                       
        // 0x00D88AA4: CBNZ x24, #0xd88aac        | if (val_13 != null) goto label_13;      
        if(val_13 != null)
        {
            goto label_13;
        }
        // 0x00D88AA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_13:
        // 0x00D88AAC: LDR x24, [x24, #0x20]      | X24 = val_13.heroData; //P2             
        // 0x00D88AB0: MOV w1, w19                | W1 = key;//m1                           
        // 0x00D88AB4: BL #0xd88b7c               | X0 = val_13.EnemyToString(key:  key);   
        string val_14 = val_13.EnemyToString(key:  key);
        // 0x00D88AB8: MOV x25, x0                | X25 = val_14;//m1                       
        // 0x00D88ABC: CBNZ x24, #0xd88ac4        | if (val_13.heroData != null) goto label_14;
        if(val_13.heroData != null)
        {
            goto label_14;
        }
        // 0x00D88AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_14:
        // 0x00D88AC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D88AC8: MOV x0, x24                | X0 = val_13.heroData;//m1               
        // 0x00D88ACC: MOV x1, x25                | X1 = val_14;//m1                        
        // 0x00D88AD0: BL #0xb4cfdc               | X0 = val_13.heroData.GetReinAttUnit(key:  val_14);
        CSPlusAtt val_15 = val_13.heroData.GetReinAttUnit(key:  val_14);
        // 0x00D88AD4: MOV x24, x0                | X24 = val_15;//m1                       
        // 0x00D88AD8: CBNZ x24, #0xd88ae0        | if (val_15 != null) goto label_15;      
        if(val_15 != null)
        {
            goto label_15;
        }
        // 0x00D88ADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_15:
        // 0x00D88AE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88AE4: MOV x0, x24                | X0 = val_15;//m1                        
        // 0x00D88AE8: BL #0xb5250c               | X0 = val_15.get_value();                
        uint val_16 = val_15.value;
        // 0x00D88AEC: MOV w24, w0                | W24 = val_16;//m1                       
        // 0x00D88AF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88AF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88AF8: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_17 = ZMG.CombatValueMgr;
        // 0x00D88AFC: MOV x25, x0                | X25 = val_17;//m1                       
        // 0x00D88B00: CBNZ x25, #0xd88b08        | if (val_17 != null) goto label_16;      
        if(val_17 != null)
        {
            goto label_16;
        }
        // 0x00D88B04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_16:
        // 0x00D88B08: LDR s8, [x25, #0x18]       | S8 = val_17.value03; //P2               
        // 0x00D88B0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88B14: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_18 = ZMG.CombatValueMgr;
        // 0x00D88B18: MOV x25, x0                | X25 = val_18;//m1                       
        // 0x00D88B1C: CBNZ x25, #0xd88b24        | if (val_18 != null) goto label_17;      
        if(val_18 != null)
        {
            goto label_17;
        }
        // 0x00D88B20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_17:
        // 0x00D88B24: LDR s0, [x25, #0x10]       | S0 = val_18.value01; //P2               
        float val_20 = val_18.value01;
        // 0x00D88B28: UCVTF d2, w23              | D2 = (double)(val_12);                  
        // 0x00D88B2C: FCVT s2, d2                | S2 = (float)val_12);                    
        // 0x00D88B30: UCVTF d1, w21              | D1 = (double)(basicsAtt);               
        // 0x00D88B34: FMUL s0, s2, s0            | S0 = (val_12 * val_18.value01);         
        val_20 = (float)(double)val_12 * val_20;
        // 0x00D88B38: UCVTF d3, w24              | D3 = (double)(val_16);                  
        // 0x00D88B3C: FCVT s1, d1                | S1 = (float)basicsAtt);                 
        // 0x00D88B40: FADD s0, s8, s0            | S0 = (val_17.value03 + (val_12 * val_18.value01));
        val_20 = val_17.value03 + val_20;
        // 0x00D88B44: FMUL s0, s1, s0            | S0 = (basicsAtt * (val_17.value03 + (val_12 * val_18.value01)));
        val_20 = (float)(double)basicsAtt * val_20;
        // 0x00D88B48: FCVT s1, d3                | S1 = (float)val_16);                    
        // 0x00D88B4C: FADD s0, s1, s0            | S0 = (val_16 + (basicsAtt * (val_17.value03 + (val_12 * val_18.value01))));
        val_20 = (float)(double)val_16 + val_20;
        // 0x00D88B50: MOV x0, x20                | X0 = 1152921514687351776 (0x1000000258D84BE0);//ML01
        // 0x00D88B54: MOV w1, w19                | W1 = key;//m1                           
        // 0x00D88B58: BL #0xd87f84               | X0 = this.GetAttribute(key:  key, basicsAtt:  val_18.value01 = (float)(double)val_16 + val_18.value01);
        uint val_19 = this.GetAttribute(key:  key, basicsAtt:  val_20);
        // 0x00D88B5C: ADD w0, w0, w22            | W0 = (val_19 + val_8);                  
        val_19 = val_19 + val_8;
        // 0x00D88B60: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D88B64: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D88B68: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D88B6C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D88B70: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00D88B74: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00D88B78: RET                        |  return (System.UInt32)(val_19 + val_8);
        return (uint)val_19;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D88C0C (14191628), len: 620  VirtAddr: 0x00D88C0C RVA: 0x00D88C0C token: 100691641 methodIndex: 26008 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetEnemyAttr(HERO_ATT_KEY key, uint basicsAtt)
    {
        //
        // Disasemble & Code
        // 0x00D88C0C: STP d9, d8, [sp, #-0x60]!  | stack[1152921514687623712] = ???;  stack[1152921514687623720] = ???;  //  dest_result_addr=1152921514687623712 |  dest_result_addr=1152921514687623720
        // 0x00D88C10: STP x26, x25, [sp, #0x10]  | stack[1152921514687623728] = ???;  stack[1152921514687623736] = ???;  //  dest_result_addr=1152921514687623728 |  dest_result_addr=1152921514687623736
        // 0x00D88C14: STP x24, x23, [sp, #0x20]  | stack[1152921514687623744] = ???;  stack[1152921514687623752] = ???;  //  dest_result_addr=1152921514687623744 |  dest_result_addr=1152921514687623752
        // 0x00D88C18: STP x22, x21, [sp, #0x30]  | stack[1152921514687623760] = ???;  stack[1152921514687623768] = ???;  //  dest_result_addr=1152921514687623760 |  dest_result_addr=1152921514687623768
        // 0x00D88C1C: STP x20, x19, [sp, #0x40]  | stack[1152921514687623776] = ???;  stack[1152921514687623784] = ???;  //  dest_result_addr=1152921514687623776 |  dest_result_addr=1152921514687623784
        // 0x00D88C20: STP x29, x30, [sp, #0x50]  | stack[1152921514687623792] = ???;  stack[1152921514687623800] = ???;  //  dest_result_addr=1152921514687623792 |  dest_result_addr=1152921514687623800
        // 0x00D88C24: ADD x29, sp, #0x50         | X29 = (1152921514687623712 + 80) = 1152921514687623792 (0x1000000258DC7270);
        // 0x00D88C28: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
        // 0x00D88C2C: LDRB w8, [x22, #0x446]     | W8 = (bool)static_value_03734446;       
        // 0x00D88C30: MOV w21, w2                | W21 = basicsAtt;//m1                    
        // 0x00D88C34: MOV w19, w1                | W19 = key;//m1                          
        // 0x00D88C38: MOV x20, x0                | X20 = 1152921514687635808 (0x1000000258DCA160);//ML01
        // 0x00D88C3C: TBNZ w8, #0, #0xd88c58     | if (static_value_03734446 == true) goto label_0;
        // 0x00D88C40: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00D88C44: LDR x8, [x8, #0x190]       | X8 = 0x2B91764;                         
        // 0x00D88C48: LDR w0, [x8]               | W0 = 0x1C9E;                            
        // 0x00D88C4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C9E, ????);     
        // 0x00D88C50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D88C54: STRB w8, [x22, #0x446]     | static_value_03734446 = true;            //  dest_result_addr=57885766
        label_0:
        // 0x00D88C58: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D88C5C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D88C60: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D88C64: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D88C68: TBZ w8, #0, #0xd88c78      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D88C6C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D88C70: CBNZ w8, #0xd88c78         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D88C74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00D88C78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88C80: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_1 = ZMG.CSGameDataMgr;
        // 0x00D88C84: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00D88C88: CBNZ x22, #0xd88c90        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00D88C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D88C90: LDR x22, [x22, #0x18]      | X22 = val_1.playerData; //P2            
        // 0x00D88C94: CBNZ x22, #0xd88c9c        | if (val_1.playerData != null) goto label_4;
        if(val_1.playerData != null)
        {
            goto label_4;
        }
        // 0x00D88C98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00D88C9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88CA0: MOV x0, x22                | X0 = val_1.playerData;//m1              
        // 0x00D88CA4: BL #0xb54a1c               | X0 = val_1.playerData.GetLeaderPlusAtt();
        System.Collections.Generic.List<CSPlusAtt> val_2 = val_1.playerData.GetLeaderPlusAtt();
        // 0x00D88CA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88CAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88CB0: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_3 = ZMG.CSGameDataMgr;
        // 0x00D88CB4: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00D88CB8: CBNZ x22, #0xd88cc0        | if (val_3 != null) goto label_5;        
        if(val_3 != null)
        {
            goto label_5;
        }
        // 0x00D88CBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00D88CC0: LDR x22, [x22, #0x18]      | X22 = val_3.playerData; //P2            
        // 0x00D88CC4: CBNZ x22, #0xd88ccc        | if (val_3.playerData != null) goto label_6;
        if(val_3.playerData != null)
        {
            goto label_6;
        }
        // 0x00D88CC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00D88CCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88CD0: MOV x0, x22                | X0 = val_3.playerData;//m1              
        // 0x00D88CD4: BL #0xb54c68               | X0 = val_3.playerData.GetReinPlusAtts();
        System.Collections.Generic.List<CSPlusAtt> val_4 = val_3.playerData.GetReinPlusAtts();
        // 0x00D88CD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88CDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88CE0: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_5 = ZMG.CSGameDataMgr;
        // 0x00D88CE4: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00D88CE8: CBNZ x22, #0xd88cf0        | if (val_5 != null) goto label_7;        
        if(val_5 != null)
        {
            goto label_7;
        }
        // 0x00D88CEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00D88CF0: LDR x22, [x22, #0x18]      | X22 = val_5.playerData; //P2            
        // 0x00D88CF4: MOV w1, w19                | W1 = key;//m1                           
        // 0x00D88CF8: BL #0xd88b7c               | X0 = val_5.EnemyToString(key:  key);    
        string val_6 = val_5.EnemyToString(key:  key);
        // 0x00D88CFC: MOV x23, x0                | X23 = val_6;//m1                        
        // 0x00D88D00: CBNZ x22, #0xd88d08        | if (val_5.playerData != null) goto label_8;
        if(val_5.playerData != null)
        {
            goto label_8;
        }
        // 0x00D88D04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_8:
        // 0x00D88D08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D88D0C: MOV x0, x22                | X0 = val_5.playerData;//m1              
        // 0x00D88D10: MOV x1, x23                | X1 = val_6;//m1                         
        // 0x00D88D14: BL #0xb551b8               | X0 = val_5.playerData.GetLearerAttUnit(key:  val_6);
        CSPlusAtt val_7 = val_5.playerData.GetLearerAttUnit(key:  val_6);
        // 0x00D88D18: MOV x22, x0                | X22 = val_7;//m1                        
        // 0x00D88D1C: CBNZ x22, #0xd88d24        | if (val_7 != null) goto label_9;        
        if(val_7 != null)
        {
            goto label_9;
        }
        // 0x00D88D20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00D88D24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88D28: MOV x0, x22                | X0 = val_7;//m1                         
        // 0x00D88D2C: BL #0xb5250c               | X0 = val_7.get_value();                 
        uint val_8 = val_7.value;
        // 0x00D88D30: MOV w22, w0                | W22 = val_8;//m1                        
        // 0x00D88D34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88D38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88D3C: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_9 = ZMG.CSGameDataMgr;
        // 0x00D88D40: MOV x23, x0                | X23 = val_9;//m1                        
        // 0x00D88D44: CBNZ x23, #0xd88d4c        | if (val_9 != null) goto label_10;       
        if(val_9 != null)
        {
            goto label_10;
        }
        // 0x00D88D48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_10:
        // 0x00D88D4C: LDR x23, [x23, #0x18]      | X23 = val_9.playerData; //P2            
        // 0x00D88D50: MOV w1, w19                | W1 = key;//m1                           
        // 0x00D88D54: BL #0xd88b7c               | X0 = val_9.EnemyToString(key:  key);    
        string val_10 = val_9.EnemyToString(key:  key);
        // 0x00D88D58: MOV x24, x0                | X24 = val_10;//m1                       
        // 0x00D88D5C: CBNZ x23, #0xd88d64        | if (val_9.playerData != null) goto label_11;
        if(val_9.playerData != null)
        {
            goto label_11;
        }
        // 0x00D88D60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_11:
        // 0x00D88D64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D88D68: MOV x0, x23                | X0 = val_9.playerData;//m1              
        // 0x00D88D6C: MOV x1, x24                | X1 = val_10;//m1                        
        // 0x00D88D70: BL #0xb551b8               | X0 = val_9.playerData.GetLearerAttUnit(key:  val_10);
        CSPlusAtt val_11 = val_9.playerData.GetLearerAttUnit(key:  val_10);
        // 0x00D88D74: MOV x23, x0                | X23 = val_11;//m1                       
        // 0x00D88D78: CBNZ x23, #0xd88d80        | if (val_11 != null) goto label_12;      
        if(val_11 != null)
        {
            goto label_12;
        }
        // 0x00D88D7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_12:
        // 0x00D88D80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88D84: MOV x0, x23                | X0 = val_11;//m1                        
        // 0x00D88D88: BL #0xb5238c               | X0 = val_11.get_valuePer();             
        uint val_12 = val_11.valuePer;
        // 0x00D88D8C: MOV w23, w0                | W23 = val_12;//m1                       
        // 0x00D88D90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88D94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88D98: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_13 = ZMG.CSGameDataMgr;
        // 0x00D88D9C: MOV x24, x0                | X24 = val_13;//m1                       
        // 0x00D88DA0: CBNZ x24, #0xd88da8        | if (val_13 != null) goto label_13;      
        if(val_13 != null)
        {
            goto label_13;
        }
        // 0x00D88DA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_13:
        // 0x00D88DA8: LDR x24, [x24, #0x18]      | X24 = val_13.playerData; //P2           
        // 0x00D88DAC: MOV w1, w19                | W1 = key;//m1                           
        // 0x00D88DB0: BL #0xd88b7c               | X0 = val_13.EnemyToString(key:  key);   
        string val_14 = val_13.EnemyToString(key:  key);
        // 0x00D88DB4: MOV x25, x0                | X25 = val_14;//m1                       
        // 0x00D88DB8: CBNZ x24, #0xd88dc0        | if (val_13.playerData != null) goto label_14;
        if(val_13.playerData != null)
        {
            goto label_14;
        }
        // 0x00D88DBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_14:
        // 0x00D88DC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D88DC4: MOV x0, x24                | X0 = val_13.playerData;//m1             
        // 0x00D88DC8: MOV x1, x25                | X1 = val_14;//m1                        
        // 0x00D88DCC: BL #0xb55280               | X0 = val_13.playerData.GetReinAttUnit(key:  val_14);
        CSPlusAtt val_15 = val_13.playerData.GetReinAttUnit(key:  val_14);
        // 0x00D88DD0: MOV x24, x0                | X24 = val_15;//m1                       
        // 0x00D88DD4: CBNZ x24, #0xd88ddc        | if (val_15 != null) goto label_15;      
        if(val_15 != null)
        {
            goto label_15;
        }
        // 0x00D88DD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_15:
        // 0x00D88DDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88DE0: MOV x0, x24                | X0 = val_15;//m1                        
        // 0x00D88DE4: BL #0xb5250c               | X0 = val_15.get_value();                
        uint val_16 = val_15.value;
        // 0x00D88DE8: MOV w24, w0                | W24 = val_16;//m1                       
        // 0x00D88DEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88DF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88DF4: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_17 = ZMG.CombatValueMgr;
        // 0x00D88DF8: MOV x25, x0                | X25 = val_17;//m1                       
        // 0x00D88DFC: CBNZ x25, #0xd88e04        | if (val_17 != null) goto label_16;      
        if(val_17 != null)
        {
            goto label_16;
        }
        // 0x00D88E00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_16:
        // 0x00D88E04: LDR s8, [x25, #0x18]       | S8 = val_17.value03; //P2               
        // 0x00D88E08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D88E0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D88E10: BL #0x26a8a70              | X0 = ZMG.get_CombatValueMgr();          
        CombatValueMgr val_18 = ZMG.CombatValueMgr;
        // 0x00D88E14: MOV x25, x0                | X25 = val_18;//m1                       
        // 0x00D88E18: CBNZ x25, #0xd88e20        | if (val_18 != null) goto label_17;      
        if(val_18 != null)
        {
            goto label_17;
        }
        // 0x00D88E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_17:
        // 0x00D88E20: LDR s0, [x25, #0x10]       | S0 = val_18.value01; //P2               
        float val_20 = val_18.value01;
        // 0x00D88E24: UCVTF d2, w23              | D2 = (double)(val_12);                  
        // 0x00D88E28: FCVT s2, d2                | S2 = (float)val_12);                    
        // 0x00D88E2C: UCVTF d1, w21              | D1 = (double)(basicsAtt);               
        // 0x00D88E30: FMUL s0, s2, s0            | S0 = (val_12 * val_18.value01);         
        val_20 = (float)(double)val_12 * val_20;
        // 0x00D88E34: UCVTF d3, w24              | D3 = (double)(val_16);                  
        // 0x00D88E38: FCVT s1, d1                | S1 = (float)basicsAtt);                 
        // 0x00D88E3C: FADD s0, s8, s0            | S0 = (val_17.value03 + (val_12 * val_18.value01));
        val_20 = val_17.value03 + val_20;
        // 0x00D88E40: FMUL s0, s1, s0            | S0 = (basicsAtt * (val_17.value03 + (val_12 * val_18.value01)));
        val_20 = (float)(double)basicsAtt * val_20;
        // 0x00D88E44: FCVT s1, d3                | S1 = (float)val_16);                    
        // 0x00D88E48: FADD s0, s1, s0            | S0 = (val_16 + (basicsAtt * (val_17.value03 + (val_12 * val_18.value01))));
        val_20 = (float)(double)val_16 + val_20;
        // 0x00D88E4C: MOV x0, x20                | X0 = 1152921514687635808 (0x1000000258DCA160);//ML01
        // 0x00D88E50: MOV w1, w19                | W1 = key;//m1                           
        // 0x00D88E54: BL #0xd87f84               | X0 = this.GetAttribute(key:  key, basicsAtt:  val_18.value01 = (float)(double)val_16 + val_18.value01);
        uint val_19 = this.GetAttribute(key:  key, basicsAtt:  val_20);
        // 0x00D88E58: ADD w0, w0, w22            | W0 = (val_19 + val_8);                  
        val_19 = val_19 + val_8;
        // 0x00D88E5C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D88E60: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D88E64: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D88E68: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D88E6C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00D88E70: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00D88E74: RET                        |  return (System.UInt32)(val_19 + val_8);
        return (uint)val_19;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D88B7C (14191484), len: 144  VirtAddr: 0x00D88B7C RVA: 0x00D88B7C token: 100691642 methodIndex: 26009 delegateWrapperIndex: 0 methodInvoker: 0
    public string EnemyToString(HERO_ATT_KEY key)
    {
        //
        // Disasemble & Code
        // 0x00D88B7C: STP x20, x19, [sp, #-0x20]! | stack[1152921514687834080] = ???;  stack[1152921514687834088] = ???;  //  dest_result_addr=1152921514687834080 |  dest_result_addr=1152921514687834088
        // 0x00D88B80: STP x29, x30, [sp, #0x10]  | stack[1152921514687834096] = ???;  stack[1152921514687834104] = ???;  //  dest_result_addr=1152921514687834096 |  dest_result_addr=1152921514687834104
        // 0x00D88B84: ADD x29, sp, #0x10         | X29 = (1152921514687834080 + 16) = 1152921514687834096 (0x1000000258DFA7F0);
        // 0x00D88B88: SUB sp, sp, #0x10          | SP = (1152921514687834080 - 16) = 1152921514687834064 (0x1000000258DFA7D0);
        // 0x00D88B8C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
        // 0x00D88B90: LDRB w8, [x19, #0x447]     | W8 = (bool)static_value_03734447;       
        // 0x00D88B94: STR w1, [sp, #0xc]         | stack[1152921514687834076] = key;        //  dest_result_addr=1152921514687834076
        // 0x00D88B98: TBNZ w8, #0, #0xd88bb4     | if (static_value_03734447 == true) goto label_0;
        // 0x00D88B9C: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00D88BA0: LDR x8, [x8, #0xe10]       | X8 = 0x2B9175C;                         
        // 0x00D88BA4: LDR w0, [x8]               | W0 = 0x1C9C;                            
        // 0x00D88BA8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C9C, ????);     
        // 0x00D88BAC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D88BB0: STRB w8, [x19, #0x447]     | static_value_03734447 = true;            //  dest_result_addr=57885767
        label_0:
        // 0x00D88BB4: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00D88BB8: LDR x8, [x8, #0xbc8]       | X8 = 1152921504894013440;               
        // 0x00D88BBC: ADD x1, sp, #0xc           | X1 = (1152921514687834064 + 12) = 1152921514687834076 (0x1000000258DFA7DC);
        // 0x00D88BC0: LDR x0, [x8]               | X0 = typeof(HERO_ATT_KEY);              
        // 0x00D88BC4: BL #0x27bc028              | X0 = 1152921514687882208 = (Il2CppObject*)Box((RuntimeClass*)typeof(HERO_ATT_KEY), key);
        // 0x00D88BC8: MOV x19, x0                | X19 = 1152921514687882208 (0x1000000258E063E0);//ML01
        // 0x00D88BCC: CBNZ x19, #0xd88bd4        | if (key != 0) goto label_1;             
        if(key != 0)
        {
            goto label_1;
        }
        // 0x00D88BD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? key, ????);        
        label_1:
        // 0x00D88BD4: LDR x8, [x19]              | X8 = typeof(HERO_ATT_KEY);              
        // 0x00D88BD8: MOV x0, x19                | X0 = 1152921514687882208 (0x1000000258E063E0);//ML01
        // 0x00D88BDC: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x00D88BE0: BLR x9                     | X0 = key.ToString();                    
        string val_1 = key.ToString();
        // 0x00D88BE4: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D88BE8: CBNZ x19, #0xd88bf0        | if (key != 0) goto label_2;             
        if(key != 0)
        {
            goto label_2;
        }
        // 0x00D88BEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00D88BF0: MOV x0, x19                | X0 = 1152921514687882208 (0x1000000258E063E0);//ML01
        // 0x00D88BF4: BL #0x27bc4e8              | key.System.IDisposable.Dispose();       
        key.System.IDisposable.Dispose();
        // 0x00D88BF8: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00D88BFC: SUB sp, x29, #0x10         | SP = (1152921514687834096 - 16) = 1152921514687834080 (0x1000000258DFA7E0);
        // 0x00D88C00: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D88C04: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D88C08: RET                        |  return (System.String)val_1;           
        return (string)val_1;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D88E78 (14192248), len: 40  VirtAddr: 0x00D88E78 RVA: 0x00D88E78 token: 100691643 methodIndex: 26010 delegateWrapperIndex: 0 methodInvoker: 0
    public void Clear()
    {
        //
        // Disasemble & Code
        // 0x00D88E78: STP x20, x19, [sp, #-0x20]! | stack[1152921514687962464] = ???;  stack[1152921514687962472] = ???;  //  dest_result_addr=1152921514687962464 |  dest_result_addr=1152921514687962472
        // 0x00D88E7C: STP x29, x30, [sp, #0x10]  | stack[1152921514687962480] = ???;  stack[1152921514687962488] = ???;  //  dest_result_addr=1152921514687962480 |  dest_result_addr=1152921514687962488
        // 0x00D88E80: ADD x29, sp, #0x10         | X29 = (1152921514687962464 + 16) = 1152921514687962480 (0x1000000258E19D70);
        // 0x00D88E84: LDR x19, [x0, #0x10]       | X19 = this.plusAtt; //P2                
        // 0x00D88E88: CBNZ x19, #0xd88e90        | if (this.plusAtt != null) goto label_0; 
        if(this.plusAtt != null)
        {
            goto label_0;
        }
        // 0x00D88E8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00D88E90: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D88E94: MOV x0, x19                | X0 = this.plusAtt;//m1                  
        // 0x00D88E98: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D88E9C: B #0xd88ea0                | this.plusAtt.Clear(); return;           
        this.plusAtt.Clear();
        return;
    
    }

}
