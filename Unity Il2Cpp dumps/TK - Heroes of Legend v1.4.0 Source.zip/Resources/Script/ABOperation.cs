using UnityEngine;

namespace Mihua.Asset.ABLoadOperation
{
    public abstract class ABOperation : IEnumerator
    {
        // Fields
        protected bool isCacheAsset; //  0x00000010
        
        // Properties
        public object Current { get; }
        public abstract float progress { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AAF678 (11204216), len: 8  VirtAddr: 0x00AAF678 RVA: 0x00AAF678 token: 100693139 methodIndex: 46896 delegateWrapperIndex: 0 methodInvoker: 0
        protected ABOperation()
        {
            //
            // Disasemble & Code
            // 0x00AAF678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAF67C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAF680 (11204224), len: 8  VirtAddr: 0x00AAF680 RVA: 0x00AAF680 token: 100693140 methodIndex: 46897 delegateWrapperIndex: 0 methodInvoker: 0
        public object get_Current()
        {
            //
            // Disasemble & Code
            // 0x00AAF680: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AAF684: RET                        |  return (System.Object)null;            
            return (object)0;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAF688 (11204232), len: 36  VirtAddr: 0x00AAF688 RVA: 0x00AAF688 token: 100693141 methodIndex: 46898 delegateWrapperIndex: 0 methodInvoker: 0
        public bool MoveNext()
        {
            //
            // Disasemble & Code
            // 0x00AAF688: STP x29, x30, [sp, #-0x10]! | stack[1152921514945017216] = ???;  stack[1152921514945017224] = ???;  //  dest_result_addr=1152921514945017216 |  dest_result_addr=1152921514945017224
            // 0x00AAF68C: MOV x29, sp                | X29 = 1152921514945017216 (0x100000026833F580);//ML01
            // 0x00AAF690: LDR x8, [x0]               | X8 = typeof(Mihua.Asset.ABLoadOperation.ABOperation);
            // 0x00AAF694: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(Mihua.Asset.ABLoadOperation.ABOperation).__il2cppRuntimeField_1B0; X1 = typeof(Mihua.Asset.ABLoadOperation.ABOperation).__il2cppRuntimeField_1B8; //  | 
            // 0x00AAF698: BLR x9                     | X0 = typeof(Mihua.Asset.ABLoadOperation.ABOperation).__il2cppRuntimeField_1B0();
            // 0x00AAF69C: MVN w8, w0                 | W8 = 1152921514945029232 (0x1000000268342470);//ML01
            // 0x00AAF6A0: AND w0, w8, #1             | W0 = (this & 1) = 0 (0x00000000);       
            // 0x00AAF6A4: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x00AAF6A8: RET                        |  return (System.Boolean)(Mihua.Asset.ABLoadOperation.ABOperation)[1152921514945029232];
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAF6AC (11204268), len: 4  VirtAddr: 0x00AAF6AC RVA: 0x00AAF6AC token: 100693142 methodIndex: 46899 delegateWrapperIndex: 0 methodInvoker: 0
        public void Reset()
        {
            //
            // Disasemble & Code
            // 0x00AAF6AC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAF6B0 (11204272), len: 4  VirtAddr: 0x00AAF6B0 RVA: 0x00AAF6B0 token: 100693143 methodIndex: 46900 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void CacheAsset()
        {
            //
            // Disasemble & Code
            // 0x00AAF6B0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAF6B4 (11204276), len: 4  VirtAddr: 0x00AAF6B4 RVA: 0x00AAF6B4 token: 100693144 methodIndex: 46901 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void ClearOnLoad()
        {
            //
            // Disasemble & Code
            // 0x00AAF6B4: RET                        |  return;                                
            return;
        
        }
        public abstract bool Update(); // 0
        public abstract bool IsDone(); // 0
        public abstract float get_progress(); // 0
        public abstract void Clear(); // 0
    
    }

}
