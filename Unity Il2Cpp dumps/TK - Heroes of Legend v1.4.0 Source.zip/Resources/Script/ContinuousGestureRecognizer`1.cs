using UnityEngine;
public abstract class ContinuousGestureRecognizer<T> : GestureRecognizerTS<T>
{
    // Methods
    // Generic instance method:
    //
    // file offset: 0x019CCB50 VirtAddr: 0x019CCB50 -RVA: 0x019CCB50 
    // -ContinuousGestureRecognizer<object>..ctor
    // -ContinuousGestureRecognizer<DragGesture>..ctor
    // -ContinuousGestureRecognizer<PinchGesture>..ctor
    // -ContinuousGestureRecognizer<TwistGesture>..ctor
    //
    //
    // Offset in libil2cpp.so: 0x019CCB50 (27052880), len: 152  VirtAddr: 0x019CCB50 RVA: 0x019CCB50 token: 100683820 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    protected ContinuousGestureRecognizer<T>()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x019CCB50: STP x22, x21, [sp, #-0x30]! | stack[1152921513556357792] = ???;  stack[1152921513556357800] = ???;  //  dest_result_addr=1152921513556357792 |  dest_result_addr=1152921513556357800
        // 0x019CCB54: STP x20, x19, [sp, #0x10]  | stack[1152921513556357808] = ???;  stack[1152921513556357816] = ???;  //  dest_result_addr=1152921513556357808 |  dest_result_addr=1152921513556357816
        // 0x019CCB58: STP x29, x30, [sp, #0x20]  | stack[1152921513556357824] = ???;  stack[1152921513556357832] = ???;  //  dest_result_addr=1152921513556357824 |  dest_result_addr=1152921513556357832
        // 0x019CCB5C: ADD x29, sp, #0x20         | X29 = (1152921513556357792 + 32) = 1152921513556357824 (0x10000002156EB2C0);
        // 0x019CCB60: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x019CCB64: MOV x20, x0                | X20 = 1152921513556369840 (0x10000002156EE1B0);//ML01
        // 0x019CCB68: CBNZ x20, #0x19ccb70       | if (this != null) goto label_0;         
        if(this != null)
        {
            goto label_0;
        }
        // 0x019CCB6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x019CCB70: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019CCB74: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCB78: LDR x21, [x8, #8]          | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
        val_1 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 8];
        val_1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
        // 0x019CCB7C: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
        // 0x019CCB80: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
        // 0x019CCB84: LDRB w8, [x21, #0x10a]     | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 8 + 266;
        // 0x019CCB88: TBZ w8, #0, #0x19ccbc4     | if ((__RuntimeMethodHiddenParam + 24 + 168 + 8 + 266 & 0x1) == 0) goto label_2;
        if(((__RuntimeMethodHiddenParam + 24 + 168 + 8 + 266) & 1) == 0)
        {
            goto label_2;
        }
        // 0x019CCB8C: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019CCB90: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCB94: LDR x21, [x8, #8]          | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
        val_1 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 8];
        val_1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
        // 0x019CCB98: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
        // 0x019CCB9C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
        // 0x019CCBA0: LDR w8, [x21, #0xbc]       | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 8 + 188;
        // 0x019CCBA4: CBNZ w8, #0x19ccbc4        | if (__RuntimeMethodHiddenParam + 24 + 168 + 8 + 188 != 0) goto label_2;
        if((__RuntimeMethodHiddenParam + 24 + 168 + 8 + 188) != 0)
        {
            goto label_2;
        }
        // 0x019CCBA8: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019CCBAC: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCBB0: LDR x21, [x8, #8]          | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
        val_1 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 8];
        val_1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
        // 0x019CCBB4: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
        // 0x019CCBB8: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
        // 0x019CCBBC: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
        // 0x019CCBC0: BL #0x27977a4              | X0 = sub_27977A4( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
        label_2:
        // 0x019CCBC4: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019CCBC8: MOV x0, x20                | X0 = 1152921513556369840 (0x10000002156EE1B0);//ML01
        // 0x019CCBCC: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCBD0: LDR x1, [x8]               | X1 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCBD4: LDR x2, [x1]               | X2 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCBD8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x019CCBDC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x019CCBE0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x019CCBE4: BR x2                      | goto __RuntimeMethodHiddenParam + 24 + 168;
        goto __RuntimeMethodHiddenParam + 24 + 168;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019CCBE8 VirtAddr: 0x019CCBE8 -RVA: 0x019CCBE8 
    // -ContinuousGestureRecognizer<object>.Reset
    // -ContinuousGestureRecognizer<TwistGesture>.Reset
    // -ContinuousGestureRecognizer<DragGesture>.Reset
    // -ContinuousGestureRecognizer<PinchGesture>.Reset
    //
    //
    // Offset in libil2cpp.so: 0x019CCBE8 (27053032), len: 76  VirtAddr: 0x019CCBE8 RVA: 0x019CCBE8 token: 100683821 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void Reset(T gesture)
    {
        //
        // Disasemble & Code
        // 0x019CCBE8: STP x22, x21, [sp, #-0x30]! | stack[1152921513556473888] = ???;  stack[1152921513556473896] = ???;  //  dest_result_addr=1152921513556473888 |  dest_result_addr=1152921513556473896
        // 0x019CCBEC: STP x20, x19, [sp, #0x10]  | stack[1152921513556473904] = ???;  stack[1152921513556473912] = ???;  //  dest_result_addr=1152921513556473904 |  dest_result_addr=1152921513556473912
        // 0x019CCBF0: STP x29, x30, [sp, #0x20]  | stack[1152921513556473920] = ???;  stack[1152921513556473928] = ???;  //  dest_result_addr=1152921513556473920 |  dest_result_addr=1152921513556473928
        // 0x019CCBF4: ADD x29, sp, #0x20         | X29 = (1152921513556473888 + 32) = 1152921513556473920 (0x1000000215707840);
        // 0x019CCBF8: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
        // 0x019CCBFC: MOV x19, x1                | X19 = gesture;//m1                      
        // 0x019CCC00: MOV x20, x0                | X20 = 1152921513556485936 (0x100000021570A730);//ML01
        // 0x019CCC04: CBNZ x20, #0x19ccc0c       | if (this != null) goto label_0;         
        if(this != null)
        {
            goto label_0;
        }
        // 0x019CCC08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x019CCC0C: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019CCC10: MOV x0, x20                | X0 = 1152921513556485936 (0x100000021570A730);//ML01
        // 0x019CCC14: MOV x1, x19                | X1 = gesture;//m1                       
        // 0x019CCC18: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCC1C: LDR x2, [x8, #0x10]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
        // 0x019CCC20: LDR x3, [x2]               | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
        // 0x019CCC24: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x019CCC28: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x019CCC2C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x019CCC30: BR x3                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 16;
        goto __RuntimeMethodHiddenParam + 24 + 168 + 16;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019CCC34 VirtAddr: 0x019CCC34 -RVA: 0x019CCC34 
    // -ContinuousGestureRecognizer<object>.OnStateChanged
    // -ContinuousGestureRecognizer<DragGesture>.OnStateChanged
    // -ContinuousGestureRecognizer<PinchGesture>.OnStateChanged
    // -ContinuousGestureRecognizer<TwistGesture>.OnStateChanged
    //
    //
    // Offset in libil2cpp.so: 0x019CCC34 (27053108), len: 332  VirtAddr: 0x019CCC34 RVA: 0x019CCC34 token: 100683822 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void OnStateChanged(Gesture sender)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        // 0x019CCC34: STP x24, x23, [sp, #-0x40]! | stack[1152921513556602256] = ???;  stack[1152921513556602264] = ???;  //  dest_result_addr=1152921513556602256 |  dest_result_addr=1152921513556602264
        // 0x019CCC38: STP x22, x21, [sp, #0x10]  | stack[1152921513556602272] = ???;  stack[1152921513556602280] = ???;  //  dest_result_addr=1152921513556602272 |  dest_result_addr=1152921513556602280
        // 0x019CCC3C: STP x20, x19, [sp, #0x20]  | stack[1152921513556602288] = ???;  stack[1152921513556602296] = ???;  //  dest_result_addr=1152921513556602288 |  dest_result_addr=1152921513556602296
        // 0x019CCC40: STP x29, x30, [sp, #0x30]  | stack[1152921513556602304] = ???;  stack[1152921513556602312] = ???;  //  dest_result_addr=1152921513556602304 |  dest_result_addr=1152921513556602312
        // 0x019CCC44: ADD x29, sp, #0x30         | X29 = (1152921513556602256 + 48) = 1152921513556602304 (0x1000000215726DC0);
        // 0x019CCC48: SUB sp, sp, #0x10          | SP = (1152921513556602256 - 16) = 1152921513556602240 (0x1000000215726D80);
        // 0x019CCC4C: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
        // 0x019CCC50: MOV x21, x1                | X21 = sender;//m1                       
        // 0x019CCC54: MOV x19, x0                | X19 = 1152921513556614320 (0x1000000215729CB0);//ML01
        // 0x019CCC58: CBNZ x19, #0x19ccc60       | if (this != null) goto label_0;         
        if(this != null)
        {
            goto label_0;
        }
        // 0x019CCC5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x019CCC60: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019CCC64: MOV x0, x19                | X0 = 1152921513556614320 (0x1000000215729CB0);//ML01
        // 0x019CCC68: MOV x1, x21                | X1 = sender;//m1                        
        // 0x019CCC6C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCC70: LDR x2, [x8, #0x18]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
        // 0x019CCC74: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
        // 0x019CCC78: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24();
        // 0x019CCC7C: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019CCC80: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCC84: LDR x23, [x8, #0x20]       | X23 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
        // 0x019CCC88: MOV x0, x23                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 32;//m1
        // 0x019CCC8C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 32, ????);
        // 0x019CCC90: CBZ x21, #0x19ccce0        | if (sender == null) goto label_1;       
        if(sender == null)
        {
            goto label_1;
        }
        // 0x019CCC94: MOV x0, x21                | X0 = sender;//m1                        
        // 0x019CCC98: MOV x1, x23                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 32;//m1
        // 0x019CCC9C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? sender, ????);     
        // 0x019CCCA0: MOV x22, x0                | X22 = sender;//m1                       
        val_4 = sender;
        // 0x019CCCA4: CBZ x22, #0x19cccb4        | if (sender == null) goto label_2;       
        if(val_4 == null)
        {
            goto label_2;
        }
        // 0x019CCCA8: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x019CCCAC: MOV x21, x22               | X21 = sender;//m1                       
        val_6 = val_4;
        // 0x019CCCB0: B #0x19cccf0               |  goto label_3;                          
        goto label_3;
        label_2:
        // 0x019CCCB4: LDR x8, [x21]              | X8 = typeof(Gesture);                   
        // 0x019CCCB8: MOV x1, x23                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 32;//m1
        // 0x019CCCBC: LDR x0, [x8, #0x30]        | X0 = Gesture.__il2cppRuntimeField_element_class;
        // 0x019CCCC0: ADD x8, sp, #8             | X8 = (1152921513556602240 + 8) = 1152921513556602248 (0x1000000215726D88);
        // 0x019CCCC4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Gesture.__il2cppRuntimeField_element_class, ????);
        // 0x019CCCC8: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513556590320]
        // 0x019CCCCC: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
        // 0x019CCCD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019CCCD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x019CCCD8: ADD x0, sp, #8             | X0 = (1152921513556602240 + 8) = 1152921513556602248 (0x1000000215726D88);
        // 0x019CCCDC: BL #0x299a140              | 
        label_1:
        // 0x019CCCE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000215726D88, ????);
        // 0x019CCCE4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_4 = 0;
        // 0x019CCCE8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_6 = 0;
        // 0x019CCCEC: ORR w23, wzr, #1           | W23 = 1(0x1);                           
        val_5 = 1;
        label_3:
        // 0x019CCCF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019CCCF4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
        // 0x019CCCF8: BL #0x287d708              | X0 = val_4.get_State();                 
        GestureRecognitionState val_2 = val_4.State;
        // 0x019CCCFC: CMP w0, #4                 | STATE = COMPARE(val_2, 0x4)             
        // 0x019CCD00: B.EQ #0x19ccd30            | if (val_2 == 0x4) goto label_7;         
        if(val_2 == 4)
        {
            goto label_7;
        }
        // 0x019CCD04: CMP w0, #3                 | STATE = COMPARE(val_2, 0x3)             
        // 0x019CCD08: B.EQ #0x19ccd18            | if (val_2 == 0x3) goto label_5;         
        if(val_2 == 3)
        {
            goto label_5;
        }
        // 0x019CCD0C: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
        // 0x019CCD10: B.NE #0x19ccd54            | if (val_2 != 0x1) goto label_9;         
        if(val_2 != 1)
        {
            goto label_9;
        }
        // 0x019CCD14: B #0x19ccd30               |  goto label_7;                          
        goto label_7;
        label_5:
        // 0x019CCD18: CBZ w23, #0x19ccd20        | if (0x1 == 0) goto label_8;             
        if(val_5 == 0)
        {
            goto label_8;
        }
        // 0x019CCD1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x019CCD20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019CCD24: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
        // 0x019CCD28: BL #0x287dad4              | X0 = val_4.get_PreviousState();         
        GestureRecognitionState val_3 = val_4.PreviousState;
        // 0x019CCD2C: CBZ w0, #0x19ccd54         | if (val_3 == 0) goto label_9;           
        if(val_3 == 0)
        {
            goto label_9;
        }
        label_7:
        // 0x019CCD30: CBNZ x19, #0x19ccd38       | if (this != null) goto label_10;        
        if(this != null)
        {
            goto label_10;
        }
        // 0x019CCD34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_10:
        // 0x019CCD38: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019CCD3C: MOV x0, x19                | X0 = 1152921513556614320 (0x1000000215729CB0);//ML01
        // 0x019CCD40: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
        // 0x019CCD44: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019CCD48: LDR x2, [x8, #0x28]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 40;
        // 0x019CCD4C: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 40;
        // 0x019CCD50: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 40();
        label_9:
        // 0x019CCD54: SUB sp, x29, #0x30         | SP = (1152921513556602304 - 48) = 1152921513556602256 (0x1000000215726D90);
        // 0x019CCD58: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x019CCD5C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x019CCD60: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x019CCD64: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x019CCD68: RET                        |  return;                                
        return;
        // 0x019CCD6C: MOV x19, x0                | 
        // 0x019CCD70: ADD x0, sp, #8             | 
        // 0x019CCD74: BL #0x299a140              | 
        // 0x019CCD78: MOV x0, x19                | 
        // 0x019CCD7C: BL #0x980800               | 
    
    }

}
