using UnityEngine;

namespace Newtonsoft.Json.Serialization
{
    internal static class CachedAttributeGetter<T>
    {
        // Fields
        private static readonly Newtonsoft.Json.Utilities.ThreadSafeStore<System.Reflection.ICustomAttributeProvider, T> TypeAttributeCache; // static_offset: 0x00000000
        private static System.Func<System.Reflection.ICustomAttributeProvider, T> <>f__mg$cache0; // static_offset: 0x00000000
        
        // Methods
        // Generic instance method:
        //
        // file offset: 0x019E7BD4 VirtAddr: 0x019E7BD4 -RVA: 0x019E7BD4 
        // -CachedAttributeGetter<object>.GetAttribute
        // -CachedAttributeGetter<Newtonsoft.Json.JsonContainerAttribute>.GetAttribute
        // -CachedAttributeGetter<System.Runtime.Serialization.DataContractAttribute>.GetAttribute
        // -CachedAttributeGetter<System.Runtime.Serialization.DataMemberAttribute>.GetAttribute
        //
        //
        // Offset in libil2cpp.so: 0x019E7BD4 (27163604), len: 260  VirtAddr: 0x019E7BD4 RVA: 0x019E7BD4 token: 100686152 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static T GetAttribute(System.Reflection.ICustomAttributeProvider type)
        {
            //
            // Disasemble & Code
            // 0x019E7BD4: STP x22, x21, [sp, #-0x30]! | stack[1152921513906990320] = ???;  stack[1152921513906990328] = ???;  //  dest_result_addr=1152921513906990320 |  dest_result_addr=1152921513906990328
            // 0x019E7BD8: STP x20, x19, [sp, #0x10]  | stack[1152921513906990336] = ???;  stack[1152921513906990344] = ???;  //  dest_result_addr=1152921513906990336 |  dest_result_addr=1152921513906990344
            // 0x019E7BDC: STP x29, x30, [sp, #0x20]  | stack[1152921513906990352] = ???;  stack[1152921513906990360] = ???;  //  dest_result_addr=1152921513906990352 |  dest_result_addr=1152921513906990360
            // 0x019E7BE0: ADD x29, sp, #0x20         | X29 = (1152921513906990320 + 32) = 1152921513906990352 (0x100000022A54ED10);
            // 0x019E7BE4: SUB sp, sp, #0x10          | SP = (1152921513906990320 - 16) = 1152921513906990304 (0x100000022A54ECE0);
            // 0x019E7BE8: MOV x20, x2                | X20 = X2;//m1                           
            // 0x019E7BEC: LDR x21, [x20, #0x18]      | X21 = X2 + 24;                          
            // 0x019E7BF0: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E7BF4: MOV x0, x21                | X0 = X2 + 24;//m1                       
            // 0x019E7BF8: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019E7BFC: LDR x8, [x21, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019E7C00: LDR x21, [x8]              | X21 = X2 + 24 + 168;                    
            // 0x019E7C04: MOV x0, x21                | X0 = X2 + 24 + 168;//m1                 
            // 0x019E7C08: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24 + 168, ????);
            // 0x019E7C0C: LDRB w8, [x21, #0x10a]     | W8 = X2 + 24 + 168 + 266;               
            // 0x019E7C10: TBZ w8, #0, #0x19e7c5c     | if ((X2 + 24 + 168 + 266 & 0x1) == 0) goto label_1;
            if(((X2 + 24 + 168 + 266) & 1) == 0)
            {
                goto label_1;
            }
            // 0x019E7C14: LDR x21, [x20, #0x18]      | X21 = X2 + 24;                          
            // 0x019E7C18: MOV x0, x21                | X0 = X2 + 24;//m1                       
            // 0x019E7C1C: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019E7C20: LDR x8, [x21, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019E7C24: LDR x21, [x8]              | X21 = X2 + 24 + 168;                    
            // 0x019E7C28: MOV x0, x21                | X0 = X2 + 24 + 168;//m1                 
            // 0x019E7C2C: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24 + 168, ????);
            // 0x019E7C30: LDR w8, [x21, #0xbc]       | W8 = X2 + 24 + 168 + 188;               
            // 0x019E7C34: CBNZ w8, #0x19e7c5c        | if (X2 + 24 + 168 + 188 != 0) goto label_1;
            if((X2 + 24 + 168 + 188) != 0)
            {
                goto label_1;
            }
            // 0x019E7C38: LDR x21, [x20, #0x18]      | X21 = X2 + 24;                          
            // 0x019E7C3C: MOV x0, x21                | X0 = X2 + 24;//m1                       
            // 0x019E7C40: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019E7C44: LDR x8, [x21, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019E7C48: LDR x21, [x8]              | X21 = X2 + 24 + 168;                    
            // 0x019E7C4C: MOV x0, x21                | X0 = X2 + 24 + 168;//m1                 
            // 0x019E7C50: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24 + 168, ????);
            // 0x019E7C54: MOV x0, x21                | X0 = X2 + 24 + 168;//m1                 
            // 0x019E7C58: BL #0x27977a4              | X0 = sub_27977A4( ?? X2 + 24 + 168, ????);
            label_1:
            // 0x019E7C5C: LDR x21, [x20, #0x18]      | X21 = X2 + 24;                          
            // 0x019E7C60: MOV x0, x21                | X0 = X2 + 24;//m1                       
            // 0x019E7C64: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019E7C68: LDR x8, [x21, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019E7C6C: LDR x21, [x8]              | X21 = X2 + 24 + 168;                    
            // 0x019E7C70: MOV x0, x21                | X0 = X2 + 24 + 168;//m1                 
            // 0x019E7C74: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24 + 168, ????);
            // 0x019E7C78: LDR x8, [x21, #0xa0]       | X8 = X2 + 24 + 168 + 160;               
            // 0x019E7C7C: LDR x21, [x8]              | X21 = X2 + 24 + 168 + 160;              
            // 0x019E7C80: CBNZ x21, #0x19e7c88       | if (X2 + 24 + 168 + 160 != 0) goto label_2;
            if((X2 + 24 + 168 + 160) != 0)
            {
                goto label_2;
            }
            // 0x019E7C84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2 + 24 + 168, ????);
            label_2:
            // 0x019E7C88: LDR x22, [x20, #0x18]      | X22 = X2 + 24;                          
            // 0x019E7C8C: MOV x0, x22                | X0 = X2 + 24;//m1                       
            // 0x019E7C90: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019E7C94: LDR x8, [x22, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019E7C98: LDR x8, [x8, #8]           | X8 = X2 + 24 + 168 + 8;                 
            // 0x019E7C9C: LDR x0, [x8]               | X0 = X2 + 24 + 168 + 8;                 
            // 0x019E7CA0: STR x0, [sp, #8]           | stack[1152921513906990312] = X2 + 24 + 168 + 8;  //  dest_result_addr=1152921513906990312
            // 0x019E7CA4: LDR x20, [x20, #0x18]      | X20 = X2 + 24;                          
            // 0x019E7CA8: MOV x0, x20                | X0 = X2 + 24;//m1                       
            // 0x019E7CAC: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019E7CB0: LDR x8, [x20, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019E7CB4: LDR x3, [sp, #8]           | X3 = X2 + 24 + 168 + 8;                 
            // 0x019E7CB8: MOV x0, x21                | X0 = X2 + 24 + 168 + 160;//m1           
            // 0x019E7CBC: MOV x1, x19                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x019E7CC0: LDR x2, [x8, #8]           | X2 = X2 + 24 + 168 + 8;                 
            // 0x019E7CC4: SUB sp, x29, #0x20         | SP = (1152921513906990352 - 32) = 1152921513906990320 (0x100000022A54ECF0);
            // 0x019E7CC8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E7CCC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E7CD0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E7CD4: BR x3                      | goto X2 + 24 + 168 + 8;                 
            goto X2 + 24 + 168 + 8;
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E7CD8 VirtAddr: 0x019E7CD8 -RVA: 0x019E7CD8 
        // -CachedAttributeGetter<object>..cctor
        //
        //
        // Offset in libil2cpp.so: 0x019E7CD8 (27163864), len: 408  VirtAddr: 0x019E7CD8 RVA: 0x019E7CD8 token: 100686153 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private static CachedAttributeGetter<T>()
        {
            //
            // Disasemble & Code
            // 0x019E7CD8: STP x24, x23, [sp, #-0x40]! | stack[1152921513907106400] = ???;  stack[1152921513907106408] = ???;  //  dest_result_addr=1152921513907106400 |  dest_result_addr=1152921513907106408
            // 0x019E7CDC: STP x22, x21, [sp, #0x10]  | stack[1152921513907106416] = ???;  stack[1152921513907106424] = ???;  //  dest_result_addr=1152921513907106416 |  dest_result_addr=1152921513907106424
            // 0x019E7CE0: STP x20, x19, [sp, #0x20]  | stack[1152921513907106432] = ???;  stack[1152921513907106440] = ???;  //  dest_result_addr=1152921513907106432 |  dest_result_addr=1152921513907106440
            // 0x019E7CE4: STP x29, x30, [sp, #0x30]  | stack[1152921513907106448] = ???;  stack[1152921513907106456] = ???;  //  dest_result_addr=1152921513907106448 |  dest_result_addr=1152921513907106456
            // 0x019E7CE8: ADD x29, sp, #0x30         | X29 = (1152921513907106400 + 48) = 1152921513907106448 (0x100000022A56B290);
            // 0x019E7CEC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x019E7CF0: LDR x20, [x19, #0x18]      | X20 = X1 + 24;                          
            // 0x019E7CF4: MOV x0, x20                | X0 = X1 + 24;//m1                       
            // 0x019E7CF8: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7CFC: LDR x8, [x20, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7D00: LDR x20, [x8]              | X20 = X1 + 24 + 168;                    
            // 0x019E7D04: MOV x0, x20                | X0 = X1 + 24 + 168;//m1                 
            // 0x019E7D08: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24 + 168, ????);
            // 0x019E7D0C: LDR x8, [x20, #0xa0]       | X8 = X1 + 24 + 168 + 160;               
            // 0x019E7D10: LDR x8, [x8, #8]           | X8 = X1 + 24 + 168 + 160 + 8;           
            // 0x019E7D14: CBNZ x8, #0x19e7db4        | if (X1 + 24 + 168 + 160 + 8 != 0) goto label_0;
            if((X1 + 24 + 168 + 160 + 8) != 0)
            {
                goto label_0;
            }
            // 0x019E7D18: LDR x20, [x19, #0x18]      | X20 = X1 + 24;                          
            // 0x019E7D1C: MOV x0, x20                | X0 = X1 + 24;//m1                       
            // 0x019E7D20: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7D24: LDR x8, [x20, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7D28: LDR x21, [x19, #0x18]      | X21 = X1 + 24;                          
            // 0x019E7D2C: LDR x20, [x8, #0x10]       | X20 = X1 + 24 + 168 + 16;               
            // 0x019E7D30: MOV x0, x21                | X0 = X1 + 24;//m1                       
            // 0x019E7D34: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7D38: LDR x8, [x21, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7D3C: LDR x21, [x8, #0x18]       | X21 = X1 + 24 + 168 + 24;               
            // 0x019E7D40: MOV x0, x21                | X0 = X1 + 24 + 168 + 24;//m1            
            // 0x019E7D44: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24 + 168 + 24, ????);
            // 0x019E7D48: MOV x0, x21                | X0 = X1 + 24 + 168 + 24;//m1            
            // 0x019E7D4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X1 + 24 + 168 + 24, ????);
            // 0x019E7D50: LDR x21, [x19, #0x18]      | X21 = X1 + 24;                          
            // 0x019E7D54: MOV x22, x0                | X22 = X1 + 24 + 168 + 24;//m1           
            // 0x019E7D58: MOV x0, x21                | X0 = X1 + 24;//m1                       
            // 0x019E7D5C: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7D60: LDR x8, [x21, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7D64: LDR x21, [x19, #0x18]      | X21 = X1 + 24;                          
            // 0x019E7D68: LDR x8, [x8, #0x20]        | X8 = X1 + 24 + 168 + 32;                
            // 0x019E7D6C: MOV x0, x21                | X0 = X1 + 24;//m1                       
            // 0x019E7D70: LDR x23, [x8]              | X23 = X1 + 24 + 168 + 32;               
            // 0x019E7D74: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7D78: LDR x8, [x21, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7D7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E7D80: MOV x0, x22                | X0 = X1 + 24 + 168 + 24;//m1            
            // 0x019E7D84: MOV x2, x20                | X2 = X1 + 24 + 168 + 16;//m1            
            // 0x019E7D88: LDR x3, [x8, #0x20]        | X3 = X1 + 24 + 168 + 32;                
            // 0x019E7D8C: BLR x23                    | X0 = X1 + 24 + 168 + 32();              
            // 0x019E7D90: LDR x20, [x19, #0x18]      | X20 = X1 + 24;                          
            // 0x019E7D94: MOV x0, x20                | X0 = X1 + 24;//m1                       
            // 0x019E7D98: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7D9C: LDR x8, [x20, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7DA0: LDR x20, [x8]              | X20 = X1 + 24 + 168;                    
            // 0x019E7DA4: MOV x0, x20                | X0 = X1 + 24 + 168;//m1                 
            // 0x019E7DA8: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24 + 168, ????);
            // 0x019E7DAC: LDR x8, [x20, #0xa0]       | X8 = X1 + 24 + 168 + 160;               
            // 0x019E7DB0: STR x22, [x8, #8]          | mem2[0] = X1 + 24 + 168 + 24;            //  dest_result_addr=0
            mem2[0] = X1 + 24 + 168 + 24;
            label_0:
            // 0x019E7DB4: LDR x20, [x19, #0x18]      | X20 = X1 + 24;                          
            // 0x019E7DB8: MOV x0, x20                | X0 = X1 + 24;//m1                       
            // 0x019E7DBC: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7DC0: LDR x8, [x20, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7DC4: LDR x20, [x8]              | X20 = X1 + 24 + 168;                    
            // 0x019E7DC8: MOV x0, x20                | X0 = X1 + 24 + 168;//m1                 
            // 0x019E7DCC: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24 + 168, ????);
            // 0x019E7DD0: LDR x8, [x20, #0xa0]       | X8 = X1 + 24 + 168 + 160;               
            // 0x019E7DD4: LDR x21, [x19, #0x18]      | X21 = X1 + 24;                          
            // 0x019E7DD8: LDR x20, [x8, #8]          | X20 = X1 + 24 + 168 + 160 + 8;          
            // 0x019E7DDC: MOV x0, x21                | X0 = X1 + 24;//m1                       
            // 0x019E7DE0: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7DE4: LDR x8, [x21, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7DE8: LDR x21, [x8, #0x28]       | X21 = X1 + 24 + 168 + 40;               
            // 0x019E7DEC: MOV x0, x21                | X0 = X1 + 24 + 168 + 40;//m1            
            // 0x019E7DF0: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24 + 168 + 40, ????);
            // 0x019E7DF4: MOV x0, x21                | X0 = X1 + 24 + 168 + 40;//m1            
            // 0x019E7DF8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X1 + 24 + 168 + 40, ????);
            // 0x019E7DFC: LDR x21, [x19, #0x18]      | X21 = X1 + 24;                          
            // 0x019E7E00: MOV x22, x0                | X22 = X1 + 24 + 168 + 40;//m1           
            // 0x019E7E04: MOV x0, x21                | X0 = X1 + 24;//m1                       
            // 0x019E7E08: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7E0C: LDR x8, [x21, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7E10: LDR x21, [x19, #0x18]      | X21 = X1 + 24;                          
            // 0x019E7E14: LDR x8, [x8, #0x30]        | X8 = X1 + 24 + 168 + 48;                
            // 0x019E7E18: MOV x0, x21                | X0 = X1 + 24;//m1                       
            // 0x019E7E1C: LDR x23, [x8]              | X23 = X1 + 24 + 168 + 48;               
            // 0x019E7E20: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7E24: LDR x8, [x21, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7E28: MOV x0, x22                | X0 = X1 + 24 + 168 + 40;//m1            
            // 0x019E7E2C: MOV x1, x20                | X1 = X1 + 24 + 168 + 160 + 8;//m1       
            // 0x019E7E30: LDR x2, [x8, #0x30]        | X2 = X1 + 24 + 168 + 48;                
            // 0x019E7E34: BLR x23                    | X0 = X1 + 24 + 168 + 48();              
            // 0x019E7E38: LDR x19, [x19, #0x18]      | X19 = X1 + 24;                          
            // 0x019E7E3C: MOV x0, x19                | X0 = X1 + 24;//m1                       
            // 0x019E7E40: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24, ????);    
            // 0x019E7E44: LDR x8, [x19, #0xa8]       | X8 = X1 + 24 + 168;                     
            // 0x019E7E48: LDR x19, [x8]              | X19 = X1 + 24 + 168;                    
            // 0x019E7E4C: MOV x0, x19                | X0 = X1 + 24 + 168;//m1                 
            // 0x019E7E50: BL #0x277461c              | X0 = sub_277461C( ?? X1 + 24 + 168, ????);
            // 0x019E7E54: LDR x8, [x19, #0xa0]       | X8 = X1 + 24 + 168 + 160;               
            // 0x019E7E58: STR x22, [x8]              | mem2[0] = X1 + 24 + 168 + 40;            //  dest_result_addr=0
            mem2[0] = X1 + 24 + 168 + 40;
            // 0x019E7E5C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x019E7E60: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x019E7E64: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x019E7E68: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x019E7E6C: RET                        |  return;                                
            return;
        
        }
    
    }

}
