using UnityEngine;

namespace Pathfinding
{
    public class BinaryHeapM
    {
        // Fields
        public int numberOfItems; //  0x00000010
        public float growthFactor; //  0x00000014
        public const int D = 4;
        private const bool SortGScores = True;
        private Pathfinding.BinaryHeapM.Tuple[] binaryHeap; //  0x00000018
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01688B54 (23628628), len: 136  VirtAddr: 0x01688B54 RVA: 0x01688B54 token: 100682138 methodIndex: 49912 delegateWrapperIndex: 0 methodInvoker: 0
        public BinaryHeapM(int numberOfElements)
        {
            //
            // Disasemble & Code
            // 0x01688B54: STP x22, x21, [sp, #-0x30]! | stack[1152921513198932240] = ???;  stack[1152921513198932248] = ???;  //  dest_result_addr=1152921513198932240 |  dest_result_addr=1152921513198932248
            // 0x01688B58: STP x20, x19, [sp, #0x10]  | stack[1152921513198932256] = ???;  stack[1152921513198932264] = ???;  //  dest_result_addr=1152921513198932256 |  dest_result_addr=1152921513198932264
            // 0x01688B5C: STP x29, x30, [sp, #0x20]  | stack[1152921513198932272] = ???;  stack[1152921513198932280] = ???;  //  dest_result_addr=1152921513198932272 |  dest_result_addr=1152921513198932280
            // 0x01688B60: ADD x29, sp, #0x20         | X29 = (1152921513198932240 + 32) = 1152921513198932272 (0x100000020020D130);
            // 0x01688B64: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01688B68: LDRB w8, [x21, #0xfa]      | W8 = (bool)static_value_037380FA;       
            // 0x01688B6C: MOV w20, w1                | W20 = numberOfElements;//m1             
            // 0x01688B70: MOV x19, x0                | X19 = 1152921513198944288 (0x1000000200210020);//ML01
            // 0x01688B74: TBNZ w8, #0, #0x1688b90    | if (static_value_037380FA == true) goto label_0;
            // 0x01688B78: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x01688B7C: LDR x8, [x8, #0x1b0]       | X8 = 0x2B8F4B0;                         
            // 0x01688B80: LDR w0, [x8]               | W0 = 0x13EE;                            
            // 0x01688B84: BL #0x2782188              | X0 = sub_2782188( ?? 0x13EE, ????);     
            // 0x01688B88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01688B8C: STRB w8, [x21, #0xfa]      | static_value_037380FA = true;            //  dest_result_addr=57901306
            label_0:
            // 0x01688B90: ORR w8, wzr, #0x40000000   | W8 = 1073741824(0x40000000);            
            // 0x01688B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688B98: MOV x0, x19                | X0 = 1152921513198944288 (0x1000000200210020);//ML01
            // 0x01688B9C: STR w8, [x19, #0x14]       | this.growthFactor = 2;                   //  dest_result_addr=1152921513198944308
            this.growthFactor = 2f;
            // 0x01688BA0: BL #0x16f59f0              | this..ctor();                           
            // 0x01688BA4: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x01688BA8: LDR x8, [x8, #0x188]       | X8 = 1152921513198916192;               
            // 0x01688BAC: LDR x21, [x8]              | X21 = typeof(Tuple[]);                  
            // 0x01688BB0: MOV x0, x21                | X0 = 1152921513198916192 (0x1000000200209260);//ML01
            // 0x01688BB4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Tuple[]), ????);
            // 0x01688BB8: MOV w1, w20                | W1 = numberOfElements;//m1              
            // 0x01688BBC: MOV x0, x21                | X0 = 1152921513198916192 (0x1000000200209260);//ML01
            // 0x01688BC0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Tuple[]), ????);
            // 0x01688BC4: STR wzr, [x19, #0x10]      | this.numberOfItems = 0;                  //  dest_result_addr=1152921513198944304
            this.numberOfItems = 0;
            // 0x01688BC8: STR x0, [x19, #0x18]       | this.binaryHeap = typeof(Tuple[]);       //  dest_result_addr=1152921513198944312
            this.binaryHeap = null;
            // 0x01688BCC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01688BD0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01688BD4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01688BD8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01688BDC (23628764), len: 8  VirtAddr: 0x01688BDC RVA: 0x01688BDC token: 100682139 methodIndex: 49913 delegateWrapperIndex: 0 methodInvoker: 0
        public void Clear()
        {
            //
            // Disasemble & Code
            // 0x01688BDC: STR wzr, [x0, #0x10]       | this.numberOfItems = 0;                  //  dest_result_addr=1152921513199056304
            this.numberOfItems = 0;
            // 0x01688BE0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01688BE4 (23628772), len: 84  VirtAddr: 0x01688BE4 RVA: 0x01688BE4 token: 100682140 methodIndex: 49914 delegateWrapperIndex: 0 methodInvoker: 0
        internal Pathfinding.PathNode GetNode(int i)
        {
            //
            // Disasemble & Code
            // 0x01688BE4: STP x22, x21, [sp, #-0x30]! | stack[1152921513199193104] = ???;  stack[1152921513199193112] = ???;  //  dest_result_addr=1152921513199193104 |  dest_result_addr=1152921513199193112
            // 0x01688BE8: STP x20, x19, [sp, #0x10]  | stack[1152921513199193120] = ???;  stack[1152921513199193128] = ???;  //  dest_result_addr=1152921513199193120 |  dest_result_addr=1152921513199193128
            // 0x01688BEC: STP x29, x30, [sp, #0x20]  | stack[1152921513199193136] = ???;  stack[1152921513199193144] = ???;  //  dest_result_addr=1152921513199193136 |  dest_result_addr=1152921513199193144
            // 0x01688BF0: ADD x29, sp, #0x20         | X29 = (1152921513199193104 + 32) = 1152921513199193136 (0x100000020024CC30);
            // 0x01688BF4: LDR x20, [x0, #0x18]       | X20 = this.binaryHeap; //P2             
            // 0x01688BF8: MOV w19, w1                | W19 = i;//m1                            
            // 0x01688BFC: CBNZ x20, #0x1688c04       | if (this.binaryHeap != null) goto label_0;
            if(this.binaryHeap != null)
            {
                goto label_0;
            }
            // 0x01688C00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01688C04: LDR w8, [x20, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688C08: SXTW x21, w19              | X21 = (long)(int)(i);                   
            // 0x01688C0C: CMP w8, w19                | STATE = COMPARE(this.binaryHeap.Length, i)
            // 0x01688C10: B.HI #0x1688c20            | if (this.binaryHeap.Length > i) goto label_1;
            if(this.binaryHeap.Length > i)
            {
                goto label_1;
            }
            // 0x01688C14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01688C18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688C1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x01688C20: ADD x8, x20, x21, lsl #4   | X8 = this.binaryHeap[((long)(int)(i)) << 4]; //PARR1 
            // 0x01688C24: LDR x0, [x8, #0x28]        | X0 = this.binaryHeap[((long)(int)(i)) << 4][1]
            Tuple val_1 = this.binaryHeap[((long)(int)(i)) << 4];
            // 0x01688C28: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01688C2C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01688C30: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01688C34: RET                        |  return (Pathfinding.PathNode)this.binaryHeap[((long)(int)(i)) << 4][1];
            return (Pathfinding.PathNode)val_1;
            //  |  // // {name=val_0, type=Pathfinding.PathNode, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01688C38 (23628856), len: 88  VirtAddr: 0x01688C38 RVA: 0x01688C38 token: 100682141 methodIndex: 49915 delegateWrapperIndex: 0 methodInvoker: 0
        internal void SetF(int i, uint F)
        {
            //
            // Disasemble & Code
            // 0x01688C38: STP x22, x21, [sp, #-0x30]! | stack[1152921513199378832] = ???;  stack[1152921513199378840] = ???;  //  dest_result_addr=1152921513199378832 |  dest_result_addr=1152921513199378840
            // 0x01688C3C: STP x20, x19, [sp, #0x10]  | stack[1152921513199378848] = ???;  stack[1152921513199378856] = ???;  //  dest_result_addr=1152921513199378848 |  dest_result_addr=1152921513199378856
            // 0x01688C40: STP x29, x30, [sp, #0x20]  | stack[1152921513199378864] = ???;  stack[1152921513199378872] = ???;  //  dest_result_addr=1152921513199378864 |  dest_result_addr=1152921513199378872
            // 0x01688C44: ADD x29, sp, #0x20         | X29 = (1152921513199378832 + 32) = 1152921513199378864 (0x100000020027A1B0);
            // 0x01688C48: LDR x21, [x0, #0x18]       | X21 = this.binaryHeap; //P2             
            // 0x01688C4C: MOV w19, w2                | W19 = F;//m1                            
            // 0x01688C50: MOV w20, w1                | W20 = i;//m1                            
            // 0x01688C54: CBNZ x21, #0x1688c5c       | if (this.binaryHeap != null) goto label_0;
            if(this.binaryHeap != null)
            {
                goto label_0;
            }
            // 0x01688C58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01688C5C: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688C60: SXTW x22, w20              | X22 = (long)(int)(i);                   
            // 0x01688C64: CMP w8, w20                | STATE = COMPARE(this.binaryHeap.Length, i)
            // 0x01688C68: B.HI #0x1688c78            | if (this.binaryHeap.Length > i) goto label_1;
            if(this.binaryHeap.Length > i)
            {
                goto label_1;
            }
            // 0x01688C6C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01688C70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688C74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x01688C78: ADD x8, x21, x22, lsl #4   | X8 = this.binaryHeap[((long)(int)(i)) << 4]; //PARR1 
            // 0x01688C7C: STR w19, [x8, #0x20]       | this.binaryHeap[((long)(int)(i)) << 4][0] = F;  //  dest_result_addr=0
            this.binaryHeap[((long)(int)(i)) << 4] = F;
            // 0x01688C80: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01688C84: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01688C88: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01688C8C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01688C90 (23628944), len: 1108  VirtAddr: 0x01688C90 RVA: 0x01688C90 token: 100682142 methodIndex: 49916 delegateWrapperIndex: 0 methodInvoker: 0
        public void Add(Pathfinding.PathNode node)
        {
            //
            // Disasemble & Code
            //  | 
            float val_2;
            //  | 
            Tuple[] val_20;
            //  | 
            float val_21;
            //  | 
            double val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            int val_25;
            //  | 
            int val_26;
            //  | 
            Tuple[] val_27;
            //  | 
            var val_28;
            // 0x01688C90: STP d9, d8, [sp, #-0x70]!  | stack[1152921513199975760] = ???;  stack[1152921513199975768] = ???;  //  dest_result_addr=1152921513199975760 |  dest_result_addr=1152921513199975768
            // 0x01688C94: STP x28, x27, [sp, #0x10]  | stack[1152921513199975776] = ???;  stack[1152921513199975784] = ???;  //  dest_result_addr=1152921513199975776 |  dest_result_addr=1152921513199975784
            // 0x01688C98: STP x26, x25, [sp, #0x20]  | stack[1152921513199975792] = ???;  stack[1152921513199975800] = ???;  //  dest_result_addr=1152921513199975792 |  dest_result_addr=1152921513199975800
            // 0x01688C9C: STP x24, x23, [sp, #0x30]  | stack[1152921513199975808] = ???;  stack[1152921513199975816] = ???;  //  dest_result_addr=1152921513199975808 |  dest_result_addr=1152921513199975816
            // 0x01688CA0: STP x22, x21, [sp, #0x40]  | stack[1152921513199975824] = ???;  stack[1152921513199975832] = ???;  //  dest_result_addr=1152921513199975824 |  dest_result_addr=1152921513199975832
            // 0x01688CA4: STP x20, x19, [sp, #0x50]  | stack[1152921513199975840] = ???;  stack[1152921513199975848] = ???;  //  dest_result_addr=1152921513199975840 |  dest_result_addr=1152921513199975848
            // 0x01688CA8: STP x29, x30, [sp, #0x60]  | stack[1152921513199975856] = ???;  stack[1152921513199975864] = ???;  //  dest_result_addr=1152921513199975856 |  dest_result_addr=1152921513199975864
            // 0x01688CAC: ADD x29, sp, #0x60         | X29 = (1152921513199975760 + 96) = 1152921513199975856 (0x100000020030BDB0);
            // 0x01688CB0: SUB sp, sp, #0x10          | SP = (1152921513199975760 - 16) = 1152921513199975744 (0x100000020030BD40);
            // 0x01688CB4: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01688CB8: LDRB w8, [x21, #0xfb]      | W8 = (bool)static_value_037380FB;       
            // 0x01688CBC: MOV x19, x1                | X19 = node;//m1                         
            // 0x01688CC0: MOV x20, x0                | X20 = 1152921513199987872 (0x100000020030ECA0);//ML01
            // 0x01688CC4: TBNZ w8, #0, #0x1688ce0    | if (static_value_037380FB == true) goto label_0;
            // 0x01688CC8: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x01688CCC: LDR x8, [x8, #0x920]       | X8 = 0x2B8F4B4;                         
            // 0x01688CD0: LDR w0, [x8]               | W0 = 0x13EF;                            
            // 0x01688CD4: BL #0x2782188              | X0 = sub_2782188( ?? 0x13EF, ????);     
            // 0x01688CD8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01688CDC: STRB w8, [x21, #0xfb]      | static_value_037380FB = true;            //  dest_result_addr=57901307
            label_0:
            // 0x01688CE0: CBZ x19, #0x1689074        | if (node == null) goto label_1;         
            if(node == null)
            {
                goto label_1;
            }
            // 0x01688CE4: LDR w21, [x20, #0x10]      | W21 = this.numberOfItems; //P2          
            // 0x01688CE8: LDR x22, [x20, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x01688CEC: CBNZ x22, #0x1688cf4       | if (this.binaryHeap != null) goto label_2;
            if(this.binaryHeap != null)
            {
                goto label_2;
            }
            // 0x01688CF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13EF, ????);     
            label_2:
            // 0x01688CF4: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688CF8: CMP w21, w8                | STATE = COMPARE(this.numberOfItems, this.binaryHeap.Length)
            // 0x01688CFC: B.NE #0x1688e64            | if (this.numberOfItems != this.binaryHeap.Length) goto label_3;
            if(this.numberOfItems != this.binaryHeap.Length)
            {
                goto label_3;
            }
            // 0x01688D00: LDR x21, [x20, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x01688D04: MOV x8, x21                | X8 = this.binaryHeap;//m1               
            val_20 = this.binaryHeap;
            // 0x01688D08: CBNZ x21, #0x1688d18       | if (this.binaryHeap != null) goto label_4;
            if(this.binaryHeap != null)
            {
                goto label_4;
            }
            // 0x01688D0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13EF, ????);     
            // 0x01688D10: LDR x8, [x20, #0x18]       | X8 = this.binaryHeap; //P2              
            val_20 = this.binaryHeap;
            // 0x01688D14: CBZ x8, #0x16890e0         | if (this.binaryHeap == null) goto label_5;
            if(val_20 == null)
            {
                goto label_5;
            }
            label_4:
            // 0x01688D18: LDR s0, [x8, #0x18]        | S0 = this.binaryHeap.Length; //P2       
            // 0x01688D1C: LDR s1, [x20, #0x14]       | S1 = this.growthFactor; //P2            
            // 0x01688D20: ADD x0, sp, #8             | X0 = (1152921513199975744 + 8) = 1152921513199975752 (0x100000020030BD48);
            // 0x01688D24: SCVTF s0, s0               | S0 = (float)(this.binaryHeap.Length);   
            // 0x01688D28: FMUL s9, s1, s0            | S9 = (this.growthFactor * this.binaryHeap.Length);
            float val_1 = this.growthFactor * (float)this.binaryHeap.Length;
            // 0x01688D2C: FCVT d8, s9                | D8 = (double)(this.growthFactor * this.binaryHeap.Length));
            // 0x01688D30: MOV v0.16b, v8.16b         | V0 = (this.growthFactor * this.binaryHeap.Length);//m1
            // 0x01688D34: BL #0x980330               | X0 = sub_980330( ?? 0x100000020030BD48, ????);
            // 0x01688D38: FCMP s9, #0.0              | STATE = COMPARE((this.growthFactor * this.binaryHeap.Length), 0)
            // 0x01688D3C: B.GE #0x1688d58            | if (val_1 >= 0) goto label_6;           
            if(val_1 >= 0f)
            {
                goto label_6;
            }
            // 0x01688D40: FMOV d1, #-0.50000000      | D1 = -0.5;                              
            // 0x01688D44: FCMP d0, d1                | STATE = COMPARE((this.growthFactor * this.binaryHeap.Length), -0.5)
            // 0x01688D48: B.NE #0x1688d80            | if ((double)float val_1 = this.growthFactor * (float)this.binaryHeap.Length != -0.5) goto label_7;
            if((double)val_1 != (-0.5))
            {
                goto label_7;
            }
            // 0x01688D4C: LDR d0, [sp, #8]           | D0 = val_2;                              //  find_add[1152921513199963872]
            val_21 = val_2;
            // 0x01688D50: FMOV d1, #-1.00000000      | D1 = -1;                                
            val_22 = -1;
            // 0x01688D54: B #0x1688d6c               |  goto label_8;                          
            goto label_8;
            label_6:
            // 0x01688D58: FMOV d1, #0.50000000       | D1 = 0.5;                               
            // 0x01688D5C: FCMP d0, d1                | STATE = COMPARE((this.growthFactor * this.binaryHeap.Length), 0.5)
            // 0x01688D60: B.NE #0x1688d8c            | if ((double)val_1 != 0.5) goto label_9; 
            if((double)val_1 != 0.5)
            {
                goto label_9;
            }
            // 0x01688D64: LDR d0, [sp, #8]           | D0 = val_2;                              //  find_add[1152921513199963872]
            val_21 = val_2;
            // 0x01688D68: FMOV d1, #1.00000000       | D1 = 1;                                 
            val_22 = 1;
            label_8:
            // 0x01688D6C: FCVTZS x8, d0              | X8 = (long)(val_2);                     
            // 0x01688D70: FADD d1, d0, d1            | D1 = (val_2 + val_22);                  
            val_22 = val_21 + val_22;
            // 0x01688D74: TST x8, #1                 | STATE = COMPARE(val_2, 0x1)             
            // 0x01688D78: FCSEL d0, d0, d1, eq       | D0 = ((long)val_21 & 0x1)!=0 ? val_2 : (val_2 + val_22);
            val_21 = (((long)val_21 & 1) != 0) ? (val_21) : (val_22);
            // 0x01688D7C: B #0x1688d94               |  goto label_11;                         
            goto label_11;
            label_7:
            // 0x01688D80: FADD d0, d8, d1            | D0 = ((this.growthFactor * this.binaryHeap.Length) + -0.5);
            double val_3 = (double)val_1 + (-0.5);
            // 0x01688D84: FRINTP d0, d0              | 
            // 0x01688D88: B #0x1688d94               |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x01688D8C: FADD d0, d8, d1            | D0 = ((this.growthFactor * this.binaryHeap.Length) + 0.5);
            double val_4 = (double)val_1 + 0.5;
            // 0x01688D90: FRINTM d0, d0              | 
            label_11:
            // 0x01688D94: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688D98: FCVTZS w2, d0              | W2 = (int)(((this.growthFactor * this.binaryHeap.Length) + 0.5));
            // 0x01688D9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688DA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01688DA4: ADD w1, w8, #4             | W1 = (this.binaryHeap.Length + 4);      
            int val_5 = this.binaryHeap.Length + 4;
            // 0x01688DA8: BL #0x16f9490              | X0 = System.Math.Max(val1:  0, val2:  int val_5 = this.binaryHeap.Length + 4);
            int val_6 = System.Math.Max(val1:  0, val2:  val_5);
            // 0x01688DAC: MOV w21, w0                | W21 = val_6;//m1                        
            // 0x01688DB0: CMP w21, #0x40, lsl #12    | STATE = COMPARE(val_6, 0x40000)         
            // 0x01688DB4: B.GT #0x16890a0            | if (val_6 > 262144) goto label_12;      
            if(val_6 > 262144)
            {
                goto label_12;
            }
            // 0x01688DB8: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x01688DBC: LDR x8, [x8, #0x188]       | X8 = 1152921513198916192;               
            // 0x01688DC0: LDR x22, [x8]              | X22 = typeof(Tuple[]);                  
            // 0x01688DC4: MOV x0, x22                | X0 = 1152921513198916192 (0x1000000200209260);//ML01
            // 0x01688DC8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Tuple[]), ????);
            // 0x01688DCC: MOV w1, w21                | W1 = val_6;//m1                         
            // 0x01688DD0: MOV x0, x22                | X0 = 1152921513198916192 (0x1000000200209260);//ML01
            // 0x01688DD4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Tuple[]), ????);
            // 0x01688DD8: MOV x21, x0                | X21 = 1152921513198916192 (0x1000000200209260);//ML01
            // 0x01688DDC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_24 = 0;
            // 0x01688DE0: B #0x1688df4               |  goto label_13;                         
            goto label_13;
            label_20:
            // 0x01688DE4: ADD x8, x23, x24, lsl #4   | X8 = (X23 + (X24) << 4);                
            var val_7 = X23 + ((X24) << 4);
            // 0x01688DE8: LDR q0, [x8, #0x20]        | Q0 = (X23 + (X24) << 4) + 32;           
            // 0x01688DEC: ADD w22, w22, #1           | W22 = (val_24 + 1) = val_24 (0x00000001);
            val_24 = 1;
            // 0x01688DF0: STR q0, [x25]              | mem2[0] = (X23 + (X24) << 4) + 32;       //  dest_result_addr=0
            mem2[0] = (X23 + (X24) << 4) + 32;
            label_13:
            // 0x01688DF4: LDR x23, [x20, #0x18]      | X23 = this.binaryHeap; //P2             
            // 0x01688DF8: CBNZ x23, #0x1688e00       | if (this.binaryHeap != null) goto label_14;
            if(this.binaryHeap != null)
            {
                goto label_14;
            }
            // 0x01688DFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Tuple[]), ????);
            label_14:
            // 0x01688E00: LDR w8, [x23, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688E04: CMP w22, w8                | STATE = COMPARE(0x1, this.binaryHeap.Length)
            // 0x01688E08: B.GE #0x1688e60            | if (val_24 >= this.binaryHeap.Length) goto label_15;
            if(val_24 >= this.binaryHeap.Length)
            {
                goto label_15;
            }
            // 0x01688E0C: CBNZ x21, #0x1688e14       | if ( != null) goto label_16;            
            if(null != null)
            {
                goto label_16;
            }
            // 0x01688E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Tuple[]), ????);
            label_16:
            // 0x01688E14: LDR x23, [x20, #0x18]      | X23 = this.binaryHeap; //P2             
            // 0x01688E18: CBNZ x23, #0x1688e20       | if (this.binaryHeap != null) goto label_17;
            if(this.binaryHeap != null)
            {
                goto label_17;
            }
            // 0x01688E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Tuple[]), ????);
            label_17:
            // 0x01688E20: LDR w8, [x21, #0x18]       | W8 = Tuple[].__il2cppRuntimeField_namespaze;
            // 0x01688E24: SXTW x24, w22              | X24 = 1 (0x00000001);                   
            // 0x01688E28: CMP w22, w8                | STATE = COMPARE(0x1, Tuple[].__il2cppRuntimeField_namespaze)
            // 0x01688E2C: B.LO #0x1688e3c            | if (val_24 < Tuple[].__il2cppRuntimeField_namespaze) goto label_18;
            // 0x01688E30: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Tuple[]), ????);
            // 0x01688E34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688E38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Tuple[]), ????);
            label_18:
            // 0x01688E3C: LDR w8, [x23, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688E40: ADD x9, x21, x24, lsl #4   | X9 = (null + 16) = 1152921513198916208 (0x1000000200209270);
            // 0x01688E44: ADD x25, x9, #0x20         | X25 = (1152921513198916208 + 32) = 1152921513198916240 (0x1000000200209290);
            // 0x01688E48: CMP w22, w8                | STATE = COMPARE(0x1, this.binaryHeap.Length)
            // 0x01688E4C: B.LO #0x1688de4            | if (val_24 < this.binaryHeap.Length) goto label_20;
            if(val_24 < this.binaryHeap.Length)
            {
                goto label_20;
            }
            // 0x01688E50: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Tuple[]), ????);
            // 0x01688E54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688E58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Tuple[]), ????);
            // 0x01688E5C: B #0x1688de4               |  goto label_20;                         
            goto label_20;
            label_15:
            // 0x01688E60: STR x21, [x20, #0x18]      | this.binaryHeap = typeof(Tuple[]);       //  dest_result_addr=1152921513199987896
            this.binaryHeap = null;
            label_3:
            // 0x01688E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688E68: MOV x0, x19                | X0 = node;//m1                          
            // 0x01688E6C: BL #0x1405cb0              | X0 = node.get_F();                      
            uint val_8 = node.F;
            // 0x01688E70: LDR x22, [x20, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x01688E74: LDRSW x23, [x20, #0x10]    | X23 = this.numberOfItems; //P2          
            val_25 = this.numberOfItems;
            // 0x01688E78: MOV w21, w0                | W21 = val_8;//m1                        
            // 0x01688E7C: CBNZ x22, #0x1688e84       | if (this.binaryHeap != null) goto label_21;
            if(this.binaryHeap != null)
            {
                goto label_21;
            }
            // 0x01688E80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_21:
            // 0x01688E84: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688E88: CMP w23, w8                | STATE = COMPARE(this.numberOfItems, this.binaryHeap.Length)
            // 0x01688E8C: B.LO #0x1688e9c            | if (val_25 < this.binaryHeap.Length) goto label_22;
            if(val_25 < this.binaryHeap.Length)
            {
                goto label_22;
            }
            // 0x01688E90: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x01688E94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688E98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_22:
            // 0x01688E9C: ADD x8, x22, x23, lsl #4   | X8 = this.binaryHeap[(this.numberOfItems) << 4]; //PARR1 
            // 0x01688EA0: STP w21, wzr, [x8, #0x20]  | this.binaryHeap[(this.numberOfItems) << 4][0] = val_8;  this.binaryHeap[(this.numberOfItems) << 4][0] = new Tuple();  //  dest_result_addr=0 |  dest_result_addr=0
            this.binaryHeap[(this.numberOfItems) << 4] = val_8;
            this.binaryHeap[(this.numberOfItems) << 4] = 0;
            // 0x01688EA4: STR x19, [x8, #0x28]       | this.binaryHeap[(this.numberOfItems) << 4][1] = node;  //  dest_result_addr=0
            this.binaryHeap[(this.numberOfItems) << 4] = node;
            // 0x01688EA8: LDR w25, [x20, #0x10]      | W25 = this.numberOfItems; //P2          
            val_26 = this.numberOfItems;
            // 0x01688EAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688EB0: MOV x0, x19                | X0 = node;//m1                          
            // 0x01688EB4: BL #0x1405cb0              | X0 = node.get_F();                      
            uint val_9 = node.F;
            // 0x01688EB8: MOV w22, w0                | W22 = val_9;//m1                        
            // 0x01688EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688EC0: MOV x0, x19                | X0 = node;//m1                          
            // 0x01688EC4: BL #0x1405c90              | X0 = node.get_G();                      
            uint val_10 = node.G;
            // 0x01688EC8: STR w0, [sp, #4]           | stack[1152921513199975748] = val_10;     //  dest_result_addr=1152921513199975748
            // 0x01688ECC: CBZ w25, #0x1689044        | if (this.numberOfItems == 0) goto label_33;
            if(val_26 == 0)
            {
                goto label_33;
            }
            label_40:
            // 0x01688ED0: SUB w8, w25, #1            | W8 = (this.numberOfItems - 1);          
            int val_11 = val_26 - 1;
            // 0x01688ED4: LDR x24, [x20, #0x18]      | X24 = this.binaryHeap; //P2             
            // 0x01688ED8: ADD w9, w25, #2            | W9 = (this.numberOfItems + 2);          
            int val_12 = val_26 + 2;
            // 0x01688EDC: CMP w8, #0                 | STATE = COMPARE((this.numberOfItems - 1), 0x0)
            // 0x01688EE0: CSEL w8, w9, w8, lt        | W8 = val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1);
            var val_13 = (val_11 < 0) ? (val_12) : (val_11);
            // 0x01688EE4: ASR w26, w8, #2            | W26 = (val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2);
            var val_14 = val_13 >> 2;
            // 0x01688EE8: CBNZ x24, #0x1688ef0       | if (this.binaryHeap != null) goto label_24;
            if(this.binaryHeap != null)
            {
                goto label_24;
            }
            // 0x01688EEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_24:
            // 0x01688EF0: LDR w8, [x24, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688EF4: SXTW x27, w26              | X27 = (long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2));
            // 0x01688EF8: CMP w26, w8                | STATE = COMPARE((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2), this.binaryHeap.Length)
            // 0x01688EFC: B.LO #0x1688f0c            | if (val_14 < this.binaryHeap.Length) goto label_25;
            if(val_14 < this.binaryHeap.Length)
            {
                goto label_25;
            }
            // 0x01688F00: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x01688F04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688F08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_25:
            // 0x01688F0C: ADD x8, x24, x27, lsl #4   | X8 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4]; //PARR1 
            // 0x01688F10: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][0]
            Tuple val_20 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4];
            // 0x01688F14: CMP w22, w8                | STATE = COMPARE(val_9, this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][0])
            // 0x01688F18: B.LO #0x1688f9c            | if (val_9 < this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4]) goto label_26;
            if(val_9 < val_20)
            {
                goto label_26;
            }
            // 0x01688F1C: LDR x24, [x20, #0x18]      | X24 = this.binaryHeap; //P2             
            // 0x01688F20: CBNZ x24, #0x1688f28       | if (this.binaryHeap != null) goto label_27;
            if(this.binaryHeap != null)
            {
                goto label_27;
            }
            // 0x01688F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_27:
            // 0x01688F28: LDR w8, [x24, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688F2C: CMP w26, w8                | STATE = COMPARE((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2), this.binaryHeap.Length)
            // 0x01688F30: B.LO #0x1688f40            | if (val_14 < this.binaryHeap.Length) goto label_28;
            if(val_14 < this.binaryHeap.Length)
            {
                goto label_28;
            }
            // 0x01688F34: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x01688F38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688F3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_28:
            // 0x01688F40: ADD x8, x24, x27, lsl #4   | X8 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4]; //PARR1 
            // 0x01688F44: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][0]
            Tuple val_21 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4];
            // 0x01688F48: CMP w22, w8                | STATE = COMPARE(val_9, this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][0])
            // 0x01688F4C: B.NE #0x1689044            | if (val_9 != this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4]) goto label_33;
            if(val_9 != val_21)
            {
                goto label_33;
            }
            // 0x01688F50: LDR x24, [x20, #0x18]      | X24 = this.binaryHeap; //P2             
            // 0x01688F54: CBNZ x24, #0x1688f5c       | if (this.binaryHeap != null) goto label_30;
            if(this.binaryHeap != null)
            {
                goto label_30;
            }
            // 0x01688F58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_30:
            // 0x01688F5C: LDR w8, [x24, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688F60: CMP w26, w8                | STATE = COMPARE((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2), this.binaryHeap.Length)
            // 0x01688F64: B.LO #0x1688f74            | if (val_14 < this.binaryHeap.Length) goto label_31;
            if(val_14 < this.binaryHeap.Length)
            {
                goto label_31;
            }
            // 0x01688F68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x01688F6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688F70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_31:
            // 0x01688F74: ADD x8, x24, x27, lsl #4   | X8 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4]; //PARR1 
            // 0x01688F78: LDR x24, [x8, #0x28]       | X24 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][1]
            Tuple val_22 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4];
            // 0x01688F7C: CBNZ x24, #0x1688f84       | if (this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][1] != 0) goto label_32;
            if(val_22 != 0)
            {
                goto label_32;
            }
            // 0x01688F80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_32:
            // 0x01688F84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688F88: MOV x0, x24                | X0 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][1];//m1
            // 0x01688F8C: BL #0x1405c90              | X0 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][1].get_G();
            uint val_15 = val_22.G;
            // 0x01688F90: LDR w8, [sp, #4]           | W8 = val_10;                            
            // 0x01688F94: CMP w8, w0                 | STATE = COMPARE(val_10, val_15)         
            // 0x01688F98: B.LS #0x1689044            | if (val_10 <= val_15) goto label_33;    
            if(val_10 <= val_15)
            {
                goto label_33;
            }
            label_26:
            // 0x01688F9C: LDR x28, [x20, #0x18]      | X28 = this.binaryHeap; //P2             
            // 0x01688FA0: MOV x24, x28               | X24 = this.binaryHeap;//m1              
            val_27 = this.binaryHeap;
            // 0x01688FA4: CBNZ x28, #0x1688fbc       | if (this.binaryHeap != null) goto label_35;
            if(this.binaryHeap != null)
            {
                goto label_35;
            }
            // 0x01688FA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            // 0x01688FAC: LDR x24, [x20, #0x18]      | X24 = this.binaryHeap; //P2             
            val_27 = this.binaryHeap;
            // 0x01688FB0: CBNZ x24, #0x1688fbc       | if (this.binaryHeap != null) goto label_35;
            if(val_27 != null)
            {
                goto label_35;
            }
            // 0x01688FB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            // 0x01688FB8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_27 = 0;
            label_35:
            // 0x01688FBC: LDR w8, [x28, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01688FC0: SXTW x23, w25              | X23 = (long)(int)(this.numberOfItems);  
            // 0x01688FC4: CMP w25, w8                | STATE = COMPARE(this.numberOfItems, this.binaryHeap.Length)
            // 0x01688FC8: B.LO #0x1688fd8            | if (val_26 < this.binaryHeap.Length) goto label_36;
            if(val_26 < this.binaryHeap.Length)
            {
                goto label_36;
            }
            // 0x01688FCC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x01688FD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688FD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_36:
            // 0x01688FD8: LDR w8, [x24, #0x18]       | W8 = 0x9814C0;                          
            // 0x01688FDC: ADD x9, x28, x23, lsl #4   | X9 = this.binaryHeap[((long)(int)(this.numberOfItems)) << 4]; //PARR1 
            // 0x01688FE0: ADD x23, x9, #0x20         | X23 = this.binaryHeap[((long)(int)(this.numberOfItems)) << 4][0x20]; //PARR1 
            // 0x01688FE4: CMP w26, w8                | STATE = COMPARE((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2), 0x9814C0)
            // 0x01688FE8: B.LO #0x1688ff8            | if (val_14 < 9966784) goto label_37;    
            if(val_14 < 9966784)
            {
                goto label_37;
            }
            // 0x01688FEC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x01688FF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688FF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_37:
            // 0x01688FF8: ADD x8, x24, x27, lsl #4   | X8 = (val_27 + ((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))
            var val_16 = val_27 + (((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4);
            // 0x01688FFC: LDR q0, [x8, #0x20]        | Q0 = (val_27 + ((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4) + 32;
            // 0x01689000: STR q0, [x23]              | mem2[0] = (val_27 + ((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4) + 32;  //  dest_result_addr=0
            mem2[0] = (val_27 + ((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4) + 32;
            // 0x01689004: LDR x24, [x20, #0x18]      | X24 = this.binaryHeap; //P2             
            // 0x01689008: CBNZ x24, #0x1689010       | if (this.binaryHeap != null) goto label_38;
            if(this.binaryHeap != null)
            {
                goto label_38;
            }
            // 0x0168900C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_38:
            // 0x01689010: LDR w8, [x24, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689014: CMP w26, w8                | STATE = COMPARE((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2), this.binaryHeap.Length)
            // 0x01689018: B.LO #0x1689028            | if (val_14 < this.binaryHeap.Length) goto label_39;
            if(val_14 < this.binaryHeap.Length)
            {
                goto label_39;
            }
            // 0x0168901C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x01689020: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689024: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_39:
            // 0x01689028: ADD x8, x24, x27, lsl #4   | X8 = this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4]; //PARR1 
            // 0x0168902C: ADD w9, w25, #2            | W9 = (this.numberOfItems + 2);          
            int val_17 = val_26 + 2;
            // 0x01689030: STP w21, wzr, [x8, #0x20]  | this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][0] = val_8;  this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][0] = new Tuple();  //  dest_result_addr=0 |  dest_result_addr=0
            this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4] = val_8;
            this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4] = 0;
            // 0x01689034: CMP w9, #6                 | STATE = COMPARE((this.numberOfItems + 2), 0x6)
            // 0x01689038: MOV w25, w26               | W25 = (val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2);//m1
            val_26 = val_14;
            // 0x0168903C: STR x19, [x8, #0x28]       | this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4][1] = node;  //  dest_result_addr=0
            this.binaryHeap[((long)(int)((val_11 < 0 ? (this.numberOfItems + 2) : (this.numberOfItems - 1) >> 2))) << 4] = node;
            // 0x01689040: B.HI #0x1688ed0            | if (val_17 > 6) goto label_40;          
            if(val_17 > 6)
            {
                goto label_40;
            }
            label_33:
            // 0x01689044: LDR w8, [x20, #0x10]       | W8 = this.numberOfItems; //P2           
            int val_23 = this.numberOfItems;
            // 0x01689048: ADD w8, w8, #1             | W8 = (this.numberOfItems + 1);          
            val_23 = val_23 + 1;
            // 0x0168904C: STR w8, [x20, #0x10]       | this.numberOfItems = (this.numberOfItems + 1);  //  dest_result_addr=1152921513199987888
            this.numberOfItems = val_23;
            // 0x01689050: SUB sp, x29, #0x60         | SP = (1152921513199975856 - 96) = 1152921513199975760 (0x100000020030BD50);
            // 0x01689054: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x01689058: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x0168905C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x01689060: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x01689064: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x01689068: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x0168906C: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x01689070: RET                        |  return;                                
            return;
            label_1:
            // 0x01689074: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x01689078: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x0168907C: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_18 = null;
            // 0x01689080: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x01689084: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x01689088: LDR x8, [x8, #0x1b0]       | X8 = (string**)(1152921513199962208)("Sending null node to BinaryHeap");
            // 0x0168908C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01689090: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            val_28 = val_18;
            // 0x01689094: LDR x1, [x8]               | X1 = "Sending null node to BinaryHeap"; 
            // 0x01689098: BL #0x18b3df0              | .ctor(paramName:  "Sending null node to BinaryHeap");
            val_18 = new System.ArgumentNullException(paramName:  "Sending null node to BinaryHeap");
            // 0x0168909C: B #0x16890c8               |  goto label_41;                         
            goto label_41;
            label_12:
            // 0x016890A0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x016890A4: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x016890A8: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_19 = null;
            // 0x016890AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x016890B0: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x016890B4: LDR x8, [x8, #0xa8]        | X8 = (string**)(1152921513199962352)("Binary Heap Size really large (2^18). A heap size this large is probably the cause of pathfinding running in an infinite loop. \nRemove this check (in BinaryHeap.cs) if you are sure that it is not caused by a bug");
            // 0x016890B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016890BC: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            val_28 = val_19;
            // 0x016890C0: LDR x1, [x8]               | X1 = "Binary Heap Size really large (2^18). A heap size this large is probably the cause of pathfinding running in an infinite loop. \nRemove this check (in BinaryHeap.cs) if you are sure that it is not caused by a bug";
            // 0x016890C4: BL #0x1c32b48              | .ctor(message:  "Binary Heap Size really large (2^18). A heap size this large is probably the cause of pathfinding running in an infinite loop. \nRemove this check (in BinaryHeap.cs) if you are sure that it is not caused by a bug");
            val_19 = new System.Exception(message:  "Binary Heap Size really large (2^18). A heap size this large is probably the cause of pathfinding running in an infinite loop. \nRemove this check (in BinaryHeap.cs) if you are sure that it is not caused by a bug");
            label_41:
            // 0x016890C8: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x016890CC: LDR x8, [x8, #0x6d8]       | X8 = 1152921513199962848;               
            // 0x016890D0: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x016890D4: LDR x1, [x8]               | X1 = public System.Void Pathfinding.BinaryHeapM::Add(Pathfinding.PathNode node);
            // 0x016890D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x016890DC: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
            label_5:
            // 0x016890E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Exception), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x016890E4 (23630052), len: 1800  VirtAddr: 0x016890E4 RVA: 0x016890E4 token: 100682143 methodIndex: 49917 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.PathNode Remove()
        {
            //
            // Disasemble & Code
            //  | 
            Tuple val_2;
            //  | 
            var val_12;
            //  | 
            int val_13;
            //  | 
            Tuple[] val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            Tuple[] val_17;
            //  | 
            Tuple val_18;
            //  | 
            var val_19;
            //  | 
            Tuple[] val_20;
            // 0x016890E4: STP x28, x27, [sp, #-0x60]! | stack[1152921513201566432] = ???;  stack[1152921513201566440] = ???;  //  dest_result_addr=1152921513201566432 |  dest_result_addr=1152921513201566440
            // 0x016890E8: STP x26, x25, [sp, #0x10]  | stack[1152921513201566448] = ???;  stack[1152921513201566456] = ???;  //  dest_result_addr=1152921513201566448 |  dest_result_addr=1152921513201566456
            // 0x016890EC: STP x24, x23, [sp, #0x20]  | stack[1152921513201566464] = ???;  stack[1152921513201566472] = ???;  //  dest_result_addr=1152921513201566464 |  dest_result_addr=1152921513201566472
            // 0x016890F0: STP x22, x21, [sp, #0x30]  | stack[1152921513201566480] = ???;  stack[1152921513201566488] = ???;  //  dest_result_addr=1152921513201566480 |  dest_result_addr=1152921513201566488
            // 0x016890F4: STP x20, x19, [sp, #0x40]  | stack[1152921513201566496] = ???;  stack[1152921513201566504] = ???;  //  dest_result_addr=1152921513201566496 |  dest_result_addr=1152921513201566504
            // 0x016890F8: STP x29, x30, [sp, #0x50]  | stack[1152921513201566512] = ???;  stack[1152921513201566520] = ???;  //  dest_result_addr=1152921513201566512 |  dest_result_addr=1152921513201566520
            // 0x016890FC: ADD x29, sp, #0x50         | X29 = (1152921513201566432 + 80) = 1152921513201566512 (0x1000000200490330);
            // 0x01689100: SUB sp, sp, #0x40          | SP = (1152921513201566432 - 64) = 1152921513201566368 (0x10000002004902A0);
            // 0x01689104: MOV x19, x0                | X19 = 1152921513201578528 (0x1000000200493220);//ML01
            // 0x01689108: STP xzr, xzr, [sp, #0x30]  | stack[1152921513201566416] = 0x0;  stack[1152921513201566424] = 0x0;  //  dest_result_addr=1152921513201566416 |  dest_result_addr=1152921513201566424
            // 0x0168910C: LDR w8, [x19, #0x10]       | W8 = this.numberOfItems; //P2           
            int val_15 = this.numberOfItems;
            // 0x01689110: LDR x20, [x19, #0x18]      | X20 = this.binaryHeap; //P2             
            // 0x01689114: SUB w8, w8, #1             | W8 = (this.numberOfItems - 1);          
            val_15 = val_15 - 1;
            // 0x01689118: STR w8, [x19, #0x10]       | this.numberOfItems = (this.numberOfItems - 1);  //  dest_result_addr=1152921513201578544
            this.numberOfItems = val_15;
            // 0x0168911C: CBNZ x20, #0x1689124       | if (this.binaryHeap != null) goto label_0;
            if(this.binaryHeap != null)
            {
                goto label_0;
            }
            // 0x01689120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01689124: LDR w8, [x20, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689128: CBNZ w8, #0x1689138        | if (this.binaryHeap.Length != 0) goto label_1;
            if(this.binaryHeap.Length != 0)
            {
                goto label_1;
            }
            // 0x0168912C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689134: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x01689138: LDR x8, [x20, #0x28]       | X8 = this.binaryHeap[1]                 
            Tuple val_16 = this.binaryHeap[1];
            // 0x0168913C: LDR x20, [x19, #0x18]      | X20 = this.binaryHeap; //P2             
            // 0x01689140: STR x8, [sp, #8]           | stack[1152921513201566376] = this.binaryHeap[1];  //  dest_result_addr=1152921513201566376
            // 0x01689144: CBZ x20, #0x1689154        | if (this.binaryHeap == null) goto label_2;
            if(this.binaryHeap == null)
            {
                goto label_2;
            }
            // 0x01689148: LDR w22, [x19, #0x10]      | W22 = this.numberOfItems; //P2          
            val_13 = this.numberOfItems;
            // 0x0168914C: MOV x21, x20               | X21 = this.binaryHeap;//m1              
            val_14 = this.binaryHeap;
            // 0x01689150: B #0x168916c               |  goto label_4;                          
            goto label_4;
            label_2:
            // 0x01689154: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x01689158: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_14 = this.binaryHeap;
            // 0x0168915C: LDR w22, [x19, #0x10]      | W22 = this.numberOfItems; //P2          
            val_13 = this.numberOfItems;
            // 0x01689160: CBNZ x21, #0x168916c       | if (this.binaryHeap != null) goto label_4;
            if(val_14 != null)
            {
                goto label_4;
            }
            // 0x01689164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x01689168: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_4:
            // 0x0168916C: LDR w8, [x20, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689170: CBNZ w8, #0x1689180        | if (this.binaryHeap.Length != 0) goto label_5;
            if(this.binaryHeap.Length != 0)
            {
                goto label_5;
            }
            // 0x01689174: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689178: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168917C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_5:
            // 0x01689180: LDR w8, [x21, #0x18]       | W8 = 0x9814C0;                          
            // 0x01689184: ADD x23, x20, #0x20        | X23 = this.binaryHeap[0x20]; //PARR1    
            // 0x01689188: SXTW x20, w22              | X20 = (long)(int)(this.numberOfItems);  
            // 0x0168918C: CMP w22, w8                | STATE = COMPARE(this.numberOfItems, 0x9814C0)
            // 0x01689190: B.LO #0x16891a0            | if (val_13 < 9966784) goto label_6;     
            if(val_13 < 9966784)
            {
                goto label_6;
            }
            // 0x01689194: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689198: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168919C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_6:
            // 0x016891A0: ADD x8, x21, x20, lsl #4   | X8 = (val_14 + ((long)(int)(this.numberOfItems)) << 4);
            var val_1 = val_14 + (((long)(int)(this.numberOfItems)) << 4);
            // 0x016891A4: LDR q0, [x8, #0x20]        | Q0 = (val_14 + ((long)(int)(this.numberOfItems)) << 4) + 32;
            // 0x016891A8: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x016891AC: STR q0, [x23]              | mem2[0] = (val_14 + ((long)(int)(this.numberOfItems)) << 4) + 32;  //  dest_result_addr=0
            mem2[0] = (val_14 + ((long)(int)(this.numberOfItems)) << 4) + 32;
            // 0x016891B0: B #0x16891c4               |  goto label_7;                          
            goto label_7;
            label_84:
            // 0x016891B4: LDR q0, [sp, #0x20]        | Q0 = val_2;                              //  find_add[1152921513201554528]
            // 0x016891B8: ADD x8, x21, x20, lsl #4   | X8 = (val_14 + 0) = 0 (0x00000000);     
            // 0x016891BC: MOV w20, w24               | W20 = W24;//m1                          
            val_16 = W24;
            // 0x016891C0: STR q0, [x8, #0x20]        | mem[32] = val_2;                         //  dest_result_addr=32
            mem[32] = val_2;
            label_7:
            // 0x016891C4: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_17 = this.binaryHeap;
            // 0x016891C8: CBNZ x21, #0x16891d0       | if (this.binaryHeap != null) goto label_8;
            if(val_17 != null)
            {
                goto label_8;
            }
            // 0x016891CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_8:
            // 0x016891D0: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x016891D4: SXTW x25, w20              | X25 = (long)(int)(W24);                 
            // 0x016891D8: CMP w20, w8                | STATE = COMPARE(W24, this.binaryHeap.Length)
            // 0x016891DC: B.LO #0x16891ec            | if (val_16 < this.binaryHeap.Length) goto label_9;
            if(val_16 < this.binaryHeap.Length)
            {
                goto label_9;
            }
            // 0x016891E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x016891E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016891E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_9:
            // 0x016891EC: ADD x8, x21, x25, lsl #4   | X8 = this.binaryHeap[((long)(int)(W24)) << 4]; //PARR1 
            // 0x016891F0: LDR w9, [x19, #0x10]       | W9 = this.numberOfItems; //P2           
            // 0x016891F4: LDR w27, [x8, #0x20]       | W27 = this.binaryHeap[((long)(int)(W24)) << 4][0]
            val_18 = val_17[((long)(int)(W24)) << 4];
            // 0x016891F8: ORR w26, wzr, #1           | W26 = 1(0x1);                           
            // 0x016891FC: BFI w26, w20, #2, #0x1e    | W26 = 1 | W24                           
            // 0x01689200: CMP w26, w9                | STATE = COMPARE(0x1, this.numberOfItems)
            // 0x01689204: B.GT #0x1689338            | if (1 > this.numberOfItems) goto label_16;
            if(1 > this.numberOfItems)
            {
                goto label_16;
            }
            // 0x01689208: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x0168920C: CBNZ x21, #0x1689214       | if (this.binaryHeap != null) goto label_11;
            if(this.binaryHeap != null)
            {
                goto label_11;
            }
            // 0x01689210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_11:
            // 0x01689214: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689218: SXTW x23, w26              | X23 = 1 (0x00000001);                   
            val_15 = 1;
            // 0x0168921C: CMP w26, w8                | STATE = COMPARE(0x1, this.binaryHeap.Length)
            // 0x01689220: B.LO #0x1689230            | if (1 < this.binaryHeap.Length) goto label_12;
            if(1 < this.binaryHeap.Length)
            {
                goto label_12;
            }
            // 0x01689224: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168922C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_12:
            // 0x01689230: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[0x10]; //PARR1     
            // 0x01689234: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[0x10][0]           
            Tuple val_17 = this.binaryHeap[16];
            // 0x01689238: CMP w8, w27                | STATE = COMPARE(this.binaryHeap[0x10][0], this.binaryHeap[((long)(int)(W24)) << 4][0])
            // 0x0168923C: B.LO #0x1689304            | if (this.binaryHeap[16] < val_18) goto label_13;
            if(val_17 < val_18)
            {
                goto label_13;
            }
            // 0x01689240: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_17 = this.binaryHeap;
            // 0x01689244: CBNZ x21, #0x168924c       | if (this.binaryHeap != null) goto label_14;
            if(val_17 != null)
            {
                goto label_14;
            }
            // 0x01689248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_14:
            // 0x0168924C: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689250: CMP w26, w8                | STATE = COMPARE(0x1, this.binaryHeap.Length)
            // 0x01689254: B.LO #0x1689264            | if (1 < this.binaryHeap.Length) goto label_15;
            if(1 < this.binaryHeap.Length)
            {
                goto label_15;
            }
            // 0x01689258: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x0168925C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689260: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_15:
            // 0x01689264: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[0x10]; //PARR1     
            // 0x01689268: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[0x10][0]           
            Tuple val_18 = val_17[16];
            // 0x0168926C: CMP w8, w27                | STATE = COMPARE(this.binaryHeap[0x10][0], this.binaryHeap[((long)(int)(W24)) << 4][0])
            // 0x01689270: B.NE #0x1689338            | if (val_17[16] != val_18) goto label_16;
            if(val_18 != val_18)
            {
                goto label_16;
            }
            // 0x01689274: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x01689278: CBNZ x21, #0x1689280       | if (this.binaryHeap != null) goto label_17;
            if(this.binaryHeap != null)
            {
                goto label_17;
            }
            // 0x0168927C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_17:
            // 0x01689280: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689284: CMP w26, w8                | STATE = COMPARE(0x1, this.binaryHeap.Length)
            // 0x01689288: B.LO #0x1689298            | if (1 < this.binaryHeap.Length) goto label_18;
            if(1 < this.binaryHeap.Length)
            {
                goto label_18;
            }
            // 0x0168928C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689290: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689294: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_18:
            // 0x01689298: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[0x10]; //PARR1     
            // 0x0168929C: LDR x21, [x8, #0x28]       | X21 = this.binaryHeap[0x10][1]          
            Tuple val_19 = this.binaryHeap[16];
            // 0x016892A0: CBNZ x21, #0x16892a8       | if (this.binaryHeap[0x10][1] != 0) goto label_19;
            if(val_19 != 0)
            {
                goto label_19;
            }
            // 0x016892A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_19:
            // 0x016892A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016892AC: MOV x0, x21                | X0 = this.binaryHeap[0x10][1];//m1      
            // 0x016892B0: BL #0x1405c90              | X0 = this.binaryHeap[0x10][1].get_G();  
            uint val_3 = val_19.G;
            // 0x016892B4: LDR x22, [x19, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x016892B8: MOV w21, w0                | W21 = val_3;//m1                        
            val_17 = val_3;
            // 0x016892BC: CBNZ x22, #0x16892c4       | if (this.binaryHeap != null) goto label_20;
            if(this.binaryHeap != null)
            {
                goto label_20;
            }
            // 0x016892C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_20:
            // 0x016892C4: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x016892C8: CMP w20, w8                | STATE = COMPARE(W24, this.binaryHeap.Length)
            // 0x016892CC: B.LO #0x16892dc            | if (val_16 < this.binaryHeap.Length) goto label_21;
            if(val_16 < this.binaryHeap.Length)
            {
                goto label_21;
            }
            // 0x016892D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x016892D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016892D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_21:
            // 0x016892DC: ADD x8, x22, x25, lsl #4   | X8 = this.binaryHeap[((long)(int)(W24)) << 4]; //PARR1 
            // 0x016892E0: LDR x22, [x8, #0x28]       | X22 = this.binaryHeap[((long)(int)(W24)) << 4][1]
            Tuple val_20 = this.binaryHeap[((long)(int)(W24)) << 4];
            // 0x016892E4: CBNZ x22, #0x16892ec       | if (this.binaryHeap[((long)(int)(W24)) << 4][1] != 0) goto label_22;
            if(val_20 != 0)
            {
                goto label_22;
            }
            // 0x016892E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_22:
            // 0x016892EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016892F0: MOV x0, x22                | X0 = this.binaryHeap[((long)(int)(W24)) << 4][1];//m1
            // 0x016892F4: BL #0x1405c90              | X0 = this.binaryHeap[((long)(int)(W24)) << 4][1].get_G();
            uint val_4 = val_20.G;
            // 0x016892F8: CMP w21, w0                | STATE = COMPARE(val_3, val_4)           
            // 0x016892FC: MOV w24, w20               | W24 = W24;//m1                          
            val_19 = val_16;
            // 0x01689300: B.HS #0x168933c            | if (val_17 >= val_4) goto label_26;     
            if(val_17 >= val_4)
            {
                goto label_26;
            }
            label_13:
            // 0x01689304: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_17 = this.binaryHeap;
            // 0x01689308: CBNZ x21, #0x1689310       | if (this.binaryHeap != null) goto label_24;
            if(val_17 != null)
            {
                goto label_24;
            }
            // 0x0168930C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_24:
            // 0x01689310: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689314: CMP w26, w8                | STATE = COMPARE(0x1, this.binaryHeap.Length)
            // 0x01689318: B.LO #0x1689328            | if (1 < this.binaryHeap.Length) goto label_25;
            if(1 < this.binaryHeap.Length)
            {
                goto label_25;
            }
            // 0x0168931C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x01689320: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689324: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_25:
            // 0x01689328: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[0x10]; //PARR1     
            // 0x0168932C: LDR w27, [x8, #0x20]       | W27 = this.binaryHeap[0x10][0]          
            val_18 = val_17[16];
            // 0x01689330: MOV w24, w26               | W24 = 1 (0x1);//ML01                    
            val_19 = 1;
            // 0x01689334: B #0x168933c               |  goto label_26;                         
            goto label_26;
            label_16:
            // 0x01689338: MOV w24, w20               | W24 = W24;//m1                          
            val_19 = val_16;
            label_26:
            // 0x0168933C: LDR w8, [x19, #0x10]       | W8 = this.numberOfItems; //P2           
            // 0x01689340: LSL w28, w20, #2           | W28 = (W24 << 2);                       
            var val_5 = val_16 << 2;
            // 0x01689344: STR x25, [sp, #0x18]       | stack[1152921513201566392] = (long)(int)(W24);  //  dest_result_addr=1152921513201566392
            // 0x01689348: CMP w26, w8                | STATE = COMPARE(0x1, this.numberOfItems)
            // 0x0168934C: B.GE #0x1689484            | if (1 >= this.numberOfItems) goto label_40;
            if(1 >= this.numberOfItems)
            {
                goto label_40;
            }
            // 0x01689350: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x01689354: ADD w25, w26, #1           | W25 = (1 + 1);                          
            var val_6 = 1 + 1;
            // 0x01689358: CBNZ x21, #0x1689360       | if (this.binaryHeap != null) goto label_28;
            if(this.binaryHeap != null)
            {
                goto label_28;
            }
            // 0x0168935C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_28:
            // 0x01689360: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689364: SXTW x23, w25              | X23 = (long)(int)((1 + 1));             
            val_15 = (long)val_6;
            // 0x01689368: CMP w25, w8                | STATE = COMPARE((1 + 1), this.binaryHeap.Length)
            // 0x0168936C: B.LO #0x168937c            | if (val_6 < this.binaryHeap.Length) goto label_29;
            if(val_6 < this.binaryHeap.Length)
            {
                goto label_29;
            }
            // 0x01689370: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689374: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689378: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_29:
            // 0x0168937C: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)((1 + 1))) << 4]; //PARR1 
            // 0x01689380: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((1 + 1))) << 4][0]
            Tuple val_21 = this.binaryHeap[((long)(int)((1 + 1))) << 4];
            // 0x01689384: CMP w8, w27                | STATE = COMPARE(this.binaryHeap[((long)(int)((1 + 1))) << 4][0], this.binaryHeap[((long)(int)(W24)) << 4][0])
            // 0x01689388: B.LO #0x1689454            | if (this.binaryHeap[((long)(int)((1 + 1))) << 4] < val_18) goto label_30;
            if(val_21 < val_18)
            {
                goto label_30;
            }
            // 0x0168938C: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_17 = this.binaryHeap;
            // 0x01689390: CBNZ x21, #0x1689398       | if (this.binaryHeap != null) goto label_31;
            if(val_17 != null)
            {
                goto label_31;
            }
            // 0x01689394: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_31:
            // 0x01689398: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x0168939C: CMP w25, w8                | STATE = COMPARE((1 + 1), this.binaryHeap.Length)
            // 0x016893A0: B.LO #0x16893b0            | if (val_6 < this.binaryHeap.Length) goto label_32;
            if(val_6 < this.binaryHeap.Length)
            {
                goto label_32;
            }
            // 0x016893A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x016893A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016893AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_32:
            // 0x016893B0: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)((1 + 1))) << 4]; //PARR1 
            // 0x016893B4: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((1 + 1))) << 4][0]
            Tuple val_22 = val_17[((long)(int)((1 + 1))) << 4];
            // 0x016893B8: CMP w8, w27                | STATE = COMPARE(this.binaryHeap[((long)(int)((1 + 1))) << 4][0], this.binaryHeap[((long)(int)(W24)) << 4][0])
            // 0x016893BC: B.NE #0x1689484            | if (val_17[((long)(int)((1 + 1))) << 4] != val_18) goto label_40;
            if(val_22 != val_18)
            {
                goto label_40;
            }
            // 0x016893C0: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x016893C4: CBNZ x21, #0x16893cc       | if (this.binaryHeap != null) goto label_34;
            if(this.binaryHeap != null)
            {
                goto label_34;
            }
            // 0x016893C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_34:
            // 0x016893CC: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x016893D0: CMP w25, w8                | STATE = COMPARE((1 + 1), this.binaryHeap.Length)
            // 0x016893D4: B.LO #0x16893e4            | if (val_6 < this.binaryHeap.Length) goto label_35;
            if(val_6 < this.binaryHeap.Length)
            {
                goto label_35;
            }
            // 0x016893D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x016893DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016893E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_35:
            // 0x016893E4: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)((1 + 1))) << 4]; //PARR1 
            // 0x016893E8: LDR x21, [x8, #0x28]       | X21 = this.binaryHeap[((long)(int)((1 + 1))) << 4][1]
            Tuple val_23 = this.binaryHeap[((long)(int)((1 + 1))) << 4];
            // 0x016893EC: CBNZ x21, #0x16893f4       | if (this.binaryHeap[((long)(int)((1 + 1))) << 4][1] != 0) goto label_36;
            if(val_23 != 0)
            {
                goto label_36;
            }
            // 0x016893F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_36:
            // 0x016893F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016893F8: MOV x0, x21                | X0 = this.binaryHeap[((long)(int)((1 + 1))) << 4][1];//m1
            // 0x016893FC: BL #0x1405c90              | X0 = this.binaryHeap[((long)(int)((1 + 1))) << 4][1].get_G();
            uint val_7 = val_23.G;
            // 0x01689400: LDR x22, [x19, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x01689404: STR w0, [sp, #0x14]        | stack[1152921513201566388] = val_7;      //  dest_result_addr=1152921513201566388
            // 0x01689408: CBNZ x22, #0x1689410       | if (this.binaryHeap != null) goto label_37;
            if(this.binaryHeap != null)
            {
                goto label_37;
            }
            // 0x0168940C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_37:
            // 0x01689410: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689414: SXTW x21, w24              | X21 = (long)(int)(W24);                 
            val_17 = (long)val_19;
            // 0x01689418: CMP w24, w8                | STATE = COMPARE(W24, this.binaryHeap.Length)
            // 0x0168941C: B.LO #0x168942c            | if (val_19 < this.binaryHeap.Length) goto label_38;
            if(val_19 < this.binaryHeap.Length)
            {
                goto label_38;
            }
            // 0x01689420: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x01689424: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689428: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_38:
            // 0x0168942C: ADD x8, x22, x21, lsl #4   | X8 = this.binaryHeap[((long)(int)(W24)) << 4]; //PARR1 
            // 0x01689430: LDR x22, [x8, #0x28]       | X22 = this.binaryHeap[((long)(int)(W24)) << 4][1]
            Tuple val_24 = this.binaryHeap[((long)(int)(W24)) << 4];
            // 0x01689434: CBNZ x22, #0x168943c       | if (this.binaryHeap[((long)(int)(W24)) << 4][1] != 0) goto label_39;
            if(val_24 != 0)
            {
                goto label_39;
            }
            // 0x01689438: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_39:
            // 0x0168943C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689440: MOV x0, x22                | X0 = this.binaryHeap[((long)(int)(W24)) << 4][1];//m1
            // 0x01689444: BL #0x1405c90              | X0 = this.binaryHeap[((long)(int)(W24)) << 4][1].get_G();
            uint val_8 = val_24.G;
            // 0x01689448: LDR w8, [sp, #0x14]        | W8 = val_7;                             
            // 0x0168944C: CMP w8, w0                 | STATE = COMPARE(val_7, val_8)           
            // 0x01689450: B.HS #0x1689484            | if (val_7 >= val_8) goto label_40;      
            if(val_7 >= val_8)
            {
                goto label_40;
            }
            label_30:
            // 0x01689454: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_17 = this.binaryHeap;
            // 0x01689458: CBNZ x21, #0x1689460       | if (this.binaryHeap != null) goto label_41;
            if(val_17 != null)
            {
                goto label_41;
            }
            // 0x0168945C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_41:
            // 0x01689460: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689464: CMP w25, w8                | STATE = COMPARE((1 + 1), this.binaryHeap.Length)
            // 0x01689468: B.LO #0x1689478            | if (val_6 < this.binaryHeap.Length) goto label_42;
            if(val_6 < this.binaryHeap.Length)
            {
                goto label_42;
            }
            // 0x0168946C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x01689470: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689474: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_42:
            // 0x01689478: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)((1 + 1))) << 4]; //PARR1 
            // 0x0168947C: LDR w27, [x8, #0x20]       | W27 = this.binaryHeap[((long)(int)((1 + 1))) << 4][0]
            val_18 = val_17[((long)(int)((1 + 1))) << 4];
            // 0x01689480: MOV w24, w25               | W24 = (1 + 1);//m1                      
            val_19 = val_6;
            label_40:
            // 0x01689484: LDR w8, [x19, #0x10]       | W8 = this.numberOfItems; //P2           
            // 0x01689488: ORR w28, w28, #3           | W28 = ((W24 << 2) | 3);                 
            val_5 = val_5 | 3;
            // 0x0168948C: CMP w28, w8                | STATE = COMPARE(((W24 << 2) | 3), this.numberOfItems)
            // 0x01689490: B.GT #0x16895c0            | if (val_5 > this.numberOfItems) goto label_56;
            if(val_5 > this.numberOfItems)
            {
                goto label_56;
            }
            // 0x01689494: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x01689498: CBNZ x21, #0x16894a0       | if (this.binaryHeap != null) goto label_44;
            if(this.binaryHeap != null)
            {
                goto label_44;
            }
            // 0x0168949C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_44:
            // 0x016894A0: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x016894A4: SXTW x23, w28              | X23 = (long)(int)(((W24 << 2) | 3));    
            val_15 = (long)val_5;
            // 0x016894A8: CMP w28, w8                | STATE = COMPARE(((W24 << 2) | 3), this.binaryHeap.Length)
            // 0x016894AC: B.LO #0x16894bc            | if (val_5 < this.binaryHeap.Length) goto label_45;
            if(val_5 < this.binaryHeap.Length)
            {
                goto label_45;
            }
            // 0x016894B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x016894B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016894B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_45:
            // 0x016894BC: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4]; //PARR1 
            // 0x016894C0: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][0]
            Tuple val_25 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4];
            // 0x016894C4: CMP w8, w27                | STATE = COMPARE(this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][0], this.binaryHeap[((long)(int)((1 + 1))) << 4][0])
            // 0x016894C8: B.LO #0x1689590            | if (this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4] < val_18) goto label_46;
            if(val_25 < val_18)
            {
                goto label_46;
            }
            // 0x016894CC: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_17 = this.binaryHeap;
            // 0x016894D0: CBNZ x21, #0x16894d8       | if (this.binaryHeap != null) goto label_47;
            if(val_17 != null)
            {
                goto label_47;
            }
            // 0x016894D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_47:
            // 0x016894D8: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x016894DC: CMP w28, w8                | STATE = COMPARE(((W24 << 2) | 3), this.binaryHeap.Length)
            // 0x016894E0: B.LO #0x16894f0            | if (val_5 < this.binaryHeap.Length) goto label_48;
            if(val_5 < this.binaryHeap.Length)
            {
                goto label_48;
            }
            // 0x016894E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x016894E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016894EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_48:
            // 0x016894F0: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4]; //PARR1 
            // 0x016894F4: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][0]
            Tuple val_26 = val_17[((long)(int)(((W24 << 2) | 3))) << 4];
            // 0x016894F8: CMP w8, w27                | STATE = COMPARE(this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][0], this.binaryHeap[((long)(int)((1 + 1))) << 4][0])
            // 0x016894FC: B.NE #0x16895c0            | if (val_17[((long)(int)(((W24 << 2) | 3))) << 4] != val_18) goto label_56;
            if(val_26 != val_18)
            {
                goto label_56;
            }
            // 0x01689500: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x01689504: CBNZ x21, #0x168950c       | if (this.binaryHeap != null) goto label_50;
            if(this.binaryHeap != null)
            {
                goto label_50;
            }
            // 0x01689508: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_50:
            // 0x0168950C: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689510: CMP w28, w8                | STATE = COMPARE(((W24 << 2) | 3), this.binaryHeap.Length)
            // 0x01689514: B.LO #0x1689524            | if (val_5 < this.binaryHeap.Length) goto label_51;
            if(val_5 < this.binaryHeap.Length)
            {
                goto label_51;
            }
            // 0x01689518: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x0168951C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689520: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_51:
            // 0x01689524: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4]; //PARR1 
            // 0x01689528: LDR x21, [x8, #0x28]       | X21 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][1]
            Tuple val_27 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4];
            // 0x0168952C: CBNZ x21, #0x1689534       | if (this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][1] != 0) goto label_52;
            if(val_27 != 0)
            {
                goto label_52;
            }
            // 0x01689530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_52:
            // 0x01689534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689538: MOV x0, x21                | X0 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][1];//m1
            // 0x0168953C: BL #0x1405c90              | X0 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][1].get_G();
            uint val_9 = val_27.G;
            // 0x01689540: LDR x22, [x19, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x01689544: MOV w21, w0                | W21 = val_9;//m1                        
            val_17 = val_9;
            // 0x01689548: CBNZ x22, #0x1689550       | if (this.binaryHeap != null) goto label_53;
            if(this.binaryHeap != null)
            {
                goto label_53;
            }
            // 0x0168954C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_53:
            // 0x01689550: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689554: SXTW x25, w24              | X25 = (long)(int)((1 + 1));             
            // 0x01689558: CMP w24, w8                | STATE = COMPARE((1 + 1), this.binaryHeap.Length)
            // 0x0168955C: B.LO #0x168956c            | if (val_19 < this.binaryHeap.Length) goto label_54;
            if(val_19 < this.binaryHeap.Length)
            {
                goto label_54;
            }
            // 0x01689560: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x01689564: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689568: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_54:
            // 0x0168956C: ADD x8, x22, x25, lsl #4   | X8 = this.binaryHeap[((long)(int)((1 + 1))) << 4]; //PARR1 
            // 0x01689570: LDR x22, [x8, #0x28]       | X22 = this.binaryHeap[((long)(int)((1 + 1))) << 4][1]
            Tuple val_28 = this.binaryHeap[((long)(int)((1 + 1))) << 4];
            // 0x01689574: CBNZ x22, #0x168957c       | if (this.binaryHeap[((long)(int)((1 + 1))) << 4][1] != 0) goto label_55;
            if(val_28 != 0)
            {
                goto label_55;
            }
            // 0x01689578: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_55:
            // 0x0168957C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689580: MOV x0, x22                | X0 = this.binaryHeap[((long)(int)((1 + 1))) << 4][1];//m1
            // 0x01689584: BL #0x1405c90              | X0 = this.binaryHeap[((long)(int)((1 + 1))) << 4][1].get_G();
            uint val_10 = val_28.G;
            // 0x01689588: CMP w21, w0                | STATE = COMPARE(val_9, val_10)          
            // 0x0168958C: B.HS #0x16895c0            | if (val_17 >= val_10) goto label_56;    
            if(val_17 >= val_10)
            {
                goto label_56;
            }
            label_46:
            // 0x01689590: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_17 = this.binaryHeap;
            // 0x01689594: CBNZ x21, #0x168959c       | if (this.binaryHeap != null) goto label_57;
            if(val_17 != null)
            {
                goto label_57;
            }
            // 0x01689598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_57:
            // 0x0168959C: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x016895A0: CMP w28, w8                | STATE = COMPARE(((W24 << 2) | 3), this.binaryHeap.Length)
            // 0x016895A4: B.LO #0x16895b4            | if (val_5 < this.binaryHeap.Length) goto label_58;
            if(val_5 < this.binaryHeap.Length)
            {
                goto label_58;
            }
            // 0x016895A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x016895AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016895B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_58:
            // 0x016895B4: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4]; //PARR1 
            // 0x016895B8: LDR w27, [x8, #0x20]       | W27 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][0]
            val_18 = val_17[((long)(int)(((W24 << 2) | 3))) << 4];
            // 0x016895BC: MOV w24, w28               | W24 = ((W24 << 2) | 3);//m1             
            val_19 = val_5;
            label_56:
            // 0x016895C0: LDR w8, [x19, #0x10]       | W8 = this.numberOfItems; //P2           
            // 0x016895C4: ADD w25, w26, #3           | W25 = (1 + 3);                          
            var val_11 = 1 + 3;
            // 0x016895C8: CMP w25, w8                | STATE = COMPARE((1 + 3), this.numberOfItems)
            // 0x016895CC: B.GT #0x16896f4            | if (val_11 > this.numberOfItems) goto label_72;
            if(val_11 > this.numberOfItems)
            {
                goto label_72;
            }
            // 0x016895D0: LDR x22, [x19, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x016895D4: CBNZ x22, #0x16895dc       | if (this.binaryHeap != null) goto label_60;
            if(this.binaryHeap != null)
            {
                goto label_60;
            }
            // 0x016895D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_60:
            // 0x016895DC: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x016895E0: SXTW x21, w25              | X21 = (long)(int)((1 + 3));             
            val_17 = (long)val_11;
            // 0x016895E4: CMP w25, w8                | STATE = COMPARE((1 + 3), this.binaryHeap.Length)
            // 0x016895E8: B.LO #0x16895f8            | if (val_11 < this.binaryHeap.Length) goto label_61;
            if(val_11 < this.binaryHeap.Length)
            {
                goto label_61;
            }
            // 0x016895EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x016895F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016895F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_61:
            // 0x016895F8: ADD x8, x22, x21, lsl #4   | X8 = this.binaryHeap[((long)(int)((1 + 3))) << 4]; //PARR1 
            // 0x016895FC: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((1 + 3))) << 4][0]
            Tuple val_29 = this.binaryHeap[((long)(int)((1 + 3))) << 4];
            // 0x01689600: CMP w8, w27                | STATE = COMPARE(this.binaryHeap[((long)(int)((1 + 3))) << 4][0], this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][0])
            // 0x01689604: B.LO #0x16896cc            | if (this.binaryHeap[((long)(int)((1 + 3))) << 4] < val_18) goto label_62;
            if(val_29 < val_18)
            {
                goto label_62;
            }
            // 0x01689608: LDR x22, [x19, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x0168960C: CBNZ x22, #0x1689614       | if (this.binaryHeap != null) goto label_63;
            if(this.binaryHeap != null)
            {
                goto label_63;
            }
            // 0x01689610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_63:
            // 0x01689614: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689618: CMP w25, w8                | STATE = COMPARE((1 + 3), this.binaryHeap.Length)
            // 0x0168961C: B.LO #0x168962c            | if (val_11 < this.binaryHeap.Length) goto label_64;
            if(val_11 < this.binaryHeap.Length)
            {
                goto label_64;
            }
            // 0x01689620: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x01689624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689628: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_64:
            // 0x0168962C: ADD x8, x22, x21, lsl #4   | X8 = this.binaryHeap[((long)(int)((1 + 3))) << 4]; //PARR1 
            // 0x01689630: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((1 + 3))) << 4][0]
            Tuple val_30 = this.binaryHeap[((long)(int)((1 + 3))) << 4];
            // 0x01689634: CMP w8, w27                | STATE = COMPARE(this.binaryHeap[((long)(int)((1 + 3))) << 4][0], this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][0])
            // 0x01689638: B.NE #0x16896f4            | if (this.binaryHeap[((long)(int)((1 + 3))) << 4] != val_18) goto label_72;
            if(val_30 != val_18)
            {
                goto label_72;
            }
            // 0x0168963C: LDR x22, [x19, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x01689640: CBNZ x22, #0x1689648       | if (this.binaryHeap != null) goto label_66;
            if(this.binaryHeap != null)
            {
                goto label_66;
            }
            // 0x01689644: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_66:
            // 0x01689648: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x0168964C: CMP w25, w8                | STATE = COMPARE((1 + 3), this.binaryHeap.Length)
            // 0x01689650: B.LO #0x1689660            | if (val_11 < this.binaryHeap.Length) goto label_67;
            if(val_11 < this.binaryHeap.Length)
            {
                goto label_67;
            }
            // 0x01689654: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x01689658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168965C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_67:
            // 0x01689660: ADD x8, x22, x21, lsl #4   | X8 = this.binaryHeap[((long)(int)((1 + 3))) << 4]; //PARR1 
            // 0x01689664: LDR x21, [x8, #0x28]       | X21 = this.binaryHeap[((long)(int)((1 + 3))) << 4][1]
            Tuple val_31 = this.binaryHeap[((long)(int)((1 + 3))) << 4];
            // 0x01689668: CBNZ x21, #0x1689670       | if (this.binaryHeap[((long)(int)((1 + 3))) << 4][1] != 0) goto label_68;
            if(val_31 != 0)
            {
                goto label_68;
            }
            // 0x0168966C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_68:
            // 0x01689670: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689674: MOV x0, x21                | X0 = this.binaryHeap[((long)(int)((1 + 3))) << 4][1];//m1
            // 0x01689678: BL #0x1405c90              | X0 = this.binaryHeap[((long)(int)((1 + 3))) << 4][1].get_G();
            uint val_12 = val_31.G;
            // 0x0168967C: LDR x22, [x19, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x01689680: MOV w21, w0                | W21 = val_12;//m1                       
            val_17 = val_12;
            // 0x01689684: CBNZ x22, #0x168968c       | if (this.binaryHeap != null) goto label_69;
            if(this.binaryHeap != null)
            {
                goto label_69;
            }
            // 0x01689688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_69:
            // 0x0168968C: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689690: SXTW x23, w24              | X23 = (long)(int)(((W24 << 2) | 3));    
            val_15 = (long)val_19;
            // 0x01689694: CMP w24, w8                | STATE = COMPARE(((W24 << 2) | 3), this.binaryHeap.Length)
            // 0x01689698: B.LO #0x16896a8            | if (val_19 < this.binaryHeap.Length) goto label_70;
            if(val_19 < this.binaryHeap.Length)
            {
                goto label_70;
            }
            // 0x0168969C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
            // 0x016896A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016896A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_70:
            // 0x016896A8: ADD x8, x22, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4]; //PARR1 
            // 0x016896AC: LDR x22, [x8, #0x28]       | X22 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][1]
            Tuple val_32 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4];
            // 0x016896B0: CBNZ x22, #0x16896b8       | if (this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][1] != 0) goto label_71;
            if(val_32 != 0)
            {
                goto label_71;
            }
            // 0x016896B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_71:
            // 0x016896B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016896BC: MOV x0, x22                | X0 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][1];//m1
            // 0x016896C0: BL #0x1405c90              | X0 = this.binaryHeap[((long)(int)(((W24 << 2) | 3))) << 4][1].get_G();
            uint val_13 = val_32.G;
            // 0x016896C4: CMP w21, w0                | STATE = COMPARE(val_12, val_13)         
            // 0x016896C8: B.HS #0x16896f4            | if (val_17 >= val_13) goto label_72;    
            if(val_17 >= val_13)
            {
                goto label_72;
            }
            label_62:
            // 0x016896CC: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_17 = this.binaryHeap;
            // 0x016896D0: CBNZ x21, #0x16896d8       | if (this.binaryHeap != null) goto label_73;
            if(val_17 != null)
            {
                goto label_73;
            }
            // 0x016896D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_73:
            // 0x016896D8: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x016896DC: CMP w25, w8                | STATE = COMPARE((1 + 3), this.binaryHeap.Length)
            // 0x016896E0: B.LO #0x16896f0            | if (val_11 < this.binaryHeap.Length) goto label_74;
            if(val_11 < this.binaryHeap.Length)
            {
                goto label_74;
            }
            // 0x016896E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x016896E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016896EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_74:
            // 0x016896F0: MOV w24, w25               | W24 = (1 + 3);//m1                      
            val_19 = val_11;
            label_72:
            // 0x016896F4: CMP w20, w24               | STATE = COMPARE(W24, (1 + 3))           
            // 0x016896F8: B.EQ #0x16897c8            | if (val_16 == val_19) goto label_75;    
            if(val_16 == val_19)
            {
                goto label_75;
            }
            // 0x016896FC: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x01689700: CBNZ x21, #0x1689708       | if (this.binaryHeap != null) goto label_76;
            if(this.binaryHeap != null)
            {
                goto label_76;
            }
            // 0x01689704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_76:
            // 0x01689708: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x0168970C: LDR x23, [sp, #0x18]       | X23 = (long)(int)(W24);                 
            // 0x01689710: CMP w20, w8                | STATE = COMPARE(W24, this.binaryHeap.Length)
            // 0x01689714: B.LO #0x1689724            | if (val_16 < this.binaryHeap.Length) goto label_77;
            if(val_16 < this.binaryHeap.Length)
            {
                goto label_77;
            }
            // 0x01689718: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x0168971C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689720: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_77:
            // 0x01689724: ADD x8, x21, x23, lsl #4   | X8 = this.binaryHeap[((long)(int)(W24)) << 4]; //PARR1 
            // 0x01689728: LDR q0, [x8, #0x20]        | Q0 = this.binaryHeap[((long)(int)(W24)) << 4][0]
            Tuple val_33 = this.binaryHeap[((long)(int)(W24)) << 4];
            // 0x0168972C: STR q0, [sp, #0x30]        | stack[1152921513201566416] = this.binaryHeap[((long)(int)(W24)) << 4][0];  //  dest_result_addr=1152921513201566416
            // 0x01689730: LDR x22, [x19, #0x18]      | X22 = this.binaryHeap; //P2             
            // 0x01689734: MOV x21, x22               | X21 = this.binaryHeap;//m1              
            val_20 = this.binaryHeap;
            // 0x01689738: CBNZ x22, #0x1689750       | if (this.binaryHeap != null) goto label_79;
            if(this.binaryHeap != null)
            {
                goto label_79;
            }
            // 0x0168973C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            // 0x01689740: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            val_20 = this.binaryHeap;
            // 0x01689744: CBNZ x21, #0x1689750       | if (this.binaryHeap != null) goto label_79;
            if(val_20 != null)
            {
                goto label_79;
            }
            // 0x01689748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            // 0x0168974C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_79:
            // 0x01689750: LDR w8, [x22, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689754: CMP w20, w8                | STATE = COMPARE(W24, this.binaryHeap.Length)
            // 0x01689758: B.LO #0x1689768            | if (val_16 < this.binaryHeap.Length) goto label_80;
            if(val_16 < this.binaryHeap.Length)
            {
                goto label_80;
            }
            // 0x0168975C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x01689760: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689764: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_80:
            // 0x01689768: LDR w8, [x21, #0x18]       | W8 = 0x9814C0;                          
            // 0x0168976C: ADD x9, x22, x23, lsl #4   | X9 = this.binaryHeap[((long)(int)(W24)) << 4]; //PARR1 
            // 0x01689770: ADD x22, x9, #0x20         | X22 = this.binaryHeap[((long)(int)(W24)) << 4][0x20]; //PARR1 
            // 0x01689774: SXTW x20, w24              | X20 = (long)(int)((1 + 3));             
            // 0x01689778: CMP w24, w8                | STATE = COMPARE((1 + 3), 0x9814C0)      
            // 0x0168977C: B.LO #0x168978c            | if (val_19 < 9966784) goto label_81;    
            if(val_19 < 9966784)
            {
                goto label_81;
            }
            // 0x01689780: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x01689784: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689788: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_81:
            // 0x0168978C: ADD x8, x21, x20, lsl #4   | X8 = (val_20 + ((long)(int)((1 + 3))) << 4);
            var val_14 = val_20 + (((long)(int)((1 + 3))) << 4);
            // 0x01689790: LDR q0, [x8, #0x20]        | Q0 = (val_20 + ((long)(int)((1 + 3))) << 4) + 32;
            // 0x01689794: STR q0, [x22]              | mem2[0] = (val_20 + ((long)(int)((1 + 3))) << 4) + 32;  //  dest_result_addr=0
            mem2[0] = (val_20 + ((long)(int)((1 + 3))) << 4) + 32;
            // 0x01689798: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x0168979C: CBNZ x21, #0x16897a4       | if (this.binaryHeap != null) goto label_82;
            if(this.binaryHeap != null)
            {
                goto label_82;
            }
            // 0x016897A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_82:
            // 0x016897A4: LDR q0, [sp, #0x30]        | Q0 = this.binaryHeap[((long)(int)(W24)) << 4][0];
            // 0x016897A8: STR q0, [sp, #0x20]        | val_2 = this.binaryHeap[((long)(int)(W24)) << 4][0];  //  dest_result_addr=1152921513201566400
            val_2 = val_33;
            // 0x016897AC: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x016897B0: CMP w24, w8                | STATE = COMPARE((1 + 3), this.binaryHeap.Length)
            // 0x016897B4: B.LO #0x16891b4            | if (val_19 < this.binaryHeap.Length) goto label_84;
            if(val_19 < this.binaryHeap.Length)
            {
                goto label_84;
            }
            // 0x016897B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x016897BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016897C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x016897C4: B #0x16891b4               |  goto label_84;                         
            goto label_84;
            label_75:
            // 0x016897C8: LDR x0, [sp, #8]           | X0 = this.binaryHeap[1];                
            // 0x016897CC: SUB sp, x29, #0x50         | SP = (1152921513201566512 - 80) = 1152921513201566432 (0x10000002004902E0);
            // 0x016897D0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x016897D4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x016897D8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x016897DC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x016897E0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x016897E4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x016897E8: RET                        |  return (Pathfinding.PathNode)this.binaryHeap[1];
            return (Pathfinding.PathNode)val_16;
            //  |  // // {name=val_0, type=Pathfinding.PathNode, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x016897EC (23631852), len: 1272  VirtAddr: 0x016897EC RVA: 0x016897EC token: 100682144 methodIndex: 49918 delegateWrapperIndex: 0 methodInvoker: 0
        private void Validate()
        {
            //
            // Disasemble & Code
            // 0x016897EC: STP x26, x25, [sp, #-0x50]! | stack[1152921513202806224] = ???;  stack[1152921513202806232] = ???;  //  dest_result_addr=1152921513202806224 |  dest_result_addr=1152921513202806232
            // 0x016897F0: STP x24, x23, [sp, #0x10]  | stack[1152921513202806240] = ???;  stack[1152921513202806248] = ???;  //  dest_result_addr=1152921513202806240 |  dest_result_addr=1152921513202806248
            // 0x016897F4: STP x22, x21, [sp, #0x20]  | stack[1152921513202806256] = ???;  stack[1152921513202806264] = ???;  //  dest_result_addr=1152921513202806256 |  dest_result_addr=1152921513202806264
            // 0x016897F8: STP x20, x19, [sp, #0x30]  | stack[1152921513202806272] = ???;  stack[1152921513202806280] = ???;  //  dest_result_addr=1152921513202806272 |  dest_result_addr=1152921513202806280
            // 0x016897FC: STP x29, x30, [sp, #0x40]  | stack[1152921513202806288] = ???;  stack[1152921513202806296] = ???;  //  dest_result_addr=1152921513202806288 |  dest_result_addr=1152921513202806296
            // 0x01689800: ADD x29, sp, #0x40         | X29 = (1152921513202806224 + 64) = 1152921513202806288 (0x10000002005BEE10);
            // 0x01689804: SUB sp, sp, #0x30          | SP = (1152921513202806224 - 48) = 1152921513202806176 (0x10000002005BEDA0);
            // 0x01689808: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168980C: LDRB w8, [x20, #0xfc]      | W8 = (bool)static_value_037380FC;       
            // 0x01689810: MOV x19, x0                | X19 = 1152921513202818304 (0x10000002005C1D00);//ML01
            // 0x01689814: TBNZ w8, #0, #0x1689830    | if (static_value_037380FC == true) goto label_0;
            // 0x01689818: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x0168981C: LDR x8, [x8, #0x250]       | X8 = 0x2B8F4B8;                         
            // 0x01689820: LDR w0, [x8]               | W0 = 0x13F0;                            
            // 0x01689824: BL #0x2782188              | X0 = sub_2782188( ?? 0x13F0, ????);     
            // 0x01689828: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168982C: STRB w8, [x20, #0xfc]      | static_value_037380FC = true;            //  dest_result_addr=57901308
            label_0:
            // 0x01689830: LDR w8, [x19, #0x10]       | W8 = this.numberOfItems; //P2           
            // 0x01689834: CMP w8, #2                 | STATE = COMPARE(this.numberOfItems, 0x2)
            // 0x01689838: B.LT #0x16898d0            | if (this.numberOfItems < 2) goto label_1;
            if(this.numberOfItems < 2)
            {
                goto label_1;
            }
            // 0x0168983C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            var val_11 = 0;
            label_7:
            // 0x01689840: LDR x23, [x19, #0x18]      | X23 = this.binaryHeap; //P2             
            // 0x01689844: ADD w8, w20, #3            | W8 = (0 + 3);                           
            var val_1 = val_11 + 3;
            // 0x01689848: CMP w20, #0                | STATE = COMPARE(0x0, 0x0)               
            // 0x0168984C: CSEL w8, w8, w20, lt       | W8 = 0 < 0x0 ? (0 + 3) : 0;             
            var val_2 = (val_11 < 0) ? (val_1) : (val_11);
            // 0x01689850: ASR w21, w8, #2            | W21 = (0 < 0x0 ? (0 + 3) : 0 >> 2);     
            int val_3 = val_2 >> 2;
            // 0x01689854: CBNZ x23, #0x168985c       | if (this.binaryHeap != null) goto label_2;
            if(this.binaryHeap != null)
            {
                goto label_2;
            }
            // 0x01689858: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13F0, ????);     
            label_2:
            // 0x0168985C: LDR w8, [x23, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689860: SXTW x22, w21              | X22 = (long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2));
            // 0x01689864: CMP w21, w8                | STATE = COMPARE((0 < 0x0 ? (0 + 3) : 0 >> 2), this.binaryHeap.Length)
            // 0x01689868: B.LO #0x1689878            | if (val_3 < this.binaryHeap.Length) goto label_3;
            if(val_3 < this.binaryHeap.Length)
            {
                goto label_3;
            }
            // 0x0168986C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x13F0, ????);     
            // 0x01689870: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689874: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x13F0, ????);     
            label_3:
            // 0x01689878: ADD x8, x23, x22, lsl #4   | X8 = this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4]; //PARR1 
            // 0x0168987C: LDR w23, [x8, #0x20]       | W23 = this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0]
            Tuple val_9 = this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4];
            // 0x01689880: LDR x24, [x19, #0x18]      | X24 = this.binaryHeap; //P2             
            // 0x01689884: ADD w26, w20, #1           | W26 = (0 + 1);                          
            var val_4 = val_11 + 1;
            // 0x01689888: CBNZ x24, #0x1689890       | if (this.binaryHeap != null) goto label_4;
            if(this.binaryHeap != null)
            {
                goto label_4;
            }
            // 0x0168988C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13F0, ????);     
            label_4:
            // 0x01689890: LDR w8, [x24, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689894: SXTW x25, w26              | X25 = (long)(int)((0 + 1));             
            // 0x01689898: CMP w26, w8                | STATE = COMPARE((0 + 1), this.binaryHeap.Length)
            // 0x0168989C: B.LO #0x16898ac            | if (val_4 < this.binaryHeap.Length) goto label_5;
            if(val_4 < this.binaryHeap.Length)
            {
                goto label_5;
            }
            // 0x016898A0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x13F0, ????);     
            // 0x016898A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016898A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x13F0, ????);     
            label_5:
            // 0x016898AC: ADD x8, x24, x25, lsl #4   | X8 = this.binaryHeap[((long)(int)((0 + 1))) << 4]; //PARR1 
            // 0x016898B0: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((0 + 1))) << 4][0]
            Tuple val_10 = this.binaryHeap[((long)(int)((0 + 1))) << 4];
            // 0x016898B4: CMP w23, w8                | STATE = COMPARE(this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0], this.binaryHeap[((long)(int)((0 + 1))) << 4][0])
            // 0x016898B8: B.HI #0x16898ec            | if (this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4] > this.binaryHeap[((long)(int)((0 + 1))) << 4]) goto label_6;
            if(val_9 > val_10)
            {
                goto label_6;
            }
            // 0x016898BC: LDR w8, [x19, #0x10]       | W8 = this.numberOfItems; //P2           
            // 0x016898C0: ADD w9, w20, #2            | W9 = (0 + 2);                           
            var val_5 = val_11 + 2;
            // 0x016898C4: ADD w20, w20, #1           | W20 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x016898C8: CMP w9, w8                 | STATE = COMPARE((0 + 2), this.numberOfItems)
            // 0x016898CC: B.LT #0x1689840            | if (val_5 < this.numberOfItems) goto label_7;
            if(val_5 < this.numberOfItems)
            {
                goto label_7;
            }
            label_1:
            // 0x016898D0: SUB sp, x29, #0x40         | SP = (1152921513202806288 - 64) = 1152921513202806224 (0x10000002005BEDD0);
            // 0x016898D4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x016898D8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x016898DC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x016898E0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x016898E4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x016898E8: RET                        |  return;                                
            return;
            label_6:
            // 0x016898EC: STP x22, x25, [sp, #8]     | stack[1152921513202806184] = (long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2));  stack[1152921513202806192] = (long)(int)((0 + 1));  //  dest_result_addr=1152921513202806184 |  dest_result_addr=1152921513202806192
            // 0x016898F0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x016898F4: STR x19, [sp, #0x18]       | stack[1152921513202806200] = this;       //  dest_result_addr=1152921513202806200
            // 0x016898F8: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x016898FC: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
            // 0x01689900: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01689904: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x01689908: MOVZ w1, #0x9              | W1 = 9 (0x9);//ML01                     
            // 0x0168990C: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01689910: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x01689914: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01689918: CBNZ x19, #0x1689920       | if ( != null) goto label_8;             
            if(null != null)
            {
                goto label_8;
            }
            // 0x0168991C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_8:
            // 0x01689920: ADRP x23, #0x3674000       | X23 = 57098240 (0x3674000);             
            // 0x01689924: LDR x23, [x23, #0x568]     | X23 = (string**)(1152921513202772448)("Invalid state at ");
            // 0x01689928: ADD w22, w20, #1           | W22 = (0 + 1);                          
            int val_6 = val_11 + 1;
            // 0x0168992C: LDR x0, [x23]              | X0 = "Invalid state at ";               
            // 0x01689930: CBZ x0, #0x1689950         | if ("Invalid state at " == null) goto label_10;
            // 0x01689934: LDR x8, [x19]              | X8 = ;                                  
            // 0x01689938: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0168993C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "Invalid state at ", ????);
            // 0x01689940: CBNZ x0, #0x1689950        | if ("Invalid state at " != null) goto label_10;
            if("Invalid state at " != null)
            {
                goto label_10;
            }
            // 0x01689944: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "Invalid state at ", ????);
            // 0x01689948: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168994C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Invalid state at ", ????);
            label_10:
            // 0x01689950: LDR x20, [x23]             | X20 = "Invalid state at ";              
            // 0x01689954: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01689958: CBNZ w8, #0x1689968        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_11;
            // 0x0168995C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "Invalid state at ", ????);
            // 0x01689960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689964: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Invalid state at ", ????);
            label_11:
            // 0x01689968: STR x20, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "Invalid state at ";  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = "Invalid state at ";
            // 0x0168996C: ADRP x23, #0x3652000       | X23 = 56958976 (0x3652000);             
            // 0x01689970: LDR x23, [x23, #0x140]     | X23 = 1152921504607113216;              
            // 0x01689974: ADD x1, sp, #0x2c          | X1 = (1152921513202806176 + 44) = 1152921513202806220 (0x10000002005BEDCC);
            // 0x01689978: STR w22, [sp, #0x2c]       | stack[1152921513202806220] = (0 + 1);    //  dest_result_addr=1152921513202806220
            // 0x0168997C: LDR x0, [x23]              | X0 = typeof(System.Int32);              
            // 0x01689980: BL #0x27bc028              | X0 = 1152921513202924032 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (0 + 1));
            // 0x01689984: MOV x20, x0                | X20 = 1152921513202924032 (0x10000002005DBA00);//ML01
            // 0x01689988: CBZ x20, #0x16899ac        | if ((0 + 1) == 0) goto label_13;        
            if(val_6 == 0)
            {
                goto label_13;
            }
            // 0x0168998C: LDR x8, [x19]              | X8 = ;                                  
            // 0x01689990: MOV x0, x20                | X0 = 1152921513202924032 (0x10000002005DBA00);//ML01
            // 0x01689994: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01689998: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (0 + 1), ????);    
            // 0x0168999C: CBNZ x0, #0x16899ac        | if ((0 + 1) != 0) goto label_13;        
            if(val_6 != 0)
            {
                goto label_13;
            }
            // 0x016899A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (0 + 1), ????);    
            // 0x016899A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016899A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (0 + 1), ????);    
            label_13:
            // 0x016899AC: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x016899B0: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x016899B4: B.HI #0x16899c4            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_14;
            // 0x016899B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (0 + 1), ????);    
            // 0x016899BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016899C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (0 + 1), ????);    
            label_14:
            // 0x016899C4: STR x20, [x19, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = (0 + 1); typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_6;
            typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
            // 0x016899C8: ADRP x20, #0x3632000       | X20 = 56827904 (0x3632000);             
            // 0x016899CC: LDR x20, [x20, #0xc30]     | X20 = (string**)(1152921509929921648)(":");
            // 0x016899D0: LDR x0, [x20]              | X0 = ":";                               
            // 0x016899D4: CBZ x0, #0x16899f4         | if (":" == null) goto label_16;         
            // 0x016899D8: LDR x8, [x19]              | X8 = ;                                  
            // 0x016899DC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x016899E0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ":", ????);        
            // 0x016899E4: CBNZ x0, #0x16899f4        | if (":" != null) goto label_16;         
            if((":") != null)
            {
                goto label_16;
            }
            // 0x016899E8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ":", ????);        
            // 0x016899EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016899F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ":", ????);        
            label_16:
            // 0x016899F4: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x016899F8: LDR x20, [x20]             | X20 = ":";                              
            // 0x016899FC: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x01689A00: B.HI #0x1689a10            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_17;
            // 0x01689A04: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ":", ????);        
            // 0x01689A08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689A0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ":", ????);        
            label_17:
            // 0x01689A10: STR x20, [x19, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = ":";  //  dest_result_addr=1152921504954501312
            typeof(System.Object[]).__il2cppRuntimeField_30 = ":";
            // 0x01689A14: LDR x0, [x23]              | X0 = typeof(System.Int32);              
            // 0x01689A18: ADD x1, sp, #0x28          | X1 = (1152921513202806176 + 40) = 1152921513202806216 (0x10000002005BEDC8);
            // 0x01689A1C: STR w21, [sp, #0x28]       | stack[1152921513202806216] = (0 < 0x0 ? (0 + 3) : 0 >> 2);  //  dest_result_addr=1152921513202806216
            // 0x01689A20: BL #0x27bc028              | X0 = 1152921513202928128 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (0 < 0x0 ? (0 + 3) : 0 >> 2));
            // 0x01689A24: MOV x20, x0                | X20 = 1152921513202928128 (0x10000002005DCA00);//ML01
            // 0x01689A28: CBZ x20, #0x1689a4c        | if ((0 < 0x0 ? (0 + 3) : 0 >> 2) == 0) goto label_19;
            if(val_3 == 0)
            {
                goto label_19;
            }
            // 0x01689A2C: LDR x8, [x19]              | X8 = ;                                  
            // 0x01689A30: MOV x0, x20                | X0 = 1152921513202928128 (0x10000002005DCA00);//ML01
            // 0x01689A34: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01689A38: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (0 < 0x0 ? (0 + 3) : 0 >> 2), ????);
            // 0x01689A3C: CBNZ x0, #0x1689a4c        | if ((0 < 0x0 ? (0 + 3) : 0 >> 2) != 0) goto label_19;
            if(val_3 != 0)
            {
                goto label_19;
            }
            // 0x01689A40: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (0 < 0x0 ? (0 + 3) : 0 >> 2), ????);
            // 0x01689A44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689A48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (0 < 0x0 ? (0 + 3) : 0 >> 2), ????);
            label_19:
            // 0x01689A4C: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01689A50: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x01689A54: B.HI #0x1689a64            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_20;
            // 0x01689A58: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (0 < 0x0 ? (0 + 3) : 0 >> 2), ????);
            // 0x01689A5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689A60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (0 < 0x0 ? (0 + 3) : 0 >> 2), ????);
            label_20:
            // 0x01689A64: STR x20, [x19, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = (0 < 0x0 ? (0 + 3) : 0 >> 2); typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
            typeof(System.Object[]).__il2cppRuntimeField_38 = val_3;
            typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
            // 0x01689A68: ADRP x20, #0x3624000       | X20 = 56770560 (0x3624000);             
            // 0x01689A6C: LDR x20, [x20, #0x98]      | X20 = (string**)(1152921513202780752)(" ( ");
            // 0x01689A70: LDR x0, [x20]              | X0 = " ( ";                             
            // 0x01689A74: CBZ x0, #0x1689a94         | if (" ( " == null) goto label_22;       
            // 0x01689A78: LDR x8, [x19]              | X8 = ;                                  
            // 0x01689A7C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01689A80: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " ( ", ????);      
            // 0x01689A84: CBNZ x0, #0x1689a94        | if (" ( " != null) goto label_22;       
            if(" ( " != null)
            {
                goto label_22;
            }
            // 0x01689A88: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " ( ", ????);      
            // 0x01689A8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689A90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " ( ", ????);      
            label_22:
            // 0x01689A94: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01689A98: LDR x20, [x20]             | X20 = " ( ";                            
            // 0x01689A9C: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x01689AA0: B.HI #0x1689ab0            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_23;
            // 0x01689AA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " ( ", ????);      
            // 0x01689AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689AAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " ( ", ????);      
            label_23:
            // 0x01689AB0: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x01689AB4: STR x20, [x19, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = " ( ";  //  dest_result_addr=1152921504954501328
            typeof(System.Object[]).__il2cppRuntimeField_40 = " ( ";
            // 0x01689AB8: LDR x20, [x8, #0x18]       | X20 = this.binaryHeap;                  
            // 0x01689ABC: CBNZ x20, #0x1689ac4       | if (this.binaryHeap != null) goto label_24;
            if(this.binaryHeap != null)
            {
                goto label_24;
            }
            // 0x01689AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? " ( ", ????);      
            label_24:
            // 0x01689AC4: LDR w8, [x20, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689AC8: CMP w21, w8                | STATE = COMPARE((0 < 0x0 ? (0 + 3) : 0 >> 2), this.binaryHeap.Length)
            // 0x01689ACC: B.LO #0x1689adc            | if (val_3 < this.binaryHeap.Length) goto label_25;
            if(val_3 < this.binaryHeap.Length)
            {
                goto label_25;
            }
            // 0x01689AD0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " ( ", ????);      
            // 0x01689AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689AD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " ( ", ????);      
            label_25:
            // 0x01689ADC: LDR x8, [sp, #8]           | X8 = (long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2));
            // 0x01689AE0: ADRP x21, #0x35e2000       | X21 = 56500224 (0x35E2000);             
            // 0x01689AE4: ADD x1, sp, #0x24          | X1 = (1152921513202806176 + 36) = 1152921513202806212 (0x10000002005BEDC4);
            // 0x01689AE8: ADD x8, x20, x8, lsl #4    | X8 = this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4]; //PARR1 
            // 0x01689AEC: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0]
            Tuple val_12 = this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4];
            // 0x01689AF0: LDR x21, [x21, #0xe18]     | X21 = 1152921504607645696;              
            // 0x01689AF4: STR w8, [sp, #0x24]        | stack[1152921513202806212] = this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0];  //  dest_result_addr=1152921513202806212
            // 0x01689AF8: LDR x0, [x21]              | X0 = typeof(System.UInt32);             
            // 0x01689AFC: BL #0x27bc028              | X0 = 1152921513202932224 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0]);
            // 0x01689B00: MOV x20, x0                | X20 = 1152921513202932224 (0x10000002005DDA00);//ML01
            // 0x01689B04: CBNZ x19, #0x1689b0c       | if ( != null) goto label_26;            
            if(null != null)
            {
                goto label_26;
            }
            // 0x01689B08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0], ????);
            label_26:
            // 0x01689B0C: CBZ x20, #0x1689b30        | if (this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0] == 0) goto label_28;
            if(val_12 == 0)
            {
                goto label_28;
            }
            // 0x01689B10: LDR x8, [x19]              | X8 = ;                                  
            // 0x01689B14: MOV x0, x20                | X0 = 1152921513202932224 (0x10000002005DDA00);//ML01
            // 0x01689B18: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01689B1C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0], ????);
            // 0x01689B20: CBNZ x0, #0x1689b30        | if (this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0] != 0) goto label_28;
            if(val_12 != 0)
            {
                goto label_28;
            }
            // 0x01689B24: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0], ????);
            // 0x01689B28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689B2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0], ????);
            label_28:
            // 0x01689B30: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01689B34: CMP w8, #5                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x5)
            // 0x01689B38: B.HI #0x1689b48            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x5) goto label_29;
            // 0x01689B3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0], ????);
            // 0x01689B40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689B44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0], ????);
            label_29:
            // 0x01689B48: STR x20, [x19, #0x48]      | typeof(System.Object[]).__il2cppRuntimeField_48 = this.binaryHeap[((long)(int)((0 < 0x0 ? (0 + 3) : 0 >> 2))) << 4][0]; typeof(System.Object[]).__il2cppRuntimeField_4C = 0x10000002;  //  dest_result_addr=1152921504954501336 dest_result_addr=1152921504954501340
            typeof(System.Object[]).__il2cppRuntimeField_48 = val_12;
            typeof(System.Object[]).__il2cppRuntimeField_4C = 268435458;
            // 0x01689B4C: ADRP x20, #0x361d000       | X20 = 56741888 (0x361D000);             
            // 0x01689B50: LDR x20, [x20, #0xa60]     | X20 = (string**)(1152921513202784928)(" > ");
            // 0x01689B54: LDR x0, [x20]              | X0 = " > ";                             
            // 0x01689B58: CBZ x0, #0x1689b78         | if (" > " == null) goto label_31;       
            // 0x01689B5C: LDR x8, [x19]              | X8 = ;                                  
            // 0x01689B60: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01689B64: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " > ", ????);      
            // 0x01689B68: CBNZ x0, #0x1689b78        | if (" > " != null) goto label_31;       
            if((" > ") != null)
            {
                goto label_31;
            }
            // 0x01689B6C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " > ", ????);      
            // 0x01689B70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689B74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " > ", ????);      
            label_31:
            // 0x01689B78: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01689B7C: LDR x20, [x20]             | X20 = " > ";                            
            // 0x01689B80: CMP w8, #6                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x6)
            // 0x01689B84: B.HI #0x1689b94            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x6) goto label_32;
            // 0x01689B88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " > ", ????);      
            // 0x01689B8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689B90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " > ", ????);      
            label_32:
            // 0x01689B94: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x01689B98: STR x20, [x19, #0x50]      | typeof(System.Object[]).__il2cppRuntimeField_50 = " > ";  //  dest_result_addr=1152921504954501344
            typeof(System.Object[]).__il2cppRuntimeField_50 = " > ";
            // 0x01689B9C: LDR x20, [x8, #0x18]       | X20 = this.binaryHeap;                  
            // 0x01689BA0: CBNZ x20, #0x1689ba8       | if (this.binaryHeap != null) goto label_33;
            if(this.binaryHeap != null)
            {
                goto label_33;
            }
            // 0x01689BA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? " > ", ????);      
            label_33:
            // 0x01689BA8: LDR w8, [x20, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689BAC: CMP w22, w8                | STATE = COMPARE((0 + 1), this.binaryHeap.Length)
            // 0x01689BB0: B.LO #0x1689bc0            | if (val_6 < this.binaryHeap.Length) goto label_34;
            if(val_6 < this.binaryHeap.Length)
            {
                goto label_34;
            }
            // 0x01689BB4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " > ", ????);      
            // 0x01689BB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689BBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " > ", ????);      
            label_34:
            // 0x01689BC0: LDR x8, [sp, #0x10]        | X8 = (long)(int)((0 + 1));              
            // 0x01689BC4: LDR x0, [x21]              | X0 = typeof(System.UInt32);             
            // 0x01689BC8: ADD x1, sp, #0x20          | X1 = (1152921513202806176 + 32) = 1152921513202806208 (0x10000002005BEDC0);
            // 0x01689BCC: ADD x8, x20, x8, lsl #4    | X8 = this.binaryHeap[((long)(int)((0 + 1))) << 4]; //PARR1 
            // 0x01689BD0: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((0 + 1))) << 4][0]
            Tuple val_13 = this.binaryHeap[((long)(int)((0 + 1))) << 4];
            // 0x01689BD4: STR w8, [sp, #0x20]        | stack[1152921513202806208] = this.binaryHeap[((long)(int)((0 + 1))) << 4][0];  //  dest_result_addr=1152921513202806208
            // 0x01689BD8: BL #0x27bc028              | X0 = 1152921513202936320 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), this.binaryHeap[((long)(int)((0 + 1))) << 4][0]);
            // 0x01689BDC: MOV x20, x0                | X20 = 1152921513202936320 (0x10000002005DEA00);//ML01
            // 0x01689BE0: CBNZ x19, #0x1689be8       | if ( != null) goto label_35;            
            if(null != null)
            {
                goto label_35;
            }
            // 0x01689BE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.binaryHeap[((long)(int)((0 + 1))) << 4][0], ????);
            label_35:
            // 0x01689BE8: CBZ x20, #0x1689c0c        | if (this.binaryHeap[((long)(int)((0 + 1))) << 4][0] == 0) goto label_37;
            if(val_13 == 0)
            {
                goto label_37;
            }
            // 0x01689BEC: LDR x8, [x19]              | X8 = ;                                  
            // 0x01689BF0: MOV x0, x20                | X0 = 1152921513202936320 (0x10000002005DEA00);//ML01
            // 0x01689BF4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01689BF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.binaryHeap[((long)(int)((0 + 1))) << 4][0], ????);
            // 0x01689BFC: CBNZ x0, #0x1689c0c        | if (this.binaryHeap[((long)(int)((0 + 1))) << 4][0] != 0) goto label_37;
            if(val_13 != 0)
            {
                goto label_37;
            }
            // 0x01689C00: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.binaryHeap[((long)(int)((0 + 1))) << 4][0], ????);
            // 0x01689C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689C08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.binaryHeap[((long)(int)((0 + 1))) << 4][0], ????);
            label_37:
            // 0x01689C0C: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01689C10: CMP w8, #7                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x7)
            // 0x01689C14: B.HI #0x1689c24            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x7) goto label_38;
            // 0x01689C18: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.binaryHeap[((long)(int)((0 + 1))) << 4][0], ????);
            // 0x01689C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689C20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.binaryHeap[((long)(int)((0 + 1))) << 4][0], ????);
            label_38:
            // 0x01689C24: STR x20, [x19, #0x58]      | typeof(System.Object[]).__il2cppRuntimeField_58 = this.binaryHeap[((long)(int)((0 + 1))) << 4][0]; typeof(System.Object[]).__il2cppRuntimeField_5C = 0x10000002;  //  dest_result_addr=1152921504954501352 dest_result_addr=1152921504954501356
            typeof(System.Object[]).__il2cppRuntimeField_58 = val_13;
            typeof(System.Object[]).__il2cppRuntimeField_5C = 268435458;
            // 0x01689C28: ADRP x20, #0x3606000       | X20 = 56647680 (0x3606000);             
            // 0x01689C2C: LDR x20, [x20, #0xfa0]     | X20 = (string**)(1152921513202789104)(" ) ");
            // 0x01689C30: LDR x0, [x20]              | X0 = " ) ";                             
            // 0x01689C34: CBZ x0, #0x1689c54         | if (" ) " == null) goto label_40;       
            // 0x01689C38: LDR x8, [x19]              | X8 = ;                                  
            // 0x01689C3C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01689C40: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " ) ", ????);      
            // 0x01689C44: CBNZ x0, #0x1689c54        | if (" ) " != null) goto label_40;       
            if(" ) " != null)
            {
                goto label_40;
            }
            // 0x01689C48: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " ) ", ????);      
            // 0x01689C4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689C50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " ) ", ????);      
            label_40:
            // 0x01689C54: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01689C58: LDR x20, [x20]             | X20 = " ) ";                            
            // 0x01689C5C: CMP w8, #8                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x8)
            // 0x01689C60: B.HI #0x1689c70            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x8) goto label_41;
            // 0x01689C64: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " ) ", ????);      
            // 0x01689C68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689C6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " ) ", ????);      
            label_41:
            // 0x01689C70: STR x20, [x19, #0x60]      | typeof(System.Object[]).__il2cppRuntimeField_60 = " ) ";  //  dest_result_addr=1152921504954501360
            typeof(System.Object[]).__il2cppRuntimeField_60 = " ) ";
            // 0x01689C74: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01689C78: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01689C7C: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x01689C80: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01689C84: TBZ w8, #0, #0x1689c94     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_43;
            // 0x01689C88: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01689C8C: CBNZ w8, #0x1689c94        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
            // 0x01689C90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_43:
            // 0x01689C94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01689C98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01689C9C: MOV x1, x19                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01689CA0: BL #0x18b07f0              | X0 = System.String.Concat(args:  0);    
            string val_7 = System.String.Concat(args:  0);
            // 0x01689CA4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x01689CA8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x01689CAC: MOV x19, x0                | X19 = val_7;//m1                        
            // 0x01689CB0: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x01689CB4: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_8 = null;
            // 0x01689CB8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x01689CBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01689CC0: MOV x1, x19                | X1 = val_7;//m1                         
            // 0x01689CC4: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x01689CC8: BL #0x1c32b48              | .ctor(message:  val_7);                 
            val_8 = new System.Exception(message:  val_7);
            // 0x01689CCC: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x01689CD0: LDR x8, [x8, #0xa90]       | X8 = 1152921513202793280;               
            // 0x01689CD4: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x01689CD8: LDR x1, [x8]               | X1 = System.Void Pathfinding.BinaryHeapM::Validate();
            // 0x01689CDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x01689CE0: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
        //
        // Offset in libil2cpp.so: 0x01689CE4 (23633124), len: 520  VirtAddr: 0x01689CE4 RVA: 0x01689CE4 token: 100682145 methodIndex: 49919 delegateWrapperIndex: 0 methodInvoker: 0
        public void Rebuild()
        {
            //
            // Disasemble & Code
            //  | 
            Tuple[] val_4;
            //  | 
            Tuple[] val_5;
            // 0x01689CE4: STP x28, x27, [sp, #-0x60]! | stack[1152921513203196736] = ???;  stack[1152921513203196744] = ???;  //  dest_result_addr=1152921513203196736 |  dest_result_addr=1152921513203196744
            // 0x01689CE8: STP x26, x25, [sp, #0x10]  | stack[1152921513203196752] = ???;  stack[1152921513203196760] = ???;  //  dest_result_addr=1152921513203196752 |  dest_result_addr=1152921513203196760
            // 0x01689CEC: STP x24, x23, [sp, #0x20]  | stack[1152921513203196768] = ???;  stack[1152921513203196776] = ???;  //  dest_result_addr=1152921513203196768 |  dest_result_addr=1152921513203196776
            // 0x01689CF0: STP x22, x21, [sp, #0x30]  | stack[1152921513203196784] = ???;  stack[1152921513203196792] = ???;  //  dest_result_addr=1152921513203196784 |  dest_result_addr=1152921513203196792
            // 0x01689CF4: STP x20, x19, [sp, #0x40]  | stack[1152921513203196800] = ???;  stack[1152921513203196808] = ???;  //  dest_result_addr=1152921513203196800 |  dest_result_addr=1152921513203196808
            // 0x01689CF8: STP x29, x30, [sp, #0x50]  | stack[1152921513203196816] = ???;  stack[1152921513203196824] = ???;  //  dest_result_addr=1152921513203196816 |  dest_result_addr=1152921513203196824
            // 0x01689CFC: ADD x29, sp, #0x50         | X29 = (1152921513203196736 + 80) = 1152921513203196816 (0x100000020061E390);
            // 0x01689D00: SUB sp, sp, #0x20          | SP = (1152921513203196736 - 32) = 1152921513203196704 (0x100000020061E320);
            // 0x01689D04: MOV x19, x0                | X19 = 1152921513203208832 (0x1000000200621280);//ML01
            // 0x01689D08: STR wzr, [sp, #0x18]       | stack[1152921513203196728] = 0x0;        //  dest_result_addr=1152921513203196728
            // 0x01689D0C: STR xzr, [sp, #0x10]       | stack[1152921513203196720] = 0x0;        //  dest_result_addr=1152921513203196720
            // 0x01689D10: LDR w8, [x19, #0x10]       | W8 = this.numberOfItems; //P2           
            // 0x01689D14: CMP w8, #3                 | STATE = COMPARE(this.numberOfItems, 0x3)
            // 0x01689D18: B.LT #0x1689e88            | if (this.numberOfItems < 3) goto label_0;
            if(this.numberOfItems < 3)
            {
                goto label_0;
            }
            // 0x01689D1C: ORR w20, wzr, #2           | W20 = 2(0x2);                           
            var val_10 = 2;
            label_14:
            // 0x01689D20: LDR x21, [x19, #0x18]      | X21 = this.binaryHeap; //P2             
            // 0x01689D24: CBNZ x21, #0x1689d2c       | if (this.binaryHeap != null) goto label_1;
            if(this.binaryHeap != null)
            {
                goto label_1;
            }
            // 0x01689D28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x01689D2C: LDR w8, [x21, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689D30: SXTW x22, w20              | X22 = 2 (0x00000002);                   
            // 0x01689D34: CMP w20, w8                | STATE = COMPARE(0x2, this.binaryHeap.Length)
            // 0x01689D38: B.LO #0x1689d48            | if (2 < this.binaryHeap.Length) goto label_2;
            if(val_10 < this.binaryHeap.Length)
            {
                goto label_2;
            }
            // 0x01689D3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689D40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689D44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_2:
            // 0x01689D48: ADD x8, x21, x22, lsl #4   | X8 = this.binaryHeap[0x20]; //PARR1     
            // 0x01689D4C: LDR w9, [x8, #0x2c]        | W9 = this.binaryHeap[0x20][1]           
            Tuple val_6 = this.binaryHeap[32];
            // 0x01689D50: LDR w21, [x8, #0x20]       | W21 = this.binaryHeap[0x20][0]          
            Tuple val_7 = this.binaryHeap[32];
            // 0x01689D54: CMP w20, #1                | STATE = COMPARE(0x2, 0x1)               
            // 0x01689D58: MOV w22, w20               | W22 = 2 (0x2);//ML01                    
            // 0x01689D5C: STR w9, [sp, #0x18]        | stack[1152921513203196728] = this.binaryHeap[0x20][1];  //  dest_result_addr=1152921513203196728
            // 0x01689D60: LDUR x8, [x8, #0x24]       | X8 = this.binaryHeap[0x20][0]           
            Tuple val_8 = this.binaryHeap[32];
            // 0x01689D64: STR x8, [sp, #0x10]        | stack[1152921513203196720] = this.binaryHeap[0x20][0];  //  dest_result_addr=1152921513203196720
            // 0x01689D68: B.EQ #0x1689e78            | if (2 == 0x1) goto label_6;             
            if(val_10 == 1)
            {
                goto label_6;
            }
            label_13:
            // 0x01689D6C: LDR x25, [x19, #0x18]      | X25 = this.binaryHeap; //P2             
            val_4 = this.binaryHeap;
            // 0x01689D70: ADD w8, w22, #3            | W8 = (2 + 3);                           
            var val_1 = val_10 + 3;
            // 0x01689D74: CMP w22, #0                | STATE = COMPARE(0x2, 0x0)               
            // 0x01689D78: CSEL w8, w8, w22, lt       | W8 = 2 < 0x0 ? (2 + 3) : 2;             
            var val_2 = (val_10 < 0) ? (val_1) : (val_10);
            // 0x01689D7C: ASR w23, w8, #2            | W23 = (2 < 0x0 ? (2 + 3) : 2 >> 2);     
            var val_3 = val_2 >> 2;
            // 0x01689D80: CBNZ x25, #0x1689d88       | if (this.binaryHeap != null) goto label_4;
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x01689D84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x01689D88: LDR w8, [x25, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689D8C: SXTW x24, w23              | X24 = (long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2));
            // 0x01689D90: CMP w23, w8                | STATE = COMPARE((2 < 0x0 ? (2 + 3) : 2 >> 2), this.binaryHeap.Length)
            // 0x01689D94: B.LO #0x1689da4            | if (val_3 < this.binaryHeap.Length) goto label_5;
            if(val_3 < this.binaryHeap.Length)
            {
                goto label_5;
            }
            // 0x01689D98: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689D9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689DA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_5:
            // 0x01689DA4: ADD x8, x25, x24, lsl #4   | X8 = this.binaryHeap[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4]; //PARR1 
            // 0x01689DA8: LDR w8, [x8, #0x20]        | W8 = this.binaryHeap[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4][0]
            Tuple val_9 = val_4[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4];
            // 0x01689DAC: CMP w21, w8                | STATE = COMPARE(this.binaryHeap[0x20][0], this.binaryHeap[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4][0])
            // 0x01689DB0: B.HS #0x1689e78            | if (this.binaryHeap[32] >= val_4[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4]) goto label_6;
            if(val_7 >= val_9)
            {
                goto label_6;
            }
            // 0x01689DB4: LDR x26, [x19, #0x18]      | X26 = this.binaryHeap; //P2             
            // 0x01689DB8: MOV x25, x26               | X25 = this.binaryHeap;//m1              
            val_5 = this.binaryHeap;
            // 0x01689DBC: CBNZ x26, #0x1689dd4       | if (this.binaryHeap != null) goto label_8;
            if(this.binaryHeap != null)
            {
                goto label_8;
            }
            // 0x01689DC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x01689DC4: LDR x25, [x19, #0x18]      | X25 = this.binaryHeap; //P2             
            val_5 = this.binaryHeap;
            // 0x01689DC8: CBNZ x25, #0x1689dd4       | if (this.binaryHeap != null) goto label_8;
            if(val_5 != null)
            {
                goto label_8;
            }
            // 0x01689DCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x01689DD0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_5 = 0;
            label_8:
            // 0x01689DD4: LDR w8, [x26, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689DD8: SXTW x27, w22              | X27 = 2 (0x00000002);                   
            // 0x01689DDC: CMP w22, w8                | STATE = COMPARE(0x2, this.binaryHeap.Length)
            // 0x01689DE0: B.LO #0x1689df0            | if (2 < this.binaryHeap.Length) goto label_9;
            if(val_10 < this.binaryHeap.Length)
            {
                goto label_9;
            }
            // 0x01689DE4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689DE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689DEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_9:
            // 0x01689DF0: LDR w8, [x25, #0x18]       | W8 = 0x9814C0;                          
            // 0x01689DF4: ADD x9, x26, x27, lsl #4   | X9 = this.binaryHeap[0x20]; //PARR1     
            // 0x01689DF8: ADD x26, x9, #0x20         | X26 = this.binaryHeap[0x20][0x20]; //PARR1 
            // 0x01689DFC: CMP w23, w8                | STATE = COMPARE((2 < 0x0 ? (2 + 3) : 2 >> 2), 0x9814C0)
            // 0x01689E00: B.LO #0x1689e10            | if (val_3 < 9966784) goto label_10;     
            if(val_3 < 9966784)
            {
                goto label_10;
            }
            // 0x01689E04: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689E0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_10:
            // 0x01689E10: ADD x8, x25, x24, lsl #4   | X8 = (val_5 + ((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4);
            var val_4 = val_5 + (((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4);
            // 0x01689E14: LDR q0, [x8, #0x20]        | Q0 = (val_5 + ((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4) + 32;
            // 0x01689E18: STR q0, [x26]              | mem2[0] = (val_5 + ((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4) + 32;  //  dest_result_addr=0
            mem2[0] = (val_5 + ((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4) + 32;
            // 0x01689E1C: LDR x25, [x19, #0x18]      | X25 = this.binaryHeap; //P2             
            val_4 = this.binaryHeap;
            // 0x01689E20: CBNZ x25, #0x1689e28       | if (this.binaryHeap != null) goto label_11;
            if(val_4 != null)
            {
                goto label_11;
            }
            // 0x01689E24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_11:
            // 0x01689E28: LDR w8, [sp, #0x18]        | W8 = this.binaryHeap[0x20][1];          
            // 0x01689E2C: LDR x9, [sp, #0x10]        | X9 = this.binaryHeap[0x20][0];          
            // 0x01689E30: STR w8, [sp, #8]           | stack[1152921513203196712] = this.binaryHeap[0x20][1];  //  dest_result_addr=1152921513203196712
            // 0x01689E34: STR x9, [sp]               | stack[1152921513203196704] = this.binaryHeap[0x20][0];  //  dest_result_addr=1152921513203196704
            // 0x01689E38: LDR w8, [x25, #0x18]       | W8 = this.binaryHeap.Length; //P2       
            // 0x01689E3C: CMP w23, w8                | STATE = COMPARE((2 < 0x0 ? (2 + 3) : 2 >> 2), this.binaryHeap.Length)
            // 0x01689E40: B.LO #0x1689e50            | if (val_3 < this.binaryHeap.Length) goto label_12;
            if(val_3 < this.binaryHeap.Length)
            {
                goto label_12;
            }
            // 0x01689E44: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01689E48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689E4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_12:
            // 0x01689E50: ADD x8, x25, x24, lsl #4   | X8 = this.binaryHeap[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4]; //PARR1 
            // 0x01689E54: STR w21, [x8, #0x20]       | this.binaryHeap[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4][0] = this.binaryHeap[0x20][0];  //  dest_result_addr=0
            val_4[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4] = val_7;
            // 0x01689E58: LDR w9, [sp, #8]           | W9 = this.binaryHeap[0x20][1];          
            // 0x01689E5C: AND w10, w22, #0xfffffffc  | W10 = (2 & 4294967292);                 
            var val_5 = val_10 & 4294967292;
            // 0x01689E60: CMP w10, #4                | STATE = COMPARE((2 & 4294967292), 0x4)  
            // 0x01689E64: MOV w22, w23               | W22 = (2 < 0x0 ? (2 + 3) : 2 >> 2);//m1 
            // 0x01689E68: STR w9, [x8, #0x2c]        | this.binaryHeap[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4][1] = this.binaryHeap[0x20][1];  //  dest_result_addr=0
            val_4[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4] = val_6;
            // 0x01689E6C: LDR x9, [sp]               | X9 = this.binaryHeap[0x20][0];          
            // 0x01689E70: STUR x9, [x8, #0x24]       | this.binaryHeap[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4][0] = this.binaryHeap[0x20][0];  //  dest_result_addr=0
            val_4[((long)(int)((2 < 0x0 ? (2 + 3) : 2 >> 2))) << 4] = val_8;
            // 0x01689E74: B.NE #0x1689d6c            | if (val_5 != 0x4) goto label_13;        
            if(val_5 != 4)
            {
                goto label_13;
            }
            label_6:
            // 0x01689E78: LDR w8, [x19, #0x10]       | W8 = this.numberOfItems; //P2           
            // 0x01689E7C: ADD w20, w20, #1           | W20 = (2 + 1);                          
            val_10 = val_10 + 1;
            // 0x01689E80: CMP w20, w8                | STATE = COMPARE((2 + 1), this.numberOfItems)
            // 0x01689E84: B.LT #0x1689d20            | if (2 < this.numberOfItems) goto label_14;
            if(val_10 < this.numberOfItems)
            {
                goto label_14;
            }
            label_0:
            // 0x01689E88: SUB sp, x29, #0x50         | SP = (1152921513203196816 - 80) = 1152921513203196736 (0x100000020061E340);
            // 0x01689E8C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01689E90: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01689E94: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01689E98: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01689E9C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01689EA0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01689EA4: RET                        |  return;                                
            return;
            // 0x01689EA8: STP x29, x30, [sp, #-0x10]! | 
            // 0x01689EAC: MOV x29, sp                | 
            // 0x01689EB0: ADRP x0, #0x2aa0000        | 
            // 0x01689EB4: ADD x0, x0, #0xf5b         | 
            // 0x01689EB8: BL #0x27af3c8              | 
            // 0x01689EBC: MOV x1, xzr                | 
            // 0x01689EC0: BL #0x27ae3bc              | 
            // 0x01689EC4: BL #0x167ef74              | 
            // 0x01689EC8: STP x29, x30, [sp, #-0x10]! | 
            // 0x01689ECC: MOV x29, sp                | 
            // 0x01689ED0: ADRP x0, #0x2aa0000        | 
            // 0x01689ED4: ADD x0, x0, #0xf5b         | 
            // 0x01689ED8: BL #0x27af3c8              | 
            // 0x01689EDC: MOV x1, xzr                | 
            // 0x01689EE0: BL #0x27ae3bc              | 
            // 0x01689EE4: BL #0x167ef74              | 
            // 0x01689EE8: RET                        | 
        
        }
    
    }

}
