using UnityEngine;

namespace Pathfinding.RVO.Sampled
{
    public class Agent : IAgent
    {
        // Fields
        private UnityEngine.Vector3 smoothPos; //  0x00000010
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285AF04
        private UnityEngine.Vector3 <Position>k__BackingField; //  0x0000001C
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285AF40
        private UnityEngine.Vector3 <DesiredVelocity>k__BackingField; //  0x00000028
        public float radius; //  0x00000034
        public float height; //  0x00000038
        public float maxSpeed; //  0x0000003C
        public float neighbourDist; //  0x00000040
        public float agentTimeHorizon; //  0x00000044
        public float obstacleTimeHorizon; //  0x00000048
        public float weight; //  0x0000004C
        public bool locked; //  0x00000050
        private Pathfinding.RVO.RVOLayer layer; //  0x00000054
        private Pathfinding.RVO.RVOLayer collidesWith; //  0x00000058
        public int maxNeighbours; //  0x0000005C
        public UnityEngine.Vector3 position; //  0x00000060
        public UnityEngine.Vector3 desiredVelocity; //  0x0000006C
        public UnityEngine.Vector3 prevSmoothPos; //  0x00000078
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285AF7C
        private Pathfinding.RVO.RVOLayer <Layer>k__BackingField; //  0x00000084
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285AFB8
        private Pathfinding.RVO.RVOLayer <CollidesWith>k__BackingField; //  0x00000088
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285AFF4
        private bool <Locked>k__BackingField; //  0x0000008C
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285B030
        private float <Radius>k__BackingField; //  0x00000090
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285B06C
        private float <Height>k__BackingField; //  0x00000094
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285B0A8
        private float <MaxSpeed>k__BackingField; //  0x00000098
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285B0E4
        private float <NeighbourDist>k__BackingField; //  0x0000009C
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285B120
        private float <AgentTimeHorizon>k__BackingField; //  0x000000A0
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285B15C
        private float <ObstacleTimeHorizon>k__BackingField; //  0x000000A4
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285B198
        private UnityEngine.Vector3 <Velocity>k__BackingField; //  0x000000A8
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285B1D4
        private bool <DebugDraw>k__BackingField; //  0x000000B4
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285B210
        private int <MaxNeighbours>k__BackingField; //  0x000000B8
        internal Pathfinding.RVO.Sampled.Agent next; //  0x000000C0
        private UnityEngine.Vector3 velocity; //  0x000000C8
        internal UnityEngine.Vector3 newVelocity; //  0x000000D4
        public Pathfinding.RVO.Simulator simulator; //  0x000000E0
        public System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent> neighbours; //  0x000000E8
        public System.Collections.Generic.List<float> neighbourDists; //  0x000000F0
        private System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex> obstaclesBuffered; //  0x000000F8
        private System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex> obstacles; //  0x00000100
        private System.Collections.Generic.List<float> obstacleDists; //  0x00000108
        public static System.Diagnostics.Stopwatch watch1; // static_offset: 0x00000000
        public static System.Diagnostics.Stopwatch watch2; // static_offset: 0x00000008
        public static float DesiredVelocityWeight; // static_offset: 0x00000010
        public static float DesiredVelocityScale; // static_offset: 0x00000014
        public static float GlobalIncompressibility; // static_offset: 0x00000018
        private const float WallWeight = 5;
        
        // Properties
        public UnityEngine.Vector3 Position { get; set; }
        public UnityEngine.Vector3 InterpolatedPosition { get; }
        public UnityEngine.Vector3 DesiredVelocity { get; set; }
        public Pathfinding.RVO.RVOLayer Layer { get; set; }
        public Pathfinding.RVO.RVOLayer CollidesWith { get; set; }
        public bool Locked { get; set; }
        public float Radius { get; set; }
        public float Height { get; set; }
        public float MaxSpeed { get; set; }
        public float NeighbourDist { get; set; }
        public float AgentTimeHorizon { get; set; }
        public float ObstacleTimeHorizon { get; set; }
        public UnityEngine.Vector3 Velocity { get; set; }
        public bool DebugDraw { get; set; }
        public int MaxNeighbours { get; set; }
        public System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex> NeighbourObstacles { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x028B7D4C (42696012), len: 360  VirtAddr: 0x028B7D4C RVA: 0x028B7D4C token: 100682446 methodIndex: 51058 delegateWrapperIndex: 0 methodInvoker: 0
        public Agent(UnityEngine.Vector3 pos)
        {
            //
            // Disasemble & Code
            // 0x028B7D4C: STP d11, d10, [sp, #-0x60]! | stack[1152921513245756336] = ???;  stack[1152921513245756344] = ???;  //  dest_result_addr=1152921513245756336 |  dest_result_addr=1152921513245756344
            // 0x028B7D50: STP d9, d8, [sp, #0x10]    | stack[1152921513245756352] = ???;  stack[1152921513245756360] = ???;  //  dest_result_addr=1152921513245756352 |  dest_result_addr=1152921513245756360
            // 0x028B7D54: STP x24, x23, [sp, #0x20]  | stack[1152921513245756368] = ???;  stack[1152921513245756376] = ???;  //  dest_result_addr=1152921513245756368 |  dest_result_addr=1152921513245756376
            // 0x028B7D58: STP x22, x21, [sp, #0x30]  | stack[1152921513245756384] = ???;  stack[1152921513245756392] = ???;  //  dest_result_addr=1152921513245756384 |  dest_result_addr=1152921513245756392
            // 0x028B7D5C: STP x20, x19, [sp, #0x40]  | stack[1152921513245756400] = ???;  stack[1152921513245756408] = ???;  //  dest_result_addr=1152921513245756400 |  dest_result_addr=1152921513245756408
            // 0x028B7D60: STP x29, x30, [sp, #0x50]  | stack[1152921513245756416] = ???;  stack[1152921513245756424] = ???;  //  dest_result_addr=1152921513245756416 |  dest_result_addr=1152921513245756424
            // 0x028B7D64: ADD x29, sp, #0x50         | X29 = (1152921513245756336 + 80) = 1152921513245756416 (0x1000000202EB4C00);
            // 0x028B7D68: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028B7D6C: LDRB w8, [x20, #0x913]     | W8 = (bool)static_value_037B8913;       
            // 0x028B7D70: MOV v8.16b, v2.16b         | V8 = pos.z;//m1                         
            // 0x028B7D74: MOV v9.16b, v1.16b         | V9 = pos.y;//m1                         
            // 0x028B7D78: MOV v10.16b, v0.16b        | V10 = pos.x;//m1                        
            // 0x028B7D7C: MOV x19, x0                | X19 = 1152921513245768432 (0x1000000202EB7AF0);//ML01
            // 0x028B7D80: TBNZ w8, #0, #0x28b7d9c    | if (static_value_037B8913 == true) goto label_0;
            // 0x028B7D84: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x028B7D88: LDR x8, [x8, #0x5d8]       | X8 = 0x2B8AA98;                         
            // 0x028B7D8C: LDR w0, [x8]               | W0 = 0x164;                             
            // 0x028B7D90: BL #0x2782188              | X0 = sub_2782188( ?? 0x164, ????);      
            // 0x028B7D94: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B7D98: STRB w8, [x20, #0x913]     | static_value_037B8913 = true;            //  dest_result_addr=58427667
            label_0:
            // 0x028B7D9C: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x028B7DA0: LDR x8, [x8, #0xa20]       | X8 = 1152921504616644608;               
            // 0x028B7DA4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent> val_1 = null;
            // 0x028B7DA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x028B7DAC: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x028B7DB0: LDR x8, [x8, #0x8a8]       | X8 = 1152921513245742384;               
            // 0x028B7DB4: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028B7DB8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::.ctor();
            // 0x028B7DBC: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>();
            // 0x028B7DC0: STR x20, [x19, #0xe8]      | this.neighbours = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513245768664
            this.neighbours = val_1;
            // 0x028B7DC4: ADRP x21, #0x35ba000       | X21 = 56336384 (0x35BA000);             
            // 0x028B7DC8: LDR x21, [x21, #0x590]     | X21 = 1152921504616644608;              
            // 0x028B7DCC: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.Single> val_2 = null;
            // 0x028B7DD0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x028B7DD4: ADRP x22, #0x3639000       | X22 = 56856576 (0x3639000);             
            // 0x028B7DD8: LDR x22, [x22, #0x6d0]     | X22 = 1152921510889998672;              
            // 0x028B7DDC: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028B7DE0: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::.ctor();
            // 0x028B7DE4: BL #0x25f69e4              | .ctor();                                
            val_2 = new System.Collections.Generic.List<System.Single>();
            // 0x028B7DE8: STR x20, [x19, #0xf0]      | this.neighbourDists = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513245768672
            this.neighbourDists = val_2;
            // 0x028B7DEC: ADRP x23, #0x3637000       | X23 = 56848384 (0x3637000);             
            // 0x028B7DF0: LDR x23, [x23, #0xf48]     | X23 = 1152921504616644608;              
            // 0x028B7DF4: LDR x0, [x23]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex> val_3 = null;
            // 0x028B7DF8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x028B7DFC: ADRP x24, #0x35d5000       | X24 = 56446976 (0x35D5000);             
            // 0x028B7E00: LDR x24, [x24, #0x778]     | X24 = 1152921513245743408;              
            // 0x028B7E04: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028B7E08: LDR x1, [x24]              | X1 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::.ctor();
            // 0x028B7E0C: BL #0x25e9474              | .ctor();                                
            val_3 = new System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>();
            // 0x028B7E10: STR x20, [x19, #0xf8]      | this.obstaclesBuffered = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513245768680
            this.obstaclesBuffered = val_3;
            // 0x028B7E14: LDR x0, [x23]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex> val_4 = null;
            // 0x028B7E18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x028B7E1C: LDR x1, [x24]              | X1 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::.ctor();
            // 0x028B7E20: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028B7E24: BL #0x25e9474              | .ctor();                                
            val_4 = new System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>();
            // 0x028B7E28: STR x20, [x19, #0x100]     | this.obstacles = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513245768688
            this.obstacles = val_4;
            // 0x028B7E2C: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.Single> val_5 = null;
            // 0x028B7E30: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x028B7E34: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::.ctor();
            // 0x028B7E38: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028B7E3C: BL #0x25f69e4              | .ctor();                                
            val_5 = new System.Collections.Generic.List<System.Single>();
            // 0x028B7E40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B7E44: MOV x0, x19                | X0 = 1152921513245768432 (0x1000000202EB7AF0);//ML01
            // 0x028B7E48: STR x20, [x19, #0x108]     | this.obstacleDists = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513245768696
            this.obstacleDists = val_5;
            // 0x028B7E4C: BL #0x16f59f0              | this..ctor();                           
            // 0x028B7E50: ORR w8, wzr, #0x40000000   | W8 = 1073741824(0x40000000);            
            // 0x028B7E54: STP w8, w8, [x19, #0xa0]   | this.<AgentTimeHorizon>k__BackingField = 2;  this.<ObstacleTimeHorizon>k__BackingField = 2;  //  dest_result_addr=1152921513245768592 |  dest_result_addr=1152921513245768596
            this.<AgentTimeHorizon>k__BackingField = 2f;
            this.<ObstacleTimeHorizon>k__BackingField = 2f;
            // 0x028B7E58: ADRP x8, #0x2bc6000        | X8 = 45899776 (0x2BC6000);              
            // 0x028B7E5C: LDR q0, [x8, #0x650]       | Q0 = ;                                  
            // 0x028B7E60: MOVZ w8, #0xa              | W8 = 10 (0xA);//ML01                    
            // 0x028B7E64: STRB wzr, [x19, #0x8c]     | this.<Locked>k__BackingField = false;    //  dest_result_addr=1152921513245768572
            this.<Locked>k__BackingField = false;
            // 0x028B7E68: STP s10, s9, [x19, #0x60]  | this.position = pos;  mem[1152921513245768532] = pos.y;  //  dest_result_addr=1152921513245768528 |  dest_result_addr=1152921513245768532
            this.position = pos;
            mem[1152921513245768532] = pos.y;
            // 0x028B7E6C: STR s8, [x19, #0x68]       | mem[1152921513245768536] = pos.z;        //  dest_result_addr=1152921513245768536
            mem[1152921513245768536] = pos.z;
            // 0x028B7E70: STP s10, s9, [x19, #0x1c]  | this.<Position>k__BackingField = pos;  mem[1152921513245768464] = pos.y;  //  dest_result_addr=1152921513245768460 |  dest_result_addr=1152921513245768464
            this.<Position>k__BackingField = pos;
            mem[1152921513245768464] = pos.y;
            // 0x028B7E74: STR s8, [x19, #0x24]       | mem[1152921513245768468] = pos.z;        //  dest_result_addr=1152921513245768468
            mem[1152921513245768468] = pos.z;
            // 0x028B7E78: STP s10, s9, [x19, #0x78]  | this.prevSmoothPos = pos;  mem[1152921513245768556] = pos.y;  //  dest_result_addr=1152921513245768552 |  dest_result_addr=1152921513245768556
            this.prevSmoothPos = pos;
            mem[1152921513245768556] = pos.y;
            // 0x028B7E7C: STR s8, [x19, #0x80]       | mem[1152921513245768560] = pos.z;        //  dest_result_addr=1152921513245768560
            mem[1152921513245768560] = pos.z;
            // 0x028B7E80: STP s10, s9, [x19, #0x10]  | this.smoothPos = pos;  mem[1152921513245768452] = pos.y;  //  dest_result_addr=1152921513245768448 |  dest_result_addr=1152921513245768452
            this.smoothPos = pos;
            mem[1152921513245768452] = pos.y;
            // 0x028B7E84: STR w8, [x19, #0xb8]       | this.<MaxNeighbours>k__BackingField = 10;  //  dest_result_addr=1152921513245768616
            this.<MaxNeighbours>k__BackingField = 10;
            // 0x028B7E88: ORR x8, xzr, #0xffffffff00000001 | X8 = -4294967295(0xFFFFFFFF00000001);   
            // 0x028B7E8C: STUR x8, [x19, #0x84]      | this.<Layer>k__BackingField = 0xFFFFFFFF00000001;  //  dest_result_addr=1152921513245768564
            this.<Layer>k__BackingField = -4294967295;
            // 0x028B7E90: STR s8, [x19, #0x18]       | mem[1152921513245768456] = pos.z;        //  dest_result_addr=1152921513245768456
            mem[1152921513245768456] = pos.z;
            // 0x028B7E94: STR q0, [x19, #0x90]       | this.<Radius>k__BackingField = ; this.<Height>k__BackingField = ; this.<MaxSpeed>k__BackingField = 2; this.<NeighbourDist>k__BackingField = 15;  //  dest_result_addr=1152921513245768576 dest_result_addr=1152921513245768580 dest_result_addr=1152921513245768584 dest_result_addr=1152921513245768588
            this.<Radius>k__BackingField = ;
            this.<Height>k__BackingField = ;
            this.<MaxSpeed>k__BackingField = 2f;
            this.<NeighbourDist>k__BackingField = 15f;
            // 0x028B7E98: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028B7E9C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028B7EA0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028B7EA4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028B7EA8: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x028B7EAC: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
            // 0x028B7EB0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7F14 (42696468), len: 12  VirtAddr: 0x028B7F14 RVA: 0x028B7F14 token: 100682447 methodIndex: 51059 delegateWrapperIndex: 0 methodInvoker: 0
        public UnityEngine.Vector3 get_Position()
        {
            //
            // Disasemble & Code
            // 0x028B7F14: LDP s0, s1, [x0, #0x1c]    | S0 = this.<Position>k__BackingField; //P2   //  | 
            // 0x028B7F18: LDR s2, [x0, #0x24]        | 
            // 0x028B7F1C: RET                        |  return new UnityEngine.Vector3() {x = this.<Position>k__BackingField};
            return new UnityEngine.Vector3() {x = this.<Position>k__BackingField};
            //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7EF8 (42696440), len: 12  VirtAddr: 0x028B7EF8 RVA: 0x028B7EF8 token: 100682448 methodIndex: 51060 delegateWrapperIndex: 0 methodInvoker: 0
        private void set_Position(UnityEngine.Vector3 value)
        {
            //
            // Disasemble & Code
            // 0x028B7EF8: STP s0, s1, [x0, #0x1c]    | this.<Position>k__BackingField = value;  mem[1152921513245992464] = value.y;  //  dest_result_addr=1152921513245992460 |  dest_result_addr=1152921513245992464
            this.<Position>k__BackingField = value;
            mem[1152921513245992464] = value.y;
            // 0x028B7EFC: STR s2, [x0, #0x24]        | mem[1152921513245992468] = value.z;      //  dest_result_addr=1152921513245992468
            mem[1152921513245992468] = value.z;
            // 0x028B7F00: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7F20 (42696480), len: 12  VirtAddr: 0x028B7F20 RVA: 0x028B7F20 token: 100682449 methodIndex: 51061 delegateWrapperIndex: 0 methodInvoker: 0
        public UnityEngine.Vector3 get_InterpolatedPosition()
        {
            //
            // Disasemble & Code
            // 0x028B7F20: LDP s0, s1, [x0, #0x10]    | S0 = this.smoothPos; //P2                //  | 
            // 0x028B7F24: LDR s2, [x0, #0x18]        | 
            // 0x028B7F28: RET                        |  return new UnityEngine.Vector3() {x = this.smoothPos};
            return new UnityEngine.Vector3() {x = this.smoothPos};
            //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7F2C (42696492), len: 12  VirtAddr: 0x028B7F2C RVA: 0x028B7F2C token: 100682450 methodIndex: 51062 delegateWrapperIndex: 0 methodInvoker: 0
        public UnityEngine.Vector3 get_DesiredVelocity()
        {
            //
            // Disasemble & Code
            // 0x028B7F2C: LDP s0, s1, [x0, #0x28]    | S0 = this.<DesiredVelocity>k__BackingField; //P2   //  | 
            // 0x028B7F30: LDR s2, [x0, #0x30]        | 
            // 0x028B7F34: RET                        |  return new UnityEngine.Vector3() {x = this.<DesiredVelocity>k__BackingField};
            return new UnityEngine.Vector3() {x = this.<DesiredVelocity>k__BackingField};
            //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7F38 (42696504), len: 12  VirtAddr: 0x028B7F38 RVA: 0x028B7F38 token: 100682451 methodIndex: 51063 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_DesiredVelocity(UnityEngine.Vector3 value)
        {
            //
            // Disasemble & Code
            // 0x028B7F38: STP s0, s1, [x0, #0x28]    | this.<DesiredVelocity>k__BackingField = value;  mem[1152921513246328476] = value.y;  //  dest_result_addr=1152921513246328472 |  dest_result_addr=1152921513246328476
            this.<DesiredVelocity>k__BackingField = value;
            mem[1152921513246328476] = value.y;
            // 0x028B7F3C: STR s2, [x0, #0x30]        | mem[1152921513246328480] = value.z;      //  dest_result_addr=1152921513246328480
            mem[1152921513246328480] = value.z;
            // 0x028B7F40: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7F44 (42696516), len: 28  VirtAddr: 0x028B7F44 RVA: 0x028B7F44 token: 100682452 methodIndex: 51064 delegateWrapperIndex: 0 methodInvoker: 0
        public void Teleport(UnityEngine.Vector3 pos)
        {
            //
            // Disasemble & Code
            // 0x028B7F44: STP s0, s1, [x0, #0x1c]    | this.<Position>k__BackingField = pos;  mem[1152921513246440464] = pos.y;  //  dest_result_addr=1152921513246440460 |  dest_result_addr=1152921513246440464
            this.<Position>k__BackingField = pos;
            mem[1152921513246440464] = pos.y;
            // 0x028B7F48: STR s2, [x0, #0x24]        | mem[1152921513246440468] = pos.z;        //  dest_result_addr=1152921513246440468
            mem[1152921513246440468] = pos.z;
            // 0x028B7F4C: STP s0, s1, [x0, #0x10]    | this.smoothPos = pos;  mem[1152921513246440452] = pos.y;  //  dest_result_addr=1152921513246440448 |  dest_result_addr=1152921513246440452
            this.smoothPos = pos;
            mem[1152921513246440452] = pos.y;
            // 0x028B7F50: STR s2, [x0, #0x18]        | mem[1152921513246440456] = pos.z;        //  dest_result_addr=1152921513246440456
            mem[1152921513246440456] = pos.z;
            // 0x028B7F54: STP s0, s1, [x0, #0x78]    | this.prevSmoothPos = pos;  mem[1152921513246440556] = pos.y;  //  dest_result_addr=1152921513246440552 |  dest_result_addr=1152921513246440556
            this.prevSmoothPos = pos;
            mem[1152921513246440556] = pos.y;
            // 0x028B7F58: STR s2, [x0, #0x80]        | mem[1152921513246440560] = pos.z;        //  dest_result_addr=1152921513246440560
            mem[1152921513246440560] = pos.z;
            // 0x028B7F5C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7F60 (42696544), len: 108  VirtAddr: 0x028B7F60 RVA: 0x028B7F60 token: 100682453 methodIndex: 51065 delegateWrapperIndex: 0 methodInvoker: 0
        public void SetYPosition(float yCoordinate)
        {
            //
            // Disasemble & Code
            // 0x028B7F60: STP d9, d8, [sp, #-0x30]!  | stack[1152921513246540384] = ???;  stack[1152921513246540392] = ???;  //  dest_result_addr=1152921513246540384 |  dest_result_addr=1152921513246540392
            // 0x028B7F64: STP x20, x19, [sp, #0x10]  | stack[1152921513246540400] = ???;  stack[1152921513246540408] = ???;  //  dest_result_addr=1152921513246540400 |  dest_result_addr=1152921513246540408
            // 0x028B7F68: STP x29, x30, [sp, #0x20]  | stack[1152921513246540416] = ???;  stack[1152921513246540424] = ???;  //  dest_result_addr=1152921513246540416 |  dest_result_addr=1152921513246540424
            // 0x028B7F6C: ADD x29, sp, #0x20         | X29 = (1152921513246540384 + 32) = 1152921513246540416 (0x1000000202F74280);
            // 0x028B7F70: SUB sp, sp, #0x10          | SP = (1152921513246540384 - 16) = 1152921513246540368 (0x1000000202F74250);
            // 0x028B7F74: MOV x19, x0                | X19 = 1152921513246552432 (0x1000000202F77170);//ML01
            // 0x028B7F78: LDR s1, [x19, #0x1c]       | S1 = this.<Position>k__BackingField; //P2 
            // 0x028B7F7C: LDR s2, [x19, #0x24]       | 
            // 0x028B7F80: MOV v8.16b, v0.16b         | V8 = yCoordinate;//m1                   
            // 0x028B7F84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B7F88: MOV x0, sp                 | X0 = 1152921513246540368 (0x1000000202F74250);//ML01
            // 0x028B7F8C: MOV v0.16b, v1.16b         | V0 = this.<Position>k__BackingField;//m1
            // 0x028B7F90: MOV v1.16b, v8.16b         | V1 = yCoordinate;//m1                   
            // 0x028B7F94: STR wzr, [sp, #8]          | stack[1152921513246540376] = 0x0;        //  dest_result_addr=1152921513246540376
            // 0x028B7F98: STR xzr, [sp]              | stack[1152921513246540368] = 0x0;        //  dest_result_addr=1152921513246540368
            // 0x028B7F9C: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B7FA0: LDP w8, w9, [sp]           | W8 = 0x0; W9 = 0x0;                      //  | 
            // 0x028B7FA4: LDR w10, [sp, #8]          | W10 = 0x0;                              
            // 0x028B7FA8: STR s8, [x19, #0x14]       | mem[1152921513246552452] = yCoordinate;  //  dest_result_addr=1152921513246552452
            mem[1152921513246552452] = yCoordinate;
            // 0x028B7FAC: STP w8, w9, [x19, #0x1c]   | this.<Position>k__BackingField = new UnityEngine.Vector3();  mem[1152921513246552464] = 0x0;  //  dest_result_addr=1152921513246552460 |  dest_result_addr=1152921513246552464
            this.<Position>k__BackingField = 0;
            mem[1152921513246552464] = 0;
            // 0x028B7FB0: STR w10, [x19, #0x24]      | mem[1152921513246552468] = 0x0;          //  dest_result_addr=1152921513246552468
            mem[1152921513246552468] = 0;
            // 0x028B7FB4: STR s8, [x19, #0x7c]       | mem[1152921513246552556] = yCoordinate;  //  dest_result_addr=1152921513246552556
            mem[1152921513246552556] = yCoordinate;
            // 0x028B7FB8: SUB sp, x29, #0x20         | SP = (1152921513246540416 - 32) = 1152921513246540384 (0x1000000202F74260);
            // 0x028B7FBC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028B7FC0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028B7FC4: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
            // 0x028B7FC8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7FCC (42696652), len: 8  VirtAddr: 0x028B7FCC RVA: 0x028B7FCC token: 100682454 methodIndex: 51066 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.RVO.RVOLayer get_Layer()
        {
            //
            // Disasemble & Code
            // 0x028B7FCC: LDR w0, [x0, #0x84]        | W0 = this.<Layer>k__BackingField; //P2  
            // 0x028B7FD0: RET                        |  return (Pathfinding.RVO.RVOLayer)this.<Layer>k__BackingField;
            return this.<Layer>k__BackingField;
            //  |  // // {name=val_0, type=Pathfinding.RVO.RVOLayer, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7F04 (42696452), len: 8  VirtAddr: 0x028B7F04 RVA: 0x028B7F04 token: 100682455 methodIndex: 51067 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Layer(Pathfinding.RVO.RVOLayer value)
        {
            //
            // Disasemble & Code
            // 0x028B7F04: STR w1, [x0, #0x84]        | this.<Layer>k__BackingField = value;     //  dest_result_addr=1152921513246788852
            this.<Layer>k__BackingField = value;
            // 0x028B7F08: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7FD4 (42696660), len: 8  VirtAddr: 0x028B7FD4 RVA: 0x028B7FD4 token: 100682456 methodIndex: 51068 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.RVO.RVOLayer get_CollidesWith()
        {
            //
            // Disasemble & Code
            // 0x028B7FD4: LDR w0, [x0, #0x88]        | W0 = this.<CollidesWith>k__BackingField; //P2 
            // 0x028B7FD8: RET                        |  return (Pathfinding.RVO.RVOLayer)this.<CollidesWith>k__BackingField;
            return this.<CollidesWith>k__BackingField;
            //  |  // // {name=val_0, type=Pathfinding.RVO.RVOLayer, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7F0C (42696460), len: 8  VirtAddr: 0x028B7F0C RVA: 0x028B7F0C token: 100682457 methodIndex: 51069 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_CollidesWith(Pathfinding.RVO.RVOLayer value)
        {
            //
            // Disasemble & Code
            // 0x028B7F0C: STR w1, [x0, #0x88]        | this.<CollidesWith>k__BackingField = value;  //  dest_result_addr=1152921513247029240
            this.<CollidesWith>k__BackingField = value;
            // 0x028B7F10: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7FDC (42696668), len: 8  VirtAddr: 0x028B7FDC RVA: 0x028B7FDC token: 100682458 methodIndex: 51070 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_Locked()
        {
            //
            // Disasemble & Code
            // 0x028B7FDC: LDRB w0, [x0, #0x8c]       | W0 = this.<Locked>k__BackingField; //P2 
            // 0x028B7FE0: RET                        |  return (System.Boolean)this.<Locked>k__BackingField;
            return this.<Locked>k__BackingField;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7EEC (42696428), len: 12  VirtAddr: 0x028B7EEC RVA: 0x028B7EEC token: 100682459 methodIndex: 51071 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Locked(bool value)
        {
            //
            // Disasemble & Code
            // 0x028B7EEC: AND w8, w1, #1             | W8 = (value & 1);                       
            bool val_1 = value;
            // 0x028B7EF0: STRB w8, [x0, #0x8c]       | this.<Locked>k__BackingField = (value & 1);  //  dest_result_addr=1152921513247257340
            this.<Locked>k__BackingField = val_1;
            // 0x028B7EF4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7FE4 (42696676), len: 8  VirtAddr: 0x028B7FE4 RVA: 0x028B7FE4 token: 100682460 methodIndex: 51072 delegateWrapperIndex: 0 methodInvoker: 0
        public float get_Radius()
        {
            //
            // Disasemble & Code
            // 0x028B7FE4: LDR s0, [x0, #0x90]        | S0 = this.<Radius>k__BackingField; //P2 
            // 0x028B7FE8: RET                        |  return (System.Single)this.<Radius>k__BackingField;
            return this.<Radius>k__BackingField;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7EDC (42696412), len: 8  VirtAddr: 0x028B7EDC RVA: 0x028B7EDC token: 100682461 methodIndex: 51073 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Radius(float value)
        {
            //
            // Disasemble & Code
            // 0x028B7EDC: STR s0, [x0, #0x90]        | this.<Radius>k__BackingField = value;    //  dest_result_addr=1152921513247481344
            this.<Radius>k__BackingField = value;
            // 0x028B7EE0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7FEC (42696684), len: 8  VirtAddr: 0x028B7FEC RVA: 0x028B7FEC token: 100682462 methodIndex: 51074 delegateWrapperIndex: 0 methodInvoker: 0
        public float get_Height()
        {
            //
            // Disasemble & Code
            // 0x028B7FEC: LDR s0, [x0, #0x94]        | S0 = this.<Height>k__BackingField; //P2 
            // 0x028B7FF0: RET                        |  return (System.Single)this.<Height>k__BackingField;
            return this.<Height>k__BackingField;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7ED4 (42696404), len: 8  VirtAddr: 0x028B7ED4 RVA: 0x028B7ED4 token: 100682463 methodIndex: 51075 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Height(float value)
        {
            //
            // Disasemble & Code
            // 0x028B7ED4: STR s0, [x0, #0x94]        | this.<Height>k__BackingField = value;    //  dest_result_addr=1152921513247705348
            this.<Height>k__BackingField = value;
            // 0x028B7ED8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7FF4 (42696692), len: 8  VirtAddr: 0x028B7FF4 RVA: 0x028B7FF4 token: 100682464 methodIndex: 51076 delegateWrapperIndex: 0 methodInvoker: 0
        public float get_MaxSpeed()
        {
            //
            // Disasemble & Code
            // 0x028B7FF4: LDR s0, [x0, #0x98]        | S0 = this.<MaxSpeed>k__BackingField; //P2 
            // 0x028B7FF8: RET                        |  return (System.Single)this.<MaxSpeed>k__BackingField;
            return this.<MaxSpeed>k__BackingField;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7EB4 (42696372), len: 8  VirtAddr: 0x028B7EB4 RVA: 0x028B7EB4 token: 100682465 methodIndex: 51077 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_MaxSpeed(float value)
        {
            //
            // Disasemble & Code
            // 0x028B7EB4: STR s0, [x0, #0x98]        | this.<MaxSpeed>k__BackingField = value;  //  dest_result_addr=1152921513247929352
            this.<MaxSpeed>k__BackingField = value;
            // 0x028B7EB8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7FFC (42696700), len: 8  VirtAddr: 0x028B7FFC RVA: 0x028B7FFC token: 100682466 methodIndex: 51078 delegateWrapperIndex: 0 methodInvoker: 0
        public float get_NeighbourDist()
        {
            //
            // Disasemble & Code
            // 0x028B7FFC: LDR s0, [x0, #0x9c]        | S0 = this.<NeighbourDist>k__BackingField; //P2 
            // 0x028B8000: RET                        |  return (System.Single)this.<NeighbourDist>k__BackingField;
            return this.<NeighbourDist>k__BackingField;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7EBC (42696380), len: 8  VirtAddr: 0x028B7EBC RVA: 0x028B7EBC token: 100682467 methodIndex: 51079 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_NeighbourDist(float value)
        {
            //
            // Disasemble & Code
            // 0x028B7EBC: STR s0, [x0, #0x9c]        | this.<NeighbourDist>k__BackingField = value;  //  dest_result_addr=1152921513248153356
            this.<NeighbourDist>k__BackingField = value;
            // 0x028B7EC0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B8004 (42696708), len: 8  VirtAddr: 0x028B8004 RVA: 0x028B8004 token: 100682468 methodIndex: 51080 delegateWrapperIndex: 0 methodInvoker: 0
        public float get_AgentTimeHorizon()
        {
            //
            // Disasemble & Code
            // 0x028B8004: LDR s0, [x0, #0xa0]        | S0 = this.<AgentTimeHorizon>k__BackingField; //P2 
            // 0x028B8008: RET                        |  return (System.Single)this.<AgentTimeHorizon>k__BackingField;
            return this.<AgentTimeHorizon>k__BackingField;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7EC4 (42696388), len: 8  VirtAddr: 0x028B7EC4 RVA: 0x028B7EC4 token: 100682469 methodIndex: 51081 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_AgentTimeHorizon(float value)
        {
            //
            // Disasemble & Code
            // 0x028B7EC4: STR s0, [x0, #0xa0]        | this.<AgentTimeHorizon>k__BackingField = value;  //  dest_result_addr=1152921513248377360
            this.<AgentTimeHorizon>k__BackingField = value;
            // 0x028B7EC8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B800C (42696716), len: 8  VirtAddr: 0x028B800C RVA: 0x028B800C token: 100682470 methodIndex: 51082 delegateWrapperIndex: 0 methodInvoker: 0
        public float get_ObstacleTimeHorizon()
        {
            //
            // Disasemble & Code
            // 0x028B800C: LDR s0, [x0, #0xa4]        | S0 = this.<ObstacleTimeHorizon>k__BackingField; //P2 
            // 0x028B8010: RET                        |  return (System.Single)this.<ObstacleTimeHorizon>k__BackingField;
            return this.<ObstacleTimeHorizon>k__BackingField;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7ECC (42696396), len: 8  VirtAddr: 0x028B7ECC RVA: 0x028B7ECC token: 100682471 methodIndex: 51083 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_ObstacleTimeHorizon(float value)
        {
            //
            // Disasemble & Code
            // 0x028B7ECC: STR s0, [x0, #0xa4]        | this.<ObstacleTimeHorizon>k__BackingField = value;  //  dest_result_addr=1152921513248601364
            this.<ObstacleTimeHorizon>k__BackingField = value;
            // 0x028B7ED0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B8014 (42696724), len: 12  VirtAddr: 0x028B8014 RVA: 0x028B8014 token: 100682472 methodIndex: 51084 delegateWrapperIndex: 0 methodInvoker: 0
        public UnityEngine.Vector3 get_Velocity()
        {
            //
            // Disasemble & Code
            // 0x028B8014: LDP s0, s1, [x0, #0xa8]    | S0 = this.<Velocity>k__BackingField; //P2   //  | 
            // 0x028B8018: LDR s2, [x0, #0xb0]        | 
            // 0x028B801C: RET                        |  return new UnityEngine.Vector3() {x = this.<Velocity>k__BackingField};
            return new UnityEngine.Vector3() {x = this.<Velocity>k__BackingField};
            //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B8020 (42696736), len: 12  VirtAddr: 0x028B8020 RVA: 0x028B8020 token: 100682473 methodIndex: 51085 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Velocity(UnityEngine.Vector3 value)
        {
            //
            // Disasemble & Code
            // 0x028B8020: STP s0, s1, [x0, #0xa8]    | this.<Velocity>k__BackingField = value;  mem[1152921513248825372] = value.y;  //  dest_result_addr=1152921513248825368 |  dest_result_addr=1152921513248825372
            this.<Velocity>k__BackingField = value;
            mem[1152921513248825372] = value.y;
            // 0x028B8024: STR s2, [x0, #0xb0]        | mem[1152921513248825376] = value.z;      //  dest_result_addr=1152921513248825376
            mem[1152921513248825376] = value.z;
            // 0x028B8028: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B802C (42696748), len: 8  VirtAddr: 0x028B802C RVA: 0x028B802C token: 100682474 methodIndex: 51086 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_DebugDraw()
        {
            //
            // Disasemble & Code
            // 0x028B802C: LDRB w0, [x0, #0xb4]       | W0 = this.<DebugDraw>k__BackingField; //P2 
            // 0x028B8030: RET                        |  return (System.Boolean)this.<DebugDraw>k__BackingField;
            return this.<DebugDraw>k__BackingField;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B8034 (42696756), len: 12  VirtAddr: 0x028B8034 RVA: 0x028B8034 token: 100682475 methodIndex: 51087 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_DebugDraw(bool value)
        {
            //
            // Disasemble & Code
            // 0x028B8034: AND w8, w1, #1             | W8 = (value & 1);                       
            bool val_1 = value;
            // 0x028B8038: STRB w8, [x0, #0xb4]       | this.<DebugDraw>k__BackingField = (value & 1);  //  dest_result_addr=1152921513249049380
            this.<DebugDraw>k__BackingField = val_1;
            // 0x028B803C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B8040 (42696768), len: 8  VirtAddr: 0x028B8040 RVA: 0x028B8040 token: 100682476 methodIndex: 51088 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_MaxNeighbours()
        {
            //
            // Disasemble & Code
            // 0x028B8040: LDR w0, [x0, #0xb8]        | W0 = this.<MaxNeighbours>k__BackingField; //P2 
            // 0x028B8044: RET                        |  return (System.Int32)this.<MaxNeighbours>k__BackingField;
            return this.<MaxNeighbours>k__BackingField;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B7EE4 (42696420), len: 8  VirtAddr: 0x028B7EE4 RVA: 0x028B7EE4 token: 100682477 methodIndex: 51089 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_MaxNeighbours(int value)
        {
            //
            // Disasemble & Code
            // 0x028B7EE4: STR w1, [x0, #0xb8]        | this.<MaxNeighbours>k__BackingField = value;  //  dest_result_addr=1152921513249273384
            this.<MaxNeighbours>k__BackingField = value;
            // 0x028B7EE8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B8048 (42696776), len: 8  VirtAddr: 0x028B8048 RVA: 0x028B8048 token: 100682478 methodIndex: 51090 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex> get_NeighbourObstacles()
        {
            //
            // Disasemble & Code
            // 0x028B8048: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B804C: RET                        |  return (System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>)null;
            return (System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>)0;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B8050 (42696784), len: 108  VirtAddr: 0x028B8050 RVA: 0x028B8050 token: 100682479 methodIndex: 51091 delegateWrapperIndex: 0 methodInvoker: 0
        public void BufferSwitch()
        {
            //
            // Disasemble & Code
            // 0x028B8050: LDP x8, x9, [x0, #0x90]    | X8 = this.<Radius>k__BackingField; //P2  X9 = this.<MaxSpeed>k__BackingField; //P2  //  | 
            float val_3 = this.<Radius>k__BackingField;
            // 0x028B8054: LDR w10, [x0, #0xb8]       | W10 = this.<MaxNeighbours>k__BackingField; //P2 
            // 0x028B8058: LDP w11, w12, [x0, #0x28]  | W11 = this.<DesiredVelocity>k__BackingField; //P2   //  | 
            // 0x028B805C: LDR w13, [x0, #0x30]       | 
            // 0x028B8060: STR w10, [x0, #0x5c]       | this.maxNeighbours = this.<MaxNeighbours>k__BackingField;  //  dest_result_addr=1152921513249513676
            this.maxNeighbours = this.<MaxNeighbours>k__BackingField;
            // 0x028B8064: LDRB w10, [x0, #0x8c]      | W10 = this.<Locked>k__BackingField; //P2 
            // 0x028B8068: STP w11, w12, [x0, #0x6c]  | this.desiredVelocity = this.<DesiredVelocity>k__BackingField;  mem[1152921513249513696] = ???;  //  dest_result_addr=1152921513249513692 |  dest_result_addr=1152921513249513696
            this.desiredVelocity = this.<DesiredVelocity>k__BackingField;
            mem[1152921513249513696] = ???;
            // 0x028B806C: LDP w11, w14, [x0, #0x84]  | W11 = this.<Layer>k__BackingField; //P2  W14 = this.<CollidesWith>k__BackingField; //P2  //  | 
            // 0x028B8070: STR w13, [x0, #0x74]       | mem[1152921513249513700] = ???;          //  dest_result_addr=1152921513249513700
            mem[1152921513249513700] = ???;
            // 0x028B8074: LDP w12, w13, [x0, #0xc8]  | W12 = this.velocity; //P2                //  | 
            // 0x028B8078: STRB w10, [x0, #0x50]      | this.locked = this.<Locked>k__BackingField;  //  dest_result_addr=1152921513249513664
            this.locked = this.<Locked>k__BackingField;
            // 0x028B807C: LDR w10, [x0, #0xd0]       | 
            // 0x028B8080: STP w11, w14, [x0, #0x54]  | this.layer = this.<Layer>k__BackingField;  this.collidesWith = this.<CollidesWith>k__BackingField;  //  dest_result_addr=1152921513249513668 |  dest_result_addr=1152921513249513672
            this.layer = this.<Layer>k__BackingField;
            this.collidesWith = this.<CollidesWith>k__BackingField;
            // 0x028B8084: LDP x11, x14, [x0, #0xf8]  | X11 = this.obstaclesBuffered; //P2  X14 = this.obstacles; //P2  //  | 
            // 0x028B8088: STP w12, w13, [x0, #0xa8]  | this.<Velocity>k__BackingField = this.velocity;  mem[1152921513249513756] = ???;  //  dest_result_addr=1152921513249513752 |  dest_result_addr=1152921513249513756
            this.<Velocity>k__BackingField = this.velocity;
            mem[1152921513249513756] = ???;
            // 0x028B808C: STR w10, [x0, #0xb0]       | mem[1152921513249513760] = this.<Locked>k__BackingField;  //  dest_result_addr=1152921513249513760
            mem[1152921513249513760] = this.<Locked>k__BackingField;
            // 0x028B8090: LDR x10, [x0, #0xa0]       | X10 = this.<AgentTimeHorizon>k__BackingField; //P2 
            // 0x028B8094: STR w8, [x0, #0x34]        | this.radius = this.<Radius>k__BackingField;  //  dest_result_addr=1152921513249513636
            this.radius = val_3;
            // 0x028B8098: LSR x8, x8, #0x20          | X8 = (this.<Radius>k__BackingField >> 32);
            val_3 = val_3 >> 32;
            // 0x028B809C: STR x14, [x0, #0xf8]       | this.obstaclesBuffered = this.obstacles;  //  dest_result_addr=1152921513249513832
            this.obstaclesBuffered = this.obstacles;
            // 0x028B80A0: STP w8, w9, [x0, #0x38]    | this.height = (this.<Radius>k__BackingField >> 32);  this.maxSpeed = this.<MaxSpeed>k__BackingField;  //  dest_result_addr=1152921513249513640 |  dest_result_addr=1152921513249513644
            this.height = val_3;
            this.maxSpeed = this.<MaxSpeed>k__BackingField;
            // 0x028B80A4: LSR x8, x9, #0x20          | X8 = (this.<MaxSpeed>k__BackingField >> 32);
            float val_1 = (this.<MaxSpeed>k__BackingField) >> 32;
            // 0x028B80A8: LSR x9, x10, #0x20         | X9 = (this.<AgentTimeHorizon>k__BackingField >> 32);
            float val_2 = (this.<AgentTimeHorizon>k__BackingField) >> 32;
            // 0x028B80AC: STP w8, w10, [x0, #0x40]   | this.neighbourDist = (this.<MaxSpeed>k__BackingField >> 32);  this.agentTimeHorizon = this.<AgentTimeHorizon>k__BackingField;  //  dest_result_addr=1152921513249513648 |  dest_result_addr=1152921513249513652
            this.neighbourDist = val_1;
            this.agentTimeHorizon = this.<AgentTimeHorizon>k__BackingField;
            // 0x028B80B0: STR w9, [x0, #0x48]        | this.obstacleTimeHorizon = (this.<AgentTimeHorizon>k__BackingField >> 32);  //  dest_result_addr=1152921513249513656
            this.obstacleTimeHorizon = val_2;
            // 0x028B80B4: STR x11, [x0, #0x100]      | this.obstacles = this.obstaclesBuffered;  //  dest_result_addr=1152921513249513840
            this.obstacles = this.obstaclesBuffered;
            // 0x028B80B8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B80BC (42696892), len: 284  VirtAddr: 0x028B80BC RVA: 0x028B80BC token: 100682480 methodIndex: 51092 delegateWrapperIndex: 0 methodInvoker: 0
        public void Update()
        {
            //
            // Disasemble & Code
            // 0x028B80BC: STP d15, d14, [sp, #-0x60]! | stack[1152921513249633968] = ???;  stack[1152921513249633976] = ???;  //  dest_result_addr=1152921513249633968 |  dest_result_addr=1152921513249633976
            // 0x028B80C0: STP d13, d12, [sp, #0x10]  | stack[1152921513249633984] = ???;  stack[1152921513249633992] = ???;  //  dest_result_addr=1152921513249633984 |  dest_result_addr=1152921513249633992
            // 0x028B80C4: STP d11, d10, [sp, #0x20]  | stack[1152921513249634000] = ???;  stack[1152921513249634008] = ???;  //  dest_result_addr=1152921513249634000 |  dest_result_addr=1152921513249634008
            // 0x028B80C8: STP d9, d8, [sp, #0x30]    | stack[1152921513249634016] = ???;  stack[1152921513249634024] = ???;  //  dest_result_addr=1152921513249634016 |  dest_result_addr=1152921513249634024
            // 0x028B80CC: STP x20, x19, [sp, #0x40]  | stack[1152921513249634032] = ???;  stack[1152921513249634040] = ???;  //  dest_result_addr=1152921513249634032 |  dest_result_addr=1152921513249634040
            // 0x028B80D0: STP x29, x30, [sp, #0x50]  | stack[1152921513249634048] = ???;  stack[1152921513249634056] = ???;  //  dest_result_addr=1152921513249634048 |  dest_result_addr=1152921513249634056
            // 0x028B80D4: ADD x29, sp, #0x50         | X29 = (1152921513249633968 + 80) = 1152921513249634048 (0x1000000203267700);
            // 0x028B80D8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028B80DC: LDRB w8, [x20, #0x914]     | W8 = (bool)static_value_037B8914;       
            // 0x028B80E0: MOV x19, x0                | X19 = 1152921513249646064 (0x100000020326A5F0);//ML01
            // 0x028B80E4: TBNZ w8, #0, #0x28b8100    | if (static_value_037B8914 == true) goto label_0;
            // 0x028B80E8: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x028B80EC: LDR x8, [x8, #0xcb8]       | X8 = 0x2B8AAC8;                         
            // 0x028B80F0: LDR w0, [x8]               | W0 = 0x170;                             
            // 0x028B80F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x170, ????);      
            // 0x028B80F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B80FC: STRB w8, [x20, #0x914]     | static_value_037B8914 = true;            //  dest_result_addr=58427668
            label_0:
            // 0x028B8100: LDP w8, w9, [x19, #0xd4]   | W8 = this.newVelocity; //P2              //  | 
            // 0x028B8104: LDP w10, w12, [x19, #0x10] | W10 = this.smoothPos; //P2               //  | 
            // 0x028B8108: LDR w11, [x19, #0xdc]      | 
            // 0x028B810C: LDR s8, [x19, #0x18]       | 
            // 0x028B8110: FMOV s13, w8               | S13 = (this.newVelocity);               
            // 0x028B8114: STP w10, w12, [x19, #0x78] | this.prevSmoothPos = this.smoothPos;  mem[1152921513249646188] = ???;  //  dest_result_addr=1152921513249646184 |  dest_result_addr=1152921513249646188
            this.prevSmoothPos = this.smoothPos;
            mem[1152921513249646188] = ???;
            // 0x028B8118: STP w10, w12, [x19, #0x60] | this.position = this.smoothPos;  mem[1152921513249646164] = ???;  //  dest_result_addr=1152921513249646160 |  dest_result_addr=1152921513249646164
            this.position = this.smoothPos;
            mem[1152921513249646164] = ???;
            // 0x028B811C: LDR x20, [x19, #0xe0]      | X20 = this.simulator; //P2              
            // 0x028B8120: FMOV s9, w10               | S9 = (this.smoothPos);                  
            // 0x028B8124: FMOV s10, w12              | S10 = (W12);                            
            // 0x028B8128: FMOV s12, w9               | S12 = (W9);                             
            // 0x028B812C: FMOV s11, w11              | S11 = (W11);                            
            // 0x028B8130: STP w8, w9, [x19, #0xc8]   | this.velocity = this.newVelocity;  mem[1152921513249646268] = ???;  //  dest_result_addr=1152921513249646264 |  dest_result_addr=1152921513249646268
            this.velocity = this.newVelocity;
            mem[1152921513249646268] = ???;
            // 0x028B8134: STR w11, [x19, #0xd0]      | mem[1152921513249646272] = ???;          //  dest_result_addr=1152921513249646272
            mem[1152921513249646272] = ???;
            // 0x028B8138: STR s8, [x19, #0x80]       | mem[1152921513249646192] = ???;          //  dest_result_addr=1152921513249646192
            mem[1152921513249646192] = ???;
            // 0x028B813C: STR s8, [x19, #0x68]       | mem[1152921513249646168] = ???;          //  dest_result_addr=1152921513249646168
            mem[1152921513249646168] = ???;
            // 0x028B8140: CBNZ x20, #0x28b8148       | if (this.simulator != null) goto label_1;
            if(this.simulator != null)
            {
                goto label_1;
            }
            // 0x028B8144: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x170, ????);      
            label_1:
            // 0x028B8148: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x028B814C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x028B8150: LDR s14, [x20, #0x50]      | S14 = this.simulator.deltaTime; //P2    
            // 0x028B8154: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x028B8158: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x028B815C: TBZ w8, #0, #0x28b816c     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028B8160: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x028B8164: CBNZ w8, #0x28b816c        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028B8168: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_3:
            // 0x028B816C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8170: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8174: MOV v0.16b, v13.16b        | V0 = this.newVelocity;//m1              
            // 0x028B8178: MOV v1.16b, v12.16b        | V1 = W9;//m1                            
            // 0x028B817C: MOV v2.16b, v11.16b        | V2 = W11;//m1                           
            // 0x028B8180: MOV v3.16b, v14.16b        | V3 = this.simulator.deltaTime;//m1      
            // 0x028B8184: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.newVelocity, y = W9, z = W11}, d:  this.simulator.deltaTime);
            UnityEngine.Vector3 val_1 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.newVelocity, y = W9, z = W11}, d:  this.simulator.deltaTime);
            // 0x028B8188: MOV v3.16b, v0.16b         | V3 = val_1.x;//m1                       
            // 0x028B818C: MOV v4.16b, v1.16b         | V4 = val_1.y;//m1                       
            // 0x028B8190: MOV v5.16b, v2.16b         | V5 = val_1.z;//m1                       
            // 0x028B8194: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8198: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B819C: MOV v0.16b, v9.16b         | V0 = this.smoothPos;//m1                
            // 0x028B81A0: MOV v1.16b, v10.16b        | V1 = W12;//m1                           
            // 0x028B81A4: MOV v2.16b, v8.16b         | V2 = V8.16B;//m1                        
            // 0x028B81A8: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = this.smoothPos, y = W12, z = V8.16B}, b:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z});
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = this.smoothPos, y = W12, z = V8.16B}, b:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z});
            // 0x028B81AC: STP s0, s1, [x19, #0x60]   | this.position = val_2;  mem[1152921513249646164] = val_2.y;  //  dest_result_addr=1152921513249646160 |  dest_result_addr=1152921513249646164
            this.position = val_2;
            mem[1152921513249646164] = val_2.y;
            // 0x028B81B0: STR s2, [x19, #0x68]       | mem[1152921513249646168] = val_2.z;      //  dest_result_addr=1152921513249646168
            mem[1152921513249646168] = val_2.z;
            // 0x028B81B4: STP s0, s1, [x19, #0x1c]   | this.<Position>k__BackingField = val_2;  mem[1152921513249646096] = val_2.y;  //  dest_result_addr=1152921513249646092 |  dest_result_addr=1152921513249646096
            this.<Position>k__BackingField = val_2;
            mem[1152921513249646096] = val_2.y;
            // 0x028B81B8: STR s2, [x19, #0x24]       | mem[1152921513249646100] = val_2.z;      //  dest_result_addr=1152921513249646100
            mem[1152921513249646100] = val_2.z;
            // 0x028B81BC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028B81C0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028B81C4: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x028B81C8: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x028B81CC: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x028B81D0: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x028B81D4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B81E0 (42697184), len: 244  VirtAddr: 0x028B81E0 RVA: 0x028B81E0 token: 100682481 methodIndex: 51093 delegateWrapperIndex: 0 methodInvoker: 0
        public void Interpolate(float t)
        {
            //
            // Disasemble & Code
            // 0x028B81E0: STP d15, d14, [sp, #-0x60]! | stack[1152921513249750064] = ???;  stack[1152921513249750072] = ???;  //  dest_result_addr=1152921513249750064 |  dest_result_addr=1152921513249750072
            // 0x028B81E4: STP d13, d12, [sp, #0x10]  | stack[1152921513249750080] = ???;  stack[1152921513249750088] = ???;  //  dest_result_addr=1152921513249750080 |  dest_result_addr=1152921513249750088
            // 0x028B81E8: STP d11, d10, [sp, #0x20]  | stack[1152921513249750096] = ???;  stack[1152921513249750104] = ???;  //  dest_result_addr=1152921513249750096 |  dest_result_addr=1152921513249750104
            // 0x028B81EC: STP d9, d8, [sp, #0x30]    | stack[1152921513249750112] = ???;  stack[1152921513249750120] = ???;  //  dest_result_addr=1152921513249750112 |  dest_result_addr=1152921513249750120
            // 0x028B81F0: STP x20, x19, [sp, #0x40]  | stack[1152921513249750128] = ???;  stack[1152921513249750136] = ???;  //  dest_result_addr=1152921513249750128 |  dest_result_addr=1152921513249750136
            // 0x028B81F4: STP x29, x30, [sp, #0x50]  | stack[1152921513249750144] = ???;  stack[1152921513249750152] = ???;  //  dest_result_addr=1152921513249750144 |  dest_result_addr=1152921513249750152
            // 0x028B81F8: ADD x29, sp, #0x50         | X29 = (1152921513249750064 + 80) = 1152921513249750144 (0x1000000203283C80);
            // 0x028B81FC: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028B8200: LDRB w8, [x20, #0x915]     | W8 = (bool)static_value_037B8915;       
            // 0x028B8204: MOV v8.16b, v0.16b         | V8 = t;//m1                             
            // 0x028B8208: MOV x19, x0                | X19 = 1152921513249762160 (0x1000000203286B70);//ML01
            // 0x028B820C: TBNZ w8, #0, #0x28b8228    | if (static_value_037B8915 == true) goto label_0;
            // 0x028B8210: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
            // 0x028B8214: LDR x8, [x8, #0x240]       | X8 = 0x2B8AAC0;                         
            // 0x028B8218: LDR w0, [x8]               | W0 = 0x16E;                             
            // 0x028B821C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16E, ????);      
            // 0x028B8220: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B8224: STRB w8, [x20, #0x915]     | static_value_037B8915 = true;            //  dest_result_addr=58427669
            label_0:
            // 0x028B8228: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x028B822C: LDP s9, s10, [x19, #0x78]  | S9 = this.prevSmoothPos; //P2            //  | 
            // 0x028B8230: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x028B8234: LDR s11, [x19, #0x80]      | 
            // 0x028B8238: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x028B823C: LDP s14, s13, [x19, #0x1c] | S14 = this.<Position>k__BackingField; //P2   //  | 
            // 0x028B8240: LDR s12, [x19, #0x24]      | 
            // 0x028B8244: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x028B8248: TBZ w8, #0, #0x28b8258     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028B824C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x028B8250: CBNZ w8, #0x28b8258        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028B8254: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x028B8258: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B825C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8260: MOV v0.16b, v14.16b        | V0 = this.<Position>k__BackingField;//m1
            // 0x028B8264: MOV v1.16b, v13.16b        | V1 = V13.16B;//m1                       
            // 0x028B8268: MOV v2.16b, v12.16b        | V2 = V12.16B;//m1                       
            // 0x028B826C: MOV v3.16b, v9.16b         | V3 = this.prevSmoothPos;//m1            
            // 0x028B8270: MOV v4.16b, v10.16b        | V4 = V10.16B;//m1                       
            // 0x028B8274: MOV v5.16b, v11.16b        | V5 = V11.16B;//m1                       
            // 0x028B8278: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.<Position>k__BackingField, y = V13.16B, z = V12.16B}, b:  new UnityEngine.Vector3() {x = this.prevSmoothPos, y = V10.16B, z = V11.16B});
            UnityEngine.Vector3 val_1 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.<Position>k__BackingField, y = V13.16B, z = V12.16B}, b:  new UnityEngine.Vector3() {x = this.prevSmoothPos, y = V10.16B, z = V11.16B});
            // 0x028B827C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8280: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8284: MOV v3.16b, v8.16b         | V3 = t;//m1                             
            // 0x028B8288: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, d:  t);
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, d:  t);
            // 0x028B828C: MOV v3.16b, v0.16b         | V3 = val_2.x;//m1                       
            // 0x028B8290: MOV v4.16b, v1.16b         | V4 = val_2.y;//m1                       
            // 0x028B8294: MOV v5.16b, v2.16b         | V5 = val_2.z;//m1                       
            // 0x028B8298: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B829C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B82A0: MOV v0.16b, v9.16b         | V0 = this.prevSmoothPos;//m1            
            // 0x028B82A4: MOV v1.16b, v10.16b        | V1 = V10.16B;//m1                       
            // 0x028B82A8: MOV v2.16b, v11.16b        | V2 = V11.16B;//m1                       
            // 0x028B82AC: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = this.prevSmoothPos, y = V10.16B, z = V11.16B}, b:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = this.prevSmoothPos, y = V10.16B, z = V11.16B}, b:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
            // 0x028B82B0: STP s0, s1, [x19, #0x10]   | this.smoothPos = val_3;  mem[1152921513249762180] = val_3.y;  //  dest_result_addr=1152921513249762176 |  dest_result_addr=1152921513249762180
            this.smoothPos = val_3;
            mem[1152921513249762180] = val_3.y;
            // 0x028B82B4: STR s2, [x19, #0x18]       | mem[1152921513249762184] = val_3.z;      //  dest_result_addr=1152921513249762184
            mem[1152921513249762184] = val_3.z;
            // 0x028B82B8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028B82BC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028B82C0: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x028B82C4: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x028B82C8: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x028B82CC: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x028B82D0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B82D4 (42697428), len: 312  VirtAddr: 0x028B82D4 RVA: 0x028B82D4 token: 100682482 methodIndex: 51094 delegateWrapperIndex: 0 methodInvoker: 0
        public void CalculateNeighbours()
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.RVO.Sampled.Agent val_3;
            // 0x028B82D4: STP d9, d8, [sp, #-0x40]!  | stack[1152921513249888720] = ???;  stack[1152921513249888728] = ???;  //  dest_result_addr=1152921513249888720 |  dest_result_addr=1152921513249888728
            // 0x028B82D8: STP x22, x21, [sp, #0x10]  | stack[1152921513249888736] = ???;  stack[1152921513249888744] = ???;  //  dest_result_addr=1152921513249888736 |  dest_result_addr=1152921513249888744
            // 0x028B82DC: STP x20, x19, [sp, #0x20]  | stack[1152921513249888752] = ???;  stack[1152921513249888760] = ???;  //  dest_result_addr=1152921513249888752 |  dest_result_addr=1152921513249888760
            // 0x028B82E0: STP x29, x30, [sp, #0x30]  | stack[1152921513249888768] = ???;  stack[1152921513249888776] = ???;  //  dest_result_addr=1152921513249888768 |  dest_result_addr=1152921513249888776
            // 0x028B82E4: ADD x29, sp, #0x30         | X29 = (1152921513249888720 + 48) = 1152921513249888768 (0x10000002032A5A00);
            // 0x028B82E8: SUB sp, sp, #0x10          | SP = (1152921513249888720 - 16) = 1152921513249888704 (0x10000002032A59C0);
            // 0x028B82EC: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028B82F0: LDRB w8, [x20, #0x916]     | W8 = (bool)static_value_037B8916;       
            // 0x028B82F4: MOV x19, x0                | X19 = 1152921513249900784 (0x10000002032A88F0);//ML01
            val_3 = this;
            // 0x028B82F8: TBNZ w8, #0, #0x28b8314    | if (static_value_037B8916 == true) goto label_0;
            // 0x028B82FC: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x028B8300: LDR x8, [x8, #0xe50]       | X8 = 0x2B8AA9C;                         
            // 0x028B8304: LDR w0, [x8]               | W0 = 0x165;                             
            // 0x028B8308: BL #0x2782188              | X0 = sub_2782188( ?? 0x165, ????);      
            // 0x028B830C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B8310: STRB w8, [x20, #0x916]     | static_value_037B8916 = true;            //  dest_result_addr=58427670
            label_0:
            // 0x028B8314: LDR x20, [x19, #0xe8]      | X20 = this.neighbours; //P2             
            // 0x028B8318: CBNZ x20, #0x28b8320       | if (this.neighbours != null) goto label_1;
            if(this.neighbours != null)
            {
                goto label_1;
            }
            // 0x028B831C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x165, ????);      
            label_1:
            // 0x028B8320: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x028B8324: LDR x8, [x8, #0xb08]       | X8 = 1152921513249854256;               
            // 0x028B8328: MOV x0, x20                | X0 = this.neighbours;//m1               
            // 0x028B832C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::Clear();
            // 0x028B8330: BL #0x25ead28              | this.neighbours.Clear();                
            this.neighbours.Clear();
            // 0x028B8334: LDR x20, [x19, #0xf0]      | X20 = this.neighbourDists; //P2         
            // 0x028B8338: CBNZ x20, #0x28b8340       | if (this.neighbourDists != null) goto label_2;
            if(this.neighbourDists != null)
            {
                goto label_2;
            }
            // 0x028B833C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.neighbours, ????);
            label_2:
            // 0x028B8340: ADRP x21, #0x3662000       | X21 = 57024512 (0x3662000);             
            // 0x028B8344: LDR x21, [x21, #0xd20]     | X21 = 1152921510888915024;              
            // 0x028B8348: MOV x0, x20                | X0 = this.neighbourDists;//m1           
            // 0x028B834C: LDR x1, [x21]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::Clear();
            // 0x028B8350: BL #0x25f82e0              | this.neighbourDists.Clear();            
            this.neighbourDists.Clear();
            // 0x028B8354: LDRB w8, [x19, #0x50]      | W8 = this.locked; //P2                  
            // 0x028B8358: CBNZ w8, #0x28b83f4        | if (this.locked == true) goto label_3;  
            if(this.locked == true)
            {
                goto label_3;
            }
            // 0x028B835C: LDR w8, [x19, #0xb8]       | W8 = this.<MaxNeighbours>k__BackingField; //P2 
            // 0x028B8360: CMP w8, #1                 | STATE = COMPARE(this.<MaxNeighbours>k__BackingField, 0x1)
            // 0x028B8364: B.LT #0x28b83bc            | if (this.<MaxNeighbours>k__BackingField < 1) goto label_4;
            if((this.<MaxNeighbours>k__BackingField) < 1)
            {
                goto label_4;
            }
            // 0x028B8368: LDR x20, [x19, #0xe0]      | X20 = this.simulator; //P2              
            // 0x028B836C: CBNZ x20, #0x28b8374       | if (this.simulator != null) goto label_5;
            if(this.simulator != null)
            {
                goto label_5;
            }
            // 0x028B8370: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.neighbourDists, ????);
            label_5:
            // 0x028B8374: LDR s0, [x19, #0x60]       | S0 = this.position; //P2                
            // 0x028B8378: LDR s1, [x19, #0x68]       | 
            // 0x028B837C: LDR x20, [x20, #0x40]      | X20 = this.simulator.quadtree; //P2     
            // 0x028B8380: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8384: ADD x0, sp, #8             | X0 = (1152921513249888704 + 8) = 1152921513249888712 (0x10000002032A59C8);
            // 0x028B8388: STR xzr, [sp, #8]          | stack[1152921513249888712] = 0x0;        //  dest_result_addr=1152921513249888712
            // 0x028B838C: BL #0x2697148              | null..ctor(_x:  this.position, _y:  null);
            Geometric.Point val_1 = new Geometric.Point(_x:  this.position, _y:  null);
            // 0x028B8390: LDR s8, [x19, #0x40]       | S8 = this.neighbourDist; //P2           
            // 0x028B8394: CBNZ x20, #0x28b839c       | if (this.simulator.quadtree != null) goto label_6;
            if(this.simulator.quadtree != null)
            {
                goto label_6;
            }
            // 0x028B8398: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  this.position, _y:  null), ????);
            label_6:
            // 0x028B839C: LDP s0, s1, [sp, #8]       | S0 = val_1.x; S1 = val_1.y;              //  | 
            // 0x028B83A0: LDP s3, s4, [x20, #0x24]   | S3 = this.simulator.quadtree.bounds; //P2   //  | 
            // 0x028B83A4: LDP s5, s6, [x20, #0x2c]   |                                          //  | 
            // 0x028B83A8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x028B83AC: MOV x0, x20                | X0 = this.simulator.quadtree;//m1       
            // 0x028B83B0: MOV v2.16b, v8.16b         | V2 = this.neighbourDist;//m1            
            // 0x028B83B4: MOV x2, x19                | X2 = 1152921513249900784 (0x10000002032A88F0);//ML01
            // 0x028B83B8: BL #0x28b5904              | X0 = this.simulator.quadtree.QueryRec(i:  0, p:  new UnityEngine.Vector2() {x = val_1.x, y = val_1.y}, radius:  this.neighbourDist, agent:  this, r:  new UnityEngine.Rect() {m_XMin = this.simulator.quadtree.bounds});
            float val_2 = this.simulator.quadtree.QueryRec(i:  0, p:  new UnityEngine.Vector2() {x = val_1.x, y = val_1.y}, radius:  this.neighbourDist, agent:  this, r:  new UnityEngine.Rect() {m_XMin = this.simulator.quadtree.bounds});
            label_4:
            // 0x028B83BC: LDR x20, [x19, #0x100]     | X20 = this.obstacles; //P2              
            // 0x028B83C0: CBNZ x20, #0x28b83c8       | if (this.obstacles != null) goto label_7;
            if(this.obstacles != null)
            {
                goto label_7;
            }
            // 0x028B83C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.simulator.quadtree, ????);
            label_7:
            // 0x028B83C8: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x028B83CC: LDR x8, [x8, #0xa78]       | X8 = 1152921513249871664;               
            // 0x028B83D0: MOV x0, x20                | X0 = this.obstacles;//m1                
            // 0x028B83D4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::Clear();
            // 0x028B83D8: BL #0x25ead28              | this.obstacles.Clear();                 
            this.obstacles.Clear();
            // 0x028B83DC: LDR x19, [x19, #0x108]     | X19 = this.obstacleDists; //P2          
            val_3 = this.obstacleDists;
            // 0x028B83E0: CBNZ x19, #0x28b83e8       | if (this.obstacleDists != null) goto label_8;
            if(val_3 != null)
            {
                goto label_8;
            }
            // 0x028B83E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.obstacles, ????);
            label_8:
            // 0x028B83E8: LDR x1, [x21]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::Clear();
            // 0x028B83EC: MOV x0, x19                | X0 = this.obstacleDists;//m1            
            // 0x028B83F0: BL #0x25f82e0              | this.obstacleDists.Clear();             
            val_3.Clear();
            label_3:
            // 0x028B83F4: SUB sp, x29, #0x30         | SP = (1152921513249888768 - 48) = 1152921513249888720 (0x10000002032A59D0);
            // 0x028B83F8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028B83FC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028B8400: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028B8404: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
            // 0x028B8408: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B8414 (42697748), len: 8  VirtAddr: 0x028B8414 RVA: 0x028B8414 token: 100682483 methodIndex: 51095 delegateWrapperIndex: 0 methodInvoker: 0
        private float Sqr(float x)
        {
            //
            // Disasemble & Code
            // 0x028B8414: FMUL s0, s0, s0            | S0 = (x * x);                           
            x = x * x;
            // 0x028B8418: RET                        |  return (System.Single)(x * x);         
            return (float)x;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B5D5C (42687836), len: 900  VirtAddr: 0x028B5D5C RVA: 0x028B5D5C token: 100682484 methodIndex: 51096 delegateWrapperIndex: 0 methodInvoker: 0
        public float InsertAgentNeighbour(Pathfinding.RVO.Sampled.Agent agent, float rangeSq)
        {
            //
            // Disasemble & Code
            //  | 
            int val_17;
            //  | 
            float val_18;
            //  | 
            var val_19;
            //  | 
            System.Collections.Generic.List<System.Single> val_20;
            //  | 
            var val_21;
            //  | 
            System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent> val_22;
            //  | 
            Pathfinding.RVO.Sampled.Agent val_23;
            //  | 
            float val_24;
            //  | 
            var val_25;
            // 0x028B5D5C: STP d11, d10, [sp, #-0x80]! | stack[1152921513250211984] = ???;  stack[1152921513250211992] = ???;  //  dest_result_addr=1152921513250211984 |  dest_result_addr=1152921513250211992
            // 0x028B5D60: STP d9, d8, [sp, #0x10]    | stack[1152921513250212000] = ???;  stack[1152921513250212008] = ???;  //  dest_result_addr=1152921513250212000 |  dest_result_addr=1152921513250212008
            // 0x028B5D64: STP x28, x27, [sp, #0x20]  | stack[1152921513250212016] = ???;  stack[1152921513250212024] = ???;  //  dest_result_addr=1152921513250212016 |  dest_result_addr=1152921513250212024
            // 0x028B5D68: STP x26, x25, [sp, #0x30]  | stack[1152921513250212032] = ???;  stack[1152921513250212040] = ???;  //  dest_result_addr=1152921513250212032 |  dest_result_addr=1152921513250212040
            // 0x028B5D6C: STP x24, x23, [sp, #0x40]  | stack[1152921513250212048] = ???;  stack[1152921513250212056] = ???;  //  dest_result_addr=1152921513250212048 |  dest_result_addr=1152921513250212056
            // 0x028B5D70: STP x22, x21, [sp, #0x50]  | stack[1152921513250212064] = ???;  stack[1152921513250212072] = ???;  //  dest_result_addr=1152921513250212064 |  dest_result_addr=1152921513250212072
            // 0x028B5D74: STP x20, x19, [sp, #0x60]  | stack[1152921513250212080] = ???;  stack[1152921513250212088] = ???;  //  dest_result_addr=1152921513250212080 |  dest_result_addr=1152921513250212088
            // 0x028B5D78: STP x29, x30, [sp, #0x70]  | stack[1152921513250212096] = ???;  stack[1152921513250212104] = ???;  //  dest_result_addr=1152921513250212096 |  dest_result_addr=1152921513250212104
            // 0x028B5D7C: ADD x29, sp, #0x70         | X29 = (1152921513250211984 + 112) = 1152921513250212096 (0x10000002032F4900);
            // 0x028B5D80: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028B5D84: LDRB w8, [x21, #0x917]     | W8 = (bool)static_value_037B8917;       
            // 0x028B5D88: MOV v8.16b, v0.16b         | V8 = rangeSq;//m1                       
            // 0x028B5D8C: MOV x20, x1                | X20 = agent;//m1                        
            // 0x028B5D90: MOV x19, x0                | X19 = 1152921513250224112 (0x10000002032F77F0);//ML01
            // 0x028B5D94: TBNZ w8, #0, #0x28b5db0    | if (static_value_037B8917 == true) goto label_0;
            // 0x028B5D98: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x028B5D9C: LDR x8, [x8, #0x5f0]       | X8 = 0x2B8AAB8;                         
            // 0x028B5DA0: LDR w0, [x8]               | W0 = 0x16C;                             
            // 0x028B5DA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x16C, ????);      
            // 0x028B5DA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B5DAC: STRB w8, [x21, #0x917]     | static_value_037B8917 = true;            //  dest_result_addr=58427671
            label_0:
            // 0x028B5DB0: CMP x19, x20               | STATE = COMPARE(this, agent)            
            // 0x028B5DB4: B.EQ #0x28b6068            | if (this == agent) goto label_25;       
            if(this == agent)
            {
                goto label_25;
            }
            // 0x028B5DB8: CBNZ x20, #0x28b5dc0       | if (agent != null) goto label_2;        
            if(agent != null)
            {
                goto label_2;
            }
            // 0x028B5DBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16C, ????);      
            label_2:
            // 0x028B5DC0: LDR w8, [x20, #0x54]       | W8 = agent.layer; //P2                  
            Pathfinding.RVO.RVOLayer val_17 = agent.layer;
            // 0x028B5DC4: LDR w9, [x19, #0x58]       | W9 = this.collidesWith; //P2            
            // 0x028B5DC8: AND w8, w9, w8             | W8 = (this.collidesWith & agent.layer); 
            val_17 = this.collidesWith & val_17;
            // 0x028B5DCC: CBZ w8, #0x28b6068         | if ((this.collidesWith & agent.layer) == 0) goto label_25;
            if(val_17 == 0)
            {
                goto label_25;
            }
            // 0x028B5DD0: LDR s0, [x20, #0x60]       | S0 = agent.position; //P2               
            UnityEngine.Vector3 val_18 = agent.position;
            // 0x028B5DD4: LDR s1, [x19, #0x60]       | S1 = this.position; //P2                
            // 0x028B5DD8: LDR s2, [x20, #0x68]       | 
            // 0x028B5DDC: LDR s3, [x19, #0x68]       | 
            // 0x028B5DE0: FSUB s0, s0, s1            | S0 = (agent.position - this.position);  
            val_18 = val_18 - this.position;
            // 0x028B5DE4: FMUL s0, s0, s0            | S0 = ((agent.position - this.position) * (agent.position - this.position));
            val_18 = val_18 * val_18;
            // 0x028B5DE8: FSUB s1, s2, s3            | S1 = (S2 - S3);                         
            float val_1 = S2 - S3;
            // 0x028B5DEC: FMUL s1, s1, s1            | S1 = ((S2 - S3) * (S2 - S3));           
            val_1 = val_1 * val_1;
            // 0x028B5DF0: FADD s9, s0, s1            | S9 = (((agent.position - this.position) * (agent.position - this.position)) + ((S2 - S3) * (S2 - S3)));
            float val_2 = val_18 + val_1;
            // 0x028B5DF4: FCMP s9, s8                | STATE = COMPARE((((agent.position - this.position) * (agent.position - this.position)) + ((S2 - S3) * (S2 - S3))), rangeSq)
            // 0x028B5DF8: B.PL #0x28b6068            | if (val_2 >= 0) goto label_25;          
            if(val_2 >= 0)
            {
                goto label_25;
            }
            // 0x028B5DFC: LDR x21, [x19, #0xe8]      | X21 = this.neighbours; //P2             
            // 0x028B5E00: CBNZ x21, #0x28b5e08       | if (this.neighbours != null) goto label_5;
            if(this.neighbours != null)
            {
                goto label_5;
            }
            // 0x028B5E04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16C, ????);      
            label_5:
            // 0x028B5E08: ADRP x24, #0x364d000       | X24 = 56938496 (0x364D000);             
            // 0x028B5E0C: LDR x24, [x24, #0x6d8]     | X24 = 1152921513250141744;              
            val_19 = 1152921513250141744;
            // 0x028B5E10: MOV x0, x21                | X0 = this.neighbours;//m1               
            // 0x028B5E14: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::get_Count();
            // 0x028B5E18: BL #0x25ed72c              | X0 = this.neighbours.get_Count();       
            int val_3 = this.neighbours.Count;
            // 0x028B5E1C: LDR w8, [x19, #0x5c]       | W8 = this.maxNeighbours; //P2           
            // 0x028B5E20: CMP w0, w8                 | STATE = COMPARE(val_3, this.maxNeighbours)
            // 0x028B5E24: B.GE #0x28b5e70            | if (val_3 >= this.maxNeighbours) goto label_6;
            if(val_3 >= this.maxNeighbours)
            {
                goto label_6;
            }
            // 0x028B5E28: LDR x21, [x19, #0xe8]      | X21 = this.neighbours; //P2             
            // 0x028B5E2C: CBNZ x21, #0x28b5e34       | if (this.neighbours != null) goto label_7;
            if(this.neighbours != null)
            {
                goto label_7;
            }
            // 0x028B5E30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_7:
            // 0x028B5E34: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028B5E38: LDR x8, [x8, #0x5f0]       | X8 = 1152921513250146864;               
            // 0x028B5E3C: MOV x0, x21                | X0 = this.neighbours;//m1               
            // 0x028B5E40: MOV x1, x20                | X1 = agent;//m1                         
            // 0x028B5E44: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::Add(Pathfinding.RVO.Sampled.Agent item);
            // 0x028B5E48: BL #0x25ea480              | this.neighbours.Add(item:  agent);      
            this.neighbours.Add(item:  agent);
            // 0x028B5E4C: LDR x21, [x19, #0xf0]      | X21 = this.neighbourDists; //P2         
            // 0x028B5E50: CBNZ x21, #0x28b5e58       | if (this.neighbourDists != null) goto label_8;
            if(this.neighbourDists != null)
            {
                goto label_8;
            }
            // 0x028B5E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.neighbours, ????);
            label_8:
            // 0x028B5E58: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x028B5E5C: LDR x8, [x8, #0xe38]       | X8 = 1152921510888403920;               
            // 0x028B5E60: MOV x0, x21                | X0 = this.neighbourDists;//m1           
            // 0x028B5E64: MOV v0.16b, v9.16b         | V0 = (((agent.position - this.position) * (agent.position - this.position)) + ((S2 - S3) * (S2 - S3)));//m1
            val_18 = val_2;
            // 0x028B5E68: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Single>::Add(System.Single item);
            // 0x028B5E6C: BL #0x25f7a38              | this.neighbourDists.Add(item:  val_18 = val_2);
            this.neighbourDists.Add(item:  val_18);
            label_6:
            // 0x028B5E70: LDR x21, [x19, #0xe8]      | X21 = this.neighbours; //P2             
            // 0x028B5E74: CBNZ x21, #0x28b5e7c       | if (this.neighbours != null) goto label_9;
            if(this.neighbours != null)
            {
                goto label_9;
            }
            // 0x028B5E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.neighbourDists, ????);
            label_9:
            // 0x028B5E7C: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::get_Count();
            // 0x028B5E80: MOV x0, x21                | X0 = this.neighbours;//m1               
            // 0x028B5E84: BL #0x25ed72c              | X0 = this.neighbours.get_Count();       
            int val_4 = this.neighbours.Count;
            // 0x028B5E88: LDR x23, [x19, #0xf0]      | X23 = this.neighbourDists; //P2         
            val_20 = this.neighbourDists;
            // 0x028B5E8C: MOV w21, w0                | W21 = val_4;//m1                        
            val_17 = val_4;
            // 0x028B5E90: SUB w22, w21, #1           | W22 = (val_4 - 1);                      
            int val_5 = val_17 - 1;
            // 0x028B5E94: CBNZ x23, #0x28b5e9c       | if (this.neighbourDists != null) goto label_10;
            if(val_20 != null)
            {
                goto label_10;
            }
            // 0x028B5E98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_10:
            // 0x028B5E9C: ADRP x26, #0x35e2000       | X26 = 56500224 (0x35E2000);             
            // 0x028B5EA0: LDR x26, [x26, #0xbb0]     | X26 = 1152921510888574288;              
            // 0x028B5EA4: MOV x0, x23                | X0 = this.neighbourDists;//m1           
            // 0x028B5EA8: MOV w1, w22                | W1 = (val_4 - 1);//m1                   
            // 0x028B5EAC: LDR x2, [x26]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
            // 0x028B5EB0: BL #0x25fad28              | X0 = this.neighbourDists.get_Item(index:  val_5);
            float val_6 = val_20.Item[val_5];
            // 0x028B5EB4: FCMP s9, s0                | STATE = COMPARE((((agent.position - this.position) * (agent.position - this.position)) + ((S2 - S3) * (S2 - S3))), val_6)
            // 0x028B5EB8: B.PL #0x28b6020            | if (val_2 >= 0) goto label_11;          
            if(val_2 >= 0)
            {
                goto label_11;
            }
            // 0x028B5EBC: CBZ w22, #0x28b5fbc        | if ((val_4 - 1) == 0) goto label_12;    
            if(val_5 == 0)
            {
                goto label_12;
            }
            // 0x028B5EC0: ADRP x27, #0x35c6000       | X27 = 56385536 (0x35C6000);             
            // 0x028B5EC4: ADRP x28, #0x35ba000       | X28 = 56336384 (0x35BA000);             
            // 0x028B5EC8: ADRP x25, #0x3639000       | X25 = 56856576 (0x3639000);             
            // 0x028B5ECC: LDR x27, [x27, #8]         | X27 = 1152921513250160176;              
            // 0x028B5ED0: LDR x28, [x28, #0xe00]     | X28 = 1152921513250161200;              
            // 0x028B5ED4: LDR x25, [x25, #0xbf0]     | X25 = 1152921513250162224;              
            // 0x028B5ED8: SUB w21, w21, #2           | W21 = (val_4 - 2);                      
            val_17 = val_17 - 2;
            label_19:
            // 0x028B5EDC: LDR x22, [x19, #0xf0]      | X22 = this.neighbourDists; //P2         
            // 0x028B5EE0: CBNZ x22, #0x28b5ee8       | if (this.neighbourDists != null) goto label_13;
            if(this.neighbourDists != null)
            {
                goto label_13;
            }
            // 0x028B5EE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.neighbourDists, ????);
            label_13:
            // 0x028B5EE8: LDR x2, [x26]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
            // 0x028B5EEC: MOV x0, x22                | X0 = this.neighbourDists;//m1           
            // 0x028B5EF0: MOV w1, w21                | W1 = (val_4 - 2);//m1                   
            // 0x028B5EF4: BL #0x25fad28              | X0 = this.neighbourDists.get_Item(index:  val_17);
            float val_7 = this.neighbourDists.Item[val_17];
            // 0x028B5EF8: FCMP s9, s0                | STATE = COMPARE((((agent.position - this.position) * (agent.position - this.position)) + ((S2 - S3) * (S2 - S3))), val_7)
            // 0x028B5EFC: B.PL #0x28b5fc4            | if (val_2 >= 0) goto label_14;          
            if(val_2 >= 0)
            {
                goto label_14;
            }
            // 0x028B5F00: LDR x23, [x19, #0xe8]      | X23 = this.neighbours; //P2             
            val_22 = this.neighbours;
            // 0x028B5F04: ADD w22, w21, #1           | W22 = ((val_4 - 2) + 1);                
            int val_8 = val_17 + 1;
            // 0x028B5F08: CBZ x23, #0x28b5f24        | if (this.neighbours == null) goto label_15;
            if(val_22 == null)
            {
                goto label_15;
            }
            // 0x028B5F0C: LDR x2, [x27]              | X2 = public Pathfinding.RVO.Sampled.Agent System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::get_Item(int index);
            // 0x028B5F10: MOV x0, x23                | X0 = this.neighbours;//m1               
            // 0x028B5F14: MOV w1, w21                | W1 = (val_4 - 2);//m1                   
            // 0x028B5F18: BL #0x25ed734              | X0 = this.neighbours.get_Item(index:  val_17);
            Pathfinding.RVO.Sampled.Agent val_9 = val_22.Item[val_17];
            // 0x028B5F1C: MOV x24, x0                | X24 = val_9;//m1                        
            val_23 = val_9;
            // 0x028B5F20: B #0x28b5f44               |  goto label_16;                         
            goto label_16;
            label_15:
            // 0x028B5F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.neighbourDists, ????);
            // 0x028B5F28: LDR x2, [x27]              | X2 = public Pathfinding.RVO.Sampled.Agent System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::get_Item(int index);
            // 0x028B5F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B5F30: MOV w1, w21                | W1 = (val_4 - 2);//m1                   
            // 0x028B5F34: BL #0x25ed734              | X0 = 0.get_Item(index:  val_17);        
            Pathfinding.RVO.Sampled.Agent val_10 = 0.Item[val_17];
            // 0x028B5F38: MOV x24, x0                | X24 = val_10;//m1                       
            val_23 = val_10;
            // 0x028B5F3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            // 0x028B5F40: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_16:
            // 0x028B5F44: LDR x3, [x28]              | X3 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::set_Item(int index, Pathfinding.RVO.Sampled.Agent value);
            // 0x028B5F48: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028B5F4C: MOV w1, w22                | W1 = ((val_4 - 2) + 1);//m1             
            // 0x028B5F50: MOV x2, x24                | X2 = val_10;//m1                        
            // 0x028B5F54: BL #0x25ed7fc              | val_22.set_Item(index:  val_8, value:  val_23);
            val_22.set_Item(index:  val_8, value:  val_23);
            // 0x028B5F58: LDR x23, [x19, #0xf0]      | X23 = this.neighbourDists; //P2         
            val_20 = this.neighbourDists;
            // 0x028B5F5C: CBZ x23, #0x28b5f78        | if (this.neighbourDists == null) goto label_17;
            if(val_20 == null)
            {
                goto label_17;
            }
            // 0x028B5F60: LDR x2, [x26]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
            // 0x028B5F64: MOV x0, x23                | X0 = this.neighbourDists;//m1           
            // 0x028B5F68: MOV w1, w21                | W1 = (val_4 - 2);//m1                   
            // 0x028B5F6C: BL #0x25fad28              | X0 = this.neighbourDists.get_Item(index:  val_17);
            float val_11 = val_20.Item[val_17];
            // 0x028B5F70: MOV v10.16b, v0.16b        | V10 = val_11;//m1                       
            val_24 = val_11;
            // 0x028B5F74: B #0x28b5f94               |  goto label_18;                         
            goto label_18;
            label_17:
            // 0x028B5F78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028B5F7C: LDR x2, [x26]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
            // 0x028B5F80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B5F84: MOV w1, w21                | W1 = (val_4 - 2);//m1                   
            // 0x028B5F88: BL #0x25fad28              | X0 = 0.get_Item(index:  val_17);        
            float val_12 = 0.Item[val_17];
            // 0x028B5F8C: MOV v10.16b, v0.16b        | V10 = val_12;//m1                       
            val_24 = val_12;
            // 0x028B5F90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_18:
            // 0x028B5F94: LDR x2, [x25]              | X2 = public System.Void System.Collections.Generic.List<System.Single>::set_Item(int index, System.Single value);
            // 0x028B5F98: MOV x0, x23                | X0 = this.neighbourDists;//m1           
            // 0x028B5F9C: MOV w1, w22                | W1 = ((val_4 - 2) + 1);//m1             
            // 0x028B5FA0: MOV v0.16b, v10.16b        | V0 = val_12;//m1                        
            // 0x028B5FA4: BL #0x25fadf0              | this.neighbourDists.set_Item(index:  val_8, value:  val_24);
            val_20.set_Item(index:  val_8, value:  val_24);
            // 0x028B5FA8: SUB w21, w21, #1           | W21 = ((val_4 - 2) - 1);                
            val_17 = val_17 - 1;
            // 0x028B5FAC: CMN w21, #1                | STATE = COMPARE(((val_4 - 2) - 1), 0x1) 
            // 0x028B5FB0: B.NE #0x28b5edc            | if (val_17 != 1) goto label_19;         
            if(val_17 != 1)
            {
                goto label_19;
            }
            // 0x028B5FB4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x028B5FB8: B #0x28b5fc8               |  goto label_20;                         
            goto label_20;
            label_12:
            // 0x028B5FBC: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x028B5FC0: B #0x28b5fd0               |  goto label_21;                         
            goto label_21;
            label_14:
            // 0x028B5FC4: ADD w21, w21, #1           | W21 = ((val_4 - 2) + 1);                
            val_17 = val_17 + 1;
            label_20:
            // 0x028B5FC8: ADRP x24, #0x364d000       | X24 = 56938496 (0x364D000);             
            // 0x028B5FCC: LDR x24, [x24, #0x6d8]     | X24 = 1152921513250141744;              
            val_19 = 1152921513250141744;
            label_21:
            // 0x028B5FD0: LDR x22, [x19, #0xe8]      | X22 = this.neighbours; //P2             
            // 0x028B5FD4: CBNZ x22, #0x28b5fdc       | if (this.neighbours != null) goto label_22;
            if(this.neighbours != null)
            {
                goto label_22;
            }
            // 0x028B5FD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.neighbourDists, ????);
            label_22:
            // 0x028B5FDC: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x028B5FE0: LDR x8, [x8, #0xe00]       | X8 = 1152921513250161200;               
            // 0x028B5FE4: MOV x0, x22                | X0 = this.neighbours;//m1               
            // 0x028B5FE8: MOV w1, w21                | W1 = ((val_4 - 2) + 1);//m1             
            // 0x028B5FEC: MOV x2, x20                | X2 = agent;//m1                         
            // 0x028B5FF0: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::set_Item(int index, Pathfinding.RVO.Sampled.Agent value);
            // 0x028B5FF4: BL #0x25ed7fc              | this.neighbours.set_Item(index:  val_17, value:  agent);
            this.neighbours.set_Item(index:  val_17, value:  agent);
            // 0x028B5FF8: LDR x20, [x19, #0xf0]      | X20 = this.neighbourDists; //P2         
            // 0x028B5FFC: CBNZ x20, #0x28b6004       | if (this.neighbourDists != null) goto label_23;
            if(this.neighbourDists != null)
            {
                goto label_23;
            }
            // 0x028B6000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.neighbours, ????);
            label_23:
            // 0x028B6004: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x028B6008: LDR x8, [x8, #0xbf0]       | X8 = 1152921513250162224;               
            // 0x028B600C: MOV x0, x20                | X0 = this.neighbourDists;//m1           
            // 0x028B6010: MOV w1, w21                | W1 = ((val_4 - 2) + 1);//m1             
            // 0x028B6014: MOV v0.16b, v9.16b         | V0 = (((agent.position - this.position) * (agent.position - this.position)) + ((S2 - S3) * (S2 - S3)));//m1
            // 0x028B6018: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.Single>::set_Item(int index, System.Single value);
            // 0x028B601C: BL #0x25fadf0              | this.neighbourDists.set_Item(index:  val_17, value:  val_2);
            this.neighbourDists.set_Item(index:  val_17, value:  val_2);
            label_11:
            // 0x028B6020: LDR x20, [x19, #0xe8]      | X20 = this.neighbours; //P2             
            // 0x028B6024: CBNZ x20, #0x28b602c       | if (this.neighbours != null) goto label_24;
            if(this.neighbours != null)
            {
                goto label_24;
            }
            // 0x028B6028: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.neighbourDists, ????);
            label_24:
            // 0x028B602C: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::get_Count();
            // 0x028B6030: MOV x0, x20                | X0 = this.neighbours;//m1               
            // 0x028B6034: BL #0x25ed72c              | X0 = this.neighbours.get_Count();       
            int val_13 = this.neighbours.Count;
            // 0x028B6038: LDR w8, [x19, #0x5c]       | W8 = this.maxNeighbours; //P2           
            // 0x028B603C: CMP w0, w8                 | STATE = COMPARE(val_13, this.maxNeighbours)
            // 0x028B6040: B.NE #0x28b6068            | if (val_13 != this.maxNeighbours) goto label_25;
            if(val_13 != this.maxNeighbours)
            {
                goto label_25;
            }
            // 0x028B6044: LDR x19, [x19, #0xf0]      | X19 = this.neighbourDists; //P2         
            // 0x028B6048: CBZ x19, #0x28b6090        | if (this.neighbourDists == null) goto label_26;
            if(this.neighbourDists == null)
            {
                goto label_26;
            }
            // 0x028B604C: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x028B6050: LDR x8, [x8, #0xc20]       | X8 = 1152921510888744656;               
            // 0x028B6054: MOV x0, x19                | X0 = this.neighbourDists;//m1           
            // 0x028B6058: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.Single>::get_Count();
            // 0x028B605C: BL #0x25fad20              | X0 = this.neighbourDists.get_Count();   
            int val_14 = this.neighbourDists.Count;
            // 0x028B6060: MOV w20, w0                | W20 = val_14;//m1                       
            val_25 = val_14;
            // 0x028B6064: B #0x28b60b0               |  goto label_27;                         
            goto label_27;
            label_25:
            // 0x028B6068: MOV v0.16b, v8.16b         | V0 = rangeSq;//m1                       
            // 0x028B606C: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x028B6070: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x028B6074: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x028B6078: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x028B607C: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
            // 0x028B6080: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
            // 0x028B6084: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x028B6088: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
            // 0x028B608C: RET                        |  return (System.Single)rangeSq;         
            return (float)rangeSq;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
            label_26:
            // 0x028B6090: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            // 0x028B6094: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x028B6098: LDR x8, [x8, #0xc20]       | X8 = 1152921510888744656;               
            // 0x028B609C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B60A0: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.Single>::get_Count();
            // 0x028B60A4: BL #0x25fad20              | X0 = 0.get_Count();                     
            int val_15 = 0.Count;
            // 0x028B60A8: MOV w20, w0                | W20 = val_15;//m1                       
            val_25 = val_15;
            // 0x028B60AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_27:
            // 0x028B60B0: SUB w1, w20, #1            | W1 = (val_15 - 1);                      
            int val_16 = val_25 - 1;
            // 0x028B60B4: LDR x2, [x26]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
            // 0x028B60B8: MOV x0, x19                | X0 = this.neighbourDists;//m1           
            // 0x028B60BC: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x028B60C0: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x028B60C4: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x028B60C8: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x028B60CC: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
            // 0x028B60D0: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
            // 0x028B60D4: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x028B60D8: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
            // 0x028B60DC: B #0x25fad28               | return this.neighbourDists.get_Item(index:  int val_16 = val_25 - 1);
            return this.neighbourDists.Item[val_16];
        
        }
        //
        // Offset in libil2cpp.so: 0x028B841C (42697756), len: 724  VirtAddr: 0x028B841C RVA: 0x028B841C token: 100682485 methodIndex: 51097 delegateWrapperIndex: 0 methodInvoker: 0
        public void InsertObstacleNeighbour(Pathfinding.RVO.ObstacleVertex ob1, float rangeSq)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.RVO.ObstacleVertex val_9;
            //  | 
            var val_10;
            //  | 
            System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex> val_11;
            //  | 
            Pathfinding.RVO.ObstacleVertex val_12;
            //  | 
            float val_13;
            //  | 
            int val_14;
            // 0x028B841C: STP d11, d10, [sp, #-0x80]! | stack[1152921513250446864] = ???;  stack[1152921513250446872] = ???;  //  dest_result_addr=1152921513250446864 |  dest_result_addr=1152921513250446872
            // 0x028B8420: STP d9, d8, [sp, #0x10]    | stack[1152921513250446880] = ???;  stack[1152921513250446888] = ???;  //  dest_result_addr=1152921513250446880 |  dest_result_addr=1152921513250446888
            // 0x028B8424: STP x28, x27, [sp, #0x20]  | stack[1152921513250446896] = ???;  stack[1152921513250446904] = ???;  //  dest_result_addr=1152921513250446896 |  dest_result_addr=1152921513250446904
            // 0x028B8428: STP x26, x25, [sp, #0x30]  | stack[1152921513250446912] = ???;  stack[1152921513250446920] = ???;  //  dest_result_addr=1152921513250446912 |  dest_result_addr=1152921513250446920
            // 0x028B842C: STP x24, x23, [sp, #0x40]  | stack[1152921513250446928] = ???;  stack[1152921513250446936] = ???;  //  dest_result_addr=1152921513250446928 |  dest_result_addr=1152921513250446936
            // 0x028B8430: STP x22, x21, [sp, #0x50]  | stack[1152921513250446944] = ???;  stack[1152921513250446952] = ???;  //  dest_result_addr=1152921513250446944 |  dest_result_addr=1152921513250446952
            // 0x028B8434: STP x20, x19, [sp, #0x60]  | stack[1152921513250446960] = ???;  stack[1152921513250446968] = ???;  //  dest_result_addr=1152921513250446960 |  dest_result_addr=1152921513250446968
            // 0x028B8438: STP x29, x30, [sp, #0x70]  | stack[1152921513250446976] = ???;  stack[1152921513250446984] = ???;  //  dest_result_addr=1152921513250446976 |  dest_result_addr=1152921513250446984
            // 0x028B843C: ADD x29, sp, #0x70         | X29 = (1152921513250446864 + 112) = 1152921513250446976 (0x100000020332DE80);
            // 0x028B8440: SUB sp, sp, #0x10          | SP = (1152921513250446864 - 16) = 1152921513250446848 (0x100000020332DE00);
            // 0x028B8444: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028B8448: LDRB w8, [x21, #0x918]     | W8 = (bool)static_value_037B8918;       
            // 0x028B844C: MOV v9.16b, v0.16b         | V9 = rangeSq;//m1                       
            // 0x028B8450: MOV x20, x1                | X20 = ob1;//m1                          
            // 0x028B8454: MOV x19, x0                | X19 = 1152921513250458992 (0x1000000203330D70);//ML01
            // 0x028B8458: TBNZ w8, #0, #0x28b8474    | if (static_value_037B8918 == true) goto label_0;
            // 0x028B845C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x028B8460: LDR x8, [x8, #0xf10]       | X8 = 0x2B8AABC;                         
            // 0x028B8464: LDR w0, [x8]               | W0 = 0x16D;                             
            // 0x028B8468: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D, ????);      
            // 0x028B846C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B8470: STRB w8, [x21, #0x918]     | static_value_037B8918 = true;            //  dest_result_addr=58427672
            label_0:
            // 0x028B8474: CBZ x20, #0x28b8480        | if (ob1 == null) goto label_1;          
            if(ob1 == null)
            {
                goto label_1;
            }
            // 0x028B8478: LDR x21, [x20, #0x38]      | X21 = ob1.next; //P2                    
            val_9 = ob1.next;
            // 0x028B847C: B #0x28b8490               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028B8480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16D, ????);      
            // 0x028B8484: ORR w8, wzr, #0x38         | W8 = 56(0x38);                          
            // 0x028B8488: LDR x21, [x8]              | X21 = 0x19001A00400006;                 
            val_9 = 4194310;
            // 0x028B848C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16D, ????);      
            label_2:
            // 0x028B8490: LDP s8, s10, [x20, #0x14]  | S8 = ob1.position; //P2                  //  | 
            // 0x028B8494: LDR s11, [x20, #0x1c]      | 
            // 0x028B8498: CBNZ x21, #0x28b84a0       | if (0x19001A00400006 != 0) goto label_3;
            if(val_9 != 0)
            {
                goto label_3;
            }
            // 0x028B849C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16D, ????);      
            label_3:
            // 0x028B84A0: LDP s3, s4, [x21, #0x14]   | S3 = mem[7036986091110426]; S4 = mem[7036986091110430]; //  | 
            // 0x028B84A4: LDR s5, [x21, #0x1c]       | S5 = mem[7036986091110434];             
            // 0x028B84A8: LDP s0, s1, [x19, #0x1c]   | S0 = this.<Position>k__BackingField; //P2   //  | 
            // 0x028B84AC: LDR s2, [x19, #0x24]       | 
            // 0x028B84B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B84B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B84B8: STP s1, s2, [sp, #4]       | stack[1152921513250446852] = ???;  stack[1152921513250446856] = ???;  //  dest_result_addr=1152921513250446852 |  dest_result_addr=1152921513250446856
            // 0x028B84BC: STR s0, [sp]               | stack[1152921513250446848] = this.<Position>k__BackingField;  //  dest_result_addr=1152921513250446848
            // 0x028B84C0: MOV v0.16b, v8.16b         | V0 = ob1.position;//m1                  
            // 0x028B84C4: MOV v1.16b, v10.16b        | V1 = V10.16B;//m1                       
            // 0x028B84C8: MOV v2.16b, v11.16b        | V2 = V11.16B;//m1                       
            // 0x028B84CC: BL #0x1684130              | X0 = Pathfinding.AstarMath.DistancePointSegmentStrict(a:  new UnityEngine.Vector3() {x = ob1.position, y = V10.16B, z = V11.16B}, b:  new UnityEngine.Vector3() {x = mem[7036986091110426], y = mem[7036986091110430], z = mem[7036986091110434]}, p:  new UnityEngine.Vector3() {x = this.<Position>k__BackingField, y = ???, z = ???});
            float val_1 = Pathfinding.AstarMath.DistancePointSegmentStrict(a:  new UnityEngine.Vector3() {x = ob1.position, y = V10.16B, z = V11.16B}, b:  new UnityEngine.Vector3() {x = mem[7036986091110426], y = mem[7036986091110430], z = mem[7036986091110434]}, p:  new UnityEngine.Vector3() {x = this.<Position>k__BackingField, y = ???, z = ???});
            // 0x028B84D0: MOV v8.16b, v0.16b         | V8 = val_1;//m1                         
            // 0x028B84D4: FCMP s8, s9                | STATE = COMPARE(val_1, rangeSq)         
            // 0x028B84D8: B.PL #0x28b8650            | if (val_1 >= 0) goto label_4;           
            if(val_1 >= 0)
            {
                goto label_4;
            }
            // 0x028B84DC: LDR x21, [x19, #0x100]     | X21 = this.obstacles; //P2              
            // 0x028B84E0: CBNZ x21, #0x28b84e8       | if (this.obstacles != null) goto label_5;
            if(this.obstacles != null)
            {
                goto label_5;
            }
            // 0x028B84E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_5:
            // 0x028B84E8: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x028B84EC: LDR x8, [x8, #0xa40]       | X8 = 1152921513250394032;               
            // 0x028B84F0: MOV x0, x21                | X0 = this.obstacles;//m1                
            // 0x028B84F4: MOV x1, x20                | X1 = ob1;//m1                           
            // 0x028B84F8: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::Add(Pathfinding.RVO.ObstacleVertex item);
            // 0x028B84FC: BL #0x25ea480              | this.obstacles.Add(item:  ob1);         
            this.obstacles.Add(item:  ob1);
            // 0x028B8500: LDR x21, [x19, #0x108]     | X21 = this.obstacleDists; //P2          
            // 0x028B8504: CBNZ x21, #0x28b850c       | if (this.obstacleDists != null) goto label_6;
            if(this.obstacleDists != null)
            {
                goto label_6;
            }
            // 0x028B8508: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.obstacles, ????);
            label_6:
            // 0x028B850C: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x028B8510: LDR x8, [x8, #0xe38]       | X8 = 1152921510888403920;               
            // 0x028B8514: MOV x0, x21                | X0 = this.obstacleDists;//m1            
            // 0x028B8518: MOV v0.16b, v8.16b         | V0 = val_1;//m1                         
            // 0x028B851C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Single>::Add(System.Single item);
            // 0x028B8520: BL #0x25f7a38              | this.obstacleDists.Add(item:  val_1);   
            this.obstacleDists.Add(item:  val_1);
            // 0x028B8524: LDR x21, [x19, #0x100]     | X21 = this.obstacles; //P2              
            System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex> val_9 = this.obstacles;
            // 0x028B8528: CBNZ x21, #0x28b8530       | if (this.obstacles != null) goto label_7;
            if(val_9 != null)
            {
                goto label_7;
            }
            // 0x028B852C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.obstacleDists, ????);
            label_7:
            // 0x028B8530: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x028B8534: LDR x8, [x8, #0xda0]       | X8 = 1152921513250403248;               
            // 0x028B8538: MOV x0, x21                | X0 = this.obstacles;//m1                
            // 0x028B853C: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::get_Count();
            // 0x028B8540: BL #0x25ed72c              | X0 = this.obstacles.get_Count();        
            int val_2 = val_9.Count;
            // 0x028B8544: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
            // 0x028B8548: B.EQ #0x28b8648            | if (val_2 == 1) goto label_8;           
            if(val_2 == 1)
            {
                goto label_8;
            }
            // 0x028B854C: ADRP x25, #0x35e2000       | X25 = 56500224 (0x35E2000);             
            // 0x028B8550: ADRP x26, #0x35f8000       | X26 = 56590336 (0x35F8000);             
            // 0x028B8554: ADRP x27, #0x3672000       | X27 = 57090048 (0x3672000);             
            // 0x028B8558: ADRP x28, #0x3639000       | X28 = 56856576 (0x3639000);             
            // 0x028B855C: LDR x25, [x25, #0xbb0]     | X25 = 1152921510888574288;              
            // 0x028B8560: LDR x26, [x26, #0xc28]     | X26 = 1152921513250404272;              
            // 0x028B8564: LDR x27, [x27, #0x4c8]     | X27 = 1152921513250405296;              
            // 0x028B8568: LDR x28, [x28, #0xbf0]     | X28 = 1152921513250162224;              
            // 0x028B856C: SUB w21, w0, #2            | W21 = (val_2 - 2);                      
            val_9 = val_2 - 2;
            label_15:
            // 0x028B8570: LDR x22, [x19, #0x108]     | X22 = this.obstacleDists; //P2          
            // 0x028B8574: CBNZ x22, #0x28b857c       | if (this.obstacleDists != null) goto label_9;
            if(this.obstacleDists != null)
            {
                goto label_9;
            }
            // 0x028B8578: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_9:
            // 0x028B857C: LDR x2, [x25]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
            // 0x028B8580: MOV x0, x22                | X0 = this.obstacleDists;//m1            
            // 0x028B8584: MOV w1, w21                | W1 = (val_2 - 2);//m1                   
            // 0x028B8588: BL #0x25fad28              | X0 = this.obstacleDists.get_Item(index:  this.obstacles);
            float val_3 = this.obstacleDists.Item[val_9];
            // 0x028B858C: FCMP s8, s0                | STATE = COMPARE(val_1, val_3)           
            // 0x028B8590: B.PL #0x28b8678            | if (val_1 >= 0) goto label_10;          
            if(val_1 >= 0)
            {
                goto label_10;
            }
            // 0x028B8594: LDR x23, [x19, #0x100]     | X23 = this.obstacles; //P2              
            val_11 = this.obstacles;
            // 0x028B8598: ADD w22, w21, #1           | W22 = ((val_2 - 2) + 1);                
            int val_4 = val_9 + 1;
            // 0x028B859C: CBZ x23, #0x28b85b8        | if (this.obstacles == null) goto label_11;
            if(val_11 == null)
            {
                goto label_11;
            }
            // 0x028B85A0: LDR x2, [x26]              | X2 = public Pathfinding.RVO.ObstacleVertex System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::get_Item(int index);
            // 0x028B85A4: MOV x0, x23                | X0 = this.obstacles;//m1                
            // 0x028B85A8: MOV w1, w21                | W1 = (val_2 - 2);//m1                   
            // 0x028B85AC: BL #0x25ed734              | X0 = this.obstacles.get_Item(index:  this.obstacles);
            Pathfinding.RVO.ObstacleVertex val_5 = val_11.Item[val_9];
            // 0x028B85B0: MOV x24, x0                | X24 = val_5;//m1                        
            val_12 = val_5;
            // 0x028B85B4: B #0x28b85d8               |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x028B85B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.obstacleDists, ????);
            // 0x028B85BC: LDR x2, [x26]              | X2 = public Pathfinding.RVO.ObstacleVertex System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::get_Item(int index);
            // 0x028B85C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B85C4: MOV w1, w21                | W1 = (val_2 - 2);//m1                   
            // 0x028B85C8: BL #0x25ed734              | X0 = 0.get_Item(index:  this.obstacles);
            Pathfinding.RVO.ObstacleVertex val_6 = 0.Item[val_9];
            // 0x028B85CC: MOV x24, x0                | X24 = val_6;//m1                        
            val_12 = val_6;
            // 0x028B85D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x028B85D4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_12:
            // 0x028B85D8: LDR x3, [x27]              | X3 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::set_Item(int index, Pathfinding.RVO.ObstacleVertex value);
            // 0x028B85DC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028B85E0: MOV w1, w22                | W1 = ((val_2 - 2) + 1);//m1             
            // 0x028B85E4: MOV x2, x24                | X2 = val_6;//m1                         
            // 0x028B85E8: BL #0x25ed7fc              | val_11.set_Item(index:  val_4, value:  val_12);
            val_11.set_Item(index:  val_4, value:  val_12);
            // 0x028B85EC: LDR x23, [x19, #0x108]     | X23 = this.obstacleDists; //P2          
            // 0x028B85F0: CBZ x23, #0x28b860c        | if (this.obstacleDists == null) goto label_13;
            if(this.obstacleDists == null)
            {
                goto label_13;
            }
            // 0x028B85F4: LDR x2, [x25]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
            // 0x028B85F8: MOV x0, x23                | X0 = this.obstacleDists;//m1            
            // 0x028B85FC: MOV w1, w21                | W1 = (val_2 - 2);//m1                   
            // 0x028B8600: BL #0x25fad28              | X0 = this.obstacleDists.get_Item(index:  this.obstacles);
            float val_7 = this.obstacleDists.Item[val_9];
            // 0x028B8604: MOV v9.16b, v0.16b         | V9 = val_7;//m1                         
            val_13 = val_7;
            // 0x028B8608: B #0x28b8628               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028B860C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028B8610: LDR x2, [x25]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
            // 0x028B8614: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8618: MOV w1, w21                | W1 = (val_2 - 2);//m1                   
            // 0x028B861C: BL #0x25fad28              | X0 = 0.get_Item(index:  this.obstacles);
            float val_8 = 0.Item[val_9];
            // 0x028B8620: MOV v9.16b, v0.16b         | V9 = val_8;//m1                         
            val_13 = val_8;
            // 0x028B8624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_14:
            // 0x028B8628: LDR x2, [x28]              | X2 = public System.Void System.Collections.Generic.List<System.Single>::set_Item(int index, System.Single value);
            // 0x028B862C: MOV x0, x23                | X0 = this.obstacleDists;//m1            
            // 0x028B8630: MOV w1, w22                | W1 = ((val_2 - 2) + 1);//m1             
            // 0x028B8634: MOV v0.16b, v9.16b         | V0 = val_8;//m1                         
            // 0x028B8638: BL #0x25fadf0              | this.obstacleDists.set_Item(index:  val_4, value:  val_13);
            this.obstacleDists.set_Item(index:  val_4, value:  val_13);
            // 0x028B863C: SUB w21, w21, #1           | W21 = ((val_2 - 2) - 1);                
            val_9 = val_9 - 1;
            // 0x028B8640: CMN w21, #1                | STATE = COMPARE(((val_2 - 2) - 1), 0x1) 
            // 0x028B8644: B.NE #0x28b8570            | if (this.obstacles != 1) goto label_15; 
            if(val_9 != 1)
            {
                goto label_15;
            }
            label_8:
            // 0x028B8648: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x028B864C: B #0x28b867c               |  goto label_16;                         
            goto label_16;
            label_4:
            // 0x028B8650: SUB sp, x29, #0x70         | SP = (1152921513250446976 - 112) = 1152921513250446864 (0x100000020332DE10);
            // 0x028B8654: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x028B8658: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x028B865C: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x028B8660: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x028B8664: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
            // 0x028B8668: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
            // 0x028B866C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x028B8670: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
            // 0x028B8674: RET                        |  return;                                
            return;
            label_10:
            // 0x028B8678: ADD w21, w21, #1           | W21 = ((val_2 - 2) + 1);                
            val_14 = val_9 + 1;
            label_16:
            // 0x028B867C: LDR x22, [x19, #0x100]     | X22 = this.obstacles; //P2              
            // 0x028B8680: CBNZ x22, #0x28b8688       | if (this.obstacles != null) goto label_17;
            if(this.obstacles != null)
            {
                goto label_17;
            }
            // 0x028B8684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.obstacleDists, ????);
            label_17:
            // 0x028B8688: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x028B868C: LDR x8, [x8, #0x4c8]       | X8 = 1152921513250405296;               
            // 0x028B8690: MOV x0, x22                | X0 = this.obstacles;//m1                
            // 0x028B8694: MOV w1, w21                | W1 = ((val_2 - 2) + 1);//m1             
            // 0x028B8698: MOV x2, x20                | X2 = ob1;//m1                           
            // 0x028B869C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::set_Item(int index, Pathfinding.RVO.ObstacleVertex value);
            // 0x028B86A0: BL #0x25ed7fc              | this.obstacles.set_Item(index:  val_14, value:  ob1);
            this.obstacles.set_Item(index:  val_14, value:  ob1);
            // 0x028B86A4: LDR x19, [x19, #0x108]     | X19 = this.obstacleDists; //P2          
            // 0x028B86A8: CBNZ x19, #0x28b86b0       | if (this.obstacleDists != null) goto label_18;
            if(this.obstacleDists != null)
            {
                goto label_18;
            }
            // 0x028B86AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.obstacles, ????);
            label_18:
            // 0x028B86B0: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x028B86B4: LDR x8, [x8, #0xbf0]       | X8 = 1152921513250162224;               
            // 0x028B86B8: MOV x0, x19                | X0 = this.obstacleDists;//m1            
            // 0x028B86BC: MOV w1, w21                | W1 = ((val_2 - 2) + 1);//m1             
            // 0x028B86C0: MOV v0.16b, v8.16b         | V0 = val_1;//m1                         
            // 0x028B86C4: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.Single>::set_Item(int index, System.Single value);
            // 0x028B86C8: SUB sp, x29, #0x70         | SP = (1152921513250446976 - 112) = 1152921513250446864 (0x100000020332DE10);
            // 0x028B86CC: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x028B86D0: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x028B86D4: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x028B86D8: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x028B86DC: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
            // 0x028B86E0: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
            // 0x028B86E4: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x028B86E8: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
            // 0x028B86EC: B #0x25fadf0               | this.obstacleDists.set_Item(index:  val_14, value:  val_1); return;
            this.obstacleDists.set_Item(index:  val_14, value:  val_1);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B86F0 (42698480), len: 60  VirtAddr: 0x028B86F0 RVA: 0x028B86F0 token: 100682486 methodIndex: 51098 delegateWrapperIndex: 0 methodInvoker: 0
        private static UnityEngine.Vector3 To3D(UnityEngine.Vector2 p)
        {
            //
            // Disasemble & Code
            // 0x028B86F0: STP x29, x30, [sp, #-0x10]! | stack[1152921513250608128] = ???;  stack[1152921513250608136] = ???;  //  dest_result_addr=1152921513250608128 |  dest_result_addr=1152921513250608136
            // 0x028B86F4: MOV x29, sp                | X29 = 1152921513250608128 (0x1000000203355400);//ML01
            // 0x028B86F8: SUB sp, sp, #0x10          | SP = (1152921513250608128 - 16) = 1152921513250608112 (0x10000002033553F0);
            // 0x028B86FC: MOV v2.16b, v1.16b         | V2 = p.y;//m1                           
            // 0x028B8700: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8704: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028B8708: MOV x0, sp                 | X0 = 1152921513250608112 (0x10000002033553F0);//ML01
            // 0x028B870C: STR wzr, [sp, #8]          | stack[1152921513250608120] = 0x0;        //  dest_result_addr=1152921513250608120
            // 0x028B8710: STR xzr, [sp]              | stack[1152921513250608112] = 0x0;        //  dest_result_addr=1152921513250608112
            // 0x028B8714: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B8718: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
            // 0x028B871C: LDR s2, [sp, #8]           | S2 = 0;                                 
            // 0x028B8720: MOV sp, x29                | SP = 1152921513250608128 (0x1000000203355400);//ML01
            // 0x028B8724: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x028B8728: RET                        |  return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
            return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
            //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028B872C (42698540), len: 200  VirtAddr: 0x028B872C RVA: 0x028B872C token: 100682487 methodIndex: 51099 delegateWrapperIndex: 0 methodInvoker: 0
        private static void DrawCircle(UnityEngine.Vector2 _p, float radius, UnityEngine.Color col)
        {
            //
            // Disasemble & Code
            // 0x028B872C: STP d15, d14, [sp, #-0x60]! | stack[1152921513250720048] = ???;  stack[1152921513250720056] = ???;  //  dest_result_addr=1152921513250720048 |  dest_result_addr=1152921513250720056
            // 0x028B8730: STP d13, d12, [sp, #0x10]  | stack[1152921513250720064] = ???;  stack[1152921513250720072] = ???;  //  dest_result_addr=1152921513250720064 |  dest_result_addr=1152921513250720072
            // 0x028B8734: STP d11, d10, [sp, #0x20]  | stack[1152921513250720080] = ???;  stack[1152921513250720088] = ???;  //  dest_result_addr=1152921513250720080 |  dest_result_addr=1152921513250720088
            // 0x028B8738: STP d9, d8, [sp, #0x30]    | stack[1152921513250720096] = ???;  stack[1152921513250720104] = ???;  //  dest_result_addr=1152921513250720096 |  dest_result_addr=1152921513250720104
            // 0x028B873C: STP x20, x19, [sp, #0x40]  | stack[1152921513250720112] = ???;  stack[1152921513250720120] = ???;  //  dest_result_addr=1152921513250720112 |  dest_result_addr=1152921513250720120
            // 0x028B8740: STP x29, x30, [sp, #0x50]  | stack[1152921513250720128] = ???;  stack[1152921513250720136] = ???;  //  dest_result_addr=1152921513250720128 |  dest_result_addr=1152921513250720136
            // 0x028B8744: ADD x29, sp, #0x50         | X29 = (1152921513250720048 + 80) = 1152921513250720128 (0x1000000203370980);
            // 0x028B8748: SUB sp, sp, #0x10          | SP = (1152921513250720048 - 16) = 1152921513250720032 (0x1000000203370920);
            // 0x028B874C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028B8750: LDRB w8, [x19, #0x919]     | W8 = (bool)static_value_037B8919;       
            // 0x028B8754: MOV v8.16b, v6.16b         | V8 = col.a;//m1                         
            // 0x028B8758: MOV v9.16b, v5.16b         | V9 = col.b;//m1                         
            // 0x028B875C: MOV v14.16b, v4.16b        | V14 = col.g;//m1                        
            // 0x028B8760: MOV v13.16b, v3.16b        | V13 = col.r;//m1                        
            // 0x028B8764: MOV v10.16b, v2.16b        | V10 = radius;//m1                       
            // 0x028B8768: MOV v11.16b, v1.16b        | V11 = _p.y;//m1                         
            // 0x028B876C: MOV v12.16b, v0.16b        | V12 = _p.x;//m1                         
            // 0x028B8770: TBNZ w8, #0, #0x28b878c    | if (static_value_037B8919 == true) goto label_0;
            // 0x028B8774: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x028B8778: LDR x8, [x8, #0xb18]       | X8 = 0x2B8AAA8;                         
            // 0x028B877C: LDR w0, [x8]               | W0 = 0x168;                             
            // 0x028B8780: BL #0x2782188              | X0 = sub_2782188( ?? 0x168, ????);      
            // 0x028B8784: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B8788: STRB w8, [x19, #0x919]     | static_value_037B8919 = true;            //  dest_result_addr=58427673
            label_0:
            // 0x028B878C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028B8790: LDR x8, [x8, #0x470]       | X8 = 1152921504840765440;               
            // 0x028B8794: LDR x0, [x8]               | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028B8798: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028B879C: TBZ w8, #0, #0x28b87ac     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028B87A0: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028B87A4: CBNZ w8, #0x28b87ac        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028B87A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_2:
            // 0x028B87AC: ADRP x8, #0x2a96000        | X8 = 44654592 (0x2A96000);              
            // 0x028B87B0: LDR s4, [x8, #0xd50]       | S4 = 6.283185;                          
            // 0x028B87B4: FMOV s3, wzr               | S3 = 0f;                                
            // 0x028B87B8: MOV v0.16b, v12.16b        | V0 = _p.x;//m1                          
            // 0x028B87BC: MOV v1.16b, v11.16b        | V1 = _p.y;//m1                          
            // 0x028B87C0: MOV v2.16b, v10.16b        | V2 = radius;//m1                        
            // 0x028B87C4: STR s14, [sp, #4]          | stack[1152921513250720036] = col.g;      //  dest_result_addr=1152921513250720036
            // 0x028B87C8: STR s13, [sp]              | stack[1152921513250720032] = col.r;      //  dest_result_addr=1152921513250720032
            // 0x028B87CC: STP s9, s8, [sp, #8]       | stack[1152921513250720040] = col.b;  stack[1152921513250720044] = col.a;  //  dest_result_addr=1152921513250720040 |  dest_result_addr=1152921513250720044
            // 0x028B87D0: BL #0x28b87f4              | Pathfinding.RVO.Sampled.Agent.DrawCircle(_p:  new UnityEngine.Vector2() {x = _p.x, y = _p.y}, radius:  radius, a0:  0f, a1:  6.283185f, col:  new UnityEngine.Color() {r = col.r, g = col.b, b = ???, a = ???});
            Pathfinding.RVO.Sampled.Agent.DrawCircle(_p:  new UnityEngine.Vector2() {x = _p.x, y = _p.y}, radius:  radius, a0:  0f, a1:  6.283185f, col:  new UnityEngine.Color() {r = col.r, g = col.b, b = ???, a = ???});
            // 0x028B87D4: SUB sp, x29, #0x50         | SP = (1152921513250720128 - 80) = 1152921513250720048 (0x1000000203370930);
            // 0x028B87D8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028B87DC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028B87E0: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x028B87E4: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x028B87E8: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x028B87EC: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x028B87F0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B87F4 (42698740), len: 792  VirtAddr: 0x028B87F4 RVA: 0x028B87F4 token: 100682488 methodIndex: 51100 delegateWrapperIndex: 0 methodInvoker: 0
        private static void DrawCircle(UnityEngine.Vector2 _p, float radius, float a0, float a1, UnityEngine.Color col)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            //  | 
            float val_10;
            // 0x028B87F4: STP d15, d14, [sp, #-0x70]! | stack[1152921513250832032] = ???;  stack[1152921513250832040] = ???;  //  dest_result_addr=1152921513250832032 |  dest_result_addr=1152921513250832040
            // 0x028B87F8: STP d13, d12, [sp, #0x10]  | stack[1152921513250832048] = ???;  stack[1152921513250832056] = ???;  //  dest_result_addr=1152921513250832048 |  dest_result_addr=1152921513250832056
            // 0x028B87FC: STP d11, d10, [sp, #0x20]  | stack[1152921513250832064] = ???;  stack[1152921513250832072] = ???;  //  dest_result_addr=1152921513250832064 |  dest_result_addr=1152921513250832072
            // 0x028B8800: STP d9, d8, [sp, #0x30]    | stack[1152921513250832080] = ???;  stack[1152921513250832088] = ???;  //  dest_result_addr=1152921513250832080 |  dest_result_addr=1152921513250832088
            // 0x028B8804: STP x22, x21, [sp, #0x40]  | stack[1152921513250832096] = ???;  stack[1152921513250832104] = ???;  //  dest_result_addr=1152921513250832096 |  dest_result_addr=1152921513250832104
            // 0x028B8808: STP x20, x19, [sp, #0x50]  | stack[1152921513250832112] = ???;  stack[1152921513250832120] = ???;  //  dest_result_addr=1152921513250832112 |  dest_result_addr=1152921513250832120
            // 0x028B880C: STP x29, x30, [sp, #0x60]  | stack[1152921513250832128] = ???;  stack[1152921513250832136] = ???;  //  dest_result_addr=1152921513250832128 |  dest_result_addr=1152921513250832136
            // 0x028B8810: ADD x29, sp, #0x60         | X29 = (1152921513250832032 + 96) = 1152921513250832128 (0x100000020338BF00);
            // 0x028B8814: SUB sp, sp, #0x70          | SP = (1152921513250832032 - 112) = 1152921513250831920 (0x100000020338BE30);
            // 0x028B8818: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028B881C: LDRB w8, [x19, #0x91a]     | W8 = (bool)static_value_037B891A;       
            // 0x028B8820: MOV v14.16b, v4.16b        | V14 = a1;//m1                           
            // 0x028B8824: MOV v15.16b, v3.16b        | V15 = a0;//m1                           
            val_10 = a0;
            // 0x028B8828: MOV v8.16b, v2.16b         | V8 = radius;//m1                        
            // 0x028B882C: MOV v11.16b, v1.16b        | V11 = _p.y;//m1                         
            // 0x028B8830: MOV v12.16b, v0.16b        | V12 = _p.x;//m1                         
            // 0x028B8834: STR s14, [sp, #0x3c]       | stack[1152921513250831980] = a1;         //  dest_result_addr=1152921513250831980
            // 0x028B8838: TBNZ w8, #0, #0x28b8854    | if (static_value_037B891A == true) goto label_0;
            // 0x028B883C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x028B8840: LDR x8, [x8, #0x858]       | X8 = 0x2B8AAA4;                         
            // 0x028B8844: LDR w0, [x8]               | W0 = 0x167;                             
            // 0x028B8848: BL #0x2782188              | X0 = sub_2782188( ?? 0x167, ????);      
            // 0x028B884C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B8850: STRB w8, [x19, #0x91a]     | static_value_037B891A = true;            //  dest_result_addr=58427674
            label_0:
            // 0x028B8854: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028B8858: STR wzr, [sp, #0x58]       | stack[1152921513250832008] = 0x0;        //  dest_result_addr=1152921513250832008
            // 0x028B885C: LDR x8, [x8, #0x470]       | X8 = 1152921504840765440;               
            // 0x028B8860: STR xzr, [sp, #0x50]       | stack[1152921513250832000] = 0x0;        //  dest_result_addr=1152921513250832000
            // 0x028B8864: STR wzr, [sp, #0x48]       | stack[1152921513250831992] = 0x0;        //  dest_result_addr=1152921513250831992
            // 0x028B8868: LDR x0, [x8]               | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028B886C: STR xzr, [sp, #0x40]       | stack[1152921513250831984] = 0x0;        //  dest_result_addr=1152921513250831984
            // 0x028B8870: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028B8874: TBZ w8, #0, #0x28b8884     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028B8878: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028B887C: CBNZ w8, #0x28b8884        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028B8880: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_2:
            // 0x028B8884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8888: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028B888C: ADD x0, sp, #0x60          | X0 = (1152921513250831920 + 96) = 1152921513250832016 (0x100000020338BE90);
            // 0x028B8890: MOV v0.16b, v12.16b        | V0 = _p.x;//m1                          
            // 0x028B8894: MOV v2.16b, v11.16b        | V2 = _p.y;//m1                          
            // 0x028B8898: STR wzr, [sp, #0x68]       | stack[1152921513250832024] = 0x0;        //  dest_result_addr=1152921513250832024
            // 0x028B889C: STR xzr, [sp, #0x60]       | stack[1152921513250832016] = 0x0;        //  dest_result_addr=1152921513250832016
            // 0x028B88A0: MOV v12.16b, v1.16b        | V12 = 0;//m1                            
            // 0x028B88A4: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B88A8: LDR s0, [sp, #0x60]        | S0 = 0;                                 
            // 0x028B88AC: FCMP s15, s14              | STATE = COMPARE(a0, a1)                 
            // 0x028B88B0: STR s0, [sp, #0x38]        | stack[1152921513250831976] = 0x0;        //  dest_result_addr=1152921513250831976
            // 0x028B88B4: LDP s0, s9, [sp, #0x64]    | S0 = 0; S9 = 0;                          //  | 
            // 0x028B88B8: STR s0, [sp, #0x34]        | stack[1152921513250831972] = 0x0;        //  dest_result_addr=1152921513250831972
            // 0x028B88BC: B.LE #0x28b88d4            | if (val_10 <= a1) goto label_3;         
            if(val_10 <= a1)
            {
                goto label_3;
            }
            // 0x028B88C0: ADRP x8, #0x2bc3000        | X8 = 45887488 (0x2BC3000);              
            // 0x028B88C4: LDR s0, [x8, #0x2f0]       | S0 = -6.283185;                         
            label_4:
            // 0x028B88C8: FADD s15, s15, s0          | S15 = (a0 + -6.283185f);                
            val_10 = val_10 + (-6.283185f);
            // 0x028B88CC: FCMP s15, s14              | STATE = COMPARE((a0 + -6.283185f), a1)  
            // 0x028B88D0: B.GT #0x28b88c8            | if (val_10 > a1) goto label_4;          
            if(val_10 > a1)
            {
                goto label_4;
            }
            label_3:
            // 0x028B88D4: ADRP x19, #0x363f000       | X19 = 56881152 (0x363F000);             
            // 0x028B88D8: STR s15, [sp, #0x30]       | stack[1152921513250831968] = (a0 + -6.283185f);  //  dest_result_addr=1152921513250831968
            // 0x028B88DC: LDR x19, [x19, #0x3b0]     | X19 = 1152921504695345152;              
            // 0x028B88E0: LDR x0, [x19]              | X0 = typeof(UnityEngine.Mathf);         
            // 0x028B88E4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028B88E8: TBZ w8, #0, #0x28b88f8     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x028B88EC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028B88F0: CBNZ w8, #0x28b88f8        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x028B88F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_6:
            // 0x028B88F8: LDR s0, [x29, #0x1c]       | S0 = val_1;                              //  find_add[1152921513250820144]
            // 0x028B88FC: STR s0, [sp, #0x2c]        | stack[1152921513250831964] = val_1;      //  dest_result_addr=1152921513250831964
            // 0x028B8900: LDR s0, [x29, #0x18]       | S0 = col.g;                             
            // 0x028B8904: STR s0, [sp, #0x28]        | stack[1152921513250831960] = col.g;      //  dest_result_addr=1152921513250831960
            // 0x028B8908: LDR s0, [x29, #0x14]       | S0 = val_2;                              //  find_add[1152921513250820144]
            // 0x028B890C: STR s0, [sp, #0x24]        | stack[1152921513250831956] = val_2;      //  dest_result_addr=1152921513250831956
            // 0x028B8910: LDR s0, [x29, #0x10]       | S0 = col.r;                             
            // 0x028B8914: STR s0, [sp, #0x20]        | stack[1152921513250831952] = col.r;      //  dest_result_addr=1152921513250831952
            // 0x028B8918: MOV v0.16b, v15.16b        | V0 = (a0 + -6.283185f);//m1             
            // 0x028B891C: BL #0x981480               | X0 = sub_981480( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028B8920: MOV v10.16b, v0.16b        | V10 = (a0 + -6.283185f);//m1            
            // 0x028B8924: MOV v0.16b, v15.16b        | V0 = (a0 + -6.283185f);//m1             
            // 0x028B8928: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028B892C: FMUL s1, s10, s8           | S1 = ((a0 + -6.283185f) * radius);      
            float val_3 = val_10 * radius;
            // 0x028B8930: MOV v10.16b, v12.16b       | V10 = 0;//m1                            
            float val_10 = 0f;
            // 0x028B8934: FMUL s2, s0, s8            | S2 = ((a0 + -6.283185f) * radius);      
            float val_4 = val_10 * radius;
            // 0x028B8938: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B893C: ADD x0, sp, #0x50          | X0 = (1152921513250831920 + 80) = 1152921513250832000 (0x100000020338BE80);
            // 0x028B8940: MOV v0.16b, v1.16b         | V0 = ((a0 + -6.283185f) * radius);//m1  
            // 0x028B8944: MOV v1.16b, v10.16b        | V1 = 0;//m1                             
            // 0x028B8948: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B894C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028B8950: LDR s0, [x8, #0x79c]       | S0 = 40;                                
            // 0x028B8954: ADRP x21, #0x3673000       | X21 = 57094144 (0x3673000);             
            // 0x028B8958: ADRP x22, #0x35f8000       | X22 = 56590336 (0x35F8000);             
            // 0x028B895C: ORR w20, wzr, #1           | W20 = 1(0x1);                           
            var val_12 = 1;
            // 0x028B8960: STR s0, [sp, #0x1c]        | stack[1152921513250831948] = 0x42200000;  //  dest_result_addr=1152921513250831948
            // 0x028B8964: LDR x21, [x21, #0x488]     | X21 = 1152921504695078912;              
            // 0x028B8968: LDR x22, [x22, #0x130]     | X22 = 1152921504692469760;              
            label_13:
            // 0x028B896C: LDR x0, [x19]              | X0 = typeof(UnityEngine.Mathf);         
            // 0x028B8970: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028B8974: TBZ w8, #0, #0x28b8984     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x028B8978: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028B897C: CBNZ w8, #0x28b8984        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x028B8980: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_8:
            // 0x028B8984: LDR s0, [sp, #0x1c]        | S0 = 40;                                
            // 0x028B8988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B898C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8990: MOV v1.16b, v14.16b        | V1 = a1;//m1                            
            // 0x028B8994: FDIV s10, s10, s0          | S10 = (0f / 40f);                       
            val_10 = val_10 / 40f;
            // 0x028B8998: MOV v0.16b, v15.16b        | V0 = (a0 + -6.283185f);//m1             
            // 0x028B899C: MOV v2.16b, v10.16b        | V2 = (0f / 40f);//m1                    
            // 0x028B89A0: BL #0x1a7dd1c              | X0 = UnityEngine.Mathf.Lerp(a:  val_10, b:  a1, t:  0f);
            float val_5 = UnityEngine.Mathf.Lerp(a:  val_10, b:  a1, t:  val_10);
            // 0x028B89A4: BL #0x981480               | X0 = sub_981480( ?? 0x0, ????);         
            // 0x028B89A8: MOV v11.16b, v0.16b        | V11 = val_5;//m1                        
            // 0x028B89AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B89B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B89B4: MOV v0.16b, v15.16b        | V0 = (a0 + -6.283185f);//m1             
            // 0x028B89B8: MOV v1.16b, v14.16b        | V1 = a1;//m1                            
            // 0x028B89BC: MOV v2.16b, v10.16b        | V2 = (0f / 40f);//m1                    
            float val_11 = val_10;
            // 0x028B89C0: BL #0x1a7dd1c              | X0 = UnityEngine.Mathf.Lerp(a:  val_10, b:  a1, t:  0f);
            float val_6 = UnityEngine.Mathf.Lerp(a:  val_10, b:  a1, t:  val_11);
            // 0x028B89C4: BL #0x9811b0               | X0 = sub_9811B0( ?? 0x0, ????);         
            // 0x028B89C8: FMUL s1, s11, s8           | S1 = (val_5 * radius);                  
            float val_7 = val_5 * radius;
            // 0x028B89CC: FMUL s2, s0, s8            | S2 = (val_6 * radius);                  
            val_11 = val_6 * radius;
            // 0x028B89D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B89D4: ADD x0, sp, #0x40          | X0 = (1152921513250831920 + 64) = 1152921513250831984 (0x100000020338BE70);
            // 0x028B89D8: MOV v0.16b, v1.16b         | V0 = (val_5 * radius);//m1              
            // 0x028B89DC: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028B89E0: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B89E4: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x028B89E8: LDP s12, s11, [sp, #0x50]  | S12 = 0; S11 = 0;                        //  | 
            // 0x028B89EC: LDR s10, [sp, #0x58]       | S10 = 0;                                
            // 0x028B89F0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x028B89F4: TBZ w8, #0, #0x28b8a04     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x028B89F8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x028B89FC: CBNZ w8, #0x28b8a04        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x028B8A00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_10:
            // 0x028B8A04: LDP s14, s13, [sp, #0x34]  | S14 = 0; S13 = 0;                        //  | 
            // 0x028B8A08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8A0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8A10: MOV v2.16b, v9.16b         | V2 = 0 (0x0);//ML01                     
            // 0x028B8A14: MOV v0.16b, v13.16b        | V0 = 0 (0x0);//ML01                     
            // 0x028B8A18: MOV v1.16b, v14.16b        | V1 = 0 (0x0);//ML01                     
            // 0x028B8A1C: MOV v3.16b, v12.16b        | V3 = 0 (0x0);//ML01                     
            // 0x028B8A20: MOV v4.16b, v11.16b        | V4 = 0 (0x0);//ML01                     
            // 0x028B8A24: MOV v5.16b, v10.16b        | V5 = 0 (0x0);//ML01                     
            // 0x028B8A28: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
            UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
            // 0x028B8A2C: LDP s3, s4, [sp, #0x40]    | S3 = 0; S4 = 0;                          //  | 
            // 0x028B8A30: LDR s5, [sp, #0x48]        | S5 = 0;                                 
            // 0x028B8A34: MOV v15.16b, v0.16b        | V15 = val_8.x;//m1                      
            // 0x028B8A38: MOV v11.16b, v1.16b        | V11 = val_8.y;//m1                      
            // 0x028B8A3C: MOV v10.16b, v2.16b        | V10 = val_8.z;//m1                      
            // 0x028B8A40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8A44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8A48: MOV v0.16b, v13.16b        | V0 = 0 (0x0);//ML01                     
            // 0x028B8A4C: MOV v1.16b, v14.16b        | V1 = 0 (0x0);//ML01                     
            // 0x028B8A50: MOV v2.16b, v9.16b         | V2 = 0 (0x0);//ML01                     
            // 0x028B8A54: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
            UnityEngine.Vector3 val_9 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
            // 0x028B8A58: LDR x0, [x22]              | X0 = typeof(UnityEngine.Debug);         
            // 0x028B8A5C: MOV v12.16b, v0.16b        | V12 = val_9.x;//m1                      
            // 0x028B8A60: MOV v13.16b, v1.16b        | V13 = val_9.y;//m1                      
            // 0x028B8A64: MOV v14.16b, v2.16b        | V14 = val_9.z;//m1                      
            // 0x028B8A68: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x028B8A6C: TBZ w8, #0, #0x28b8a7c     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x028B8A70: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x028B8A74: CBNZ w8, #0x28b8a7c        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x028B8A78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_12:
            // 0x028B8A7C: LDR s0, [sp, #0x24]        | S0 = val_2;                             
            // 0x028B8A80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8A84: MOV v1.16b, v11.16b        | V1 = val_8.y;//m1                       
            // 0x028B8A88: MOV v2.16b, v10.16b        | V2 = val_8.z;//m1                       
            // 0x028B8A8C: STR s0, [sp, #4]           | stack[1152921513250831924] = val_2;      //  dest_result_addr=1152921513250831924
            // 0x028B8A90: LDR s0, [sp, #0x20]        | S0 = col.r;                             
            // 0x028B8A94: MOV v3.16b, v12.16b        | V3 = val_9.x;//m1                       
            // 0x028B8A98: MOV v4.16b, v13.16b        | V4 = val_9.y;//m1                       
            // 0x028B8A9C: MOV v5.16b, v14.16b        | V5 = val_9.z;//m1                       
            // 0x028B8AA0: STR s0, [sp]               | stack[1152921513250831920] = col.r;      //  dest_result_addr=1152921513250831920
            // 0x028B8AA4: LDR s0, [sp, #0x28]        | S0 = col.g;                             
            // 0x028B8AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8AAC: STR s0, [sp, #8]           | stack[1152921513250831928] = col.g;      //  dest_result_addr=1152921513250831928
            // 0x028B8AB0: LDR s0, [sp, #0x2c]        | S0 = val_1;                             
            // 0x028B8AB4: STR s0, [sp, #0xc]         | stack[1152921513250831932] = val_1;      //  dest_result_addr=1152921513250831932
            // 0x028B8AB8: MOV v0.16b, v15.16b        | V0 = val_8.x;//m1                       
            // 0x028B8ABC: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, end:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, color:  new UnityEngine.Color() {r = col.r, g = col.g});
            UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, end:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, color:  new UnityEngine.Color() {r = col.r, g = col.g});
            // 0x028B8AC0: LDR w8, [sp, #0x48]        | W8 = 0x0;                               
            // 0x028B8AC4: LDR x9, [sp, #0x40]        | X9 = 0x0;                               
            // 0x028B8AC8: LDR s14, [sp, #0x3c]       | S14 = a1;                               
            // 0x028B8ACC: LDR s15, [sp, #0x30]       | S15 = (a0 + -6.283185f);                
            // 0x028B8AD0: SCVTF s10, w20             | S10 = 1;                                
            // 0x028B8AD4: ADD w20, w20, #1           | W20 = (1 + 1);                          
            val_12 = val_12 + 1;
            // 0x028B8AD8: STR w8, [sp, #0x58]        | stack[1152921513250832008] = 0x0;        //  dest_result_addr=1152921513250832008
            // 0x028B8ADC: STR x9, [sp, #0x50]        | stack[1152921513250832000] = 0x0;        //  dest_result_addr=1152921513250832000
            // 0x028B8AE0: CMP w20, #0x2a             | STATE = COMPARE((1 + 1), 0x2A)          
            // 0x028B8AE4: B.NE #0x28b896c            | if (1 != 0x2A) goto label_13;           
            if(val_12 != 42)
            {
                goto label_13;
            }
            // 0x028B8AE8: SUB sp, x29, #0x60         | SP = (1152921513250832128 - 96) = 1152921513250832032 (0x100000020338BEA0);
            // 0x028B8AEC: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x028B8AF0: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x028B8AF4: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x028B8AF8: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x028B8AFC: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x028B8B00: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x028B8B04: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
            // 0x028B8B08: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B8B0C (42699532), len: 1332  VirtAddr: 0x028B8B0C RVA: 0x028B8B0C token: 100682489 methodIndex: 51101 delegateWrapperIndex: 0 methodInvoker: 0
        private static void DrawVO(UnityEngine.Vector2 circleCenter, float radius, UnityEngine.Vector2 origin)
        {
            //
            // Disasemble & Code
            //  | 
            float val_20;
            //  | 
            float val_21;
            //  | 
            float val_22;
            // 0x028B8B0C: STP d15, d14, [sp, #-0x60]! | stack[1152921513250944048] = ???;  stack[1152921513250944056] = ???;  //  dest_result_addr=1152921513250944048 |  dest_result_addr=1152921513250944056
            // 0x028B8B10: STP d13, d12, [sp, #0x10]  | stack[1152921513250944064] = ???;  stack[1152921513250944072] = ???;  //  dest_result_addr=1152921513250944064 |  dest_result_addr=1152921513250944072
            // 0x028B8B14: STP d11, d10, [sp, #0x20]  | stack[1152921513250944080] = ???;  stack[1152921513250944088] = ???;  //  dest_result_addr=1152921513250944080 |  dest_result_addr=1152921513250944088
            // 0x028B8B18: STP d9, d8, [sp, #0x30]    | stack[1152921513250944096] = ???;  stack[1152921513250944104] = ???;  //  dest_result_addr=1152921513250944096 |  dest_result_addr=1152921513250944104
            // 0x028B8B1C: STP x20, x19, [sp, #0x40]  | stack[1152921513250944112] = ???;  stack[1152921513250944120] = ???;  //  dest_result_addr=1152921513250944112 |  dest_result_addr=1152921513250944120
            // 0x028B8B20: STP x29, x30, [sp, #0x50]  | stack[1152921513250944128] = ???;  stack[1152921513250944136] = ???;  //  dest_result_addr=1152921513250944128 |  dest_result_addr=1152921513250944136
            // 0x028B8B24: ADD x29, sp, #0x50         | X29 = (1152921513250944048 + 80) = 1152921513250944128 (0x10000002033A7480);
            // 0x028B8B28: SUB sp, sp, #0x80          | SP = (1152921513250944048 - 128) = 1152921513250943920 (0x10000002033A73B0);
            // 0x028B8B2C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028B8B30: LDRB w8, [x19, #0x91b]     | W8 = (bool)static_value_037B891B;       
            // 0x028B8B34: MOV v11.16b, v4.16b        | V11 = origin.y;//m1                     
            // 0x028B8B38: MOV v12.16b, v3.16b        | V12 = origin.x;//m1                     
            // 0x028B8B3C: MOV v14.16b, v2.16b        | V14 = radius;//m1                       
            // 0x028B8B40: MOV v10.16b, v1.16b        | V10 = circleCenter.y;//m1               
            // 0x028B8B44: MOV v9.16b, v0.16b         | V9 = circleCenter.x;//m1                
            // 0x028B8B48: TBNZ w8, #0, #0x28b8b64    | if (static_value_037B891B == true) goto label_0;
            // 0x028B8B4C: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x028B8B50: LDR x8, [x8, #0x7f8]       | X8 = 0x2B8AAB4;                         
            // 0x028B8B54: LDR w0, [x8]               | W0 = 0x16B;                             
            // 0x028B8B58: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B, ????);      
            // 0x028B8B5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B8B60: STRB w8, [x19, #0x91b]     | static_value_037B891B = true;            //  dest_result_addr=58427675
            label_0:
            // 0x028B8B64: STP xzr, xzr, [sp, #0x60]  | stack[1152921513250944016] = 0x0;  stack[1152921513250944024] = 0x0;  //  dest_result_addr=1152921513250944016 |  dest_result_addr=1152921513250944024
            // 0x028B8B68: ADRP x19, #0x366e000       | X19 = 57073664 (0x366E000);             
            // 0x028B8B6C: STR wzr, [sp, #0x58]       | stack[1152921513250944008] = 0x0;        //  dest_result_addr=1152921513250944008
            // 0x028B8B70: LDR x19, [x19, #0xfb0]     | X19 = 1152921504708657152;              
            // 0x028B8B74: STR xzr, [sp, #0x50]       | stack[1152921513250944000] = 0x0;        //  dest_result_addr=1152921513250944000
            // 0x028B8B78: STR wzr, [sp, #0x48]       | stack[1152921513250943992] = 0x0;        //  dest_result_addr=1152921513250943992
            // 0x028B8B7C: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B8B80: STR xzr, [sp, #0x40]       | stack[1152921513250943984] = 0x0;        //  dest_result_addr=1152921513250943984
            // 0x028B8B84: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B8B88: TBZ w8, #0, #0x28b8b98     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028B8B8C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B8B90: CBNZ w8, #0x28b8b98        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028B8B94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_2:
            // 0x028B8B98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8B9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8BA0: MOV v0.16b, v12.16b        | V0 = origin.x;//m1                      
            // 0x028B8BA4: MOV v1.16b, v11.16b        | V1 = origin.y;//m1                      
            // 0x028B8BA8: MOV v2.16b, v9.16b         | V2 = circleCenter.x;//m1                
            // 0x028B8BAC: MOV v3.16b, v10.16b        | V3 = circleCenter.y;//m1                
            // 0x028B8BB0: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = origin.x, y = origin.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = circleCenter.y});
            UnityEngine.Vector2 val_1 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = origin.x, y = origin.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = circleCenter.y});
            // 0x028B8BB4: MOV v13.16b, v1.16b        | V13 = val_1.y;//m1                      
            // 0x028B8BB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8BBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8BC0: MOV v0.16b, v12.16b        | V0 = origin.x;//m1                      
            // 0x028B8BC4: MOV v1.16b, v11.16b        | V1 = origin.y;//m1                      
            // 0x028B8BC8: MOV v2.16b, v9.16b         | V2 = circleCenter.x;//m1                
            // 0x028B8BCC: MOV v3.16b, v10.16b        | V3 = circleCenter.y;//m1                
            // 0x028B8BD0: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = origin.x, y = origin.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = circleCenter.y});
            UnityEngine.Vector2 val_2 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = origin.x, y = origin.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = circleCenter.y});
            // 0x028B8BD4: ADRP x20, #0x363f000       | X20 = 56881152 (0x363F000);             
            // 0x028B8BD8: LDR x20, [x20, #0x3b0]     | X20 = 1152921504695345152;              
            // 0x028B8BDC: MOV v8.16b, v0.16b         | V8 = val_2.x;//m1                       
            // 0x028B8BE0: LDR x0, [x20]              | X0 = typeof(UnityEngine.Mathf);         
            // 0x028B8BE4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028B8BE8: TBZ w8, #0, #0x28b8bf8     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x028B8BEC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028B8BF0: CBNZ w8, #0x28b8bf8        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x028B8BF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_4:
            // 0x028B8BF8: MOV v0.16b, v13.16b        | V0 = val_1.y;//m1                       
            // 0x028B8BFC: MOV v1.16b, v8.16b         | V1 = val_2.x;//m1                       
            // 0x028B8C00: BL #0x980de0               | X0 = sub_980DE0( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028B8C04: MOV v13.16b, v0.16b        | V13 = val_1.y;//m1                      
            // 0x028B8C08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8C0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8C10: MOV v0.16b, v12.16b        | V0 = origin.x;//m1                      
            // 0x028B8C14: MOV v1.16b, v11.16b        | V1 = origin.y;//m1                      
            // 0x028B8C18: MOV v2.16b, v9.16b         | V2 = circleCenter.x;//m1                
            // 0x028B8C1C: MOV v3.16b, v10.16b        | V3 = circleCenter.y;//m1                
            // 0x028B8C20: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = origin.x, y = origin.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = circleCenter.y});
            UnityEngine.Vector2 val_3 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = origin.x, y = origin.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = circleCenter.y});
            // 0x028B8C24: ADD x0, sp, #0x68          | X0 = (1152921513250943920 + 104) = 1152921513250944024 (0x10000002033A7418);
            // 0x028B8C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8C2C: STP s0, s1, [sp, #0x68]    | stack[1152921513250944024] = val_3.x;  stack[1152921513250944028] = val_3.y;  //  dest_result_addr=1152921513250944024 |  dest_result_addr=1152921513250944028
            // 0x028B8C30: BL #0x269749c              | X0 = label_UnityEngine_Vector2_op_Subtraction_GL0269749C();
            // 0x028B8C34: FDIV s11, s14, s0          | S11 = (radius / val_3.x);               
            float val_4 = radius / val_3.x;
            // 0x028B8C38: FMOV s0, #1.00000000       | S0 = 1;                                 
            val_20 = 1f;
            // 0x028B8C3C: FCMP s11, s0               | STATE = COMPARE((radius / val_3.x), 1)  
            // 0x028B8C40: B.LS #0x28b8c54            | if (val_4 <= val_20) goto label_5;      
            if(val_4 <= val_20)
            {
                goto label_5;
            }
            // 0x028B8C44: STP s14, s9, [sp, #0x20]   | stack[1152921513250943952] = radius;  stack[1152921513250943956] = circleCenter.x;  //  dest_result_addr=1152921513250943952 |  dest_result_addr=1152921513250943956
            // 0x028B8C48: MOV v9.16b, v10.16b        | V9 = circleCenter.y;//m1                
            val_21 = circleCenter.y;
            // 0x028B8C4C: FMOV s11, wzr              | S11 = 0f;                               
            val_22 = 0f;
            // 0x028B8C50: B #0x28b8c80               |  goto label_6;                          
            goto label_6;
            label_5:
            // 0x028B8C54: STP s14, s9, [sp, #0x20]   | stack[1152921513250943952] = radius;  stack[1152921513250943956] = circleCenter.x;  //  dest_result_addr=1152921513250943952 |  dest_result_addr=1152921513250943956
            // 0x028B8C58: LDR x0, [x20]              | X0 = typeof(UnityEngine.Mathf);         
            // 0x028B8C5C: MOV v9.16b, v10.16b        | V9 = circleCenter.y;//m1                
            val_21 = circleCenter.y;
            // 0x028B8C60: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028B8C64: TBZ w8, #0, #0x28b8c74     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x028B8C68: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028B8C6C: CBNZ w8, #0x28b8c74        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x028B8C70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_8:
            // 0x028B8C74: MOV v0.16b, v11.16b        | V0 = (radius / val_3.x);//m1            
            val_20 = val_4;
            // 0x028B8C78: BL #0x980f40               | X0 = sub_980F40( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028B8C7C: FABS s11, s0               | S11 = System.Math.Abs((radius / val_3.x));
            val_22 = System.Math.Abs(val_20);
            label_6:
            // 0x028B8C80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8C84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8C88: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
            UnityEngine.Color val_5 = UnityEngine.Color.black;
            // 0x028B8C8C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028B8C90: LDR x8, [x8, #0x470]       | X8 = 1152921504840765440;               
            // 0x028B8C94: MOV v14.16b, v0.16b        | V14 = val_5.r;//m1                      
            // 0x028B8C98: MOV v15.16b, v1.16b        | V15 = val_5.g;//m1                      
            // 0x028B8C9C: MOV v10.16b, v2.16b        | V10 = val_5.b;//m1                      
            // 0x028B8CA0: LDR x0, [x8]               | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028B8CA4: MOV v8.16b, v3.16b         | V8 = val_5.a;//m1                       
            // 0x028B8CA8: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028B8CAC: TBZ w8, #0, #0x28b8cbc     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x028B8CB0: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028B8CB4: CBNZ w8, #0x28b8cbc        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x028B8CB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_10:
            // 0x028B8CBC: STP s10, s8, [sp, #8]      | stack[1152921513250943928] = val_5.b;  stack[1152921513250943932] = val_5.a;  //  dest_result_addr=1152921513250943928 |  dest_result_addr=1152921513250943932
            // 0x028B8CC0: STP s14, s15, [sp]         | stack[1152921513250943920] = val_5.r;  stack[1152921513250943924] = val_5.g;  //  dest_result_addr=1152921513250943920 |  dest_result_addr=1152921513250943924
            // 0x028B8CC4: MOV v15.16b, v9.16b        | V15 = circleCenter.y;//m1               
            // 0x028B8CC8: LDP s9, s0, [sp, #0x20]    | S9 = radius; S0 = circleCenter.x;        //  | 
            // 0x028B8CCC: FSUB s12, s13, s11         | S12 = (val_1.y - (radius / val_3.x));   
            float val_6 = val_1.y - val_22;
            // 0x028B8CD0: FADD s11, s13, s11         | S11 = (val_1.y + (radius / val_3.x));   
            val_22 = val_1.y + val_22;
            // 0x028B8CD4: MOV v1.16b, v15.16b        | V1 = circleCenter.y;//m1                
            // 0x028B8CD8: MOV v2.16b, v9.16b         | V2 = radius;//m1                        
            // 0x028B8CDC: MOV v3.16b, v12.16b        | V3 = (val_1.y - (radius / val_3.x));//m1
            // 0x028B8CE0: MOV v4.16b, v11.16b        | V4 = (val_1.y + (radius / val_3.x));//m1
            // 0x028B8CE4: BL #0x28b87f4              | Pathfinding.RVO.Sampled.Agent.DrawCircle(_p:  new UnityEngine.Vector2() {x = circleCenter.x, y = val_21}, radius:  radius, a0:  val_6, a1:  val_22, col:  new UnityEngine.Color() {r = val_5.r, g = val_5.b});
            Pathfinding.RVO.Sampled.Agent.DrawCircle(_p:  new UnityEngine.Vector2() {x = circleCenter.x, y = val_21}, radius:  radius, a0:  val_6, a1:  val_22, col:  new UnityEngine.Color() {r = val_5.r, g = val_5.b});
            // 0x028B8CE8: LDR x0, [x20]              | X0 = typeof(UnityEngine.Mathf);         
            // 0x028B8CEC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028B8CF0: TBZ w8, #0, #0x28b8d00     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x028B8CF4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028B8CF8: CBNZ w8, #0x28b8d00        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x028B8CFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_12:
            // 0x028B8D00: MOV v0.16b, v12.16b        | V0 = (val_1.y - (radius / val_3.x));//m1
            // 0x028B8D04: BL #0x981480               | X0 = sub_981480( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028B8D08: MOV v8.16b, v0.16b         | V8 = (val_1.y - (radius / val_3.x));//m1
            // 0x028B8D0C: MOV v0.16b, v12.16b        | V0 = (val_1.y - (radius / val_3.x));//m1
            // 0x028B8D10: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028B8D14: MOV v1.16b, v0.16b         | V1 = (val_1.y - (radius / val_3.x));//m1
            // 0x028B8D18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8D1C: ADD x0, sp, #0x38          | X0 = (1152921513250943920 + 56) = 1152921513250943976 (0x10000002033A73E8);
            // 0x028B8D20: MOV v0.16b, v8.16b         | V0 = (val_1.y - (radius / val_3.x));//m1
            // 0x028B8D24: STR xzr, [sp, #0x38]       | stack[1152921513250943976] = 0x0;        //  dest_result_addr=1152921513250943976
            // 0x028B8D28: BL #0x2697148              | null..ctor(_x:  val_6, _y:  val_6);     
            Geometric.Point val_7 = new Geometric.Point(_x:  val_6, _y:  val_6);
            // 0x028B8D2C: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B8D30: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B8D34: TBZ w8, #0, #0x28b8d44     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x028B8D38: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B8D3C: CBNZ w8, #0x28b8d44        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x028B8D40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_14:
            // 0x028B8D44: LDP s0, s1, [sp, #0x38]    | S0 = val_7.x; S1 = val_7.y;              //  | 
            // 0x028B8D48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8D4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8D50: MOV v2.16b, v9.16b         | V2 = radius;//m1                        
            // 0x028B8D54: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_7.x, y = val_7.y}, d:  radius);
            UnityEngine.Vector2 val_8 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_7.x, y = val_7.y}, d:  radius);
            // 0x028B8D58: MOV v12.16b, v0.16b        | V12 = val_8.x;//m1                      
            // 0x028B8D5C: MOV v0.16b, v11.16b        | V0 = (val_1.y + (radius / val_3.x));//m1
            // 0x028B8D60: MOV v13.16b, v1.16b        | V13 = val_8.y;//m1                      
            // 0x028B8D64: BL #0x981480               | X0 = sub_981480( ?? 0x0, ????);         
            // 0x028B8D68: MOV v8.16b, v0.16b         | V8 = (val_1.y + (radius / val_3.x));//m1
            // 0x028B8D6C: MOV v0.16b, v11.16b        | V0 = (val_1.y + (radius / val_3.x));//m1
            // 0x028B8D70: BL #0x9811b0               | X0 = sub_9811B0( ?? 0x0, ????);         
            // 0x028B8D74: MOV v1.16b, v0.16b         | V1 = (val_1.y + (radius / val_3.x));//m1
            // 0x028B8D78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8D7C: ADD x0, sp, #0x30          | X0 = (1152921513250943920 + 48) = 1152921513250943968 (0x10000002033A73E0);
            // 0x028B8D80: MOV v0.16b, v8.16b         | V0 = (val_1.y + (radius / val_3.x));//m1
            // 0x028B8D84: STR xzr, [sp, #0x30]       | stack[1152921513250943968] = 0x0;        //  dest_result_addr=1152921513250943968
            // 0x028B8D88: BL #0x2697148              | null..ctor(_x:  val_22, _y:  val_22);   
            Geometric.Point val_9 = new Geometric.Point(_x:  val_22, _y:  val_22);
            // 0x028B8D8C: LDP s0, s1, [sp, #0x30]    | S0 = val_9.x; S1 = val_9.y;              //  | 
            // 0x028B8D90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8D94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8D98: MOV v2.16b, v9.16b         | V2 = radius;//m1                        
            // 0x028B8D9C: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_9.x, y = val_9.y}, d:  radius);
            UnityEngine.Vector2 val_10 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_9.x, y = val_9.y}, d:  radius);
            // 0x028B8DA0: MOV v8.16b, v0.16b         | V8 = val_10.x;//m1                      
            // 0x028B8DA4: MOV v10.16b, v1.16b        | V10 = val_10.y;//m1                     
            // 0x028B8DA8: FNEG s0, s13               | S0 = -(val_8.y);                        
            // 0x028B8DAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8DB0: ADD x0, sp, #0x28          | X0 = (1152921513250943920 + 40) = 1152921513250943960 (0x10000002033A73D8);
            // 0x028B8DB4: MOV v1.16b, v12.16b        | V1 = val_8.x;//m1                       
            // 0x028B8DB8: STR xzr, [sp, #0x28]       | stack[1152921513250943960] = 0x0;        //  dest_result_addr=1152921513250943960
            // 0x028B8DBC: BL #0x2697148              | null..ctor(_x:  -val_8.y, _y:  val_8.x);
            Geometric.Point val_11 = new Geometric.Point(_x:  -val_8.y, _y:  val_8.x);
            // 0x028B8DC0: LDP s0, s1, [sp, #0x28]    | S0 = val_11.x; S1 = val_11.y;            //  | 
            // 0x028B8DC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8DC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8DCC: BL #0x26982c4              | X0 = UnityEngine.Vector2.op_UnaryNegation(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_12 = UnityEngine.Vector2.op_UnaryNegation(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028B8DD0: MOV v11.16b, v0.16b        | V11 = val_12.x;//m1                     
            // 0x028B8DD4: MOV v14.16b, v1.16b        | V14 = val_12.y;//m1                     
            // 0x028B8DD8: FNEG s0, s10               | S0 = -(val_10.y);                       
            // 0x028B8DDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8DE0: ADD x0, sp, #0x60          | X0 = (1152921513250943920 + 96) = 1152921513250944016 (0x10000002033A7410);
            // 0x028B8DE4: MOV v1.16b, v8.16b         | V1 = val_10.x;//m1                      
            // 0x028B8DE8: BL #0x2697148              | null..ctor(_x:  -val_10.y, _y:  val_10.x);
            Geometric.Point val_13 = new Geometric.Point(_x:  -val_10.y, _y:  val_10.x);
            // 0x028B8DEC: LDR s9, [sp, #0x24]        | S9 = circleCenter.x;                    
            // 0x028B8DF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8DF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8DF8: MOV v0.16b, v12.16b        | V0 = val_8.x;//m1                       
            // 0x028B8DFC: MOV v1.16b, v13.16b        | V1 = val_8.y;//m1                       
            // 0x028B8E00: MOV v2.16b, v9.16b         | V2 = circleCenter.x;//m1                
            // 0x028B8E04: MOV v3.16b, v15.16b        | V3 = circleCenter.y;//m1                
            // 0x028B8E08: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_8.x, y = val_8.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = val_21});
            UnityEngine.Vector2 val_14 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_8.x, y = val_8.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = val_21});
            // 0x028B8E0C: MOV v12.16b, v0.16b        | V12 = val_14.x;//m1                     
            // 0x028B8E10: MOV v13.16b, v1.16b        | V13 = val_14.y;//m1                     
            // 0x028B8E14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8E18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8E1C: MOV v0.16b, v8.16b         | V0 = val_10.x;//m1                      
            // 0x028B8E20: MOV v1.16b, v10.16b        | V1 = val_10.y;//m1                      
            // 0x028B8E24: MOV v2.16b, v9.16b         | V2 = circleCenter.x;//m1                
            // 0x028B8E28: MOV v3.16b, v15.16b        | V3 = circleCenter.y;//m1                
            // 0x028B8E2C: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_10.x, y = val_10.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = val_21});
            UnityEngine.Vector2 val_15 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_10.x, y = val_10.y}, b:  new UnityEngine.Vector2() {x = circleCenter.x, y = val_21});
            // 0x028B8E30: FMOV s8, wzr               | S8 = 0f;                                
            // 0x028B8E34: STP s0, s1, [sp, #0x20]    | stack[1152921513250943952] = val_15.x;  stack[1152921513250943956] = val_15.y;  //  dest_result_addr=1152921513250943952 |  dest_result_addr=1152921513250943956
            // 0x028B8E38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8E3C: SUB x0, x29, #0x60         | X0 = (1152921513250944128 - 96) = 1152921513250944032 (0x10000002033A7420);
            // 0x028B8E40: MOV v0.16b, v12.16b        | V0 = val_14.x;//m1                      
            // 0x028B8E44: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x028B8E48: MOV v2.16b, v13.16b        | V2 = val_14.y;//m1                      
            // 0x028B8E4C: STUR wzr, [x29, #-0x58]    | stack[1152921513250944040] = 0x0;        //  dest_result_addr=1152921513250944040
            // 0x028B8E50: STUR xzr, [x29, #-0x60]    | stack[1152921513250944032] = 0x0;        //  dest_result_addr=1152921513250944032
            // 0x028B8E54: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B8E58: LDUR s0, [x29, #-0x60]     | S0 = 0;                                 
            // 0x028B8E5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8E60: SUB x0, x29, #0x60         | X0 = (1152921513250944128 - 96) = 1152921513250944032 (0x10000002033A7420);
            // 0x028B8E64: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x028B8E68: STR s0, [sp, #0x1c]        | stack[1152921513250943948] = 0x0;        //  dest_result_addr=1152921513250943948
            // 0x028B8E6C: LDUR s0, [x29, #-0x5c]     | S0 = 0;                                 
            // 0x028B8E70: MOV v2.16b, v14.16b        | V2 = val_12.y;//m1                      
            // 0x028B8E74: STR s0, [sp, #0x18]        | stack[1152921513250943944] = 0x0;        //  dest_result_addr=1152921513250943944
            // 0x028B8E78: LDUR s0, [x29, #-0x58]     | S0 = 0;                                 
            // 0x028B8E7C: STUR wzr, [x29, #-0x58]    | stack[1152921513250944040] = 0x0;        //  dest_result_addr=1152921513250944040
            // 0x028B8E80: STR s0, [sp, #0x14]        | stack[1152921513250943940] = 0x0;        //  dest_result_addr=1152921513250943940
            // 0x028B8E84: MOV v0.16b, v11.16b        | V0 = val_12.x;//m1                      
            // 0x028B8E88: STUR xzr, [x29, #-0x60]    | stack[1152921513250944032] = 0x0;        //  dest_result_addr=1152921513250944032
            // 0x028B8E8C: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B8E90: LDUR x8, [x29, #-0x60]     | X8 = 0x0;                               
            // 0x028B8E94: LDUR w9, [x29, #-0x58]     | W9 = 0x0;                               
            // 0x028B8E98: ADD x0, sp, #0x50          | X0 = (1152921513250943920 + 80) = 1152921513250944000 (0x10000002033A7400);
            // 0x028B8E9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8EA0: STR x8, [sp, #0x50]        | stack[1152921513250944000] = 0x0;        //  dest_result_addr=1152921513250944000
            // 0x028B8EA4: STR w9, [sp, #0x58]        | stack[1152921513250944008] = 0x0;        //  dest_result_addr=1152921513250944008
            // 0x028B8EA8: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
            // 0x028B8EAC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x028B8EB0: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x028B8EB4: MOV v8.16b, v0.16b         | V8 = val_12.x;//m1                      
            // 0x028B8EB8: MOV v14.16b, v1.16b        | V14 = 0;//m1                            
            // 0x028B8EBC: MOV v9.16b, v2.16b         | V9 = val_12.y;//m1                      
            // 0x028B8EC0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x028B8EC4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x028B8EC8: TBZ w8, #0, #0x28b8ed8     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x028B8ECC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x028B8ED0: CBNZ w8, #0x28b8ed8        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x028B8ED4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_16:
            // 0x028B8ED8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028B8EDC: LDR s10, [x8, #0x4b0]      | S10 = 100;                              
            // 0x028B8EE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8EE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8EE8: MOV v0.16b, v8.16b         | V0 = val_12.x;//m1                      
            // 0x028B8EEC: MOV v1.16b, v14.16b        | V1 = 0;//m1                             
            // 0x028B8EF0: MOV v2.16b, v9.16b         | V2 = val_12.y;//m1                      
            // 0x028B8EF4: MOV v3.16b, v10.16b        | V3 = 1120403456 (0x42C80000);//ML01     
            // 0x028B8EF8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_12.x, y = 0f, z = val_12.y}, d:  100f);
            UnityEngine.Vector3 val_16 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_12.x, y = 0f, z = val_12.y}, d:  100f);
            // 0x028B8EFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8F00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8F04: MOV v14.16b, v0.16b        | V14 = val_16.x;//m1                     
            // 0x028B8F08: MOV v15.16b, v1.16b        | V15 = val_16.y;//m1                     
            // 0x028B8F0C: MOV v8.16b, v2.16b         | V8 = val_16.z;//m1                      
            // 0x028B8F10: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
            UnityEngine.Color val_17 = UnityEngine.Color.black;
            // 0x028B8F14: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x028B8F18: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x028B8F1C: MOV v9.16b, v0.16b         | V9 = val_17.r;//m1                      
            // 0x028B8F20: MOV v11.16b, v1.16b        | V11 = val_17.g;//m1                     
            // 0x028B8F24: MOV v12.16b, v2.16b        | V12 = val_17.b;//m1                     
            // 0x028B8F28: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x028B8F2C: MOV v13.16b, v3.16b        | V13 = val_17.a;//m1                     
            // 0x028B8F30: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x028B8F34: TBZ w8, #0, #0x28b8f44     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x028B8F38: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x028B8F3C: CBNZ w8, #0x28b8f44        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x028B8F40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_18:
            // 0x028B8F44: STP s12, s13, [sp, #8]     | stack[1152921513250943928] = val_17.b;  stack[1152921513250943932] = val_17.a;  //  dest_result_addr=1152921513250943928 |  dest_result_addr=1152921513250943932
            // 0x028B8F48: STP s9, s11, [sp]          | stack[1152921513250943920] = val_17.r;  stack[1152921513250943924] = val_17.g;  //  dest_result_addr=1152921513250943920 |  dest_result_addr=1152921513250943924
            // 0x028B8F4C: LDP s1, s0, [sp, #0x18]    | S1 = 0; S0 = 0;                          //  | 
            // 0x028B8F50: LDR s2, [sp, #0x14]        | S2 = 0;                                 
            // 0x028B8F54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8F58: MOV v3.16b, v14.16b        | V3 = val_16.x;//m1                      
            // 0x028B8F5C: MOV v4.16b, v15.16b        | V4 = val_16.y;//m1                      
            // 0x028B8F60: MOV v5.16b, v8.16b         | V5 = val_16.z;//m1                      
            // 0x028B8F64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8F68: BL #0x1a5cee8              | UnityEngine.Debug.DrawRay(start:  new UnityEngine.Vector3() {x = 0f, y = 0f}, dir:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, color:  new UnityEngine.Color() {r = val_17.r, g = val_17.b, a = 0f});
            UnityEngine.Debug.DrawRay(start:  new UnityEngine.Vector3() {x = 0f, y = 0f}, dir:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, color:  new UnityEngine.Color() {r = val_17.r, g = val_17.b, a = 0f});
            // 0x028B8F6C: STUR wzr, [x29, #-0x58]    | stack[1152921513250944040] = 0x0;        //  dest_result_addr=1152921513250944040
            // 0x028B8F70: STUR xzr, [x29, #-0x60]    | stack[1152921513250944032] = 0x0;        //  dest_result_addr=1152921513250944032
            // 0x028B8F74: LDP s0, s2, [sp, #0x20]    | S0 = val_15.x; S2 = val_15.y;            //  | 
            // 0x028B8F78: FMOV s8, wzr               | S8 = 0f;                                
            // 0x028B8F7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8F80: SUB x0, x29, #0x60         | X0 = (1152921513250944128 - 96) = 1152921513250944032 (0x10000002033A7420);
            // 0x028B8F84: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x028B8F88: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B8F8C: LDP s9, s11, [x29, #-0x60] | S9 = 0; S11 = 0;                         //  | 
            // 0x028B8F90: LDUR s12, [x29, #-0x58]    | S12 = 0;                                
            // 0x028B8F94: LDP s0, s2, [sp, #0x60]    | S0 = val_13.x; S2 = val_13.y;            //  | 
            // 0x028B8F98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8F9C: SUB x0, x29, #0x60         | X0 = (1152921513250944128 - 96) = 1152921513250944032 (0x10000002033A7420);
            // 0x028B8FA0: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x028B8FA4: STUR wzr, [x29, #-0x58]    | stack[1152921513250944040] = 0x0;        //  dest_result_addr=1152921513250944040
            // 0x028B8FA8: STUR xzr, [x29, #-0x60]    | stack[1152921513250944032] = 0x0;        //  dest_result_addr=1152921513250944032
            // 0x028B8FAC: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B8FB0: LDUR x8, [x29, #-0x60]     | X8 = 0x0;                               
            // 0x028B8FB4: LDUR w9, [x29, #-0x58]     | W9 = 0x0;                               
            // 0x028B8FB8: ADD x0, sp, #0x40          | X0 = (1152921513250943920 + 64) = 1152921513250943984 (0x10000002033A73F0);
            // 0x028B8FBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8FC0: STR x8, [sp, #0x40]        | stack[1152921513250943984] = 0x0;        //  dest_result_addr=1152921513250943984
            // 0x028B8FC4: STR w9, [sp, #0x48]        | stack[1152921513250943992] = 0x0;        //  dest_result_addr=1152921513250943992
            // 0x028B8FC8: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
            // 0x028B8FCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8FD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8FD4: MOV v3.16b, v10.16b        | V3 = 1120403456 (0x42C80000);//ML01     
            // 0x028B8FD8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_13.x, y = 0f, z = val_13.y}, d:  100f);
            UnityEngine.Vector3 val_18 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_13.x, y = 0f, z = val_13.y}, d:  100f);
            // 0x028B8FDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8FE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B8FE4: MOV v8.16b, v0.16b         | V8 = val_18.x;//m1                      
            // 0x028B8FE8: MOV v10.16b, v1.16b        | V10 = val_18.y;//m1                     
            // 0x028B8FEC: MOV v13.16b, v2.16b        | V13 = val_18.z;//m1                     
            // 0x028B8FF0: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
            UnityEngine.Color val_19 = UnityEngine.Color.black;
            // 0x028B8FF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B8FF8: STP s2, s3, [sp, #8]       | stack[1152921513250943928] = val_19.b;  stack[1152921513250943932] = val_19.a;  //  dest_result_addr=1152921513250943928 |  dest_result_addr=1152921513250943932
            // 0x028B8FFC: STP s0, s1, [sp]           | stack[1152921513250943920] = val_19.r;  stack[1152921513250943924] = val_19.g;  //  dest_result_addr=1152921513250943920 |  dest_result_addr=1152921513250943924
            // 0x028B9000: MOV v0.16b, v9.16b         | V0 = 0 (0x0);//ML01                     
            // 0x028B9004: MOV v1.16b, v11.16b        | V1 = 0 (0x0);//ML01                     
            // 0x028B9008: MOV v2.16b, v12.16b        | V2 = 0 (0x0);//ML01                     
            // 0x028B900C: MOV v3.16b, v8.16b         | V3 = val_18.x;//m1                      
            // 0x028B9010: MOV v4.16b, v10.16b        | V4 = val_18.y;//m1                      
            // 0x028B9014: MOV v5.16b, v13.16b        | V5 = val_18.z;//m1                      
            // 0x028B9018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B901C: BL #0x1a5cee8              | UnityEngine.Debug.DrawRay(start:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, dir:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, color:  new UnityEngine.Color() {r = val_19.r, g = val_19.b, a = 0f});
            UnityEngine.Debug.DrawRay(start:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, dir:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, color:  new UnityEngine.Color() {r = val_19.r, g = val_19.b, a = 0f});
            // 0x028B9020: SUB sp, x29, #0x50         | SP = (1152921513250944128 - 80) = 1152921513250944048 (0x10000002033A7430);
            // 0x028B9024: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028B9028: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028B902C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x028B9030: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x028B9034: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x028B9038: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x028B903C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B9040 (42700864), len: 192  VirtAddr: 0x028B9040 RVA: 0x028B9040 token: 100682490 methodIndex: 51102 delegateWrapperIndex: 0 methodInvoker: 0
        private static void DrawCross(UnityEngine.Vector2 p, float size = 1)
        {
            //
            // Disasemble & Code
            // 0x028B9040: STP d15, d14, [sp, #-0x60]! | stack[1152921513251056048] = ???;  stack[1152921513251056056] = ???;  //  dest_result_addr=1152921513251056048 |  dest_result_addr=1152921513251056056
            // 0x028B9044: STP d13, d12, [sp, #0x10]  | stack[1152921513251056064] = ???;  stack[1152921513251056072] = ???;  //  dest_result_addr=1152921513251056064 |  dest_result_addr=1152921513251056072
            // 0x028B9048: STP d11, d10, [sp, #0x20]  | stack[1152921513251056080] = ???;  stack[1152921513251056088] = ???;  //  dest_result_addr=1152921513251056080 |  dest_result_addr=1152921513251056088
            // 0x028B904C: STP d9, d8, [sp, #0x30]    | stack[1152921513251056096] = ???;  stack[1152921513251056104] = ???;  //  dest_result_addr=1152921513251056096 |  dest_result_addr=1152921513251056104
            // 0x028B9050: STP x20, x19, [sp, #0x40]  | stack[1152921513251056112] = ???;  stack[1152921513251056120] = ???;  //  dest_result_addr=1152921513251056112 |  dest_result_addr=1152921513251056120
            // 0x028B9054: STP x29, x30, [sp, #0x50]  | stack[1152921513251056128] = ???;  stack[1152921513251056136] = ???;  //  dest_result_addr=1152921513251056128 |  dest_result_addr=1152921513251056136
            // 0x028B9058: ADD x29, sp, #0x50         | X29 = (1152921513251056048 + 80) = 1152921513251056128 (0x10000002033C2A00);
            // 0x028B905C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028B9060: LDRB w8, [x19, #0x91c]     | W8 = (bool)static_value_037B891C;       
            // 0x028B9064: MOV v8.16b, v2.16b         | V8 = size;//m1                          
            // 0x028B9068: MOV v9.16b, v1.16b         | V9 = p.y;//m1                           
            // 0x028B906C: MOV v10.16b, v0.16b        | V10 = p.x;//m1                          
            // 0x028B9070: TBNZ w8, #0, #0x28b908c    | if (static_value_037B891C == true) goto label_0;
            // 0x028B9074: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x028B9078: LDR x8, [x8, #0x9f0]       | X8 = 0x2B8AAAC;                         
            // 0x028B907C: LDR w0, [x8]               | W0 = 0x169;                             
            // 0x028B9080: BL #0x2782188              | X0 = sub_2782188( ?? 0x169, ????);      
            // 0x028B9084: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B9088: STRB w8, [x19, #0x91c]     | static_value_037B891C = true;            //  dest_result_addr=58427676
            label_0:
            // 0x028B908C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9090: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9094: BL #0x20d3be4              | X0 = UnityEngine.Color.get_white();     
            UnityEngine.Color val_1 = UnityEngine.Color.white;
            // 0x028B9098: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028B909C: LDR x8, [x8, #0x470]       | X8 = 1152921504840765440;               
            // 0x028B90A0: MOV v11.16b, v0.16b        | V11 = val_1.r;//m1                      
            // 0x028B90A4: MOV v12.16b, v1.16b        | V12 = val_1.g;//m1                      
            // 0x028B90A8: MOV v14.16b, v2.16b        | V14 = val_1.b;//m1                      
            // 0x028B90AC: LDR x0, [x8]               | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028B90B0: MOV v13.16b, v3.16b        | V13 = val_1.a;//m1                      
            // 0x028B90B4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028B90B8: TBZ w8, #0, #0x28b90c8     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028B90BC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028B90C0: CBNZ w8, #0x28b90c8        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028B90C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_2:
            // 0x028B90C8: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x028B90CC: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x028B90D0: MOV v2.16b, v11.16b        | V2 = val_1.r;//m1                       
            // 0x028B90D4: MOV v3.16b, v12.16b        | V3 = val_1.g;//m1                       
            // 0x028B90D8: MOV v5.16b, v13.16b        | V5 = val_1.a;//m1                       
            // 0x028B90DC: MOV v6.16b, v8.16b         | V6 = size;//m1                          
            // 0x028B90E0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028B90E4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028B90E8: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x028B90EC: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x028B90F0: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x028B90F4: MOV v4.16b, v14.16b        | V4 = val_1.b;//m1                       
            // 0x028B90F8: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x028B90FC: B #0x28b9100               | Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = p.x, y = p.y}, col:  new UnityEngine.Color() {r = val_1.r, g = val_1.g, b = val_1.b, a = val_1.a}, size:  size); return;
            Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = p.x, y = p.y}, col:  new UnityEngine.Color() {r = val_1.r, g = val_1.g, b = val_1.b, a = val_1.a}, size:  size);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B9100 (42701056), len: 752  VirtAddr: 0x028B9100 RVA: 0x028B9100 token: 100682491 methodIndex: 51103 delegateWrapperIndex: 0 methodInvoker: 0
        private static void DrawCross(UnityEngine.Vector2 p, UnityEngine.Color col, float size = 1)
        {
            //
            // Disasemble & Code
            // 0x028B9100: STP d15, d14, [sp, #-0x60]! | stack[1152921513251168048] = ???;  stack[1152921513251168056] = ???;  //  dest_result_addr=1152921513251168048 |  dest_result_addr=1152921513251168056
            // 0x028B9104: STP d13, d12, [sp, #0x10]  | stack[1152921513251168064] = ???;  stack[1152921513251168072] = ???;  //  dest_result_addr=1152921513251168064 |  dest_result_addr=1152921513251168072
            // 0x028B9108: STP d11, d10, [sp, #0x20]  | stack[1152921513251168080] = ???;  stack[1152921513251168088] = ???;  //  dest_result_addr=1152921513251168080 |  dest_result_addr=1152921513251168088
            // 0x028B910C: STP d9, d8, [sp, #0x30]    | stack[1152921513251168096] = ???;  stack[1152921513251168104] = ???;  //  dest_result_addr=1152921513251168096 |  dest_result_addr=1152921513251168104
            // 0x028B9110: STP x20, x19, [sp, #0x40]  | stack[1152921513251168112] = ???;  stack[1152921513251168120] = ???;  //  dest_result_addr=1152921513251168112 |  dest_result_addr=1152921513251168120
            // 0x028B9114: STP x29, x30, [sp, #0x50]  | stack[1152921513251168128] = ???;  stack[1152921513251168136] = ???;  //  dest_result_addr=1152921513251168128 |  dest_result_addr=1152921513251168136
            // 0x028B9118: ADD x29, sp, #0x50         | X29 = (1152921513251168048 + 80) = 1152921513251168128 (0x10000002033DDF80);
            // 0x028B911C: SUB sp, sp, #0x70          | SP = (1152921513251168048 - 112) = 1152921513251167936 (0x10000002033DDEC0);
            // 0x028B9120: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028B9124: LDRB w8, [x19, #0x91d]     | W8 = (bool)static_value_037B891D;       
            // 0x028B9128: MOV v8.16b, v6.16b         | V8 = size;//m1                          
            // 0x028B912C: MOV v15.16b, v2.16b        | V15 = col.r;//m1                        
            // 0x028B9130: MOV v10.16b, v1.16b        | V10 = p.y;//m1                          
            // 0x028B9134: MOV v12.16b, v0.16b        | V12 = p.x;//m1                          
            // 0x028B9138: STR s5, [sp, #0x28]        | stack[1152921513251167976] = col.a;      //  dest_result_addr=1152921513251167976
            // 0x028B913C: STR s4, [sp, #0x24]        | stack[1152921513251167972] = col.b;      //  dest_result_addr=1152921513251167972
            // 0x028B9140: STR s3, [sp, #0x2c]        | stack[1152921513251167980] = col.g;      //  dest_result_addr=1152921513251167980
            // 0x028B9144: TBNZ w8, #0, #0x28b9160    | if (static_value_037B891D == true) goto label_0;
            // 0x028B9148: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x028B914C: LDR x8, [x8, #0xe40]       | X8 = 0x2B8AAB0;                         
            // 0x028B9150: LDR w0, [x8]               | W0 = 0x16A;                             
            // 0x028B9154: BL #0x2782188              | X0 = sub_2782188( ?? 0x16A, ????);      
            // 0x028B9158: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B915C: STRB w8, [x19, #0x91d]     | static_value_037B891D = true;            //  dest_result_addr=58427677
            label_0:
            // 0x028B9160: FMOV s0, #0.50000000       | S0 = 0.5;                               
            // 0x028B9164: FMUL s14, s8, s0           | S14 = (size * 0.5f);                    
            float val_1 = size * 0.5f;
            // 0x028B9168: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B916C: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028B9170: ADD x0, sp, #0x60          | X0 = (1152921513251167936 + 96) = 1152921513251168032 (0x10000002033DDF20);
            // 0x028B9174: MOV v0.16b, v12.16b        | V0 = p.x;//m1                           
            // 0x028B9178: MOV v2.16b, v10.16b        | V2 = p.y;//m1                           
            // 0x028B917C: STR wzr, [sp, #0x68]       | stack[1152921513251168040] = 0x0;        //  dest_result_addr=1152921513251168040
            // 0x028B9180: STR xzr, [sp, #0x60]       | stack[1152921513251168032] = 0x0;        //  dest_result_addr=1152921513251168032
            // 0x028B9184: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B9188: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x028B918C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x028B9190: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x028B9194: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x028B9198: TBZ w8, #0, #0x28b91a8     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028B919C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x028B91A0: CBNZ w8, #0x28b91a8        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028B91A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x028B91A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B91AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B91B0: BL #0x2693b08              | X0 = UnityEngine.Vector3.get_right();   
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.right;
            // 0x028B91B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B91B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B91BC: MOV v3.16b, v14.16b        | V3 = (size * 0.5f);//m1                 
            // 0x028B91C0: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, d:  val_1);
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, d:  val_1);
            // 0x028B91C4: MOV v3.16b, v0.16b         | V3 = val_3.x;//m1                       
            // 0x028B91C8: MOV v4.16b, v1.16b         | V4 = val_3.y;//m1                       
            // 0x028B91CC: LDP s0, s1, [sp, #0x60]    | S0 = 0; S1 = 0;                          //  | 
            // 0x028B91D0: LDR s5, [sp, #0x68]        | S5 = 0;                                 
            // 0x028B91D4: MOV v6.16b, v2.16b         | V6 = val_3.z;//m1                       
            // 0x028B91D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B91DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B91E0: MOV v2.16b, v5.16b         | V2 = 0 (0x0);//ML01                     
            // 0x028B91E4: MOV v5.16b, v6.16b         | V5 = val_3.z;//m1                       
            // 0x028B91E8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            UnityEngine.Vector3 val_4 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            // 0x028B91EC: STP s1, s0, [sp, #0x14]    | stack[1152921513251167956] = val_4.y;  stack[1152921513251167960] = val_4.x;  //  dest_result_addr=1152921513251167956 |  dest_result_addr=1152921513251167960
            // 0x028B91F0: MOV v9.16b, v2.16b         | V9 = val_4.z;//m1                       
            // 0x028B91F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B91F8: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028B91FC: ADD x0, sp, #0x50          | X0 = (1152921513251167936 + 80) = 1152921513251168016 (0x10000002033DDF10);
            // 0x028B9200: MOV v0.16b, v12.16b        | V0 = p.x;//m1                           
            // 0x028B9204: MOV v2.16b, v10.16b        | V2 = p.y;//m1                           
            // 0x028B9208: STR wzr, [sp, #0x58]       | stack[1152921513251168024] = 0x0;        //  dest_result_addr=1152921513251168024
            // 0x028B920C: STR xzr, [sp, #0x50]       | stack[1152921513251168016] = 0x0;        //  dest_result_addr=1152921513251168016
            // 0x028B9210: STR s10, [sp, #0x20]       | stack[1152921513251167968] = p.y;        //  dest_result_addr=1152921513251167968
            // 0x028B9214: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B9218: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B921C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9220: BL #0x2693b08              | X0 = UnityEngine.Vector3.get_right();   
            UnityEngine.Vector3 val_5 = UnityEngine.Vector3.right;
            // 0x028B9224: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B922C: MOV v3.16b, v14.16b        | V3 = (size * 0.5f);//m1                 
            // 0x028B9230: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, d:  val_1);
            UnityEngine.Vector3 val_6 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, d:  val_1);
            // 0x028B9234: MOV v3.16b, v0.16b         | V3 = val_6.x;//m1                       
            // 0x028B9238: MOV v4.16b, v1.16b         | V4 = val_6.y;//m1                       
            // 0x028B923C: LDP s0, s1, [sp, #0x50]    | S0 = 0; S1 = 0;                          //  | 
            // 0x028B9240: LDR s5, [sp, #0x58]        | S5 = 0;                                 
            // 0x028B9244: MOV v6.16b, v2.16b         | V6 = val_6.z;//m1                       
            // 0x028B9248: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B924C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9250: MOV v2.16b, v5.16b         | V2 = 0 (0x0);//ML01                     
            // 0x028B9254: MOV v5.16b, v6.16b         | V5 = val_6.z;//m1                       
            // 0x028B9258: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
            UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
            // 0x028B925C: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x028B9260: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x028B9264: MOV v10.16b, v0.16b        | V10 = val_7.x;//m1                      
            // 0x028B9268: MOV v11.16b, v1.16b        | V11 = val_7.y;//m1                      
            // 0x028B926C: MOV v8.16b, v2.16b         | V8 = val_7.z;//m1                       
            // 0x028B9270: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x028B9274: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x028B9278: TBZ w8, #0, #0x28b9288     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x028B927C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x028B9280: CBNZ w8, #0x28b9288        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x028B9284: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_4:
            // 0x028B9288: LDR s0, [sp, #0x2c]        | S0 = col.g;                             
            // 0x028B928C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9290: MOV v2.16b, v9.16b         | V2 = val_4.z;//m1                       
            // 0x028B9294: MOV v3.16b, v10.16b        | V3 = val_7.x;//m1                       
            // 0x028B9298: STP s15, s0, [sp]          | stack[1152921513251167936] = col.r;  stack[1152921513251167940] = col.g;  //  dest_result_addr=1152921513251167936 |  dest_result_addr=1152921513251167940
            // 0x028B929C: LDR s13, [sp, #0x24]       | S13 = col.b;                            
            // 0x028B92A0: STR s15, [sp, #0x1c]       | stack[1152921513251167964] = col.r;      //  dest_result_addr=1152921513251167964
            // 0x028B92A4: LDR s15, [sp, #0x28]       | S15 = col.a;                            
            // 0x028B92A8: MOV v4.16b, v11.16b        | V4 = val_7.y;//m1                       
            // 0x028B92AC: MOV v5.16b, v8.16b         | V5 = val_7.z;//m1                       
            // 0x028B92B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B92B4: STP s13, s15, [sp, #8]     | stack[1152921513251167944] = col.b;  stack[1152921513251167948] = col.a;  //  dest_result_addr=1152921513251167944 |  dest_result_addr=1152921513251167948
            // 0x028B92B8: LDP s1, s0, [sp, #0x14]    | S1 = val_4.y; S0 = val_4.x;              //  | 
            // 0x028B92BC: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, end:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, color:  new UnityEngine.Color() {r = col.r, g = col.b, a = val_4.x});
            UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, end:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, color:  new UnityEngine.Color() {r = col.r, g = col.b, a = val_4.x});
            // 0x028B92C0: LDR s8, [sp, #0x20]        | S8 = p.y;                               
            // 0x028B92C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B92C8: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028B92CC: ADD x0, sp, #0x40          | X0 = (1152921513251167936 + 64) = 1152921513251168000 (0x10000002033DDF00);
            // 0x028B92D0: MOV v0.16b, v12.16b        | V0 = p.x;//m1                           
            // 0x028B92D4: MOV v2.16b, v8.16b         | V2 = p.y;//m1                           
            // 0x028B92D8: STR wzr, [sp, #0x48]       | stack[1152921513251168008] = 0x0;        //  dest_result_addr=1152921513251168008
            // 0x028B92DC: STR xzr, [sp, #0x40]       | stack[1152921513251168000] = 0x0;        //  dest_result_addr=1152921513251168000
            // 0x028B92E0: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B92E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B92E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B92EC: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
            UnityEngine.Vector3 val_8 = UnityEngine.Vector3.forward;
            // 0x028B92F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B92F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B92F8: MOV v3.16b, v14.16b        | V3 = (size * 0.5f);//m1                 
            // 0x028B92FC: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, d:  val_1);
            UnityEngine.Vector3 val_9 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, d:  val_1);
            // 0x028B9300: MOV v3.16b, v0.16b         | V3 = val_9.x;//m1                       
            // 0x028B9304: MOV v4.16b, v1.16b         | V4 = val_9.y;//m1                       
            // 0x028B9308: LDP s0, s1, [sp, #0x40]    | S0 = 0; S1 = 0;                          //  | 
            // 0x028B930C: LDR s5, [sp, #0x48]        | S5 = 0;                                 
            // 0x028B9310: MOV v6.16b, v2.16b         | V6 = val_9.z;//m1                       
            // 0x028B9314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9318: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B931C: MOV v2.16b, v5.16b         | V2 = 0 (0x0);//ML01                     
            // 0x028B9320: MOV v5.16b, v6.16b         | V5 = val_9.z;//m1                       
            // 0x028B9324: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
            UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
            // 0x028B9328: MOV v9.16b, v0.16b         | V9 = val_10.x;//m1                      
            // 0x028B932C: MOV v10.16b, v1.16b        | V10 = val_10.y;//m1                     
            // 0x028B9330: MOV v11.16b, v2.16b        | V11 = val_10.z;//m1                     
            // 0x028B9334: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9338: ADD x0, sp, #0x30          | X0 = (1152921513251167936 + 48) = 1152921513251167984 (0x10000002033DDEF0);
            // 0x028B933C: MOV v0.16b, v12.16b        | V0 = p.x;//m1                           
            // 0x028B9340: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028B9344: MOV v2.16b, v8.16b         | V2 = p.y;//m1                           
            // 0x028B9348: STR wzr, [sp, #0x38]       | stack[1152921513251167992] = 0x0;        //  dest_result_addr=1152921513251167992
            // 0x028B934C: STR xzr, [sp, #0x30]       | stack[1152921513251167984] = 0x0;        //  dest_result_addr=1152921513251167984
            // 0x028B9350: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028B9354: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9358: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B935C: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
            UnityEngine.Vector3 val_11 = UnityEngine.Vector3.forward;
            // 0x028B9360: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9364: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9368: MOV v3.16b, v14.16b        | V3 = (size * 0.5f);//m1                 
            // 0x028B936C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, d:  val_1);
            UnityEngine.Vector3 val_12 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, d:  val_1);
            // 0x028B9370: MOV v3.16b, v0.16b         | V3 = val_12.x;//m1                      
            // 0x028B9374: MOV v4.16b, v1.16b         | V4 = val_12.y;//m1                      
            // 0x028B9378: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
            // 0x028B937C: LDR s5, [sp, #0x38]        | S5 = 0;                                 
            // 0x028B9380: MOV v6.16b, v2.16b         | V6 = val_12.z;//m1                      
            // 0x028B9384: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9388: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B938C: MOV v2.16b, v5.16b         | V2 = 0 (0x0);//ML01                     
            // 0x028B9390: MOV v5.16b, v6.16b         | V5 = val_12.z;//m1                      
            // 0x028B9394: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z});
            UnityEngine.Vector3 val_13 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z});
            // 0x028B9398: STP s13, s15, [sp, #8]     | stack[1152921513251167944] = col.b;  stack[1152921513251167948] = col.a;  //  dest_result_addr=1152921513251167944 |  dest_result_addr=1152921513251167948
            // 0x028B939C: MOV v3.16b, v0.16b         | V3 = val_13.x;//m1                      
            // 0x028B93A0: LDR s0, [sp, #0x2c]        | S0 = col.g;                             
            // 0x028B93A4: MOV v4.16b, v1.16b         | V4 = val_13.y;//m1                      
            // 0x028B93A8: MOV v5.16b, v2.16b         | V5 = val_13.z;//m1                      
            // 0x028B93AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B93B0: STR s0, [sp, #4]           | stack[1152921513251167940] = col.g;      //  dest_result_addr=1152921513251167940
            // 0x028B93B4: LDR s0, [sp, #0x1c]        | S0 = col.r;                             
            // 0x028B93B8: MOV v1.16b, v10.16b        | V1 = val_10.y;//m1                      
            // 0x028B93BC: MOV v2.16b, v11.16b        | V2 = val_10.z;//m1                      
            // 0x028B93C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B93C4: STR s0, [sp]               | stack[1152921513251167936] = col.r;      //  dest_result_addr=1152921513251167936
            // 0x028B93C8: MOV v0.16b, v9.16b         | V0 = val_10.x;//m1                      
            // 0x028B93CC: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, end:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, color:  new UnityEngine.Color() {r = col.r, g = col.b, a = val_4.x});
            UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, end:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, color:  new UnityEngine.Color() {r = col.r, g = col.b, a = val_4.x});
            // 0x028B93D0: SUB sp, x29, #0x50         | SP = (1152921513251168128 - 80) = 1152921513251168048 (0x10000002033DDF30);
            // 0x028B93D4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028B93D8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028B93DC: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x028B93E0: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x028B93E4: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x028B93E8: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x028B93EC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028B93F0 (42701808), len: 9464  VirtAddr: 0x028B93F0 RVA: 0x028B93F0 token: 100682492 methodIndex: 51104 delegateWrapperIndex: 0 methodInvoker: 0
        internal void CalculateVelocity(Pathfinding.RVO.Simulator.WorkerContext context)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.RVO.Simulator val_140;
            //  | 
            Pathfinding.RVO.Sampled.Agent val_141;
            //  | 
            var val_142;
            //  | 
            var val_143;
            //  | 
            var val_144;
            //  | 
            var val_145;
            //  | 
            var val_146;
            //  | 
            var val_147;
            //  | 
            var val_148;
            //  | 
            var val_149;
            //  | 
            float val_150;
            //  | 
            var val_151;
            //  | 
            var val_152;
            //  | 
            float val_153;
            //  | 
            float val_154;
            //  | 
            float val_155;
            //  | 
            var val_156;
            //  | 
            var val_157;
            //  | 
            float val_158;
            //  | 
            var val_159;
            //  | 
            var val_160;
            //  | 
            float val_161;
            //  | 
            float val_162;
            //  | 
            var val_163;
            //  | 
            float val_164;
            //  | 
            var val_165;
            //  | 
            var val_166;
            //  | 
            var val_167;
            //  | 
            var val_168;
            //  | 
            var val_169;
            //  | 
            var val_170;
            //  | 
            var val_171;
            //  | 
            var val_172;
            //  | 
            float val_173;
            //  | 
            float val_174;
            //  | 
            var val_175;
            //  | 
            var val_176;
            //  | 
            var val_177;
            //  | 
            float val_178;
            //  | 
            var val_179;
            //  | 
            var val_180;
            // 0x028B93F0: STP d15, d14, [sp, #-0xa0]! | stack[1152921513251505264] = ???;  stack[1152921513251505272] = ???;  //  dest_result_addr=1152921513251505264 |  dest_result_addr=1152921513251505272
            // 0x028B93F4: STP d13, d12, [sp, #0x10]  | stack[1152921513251505280] = ???;  stack[1152921513251505288] = ???;  //  dest_result_addr=1152921513251505280 |  dest_result_addr=1152921513251505288
            // 0x028B93F8: STP d11, d10, [sp, #0x20]  | stack[1152921513251505296] = ???;  stack[1152921513251505304] = ???;  //  dest_result_addr=1152921513251505296 |  dest_result_addr=1152921513251505304
            // 0x028B93FC: STP d9, d8, [sp, #0x30]    | stack[1152921513251505312] = ???;  stack[1152921513251505320] = ???;  //  dest_result_addr=1152921513251505312 |  dest_result_addr=1152921513251505320
            // 0x028B9400: STP x28, x27, [sp, #0x40]  | stack[1152921513251505328] = ???;  stack[1152921513251505336] = ???;  //  dest_result_addr=1152921513251505328 |  dest_result_addr=1152921513251505336
            // 0x028B9404: STP x26, x25, [sp, #0x50]  | stack[1152921513251505344] = ???;  stack[1152921513251505352] = ???;  //  dest_result_addr=1152921513251505344 |  dest_result_addr=1152921513251505352
            // 0x028B9408: STP x24, x23, [sp, #0x60]  | stack[1152921513251505360] = ???;  stack[1152921513251505368] = ???;  //  dest_result_addr=1152921513251505360 |  dest_result_addr=1152921513251505368
            // 0x028B940C: STP x22, x21, [sp, #0x70]  | stack[1152921513251505376] = ???;  stack[1152921513251505384] = ???;  //  dest_result_addr=1152921513251505376 |  dest_result_addr=1152921513251505384
            // 0x028B9410: STP x20, x19, [sp, #0x80]  | stack[1152921513251505392] = ???;  stack[1152921513251505400] = ???;  //  dest_result_addr=1152921513251505392 |  dest_result_addr=1152921513251505400
            // 0x028B9414: STP x29, x30, [sp, #0x90]  | stack[1152921513251505408] = ???;  stack[1152921513251505416] = ???;  //  dest_result_addr=1152921513251505408 |  dest_result_addr=1152921513251505416
            // 0x028B9418: ADD x29, sp, #0x90         | X29 = (1152921513251505264 + 144) = 1152921513251505408 (0x1000000203430500);
            // 0x028B941C: SUB sp, sp, #0x1d0         | SP = (1152921513251505264 - 464) = 1152921513251504800 (0x10000002034302A0);
            // 0x028B9420: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028B9424: LDRB w8, [x19, #0x91e]     | W8 = (bool)static_value_037B891E;       
            // 0x028B9428: MOV x22, x1                | X22 = context;//m1                      
            // 0x028B942C: MOV x25, x0                | X25 = 1152921513251517424 (0x10000002034333F0);//ML01
            val_141 = this;
            // 0x028B9430: TBNZ w8, #0, #0x28b944c    | if (static_value_037B891E == true) goto label_0;
            // 0x028B9434: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x028B9438: LDR x8, [x8, #0xba8]       | X8 = 0x2B8AAA0;                         
            // 0x028B943C: LDR w0, [x8]               | W0 = 0x166;                             
            // 0x028B9440: BL #0x2782188              | X0 = sub_2782188( ?? 0x166, ????);      
            // 0x028B9444: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028B9448: STRB w8, [x19, #0x91e]     | static_value_037B891E = true;            //  dest_result_addr=58427678
            label_0:
            // 0x028B944C: STP xzr, xzr, [x29, #-0xa0] | stack[1152921513251505248] = 0x0;  stack[1152921513251505256] = 0x0;  //  dest_result_addr=1152921513251505248 |  dest_result_addr=1152921513251505256
            // 0x028B9450: STP xzr, xzr, [x29, #-0xb0] | stack[1152921513251505232] = 0x0;  stack[1152921513251505240] = 0x0;  //  dest_result_addr=1152921513251505232 |  dest_result_addr=1152921513251505240
            // 0x028B9454: STP xzr, xzr, [x29, #-0xc0] | stack[1152921513251505216] = 0x0;  stack[1152921513251505224] = 0x0;  //  dest_result_addr=1152921513251505216 |  dest_result_addr=1152921513251505224
            // 0x028B9458: STUR xzr, [x29, #-0xc8]    | stack[1152921513251505208] = 0x0;        //  dest_result_addr=1152921513251505208
            // 0x028B945C: STUR wzr, [x29, #-0xcc]    | stack[1152921513251505204] = 0x0;        //  dest_result_addr=1152921513251505204
            // 0x028B9460: STUR xzr, [x29, #-0xd8]    | stack[1152921513251505192] = 0x0;        //  dest_result_addr=1152921513251505192
            // 0x028B9464: STUR wzr, [x29, #-0xdc]    | stack[1152921513251505188] = 0x0;        //  dest_result_addr=1152921513251505188
            // 0x028B9468: STUR xzr, [x29, #-0xe8]    | stack[1152921513251505176] = 0x0;        //  dest_result_addr=1152921513251505176
            // 0x028B946C: STUR wzr, [x29, #-0xec]    | stack[1152921513251505172] = 0x0;        //  dest_result_addr=1152921513251505172
            // 0x028B9470: STUR xzr, [x29, #-0xf8]    | stack[1152921513251505160] = 0x0;        //  dest_result_addr=1152921513251505160
            // 0x028B9474: STUR wzr, [x29, #-0xfc]    | stack[1152921513251505156] = 0x0;        //  dest_result_addr=1152921513251505156
            // 0x028B9478: STR xzr, [sp, #0x158]      | stack[1152921513251505144] = 0x0;        //  dest_result_addr=1152921513251505144
            // 0x028B947C: STR wzr, [sp, #0x150]      | stack[1152921513251505136] = 0x0;        //  dest_result_addr=1152921513251505136
            // 0x028B9480: STP xzr, xzr, [sp, #0x140] | stack[1152921513251505120] = 0x0;  stack[1152921513251505128] = 0x0;  //  dest_result_addr=1152921513251505120 |  dest_result_addr=1152921513251505128
            // 0x028B9484: STR xzr, [sp, #0x138]      | stack[1152921513251505112] = 0x0;        //  dest_result_addr=1152921513251505112
            // 0x028B9488: LDRB w8, [x25, #0x50]      | W8 = this.locked; //P2                  
            // 0x028B948C: CBZ w8, #0x28b94d4         | if (this.locked == false) goto label_1; 
            if(this.locked == false)
            {
                goto label_1;
            }
            // 0x028B9490: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B9494: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028B9498: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B949C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B94A0: TBZ w8, #0, #0x28b94b0     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028B94A4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B94A8: CBNZ w8, #0x28b94b0        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028B94AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_3:
            // 0x028B94B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B94B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B94B8: BL #0x2697648              | X0 = UnityEngine.Vector2.get_zero();    
            UnityEngine.Vector2 val_1 = UnityEngine.Vector2.zero;
            // 0x028B94BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B94C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B94C4: BL #0x269840c              | X0 = UnityEngine.Vector2.op_Implicit(v:  new UnityEngine.Vector2() {x = val_1.x, y = val_1.y});
            UnityEngine.Vector3 val_2 = UnityEngine.Vector2.op_Implicit(v:  new UnityEngine.Vector2() {x = val_1.x, y = val_1.y});
            // 0x028B94C8: STP s0, s1, [x25, #0xd4]   | this.newVelocity = val_2;  mem[1152921513251517640] = val_2.y;  //  dest_result_addr=1152921513251517636 |  dest_result_addr=1152921513251517640
            this.newVelocity = val_2;
            mem[1152921513251517640] = val_2.y;
            // 0x028B94CC: STR s2, [x25, #0xdc]       | mem[1152921513251517644] = val_2.z;      //  dest_result_addr=1152921513251517644
            mem[1152921513251517644] = val_2.z;
            // 0x028B94D0: B #0x28bb8b4               |  goto label_4;                          
            goto label_4;
            label_1:
            // 0x028B94D4: CBNZ x22, #0x28b94dc       | if (context != null) goto label_5;      
            if(context != null)
            {
                goto label_5;
            }
            // 0x028B94D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x166, ????);      
            label_5:
            // 0x028B94DC: LDR x23, [x22, #0x10]      | X23 = context.vos; //P2                 
            // 0x028B94E0: CBNZ x23, #0x28b94e8       | if (context.vos != null) goto label_6;  
            if(context.vos != null)
            {
                goto label_6;
            }
            // 0x028B94E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x166, ????);      
            label_6:
            // 0x028B94E8: LDR x20, [x25, #0xe8]      | X20 = this.neighbours; //P2             
            // 0x028B94EC: CBNZ x20, #0x28b94f4       | if (this.neighbours != null) goto label_7;
            if(this.neighbours != null)
            {
                goto label_7;
            }
            // 0x028B94F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x166, ????);      
            label_7:
            // 0x028B94F4: ADRP x28, #0x364d000       | X28 = 56938496 (0x364D000);             
            // 0x028B94F8: LDR x28, [x28, #0x6d8]     | X28 = 1152921513250141744;              
            val_142 = 1152921513250141744;
            // 0x028B94FC: MOV x0, x20                | X0 = this.neighbours;//m1               
            // 0x028B9500: LDR x1, [x28]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::get_Count();
            // 0x028B9504: BL #0x25ed72c              | X0 = this.neighbours.get_Count();       
            int val_3 = this.neighbours.Count;
            // 0x028B9508: LDR x19, [x25, #0xe0]      | X19 = this.simulator; //P2              
            // 0x028B950C: MOV w20, w0                | W20 = val_3;//m1                        
            // 0x028B9510: CBNZ x19, #0x28b9518       | if (this.simulator != null) goto label_8;
            if(this.simulator != null)
            {
                goto label_8;
            }
            // 0x028B9514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_8:
            // 0x028B9518: LDR x21, [x19, #0x30]      | X21 = this.simulator.obstacles; //P2    
            // 0x028B951C: CBNZ x21, #0x28b9524       | if (this.simulator.obstacles != null) goto label_9;
            if(this.simulator.obstacles != null)
            {
                goto label_9;
            }
            // 0x028B9520: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x028B9524: ADRP x19, #0x35f9000       | X19 = 56594432 (0x35F9000);             
            // 0x028B9528: LDR x19, [x19, #0xda0]     | X19 = 1152921513250403248;              
            // 0x028B952C: MOV x0, x21                | X0 = this.simulator.obstacles;//m1      
            // 0x028B9530: LDR x1, [x19]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::get_Count();
            // 0x028B9534: BL #0x25ed72c              | X0 = this.simulator.obstacles.get_Count();
            int val_4 = this.simulator.obstacles.Count;
            // 0x028B9538: LDR w8, [x23, #0x18]       | W8 = context.vos.Length; //P2           
            // 0x028B953C: ADD w9, w0, w20            | W9 = (val_4 + val_3);                   
            int val_5 = val_4 + val_3;
            // 0x028B9540: CMP w8, w9                 | STATE = COMPARE(context.vos.Length, (val_4 + val_3))
            // 0x028B9544: B.GE #0x28b960c            | if (context.vos.Length >= val_5) goto label_10;
            if(context.vos.Length >= val_5)
            {
                goto label_10;
            }
            // 0x028B9548: CBNZ x22, #0x28b9550       | if (context != null) goto label_11;     
            if(context != null)
            {
                goto label_11;
            }
            // 0x028B954C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_11:
            // 0x028B9550: LDR x23, [x22, #0x10]      | X23 = context.vos; //P2                 
            // 0x028B9554: CBNZ x23, #0x28b955c       | if (context.vos != null) goto label_12; 
            if(context.vos != null)
            {
                goto label_12;
            }
            // 0x028B9558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x028B955C: LDR x20, [x25, #0xe8]      | X20 = this.neighbours; //P2             
            // 0x028B9560: CBNZ x20, #0x28b9568       | if (this.neighbours != null) goto label_13;
            if(this.neighbours != null)
            {
                goto label_13;
            }
            // 0x028B9564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_13:
            // 0x028B9568: LDR x1, [x28]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::get_Count();
            // 0x028B956C: MOV x0, x20                | X0 = this.neighbours;//m1               
            // 0x028B9570: BL #0x25ed72c              | X0 = this.neighbours.get_Count();       
            int val_6 = this.neighbours.Count;
            // 0x028B9574: LDR x21, [x25, #0xe0]      | X21 = this.simulator; //P2              
            // 0x028B9578: MOV w20, w0                | W20 = val_6;//m1                        
            // 0x028B957C: CBNZ x21, #0x28b9584       | if (this.simulator != null) goto label_14;
            if(this.simulator != null)
            {
                goto label_14;
            }
            // 0x028B9580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_14:
            // 0x028B9584: LDR x21, [x21, #0x30]      | X21 = this.simulator.obstacles; //P2    
            // 0x028B9588: CBNZ x21, #0x28b9590       | if (this.simulator.obstacles != null) goto label_15;
            if(this.simulator.obstacles != null)
            {
                goto label_15;
            }
            // 0x028B958C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_15:
            // 0x028B9590: LDR x1, [x19]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::get_Count();
            // 0x028B9594: MOV x0, x21                | X0 = this.simulator.obstacles;//m1      
            // 0x028B9598: BL #0x25ed72c              | X0 = this.simulator.obstacles.get_Count();
            int val_7 = this.simulator.obstacles.Count;
            // 0x028B959C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028B95A0: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x028B95A4: MOV w21, w0                | W21 = val_7;//m1                        
            // 0x028B95A8: LDR x8, [x8]               | X8 = typeof(UnityEngine.Mathf);         
            // 0x028B95AC: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028B95B0: TBZ w9, #0, #0x28b95c4     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x028B95B4: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028B95B8: CBNZ w9, #0x28b95c4        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x028B95BC: MOV x0, x8                 | X0 = 1152921504695345152 (0x1000000005466000);//ML01
            // 0x028B95C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_17:
            // 0x028B95C4: LDR w8, [x23, #0x18]       | W8 = context.vos.Length; //P2           
            // 0x028B95C8: ADD w2, w21, w20           | W2 = (val_7 + val_6);                   
            int val_8 = val_7 + val_6;
            // 0x028B95CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B95D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028B95D4: LSL w1, w8, #1             | W1 = (context.vos.Length << 1);         
            int val_9 = context.vos.Length << 1;
            // 0x028B95D8: BL #0x1a7da0c              | X0 = UnityEngine.Mathf.Max(a:  0, b:  int val_9 = context.vos.Length << 1);
            int val_10 = UnityEngine.Mathf.Max(a:  0, b:  val_9);
            // 0x028B95DC: MOV w20, w0                | W20 = val_10;//m1                       
            // 0x028B95E0: CBNZ x22, #0x28b95e8       | if (context != null) goto label_18;     
            if(context != null)
            {
                goto label_18;
            }
            // 0x028B95E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_18:
            // 0x028B95E8: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x028B95EC: LDR x8, [x8, #0xcf0]       | X8 = 1152921507456632288;               
            // 0x028B95F0: LDR x21, [x8]              | X21 = typeof(VO[]);                     
            // 0x028B95F4: MOV x0, x21                | X0 = 1152921507456632288 (0x10000000A9DC45E0);//ML01
            // 0x028B95F8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(VO[]), ????);
            // 0x028B95FC: MOV w1, w20                | W1 = val_10;//m1                        
            // 0x028B9600: MOV x0, x21                | X0 = 1152921507456632288 (0x10000000A9DC45E0);//ML01
            // 0x028B9604: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(VO[]), ????);
            // 0x028B9608: STR x0, [x22, #0x10]       | context.vos = typeof(VO[]);              //  dest_result_addr=0
            context.vos = null;
            label_10:
            // 0x028B960C: LDR s0, [x25, #0x60]       | S0 = this.position; //P2                
            // 0x028B9610: LDR s1, [x25, #0x68]       | 
            // 0x028B9614: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9618: SUB x0, x29, #0x98         | X0 = (1152921513251505408 - 152) = 1152921513251505256 (0x1000000203430468);
            // 0x028B961C: BL #0x2697148              | null..ctor(_x:  this.position, _y:  null);
            Geometric.Point val_11 = new Geometric.Point(_x:  this.position, _y:  null);
            // 0x028B9620: CBNZ x22, #0x28b9628       | if (context != null) goto label_19;     
            if(context != null)
            {
                goto label_19;
            }
            // 0x028B9624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  this.position, _y:  null), ????);
            label_19:
            // 0x028B9628: LDR s0, [x25, #0xc8]       | S0 = this.velocity; //P2                
            // 0x028B962C: LDR s1, [x25, #0xd0]       | 
            // 0x028B9630: LDR x20, [x22, #0x10]      | X20 = context.vos; //P2                 
            // 0x028B9634: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9638: SUB x0, x29, #0xa0         | X0 = (1152921513251505408 - 160) = 1152921513251505248 (0x1000000203430460);
            // 0x028B963C: STR x22, [sp, #0x98]       | stack[1152921513251504952] = context;    //  dest_result_addr=1152921513251504952
            // 0x028B9640: BL #0x2697148              | null..ctor(_x:  this.velocity, _y:  null);
            Geometric.Point val_12 = new Geometric.Point(_x:  this.velocity, _y:  null);
            // 0x028B9644: LDR x21, [x25, #0xe0]      | X21 = this.simulator; //P2              
            // 0x028B9648: LDR s8, [x25, #0x44]       | S8 = this.agentTimeHorizon; //P2        
            // 0x028B964C: MOV x8, x21                | X8 = this.simulator;//m1                
            // 0x028B9650: CBNZ x21, #0x28b9660       | if (this.simulator != null) goto label_20;
            if(this.simulator != null)
            {
                goto label_20;
            }
            // 0x028B9654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  this.velocity, _y:  null), ????);
            // 0x028B9658: LDR x8, [x25, #0xe0]       | X8 = this.simulator; //P2               
            // 0x028B965C: CBZ x8, #0x28bb8e4         | if (this.simulator == null) goto label_62;
            if(this.simulator == null)
            {
                goto label_62;
            }
            label_20:
            // 0x028B9660: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
            // 0x028B9664: STR x9, [sp, #0xc0]        | stack[1152921513251504992] = 0x0;        //  dest_result_addr=1152921513251504992
            // 0x028B9668: LDR w8, [x8, #0x38]        | W8 = this.simulator.algorithm; //P2     
            // 0x028B966C: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x028B9670: LDR s0, [x21, #0x64]       | S0 = this.simulator.wallThickness; //P2 
            float val_161 = this.simulator.wallThickness;
            // 0x028B9674: LDR s1, [x9, #0x950]       | S1 = 0.05;                              
            float val_163 = 0.05f;
            // 0x028B9678: FMOV s2, #1.00000000       | S2 = 1;                                 
            // 0x028B967C: ADRP x21, #0x35f8000       | X21 = 56590336 (0x35F8000);             
            // 0x028B9680: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            // 0x028B9684: FMOV s3, #5.00000000       | S3 = 5;                                 
            // 0x028B9688: LDR x21, [x21, #0xc28]     | X21 = 1152921513250404272;              
            val_144 = 1152921513250404272;
            // 0x028B968C: FDIV s4, s2, s8            | S4 = (1f / this.agentTimeHorizon);      
            float val_13 = 1f / this.agentTimeHorizon;
            // 0x028B9690: CMP w8, #1                 | STATE = COMPARE(this.simulator.algorithm, 0x1)
            // 0x028B9694: STR s4, [sp, #0xb0]        | stack[1152921513251504976] = (1f / this.agentTimeHorizon);  //  dest_result_addr=1152921513251504976
            // 0x028B9698: FNEG s4, s0                | S4 = -(this.simulator.wallThickness);   
            // 0x028B969C: FCSEL s2, s2, s3, eq       | S2 = this.simulator.algorithm == 0x1 ? 1f : 5f;
            float val_14 = (this.simulator.algorithm == 1) ? (1f) : (5f);
            // 0x028B96A0: FMUL s0, s0, s1            | S0 = (this.simulator.wallThickness * 0.05f);
            val_161 = val_161 * val_163;
            // 0x028B96A4: STR s0, [sp, #0xc8]        | stack[1152921513251505000] = (this.simulator.wallThickness * 0.05f);  //  dest_result_addr=1152921513251505000
            // 0x028B96A8: FADD s0, s2, s2            | S0 = (this.simulator.algorithm == 0x1 ? 1f : 5f + this.simulator.algorithm == 0x1 ? 1f : 5f);
            float val_15 = val_14 + val_14;
            // 0x028B96AC: STR s4, [sp, #0xbc]        | stack[1152921513251504988] = this.simulator.wallThickness;  //  dest_result_addr=1152921513251504988
            // 0x028B96B0: STR s2, [sp, #0xa0]        | stack[1152921513251504960] = this.simulator.algorithm == 0x1 ? 1f : 5f;  //  dest_result_addr=1152921513251504960
            // 0x028B96B4: STR s0, [sp, #0xac]        | stack[1152921513251504972] = (this.simulator.algorithm == 0x1 ? 1f : 5f + this.simulator.algorithm == 0x1 ? 1f : 5f);  //  dest_result_addr=1152921513251504972
            // 0x028B96B8: MOVZ w26, #0x50            | W26 = 80 (0x50);//ML01                  
            // 0x028B96BC: B #0x28b96c4               |  goto label_22;                         
            goto label_22;
            label_67:
            // 0x028B96C0: ADD w23, w23, #1           | W23 = (0 + 1) = 1 (0x00000001);         
            label_22:
            // 0x028B96C4: LDR x22, [x25, #0xe0]      | X22 = this.simulator; //P2              
            // 0x028B96C8: CBNZ x22, #0x28b96d0       | if (this.simulator != null) goto label_23;
            if(this.simulator != null)
            {
                goto label_23;
            }
            // 0x028B96CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  this.velocity, _y:  null), ????);
            label_23:
            // 0x028B96D0: LDR x24, [x22, #0x30]      | X24 = this.simulator.obstacles; //P2    
            // 0x028B96D4: CBNZ x24, #0x28b96dc       | if (this.simulator.obstacles != null) goto label_24;
            if(this.simulator.obstacles != null)
            {
                goto label_24;
            }
            // 0x028B96D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  this.velocity, _y:  null), ????);
            label_24:
            // 0x028B96DC: LDR x1, [x19]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::get_Count();
            // 0x028B96E0: MOV x0, x24                | X0 = this.simulator.obstacles;//m1      
            // 0x028B96E4: BL #0x25ed72c              | X0 = this.simulator.obstacles.get_Count();
            int val_16 = this.simulator.obstacles.Count;
            // 0x028B96E8: CMP w23, w0                | STATE = COMPARE(0x1, val_16)            
            // 0x028B96EC: B.GE #0x28b9b74            | if (1 >= val_16) goto label_25;         
            if(1 >= val_16)
            {
                goto label_25;
            }
            // 0x028B96F0: LDR x22, [x25, #0xe0]      | X22 = this.simulator; //P2              
            // 0x028B96F4: CBNZ x22, #0x28b96fc       | if (this.simulator != null) goto label_26;
            if(this.simulator != null)
            {
                goto label_26;
            }
            // 0x028B96F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_26:
            // 0x028B96FC: LDR x24, [x22, #0x30]      | X24 = this.simulator.obstacles; //P2    
            // 0x028B9700: CBNZ x24, #0x28b9708       | if (this.simulator.obstacles != null) goto label_27;
            if(this.simulator.obstacles != null)
            {
                goto label_27;
            }
            // 0x028B9704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_27:
            // 0x028B9708: LDR x2, [x21]              | X2 = public Pathfinding.RVO.ObstacleVertex System.Collections.Generic.List<Pathfinding.RVO.ObstacleVertex>::get_Item(int index);
            // 0x028B970C: MOV x0, x24                | X0 = this.simulator.obstacles;//m1      
            // 0x028B9710: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x028B9714: BL #0x25ed734              | X0 = this.simulator.obstacles.get_Item(index:  1);
            Pathfinding.RVO.ObstacleVertex val_17 = this.simulator.obstacles.Item[1];
            // 0x028B9718: MOV x24, x0                | X24 = val_17;//m1                       
            // 0x028B971C: MOV x27, x24               | X27 = val_17;//m1                       
            label_66:
            // 0x028B9720: CBNZ x27, #0x28b9728       | if (val_17 != null) goto label_28;      
            if(val_17 != null)
            {
                goto label_28;
            }
            // 0x028B9724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_28:
            // 0x028B9728: LDRB w8, [x27, #0x10]      | W8 = val_17.ignore; //P2                
            // 0x028B972C: CBNZ w8, #0x28b9b64        | if (val_17.ignore == true) goto label_65;
            if(val_17.ignore == true)
            {
                goto label_65;
            }
            // 0x028B9730: LDR s0, [x27, #0x18]       | 
            // 0x028B9734: LDR s2, [x27, #0x28]       | S2 = val_17.height; //P2                
            float val_162 = val_17.height;
            // 0x028B9738: LDR s1, [x25, #0x64]       | 
            // 0x028B973C: FADD s2, s0, s2            | S2 = ((this.simulator.algorithm == 0x1 ? 1f : 5f + this.simulator.algorithm == 0x1 ? 1f : 5f) + val_17.height);
            val_162 = val_15 + val_162;
            // 0x028B9740: FCMP s1, s2                | STATE = COMPARE(0.0500000007450581, ((this.simulator.algorithm == 0x1 ? 1f : 5f + this.simulator.algorithm == 0x1 ? 1f : 5f) + val_17.height))
            // 0x028B9744: B.GT #0x28b9b64            | if (0.05f > val_17.height) goto label_65;
            if(val_163 > val_162)
            {
                goto label_65;
            }
            // 0x028B9748: LDR s2, [x25, #0x38]       | S2 = this.height; //P2                  
            // 0x028B974C: FADD s1, s1, s2            | S1 = (0.05f + this.height);             
            val_163 = val_163 + this.height;
            // 0x028B9750: FCMP s1, s0                | STATE = COMPARE((0.05f + this.height), (this.simulator.algorithm == 0x1 ? 1f : 5f + this.simulator.algorithm == 0x1 ? 1f : 5f))
            // 0x028B9754: B.MI #0x28b9b64            | if (0.05f < 0) goto label_65;           
            if(val_163 < 0)
            {
                goto label_65;
            }
            // 0x028B9758: LDR w8, [x27, #0x2c]       | W8 = val_17.layer; //P2                 
            Pathfinding.RVO.RVOLayer val_164 = val_17.layer;
            // 0x028B975C: LDR w9, [x25, #0x58]       | W9 = this.collidesWith; //P2            
            // 0x028B9760: AND w8, w9, w8             | W8 = (this.collidesWith & val_17.layer);
            val_164 = this.collidesWith & val_164;
            // 0x028B9764: CBZ w8, #0x28b9b64         | if ((this.collidesWith & val_17.layer) == 0) goto label_65;
            if(val_164 == 0)
            {
                goto label_65;
            }
            // 0x028B9768: LDR s0, [x27, #0x14]       | S0 = val_17.position; //P2              
            // 0x028B976C: LDR s1, [x27, #0x1c]       | 
            // 0x028B9770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9774: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B9778: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028B977C: BL #0x2697148              | null..ctor(_x:  val_17.position, _y:  0.05f = 0.05f + this.height);
            Geometric.Point val_18 = new Geometric.Point(_x:  val_17.position, _y:  val_163);
            // 0x028B9780: LDP s11, s10, [x27, #0x20] | S11 = val_17.dir; //P2                   //  | 
            // 0x028B9784: LDR s1, [x27, #0x1c]       | 
            // 0x028B9788: LDP s12, s13, [x29, #-0x98] | S12 = val_11.x; S13 = val_11.y;          //  | 
            // 0x028B978C: LDP s9, s15, [sp, #0xe0]   | S9 = val_18.x; S15 = val_18.y;           //  | 
            // 0x028B9790: LDR s0, [x27, #0x14]       | S0 = val_17.position; //P2              
            // 0x028B9794: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9798: ADD x0, sp, #0x130         | X0 = (1152921513251504800 + 304) = 1152921513251505104 (0x10000002034303D0);
            // 0x028B979C: STR xzr, [sp, #0x130]      | stack[1152921513251505104] = 0x0;        //  dest_result_addr=1152921513251505104
            // 0x028B97A0: BL #0x2697148              | null..ctor(_x:  val_17.position, _y:  0.05f);
            Geometric.Point val_19 = new Geometric.Point(_x:  val_17.position, _y:  val_163);
            // 0x028B97A4: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B97A8: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028B97AC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B97B0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B97B4: TBZ w8, #0, #0x28b97c4     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x028B97B8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B97BC: CBNZ w8, #0x28b97c4        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x028B97C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_34:
            // 0x028B97C4: LDR s2, [sp, #0x130]       | S2 = val_19.x;                          
            // 0x028B97C8: LDR s3, [sp, #0x134]       | S3 = val_19.y;                          
            // 0x028B97CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B97D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B97D4: MOV v0.16b, v12.16b        | V0 = val_11.x;//m1                      
            // 0x028B97D8: MOV v1.16b, v13.16b        | V1 = val_11.y;//m1                      
            // 0x028B97DC: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y}, b:  new UnityEngine.Vector2() {x = val_19.x, y = val_19.y});
            UnityEngine.Vector2 val_20 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y}, b:  new UnityEngine.Vector2() {x = val_19.x, y = val_19.y});
            // 0x028B97E0: MOV v2.16b, v0.16b         | V2 = val_20.x;//m1                      
            // 0x028B97E4: MOV v3.16b, v1.16b         | V3 = val_20.y;//m1                      
            // 0x028B97E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B97EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B97F0: MOV v0.16b, v11.16b        | V0 = val_17.dir;//m1                    
            // 0x028B97F4: MOV v1.16b, v10.16b        | V1 = V10.16B;//m1                       
            // 0x028B97F8: BL #0x2697b78              | X0 = UnityEngine.Vector2.Dot(lhs:  new UnityEngine.Vector2() {x = val_17.dir, y = V10.16B}, rhs:  new UnityEngine.Vector2() {x = val_20.x, y = val_20.y});
            float val_21 = UnityEngine.Vector2.Dot(lhs:  new UnityEngine.Vector2() {x = val_17.dir, y = V10.16B}, rhs:  new UnityEngine.Vector2() {x = val_20.x, y = val_20.y});
            // 0x028B97FC: MOV v14.16b, v0.16b        | V14 = val_21;//m1                       
            // 0x028B9800: LDR s0, [sp, #0xc8]        | S0 = (this.simulator.wallThickness * 0.05f);
            // 0x028B9804: FCMP s14, s0               | STATE = COMPARE(val_21, (this.simulator.wallThickness * 0.05f))
            // 0x028B9808: B.LS #0x28b9818            | if (val_21 <= this.simulator.wallThickness) goto label_35;
            if(val_21 <= val_161)
            {
                goto label_35;
            }
            // 0x028B980C: CBZ x27, #0x28b9820        | if (val_17 == null) goto label_36;      
            if(val_17 == null)
            {
                goto label_36;
            }
            // 0x028B9810: LDR s8, [x27, #0x14]       | S8 = val_17.position; //P2              
            // 0x028B9814: B #0x28b982c               |  goto label_37;                         
            goto label_37;
            label_35:
            // 0x028B9818: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            // 0x028B981C: B #0x28b98d4               |  goto label_38;                         
            goto label_38;
            label_36:
            // 0x028B9820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028B9824: LDR s8, [x27, #0x14]       | S8 = val_17.position; //P2              
            // 0x028B9828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_37:
            // 0x028B982C: LDR s1, [x27, #0x1c]       | 
            // 0x028B9830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9834: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B9838: MOV v0.16b, v8.16b         | V0 = val_17.position;//m1               
            // 0x028B983C: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028B9840: BL #0x2697148              | null..ctor(_x:  val_17.position, _y:  V10.16B);
            Geometric.Point val_22 = new Geometric.Point(_x:  val_17.position, _y:  V10.16B);
            // 0x028B9844: CBNZ x27, #0x28b984c       | if (val_17 != null) goto label_39;      
            if(val_17 != null)
            {
                goto label_39;
            }
            // 0x028B9848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  val_17.position, _y:  V10.16B), ????);
            label_39:
            // 0x028B984C: LDR x22, [x27, #0x38]      | X22 = val_17.next; //P2                 
            // 0x028B9850: MOV x8, x22                | X8 = val_17.next;//m1                   
            // 0x028B9854: CBNZ x22, #0x28b9864       | if (val_17.next != null) goto label_40; 
            if(val_17.next != null)
            {
                goto label_40;
            }
            // 0x028B9858: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  val_17.position, _y:  V10.16B), ????);
            // 0x028B985C: LDR x8, [x27, #0x38]       | X8 = val_17.next; //P2                  
            // 0x028B9860: CBZ x8, #0x28bb8e4         | if (val_17.next == null) goto label_62; 
            if(val_17.next == null)
            {
                goto label_62;
            }
            label_40:
            // 0x028B9864: LDR s0, [x22, #0x14]       | S0 = val_17.next.position; //P2         
            // 0x028B9868: LDR s1, [x8, #0x1c]        | 
            // 0x028B986C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9870: ADD x0, sp, #0x130         | X0 = (1152921513251504800 + 304) = 1152921513251505104 (0x10000002034303D0);
            // 0x028B9874: STR xzr, [sp, #0x130]      | stack[1152921513251505104] = 0x0;        //  dest_result_addr=1152921513251505104
            // 0x028B9878: BL #0x2697148              | null..ctor(_x:  val_17.next.position, _y:  V10.16B);
            Geometric.Point val_23 = new Geometric.Point(_x:  val_17.next.position, _y:  V10.16B);
            // 0x028B987C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B9880: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028B9884: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B9888: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B988C: TBZ w8, #0, #0x28b989c     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_43;
            // 0x028B9890: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B9894: CBNZ w8, #0x28b989c        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
            // 0x028B9898: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_43:
            // 0x028B989C: LDP s0, s1, [sp, #0xe0]    | S0 = val_22.x; S1 = val_22.y;            //  | 
            // 0x028B98A0: LDR s2, [sp, #0x130]       | S2 = val_23.x;                          
            // 0x028B98A4: LDR s3, [sp, #0x134]       | S3 = val_23.y;                          
            // 0x028B98A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B98AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B98B0: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_22.x, y = val_22.y}, b:  new UnityEngine.Vector2() {x = val_23.x, y = val_23.y});
            UnityEngine.Vector2 val_24 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_22.x, y = val_22.y}, b:  new UnityEngine.Vector2() {x = val_23.x, y = val_23.y});
            // 0x028B98B4: SUB x0, x29, #0xa8         | X0 = (1152921513251505408 - 168) = 1152921513251505240 (0x1000000203430458);
            // 0x028B98B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B98BC: STP s0, s1, [x29, #-0xa8]  | stack[1152921513251505240] = val_24.x;  stack[1152921513251505244] = val_24.y;  //  dest_result_addr=1152921513251505240 |  dest_result_addr=1152921513251505244
            // 0x028B98C0: BL #0x269749c              | X0 = label_UnityEngine_Vector2_op_Subtraction_GL0269749C();
            // 0x028B98C4: LDR s1, [sp, #0xc8]        | S1 = (this.simulator.wallThickness * 0.05f);
            // 0x028B98C8: FSUB s0, s0, s1            | S0 = (val_24.x - (this.simulator.wallThickness * 0.05f));
            val_24.x = val_24.x - val_161;
            // 0x028B98CC: FCMP s14, s0               | STATE = COMPARE(val_21, (val_24.x - (this.simulator.wallThickness * 0.05f)))
            // 0x028B98D0: CSET w22, ge               | W22 = val_21 >= val_24.x ? 1 : 0;       
            var val_25 = (val_21 >= val_24.x) ? 1 : 0;
            label_38:
            // 0x028B98D4: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028B98D8: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x028B98DC: FSUB s0, s12, s9           | S0 = (val_11.x - val_18.x);             
            float val_26 = val_11.x - val_18.x;
            // 0x028B98E0: FSUB s1, s13, s15          | S1 = (val_11.y - val_18.y);             
            float val_27 = val_11.y - val_18.y;
            // 0x028B98E4: FMUL s0, s10, s0           | S0 = (S10 * (val_11.x - val_18.x));     
            val_26 = S10 * val_26;
            // 0x028B98E8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x028B98EC: FMUL s1, s11, s1           | S1 = (val_17.dir * (val_11.y - val_18.y));
            val_27 = val_17.dir * val_27;
            // 0x028B98F0: FSUB s8, s0, s1            | S8 = ((S10 * (val_11.x - val_18.x)) - (val_17.dir * (val_11.y - val_18.y)));
            float val_28 = val_26 - val_27;
            // 0x028B98F4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028B98F8: TBZ w8, #0, #0x28b9908     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_45;
            // 0x028B98FC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028B9900: CBNZ w8, #0x28b9908        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
            // 0x028B9904: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_45:
            // 0x028B9908: LDR s0, [x25, #0x40]       | S0 = this.neighbourDist; //P2           
            // 0x028B990C: FABS s1, s8                | S1 = System.Math.Abs(((S10 * (val_11.x - val_18.x)) - (val_17.dir * (val_11.y - val_18.y))));
            float val_165 = System.Math.Abs(val_28);
            // 0x028B9910: FCMP s1, s0                | STATE = COMPARE(((S10 * (val_11.x - val_18.x)) - (val_17.dir * (val_11.y - val_18.y))), this.neighbourDist)
            // 0x028B9914: B.PL #0x28b9b5c            | if (System.Math.Abs(float val_28 = val_26 - val_27) >= 0) goto label_53;
            if(val_165 >= 0)
            {
                goto label_53;
            }
            // 0x028B9918: LDR s0, [sp, #0xbc]        | S0 = this.simulator.wallThickness;      
            // 0x028B991C: FCMP s8, s0                | STATE = COMPARE(((S10 * (val_11.x - val_18.x)) - (val_17.dir * (val_11.y - val_18.y))), this.simulator.wallThickness)
            // 0x028B9920: B.LE #0x28b9944            | if (val_28 <= -this.simulator.wallThickness) goto label_49;
            if(val_28 <= (-val_161))
            {
                goto label_49;
            }
            // 0x028B9924: FCMP s8, #0.0              | STATE = COMPARE(((S10 * (val_11.x - val_18.x)) - (val_17.dir * (val_11.y - val_18.y))), 0)
            // 0x028B9928: B.HI #0x28b9944            | if (val_28 > 0) goto label_49;          
            if(val_28 > 0f)
            {
                goto label_49;
            }
            // 0x028B992C: CBNZ w22, #0x28b9944       | if (val_21 >= val_24.x ? 1 : 0 != 0) goto label_49;
            if(val_25 != 0)
            {
                goto label_49;
            }
            // 0x028B9930: CBNZ x20, #0x28b9938       | if (context.vos != null) goto label_50; 
            if(context.vos != null)
            {
                goto label_50;
            }
            // 0x028B9934: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
            label_50:
            // 0x028B9938: CBZ x27, #0x28b9958        | if (val_17 == null) goto label_51;      
            if(val_17 == null)
            {
                goto label_51;
            }
            // 0x028B993C: LDR s8, [x27, #0x14]       | S8 = val_17.position; //P2              
            // 0x028B9940: B #0x28b9964               |  goto label_52;                         
            goto label_52;
            label_49:
            // 0x028B9944: FCMP s8, #0.0              | STATE = COMPARE(((S10 * (val_11.x - val_18.x)) - (val_17.dir * (val_11.y - val_18.y))), 0)
            // 0x028B9948: B.LE #0x28b9b5c            | if (val_28 <= 0) goto label_53;         
            if(val_28 <= 0f)
            {
                goto label_53;
            }
            // 0x028B994C: CBZ x27, #0x28b99f8        | if (val_17 == null) goto label_54;      
            if(val_17 == null)
            {
                goto label_54;
            }
            // 0x028B9950: LDR s8, [x27, #0x14]       | S8 = val_17.position; //P2              
            // 0x028B9954: B #0x28b9a04               |  goto label_55;                         
            goto label_55;
            label_51:
            // 0x028B9958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028B995C: LDR s8, [x27, #0x14]       | S8 = val_17.position; //P2              
            // 0x028B9960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
            label_52:
            // 0x028B9964: LDR s1, [x27, #0x1c]       | 
            // 0x028B9968: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B996C: ADD x0, sp, #0x130         | X0 = (1152921513251504800 + 304) = 1152921513251505104 (0x10000002034303D0);
            // 0x028B9970: MOV v0.16b, v8.16b         | V0 = val_17.position;//m1               
            // 0x028B9974: STR xzr, [sp, #0x130]      | stack[1152921513251505104] = 0x0;        //  dest_result_addr=1152921513251505104
            // 0x028B9978: BL #0x2697148              | null..ctor(_x:  val_17.position, _y:  System.Math.Abs(val_28));
            Geometric.Point val_29 = new Geometric.Point(_x:  val_17.position, _y:  val_165);
            // 0x028B997C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B9980: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028B9984: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B9988: LDP s10, s8, [x29, #-0x98] | S10 = val_11.x; S8 = val_11.y;           //  | 
            // 0x028B998C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B9990: TBZ w8, #0, #0x28b99a0     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_57;
            // 0x028B9994: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B9998: CBNZ w8, #0x28b99a0        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_57;
            // 0x028B999C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_57:
            // 0x028B99A0: LDR s0, [sp, #0x130]       | S0 = val_29.x;                          
            // 0x028B99A4: LDR s1, [sp, #0x134]       | S1 = val_29.y;                          
            // 0x028B99A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B99AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B99B0: MOV v2.16b, v10.16b        | V2 = val_11.x;//m1                      
            // 0x028B99B4: MOV v3.16b, v8.16b         | V3 = val_11.y;//m1                      
            // 0x028B99B8: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_29.x, y = val_29.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_30 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_29.x, y = val_29.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028B99BC: LDP s10, s11, [x27, #0x20] | S10 = val_17.dir; //P2                   //  | 
            // 0x028B99C0: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B99C4: MOVZ w2, #0x50             | W2 = 80 (0x50);//ML01                   
            // 0x028B99C8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x028B99CC: MOV v8.16b, v0.16b         | V8 = val_30.x;//m1                      
            // 0x028B99D0: MOV v12.16b, v1.16b        | V12 = val_30.y;//m1                     
            // 0x028B99D4: BL #0x980b70               | X0 = sub_980B70( ?? 0x1000000203430380, ????);
            // 0x028B99D8: LDR s6, [sp, #0xac]        | S6 = (this.simulator.algorithm == 0x1 ? 1f : 5f + this.simulator.algorithm == 0x1 ? 1f : 5f);
            // 0x028B99DC: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B99E0: MOV v2.16b, v8.16b         | V2 = val_30.x;//m1                      
            // 0x028B99E4: MOV v3.16b, v12.16b        | V3 = val_30.y;//m1                      
            // 0x028B99E8: MOV v4.16b, v10.16b        | V4 = val_17.dir;//m1                    
            // 0x028B99EC: MOV v5.16b, v11.16b        | V5 = val_17.dir;//m1                    
            // 0x028B99F0: BL #0x28bb908              | X0 = label_Agent_VO_Det_GL028BB908();   
            // 0x028B99F4: B #0x28b9b1c               |  goto label_58;                         
            goto label_58;
            label_54:
            // 0x028B99F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028B99FC: LDR s8, [x27, #0x14]       | S8 = val_17.position; //P2              
            // 0x028B9A00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
            label_55:
            // 0x028B9A04: LDR s1, [x27, #0x1c]       | 
            // 0x028B9A08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9A0C: ADD x0, sp, #0x130         | X0 = (1152921513251504800 + 304) = 1152921513251505104 (0x10000002034303D0);
            // 0x028B9A10: MOV v0.16b, v8.16b         | V0 = val_17.position;//m1               
            // 0x028B9A14: STR xzr, [sp, #0x130]      | stack[1152921513251505104] = 0x0;        //  dest_result_addr=1152921513251505104
            // 0x028B9A18: BL #0x2697148              | null..ctor(_x:  val_17.position, _y:  System.Math.Abs(val_28));
            Geometric.Point val_31 = new Geometric.Point(_x:  val_17.position, _y:  val_165);
            // 0x028B9A1C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B9A20: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028B9A24: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B9A28: LDP s10, s8, [x29, #-0x98] | S10 = val_11.x; S8 = val_11.y;           //  | 
            // 0x028B9A2C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B9A30: TBZ w8, #0, #0x28b9a40     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_60;
            // 0x028B9A34: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B9A38: CBNZ w8, #0x28b9a40        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
            // 0x028B9A3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_60:
            // 0x028B9A40: LDR s0, [sp, #0x130]       | S0 = val_31.x;                          
            // 0x028B9A44: LDR s1, [sp, #0x134]       | S1 = val_31.y;                          
            // 0x028B9A48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9A4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9A50: MOV v2.16b, v10.16b        | V2 = val_11.x;//m1                      
            // 0x028B9A54: MOV v3.16b, v8.16b         | V3 = val_11.y;//m1                      
            // 0x028B9A58: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_31.x, y = val_31.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_32 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_31.x, y = val_31.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028B9A5C: STP s0, s1, [x29, #-0xb0]  | stack[1152921513251505232] = val_32.x;  stack[1152921513251505236] = val_32.y;  //  dest_result_addr=1152921513251505232 |  dest_result_addr=1152921513251505236
            // 0x028B9A60: LDR x22, [x27, #0x38]      | X22 = val_17.next; //P2                 
            // 0x028B9A64: MOV x8, x22                | X8 = val_17.next;//m1                   
            // 0x028B9A68: CBNZ x22, #0x28b9a78       | if (val_17.next != null) goto label_61; 
            if(val_17.next != null)
            {
                goto label_61;
            }
            // 0x028B9A6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028B9A70: LDR x8, [x27, #0x38]       | X8 = val_17.next; //P2                  
            // 0x028B9A74: CBZ x8, #0x28bb8e4         | if (val_17.next == null) goto label_62; 
            if(val_17.next == null)
            {
                goto label_62;
            }
            label_61:
            // 0x028B9A78: LDR s0, [x22, #0x14]       | S0 = val_17.next.position; //P2         
            // 0x028B9A7C: LDR s1, [x8, #0x1c]        | 
            // 0x028B9A80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9A84: ADD x0, sp, #0xd8          | X0 = (1152921513251504800 + 216) = 1152921513251505016 (0x1000000203430378);
            // 0x028B9A88: STR xzr, [sp, #0xd8]       | stack[1152921513251505016] = 0x0;        //  dest_result_addr=1152921513251505016
            // 0x028B9A8C: BL #0x2697148              | null..ctor(_x:  val_17.next.position, _y:  val_32.y);
            Geometric.Point val_33 = new Geometric.Point(_x:  val_17.next.position, _y:  val_32.y);
            // 0x028B9A90: LDP s2, s3, [x29, #-0x98]  | S2 = val_11.x; S3 = val_11.y;            //  | 
            // 0x028B9A94: LDP s0, s1, [sp, #0xd8]    | S0 = val_33.x; S1 = val_33.y;            //  | 
            // 0x028B9A98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9A9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9AA0: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_33.x, y = val_33.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_34 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_33.x, y = val_33.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028B9AA4: SUB x0, x29, #0xb0         | X0 = (1152921513251505408 - 176) = 1152921513251505232 (0x1000000203430450);
            // 0x028B9AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9AAC: STP s0, s1, [x29, #-0xb8]  | stack[1152921513251505224] = val_34.x;  stack[1152921513251505228] = val_34.y;  //  dest_result_addr=1152921513251505224 |  dest_result_addr=1152921513251505228
            // 0x028B9AB0: BL #0x26976b8              | X0 = label_UnityEngine_Vector2_Normalize_GL026976B8();
            // 0x028B9AB4: SUB x0, x29, #0xb8         | X0 = (1152921513251505408 - 184) = 1152921513251505224 (0x1000000203430448);
            // 0x028B9AB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9ABC: MOV v8.16b, v0.16b         | V8 = val_34.x;//m1                      
            // 0x028B9AC0: MOV v10.16b, v1.16b        | V10 = val_34.y;//m1                     
            // 0x028B9AC4: BL #0x26976b8              | X0 = label_UnityEngine_Vector2_Normalize_GL026976B8();
            // 0x028B9AC8: MOV v11.16b, v0.16b        | V11 = val_34.x;//m1                     
            // 0x028B9ACC: MOV v12.16b, v1.16b        | V12 = val_34.y;//m1                     
            // 0x028B9AD0: CBNZ x20, #0x28b9ad8       | if (context.vos != null) goto label_63; 
            if(context.vos != null)
            {
                goto label_63;
            }
            // 0x028B9AD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000203430448, ????);
            label_63:
            // 0x028B9AD8: LDP s13, s14, [x29, #-0xb0] | S13 = val_32.x; S14 = val_32.y;          //  | 
            // 0x028B9ADC: LDP s15, s9, [x29, #-0xb8] | S15 = val_34.x; S9 = val_34.y;           //  | 
            // 0x028B9AE0: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B9AE4: MOVZ w2, #0x50             | W2 = 80 (0x50);//ML01                   
            // 0x028B9AE8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x028B9AEC: BL #0x980b70               | X0 = sub_980B70( ?? 0x1000000203430380, ????);
            // 0x028B9AF0: LDR s0, [sp, #0xa0]        | S0 = this.simulator.algorithm == 0x1 ? 1f : 5f;
            // 0x028B9AF4: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B9AF8: MOV v2.16b, v13.16b        | V2 = val_32.x;//m1                      
            // 0x028B9AFC: MOV v3.16b, v14.16b        | V3 = val_32.y;//m1                      
            // 0x028B9B00: MOV v4.16b, v15.16b        | V4 = val_34.x;//m1                      
            // 0x028B9B04: MOV v5.16b, v9.16b         | V5 = val_34.y;//m1                      
            // 0x028B9B08: MOV v6.16b, v8.16b         | V6 = val_34.x;//m1                      
            // 0x028B9B0C: MOV v7.16b, v10.16b        | V7 = val_34.y;//m1                      
            // 0x028B9B10: STP s12, s0, [sp, #4]      | stack[1152921513251504804] = val_34.y;  stack[1152921513251504808] = this.simulator.algorithm == 0x1 ? 1f : 5f;  //  dest_result_addr=1152921513251504804 |  dest_result_addr=1152921513251504808
            // 0x028B9B14: STR s11, [sp]              | stack[1152921513251504800] = val_34.x;   //  dest_result_addr=1152921513251504800
            // 0x028B9B18: BL #0x28bba30              | X0 = label_Agent_VO_Det_GL028BBA30();   
            label_58:
            // 0x028B9B1C: LDR w8, [x20, #0x18]       | W8 = context.vos.Length; //P2           
            // 0x028B9B20: LDR x9, [sp, #0xc0]        | X9 = 0x0;                               
            // 0x028B9B24: SXTW x22, w9               | X22 = 0 (0x00000000);                   
            // 0x028B9B28: CMP w9, w8                 | STATE = COMPARE(0x0, context.vos.Length)
            // 0x028B9B2C: B.LO #0x28b9b3c            | if (0 < context.vos.Length) goto label_64;
            if(0 < context.vos.Length)
            {
                goto label_64;
            }
            // 0x028B9B30: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000203430380, ????);
            // 0x028B9B34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9B38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000203430380, ????);
            label_64:
            // 0x028B9B3C: MADD x8, x22, x26, x20     | X8 = (0 * 80 + context.vos) = 0 (0x00000000);
            // 0x028B9B40: ADD x0, x8, #0x20          | X0 = (0 + 32) = 32 (0x00000020);        
            // 0x028B9B44: ADD x1, sp, #0xe0          | X1 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B9B48: MOVZ w2, #0x50             | W2 = 80 (0x50);//ML01                   
            // 0x028B9B4C: BL #0x9808a0               | X0 = sub_9808A0( ?? 0x20, ????);        
            // 0x028B9B50: LDR x8, [sp, #0xc0]        | X8 = 0x0;                               
            // 0x028B9B54: ADD w8, w8, #1             | W8 = (0 + 1) = 1 (0x00000001);          
            // 0x028B9B58: STR x8, [sp, #0xc0]        | stack[1152921513251504992] = 0x1;        //  dest_result_addr=1152921513251504992
            label_53:
            // 0x028B9B5C: CBNZ x27, #0x28b9b64       | if (val_17 != null) goto label_65;      
            if(val_17 != null)
            {
                goto label_65;
            }
            // 0x028B9B60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x20, ????);       
            label_65:
            // 0x028B9B64: LDR x27, [x27, #0x38]      | X27 = val_17.next; //P2                 
            // 0x028B9B68: CMP x27, x24               | STATE = COMPARE(val_17.next, val_17)    
            // 0x028B9B6C: B.NE #0x28b9720            | if (val_17.next != val_17) goto label_66;
            if(val_17.next != val_17)
            {
                goto label_66;
            }
            // 0x028B9B70: B #0x28b96c0               |  goto label_67;                         
            goto label_67;
            label_25:
            // 0x028B9B74: ADRP x19, #0x35c6000       | X19 = 56385536 (0x35C6000);             
            // 0x028B9B78: LDR x19, [x19, #8]         | X19 = 1152921513250160176;              
            // 0x028B9B7C: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_145 = 0;
            // 0x028B9B80: MOVZ w26, #0x50            | W26 = 80 (0x50);//ML01                  
            // 0x028B9B84: ORR w27, wzr, #0x3f800000  | W27 = 1065353216(0x3F800000);           
            val_146 = 1065353216;
            // 0x028B9B88: B #0x28b9b90               |  goto label_68;                         
            goto label_68;
            label_95:
            // 0x028B9B8C: ADD w23, w23, #1           | W23 = (val_145 + 1) = val_145 (0x00000001);
            val_145 = 1;
            label_68:
            // 0x028B9B90: LDR x24, [x25, #0xe8]      | X24 = this.neighbours; //P2             
            // 0x028B9B94: CBNZ x24, #0x28b9b9c       | if (this.neighbours != null) goto label_69;
            if(this.neighbours != null)
            {
                goto label_69;
            }
            // 0x028B9B98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_69:
            // 0x028B9B9C: LDR x1, [x28]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::get_Count();
            // 0x028B9BA0: MOV x0, x24                | X0 = this.neighbours;//m1               
            // 0x028B9BA4: BL #0x25ed72c              | X0 = this.neighbours.get_Count();       
            int val_35 = this.neighbours.Count;
            // 0x028B9BA8: CMP w23, w0                | STATE = COMPARE(0x1, val_35)            
            // 0x028B9BAC: B.GE #0x28b9f10            | if (val_145 >= val_35) goto label_70;   
            if(val_145 >= val_35)
            {
                goto label_70;
            }
            // 0x028B9BB0: LDR x24, [x25, #0xe8]      | X24 = this.neighbours; //P2             
            // 0x028B9BB4: CBNZ x24, #0x28b9bbc       | if (this.neighbours != null) goto label_71;
            if(this.neighbours != null)
            {
                goto label_71;
            }
            // 0x028B9BB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_71:
            // 0x028B9BBC: LDR x2, [x19]              | X2 = public Pathfinding.RVO.Sampled.Agent System.Collections.Generic.List<Pathfinding.RVO.Sampled.Agent>::get_Item(int index);
            // 0x028B9BC0: MOV x0, x24                | X0 = this.neighbours;//m1               
            // 0x028B9BC4: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x028B9BC8: BL #0x25ed734              | X0 = this.neighbours.get_Item(index:  1);
            Pathfinding.RVO.Sampled.Agent val_36 = this.neighbours.Item[1];
            // 0x028B9BCC: MOV x22, x0                | X22 = val_36;//m1                       
            // 0x028B9BD0: CMP x22, x25               | STATE = COMPARE(val_36, this)           
            // 0x028B9BD4: B.EQ #0x28b9b8c            | if (val_36 == val_141) goto label_95;   
            if(val_36 == val_141)
            {
                goto label_95;
            }
            // 0x028B9BD8: LDR s8, [x25, #0x64]       | 
            // 0x028B9BDC: LDR s9, [x25, #0x38]       | S9 = this.height; //P2                  
            // 0x028B9BE0: CBZ x22, #0x28b9bf4        | if (val_36 == null) goto label_73;      
            if(val_36 == null)
            {
                goto label_73;
            }
            // 0x028B9BE4: MOV x24, x22               | X24 = val_36;//m1                       
            // 0x028B9BE8: LDR s10, [x24, #0x64]!     | 
            // 0x028B9BEC: SUB x21, x24, #4           | X21 = (val_36 + 100 - 4);               
            var val_37 = (val_36 + 100) - 4;
            // 0x028B9BF0: B #0x28b9c0c               |  goto label_74;                         
            goto label_74;
            label_73:
            // 0x028B9BF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            // 0x028B9BF8: MOVZ w8, #0x64             | W8 = 100 (0x64);//ML01                  
            // 0x028B9BFC: LDR s10, [x8]              | S10 = 0;                                
            // 0x028B9C00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            // 0x028B9C04: MOVZ w24, #0x64            | W24 = 100 (0x64);//ML01                 
            // 0x028B9C08: ORR w21, wzr, #0x60        | W21 = 96(0x60);                         
            label_74:
            // 0x028B9C0C: LDR s1, [x22, #0x38]       | S1 = val_36.height; //P2                
            float val_166 = val_36.height;
            // 0x028B9C10: FADD s0, s8, s9            | S0 = (this.agentTimeHorizon + this.height);
            float val_38 = this.agentTimeHorizon + this.height;
            // 0x028B9C14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9C18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9C1C: FADD s1, s10, s1           | S1 = (0f + val_36.height);              
            val_166 = 0f + val_166;
            // 0x028B9C20: BL #0x16f9600              | X0 = System.Math.Min(val1:  float val_38 = this.agentTimeHorizon + this.height, val2:  val_36.height = 0f + val_36.height);
            float val_39 = System.Math.Min(val1:  val_38, val2:  val_166);
            // 0x028B9C24: LDR s9, [x25, #0x64]       | 
            // 0x028B9C28: MOV v8.16b, v0.16b         | V8 = val_39;//m1                        
            // 0x028B9C2C: CBNZ x22, #0x28b9c34       | if (val_36 != null) goto label_75;      
            if(val_36 != null)
            {
                goto label_75;
            }
            // 0x028B9C30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_75:
            // 0x028B9C34: LDR s1, [x24]              | S1 = 0;                                 
            // 0x028B9C38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9C3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9C40: MOV v0.16b, v9.16b         | V0 = this.height;//m1                   
            // 0x028B9C44: BL #0x16f9434              | X0 = System.Math.Max(val1:  this.height, val2:  0f);
            float val_40 = System.Math.Max(val1:  this.height, val2:  0f);
            // 0x028B9C48: FSUB s0, s8, s0            | S0 = (val_39 - val_40);                 
            val_40 = val_39 - val_40;
            // 0x028B9C4C: FCMP s0, #0.0              | STATE = COMPARE((val_39 - val_40), 0)   
            // 0x028B9C50: B.MI #0x28b9b8c            | if (val_40 < 0) goto label_95;          
            if(val_40 < 0)
            {
                goto label_95;
            }
            // 0x028B9C54: CBZ x22, #0x28b9c60        | if (val_36 == null) goto label_77;      
            if(val_36 == null)
            {
                goto label_77;
            }
            // 0x028B9C58: LDR s8, [x22, #0xa8]       | S8 = val_36.<Velocity>k__BackingField; //P2 
            // 0x028B9C5C: B #0x28b9c6c               |  goto label_78;                         
            goto label_78;
            label_77:
            // 0x028B9C60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028B9C64: LDR s8, [x22, #0xa8]       | S8 = val_36.<Velocity>k__BackingField; //P2 
            // 0x028B9C68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_78:
            // 0x028B9C6C: LDR s1, [x22, #0xd0]       | 
            // 0x028B9C70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9C74: SUB x0, x29, #0xc0         | X0 = (1152921513251505408 - 192) = 1152921513251505216 (0x1000000203430440);
            // 0x028B9C78: MOV v0.16b, v8.16b         | V0 = val_36.<Velocity>k__BackingField;//m1
            // 0x028B9C7C: BL #0x2697148              | null..ctor(_x:  val_36.<Velocity>k__BackingField, _y:  0f);
            Geometric.Point val_41 = new Geometric.Point(_x:  val_36.<Velocity>k__BackingField, _y:  0f);
            // 0x028B9C80: LDR s9, [x25, #0x34]       | S9 = this.radius; //P2                  
            // 0x028B9C84: CBZ x22, #0x28b9c94        | if (val_36 == null) goto label_79;      
            if(val_36 == null)
            {
                goto label_79;
            }
            // 0x028B9C88: LDR s12, [x22, #0x34]      | S12 = val_36.radius; //P2               
            // 0x028B9C8C: LDR s8, [x21]              | S8 = 5.356395E-37;                      
            // 0x028B9C90: B #0x28b9ca8               |  goto label_80;                         
            goto label_80;
            label_79:
            // 0x028B9C94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  val_36.<Velocity>k__BackingField, _y:  0f), ????);
            // 0x028B9C98: LDR s12, [x22, #0x34]      | S12 = val_36.radius; //P2               
            // 0x028B9C9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  val_36.<Velocity>k__BackingField, _y:  0f), ????);
            // 0x028B9CA0: LDR s8, [x21]              | S8 = 5.356395E-37;                      
            // 0x028B9CA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  val_36.<Velocity>k__BackingField, _y:  0f), ????);
            label_80:
            // 0x028B9CA8: LDR s1, [x21, #8]          | S1 = 5.356395E-37;                      
            // 0x028B9CAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9CB0: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B9CB4: MOV v0.16b, v8.16b         | V0 = 53888200 (0x33644C8);//ML01        
            // 0x028B9CB8: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028B9CBC: BL #0x2697148              | null..ctor(_x:  5.356395E-37f, _y:  5.356395E-37f);
            Geometric.Point val_42 = new Geometric.Point(_x:  5.356395E-37f, _y:  5.356395E-37f);
            // 0x028B9CC0: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B9CC4: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028B9CC8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B9CCC: LDP s10, s8, [x29, #-0x98] | S10 = val_11.x; S8 = val_11.y;           //  | 
            // 0x028B9CD0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B9CD4: TBZ w8, #0, #0x28b9ce4     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_82;
            // 0x028B9CD8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B9CDC: CBNZ w8, #0x28b9ce4        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_82;
            // 0x028B9CE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_82:
            // 0x028B9CE4: LDP s0, s1, [sp, #0xe0]    | S0 = val_42.x; S1 = val_42.y;            //  | 
            // 0x028B9CE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9CEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9CF0: MOV v2.16b, v10.16b        | V2 = val_11.x;//m1                      
            // 0x028B9CF4: MOV v3.16b, v8.16b         | V3 = val_11.y;//m1                      
            // 0x028B9CF8: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_42.x, y = val_42.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_43 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_42.x, y = val_42.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028B9CFC: MOV v10.16b, v0.16b        | V10 = val_43.x;//m1                     
            // 0x028B9D00: LDP s0, s4, [x29, #-0xa0]  | S0 = val_12.x; S4 = val_12.y;            //  | 
            // 0x028B9D04: LDP s2, s3, [x29, #-0xc0]  | S2 = val_41.x; S3 = val_41.y;            //  | 
            // 0x028B9D08: MOV v11.16b, v1.16b        | V11 = val_43.y;//m1                     
            // 0x028B9D0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9D10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9D14: MOV v1.16b, v4.16b         | V1 = val_12.y;//m1                      
            // 0x028B9D18: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, b:  new UnityEngine.Vector2() {x = val_41.x, y = val_41.y});
            UnityEngine.Vector2 val_44 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, b:  new UnityEngine.Vector2() {x = val_41.x, y = val_41.y});
            // 0x028B9D1C: MOV v15.16b, v0.16b        | V15 = val_44.x;//m1                     
            // 0x028B9D20: MOV v8.16b, v1.16b         | V8 = val_44.y;//m1                      
            // 0x028B9D24: CBNZ x22, #0x28b9d2c       | if (val_36 != null) goto label_83;      
            if(val_36 != null)
            {
                goto label_83;
            }
            // 0x028B9D28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_83:
            // 0x028B9D2C: LDRB w8, [x22, #0x50]      | W8 = val_36.locked; //P2                
            // 0x028B9D30: CBZ w8, #0x28b9d3c         | if (val_36.locked == false) goto label_84;
            if(val_36.locked == false)
            {
                goto label_84;
            }
            // 0x028B9D34: LDP s13, s14, [x29, #-0xc0] | S13 = val_41.x; S14 = val_41.y;          //  | 
            // 0x028B9D38: B #0x28b9da8               |  goto label_85;                         
            goto label_85;
            label_84:
            // 0x028B9D3C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B9D40: STR s12, [sp, #0xbc]       | stack[1152921513251504988] = val_36.radius;  //  dest_result_addr=1152921513251504988
            // 0x028B9D44: STR s9, [sp, #0xc8]        | stack[1152921513251505000] = this.radius;  //  dest_result_addr=1152921513251505000
            // 0x028B9D48: LDP s12, s9, [x29, #-0xa0] | S12 = val_12.x; S9 = val_12.y;           //  | 
            // 0x028B9D4C: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028B9D50: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B9D54: LDP s14, s13, [x29, #-0xc0] | S14 = val_41.x; S13 = val_41.y;          //  | 
            // 0x028B9D58: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B9D5C: TBZ w8, #0, #0x28b9d6c     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_87;
            // 0x028B9D60: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B9D64: CBNZ w8, #0x28b9d6c        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_87;
            // 0x028B9D68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_87:
            // 0x028B9D6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9D70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9D74: MOV v0.16b, v12.16b        | V0 = val_12.x;//m1                      
            // 0x028B9D78: MOV v1.16b, v9.16b         | V1 = val_12.y;//m1                      
            // 0x028B9D7C: MOV v2.16b, v14.16b        | V2 = val_41.x;//m1                      
            // 0x028B9D80: MOV v3.16b, v13.16b        | V3 = val_41.y;//m1                      
            // 0x028B9D84: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, b:  new UnityEngine.Vector2() {x = val_41.x, y = val_41.y});
            UnityEngine.Vector2 val_45 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, b:  new UnityEngine.Vector2() {x = val_41.x, y = val_41.y});
            // 0x028B9D88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9D8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9D90: FMOV s2, #0.50000000       | S2 = 0.5;                               
            // 0x028B9D94: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_45.x, y = val_45.y}, d:  0.5f);
            UnityEngine.Vector2 val_46 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_45.x, y = val_45.y}, d:  0.5f);
            // 0x028B9D98: LDR s9, [sp, #0xc8]        | S9 = this.radius;                       
            // 0x028B9D9C: LDR s12, [sp, #0xbc]       | S12 = val_36.radius;                    
            float val_167 = val_36.radius;
            // 0x028B9DA0: MOV v13.16b, v0.16b        | V13 = val_46.x;//m1                     
            // 0x028B9DA4: MOV v14.16b, v1.16b        | V14 = val_46.y;//m1                     
            label_85:
            // 0x028B9DA8: FADD s12, s9, s12          | S12 = (this.radius + val_36.radius);    
            val_167 = this.radius + val_167;
            // 0x028B9DAC: CBNZ x20, #0x28b9db4       | if (context.vos != null) goto label_88; 
            if(context.vos != null)
            {
                goto label_88;
            }
            // 0x028B9DB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_88:
            // 0x028B9DB4: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B9DB8: MOVZ w2, #0x50             | W2 = 80 (0x50);//ML01                   
            // 0x028B9DBC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x028B9DC0: BL #0x980b70               | X0 = sub_980B70( ?? 0x1000000203430380, ????);
            // 0x028B9DC4: LDR s7, [sp, #0xb0]        | S7 = (1f / this.agentTimeHorizon);      
            // 0x028B9DC8: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B9DCC: MOV v0.16b, v10.16b        | V0 = val_43.x;//m1                      
            // 0x028B9DD0: MOV v1.16b, v11.16b        | V1 = val_43.y;//m1                      
            // 0x028B9DD4: MOV v2.16b, v13.16b        | V2 = val_46.x;//m1                      
            // 0x028B9DD8: MOV v3.16b, v14.16b        | V3 = val_46.y;//m1                      
            // 0x028B9DDC: MOV v4.16b, v12.16b        | V4 = (this.radius + val_36.radius);//m1 
            // 0x028B9DE0: MOV v5.16b, v15.16b        | V5 = val_44.x;//m1                      
            // 0x028B9DE4: MOV v6.16b, v8.16b         | V6 = val_44.y;//m1                      
            // 0x028B9DE8: STR w27, [sp]              | stack[1152921513251504800] = 0x3F800000;  //  dest_result_addr=1152921513251504800
            // 0x028B9DEC: BL #0x28bbb8c              | X0 = label_Agent_VO_Det_GL028BBB8C();   
            // 0x028B9DF0: LDR x9, [sp, #0xc0]        | X9 = 0x1;                               
            // 0x028B9DF4: LDR w8, [x20, #0x18]       | W8 = context.vos.Length; //P2           
            // 0x028B9DF8: SXTW x22, w9               | X22 = 1 (0x00000001);                   
            // 0x028B9DFC: CMP w9, w8                 | STATE = COMPARE(0x1, context.vos.Length)
            // 0x028B9E00: B.LO #0x28b9e10            | if (1 < context.vos.Length) goto label_89;
            if(1 < context.vos.Length)
            {
                goto label_89;
            }
            // 0x028B9E04: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000203430380, ????);
            // 0x028B9E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9E0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000203430380, ????);
            label_89:
            // 0x028B9E10: MADD x8, x22, x26, x20     | X8 = (1 * 80 + context.vos) = 80 (0x00000050);
            // 0x028B9E14: ADD x0, x8, #0x20          | X0 = (80 + 32) = 112 (0x00000070);      
            // 0x028B9E18: ADD x1, sp, #0xe0          | X1 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028B9E1C: MOVZ w2, #0x50             | W2 = 80 (0x50);//ML01                   
            // 0x028B9E20: BL #0x9808a0               | X0 = sub_9808A0( ?? 0x70, ????);        
            // 0x028B9E24: LDR x9, [sp, #0xc0]        | X9 = 0x1;                               
            // 0x028B9E28: LDRB w8, [x25, #0xb4]      | W8 = this.<DebugDraw>k__BackingField; //P2 
            // 0x028B9E2C: ADD w9, w9, #1             | W9 = (1 + 1) = 2 (0x00000002);          
            // 0x028B9E30: STR x9, [sp, #0xc0]        | stack[1152921513251504992] = 0x2;        //  dest_result_addr=1152921513251504992
            // 0x028B9E34: CBZ w8, #0x28b9b8c         | if (this.<DebugDraw>k__BackingField == false) goto label_95;
            if((this.<DebugDraw>k__BackingField) == false)
            {
                goto label_95;
            }
            // 0x028B9E38: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B9E3C: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028B9E40: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B9E44: LDP s15, s8, [x29, #-0x98] | S15 = val_11.x; S8 = val_11.y;           //  | 
            // 0x028B9E48: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B9E4C: TBZ w8, #0, #0x28b9e5c     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_92;
            // 0x028B9E50: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B9E54: CBNZ w8, #0x28b9e5c        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_92;
            // 0x028B9E58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_92:
            // 0x028B9E5C: LDR s2, [sp, #0xb0]        | S2 = (1f / this.agentTimeHorizon);      
            // 0x028B9E60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9E68: MOV v0.16b, v10.16b        | V0 = val_43.x;//m1                      
            // 0x028B9E6C: MOV v1.16b, v11.16b        | V1 = val_43.y;//m1                      
            // 0x028B9E70: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_43.x, y = val_43.y}, d:  val_13);
            UnityEngine.Vector2 val_47 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_43.x, y = val_43.y}, d:  val_13);
            // 0x028B9E74: MOV v2.16b, v0.16b         | V2 = val_47.x;//m1                      
            // 0x028B9E78: MOV v3.16b, v1.16b         | V3 = val_47.y;//m1                      
            // 0x028B9E7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9E80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9E84: MOV v0.16b, v15.16b        | V0 = val_11.x;//m1                      
            // 0x028B9E88: MOV v1.16b, v8.16b         | V1 = val_11.y;//m1                      
            // 0x028B9E8C: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y}, b:  new UnityEngine.Vector2() {x = val_47.x, y = val_47.y});
            UnityEngine.Vector2 val_48 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y}, b:  new UnityEngine.Vector2() {x = val_47.x, y = val_47.y});
            // 0x028B9E90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9E94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9E98: MOV v2.16b, v13.16b        | V2 = val_46.x;//m1                      
            // 0x028B9E9C: MOV v3.16b, v14.16b        | V3 = val_46.y;//m1                      
            // 0x028B9EA0: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_48.x, y = val_48.y}, b:  new UnityEngine.Vector2() {x = val_46.x, y = val_46.y});
            UnityEngine.Vector2 val_49 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_48.x, y = val_48.y}, b:  new UnityEngine.Vector2() {x = val_46.x, y = val_46.y});
            // 0x028B9EA4: MOV v8.16b, v0.16b         | V8 = val_49.x;//m1                      
            // 0x028B9EA8: LDP s0, s2, [x29, #-0x98]  | S0 = val_11.x; S2 = val_11.y;            //  | 
            // 0x028B9EAC: MOV v10.16b, v1.16b        | V10 = val_49.y;//m1                     
            // 0x028B9EB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9EB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9EB8: MOV v1.16b, v2.16b         | V1 = val_11.y;//m1                      
            // 0x028B9EBC: MOV v2.16b, v13.16b        | V2 = val_46.x;//m1                      
            // 0x028B9EC0: MOV v3.16b, v14.16b        | V3 = val_46.y;//m1                      
            // 0x028B9EC4: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y}, b:  new UnityEngine.Vector2() {x = val_46.x, y = val_46.y});
            UnityEngine.Vector2 val_50 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y}, b:  new UnityEngine.Vector2() {x = val_46.x, y = val_46.y});
            // 0x028B9EC8: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028B9ECC: LDR x8, [x8, #0x470]       | X8 = 1152921504840765440;               
            // 0x028B9ED0: MOV v11.16b, v0.16b        | V11 = val_50.x;//m1                     
            // 0x028B9ED4: MOV v13.16b, v1.16b        | V13 = val_50.y;//m1                     
            // 0x028B9ED8: LDR x0, [x8]               | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028B9EDC: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028B9EE0: TBZ w8, #0, #0x28b9ef0     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_94;
            // 0x028B9EE4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028B9EE8: CBNZ w8, #0x28b9ef0        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_94;
            // 0x028B9EEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_94:
            // 0x028B9EF0: LDR s0, [sp, #0xb0]        | S0 = (1f / this.agentTimeHorizon);      
            // 0x028B9EF4: MOV v1.16b, v10.16b        | V1 = val_49.y;//m1                      
            // 0x028B9EF8: MOV v3.16b, v11.16b        | V3 = val_50.x;//m1                      
            // 0x028B9EFC: MOV v4.16b, v13.16b        | V4 = val_50.y;//m1                      
            // 0x028B9F00: FMUL s2, s0, s12           | S2 = ((1f / this.agentTimeHorizon) * (this.radius + val_36.radius));
            float val_51 = val_13 * val_167;
            // 0x028B9F04: MOV v0.16b, v8.16b         | V0 = val_49.x;//m1                      
            // 0x028B9F08: BL #0x28b8b0c              | Pathfinding.RVO.Sampled.Agent.DrawVO(circleCenter:  new UnityEngine.Vector2() {x = val_49.x, y = val_49.y}, radius:  float val_51 = val_13 * val_36.radius, origin:  new UnityEngine.Vector2() {x = val_50.x, y = val_50.y});
            Pathfinding.RVO.Sampled.Agent.DrawVO(circleCenter:  new UnityEngine.Vector2() {x = val_49.x, y = val_49.y}, radius:  val_51, origin:  new UnityEngine.Vector2() {x = val_50.x, y = val_50.y});
            // 0x028B9F0C: B #0x28b9b8c               |  goto label_95;                         
            goto label_95;
            label_70:
            // 0x028B9F10: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B9F14: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028B9F18: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028B9F1C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028B9F20: TBZ w8, #0, #0x28b9f30     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_97;
            // 0x028B9F24: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028B9F28: CBNZ w8, #0x28b9f30        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_97;
            // 0x028B9F2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_97:
            // 0x028B9F30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028B9F34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9F38: BL #0x2697648              | X0 = UnityEngine.Vector2.get_zero();    
            UnityEngine.Vector2 val_52 = UnityEngine.Vector2.zero;
            // 0x028B9F3C: ADRP x22, #0x3626000       | X22 = 56778752 (0x3626000);             
            // 0x028B9F40: LDR x19, [x25, #0xe0]      | X19 = this.simulator; //P2              
            // 0x028B9F44: LDR x22, [x22, #0x470]     | X22 = 1152921504840765440;              
            val_149 = 1152921504840765440;
            // 0x028B9F48: CBNZ x19, #0x28b9f50       | if (this.simulator != null) goto label_98;
            if(this.simulator != null)
            {
                goto label_98;
            }
            // 0x028B9F4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_98:
            // 0x028B9F50: LDR w8, [x19, #0x38]       | W8 = this.simulator.algorithm; //P2     
            // 0x028B9F54: CMP w8, #1                 | STATE = COMPARE(this.simulator.algorithm, 0x1)
            // 0x028B9F58: B.NE #0x28ba7e8            | if (this.simulator.algorithm != 0x1) goto label_99;
            if(this.simulator.algorithm != 1)
            {
                goto label_99;
            }
            // 0x028B9F5C: LDRB w8, [x25, #0xb4]      | W8 = this.<DebugDraw>k__BackingField; //P2 
            // 0x028B9F60: CBZ w8, #0x28ba5a8         | if (this.<DebugDraw>k__BackingField == false) goto label_100;
            if((this.<DebugDraw>k__BackingField) == false)
            {
                goto label_100;
            }
            // 0x028B9F64: LDR x8, [sp, #0xc0]        | X8 = 0x2;                               
            // 0x028B9F68: ADRP x24, #0x35f8000       | X24 = 56590336 (0x35F8000);             
            // 0x028B9F6C: LDR x24, [x24, #0x130]     | X24 = 1152921504692469760;              
            // 0x028B9F70: ADRP x26, #0x3673000       | X26 = 57094144 (0x3673000);             
            // 0x028B9F74: MOV w23, w8                | W23 = 2 (0x2);//ML01                    
            val_145 = 2;
            // 0x028B9F78: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028B9F7C: LDR s0, [x8, #0x79c]       | S0 = 40;                                
            // 0x028B9F80: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028B9F84: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
            // 0x028B9F88: ADD x21, x20, #0x20        | X21 = context.vos[0x20]; //PARR1        
            // 0x028B9F8C: STR s0, [sp, #0xb0]        | stack[1152921513251504976] = 0x42200000;  //  dest_result_addr=1152921513251504976
            // 0x028B9F90: LDR s0, [x8, #0x770]       | S0 = 0.01;                              
            // 0x028B9F94: ADRP x8, #0x2bc6000        | X8 = 45899776 (0x2BC6000);              
            // 0x028B9F98: FMOV s13, wzr              | S13 = 0f;                               
            // 0x028B9F9C: STR s0, [sp, #0xa0]        | stack[1152921513251504960] = 0x3C23D70A;  //  dest_result_addr=1152921513251504960
            // 0x028B9FA0: LDR s0, [x8, #0x6a4]       | S0 = 0.365625;                          
            // 0x028B9FA4: STR s0, [sp, #0x98]        | stack[1152921513251504952] = 0x3EBB3333;  //  dest_result_addr=1152921513251504952
            // 0x028B9FA8: LDR x26, [x26, #0x488]     | X26 = 1152921504695078912;              
            label_136:
            // 0x028B9FAC: SCVTF s0, w9               | S0 = 0;                                 
            float val_168 = 0f;
            // 0x028B9FB0: FMOV s1, #15.00000000      | S1 = 15;                                
            // 0x028B9FB4: FMUL s0, s0, s1            | S0 = (0f * 15f);                        
            val_168 = val_168 * 15f;
            // 0x028B9FB8: LDR s1, [sp, #0xb0]        | S1 = 40;                                
            // 0x028B9FBC: STR w9, [sp, #0x90]        | stack[1152921513251504944] = 0x0;        //  dest_result_addr=1152921513251504944
            // 0x028B9FC0: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            // 0x028B9FC4: FDIV s0, s0, s1            | S0 = ((0f * 15f) / 40f);                
            val_168 = val_168 / 40f;
            // 0x028B9FC8: STR s0, [sp, #0xac]        | stack[1152921513251504972] = ((0f * 15f) / 40f);  //  dest_result_addr=1152921513251504972
            label_135:
            // 0x028B9FCC: SCVTF s0, w27              | S0 = 0;                                 
            float val_169 = 0f;
            // 0x028B9FD0: FMOV s1, #15.00000000      | S1 = 15;                                
            // 0x028B9FD4: FMUL s0, s0, s1            | S0 = (0f * 15f);                        
            val_169 = val_169 * 15f;
            // 0x028B9FD8: LDR s1, [sp, #0xb0]        | S1 = 40;                                
            float val_170 = 40f;
            // 0x028B9FDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028B9FE0: SUB x0, x29, #0xc8         | X0 = (1152921513251505408 - 200) = 1152921513251505208 (0x1000000203430438);
            // 0x028B9FE4: MOV x19, x22               | X19 = 58021168 (0x3755530);//ML01       
            // 0x028B9FE8: FDIV s1, s0, s1            | S1 = ((0f * 15f) / 40f);                
            val_170 = val_169 / val_170;
            // 0x028B9FEC: LDR s0, [sp, #0xac]        | S0 = ((0f * 15f) / 40f);                
            // 0x028B9FF0: MOV x28, x25               | X28 = 1152921513251517424 (0x10000002034333F0);//ML01
            // 0x028B9FF4: BL #0x2697148              | null..ctor(_x:  0f, _y:  40f = 0f / 40f);
            Geometric.Point val_53 = new Geometric.Point(_x:  val_168, _y:  val_170);
            // 0x028B9FF8: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028B9FFC: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA000: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA004: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA008: TBZ w8, #0, #0x28ba018     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_102;
            // 0x028BA00C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA010: CBNZ w8, #0x28ba018        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_102;
            // 0x028BA014: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_102:
            // 0x028BA018: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA01C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA020: BL #0x2697648              | X0 = UnityEngine.Vector2.get_zero();    
            UnityEngine.Vector2 val_54 = UnityEngine.Vector2.zero;
            // 0x028BA024: LDR x8, [sp, #0xc0]        | X8 = 0x2;                               
            // 0x028BA028: MOV v12.16b, v0.16b        | V12 = val_54.x;//m1                     
            // 0x028BA02C: MOV v15.16b, v1.16b        | V15 = val_54.y;//m1                     
            // 0x028BA030: CMP w8, #1                 | STATE = COMPARE(0x2, 0x1)               
            // 0x028BA034: B.LT #0x28ba10c            | if (2 < 0x1) goto label_103;            
            if(2 < 1)
            {
                goto label_103;
            }
            // 0x028BA038: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            // 0x028BA03C: MOV x22, x21               | X22 = context.vos[0x20];//m1            
            var val_171 = context.vos[32];
            // 0x028BA040: MOV v14.16b, v13.16b       | V14 = 0;//m1                            
            label_108:
            // 0x028BA044: STUR wzr, [x29, #-0xcc]    | stack[1152921513251505204] = 0x0;        //  dest_result_addr=1152921513251505204
            // 0x028BA048: CBNZ x20, #0x28ba050       | if (context.vos != null) goto label_104;
            if(context.vos != null)
            {
                goto label_104;
            }
            // 0x028BA04C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_104:
            // 0x028BA050: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BA054: LDP s8, s11, [x29, #-0xc8] | S8 = val_53.x; S11 = val_53.y;           //  | 
            // 0x028BA058: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA05C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA060: LDP s10, s9, [x29, #-0x98] | S10 = val_11.x; S9 = val_11.y;           //  | 
            // 0x028BA064: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA068: TBZ w8, #0, #0x28ba078     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_106;
            // 0x028BA06C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA070: CBNZ w8, #0x28ba078        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_106;
            // 0x028BA074: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_106:
            // 0x028BA078: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA07C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA080: MOV v0.16b, v8.16b         | V0 = val_53.x;//m1                      
            // 0x028BA084: MOV v1.16b, v11.16b        | V1 = val_53.y;//m1                      
            // 0x028BA088: MOV v2.16b, v10.16b        | V2 = val_11.x;//m1                      
            // 0x028BA08C: MOV v3.16b, v9.16b         | V3 = val_11.y;//m1                      
            // 0x028BA090: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_53.x, y = val_53.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_55 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_53.x, y = val_53.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028BA094: LDR w8, [x20, #0x18]       | W8 = context.vos.Length; //P2           
            // 0x028BA098: MOV v8.16b, v0.16b         | V8 = val_55.x;//m1                      
            // 0x028BA09C: MOV v9.16b, v1.16b         | V9 = val_55.y;//m1                      
            // 0x028BA0A0: CMP x25, x8                | STATE = COMPARE(0x0, context.vos.Length)
            // 0x028BA0A4: B.LO #0x28ba0b4            | if (0 < context.vos.Length) goto label_107;
            if(0 < context.vos.Length)
            {
                goto label_107;
            }
            // 0x028BA0A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BA0AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA0B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_107:
            // 0x028BA0B4: SUB x1, x29, #0xcc         | X1 = (1152921513251505408 - 204) = 1152921513251505204 (0x1000000203430434);
            // 0x028BA0B8: MOV x0, x22                | X0 = context.vos[0x20];//m1             
            // 0x028BA0BC: MOV v0.16b, v8.16b         | V0 = val_55.x;//m1                      
            // 0x028BA0C0: MOV v1.16b, v9.16b         | V1 = val_55.y;//m1                      
            // 0x028BA0C4: BL #0x28bc018              | X0 = label_Agent_VO_Det_GL028BC018();   
            // 0x028BA0C8: MOV v2.16b, v0.16b         | V2 = val_55.x;//m1                      
            // 0x028BA0CC: MOV v3.16b, v1.16b         | V3 = val_55.y;//m1                      
            // 0x028BA0D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA0D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA0D8: MOV v0.16b, v12.16b        | V0 = val_54.x;//m1                      
            // 0x028BA0DC: MOV v1.16b, v15.16b        | V1 = val_54.y;//m1                      
            // 0x028BA0E0: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_54.x, y = val_54.y}, b:  new UnityEngine.Vector2() {x = val_55.x, y = val_55.y});
            UnityEngine.Vector2 val_56 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_54.x, y = val_54.y}, b:  new UnityEngine.Vector2() {x = val_55.x, y = val_55.y});
            // 0x028BA0E4: MOV v12.16b, v0.16b        | V12 = val_56.x;//m1                     
            // 0x028BA0E8: LDUR s0, [x29, #-0xcc]     | S0 = 0;                                 
            // 0x028BA0EC: MOV v15.16b, v1.16b        | V15 = val_56.y;//m1                     
            // 0x028BA0F0: ADD x25, x25, #1           | X25 = (0 + 1) = 1 (0x00000001);         
            // 0x028BA0F4: ADD x22, x22, #0x50        | X22 = context.vos[0x20][0x50]; //PARR1  
            // 0x028BA0F8: FCMP s0, s14               | STATE = COMPARE(0, 0)                   
            // 0x028BA0FC: FCSEL s14, s0, s14, gt     | S14 = 0f > 0f ? 0f : 0f;                
            var val_57 = (0f > 0f) ? (0f) : (0f);
            // 0x028BA100: CMP w23, w25               | STATE = COMPARE(0x2, 0x1)               
            // 0x028BA104: B.NE #0x28ba044            | if (val_145 != 1) goto label_108;       
            if(val_145 != 1)
            {
                goto label_108;
            }
            // 0x028BA108: B #0x28ba110               |  goto label_109;                        
            goto label_109;
            label_103:
            // 0x028BA10C: MOV v14.16b, v13.16b       | V14 = 0;//m1                            
            label_109:
            // 0x028BA110: MOV x25, x28               | X25 = 1152921513251517424 (0x10000002034333F0);//ML01
            val_141 = val_141;
            // 0x028BA114: LDR s0, [x25, #0x6c]       | S0 = this.desiredVelocity; //P2         
            // 0x028BA118: LDR s1, [x25, #0x74]       | 
            // 0x028BA11C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA120: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028BA124: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028BA128: BL #0x2697148              | null..ctor(_x:  this.desiredVelocity, _y:  val_54.y);
            Geometric.Point val_58 = new Geometric.Point(_x:  this.desiredVelocity, _y:  val_54.y);
            // 0x028BA12C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BA130: LDP s8, s11, [x29, #-0xc8] | S8 = val_53.x; S11 = val_53.y;           //  | 
            // 0x028BA134: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA138: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA13C: LDP s10, s9, [x29, #-0x98] | S10 = val_11.x; S9 = val_11.y;           //  | 
            // 0x028BA140: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA144: TBZ w8, #0, #0x28ba154     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_111;
            // 0x028BA148: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA14C: CBNZ w8, #0x28ba154        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_111;
            // 0x028BA150: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_111:
            // 0x028BA154: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA15C: MOV v0.16b, v8.16b         | V0 = val_53.x;//m1                      
            // 0x028BA160: MOV v1.16b, v11.16b        | V1 = val_53.y;//m1                      
            // 0x028BA164: MOV v2.16b, v10.16b        | V2 = val_11.x;//m1                      
            // 0x028BA168: MOV v3.16b, v9.16b         | V3 = val_11.y;//m1                      
            // 0x028BA16C: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_53.x, y = val_53.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_59 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_53.x, y = val_53.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028BA170: MOV v2.16b, v0.16b         | V2 = val_59.x;//m1                      
            // 0x028BA174: LDP s0, s3, [sp, #0xe0]    | S0 = val_58.x; S3 = val_58.y;            //  | 
            // 0x028BA178: MOV v4.16b, v1.16b         | V4 = val_59.y;//m1                      
            // 0x028BA17C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA180: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA184: MOV v1.16b, v3.16b         | V1 = val_58.y;//m1                      
            // 0x028BA188: MOV v3.16b, v4.16b         | V3 = val_59.y;//m1                      
            // 0x028BA18C: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_58.x, y = val_58.y}, b:  new UnityEngine.Vector2() {x = val_59.x, y = val_59.y});
            UnityEngine.Vector2 val_60 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_58.x, y = val_58.y}, b:  new UnityEngine.Vector2() {x = val_59.x, y = val_59.y});
            // 0x028BA190: MOV x22, x19               | X22 = 58021168 (0x3755530);//ML01       
            val_149 = val_149;
            // 0x028BA194: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BA198: MOV v8.16b, v0.16b         | V8 = val_60.x;//m1                      
            // 0x028BA19C: MOV v10.16b, v1.16b        | V10 = val_60.y;//m1                     
            // 0x028BA1A0: STP s8, s10, [x29, #-0xd8] | stack[1152921513251505192] = val_60.x;  stack[1152921513251505196] = val_60.y;  //  dest_result_addr=1152921513251505192 |  dest_result_addr=1152921513251505196
            // 0x028BA1A4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BA1A8: TBZ w8, #0, #0x28ba1bc     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_113;
            // 0x028BA1AC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BA1B0: CBNZ w8, #0x28ba1bc        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_113;
            // 0x028BA1B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BA1B8: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            label_113:
            // 0x028BA1BC: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BA1C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA1C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA1C8: MOV v0.16b, v8.16b         | V0 = val_60.x;//m1                      
            // 0x028BA1CC: LDR s2, [x8, #0x14]        | S2 = Pathfinding.RVO.Sampled.Agent.DesiredVelocityScale;
            // 0x028BA1D0: MOV v1.16b, v10.16b        | V1 = val_60.y;//m1                      
            // 0x028BA1D4: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_60.x, y = val_60.y}, d:  Pathfinding.RVO.Sampled.Agent.DesiredVelocityScale);
            UnityEngine.Vector2 val_61 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_60.x, y = val_60.y}, d:  Pathfinding.RVO.Sampled.Agent.DesiredVelocityScale);
            // 0x028BA1D8: MOV v2.16b, v0.16b         | V2 = val_61.x;//m1                      
            // 0x028BA1DC: MOV v3.16b, v1.16b         | V3 = val_61.y;//m1                      
            // 0x028BA1E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA1E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA1E8: MOV v0.16b, v12.16b        | V0 = val_54.x;//m1                      
            // 0x028BA1EC: MOV v1.16b, v15.16b        | V1 = val_54.y;//m1                      
            // 0x028BA1F0: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_54.x, y = val_54.y}, b:  new UnityEngine.Vector2() {x = val_61.x, y = val_61.y});
            UnityEngine.Vector2 val_62 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_54.x, y = val_54.y}, b:  new UnityEngine.Vector2() {x = val_61.x, y = val_61.y});
            // 0x028BA1F4: SUB x0, x29, #0xd8         | X0 = (1152921513251505408 - 216) = 1152921513251505192 (0x1000000203430428);
            // 0x028BA1F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA1FC: MOV v12.16b, v0.16b        | V12 = val_62.x;//m1                     
            // 0x028BA200: MOV v15.16b, v1.16b        | V15 = val_62.y;//m1                     
            // 0x028BA204: BL #0x269749c              | X0 = label_UnityEngine_Vector2_op_Subtraction_GL0269749C();
            // 0x028BA208: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BA20C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BA210: LDR s1, [x8, #0x10]        | S1 = Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight;
            // 0x028BA214: FMUL s0, s0, s1            | S0 = (val_62.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight);
            val_62.x = val_62.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight;
            // 0x028BA218: FCMP s0, s14               | STATE = COMPARE((val_62.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight), 0)
            // 0x028BA21C: B.LE #0x28ba258            | if (val_62.x <= 0f) goto label_114;     
            if(val_62.x <= 0f)
            {
                goto label_114;
            }
            // 0x028BA220: SUB x0, x29, #0xd8         | X0 = (1152921513251505408 - 216) = 1152921513251505192 (0x1000000203430428);
            // 0x028BA224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA228: BL #0x269749c              | X0 = label_UnityEngine_Vector2_op_Subtraction_GL0269749C();
            // 0x028BA22C: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BA230: MOV v8.16b, v0.16b         | V8 = (val_62.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight);//m1
            // 0x028BA234: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BA238: TBZ w8, #0, #0x28ba24c     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_116;
            // 0x028BA23C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BA240: CBNZ w8, #0x28ba24c        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_116;
            // 0x028BA244: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BA248: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            label_116:
            // 0x028BA24C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BA250: LDR s0, [x8, #0x10]        | S0 = Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight;
            // 0x028BA254: FMUL s14, s8, s0           | S14 = ((val_62.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight) * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight);
            float val_63 = val_62.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight;
            label_114:
            // 0x028BA258: FCMP s14, #0.0             | STATE = COMPARE(((val_62.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight) * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight), 0)
            // 0x028BA25C: B.LE #0x28ba29c            | if (val_63 <= 0) goto label_117;        
            if(val_63 <= 0f)
            {
                goto label_117;
            }
            // 0x028BA260: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BA264: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA268: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA26C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA270: TBZ w8, #0, #0x28ba280     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_119;
            // 0x028BA274: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA278: CBNZ w8, #0x28ba280        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_119;
            // 0x028BA27C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_119:
            // 0x028BA280: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA284: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA288: MOV v0.16b, v12.16b        | V0 = val_62.x;//m1                      
            // 0x028BA28C: MOV v1.16b, v15.16b        | V1 = val_62.y;//m1                      
            // 0x028BA290: MOV v2.16b, v14.16b        | V2 = ((val_62.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight) * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight);//m1
            // 0x028BA294: BL #0x2697534              | X0 = UnityEngine.Vector2.op_Division(a:  new UnityEngine.Vector2() {x = val_62.x, y = val_62.y}, d:  val_63);
            UnityEngine.Vector2 val_64 = UnityEngine.Vector2.op_Division(a:  new UnityEngine.Vector2() {x = val_62.x, y = val_62.y}, d:  val_63);
            // 0x028BA298: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            label_117:
            // 0x028BA29C: LDP s9, s8, [x29, #-0xc8]  | S9 = val_53.x; S8 = val_53.y;            //  | 
            // 0x028BA2A0: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BA2A4: TBZ w8, #0, #0x28ba2b4     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_121;
            // 0x028BA2A8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BA2AC: CBNZ w8, #0x28ba2b4        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_121;
            // 0x028BA2B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_121:
            // 0x028BA2B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA2B8: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028BA2BC: MOV v0.16b, v9.16b         | V0 = val_53.x;//m1                      
            // 0x028BA2C0: MOV v1.16b, v13.16b        | V1 = 0;//m1                             
            // 0x028BA2C4: MOV v2.16b, v8.16b         | V2 = val_53.y;//m1                      
            // 0x028BA2C8: STR wzr, [sp, #0xe8]       | stack[1152921513251505032] = 0x0;        //  dest_result_addr=1152921513251505032
            // 0x028BA2CC: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028BA2D0: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028BA2D4: LDR s0, [sp, #0xe0]        | S0 = 0;                                 
            // 0x028BA2D8: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BA2DC: STR s0, [sp, #0xc8]        | stack[1152921513251505000] = 0x0;        //  dest_result_addr=1152921513251505000
            // 0x028BA2E0: LDP s0, s15, [sp, #0xe4]   | S0 = 0; S15 = 0;                         //  | 
            // 0x028BA2E4: STR s0, [sp, #0xbc]        | stack[1152921513251504988] = 0x0;        //  dest_result_addr=1152921513251504988
            // 0x028BA2E8: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA2EC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA2F0: LDP s9, s8, [x29, #-0xd8]  | S9 = val_60.x; S8 = val_60.y;            //  | 
            // 0x028BA2F4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA2F8: TBZ w8, #0, #0x28ba308     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_123;
            // 0x028BA2FC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA300: CBNZ w8, #0x28ba308        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_123;
            // 0x028BA304: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_123:
            // 0x028BA308: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA30C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA310: MOV v0.16b, v9.16b         | V0 = val_60.x;//m1                      
            // 0x028BA314: MOV v1.16b, v8.16b         | V1 = val_60.y;//m1                      
            // 0x028BA318: MOV v2.16b, v13.16b        | V2 = 0;//m1                             
            // 0x028BA31C: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_60.x, y = val_60.y}, d:  0f);
            UnityEngine.Vector2 val_65 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_60.x, y = val_60.y}, d:  0f);
            // 0x028BA320: MOV v2.16b, v1.16b         | V2 = val_65.y;//m1                      
            // 0x028BA324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA328: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028BA32C: MOV v1.16b, v13.16b        | V1 = 0;//m1                             
            // 0x028BA330: STR wzr, [sp, #0xe8]       | stack[1152921513251505032] = 0x0;        //  dest_result_addr=1152921513251505032
            // 0x028BA334: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028BA338: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028BA33C: LDP s8, s10, [sp, #0xe0]   | S8 = 0; S10 = 0;                         //  | 
            val_150 = 0f;
            // 0x028BA340: LDR s11, [sp, #0xe8]       | S11 = 0;                                
            // 0x028BA344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA348: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA34C: BL #0x20d3bd0              | X0 = UnityEngine.Color.get_blue();      
            UnityEngine.Color val_66 = UnityEngine.Color.blue;
            // 0x028BA350: LDR x0, [x24]              | X0 = typeof(UnityEngine.Debug);         
            // 0x028BA354: MOV v13.16b, v0.16b        | V13 = val_66.r;//m1                     
            // 0x028BA358: MOV v9.16b, v1.16b         | V9 = val_66.g;//m1                      
            // 0x028BA35C: MOV v12.16b, v2.16b        | V12 = val_66.b;//m1                     
            // 0x028BA360: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x028BA364: MOV v14.16b, v3.16b        | V14 = val_66.a;//m1                     
            // 0x028BA368: TBZ w8, #0, #0x28ba378     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_125;
            // 0x028BA36C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x028BA370: CBNZ w8, #0x28ba378        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_125;
            // 0x028BA374: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_125:
            // 0x028BA378: STP s12, s14, [sp, #8]     | stack[1152921513251504808] = val_66.b;  stack[1152921513251504812] = val_66.a;  //  dest_result_addr=1152921513251504808 |  dest_result_addr=1152921513251504812
            // 0x028BA37C: STP s13, s9, [sp]          | stack[1152921513251504800] = val_66.r;  stack[1152921513251504804] = val_66.g;  //  dest_result_addr=1152921513251504800 |  dest_result_addr=1152921513251504804
            // 0x028BA380: LDR s0, [sp, #0xc8]        | S0 = 0;                                 
            // 0x028BA384: LDR s1, [sp, #0xbc]        | S1 = 0;                                 
            // 0x028BA388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA38C: MOV v2.16b, v15.16b        | V2 = 0 (0x0);//ML01                     
            // 0x028BA390: MOV v3.16b, v8.16b         | V3 = 0 (0x0);//ML01                     
            // 0x028BA394: MOV v4.16b, v10.16b        | V4 = 0 (0x0);//ML01                     
            // 0x028BA398: MOV v5.16b, v11.16b        | V5 = 0 (0x0);//ML01                     
            // 0x028BA39C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA3A0: BL #0x1a5cee8              | UnityEngine.Debug.DrawRay(start:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, dir:  new UnityEngine.Vector3() {x = 0f, y = val_150, z = 0f}, color:  new UnityEngine.Color() {r = val_66.r, g = val_66.b});
            UnityEngine.Debug.DrawRay(start:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, dir:  new UnityEngine.Vector3() {x = 0f, y = val_150, z = 0f}, color:  new UnityEngine.Color() {r = val_66.r, g = val_66.b});
            // 0x028BA3A4: LDP s8, s9, [x29, #-0xc8]  | S8 = val_53.x; S9 = val_53.y;            //  | 
            // 0x028BA3A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA3AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA3B0: STUR wzr, [x29, #-0xdc]    | stack[1152921513251505188] = 0x0;        //  dest_result_addr=1152921513251505188
            // 0x028BA3B4: BL #0x2698414              | X0 = UnityEngine.Vector2.get_one();     
            UnityEngine.Vector2 val_67 = UnityEngine.Vector2.one;
            // 0x028BA3B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA3BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA3C0: FMOV s2, #15.00000000      | S2 = 15;                                
            // 0x028BA3C4: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_67.x, y = val_67.y}, d:  15f);
            UnityEngine.Vector2 val_68 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_67.x, y = val_67.y}, d:  15f);
            // 0x028BA3C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA3CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA3D0: FMOV s2, #0.50000000       | S2 = 0.5;                               
            // 0x028BA3D4: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_68.x, y = val_68.y}, d:  0.5f);
            UnityEngine.Vector2 val_69 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_68.x, y = val_68.y}, d:  0.5f);
            // 0x028BA3D8: MOV v2.16b, v0.16b         | V2 = val_69.x;//m1                      
            // 0x028BA3DC: MOV v3.16b, v1.16b         | V3 = val_69.y;//m1                      
            // 0x028BA3E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA3E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA3E8: MOV v0.16b, v8.16b         | V0 = val_53.x;//m1                      
            // 0x028BA3EC: MOV v1.16b, v9.16b         | V1 = val_53.y;//m1                      
            // 0x028BA3F0: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_53.x, y = val_53.y}, b:  new UnityEngine.Vector2() {x = val_69.x, y = val_69.y});
            UnityEngine.Vector2 val_70 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_53.x, y = val_53.y}, b:  new UnityEngine.Vector2() {x = val_69.x, y = val_69.y});
            // 0x028BA3F4: LDR x2, [sp, #0xc0]        | X2 = 0x2;                               
            // 0x028BA3F8: LDR s2, [sp, #0xa0]        | S2 = 0.01;                              
            // 0x028BA3FC: SUB x3, x29, #0xdc         | X3 = (1152921513251505408 - 220) = 1152921513251505188 (0x1000000203430424);
            // 0x028BA400: MOV x0, x25                | X0 = 1152921513251517424 (0x10000002034333F0);//ML01
            // 0x028BA404: MOV x1, x20                | X1 = context.vos;//m1                   
            // 0x028BA408: MOV v8.16b, v0.16b         | V8 = val_70.x;//m1                      
            // 0x028BA40C: MOV v9.16b, v1.16b         | V9 = val_70.y;//m1                      
            val_153 = val_70.y;
            // 0x028BA410: BL #0x28bc2b4              | X0 = this.Trace(vos:  context.vos, voCount:  2, p:  new UnityEngine.Vector2() {x = val_70.x, y = val_70.y}, cutoff:  0.01f, score: out  float val_71 = 5.73101E-37f);
            UnityEngine.Vector2 val_72 = this.Trace(vos:  context.vos, voCount:  2, p:  new UnityEngine.Vector2() {x = val_70.x, y = val_70.y}, cutoff:  0.01f, score: out  float val_71 = 5.73101E-37f);
            // 0x028BA414: MOV v12.16b, v0.16b        | V12 = val_72.x;//m1                     
            val_154 = val_72.x;
            // 0x028BA418: MOV v14.16b, v1.16b        | V14 = val_72.y;//m1                     
            val_155 = val_72.y;
            // 0x028BA41C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA424: MOV v0.16b, v8.16b         | V0 = val_70.x;//m1                      
            // 0x028BA428: MOV v1.16b, v9.16b         | V1 = val_70.y;//m1                      
            // 0x028BA42C: MOV v2.16b, v12.16b        | V2 = val_72.x;//m1                      
            // 0x028BA430: MOV v3.16b, v14.16b        | V3 = val_72.y;//m1                      
            // 0x028BA434: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_70.x, y = val_153}, b:  new UnityEngine.Vector2() {x = val_154, y = val_155});
            UnityEngine.Vector2 val_73 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_70.x, y = val_153}, b:  new UnityEngine.Vector2() {x = val_154, y = val_155});
            // 0x028BA438: SUB x0, x29, #0xe8         | X0 = (1152921513251505408 - 232) = 1152921513251505176 (0x1000000203430418);
            // 0x028BA43C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA440: STP s0, s1, [x29, #-0xe8]  | stack[1152921513251505176] = val_73.x;  stack[1152921513251505180] = val_73.y;  //  dest_result_addr=1152921513251505176 |  dest_result_addr=1152921513251505180
            // 0x028BA444: BL #0x2697ba0              | X0 = val_73.x.get_sqrMagnitude();       
            float val_74 = val_73.x.sqrMagnitude;
            // 0x028BA448: LDR s1, [sp, #0x98]        | S1 = 0.365625;                          
            // 0x028BA44C: FCMP s0, s1                | STATE = COMPARE(val_74, 0.365624994039536)
            // 0x028BA450: B.PL #0x28ba588            | if (val_74 >= 0) goto label_126;        
            if(val_74 >= 0)
            {
                goto label_126;
            }
            // 0x028BA454: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BA458: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA45C: FMOV s10, wzr              | S10 = 0f;                               
            // 0x028BA460: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA464: LDP s9, s8, [x29, #-0x98]  | S9 = val_11.x; S8 = val_11.y;            //  | 
            // 0x028BA468: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA46C: TBZ w8, #0, #0x28ba47c     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_128;
            // 0x028BA470: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA474: CBNZ w8, #0x28ba47c        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_128;
            // 0x028BA478: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_128:
            // 0x028BA47C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA480: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA484: MOV v0.16b, v12.16b        | V0 = val_72.x;//m1                      
            // 0x028BA488: MOV v1.16b, v14.16b        | V1 = val_72.y;//m1                      
            // 0x028BA48C: MOV v2.16b, v9.16b         | V2 = val_11.x;//m1                      
            // 0x028BA490: MOV v3.16b, v8.16b         | V3 = val_11.y;//m1                      
            // 0x028BA494: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_154, y = val_155}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_75 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_154, y = val_155}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028BA498: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BA49C: MOV v8.16b, v0.16b         | V8 = val_75.x;//m1                      
            // 0x028BA4A0: MOV v9.16b, v1.16b         | V9 = val_75.y;//m1                      
            // 0x028BA4A4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BA4A8: TBZ w8, #0, #0x28ba4b8     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_130;
            // 0x028BA4AC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BA4B0: CBNZ w8, #0x28ba4b8        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_130;
            // 0x028BA4B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_130:
            // 0x028BA4B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA4BC: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028BA4C0: MOV v0.16b, v8.16b         | V0 = val_75.x;//m1                      
            // 0x028BA4C4: MOV v1.16b, v10.16b        | V1 = 0;//m1                             
            // 0x028BA4C8: MOV v2.16b, v9.16b         | V2 = val_75.y;//m1                      
            // 0x028BA4CC: STR wzr, [sp, #0xe8]       | stack[1152921513251505032] = 0x0;        //  dest_result_addr=1152921513251505032
            // 0x028BA4D0: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028BA4D4: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028BA4D8: LDR x0, [x26]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x028BA4DC: LDP s15, s0, [sp, #0xe0]   | S15 = 0; S0 = 0;                         //  | 
            // 0x028BA4E0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x028BA4E4: STR s0, [sp, #0xbc]        | stack[1152921513251504988] = 0x0;        //  dest_result_addr=1152921513251504988
            // 0x028BA4E8: LDR s0, [sp, #0xe8]        | S0 = 0;                                 
            // 0x028BA4EC: STR s0, [sp, #0xc8]        | stack[1152921513251505000] = 0x0;        //  dest_result_addr=1152921513251505000
            // 0x028BA4F0: TBZ w8, #0, #0x28ba500     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_132;
            // 0x028BA4F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x028BA4F8: CBNZ w8, #0x28ba500        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_132;
            // 0x028BA4FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_132:
            // 0x028BA500: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA504: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA508: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
            UnityEngine.Vector3 val_76 = UnityEngine.Vector3.up;
            // 0x028BA50C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA510: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA514: FMOV s3, #1.00000000       | S3 = 1;                                 
            // 0x028BA518: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_76.x, y = val_76.y, z = val_76.z}, d:  1f);
            UnityEngine.Vector3 val_77 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_76.x, y = val_76.y, z = val_76.z}, d:  1f);
            // 0x028BA51C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA524: MOV v11.16b, v0.16b        | V11 = val_77.x;//m1                     
            // 0x028BA528: MOV v8.16b, v1.16b         | V8 = val_77.y;//m1                      
            // 0x028BA52C: MOV v10.16b, v2.16b        | V10 = val_77.z;//m1                     
            val_150 = val_77.z;
            // 0x028BA530: BL #0x20d3ba8              | X0 = UnityEngine.Color.get_red();       
            UnityEngine.Color val_78 = UnityEngine.Color.red;
            // 0x028BA534: LDR x0, [x24]              | X0 = typeof(UnityEngine.Debug);         
            // 0x028BA538: MOV v13.16b, v0.16b        | V13 = val_78.r;//m1                     
            // 0x028BA53C: MOV v9.16b, v1.16b         | V9 = val_78.g;//m1                      
            val_153 = val_78.g;
            // 0x028BA540: MOV v12.16b, v2.16b        | V12 = val_78.b;//m1                     
            val_154 = val_78.b;
            // 0x028BA544: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x028BA548: MOV v14.16b, v3.16b        | V14 = val_78.a;//m1                     
            val_155 = val_78.a;
            // 0x028BA54C: TBZ w8, #0, #0x28ba55c     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_134;
            // 0x028BA550: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x028BA554: CBNZ w8, #0x28ba55c        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_134;
            // 0x028BA558: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_134:
            // 0x028BA55C: STP s12, s14, [sp, #8]     | stack[1152921513251504808] = val_78.b;  stack[1152921513251504812] = val_78.a;  //  dest_result_addr=1152921513251504808 |  dest_result_addr=1152921513251504812
            // 0x028BA560: STP s13, s9, [sp]          | stack[1152921513251504800] = val_78.r;  stack[1152921513251504804] = val_78.g;  //  dest_result_addr=1152921513251504800 |  dest_result_addr=1152921513251504804
            // 0x028BA564: LDR s1, [sp, #0xbc]        | S1 = 0;                                 
            // 0x028BA568: LDR s2, [sp, #0xc8]        | S2 = 0;                                 
            // 0x028BA56C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA570: MOV v0.16b, v15.16b        | V0 = 0 (0x0);//ML01                     
            // 0x028BA574: MOV v3.16b, v11.16b        | V3 = val_77.x;//m1                      
            // 0x028BA578: MOV v4.16b, v8.16b         | V4 = val_77.y;//m1                      
            // 0x028BA57C: MOV v5.16b, v10.16b        | V5 = val_77.z;//m1                      
            // 0x028BA580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA584: BL #0x1a5cee8              | UnityEngine.Debug.DrawRay(start:  new UnityEngine.Vector3() {x = 0f, y = 0f}, dir:  new UnityEngine.Vector3() {x = val_77.x, y = val_77.y, z = val_150}, color:  new UnityEngine.Color() {r = val_78.r, g = val_154});
            UnityEngine.Debug.DrawRay(start:  new UnityEngine.Vector3() {x = 0f, y = 0f}, dir:  new UnityEngine.Vector3() {x = val_77.x, y = val_77.y, z = val_150}, color:  new UnityEngine.Color() {r = val_78.r, g = val_154});
            label_126:
            // 0x028BA588: ADD w27, w27, #1           | W27 = (0 + 1);                          
            val_146 = 0 + 1;
            // 0x028BA58C: FMOV s13, wzr              | S13 = 0f;                               
            // 0x028BA590: CMP w27, #0x28             | STATE = COMPARE((0 + 1), 0x28)          
            // 0x028BA594: B.NE #0x28b9fcc            | if (val_146 != 0x28) goto label_135;    
            if(val_146 != 40)
            {
                goto label_135;
            }
            // 0x028BA598: LDR w9, [sp, #0x90]        | W9 = 0x0;                               
            // 0x028BA59C: ADD w9, w9, #1             | W9 = (0 + 1) = val_143 (0x00000001);    
            val_143 = 1;
            // 0x028BA5A0: CMP w9, #0x28              | STATE = COMPARE(0x1, 0x28)              
            // 0x028BA5A4: B.NE #0x28b9fac            | if (val_143 != 0x28) goto label_136;    
            if(val_143 != 40)
            {
                goto label_136;
            }
            label_100:
            // 0x028BA5A8: ORR w8, wzr, #0x7f800000   | W8 = 2139095040(0x7F800000);            
            // 0x028BA5AC: STUR w8, [x29, #-0xec]     | stack[1152921513251505172] = 0x7F800000;  //  dest_result_addr=1152921513251505172
            // 0x028BA5B0: LDR s0, [x25, #0xc8]       | S0 = this.velocity; //P2                
            // 0x028BA5B4: LDR s1, [x25, #0xd0]       | 
            // 0x028BA5B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA5BC: SUB x0, x29, #0xf8         | X0 = (1152921513251505408 - 248) = 1152921513251505160 (0x1000000203430408);
            // 0x028BA5C0: BL #0x2697148              | null..ctor(_x:  this.velocity, _y:  0f);
            Geometric.Point val_79 = new Geometric.Point(_x:  this.velocity, _y:  0f);
            // 0x028BA5C4: SUB x0, x29, #0xf8         | X0 = (1152921513251505408 - 248) = 1152921513251505160 (0x1000000203430408);
            // 0x028BA5C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA5CC: BL #0x269749c              | X0 = label_UnityEngine_Vector2_op_Subtraction_GL0269749C();
            // 0x028BA5D0: LDR x19, [x25, #0xe0]      | X19 = this.simulator; //P2              
            val_140 = this.simulator;
            // 0x028BA5D4: MOV v8.16b, v0.16b         | V8 = this.velocity;//m1                 
            float val_172 = this.velocity;
            // 0x028BA5D8: CBNZ x19, #0x28ba5e0       | if (this.simulator != null) goto label_137;
            if(val_140 != null)
            {
                goto label_137;
            }
            // 0x028BA5DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000203430408, ????);
            label_137:
            // 0x028BA5E0: LDR s2, [x19, #0x48]       | S2 = this.simulator.qualityCutoff; //P2 
            // 0x028BA5E4: LDR s0, [x25, #0x6c]       | S0 = this.desiredVelocity; //P2         
            // 0x028BA5E8: LDR s1, [x25, #0x74]       | 
            // 0x028BA5EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA5F0: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028BA5F4: FMUL s8, s8, s2            | S8 = (this.velocity * this.simulator.qualityCutoff);
            val_172 = val_172 * this.simulator.qualityCutoff;
            // 0x028BA5F8: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028BA5FC: BL #0x2697148              | null..ctor(_x:  this.desiredVelocity, _y:  0f);
            Geometric.Point val_80 = new Geometric.Point(_x:  this.desiredVelocity, _y:  0f);
            // 0x028BA600: LDP s0, s1, [sp, #0xe0]    | S0 = val_80.x; S1 = val_80.y;            //  | 
            // 0x028BA604: LDR x2, [sp, #0xc0]        | X2 = 0x2;                               
            // 0x028BA608: SUB x3, x29, #0xec         | X3 = (1152921513251505408 - 236) = 1152921513251505172 (0x1000000203430414);
            // 0x028BA60C: MOV x0, x25                | X0 = 1152921513251517424 (0x10000002034333F0);//ML01
            // 0x028BA610: MOV x1, x20                | X1 = context.vos;//m1                   
            // 0x028BA614: MOV v2.16b, v8.16b         | V2 = (this.velocity * this.simulator.qualityCutoff);//m1
            // 0x028BA618: BL #0x28bc2b4              | X0 = this.Trace(vos:  context.vos, voCount:  2, p:  new UnityEngine.Vector2() {x = val_80.x, y = val_80.y}, cutoff:  this.velocity, score: out  float val_81 = 5.731003E-37f);
            UnityEngine.Vector2 val_82 = this.Trace(vos:  context.vos, voCount:  2, p:  new UnityEngine.Vector2() {x = val_80.x, y = val_80.y}, cutoff:  val_172, score: out  float val_81 = 5.731003E-37f);
            // 0x028BA61C: LDRB w8, [x25, #0xb4]      | W8 = this.<DebugDraw>k__BackingField; //P2 
            // 0x028BA620: STR s0, [sp, #0x54]        | stack[1152921513251504884] = val_82.x;   //  dest_result_addr=1152921513251504884
            // 0x028BA624: STR s1, [sp, #0x50]        | stack[1152921513251504880] = val_82.y;   //  dest_result_addr=1152921513251504880
            // 0x028BA628: CBZ w8, #0x28ba6c4         | if (this.<DebugDraw>k__BackingField == false) goto label_138;
            if((this.<DebugDraw>k__BackingField) == false)
            {
                goto label_138;
            }
            // 0x028BA62C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BA630: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA634: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA638: LDP s10, s9, [x29, #-0x98] | S10 = val_11.x; S9 = val_11.y;           //  | 
            // 0x028BA63C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA640: TBZ w8, #0, #0x28ba650     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_140;
            // 0x028BA644: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA648: CBNZ w8, #0x28ba650        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_140;
            // 0x028BA64C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_140:
            // 0x028BA650: LDP s1, s0, [sp, #0x50]    | S1 = val_82.y; S0 = val_82.x;            //  | 
            // 0x028BA654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA65C: MOV v2.16b, v10.16b        | V2 = val_11.x;//m1                      
            // 0x028BA660: MOV v3.16b, v9.16b         | V3 = val_11.y;//m1                      
            // 0x028BA664: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_82.x, y = val_82.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_83 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_82.x, y = val_82.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028BA668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA66C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA670: MOV v9.16b, v0.16b         | V9 = val_83.x;//m1                      
            // 0x028BA674: MOV v10.16b, v1.16b        | V10 = val_83.y;//m1                     
            val_150 = val_83.y;
            // 0x028BA678: BL #0x20d3c0c              | X0 = UnityEngine.Color.get_yellow();    
            UnityEngine.Color val_84 = UnityEngine.Color.yellow;
            // 0x028BA67C: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BA680: MOV v11.16b, v0.16b        | V11 = val_84.r;//m1                     
            // 0x028BA684: MOV v12.16b, v1.16b        | V12 = val_84.g;//m1                     
            val_154 = val_84.g;
            // 0x028BA688: MOV v14.16b, v2.16b        | V14 = val_84.b;//m1                     
            val_155 = val_84.b;
            // 0x028BA68C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BA690: MOV v13.16b, v3.16b        | V13 = val_84.a;//m1                     
            // 0x028BA694: TBZ w8, #0, #0x28ba6a4     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_142;
            // 0x028BA698: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BA69C: CBNZ w8, #0x28ba6a4        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_142;
            // 0x028BA6A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_142:
            // 0x028BA6A4: FMOV s6, #0.50000000       | S6 = 0.5;                               
            // 0x028BA6A8: MOV v0.16b, v9.16b         | V0 = val_83.x;//m1                      
            // 0x028BA6AC: MOV v1.16b, v10.16b        | V1 = val_83.y;//m1                      
            // 0x028BA6B0: MOV v2.16b, v11.16b        | V2 = val_84.r;//m1                      
            // 0x028BA6B4: MOV v3.16b, v12.16b        | V3 = val_84.g;//m1                      
            // 0x028BA6B8: MOV v4.16b, v14.16b        | V4 = val_84.b;//m1                      
            // 0x028BA6BC: MOV v5.16b, v13.16b        | V5 = val_84.a;//m1                      
            // 0x028BA6C0: BL #0x28b9100              | Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = val_83.x, y = val_150}, col:  new UnityEngine.Color() {r = val_84.r, g = val_154, b = val_155, a = val_84.a}, size:  0.5f);
            Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = val_83.x, y = val_150}, col:  new UnityEngine.Color() {r = val_84.r, g = val_154, b = val_155, a = val_84.a}, size:  0.5f);
            label_138:
            // 0x028BA6C4: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BA6C8: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA6CC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA6D0: LDP s11, s10, [x25, #0xa8] | S11 = this.<Velocity>k__BackingField; //P2   //  | 
            // 0x028BA6D4: LDR s9, [x25, #0xb0]       | 
            // 0x028BA6D8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA6DC: TBZ w8, #0, #0x28ba6ec     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_144;
            // 0x028BA6E0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA6E4: CBNZ w8, #0x28ba6ec        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_144;
            // 0x028BA6E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_144:
            // 0x028BA6EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA6F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA6F4: MOV v0.16b, v11.16b        | V0 = this.<Velocity>k__BackingField;//m1
            // 0x028BA6F8: MOV v1.16b, v10.16b        | V1 = val_83.y;//m1                      
            // 0x028BA6FC: MOV v2.16b, v9.16b         | V2 = val_83.x;//m1                      
            // 0x028BA700: BL #0x2698408              | X0 = UnityEngine.Vector2.op_Implicit(v:  new UnityEngine.Vector3() {x = this.<Velocity>k__BackingField, y = val_150, z = val_83.x});
            UnityEngine.Vector2 val_85 = UnityEngine.Vector2.op_Implicit(v:  new UnityEngine.Vector3() {x = this.<Velocity>k__BackingField, y = val_150, z = val_83.x});
            // 0x028BA704: LDR x2, [sp, #0xc0]        | X2 = 0x2;                               
            // 0x028BA708: SUB x3, x29, #0xfc         | X3 = (1152921513251505408 - 252) = 1152921513251505156 (0x1000000203430404);
            // 0x028BA70C: MOV x0, x25                | X0 = 1152921513251517424 (0x10000002034333F0);//ML01
            // 0x028BA710: MOV x1, x20                | X1 = context.vos;//m1                   
            // 0x028BA714: MOV v2.16b, v8.16b         | V2 = (this.velocity * this.simulator.qualityCutoff);//m1
            // 0x028BA718: BL #0x28bc2b4              | X0 = this.Trace(vos:  context.vos, voCount:  2, p:  new UnityEngine.Vector2() {x = val_85.x, y = val_85.y}, cutoff:  this.velocity, score: out  float val_86 = 5.730996E-37f);
            UnityEngine.Vector2 val_87 = this.Trace(vos:  context.vos, voCount:  2, p:  new UnityEngine.Vector2() {x = val_85.x, y = val_85.y}, cutoff:  val_172, score: out  float val_86 = 5.730996E-37f);
            // 0x028BA71C: MOV v8.16b, v0.16b         | V8 = val_87.x;//m1                      
            // 0x028BA720: LDUR s0, [x29, #-0xfc]     | S0 = 0;                                 
            val_161 = 0f;
            // 0x028BA724: LDUR s2, [x29, #-0xec]     | S2 = Infinity;                          
            // 0x028BA728: MOV v9.16b, v1.16b         | V9 = val_87.y;//m1                      
            // 0x028BA72C: FCMP s0, s2                | STATE = COMPARE(0, Infinity)            
            // 0x028BA730: B.PL #0x28ba73c            | if (val_161 >= 0) goto label_145;       
            if(val_161 >= 0)
            {
                goto label_145;
            }
            // 0x028BA734: STUR s0, [x29, #-0xec]     | stack[1152921513251505172] = 0;          //  dest_result_addr=1152921513251505172
            // 0x028BA738: STP s9, s8, [sp, #0x50]    | stack[1152921513251504880] = val_87.y;  stack[1152921513251504884] = val_87.x;  //  dest_result_addr=1152921513251504880 |  dest_result_addr=1152921513251504884
            label_145:
            // 0x028BA73C: LDRB w8, [x25, #0xb4]      | W8 = this.<DebugDraw>k__BackingField; //P2 
            // 0x028BA740: CBZ w8, #0x28bb82c         | if (this.<DebugDraw>k__BackingField == false) goto label_276;
            if((this.<DebugDraw>k__BackingField) == false)
            {
                goto label_276;
            }
            // 0x028BA744: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BA748: STR x25, [sp, #0x70]       | stack[1152921513251504912] = this;       //  dest_result_addr=1152921513251504912
            // 0x028BA74C: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA750: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA754: LDP s11, s10, [x29, #-0x98] | S11 = val_11.x; S10 = val_11.y;          //  | 
            // 0x028BA758: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA75C: TBZ w8, #0, #0x28ba76c     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_148;
            // 0x028BA760: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA764: CBNZ w8, #0x28ba76c        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_148;
            // 0x028BA768: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_148:
            // 0x028BA76C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA774: MOV v0.16b, v8.16b         | V0 = val_87.x;//m1                      
            // 0x028BA778: MOV v1.16b, v9.16b         | V1 = val_87.y;//m1                      
            // 0x028BA77C: MOV v2.16b, v11.16b        | V2 = val_11.x;//m1                      
            // 0x028BA780: MOV v3.16b, v10.16b        | V3 = val_11.y;//m1                      
            // 0x028BA784: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_87.x, y = val_87.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_88 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_87.x, y = val_87.y}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028BA788: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA78C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA790: MOV v8.16b, v0.16b         | V8 = val_88.x;//m1                      
            val_162 = val_88.x;
            // 0x028BA794: MOV v9.16b, v1.16b         | V9 = val_88.y;//m1                      
            // 0x028BA798: BL #0x20d3c3c              | X0 = UnityEngine.Color.get_magenta();   
            UnityEngine.Color val_89 = UnityEngine.Color.magenta;
            // 0x028BA79C: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BA7A0: MOV v10.16b, v0.16b        | V10 = val_89.r;//m1                     
            val_158 = val_89.r;
            // 0x028BA7A4: MOV v11.16b, v1.16b        | V11 = val_89.g;//m1                     
            // 0x028BA7A8: MOV v13.16b, v2.16b        | V13 = val_89.b;//m1                     
            // 0x028BA7AC: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BA7B0: MOV v12.16b, v3.16b        | V12 = val_89.a;//m1                     
            val_154 = val_89.a;
            // 0x028BA7B4: TBZ w8, #0, #0x28ba7c4     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_150;
            // 0x028BA7B8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BA7BC: CBNZ w8, #0x28ba7c4        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_150;
            // 0x028BA7C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_150:
            // 0x028BA7C4: FMOV s6, #0.50000000       | S6 = 0.5;                               
            // 0x028BA7C8: MOV v0.16b, v8.16b         | V0 = val_88.x;//m1                      
            val_161 = val_162;
            // 0x028BA7CC: MOV v1.16b, v9.16b         | V1 = val_88.y;//m1                      
            // 0x028BA7D0: MOV v2.16b, v10.16b        | V2 = val_89.r;//m1                      
            // 0x028BA7D4: MOV v3.16b, v11.16b        | V3 = val_89.g;//m1                      
            // 0x028BA7D8: MOV v4.16b, v13.16b        | V4 = val_89.b;//m1                      
            // 0x028BA7DC: MOV v5.16b, v12.16b        | V5 = val_89.a;//m1                      
            // 0x028BA7E0: BL #0x28b9100              | Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = val_161, y = val_88.y}, col:  new UnityEngine.Color() {r = val_158, g = val_89.g, b = val_89.b, a = val_154}, size:  0.5f);
            Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = val_161, y = val_88.y}, col:  new UnityEngine.Color() {r = val_158, g = val_89.g, b = val_89.b, a = val_154}, size:  0.5f);
            // 0x028BA7E4: B #0x28bb7b4               |  goto label_151;                        
            goto label_151;
            label_99:
            // 0x028BA7E8: LDR x22, [sp, #0x98]       | X22 = 0x3EBB3333;                       
            // 0x028BA7EC: CBZ x22, #0x28ba7f8        | if (0x3EBB3333 == 0) goto label_152;    
            if(0.365625f == 0)
            {
                goto label_152;
            }
            // 0x028BA7F0: LDR x23, [x22, #0x30]      | X23 = mem[1052455779];                  
            val_145 = mem[1052455779];
            // 0x028BA7F4: B #0x28ba808               |  goto label_153;                        
            goto label_153;
            label_152:
            // 0x028BA7F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028BA7FC: ORR w8, wzr, #0x30         | W8 = 48(0x30);                          
            // 0x028BA800: LDR x23, [x8]              | X23 = 0x38004000000000;                 
            val_145 = 0;
            // 0x028BA804: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_153:
            // 0x028BA808: LDR s0, [x25, #0x6c]       | S0 = this.desiredVelocity; //P2         
            // 0x028BA80C: LDR s1, [x25, #0x74]       | 
            // 0x028BA810: LDR x21, [x22, #0x38]      | X21 = mem[1052455787];                  
            var val_174 = mem[1052455787];
            // 0x028BA814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA818: ADD x0, sp, #0x158         | X0 = (1152921513251504800 + 344) = 1152921513251505144 (0x10000002034303F8);
            // 0x028BA81C: BL #0x2697148              | null..ctor(_x:  this.desiredVelocity, _y:  val_52.y);
            Geometric.Point val_90 = new Geometric.Point(_x:  this.desiredVelocity, _y:  val_52.y);
            // 0x028BA820: LDR s8, [x25, #0x34]       | S8 = this.radius; //P2                  
            float val_173 = this.radius;
            // 0x028BA824: ADD x0, sp, #0x158         | X0 = (1152921513251504800 + 344) = 1152921513251505144 (0x10000002034303F8);
            // 0x028BA828: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA82C: BL #0x269749c              | X0 = label_UnityEngine_Vector2_op_Subtraction_GL0269749C();
            // 0x028BA830: LDP w8, w9, [x25, #0xa8]   | W8 = this.<Velocity>k__BackingField; //P2   //  | 
            // 0x028BA834: LDR w10, [x25, #0xb0]      | 
            // 0x028BA838: ADD x0, sp, #0x148         | X0 = (1152921513251504800 + 328) = 1152921513251505128 (0x10000002034303E8);
            // 0x028BA83C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA840: MOV v10.16b, v0.16b        | V10 = this.desiredVelocity;//m1         
            // 0x028BA844: STR w8, [sp, #0x148]       | stack[1152921513251505128] = this.<Velocity>k__BackingField;  //  dest_result_addr=1152921513251505128
            // 0x028BA848: STR w9, [sp, #0x14c]       | stack[1152921513251505132] = 0x15C;      //  dest_result_addr=1152921513251505132
            // 0x028BA84C: STR w10, [sp, #0x150]      | stack[1152921513251505136] = ???;        //  dest_result_addr=1152921513251505136
            // 0x028BA850: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
            // 0x028BA854: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028BA858: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x028BA85C: MOV v9.16b, v0.16b         | V9 = this.desiredVelocity;//m1          
            // 0x028BA860: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x028BA864: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028BA868: TBZ w8, #0, #0x28ba878     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_155;
            // 0x028BA86C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028BA870: CBNZ w8, #0x28ba878        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_155;
            // 0x028BA874: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_155:
            // 0x028BA878: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA87C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA880: MOV v0.16b, v10.16b        | V0 = this.desiredVelocity;//m1          
            // 0x028BA884: MOV v1.16b, v9.16b         | V1 = this.desiredVelocity;//m1          
            // 0x028BA888: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  this.desiredVelocity, b:  this.desiredVelocity);
            float val_91 = UnityEngine.Mathf.Max(a:  this.desiredVelocity, b:  this.desiredVelocity);
            // 0x028BA88C: MOV v1.16b, v0.16b         | V1 = val_91;//m1                        
            // 0x028BA890: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA894: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA898: MOV v0.16b, v8.16b         | V0 = this.radius;//m1                   
            // 0x028BA89C: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  this.radius, b:  val_91);
            float val_92 = UnityEngine.Mathf.Max(a:  val_173, b:  val_91);
            // 0x028BA8A0: STR s0, [sp, #0xbc]        | stack[1152921513251504988] = val_92;     //  dest_result_addr=1152921513251504988
            // 0x028BA8A4: CBNZ x23, #0x28ba8ac       | if (0x38004000000000 != 0) goto label_156;
            if(val_145 != 0)
            {
                goto label_156;
            }
            // 0x028BA8A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_156:
            // 0x028BA8AC: LDR x19, [sp, #0x158]      | X19 = val_90.x;                         
            // 0x028BA8B0: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BA8B4: CBNZ w8, #0x28ba8c4        | if (mem[15762873573703704] != 0) goto label_157;
            if(mem[15762873573703704] != 0)
            {
                goto label_157;
            }
            // 0x028BA8B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BA8BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA8C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_157:
            // 0x028BA8C4: STR x19, [x23, #0x20]      | mem[15762873573703712] = val_90.x;       //  dest_result_addr=15762873573703712
            mem[15762873573703712] = val_90.x;
            // 0x028BA8C8: CBNZ x21, #0x28ba8d0       | if (mem[1052455787] != 0) goto label_158;
            if(val_174 != 0)
            {
                goto label_158;
            }
            // 0x028BA8CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_158:
            // 0x028BA8D0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028BA8D4: LDR s0, [x8, #0x934]       | S0 = 0.3;                               
            // 0x028BA8D8: LDR s1, [sp, #0xbc]        | S1 = val_92;                            
            // 0x028BA8DC: LDR w8, [x21, #0x18]       | W8 = mem[1052455787] + 24;              
            // 0x028BA8E0: FMUL s8, s1, s0            | S8 = (val_92 * 0.3f);                   
            val_173 = val_92 * 0.3f;
            // 0x028BA8E4: CBNZ w8, #0x28ba8f4        | if (mem[1052455787] + 24 != 0) goto label_159;
            if((mem[1052455787] + 24) != 0)
            {
                goto label_159;
            }
            // 0x028BA8E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BA8EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA8F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_159:
            // 0x028BA8F4: STR s8, [x21, #0x20]       | mem2[0] = (val_92 * 0.3f);               //  dest_result_addr=0
            mem2[0] = val_173;
            // 0x028BA8F8: CBNZ x23, #0x28ba900       | if (0x38004000000000 != 0) goto label_160;
            if(val_145 != 0)
            {
                goto label_160;
            }
            // 0x028BA8FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_160:
            // 0x028BA900: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BA904: LDUR x19, [x29, #-0xa0]    | X19 = val_12.x;                         
            // 0x028BA908: CMP w8, #1                 | STATE = COMPARE(mem[15762873573703704], 0x1)
            // 0x028BA90C: B.HI #0x28ba91c            | if (mem[15762873573703704] > 0x1) goto label_161;
            if(mem[15762873573703704] > 1)
            {
                goto label_161;
            }
            // 0x028BA910: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BA914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA918: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_161:
            // 0x028BA91C: STR x19, [x23, #0x28]      | mem[15762873573703720] = val_12.x;       //  dest_result_addr=15762873573703720
            mem[15762873573703720] = val_12.x;
            // 0x028BA920: CBNZ x21, #0x28ba928       | if (mem[1052455787] != 0) goto label_162;
            if(val_174 != 0)
            {
                goto label_162;
            }
            // 0x028BA924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_162:
            // 0x028BA928: LDR w8, [x21, #0x18]       | W8 = mem[1052455787] + 24;              
            // 0x028BA92C: CMP w8, #1                 | STATE = COMPARE(mem[1052455787] + 24, 0x1)
            // 0x028BA930: B.HI #0x28ba940            | if (mem[1052455787] + 24 > 0x1) goto label_163;
            if((mem[1052455787] + 24) > 1)
            {
                goto label_163;
            }
            // 0x028BA934: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BA938: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA93C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_163:
            // 0x028BA940: STR s8, [x21, #0x24]       | mem2[0] = (val_92 * 0.3f);               //  dest_result_addr=0
            mem2[0] = val_173;
            // 0x028BA944: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BA948: STR x25, [sp, #0x70]       | stack[1152921513251504912] = this;       //  dest_result_addr=1152921513251504912
            // 0x028BA94C: STR s8, [sp, #0xb0]        | stack[1152921513251504976] = (val_92 * 0.3f);  //  dest_result_addr=1152921513251504976
            // 0x028BA950: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BA954: MOV x24, x21               | X24 = mem[1052455787];//m1              
            // 0x028BA958: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BA95C: LDP s9, s8, [x29, #-0xa0]  | S9 = val_12.x; S8 = val_12.y;            //  | 
            // 0x028BA960: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BA964: TBZ w8, #0, #0x28ba974     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_165;
            // 0x028BA968: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BA96C: CBNZ w8, #0x28ba974        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_165;
            // 0x028BA970: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_165:
            // 0x028BA974: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BA978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA97C: MOV v0.16b, v9.16b         | V0 = val_12.x;//m1                      
            // 0x028BA980: MOV v1.16b, v8.16b         | V1 = val_12.y;//m1                      
            // 0x028BA984: FMOV s2, #0.50000000       | S2 = 0.5;                               
            // 0x028BA988: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, d:  0.5f);
            UnityEngine.Vector2 val_93 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, d:  0.5f);
            // 0x028BA98C: MOV v11.16b, v0.16b        | V11 = val_93.x;//m1                     
            // 0x028BA990: MOV v12.16b, v1.16b        | V12 = val_93.y;//m1                     
            // 0x028BA994: FNEG s1, s11               | S1 = -(val_93.x);                       
            // 0x028BA998: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BA99C: ADD x0, sp, #0x140         | X0 = (1152921513251504800 + 320) = 1152921513251505120 (0x10000002034303E0);
            // 0x028BA9A0: MOV v0.16b, v12.16b        | V0 = val_93.y;//m1                      
            // 0x028BA9A4: BL #0x2697148              | null..ctor(_x:  val_93.y, _y:  -val_93.x);
            Geometric.Point val_94 = new Geometric.Point(_x:  val_93.y, _y:  -val_93.x);
            // 0x028BA9A8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028BA9AC: LDR s15, [x8, #0xd6c]      | S15 = 3.141593;                         
            // 0x028BA9B0: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            var val_178 = 0;
            // 0x028BA9B4: ADD x21, x24, #0x28        | X21 = (mem[1052455787] + 40);           
            val_174 = val_174 + 40;
            // 0x028BA9B8: ADD x25, x23, #0x34        | X25 = (val_145 + 52);                   
            var val_95 = val_145 + 52;
            label_174:
            // 0x028BA9BC: CBNZ x23, #0x28ba9c4       | if (0x38004000000000 != 0) goto label_166;
            if(val_145 != 0)
            {
                goto label_166;
            }
            // 0x028BA9C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  val_93.y, _y:  -val_93.x), ????);
            label_166:
            // 0x028BA9C4: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028BA9C8: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x028BA9CC: LDR s13, [sp, #0x140]      | S13 = val_94.x;                         
            // 0x028BA9D0: LDR s8, [sp, #0x144]       | S8 = val_94.y;                          
            // 0x028BA9D4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x028BA9D8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028BA9DC: TBZ w8, #0, #0x28ba9ec     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_168;
            // 0x028BA9E0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028BA9E4: CBNZ w8, #0x28ba9ec        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_168;
            // 0x028BA9E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_168:
            // 0x028BA9EC: SCVTF s10, w19             | S10 = 0;                                
            // 0x028BA9F0: FMUL s0, s10, s15          | S0 = (0f * 3.141593f);                  
            float val_96 = 0f * 3.141593f;
            // 0x028BA9F4: FADD s0, s0, s0            | S0 = ((0f * 3.141593f) + (0f * 3.141593f));
            val_96 = val_96 + val_96;
            // 0x028BA9F8: FMOV s1, #0.12500000       | S1 = 0.125;                             
            // 0x028BA9FC: FMUL s14, s0, s1           | S14 = (((0f * 3.141593f) + (0f * 3.141593f)) * 0.125f);
            float val_97 = val_96 * 0.125f;
            // 0x028BAA00: MOV v0.16b, v14.16b        | V0 = (((0f * 3.141593f) + (0f * 3.141593f)) * 0.125f);//m1
            // 0x028BAA04: ADD x26, x19, #2           | X26 = (0 + 2);                          
            var val_98 = val_178 + 2;
            // 0x028BAA08: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028BAA0C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BAA10: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BAA14: MOV v9.16b, v0.16b         | V9 = (((0f * 3.141593f) + (0f * 3.141593f)) * 0.125f);//m1
            // 0x028BAA18: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BAA1C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BAA20: TBZ w8, #0, #0x28baa30     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_170;
            // 0x028BAA24: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BAA28: CBNZ w8, #0x28baa30        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_170;
            // 0x028BAA2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_170:
            // 0x028BAA30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BAA34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAA38: MOV v0.16b, v13.16b        | V0 = val_94.x;//m1                      
            // 0x028BAA3C: MOV v1.16b, v8.16b         | V1 = val_94.y;//m1                      
            // 0x028BAA40: MOV v2.16b, v9.16b         | V2 = (((0f * 3.141593f) + (0f * 3.141593f)) * 0.125f);//m1
            // 0x028BAA44: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_94.x, y = val_94.y}, d:  val_97);
            UnityEngine.Vector2 val_99 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_94.x, y = val_94.y}, d:  val_97);
            // 0x028BAA48: MOV v8.16b, v0.16b         | V8 = val_99.x;//m1                      
            // 0x028BAA4C: MOV v0.16b, v14.16b        | V0 = (((0f * 3.141593f) + (0f * 3.141593f)) * 0.125f);//m1
            // 0x028BAA50: MOV v9.16b, v1.16b         | V9 = val_99.y;//m1                      
            // 0x028BAA54: BL #0x981480               | X0 = sub_981480( ?? 0x0, ????);         
            // 0x028BAA58: FMOV s1, #1.00000000       | S1 = 1;                                 
            // 0x028BAA5C: FADD s2, s0, s1            | S2 = ((((0f * 3.141593f) + (0f * 3.141593f)) * 0.125f) + 1f);
            float val_100 = val_97 + 1f;
            // 0x028BAA60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BAA64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAA68: MOV v0.16b, v11.16b        | V0 = val_93.x;//m1                      
            // 0x028BAA6C: MOV v1.16b, v12.16b        | V1 = val_93.y;//m1                      
            // 0x028BAA70: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_93.x, y = val_93.y}, d:  float val_100 = val_97 + 1f);
            UnityEngine.Vector2 val_101 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_93.x, y = val_93.y}, d:  val_100);
            // 0x028BAA74: MOV v2.16b, v0.16b         | V2 = val_101.x;//m1                     
            // 0x028BAA78: MOV v3.16b, v1.16b         | V3 = val_101.y;//m1                     
            // 0x028BAA7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BAA80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAA84: MOV v0.16b, v8.16b         | V0 = val_99.x;//m1                      
            // 0x028BAA88: MOV v1.16b, v9.16b         | V1 = val_99.y;//m1                      
            // 0x028BAA8C: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_99.x, y = val_99.y}, b:  new UnityEngine.Vector2() {x = val_101.x, y = val_101.y});
            UnityEngine.Vector2 val_102 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_99.x, y = val_99.y}, b:  new UnityEngine.Vector2() {x = val_101.x, y = val_101.y});
            // 0x028BAA90: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BAA94: MOV v8.16b, v0.16b         | V8 = val_102.x;//m1                     
            // 0x028BAA98: MOV v9.16b, v1.16b         | V9 = val_102.y;//m1                     
            // 0x028BAA9C: CMP x26, x8                | STATE = COMPARE((0 + 2), mem[15762873573703704])
            // 0x028BAAA0: B.LO #0x28baab0            | if (val_98 < mem[15762873573703704]) goto label_171;
            if(val_98 < mem[15762873573703704])
            {
                goto label_171;
            }
            // 0x028BAAA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BAAA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAAAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_171:
            // 0x028BAAB0: FMOV s0, #-4.00000000      | S0 = -4;                                
            float val_175 = -4f;
            // 0x028BAAB4: FADD s0, s10, s0           | S0 = (0f + -4f);                        
            val_175 = 0f + val_175;
            // 0x028BAAB8: STUR s8, [x25, #-4]        | mem2[0] = val_102.x;                     //  dest_result_addr=0
            mem2[0] = val_102.x;
            // 0x028BAABC: FABS s8, s0                | S8 = System.Math.Abs((0f + -4f));       
            float val_176 = System.Math.Abs(val_175);
            // 0x028BAAC0: STR s9, [x25]              | mem2[0] = val_102.y;                     //  dest_result_addr=0
            mem2[0] = val_102.y;
            // 0x028BAAC4: CBNZ x24, #0x28baacc       | if (mem[1052455787] != 0) goto label_172;
            if(val_174 != 0)
            {
                goto label_172;
            }
            // 0x028BAAC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_172:
            // 0x028BAACC: FMOV s0, #-0.12500000      | S0 = -0.125;                            
            float val_177 = -0.125f;
            // 0x028BAAD0: FMUL s0, s8, s0            | S0 = ((0f + -4f) * -0.125f);            
            val_177 = val_176 * val_177;
            // 0x028BAAD4: FMOV s1, #1.00000000       | S1 = 1;                                 
            // 0x028BAAD8: FADD s0, s0, s1            | S0 = (((0f + -4f) * -0.125f) + 1f);     
            val_177 = val_177 + 1f;
            // 0x028BAADC: LDR s1, [sp, #0xbc]        | S1 = val_92;                            
            // 0x028BAAE0: LDR w8, [x24, #0x18]       | W8 = mem[1052455787] + 24;              
            // 0x028BAAE4: FMUL s0, s1, s0            | S0 = (val_92 * (((0f + -4f) * -0.125f) + 1f));
            val_177 = val_92 * val_177;
            // 0x028BAAE8: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x028BAAEC: FMUL s8, s0, s1            | S8 = ((val_92 * (((0f + -4f) * -0.125f) + 1f)) * 0.5f);
            val_176 = val_177 * 0.5f;
            // 0x028BAAF0: CMP x26, x8                | STATE = COMPARE((0 + 2), mem[1052455787] + 24)
            // 0x028BAAF4: B.LO #0x28bab04            | if (val_98 < mem[1052455787] + 24) goto label_173;
            if(val_98 < (mem[1052455787] + 24))
            {
                goto label_173;
            }
            // 0x028BAAF8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BAAFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAB00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_173:
            // 0x028BAB04: STR s8, [x21, x19, lsl #2] | mem2[0] = ((val_92 * (((0f + -4f) * -0.125f) + 1f)) * 0.5f);  //  dest_result_addr=0
            mem2[0] = val_176;
            // 0x028BAB08: ADD x19, x19, #1           | X19 = (0 + 1);                          
            val_178 = val_178 + 1;
            // 0x028BAB0C: ADD x25, x25, #8           | X25 = ((val_145 + 52) + 8);             
            val_95 = val_95 + 8;
            // 0x028BAB10: CMP w19, #8                | STATE = COMPARE((0 + 1), 0x8)           
            // 0x028BAB14: B.NE #0x28ba9bc            | if (0 != 0x8) goto label_174;           
            if(val_178 != 8)
            {
                goto label_174;
            }
            // 0x028BAB18: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BAB1C: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BAB20: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BAB24: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BAB28: TBZ w8, #0, #0x28bab38     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_176;
            // 0x028BAB2C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BAB30: CBNZ w8, #0x28bab38        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_176;
            // 0x028BAB34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_176:
            // 0x028BAB38: ADRP x8, #0x2a93000        | X8 = 44642304 (0x2A93000);              
            // 0x028BAB3C: LDR s8, [x8, #0x440]       | S8 = 0.6;                               
            // 0x028BAB40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BAB44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAB48: MOV v0.16b, v11.16b        | V0 = val_93.x;//m1                      
            // 0x028BAB4C: MOV v1.16b, v12.16b        | V1 = val_93.y;//m1                      
            // 0x028BAB50: MOV v2.16b, v8.16b         | V2 = 1058642330 (0x3F19999A);//ML01     
            // 0x028BAB54: STR s8, [sp, #0xac]        | stack[1152921513251504972] = 0x3F19999A;  //  dest_result_addr=1152921513251504972
            // 0x028BAB58: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_93.x, y = val_93.y}, d:  0.6f);
            UnityEngine.Vector2 val_103 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_93.x, y = val_93.y}, d:  0.6f);
            // 0x028BAB5C: LDR s2, [sp, #0x144]       | S2 = val_94.y;                          
            // 0x028BAB60: MOV v11.16b, v0.16b        | V11 = val_103.x;//m1                    
            // 0x028BAB64: LDR s0, [sp, #0x140]       | S0 = val_94.x;                          
            // 0x028BAB68: MOV v12.16b, v1.16b        | V12 = val_103.y;//m1                    
            // 0x028BAB6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BAB70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAB74: MOV v1.16b, v2.16b         | V1 = val_94.y;//m1                      
            // 0x028BAB78: MOV v2.16b, v8.16b         | V2 = 1058642330 (0x3F19999A);//ML01     
            // 0x028BAB7C: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_94.x, y = val_94.y}, d:  0.6f);
            UnityEngine.Vector2 val_104 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_94.x, y = val_94.y}, d:  0.6f);
            // 0x028BAB80: ADRP x8, #0x2bc6000        | X8 = 45899776 (0x2BC6000);              
            // 0x028BAB84: LDR s10, [x8, #0x6a0]      | S10 = 1.666667;                         
            // 0x028BAB88: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            var val_180 = 0;
            // 0x028BAB8C: ADD x21, x23, #0x74        | X21 = (val_145 + 116);                  
            var val_105 = val_145 + 116;
            // 0x028BAB90: ADD x25, x24, #0x48        | X25 = (mem[1052455787] + 72);           
            var val_106 = val_174 + 72;
            // 0x028BAB94: STR s0, [sp, #0x140]       | stack[1152921513251505120] = val_104.x;  //  dest_result_addr=1152921513251505120
            // 0x028BAB98: STR s1, [sp, #0x144]       | stack[1152921513251505124] = val_104.y;  //  dest_result_addr=1152921513251505124
            label_185:
            // 0x028BAB9C: CBNZ x23, #0x28baba4       | if (0x38004000000000 != 0) goto label_177;
            if(val_145 != 0)
            {
                goto label_177;
            }
            // 0x028BABA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_177:
            // 0x028BABA4: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028BABA8: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x028BABAC: LDR s14, [sp, #0x140]      | S14 = val_104.x;                        
            // 0x028BABB0: LDR s13, [sp, #0x144]      | S13 = val_104.y;                        
            // 0x028BABB4: ADD x26, x19, #0xa         | X26 = (0 + 10);                         
            var val_107 = val_180 + 10;
            // 0x028BABB8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x028BABBC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028BABC0: TBZ w8, #0, #0x28babd0     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_179;
            // 0x028BABC4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028BABC8: CBNZ w8, #0x28babd0        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_179;
            // 0x028BABCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_179:
            // 0x028BABD0: SCVTF s0, w19              | S0 = 0;                                 
            float val_179 = 0f;
            // 0x028BABD4: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x028BABD8: FADD s0, s0, s1            | S0 = (0f + 0.5f);                       
            val_179 = val_179 + 0.5f;
            // 0x028BABDC: FMUL s0, s0, s15           | S0 = ((0f + 0.5f) * 3.141593f);         
            val_179 = val_179 * 3.141593f;
            // 0x028BABE0: FADD s0, s0, s0            | S0 = (((0f + 0.5f) * 3.141593f) + ((0f + 0.5f) * 3.141593f));
            val_179 = val_179 + val_179;
            // 0x028BABE4: FMOV s1, #6.00000000       | S1 = 6;                                 
            // 0x028BABE8: FDIV s8, s0, s1            | S8 = ((((0f + 0.5f) * 3.141593f) + ((0f + 0.5f) * 3.141593f)) / 6f);
            float val_108 = val_179 / 6f;
            // 0x028BABEC: MOV v0.16b, v8.16b         | V0 = ((((0f + 0.5f) * 3.141593f) + ((0f + 0.5f) * 3.141593f)) / 6f);//m1
            // 0x028BABF0: BL #0x981480               | X0 = sub_981480( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028BABF4: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BABF8: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BABFC: MOV v9.16b, v0.16b         | V9 = ((((0f + 0.5f) * 3.141593f) + ((0f + 0.5f) * 3.141593f)) / 6f);//m1
            // 0x028BAC00: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BAC04: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BAC08: TBZ w8, #0, #0x28bac18     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_181;
            // 0x028BAC0C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BAC10: CBNZ w8, #0x28bac18        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_181;
            // 0x028BAC14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_181:
            // 0x028BAC18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BAC1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAC20: MOV v0.16b, v14.16b        | V0 = val_104.x;//m1                     
            // 0x028BAC24: MOV v1.16b, v13.16b        | V1 = val_104.y;//m1                     
            // 0x028BAC28: MOV v2.16b, v9.16b         | V2 = ((((0f + 0.5f) * 3.141593f) + ((0f + 0.5f) * 3.141593f)) / 6f);//m1
            // 0x028BAC2C: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_104.x, y = val_104.y}, d:  val_108);
            UnityEngine.Vector2 val_109 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_104.x, y = val_104.y}, d:  val_108);
            // 0x028BAC30: MOV v9.16b, v0.16b         | V9 = val_109.x;//m1                     
            // 0x028BAC34: MOV v0.16b, v8.16b         | V0 = ((((0f + 0.5f) * 3.141593f) + ((0f + 0.5f) * 3.141593f)) / 6f);//m1
            // 0x028BAC38: MOV v13.16b, v1.16b        | V13 = val_109.y;//m1                    
            // 0x028BAC3C: BL #0x9811b0               | X0 = sub_9811B0( ?? 0x0, ????);         
            // 0x028BAC40: FADD s2, s0, s10           | S2 = (((((0f + 0.5f) * 3.141593f) + ((0f + 0.5f) * 3.141593f)) / 6f) + 1.666667f);
            float val_110 = val_108 + 1.666667f;
            // 0x028BAC44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BAC48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAC4C: MOV v0.16b, v11.16b        | V0 = val_103.x;//m1                     
            // 0x028BAC50: MOV v1.16b, v12.16b        | V1 = val_103.y;//m1                     
            // 0x028BAC54: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_103.x, y = val_103.y}, d:  float val_110 = val_108 + 1.666667f);
            UnityEngine.Vector2 val_111 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_103.x, y = val_103.y}, d:  val_110);
            // 0x028BAC58: MOV v2.16b, v0.16b         | V2 = val_111.x;//m1                     
            // 0x028BAC5C: MOV v3.16b, v1.16b         | V3 = val_111.y;//m1                     
            val_164 = val_111.y;
            // 0x028BAC60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BAC64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAC68: MOV v0.16b, v9.16b         | V0 = val_109.x;//m1                     
            // 0x028BAC6C: MOV v1.16b, v13.16b        | V1 = val_109.y;//m1                     
            // 0x028BAC70: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_109.x, y = val_109.y}, b:  new UnityEngine.Vector2() {x = val_111.x, y = val_164});
            UnityEngine.Vector2 val_112 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_109.x, y = val_109.y}, b:  new UnityEngine.Vector2() {x = val_111.x, y = val_164});
            // 0x028BAC74: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BAC78: MOV v8.16b, v0.16b         | V8 = val_112.x;//m1                     
            // 0x028BAC7C: MOV v9.16b, v1.16b         | V9 = val_112.y;//m1                     
            // 0x028BAC80: CMP w26, w8                | STATE = COMPARE((0 + 10), mem[15762873573703704])
            // 0x028BAC84: B.LO #0x28bac94            | if (val_107 < mem[15762873573703704]) goto label_182;
            if(val_107 < mem[15762873573703704])
            {
                goto label_182;
            }
            // 0x028BAC88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BAC8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAC90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_182:
            // 0x028BAC94: STUR s8, [x21, #-4]        | mem2[0] = val_112.x;                     //  dest_result_addr=0
            mem2[0] = val_112.x;
            // 0x028BAC98: STR s9, [x21]              | mem2[0] = val_112.y;                     //  dest_result_addr=0
            mem2[0] = val_112.y;
            // 0x028BAC9C: CBNZ x24, #0x28baca4       | if (mem[1052455787] != 0) goto label_183;
            if(val_174 != 0)
            {
                goto label_183;
            }
            // 0x028BACA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_183:
            // 0x028BACA4: LDR w8, [x24, #0x18]       | W8 = mem[1052455787] + 24;              
            // 0x028BACA8: CMP w26, w8                | STATE = COMPARE((0 + 10), mem[1052455787] + 24)
            // 0x028BACAC: B.LO #0x28bacbc            | if (val_107 < mem[1052455787] + 24) goto label_184;
            if(val_107 < (mem[1052455787] + 24))
            {
                goto label_184;
            }
            // 0x028BACB0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BACB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BACB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_184:
            // 0x028BACBC: LDR s0, [sp, #0xb0]        | S0 = (val_92 * 0.3f);                   
            // 0x028BACC0: ADD x21, x21, #8           | X21 = ((val_145 + 116) + 8);            
            val_105 = val_105 + 8;
            // 0x028BACC4: STR s0, [x25, x19, lsl #2] | mem2[0] = (val_92 * 0.3f);               //  dest_result_addr=0
            mem2[0] = val_173;
            // 0x028BACC8: ADD x19, x19, #1           | X19 = (0 + 1);                          
            val_180 = val_180 + 1;
            // 0x028BACCC: CMP w19, #6                | STATE = COMPARE((0 + 1), 0x6)           
            // 0x028BACD0: B.NE #0x28bab9c            | if (0 != 0x6) goto label_185;           
            if(val_180 != 6)
            {
                goto label_185;
            }
            // 0x028BACD4: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028BACD8: LDR s0, [x8, #0x7ac]       | S0 = 0.2;                               
            // 0x028BACDC: LDR s1, [sp, #0xbc]        | S1 = val_92;                            
            // 0x028BACE0: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_165 = 0;
            // 0x028BACE4: FMUL s10, s1, s0           | S10 = (val_92 * 0.2f);                  
            float val_113 = val_92 * 0.2f;
            // 0x028BACE8: FADD s11, s10, s10         | S11 = ((val_92 * 0.2f) + (val_92 * 0.2f));
            float val_114 = val_113 + val_113;
            // 0x028BACEC: B #0x28bacfc               |  goto label_186;                        
            goto label_186;
            label_196:
            // 0x028BACF0: ADD x8, x24, x25, lsl #2   | X8 = (mem[1052455787] + ((mem[1052455787] + 72)) << 2);
            var val_115 = val_174 + (((mem[1052455787] + 72)) << 2);
            // 0x028BACF4: ADD w19, w19, #1           | W19 = (val_165 + 1) = val_165 (0x00000001);
            val_165 = 1;
            // 0x028BACF8: STR s11, [x8, #0x20]       | mem2[0] = ((val_92 * 0.2f) + (val_92 * 0.2f));  //  dest_result_addr=0
            mem2[0] = val_114;
            label_186:
            // 0x028BACFC: CBNZ x23, #0x28bad04       | if (0x38004000000000 != 0) goto label_187;
            if(val_145 != 0)
            {
                goto label_187;
            }
            // 0x028BAD00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_187:
            // 0x028BAD04: LDP s13, s12, [x29, #-0xa0] | S13 = val_12.x; S12 = val_12.y;          //  | 
            // 0x028BAD08: CMP w19, #6                | STATE = COMPARE(0x1, 0x6)               
            // 0x028BAD0C: B.GE #0x28bae08            | if (val_165 >= 0x6) goto label_188;     
            if(val_165 >= 6)
            {
                goto label_188;
            }
            // 0x028BAD10: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028BAD14: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x028BAD18: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x028BAD1C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028BAD20: TBZ w8, #0, #0x28bad30     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_190;
            // 0x028BAD24: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028BAD28: CBNZ w8, #0x28bad30        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_190;
            // 0x028BAD2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_190:
            // 0x028BAD30: SCVTF s0, w19              | S0 = 1;                                 
            float val_181 = 1f;
            // 0x028BAD34: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x028BAD38: FADD s0, s0, s1            | S0 = (1f + 0.5f);                       
            val_181 = val_181 + 0.5f;
            // 0x028BAD3C: FMUL s0, s0, s15           | S0 = ((1f + 0.5f) * 3.141593f);         
            val_181 = val_181 * 3.141593f;
            // 0x028BAD40: FADD s0, s0, s0            | S0 = (((1f + 0.5f) * 3.141593f) + ((1f + 0.5f) * 3.141593f));
            val_181 = val_181 + val_181;
            // 0x028BAD44: FMOV s1, #6.00000000       | S1 = 6;                                 
            float val_182 = 6f;
            // 0x028BAD48: FDIV s8, s0, s1            | S8 = ((((1f + 0.5f) * 3.141593f) + ((1f + 0.5f) * 3.141593f)) / 6f);
            float val_116 = val_181 / val_182;
            // 0x028BAD4C: MOV v0.16b, v8.16b         | V0 = ((((1f + 0.5f) * 3.141593f) + ((1f + 0.5f) * 3.141593f)) / 6f);//m1
            // 0x028BAD50: ADD w21, w19, #0x10        | W21 = (val_165 + 16);                   
            var val_117 = val_165 + 16;
            // 0x028BAD54: BL #0x981480               | X0 = sub_981480( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028BAD58: MOV v9.16b, v0.16b         | V9 = ((((1f + 0.5f) * 3.141593f) + ((1f + 0.5f) * 3.141593f)) / 6f);//m1
            // 0x028BAD5C: MOV v0.16b, v8.16b         | V0 = ((((1f + 0.5f) * 3.141593f) + ((1f + 0.5f) * 3.141593f)) / 6f);//m1
            // 0x028BAD60: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028BAD64: FMUL s2, s10, s9           | S2 = ((val_92 * 0.2f) * ((((1f + 0.5f) * 3.141593f) + ((1f + 0.5f) * 3.141593f)) / 6f));
            float val_118 = val_113 * val_116;
            // 0x028BAD68: FMUL s1, s10, s0           | S1 = ((val_92 * 0.2f) * ((((1f + 0.5f) * 3.141593f) + ((1f + 0.5f) * 3.141593f)) / 6f));
            val_182 = val_113 * val_116;
            // 0x028BAD6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAD70: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028BAD74: MOV v0.16b, v2.16b         | V0 = ((val_92 * 0.2f) * ((((1f + 0.5f) * 3.141593f) + ((1f + 0.5f) * 3.141593f)) / 6f));//m1
            // 0x028BAD78: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028BAD7C: BL #0x2697148              | null..ctor(_x:  val_118, _y:  6f = val_113 * val_116);
            Geometric.Point val_119 = new Geometric.Point(_x:  val_118, _y:  val_182);
            // 0x028BAD80: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BAD84: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BAD88: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BAD8C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BAD90: TBZ w8, #0, #0x28bada0     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_192;
            // 0x028BAD94: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BAD98: CBNZ w8, #0x28bada0        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_192;
            // 0x028BAD9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_192:
            // 0x028BADA0: LDP s2, s3, [sp, #0xe0]    | S2 = val_119.x; S3 = val_119.y;          //  | 
            // 0x028BADA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BADA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BADAC: MOV v0.16b, v13.16b        | V0 = val_12.x;//m1                      
            // 0x028BADB0: MOV v1.16b, v12.16b        | V1 = val_12.y;//m1                      
            // 0x028BADB4: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, b:  new UnityEngine.Vector2() {x = val_119.x, y = val_119.y});
            UnityEngine.Vector2 val_120 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, b:  new UnityEngine.Vector2() {x = val_119.x, y = val_119.y});
            // 0x028BADB8: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BADBC: MOV v8.16b, v0.16b         | V8 = val_120.x;//m1                     
            // 0x028BADC0: MOV v9.16b, v1.16b         | V9 = val_120.y;//m1                     
            // 0x028BADC4: SXTW x25, w21              | X25 = (long)(int)((val_165 + 16));      
            // 0x028BADC8: CMP w21, w8                | STATE = COMPARE((val_165 + 16), mem[15762873573703704])
            // 0x028BADCC: B.LO #0x28baddc            | if (val_117 < mem[15762873573703704]) goto label_193;
            if(val_117 < mem[15762873573703704])
            {
                goto label_193;
            }
            // 0x028BADD0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BADD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BADD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_193:
            // 0x028BADDC: ADD x8, x23, x25, lsl #3   | X8 = (val_145 + ((long)(int)((val_165 + 16))) << 3);
            var val_121 = val_145 + (((long)(int)((val_165 + 16))) << 3);
            // 0x028BADE0: STP s8, s9, [x8, #0x20]    | mem2[0] = val_120.x;  mem2[0] = val_120.y;  //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = val_120.x;
            mem2[0] = val_120.y;
            // 0x028BADE4: CBNZ x24, #0x28badec       | if (mem[1052455787] != 0) goto label_194;
            if(val_174 != 0)
            {
                goto label_194;
            }
            // 0x028BADE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_194:
            // 0x028BADEC: LDR w8, [x24, #0x18]       | W8 = mem[1052455787] + 24;              
            // 0x028BADF0: CMP w21, w8                | STATE = COMPARE((val_165 + 16), mem[1052455787] + 24)
            // 0x028BADF4: B.LO #0x28bacf0            | if (val_117 < mem[1052455787] + 24) goto label_196;
            if(val_117 < (mem[1052455787] + 24))
            {
                goto label_196;
            }
            // 0x028BADF8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BADFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAE00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x028BAE04: B #0x28bacf0               |  goto label_196;                        
            goto label_196;
            label_188:
            // 0x028BAE08: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BAE0C: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BAE10: ADD w21, w19, #0x10        | W21 = (val_165 + 16);                   
            var val_122 = val_165 + 16;
            // 0x028BAE14: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BAE18: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BAE1C: TBZ w8, #0, #0x28bae2c     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_198;
            // 0x028BAE20: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BAE24: CBNZ w8, #0x28bae2c        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_198;
            // 0x028BAE28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_198:
            // 0x028BAE2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BAE30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAE34: FMOV s2, #0.50000000       | S2 = 0.5;                               
            // 0x028BAE38: MOV v0.16b, v13.16b        | V0 = val_12.x;//m1                      
            // 0x028BAE3C: MOV v1.16b, v12.16b        | V1 = val_12.y;//m1                      
            // 0x028BAE40: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, d:  0.5f);
            UnityEngine.Vector2 val_123 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_12.x, y = val_12.y}, d:  0.5f);
            // 0x028BAE44: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BAE48: MOV v8.16b, v0.16b         | V8 = val_123.x;//m1                     
            // 0x028BAE4C: MOV v9.16b, v1.16b         | V9 = val_123.y;//m1                     
            // 0x028BAE50: SXTW x25, w21              | X25 = (long)(int)((val_165 + 16));      
            // 0x028BAE54: CMP w21, w8                | STATE = COMPARE((val_165 + 16), mem[15762873573703704])
            // 0x028BAE58: B.LO #0x28bae68            | if (val_122 < mem[15762873573703704]) goto label_199;
            if(val_122 < mem[15762873573703704])
            {
                goto label_199;
            }
            // 0x028BAE5C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BAE60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAE64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_199:
            // 0x028BAE68: ADD x8, x23, x25, lsl #3   | X8 = (val_145 + ((long)(int)((val_165 + 16))) << 3);
            var val_124 = val_145 + (((long)(int)((val_165 + 16))) << 3);
            // 0x028BAE6C: STP s8, s9, [x8, #0x20]    | mem2[0] = val_123.x;  mem2[0] = val_123.y;  //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = val_123.x;
            mem2[0] = val_123.y;
            // 0x028BAE70: CBNZ x24, #0x28bae78       | if (mem[1052455787] != 0) goto label_200;
            if(val_174 != 0)
            {
                goto label_200;
            }
            // 0x028BAE74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_200:
            // 0x028BAE78: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028BAE7C: LDR s0, [x8, #0x790]       | S0 = 0.4;                               
            // 0x028BAE80: LDR s1, [sp, #0xbc]        | S1 = val_92;                            
            // 0x028BAE84: LDR w8, [x24, #0x18]       | W8 = mem[1052455787] + 24;              
            // 0x028BAE88: FMUL s8, s1, s0            | S8 = (val_92 * 0.4f);                   
            float val_125 = val_92 * 0.4f;
            // 0x028BAE8C: CMP w21, w8                | STATE = COMPARE((val_165 + 16), mem[1052455787] + 24)
            // 0x028BAE90: B.LO #0x28baea0            | if (val_122 < mem[1052455787] + 24) goto label_201;
            if(val_122 < (mem[1052455787] + 24))
            {
                goto label_201;
            }
            // 0x028BAE94: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BAE98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAE9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_201:
            // 0x028BAEA0: ADD x8, x24, x25, lsl #2   | X8 = (mem[1052455787] + ((long)(int)((val_165 + 16))) << 2);
            var val_126 = val_174 + (((long)(int)((val_165 + 16))) << 2);
            // 0x028BAEA4: ADD w25, w19, #0x11        | W25 = (val_165 + 17);                   
            var val_127 = val_165 + 17;
            // 0x028BAEA8: STR s8, [x8, #0x20]        | mem2[0] = (val_92 * 0.4f);               //  dest_result_addr=0
            mem2[0] = val_125;
            // 0x028BAEAC: CBZ x22, #0x28baebc        | if (0x3EBB3333 == 0) goto label_202;    
            if(0.365625f == 0)
            {
                goto label_202;
            }
            // 0x028BAEB0: STR x24, [sp, #0xc8]       | stack[1152921513251505000] = mem[1052455787];  //  dest_result_addr=1152921513251505000
            // 0x028BAEB4: LDP x24, x26, [x22, #0x18] | X24 = mem[1052455755]; X26 = mem[1052455763]; //  | 
            val_168 = mem[1052455755];
            val_169 = mem[1052455763];
            // 0x028BAEB8: B #0x28baedc               |  goto label_203;                        
            goto label_203;
            label_202:
            // 0x028BAEBC: STR x24, [sp, #0xc8]       | stack[1152921513251505000] = mem[1052455787];  //  dest_result_addr=1152921513251505000
            // 0x028BAEC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028BAEC4: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x028BAEC8: LDR x24, [x8]              | X24 = 0x9814C0;                         
            val_168 = 9966784;
            // 0x028BAECC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028BAED0: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
            // 0x028BAED4: LDR x26, [x8]              | X26 = 0x40;                             
            val_169 = 64;
            // 0x028BAED8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_203:
            // 0x028BAEDC: LDR x9, [x22, #0x28]       | X9 = mem[1052455771];                   
            val_170 = mem[1052455771];
            // 0x028BAEE0: STR x24, [sp, #0x80]       | stack[1152921513251504928] = 0x9814C0;   //  dest_result_addr=1152921513251504928
            // 0x028BAEE4: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_171 = 0;
            // 0x028BAEE8: ORR w21, wzr, #0x7f800000  | W21 = 2139095040(0x7F800000);           
            // 0x028BAEEC: B #0x28baf00               |  goto label_204;                        
            goto label_204;
            label_208:
            // 0x028BAEF0: MOV x9, x27                | X9 = 1065353216 (0x3F800000);//ML01     
            val_170 = val_146;
            // 0x028BAEF4: ADD x8, x9, x22, lsl #2    | X8 = (val_170 + 4209822924);            
            var val_128 = val_170 + 4209822924;
            // 0x028BAEF8: ADD w19, w19, #1           | W19 = (val_171 + 1) = val_171 (0x00000001);
            val_171 = 1;
            // 0x028BAEFC: STR w21, [x8, #0x20]       | mem2[0] = 0x7F800000;                    //  dest_result_addr=0
            mem2[0] = 2139095040;
            label_204:
            // 0x028BAF00: MOV x27, x9                | X27 = 1065353216 (0x3F800000);//ML01    
            // 0x028BAF04: CBNZ x9, #0x28baf0c        | if (0x3F800000 != 0) goto label_205;    
            if(val_170 != 0)
            {
                goto label_205;
            }
            // 0x028BAF08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_205:
            // 0x028BAF0C: CMP w19, #3                | STATE = COMPARE(0x1, 0x3)               
            // 0x028BAF10: B.GE #0x28baf34            | if (val_171 >= 0x3) goto label_206;     
            if(val_171 >= 3)
            {
                goto label_206;
            }
            // 0x028BAF14: LDR w8, [x27, #0x18]       | W8 = mem[1065353240];                   
            // 0x028BAF18: SXTW x22, w19              | X22 = 1 (0x00000001);                   
            // 0x028BAF1C: CMP w19, w8                | STATE = COMPARE(0x1, mem[1065353240])   
            // 0x028BAF20: B.LO #0x28baef0            | if (val_171 < mem[1065353240]) goto label_208;
            if(val_171 < mem[1065353240])
            {
                goto label_208;
            }
            // 0x028BAF24: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BAF28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAF2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x028BAF30: B #0x28baef0               |  goto label_208;                        
            goto label_208;
            label_206:
            // 0x028BAF34: LDR w8, [x27, #0x18]       | W8 = mem[1065353240];                   
            // 0x028BAF38: CMP w8, #3                 | STATE = COMPARE(mem[1065353240], 0x3)   
            // 0x028BAF3C: B.HI #0x28baf4c            | if (mem[1065353240] > 0x3) goto label_209;
            if(mem[1065353240] > 3)
            {
                goto label_209;
            }
            // 0x028BAF40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BAF44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BAF48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_209:
            // 0x028BAF4C: ADD x9, x20, #0x20         | X9 = context.vos[0x20]; //PARR1         
            // 0x028BAF50: STR x9, [sp, #0x58]        | stack[1152921513251504888] = context.vos[0x20];  //  dest_result_addr=1152921513251504888
            VO[] val_183 = context.vos[32];
            // 0x028BAF54: LDR x9, [sp, #0xc0]        | X9 = 0x2;                               
            // 0x028BAF58: ADD x8, x27, #0x20         | X8 = (val_170 + 32);                    
            var val_129 = val_170 + 32;
            // 0x028BAF5C: STR x8, [sp, #0xa0]        | stack[1152921513251504960] = (val_170 + 32);  //  dest_result_addr=1152921513251504960
            // 0x028BAF60: ORR w8, wzr, #0xff800000   | W8 = -8388608(0xFFFFFFFFFF800000);      
            // 0x028BAF64: MOV w9, w9                 | W9 = 2 (0x2);//ML01                     
            // 0x028BAF68: MOV x21, x26               | X21 = 64 (0x40);//ML01                  
            val_172 = val_169;
            // 0x028BAF6C: MOV x26, x27               | X26 = 1065353216 (0x3F800000);//ML01    
            // 0x028BAF70: STR x9, [sp, #0x68]        | stack[1152921513251504904] = 0x2;        //  dest_result_addr=1152921513251504904
            // 0x028BAF74: ADD x9, x24, #0x18         | X9 = (val_168 + 24);                    
            var val_130 = val_168 + 24;
            // 0x028BAF78: STR w8, [x26, #0x2c]       | mem[1065353260] = 0xFFFFFFFFFF800000;    //  dest_result_addr=1065353260
            mem[1065353260] = -8388608;
            // 0x028BAF7C: STR x9, [sp, #0x48]        | stack[1152921513251504872] = (val_168 + 24);  //  dest_result_addr=1152921513251504872
            // 0x028BAF80: ADD x9, x21, #0x1c         | X9 = (val_172 + 28) = 92 (0x0000005C);  
            // 0x028BAF84: LDUR s0, [x29, #-0xa0]     | S0 = val_12.x;                          
            // 0x028BAF88: STR x9, [sp, #0x40]        | stack[1152921513251504864] = 0x5C;       //  dest_result_addr=1152921513251504864
            // 0x028BAF8C: ADD x9, x21, #0x20         | X9 = (val_172 + 32) = 96 (0x00000060);  
            // 0x028BAF90: STR x9, [sp, #0x98]        | stack[1152921513251504952] = 0x60;       //  dest_result_addr=1152921513251504952
            // 0x028BAF94: ADD x9, x24, #0x24         | X9 = (val_168 + 36);                    
            float val_131 = val_168 + 36;
            // 0x028BAF98: STR x9, [sp, #0x30]        | stack[1152921513251504848] = (val_168 + 36);  //  dest_result_addr=1152921513251504848
            // 0x028BAF9C: LDR x9, [sp, #0xc8]        | X9 = mem[1052455787];                   
            var val_184 = val_174;
            // 0x028BAFA0: STR s0, [sp, #0x54]        | stack[1152921513251504884] = val_12.x;   //  dest_result_addr=1152921513251504884
            // 0x028BAFA4: LDUR s0, [x29, #-0x9c]     | S0 = val_12.y;                          
            // 0x028BAFA8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028BAFAC: ADD x9, x9, #0x2c          | X9 = (mem[1052455787] + 44);            
            val_184 = val_184 + 44;
            // 0x028BAFB0: STR x9, [sp, #0x28]        | stack[1152921513251504840] = (mem[1052455787] + 44);  //  dest_result_addr=1152921513251504840
            // 0x028BAFB4: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x028BAFB8: STR s0, [sp, #0x50]        | stack[1152921513251504880] = val_12.y;   //  dest_result_addr=1152921513251504880
            // 0x028BAFBC: LDR s0, [x8, #0x774]       | S0 = 0.001;                             
            // 0x028BAFC0: LDR s1, [x9, #0x930]       | S1 = Infinity;                          
            // 0x028BAFC4: ADD x8, x23, #0x3c         | X8 = (val_145 + 60);                    
            var val_132 = val_145 + 60;
            // 0x028BAFC8: MOV w10, wzr               | W10 = 0 (0x0);//ML01                    
            // 0x028BAFCC: STR x27, [sp, #0xb0]       | stack[1152921513251504976] = 0x3F800000;  //  dest_result_addr=1152921513251504976
            // 0x028BAFD0: STR s0, [sp, #0x64]        | stack[1152921513251504900] = 0x3A83126F;  //  dest_result_addr=1152921513251504900
            // 0x028BAFD4: STR x8, [sp, #0x20]        | stack[1152921513251504832] = (val_145 + 60);  //  dest_result_addr=1152921513251504832
            label_275:
            // 0x028BAFD8: STR w10, [sp, #0x3c]       | stack[1152921513251504860] = 0x0;        //  dest_result_addr=1152921513251504860
            // 0x028BAFDC: CMP w25, #1                | STATE = COMPARE((val_165 + 17), 0x1)    
            // 0x028BAFE0: B.LT #0x28bb474            | if (val_127 < 0x1) goto label_210;      
            if(val_127 < 1)
            {
                goto label_210;
            }
            // 0x028BAFE4: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            var val_191 = 0;
            // 0x028BAFE8: SXTW x8, w25               | X8 = (long)(int)((val_165 + 17));       
            // 0x028BAFEC: MOV v9.16b, v1.16b         | V9 = 2139095040 (0x7F800000);//ML01     
            val_173 = Infinityf;
            // 0x028BAFF0: STR x8, [sp, #0x78]        | stack[1152921513251504920] = (long)(int)((val_165 + 17));  //  dest_result_addr=1152921513251504920
            label_253:
            // 0x028BAFF4: LDR x8, [sp, #0xc0]        | X8 = 0x2;                               
            // 0x028BAFF8: LDR x24, [sp, #0x68]       | X24 = 0x2;                              
            // 0x028BAFFC: FMOV s12, wzr              | S12 = 0f;                               
            val_174 = 0f;
            // 0x028BB000: CMP w8, #1                 | STATE = COMPARE(0x2, 0x1)               
            // 0x028BB004: B.LT #0x28bb098            | if (2 < 0x1) goto label_211;            
            if(2 < 1)
            {
                goto label_211;
            }
            // 0x028BB008: LDR x22, [sp, #0x58]       | X22 = context.vos[0x20];                
            VO[] val_186 = val_183;
            // 0x028BB00C: ADD x8, x23, x19, lsl #3   | X8 = (val_145 + 0);                     
            var val_133 = val_145 + 0;
            // 0x028BB010: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            var val_185 = 0;
            // 0x028BB014: ADD x27, x8, #0x20         | X27 = ((val_145 + 0) + 32);             
            float val_134 = val_133 + 32;
            // 0x028BB018: ADD x28, x8, #0x24         | X28 = ((val_145 + 0) + 36);             
            var val_135 = val_133 + 36;
            // 0x028BB01C: FMOV s12, wzr              | S12 = 0f;                               
            label_216:
            // 0x028BB020: CBNZ x20, #0x28bb028       | if (context.vos != null) goto label_212;
            if(context.vos != null)
            {
                goto label_212;
            }
            // 0x028BB024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_212:
            // 0x028BB028: CBNZ x23, #0x28bb030       | if (0x38004000000000 != 0) goto label_213;
            if(val_145 != 0)
            {
                goto label_213;
            }
            // 0x028BB02C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_213:
            // 0x028BB030: LDR w8, [x20, #0x18]       | W8 = context.vos.Length; //P2           
            // 0x028BB034: CMP x25, x8                | STATE = COMPARE(0x0, context.vos.Length)
            // 0x028BB038: B.LO #0x28bb048            | if (0 < context.vos.Length) goto label_214;
            if(val_185 < context.vos.Length)
            {
                goto label_214;
            }
            // 0x028BB03C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB040: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB044: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_214:
            // 0x028BB048: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BB04C: CMP x19, x8                | STATE = COMPARE(0x0, mem[15762873573703704])
            // 0x028BB050: B.LO #0x28bb060            | if (0 < mem[15762873573703704]) goto label_215;
            if(val_191 < mem[15762873573703704])
            {
                goto label_215;
            }
            // 0x028BB054: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB058: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB05C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_215:
            // 0x028BB060: LDR s0, [x27]              | S0 = ((val_145 + 0) + 32);              
            // 0x028BB064: LDR s1, [x28]              | S1 = ((val_145 + 0) + 36);              
            // 0x028BB068: MOV x0, x22                | X0 = context.vos[0x20];//m1             
            // 0x028BB06C: BL #0x28bc860              | X0 = label_Pathfinding_RVO_Sampled_Agent_Trace_GL028BC860();
            // 0x028BB070: MOV v1.16b, v0.16b         | V1 = ((val_145 + 0) + 32);//m1          
            // 0x028BB074: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BB078: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB07C: MOV v0.16b, v12.16b        | V0 = 0;//m1                             
            // 0x028BB080: BL #0x16f9434              | X0 = System.Math.Max(val1:  0f, val2:  val_134);
            float val_136 = System.Math.Max(val1:  0f, val2:  val_134);
            // 0x028BB084: MOV v12.16b, v0.16b        | V12 = val_136;//m1                      
            val_174 = val_136;
            // 0x028BB088: ADD x25, x25, #1           | X25 = (0 + 1);                          
            val_185 = val_185 + 1;
            // 0x028BB08C: ADD x22, x22, #0x50        | X22 = (context.vos[0x20] + 80);         
            val_186 = val_186 + 80;
            // 0x028BB090: CMP w24, w25               | STATE = COMPARE(0x2, (0 + 1))           
            // 0x028BB094: B.NE #0x28bb020            | if (2 != 0) goto label_216;             
            if(2 != val_185)
            {
                goto label_216;
            }
            label_211:
            // 0x028BB098: CBNZ x23, #0x28bb0a0       | if (0x38004000000000 != 0) goto label_217;
            if(val_145 != 0)
            {
                goto label_217;
            }
            // 0x028BB09C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_217:
            // 0x028BB0A0: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BB0A4: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BB0A8: LDR s14, [sp, #0x158]      | S14 = val_90.x;                         
            // 0x028BB0AC: LDR s13, [sp, #0x15c]      | S13 = val_90.y;                         
            // 0x028BB0B0: LDR x24, [sp, #0x70]       | X24 = this;                             
            // 0x028BB0B4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BB0B8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BB0BC: TBZ w8, #0, #0x28bb0cc     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_219;
            // 0x028BB0C0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BB0C4: CBNZ w8, #0x28bb0cc        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_219;
            // 0x028BB0C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_219:
            // 0x028BB0CC: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BB0D0: CMP x19, x8                | STATE = COMPARE(0x0, mem[15762873573703704])
            // 0x028BB0D4: B.LO #0x28bb0e4            | if (0 < mem[15762873573703704]) goto label_220;
            if(val_191 < mem[15762873573703704])
            {
                goto label_220;
            }
            // 0x028BB0D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.Vector2), ????);
            // 0x028BB0DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB0E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.Vector2), ????);
            label_220:
            // 0x028BB0E4: ADD x22, x23, x19, lsl #3  | X22 = (val_145 + 0);                    
            var val_137 = val_145 + 0;
            // 0x028BB0E8: LDR s0, [x22, #0x20]!      | S0 = (val_145 + 0) + 32;                
            // 0x028BB0EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BB0F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB0F4: MOV v2.16b, v14.16b        | V2 = val_90.x;//m1                      
            // 0x028BB0F8: MOV x28, x22               | X28 = (val_145 + 0) + 32;//m1           
            val_142 = (val_145 + 0) + 32;
            // 0x028BB0FC: LDR s1, [x28, #4]!         | S1 = (val_145 + 0) + 32 + 4;            
            // 0x028BB100: MOV v3.16b, v13.16b        | V3 = val_90.y;//m1                      
            val_164 = val_90.y;
            // 0x028BB104: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = (val_145 + 0) + 32, y = (val_145 + 0) + 32 + 4}, b:  new UnityEngine.Vector2() {x = val_90.x, y = val_164});
            UnityEngine.Vector2 val_138 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = (val_145 + 0) + 32, y = (val_145 + 0) + 32 + 4}, b:  new UnityEngine.Vector2() {x = val_90.x, y = val_164});
            // 0x028BB108: ADD x0, sp, #0x138         | X0 = (1152921513251504800 + 312) = 1152921513251505112 (0x10000002034303D8);
            // 0x028BB10C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB110: STR s0, [sp, #0x138]       | stack[1152921513251505112] = val_138.x;  //  dest_result_addr=1152921513251505112
            // 0x028BB114: STR s1, [sp, #0x13c]       | stack[1152921513251505116] = val_138.y;  //  dest_result_addr=1152921513251505116
            // 0x028BB118: BL #0x269749c              | X0 = label_UnityEngine_Vector2_op_Subtraction_GL0269749C();
            // 0x028BB11C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028BB120: LDR x8, [x8, #0x470]       | X8 = 1152921504840765440;               
            // 0x028BB124: MOV v13.16b, v0.16b        | V13 = val_138.x;//m1                    
            // 0x028BB128: LDR x0, [x8]               | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            val_177 = null;
            // 0x028BB12C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BB130: TBZ w8, #0, #0x28bb14c     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_222;
            // 0x028BB134: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BB138: CBNZ w8, #0x28bb14c        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_222;
            // 0x028BB13C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB140: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028BB144: LDR x8, [x8, #0x470]       | X8 = 1152921504840765440;               
            // 0x028BB148: LDR x0, [x8]               | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            val_177 = null;
            label_222:
            // 0x028BB14C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BB150: LDR s0, [sp, #0x64]        | S0 = 0.001;                             
            float val_187 = 0.001f;
            // 0x028BB154: LDR s1, [x8, #0x10]        | S1 = Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight;
            val_178 = Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight;
            // 0x028BB158: LDRB w8, [x24, #0xb4]      | W8 = this.<DebugDraw>k__BackingField;   
            // 0x028BB15C: FMUL s0, s13, s0           | S0 = (val_138.x * 0.001f);              
            val_187 = val_138.x * val_187;
            // 0x028BB160: FADD s0, s12, s0           | S0 = (val_136 + (val_138.x * 0.001f));  
            val_187 = val_174 + val_187;
            // 0x028BB164: STR s0, [sp, #0xbc]        | stack[1152921513251504988] = (val_136 + (val_138.x * 0.001f));  //  dest_result_addr=1152921513251504988
            // 0x028BB168: CBZ w8, #0x28bb2b8         | if (this.<DebugDraw>k__BackingField == false) goto label_223;
            if((this.<DebugDraw>k__BackingField) == false)
            {
                goto label_223;
            }
            // 0x028BB16C: STR s1, [sp, #0x90]        | stack[1152921513251504944] = Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight;  //  dest_result_addr=1152921513251504944
            // 0x028BB170: LDP s14, s15, [x29, #-0x98] | S14 = val_11.x; S15 = val_11.y;          //  | 
            // 0x028BB174: CBNZ x23, #0x28bb17c       | if (0x38004000000000 != 0) goto label_224;
            if(val_145 != 0)
            {
                goto label_224;
            }
            // 0x028BB178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_224:
            // 0x028BB17C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BB180: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BB184: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BB188: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BB18C: TBZ w8, #0, #0x28bb19c     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_226;
            // 0x028BB190: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BB194: CBNZ w8, #0x28bb19c        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_226;
            // 0x028BB198: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_226:
            // 0x028BB19C: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BB1A0: LDR s8, [sp, #0xbc]        | S8 = (val_136 + (val_138.x * 0.001f));  
            // 0x028BB1A4: CMP x19, x8                | STATE = COMPARE(0x0, mem[15762873573703704])
            // 0x028BB1A8: B.LO #0x28bb1b8            | if (0 < mem[15762873573703704]) goto label_227;
            if(val_191 < mem[15762873573703704])
            {
                goto label_227;
            }
            // 0x028BB1AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.Vector2), ????);
            // 0x028BB1B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB1B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.Vector2), ????);
            label_227:
            // 0x028BB1B8: LDR s2, [x22]              | S2 = (val_145 + 0) + 32;                
            // 0x028BB1BC: LDR s3, [x28]              | S3 = (val_145 + 0) + 32 + 4;            
            // 0x028BB1C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BB1C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB1C8: MOV v0.16b, v14.16b        | V0 = val_11.x;//m1                      
            // 0x028BB1CC: MOV v1.16b, v15.16b        | V1 = val_11.y;//m1                      
            // 0x028BB1D0: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y}, b:  new UnityEngine.Vector2() {x = (val_145 + 0) + 32, y = (val_145 + 0) + 32 + 4});
            UnityEngine.Vector2 val_139 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y}, b:  new UnityEngine.Vector2() {x = (val_145 + 0) + 32, y = (val_145 + 0) + 32 + 4});
            // 0x028BB1D4: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028BB1D8: STR s0, [sp, #0x8c]        | stack[1152921513251504940] = val_139.x;  //  dest_result_addr=1152921513251504940
            // 0x028BB1DC: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x028BB1E0: MOV v15.16b, v1.16b        | V15 = val_139.y;//m1                    
            // 0x028BB1E4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x028BB1E8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028BB1EC: TBZ w8, #0, #0x28bb1fc     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_229;
            // 0x028BB1F0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028BB1F4: CBNZ w8, #0x28bb1fc        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_229;
            // 0x028BB1F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_229:
            // 0x028BB1FC: FMOV s0, #1.00000000       | S0 = 1;                                 
            float val_188 = 1f;
            // 0x028BB200: FADD s0, s8, s0            | S0 = ((val_136 + (val_138.x * 0.001f)) + 1f);
            val_188 = val_187 + val_188;
            // 0x028BB204: MOV v14.16b, v9.16b        | V14 = 2139095040 (0x7F800000);//ML01    
            // 0x028BB208: BL #0x981030               | X0 = sub_981030( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028BB20C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028BB210: LDR x8, [x8, #0x470]       | X8 = 1152921504840765440;               
            // 0x028BB214: MOV v8.16b, v0.16b         | V8 = ((val_136 + (val_138.x * 0.001f)) + 1f);//m1
            // 0x028BB218: LDR x0, [x8]               | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BB21C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BB220: TBZ w8, #0, #0x28bb230     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_231;
            // 0x028BB224: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BB228: CBNZ w8, #0x28bb230        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_231;
            // 0x028BB22C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_231:
            // 0x028BB230: FMOV s0, #5.00000000       | S0 = 5;                                 
            float val_189 = 5f;
            // 0x028BB234: FMUL s0, s8, s0            | S0 = (((val_136 + (val_138.x * 0.001f)) + 1f) * 5f);
            val_189 = val_188 * val_189;
            // 0x028BB238: BL #0x28bc9bc              | X0 = Pathfinding.RVO.Sampled.Agent.Rainbow(v:  5f = 1f * 5f);
            UnityEngine.Color val_140 = Pathfinding.RVO.Sampled.Agent.Rainbow(v:  val_189);
            // 0x028BB23C: LDR x9, [sp, #0xc8]        | X9 = mem[1052455787];                   
            val_179 = val_174;
            // 0x028BB240: MOV v9.16b, v0.16b         | V9 = val_140.r;//m1                     
            // 0x028BB244: MOV v10.16b, v1.16b        | V10 = val_140.g;//m1                    
            // 0x028BB248: MOV v11.16b, v2.16b        | V11 = val_140.b;//m1                    
            // 0x028BB24C: MOV v8.16b, v3.16b         | V8 = val_140.a;//m1                     
            // 0x028BB250: CBNZ x9, #0x28bb260        | if (mem[1052455787] != 0) goto label_232;
            if(val_179 != 0)
            {
                goto label_232;
            }
            // 0x028BB254: MOV x24, x9                | X24 = mem[1052455787];//m1              
            // 0x028BB258: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB25C: MOV x9, x24                | X9 = mem[1052455787];//m1               
            val_179 = val_179;
            label_232:
            // 0x028BB260: LDR w8, [x9, #0x18]        | W8 = mem[1052455787] + 24;              
            // 0x028BB264: CMP x19, x8                | STATE = COMPARE(0x0, mem[1052455787] + 24)
            // 0x028BB268: B.LO #0x28bb280            | if (0 < mem[1052455787] + 24) goto label_233;
            if(val_191 < (mem[1052455787] + 24))
            {
                goto label_233;
            }
            // 0x028BB26C: MOV x24, x9                | X24 = mem[1052455787];//m1              
            // 0x028BB270: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB274: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB278: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB27C: MOV x9, x24                | X9 = mem[1052455787];//m1               
            val_179 = val_179;
            label_233:
            // 0x028BB280: ADD x8, x9, x19, lsl #2    | X8 = (mem[1052455787] + 0);             
            var val_141 = val_179 + 0;
            // 0x028BB284: LDR s0, [x8, #0x20]        | S0 = (mem[1052455787] + 0) + 32;        
            // 0x028BB288: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x028BB28C: MOV v2.16b, v9.16b         | V2 = val_140.r;//m1                     
            // 0x028BB290: MOV v3.16b, v10.16b        | V3 = val_140.g;//m1                     
            val_164 = val_140.g;
            // 0x028BB294: FMUL s6, s0, s1            | S6 = ((mem[1052455787] + 0) + 32 * 0.5f);
            float val_142 = ((mem[1052455787] + 0) + 32) * 0.5f;
            // 0x028BB298: LDR s0, [sp, #0x8c]        | S0 = val_139.x;                         
            // 0x028BB29C: MOV v1.16b, v15.16b        | V1 = val_139.y;//m1                     
            // 0x028BB2A0: MOV v4.16b, v11.16b        | V4 = val_140.b;//m1                     
            // 0x028BB2A4: MOV v5.16b, v8.16b         | V5 = val_140.a;//m1                     
            // 0x028BB2A8: STR x9, [sp, #0xc8]        | stack[1152921513251505000] = mem[1052455787];  //  dest_result_addr=1152921513251505000
            // 0x028BB2AC: BL #0x28b9100              | Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = val_139.x, y = val_139.y}, col:  new UnityEngine.Color() {r = val_140.r, g = val_164, b = val_140.b, a = val_140.a}, size:  float val_142 = ((mem[1052455787] + 0) + 32) * 0.5f);
            Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = val_139.x, y = val_139.y}, col:  new UnityEngine.Color() {r = val_140.r, g = val_164, b = val_140.b, a = val_140.a}, size:  val_142);
            // 0x028BB2B0: LDR s1, [sp, #0x90]        | S1 = Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight;
            val_178 = val_178;
            // 0x028BB2B4: MOV v9.16b, v14.16b        | V9 = 2139095040 (0x7F800000);//ML01     
            val_173 = val_173;
            label_223:
            // 0x028BB2B8: FMUL s8, s13, s1           | S8 = (val_138.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight);
            float val_143 = val_138.x * val_178;
            // 0x028BB2BC: CBNZ x26, #0x28bb2c4       | if (0x3F800000 != 0) goto label_234;    
            if(val_170 != 0)
            {
                goto label_234;
            }
            // 0x028BB2C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_234:
            // 0x028BB2C4: LDR w8, [x26, #0x18]       | W8 = mem[1065353240];                   
            // 0x028BB2C8: FADD s8, s12, s8           | S8 = (val_136 + (val_138.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight));
            val_143 = val_174 + val_143;
            // 0x028BB2CC: CBNZ w8, #0x28bb2dc        | if (mem[1065353240] != 0) goto label_235;
            if(mem[1065353240] != 0)
            {
                goto label_235;
            }
            // 0x028BB2D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB2D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB2D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_235:
            // 0x028BB2DC: LDR s0, [x26, #0x20]       | S0 = mem[1065353248];                   
            // 0x028BB2E0: FCMP s8, s0                | STATE = COMPARE((val_136 + (val_138.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight)), mem[1065353248])
            // 0x028BB2E4: B.PL #0x28bb410            | if (val_143 >= 0) goto label_237;       
            if(val_143 >= 0)
            {
                goto label_237;
            }
            // 0x028BB2E8: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            var val_190 = 0;
            label_239:
            // 0x028BB2EC: MOV x24, x25               | X24 = 0 (0x0);//ML01                    
            // 0x028BB2F0: CMP x24, #3                | STATE = COMPARE(0x0, 0x3)               
            // 0x028BB2F4: B.GE #0x28bb410            | if (0 >= 0x3) goto label_237;           
            if(val_190 >= 3)
            {
                goto label_237;
            }
            // 0x028BB2F8: LDR w8, [x26, #0x18]       | W8 = mem[1065353240];                   
            // 0x028BB2FC: ADD x25, x24, #1           | X25 = (0 + 1);                          
            val_190 = val_190 + 1;
            // 0x028BB300: CMP x25, x8                | STATE = COMPARE((0 + 1), mem[1065353240])
            // 0x028BB304: B.LO #0x28bb314            | if (0 < mem[1065353240]) goto label_238;
            if(val_190 < mem[1065353240])
            {
                goto label_238;
            }
            // 0x028BB308: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB30C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB310: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_238:
            // 0x028BB314: ADD x8, x26, x24, lsl #2   | X8 = (val_170 + 0);                     
            var val_144 = val_170 + 0;
            // 0x028BB318: LDR s0, [x8, #0x24]        | S0 = (val_170 + 0) + 36;                
            // 0x028BB31C: FCMP s8, s0                | STATE = COMPARE((val_136 + (val_138.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight)), (val_170 + 0) + 36)
            // 0x028BB320: B.LT #0x28bb2ec            | if (val_143 < (val_170 + 0) + 36) goto label_239;
            if(val_143 < ((val_170 + 0) + 36))
            {
                goto label_239;
            }
            // 0x028BB324: LDR w8, [x26, #0x18]       | W8 = mem[1065353240];                   
            // 0x028BB328: SUB x27, x25, #1           | X27 = ((0 + 1) - 1);                    
            var val_145 = val_190 - 1;
            // 0x028BB32C: CMP w27, w8                | STATE = COMPARE(((0 + 1) - 1), mem[1065353240])
            // 0x028BB330: B.LO #0x28bb340            | if (val_145 < mem[1065353240]) goto label_240;
            if(val_145 < mem[1065353240])
            {
                goto label_240;
            }
            // 0x028BB334: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB338: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB33C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_240:
            // 0x028BB340: LDR x9, [sp, #0xc8]        | X9 = mem[1052455787];                   
            val_180 = val_179;
            // 0x028BB344: ADD x8, x26, x25, lsl #2   | X8 = (val_170 + ((0 + 1)) << 2);        
            var val_146 = val_170 + (((0 + 1)) << 2);
            // 0x028BB348: STR s8, [x8, #0x1c]        | mem2[0] = (val_136 + (val_138.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight));  //  dest_result_addr=0
            mem2[0] = val_143;
            // 0x028BB34C: CBNZ x9, #0x28bb35c        | if (mem[1052455787] != 0) goto label_241;
            if(val_180 != 0)
            {
                goto label_241;
            }
            // 0x028BB350: MOV x24, x9                | X24 = mem[1052455787];//m1              
            // 0x028BB354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB358: MOV x9, x24                | X9 = mem[1052455787];//m1               
            val_180 = val_180;
            label_241:
            // 0x028BB35C: LDR w8, [x9, #0x18]        | W8 = mem[1052455787] + 24;              
            // 0x028BB360: CMP x19, x8                | STATE = COMPARE(0x0, mem[1052455787] + 24)
            // 0x028BB364: B.LO #0x28bb37c            | if (0 < mem[1052455787] + 24) goto label_242;
            if(val_191 < (mem[1052455787] + 24))
            {
                goto label_242;
            }
            // 0x028BB368: MOV x24, x9                | X24 = mem[1052455787];//m1              
            // 0x028BB36C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB370: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB374: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB378: MOV x9, x24                | X9 = mem[1052455787];//m1               
            val_180 = val_180;
            label_242:
            // 0x028BB37C: ADD x8, x9, x19, lsl #2    | X8 = (mem[1052455787] + 0);             
            var val_147 = val_180 + 0;
            // 0x028BB380: LDR w24, [x8, #0x20]       | W24 = (mem[1052455787] + 0) + 32;       
            // 0x028BB384: CBNZ x21, #0x28bb390       | if (0x40 != 0) goto label_243;          
            if(val_172 != 0)
            {
                goto label_243;
            }
            // 0x028BB388: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB38C: LDR x9, [sp, #0xc8]        | X9 = mem[1052455787];                   
            val_180 = val_179;
            label_243:
            // 0x028BB390: LDR w8, [x21, #0x18]       | W8 = 0x0;                               
            // 0x028BB394: MOV x26, x21               | X26 = 64 (0x40);//ML01                  
            // 0x028BB398: STR x9, [sp, #0xc8]        | stack[1152921513251505000] = mem[1052455787];  //  dest_result_addr=1152921513251505000
            // 0x028BB39C: CMP w27, w8                | STATE = COMPARE(((0 + 1) - 1), 0x0)     
            // 0x028BB3A0: B.LO #0x28bb3b0            | if (val_145 < 0) goto label_244;        
            if(val_145 < 0)
            {
                goto label_244;
            }
            // 0x028BB3A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB3A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB3AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_244:
            // 0x028BB3B0: LDR x8, [sp, #0x40]        | X8 = 0x5C;                              
            // 0x028BB3B4: LDR x21, [sp, #0x80]       | X21 = 0x9814C0;                         
            // 0x028BB3B8: STR w24, [x8, x25, lsl #2] | mem2[0] = (mem[1052455787] + 0) + 32;    //  dest_result_addr=0
            mem2[0] = (mem[1052455787] + 0) + 32;
            // 0x028BB3BC: CBNZ x21, #0x28bb3c4       | if (0x9814C0 != 0) goto label_245;      
            if(val_168 != 0)
            {
                goto label_245;
            }
            // 0x028BB3C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_245:
            // 0x028BB3C4: CBNZ x23, #0x28bb3cc       | if (0x38004000000000 != 0) goto label_246;
            if(val_145 != 0)
            {
                goto label_246;
            }
            // 0x028BB3C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_246:
            // 0x028BB3CC: LDR w8, [x21, #0x18]       | W8 = 0x8805FC64;                        
            // 0x028BB3D0: CMP w27, w8                | STATE = COMPARE(((0 + 1) - 1), 0x8805FC64)
            // 0x028BB3D4: B.LO #0x28bb3e4            | if (val_145 < -2012873628) goto label_247;
            if(val_145 < (-2012873628))
            {
                goto label_247;
            }
            // 0x028BB3D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB3DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB3E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_247:
            // 0x028BB3E4: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BB3E8: CMP x19, x8                | STATE = COMPARE(0x0, mem[15762873573703704])
            // 0x028BB3EC: MOV x21, x26               | X21 = 64 (0x40);//ML01                  
            val_172 = val_172;
            // 0x028BB3F0: B.LO #0x28bb400            | if (0 < mem[15762873573703704]) goto label_248;
            if(val_191 < mem[15762873573703704])
            {
                goto label_248;
            }
            // 0x028BB3F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB3F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB3FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_248:
            // 0x028BB400: LDR x8, [x22]              | X8 = (val_145 + 0) + 32;                
            // 0x028BB404: LDR x9, [sp, #0x48]        | X9 = (val_168 + 24);                    
            // 0x028BB408: LDR x26, [sp, #0xb0]       | X26 = 0x3F800000;                       
            // 0x028BB40C: STR x8, [x9, x25, lsl #3]  | mem2[0] = (val_145 + 0) + 32;            //  dest_result_addr=0
            mem2[0] = (val_145 + 0) + 32;
            label_237:
            // 0x028BB410: LDR s8, [sp, #0xbc]        | S8 = (val_136 + (val_138.x * 0.001f));  
            // 0x028BB414: LDR x24, [sp, #0x80]       | X24 = 0x9814C0;                         
            val_168 = val_168;
            // 0x028BB418: FCMP s8, s9                | STATE = COMPARE((val_136 + (val_138.x * 0.001f)), Infinity)
            // 0x028BB41C: B.PL #0x28bb45c            | if (0.001f >= 0) goto label_249;        
            if(val_187 >= 0)
            {
                goto label_249;
            }
            // 0x028BB420: CBNZ x23, #0x28bb428       | if (0x38004000000000 != 0) goto label_250;
            if(val_145 != 0)
            {
                goto label_250;
            }
            // 0x028BB424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_250:
            // 0x028BB428: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BB42C: CMP x19, x8                | STATE = COMPARE(0x0, mem[15762873573703704])
            // 0x028BB430: B.LO #0x28bb440            | if (0 < mem[15762873573703704]) goto label_251;
            if(val_191 < mem[15762873573703704])
            {
                goto label_251;
            }
            // 0x028BB434: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB438: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB43C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_251:
            // 0x028BB440: LDR s0, [x22]              | S0 = (val_145 + 0) + 32;                
            // 0x028BB444: FCMP s8, #0.0              | STATE = COMPARE((val_136 + (val_138.x * 0.001f)), 0)
            // 0x028BB448: STR s0, [sp, #0x54]        | stack[1152921513251504884] = (val_145 + 0) + 32;  //  dest_result_addr=1152921513251504884
            // 0x028BB44C: LDR s0, [x28]              | S0 = (val_145 + 0) + 32 + 4;            
            // 0x028BB450: STR s0, [sp, #0x50]        | stack[1152921513251504880] = (val_145 + 0) + 32 + 4;  //  dest_result_addr=1152921513251504880
            // 0x028BB454: B.EQ #0x28bb47c            | if (0.001f == 0) goto label_252;        
            if(val_187 == 0f)
            {
                goto label_252;
            }
            // 0x028BB458: MOV v9.16b, v8.16b         | V9 = (val_136 + (val_138.x * 0.001f));//m1
            val_173 = val_187;
            label_249:
            // 0x028BB45C: LDR x8, [sp, #0x78]        | X8 = (long)(int)((val_165 + 17));       
            // 0x028BB460: ADD x19, x19, #1           | X19 = (0 + 1);                          
            val_191 = val_191 + 1;
            // 0x028BB464: CMP x19, x8                | STATE = COMPARE((0 + 1), (long)(int)((val_165 + 17)))
            // 0x028BB468: B.LT #0x28baff4            | if (0 < (long)val_127) goto label_253;  
            if(val_191 < (long)val_127)
            {
                goto label_253;
            }
            // 0x028BB46C: STR s9, [sp, #0xbc]        | stack[1152921513251504988] = (val_136 + (val_138.x * 0.001f));  //  dest_result_addr=1152921513251504988
            // 0x028BB470: B #0x28bb484               |  goto label_255;                        
            goto label_255;
            label_210:
            // 0x028BB474: STR s1, [sp, #0xbc]        | stack[1152921513251504988] = 0x7F800000;  //  dest_result_addr=1152921513251504988
            // 0x028BB478: B #0x28bb484               |  goto label_255;                        
            goto label_255;
            label_252:
            // 0x028BB47C: MOVZ w8, #0x64             | W8 = 100 (0x64);//ML01                  
            // 0x028BB480: STR w8, [sp, #0x3c]        | stack[1152921513251504860] = 0x64;       //  dest_result_addr=1152921513251504860
            label_255:
            // 0x028BB484: LDP x22, x28, [sp, #0x20]  | X22 = (val_145 + 60); X28 = (mem[1052455787] + 44); //  | 
            var val_193 = val_132;
            // 0x028BB488: LDR x27, [sp, #0x30]       | X27 = (val_168 + 36);                   
            // 0x028BB48C: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            // 0x028BB490: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            var val_192 = 0;
            label_274:
            // 0x028BB494: CBNZ x24, #0x28bb49c       | if (0x9814C0 != 0) goto label_256;      
            if(val_168 != 0)
            {
                goto label_256;
            }
            // 0x028BB498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_256:
            // 0x028BB49C: LDR w8, [x24, #0x18]       | W8 = 0x8805FC64;                        
            // 0x028BB4A0: CMP x19, x8                | STATE = COMPARE(0x0, 0x8805FC64)        
            // 0x028BB4A4: B.LO #0x28bb4b4            | if (0 < -2012873628) goto label_257;    
            if(0 < (-2012873628))
            {
                goto label_257;
            }
            // 0x028BB4A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB4AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB4B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_257:
            // 0x028BB4B4: LDUR s12, [x27, #-4]       | S12 = (val_168 + 36) + -4;              
            val_154 = (val_168 + 36) + -4;
            // 0x028BB4B8: LDR s13, [x27]             | S13 = (val_168 + 36);                   
            // 0x028BB4BC: LDR x26, [sp, #0xb0]       | X26 = 0x3F800000;                       
            // 0x028BB4C0: CBNZ x21, #0x28bb4c8       | if (0x40 != 0) goto label_258;          
            if(val_172 != 0)
            {
                goto label_258;
            }
            // 0x028BB4C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_258:
            // 0x028BB4C8: LDR w8, [x21, #0x18]       | W8 = 0x0;                               
            // 0x028BB4CC: CMP x19, x8                | STATE = COMPARE(0x0, 0x0)               
            // 0x028BB4D0: B.LO #0x28bb4e0            | if (0 < 0) goto label_259;              
            if(0 < 0)
            {
                goto label_259;
            }
            // 0x028BB4D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB4D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB4DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_259:
            // 0x028BB4E0: LDR x8, [sp, #0x98]        | X8 = 0x60;                              
            // 0x028BB4E4: LDR s10, [x8, x19, lsl #2] | S10 = 5.356395E-37;                     
            val_158 = 5.356395E-37f;
            // 0x028BB4E8: CBNZ x26, #0x28bb4f0       | if (0x3F800000 != 0) goto label_260;    
            if(val_170 != 0)
            {
                goto label_260;
            }
            // 0x028BB4EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_260:
            // 0x028BB4F0: LDR w8, [x26, #0x18]       | W8 = mem[1065353240];                   
            // 0x028BB4F4: CMP x19, x8                | STATE = COMPARE(0x0, mem[1065353240])   
            // 0x028BB4F8: B.LO #0x28bb508            | if (0 < mem[1065353240]) goto label_261;
            if(0 < mem[1065353240])
            {
                goto label_261;
            }
            // 0x028BB4FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BB500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB504: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_261:
            // 0x028BB508: LDR s0, [sp, #0xac]        | S0 = 0.6;                               
            // 0x028BB50C: LDR x8, [sp, #0xa0]        | X8 = (val_170 + 32);                    
            // 0x028BB510: ORR w9, wzr, #0x7f800000   | W9 = 2139095040(0x7F800000);            
            // 0x028BB514: FMUL s11, s10, s0          | S11 = (val_158 * 0.6f);                 
            float val_148 = val_158 * 0.6f;
            // 0x028BB518: FMOV s0, #0.50000000       | S0 = 0.5;                               
            // 0x028BB51C: FMUL s14, s11, s0          | S14 = ((val_158 * 0.6f) * 0.5f);        
            val_155 = val_148 * 0.5f;
            // 0x028BB520: STR w9, [x8, x19, lsl #2]  | mem2[0] = 0x7F800000;                    //  dest_result_addr=0
            mem2[0] = 2139095040;
            // 0x028BB524: CBNZ x23, #0x28bb52c       | if (0x38004000000000 != 0) goto label_262;
            if(val_145 != 0)
            {
                goto label_262;
            }
            // 0x028BB528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_262:
            // 0x028BB52C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB530: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028BB534: MOV v0.16b, v14.16b        | V0 = ((val_158 * 0.6f) * 0.5f);//m1     
            // 0x028BB538: MOV v1.16b, v14.16b        | V1 = ((val_158 * 0.6f) * 0.5f);//m1     
            // 0x028BB53C: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028BB540: BL #0x2697148              | null..ctor(_x:  val_155, _y:  val_155); 
            Geometric.Point val_149 = new Geometric.Point(_x:  val_155, _y:  val_155);
            // 0x028BB544: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BB548: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BB54C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BB550: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BB554: TBZ w8, #0, #0x28bb564     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_264;
            // 0x028BB558: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BB55C: CBNZ w8, #0x28bb564        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_264;
            // 0x028BB560: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_264:
            // 0x028BB564: LDP s2, s3, [sp, #0xe0]    | S2 = val_149.x; S3 = val_149.y;          //  | 
            // 0x028BB568: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BB56C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB570: MOV v0.16b, v12.16b        | V0 = (val_168 + 36) + -4;//m1           
            // 0x028BB574: MOV v1.16b, v13.16b        | V1 = (val_168 + 36);//m1                
            // 0x028BB578: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_154, y = val_131}, b:  new UnityEngine.Vector2() {x = val_149.x, y = val_149.y});
            UnityEngine.Vector2 val_150 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_154, y = val_131}, b:  new UnityEngine.Vector2() {x = val_149.x, y = val_149.y});
            // 0x028BB57C: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BB580: MOV v8.16b, v0.16b         | V8 = val_150.x;//m1                     
            // 0x028BB584: MOV v9.16b, v1.16b         | V9 = val_150.y;//m1                     
            // 0x028BB588: CMP x25, x8                | STATE = COMPARE(0x0, mem[15762873573703704])
            // 0x028BB58C: B.LO #0x28bb59c            | if (0 < mem[15762873573703704]) goto label_265;
            if(val_192 < mem[15762873573703704])
            {
                goto label_265;
            }
            // 0x028BB590: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB594: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB598: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_265:
            // 0x028BB59C: FNEG s15, s14              | S15 = -(((val_158 * 0.6f) * 0.5f));     
            // 0x028BB5A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB5A4: ADD x0, sp, #0x130         | X0 = (1152921513251504800 + 304) = 1152921513251505104 (0x10000002034303D0);
            // 0x028BB5A8: MOV v0.16b, v15.16b        | V0 = ((val_158 * 0.6f) * 0.5f);//m1     
            // 0x028BB5AC: MOV v1.16b, v14.16b        | V1 = ((val_158 * 0.6f) * 0.5f);//m1     
            // 0x028BB5B0: STP s8, s9, [x22, #-0x1c]  | mem2[0] = val_150.x;  mem2[0] = val_150.y;  //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = val_150.x;
            mem2[0] = val_150.y;
            // 0x028BB5B4: STR xzr, [sp, #0x130]      | stack[1152921513251505104] = 0x0;        //  dest_result_addr=1152921513251505104
            // 0x028BB5B8: BL #0x2697148              | null..ctor(_x:  -val_155, _y:  val_155);
            Geometric.Point val_151 = new Geometric.Point(_x:  -val_155, _y:  val_155);
            // 0x028BB5BC: LDR s2, [sp, #0x130]       | S2 = val_151.x;                         
            // 0x028BB5C0: LDR s3, [sp, #0x134]       | S3 = val_151.y;                         
            // 0x028BB5C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BB5C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB5CC: MOV v0.16b, v12.16b        | V0 = (val_168 + 36) + -4;//m1           
            // 0x028BB5D0: MOV v1.16b, v13.16b        | V1 = (val_168 + 36);//m1                
            // 0x028BB5D4: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_154, y = val_131}, b:  new UnityEngine.Vector2() {x = val_151.x, y = val_151.y});
            UnityEngine.Vector2 val_152 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_154, y = val_131}, b:  new UnityEngine.Vector2() {x = val_151.x, y = val_151.y});
            // 0x028BB5D8: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BB5DC: MOV v8.16b, v0.16b         | V8 = val_152.x;//m1                     
            // 0x028BB5E0: MOV v9.16b, v1.16b         | V9 = val_152.y;//m1                     
            // 0x028BB5E4: ADD x25, x25, #1           | X25 = (0 + 1);                          
            val_192 = val_192 + 1;
            // 0x028BB5E8: CMP x25, x8                | STATE = COMPARE((0 + 1), mem[15762873573703704])
            // 0x028BB5EC: B.LO #0x28bb5fc            | if (0 < mem[15762873573703704]) goto label_266;
            if(val_192 < mem[15762873573703704])
            {
                goto label_266;
            }
            // 0x028BB5F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB5F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB5F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_266:
            // 0x028BB5FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB600: ADD x0, sp, #0xd8          | X0 = (1152921513251504800 + 216) = 1152921513251505016 (0x1000000203430378);
            // 0x028BB604: MOV v0.16b, v15.16b        | V0 = ((val_158 * 0.6f) * 0.5f);//m1     
            // 0x028BB608: MOV v1.16b, v15.16b        | V1 = ((val_158 * 0.6f) * 0.5f);//m1     
            // 0x028BB60C: MOV x26, x21               | X26 = 64 (0x40);//ML01                  
            // 0x028BB610: STP s8, s9, [x22, #-0x14]  | mem2[0] = val_152.x;  mem2[0] = val_152.y;  //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = val_152.x;
            mem2[0] = val_152.y;
            // 0x028BB614: STR xzr, [sp, #0xd8]       | stack[1152921513251505016] = 0x0;        //  dest_result_addr=1152921513251505016
            // 0x028BB618: BL #0x2697148              | null..ctor(_x:  -val_155, _y:  -val_155);
            Geometric.Point val_153 = new Geometric.Point(_x:  -val_155, _y:  -val_155);
            // 0x028BB61C: LDP s2, s3, [sp, #0xd8]    | S2 = val_153.x; S3 = val_153.y;          //  | 
            // 0x028BB620: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BB624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB628: MOV v0.16b, v12.16b        | V0 = (val_168 + 36) + -4;//m1           
            // 0x028BB62C: MOV v1.16b, v13.16b        | V1 = (val_168 + 36);//m1                
            // 0x028BB630: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_154, y = val_131}, b:  new UnityEngine.Vector2() {x = val_153.x, y = val_153.y});
            UnityEngine.Vector2 val_154 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_154, y = val_131}, b:  new UnityEngine.Vector2() {x = val_153.x, y = val_153.y});
            // 0x028BB634: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BB638: MOV v8.16b, v0.16b         | V8 = val_154.x;//m1                     
            // 0x028BB63C: MOV v9.16b, v1.16b         | V9 = val_154.y;//m1                     
            // 0x028BB640: ADD x25, x25, #1           | X25 = ((0 + 1) + 1);                    
            val_192 = val_192 + 1;
            // 0x028BB644: CMP x25, x8                | STATE = COMPARE(((0 + 1) + 1), mem[15762873573703704])
            // 0x028BB648: B.LO #0x28bb658            | if (0 < mem[15762873573703704]) goto label_267;
            if(val_192 < mem[15762873573703704])
            {
                goto label_267;
            }
            // 0x028BB64C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB650: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB654: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_267:
            // 0x028BB658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB65C: ADD x0, sp, #0xd0          | X0 = (1152921513251504800 + 208) = 1152921513251505008 (0x1000000203430370);
            // 0x028BB660: MOV v0.16b, v14.16b        | V0 = ((val_158 * 0.6f) * 0.5f);//m1     
            // 0x028BB664: MOV v1.16b, v15.16b        | V1 = ((val_158 * 0.6f) * 0.5f);//m1     
            // 0x028BB668: MOV x21, x24               | X21 = 9966784 (0x9814C0);//ML01         
            // 0x028BB66C: STP s8, s9, [x22, #-0xc]   | mem2[0] = val_154.x;  mem2[0] = val_154.y;  //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = val_154.x;
            mem2[0] = val_154.y;
            // 0x028BB670: STR xzr, [sp, #0xd0]       | stack[1152921513251505008] = 0x0;        //  dest_result_addr=1152921513251505008
            // 0x028BB674: BL #0x2697148              | null..ctor(_x:  val_155, _y:  -val_155);
            Geometric.Point val_155 = new Geometric.Point(_x:  val_155, _y:  -val_155);
            // 0x028BB678: LDP s2, s3, [sp, #0xd0]    | S2 = val_155.x; S3 = val_155.y;          //  | 
            // 0x028BB67C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BB680: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB684: MOV v0.16b, v12.16b        | V0 = (val_168 + 36) + -4;//m1           
            val_161 = val_154;
            // 0x028BB688: MOV v1.16b, v13.16b        | V1 = (val_168 + 36);//m1                
            // 0x028BB68C: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_161, y = val_131}, b:  new UnityEngine.Vector2() {x = val_155.x, y = val_155.y});
            UnityEngine.Vector2 val_156 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_161, y = val_131}, b:  new UnityEngine.Vector2() {x = val_155.x, y = val_155.y});
            // 0x028BB690: LDR w8, [x23, #0x18]       | W8 = mem[15762873573703704];            
            // 0x028BB694: MOV v8.16b, v0.16b         | V8 = val_156.x;//m1                     
            // 0x028BB698: MOV v9.16b, v1.16b         | V9 = val_156.y;//m1                     
            // 0x028BB69C: ADD x25, x25, #1           | X25 = (((0 + 1) + 1) + 1);              
            val_192 = val_192 + 1;
            // 0x028BB6A0: CMP x25, x8                | STATE = COMPARE((((0 + 1) + 1) + 1), mem[15762873573703704])
            // 0x028BB6A4: B.LO #0x28bb6b4            | if (0 < mem[15762873573703704]) goto label_268;
            if(val_192 < mem[15762873573703704])
            {
                goto label_268;
            }
            // 0x028BB6A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB6AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB6B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_268:
            // 0x028BB6B4: LDR x9, [sp, #0xc8]        | X9 = mem[1052455787];                   
            val_143 = val_180;
            // 0x028BB6B8: STUR s8, [x22, #-4]        | mem2[0] = val_156.x;                     //  dest_result_addr=0
            mem2[0] = val_156.x;
            // 0x028BB6BC: STR s9, [x22]              | mem2[0] = val_156.y;                     //  dest_result_addr=0
            mem2[0] = val_156.y;
            // 0x028BB6C0: CBNZ x9, #0x28bb6d0        | if (mem[1052455787] != 0) goto label_269;
            if(val_143 != 0)
            {
                goto label_269;
            }
            // 0x028BB6C4: MOV x24, x9                | X24 = mem[1052455787];//m1              
            // 0x028BB6C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028BB6CC: MOV x9, x24                | X9 = mem[1052455787];//m1               
            val_143 = val_143;
            label_269:
            // 0x028BB6D0: LDR w8, [x9, #0x18]        | W8 = mem[1052455787] + 24;              
            // 0x028BB6D4: FMUL s8, s10, s11          | S8 = (val_158 * (val_158 * 0.6f));      
            val_162 = val_158 * val_148;
            // 0x028BB6D8: SUB x24, x25, #3           | X24 = ((((0 + 1) + 1) + 1) - 3);        
            var val_157 = val_192 - 3;
            // 0x028BB6DC: CMP x24, x8                | STATE = COMPARE(((((0 + 1) + 1) + 1) - 3), mem[1052455787] + 24)
            // 0x028BB6E0: B.LO #0x28bb6f8            | if (val_157 < mem[1052455787] + 24) goto label_270;
            if(val_157 < (mem[1052455787] + 24))
            {
                goto label_270;
            }
            // 0x028BB6E4: MOV x25, x9                | X25 = mem[1052455787];//m1              
            // 0x028BB6E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB6EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB6F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x028BB6F4: MOV x9, x25                | X9 = mem[1052455787];//m1               
            val_143 = val_143;
            label_270:
            // 0x028BB6F8: STUR s8, [x28, #-0xc]      | mem2[0] = (val_158 * (val_158 * 0.6f));  //  dest_result_addr=0
            mem2[0] = val_162;
            // 0x028BB6FC: LDR w8, [x9, #0x18]        | W8 = mem[1052455787] + 24;              
            // 0x028BB700: ADD x24, x24, #1           | X24 = (((((0 + 1) + 1) + 1) - 3) + 1);  
            val_157 = val_157 + 1;
            // 0x028BB704: CMP x24, x8                | STATE = COMPARE((((((0 + 1) + 1) + 1) - 3) + 1), mem[1052455787] + 24)
            // 0x028BB708: B.LO #0x28bb720            | if (val_157 < mem[1052455787] + 24) goto label_271;
            if(val_157 < (mem[1052455787] + 24))
            {
                goto label_271;
            }
            // 0x028BB70C: MOV x25, x9                | X25 = mem[1052455787];//m1              
            // 0x028BB710: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB718: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x028BB71C: MOV x9, x25                | X9 = mem[1052455787];//m1               
            val_143 = val_143;
            label_271:
            // 0x028BB720: STUR s8, [x28, #-8]        | mem2[0] = (val_158 * (val_158 * 0.6f));  //  dest_result_addr=0
            mem2[0] = val_162;
            // 0x028BB724: LDR w8, [x9, #0x18]        | W8 = mem[1052455787] + 24;              
            // 0x028BB728: ADD x24, x24, #1           | X24 = ((((((0 + 1) + 1) + 1) - 3) + 1) + 1);
            val_157 = val_157 + 1;
            // 0x028BB72C: CMP x24, x8                | STATE = COMPARE(((((((0 + 1) + 1) + 1) - 3) + 1) + 1), mem[1052455787] + 24)
            // 0x028BB730: B.LO #0x28bb748            | if (val_157 < mem[1052455787] + 24) goto label_272;
            if(val_157 < (mem[1052455787] + 24))
            {
                goto label_272;
            }
            // 0x028BB734: MOV x25, x9                | X25 = mem[1052455787];//m1              
            // 0x028BB738: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB73C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB740: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x028BB744: MOV x9, x25                | X9 = mem[1052455787];//m1               
            val_143 = val_143;
            label_272:
            // 0x028BB748: STUR s8, [x28, #-4]        | mem2[0] = (val_158 * (val_158 * 0.6f));  //  dest_result_addr=0
            mem2[0] = val_162;
            // 0x028BB74C: LDR w8, [x9, #0x18]        | W8 = mem[1052455787] + 24;              
            // 0x028BB750: ADD x24, x24, #1           | X24 = (((((((0 + 1) + 1) + 1) - 3) + 1) + 1) + 1);
            val_157 = val_157 + 1;
            // 0x028BB754: STR x9, [sp, #0xc8]        | stack[1152921513251505000] = mem[1052455787];  //  dest_result_addr=1152921513251505000
            // 0x028BB758: CMP x24, x8                | STATE = COMPARE((((((((0 + 1) + 1) + 1) - 3) + 1) + 1) + 1), mem[1052455787] + 24)
            // 0x028BB75C: B.LO #0x28bb76c            | if (val_157 < mem[1052455787] + 24) goto label_273;
            if(val_157 < (mem[1052455787] + 24))
            {
                goto label_273;
            }
            // 0x028BB760: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BB764: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB768: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_273:
            // 0x028BB76C: ADD x19, x19, #1           | X19 = (0 + 1);                          
            val_140 = 0 + 1;
            // 0x028BB770: CMP x19, #3                | STATE = COMPARE((0 + 1), 0x3)           
            // 0x028BB774: STR s8, [x28], #0x10       | mem2[0] = (val_158 * (val_158 * 0.6f));  //  dest_result_addr=0
            mem2[0] = val_162;
            // 0x028BB778: ADD x27, x27, #8           | X27 = ((val_168 + 36) + 8);             
            val_146 = val_131 + 8;
            // 0x028BB77C: ADD x22, x22, #0x20        | X22 = ((val_145 + 60) + 32);            
            val_193 = val_193 + 32;
            // 0x028BB780: ADD x25, x24, #1           | X25 = ((((((((0 + 1) + 1) + 1) - 3) + 1) + 1) + 1) + 1);
            var val_158 = val_157 + 1;
            // 0x028BB784: MOV x24, x21               | X24 = 9966784 (0x9814C0);//ML01         
            // 0x028BB788: MOV x21, x26               | X21 = 64 (0x40);//ML01                  
            val_144 = val_172;
            // 0x028BB78C: B.NE #0x28bb494            | if (val_140 != 0x3) goto label_274;     
            if(val_140 != 3)
            {
                goto label_274;
            }
            // 0x028BB790: LDR w10, [sp, #0x3c]       | W10 = 0x64;                             
            // 0x028BB794: ADRP x22, #0x3626000       | X22 = 56778752 (0x3626000);             
            // 0x028BB798: LDR x22, [x22, #0x470]     | X22 = 1152921504840765440;              
            val_149 = 1152921504840765440;
            // 0x028BB79C: LDR x26, [sp, #0xb0]       | X26 = 0x3F800000;                       
            // 0x028BB7A0: LDR s1, [sp, #0xbc]        | S1 = Infinity;                          
            // 0x028BB7A4: ADD w10, w10, #1           | W10 = (100 + 1) = 101 (0x00000065);     
            // 0x028BB7A8: ORR w25, wzr, #0xc         | W25 = 12(0xC);                          
            // 0x028BB7AC: CMP w10, #2                | STATE = COMPARE(0x65, 0x2)              
            // 0x028BB7B0: B.LE #0x28bafd8            | if (101 <= 0x2) goto label_275;         
            if(101 <= 2)
            {
                goto label_275;
            }
            label_151:
            // 0x028BB7B4: LDR x25, [sp, #0x70]       | X25 = this;                             
            val_141 = val_141;
            // 0x028BB7B8: LDRB w8, [x25, #0xb4]      | W8 = this.<DebugDraw>k__BackingField;   
            // 0x028BB7BC: CBZ w8, #0x28bb82c         | if (this.<DebugDraw>k__BackingField == false) goto label_276;
            if((this.<DebugDraw>k__BackingField) == false)
            {
                goto label_276;
            }
            // 0x028BB7C0: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BB7C4: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BB7C8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BB7CC: LDP s9, s8, [x29, #-0x98]  | S9 = val_11.x; S8 = val_11.y;            //  | 
            // 0x028BB7D0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BB7D4: TBZ w8, #0, #0x28bb7e4     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_278;
            // 0x028BB7D8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BB7DC: CBNZ w8, #0x28bb7e4        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_278;
            // 0x028BB7E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_278:
            // 0x028BB7E4: LDP s1, s0, [sp, #0x50]    | S1 = (val_145 + 0) + 32 + 4; S0 = (val_145 + 0) + 32; //  | 
            // 0x028BB7E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BB7EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB7F0: MOV v2.16b, v9.16b         | V2 = val_11.x;//m1                      
            // 0x028BB7F4: MOV v3.16b, v8.16b         | V3 = val_11.y;//m1                      
            // 0x028BB7F8: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = (val_145 + 0) + 32, y = (val_145 + 0) + 32 + 4}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            UnityEngine.Vector2 val_159 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = (val_145 + 0) + 32, y = (val_145 + 0) + 32 + 4}, b:  new UnityEngine.Vector2() {x = val_11.x, y = val_11.y});
            // 0x028BB7FC: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BB800: MOV v8.16b, v0.16b         | V8 = val_159.x;//m1                     
            // 0x028BB804: MOV v9.16b, v1.16b         | V9 = val_159.y;//m1                     
            // 0x028BB808: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BB80C: TBZ w8, #0, #0x28bb81c     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_280;
            // 0x028BB810: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BB814: CBNZ w8, #0x28bb81c        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_280;
            // 0x028BB818: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_280:
            // 0x028BB81C: FMOV s2, #1.00000000       | S2 = 1;                                 
            // 0x028BB820: MOV v0.16b, v8.16b         | V0 = val_159.x;//m1                     
            val_161 = val_159.x;
            // 0x028BB824: MOV v1.16b, v9.16b         | V1 = val_159.y;//m1                     
            // 0x028BB828: BL #0x28b9040              | Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = val_161, y = val_159.y}, size:  1f);
            Pathfinding.RVO.Sampled.Agent.DrawCross(p:  new UnityEngine.Vector2() {x = val_161, y = val_159.y}, size:  1f);
            label_276:
            // 0x028BB82C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028BB830: LDR x8, [x8, #0xfb0]       | X8 = 1152921504708657152;               
            // 0x028BB834: LDR s8, [x25, #0x3c]       | S8 = mem[1152921513251517484];          
            // 0x028BB838: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BB83C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BB840: TBZ w8, #0, #0x28bb850     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_282;
            // 0x028BB844: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BB848: CBNZ w8, #0x28bb850        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_282;
            // 0x028BB84C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_282:
            // 0x028BB850: LDP s1, s0, [sp, #0x50]    | S1 = (val_145 + 0) + 32 + 4; S0 = (val_145 + 0) + 32; //  | 
            // 0x028BB854: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BB858: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB85C: MOV v2.16b, v8.16b         | V2 = mem[1152921513251517484];//m1      
            // 0x028BB860: BL #0x2697e88              | X0 = UnityEngine.Vector2.ClampMagnitude(vector:  new UnityEngine.Vector2() {x = (val_145 + 0) + 32, y = (val_145 + 0) + 32 + 4}, maxLength:  mem[1152921513251517484]);
            UnityEngine.Vector2 val_160 = UnityEngine.Vector2.ClampMagnitude(vector:  new UnityEngine.Vector2() {x = (val_145 + 0) + 32, y = (val_145 + 0) + 32 + 4}, maxLength:  mem[1152921513251517484]);
            // 0x028BB864: LDR x0, [x22]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BB868: MOV v8.16b, v0.16b         | V8 = val_160.x;//m1                     
            // 0x028BB86C: MOV v9.16b, v1.16b         | V9 = val_160.y;//m1                     
            // 0x028BB870: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BB874: TBZ w8, #0, #0x28bb884     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_284;
            // 0x028BB878: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BB87C: CBNZ w8, #0x28bb884        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_284;
            // 0x028BB880: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_284:
            // 0x028BB884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BB888: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028BB88C: ADD x0, sp, #0xe0          | X0 = (1152921513251504800 + 224) = 1152921513251505024 (0x1000000203430380);
            // 0x028BB890: MOV v0.16b, v8.16b         | V0 = val_160.x;//m1                     
            // 0x028BB894: MOV v2.16b, v9.16b         | V2 = val_160.y;//m1                     
            // 0x028BB898: STR wzr, [sp, #0xe8]       | stack[1152921513251505032] = 0x0;        //  dest_result_addr=1152921513251505032
            // 0x028BB89C: STR xzr, [sp, #0xe0]       | stack[1152921513251505024] = 0x0;        //  dest_result_addr=1152921513251505024
            // 0x028BB8A0: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028BB8A4: LDP w8, w9, [sp, #0xe0]    | W8 = 0x0; W9 = 0x0;                      //  | 
            // 0x028BB8A8: LDR w10, [sp, #0xe8]       | W10 = 0x0;                              
            // 0x028BB8AC: STP w8, w9, [x25, #0xd4]   | mem[1152921513251517636] = 0x0;  mem[1152921513251517640] = 0x0;  //  dest_result_addr=1152921513251517636 |  dest_result_addr=1152921513251517640
            mem[1152921513251517636] = 0;
            mem[1152921513251517640] = 0;
            // 0x028BB8B0: STR w10, [x25, #0xdc]      | mem[1152921513251517644] = 0x0;          //  dest_result_addr=1152921513251517644
            mem[1152921513251517644] = 0;
            label_4:
            // 0x028BB8B4: SUB sp, x29, #0x90         | SP = (1152921513251505408 - 144) = 1152921513251505264 (0x1000000203430470);
            // 0x028BB8B8: LDP x29, x30, [sp, #0x90]  | X29 = ; X30 = ;                          //  | 
            // 0x028BB8BC: LDP x20, x19, [sp, #0x80]  | X20 = ; X19 = ;                          //  | 
            // 0x028BB8C0: LDP x22, x21, [sp, #0x70]  | X22 = ; X21 = ;                          //  | 
            // 0x028BB8C4: LDP x24, x23, [sp, #0x60]  | X24 = ; X23 = ;                          //  | 
            // 0x028BB8C8: LDP x26, x25, [sp, #0x50]  | X26 = ; X25 = ;                          //  | 
            // 0x028BB8CC: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
            // 0x028BB8D0: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x028BB8D4: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x028BB8D8: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x028BB8DC: LDP d15, d14, [sp], #0xa0  | D15 = ; D14 = ;                          //  | 
            // 0x028BB8E0: RET                        |  return;                                
            return;
            label_62:
            // 0x028BB8E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  this.velocity, _y:  null), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028BC9BC (42715580), len: 136  VirtAddr: 0x028BC9BC RVA: 0x028BC9BC token: 100682493 methodIndex: 51105 delegateWrapperIndex: 0 methodInvoker: 0
        private static UnityEngine.Color Rainbow(float v)
        {
            //
            // Disasemble & Code
            //  | 
            float val_1;
            // 0x028BC9BC: STP x29, x30, [sp, #-0x10]! | stack[1152921513251842688] = ???;  stack[1152921513251842696] = ???;  //  dest_result_addr=1152921513251842688 |  dest_result_addr=1152921513251842696
            // 0x028BC9C0: MOV x29, sp                | X29 = 1152921513251842688 (0x1000000203482A80);//ML01
            // 0x028BC9C4: STP xzr, xzr, [sp, #-0x10]! | stack[1152921513251842672] = 0x0;  stack[1152921513251842680] = 0x0;  //  dest_result_addr=1152921513251842672 |  dest_result_addr=1152921513251842680
            // 0x028BC9C8: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028BC9CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC9D0: MOV x0, sp                 | X0 = 1152921513251842672 (0x1000000203482A70);//ML01
            // 0x028BC9D4: MOV v2.16b, v1.16b         | V2 = 0;//m1                             
            // 0x028BC9D8: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
            // 0x028BC9DC: LDR s0, [sp]               | S0 = 0;                                 
            // 0x028BC9E0: FMOV s3, #1.00000000       | S3 = 1;                                 
            // 0x028BC9E4: FCMP s0, s3                | STATE = COMPARE(0, 1)                   
            // 0x028BC9E8: B.LE #0x28bca08            | if (0f <= 1f) goto label_0;             
            if(0f <= 1f)
            {
                goto label_0;
            }
            // 0x028BC9EC: FMOV s1, #-1.00000000      | S1 = -1;                                
            // 0x028BC9F0: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
            // 0x028BC9F4: FADD s1, s0, s1            | S1 = (0f + -1f);                        
            val_1 = 0f + (-1f);
            // 0x028BC9F8: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x028BC9FC: STR s1, [sp, #4]           | stack[1152921513251842676] = (0f + -1f);  //  dest_result_addr=1152921513251842676
            // 0x028BCA00: STR w8, [sp]               | stack[1152921513251842672] = 0x3F800000;  //  dest_result_addr=1152921513251842672
            // 0x028BCA04: B #0x28bca0c               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x028BCA08: LDR s1, [sp, #4]           | S1 = (0f + -1f);                        
            val_1 = val_1;
            label_1:
            // 0x028BCA0C: FCMP s1, s3                | STATE = COMPARE((0f + -1f), 1)          
            // 0x028BCA10: B.LE #0x28bca30            | if (val_1 <= 1f) goto label_2;          
            if(val_1 <= 1f)
            {
                goto label_2;
            }
            // 0x028BCA14: FMOV s2, #-1.00000000      | S2 = -1;                                
            float val_1 = -1f;
            // 0x028BCA18: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
            // 0x028BCA1C: FADD s2, s1, s2            | S2 = ((0f + -1f) + -1f);                
            val_1 = val_1 + val_1;
            // 0x028BCA20: MOV v1.16b, v3.16b         | V1 = 1;//m1                             
            // 0x028BCA24: STR s2, [sp, #8]           | stack[1152921513251842680] = ((0f + -1f) + -1f);  //  dest_result_addr=1152921513251842680
            // 0x028BCA28: STR w8, [sp, #4]           | stack[1152921513251842676] = 0x3F800000;  //  dest_result_addr=1152921513251842676
            // 0x028BCA2C: B #0x28bca34               |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x028BCA30: LDR s2, [sp, #8]           | S2 = ((0f + -1f) + -1f);                
            label_3:
            // 0x028BCA34: LDR s3, [sp, #0xc]         | S3 = 0;                                 
            // 0x028BCA38: MOV sp, x29                | SP = 1152921513251842688 (0x1000000203482A80);//ML01
            // 0x028BCA3C: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x028BCA40: RET                        |  return new UnityEngine.Color() {r = 0f, g = val_1, b = -1f, a = 0f};
            return new UnityEngine.Color() {r = 0f, g = val_1, b = val_1, a = 0f};
            //  |  // // {name=val_0.r, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.g, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.b, type=System.Single, size=4, nSRN=2 }
            //  |  // // {name=val_0.a, type=System.Single, size=4, nSRN=3 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028BC2B4 (42713780), len: 1800  VirtAddr: 0x028BC2B4 RVA: 0x028BC2B4 token: 100682494 methodIndex: 51106 delegateWrapperIndex: 0 methodInvoker: 0
        private UnityEngine.Vector2 Trace(Pathfinding.RVO.Sampled.Agent.VO[] vos, int voCount, UnityEngine.Vector2 p, float cutoff, out float score)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.RVO.Simulator val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            float val_25;
            //  | 
            var val_26;
            //  | 
            float val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            float val_30;
            //  | 
            var val_31;
            //  | 
            float val_32;
            //  | 
            float val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            // 0x028BC2B4: STP d15, d14, [sp, #-0xa0]! | stack[1152921513251999552] = ???;  stack[1152921513251999560] = ???;  //  dest_result_addr=1152921513251999552 |  dest_result_addr=1152921513251999560
            // 0x028BC2B8: STP d13, d12, [sp, #0x10]  | stack[1152921513251999568] = ???;  stack[1152921513251999576] = ???;  //  dest_result_addr=1152921513251999568 |  dest_result_addr=1152921513251999576
            // 0x028BC2BC: STP d11, d10, [sp, #0x20]  | stack[1152921513251999584] = ???;  stack[1152921513251999592] = ???;  //  dest_result_addr=1152921513251999584 |  dest_result_addr=1152921513251999592
            // 0x028BC2C0: STP d9, d8, [sp, #0x30]    | stack[1152921513251999600] = ???;  stack[1152921513251999608] = ???;  //  dest_result_addr=1152921513251999600 |  dest_result_addr=1152921513251999608
            // 0x028BC2C4: STP x28, x27, [sp, #0x40]  | stack[1152921513251999616] = ???;  stack[1152921513251999624] = ???;  //  dest_result_addr=1152921513251999616 |  dest_result_addr=1152921513251999624
            // 0x028BC2C8: STP x26, x25, [sp, #0x50]  | stack[1152921513251999632] = ???;  stack[1152921513251999640] = ???;  //  dest_result_addr=1152921513251999632 |  dest_result_addr=1152921513251999640
            // 0x028BC2CC: STP x24, x23, [sp, #0x60]  | stack[1152921513251999648] = ???;  stack[1152921513251999656] = ???;  //  dest_result_addr=1152921513251999648 |  dest_result_addr=1152921513251999656
            // 0x028BC2D0: STP x22, x21, [sp, #0x70]  | stack[1152921513251999664] = ???;  stack[1152921513251999672] = ???;  //  dest_result_addr=1152921513251999664 |  dest_result_addr=1152921513251999672
            // 0x028BC2D4: STP x20, x19, [sp, #0x80]  | stack[1152921513251999680] = ???;  stack[1152921513251999688] = ???;  //  dest_result_addr=1152921513251999680 |  dest_result_addr=1152921513251999688
            // 0x028BC2D8: STP x29, x30, [sp, #0x90]  | stack[1152921513251999696] = ???;  stack[1152921513251999704] = ???;  //  dest_result_addr=1152921513251999696 |  dest_result_addr=1152921513251999704
            // 0x028BC2DC: ADD x29, sp, #0x90         | X29 = (1152921513251999552 + 144) = 1152921513251999696 (0x10000002034A8FD0);
            // 0x028BC2E0: SUB sp, sp, #0x80          | SP = (1152921513251999552 - 128) = 1152921513251999424 (0x10000002034A8EC0);
            // 0x028BC2E4: ADRP x23, #0x37b8000       | X23 = 58425344 (0x37B8000);             
            // 0x028BC2E8: LDRB w8, [x23, #0x91f]     | W8 = (bool)static_value_037B891F;       
            // 0x028BC2EC: MOV x19, x3                | X19 = 1152921513252080576 (0x10000002034BCBC0);//ML01
            // 0x028BC2F0: MOV v9.16b, v1.16b         | V9 = p.y;//m1                           
            // 0x028BC2F4: MOV v8.16b, v0.16b         | V8 = p.x;//m1                           
            // 0x028BC2F8: MOV w20, w2                | W20 = voCount;//m1                      
            // 0x028BC2FC: MOV x21, x1                | X21 = vos;//m1                          
            // 0x028BC300: MOV x22, x0                | X22 = 1152921513252011712 (0x10000002034ABEC0);//ML01
            // 0x028BC304: STR s2, [sp, #0x1c]        | stack[1152921513251999452] = cutoff;     //  dest_result_addr=1152921513251999452
            // 0x028BC308: TBNZ w8, #0, #0x28bc324    | if (static_value_037B891F == true) goto label_0;
            // 0x028BC30C: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x028BC310: LDR x8, [x8, #0x448]       | X8 = 0x2B8AAC4;                         
            // 0x028BC314: LDR w0, [x8]               | W0 = 0x16F;                             
            // 0x028BC318: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F, ????);      
            // 0x028BC31C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BC320: STRB w8, [x23, #0x91f]     | static_value_037B891F = true;            //  dest_result_addr=58427679
            label_0:
            // 0x028BC324: STR xzr, [sp, #0x78]       | stack[1152921513251999544] = 0x0;        //  dest_result_addr=1152921513251999544
            // 0x028BC328: STR wzr, [sp, #0x74]       | stack[1152921513251999540] = 0x0;        //  dest_result_addr=1152921513251999540
            // 0x028BC32C: STR xzr, [sp, #0x68]       | stack[1152921513251999528] = 0x0;        //  dest_result_addr=1152921513251999528
            // 0x028BC330: STR wzr, [x19]             | score = 0;                               //  dest_result_addr=1152921513252080576
            score = 0f;
            // 0x028BC334: LDR x23, [x22, #0xe0]      | X23 = this.simulator; //P2              
            val_21 = this.simulator;
            // 0x028BC338: CBNZ x23, #0x28bc340       | if (this.simulator != null) goto label_1;
            if(val_21 != null)
            {
                goto label_1;
            }
            // 0x028BC33C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16F, ????);      
            label_1:
            // 0x028BC340: LDR s0, [x23, #0x4c]       | S0 = this.simulator.stepScale; //P2     
            // 0x028BC344: ADD x8, x21, #0x20         | X8 = vos[0x20]; //PARR1                 
            // 0x028BC348: STR x8, [sp, #0x28]        | stack[1152921513251999464] = vos[0x20];  //  dest_result_addr=1152921513251999464
            VO[] val_21 = vos[32];
            // 0x028BC34C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028BC350: STR s0, [sp, #0x38]        | stack[1152921513251999480] = this.simulator.stepScale;  //  dest_result_addr=1152921513251999480
            // 0x028BC354: LDR s0, [x8, #0x930]       | S0 = Infinity;                          
            // 0x028BC358: ADRP x9, #0x2bc6000        | X9 = 45899776 (0x2BC6000);              
            // 0x028BC35C: ADRP x27, #0x366e000       | X27 = 57073664 (0x366E000);             
            // 0x028BC360: ADRP x28, #0x3626000       | X28 = 56778752 (0x3626000);             
            // 0x028BC364: LDR x27, [x27, #0xfb0]     | X27 = 1152921504708657152;              
            // 0x028BC368: LDR x28, [x28, #0x470]     | X28 = 1152921504840765440;              
            // 0x028BC36C: STR s0, [sp, #0x54]        | stack[1152921513251999508] = 0x7F800000;  //  dest_result_addr=1152921513251999508
            // 0x028BC370: LDR s0, [x9, #0x6a8]       | S0 = -50;                               
            // 0x028BC374: ADRP x10, #0x2a92000       | X10 = 44638208 (0x2A92000);             
            // 0x028BC378: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x028BC37C: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x028BC380: STR s0, [sp, #0x34]        | stack[1152921513251999476] = 0xC2480000;  //  dest_result_addr=1152921513251999476
            // 0x028BC384: LDR s0, [x10, #0x4b4]      | S0 = 0.1;                               
            // 0x028BC388: MOV w26, w20               | W26 = voCount;//m1                      
            // 0x028BC38C: STR s0, [sp, #0x24]        | stack[1152921513251999460] = 0x3DCCCCCD;  //  dest_result_addr=1152921513251999460
            // 0x028BC390: LDR s0, [x8, #0x7ac]       | S0 = 0.2;                               
            // 0x028BC394: STR s0, [sp, #0x20]        | stack[1152921513251999456] = 0x3E4CCCCD;  //  dest_result_addr=1152921513251999456
            label_31:
            // 0x028BC398: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BC39C: MOV v13.16b, v8.16b        | V13 = p.x;//m1                          
            // 0x028BC3A0: MOV v12.16b, v9.16b        | V12 = p.y;//m1                          
            // 0x028BC3A4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BC3A8: TBZ w8, #0, #0x28bc3b8     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028BC3AC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BC3B0: CBNZ w8, #0x28bc3b8        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028BC3B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_3:
            // 0x028BC3B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC3BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC3C0: BL #0x2697648              | X0 = UnityEngine.Vector2.get_zero();    
            UnityEngine.Vector2 val_1 = UnityEngine.Vector2.zero;
            // 0x028BC3C4: FMOV s14, wzr              | S14 = 0f;                               
            val_25 = 0f;
            // 0x028BC3C8: STP s0, s1, [sp, #0x78]    | stack[1152921513251999544] = val_1.x;  stack[1152921513251999548] = val_1.y;  //  dest_result_addr=1152921513251999544 |  dest_result_addr=1152921513251999548
            // 0x028BC3CC: CMP w20, #1                | STATE = COMPARE(voCount, 0x1)           
            // 0x028BC3D0: B.LT #0x28bc474            | if (voCount < 1) goto label_4;          
            if(voCount < 1)
            {
                goto label_4;
            }
            // 0x028BC3D4: LDR x23, [sp, #0x28]       | X23 = vos[0x20];                        
            // 0x028BC3D8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            var val_22 = 0;
            // 0x028BC3DC: FMOV s14, wzr              | S14 = 0f;                               
            label_9:
            // 0x028BC3E0: CBNZ x21, #0x28bc3e8       | if (vos != null) goto label_5;          
            if(vos != null)
            {
                goto label_5;
            }
            // 0x028BC3E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_5:
            // 0x028BC3E8: LDR w8, [x21, #0x18]       | W8 = vos.Length; //P2                   
            // 0x028BC3EC: CMP x24, x8                | STATE = COMPARE(0x0, vos.Length)        
            // 0x028BC3F0: B.LO #0x28bc400            | if (0 < vos.Length) goto label_6;       
            if(val_22 < vos.Length)
            {
                goto label_6;
            }
            // 0x028BC3F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x028BC3F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC3FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_6:
            // 0x028BC400: ADD x1, sp, #0x74          | X1 = (1152921513251999424 + 116) = 1152921513251999540 (0x10000002034A8F34);
            // 0x028BC404: MOV x0, x23                | X0 = vos[0x20];//m1                     
            // 0x028BC408: MOV v0.16b, v13.16b        | V0 = p.x;//m1                           
            // 0x028BC40C: MOV v1.16b, v12.16b        | V1 = p.y;//m1                           
            // 0x028BC410: BL #0x28bc018              | X0 = label_Agent_VO_Det_GL028BC018();   
            // 0x028BC414: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BC418: LDP s11, s10, [sp, #0x78]  | S11 = val_1.x; S10 = val_1.y;            //  | 
            // 0x028BC41C: MOV v8.16b, v0.16b         | V8 = p.x;//m1                           
            // 0x028BC420: MOV v9.16b, v1.16b         | V9 = p.y;//m1                           
            // 0x028BC424: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BC428: TBZ w8, #0, #0x28bc438     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x028BC42C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BC430: CBNZ w8, #0x28bc438        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x028BC434: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_8:
            // 0x028BC438: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC43C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC440: MOV v0.16b, v11.16b        | V0 = val_1.x;//m1                       
            // 0x028BC444: MOV v1.16b, v10.16b        | V1 = val_1.y;//m1                       
            // 0x028BC448: MOV v2.16b, v8.16b         | V2 = p.x;//m1                           
            // 0x028BC44C: MOV v3.16b, v9.16b         | V3 = p.y;//m1                           
            // 0x028BC450: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_1.x, y = val_1.y}, b:  new UnityEngine.Vector2() {x = p.x, y = p.y});
            UnityEngine.Vector2 val_2 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_1.x, y = val_1.y}, b:  new UnityEngine.Vector2() {x = p.x, y = p.y});
            // 0x028BC454: STP s0, s1, [sp, #0x78]    | stack[1152921513251999544] = val_2.x;  stack[1152921513251999548] = val_2.y;  //  dest_result_addr=1152921513251999544 |  dest_result_addr=1152921513251999548
            // 0x028BC458: LDR s0, [sp, #0x74]        | S0 = 0;                                 
            // 0x028BC45C: ADD x24, x24, #1           | X24 = (0 + 1);                          
            val_22 = val_22 + 1;
            // 0x028BC460: ADD x23, x23, #0x50        | X23 = (vos[0x20] + 80);                 
            val_21 = val_21 + 80;
            // 0x028BC464: FCMP s0, s14               | STATE = COMPARE(0, 0)                   
            // 0x028BC468: FCSEL s14, s0, s14, gt     | S14 = 0f > 0f ? 0f : 0f;                
            float val_3 = (0f > 0f) ? (0f) : (0f);
            // 0x028BC46C: CMP w26, w24               | STATE = COMPARE(voCount, (0 + 1))       
            // 0x028BC470: B.NE #0x28bc3e0            | if (voCount != 0) goto label_9;         
            if(voCount != val_22)
            {
                goto label_9;
            }
            label_4:
            // 0x028BC474: LDR s0, [x22, #0x6c]       | S0 = this.desiredVelocity; //P2         
            // 0x028BC478: LDR s1, [x22, #0x74]       | 
            // 0x028BC47C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC480: ADD x0, sp, #0x58          | X0 = (1152921513251999424 + 88) = 1152921513251999512 (0x10000002034A8F18);
            // 0x028BC484: STR xzr, [sp, #0x58]       | stack[1152921513251999512] = 0x0;        //  dest_result_addr=1152921513251999512
            // 0x028BC488: BL #0x2697148              | null..ctor(_x:  this.desiredVelocity, _y:  val_2.y);
            Geometric.Point val_4 = new Geometric.Point(_x:  this.desiredVelocity, _y:  val_2.y);
            // 0x028BC48C: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BC490: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BC494: TBZ w8, #0, #0x28bc4a4     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x028BC498: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BC49C: CBNZ w8, #0x28bc4a4        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x028BC4A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_11:
            // 0x028BC4A4: LDP s0, s1, [sp, #0x58]    | S0 = val_4.x; S1 = val_4.y;              //  | 
            // 0x028BC4A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC4AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC4B0: MOV v2.16b, v13.16b        | V2 = p.x;//m1                           
            // 0x028BC4B4: MOV v3.16b, v12.16b        | V3 = p.y;//m1                           
            // 0x028BC4B8: BL #0x2697490              | X0 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_4.x, y = val_4.y}, b:  new UnityEngine.Vector2() {x = p.x, y = p.y});
            UnityEngine.Vector2 val_5 = UnityEngine.Vector2.op_Subtraction(a:  new UnityEngine.Vector2() {x = val_4.x, y = val_4.y}, b:  new UnityEngine.Vector2() {x = p.x, y = p.y});
            // 0x028BC4BC: ADD x0, sp, #0x68          | X0 = (1152921513251999424 + 104) = 1152921513251999528 (0x10000002034A8F28);
            // 0x028BC4C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC4C4: STP s0, s1, [sp, #0x68]    | stack[1152921513251999528] = val_5.x;  stack[1152921513251999532] = val_5.y;  //  dest_result_addr=1152921513251999528 |  dest_result_addr=1152921513251999532
            // 0x028BC4C8: BL #0x269749c              | X0 = label_UnityEngine_Vector2_op_Subtraction_GL0269749C();
            // 0x028BC4CC: LDR x0, [x28]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            val_26 = null;
            // 0x028BC4D0: MOV v8.16b, v0.16b         | V8 = val_5.x;//m1                       
            // 0x028BC4D4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BC4D8: TBZ w8, #0, #0x28bc4ec     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x028BC4DC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BC4E0: CBNZ w8, #0x28bc4ec        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x028BC4E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            // 0x028BC4E8: LDR x0, [x28]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            val_26 = null;
            label_13:
            // 0x028BC4EC: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BC4F0: LDP s9, s10, [sp, #0x78]   | S9 = val_2.x; S10 = val_2.y;             //  | 
            // 0x028BC4F4: LDP s0, s1, [sp, #0x68]    | S0 = val_5.x; S1 = val_5.y;              //  | 
            // 0x028BC4F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC4FC: LDP s3, s2, [x8, #0x10]    | S3 = Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight; S2 = Pathfinding.RVO.Sampled.Agent.DesiredVelocityScale; //  | 
            // 0x028BC500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC504: FMUL s8, s8, s3            | S8 = (val_5.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight);
            val_27 = val_5.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight;
            // 0x028BC508: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_5.x, y = val_5.y}, d:  Pathfinding.RVO.Sampled.Agent.DesiredVelocityScale);
            UnityEngine.Vector2 val_6 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_5.x, y = val_5.y}, d:  Pathfinding.RVO.Sampled.Agent.DesiredVelocityScale);
            // 0x028BC50C: MOV v2.16b, v0.16b         | V2 = val_6.x;//m1                       
            // 0x028BC510: MOV v3.16b, v1.16b         | V3 = val_6.y;//m1                       
            // 0x028BC514: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC51C: MOV v0.16b, v9.16b         | V0 = val_2.x;//m1                       
            // 0x028BC520: MOV v1.16b, v10.16b        | V1 = val_2.y;//m1                       
            // 0x028BC524: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_2.x, y = val_2.y}, b:  new UnityEngine.Vector2() {x = val_6.x, y = val_6.y});
            UnityEngine.Vector2 val_7 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = val_2.x, y = val_2.y}, b:  new UnityEngine.Vector2() {x = val_6.x, y = val_6.y});
            // 0x028BC528: STP s0, s1, [sp, #0x78]    | stack[1152921513251999544] = val_7.x;  stack[1152921513251999548] = val_7.y;  //  dest_result_addr=1152921513251999544 |  dest_result_addr=1152921513251999548
            // 0x028BC52C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC534: MOV v0.16b, v14.16b        | V0 = 0f > 0f ? 0f : 0f;//m1             
            // 0x028BC538: MOV v1.16b, v8.16b         | V1 = (val_5.x * Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight);//m1
            // 0x028BC53C: BL #0x16f9434              | X0 = System.Math.Max(val1:  val_3, val2:  val_27);
            float val_8 = System.Math.Max(val1:  val_3, val2:  val_27);
            // 0x028BC540: MOV v10.16b, v0.16b        | V10 = val_8;//m1                        
            val_30 = val_8;
            // 0x028BC544: LDR s0, [sp, #0x54]        | S0 = Infinity;                          
            // 0x028BC548: STR s10, [x19]             | score = val_8;                           //  dest_result_addr=1152921513252080576
            score = val_30;
            // 0x028BC54C: FCMP s10, s0               | STATE = COMPARE(val_8, Infinity)        
            // 0x028BC550: FCSEL s0, s10, s0, mi      | S0 = val_30 < 0 ? val_8 : Infinityf;    
            float val_9 = (val_30 < 0) ? (val_30) : (Infinityf);
            // 0x028BC554: STR s0, [sp, #0x54]        | stack[1152921513251999508] = val_30 < 0 ? val_8 : Infinityf;  //  dest_result_addr=1152921513251999508
            // 0x028BC558: CMP w25, #0xb              | STATE = COMPARE(0x0, 0xB)               
            // 0x028BC55C: B.LT #0x28bc56c            | if (val_22 < 0xB) goto label_14;        
            if(val_22 < 11)
            {
                goto label_14;
            }
            // 0x028BC560: LDR s0, [sp, #0x1c]        | S0 = cutoff;                            
            // 0x028BC564: FCMP s10, s0               | STATE = COMPARE(val_8, cutoff)          
            // 0x028BC568: B.LS #0x28bc820            | if (val_30 <= cutoff) goto label_15;    
            if(val_30 <= cutoff)
            {
                goto label_15;
            }
            label_14:
            // 0x028BC56C: LDR s1, [sp, #0x34]        | S1 = -50;                               
            // 0x028BC570: SCVTF s0, w25              | S0 = 0;                                 
            float val_23 = 0f;
            // 0x028BC574: ADD x0, sp, #0x78          | X0 = (1152921513251999424 + 120) = 1152921513251999544 (0x10000002034A8F38);
            // 0x028BC578: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC57C: FDIV s0, s0, s1            | S0 = (0f / -50f);                       
            val_23 = val_23 / (-50f);
            // 0x028BC580: FMOV s1, #1.00000000       | S1 = 1;                                 
            // 0x028BC584: FADD s15, s0, s1           | S15 = ((0f / -50f) + 1f);               
            float val_10 = val_23 + 1f;
            // 0x028BC588: BL #0x2697ba0              | X0 = val_7.x.get_sqrMagnitude();        
            float val_11 = val_7.x.sqrMagnitude;
            // 0x028BC58C: LDP s9, s8, [sp, #0x78]    | S9 = val_7.x; S8 = val_7.y;              //  | 
            val_32 = val_7.x;
            val_33 = val_7.y;
            // 0x028BC590: MOV v11.16b, v0.16b        | V11 = val_11;//m1                       
            // 0x028BC594: FCMP s11, #0.0             | STATE = COMPARE(val_11, 0)              
            // 0x028BC598: B.LE #0x28bc610            | if (val_11 <= 0) goto label_16;         
            if(val_11 <= 0f)
            {
                goto label_16;
            }
            // 0x028BC59C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028BC5A0: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x028BC5A4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x028BC5A8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x028BC5AC: TBZ w8, #0, #0x28bc5bc     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x028BC5B0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x028BC5B4: CBNZ w8, #0x28bc5bc        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x028BC5B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_18:
            // 0x028BC5BC: FSQRT s14, s11             | 
            // 0x028BC5C0: FCMP s14, s14              | STATE = COMPARE(0f > 0f ? 0f : 0f, 0f > 0f ? 0f : 0f)
            // 0x028BC5C4: B.VC #0x28bc5d4            | if (val_3 < _TYPE_MAX_) goto label_19;  
            if(val_3 < _TYPE_MAX_)
            {
                goto label_19;
            }
            // 0x028BC5C8: MOV v0.16b, v11.16b        | V0 = val_11;//m1                        
            // 0x028BC5CC: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
            // 0x028BC5D0: MOV v14.16b, v0.16b        | V14 = val_11;//m1                       
            val_25 = val_11;
            label_19:
            // 0x028BC5D4: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BC5D8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BC5DC: TBZ w8, #0, #0x28bc5ec     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x028BC5E0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BC5E4: CBNZ w8, #0x28bc5ec        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x028BC5E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_21:
            // 0x028BC5EC: FDIV s2, s10, s14          | S2 = (val_8 / val_11);                  
            float val_12 = val_30 / val_25;
            // 0x028BC5F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC5F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC5F8: MOV v0.16b, v9.16b         | V0 = val_7.x;//m1                       
            // 0x028BC5FC: MOV v1.16b, v8.16b         | V1 = val_7.y;//m1                       
            // 0x028BC600: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_32, y = val_33}, d:  float val_12 = val_30 / val_25);
            UnityEngine.Vector2 val_13 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_32, y = val_33}, d:  val_12);
            // 0x028BC604: MOV v9.16b, v0.16b         | V9 = val_13.x;//m1                      
            val_32 = val_13.x;
            // 0x028BC608: MOV v8.16b, v1.16b         | V8 = val_13.y;//m1                      
            val_33 = val_13.y;
            // 0x028BC60C: STP s9, s8, [sp, #0x78]    | stack[1152921513251999544] = val_13.x;  stack[1152921513251999548] = val_13.y;  //  dest_result_addr=1152921513251999544 |  dest_result_addr=1152921513251999548
            label_16:
            // 0x028BC610: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector2);       
            // 0x028BC614: LDR s0, [sp, #0x38]        | S0 = this.simulator.stepScale;          
            // 0x028BC618: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector2.__il2cppRuntimeField_10A;
            // 0x028BC61C: FMUL s10, s0, s15          | S10 = (this.simulator.stepScale * ((0f / -50f) + 1f));
            val_30 = this.simulator.stepScale * val_10;
            // 0x028BC620: TBZ w8, #0, #0x28bc630     | if (UnityEngine.Vector2.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x028BC624: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished;
            // 0x028BC628: CBNZ w8, #0x28bc630        | if (UnityEngine.Vector2.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x028BC62C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector2), ????);
            label_23:
            // 0x028BC630: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC634: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC638: MOV v0.16b, v9.16b         | V0 = val_13.x;//m1                      
            // 0x028BC63C: MOV v1.16b, v8.16b         | V1 = val_13.y;//m1                      
            // 0x028BC640: MOV v2.16b, v10.16b        | V2 = (this.simulator.stepScale * ((0f / -50f) + 1f));//m1
            // 0x028BC644: BL #0x2697540              | X0 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_32, y = val_33}, d:  val_30);
            UnityEngine.Vector2 val_14 = UnityEngine.Vector2.op_Multiply(a:  new UnityEngine.Vector2() {x = val_32, y = val_33}, d:  val_30);
            // 0x028BC648: MOV v2.16b, v0.16b         | V2 = val_14.x;//m1                      
            // 0x028BC64C: MOV v3.16b, v1.16b         | V3 = val_14.y;//m1                      
            // 0x028BC650: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC654: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC658: MOV v0.16b, v13.16b        | V0 = p.x;//m1                           
            // 0x028BC65C: MOV v1.16b, v12.16b        | V1 = p.y;//m1                           
            // 0x028BC660: STP s2, s3, [sp, #0x78]    | stack[1152921513251999544] = val_14.x;  stack[1152921513251999548] = val_14.y;  //  dest_result_addr=1152921513251999544 |  dest_result_addr=1152921513251999548
            // 0x028BC664: BL #0x269754c              | X0 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = p.x, y = p.y}, b:  new UnityEngine.Vector2() {x = val_14.x, y = val_14.y});
            UnityEngine.Vector2 val_15 = UnityEngine.Vector2.op_Addition(a:  new UnityEngine.Vector2() {x = p.x, y = p.y}, b:  new UnityEngine.Vector2() {x = val_14.x, y = val_14.y});
            // 0x028BC668: LDRB w8, [x22, #0xb4]      | W8 = this.<DebugDraw>k__BackingField; //P2 
            // 0x028BC66C: MOV v8.16b, v0.16b         | V8 = val_15.x;//m1                      
            val_27 = val_15.x;
            // 0x028BC670: MOV v9.16b, v1.16b         | V9 = val_15.y;//m1                      
            // 0x028BC674: CBZ w8, #0x28bc810         | if (this.<DebugDraw>k__BackingField == false) goto label_24;
            if((this.<DebugDraw>k__BackingField) == false)
            {
                goto label_24;
            }
            // 0x028BC678: STP s9, s8, [sp, #0x4c]    | stack[1152921513251999500] = val_15.y;  stack[1152921513251999504] = val_15.x;  //  dest_result_addr=1152921513251999500 |  dest_result_addr=1152921513251999504
            // 0x028BC67C: LDR x0, [x28]              | X0 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BC680: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_10A;
            // 0x028BC684: TBZ w8, #0, #0x28bc694     | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_has_cctor == 0) goto label_26;
            // 0x028BC688: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished;
            // 0x028BC68C: CBNZ w8, #0x28bc694        | if (Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
            // 0x028BC690: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.RVO.Sampled.Agent), ????);
            label_26:
            // 0x028BC694: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC698: ADD x0, sp, #0x58          | X0 = (1152921513251999424 + 88) = 1152921513251999512 (0x10000002034A8F18);
            // 0x028BC69C: MOV v0.16b, v13.16b        | V0 = p.x;//m1                           
            // 0x028BC6A0: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028BC6A4: MOV v2.16b, v12.16b        | V2 = p.y;//m1                           
            // 0x028BC6A8: STR wzr, [sp, #0x60]       | stack[1152921513251999520] = 0x0;        //  dest_result_addr=1152921513251999520
            // 0x028BC6AC: STR xzr, [sp, #0x58]       | stack[1152921513251999512] = 0x0;        //  dest_result_addr=1152921513251999512
            // 0x028BC6B0: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028BC6B4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x028BC6B8: LDP s8, s9, [sp, #0x58]    | S8 = 0; S9 = 0;                          //  | 
            // 0x028BC6BC: LDR s10, [sp, #0x60]       | S10 = 0;                                
            // 0x028BC6C0: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x028BC6C4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x028BC6C8: LDP s15, s14, [x22, #0x60] | S15 = this.position; //P2                //  | 
            // 0x028BC6CC: LDR s11, [x22, #0x68]      | 
            // 0x028BC6D0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x028BC6D4: TBZ w8, #0, #0x28bc6e4     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x028BC6D8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x028BC6DC: CBNZ w8, #0x28bc6e4        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x028BC6E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_28:
            // 0x028BC6E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC6E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC6EC: MOV v0.16b, v8.16b         | V0 = 0 (0x0);//ML01                     
            // 0x028BC6F0: MOV v1.16b, v9.16b         | V1 = 0 (0x0);//ML01                     
            // 0x028BC6F4: MOV v2.16b, v10.16b        | V2 = 0 (0x0);//ML01                     
            // 0x028BC6F8: MOV v3.16b, v15.16b        | V3 = this.position;//m1                 
            // 0x028BC6FC: MOV v4.16b, v14.16b        | V4 = val_11;//m1                        
            // 0x028BC700: MOV v5.16b, v11.16b        | V5 = val_11;//m1                        
            // 0x028BC704: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = this.position, y = val_25, z = val_11});
            UnityEngine.Vector3 val_16 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = this.position, y = val_25, z = val_11});
            // 0x028BC708: STP s1, s0, [sp, #0x44]    | stack[1152921513251999492] = val_16.y;  stack[1152921513251999496] = val_16.x;  //  dest_result_addr=1152921513251999492 |  dest_result_addr=1152921513251999496
            // 0x028BC70C: STR s2, [sp, #0x40]        | stack[1152921513251999488] = val_16.z;   //  dest_result_addr=1152921513251999488
            // 0x028BC710: STR wzr, [sp, #0x60]       | stack[1152921513251999520] = 0x0;        //  dest_result_addr=1152921513251999520
            // 0x028BC714: STR xzr, [sp, #0x58]       | stack[1152921513251999512] = 0x0;        //  dest_result_addr=1152921513251999512
            // 0x028BC718: LDP s2, s0, [sp, #0x4c]    | S2 = val_15.y; S0 = val_15.x;            //  | 
            // 0x028BC71C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC720: ADD x0, sp, #0x58          | X0 = (1152921513251999424 + 88) = 1152921513251999512 (0x10000002034A8F18);
            // 0x028BC724: FMOV s1, wzr               | S1 = 0f;                                
            // 0x028BC728: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028BC72C: LDP s0, s1, [sp, #0x58]    | S0 = 0; S1 = 0;                          //  | 
            // 0x028BC730: LDR s2, [sp, #0x60]        | S2 = 0;                                 
            // 0x028BC734: LDP s3, s4, [x22, #0x60]   | S3 = this.position; //P2                 //  | 
            // 0x028BC738: LDR s5, [x22, #0x68]       | 
            // 0x028BC73C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC744: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = this.position, y = val_25, z = val_11});
            UnityEngine.Vector3 val_17 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = this.position, y = val_25, z = val_11});
            // 0x028BC748: MOV v10.16b, v0.16b        | V10 = val_17.x;//m1                     
            val_30 = val_17.x;
            // 0x028BC74C: STR s1, [sp, #0x3c]        | stack[1152921513251999484] = val_17.y;   //  dest_result_addr=1152921513251999484
            // 0x028BC750: LDR s0, [x19]              | S0 = val_8;                             
            float val_24 = score;
            // 0x028BC754: LDR s1, [sp, #0x24]        | S1 = 0.1;                               
            // 0x028BC758: MOV v9.16b, v2.16b         | V9 = val_17.z;//m1                      
            // 0x028BC75C: FDIV s0, s1, s0            | S0 = (0.1f / val_8);                    
            val_24 = 0.1f / val_24;
            // 0x028BC760: BL #0x28bc9bc              | X0 = Pathfinding.RVO.Sampled.Agent.Rainbow(v:  score = 0.1f / score);
            UnityEngine.Color val_18 = Pathfinding.RVO.Sampled.Agent.Rainbow(v:  val_24);
            // 0x028BC764: STP xzr, xzr, [sp, #0x58]  | stack[1152921513251999512] = 0x0;  stack[1152921513251999520] = 0x0;  //  dest_result_addr=1152921513251999512 |  dest_result_addr=1152921513251999520
            // 0x028BC768: MOV v15.16b, v3.16b        | V15 = val_18.a;//m1                     
            // 0x028BC76C: LDR s3, [sp, #0x20]        | S3 = 0.2;                               
            // 0x028BC770: MOV v8.16b, v0.16b         | V8 = val_18.r;//m1                      
            // 0x028BC774: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x028BC778: MOV v11.16b, v1.16b        | V11 = val_18.g;//m1                     
            // 0x028BC77C: MOV v14.16b, v2.16b        | V14 = val_18.b;//m1                     
            // 0x028BC780: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC784: ADD x0, sp, #0x58          | X0 = (1152921513251999424 + 88) = 1152921513251999512 (0x10000002034A8F18);
            // 0x028BC788: MOV v1.16b, v0.16b         | V1 = 1;//m1                             
            // 0x028BC78C: MOV v2.16b, v0.16b         | V2 = 1;//m1                             
            // 0x028BC790: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x028BC794: LDP s4, s5, [sp, #0x58]    | S4 = 0; S5 = 0;                          //  | 
            // 0x028BC798: LDP s6, s7, [sp, #0x60]    | S6 = 0; S7 = 0;                          //  | 
            // 0x028BC79C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC7A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC7A4: MOV v0.16b, v8.16b         | V0 = val_18.r;//m1                      
            // 0x028BC7A8: MOV v1.16b, v11.16b        | V1 = val_18.g;//m1                      
            // 0x028BC7AC: MOV v2.16b, v14.16b        | V2 = val_18.b;//m1                      
            // 0x028BC7B0: MOV v3.16b, v15.16b        | V3 = val_18.a;//m1                      
            // 0x028BC7B4: BL #0x20d3908              | X0 = UnityEngine.Color.op_Multiply(a:  new UnityEngine.Color() {r = val_18.r, g = val_18.g, b = val_18.b, a = val_18.a}, b:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
            UnityEngine.Color val_19 = UnityEngine.Color.op_Multiply(a:  new UnityEngine.Color() {r = val_18.r, g = val_18.g, b = val_18.b, a = val_18.a}, b:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
            // 0x028BC7B8: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x028BC7BC: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x028BC7C0: MOV v11.16b, v0.16b        | V11 = val_19.r;//m1                     
            // 0x028BC7C4: MOV v14.16b, v1.16b        | V14 = val_19.g;//m1                     
            val_25 = val_19.g;
            // 0x028BC7C8: MOV v15.16b, v2.16b        | V15 = val_19.b;//m1                     
            // 0x028BC7CC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x028BC7D0: MOV v8.16b, v3.16b         | V8 = val_19.a;//m1                      
            // 0x028BC7D4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x028BC7D8: TBZ w8, #0, #0x28bc7e8     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_30;
            // 0x028BC7DC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x028BC7E0: CBNZ w8, #0x28bc7e8        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
            // 0x028BC7E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_30:
            // 0x028BC7E8: STP s15, s8, [sp, #8]      | stack[1152921513251999432] = val_19.b;  stack[1152921513251999436] = val_19.a;  //  dest_result_addr=1152921513251999432 |  dest_result_addr=1152921513251999436
            // 0x028BC7EC: STP s11, s14, [sp]         | stack[1152921513251999424] = val_19.r;  stack[1152921513251999428] = val_19.g;  //  dest_result_addr=1152921513251999424 |  dest_result_addr=1152921513251999428
            // 0x028BC7F0: LDP s1, s0, [sp, #0x44]    | S1 = val_16.y; S0 = val_16.x;            //  | 
            // 0x028BC7F4: LDP s4, s2, [sp, #0x3c]    | S4 = val_17.y; S2 = val_16.z;            //  | 
            // 0x028BC7F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BC7FC: MOV v3.16b, v10.16b        | V3 = val_17.x;//m1                      
            // 0x028BC800: MOV v5.16b, v9.16b         | V5 = val_17.z;//m1                      
            // 0x028BC804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BC808: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, end:  new UnityEngine.Vector3() {x = val_30, y = val_17.y, z = val_17.z}, color:  new UnityEngine.Color() {r = val_19.r, g = val_19.b});
            UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, end:  new UnityEngine.Vector3() {x = val_30, y = val_17.y, z = val_17.z}, color:  new UnityEngine.Color() {r = val_19.r, g = val_19.b});
            // 0x028BC80C: LDP s9, s8, [sp, #0x4c]    | S9 = val_15.y; S8 = val_15.x;            //  | 
            val_27 = val_27;
            label_24:
            // 0x028BC810: ADD w8, w25, #1            | W8 = (val_22 + 1);                      
            var val_20 = val_22 + 1;
            // 0x028BC814: CMP w25, #0x31             | STATE = COMPARE(0x0, 0x31)              
            // 0x028BC818: MOV w25, w8                | W25 = (val_22 + 1);//m1                 
            val_22 = val_20;
            // 0x028BC81C: B.LT #0x28bc398            | if (val_22 < 0x31) goto label_31;       
            if(val_22 < 49)
            {
                goto label_31;
            }
            label_15:
            // 0x028BC820: LDR s0, [sp, #0x54]        | S0 = val_30 < 0 ? val_8 : Infinityf;    
            // 0x028BC824: MOV v1.16b, v12.16b        | V1 = p.y;//m1                           
            // 0x028BC828: STR s0, [x19]              | score = val_30 < 0 ? val_8 : Infinityf;  //  dest_result_addr=1152921513252080576
            score = val_9;
            // 0x028BC82C: MOV v0.16b, v13.16b        | V0 = p.x;//m1                           
            // 0x028BC830: SUB sp, x29, #0x90         | SP = (1152921513251999696 - 144) = 1152921513251999552 (0x10000002034A8F40);
            // 0x028BC834: LDP x29, x30, [sp, #0x90]  | X29 = ; X30 = ;                          //  | 
            // 0x028BC838: LDP x20, x19, [sp, #0x80]  | X20 = ; X19 = ;                          //  | 
            // 0x028BC83C: LDP x22, x21, [sp, #0x70]  | X22 = ; X21 = ;                          //  | 
            // 0x028BC840: LDP x24, x23, [sp, #0x60]  | X24 = ; X23 = ;                          //  | 
            // 0x028BC844: LDP x26, x25, [sp, #0x50]  | X26 = ; X25 = ;                          //  | 
            // 0x028BC848: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
            // 0x028BC84C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x028BC850: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x028BC854: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x028BC858: LDP d15, d14, [sp], #0xa0  | D15 = ; D14 = ;                          //  | 
            // 0x028BC85C: RET                        |  return new UnityEngine.Vector2() {x = p.x, y = p.y};
            return new UnityEngine.Vector2() {x = p.x, y = p.y};
            //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028BCA44 (42715716), len: 68  VirtAddr: 0x028BCA44 RVA: 0x028BCA44 token: 100682495 methodIndex: 51107 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool IntersectionFactor(UnityEngine.Vector2 start1, UnityEngine.Vector2 dir1, UnityEngine.Vector2 start2, UnityEngine.Vector2 dir2, out float factor)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            float val_2;
            // 0x028BCA44: FMUL s2, s2, s7            | S2 = (dir1.x * dir2.y);                 
            dir1.x = dir1.x * dir2.y;
            // 0x028BCA48: FMUL s3, s3, s6            | S3 = (dir1.y * dir2.x);                 
            dir1.y = dir1.y * dir2.x;
            // 0x028BCA4C: FSUB s2, s2, s3            | S2 = ((dir1.x * dir2.y) - (dir1.y * dir2.x));
            dir1.x = dir1.x - dir1.y;
            // 0x028BCA50: FCMP s2, #0.0              | STATE = COMPARE(((dir1.x * dir2.y) - (dir1.y * dir2.x)), 0)
            // 0x028BCA54: B.NE #0x28bca64            | if (dir1.x != 0) goto label_0;          
            if(dir1.x != 0f)
            {
                goto label_0;
            }
            // 0x028BCA58: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_1 = 0;
            // 0x028BCA5C: FMOV s0, wzr               | S0 = 0f;                                
            val_2 = 0f;
            // 0x028BCA60: B #0x28bca80               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x028BCA64: FSUB s1, s1, s5            | S1 = (start1.y - start2.y);             
            start1.y = start1.y - start2.y;
            // 0x028BCA68: FSUB s0, s0, s4            | S0 = (start1.x - start2.x);             
            start1.x = start1.x - start2.x;
            // 0x028BCA6C: FMUL s1, s6, s1            | S1 = (dir2.x * (start1.y - start2.y));  
            start1.y = dir2.x * start1.y;
            // 0x028BCA70: FMUL s0, s7, s0            | S0 = (dir2.y * (start1.x - start2.x));  
            start1.x = dir2.y * start1.x;
            // 0x028BCA74: FSUB s0, s1, s0            | S0 = ((dir2.x * (start1.y - start2.y)) - (dir2.y * (start1.x - start2.x)));
            start1.x = start1.y - start1.x;
            // 0x028BCA78: FDIV s0, s0, s2            | S0 = (((dir2.x * (start1.y - start2.y)) - (dir2.y * (start1.x - start2.x))) / ((dir1.x * dir2.y) - (dir1.y * dir2.x)));
            val_2 = start1.x / dir1.x;
            // 0x028BCA7C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_1 = 1;
            label_1:
            // 0x028BCA80: STR s0, [x1]               | mem2[0] = (((dir2.x * (start1.y - start2.y)) - (dir2.y * (start1.x - start2.x))) / ((dir1.x * dir2.y) - (dir1.y * dir2.x)));  //  dest_result_addr=0
            mem2[0] = val_2;
            // 0x028BCA84: RET                        |  return (System.Boolean)true;           
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028BCA88 (42715784), len: 440  VirtAddr: 0x028BCA88 RVA: 0x028BCA88 token: 100682496 methodIndex: 51108 delegateWrapperIndex: 0 methodInvoker: 0
        private static Agent()
        {
            //
            // Disasemble & Code
            // 0x028BCA88: STP x22, x21, [sp, #-0x30]! | stack[1152921513252276832] = ???;  stack[1152921513252276840] = ???;  //  dest_result_addr=1152921513252276832 |  dest_result_addr=1152921513252276840
            // 0x028BCA8C: STP x20, x19, [sp, #0x10]  | stack[1152921513252276848] = ???;  stack[1152921513252276856] = ???;  //  dest_result_addr=1152921513252276848 |  dest_result_addr=1152921513252276856
            // 0x028BCA90: STP x29, x30, [sp, #0x20]  | stack[1152921513252276864] = ???;  stack[1152921513252276872] = ???;  //  dest_result_addr=1152921513252276864 |  dest_result_addr=1152921513252276872
            // 0x028BCA94: ADD x29, sp, #0x20         | X29 = (1152921513252276832 + 32) = 1152921513252276864 (0x10000002034ECA80);
            // 0x028BCA98: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028BCA9C: LDRB w8, [x19, #0x920]     | W8 = (bool)static_value_037B8920;       
            // 0x028BCAA0: TBNZ w8, #0, #0x28bcabc    | if (static_value_037B8920 == true) goto label_0;
            // 0x028BCAA4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028BCAA8: LDR x8, [x8, #0x5c0]       | X8 = 0x2B8AA94;                         
            // 0x028BCAAC: LDR w0, [x8]               | W0 = 0x163;                             
            // 0x028BCAB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x163, ????);      
            // 0x028BCAB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BCAB8: STRB w8, [x19, #0x920]     | static_value_037B8920 = true;            //  dest_result_addr=58427680
            label_0:
            // 0x028BCABC: ADRP x20, #0x366e000       | X20 = 57073664 (0x366E000);             
            // 0x028BCAC0: LDR x20, [x20, #0xf28]     | X20 = 1152921504673247232;              
            // 0x028BCAC4: LDR x0, [x20]              | X0 = typeof(System.Diagnostics.Stopwatch);
            System.Diagnostics.Stopwatch val_1 = null;
            // 0x028BCAC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Diagnostics.Stopwatch), ????);
            // 0x028BCACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BCAD0: MOV x19, x0                | X19 = 1152921504673247232 (0x1000000003F53000);//ML01
            // 0x028BCAD4: BL #0x14ff724              | .ctor();                                
            val_1 = new System.Diagnostics.Stopwatch();
            // 0x028BCAD8: ADRP x21, #0x3626000       | X21 = 56778752 (0x3626000);             
            // 0x028BCADC: LDR x21, [x21, #0x470]     | X21 = 1152921504840765440;              
            // 0x028BCAE0: LDR x8, [x21]              | X8 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BCAE4: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BCAE8: STR x19, [x8]              | Pathfinding.RVO.Sampled.Agent.WallWeight = typeof(System.Diagnostics.Stopwatch); Pathfinding.RVO.Sampled.Agent.WallWeight.__il2cppRuntimeField_3 = 0x10000000;  //  dest_result_addr=1152921504840769536 dest_result_addr=1152921504840769540
            Pathfinding.RVO.Sampled.Agent.WallWeight = val_1;
            Pathfinding.RVO.Sampled.Agent.WallWeight.__il2cppRuntimeField_3 = 268435456;
            // 0x028BCAEC: LDR x0, [x20]              | X0 = typeof(System.Diagnostics.Stopwatch);
            System.Diagnostics.Stopwatch val_2 = null;
            // 0x028BCAF0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Diagnostics.Stopwatch), ????);
            // 0x028BCAF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BCAF8: MOV x19, x0                | X19 = 1152921504673247232 (0x1000000003F53000);//ML01
            // 0x028BCAFC: BL #0x14ff724              | .ctor();                                
            val_2 = new System.Diagnostics.Stopwatch();
            // 0x028BCB00: LDR x8, [x21]              | X8 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BCB04: MOVZ w9, #0x3ca3, lsl #16  | W9 = 1017315328 (0x3CA30000);//ML01     
            // 0x028BCB08: MOVK w9, #0xd70a           | W9 = 1017370378 (0x3CA3D70A);           
            // 0x028BCB0C: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BCB10: STR x19, [x8, #8]          | Pathfinding.RVO.Sampled.Agent.watch2 = typeof(System.Diagnostics.Stopwatch);  //  dest_result_addr=1152921504840769544
            Pathfinding.RVO.Sampled.Agent.watch2 = val_2;
            // 0x028BCB14: LDR x8, [x21]              | X8 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BCB18: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BCB1C: STR w9, [x8, #0x10]        | Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight = 0.02;  //  dest_result_addr=1152921504840769552
            Pathfinding.RVO.Sampled.Agent.DesiredVelocityWeight = 0.02f;
            // 0x028BCB20: LDR x8, [x21]              | X8 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BCB24: MOVZ w9, #0x3dcc, lsl #16  | W9 = 1036779520 (0x3DCC0000);//ML01     
            // 0x028BCB28: MOVK w9, #0xcccd           | W9 = 1036831949 (0x3DCCCCCD);           
            // 0x028BCB2C: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BCB30: STR w9, [x8, #0x14]        | Pathfinding.RVO.Sampled.Agent.DesiredVelocityScale = 0.1;  //  dest_result_addr=1152921504840769556
            Pathfinding.RVO.Sampled.Agent.DesiredVelocityScale = 0.1f;
            // 0x028BCB34: LDR x8, [x21]              | X8 = typeof(Pathfinding.RVO.Sampled.Agent);
            // 0x028BCB38: MOVZ w9, #0x41f0, lsl #16  | W9 = 1106247680 (0x41F00000);//ML01     
            // 0x028BCB3C: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.RVO.Sampled.Agent.__il2cppRuntimeField_static_fields;
            // 0x028BCB40: STR w9, [x8, #0x18]        | Pathfinding.RVO.Sampled.Agent.GlobalIncompressibility = 30;  //  dest_result_addr=1152921504840769560
            Pathfinding.RVO.Sampled.Agent.GlobalIncompressibility = 30f;
            // 0x028BCB44: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028BCB48: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028BCB4C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028BCB50: RET                        |  return;                                
            return;
        
        }
    
    }

}
