using UnityEngine;
internal class CoroutineAdapter.Adaptor : IEnumerator<object>, IEnumerator, IDisposable, CrossBindingAdaptorType
{
    // Fields
    private ILRuntime.Runtime.Intepreter.ILTypeInstance instance; //  0x00000010
    private ILRuntime.Runtime.Enviorment.AppDomain appdomain; //  0x00000018
    private ILRuntime.CLR.Method.IMethod mCurrentMethod; //  0x00000020
    private bool mCurrentMethodGot; //  0x00000028
    private ILRuntime.CLR.Method.IMethod mDisposeMethod; //  0x00000030
    private bool mDisposeMethodGot; //  0x00000038
    private ILRuntime.CLR.Method.IMethod mMoveNextMethod; //  0x00000040
    private bool mMoveNextMethodGot; //  0x00000048
    private ILRuntime.CLR.Method.IMethod mResetMethod; //  0x00000050
    private bool mResetMethodGot; //  0x00000058
    
    // Properties
    public ILRuntime.Runtime.Intepreter.ILTypeInstance ILInstance { get; }
    public object Current { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00E2FD10 (14875920), len: 8  VirtAddr: 0x00E2FD10 RVA: 0x00E2FD10 token: 100681001 methodIndex: 57326 delegateWrapperIndex: 0 methodInvoker: 0
    public CoroutineAdapter.Adaptor()
    {
        //
        // Disasemble & Code
        // 0x00E2FD10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E2FD14: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00E2FCD8 (14875864), len: 56  VirtAddr: 0x00E2FCD8 RVA: 0x00E2FCD8 token: 100681002 methodIndex: 57327 delegateWrapperIndex: 0 methodInvoker: 0
    public CoroutineAdapter.Adaptor(ILRuntime.Runtime.Enviorment.AppDomain appdomain, ILRuntime.Runtime.Intepreter.ILTypeInstance instance)
    {
        //
        // Disasemble & Code
        // 0x00E2FCD8: STP x22, x21, [sp, #-0x30]! | stack[1152921512998759056] = ???;  stack[1152921512998759064] = ???;  //  dest_result_addr=1152921512998759056 |  dest_result_addr=1152921512998759064
        // 0x00E2FCDC: STP x20, x19, [sp, #0x10]  | stack[1152921512998759072] = ???;  stack[1152921512998759080] = ???;  //  dest_result_addr=1152921512998759072 |  dest_result_addr=1152921512998759080
        // 0x00E2FCE0: STP x29, x30, [sp, #0x20]  | stack[1152921512998759088] = ???;  stack[1152921512998759096] = ???;  //  dest_result_addr=1152921512998759088 |  dest_result_addr=1152921512998759096
        // 0x00E2FCE4: ADD x29, sp, #0x20         | X29 = (1152921512998759056 + 32) = 1152921512998759088 (0x10000001F4326AB0);
        // 0x00E2FCE8: MOV x20, x1                | X20 = appdomain;//m1                    
        // 0x00E2FCEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E2FCF0: MOV x19, x2                | X19 = instance;//m1                     
        // 0x00E2FCF4: MOV x21, x0                | X21 = 1152921512998771104 (0x10000001F43299A0);//ML01
        // 0x00E2FCF8: BL #0x16f59f0              | instance..ctor();                       
        val_1 = new System.Object();
        // 0x00E2FCFC: STP x19, x20, [x21, #0x10] | this.instance = instance;  this.appdomain = appdomain;  //  dest_result_addr=1152921512998771120 |  dest_result_addr=1152921512998771128
        this.instance = val_1;
        this.appdomain = appdomain;
        // 0x00E2FD00: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E2FD04: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E2FD08: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E2FD0C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00E2FD18 (14875928), len: 8  VirtAddr: 0x00E2FD18 RVA: 0x00E2FD18 token: 100681003 methodIndex: 57328 delegateWrapperIndex: 0 methodInvoker: 0
    public ILRuntime.Runtime.Intepreter.ILTypeInstance get_ILInstance()
    {
        //
        // Disasemble & Code
        // 0x00E2FD18: LDR x0, [x0, #0x10]        | X0 = this.instance; //P2                
        // 0x00E2FD1C: RET                        |  return (ILRuntime.Runtime.Intepreter.ILTypeInstance)this.instance;
        return this.instance;
        //  |  // // {name=val_0, type=ILRuntime.Runtime.Intepreter.ILTypeInstance, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00E2FD20 (14875936), len: 308  VirtAddr: 0x00E2FD20 RVA: 0x00E2FD20 token: 100681004 methodIndex: 57329 delegateWrapperIndex: 0 methodInvoker: 0
    public object get_Current()
    {
        //
        // Disasemble & Code
        //  | 
        ILRuntime.CLR.Method.IMethod val_5;
        // 0x00E2FD20: STP x22, x21, [sp, #-0x30]! | stack[1152921512999036304] = ???;  stack[1152921512999036312] = ???;  //  dest_result_addr=1152921512999036304 |  dest_result_addr=1152921512999036312
        // 0x00E2FD24: STP x20, x19, [sp, #0x10]  | stack[1152921512999036320] = ???;  stack[1152921512999036328] = ???;  //  dest_result_addr=1152921512999036320 |  dest_result_addr=1152921512999036328
        // 0x00E2FD28: STP x29, x30, [sp, #0x20]  | stack[1152921512999036336] = ???;  stack[1152921512999036344] = ???;  //  dest_result_addr=1152921512999036336 |  dest_result_addr=1152921512999036344
        // 0x00E2FD2C: ADD x29, sp, #0x20         | X29 = (1152921512999036304 + 32) = 1152921512999036336 (0x10000001F436A5B0);
        // 0x00E2FD30: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00E2FD34: LDRB w8, [x20, #0x93f]     | W8 = (bool)static_value_0373493F;       
        // 0x00E2FD38: MOV x19, x0                | X19 = 1152921512999048352 (0x10000001F436D4A0);//ML01
        // 0x00E2FD3C: TBNZ w8, #0, #0xe2fd58     | if (static_value_0373493F == true) goto label_0;
        // 0x00E2FD40: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
        // 0x00E2FD44: LDR x8, [x8, #0x4a0]       | X8 = 0x2B8AA04;                         
        // 0x00E2FD48: LDR w0, [x8]               | W0 = 0x13F;                             
        // 0x00E2FD4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x13F, ????);      
        // 0x00E2FD50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00E2FD54: STRB w8, [x20, #0x93f]     | static_value_0373493F = true;            //  dest_result_addr=57887039
        label_0:
        // 0x00E2FD58: LDRB w8, [x19, #0x28]      | W8 = this.mCurrentMethodGot; //P2       
        // 0x00E2FD5C: CBZ w8, #0xe2fd68          | if (this.mCurrentMethodGot == false) goto label_1;
        if(this.mCurrentMethodGot == false)
        {
            goto label_1;
        }
        // 0x00E2FD60: LDR x20, [x19, #0x20]      | X20 = this.mCurrentMethod; //P2         
        val_5 = this.mCurrentMethod;
        // 0x00E2FD64: B #0xe2fe0c                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00E2FD68: LDR x20, [x19, #0x10]      | X20 = this.instance; //P2               
        // 0x00E2FD6C: CBNZ x20, #0xe2fd74        | if (this.instance != null) goto label_3;
        if(this.instance != null)
        {
            goto label_3;
        }
        // 0x00E2FD70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13F, ????);      
        label_3:
        // 0x00E2FD74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E2FD78: MOV x0, x20                | X0 = this.instance;//m1                 
        // 0x00E2FD7C: BL #0x1f95a54              | X0 = this.instance.get_Type();          
        ILRuntime.CLR.TypeSystem.ILType val_1 = this.instance.Type;
        // 0x00E2FD80: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00E2FD84: CBNZ x20, #0xe2fd8c        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00E2FD88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00E2FD8C: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00E2FD90: LDR x8, [x8, #0x320]       | X8 = (string**)(1152921510491971920)("get_Current");
        // 0x00E2FD94: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00E2FD98: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00E2FD9C: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00E2FDA0: LDR x1, [x8]               | X1 = "get_Current";                     
        // 0x00E2FDA4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E2FDA8: BL #0x10fb420              | X0 = val_1.GetMethod(name:  "get_Current", paramCount:  0, declaredOnly:  false);
        ILRuntime.CLR.Method.IMethod val_2 = val_1.GetMethod(name:  "get_Current", paramCount:  0, declaredOnly:  false);
        // 0x00E2FDAC: MOV x20, x0                | X20 = val_2;//m1                        
        val_5 = val_2;
        // 0x00E2FDB0: STR x20, [x19, #0x20]      | this.mCurrentMethod = val_2;             //  dest_result_addr=1152921512999048384
        this.mCurrentMethod = val_5;
        // 0x00E2FDB4: CBNZ x20, #0xe2fe04        | if (val_2 != null) goto label_5;        
        if(val_5 != null)
        {
            goto label_5;
        }
        // 0x00E2FDB8: LDR x20, [x19, #0x10]      | X20 = this.instance; //P2               
        // 0x00E2FDBC: CBNZ x20, #0xe2fdc4        | if (this.instance != null) goto label_6;
        if(this.instance != null)
        {
            goto label_6;
        }
        // 0x00E2FDC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00E2FDC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E2FDC8: MOV x0, x20                | X0 = this.instance;//m1                 
        // 0x00E2FDCC: BL #0x1f95a54              | X0 = this.instance.get_Type();          
        ILRuntime.CLR.TypeSystem.ILType val_3 = this.instance.Type;
        // 0x00E2FDD0: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00E2FDD4: CBNZ x20, #0xe2fddc        | if (val_3 != null) goto label_7;        
        if(val_3 != null)
        {
            goto label_7;
        }
        // 0x00E2FDD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00E2FDDC: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00E2FDE0: LDR x8, [x8, #0x798]       | X8 = (string**)(1152921512956886240)("System.Collections.IEnumerator.get_Current");
        // 0x00E2FDE4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00E2FDE8: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00E2FDEC: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00E2FDF0: LDR x1, [x8]               | X1 = "System.Collections.IEnumerator.get_Current";
        // 0x00E2FDF4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E2FDF8: BL #0x10fb420              | X0 = val_3.GetMethod(name:  "System.Collections.IEnumerator.get_Current", paramCount:  0, declaredOnly:  false);
        ILRuntime.CLR.Method.IMethod val_4 = val_3.GetMethod(name:  "System.Collections.IEnumerator.get_Current", paramCount:  0, declaredOnly:  false);
        // 0x00E2FDFC: MOV x20, x0                | X20 = val_4;//m1                        
        val_5 = val_4;
        // 0x00E2FE00: STR x20, [x19, #0x20]      | this.mCurrentMethod = val_4;             //  dest_result_addr=1152921512999048384
        this.mCurrentMethod = val_5;
        label_5:
        // 0x00E2FE04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00E2FE08: STRB w8, [x19, #0x28]      | this.mCurrentMethodGot = true;           //  dest_result_addr=1152921512999048392
        this.mCurrentMethodGot = true;
        label_2:
        // 0x00E2FE0C: CBZ x20, #0xe2fe40         | if (val_4 == null) goto label_8;        
        if(val_5 == null)
        {
            goto label_8;
        }
        // 0x00E2FE10: LDP x21, x19, [x19, #0x10] | X21 = this.instance; //P2  X19 = this.appdomain; //P2  //  | 
        // 0x00E2FE14: CBNZ x19, #0xe2fe1c        | if (this.appdomain != null) goto label_9;
        if(this.appdomain != null)
        {
            goto label_9;
        }
        // 0x00E2FE18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00E2FE1C: MOV x0, x19                | X0 = this.appdomain;//m1                
        // 0x00E2FE20: MOV x1, x20                | X1 = val_4;//m1                         
        // 0x00E2FE24: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E2FE28: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E2FE2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00E2FE30: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E2FE34: MOV x2, x21                | X2 = this.instance;//m1                 
        // 0x00E2FE38: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E2FE3C: B #0x28dd360               | return this.appdomain.Invoke(m:  val_5, instance:  this.instance, p:  0);
        return this.appdomain.Invoke(m:  val_5, instance:  this.instance, p:  0);
        label_8:
        // 0x00E2FE40: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E2FE44: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E2FE48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00E2FE4C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E2FE50: RET                        |  return (System.Object)null;            
        return (object)0;
        //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00E2FE54 (14876244), len: 304  VirtAddr: 0x00E2FE54 RVA: 0x00E2FE54 token: 100681005 methodIndex: 57330 delegateWrapperIndex: 0 methodInvoker: 0
    public void Dispose()
    {
        //
        // Disasemble & Code
        //  | 
        ILRuntime.CLR.Method.IMethod val_6;
        // 0x00E2FE54: STP x22, x21, [sp, #-0x30]! | stack[1152921512999226128] = ???;  stack[1152921512999226136] = ???;  //  dest_result_addr=1152921512999226128 |  dest_result_addr=1152921512999226136
        // 0x00E2FE58: STP x20, x19, [sp, #0x10]  | stack[1152921512999226144] = ???;  stack[1152921512999226152] = ???;  //  dest_result_addr=1152921512999226144 |  dest_result_addr=1152921512999226152
        // 0x00E2FE5C: STP x29, x30, [sp, #0x20]  | stack[1152921512999226160] = ???;  stack[1152921512999226168] = ???;  //  dest_result_addr=1152921512999226160 |  dest_result_addr=1152921512999226168
        // 0x00E2FE60: ADD x29, sp, #0x20         | X29 = (1152921512999226128 + 32) = 1152921512999226160 (0x10000001F4398B30);
        // 0x00E2FE64: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00E2FE68: LDRB w8, [x20, #0x940]     | W8 = (bool)static_value_03734940;       
        // 0x00E2FE6C: MOV x19, x0                | X19 = 1152921512999238176 (0x10000001F439BA20);//ML01
        // 0x00E2FE70: TBNZ w8, #0, #0xe2fe8c     | if (static_value_03734940 == true) goto label_0;
        // 0x00E2FE74: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x00E2FE78: LDR x8, [x8, #0x8c0]       | X8 = 0x2B8A9FC;                         
        // 0x00E2FE7C: LDR w0, [x8]               | W0 = 0x13D;                             
        // 0x00E2FE80: BL #0x2782188              | X0 = sub_2782188( ?? 0x13D, ????);      
        // 0x00E2FE84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00E2FE88: STRB w8, [x20, #0x940]     | static_value_03734940 = true;            //  dest_result_addr=57887040
        label_0:
        // 0x00E2FE8C: LDRB w8, [x19, #0x38]      | W8 = this.mDisposeMethodGot; //P2       
        // 0x00E2FE90: CBZ w8, #0xe2fe9c          | if (this.mDisposeMethodGot == false) goto label_1;
        if(this.mDisposeMethodGot == false)
        {
            goto label_1;
        }
        // 0x00E2FE94: LDR x20, [x19, #0x30]      | X20 = this.mDisposeMethod; //P2         
        val_6 = this.mDisposeMethod;
        // 0x00E2FE98: B #0xe2ff40                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00E2FE9C: LDR x20, [x19, #0x10]      | X20 = this.instance; //P2               
        // 0x00E2FEA0: CBNZ x20, #0xe2fea8        | if (this.instance != null) goto label_3;
        if(this.instance != null)
        {
            goto label_3;
        }
        // 0x00E2FEA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13D, ????);      
        label_3:
        // 0x00E2FEA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E2FEAC: MOV x0, x20                | X0 = this.instance;//m1                 
        // 0x00E2FEB0: BL #0x1f95a54              | X0 = this.instance.get_Type();          
        ILRuntime.CLR.TypeSystem.ILType val_1 = this.instance.Type;
        // 0x00E2FEB4: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00E2FEB8: CBNZ x20, #0xe2fec0        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00E2FEBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00E2FEC0: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00E2FEC4: LDR x8, [x8, #0x920]       | X8 = (string**)(1152921509556682112)("Dispose");
        // 0x00E2FEC8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00E2FECC: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00E2FED0: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00E2FED4: LDR x1, [x8]               | X1 = "Dispose";                         
        // 0x00E2FED8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E2FEDC: BL #0x10fb420              | X0 = val_1.GetMethod(name:  "Dispose", paramCount:  0, declaredOnly:  false);
        ILRuntime.CLR.Method.IMethod val_2 = val_1.GetMethod(name:  "Dispose", paramCount:  0, declaredOnly:  false);
        // 0x00E2FEE0: MOV x20, x0                | X20 = val_2;//m1                        
        val_6 = val_2;
        // 0x00E2FEE4: STR x20, [x19, #0x30]      | this.mDisposeMethod = val_2;             //  dest_result_addr=1152921512999238224
        this.mDisposeMethod = val_6;
        // 0x00E2FEE8: CBNZ x20, #0xe2ff38        | if (val_2 != null) goto label_5;        
        if(val_6 != null)
        {
            goto label_5;
        }
        // 0x00E2FEEC: LDR x20, [x19, #0x10]      | X20 = this.instance; //P2               
        // 0x00E2FEF0: CBNZ x20, #0xe2fef8        | if (this.instance != null) goto label_6;
        if(this.instance != null)
        {
            goto label_6;
        }
        // 0x00E2FEF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00E2FEF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E2FEFC: MOV x0, x20                | X0 = this.instance;//m1                 
        // 0x00E2FF00: BL #0x1f95a54              | X0 = this.instance.get_Type();          
        ILRuntime.CLR.TypeSystem.ILType val_3 = this.instance.Type;
        // 0x00E2FF04: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00E2FF08: CBNZ x20, #0xe2ff10        | if (val_3 != null) goto label_7;        
        if(val_3 != null)
        {
            goto label_7;
        }
        // 0x00E2FF0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00E2FF10: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
        // 0x00E2FF14: LDR x8, [x8, #0x1f8]       | X8 = (string**)(1152921512957072128)("System.IDisposable.Dispose");
        // 0x00E2FF18: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00E2FF1C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00E2FF20: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00E2FF24: LDR x1, [x8]               | X1 = "System.IDisposable.Dispose";      
        // 0x00E2FF28: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E2FF2C: BL #0x10fb420              | X0 = val_3.GetMethod(name:  "System.IDisposable.Dispose", paramCount:  0, declaredOnly:  false);
        ILRuntime.CLR.Method.IMethod val_4 = val_3.GetMethod(name:  "System.IDisposable.Dispose", paramCount:  0, declaredOnly:  false);
        // 0x00E2FF30: MOV x20, x0                | X20 = val_4;//m1                        
        val_6 = val_4;
        // 0x00E2FF34: STR x20, [x19, #0x30]      | this.mDisposeMethod = val_4;             //  dest_result_addr=1152921512999238224
        this.mDisposeMethod = val_6;
        label_5:
        // 0x00E2FF38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00E2FF3C: STRB w8, [x19, #0x38]      | this.mDisposeMethodGot = true;           //  dest_result_addr=1152921512999238232
        this.mDisposeMethodGot = true;
        label_2:
        // 0x00E2FF40: CBZ x20, #0xe2ff74         | if (val_4 == null) goto label_8;        
        if(val_6 == null)
        {
            goto label_8;
        }
        // 0x00E2FF44: LDP x21, x19, [x19, #0x10] | X21 = this.instance; //P2  X19 = this.appdomain; //P2  //  | 
        // 0x00E2FF48: CBNZ x19, #0xe2ff50        | if (this.appdomain != null) goto label_9;
        if(this.appdomain != null)
        {
            goto label_9;
        }
        // 0x00E2FF4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00E2FF50: MOV x0, x19                | X0 = this.appdomain;//m1                
        // 0x00E2FF54: MOV x1, x20                | X1 = val_4;//m1                         
        // 0x00E2FF58: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E2FF5C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E2FF60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00E2FF64: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E2FF68: MOV x2, x21                | X2 = this.instance;//m1                 
        // 0x00E2FF6C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E2FF70: B #0x28dd360               | X0 = this.appdomain.Invoke(m:  val_6, instance:  this.instance, p:  0); return;
        object val_5 = this.appdomain.Invoke(m:  val_6, instance:  this.instance, p:  0);
        return;
        label_8:
        // 0x00E2FF74: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E2FF78: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E2FF7C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E2FF80: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00E2FF84 (14876548), len: 348  VirtAddr: 0x00E2FF84 RVA: 0x00E2FF84 token: 100681006 methodIndex: 57331 delegateWrapperIndex: 0 methodInvoker: 0
    public bool MoveNext()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        ILRuntime.CLR.Method.IMethod val_7;
        //  | 
        var val_8;
        // 0x00E2FF84: STP x22, x21, [sp, #-0x30]! | stack[1152921512999407760] = ???;  stack[1152921512999407768] = ???;  //  dest_result_addr=1152921512999407760 |  dest_result_addr=1152921512999407768
        // 0x00E2FF88: STP x20, x19, [sp, #0x10]  | stack[1152921512999407776] = ???;  stack[1152921512999407784] = ???;  //  dest_result_addr=1152921512999407776 |  dest_result_addr=1152921512999407784
        // 0x00E2FF8C: STP x29, x30, [sp, #0x20]  | stack[1152921512999407792] = ???;  stack[1152921512999407800] = ???;  //  dest_result_addr=1152921512999407792 |  dest_result_addr=1152921512999407800
        // 0x00E2FF90: ADD x29, sp, #0x20         | X29 = (1152921512999407760 + 32) = 1152921512999407792 (0x10000001F43C50B0);
        // 0x00E2FF94: SUB sp, sp, #0x10          | SP = (1152921512999407760 - 16) = 1152921512999407744 (0x10000001F43C5080);
        // 0x00E2FF98: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00E2FF9C: LDRB w8, [x20, #0x941]     | W8 = (bool)static_value_03734941;       
        // 0x00E2FFA0: MOV x19, x0                | X19 = 1152921512999419808 (0x10000001F43C7FA0);//ML01
        val_6 = this;
        // 0x00E2FFA4: TBNZ w8, #0, #0xe2ffc0     | if (static_value_03734941 == true) goto label_0;
        // 0x00E2FFA8: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
        // 0x00E2FFAC: LDR x8, [x8, #0x190]       | X8 = 0x2B8AA10;                         
        // 0x00E2FFB0: LDR w0, [x8]               | W0 = 0x142;                             
        // 0x00E2FFB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x142, ????);      
        // 0x00E2FFB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00E2FFBC: STRB w8, [x20, #0x941]     | static_value_03734941 = true;            //  dest_result_addr=57887041
        label_0:
        // 0x00E2FFC0: LDRB w8, [x19, #0x48]      | W8 = this.mMoveNextMethodGot; //P2      
        // 0x00E2FFC4: CBZ w8, #0xe2ffd0          | if (this.mMoveNextMethodGot == false) goto label_1;
        if(this.mMoveNextMethodGot == false)
        {
            goto label_1;
        }
        // 0x00E2FFC8: LDR x20, [x19, #0x40]      | X20 = this.mMoveNextMethod; //P2        
        val_7 = this.mMoveNextMethod;
        // 0x00E2FFCC: B #0xe30024                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00E2FFD0: LDR x20, [x19, #0x10]      | X20 = this.instance; //P2               
        // 0x00E2FFD4: CBNZ x20, #0xe2ffdc        | if (this.instance != null) goto label_3;
        if(this.instance != null)
        {
            goto label_3;
        }
        // 0x00E2FFD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x142, ????);      
        label_3:
        // 0x00E2FFDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E2FFE0: MOV x0, x20                | X0 = this.instance;//m1                 
        // 0x00E2FFE4: BL #0x1f95a54              | X0 = this.instance.get_Type();          
        ILRuntime.CLR.TypeSystem.ILType val_1 = this.instance.Type;
        // 0x00E2FFE8: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00E2FFEC: CBNZ x20, #0xe2fff4        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00E2FFF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00E2FFF4: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00E2FFF8: LDR x8, [x8, #0x688]       | X8 = (string**)(1152921510491977136)("MoveNext");
        // 0x00E2FFFC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00E30000: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00E30004: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00E30008: LDR x1, [x8]               | X1 = "MoveNext";                        
        // 0x00E3000C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E30010: BL #0x10fb420              | X0 = val_1.GetMethod(name:  "MoveNext", paramCount:  0, declaredOnly:  false);
        ILRuntime.CLR.Method.IMethod val_2 = val_1.GetMethod(name:  "MoveNext", paramCount:  0, declaredOnly:  false);
        // 0x00E30014: MOV x20, x0                | X20 = val_2;//m1                        
        val_7 = val_2;
        // 0x00E30018: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00E3001C: STR x20, [x19, #0x40]      | this.mMoveNextMethod = val_2;            //  dest_result_addr=1152921512999419872
        this.mMoveNextMethod = val_7;
        // 0x00E30020: STRB w8, [x19, #0x48]      | this.mMoveNextMethodGot = true;          //  dest_result_addr=1152921512999419880
        this.mMoveNextMethodGot = true;
        label_2:
        // 0x00E30024: CBZ x20, #0xe30090         | if (val_2 == null) goto label_5;        
        if(val_7 == null)
        {
            goto label_5;
        }
        // 0x00E30028: LDP x21, x19, [x19, #0x10] | X21 = this.instance; //P2  X19 = this.appdomain; //P2  //  | 
        // 0x00E3002C: CBNZ x19, #0xe30034        | if (this.appdomain != null) goto label_6;
        if(this.appdomain != null)
        {
            goto label_6;
        }
        // 0x00E30030: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00E30034: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00E30038: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E3003C: MOV x0, x19                | X0 = this.appdomain;//m1                
        // 0x00E30040: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00E30044: MOV x2, x21                | X2 = this.instance;//m1                 
        // 0x00E30048: BL #0x28dd360              | X0 = this.appdomain.Invoke(m:  val_7, instance:  this.instance, p:  0);
        object val_3 = this.appdomain.Invoke(m:  val_7, instance:  this.instance, p:  0);
        // 0x00E3004C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00E30050: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
        // 0x00E30054: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00E30058: LDR x19, [x8]              | X19 = typeof(System.Boolean);           
        val_6 = null;
        // 0x00E3005C: CBNZ x20, #0xe30064        | if (val_3 != null) goto label_7;        
        if(val_3 != null)
        {
            goto label_7;
        }
        // 0x00E30060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00E30064: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00E30068: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00E3006C: LDR x8, [x19, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
        // 0x00E30070: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Boolean.__il2cppRuntimeField_element_class)
        // 0x00E30074: B.NE #0xe300a8             | if (System.Object.__il2cppRuntimeField_element_class != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
        // 0x00E30078: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00E3007C: BL #0x27bc4e8              | val_3.System.IDisposable.Dispose();     
        val_3.System.IDisposable.Dispose();
        // 0x00E30080: LDRB w8, [x0]              | W8 = typeof(System.Object);             
        // 0x00E30084: CMP w8, #0                 | STATE = COMPARE(typeof(System.Object), 0x0)
        // 0x00E30088: CSET w0, ne                | W0 = typeof(System.Object) != null ? 1 : 0;
        var val_4 = (null != 0) ? 1 : 0;
        // 0x00E3008C: B #0xe30094                |  goto label_9;                          
        goto label_9;
        label_5:
        // 0x00E30090: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_8 = 0;
        label_9:
        // 0x00E30094: SUB sp, x29, #0x20         | SP = (1152921512999407792 - 32) = 1152921512999407760 (0x10000001F43C5090);
        // 0x00E30098: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E3009C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E300A0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E300A4: RET                        |  return (System.Boolean)false;          
        return (bool)val_8;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        label_8:
        // 0x00E300A8: ADD x8, sp, #8             | X8 = (1152921512999407744 + 8) = 1152921512999407752 (0x10000001F43C5088);
        // 0x00E300AC: MOV x1, x19                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
        // 0x00E300B0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00E300B4: LDR x0, [sp, #8]           | X0 = val_5;                              //  find_add[1152921512999395808]
        // 0x00E300B8: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
        // 0x00E300BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E300C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        // 0x00E300C4: ADD x0, sp, #8             | X0 = (1152921512999407744 + 8) = 1152921512999407752 (0x10000001F43C5088);
        // 0x00E300C8: BL #0x299a140              | 
        // 0x00E300CC: MOV x19, x0                | X19 = 1152921512999407752 (0x10000001F43C5088);//ML01
        // 0x00E300D0: ADD x0, sp, #8             | X0 = (1152921512999407744 + 8) = 1152921512999407752 (0x10000001F43C5088);
        // 0x00E300D4: BL #0x299a140              | 
        // 0x00E300D8: MOV x0, x19                | X0 = 1152921512999407752 (0x10000001F43C5088);//ML01
        // 0x00E300DC: BL #0x980800               | X0 = sub_980800( ?? 0x10000001F43C5088, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00E300E0 (14876896), len: 224  VirtAddr: 0x00E300E0 RVA: 0x00E300E0 token: 100681007 methodIndex: 57332 delegateWrapperIndex: 0 methodInvoker: 0
    public void Reset()
    {
        //
        // Disasemble & Code
        //  | 
        ILRuntime.CLR.Method.IMethod val_4;
        // 0x00E300E0: STP x22, x21, [sp, #-0x30]! | stack[1152921512999577104] = ???;  stack[1152921512999577112] = ???;  //  dest_result_addr=1152921512999577104 |  dest_result_addr=1152921512999577112
        // 0x00E300E4: STP x20, x19, [sp, #0x10]  | stack[1152921512999577120] = ???;  stack[1152921512999577128] = ???;  //  dest_result_addr=1152921512999577120 |  dest_result_addr=1152921512999577128
        // 0x00E300E8: STP x29, x30, [sp, #0x20]  | stack[1152921512999577136] = ???;  stack[1152921512999577144] = ???;  //  dest_result_addr=1152921512999577136 |  dest_result_addr=1152921512999577144
        // 0x00E300EC: ADD x29, sp, #0x20         | X29 = (1152921512999577104 + 32) = 1152921512999577136 (0x10000001F43EE630);
        // 0x00E300F0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00E300F4: LDRB w8, [x20, #0x942]     | W8 = (bool)static_value_03734942;       
        // 0x00E300F8: MOV x19, x0                | X19 = 1152921512999589152 (0x10000001F43F1520);//ML01
        // 0x00E300FC: TBNZ w8, #0, #0xe30118     | if (static_value_03734942 == true) goto label_0;
        // 0x00E30100: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00E30104: LDR x8, [x8, #0x1d0]       | X8 = 0x2B8AA14;                         
        // 0x00E30108: LDR w0, [x8]               | W0 = 0x143;                             
        // 0x00E3010C: BL #0x2782188              | X0 = sub_2782188( ?? 0x143, ????);      
        // 0x00E30110: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00E30114: STRB w8, [x20, #0x942]     | static_value_03734942 = true;            //  dest_result_addr=57887042
        label_0:
        // 0x00E30118: LDRB w8, [x19, #0x58]      | W8 = this.mResetMethodGot; //P2         
        // 0x00E3011C: CBZ w8, #0xe30128          | if (this.mResetMethodGot == false) goto label_1;
        if(this.mResetMethodGot == false)
        {
            goto label_1;
        }
        // 0x00E30120: LDR x20, [x19, #0x50]      | X20 = this.mResetMethod; //P2           
        val_4 = this.mResetMethod;
        // 0x00E30124: B #0xe3017c                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00E30128: LDR x20, [x19, #0x10]      | X20 = this.instance; //P2               
        // 0x00E3012C: CBNZ x20, #0xe30134        | if (this.instance != null) goto label_3;
        if(this.instance != null)
        {
            goto label_3;
        }
        // 0x00E30130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x143, ????);      
        label_3:
        // 0x00E30134: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E30138: MOV x0, x20                | X0 = this.instance;//m1                 
        // 0x00E3013C: BL #0x1f95a54              | X0 = this.instance.get_Type();          
        ILRuntime.CLR.TypeSystem.ILType val_1 = this.instance.Type;
        // 0x00E30140: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00E30144: CBNZ x20, #0xe3014c        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00E30148: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00E3014C: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00E30150: LDR x8, [x8, #0x620]       | X8 = (string**)(1152921510029987872)("Reset");
        // 0x00E30154: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00E30158: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00E3015C: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00E30160: LDR x1, [x8]               | X1 = "Reset";                           
        // 0x00E30164: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E30168: BL #0x10fb420              | X0 = val_1.GetMethod(name:  "Reset", paramCount:  0, declaredOnly:  false);
        ILRuntime.CLR.Method.IMethod val_2 = val_1.GetMethod(name:  "Reset", paramCount:  0, declaredOnly:  false);
        // 0x00E3016C: MOV x20, x0                | X20 = val_2;//m1                        
        val_4 = val_2;
        // 0x00E30170: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00E30174: STR x20, [x19, #0x50]      | this.mResetMethod = val_2;               //  dest_result_addr=1152921512999589232
        this.mResetMethod = val_4;
        // 0x00E30178: STRB w8, [x19, #0x58]      | this.mResetMethodGot = true;             //  dest_result_addr=1152921512999589240
        this.mResetMethodGot = true;
        label_2:
        // 0x00E3017C: CBZ x20, #0xe301b0         | if (val_2 == null) goto label_5;        
        if(val_4 == null)
        {
            goto label_5;
        }
        // 0x00E30180: LDP x21, x19, [x19, #0x10] | X21 = this.instance; //P2  X19 = this.appdomain; //P2  //  | 
        // 0x00E30184: CBNZ x19, #0xe3018c        | if (this.appdomain != null) goto label_6;
        if(this.appdomain != null)
        {
            goto label_6;
        }
        // 0x00E30188: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00E3018C: MOV x0, x19                | X0 = this.appdomain;//m1                
        // 0x00E30190: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00E30194: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E30198: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E3019C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00E301A0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00E301A4: MOV x2, x21                | X2 = this.instance;//m1                 
        // 0x00E301A8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E301AC: B #0x28dd360               | X0 = this.appdomain.Invoke(m:  val_4, instance:  this.instance, p:  0); return;
        object val_3 = this.appdomain.Invoke(m:  val_4, instance:  this.instance, p:  0);
        return;
        label_5:
        // 0x00E301B0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E301B4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E301B8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E301BC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00E301C0 (14877120), len: 436  VirtAddr: 0x00E301C0 RVA: 0x00E301C0 token: 100681008 methodIndex: 57333 delegateWrapperIndex: 0 methodInvoker: 0
    public override string ToString()
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        // 0x00E301C0: STP x22, x21, [sp, #-0x30]! | stack[1152921512999750544] = ???;  stack[1152921512999750552] = ???;  //  dest_result_addr=1152921512999750544 |  dest_result_addr=1152921512999750552
        // 0x00E301C4: STP x20, x19, [sp, #0x10]  | stack[1152921512999750560] = ???;  stack[1152921512999750568] = ???;  //  dest_result_addr=1152921512999750560 |  dest_result_addr=1152921512999750568
        // 0x00E301C8: STP x29, x30, [sp, #0x20]  | stack[1152921512999750576] = ???;  stack[1152921512999750584] = ???;  //  dest_result_addr=1152921512999750576 |  dest_result_addr=1152921512999750584
        // 0x00E301CC: ADD x29, sp, #0x20         | X29 = (1152921512999750544 + 32) = 1152921512999750576 (0x10000001F4418BB0);
        // 0x00E301D0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00E301D4: LDRB w8, [x20, #0x943]     | W8 = (bool)static_value_03734943;       
        // 0x00E301D8: MOV x19, x0                | X19 = 1152921512999762592 (0x10000001F441BAA0);//ML01
        // 0x00E301DC: TBNZ w8, #0, #0xe301f8     | if (static_value_03734943 == true) goto label_0;
        // 0x00E301E0: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00E301E4: LDR x8, [x8, #0x5f0]       | X8 = 0x2B8AA28;                         
        // 0x00E301E8: LDR w0, [x8]               | W0 = 0x148;                             
        // 0x00E301EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x148, ????);      
        // 0x00E301F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00E301F4: STRB w8, [x20, #0x943]     | static_value_03734943 = true;            //  dest_result_addr=57887043
        label_0:
        // 0x00E301F8: LDR x20, [x19, #0x18]      | X20 = this.appdomain; //P2              
        // 0x00E301FC: CBNZ x20, #0xe30204        | if (this.appdomain != null) goto label_1;
        if(this.appdomain != null)
        {
            goto label_1;
        }
        // 0x00E30200: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x148, ????);      
        label_1:
        // 0x00E30204: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E30208: MOV x0, x20                | X0 = this.appdomain;//m1                
        // 0x00E3020C: BL #0x28e42d4              | X0 = this.appdomain.get_ObjectType();   
        ILRuntime.CLR.TypeSystem.IType val_1 = this.appdomain.ObjectType;
        // 0x00E30210: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00E30214: CBNZ x20, #0xe3021c        | if (val_1 != null) goto label_2;        
        if(val_1 != null)
        {
            goto label_2;
        }
        // 0x00E30218: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00E3021C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00E30220: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
        // 0x00E30224: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
        // 0x00E30228: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
        // 0x00E3022C: ADRP x9, #0x3613000        | X9 = 56700928 (0x3613000);              
        // 0x00E30230: LDR x9, [x9, #0xcb0]       | X9 = (string**)(1152921510008585248)("ToString");
        // 0x00E30234: LDR x21, [x9]              | X21 = "ToString";                       
        // 0x00E30238: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
        // 0x00E3023C: CBZ x9, #0xe30268          | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_3;
        // 0x00E30240: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
        // 0x00E30244: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_6 = 0;
        // 0x00E30248: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
        label_5:
        // 0x00E3024C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00E30250: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
        // 0x00E30254: B.EQ #0xe30278             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_4;
        // 0x00E30258: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_6 = val_6 + 1;
        // 0x00E3025C: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
        // 0x00E30260: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
        // 0x00E30264: B.LO #0xe3024c             | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_5;
        label_3:
        // 0x00E30268: MOVZ w2, #0x16             | W2 = 22 (0x16);//ML01                   
        // 0x00E3026C: MOV x0, x20                | X0 = val_1;//m1                         
        val_6 = val_1;
        // 0x00E30270: BL #0x2776c24              | X0 = sub_2776C24( ?? val_1, ????);      
        // 0x00E30274: B #0xe30288                |  goto label_6;                          
        goto label_6;
        label_4:
        // 0x00E30278: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00E3027C: ADD w9, w9, #0x16          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 22);
        // 0x00E30280: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 22));
        // 0x00E30284: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 22)).272
        label_6:
        // 0x00E30288: LDP x8, x4, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
        // 0x00E3028C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00E30290: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00E30294: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00E30298: MOV x1, x21                | X1 = 1152921510008585248 (0x1000000141F7FC20);//ML01
        // 0x00E3029C: BLR x8                     | X0 = sub_100000000A746000( ?? val_1, ????);
        // 0x00E302A0: LDR x21, [x19, #0x10]      | X21 = this.instance; //P2               
        // 0x00E302A4: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00E302A8: CBNZ x21, #0xe302b0        | if (this.instance != null) goto label_7;
        if(this.instance != null)
        {
            goto label_7;
        }
        // 0x00E302AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_7:
        // 0x00E302B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E302B4: MOV x0, x21                | X0 = this.instance;//m1                 
        // 0x00E302B8: BL #0x1f95a54              | X0 = this.instance.get_Type();          
        ILRuntime.CLR.TypeSystem.ILType val_3 = this.instance.Type;
        // 0x00E302BC: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00E302C0: CBNZ x21, #0xe302c8        | if (val_3 != null) goto label_8;        
        if(val_3 != null)
        {
            goto label_8;
        }
        // 0x00E302C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00E302C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00E302CC: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00E302D0: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00E302D4: BL #0x10f7870              | X0 = val_3.GetVirtualMethod(method:  val_1);
        ILRuntime.CLR.Method.IMethod val_4 = val_3.GetVirtualMethod(method:  val_1);
        // 0x00E302D8: CBZ x0, #0xe3034c          | if (val_4 == null) goto label_11;       
        if(val_4 == null)
        {
            goto label_11;
        }
        // 0x00E302DC: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x00E302E0: LDR x8, [x8, #0x7b8]       | X8 = 1152921504781926400;               
        // 0x00E302E4: LDR x9, [x0]               | X9 = typeof(ILRuntime.CLR.Method.IMethod);
        // 0x00E302E8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Method.ILMethod);
        // 0x00E302EC: LDRB w11, [x9, #0x104]     | W11 = ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x00E302F0: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.Method.ILMethod.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x00E302F4: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.Method.ILMethod.__il2cppRuntimeField_typeHierarchyDepth)
        // 0x00E302F8: B.LO #0xe30310             | if (ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.Method.ILMethod.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
        // 0x00E302FC: LDR x9, [x9, #0xb0]        | X9 = ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_typeHierarchy;
        // 0x00E30300: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.Method.ILMeth
        // 0x00E30304: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.Method.ILMethod.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
        // 0x00E30308: CMP x9, x8                 | STATE = COMPARE((ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.Method.ILMethod.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.Method.ILMethod))
        // 0x00E3030C: B.EQ #0xe3034c             | if ((ILRuntime.CLR.Method.IMethod.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.Method.ILMethod.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
        label_10:
        // 0x00E30310: LDR x19, [x19, #0x10]      | X19 = this.instance; //P2               
        // 0x00E30314: CBNZ x19, #0xe3031c        | if (this.instance != null) goto label_12;
        if(this.instance != null)
        {
            goto label_12;
        }
        // 0x00E30318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_12:
        // 0x00E3031C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E30320: MOV x0, x19                | X0 = this.instance;//m1                 
        // 0x00E30324: BL #0x1f95a54              | X0 = this.instance.get_Type();          
        ILRuntime.CLR.TypeSystem.ILType val_5 = this.instance.Type;
        // 0x00E30328: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00E3032C: CBNZ x19, #0xe30334        | if (val_5 != null) goto label_13;       
        if(val_5 != null)
        {
            goto label_13;
        }
        // 0x00E30330: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_13:
        // 0x00E30334: MOV x0, x19                | X0 = val_5;//m1                         
        // 0x00E30338: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E3033C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E30340: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00E30344: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E30348: B #0x10f2674               | return val_5.get_FullName();            
        return val_5.FullName;
        label_11:
        // 0x00E3034C: LDR x19, [x19, #0x10]      | X19 = this.instance; //P2               
        // 0x00E30350: CBNZ x19, #0xe30358        | if (this.instance != null) goto label_14;
        if(this.instance != null)
        {
            goto label_14;
        }
        // 0x00E30354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_14:
        // 0x00E30358: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
        // 0x00E3035C: MOV x0, x19                | X0 = this.instance;//m1                 
        // 0x00E30360: LDP x2, x1, [x8, #0x140]   | X2 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance).__il2cppRuntimeField_140; X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance).__il2cppRuntimeField_148; //  | 
        // 0x00E30364: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00E30368: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00E3036C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00E30370: BR x2                      | goto typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance).__il2cppRuntimeField_140;
        goto typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance).__il2cppRuntimeField_140;
    
    }

}
