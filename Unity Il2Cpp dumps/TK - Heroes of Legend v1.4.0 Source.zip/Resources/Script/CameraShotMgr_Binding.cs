using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CameraShotMgr_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache12; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache13; // static_offset: 0x00000098
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache14; // static_offset: 0x000000A0
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01434394 (21185428), len: 8  VirtAddr: 0x01434394 RVA: 0x01434394 token: 100664166 methodIndex: 30213 delegateWrapperIndex: 0 methodInvoker: 0
        public CameraShotMgr_Binding()
        {
            //
            // Disasemble & Code
            // 0x01434394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434398: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0143439C (21185436), len: 4660  VirtAddr: 0x0143439C RVA: 0x0143439C token: 100664167 methodIndex: 30214 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_42;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_43;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_45;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_46;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_47;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_48;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_49;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_50;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_51;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_52;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_53;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_54;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_55;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_56;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_57;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_58;
            // 0x0143439C: STP x28, x27, [sp, #-0x60]! | stack[1152921510113336960] = ???;  stack[1152921510113336968] = ???;  //  dest_result_addr=1152921510113336960 |  dest_result_addr=1152921510113336968
            // 0x014343A0: STP x26, x25, [sp, #0x10]  | stack[1152921510113336976] = ???;  stack[1152921510113336984] = ???;  //  dest_result_addr=1152921510113336976 |  dest_result_addr=1152921510113336984
            // 0x014343A4: STP x24, x23, [sp, #0x20]  | stack[1152921510113336992] = ???;  stack[1152921510113337000] = ???;  //  dest_result_addr=1152921510113336992 |  dest_result_addr=1152921510113337000
            // 0x014343A8: STP x22, x21, [sp, #0x30]  | stack[1152921510113337008] = ???;  stack[1152921510113337016] = ???;  //  dest_result_addr=1152921510113337008 |  dest_result_addr=1152921510113337016
            // 0x014343AC: STP x20, x19, [sp, #0x40]  | stack[1152921510113337024] = ???;  stack[1152921510113337032] = ???;  //  dest_result_addr=1152921510113337024 |  dest_result_addr=1152921510113337032
            // 0x014343B0: STP x29, x30, [sp, #0x50]  | stack[1152921510113337040] = ???;  stack[1152921510113337048] = ???;  //  dest_result_addr=1152921510113337040 |  dest_result_addr=1152921510113337048
            // 0x014343B4: ADD x29, sp, #0x50         | X29 = (1152921510113336960 + 80) = 1152921510113337040 (0x1000000148365ED0);
            // 0x014343B8: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014343BC: LDRB w8, [x20, #0x45]      | W8 = (bool)static_value_03737045;       
            // 0x014343C0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014343C4: TBNZ w8, #0, #0x14343e0    | if (static_value_03737045 == true) goto label_0;
            // 0x014343C8: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x014343CC: LDR x8, [x8, #0x890]       | X8 = 0x2B902E8;                         
            // 0x014343D0: LDR w0, [x8]               | W0 = 0x177E;                            
            // 0x014343D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x177E, ????);     
            // 0x014343D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014343DC: STRB w8, [x20, #0x45]      | static_value_03737045 = true;            //  dest_result_addr=57897029
            label_0:
            // 0x014343E0: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x014343E4: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x014343E8: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x014343EC: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x014343F0: LDR x8, [x8, #0xa78]       | X8 = 1152921504909828096;               
            // 0x014343F4: LDR x20, [x8]              | X20 = typeof(CameraShotMgr);            
            // 0x014343F8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x014343FC: TBZ w8, #0, #0x143440c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01434400: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01434404: CBNZ w8, #0x143440c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01434408: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0143440C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01434410: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01434414: MOV x1, x20                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x01434418: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143441C: ADRP x25, #0x35ef000       | X25 = 56553472 (0x35EF000);             
            // 0x01434420: LDR x25, [x25, #0xff0]     | X25 = 1152921504987155056;              
            // 0x01434424: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01434428: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x0143442C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434430: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434434: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x01434438: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143443C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434440: ADRP x28, #0x3611000       | X28 = 56692736 (0x3611000);             
            // 0x01434444: LDR x28, [x28, #0x9a8]     | X28 = 1152921504607113216;              
            // 0x01434448: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143444C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01434450: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01434454: LDR x1, [x28]              | X1 = typeof(System.Int32);              
            // 0x01434458: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143445C: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x01434460: CBNZ x21, #0x1434468       | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x01434464: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x01434468: CBZ x22, #0x143448c        | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x0143446C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01434470: MOV x0, x22                | X0 = val_2;//m1                         
            // 0x01434474: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01434478: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x0143447C: CBNZ x0, #0x143448c        | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x01434480: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x01434484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434488: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_5:
            // 0x0143448C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01434490: CBNZ w8, #0x14344a0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x01434494: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x01434498: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143449C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x014344A0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;
            // 0x014344A4: LDR x1, [x28]              | X1 = typeof(System.Int32);              
            // 0x014344A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014344AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014344B0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014344B4: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x014344B8: CBZ x22, #0x14344dc        | if (val_3 == null) goto label_8;        
            if(val_3 == null)
            {
                goto label_8;
            }
            // 0x014344BC: LDR x8, [x21]              | X8 = ;                                  
            // 0x014344C0: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x014344C4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014344C8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x014344CC: CBNZ x0, #0x14344dc        | if (val_3 != null) goto label_8;        
            if(val_3 != null)
            {
                goto label_8;
            }
            // 0x014344D0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
            // 0x014344D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014344D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_8:
            // 0x014344DC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014344E0: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x014344E4: B.HI #0x14344f4            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_9;
            // 0x014344E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x014344EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014344F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_9:
            // 0x014344F4: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_3;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_3;
            // 0x014344F8: CBNZ x20, #0x1434500       | if (val_1 != null) goto label_10;       
            if(val_1 != null)
            {
                goto label_10;
            }
            // 0x014344FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x01434500: ADRP x27, #0x3637000       | X27 = 56848384 (0x3637000);             
            // 0x01434504: LDR x27, [x27, #0x428]     | X27 = (string**)(1152921510113232416)("PreviewCameraShot");
            // 0x01434508: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143450C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01434510: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01434514: LDR x1, [x27]              | X1 = "PreviewCameraShot";               
            // 0x01434518: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143451C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434520: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01434524: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "PreviewCameraShot", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_4 = val_1.GetMethod(name:  "PreviewCameraShot", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01434528: ADRP x24, #0x3654000       | X24 = 56967168 (0x3654000);             
            // 0x0143452C: LDR x24, [x24, #0x790]     | X24 = 1152921504783683584;              
            // 0x01434530: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x01434534: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434538: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143453C: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache0;
            // 0x01434540: CBNZ x22, #0x143458c       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache0 != null) goto label_11;
            if((ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache0) != null)
            {
                goto label_11;
            }
            // 0x01434544: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x01434548: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0143454C: LDR x8, [x8, #0xe08]       | X8 = 1152921510113236624;               
            // 0x01434550: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01434554: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01434558: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_5 = null;
            // 0x0143455C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01434560: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434564: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434568: MOV x2, x22                | X2 = 1152921510113236624 (0x100000014834D690);//ML01
            // 0x0143456C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_5;
            // 0x01434570: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434574: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434578: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143457C: STR x23, [x8]              | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687680
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache0 = val_42;
            // 0x01434580: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434584: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434588: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_11:
            // 0x0143458C: CBNZ x19, #0x1434594       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01434590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_12:
            // 0x01434594: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434598: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143459C: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x014345A0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x014345A4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_4, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache0);
            X1.RegisterCLRMethodRedirection(mi:  val_4, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache0);
            // 0x014345A8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x014345AC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014345B0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x014345B4: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x014345B8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014345BC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x014345C0: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x014345C4: LDR x22, [x28]             | X22 = typeof(System.Int32);             
            // 0x014345C8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014345CC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x014345D0: TBZ w9, #0, #0x14345e4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x014345D4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x014345D8: CBNZ w9, #0x14345e4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x014345DC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x014345E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_14:
            // 0x014345E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014345E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014345EC: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x014345F0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014345F4: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x014345F8: CBNZ x21, #0x1434600       | if ( != null) goto label_15;            
            if(null != null)
            {
                goto label_15;
            }
            // 0x014345FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_15:
            // 0x01434600: CBZ x22, #0x1434624        | if (val_6 == null) goto label_17;       
            if(val_6 == null)
            {
                goto label_17;
            }
            // 0x01434604: LDR x8, [x21]              | X8 = ;                                  
            // 0x01434608: MOV x0, x22                | X0 = val_6;//m1                         
            // 0x0143460C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01434610: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x01434614: CBNZ x0, #0x1434624        | if (val_6 != null) goto label_17;       
            if(val_6 != null)
            {
                goto label_17;
            }
            // 0x01434618: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
            // 0x0143461C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434620: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_17:
            // 0x01434624: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01434628: CBNZ w8, #0x1434638        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_18;
            // 0x0143462C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x01434630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434634: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_18:
            // 0x01434638: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;
            // 0x0143463C: LDR x1, [x28]              | X1 = typeof(System.Int32);              
            // 0x01434640: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01434644: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01434648: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143464C: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x01434650: CBZ x22, #0x1434674        | if (val_7 == null) goto label_20;       
            if(val_7 == null)
            {
                goto label_20;
            }
            // 0x01434654: LDR x8, [x21]              | X8 = ;                                  
            // 0x01434658: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x0143465C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01434660: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x01434664: CBNZ x0, #0x1434674        | if (val_7 != null) goto label_20;       
            if(val_7 != null)
            {
                goto label_20;
            }
            // 0x01434668: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
            // 0x0143466C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434670: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_20:
            // 0x01434674: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01434678: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0143467C: B.HI #0x143468c            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_21;
            // 0x01434680: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x01434684: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434688: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_21:
            // 0x0143468C: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_7;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_7;
            // 0x01434690: CBNZ x20, #0x1434698       | if (val_1 != null) goto label_22;       
            if(val_1 != null)
            {
                goto label_22;
            }
            // 0x01434694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_22:
            // 0x01434698: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x0143469C: LDR x8, [x8, #0x4c8]       | X8 = (string**)(1152921510113245840)("isCameraShotSkillFit");
            // 0x014346A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014346A4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x014346A8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014346AC: LDR x1, [x8]               | X1 = "isCameraShotSkillFit";            
            // 0x014346B0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014346B4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014346B8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x014346BC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "isCameraShotSkillFit", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_8 = val_1.GetMethod(name:  "isCameraShotSkillFit", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x014346C0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014346C4: MOV x21, x0                | X21 = val_8;//m1                        
            // 0x014346C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014346CC: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache1;
            // 0x014346D0: CBNZ x22, #0x143471c       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache1 != null) goto label_23;
            if((ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache1) != null)
            {
                goto label_23;
            }
            // 0x014346D4: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x014346D8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x014346DC: LDR x8, [x8, #0x690]       | X8 = 1152921510113250048;               
            // 0x014346E0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x014346E4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::isCameraShotSkillFit_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x014346E8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_9 = null;
            // 0x014346EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x014346F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014346F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014346F8: MOV x2, x22                | X2 = 1152921510113250048 (0x1000000148350B00);//ML01
            // 0x014346FC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_9;
            // 0x01434700: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::isCameraShotSkillFit_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_9 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::isCameraShotSkillFit_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434704: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434708: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143470C: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687688
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache1 = val_42;
            // 0x01434710: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434714: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434718: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_23:
            // 0x0143471C: CBNZ x19, #0x1434724       | if (X1 != 0) goto label_24;             
            if(X1 != 0)
            {
                goto label_24;
            }
            // 0x01434720: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::isCameraShotSkillFit_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_24:
            // 0x01434724: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434728: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143472C: MOV x1, x21                | X1 = val_8;//m1                         
            // 0x01434730: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434734: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_8, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache1);
            X1.RegisterCLRMethodRedirection(mi:  val_8, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache1);
            // 0x01434738: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x0143473C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434740: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434744: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01434748: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143474C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434750: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x01434754: LDR x22, [x28]             | X22 = typeof(System.Int32);             
            // 0x01434758: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143475C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01434760: TBZ w9, #0, #0x1434774     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_26;
            // 0x01434764: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01434768: CBNZ w9, #0x1434774        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
            // 0x0143476C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01434770: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_26:
            // 0x01434774: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01434778: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143477C: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x01434780: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01434784: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x01434788: CBNZ x21, #0x1434790       | if ( != null) goto label_27;            
            if(null != null)
            {
                goto label_27;
            }
            // 0x0143478C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_27:
            // 0x01434790: CBZ x22, #0x14347b4        | if (val_10 == null) goto label_29;      
            if(val_10 == null)
            {
                goto label_29;
            }
            // 0x01434794: LDR x8, [x21]              | X8 = ;                                  
            // 0x01434798: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x0143479C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014347A0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x014347A4: CBNZ x0, #0x14347b4        | if (val_10 != null) goto label_29;      
            if(val_10 != null)
            {
                goto label_29;
            }
            // 0x014347A8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_10, ????);     
            // 0x014347AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014347B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_29:
            // 0x014347B4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014347B8: CBNZ w8, #0x14347c8        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_30;
            // 0x014347BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x014347C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014347C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_30:
            // 0x014347C8: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_10;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_10;
            // 0x014347CC: CBNZ x20, #0x14347d4       | if (val_1 != null) goto label_31;       
            if(val_1 != null)
            {
                goto label_31;
            }
            // 0x014347D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_31:
            // 0x014347D4: LDR x1, [x27]              | X1 = "PreviewCameraShot";               
            // 0x014347D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014347DC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x014347E0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014347E4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014347E8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014347EC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x014347F0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "PreviewCameraShot", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_11 = val_1.GetMethod(name:  "PreviewCameraShot", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x014347F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014347F8: MOV x21, x0                | X21 = val_11;//m1                       
            // 0x014347FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434800: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache2;
            // 0x01434804: CBNZ x22, #0x1434850       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache2 != null) goto label_32;
            if((ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache2) != null)
            {
                goto label_32;
            }
            // 0x01434808: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x0143480C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01434810: LDR x8, [x8, #0x1d8]       | X8 = 1152921510113259264;               
            // 0x01434814: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01434818: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0143481C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_12 = null;
            // 0x01434820: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01434824: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434828: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143482C: MOV x2, x22                | X2 = 1152921510113259264 (0x1000000148352F00);//ML01
            // 0x01434830: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_12;
            // 0x01434834: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_12 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434838: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x0143483C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434840: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687696
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache2 = val_42;
            // 0x01434844: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434848: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143484C: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_32:
            // 0x01434850: CBNZ x19, #0x1434858       | if (X1 != 0) goto label_33;             
            if(X1 != 0)
            {
                goto label_33;
            }
            // 0x01434854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_33:
            // 0x01434858: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143485C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01434860: MOV x1, x21                | X1 = val_11;//m1                        
            // 0x01434864: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434868: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_11, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache2);
            X1.RegisterCLRMethodRedirection(mi:  val_11, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache2);
            // 0x0143486C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01434870: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434874: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143487C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434880: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434884: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434888: CBNZ x20, #0x1434890       | if (val_1 != null) goto label_34;       
            if(val_1 != null)
            {
                goto label_34;
            }
            // 0x0143488C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_34:
            // 0x01434890: LDR x1, [x27]              | X1 = "PreviewCameraShot";               
            // 0x01434894: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434898: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143489C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014348A0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014348A4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014348A8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x014348AC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "PreviewCameraShot", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_13 = val_1.GetMethod(name:  "PreviewCameraShot", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x014348B0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014348B4: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x014348B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014348BC: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache3;
            // 0x014348C0: CBNZ x22, #0x143490c       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache3 != null) goto label_35;
            if((ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache3) != null)
            {
                goto label_35;
            }
            // 0x014348C4: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x014348C8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x014348CC: LDR x8, [x8, #0xb78]       | X8 = 1152921510113264384;               
            // 0x014348D0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x014348D4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x014348D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_14 = null;
            // 0x014348DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x014348E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014348E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014348E8: MOV x2, x22                | X2 = 1152921510113264384 (0x1000000148354300);//ML01
            // 0x014348EC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_14;
            // 0x014348F0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_14 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x014348F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014348F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014348FC: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687704
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache3 = val_42;
            // 0x01434900: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434904: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434908: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_35:
            // 0x0143490C: CBNZ x19, #0x1434914       | if (X1 != 0) goto label_36;             
            if(X1 != 0)
            {
                goto label_36;
            }
            // 0x01434910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::PreviewCameraShot_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_36:
            // 0x01434914: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434918: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143491C: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x01434920: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434924: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache3);
            X1.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache3);
            // 0x01434928: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x0143492C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434930: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434934: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x01434938: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143493C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434940: ADRP x9, #0x363f000        | X9 = 56881152 (0x363F000);              
            // 0x01434944: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x01434948: LDR x9, [x9, #0x858]       | X9 = 1152921508129291760;               
            // 0x0143494C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434950: LDR x22, [x9]              | X22 = typeof(cameraShotCfg[]);          
            // 0x01434954: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01434958: TBZ w9, #0, #0x143496c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_38;
            // 0x0143495C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01434960: CBNZ w9, #0x143496c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x01434964: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01434968: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_38:
            // 0x0143496C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01434970: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01434974: MOV x1, x22                | X1 = 1152921508129291760 (0x10000000D1F43DF0);//ML01
            // 0x01434978: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143497C: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x01434980: CBNZ x21, #0x1434988       | if ( != null) goto label_39;            
            if(null != null)
            {
                goto label_39;
            }
            // 0x01434984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_39:
            // 0x01434988: CBZ x22, #0x14349ac        | if (val_15 == null) goto label_41;      
            if(val_15 == null)
            {
                goto label_41;
            }
            // 0x0143498C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01434990: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x01434994: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01434998: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x0143499C: CBNZ x0, #0x14349ac        | if (val_15 != null) goto label_41;      
            if(val_15 != null)
            {
                goto label_41;
            }
            // 0x014349A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
            // 0x014349A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014349A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_41:
            // 0x014349AC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014349B0: CBNZ w8, #0x14349c0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_42;
            // 0x014349B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x014349B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014349BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_42:
            // 0x014349C0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_15;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_15;
            // 0x014349C4: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x014349C8: LDR x8, [x8, #0x248]       | X8 = 1152921504888528896;               
            // 0x014349CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014349D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014349D4: LDR x1, [x8]               | X1 = typeof(CameraAniMap);              
            // 0x014349D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014349DC: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x014349E0: CBZ x22, #0x1434a04        | if (val_16 == null) goto label_44;      
            if(val_16 == null)
            {
                goto label_44;
            }
            // 0x014349E4: LDR x8, [x21]              | X8 = ;                                  
            // 0x014349E8: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x014349EC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014349F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x014349F4: CBNZ x0, #0x1434a04        | if (val_16 != null) goto label_44;      
            if(val_16 != null)
            {
                goto label_44;
            }
            // 0x014349F8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x014349FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434A00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_44:
            // 0x01434A04: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01434A08: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x01434A0C: B.HI #0x1434a1c            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_45;
            // 0x01434A10: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x01434A14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434A18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_45:
            // 0x01434A1C: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_16;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_16;
            // 0x01434A20: CBNZ x20, #0x1434a28       | if (val_1 != null) goto label_46;       
            if(val_1 != null)
            {
                goto label_46;
            }
            // 0x01434A24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_46:
            // 0x01434A28: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x01434A2C: LDR x8, [x8, #0x460]       | X8 = (string**)(1152921510113273600)("previewInEditor");
            // 0x01434A30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434A34: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01434A38: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01434A3C: LDR x1, [x8]               | X1 = "previewInEditor";                 
            // 0x01434A40: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01434A44: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434A48: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01434A4C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "previewInEditor", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_17 = val_1.GetMethod(name:  "previewInEditor", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01434A50: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434A54: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x01434A58: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434A5C: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache4;
            // 0x01434A60: CBNZ x22, #0x1434aac       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache4 != null) goto label_47;
            if((ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache4) != null)
            {
                goto label_47;
            }
            // 0x01434A64: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x01434A68: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01434A6C: LDR x8, [x8, #0x9a0]       | X8 = 1152921510113277808;               
            // 0x01434A70: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01434A74: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::previewInEditor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01434A78: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_18 = null;
            // 0x01434A7C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01434A80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434A84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434A88: MOV x2, x22                | X2 = 1152921510113277808 (0x1000000148357770);//ML01
            // 0x01434A8C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_18;
            // 0x01434A90: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::previewInEditor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::previewInEditor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434A94: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434A98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434A9C: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687712
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache4 = val_42;
            // 0x01434AA0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434AA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434AA8: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_47:
            // 0x01434AAC: CBNZ x19, #0x1434ab4       | if (X1 != 0) goto label_48;             
            if(X1 != 0)
            {
                goto label_48;
            }
            // 0x01434AB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::previewInEditor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_48:
            // 0x01434AB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434AB8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01434ABC: MOV x1, x21                | X1 = val_17;//m1                        
            // 0x01434AC0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434AC4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_17, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache4);
            X1.RegisterCLRMethodRedirection(mi:  val_17, func:  ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache4);
            // 0x01434AC8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01434ACC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434AD0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434AD8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434ADC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434AE0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434AE4: CBNZ x20, #0x1434aec       | if (val_1 != null) goto label_49;       
            if(val_1 != null)
            {
                goto label_49;
            }
            // 0x01434AE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_49:
            // 0x01434AEC: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x01434AF0: LDR x8, [x8, #0x6f0]       | X8 = (string**)(1152921510103408416)("Open");
            // 0x01434AF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434AF8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01434AFC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01434B00: LDR x1, [x8]               | X1 = "Open";                            
            // 0x01434B04: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01434B08: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434B0C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01434B10: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Open", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_19 = val_1.GetMethod(name:  "Open", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01434B14: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434B18: MOV x21, x0                | X21 = val_19;//m1                       
            // 0x01434B1C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434B20: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache5;
            val_43 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache5;
            // 0x01434B24: CBNZ x22, #0x1434b70       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache5 != null) goto label_50;
            if(val_43 != null)
            {
                goto label_50;
            }
            // 0x01434B28: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x01434B2C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01434B30: LDR x8, [x8, #0x9c8]       | X8 = 1152921510113282928;               
            // 0x01434B34: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01434B38: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Open_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01434B3C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_20 = null;
            // 0x01434B40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01434B44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434B48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434B4C: MOV x2, x22                | X2 = 1152921510113282928 (0x1000000148358B70);//ML01
            // 0x01434B50: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_20;
            // 0x01434B54: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Open_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_20 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Open_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434B58: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434B5C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434B60: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687720
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache5 = val_42;
            // 0x01434B64: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434B68: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434B6C: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_43 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache5;
            label_50:
            // 0x01434B70: CBNZ x19, #0x1434b78       | if (X1 != 0) goto label_51;             
            if(X1 != 0)
            {
                goto label_51;
            }
            // 0x01434B74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Open_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_51:
            // 0x01434B78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434B7C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01434B80: MOV x1, x21                | X1 = val_19;//m1                        
            // 0x01434B84: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434B88: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_43);
            X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_43);
            // 0x01434B8C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01434B90: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434B94: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434B98: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01434B9C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434BA0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434BA4: ADRP x9, #0x3615000        | X9 = 56709120 (0x3615000);              
            // 0x01434BA8: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x01434BAC: LDR x9, [x9, #0x668]       | X9 = 1152921504898326528;               
            // 0x01434BB0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434BB4: LDR x22, [x9]              | X22 = typeof(CEvent.ZEvent);            
            // 0x01434BB8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01434BBC: TBZ w9, #0, #0x1434bd0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_53;
            // 0x01434BC0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01434BC4: CBNZ w9, #0x1434bd0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_53;
            // 0x01434BC8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01434BCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_53:
            // 0x01434BD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01434BD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01434BD8: MOV x1, x22                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x01434BDC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_21 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01434BE0: MOV x22, x0                | X22 = val_21;//m1                       
            // 0x01434BE4: CBNZ x21, #0x1434bec       | if ( != null) goto label_54;            
            if(null != null)
            {
                goto label_54;
            }
            // 0x01434BE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_54:
            // 0x01434BEC: CBZ x22, #0x1434c10        | if (val_21 == null) goto label_56;      
            if(val_21 == null)
            {
                goto label_56;
            }
            // 0x01434BF0: LDR x8, [x21]              | X8 = ;                                  
            // 0x01434BF4: MOV x0, x22                | X0 = val_21;//m1                        
            // 0x01434BF8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01434BFC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_21, ????);     
            // 0x01434C00: CBNZ x0, #0x1434c10        | if (val_21 != null) goto label_56;      
            if(val_21 != null)
            {
                goto label_56;
            }
            // 0x01434C04: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_21, ????);     
            // 0x01434C08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434C0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            label_56:
            // 0x01434C10: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01434C14: CBNZ w8, #0x1434c24        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_57;
            // 0x01434C18: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_21, ????);     
            // 0x01434C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434C20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            label_57:
            // 0x01434C24: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_21;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_21;
            // 0x01434C28: CBNZ x20, #0x1434c30       | if (val_1 != null) goto label_58;       
            if(val_1 != null)
            {
                goto label_58;
            }
            // 0x01434C2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_58:
            // 0x01434C30: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x01434C34: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921510113288048)("JumpAllStory");
            // 0x01434C38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434C3C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01434C40: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01434C44: LDR x1, [x8]               | X1 = "JumpAllStory";                    
            // 0x01434C48: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01434C4C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434C50: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01434C54: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "JumpAllStory", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_22 = val_1.GetMethod(name:  "JumpAllStory", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01434C58: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434C5C: MOV x21, x0                | X21 = val_22;//m1                       
            // 0x01434C60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434C64: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache6;
            val_44 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache6;
            // 0x01434C68: CBNZ x22, #0x1434cb4       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache6 != null) goto label_59;
            if(val_44 != null)
            {
                goto label_59;
            }
            // 0x01434C6C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01434C70: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01434C74: LDR x8, [x8, #0x580]       | X8 = 1152921510113292240;               
            // 0x01434C78: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01434C7C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::JumpAllStory_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01434C80: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_23 = null;
            // 0x01434C84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01434C88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434C8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434C90: MOV x2, x22                | X2 = 1152921510113292240 (0x100000014835AFD0);//ML01
            // 0x01434C94: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_23;
            // 0x01434C98: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::JumpAllStory_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::JumpAllStory_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434C9C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434CA0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434CA4: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687728
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache6 = val_42;
            // 0x01434CA8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434CAC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434CB0: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_44 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache6;
            label_59:
            // 0x01434CB4: CBNZ x19, #0x1434cbc       | if (X1 != 0) goto label_60;             
            if(X1 != 0)
            {
                goto label_60;
            }
            // 0x01434CB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::JumpAllStory_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_60:
            // 0x01434CBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434CC0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01434CC4: MOV x1, x21                | X1 = val_22;//m1                        
            // 0x01434CC8: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434CCC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_44);
            X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_44);
            // 0x01434CD0: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01434CD4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434CD8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434CDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434CE0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434CE4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434CE8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434CEC: CBNZ x20, #0x1434cf4       | if (val_1 != null) goto label_61;       
            if(val_1 != null)
            {
                goto label_61;
            }
            // 0x01434CF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_61:
            // 0x01434CF4: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x01434CF8: LDR x8, [x8, #0xe60]       | X8 = (string**)(1152921510113293264)("Close");
            // 0x01434CFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434D00: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01434D04: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01434D08: LDR x1, [x8]               | X1 = "Close";                           
            // 0x01434D0C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01434D10: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434D14: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01434D18: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Close", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_24 = val_1.GetMethod(name:  "Close", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01434D1C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434D20: MOV x21, x0                | X21 = val_24;//m1                       
            // 0x01434D24: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434D28: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache7;
            val_45 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache7;
            // 0x01434D2C: CBNZ x22, #0x1434d78       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache7 != null) goto label_62;
            if(val_45 != null)
            {
                goto label_62;
            }
            // 0x01434D30: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x01434D34: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01434D38: LDR x8, [x8, #0x110]       | X8 = 1152921510113297440;               
            // 0x01434D3C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01434D40: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Close_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01434D44: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25 = null;
            // 0x01434D48: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01434D4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434D50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434D54: MOV x2, x22                | X2 = 1152921510113297440 (0x100000014835C420);//ML01
            // 0x01434D58: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_25;
            // 0x01434D5C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Close_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_25 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Close_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434D60: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434D64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434D68: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687736
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache7 = val_42;
            // 0x01434D6C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434D70: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434D74: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_45 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache7;
            label_62:
            // 0x01434D78: CBNZ x19, #0x1434d80       | if (X1 != 0) goto label_63;             
            if(X1 != 0)
            {
                goto label_63;
            }
            // 0x01434D7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Close_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_63:
            // 0x01434D80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434D84: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01434D88: MOV x1, x21                | X1 = val_24;//m1                        
            // 0x01434D8C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434D90: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_45);
            X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_45);
            // 0x01434D94: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01434D98: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434D9C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434DA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434DA4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434DA8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434DAC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434DB0: CBNZ x20, #0x1434db8       | if (val_1 != null) goto label_64;       
            if(val_1 != null)
            {
                goto label_64;
            }
            // 0x01434DB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_64:
            // 0x01434DB8: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x01434DBC: LDR x8, [x8, #0xfc8]       | X8 = (string**)(1152921510113298464)("ClosePeak");
            // 0x01434DC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434DC4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01434DC8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01434DCC: LDR x1, [x8]               | X1 = "ClosePeak";                       
            // 0x01434DD0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01434DD4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434DD8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01434DDC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ClosePeak", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_26 = val_1.GetMethod(name:  "ClosePeak", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01434DE0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434DE4: MOV x21, x0                | X21 = val_26;//m1                       
            // 0x01434DE8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434DEC: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache8;
            val_46 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache8;
            // 0x01434DF0: CBNZ x22, #0x1434e3c       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache8 != null) goto label_65;
            if(val_46 != null)
            {
                goto label_65;
            }
            // 0x01434DF4: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x01434DF8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01434DFC: LDR x8, [x8, #0x250]       | X8 = 1152921510113302656;               
            // 0x01434E00: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01434E04: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::ClosePeak_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01434E08: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_27 = null;
            // 0x01434E0C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01434E10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434E14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434E18: MOV x2, x22                | X2 = 1152921510113302656 (0x100000014835D880);//ML01
            // 0x01434E1C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_27;
            // 0x01434E20: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::ClosePeak_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_27 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::ClosePeak_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434E24: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434E28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434E2C: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687744
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache8 = val_42;
            // 0x01434E30: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434E34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434E38: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_46 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache8;
            label_65:
            // 0x01434E3C: CBNZ x19, #0x1434e44       | if (X1 != 0) goto label_66;             
            if(X1 != 0)
            {
                goto label_66;
            }
            // 0x01434E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::ClosePeak_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_66:
            // 0x01434E44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434E48: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01434E4C: MOV x1, x21                | X1 = val_26;//m1                        
            // 0x01434E50: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434E54: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_46);
            X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_46);
            // 0x01434E58: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01434E5C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434E60: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434E68: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434E6C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434E70: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434E74: CBNZ x20, #0x1434e7c       | if (val_1 != null) goto label_67;       
            if(val_1 != null)
            {
                goto label_67;
            }
            // 0x01434E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_67:
            // 0x01434E7C: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x01434E80: LDR x8, [x8, #0x9a0]       | X8 = (string**)(1152921510113303680)("Execute");
            // 0x01434E84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434E88: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01434E8C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01434E90: LDR x1, [x8]               | X1 = "Execute";                         
            // 0x01434E94: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01434E98: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434E9C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01434EA0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Execute", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_28 = val_1.GetMethod(name:  "Execute", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01434EA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434EA8: MOV x21, x0                | X21 = val_28;//m1                       
            // 0x01434EAC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434EB0: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache9;
            val_47 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache9;
            // 0x01434EB4: CBNZ x22, #0x1434f00       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache9 != null) goto label_68;
            if(val_47 != null)
            {
                goto label_68;
            }
            // 0x01434EB8: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x01434EBC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01434EC0: LDR x8, [x8, #0xec8]       | X8 = 1152921510113307872;               
            // 0x01434EC4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01434EC8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Execute_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01434ECC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_29 = null;
            // 0x01434ED0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01434ED4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434ED8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434EDC: MOV x2, x22                | X2 = 1152921510113307872 (0x100000014835ECE0);//ML01
            // 0x01434EE0: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_29;
            // 0x01434EE4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Execute_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_29 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Execute_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434EE8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434EEC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434EF0: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687752
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache9 = val_42;
            // 0x01434EF4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434EF8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434EFC: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_47 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache9;
            label_68:
            // 0x01434F00: CBNZ x19, #0x1434f08       | if (X1 != 0) goto label_69;             
            if(X1 != 0)
            {
                goto label_69;
            }
            // 0x01434F04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::Execute_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_69:
            // 0x01434F08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434F0C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01434F10: MOV x1, x21                | X1 = val_28;//m1                        
            // 0x01434F14: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434F18: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_28, func:  val_47);
            X1.RegisterCLRMethodRedirection(mi:  val_28, func:  val_47);
            // 0x01434F1C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01434F20: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434F24: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01434F28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434F2C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434F30: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01434F34: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434F38: CBNZ x20, #0x1434f40       | if (val_1 != null) goto label_70;       
            if(val_1 != null)
            {
                goto label_70;
            }
            // 0x01434F3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_70:
            // 0x01434F40: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x01434F44: LDR x8, [x8, #0x1b8]       | X8 = (string**)(1152921510113308896)("OnEnd");
            // 0x01434F48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434F4C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01434F50: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01434F54: LDR x1, [x8]               | X1 = "OnEnd";                           
            // 0x01434F58: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01434F5C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01434F60: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01434F64: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "OnEnd", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_30 = val_1.GetMethod(name:  "OnEnd", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01434F68: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434F6C: MOV x21, x0                | X21 = val_30;//m1                       
            // 0x01434F70: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434F74: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheA;
            val_48 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheA;
            // 0x01434F78: CBNZ x22, #0x1434fc4       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheA != null) goto label_71;
            if(val_48 != null)
            {
                goto label_71;
            }
            // 0x01434F7C: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x01434F80: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01434F84: LDR x8, [x8, #0x150]       | X8 = 1152921510113313072;               
            // 0x01434F88: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01434F8C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::OnEnd_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01434F90: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_31 = null;
            // 0x01434F94: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01434F98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434F9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434FA0: MOV x2, x22                | X2 = 1152921510113313072 (0x1000000148360130);//ML01
            // 0x01434FA4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_42 = val_31;
            // 0x01434FA8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::OnEnd_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_31 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::OnEnd_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01434FAC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434FB0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434FB4: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783687760
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheA = val_42;
            // 0x01434FB8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01434FBC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01434FC0: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_48 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheA;
            label_71:
            // 0x01434FC4: CBNZ x19, #0x1434fcc       | if (X1 != 0) goto label_72;             
            if(X1 != 0)
            {
                goto label_72;
            }
            // 0x01434FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraShotMgr_Binding::OnEnd_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_72:
            // 0x01434FCC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01434FD0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01434FD4: MOV x1, x21                | X1 = val_30;//m1                        
            // 0x01434FD8: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01434FDC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_48);
            X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_48);
            // 0x01434FE0: CBNZ x20, #0x1434fe8       | if (val_1 != null) goto label_73;       
            if(val_1 != null)
            {
                goto label_73;
            }
            // 0x01434FE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_73:
            // 0x01434FE8: ADRP x9, #0x361f000        | X9 = 56750080 (0x361F000);              
            // 0x01434FEC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01434FF0: LDR x9, [x9, #0xde0]       | X9 = (string**)(1152921510113314096)("WAITTIME_COMPLETE");
            // 0x01434FF4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01434FF8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01434FFC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01435000: LDR x1, [x9]               | X1 = "WAITTIME_COMPLETE";               
            // 0x01435004: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01435008: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x0143500C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435010: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01435014: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435018: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheB;
            val_49 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheB;
            // 0x0143501C: CBNZ x22, #0x1435068       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheB != null) goto label_74;
            if(val_49 != null)
            {
                goto label_74;
            }
            // 0x01435020: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x01435024: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01435028: LDR x8, [x8, #0x748]       | X8 = 1152921510113314208;               
            // 0x0143502C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01435030: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_WAITTIME_COMPLETE_0(ref object o);
            // 0x01435034: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_32 = null;
            // 0x01435038: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x0143503C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435040: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435044: MOV x2, x22                | X2 = 1152921510113314208 (0x10000001483605A0);//ML01
            // 0x01435048: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_42 = val_32;
            // 0x0143504C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_WAITTIME_COMPLETE_0(ref object o));
            val_32 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_WAITTIME_COMPLETE_0(ref object o));
            // 0x01435050: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435054: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435058: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783687768
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheB = val_42;
            // 0x0143505C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435060: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435064: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_49 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheB;
            label_74:
            // 0x01435068: CBNZ x19, #0x1435070       | if (X1 != 0) goto label_75;             
            if(X1 != 0)
            {
                goto label_75;
            }
            // 0x0143506C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_WAITTIME_COMPLETE_0(ref object o)), ????);
            label_75:
            // 0x01435070: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435074: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435078: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x0143507C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01435080: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_49);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_49);
            // 0x01435084: CBNZ x20, #0x143508c       | if (val_1 != null) goto label_76;       
            if(val_1 != null)
            {
                goto label_76;
            }
            // 0x01435088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_76:
            // 0x0143508C: ADRP x9, #0x3675000        | X9 = 57102336 (0x3675000);              
            // 0x01435090: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01435094: LDR x9, [x9, #0xdf8]       | X9 = (string**)(1152921510113315232)("ACTION_DONE");
            // 0x01435098: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0143509C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014350A0: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014350A4: LDR x1, [x9]               | X1 = "ACTION_DONE";                     
            // 0x014350A8: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014350AC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014350B0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014350B4: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x014350B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014350BC: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheC;
            val_50 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheC;
            // 0x014350C0: CBNZ x22, #0x143510c       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheC != null) goto label_77;
            if(val_50 != null)
            {
                goto label_77;
            }
            // 0x014350C4: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x014350C8: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x014350CC: LDR x8, [x8, #0x688]       | X8 = 1152921510113315328;               
            // 0x014350D0: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x014350D4: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_ACTION_DONE_1(ref object o);
            // 0x014350D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_33 = null;
            // 0x014350DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x014350E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014350E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014350E8: MOV x2, x22                | X2 = 1152921510113315328 (0x1000000148360A00);//ML01
            // 0x014350EC: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_42 = val_33;
            // 0x014350F0: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_ACTION_DONE_1(ref object o));
            val_33 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_ACTION_DONE_1(ref object o));
            // 0x014350F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014350F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014350FC: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783687776
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheC = val_42;
            // 0x01435100: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435104: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435108: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_50 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheC;
            label_77:
            // 0x0143510C: CBNZ x19, #0x1435114       | if (X1 != 0) goto label_78;             
            if(X1 != 0)
            {
                goto label_78;
            }
            // 0x01435110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_ACTION_DONE_1(ref object o)), ????);
            label_78:
            // 0x01435114: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435118: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143511C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01435120: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01435124: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_50);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_50);
            // 0x01435128: CBNZ x20, #0x1435130       | if (val_1 != null) goto label_79;       
            if(val_1 != null)
            {
                goto label_79;
            }
            // 0x0143512C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_79:
            // 0x01435130: ADRP x9, #0x35fb000        | X9 = 56602624 (0x35FB000);              
            // 0x01435134: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01435138: LDR x9, [x9, #0x728]       | X9 = (string**)(1152921510113316352)("SKILL_DONE");
            // 0x0143513C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01435140: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01435144: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01435148: LDR x1, [x9]               | X1 = "SKILL_DONE";                      
            // 0x0143514C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01435150: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01435154: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435158: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x0143515C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435160: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheD;
            val_51 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheD;
            // 0x01435164: CBNZ x22, #0x14351b0       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheD != null) goto label_80;
            if(val_51 != null)
            {
                goto label_80;
            }
            // 0x01435168: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x0143516C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01435170: LDR x8, [x8, #0x450]       | X8 = 1152921510113316448;               
            // 0x01435174: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01435178: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_SKILL_DONE_2(ref object o);
            // 0x0143517C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_34 = null;
            // 0x01435180: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01435184: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435188: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143518C: MOV x2, x22                | X2 = 1152921510113316448 (0x1000000148360E60);//ML01
            // 0x01435190: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_42 = val_34;
            // 0x01435194: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_SKILL_DONE_2(ref object o));
            val_34 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_SKILL_DONE_2(ref object o));
            // 0x01435198: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x0143519C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014351A0: STR x23, [x8, #0x68]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783687784
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheD = val_42;
            // 0x014351A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014351A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014351AC: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_51 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheD;
            label_80:
            // 0x014351B0: CBNZ x19, #0x14351b8       | if (X1 != 0) goto label_81;             
            if(X1 != 0)
            {
                goto label_81;
            }
            // 0x014351B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_SKILL_DONE_2(ref object o)), ????);
            label_81:
            // 0x014351B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014351BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014351C0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014351C4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x014351C8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_51);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_51);
            // 0x014351CC: CBNZ x20, #0x14351d4       | if (val_1 != null) goto label_82;       
            if(val_1 != null)
            {
                goto label_82;
            }
            // 0x014351D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_82:
            // 0x014351D4: ADRP x9, #0x35d1000        | X9 = 56430592 (0x35D1000);              
            // 0x014351D8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014351DC: LDR x9, [x9, #0xa00]       | X9 = (string**)(1152921510113317472)("START_ANI_COMPLETE");
            // 0x014351E0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014351E4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014351E8: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014351EC: LDR x1, [x9]               | X1 = "START_ANI_COMPLETE";              
            // 0x014351F0: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014351F4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014351F8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014351FC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01435200: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435204: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheE;
            val_52 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheE;
            // 0x01435208: CBNZ x22, #0x1435254       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheE != null) goto label_83;
            if(val_52 != null)
            {
                goto label_83;
            }
            // 0x0143520C: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x01435210: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01435214: LDR x8, [x8, #0xa78]       | X8 = 1152921510113317584;               
            // 0x01435218: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x0143521C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_START_ANI_COMPLETE_3(ref object o);
            // 0x01435220: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_35 = null;
            // 0x01435224: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01435228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143522C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435230: MOV x2, x22                | X2 = 1152921510113317584 (0x10000001483612D0);//ML01
            // 0x01435234: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_42 = val_35;
            // 0x01435238: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_START_ANI_COMPLETE_3(ref object o));
            val_35 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_START_ANI_COMPLETE_3(ref object o));
            // 0x0143523C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435240: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435244: STR x23, [x8, #0x70]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783687792
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheE = val_42;
            // 0x01435248: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x0143524C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435250: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_52 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheE;
            label_83:
            // 0x01435254: CBNZ x19, #0x143525c       | if (X1 != 0) goto label_84;             
            if(X1 != 0)
            {
                goto label_84;
            }
            // 0x01435258: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_START_ANI_COMPLETE_3(ref object o)), ????);
            label_84:
            // 0x0143525C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435260: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435264: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01435268: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x0143526C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_52);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_52);
            // 0x01435270: CBNZ x20, #0x1435278       | if (val_1 != null) goto label_85;       
            if(val_1 != null)
            {
                goto label_85;
            }
            // 0x01435274: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_85:
            // 0x01435278: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
            // 0x0143527C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01435280: LDR x9, [x9, #0xcd0]       | X9 = (string**)(1152921510113318608)("isEditorRun");
            // 0x01435284: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01435288: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143528C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01435290: LDR x1, [x9]               | X1 = "isEditorRun";                     
            // 0x01435294: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01435298: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x0143529C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014352A0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x014352A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014352A8: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheF;
            val_53 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheF;
            // 0x014352AC: CBNZ x22, #0x14352f8       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheF != null) goto label_86;
            if(val_53 != null)
            {
                goto label_86;
            }
            // 0x014352B0: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x014352B4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x014352B8: LDR x8, [x8, #0x380]       | X8 = 1152921510113318704;               
            // 0x014352BC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x014352C0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_isEditorRun_4(ref object o);
            // 0x014352C4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_36 = null;
            // 0x014352C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x014352CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014352D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014352D4: MOV x2, x22                | X2 = 1152921510113318704 (0x1000000148361730);//ML01
            // 0x014352D8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_42 = val_36;
            // 0x014352DC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_isEditorRun_4(ref object o));
            val_36 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_isEditorRun_4(ref object o));
            // 0x014352E0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014352E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014352E8: STR x23, [x8, #0x78]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783687800
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheF = val_42;
            // 0x014352EC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014352F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014352F4: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_53 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cacheF;
            label_86:
            // 0x014352F8: CBNZ x19, #0x1435300       | if (X1 != 0) goto label_87;             
            if(X1 != 0)
            {
                goto label_87;
            }
            // 0x014352FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_isEditorRun_4(ref object o)), ????);
            label_87:
            // 0x01435300: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435304: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435308: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x0143530C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01435310: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_53);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_53);
            // 0x01435314: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435318: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143531C: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache10;
            val_54 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache10;
            // 0x01435320: CBNZ x22, #0x143536c       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache10 != null) goto label_88;
            if(val_54 != null)
            {
                goto label_88;
            }
            // 0x01435324: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x01435328: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x0143532C: LDR x8, [x8, #0xf48]       | X8 = 1152921510113319728;               
            // 0x01435330: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01435334: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_isEditorRun_4(ref object o, object v);
            // 0x01435338: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_37 = null;
            // 0x0143533C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01435340: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435344: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435348: MOV x2, x22                | X2 = 1152921510113319728 (0x1000000148361B30);//ML01
            // 0x0143534C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_42 = val_37;
            // 0x01435350: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_isEditorRun_4(ref object o, object v));
            val_37 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_isEditorRun_4(ref object o, object v));
            // 0x01435354: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435358: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143535C: STR x23, [x8, #0x80]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783687808
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache10 = val_42;
            // 0x01435360: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435364: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435368: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_54 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache10;
            label_88:
            // 0x0143536C: CBNZ x19, #0x1435374       | if (X1 != 0) goto label_89;             
            if(X1 != 0)
            {
                goto label_89;
            }
            // 0x01435370: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_isEditorRun_4(ref object o, object v)), ????);
            label_89:
            // 0x01435374: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435378: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143537C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01435380: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01435384: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_54);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_54);
            // 0x01435388: CBNZ x20, #0x1435390       | if (val_1 != null) goto label_90;       
            if(val_1 != null)
            {
                goto label_90;
            }
            // 0x0143538C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_90:
            // 0x01435390: ADRP x9, #0x35e3000        | X9 = 56504320 (0x35E3000);              
            // 0x01435394: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01435398: LDR x9, [x9, #0x800]       | X9 = (string**)(1152921510113320752)("isCameraShotRunning");
            // 0x0143539C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014353A0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014353A4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014353A8: LDR x1, [x9]               | X1 = "isCameraShotRunning";             
            // 0x014353AC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014353B0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014353B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014353B8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x014353BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014353C0: LDR x22, [x8, #0x88]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache11;
            val_55 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache11;
            // 0x014353C4: CBNZ x22, #0x1435410       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache11 != null) goto label_91;
            if(val_55 != null)
            {
                goto label_91;
            }
            // 0x014353C8: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x014353CC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x014353D0: LDR x8, [x8, #0xa00]       | X8 = 1152921510113320864;               
            // 0x014353D4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x014353D8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_isCameraShotRunning_5(ref object o);
            // 0x014353DC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_38 = null;
            // 0x014353E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x014353E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014353E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014353EC: MOV x2, x22                | X2 = 1152921510113320864 (0x1000000148361FA0);//ML01
            // 0x014353F0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_42 = val_38;
            // 0x014353F4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_isCameraShotRunning_5(ref object o));
            val_38 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_isCameraShotRunning_5(ref object o));
            // 0x014353F8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014353FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435400: STR x23, [x8, #0x88]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783687816
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache11 = val_42;
            // 0x01435404: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435408: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143540C: LDR x22, [x8, #0x88]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_55 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache11;
            label_91:
            // 0x01435410: CBNZ x19, #0x1435418       | if (X1 != 0) goto label_92;             
            if(X1 != 0)
            {
                goto label_92;
            }
            // 0x01435414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_isCameraShotRunning_5(ref object o)), ????);
            label_92:
            // 0x01435418: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143541C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435420: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01435424: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01435428: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_55);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_55);
            // 0x0143542C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435430: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435434: LDR x22, [x8, #0x90]       | X22 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache12;
            val_56 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache12;
            // 0x01435438: CBNZ x22, #0x1435484       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache12 != null) goto label_93;
            if(val_56 != null)
            {
                goto label_93;
            }
            // 0x0143543C: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x01435440: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01435444: LDR x8, [x8, #0xa40]       | X8 = 1152921510113321888;               
            // 0x01435448: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x0143544C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_isCameraShotRunning_5(ref object o, object v);
            // 0x01435450: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_39 = null;
            // 0x01435454: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01435458: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143545C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435460: MOV x2, x22                | X2 = 1152921510113321888 (0x10000001483623A0);//ML01
            // 0x01435464: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_42 = val_39;
            // 0x01435468: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_isCameraShotRunning_5(ref object o, object v));
            val_39 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_isCameraShotRunning_5(ref object o, object v));
            // 0x0143546C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435470: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435474: STR x23, [x8, #0x90]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache12 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783687824
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache12 = val_42;
            // 0x01435478: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x0143547C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435480: LDR x22, [x8, #0x90]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_56 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache12;
            label_93:
            // 0x01435484: CBNZ x19, #0x143548c       | if (X1 != 0) goto label_94;             
            if(X1 != 0)
            {
                goto label_94;
            }
            // 0x01435488: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_isCameraShotRunning_5(ref object o, object v)), ????);
            label_94:
            // 0x0143548C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435490: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435494: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01435498: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x0143549C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_56);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_56);
            // 0x014354A0: CBNZ x20, #0x14354a8       | if (val_1 != null) goto label_95;       
            if(val_1 != null)
            {
                goto label_95;
            }
            // 0x014354A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_95:
            // 0x014354A8: ADRP x9, #0x35bd000        | X9 = 56348672 (0x35BD000);              
            // 0x014354AC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014354B0: LDR x9, [x9, #0x818]       | X9 = (string**)(1152921510113322912)("effectDic");
            // 0x014354B4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014354B8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014354BC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014354C0: LDR x1, [x9]               | X1 = "effectDic";                       
            // 0x014354C4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014354C8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014354CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x014354D0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x014354D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x014354D8: LDR x21, [x8, #0x98]       | X21 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache13;
            val_57 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache13;
            // 0x014354DC: CBNZ x21, #0x1435528       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache13 != null) goto label_96;
            if(val_57 != null)
            {
                goto label_96;
            }
            // 0x014354E0: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x014354E4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x014354E8: LDR x8, [x8, #0xf70]       | X8 = 1152921510113323008;               
            // 0x014354EC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x014354F0: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_effectDic_6(ref object o);
            // 0x014354F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_40 = null;
            // 0x014354F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x014354FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435500: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435504: MOV x2, x21                | X2 = 1152921510113323008 (0x1000000148362800);//ML01
            // 0x01435508: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x0143550C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_effectDic_6(ref object o));
            val_40 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_effectDic_6(ref object o));
            // 0x01435510: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435514: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435518: STR x22, [x8, #0x98]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache13 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783687832
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache13 = val_40;
            // 0x0143551C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435520: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435524: LDR x21, [x8, #0x98]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_57 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache13;
            label_96:
            // 0x01435528: CBNZ x19, #0x1435530       | if (X1 != 0) goto label_97;             
            if(X1 != 0)
            {
                goto label_97;
            }
            // 0x0143552C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraShotMgr_Binding::get_effectDic_6(ref object o)), ????);
            label_97:
            // 0x01435530: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435534: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435538: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x0143553C: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01435540: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_57);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_57);
            // 0x01435544: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435548: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143554C: LDR x21, [x8, #0xa0]       | X21 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache14;
            val_58 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache14;
            // 0x01435550: CBNZ x21, #0x143559c       | if (ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache14 != null) goto label_98;
            if(val_58 != null)
            {
                goto label_98;
            }
            // 0x01435554: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x01435558: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x0143555C: LDR x8, [x8, #0xa88]       | X8 = 1152921510113324032;               
            // 0x01435560: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01435564: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_effectDic_6(ref object o, object v);
            // 0x01435568: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_41 = null;
            // 0x0143556C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01435570: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435574: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435578: MOV x2, x21                | X2 = 1152921510113324032 (0x1000000148362C00);//ML01
            // 0x0143557C: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01435580: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_effectDic_6(ref object o, object v));
            val_41 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_effectDic_6(ref object o, object v));
            // 0x01435584: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435588: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143558C: STR x22, [x8, #0xa0]       | ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache14 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783687840
            ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache14 = val_41;
            // 0x01435590: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraShotMgr_Binding);
            // 0x01435594: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01435598: LDR x21, [x8, #0xa0]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_58 = ILRuntime.Runtime.Generated.CameraShotMgr_Binding.<>f__mg$cache14;
            label_98:
            // 0x0143559C: CBNZ x19, #0x14355a4       | if (X1 != 0) goto label_99;             
            if(X1 != 0)
            {
                goto label_99;
            }
            // 0x014355A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraShotMgr_Binding::set_effectDic_6(ref object o, object v)), ????);
            label_99:
            // 0x014355A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014355A8: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x014355AC: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x014355B0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x014355B4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x014355B8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x014355BC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x014355C0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x014355C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014355C8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x014355CC: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_58); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_58);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x014355D0 (21190096), len: 616  VirtAddr: 0x014355D0 RVA: 0x014355D0 token: 100664168 methodIndex: 30215 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* PreviewCameraShot_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            //  | 
            var val_11;
            // 0x014355D0: STP x26, x25, [sp, #-0x50]! | stack[1152921510113563664] = ???;  stack[1152921510113563672] = ???;  //  dest_result_addr=1152921510113563664 |  dest_result_addr=1152921510113563672
            // 0x014355D4: STP x24, x23, [sp, #0x10]  | stack[1152921510113563680] = ???;  stack[1152921510113563688] = ???;  //  dest_result_addr=1152921510113563680 |  dest_result_addr=1152921510113563688
            // 0x014355D8: STP x22, x21, [sp, #0x20]  | stack[1152921510113563696] = ???;  stack[1152921510113563704] = ???;  //  dest_result_addr=1152921510113563696 |  dest_result_addr=1152921510113563704
            // 0x014355DC: STP x20, x19, [sp, #0x30]  | stack[1152921510113563712] = ???;  stack[1152921510113563720] = ???;  //  dest_result_addr=1152921510113563712 |  dest_result_addr=1152921510113563720
            // 0x014355E0: STP x29, x30, [sp, #0x40]  | stack[1152921510113563728] = ???;  stack[1152921510113563736] = ???;  //  dest_result_addr=1152921510113563728 |  dest_result_addr=1152921510113563736
            // 0x014355E4: ADD x29, sp, #0x40         | X29 = (1152921510113563664 + 64) = 1152921510113563728 (0x100000014839D450);
            // 0x014355E8: SUB sp, sp, #0x10          | SP = (1152921510113563664 - 16) = 1152921510113563648 (0x100000014839D400);
            // 0x014355EC: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014355F0: LDRB w8, [x20, #0x46]      | W8 = (bool)static_value_03737046;       
            // 0x014355F4: MOV x24, x3                | X24 = X3;//m1                           
            // 0x014355F8: MOV x23, x2                | X23 = X2;//m1                           
            // 0x014355FC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01435600: TBNZ w8, #0, #0x143561c    | if (static_value_03737046 == true) goto label_0;
            // 0x01435604: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x01435608: LDR x8, [x8, #0x2b8]       | X8 = 0x2B902D8;                         
            // 0x0143560C: LDR w0, [x8]               | W0 = 0x177A;                            
            // 0x01435610: BL #0x2782188              | X0 = sub_2782188( ?? 0x177A, ????);     
            // 0x01435614: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01435618: STRB w8, [x20, #0x46]      | static_value_03737046 = true;            //  dest_result_addr=57897030
            label_0:
            // 0x0143561C: CBNZ x19, #0x1435624       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01435620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x177A, ????);     
            label_1:
            // 0x01435624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435628: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143562C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01435630: MOV x25, x0                | X25 = val_1;//m1                        
            // 0x01435634: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435638: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143563C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01435640: MOV x1, x23                | X1 = X2;//m1                            
            // 0x01435644: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435648: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0143564C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435650: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435654: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01435658: MOV x1, x23                | X1 = X2;//m1                            
            // 0x0143565C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435660: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01435664: CBNZ x21, #0x143566c       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x01435668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x0143566C: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x01435670: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435674: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435678: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143567C: MOV x1, x23                | X1 = X2;//m1                            
            // 0x01435680: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435684: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x01435688: CBNZ x22, #0x1435690       | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x0143568C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x01435690: LDR w22, [x22, #4]         | W22 = val_4 + 4;                        
            // 0x01435694: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435698: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143569C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x014356A0: MOV x1, x23                | X1 = X2;//m1                            
            // 0x014356A4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014356A8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x014356AC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x014356B0: ADRP x9, #0x35d3000        | X9 = 56438784 (0x35D3000);              
            // 0x014356B4: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x014356B8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x014356BC: LDR x9, [x9, #0xa78]       | X9 = 1152921504909828096;               
            // 0x014356C0: LDR x26, [x9]              | X26 = typeof(CameraShotMgr);            
            // 0x014356C4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x014356C8: TBZ w9, #0, #0x14356dc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x014356CC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x014356D0: CBNZ w9, #0x14356dc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x014356D4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x014356D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x014356DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014356E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014356E4: MOV x1, x26                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x014356E8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014356EC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x014356F0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x014356F4: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x014356F8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x014356FC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01435700: TBZ w9, #0, #0x1435714     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01435704: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01435708: CBNZ w9, #0x1435714        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143570C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01435710: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x01435714: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435718: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143571C: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x01435720: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x01435724: MOV x3, x24                | X3 = X3;//m1                            
            // 0x01435728: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143572C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01435730: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01435734: MOV x24, x0                | X24 = val_7;//m1                        
            // 0x01435738: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143573C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01435740: TBZ w9, #0, #0x1435754     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x01435744: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01435748: CBNZ w9, #0x1435754        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x0143574C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01435750: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_9:
            // 0x01435754: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435758: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143575C: MOV x1, x26                | X1 = val_6;//m1                         
            // 0x01435760: MOV x2, x24                | X2 = val_7;//m1                         
            // 0x01435764: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            object val_8 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            // 0x01435768: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x0143576C: CBZ x0, #0x14357d0         | if (val_8 == null) goto label_12;       
            if(val_8 == null)
            {
                goto label_12;
            }
            // 0x01435770: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x01435774: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x01435778: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143577C: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x01435780: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01435784: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01435788: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143578C: B.LO #0x14357a8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_11;
            // 0x01435790: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01435794: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x01435798: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143579C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x014357A0: MOV x24, x0                | X24 = val_8;//m1                        
            val_11 = val_8;
            // 0x014357A4: B.EQ #0x14357d0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_12;
            label_11:
            // 0x014357A8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014357AC: ADD x8, sp, #8             | X8 = (1152921510113563648 + 8) = 1152921510113563656 (0x100000014839D408);
            // 0x014357B0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014357B4: LDR x0, [sp, #8]           | X0 = val_10;                             //  find_add[1152921510113551744]
            // 0x014357B8: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x014357BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014357C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x014357C4: ADD x0, sp, #8             | X0 = (1152921510113563648 + 8) = 1152921510113563656 (0x100000014839D408);
            // 0x014357C8: BL #0x299a140              | 
            // 0x014357CC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_12:
            // 0x014357D0: CBNZ x19, #0x14357d8       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x014357D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014839D408, ????);
            label_13:
            // 0x014357D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014357DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014357E0: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x014357E4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014357E8: CBNZ x24, #0x14357f0       | if (0x0 != 0) goto label_14;            
            if(val_11 != 0)
            {
                goto label_14;
            }
            // 0x014357EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_14:
            // 0x014357F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014357F4: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x014357F8: MOV w1, w22                | W1 = val_4 + 4;//m1                     
            // 0x014357FC: MOV w2, w21                | W2 = val_3 + 4;//m1                     
            // 0x01435800: BL #0xd780d4               | val_11.PreviewCameraShot(mapId:  val_4 + 4, cameraShotId:  val_3 + 4);
            val_11.PreviewCameraShot(mapId:  val_4 + 4, cameraShotId:  val_3 + 4);
            // 0x01435804: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01435808: SUB sp, x29, #0x40         | SP = (1152921510113563728 - 64) = 1152921510113563664 (0x100000014839D410);
            // 0x0143580C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01435810: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01435814: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01435818: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0143581C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01435820: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01435824: MOV x19, x0                | 
            // 0x01435828: ADD x0, sp, #8             | 
            // 0x0143582C: BL #0x299a140              | 
            // 0x01435830: MOV x0, x19                | 
            // 0x01435834: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01435838 (21190712), len: 700  VirtAddr: 0x01435838 RVA: 0x01435838 token: 100664169 methodIndex: 30216 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* isCameraShotSkillFit_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            //  | 
            var val_15;
            //  | 
            bool val_16;
            //  | 
            var val_17;
            // 0x01435838: STP x28, x27, [sp, #-0x60]! | stack[1152921510113732992] = ???;  stack[1152921510113733000] = ???;  //  dest_result_addr=1152921510113732992 |  dest_result_addr=1152921510113733000
            // 0x0143583C: STP x26, x25, [sp, #0x10]  | stack[1152921510113733008] = ???;  stack[1152921510113733016] = ???;  //  dest_result_addr=1152921510113733008 |  dest_result_addr=1152921510113733016
            // 0x01435840: STP x24, x23, [sp, #0x20]  | stack[1152921510113733024] = ???;  stack[1152921510113733032] = ???;  //  dest_result_addr=1152921510113733024 |  dest_result_addr=1152921510113733032
            // 0x01435844: STP x22, x21, [sp, #0x30]  | stack[1152921510113733040] = ???;  stack[1152921510113733048] = ???;  //  dest_result_addr=1152921510113733040 |  dest_result_addr=1152921510113733048
            // 0x01435848: STP x20, x19, [sp, #0x40]  | stack[1152921510113733056] = ???;  stack[1152921510113733064] = ???;  //  dest_result_addr=1152921510113733056 |  dest_result_addr=1152921510113733064
            // 0x0143584C: STP x29, x30, [sp, #0x50]  | stack[1152921510113733072] = ???;  stack[1152921510113733080] = ???;  //  dest_result_addr=1152921510113733072 |  dest_result_addr=1152921510113733080
            // 0x01435850: ADD x29, sp, #0x50         | X29 = (1152921510113732992 + 80) = 1152921510113733072 (0x10000001483C69D0);
            // 0x01435854: SUB sp, sp, #0x10          | SP = (1152921510113732992 - 16) = 1152921510113732976 (0x10000001483C6970);
            // 0x01435858: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x0143585C: LDRB w8, [x19, #0x47]      | W8 = (bool)static_value_03737047;       
            // 0x01435860: MOV x24, x3                | X24 = X3;//m1                           
            // 0x01435864: MOV x23, x2                | X23 = X2;//m1                           
            // 0x01435868: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0143586C: TBNZ w8, #0, #0x1435888    | if (static_value_03737047 == true) goto label_0;
            // 0x01435870: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x01435874: LDR x8, [x8, #0xf98]       | X8 = 0x2B902C8;                         
            // 0x01435878: LDR w0, [x8]               | W0 = 0x1776;                            
            // 0x0143587C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1776, ????);     
            // 0x01435880: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01435884: STRB w8, [x19, #0x47]      | static_value_03737047 = true;            //  dest_result_addr=57897031
            label_0:
            // 0x01435888: CBNZ x20, #0x1435890       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143588C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1776, ????);     
            label_1:
            // 0x01435890: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435894: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01435898: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0143589C: MOV x25, x0                | X25 = val_1;//m1                        
            // 0x014358A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014358A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014358A8: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x014358AC: MOV x1, x23                | X1 = X2;//m1                            
            // 0x014358B0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014358B4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x014358B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014358BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014358C0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014358C4: MOV x1, x23                | X1 = X2;//m1                            
            // 0x014358C8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014358CC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x014358D0: CBNZ x21, #0x14358d8       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x014358D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x014358D8: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x014358DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014358E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014358E4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014358E8: MOV x1, x23                | X1 = X2;//m1                            
            // 0x014358EC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014358F0: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x014358F4: CBNZ x22, #0x14358fc       | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x014358F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x014358FC: LDR w22, [x22, #4]         | W22 = val_4 + 4;                        
            // 0x01435900: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435904: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435908: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x0143590C: MOV x1, x23                | X1 = X2;//m1                            
            // 0x01435910: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435914: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01435918: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0143591C: ADRP x9, #0x35d3000        | X9 = 56438784 (0x35D3000);              
            // 0x01435920: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x01435924: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01435928: LDR x9, [x9, #0xa78]       | X9 = 1152921504909828096;               
            // 0x0143592C: LDR x26, [x9]              | X26 = typeof(CameraShotMgr);            
            // 0x01435930: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01435934: TBZ w9, #0, #0x1435948     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01435938: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143593C: CBNZ w9, #0x1435948        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01435940: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01435944: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x01435948: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143594C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01435950: MOV x1, x26                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x01435954: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01435958: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x0143595C: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x01435960: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x01435964: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01435968: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0143596C: TBZ w9, #0, #0x1435980     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01435970: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01435974: CBNZ w9, #0x1435980        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01435978: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0143597C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x01435980: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435984: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01435988: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x0143598C: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x01435990: MOV x3, x24                | X3 = X3;//m1                            
            // 0x01435994: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01435998: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0143599C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014359A0: MOV x24, x0                | X24 = val_7;//m1                        
            // 0x014359A4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014359A8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014359AC: TBZ w9, #0, #0x14359c0     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x014359B0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014359B4: CBNZ w9, #0x14359c0        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x014359B8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014359BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_9:
            // 0x014359C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014359C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014359C8: MOV x1, x26                | X1 = val_6;//m1                         
            // 0x014359CC: MOV x2, x24                | X2 = val_7;//m1                         
            // 0x014359D0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            object val_8 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            // 0x014359D4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x014359D8: CBZ x0, #0x1435a3c         | if (val_8 == null) goto label_12;       
            if(val_8 == null)
            {
                goto label_12;
            }
            // 0x014359DC: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x014359E0: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x014359E4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x014359E8: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x014359EC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014359F0: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014359F4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014359F8: B.LO #0x1435a14            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_11;
            // 0x014359FC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01435A00: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x01435A04: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01435A08: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01435A0C: MOV x24, x0                | X24 = val_8;//m1                        
            val_15 = val_8;
            // 0x01435A10: B.EQ #0x1435a3c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_12;
            label_11:
            // 0x01435A14: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01435A18: ADD x8, sp, #8             | X8 = (1152921510113732976 + 8) = 1152921510113732984 (0x10000001483C6978);
            // 0x01435A1C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01435A20: LDR x0, [sp, #8]           | X0 = val_10;                             //  find_add[1152921510113721088]
            // 0x01435A24: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x01435A28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435A2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x01435A30: ADD x0, sp, #8             | X0 = (1152921510113732976 + 8) = 1152921510113732984 (0x10000001483C6978);
            // 0x01435A34: BL #0x299a140              | 
            // 0x01435A38: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_12:
            // 0x01435A3C: CBNZ x20, #0x1435a44       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x01435A40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001483C6978, ????);
            label_13:
            // 0x01435A44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01435A48: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01435A4C: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x01435A50: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01435A54: CBNZ x24, #0x1435a5c       | if (0x0 != 0) goto label_14;            
            if(val_15 != 0)
            {
                goto label_14;
            }
            // 0x01435A58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_14:
            // 0x01435A5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435A60: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x01435A64: MOV w1, w22                | W1 = val_4 + 4;//m1                     
            // 0x01435A68: MOV w2, w21                | W2 = val_3 + 4;//m1                     
            // 0x01435A6C: BL #0xd780f0               | X0 = val_15.isCameraShotSkillFit(effid:  val_4 + 4, scrid:  val_3 + 4);
            bool val_11 = val_15.isCameraShotSkillFit(effid:  val_4 + 4, scrid:  val_3 + 4);
            // 0x01435A70: MOV w20, w0                | W20 = val_11;//m1                       
            // 0x01435A74: CBZ x19, #0x1435a88        | if (val_2 == 0) goto label_15;          
            if(val_2 == 0)
            {
                goto label_15;
            }
            // 0x01435A78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01435A7C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01435A80: AND w20, w20, #1           | W20 = (val_11 & 1);                     
            val_16 = val_11;
            // 0x01435A84: B #0x1435a9c               |  goto label_16;                         
            goto label_16;
            label_15:
            // 0x01435A88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            // 0x01435A8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01435A90: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01435A94: AND w20, w20, #1           | W20 = (val_11 & 1);                     
            val_16 = val_11;
            // 0x01435A98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_16:
            // 0x01435A9C: STR w20, [x19, #4]         | mem2[0] = (val_11 & 1);                  //  dest_result_addr=0
            mem2[0] = val_16;
            // 0x01435AA0: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01435AA4: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_17 = 8;
            // 0x01435AA8: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x01435AAC: TBZ w9, #0, #0x1435abc     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_17;
            // 0x01435AB0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x01435AB4: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x01435AB8: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_17 = 219381744;
            label_17:
            // 0x01435ABC: ADD x0, x8, x19            | X0 = (val_17 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_12 = val_17 + val_2;
            // 0x01435AC0: SUB sp, x29, #0x50         | SP = (1152921510113733072 - 80) = 1152921510113732992 (0x10000001483C6980);
            // 0x01435AC4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01435AC8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01435ACC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01435AD0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01435AD4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01435AD8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01435ADC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_17 + val_2);
            return val_12;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01435AE0: MOV x19, x0                | 
            // 0x01435AE4: ADD x0, sp, #8             | 
            // 0x01435AE8: BL #0x299a140              | 
            // 0x01435AEC: MOV x0, x19                | 
            // 0x01435AF0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01435AF4 (21191412), len: 576  VirtAddr: 0x01435AF4 RVA: 0x01435AF4 token: 100664170 methodIndex: 30217 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* PreviewCameraShot_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x01435AF4: STP x26, x25, [sp, #-0x50]! | stack[1152921510113902352] = ???;  stack[1152921510113902360] = ???;  //  dest_result_addr=1152921510113902352 |  dest_result_addr=1152921510113902360
            // 0x01435AF8: STP x24, x23, [sp, #0x10]  | stack[1152921510113902368] = ???;  stack[1152921510113902376] = ???;  //  dest_result_addr=1152921510113902368 |  dest_result_addr=1152921510113902376
            // 0x01435AFC: STP x22, x21, [sp, #0x20]  | stack[1152921510113902384] = ???;  stack[1152921510113902392] = ???;  //  dest_result_addr=1152921510113902384 |  dest_result_addr=1152921510113902392
            // 0x01435B00: STP x20, x19, [sp, #0x30]  | stack[1152921510113902400] = ???;  stack[1152921510113902408] = ???;  //  dest_result_addr=1152921510113902400 |  dest_result_addr=1152921510113902408
            // 0x01435B04: STP x29, x30, [sp, #0x40]  | stack[1152921510113902416] = ???;  stack[1152921510113902424] = ???;  //  dest_result_addr=1152921510113902416 |  dest_result_addr=1152921510113902424
            // 0x01435B08: ADD x29, sp, #0x40         | X29 = (1152921510113902352 + 64) = 1152921510113902416 (0x10000001483EFF50);
            // 0x01435B0C: SUB sp, sp, #0x10          | SP = (1152921510113902352 - 16) = 1152921510113902336 (0x10000001483EFF00);
            // 0x01435B10: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01435B14: LDRB w8, [x20, #0x48]      | W8 = (bool)static_value_03737048;       
            // 0x01435B18: MOV x23, x3                | X23 = X3;//m1                           
            // 0x01435B1C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01435B20: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01435B24: TBNZ w8, #0, #0x1435b40    | if (static_value_03737048 == true) goto label_0;
            // 0x01435B28: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x01435B2C: LDR x8, [x8, #0x630]       | X8 = 0x2B902DC;                         
            // 0x01435B30: LDR w0, [x8]               | W0 = 0x177B;                            
            // 0x01435B34: BL #0x2782188              | X0 = sub_2782188( ?? 0x177B, ????);     
            // 0x01435B38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01435B3C: STRB w8, [x20, #0x48]      | static_value_03737048 = true;            //  dest_result_addr=57897032
            label_0:
            // 0x01435B40: CBNZ x19, #0x1435b48       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01435B44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x177B, ????);     
            label_1:
            // 0x01435B48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435B4C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435B50: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01435B54: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x01435B58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435B5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435B60: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01435B64: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01435B68: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435B6C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01435B70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435B74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435B78: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01435B7C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01435B80: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435B84: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01435B88: CBNZ x21, #0x1435b90       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x01435B8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x01435B90: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x01435B94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435B98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435B9C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01435BA0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01435BA4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435BA8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01435BAC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01435BB0: ADRP x9, #0x35d3000        | X9 = 56438784 (0x35D3000);              
            // 0x01435BB4: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x01435BB8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01435BBC: LDR x9, [x9, #0xa78]       | X9 = 1152921504909828096;               
            // 0x01435BC0: LDR x25, [x9]              | X25 = typeof(CameraShotMgr);            
            // 0x01435BC4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01435BC8: TBZ w9, #0, #0x1435bdc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01435BCC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01435BD0: CBNZ w9, #0x1435bdc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01435BD4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01435BD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x01435BDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435BE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01435BE4: MOV x1, x25                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x01435BE8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01435BEC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01435BF0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01435BF4: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x01435BF8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01435BFC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01435C00: TBZ w9, #0, #0x1435c14     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x01435C04: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01435C08: CBNZ w9, #0x1435c14        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x01435C0C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01435C10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x01435C14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435C18: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01435C1C: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x01435C20: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x01435C24: MOV x3, x23                | X3 = X3;//m1                            
            // 0x01435C28: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01435C2C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01435C30: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01435C34: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x01435C38: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01435C3C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01435C40: TBZ w9, #0, #0x1435c54     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01435C44: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01435C48: CBNZ w9, #0x1435c54        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01435C4C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01435C50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x01435C54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435C58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435C5C: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x01435C60: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x01435C64: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x01435C68: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x01435C6C: CBZ x0, #0x1435cd0         | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x01435C70: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x01435C74: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x01435C78: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01435C7C: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x01435C80: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01435C84: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01435C88: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01435C8C: B.LO #0x1435ca8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x01435C90: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01435C94: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x01435C98: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01435C9C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01435CA0: MOV x23, x0                | X23 = val_7;//m1                        
            val_10 = val_7;
            // 0x01435CA4: B.EQ #0x1435cd0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x01435CA8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01435CAC: ADD x8, sp, #8             | X8 = (1152921510113902336 + 8) = 1152921510113902344 (0x10000001483EFF08);
            // 0x01435CB0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01435CB4: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510113890432]
            // 0x01435CB8: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x01435CBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435CC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x01435CC4: ADD x0, sp, #8             | X0 = (1152921510113902336 + 8) = 1152921510113902344 (0x10000001483EFF08);
            // 0x01435CC8: BL #0x299a140              | 
            // 0x01435CCC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_11:
            // 0x01435CD0: CBNZ x19, #0x1435cd8       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01435CD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001483EFF08, ????);
            label_12:
            // 0x01435CD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01435CDC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435CE0: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x01435CE4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01435CE8: CBNZ x23, #0x1435cf0       | if (0x0 != 0) goto label_13;            
            if(val_10 != 0)
            {
                goto label_13;
            }
            // 0x01435CEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x01435CF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01435CF4: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x01435CF8: MOV w1, w21                | W1 = val_3 + 4;//m1                     
            // 0x01435CFC: BL #0xd77ec4               | val_10.PreviewCameraShot(cameraShotId:  val_3 + 4);
            val_10.PreviewCameraShot(cameraShotId:  val_3 + 4);
            // 0x01435D00: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01435D04: SUB sp, x29, #0x40         | SP = (1152921510113902416 - 64) = 1152921510113902352 (0x10000001483EFF10);
            // 0x01435D08: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01435D0C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01435D10: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01435D14: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01435D18: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01435D1C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01435D20: MOV x19, x0                | 
            // 0x01435D24: ADD x0, sp, #8             | 
            // 0x01435D28: BL #0x299a140              | 
            // 0x01435D2C: MOV x0, x19                | 
            // 0x01435D30: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01435D34 (21191988), len: 528  VirtAddr: 0x01435D34 RVA: 0x01435D34 token: 100664171 methodIndex: 30218 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* PreviewCameraShot_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01435D34: STP x24, x23, [sp, #-0x40]! | stack[1152921510114071712] = ???;  stack[1152921510114071720] = ???;  //  dest_result_addr=1152921510114071712 |  dest_result_addr=1152921510114071720
            // 0x01435D38: STP x22, x21, [sp, #0x10]  | stack[1152921510114071728] = ???;  stack[1152921510114071736] = ???;  //  dest_result_addr=1152921510114071728 |  dest_result_addr=1152921510114071736
            // 0x01435D3C: STP x20, x19, [sp, #0x20]  | stack[1152921510114071744] = ???;  stack[1152921510114071752] = ???;  //  dest_result_addr=1152921510114071744 |  dest_result_addr=1152921510114071752
            // 0x01435D40: STP x29, x30, [sp, #0x30]  | stack[1152921510114071760] = ???;  stack[1152921510114071768] = ???;  //  dest_result_addr=1152921510114071760 |  dest_result_addr=1152921510114071768
            // 0x01435D44: ADD x29, sp, #0x30         | X29 = (1152921510114071712 + 48) = 1152921510114071760 (0x10000001484194D0);
            // 0x01435D48: SUB sp, sp, #0x10          | SP = (1152921510114071712 - 16) = 1152921510114071696 (0x1000000148419490);
            // 0x01435D4C: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01435D50: LDRB w8, [x20, #0x49]      | W8 = (bool)static_value_03737049;       
            // 0x01435D54: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01435D58: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01435D5C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01435D60: TBNZ w8, #0, #0x1435d7c    | if (static_value_03737049 == true) goto label_0;
            // 0x01435D64: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x01435D68: LDR x8, [x8, #0x5b8]       | X8 = 0x2B902E0;                         
            // 0x01435D6C: LDR w0, [x8]               | W0 = 0x177C;                            
            // 0x01435D70: BL #0x2782188              | X0 = sub_2782188( ?? 0x177C, ????);     
            // 0x01435D74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01435D78: STRB w8, [x20, #0x49]      | static_value_03737049 = true;            //  dest_result_addr=57897033
            label_0:
            // 0x01435D7C: CBNZ x19, #0x1435d84       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01435D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x177C, ????);     
            label_1:
            // 0x01435D84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435D88: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435D8C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01435D90: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01435D94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435D98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435D9C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01435DA0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01435DA4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435DA8: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01435DAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435DB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435DB4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01435DB8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01435DBC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435DC0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01435DC4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01435DC8: ADRP x9, #0x35d3000        | X9 = 56438784 (0x35D3000);              
            // 0x01435DCC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01435DD0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01435DD4: LDR x9, [x9, #0xa78]       | X9 = 1152921504909828096;               
            // 0x01435DD8: LDR x24, [x9]              | X24 = typeof(CameraShotMgr);            
            // 0x01435DDC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01435DE0: TBZ w9, #0, #0x1435df4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01435DE4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01435DE8: CBNZ w9, #0x1435df4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01435DEC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01435DF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01435DF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435DF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01435DFC: MOV x1, x24                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x01435E00: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01435E04: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01435E08: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01435E0C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01435E10: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01435E14: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01435E18: TBZ w9, #0, #0x1435e2c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01435E1C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01435E20: CBNZ w9, #0x1435e2c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01435E24: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01435E28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01435E2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435E30: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01435E34: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01435E38: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01435E3C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01435E40: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01435E44: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01435E48: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01435E4C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01435E50: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01435E54: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01435E58: TBZ w9, #0, #0x1435e6c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01435E5C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01435E60: CBNZ w9, #0x1435e6c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01435E64: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01435E68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01435E6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435E70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435E74: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01435E78: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01435E7C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01435E80: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x01435E84: CBZ x0, #0x1435ee8         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01435E88: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x01435E8C: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x01435E90: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01435E94: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x01435E98: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01435E9C: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01435EA0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01435EA4: B.LO #0x1435ec0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01435EA8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01435EAC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x01435EB0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01435EB4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01435EB8: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01435EBC: B.EQ #0x1435ee8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01435EC0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01435EC4: ADD x8, sp, #8             | X8 = (1152921510114071696 + 8) = 1152921510114071704 (0x1000000148419498);
            // 0x01435EC8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01435ECC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510114059776]
            // 0x01435ED0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01435ED4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435ED8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01435EDC: ADD x0, sp, #8             | X0 = (1152921510114071696 + 8) = 1152921510114071704 (0x1000000148419498);
            // 0x01435EE0: BL #0x299a140              | 
            // 0x01435EE4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x01435EE8: CBNZ x19, #0x1435ef0       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01435EEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148419498, ????);
            label_11:
            // 0x01435EF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01435EF4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435EF8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01435EFC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01435F00: CBNZ x22, #0x1435f08       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01435F04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01435F08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435F0C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01435F10: BL #0xd77e30               | val_9.PreviewCameraShot();              
            val_9.PreviewCameraShot();
            // 0x01435F14: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01435F18: SUB sp, x29, #0x30         | SP = (1152921510114071760 - 48) = 1152921510114071712 (0x10000001484194A0);
            // 0x01435F1C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01435F20: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01435F24: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01435F28: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01435F2C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01435F30: MOV x19, x0                | 
            // 0x01435F34: ADD x0, sp, #8             | 
            // 0x01435F38: BL #0x299a140              | 
            // 0x01435F3C: MOV x0, x19                | 
            // 0x01435F40: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01435F44 (21192516), len: 1012  VirtAddr: 0x01435F44 RVA: 0x01435F44 token: 100664172 methodIndex: 30219 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* previewInEditor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            var val_19;
            //  | 
            CameraAniMap val_20;
            //  | 
            cameraShotCfg[] val_21;
            //  | 
            var val_22;
            // 0x01435F44: STP x28, x27, [sp, #-0x60]! | stack[1152921510114265600] = ???;  stack[1152921510114265608] = ???;  //  dest_result_addr=1152921510114265600 |  dest_result_addr=1152921510114265608
            // 0x01435F48: STP x26, x25, [sp, #0x10]  | stack[1152921510114265616] = ???;  stack[1152921510114265624] = ???;  //  dest_result_addr=1152921510114265616 |  dest_result_addr=1152921510114265624
            // 0x01435F4C: STP x24, x23, [sp, #0x20]  | stack[1152921510114265632] = ???;  stack[1152921510114265640] = ???;  //  dest_result_addr=1152921510114265632 |  dest_result_addr=1152921510114265640
            // 0x01435F50: STP x22, x21, [sp, #0x30]  | stack[1152921510114265648] = ???;  stack[1152921510114265656] = ???;  //  dest_result_addr=1152921510114265648 |  dest_result_addr=1152921510114265656
            // 0x01435F54: STP x20, x19, [sp, #0x40]  | stack[1152921510114265664] = ???;  stack[1152921510114265672] = ???;  //  dest_result_addr=1152921510114265664 |  dest_result_addr=1152921510114265672
            // 0x01435F58: STP x29, x30, [sp, #0x50]  | stack[1152921510114265680] = ???;  stack[1152921510114265688] = ???;  //  dest_result_addr=1152921510114265680 |  dest_result_addr=1152921510114265688
            // 0x01435F5C: ADD x29, sp, #0x50         | X29 = (1152921510114265600 + 80) = 1152921510114265680 (0x1000000148448A50);
            // 0x01435F60: SUB sp, sp, #0x20          | SP = (1152921510114265600 - 32) = 1152921510114265568 (0x10000001484489E0);
            // 0x01435F64: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01435F68: LDRB w8, [x20, #0x4a]      | W8 = (bool)static_value_0373704A;       
            // 0x01435F6C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x01435F70: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01435F74: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01435F78: TBNZ w8, #0, #0x1435f94    | if (static_value_0373704A == true) goto label_0;
            // 0x01435F7C: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01435F80: LDR x8, [x8, #0xc30]       | X8 = 0x2B902E4;                         
            // 0x01435F84: LDR w0, [x8]               | W0 = 0x177D;                            
            // 0x01435F88: BL #0x2782188              | X0 = sub_2782188( ?? 0x177D, ????);     
            // 0x01435F8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01435F90: STRB w8, [x20, #0x4a]      | static_value_0373704A = true;            //  dest_result_addr=57897034
            label_0:
            // 0x01435F94: CBNZ x19, #0x1435f9c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01435F98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x177D, ????);     
            label_1:
            // 0x01435F9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01435FA0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01435FA4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01435FA8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01435FAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435FB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435FB4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01435FB8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01435FBC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435FC0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01435FC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01435FC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01435FCC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01435FD0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01435FD4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01435FD8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01435FDC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01435FE0: ADRP x9, #0x3646000        | X9 = 56909824 (0x3646000);              
            // 0x01435FE4: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x01435FE8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01435FEC: LDR x9, [x9, #0x248]       | X9 = 1152921504888528896;               
            // 0x01435FF0: LDR x24, [x9]              | X24 = typeof(CameraAniMap);             
            // 0x01435FF4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01435FF8: TBZ w9, #0, #0x143600c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01435FFC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01436000: CBNZ w9, #0x143600c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01436004: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01436008: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0143600C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436010: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436014: MOV x1, x24                | X1 = 1152921504888528896 (0x1000000010CA2000);//ML01
            // 0x01436018: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143601C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01436020: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01436024: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01436028: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143602C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01436030: TBZ w9, #0, #0x1436044     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01436034: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01436038: CBNZ w9, #0x1436044        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0143603C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01436040: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01436044: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436048: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143604C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01436050: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01436054: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01436058: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x0143605C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01436060: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01436064: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01436068: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143606C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01436070: TBZ w9, #0, #0x1436084     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01436074: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01436078: CBNZ w9, #0x1436084        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143607C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01436080: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01436084: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436088: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143608C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01436090: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01436094: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01436098: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            // 0x0143609C: CBZ x0, #0x1436100         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x014360A0: ADRP x9, #0x3653000        | X9 = 56963072 (0x3653000);              
            // 0x014360A4: LDR x9, [x9, #0xa18]       | X9 = 1152921504888528896;               
            // 0x014360A8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x014360AC: LDR x1, [x9]               | X1 = typeof(CameraAniMap);              
            // 0x014360B0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014360B4: LDRB w9, [x1, #0x104]      | W9 = CameraAniMap.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014360B8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraAniMap.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014360BC: B.LO #0x14360d8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraAniMap.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x014360C0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014360C4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraAniMap.__il2cppRuntimeField_typeHier
            // 0x014360C8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraAniMap.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014360CC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraAniMap.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraAniMap))
            // 0x014360D0: MOV x24, x0                | X24 = val_6;//m1                        
            val_20 = val_6;
            // 0x014360D4: B.EQ #0x1436100            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraAniMap.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x014360D8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014360DC: ADD x8, sp, #8             | X8 = (1152921510114265568 + 8) = 1152921510114265576 (0x10000001484489E8);
            // 0x014360E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014360E4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510114253696]
            // 0x014360E8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x014360EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014360F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x014360F4: ADD x0, sp, #8             | X0 = (1152921510114265568 + 8) = 1152921510114265576 (0x10000001484489E8);
            // 0x014360F8: BL #0x299a140              | 
            // 0x014360FC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_10:
            // 0x01436100: CBNZ x19, #0x1436108       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01436104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001484489E8, ????);
            label_11:
            // 0x01436108: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143610C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01436110: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01436114: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01436118: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143611C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436120: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01436124: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01436128: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143612C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x01436130: LDR x8, [x8, #0x858]       | X8 = 1152921508129291760;               
            // 0x01436134: MOV x26, x0                | X26 = val_9;//m1                        
            // 0x01436138: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143613C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436140: LDR x1, [x8]               | X1 = typeof(cameraShotCfg[]);           
            // 0x01436144: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01436148: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x0143614C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436150: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01436154: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x01436158: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143615C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01436160: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x01436164: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x01436168: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143616C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436170: MOV x1, x25                | X1 = val_10;//m1                        
            // 0x01436174: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x01436178: MOV x27, x0                | X27 = val_12;//m1                       
            // 0x0143617C: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x01436180: CBZ x27, #0x14361d4        | if (val_12 == null) goto label_13;      
            if(val_12 == null)
            {
                goto label_13;
            }
            // 0x01436184: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x01436188: LDR x8, [x8, #0x378]       | X8 = 1152921508129291760;               
            // 0x0143618C: MOV x0, x27                | X0 = val_12;//m1                        
            // 0x01436190: LDR x28, [x8]              | X28 = typeof(cameraShotCfg[]);          
            // 0x01436194: MOV x1, x28                | X1 = 1152921508129291760 (0x10000000D1F43DF0);//ML01
            // 0x01436198: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x0143619C: MOV x25, x0                | X25 = val_12;//m1                       
            val_21 = val_12;
            // 0x014361A0: CBNZ x25, #0x14361d4       | if (val_12 != null) goto label_13;      
            if(val_21 != null)
            {
                goto label_13;
            }
            // 0x014361A4: LDR x8, [x27]              | X8 = typeof(System.Object);             
            // 0x014361A8: MOV x1, x28                | X1 = 1152921508129291760 (0x10000000D1F43DF0);//ML01
            // 0x014361AC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014361B0: ADD x8, sp, #0x10          | X8 = (1152921510114265568 + 16) = 1152921510114265584 (0x10000001484489F0);
            // 0x014361B4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014361B8: LDR x0, [sp, #0x10]        | X0 = val_13;                             //  find_add[1152921510114253696]
            // 0x014361BC: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x014361C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014361C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x014361C8: ADD x0, sp, #0x10          | X0 = (1152921510114265568 + 16) = 1152921510114265584 (0x10000001484489F0);
            // 0x014361CC: BL #0x299a140              | 
            // 0x014361D0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_13:
            // 0x014361D4: CBNZ x19, #0x14361dc       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x014361D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001484489F0, ????);
            label_14:
            // 0x014361DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014361E0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014361E4: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x014361E8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014361EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014361F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014361F4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x014361F8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014361FC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01436200: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x01436204: LDR x8, [x8, #0xa78]       | X8 = 1152921504909828096;               
            // 0x01436208: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x0143620C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436210: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436214: LDR x1, [x8]               | X1 = typeof(CameraShotMgr);             
            // 0x01436218: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143621C: MOV x26, x0                | X26 = val_15;//m1                       
            // 0x01436220: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436224: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01436228: MOV x1, x22                | X1 = val_14;//m1                        
            // 0x0143622C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01436230: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01436234: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_16 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x01436238: MOV x2, x0                 | X2 = val_16;//m1                        
            // 0x0143623C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436240: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436244: MOV x1, x26                | X1 = val_15;//m1                        
            // 0x01436248: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            object val_17 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            // 0x0143624C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x01436250: CBZ x0, #0x14362b4         | if (val_17 == null) goto label_17;      
            if(val_17 == null)
            {
                goto label_17;
            }
            // 0x01436254: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x01436258: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x0143625C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01436260: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x01436264: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01436268: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143626C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01436270: B.LO #0x143628c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x01436274: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01436278: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x0143627C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01436280: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01436284: MOV x21, x0                | X21 = val_17;//m1                       
            val_22 = val_17;
            // 0x01436288: B.EQ #0x14362b4            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
            label_16:
            // 0x0143628C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01436290: ADD x8, sp, #0x18          | X8 = (1152921510114265568 + 24) = 1152921510114265592 (0x10000001484489F8);
            // 0x01436294: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01436298: LDR x0, [sp, #0x18]        | X0 = val_19;                             //  find_add[1152921510114253696]
            // 0x0143629C: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x014362A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014362A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x014362A8: ADD x0, sp, #0x18          | X0 = (1152921510114265568 + 24) = 1152921510114265592 (0x10000001484489F8);
            // 0x014362AC: BL #0x299a140              | 
            // 0x014362B0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_17:
            // 0x014362B4: CBNZ x19, #0x14362bc       | if (X1 != 0) goto label_18;             
            if(X1 != 0)
            {
                goto label_18;
            }
            // 0x014362B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001484489F8, ????);
            label_18:
            // 0x014362BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014362C0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014362C4: MOV x1, x22                | X1 = val_14;//m1                        
            // 0x014362C8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014362CC: CBNZ x21, #0x14362d4       | if (0x0 != 0) goto label_19;            
            if(val_22 != 0)
            {
                goto label_19;
            }
            // 0x014362D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_19:
            // 0x014362D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014362D8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x014362DC: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x014362E0: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x014362E4: BL #0xd7b8a8               | val_22.previewInEditor(cameraShotCfgList:  val_21, curAniMap:  val_20);
            val_22.previewInEditor(cameraShotCfgList:  val_21, curAniMap:  val_20);
            // 0x014362E8: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x014362EC: SUB sp, x29, #0x50         | SP = (1152921510114265680 - 80) = 1152921510114265600 (0x1000000148448A00);
            // 0x014362F0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x014362F4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x014362F8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x014362FC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01436300: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01436304: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01436308: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0143630C: MOV x19, x0                | 
            // 0x01436310: ADD x0, sp, #8             | 
            // 0x01436314: B #0x143632c               | 
            // 0x01436318: MOV x19, x0                | 
            // 0x0143631C: ADD x0, sp, #0x18          | 
            // 0x01436320: B #0x143632c               | 
            // 0x01436324: MOV x19, x0                | 
            // 0x01436328: ADD x0, sp, #0x10          | 
            label_21:
            // 0x0143632C: BL #0x299a140              | 
            // 0x01436330: MOV x0, x19                | 
            // 0x01436334: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01436338 (21193528), len: 528  VirtAddr: 0x01436338 RVA: 0x01436338 token: 100664173 methodIndex: 30220 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Open_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01436338: STP x24, x23, [sp, #-0x40]! | stack[1152921510114459552] = ???;  stack[1152921510114459560] = ???;  //  dest_result_addr=1152921510114459552 |  dest_result_addr=1152921510114459560
            // 0x0143633C: STP x22, x21, [sp, #0x10]  | stack[1152921510114459568] = ???;  stack[1152921510114459576] = ???;  //  dest_result_addr=1152921510114459568 |  dest_result_addr=1152921510114459576
            // 0x01436340: STP x20, x19, [sp, #0x20]  | stack[1152921510114459584] = ???;  stack[1152921510114459592] = ???;  //  dest_result_addr=1152921510114459584 |  dest_result_addr=1152921510114459592
            // 0x01436344: STP x29, x30, [sp, #0x30]  | stack[1152921510114459600] = ???;  stack[1152921510114459608] = ???;  //  dest_result_addr=1152921510114459600 |  dest_result_addr=1152921510114459608
            // 0x01436348: ADD x29, sp, #0x30         | X29 = (1152921510114459552 + 48) = 1152921510114459600 (0x1000000148477FD0);
            // 0x0143634C: SUB sp, sp, #0x10          | SP = (1152921510114459552 - 16) = 1152921510114459536 (0x1000000148477F90);
            // 0x01436350: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01436354: LDRB w8, [x20, #0x4b]      | W8 = (bool)static_value_0373704B;       
            // 0x01436358: MOV x22, x3                | X22 = X3;//m1                           
            // 0x0143635C: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01436360: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01436364: TBNZ w8, #0, #0x1436380    | if (static_value_0373704B == true) goto label_0;
            // 0x01436368: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x0143636C: LDR x8, [x8, #0xbd0]       | X8 = 0x2B902D4;                         
            // 0x01436370: LDR w0, [x8]               | W0 = 0x1779;                            
            // 0x01436374: BL #0x2782188              | X0 = sub_2782188( ?? 0x1779, ????);     
            // 0x01436378: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143637C: STRB w8, [x20, #0x4b]      | static_value_0373704B = true;            //  dest_result_addr=57897035
            label_0:
            // 0x01436380: CBNZ x19, #0x1436388       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01436384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1779, ????);     
            label_1:
            // 0x01436388: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143638C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01436390: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01436394: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01436398: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143639C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014363A0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014363A4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014363A8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014363AC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x014363B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014363B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014363B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014363BC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014363C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014363C4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x014363C8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x014363CC: ADRP x9, #0x35d3000        | X9 = 56438784 (0x35D3000);              
            // 0x014363D0: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x014363D4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x014363D8: LDR x9, [x9, #0xa78]       | X9 = 1152921504909828096;               
            // 0x014363DC: LDR x24, [x9]              | X24 = typeof(CameraShotMgr);            
            // 0x014363E0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x014363E4: TBZ w9, #0, #0x14363f8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x014363E8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x014363EC: CBNZ w9, #0x14363f8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x014363F0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x014363F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x014363F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014363FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436400: MOV x1, x24                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x01436404: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01436408: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0143640C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01436410: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01436414: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01436418: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0143641C: TBZ w9, #0, #0x1436430     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01436420: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01436424: CBNZ w9, #0x1436430        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01436428: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0143642C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01436430: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436434: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01436438: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x0143643C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01436440: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01436444: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01436448: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0143644C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01436450: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01436454: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01436458: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0143645C: TBZ w9, #0, #0x1436470     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01436460: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01436464: CBNZ w9, #0x1436470        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01436468: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0143646C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01436470: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436474: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436478: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0143647C: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01436480: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01436484: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x01436488: CBZ x0, #0x14364ec         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x0143648C: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x01436490: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x01436494: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01436498: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x0143649C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014364A0: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014364A4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014364A8: B.LO #0x14364c4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x014364AC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014364B0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x014364B4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014364B8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x014364BC: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x014364C0: B.EQ #0x14364ec            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x014364C4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014364C8: ADD x8, sp, #8             | X8 = (1152921510114459536 + 8) = 1152921510114459544 (0x1000000148477F98);
            // 0x014364CC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014364D0: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510114447616]
            // 0x014364D4: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x014364D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014364DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x014364E0: ADD x0, sp, #8             | X0 = (1152921510114459536 + 8) = 1152921510114459544 (0x1000000148477F98);
            // 0x014364E4: BL #0x299a140              | 
            // 0x014364E8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x014364EC: CBNZ x19, #0x14364f4       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x014364F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148477F98, ????);
            label_11:
            // 0x014364F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014364F8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014364FC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01436500: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01436504: CBNZ x22, #0x143650c       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01436508: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x0143650C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01436510: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01436514: BL #0xd7d570               | val_9.Open();                           
            val_9.Open();
            // 0x01436518: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0143651C: SUB sp, x29, #0x30         | SP = (1152921510114459600 - 48) = 1152921510114459552 (0x1000000148477FA0);
            // 0x01436520: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01436524: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01436528: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0143652C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01436530: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01436534: MOV x19, x0                | 
            // 0x01436538: ADD x0, sp, #8             | 
            // 0x0143653C: BL #0x299a140              | 
            // 0x01436540: MOV x0, x19                | 
            // 0x01436544: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01436548 (21194056), len: 776  VirtAddr: 0x01436548 RVA: 0x01436548 token: 100664174 methodIndex: 30221 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* JumpAllStory_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            CEvent.ZEvent val_15;
            //  | 
            var val_16;
            // 0x01436548: STP x26, x25, [sp, #-0x50]! | stack[1152921510114641168] = ???;  stack[1152921510114641176] = ???;  //  dest_result_addr=1152921510114641168 |  dest_result_addr=1152921510114641176
            // 0x0143654C: STP x24, x23, [sp, #0x10]  | stack[1152921510114641184] = ???;  stack[1152921510114641192] = ???;  //  dest_result_addr=1152921510114641184 |  dest_result_addr=1152921510114641192
            // 0x01436550: STP x22, x21, [sp, #0x20]  | stack[1152921510114641200] = ???;  stack[1152921510114641208] = ???;  //  dest_result_addr=1152921510114641200 |  dest_result_addr=1152921510114641208
            // 0x01436554: STP x20, x19, [sp, #0x30]  | stack[1152921510114641216] = ???;  stack[1152921510114641224] = ???;  //  dest_result_addr=1152921510114641216 |  dest_result_addr=1152921510114641224
            // 0x01436558: STP x29, x30, [sp, #0x40]  | stack[1152921510114641232] = ???;  stack[1152921510114641240] = ???;  //  dest_result_addr=1152921510114641232 |  dest_result_addr=1152921510114641240
            // 0x0143655C: ADD x29, sp, #0x40         | X29 = (1152921510114641168 + 64) = 1152921510114641232 (0x10000001484A4550);
            // 0x01436560: SUB sp, sp, #0x10          | SP = (1152921510114641168 - 16) = 1152921510114641152 (0x10000001484A4500);
            // 0x01436564: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01436568: LDRB w8, [x20, #0x4c]      | W8 = (bool)static_value_0373704C;       
            // 0x0143656C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x01436570: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01436574: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01436578: TBNZ w8, #0, #0x1436594    | if (static_value_0373704C == true) goto label_0;
            // 0x0143657C: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x01436580: LDR x8, [x8, #0x4e0]       | X8 = 0x2B902CC;                         
            // 0x01436584: LDR w0, [x8]               | W0 = 0x1777;                            
            // 0x01436588: BL #0x2782188              | X0 = sub_2782188( ?? 0x1777, ????);     
            // 0x0143658C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01436590: STRB w8, [x20, #0x4c]      | static_value_0373704C = true;            //  dest_result_addr=57897036
            label_0:
            // 0x01436594: CBNZ x19, #0x143659c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01436598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1777, ????);     
            label_1:
            // 0x0143659C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014365A0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014365A4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x014365A8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x014365AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014365B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014365B4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014365B8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014365BC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014365C0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x014365C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014365C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014365CC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014365D0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014365D4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014365D8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x014365DC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x014365E0: ADRP x9, #0x3615000        | X9 = 56709120 (0x3615000);              
            // 0x014365E4: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x014365E8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x014365EC: LDR x9, [x9, #0x668]       | X9 = 1152921504898326528;               
            // 0x014365F0: LDR x25, [x9]              | X25 = typeof(CEvent.ZEvent);            
            // 0x014365F4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x014365F8: TBZ w9, #0, #0x143660c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x014365FC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01436600: CBNZ w9, #0x143660c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01436604: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01436608: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0143660C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436610: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436614: MOV x1, x25                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x01436618: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143661C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01436620: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01436624: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x01436628: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143662C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01436630: TBZ w9, #0, #0x1436644     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01436634: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01436638: CBNZ w9, #0x1436644        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0143663C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01436640: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01436644: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436648: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143664C: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x01436650: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01436654: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01436658: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143665C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01436660: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01436664: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01436668: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143666C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01436670: TBZ w9, #0, #0x1436684     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01436674: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01436678: CBNZ w9, #0x1436684        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143667C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01436680: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01436684: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436688: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143668C: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x01436690: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01436694: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01436698: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x0143669C: CBZ x0, #0x1436700         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x014366A0: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x014366A4: LDR x9, [x9, #0x440]       | X9 = 1152921504898326528;               
            // 0x014366A8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x014366AC: LDR x1, [x9]               | X1 = typeof(CEvent.ZEvent);             
            // 0x014366B0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014366B4: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014366B8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014366BC: B.LO #0x14366d8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x014366C0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014366C4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHie
            // 0x014366C8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014366CC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x014366D0: MOV x25, x0                | X25 = val_6;//m1                        
            val_15 = val_6;
            // 0x014366D4: B.EQ #0x1436700            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x014366D8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014366DC: MOV x8, sp                 | X8 = 1152921510114641152 (0x10000001484A4500);//ML01
            // 0x014366E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014366E4: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510114629248]
            // 0x014366E8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x014366EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014366F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x014366F4: MOV x0, sp                 | X0 = 1152921510114641152 (0x10000001484A4500);//ML01
            // 0x014366F8: BL #0x299a140              | 
            // 0x014366FC: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x01436700: CBNZ x19, #0x1436708       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01436704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001484A4500, ????);
            label_11:
            // 0x01436708: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143670C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01436710: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x01436714: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01436718: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143671C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436720: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01436724: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01436728: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143672C: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x01436730: LDR x8, [x8, #0xa78]       | X8 = 1152921504909828096;               
            // 0x01436734: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x01436738: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143673C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436740: LDR x1, [x8]               | X1 = typeof(CameraShotMgr);             
            // 0x01436744: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01436748: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x0143674C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436750: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01436754: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x01436758: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143675C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01436760: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01436764: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x01436768: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143676C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436770: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x01436774: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x01436778: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x0143677C: CBZ x0, #0x14367e0         | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x01436780: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x01436784: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x01436788: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143678C: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x01436790: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01436794: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01436798: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143679C: B.LO #0x14367b8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x014367A0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014367A4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x014367A8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014367AC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x014367B0: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x014367B4: B.EQ #0x14367e0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x014367B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014367BC: ADD x8, sp, #8             | X8 = (1152921510114641152 + 8) = 1152921510114641160 (0x10000001484A4508);
            // 0x014367C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014367C4: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510114629248]
            // 0x014367C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x014367CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014367D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x014367D4: ADD x0, sp, #8             | X0 = (1152921510114641152 + 8) = 1152921510114641160 (0x10000001484A4508);
            // 0x014367D8: BL #0x299a140              | 
            // 0x014367DC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_14:
            // 0x014367E0: CBNZ x19, #0x14367e8       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x014367E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001484A4508, ????);
            label_15:
            // 0x014367E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014367EC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014367F0: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x014367F4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014367F8: CBNZ x21, #0x1436800       | if (0x0 != 0) goto label_16;            
            if(val_16 != 0)
            {
                goto label_16;
            }
            // 0x014367FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x01436800: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436804: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01436808: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x0143680C: BL #0xd7d664               | val_16.JumpAllStory(e:  val_15);        
            val_16.JumpAllStory(e:  val_15);
            // 0x01436810: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01436814: SUB sp, x29, #0x40         | SP = (1152921510114641232 - 64) = 1152921510114641168 (0x10000001484A4510);
            // 0x01436818: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0143681C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01436820: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01436824: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01436828: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0143682C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01436830: MOV x19, x0                | 
            // 0x01436834: MOV x0, sp                 | 
            // 0x01436838: B #0x1436844               | 
            // 0x0143683C: MOV x19, x0                | 
            // 0x01436840: ADD x0, sp, #8             | 
            label_17:
            // 0x01436844: BL #0x299a140              | 
            // 0x01436848: MOV x0, x19                | 
            // 0x0143684C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01436850 (21194832), len: 528  VirtAddr: 0x01436850 RVA: 0x01436850 token: 100664175 methodIndex: 30222 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Close_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01436850: STP x24, x23, [sp, #-0x40]! | stack[1152921510114822816] = ???;  stack[1152921510114822824] = ???;  //  dest_result_addr=1152921510114822816 |  dest_result_addr=1152921510114822824
            // 0x01436854: STP x22, x21, [sp, #0x10]  | stack[1152921510114822832] = ???;  stack[1152921510114822840] = ???;  //  dest_result_addr=1152921510114822832 |  dest_result_addr=1152921510114822840
            // 0x01436858: STP x20, x19, [sp, #0x20]  | stack[1152921510114822848] = ???;  stack[1152921510114822856] = ???;  //  dest_result_addr=1152921510114822848 |  dest_result_addr=1152921510114822856
            // 0x0143685C: STP x29, x30, [sp, #0x30]  | stack[1152921510114822864] = ???;  stack[1152921510114822872] = ???;  //  dest_result_addr=1152921510114822864 |  dest_result_addr=1152921510114822872
            // 0x01436860: ADD x29, sp, #0x30         | X29 = (1152921510114822816 + 48) = 1152921510114822864 (0x10000001484D0AD0);
            // 0x01436864: SUB sp, sp, #0x10          | SP = (1152921510114822816 - 16) = 1152921510114822800 (0x10000001484D0A90);
            // 0x01436868: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143686C: LDRB w8, [x20, #0x4d]      | W8 = (bool)static_value_0373704D;       
            // 0x01436870: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01436874: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01436878: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143687C: TBNZ w8, #0, #0x1436898    | if (static_value_0373704D == true) goto label_0;
            // 0x01436880: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x01436884: LDR x8, [x8, #0xcb8]       | X8 = 0x2B902A0;                         
            // 0x01436888: LDR w0, [x8]               | W0 = 0x176C;                            
            // 0x0143688C: BL #0x2782188              | X0 = sub_2782188( ?? 0x176C, ????);     
            // 0x01436890: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01436894: STRB w8, [x20, #0x4d]      | static_value_0373704D = true;            //  dest_result_addr=57897037
            label_0:
            // 0x01436898: CBNZ x19, #0x14368a0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143689C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x176C, ????);     
            label_1:
            // 0x014368A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014368A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014368A8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x014368AC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x014368B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014368B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014368B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014368BC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014368C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014368C4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x014368C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014368CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014368D0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014368D4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014368D8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014368DC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x014368E0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x014368E4: ADRP x9, #0x35d3000        | X9 = 56438784 (0x35D3000);              
            // 0x014368E8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x014368EC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x014368F0: LDR x9, [x9, #0xa78]       | X9 = 1152921504909828096;               
            // 0x014368F4: LDR x24, [x9]              | X24 = typeof(CameraShotMgr);            
            // 0x014368F8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x014368FC: TBZ w9, #0, #0x1436910     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01436900: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01436904: CBNZ w9, #0x1436910        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01436908: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143690C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01436910: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436914: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436918: MOV x1, x24                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x0143691C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01436920: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01436924: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01436928: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0143692C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01436930: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01436934: TBZ w9, #0, #0x1436948     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01436938: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0143693C: CBNZ w9, #0x1436948        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01436940: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01436944: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01436948: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143694C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01436950: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01436954: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01436958: MOV x3, x22                | X3 = X3;//m1                            
            // 0x0143695C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01436960: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01436964: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01436968: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x0143696C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01436970: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01436974: TBZ w9, #0, #0x1436988     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01436978: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0143697C: CBNZ w9, #0x1436988        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01436980: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01436984: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01436988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143698C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436990: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01436994: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01436998: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0143699C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x014369A0: CBZ x0, #0x1436a04         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x014369A4: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x014369A8: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x014369AC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x014369B0: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x014369B4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014369B8: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014369BC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014369C0: B.LO #0x14369dc            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x014369C4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014369C8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x014369CC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014369D0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x014369D4: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x014369D8: B.EQ #0x1436a04            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x014369DC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014369E0: ADD x8, sp, #8             | X8 = (1152921510114822800 + 8) = 1152921510114822808 (0x10000001484D0A98);
            // 0x014369E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014369E8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510114810880]
            // 0x014369EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x014369F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014369F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x014369F8: ADD x0, sp, #8             | X0 = (1152921510114822800 + 8) = 1152921510114822808 (0x10000001484D0A98);
            // 0x014369FC: BL #0x299a140              | 
            // 0x01436A00: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x01436A04: CBNZ x19, #0x1436a0c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01436A08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001484D0A98, ????);
            label_11:
            // 0x01436A0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436A10: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01436A14: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01436A18: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01436A1C: CBNZ x22, #0x1436a24       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01436A20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01436A24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01436A28: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01436A2C: BL #0xd7d7f4               | val_9.Close();                          
            val_9.Close();
            // 0x01436A30: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01436A34: SUB sp, x29, #0x30         | SP = (1152921510114822864 - 48) = 1152921510114822816 (0x10000001484D0AA0);
            // 0x01436A38: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01436A3C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01436A40: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01436A44: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01436A48: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01436A4C: MOV x19, x0                | 
            // 0x01436A50: ADD x0, sp, #8             | 
            // 0x01436A54: BL #0x299a140              | 
            // 0x01436A58: MOV x0, x19                | 
            // 0x01436A5C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01436A60 (21195360), len: 528  VirtAddr: 0x01436A60 RVA: 0x01436A60 token: 100664176 methodIndex: 30223 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ClosePeak_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01436A60: STP x24, x23, [sp, #-0x40]! | stack[1152921510114992160] = ???;  stack[1152921510114992168] = ???;  //  dest_result_addr=1152921510114992160 |  dest_result_addr=1152921510114992168
            // 0x01436A64: STP x22, x21, [sp, #0x10]  | stack[1152921510114992176] = ???;  stack[1152921510114992184] = ???;  //  dest_result_addr=1152921510114992176 |  dest_result_addr=1152921510114992184
            // 0x01436A68: STP x20, x19, [sp, #0x20]  | stack[1152921510114992192] = ???;  stack[1152921510114992200] = ???;  //  dest_result_addr=1152921510114992192 |  dest_result_addr=1152921510114992200
            // 0x01436A6C: STP x29, x30, [sp, #0x30]  | stack[1152921510114992208] = ???;  stack[1152921510114992216] = ???;  //  dest_result_addr=1152921510114992208 |  dest_result_addr=1152921510114992216
            // 0x01436A70: ADD x29, sp, #0x30         | X29 = (1152921510114992160 + 48) = 1152921510114992208 (0x10000001484FA050);
            // 0x01436A74: SUB sp, sp, #0x10          | SP = (1152921510114992160 - 16) = 1152921510114992144 (0x10000001484FA010);
            // 0x01436A78: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01436A7C: LDRB w8, [x20, #0x4e]      | W8 = (bool)static_value_0373704E;       
            // 0x01436A80: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01436A84: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01436A88: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01436A8C: TBNZ w8, #0, #0x1436aa8    | if (static_value_0373704E == true) goto label_0;
            // 0x01436A90: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x01436A94: LDR x8, [x8, #0xd10]       | X8 = 0x2B902A4;                         
            // 0x01436A98: LDR w0, [x8]               | W0 = 0x176D;                            
            // 0x01436A9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x176D, ????);     
            // 0x01436AA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01436AA4: STRB w8, [x20, #0x4e]      | static_value_0373704E = true;            //  dest_result_addr=57897038
            label_0:
            // 0x01436AA8: CBNZ x19, #0x1436ab0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01436AAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x176D, ????);     
            label_1:
            // 0x01436AB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01436AB4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01436AB8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01436ABC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01436AC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436AC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436AC8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01436ACC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01436AD0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01436AD4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01436AD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436ADC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436AE0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01436AE4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01436AE8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01436AEC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01436AF0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01436AF4: ADRP x9, #0x35d3000        | X9 = 56438784 (0x35D3000);              
            // 0x01436AF8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01436AFC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01436B00: LDR x9, [x9, #0xa78]       | X9 = 1152921504909828096;               
            // 0x01436B04: LDR x24, [x9]              | X24 = typeof(CameraShotMgr);            
            // 0x01436B08: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01436B0C: TBZ w9, #0, #0x1436b20     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01436B10: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01436B14: CBNZ w9, #0x1436b20        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01436B18: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01436B1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01436B20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436B24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436B28: MOV x1, x24                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x01436B2C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01436B30: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01436B34: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01436B38: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01436B3C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01436B40: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01436B44: TBZ w9, #0, #0x1436b58     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01436B48: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01436B4C: CBNZ w9, #0x1436b58        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01436B50: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01436B54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01436B58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436B5C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01436B60: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01436B64: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01436B68: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01436B6C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01436B70: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01436B74: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01436B78: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01436B7C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01436B80: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01436B84: TBZ w9, #0, #0x1436b98     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01436B88: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01436B8C: CBNZ w9, #0x1436b98        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01436B90: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01436B94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01436B98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436B9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436BA0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01436BA4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01436BA8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01436BAC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x01436BB0: CBZ x0, #0x1436c14         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01436BB4: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x01436BB8: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x01436BBC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01436BC0: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x01436BC4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01436BC8: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01436BCC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01436BD0: B.LO #0x1436bec            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01436BD4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01436BD8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x01436BDC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01436BE0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01436BE4: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01436BE8: B.EQ #0x1436c14            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01436BEC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01436BF0: ADD x8, sp, #8             | X8 = (1152921510114992144 + 8) = 1152921510114992152 (0x10000001484FA018);
            // 0x01436BF4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01436BF8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510114980224]
            // 0x01436BFC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01436C00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01436C04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01436C08: ADD x0, sp, #8             | X0 = (1152921510114992144 + 8) = 1152921510114992152 (0x10000001484FA018);
            // 0x01436C0C: BL #0x299a140              | 
            // 0x01436C10: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x01436C14: CBNZ x19, #0x1436c1c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01436C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001484FA018, ????);
            label_11:
            // 0x01436C1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436C20: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01436C24: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01436C28: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01436C2C: CBNZ x22, #0x1436c34       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01436C30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01436C34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01436C38: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01436C3C: BL #0xd7dbf0               | val_9.ClosePeak();                      
            val_9.ClosePeak();
            // 0x01436C40: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01436C44: SUB sp, x29, #0x30         | SP = (1152921510114992208 - 48) = 1152921510114992160 (0x10000001484FA020);
            // 0x01436C48: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01436C4C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01436C50: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01436C54: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01436C58: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01436C5C: MOV x19, x0                | 
            // 0x01436C60: ADD x0, sp, #8             | 
            // 0x01436C64: BL #0x299a140              | 
            // 0x01436C68: MOV x0, x19                | 
            // 0x01436C6C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01436C70 (21195888), len: 528  VirtAddr: 0x01436C70 RVA: 0x01436C70 token: 100664177 methodIndex: 30224 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Execute_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01436C70: STP x24, x23, [sp, #-0x40]! | stack[1152921510115161504] = ???;  stack[1152921510115161512] = ???;  //  dest_result_addr=1152921510115161504 |  dest_result_addr=1152921510115161512
            // 0x01436C74: STP x22, x21, [sp, #0x10]  | stack[1152921510115161520] = ???;  stack[1152921510115161528] = ???;  //  dest_result_addr=1152921510115161520 |  dest_result_addr=1152921510115161528
            // 0x01436C78: STP x20, x19, [sp, #0x20]  | stack[1152921510115161536] = ???;  stack[1152921510115161544] = ???;  //  dest_result_addr=1152921510115161536 |  dest_result_addr=1152921510115161544
            // 0x01436C7C: STP x29, x30, [sp, #0x30]  | stack[1152921510115161552] = ???;  stack[1152921510115161560] = ???;  //  dest_result_addr=1152921510115161552 |  dest_result_addr=1152921510115161560
            // 0x01436C80: ADD x29, sp, #0x30         | X29 = (1152921510115161504 + 48) = 1152921510115161552 (0x10000001485235D0);
            // 0x01436C84: SUB sp, sp, #0x10          | SP = (1152921510115161504 - 16) = 1152921510115161488 (0x1000000148523590);
            // 0x01436C88: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01436C8C: LDRB w8, [x20, #0x4f]      | W8 = (bool)static_value_0373704F;       
            // 0x01436C90: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01436C94: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01436C98: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01436C9C: TBNZ w8, #0, #0x1436cb8    | if (static_value_0373704F == true) goto label_0;
            // 0x01436CA0: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x01436CA4: LDR x8, [x8, #0x9c0]       | X8 = 0x2B902A8;                         
            // 0x01436CA8: LDR w0, [x8]               | W0 = 0x176E;                            
            // 0x01436CAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x176E, ????);     
            // 0x01436CB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01436CB4: STRB w8, [x20, #0x4f]      | static_value_0373704F = true;            //  dest_result_addr=57897039
            label_0:
            // 0x01436CB8: CBNZ x19, #0x1436cc0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01436CBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x176E, ????);     
            label_1:
            // 0x01436CC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01436CC4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01436CC8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01436CCC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01436CD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436CD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436CD8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01436CDC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01436CE0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01436CE4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01436CE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436CEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436CF0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01436CF4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01436CF8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01436CFC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01436D00: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01436D04: ADRP x9, #0x35d3000        | X9 = 56438784 (0x35D3000);              
            // 0x01436D08: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01436D0C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01436D10: LDR x9, [x9, #0xa78]       | X9 = 1152921504909828096;               
            // 0x01436D14: LDR x24, [x9]              | X24 = typeof(CameraShotMgr);            
            // 0x01436D18: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01436D1C: TBZ w9, #0, #0x1436d30     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01436D20: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01436D24: CBNZ w9, #0x1436d30        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01436D28: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01436D2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01436D30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436D34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436D38: MOV x1, x24                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x01436D3C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01436D40: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01436D44: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01436D48: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01436D4C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01436D50: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01436D54: TBZ w9, #0, #0x1436d68     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01436D58: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01436D5C: CBNZ w9, #0x1436d68        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01436D60: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01436D64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01436D68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436D6C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01436D70: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01436D74: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01436D78: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01436D7C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01436D80: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01436D84: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01436D88: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01436D8C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01436D90: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01436D94: TBZ w9, #0, #0x1436da8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01436D98: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01436D9C: CBNZ w9, #0x1436da8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01436DA0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01436DA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01436DA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436DAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436DB0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01436DB4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01436DB8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01436DBC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x01436DC0: CBZ x0, #0x1436e24         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01436DC4: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x01436DC8: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x01436DCC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01436DD0: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x01436DD4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01436DD8: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01436DDC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01436DE0: B.LO #0x1436dfc            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01436DE4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01436DE8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x01436DEC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01436DF0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01436DF4: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01436DF8: B.EQ #0x1436e24            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01436DFC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01436E00: ADD x8, sp, #8             | X8 = (1152921510115161488 + 8) = 1152921510115161496 (0x1000000148523598);
            // 0x01436E04: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01436E08: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510115149568]
            // 0x01436E0C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01436E10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01436E14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01436E18: ADD x0, sp, #8             | X0 = (1152921510115161488 + 8) = 1152921510115161496 (0x1000000148523598);
            // 0x01436E1C: BL #0x299a140              | 
            // 0x01436E20: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x01436E24: CBNZ x19, #0x1436e2c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01436E28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148523598, ????);
            label_11:
            // 0x01436E2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436E30: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01436E34: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01436E38: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01436E3C: CBNZ x22, #0x1436e44       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01436E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01436E44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01436E48: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01436E4C: BL #0xd79714               | val_9.Execute();                        
            val_9.Execute();
            // 0x01436E50: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01436E54: SUB sp, x29, #0x30         | SP = (1152921510115161552 - 48) = 1152921510115161504 (0x10000001485235A0);
            // 0x01436E58: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01436E5C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01436E60: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01436E64: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01436E68: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01436E6C: MOV x19, x0                | 
            // 0x01436E70: ADD x0, sp, #8             | 
            // 0x01436E74: BL #0x299a140              | 
            // 0x01436E78: MOV x0, x19                | 
            // 0x01436E7C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01436E80 (21196416), len: 528  VirtAddr: 0x01436E80 RVA: 0x01436E80 token: 100664178 methodIndex: 30225 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* OnEnd_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01436E80: STP x24, x23, [sp, #-0x40]! | stack[1152921510115330848] = ???;  stack[1152921510115330856] = ???;  //  dest_result_addr=1152921510115330848 |  dest_result_addr=1152921510115330856
            // 0x01436E84: STP x22, x21, [sp, #0x10]  | stack[1152921510115330864] = ???;  stack[1152921510115330872] = ???;  //  dest_result_addr=1152921510115330864 |  dest_result_addr=1152921510115330872
            // 0x01436E88: STP x20, x19, [sp, #0x20]  | stack[1152921510115330880] = ???;  stack[1152921510115330888] = ???;  //  dest_result_addr=1152921510115330880 |  dest_result_addr=1152921510115330888
            // 0x01436E8C: STP x29, x30, [sp, #0x30]  | stack[1152921510115330896] = ???;  stack[1152921510115330904] = ???;  //  dest_result_addr=1152921510115330896 |  dest_result_addr=1152921510115330904
            // 0x01436E90: ADD x29, sp, #0x30         | X29 = (1152921510115330848 + 48) = 1152921510115330896 (0x100000014854CB50);
            // 0x01436E94: SUB sp, sp, #0x10          | SP = (1152921510115330848 - 16) = 1152921510115330832 (0x100000014854CB10);
            // 0x01436E98: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01436E9C: LDRB w8, [x20, #0x50]      | W8 = (bool)static_value_03737050;       
            // 0x01436EA0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01436EA4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01436EA8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01436EAC: TBNZ w8, #0, #0x1436ec8    | if (static_value_03737050 == true) goto label_0;
            // 0x01436EB0: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x01436EB4: LDR x8, [x8, #0x480]       | X8 = 0x2B902D0;                         
            // 0x01436EB8: LDR w0, [x8]               | W0 = 0x1778;                            
            // 0x01436EBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1778, ????);     
            // 0x01436EC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01436EC4: STRB w8, [x20, #0x50]      | static_value_03737050 = true;            //  dest_result_addr=57897040
            label_0:
            // 0x01436EC8: CBNZ x19, #0x1436ed0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01436ECC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1778, ????);     
            label_1:
            // 0x01436ED0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01436ED4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01436ED8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01436EDC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01436EE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436EE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436EE8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01436EEC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01436EF0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01436EF4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01436EF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436EFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436F00: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01436F04: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01436F08: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01436F0C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01436F10: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01436F14: ADRP x9, #0x35d3000        | X9 = 56438784 (0x35D3000);              
            // 0x01436F18: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01436F1C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01436F20: LDR x9, [x9, #0xa78]       | X9 = 1152921504909828096;               
            // 0x01436F24: LDR x24, [x9]              | X24 = typeof(CameraShotMgr);            
            // 0x01436F28: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01436F2C: TBZ w9, #0, #0x1436f40     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01436F30: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01436F34: CBNZ w9, #0x1436f40        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01436F38: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01436F3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01436F40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436F44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01436F48: MOV x1, x24                | X1 = 1152921504909828096 (0x10000000120F2000);//ML01
            // 0x01436F4C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01436F50: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01436F54: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01436F58: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01436F5C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01436F60: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01436F64: TBZ w9, #0, #0x1436f78     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01436F68: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01436F6C: CBNZ w9, #0x1436f78        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01436F70: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01436F74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01436F78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436F7C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01436F80: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01436F84: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01436F88: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01436F8C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01436F90: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01436F94: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01436F98: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01436F9C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01436FA0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01436FA4: TBZ w9, #0, #0x1436fb8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01436FA8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01436FAC: CBNZ w9, #0x1436fb8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01436FB0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01436FB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01436FB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01436FBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01436FC0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01436FC4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01436FC8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01436FCC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x01436FD0: CBZ x0, #0x1437034         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01436FD4: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
            // 0x01436FD8: LDR x9, [x9, #0x900]       | X9 = 1152921504909828096;               
            // 0x01436FDC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01436FE0: LDR x1, [x9]               | X1 = typeof(CameraShotMgr);             
            // 0x01436FE4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01436FE8: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01436FEC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01436FF0: B.LO #0x143700c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01436FF4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01436FF8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHie
            // 0x01436FFC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437000: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01437004: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01437008: B.EQ #0x1437034            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x0143700C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01437010: ADD x8, sp, #8             | X8 = (1152921510115330832 + 8) = 1152921510115330840 (0x100000014854CB18);
            // 0x01437014: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01437018: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510115318912]
            // 0x0143701C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01437020: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437024: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01437028: ADD x0, sp, #8             | X0 = (1152921510115330832 + 8) = 1152921510115330840 (0x100000014854CB18);
            // 0x0143702C: BL #0x299a140              | 
            // 0x01437030: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x01437034: CBNZ x19, #0x143703c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01437038: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014854CB18, ????);
            label_11:
            // 0x0143703C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01437040: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01437044: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01437048: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143704C: CBNZ x22, #0x1437054       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01437050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01437054: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437058: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x0143705C: BL #0xd781c0               | val_9.OnEnd();                          
            val_9.OnEnd();
            // 0x01437060: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01437064: SUB sp, x29, #0x30         | SP = (1152921510115330896 - 48) = 1152921510115330848 (0x100000014854CB20);
            // 0x01437068: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0143706C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01437070: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01437074: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01437078: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0143707C: MOV x19, x0                | 
            // 0x01437080: ADD x0, sp, #8             | 
            // 0x01437084: BL #0x299a140              | 
            // 0x01437088: MOV x0, x19                | 
            // 0x0143708C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01437090 (21196944), len: 72  VirtAddr: 0x01437090 RVA: 0x01437090 token: 100664179 methodIndex: 30226 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_WAITTIME_COMPLETE_0(ref object o)
        {
            //
            // Disasemble & Code
            // 0x01437090: STP x20, x19, [sp, #-0x20]! | stack[1152921510115475568] = ???;  stack[1152921510115475576] = ???;  //  dest_result_addr=1152921510115475568 |  dest_result_addr=1152921510115475576
            // 0x01437094: STP x29, x30, [sp, #0x10]  | stack[1152921510115475584] = ???;  stack[1152921510115475592] = ???;  //  dest_result_addr=1152921510115475584 |  dest_result_addr=1152921510115475592
            // 0x01437098: ADD x29, sp, #0x10         | X29 = (1152921510115475568 + 16) = 1152921510115475584 (0x1000000148570080);
            // 0x0143709C: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x014370A0: LDRB w8, [x19, #0x51]      | W8 = (bool)static_value_03737051;       
            // 0x014370A4: TBNZ w8, #0, #0x14370c0    | if (static_value_03737051 == true) goto label_0;
            // 0x014370A8: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x014370AC: LDR x8, [x8, #0x858]       | X8 = 0x2B902C4;                         
            // 0x014370B0: LDR w0, [x8]               | W0 = 0x1775;                            
            // 0x014370B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1775, ????);     
            // 0x014370B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014370BC: STRB w8, [x19, #0x51]      | static_value_03737051 = true;            //  dest_result_addr=57897041
            label_0:
            // 0x014370C0: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x014370C4: LDR x8, [x8, #0xde0]       | X8 = (string**)(1152921510113314096)("WAITTIME_COMPLETE");
            // 0x014370C8: LDR x0, [x8]               | X0 = "WAITTIME_COMPLETE";               
            // 0x014370CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x014370D0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x014370D4: RET                        |  return (System.Object)"WAITTIME_COMPLETE";
            return (object)"WAITTIME_COMPLETE";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x014370D8 (21197016), len: 72  VirtAddr: 0x014370D8 RVA: 0x014370D8 token: 100664180 methodIndex: 30227 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_ACTION_DONE_1(ref object o)
        {
            //
            // Disasemble & Code
            // 0x014370D8: STP x20, x19, [sp, #-0x20]! | stack[1152921510115595600] = ???;  stack[1152921510115595608] = ???;  //  dest_result_addr=1152921510115595600 |  dest_result_addr=1152921510115595608
            // 0x014370DC: STP x29, x30, [sp, #0x10]  | stack[1152921510115595616] = ???;  stack[1152921510115595624] = ???;  //  dest_result_addr=1152921510115595616 |  dest_result_addr=1152921510115595624
            // 0x014370E0: ADD x29, sp, #0x10         | X29 = (1152921510115595600 + 16) = 1152921510115595616 (0x100000014858D560);
            // 0x014370E4: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x014370E8: LDRB w8, [x19, #0x52]      | W8 = (bool)static_value_03737052;       
            // 0x014370EC: TBNZ w8, #0, #0x1437108    | if (static_value_03737052 == true) goto label_0;
            // 0x014370F0: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x014370F4: LDR x8, [x8, #0x418]       | X8 = 0x2B902AC;                         
            // 0x014370F8: LDR w0, [x8]               | W0 = 0x176F;                            
            // 0x014370FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x176F, ????);     
            // 0x01437100: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01437104: STRB w8, [x19, #0x52]      | static_value_03737052 = true;            //  dest_result_addr=57897042
            label_0:
            // 0x01437108: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x0143710C: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921510113315232)("ACTION_DONE");
            // 0x01437110: LDR x0, [x8]               | X0 = "ACTION_DONE";                     
            // 0x01437114: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01437118: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0143711C: RET                        |  return (System.Object)"ACTION_DONE";   
            return (object)"ACTION_DONE";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01437120 (21197088), len: 72  VirtAddr: 0x01437120 RVA: 0x01437120 token: 100664181 methodIndex: 30228 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_SKILL_DONE_2(ref object o)
        {
            //
            // Disasemble & Code
            // 0x01437120: STP x20, x19, [sp, #-0x20]! | stack[1152921510115715632] = ???;  stack[1152921510115715640] = ???;  //  dest_result_addr=1152921510115715632 |  dest_result_addr=1152921510115715640
            // 0x01437124: STP x29, x30, [sp, #0x10]  | stack[1152921510115715648] = ???;  stack[1152921510115715656] = ???;  //  dest_result_addr=1152921510115715648 |  dest_result_addr=1152921510115715656
            // 0x01437128: ADD x29, sp, #0x10         | X29 = (1152921510115715632 + 16) = 1152921510115715648 (0x10000001485AAA40);
            // 0x0143712C: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x01437130: LDRB w8, [x19, #0x53]      | W8 = (bool)static_value_03737053;       
            // 0x01437134: TBNZ w8, #0, #0x1437150    | if (static_value_03737053 == true) goto label_0;
            // 0x01437138: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x0143713C: LDR x8, [x8, #0x2c0]       | X8 = 0x2B902BC;                         
            // 0x01437140: LDR w0, [x8]               | W0 = 0x1773;                            
            // 0x01437144: BL #0x2782188              | X0 = sub_2782188( ?? 0x1773, ????);     
            // 0x01437148: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143714C: STRB w8, [x19, #0x53]      | static_value_03737053 = true;            //  dest_result_addr=57897043
            label_0:
            // 0x01437150: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x01437154: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921510113316352)("SKILL_DONE");
            // 0x01437158: LDR x0, [x8]               | X0 = "SKILL_DONE";                      
            // 0x0143715C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01437160: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01437164: RET                        |  return (System.Object)"SKILL_DONE";    
            return (object)"SKILL_DONE";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01437168 (21197160), len: 72  VirtAddr: 0x01437168 RVA: 0x01437168 token: 100664182 methodIndex: 30229 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_START_ANI_COMPLETE_3(ref object o)
        {
            //
            // Disasemble & Code
            // 0x01437168: STP x20, x19, [sp, #-0x20]! | stack[1152921510115835664] = ???;  stack[1152921510115835672] = ???;  //  dest_result_addr=1152921510115835664 |  dest_result_addr=1152921510115835672
            // 0x0143716C: STP x29, x30, [sp, #0x10]  | stack[1152921510115835680] = ???;  stack[1152921510115835688] = ???;  //  dest_result_addr=1152921510115835680 |  dest_result_addr=1152921510115835688
            // 0x01437170: ADD x29, sp, #0x10         | X29 = (1152921510115835664 + 16) = 1152921510115835680 (0x10000001485C7F20);
            // 0x01437174: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x01437178: LDRB w8, [x19, #0x54]      | W8 = (bool)static_value_03737054;       
            // 0x0143717C: TBNZ w8, #0, #0x1437198    | if (static_value_03737054 == true) goto label_0;
            // 0x01437180: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x01437184: LDR x8, [x8, #0x138]       | X8 = 0x2B902C0;                         
            // 0x01437188: LDR w0, [x8]               | W0 = 0x1774;                            
            // 0x0143718C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1774, ????);     
            // 0x01437190: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01437194: STRB w8, [x19, #0x54]      | static_value_03737054 = true;            //  dest_result_addr=57897044
            label_0:
            // 0x01437198: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x0143719C: LDR x8, [x8, #0xa00]       | X8 = (string**)(1152921510113317472)("START_ANI_COMPLETE");
            // 0x014371A0: LDR x0, [x8]               | X0 = "START_ANI_COMPLETE";              
            // 0x014371A4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x014371A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x014371AC: RET                        |  return (System.Object)"START_ANI_COMPLETE";
            return (object)"START_ANI_COMPLETE";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x014371B0 (21197232), len: 312  VirtAddr: 0x014371B0 RVA: 0x014371B0 token: 100664183 methodIndex: 30230 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_isEditorRun_4(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x014371B0: STP x20, x19, [sp, #-0x20]! | stack[1152921510115959792] = ???;  stack[1152921510115959800] = ???;  //  dest_result_addr=1152921510115959792 |  dest_result_addr=1152921510115959800
            // 0x014371B4: STP x29, x30, [sp, #0x10]  | stack[1152921510115959808] = ???;  stack[1152921510115959816] = ???;  //  dest_result_addr=1152921510115959808 |  dest_result_addr=1152921510115959816
            // 0x014371B8: ADD x29, sp, #0x10         | X29 = (1152921510115959792 + 16) = 1152921510115959808 (0x10000001485E6400);
            // 0x014371BC: SUB sp, sp, #0x20          | SP = (1152921510115959792 - 32) = 1152921510115959760 (0x10000001485E63D0);
            // 0x014371C0: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014371C4: LDRB w8, [x20, #0x55]      | W8 = (bool)static_value_03737055;       
            // 0x014371C8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014371CC: TBNZ w8, #0, #0x14371e8    | if (static_value_03737055 == true) goto label_0;
            // 0x014371D0: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x014371D4: LDR x8, [x8, #0x748]       | X8 = 0x2B902B8;                         
            // 0x014371D8: LDR w0, [x8]               | W0 = 0x1772;                            
            // 0x014371DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1772, ????);     
            // 0x014371E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014371E4: STRB w8, [x20, #0x55]      | static_value_03737055 = true;            //  dest_result_addr=57897045
            label_0:
            // 0x014371E8: ADRP x20, #0x3621000       | X20 = 56758272 (0x3621000);             
            // 0x014371EC: LDR x19, [x19]             | X19 = X1;                               
            // 0x014371F0: LDR x20, [x20, #0x900]     | X20 = 1152921504909828096;              
            // 0x014371F4: CBZ x19, #0x1437248        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x014371F8: LDR x8, [x19]              | X8 = X1;                                
            // 0x014371FC: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x01437200: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01437204: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437208: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143720C: B.LO #0x1437224            | if (X1 + 260 < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01437210: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01437214: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437218: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143721C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01437220: B.EQ #0x143724c            | if ((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01437224: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01437228: ADD x8, sp, #0x10          | X8 = (1152921510115959760 + 16) = 1152921510115959776 (0x10000001485E63E0);
            // 0x0143722C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01437230: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510115947824]
            // 0x01437234: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01437238: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143723C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01437240: ADD x0, sp, #0x10          | X0 = (1152921510115959760 + 16) = 1152921510115959776 (0x10000001485E63E0);
            // 0x01437244: BL #0x299a140              | 
            label_1:
            // 0x01437248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001485E63E0, ????);
            label_3:
            // 0x0143724C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01437250: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x01437254: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01437258: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143725C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437260: B.LO #0x14372a4            | if (X1 + 260 < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01437264: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01437268: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0143726C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437270: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01437274: B.NE #0x14372a4            | if ((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01437278: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x0143727C: LDRB w8, [x19, #0x34]      | W8 = X1 + 52;                           
            // 0x01437280: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x01437284: ADD x1, sp, #0xf           | X1 = (1152921510115959760 + 15) = 1152921510115959775 (0x10000001485E63DF);
            // 0x01437288: STRB w8, [sp, #0xf]        | stack[1152921510115959775] = X1 + 52;    //  dest_result_addr=1152921510115959775
            // 0x0143728C: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x01437290: BL #0x27bc028              | X0 = 1152921510116007840 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 52);
            // 0x01437294: SUB sp, x29, #0x10         | SP = (1152921510115959808 - 16) = 1152921510115959792 (0x10000001485E63F0);
            // 0x01437298: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0143729C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x014372A0: RET                        |  return (System.Object)X1 + 52;         
            return (object)X1 + 52;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x014372A4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014372A8: ADD x8, sp, #0x18          | X8 = (1152921510115959760 + 24) = 1152921510115959784 (0x10000001485E63E8);
            // 0x014372AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x014372B0: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510115947824]
            // 0x014372B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014372B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014372BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014372C0: ADD x0, sp, #0x18          | X0 = (1152921510115959760 + 24) = 1152921510115959784 (0x10000001485E63E8);
            // 0x014372C4: BL #0x299a140              | 
            // 0x014372C8: MOV x19, x0                | X19 = 1152921510115959784 (0x10000001485E63E8);//ML01
            // 0x014372CC: ADD x0, sp, #0x10          | X0 = (1152921510115959760 + 16) = 1152921510115959776 (0x10000001485E63E0);
            label_6:
            // 0x014372D0: BL #0x299a140              | 
            // 0x014372D4: MOV x0, x19                | X0 = 1152921510115959784 (0x10000001485E63E8);//ML01
            // 0x014372D8: BL #0x980800               | X0 = sub_980800( ?? 0x10000001485E63E8, ????);
            // 0x014372DC: MOV x19, x0                | X19 = 1152921510115959784 (0x10000001485E63E8);//ML01
            // 0x014372E0: ADD x0, sp, #0x18          | X0 = (1152921510115959760 + 24) = 1152921510115959784 (0x10000001485E63E8);
            // 0x014372E4: B #0x14372d0               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x014372E8 (21197544), len: 412  VirtAddr: 0x014372E8 RVA: 0x014372E8 token: 100664184 methodIndex: 30231 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_isEditorRun_4(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x014372E8: STP x22, x21, [sp, #-0x30]! | stack[1152921510116088000] = ???;  stack[1152921510116088008] = ???;  //  dest_result_addr=1152921510116088000 |  dest_result_addr=1152921510116088008
            // 0x014372EC: STP x20, x19, [sp, #0x10]  | stack[1152921510116088016] = ???;  stack[1152921510116088024] = ???;  //  dest_result_addr=1152921510116088016 |  dest_result_addr=1152921510116088024
            // 0x014372F0: STP x29, x30, [sp, #0x20]  | stack[1152921510116088032] = ???;  stack[1152921510116088040] = ???;  //  dest_result_addr=1152921510116088032 |  dest_result_addr=1152921510116088040
            // 0x014372F4: ADD x29, sp, #0x20         | X29 = (1152921510116088000 + 32) = 1152921510116088032 (0x10000001486058E0);
            // 0x014372F8: SUB sp, sp, #0x20          | SP = (1152921510116088000 - 32) = 1152921510116087968 (0x10000001486058A0);
            // 0x014372FC: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01437300: LDRB w8, [x21, #0x56]      | W8 = (bool)static_value_03737056;       
            // 0x01437304: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01437308: MOV x20, x1                | X20 = v;//m1                            
            // 0x0143730C: TBNZ w8, #0, #0x1437328    | if (static_value_03737056 == true) goto label_0;
            // 0x01437310: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x01437314: LDR x8, [x8, #0xa40]       | X8 = 0x2B902F4;                         
            // 0x01437318: LDR w0, [x8]               | W0 = 0x1781;                            
            // 0x0143731C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1781, ????);     
            // 0x01437320: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01437324: STRB w8, [x21, #0x56]      | static_value_03737056 = true;            //  dest_result_addr=57897046
            label_0:
            // 0x01437328: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x0143732C: CBZ x21, #0x14373e0        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01437330: ADRP x20, #0x3621000       | X20 = 56758272 (0x3621000);             
            // 0x01437334: LDR x20, [x20, #0x900]     | X20 = 1152921504909828096;              
            // 0x01437338: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143733C: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x01437340: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01437344: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437348: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143734C: B.LO #0x1437364            | if (mem[null + 260] < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01437350: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01437354: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437358: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143735C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01437360: B.EQ #0x143738c            | if ((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01437364: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01437368: ADD x8, sp, #8             | X8 = (1152921510116087968 + 8) = 1152921510116087976 (0x10000001486058A8);
            // 0x0143736C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01437370: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510116076048]
            // 0x01437374: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01437378: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143737C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01437380: ADD x0, sp, #8             | X0 = (1152921510116087968 + 8) = 1152921510116087976 (0x10000001486058A8);
            // 0x01437384: BL #0x299a140              | 
            // 0x01437388: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001486058A8, ????);
            label_3:
            // 0x0143738C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01437390: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x01437394: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01437398: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143739C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014373A0: B.LO #0x14373b8            | if (mem[null + 260] < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x014373A4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x014373A8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014373AC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014373B0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x014373B4: B.EQ #0x14373e8            | if ((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x014373B8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014373BC: ADD x8, sp, #0x10          | X8 = (1152921510116087968 + 16) = 1152921510116087984 (0x10000001486058B0);
            // 0x014373C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x014373C4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510116076048]
            // 0x014373C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014373CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014373D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014373D4: ADD x0, sp, #0x10          | X0 = (1152921510116087968 + 16) = 1152921510116087984 (0x10000001486058B0);
            // 0x014373D8: BL #0x299a140              | 
            // 0x014373DC: B #0x14373e4               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x014373E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1781, ????);     
            label_6:
            // 0x014373E4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x014373E8: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x014373EC: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x014373F0: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x014373F4: CBNZ x19, #0x14373fc       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x014373F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1781, ????);     
            label_7:
            // 0x014373FC: LDR x8, [x19]              | X8 = X2;                                
            // 0x01437400: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01437404: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x01437408: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x0143740C: B.NE #0x1437454            | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01437410: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01437414: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01437418: LDRB w8, [x0]              | W8 = X2;                                
            // 0x0143741C: STRB w8, [x21, #0x34]      | mem[52] = X2;                            //  dest_result_addr=52
            mem[52] = X2;
            // 0x01437420: SUB sp, x29, #0x20         | SP = (1152921510116088032 - 32) = 1152921510116088000 (0x10000001486058C0);
            // 0x01437424: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01437428: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0143742C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01437430: RET                        |  return;                                
            return;
            // 0x01437434: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01437438: ADD x0, sp, #8             | X0 = (1152921510116088048 + 8) = 1152921510116088056 (0x10000001486058F8);
            // 0x0143743C: B #0x1437448               |  goto label_10;                         
            goto label_10;
            // 0x01437440: MOV x19, x0                | X19 = 1152921510116088056 (0x10000001486058F8);//ML01
            val_7;
            // 0x01437444: ADD x0, sp, #0x10          | X0 = (1152921510116088048 + 16) = 1152921510116088064 (0x1000000148605900);
            label_10:
            // 0x01437448: BL #0x299a140              | 
            // 0x0143744C: MOV x0, x19                | X0 = 1152921510116088056 (0x10000001486058F8);//ML01
            // 0x01437450: BL #0x980800               | X0 = sub_980800( ?? 0x10000001486058F8, ????);
            label_8:
            // 0x01437454: ADD x8, sp, #0x18          | X8 = (1152921510116088048 + 24) = 1152921510116088072 (0x1000000148605908);
            // 0x01437458: MOV x1, x20                | X1 = X20;//m1                           
            // 0x0143745C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001486058F8, ????);
            // 0x01437460: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510116076048]
            // 0x01437464: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01437468: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143746C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01437470: ADD x0, sp, #0x18          | X0 = (1152921510116088048 + 24) = 1152921510116088072 (0x1000000148605908);
            // 0x01437474: BL #0x299a140              | 
            // 0x01437478: MOV x19, x0                | X19 = 1152921510116088072 (0x1000000148605908);//ML01
            // 0x0143747C: ADD x0, sp, #0x18          | X0 = (1152921510116088048 + 24) = 1152921510116088072 (0x1000000148605908);
            // 0x01437480: B #0x1437448               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01437484 (21197956), len: 312  VirtAddr: 0x01437484 RVA: 0x01437484 token: 100664185 methodIndex: 30232 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_isCameraShotRunning_5(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01437484: STP x20, x19, [sp, #-0x20]! | stack[1152921510116216240] = ???;  stack[1152921510116216248] = ???;  //  dest_result_addr=1152921510116216240 |  dest_result_addr=1152921510116216248
            // 0x01437488: STP x29, x30, [sp, #0x10]  | stack[1152921510116216256] = ???;  stack[1152921510116216264] = ???;  //  dest_result_addr=1152921510116216256 |  dest_result_addr=1152921510116216264
            // 0x0143748C: ADD x29, sp, #0x10         | X29 = (1152921510116216240 + 16) = 1152921510116216256 (0x1000000148624DC0);
            // 0x01437490: SUB sp, sp, #0x20          | SP = (1152921510116216240 - 32) = 1152921510116216208 (0x1000000148624D90);
            // 0x01437494: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01437498: LDRB w8, [x20, #0x57]      | W8 = (bool)static_value_03737057;       
            // 0x0143749C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014374A0: TBNZ w8, #0, #0x14374bc    | if (static_value_03737057 == true) goto label_0;
            // 0x014374A4: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x014374A8: LDR x8, [x8, #0xce0]       | X8 = 0x2B902B4;                         
            // 0x014374AC: LDR w0, [x8]               | W0 = 0x1771;                            
            // 0x014374B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1771, ????);     
            // 0x014374B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014374B8: STRB w8, [x20, #0x57]      | static_value_03737057 = true;            //  dest_result_addr=57897047
            label_0:
            // 0x014374BC: ADRP x20, #0x3621000       | X20 = 56758272 (0x3621000);             
            // 0x014374C0: LDR x19, [x19]             | X19 = X1;                               
            // 0x014374C4: LDR x20, [x20, #0x900]     | X20 = 1152921504909828096;              
            // 0x014374C8: CBZ x19, #0x143751c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x014374CC: LDR x8, [x19]              | X8 = X1;                                
            // 0x014374D0: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x014374D4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x014374D8: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014374DC: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014374E0: B.LO #0x14374f8            | if (X1 + 260 < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x014374E4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x014374E8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014374EC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014374F0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x014374F4: B.EQ #0x1437520            | if ((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x014374F8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014374FC: ADD x8, sp, #0x10          | X8 = (1152921510116216208 + 16) = 1152921510116216224 (0x1000000148624DA0);
            // 0x01437500: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01437504: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510116204272]
            // 0x01437508: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x0143750C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437510: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01437514: ADD x0, sp, #0x10          | X0 = (1152921510116216208 + 16) = 1152921510116216224 (0x1000000148624DA0);
            // 0x01437518: BL #0x299a140              | 
            label_1:
            // 0x0143751C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148624DA0, ????);
            label_3:
            // 0x01437520: LDR x8, [x19]              | X8 = X1;                                
            // 0x01437524: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x01437528: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x0143752C: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437530: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437534: B.LO #0x1437578            | if (X1 + 260 < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01437538: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x0143753C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437540: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437544: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01437548: B.NE #0x1437578            | if ((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x0143754C: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x01437550: LDRB w8, [x19, #0x44]      | W8 = X1 + 68;                           
            // 0x01437554: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x01437558: ADD x1, sp, #0xf           | X1 = (1152921510116216208 + 15) = 1152921510116216223 (0x1000000148624D9F);
            // 0x0143755C: STRB w8, [sp, #0xf]        | stack[1152921510116216223] = X1 + 68;    //  dest_result_addr=1152921510116216223
            // 0x01437560: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x01437564: BL #0x27bc028              | X0 = 1152921510116264288 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 68);
            // 0x01437568: SUB sp, x29, #0x10         | SP = (1152921510116216256 - 16) = 1152921510116216240 (0x1000000148624DB0);
            // 0x0143756C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01437570: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01437574: RET                        |  return (System.Object)X1 + 68;         
            return (object)X1 + 68;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01437578: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x0143757C: ADD x8, sp, #0x18          | X8 = (1152921510116216208 + 24) = 1152921510116216232 (0x1000000148624DA8);
            // 0x01437580: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01437584: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510116204272]
            // 0x01437588: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x0143758C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437590: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01437594: ADD x0, sp, #0x18          | X0 = (1152921510116216208 + 24) = 1152921510116216232 (0x1000000148624DA8);
            // 0x01437598: BL #0x299a140              | 
            // 0x0143759C: MOV x19, x0                | X19 = 1152921510116216232 (0x1000000148624DA8);//ML01
            // 0x014375A0: ADD x0, sp, #0x10          | X0 = (1152921510116216208 + 16) = 1152921510116216224 (0x1000000148624DA0);
            label_6:
            // 0x014375A4: BL #0x299a140              | 
            // 0x014375A8: MOV x0, x19                | X0 = 1152921510116216232 (0x1000000148624DA8);//ML01
            // 0x014375AC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000148624DA8, ????);
            // 0x014375B0: MOV x19, x0                | X19 = 1152921510116216232 (0x1000000148624DA8);//ML01
            // 0x014375B4: ADD x0, sp, #0x18          | X0 = (1152921510116216208 + 24) = 1152921510116216232 (0x1000000148624DA8);
            // 0x014375B8: B #0x14375a4               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x014375BC (21198268), len: 412  VirtAddr: 0x014375BC RVA: 0x014375BC token: 100664186 methodIndex: 30233 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_isCameraShotRunning_5(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x014375BC: STP x22, x21, [sp, #-0x30]! | stack[1152921510116344448] = ???;  stack[1152921510116344456] = ???;  //  dest_result_addr=1152921510116344448 |  dest_result_addr=1152921510116344456
            // 0x014375C0: STP x20, x19, [sp, #0x10]  | stack[1152921510116344464] = ???;  stack[1152921510116344472] = ???;  //  dest_result_addr=1152921510116344464 |  dest_result_addr=1152921510116344472
            // 0x014375C4: STP x29, x30, [sp, #0x20]  | stack[1152921510116344480] = ???;  stack[1152921510116344488] = ???;  //  dest_result_addr=1152921510116344480 |  dest_result_addr=1152921510116344488
            // 0x014375C8: ADD x29, sp, #0x20         | X29 = (1152921510116344448 + 32) = 1152921510116344480 (0x10000001486442A0);
            // 0x014375CC: SUB sp, sp, #0x20          | SP = (1152921510116344448 - 32) = 1152921510116344416 (0x1000000148644260);
            // 0x014375D0: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x014375D4: LDRB w8, [x21, #0x58]      | W8 = (bool)static_value_03737058;       
            // 0x014375D8: MOV x19, x2                | X19 = X2;//m1                           
            // 0x014375DC: MOV x20, x1                | X20 = v;//m1                            
            // 0x014375E0: TBNZ w8, #0, #0x14375fc    | if (static_value_03737058 == true) goto label_0;
            // 0x014375E4: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x014375E8: LDR x8, [x8, #0x58]        | X8 = 0x2B902F0;                         
            // 0x014375EC: LDR w0, [x8]               | W0 = 0x1780;                            
            // 0x014375F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1780, ????);     
            // 0x014375F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014375F8: STRB w8, [x21, #0x58]      | static_value_03737058 = true;            //  dest_result_addr=57897048
            label_0:
            // 0x014375FC: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01437600: CBZ x21, #0x14376b4        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01437604: ADRP x20, #0x3621000       | X20 = 56758272 (0x3621000);             
            // 0x01437608: LDR x20, [x20, #0x900]     | X20 = 1152921504909828096;              
            // 0x0143760C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01437610: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x01437614: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01437618: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143761C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437620: B.LO #0x1437638            | if (mem[null + 260] < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01437624: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01437628: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0143762C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437630: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01437634: B.EQ #0x1437660            | if ((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01437638: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143763C: ADD x8, sp, #8             | X8 = (1152921510116344416 + 8) = 1152921510116344424 (0x1000000148644268);
            // 0x01437640: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01437644: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510116332496]
            // 0x01437648: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x0143764C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437650: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01437654: ADD x0, sp, #8             | X0 = (1152921510116344416 + 8) = 1152921510116344424 (0x1000000148644268);
            // 0x01437658: BL #0x299a140              | 
            // 0x0143765C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148644268, ????);
            label_3:
            // 0x01437660: LDR x8, [x21]              | X8 = ;                                  
            // 0x01437664: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x01437668: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x0143766C: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437670: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437674: B.LO #0x143768c            | if (mem[null + 260] < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01437678: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x0143767C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437680: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437684: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01437688: B.EQ #0x14376bc            | if ((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x0143768C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01437690: ADD x8, sp, #0x10          | X8 = (1152921510116344416 + 16) = 1152921510116344432 (0x1000000148644270);
            // 0x01437694: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01437698: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510116332496]
            // 0x0143769C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014376A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014376A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014376A8: ADD x0, sp, #0x10          | X0 = (1152921510116344416 + 16) = 1152921510116344432 (0x1000000148644270);
            // 0x014376AC: BL #0x299a140              | 
            // 0x014376B0: B #0x14376b8               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x014376B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1780, ????);     
            label_6:
            // 0x014376B8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x014376BC: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x014376C0: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x014376C4: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x014376C8: CBNZ x19, #0x14376d0       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x014376CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1780, ????);     
            label_7:
            // 0x014376D0: LDR x8, [x19]              | X8 = X2;                                
            // 0x014376D4: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x014376D8: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x014376DC: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x014376E0: B.NE #0x1437728            | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x014376E4: MOV x0, x19                | X0 = X2;//m1                            
            // 0x014376E8: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x014376EC: LDRB w8, [x0]              | W8 = X2;                                
            // 0x014376F0: STRB w8, [x21, #0x44]      | mem[68] = X2;                            //  dest_result_addr=68
            mem[68] = X2;
            // 0x014376F4: SUB sp, x29, #0x20         | SP = (1152921510116344480 - 32) = 1152921510116344448 (0x1000000148644280);
            // 0x014376F8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x014376FC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01437700: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01437704: RET                        |  return;                                
            return;
            // 0x01437708: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x0143770C: ADD x0, sp, #8             | X0 = (1152921510116344496 + 8) = 1152921510116344504 (0x10000001486442B8);
            // 0x01437710: B #0x143771c               |  goto label_10;                         
            goto label_10;
            // 0x01437714: MOV x19, x0                | X19 = 1152921510116344504 (0x10000001486442B8);//ML01
            val_7;
            // 0x01437718: ADD x0, sp, #0x10          | X0 = (1152921510116344496 + 16) = 1152921510116344512 (0x10000001486442C0);
            label_10:
            // 0x0143771C: BL #0x299a140              | 
            // 0x01437720: MOV x0, x19                | X0 = 1152921510116344504 (0x10000001486442B8);//ML01
            // 0x01437724: BL #0x980800               | X0 = sub_980800( ?? 0x10000001486442B8, ????);
            label_8:
            // 0x01437728: ADD x8, sp, #0x18          | X8 = (1152921510116344496 + 24) = 1152921510116344520 (0x10000001486442C8);
            // 0x0143772C: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01437730: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001486442B8, ????);
            // 0x01437734: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510116332496]
            // 0x01437738: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x0143773C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437740: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01437744: ADD x0, sp, #0x18          | X0 = (1152921510116344496 + 24) = 1152921510116344520 (0x10000001486442C8);
            // 0x01437748: BL #0x299a140              | 
            // 0x0143774C: MOV x19, x0                | X19 = 1152921510116344520 (0x10000001486442C8);//ML01
            // 0x01437750: ADD x0, sp, #0x18          | X0 = (1152921510116344496 + 24) = 1152921510116344520 (0x10000001486442C8);
            // 0x01437754: B #0x143771c               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01437758 (21198680), len: 288  VirtAddr: 0x01437758 RVA: 0x01437758 token: 100664187 methodIndex: 30234 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_effectDic_6(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01437758: STP x20, x19, [sp, #-0x20]! | stack[1152921510116468592] = ???;  stack[1152921510116468600] = ???;  //  dest_result_addr=1152921510116468592 |  dest_result_addr=1152921510116468600
            // 0x0143775C: STP x29, x30, [sp, #0x10]  | stack[1152921510116468608] = ???;  stack[1152921510116468616] = ???;  //  dest_result_addr=1152921510116468608 |  dest_result_addr=1152921510116468616
            // 0x01437760: ADD x29, sp, #0x10         | X29 = (1152921510116468592 + 16) = 1152921510116468608 (0x1000000148662780);
            // 0x01437764: SUB sp, sp, #0x10          | SP = (1152921510116468592 - 16) = 1152921510116468576 (0x1000000148662760);
            // 0x01437768: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143776C: LDRB w8, [x20, #0x59]      | W8 = (bool)static_value_03737059;       
            // 0x01437770: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01437774: TBNZ w8, #0, #0x1437790    | if (static_value_03737059 == true) goto label_0;
            // 0x01437778: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x0143777C: LDR x8, [x8, #0xdd0]       | X8 = 0x2B902B0;                         
            // 0x01437780: LDR w0, [x8]               | W0 = 0x1770;                            
            // 0x01437784: BL #0x2782188              | X0 = sub_2782188( ?? 0x1770, ????);     
            // 0x01437788: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143778C: STRB w8, [x20, #0x59]      | static_value_03737059 = true;            //  dest_result_addr=57897049
            label_0:
            // 0x01437790: ADRP x20, #0x3621000       | X20 = 56758272 (0x3621000);             
            // 0x01437794: LDR x19, [x19]             | X19 = X1;                               
            // 0x01437798: LDR x20, [x20, #0x900]     | X20 = 1152921504909828096;              
            // 0x0143779C: CBZ x19, #0x14377f0        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x014377A0: LDR x8, [x19]              | X8 = X1;                                
            // 0x014377A4: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x014377A8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x014377AC: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014377B0: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014377B4: B.LO #0x14377cc            | if (X1 + 260 < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x014377B8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x014377BC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014377C0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014377C4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x014377C8: B.EQ #0x14377f4            | if ((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x014377CC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014377D0: MOV x8, sp                 | X8 = 1152921510116468576 (0x1000000148662760);//ML01
            // 0x014377D4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x014377D8: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510116456624]
            // 0x014377DC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x014377E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014377E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x014377E8: MOV x0, sp                 | X0 = 1152921510116468576 (0x1000000148662760);//ML01
            // 0x014377EC: BL #0x299a140              | 
            label_1:
            // 0x014377F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148662760, ????);
            label_3:
            // 0x014377F4: LDR x8, [x19]              | X8 = X1;                                
            // 0x014377F8: LDR x1, [x20]              | X1 = typeof(CameraShotMgr);             
            // 0x014377FC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01437800: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437804: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437808: B.LO #0x1437834            | if (X1 + 260 < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x0143780C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01437810: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437814: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437818: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x0143781C: B.NE #0x1437834            | if ((X1 + 176 + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01437820: LDR x0, [x19, #0x78]       | X0 = X1 + 120;                          
            // 0x01437824: SUB sp, x29, #0x10         | SP = (1152921510116468608 - 16) = 1152921510116468592 (0x1000000148662770);
            // 0x01437828: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0143782C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01437830: RET                        |  return (System.Object)X1 + 120;        
            return (object)X1 + 120;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01437834: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01437838: ADD x8, sp, #8             | X8 = (1152921510116468576 + 8) = 1152921510116468584 (0x1000000148662768);
            // 0x0143783C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01437840: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510116456624]
            // 0x01437844: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01437848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143784C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01437850: ADD x0, sp, #8             | X0 = (1152921510116468576 + 8) = 1152921510116468584 (0x1000000148662768);
            // 0x01437854: BL #0x299a140              | 
            // 0x01437858: MOV x19, x0                | X19 = 1152921510116468584 (0x1000000148662768);//ML01
            // 0x0143785C: MOV x0, sp                 | X0 = 1152921510116468576 (0x1000000148662760);//ML01
            label_6:
            // 0x01437860: BL #0x299a140              | 
            // 0x01437864: MOV x0, x19                | X0 = 1152921510116468584 (0x1000000148662768);//ML01
            // 0x01437868: BL #0x980800               | X0 = sub_980800( ?? 0x1000000148662768, ????);
            // 0x0143786C: MOV x19, x0                | X19 = 1152921510116468584 (0x1000000148662768);//ML01
            // 0x01437870: ADD x0, sp, #8             | X0 = (1152921510116468576 + 8) = 1152921510116468584 (0x1000000148662768);
            // 0x01437874: B #0x1437860               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01437878 (21198968), len: 420  VirtAddr: 0x01437878 RVA: 0x01437878 token: 100664188 methodIndex: 30235 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_effectDic_6(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01437878: STP x22, x21, [sp, #-0x30]! | stack[1152921510116592704] = ???;  stack[1152921510116592712] = ???;  //  dest_result_addr=1152921510116592704 |  dest_result_addr=1152921510116592712
            // 0x0143787C: STP x20, x19, [sp, #0x10]  | stack[1152921510116592720] = ???;  stack[1152921510116592728] = ???;  //  dest_result_addr=1152921510116592720 |  dest_result_addr=1152921510116592728
            // 0x01437880: STP x29, x30, [sp, #0x20]  | stack[1152921510116592736] = ???;  stack[1152921510116592744] = ???;  //  dest_result_addr=1152921510116592736 |  dest_result_addr=1152921510116592744
            // 0x01437884: ADD x29, sp, #0x20         | X29 = (1152921510116592704 + 32) = 1152921510116592736 (0x1000000148680C60);
            // 0x01437888: SUB sp, sp, #0x20          | SP = (1152921510116592704 - 32) = 1152921510116592672 (0x1000000148680C20);
            // 0x0143788C: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01437890: LDRB w8, [x21, #0x5a]      | W8 = (bool)static_value_0373705A;       
            // 0x01437894: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x01437898: MOV x20, x1                | X20 = v;//m1                            
            // 0x0143789C: TBNZ w8, #0, #0x14378b8    | if (static_value_0373705A == true) goto label_0;
            // 0x014378A0: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x014378A4: LDR x8, [x8, #0x988]       | X8 = 0x2B902EC;                         
            // 0x014378A8: LDR w0, [x8]               | W0 = 0x177F;                            
            // 0x014378AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x177F, ????);     
            // 0x014378B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014378B4: STRB w8, [x21, #0x5a]      | static_value_0373705A = true;            //  dest_result_addr=57897050
            label_0:
            // 0x014378B8: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x014378BC: CBZ x20, #0x1437970        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x014378C0: ADRP x21, #0x3621000       | X21 = 56758272 (0x3621000);             
            // 0x014378C4: LDR x21, [x21, #0x900]     | X21 = 1152921504909828096;              
            val_7 = 1152921504909828096;
            // 0x014378C8: LDR x8, [x20]              | X8 = ;                                  
            // 0x014378CC: LDR x1, [x21]              | X1 = typeof(CameraShotMgr);             
            // 0x014378D0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x014378D4: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014378D8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014378DC: B.LO #0x14378f4            | if (mem[null + 260] < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x014378E0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x014378E4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014378E8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014378EC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x014378F0: B.EQ #0x143791c            | if ((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x014378F4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014378F8: ADD x8, sp, #8             | X8 = (1152921510116592672 + 8) = 1152921510116592680 (0x1000000148680C28);
            // 0x014378FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01437900: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510116580752]
            // 0x01437904: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01437908: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143790C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01437910: ADD x0, sp, #8             | X0 = (1152921510116592672 + 8) = 1152921510116592680 (0x1000000148680C28);
            // 0x01437914: BL #0x299a140              | 
            // 0x01437918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148680C28, ????);
            label_3:
            // 0x0143791C: LDR x8, [x20]              | X8 = ;                                  
            // 0x01437920: LDR x1, [x21]              | X1 = typeof(CameraShotMgr);             
            // 0x01437924: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01437928: LDRB w9, [x1, #0x104]      | W9 = CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143792C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437930: B.LO #0x1437948            | if (mem[null + 260] < CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01437934: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01437938: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0143793C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437940: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraShotMgr))
            // 0x01437944: B.EQ #0x1437978            | if ((mem[null + 176] + (CameraShotMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01437948: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143794C: ADD x8, sp, #0x10          | X8 = (1152921510116592672 + 16) = 1152921510116592688 (0x1000000148680C30);
            // 0x01437950: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01437954: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510116580752]
            // 0x01437958: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x0143795C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437960: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01437964: ADD x0, sp, #0x10          | X0 = (1152921510116592672 + 16) = 1152921510116592688 (0x1000000148680C30);
            // 0x01437968: BL #0x299a140              | 
            // 0x0143796C: B #0x1437974               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01437970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x177F, ????);     
            label_6:
            // 0x01437974: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x01437978: CBZ x19, #0x14379d4        | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x0143797C: ADRP x9, #0x35d1000        | X9 = 56430592 (0x35D1000);              
            // 0x01437980: LDR x9, [x9, #0x148]       | X9 = 1152921504615792640;               
            // 0x01437984: LDR x8, [x19]              | X8 = X2;                                
            // 0x01437988: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            // 0x0143798C: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x01437990: LDRB w9, [x1, #0x104]      | W9 = System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437994: CMP w10, w9                | STATE = COMPARE(X2 + 260, System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437998: B.LO #0x14379b0            | if (X2 + 260 < System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x0143799C: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x014379A0: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHiera
            // 0x014379A4: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014379A8: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Collections.Generic.Dictionary<TKey, TValue>))
            // 0x014379AC: B.EQ #0x14379d8            | if ((X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x014379B0: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x014379B4: ADD x8, sp, #0x18          | X8 = (1152921510116592672 + 24) = 1152921510116592696 (0x1000000148680C38);
            // 0x014379B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x014379BC: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510116580752]
            // 0x014379C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x014379C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014379C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x014379CC: ADD x0, sp, #0x18          | X0 = (1152921510116592672 + 24) = 1152921510116592696 (0x1000000148680C38);
            // 0x014379D0: BL #0x299a140              | 
            label_7:
            // 0x014379D4: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x014379D8: STR x19, [x20, #0x78]      | mem[120] = 0x0;                          //  dest_result_addr=120
            mem[120] = val_8;
            // 0x014379DC: SUB sp, x29, #0x20         | SP = (1152921510116592736 - 32) = 1152921510116592704 (0x1000000148680C40);
            // 0x014379E0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x014379E4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x014379E8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x014379EC: RET                        |  return;                                
            return;
            // 0x014379F0: MOV x19, x0                | 
            // 0x014379F4: ADD x0, sp, #8             | 
            // 0x014379F8: B #0x1437a10               | 
            // 0x014379FC: MOV x19, x0                | 
            // 0x01437A00: ADD x0, sp, #0x10          | 
            // 0x01437A04: B #0x1437a10               | 
            // 0x01437A08: MOV x19, x0                | 
            // 0x01437A0C: ADD x0, sp, #0x18          | 
            label_11:
            // 0x01437A10: BL #0x299a140              | 
            // 0x01437A14: MOV x0, x19                | 
            // 0x01437A18: BL #0x980800               | 
        
        }
    
    }

}
