using UnityEngine;

namespace ProtoBuf
{
    public sealed class BufferExtension : IExtension
    {
        // Fields
        private byte[] buffer; //  0x00000010
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00C7C000 (13090816), len: 8  VirtAddr: 0x00C7C000 RVA: 0x00C7C000 token: 100689128 methodIndex: 53359 delegateWrapperIndex: 0 methodInvoker: 0
        public BufferExtension()
        {
            //
            // Disasemble & Code
            // 0x00C7C000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7C004: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C008 (13090824), len: 24  VirtAddr: 0x00C7C008 RVA: 0x00C7C008 token: 100689129 methodIndex: 53360 delegateWrapperIndex: 0 methodInvoker: 0
        private int ProtoBuf.IExtension.GetLength()
        {
            //
            // Disasemble & Code
            // 0x00C7C008: LDR x8, [x0, #0x10]        | X8 = this.buffer; //P2                  
            // 0x00C7C00C: CBZ x8, #0xc7c018          | if (this.buffer == null) goto label_0;  
            if(this.buffer == null)
            {
                goto label_0;
            }
            // 0x00C7C010: LDR w0, [x8, #0x18]        | W0 = this.buffer.Length; //P2           
            // 0x00C7C014: RET                        |  return (System.Int32)this.buffer.Length;
            return this.buffer.Length;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_0:
            // 0x00C7C018: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00C7C01C: RET                        |  return (System.Int32)0;                
            return (int)0;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C020 (13090848), len: 92  VirtAddr: 0x00C7C020 RVA: 0x00C7C020 token: 100689130 methodIndex: 53361 delegateWrapperIndex: 0 methodInvoker: 0
        private System.IO.Stream ProtoBuf.IExtension.BeginAppend()
        {
            //
            // Disasemble & Code
            // 0x00C7C020: STP x20, x19, [sp, #-0x20]! | stack[1152921514335000240] = ???;  stack[1152921514335000248] = ???;  //  dest_result_addr=1152921514335000240 |  dest_result_addr=1152921514335000248
            // 0x00C7C024: STP x29, x30, [sp, #0x10]  | stack[1152921514335000256] = ???;  stack[1152921514335000264] = ???;  //  dest_result_addr=1152921514335000256 |  dest_result_addr=1152921514335000264
            // 0x00C7C028: ADD x29, sp, #0x10         | X29 = (1152921514335000240 + 16) = 1152921514335000256 (0x1000000243D7D6C0);
            // 0x00C7C02C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00C7C030: LDRB w8, [x19, #0xf83]     | W8 = (bool)static_value_03733F83;       
            // 0x00C7C034: TBNZ w8, #0, #0xc7c050     | if (static_value_03733F83 == true) goto label_0;
            // 0x00C7C038: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00C7C03C: LDR x8, [x8, #0x100]       | X8 = 0x2B8FDB0;                         
            // 0x00C7C040: LDR w0, [x8]               | W0 = 0x1630;                            
            // 0x00C7C044: BL #0x2782188              | X0 = sub_2782188( ?? 0x1630, ????);     
            // 0x00C7C048: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7C04C: STRB w8, [x19, #0xf83]     | static_value_03733F83 = true;            //  dest_result_addr=57884547
            label_0:
            // 0x00C7C050: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00C7C054: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x00C7C058: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_1 = null;
            // 0x00C7C05C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x00C7C060: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7C064: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x00C7C068: BL #0x1e762f4              | .ctor();                                
            val_1 = new System.IO.MemoryStream();
            // 0x00C7C06C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C070: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x00C7C074: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C078: RET                        |  return (System.IO.Stream)typeof(System.IO.MemoryStream);
            return (System.IO.Stream)val_1;
            //  |  // // {name=val_0, type=System.IO.Stream, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C07C (13090940), len: 684  VirtAddr: 0x00C7C07C RVA: 0x00C7C07C token: 100689131 methodIndex: 53362 delegateWrapperIndex: 0 methodInvoker: 0
        private void ProtoBuf.IExtension.EndAppend(System.IO.Stream stream, bool commit)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            System.Byte[] val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00C7C07C: STP x26, x25, [sp, #-0x50]! | stack[1152921514335190016] = ???;  stack[1152921514335190024] = ???;  //  dest_result_addr=1152921514335190016 |  dest_result_addr=1152921514335190024
            // 0x00C7C080: STP x24, x23, [sp, #0x10]  | stack[1152921514335190032] = ???;  stack[1152921514335190040] = ???;  //  dest_result_addr=1152921514335190032 |  dest_result_addr=1152921514335190040
            // 0x00C7C084: STP x22, x21, [sp, #0x20]  | stack[1152921514335190048] = ???;  stack[1152921514335190056] = ???;  //  dest_result_addr=1152921514335190048 |  dest_result_addr=1152921514335190056
            // 0x00C7C088: STP x20, x19, [sp, #0x30]  | stack[1152921514335190064] = ???;  stack[1152921514335190072] = ???;  //  dest_result_addr=1152921514335190064 |  dest_result_addr=1152921514335190072
            // 0x00C7C08C: STP x29, x30, [sp, #0x40]  | stack[1152921514335190080] = ???;  stack[1152921514335190088] = ???;  //  dest_result_addr=1152921514335190080 |  dest_result_addr=1152921514335190088
            // 0x00C7C090: ADD x29, sp, #0x40         | X29 = (1152921514335190016 + 64) = 1152921514335190080 (0x1000000243DABC40);
            // 0x00C7C094: SUB sp, sp, #0x10          | SP = (1152921514335190016 - 16) = 1152921514335190000 (0x1000000243DABBF0);
            // 0x00C7C098: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00C7C09C: LDRB w8, [x22, #0xf84]     | W8 = (bool)static_value_03733F84;       
            // 0x00C7C0A0: MOV w21, w2                | W21 = commit;//m1                       
            // 0x00C7C0A4: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00C7C0A8: MOV x20, x0                | X20 = 1152921514335202096 (0x1000000243DAEB30);//ML01
            // 0x00C7C0AC: TBNZ w8, #0, #0xc7c0c8     | if (static_value_03733F84 == true) goto label_0;
            // 0x00C7C0B0: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00C7C0B4: LDR x8, [x8, #0x568]       | X8 = 0x2B8FDB8;                         
            // 0x00C7C0B8: LDR w0, [x8]               | W0 = 0x1632;                            
            // 0x00C7C0BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1632, ????);     
            // 0x00C7C0C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7C0C4: STRB w8, [x22, #0xf84]     | static_value_03733F84 = true;            //  dest_result_addr=57884548
            label_0:
            // 0x00C7C0C8: TBZ w21, #0, #0xc7c20c     | if (commit == false) goto label_1;      
            if(commit == false)
            {
                goto label_1;
            }
            // 0x00C7C0CC: CBNZ x19, #0xc7c0d4        | if (stream != null) goto label_2;       
            if(stream != null)
            {
                goto label_2;
            }
            // 0x00C7C0D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1632, ????);     
            label_2:
            // 0x00C7C0D4: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x00C7C0D8: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_190; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_198; //  | 
            // 0x00C7C0DC: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00C7C0E0: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_190();
            // 0x00C7C0E4: MOV x21, x0                | X21 = stream;//m1                       
            // 0x00C7C0E8: CMP w21, #1                | STATE = COMPARE(stream, 0x1)            
            // 0x00C7C0EC: B.LT #0xc7c214             | if (stream < 0x1) goto label_3;         
            if(stream < 1)
            {
                goto label_3;
            }
            // 0x00C7C0F0: ADRP x9, #0x3613000        | X9 = 56700928 (0x3613000);              
            // 0x00C7C0F4: LDR x9, [x9, #0xc58]       | X9 = 1152921504621809664;               
            // 0x00C7C0F8: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x00C7C0FC: LDR x1, [x9]               | X1 = typeof(System.IO.MemoryStream);    
            // 0x00C7C100: LDRB w10, [x8, #0x104]     | W10 = System.IO.Stream.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00C7C104: LDRB w9, [x1, #0x104]      | W9 = System.IO.MemoryStream.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00C7C108: CMP w10, w9                | STATE = COMPARE(System.IO.Stream.__il2cppRuntimeField_typeHierarchyDepth, System.IO.MemoryStream.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00C7C10C: B.LO #0xc7c128             | if (System.IO.Stream.__il2cppRuntimeField_typeHierarchyDepth < System.IO.MemoryStream.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00C7C110: LDR x10, [x8, #0xb0]       | X10 = System.IO.Stream.__il2cppRuntimeField_typeHierarchy;
            // 0x00C7C114: ADD x9, x10, x9, lsl #3    | X9 = (System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (System.IO.MemoryStream.__il2cppRuntimeF
            // 0x00C7C118: LDUR x9, [x9, #-8]         | X9 = (System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (System.IO.MemoryStream.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00C7C11C: CMP x9, x1                 | STATE = COMPARE((System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (System.IO.MemoryStream.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.IO.MemoryStream))
            // 0x00C7C120: MOV x22, x19               | X22 = stream;//m1                       
            val_5 = stream;
            // 0x00C7C124: B.EQ #0xc7c150             | if ((System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (System.IO.MemoryStream.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00C7C128: LDR x0, [x8, #0x30]        | X0 = System.IO.Stream.__il2cppRuntimeField_element_class;
            // 0x00C7C12C: ADD x8, sp, #8             | X8 = (1152921514335190000 + 8) = 1152921514335190008 (0x1000000243DABBF8);
            // 0x00C7C130: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.IO.Stream.__il2cppRuntimeField_element_class, ????);
            // 0x00C7C134: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921514335178096]
            // 0x00C7C138: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00C7C13C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7C140: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00C7C144: ADD x0, sp, #8             | X0 = (1152921514335190000 + 8) = 1152921514335190008 (0x1000000243DABBF8);
            // 0x00C7C148: BL #0x299a140              | 
            // 0x00C7C14C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_5 = 0;
            label_5:
            // 0x00C7C150: LDR x8, [x20, #0x10]       | X8 = this.buffer; //P2                  
            // 0x00C7C154: CBZ x8, #0xc7c220          | if (this.buffer == null) goto label_6;  
            if(this.buffer == null)
            {
                goto label_6;
            }
            // 0x00C7C158: LDR x23, [x8, #0x18]       | X23 = this.buffer.Length; //P2          
            // 0x00C7C15C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00C7C160: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00C7C164: LDR x24, [x8]              | X24 = typeof(System.Byte[]);            
            // 0x00C7C168: MOV x0, x24                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C16C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00C7C170: ADD w1, w23, w21           | W1 = (this.buffer.Length + stream);     
            int val_3 = this.buffer.Length + stream;
            // 0x00C7C174: MOV x0, x24                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C178: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00C7C17C: MOV x24, x0                | X24 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C180: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00C7C184: LDR x8, [x8, #0x2e8]       | X8 = 1152921504881979392;               
            // 0x00C7C188: LDR x25, [x20, #0x10]      | X25 = this.buffer; //P2                 
            // 0x00C7C18C: LDR x0, [x8]               | X0 = typeof(ProtoBuf.Helpers);          
            // 0x00C7C190: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Helpers.__il2cppRuntimeField_10A;
            // 0x00C7C194: TBZ w8, #0, #0xc7c1a4      | if (ProtoBuf.Helpers.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00C7C198: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Helpers.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C19C: CBNZ w8, #0xc7c1a4         | if (ProtoBuf.Helpers.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00C7C1A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Helpers), ????);
            label_8:
            // 0x00C7C1A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7C1A8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7C1AC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00C7C1B0: MOV x1, x25                | X1 = this.buffer;//m1                   
            // 0x00C7C1B4: MOV x3, x24                | X3 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C1B8: MOV w5, w23                | W5 = this.buffer.Length;//m1            
            // 0x00C7C1BC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00C7C1C0: BL #0x18b30e0              | System.Buffer.BlockCopy(src:  0, srcOffset:  this.buffer, dst:  0, dstOffset:  389323824, count:  0);
            System.Buffer.BlockCopy(src:  0, srcOffset:  this.buffer, dst:  0, dstOffset:  389323824, count:  0);
            // 0x00C7C1C4: CBNZ x22, #0xc7c1cc        | if (0x0 != 0) goto label_9;             
            if(val_5 != 0)
            {
                goto label_9;
            }
            // 0x00C7C1C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_9:
            // 0x00C7C1CC: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00C7C1D0: LDR x1, [x8, #0x2d8]       | X1 = mem[282584257677399];              
            // 0x00C7C1D4: LDR x9, [x8, #0x2d0]       | X9 = mem[282584257677391];              
            // 0x00C7C1D8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00C7C1DC: BLR x9                     | X0 = mem[282584257677391]();            
            // 0x00C7C1E0: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
            // 0x00C7C1E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7C1E8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7C1EC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00C7C1F0: MOV x3, x24                | X3 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00C7C1F4: MOV w4, w23                | W4 = this.buffer.Length;//m1            
            // 0x00C7C1F8: MOV w5, w21                | W5 = stream;//m1                        
            // 0x00C7C1FC: BL #0x18b30e0              | System.Buffer.BlockCopy(src:  0, srcOffset:  0, dst:  0, dstOffset:  389323824, count:  this.buffer.Length);
            System.Buffer.BlockCopy(src:  0, srcOffset:  0, dst:  0, dstOffset:  389323824, count:  this.buffer.Length);
            // 0x00C7C200: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00C7C204: STR x24, [x20, #0x10]      | this.buffer = typeof(System.Byte[]);     //  dest_result_addr=1152921514335202112
            this.buffer = null;
            // 0x00C7C208: B #0xc7c244                |  goto label_11;                         
            goto label_11;
            label_1:
            // 0x00C7C20C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00C7C210: B #0xc7c244                |  goto label_11;                         
            goto label_11;
            label_3:
            // 0x00C7C214: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00C7C218: MOVZ w20, #0x87            | W20 = 135 (0x87);//ML01                 
            val_7 = 135;
            // 0x00C7C21C: B #0xc7c24c                |  goto label_12;                         
            goto label_12;
            label_6:
            // 0x00C7C220: CBNZ x22, #0xc7c228        | if (0x0 != 0) goto label_13;            
            if(val_5 != 0)
            {
                goto label_13;
            }
            // 0x00C7C224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000243DABBF8, ????);
            label_13:
            // 0x00C7C228: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00C7C22C: LDR x1, [x8, #0x2e8]       | X1 = mem[282584257677415];              
            // 0x00C7C230: LDR x9, [x8, #0x2e0]       | X9 = mem[282584257677407];              
            // 0x00C7C234: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00C7C238: BLR x9                     | X0 = mem[282584257677407]();            
            // 0x00C7C23C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00C7C240: STR x0, [x20, #0x10]       | this.buffer = null;                      //  dest_result_addr=1152921514335202112
            this.buffer = val_5;
            label_11:
            // 0x00C7C244: MOVZ w20, #0x87            | W20 = 135 (0x87);//ML01                 
            val_7 = 135;
            label_23:
            // 0x00C7C248: CBZ x19, #0xc7c2b4         | if (stream == null) goto label_14;      
            if(stream == null)
            {
                goto label_14;
            }
            label_12:
            // 0x00C7C24C: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00C7C250: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x00C7C254: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00C7C258: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00C7C25C: LDRH w9, [x8, #0x102]      | W9 = System.IO.Stream.__il2cppRuntimeField_interface_offsets_count;
            // 0x00C7C260: CBZ x9, #0xc7c28c          | if (System.IO.Stream.__il2cppRuntimeField_interface_offsets_count == 0) goto label_15;
            // 0x00C7C264: LDR x10, [x8, #0x98]       | X10 = System.IO.Stream.__il2cppRuntimeField_interfaceOffsets;
            // 0x00C7C268: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_5 = 0;
            // 0x00C7C26C: ADD x10, x10, #8           | X10 = (System.IO.Stream.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504622379016 (0x1000000000ED0008);
            label_17:
            // 0x00C7C270: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00C7C274: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00C7C278: B.EQ #0xc7c29c             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_16;
            // 0x00C7C27C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_5 = val_5 + 1;
            // 0x00C7C280: ADD x10, x10, #0x10        | X10 = (1152921504622379016 + 16) = 1152921504622379032 (0x1000000000ED0018);
            // 0x00C7C284: CMP x11, x9                | STATE = COMPARE((0 + 1), System.IO.Stream.__il2cppRuntimeField_interface_offsets_count)
            // 0x00C7C288: B.LO #0xc7c270             | if (0 < System.IO.Stream.__il2cppRuntimeField_interface_offsets_count) goto label_17;
            label_15:
            // 0x00C7C28C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7C290: MOV x0, x19                | X0 = stream;//m1                        
            val_8 = stream;
            // 0x00C7C294: BL #0x2776c24              | X0 = sub_2776C24( ?? stream, ????);     
            // 0x00C7C298: B #0xc7c2a8                |  goto label_18;                         
            goto label_18;
            label_16:
            // 0x00C7C29C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00C7C2A0: ADD x8, x8, x9, lsl #4     | X8 = (1152921504622342144 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00C7C2A4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504622342144 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_18:
            // 0x00C7C2A8: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
            // 0x00C7C2AC: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00C7C2B0: BLR x8                     | X0 = sub_10102464C457F( ?? stream, ????);
            label_14:
            // 0x00C7C2B4: CBZ x21, #0xc7c2cc         | if (0x0 == 0) goto label_20;            
            if(val_6 == 0)
            {
                goto label_20;
            }
            // 0x00C7C2B8: CMP w20, #0x87             | STATE = COMPARE(0x87, 0x87)             
            // 0x00C7C2BC: B.EQ #0xc7c2cc             | if (0x87 == 0x87) goto label_20;        
            if(135 == 135)
            {
                goto label_20;
            }
            // 0x00C7C2C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7C2C4: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00C7C2C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_20:
            // 0x00C7C2CC: SUB sp, x29, #0x40         | SP = (1152921514335190080 - 64) = 1152921514335190016 (0x1000000243DABC00);
            // 0x00C7C2D0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C2D4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C2D8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7C2DC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7C2E0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00C7C2E4: RET                        |  return;                                
            return;
            // 0x00C7C2E8: MOV x21, x1                | 
            // 0x00C7C2EC: MOV x20, x0                | 
            // 0x00C7C2F0: B #0xc7c304                | 
            // 0x00C7C2F4: MOV x20, x0                | 
            // 0x00C7C2F8: ADD x0, sp, #8             | 
            // 0x00C7C2FC: MOV x21, x1                | 
            // 0x00C7C300: BL #0x299a140              | 
            label_21:
            // 0x00C7C304: MOV x0, x20                | 
            // 0x00C7C308: CMP w21, #1                | 
            // 0x00C7C30C: B.NE #0xc7c324             | 
            // 0x00C7C310: BL #0x981060               | 
            // 0x00C7C314: LDR x21, [x0]              | 
            // 0x00C7C318: BL #0x980920               | 
            // 0x00C7C31C: MOV w20, wzr               | 
            // 0x00C7C320: B #0xc7c248                | 
            label_22:
            // 0x00C7C324: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C334 (13091636), len: 156  VirtAddr: 0x00C7C334 RVA: 0x00C7C334 token: 100689132 methodIndex: 53363 delegateWrapperIndex: 0 methodInvoker: 0
        private System.IO.Stream ProtoBuf.IExtension.BeginQuery()
        {
            //
            // Disasemble & Code
            //  | 
            System.IO.Stream val_2;
            //  | 
            var val_3;
            // 0x00C7C334: STP x20, x19, [sp, #-0x20]! | stack[1152921514335416752] = ???;  stack[1152921514335416760] = ???;  //  dest_result_addr=1152921514335416752 |  dest_result_addr=1152921514335416760
            // 0x00C7C338: STP x29, x30, [sp, #0x10]  | stack[1152921514335416768] = ???;  stack[1152921514335416776] = ???;  //  dest_result_addr=1152921514335416768 |  dest_result_addr=1152921514335416776
            // 0x00C7C33C: ADD x29, sp, #0x10         | X29 = (1152921514335416752 + 16) = 1152921514335416768 (0x1000000243DE31C0);
            // 0x00C7C340: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7C344: LDRB w8, [x20, #0xf85]     | W8 = (bool)static_value_03733F85;       
            // 0x00C7C348: MOV x19, x0                | X19 = 1152921514335428784 (0x1000000243DE60B0);//ML01
            // 0x00C7C34C: TBNZ w8, #0, #0xc7c368     | if (static_value_03733F85 == true) goto label_0;
            // 0x00C7C350: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00C7C354: LDR x8, [x8, #0xf0]        | X8 = 0x2B8FDB4;                         
            // 0x00C7C358: LDR w0, [x8]               | W0 = 0x1631;                            
            // 0x00C7C35C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1631, ????);     
            // 0x00C7C360: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7C364: STRB w8, [x20, #0xf85]     | static_value_03733F85 = true;            //  dest_result_addr=57884549
            label_0:
            // 0x00C7C368: LDR x20, [x19, #0x10]      | X20 = this.buffer; //P2                 
            // 0x00C7C36C: CBZ x20, #0xc7c394         | if (this.buffer == null) goto label_1;  
            if(this.buffer == null)
            {
                goto label_1;
            }
            // 0x00C7C370: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00C7C374: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x00C7C378: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_1 = null;
            // 0x00C7C37C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x00C7C380: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7C384: MOV x1, x20                | X1 = this.buffer;//m1                   
            // 0x00C7C388: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_2 = val_1;
            // 0x00C7C38C: BL #0x1e78658              | .ctor(buffer:  this.buffer);            
            val_1 = new System.IO.MemoryStream(buffer:  this.buffer);
            // 0x00C7C390: B #0xc7c3c0                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00C7C394: ADRP x19, #0x3654000       | X19 = 56967168 (0x3654000);             
            // 0x00C7C398: LDR x19, [x19, #0x898]     | X19 = 1152921504622342144;              
            // 0x00C7C39C: LDR x0, [x19]              | X0 = typeof(System.IO.Stream);          
            val_3 = null;
            // 0x00C7C3A0: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Stream.__il2cppRuntimeField_10A;
            // 0x00C7C3A4: TBZ w8, #0, #0xc7c3b8      | if (System.IO.Stream.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00C7C3A8: LDR w8, [x0, #0xbc]        | W8 = System.IO.Stream.__il2cppRuntimeField_cctor_finished;
            // 0x00C7C3AC: CBNZ w8, #0xc7c3b8         | if (System.IO.Stream.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00C7C3B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Stream), ????);
            // 0x00C7C3B4: LDR x0, [x19]              | X0 = typeof(System.IO.Stream);          
            val_3 = null;
            label_4:
            // 0x00C7C3B8: LDR x8, [x0, #0xa0]        | X8 = System.IO.Stream.__il2cppRuntimeField_static_fields;
            // 0x00C7C3BC: LDR x19, [x8]              | X19 = System.IO.Stream.Null;            
            val_2 = System.IO.Stream.Null;
            label_2:
            // 0x00C7C3C0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C3C4: MOV x0, x19                | X0 = System.IO.Stream.Null;//m1         
            // 0x00C7C3C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C3CC: RET                        |  return (System.IO.Stream)System.IO.Stream.Null;
            return (System.IO.Stream)val_2;
            //  |  // // {name=val_0, type=System.IO.Stream, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7C3D0 (13091792), len: 180  VirtAddr: 0x00C7C3D0 RVA: 0x00C7C3D0 token: 100689133 methodIndex: 53364 delegateWrapperIndex: 0 methodInvoker: 0
        private void ProtoBuf.IExtension.EndQuery(System.IO.Stream stream)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x00C7C3D0: STP x20, x19, [sp, #-0x20]! | stack[1152921514335569712] = ???;  stack[1152921514335569720] = ???;  //  dest_result_addr=1152921514335569712 |  dest_result_addr=1152921514335569720
            // 0x00C7C3D4: STP x29, x30, [sp, #0x10]  | stack[1152921514335569728] = ???;  stack[1152921514335569736] = ???;  //  dest_result_addr=1152921514335569728 |  dest_result_addr=1152921514335569736
            // 0x00C7C3D8: ADD x29, sp, #0x10         | X29 = (1152921514335569712 + 16) = 1152921514335569728 (0x1000000243E08740);
            // 0x00C7C3DC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7C3E0: LDRB w8, [x20, #0xf86]     | W8 = (bool)static_value_03733F86;       
            // 0x00C7C3E4: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00C7C3E8: TBNZ w8, #0, #0xc7c404     | if (static_value_03733F86 == true) goto label_0;
            // 0x00C7C3EC: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00C7C3F0: LDR x8, [x8, #0x318]       | X8 = 0x2B8FDBC;                         
            // 0x00C7C3F4: LDR w0, [x8]               | W0 = 0x1633;                            
            // 0x00C7C3F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1633, ????);     
            // 0x00C7C3FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7C400: STRB w8, [x20, #0xf86]     | static_value_03733F86 = true;            //  dest_result_addr=57884550
            label_0:
            // 0x00C7C404: CBZ x19, #0xc7c458         | if (stream == null) goto label_1;       
            if(stream == null)
            {
                goto label_1;
            }
            // 0x00C7C408: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00C7C40C: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x00C7C410: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00C7C414: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00C7C418: LDRH w9, [x8, #0x102]      | W9 = System.IO.Stream.__il2cppRuntimeField_interface_offsets_count;
            // 0x00C7C41C: CBZ x9, #0xc7c448          | if (System.IO.Stream.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x00C7C420: LDR x10, [x8, #0x98]       | X10 = System.IO.Stream.__il2cppRuntimeField_interfaceOffsets;
            // 0x00C7C424: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x00C7C428: ADD x10, x10, #8           | X10 = (System.IO.Stream.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504622379016 (0x1000000000ED0008);
            label_4:
            // 0x00C7C42C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00C7C430: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00C7C434: B.EQ #0xc7c464             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x00C7C438: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x00C7C43C: ADD x10, x10, #0x10        | X10 = (1152921504622379016 + 16) = 1152921504622379032 (0x1000000000ED0018);
            // 0x00C7C440: CMP x11, x9                | STATE = COMPARE((0 + 1), System.IO.Stream.__il2cppRuntimeField_interface_offsets_count)
            // 0x00C7C444: B.LO #0xc7c42c             | if (0 < System.IO.Stream.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x00C7C448: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7C44C: MOV x0, x19                | X0 = stream;//m1                        
            val_2 = stream;
            // 0x00C7C450: BL #0x2776c24              | X0 = sub_2776C24( ?? stream, ????);     
            // 0x00C7C454: B #0xc7c470                |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x00C7C458: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C45C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C460: RET                        |  return;                                
            return;
            label_3:
            // 0x00C7C464: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00C7C468: ADD x8, x8, x9, lsl #4     | X8 = (1152921504622342144 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00C7C46C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504622342144 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_5:
            // 0x00C7C470: LDP x2, x1, [x0]           | X2 = 0xC8A0000000000; X1 = 0x7A64E4000A001200; //  | 
            // 0x00C7C474: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7C478: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00C7C47C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7C480: BR x2                      | X0 = sub_C8A0000000000( ?? stream, ????);
        
        }
    
    }

}
