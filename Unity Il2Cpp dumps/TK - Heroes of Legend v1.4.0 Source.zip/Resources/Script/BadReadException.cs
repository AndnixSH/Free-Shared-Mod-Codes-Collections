using UnityEngine;

namespace Pathfinding.Ionic.Zip
{
    [System.Runtime.InteropServices.GuidAttribute] // 0x281401C
    public class BadReadException : ZipException
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x01970374 (26674036), len: 8  VirtAddr: 0x01970374 RVA: 0x01970374 token: 100663345 methodIndex: 20856 delegateWrapperIndex: 0 methodInvoker: 0
        public BadReadException(string message)
        {
            //
            // Disasemble & Code
            // 0x01970374: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01970378: B #0x1c32b48               | this..ctor(message:  message); return;  
            val_1 = new System.Exception(message:  message);
            return;
        
        }
    
    }

}
