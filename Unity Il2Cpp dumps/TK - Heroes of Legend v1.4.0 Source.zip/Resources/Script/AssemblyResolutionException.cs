using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    [Serializable]
    public sealed class AssemblyResolutionException : FileNotFoundException
    {
        // Fields
        private readonly ILRuntime.Mono.Cecil.AssemblyNameReference reference; //  0x00000070
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E56134 (15032628), len: 8  VirtAddr: 0x00E56134 RVA: 0x00E56134 token: 100663728 methodIndex: 19317 delegateWrapperIndex: 0 methodInvoker: 0
        public AssemblyResolutionException(ILRuntime.Mono.Cecil.AssemblyNameReference reference)
        {
            //
            // Disasemble & Code
            // 0x00E56134: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56138: B #0xe5613c                | this..ctor(reference:  reference, innerException:  0); return;
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5613C (15032636), len: 164  VirtAddr: 0x00E5613C RVA: 0x00E5613C token: 100663729 methodIndex: 19318 delegateWrapperIndex: 0 methodInvoker: 0
        public AssemblyResolutionException(ILRuntime.Mono.Cecil.AssemblyNameReference reference, System.Exception innerException)
        {
            //
            // Disasemble & Code
            // 0x00E5613C: STP x22, x21, [sp, #-0x30]! | stack[1152921509462002784] = ???;  stack[1152921509462002792] = ???;  //  dest_result_addr=1152921509462002784 |  dest_result_addr=1152921509462002792
            // 0x00E56140: STP x20, x19, [sp, #0x10]  | stack[1152921509462002800] = ???;  stack[1152921509462002808] = ???;  //  dest_result_addr=1152921509462002800 |  dest_result_addr=1152921509462002808
            // 0x00E56144: STP x29, x30, [sp, #0x20]  | stack[1152921509462002816] = ???;  stack[1152921509462002824] = ???;  //  dest_result_addr=1152921509462002816 |  dest_result_addr=1152921509462002824
            // 0x00E56148: ADD x29, sp, #0x20         | X29 = (1152921509462002784 + 32) = 1152921509462002816 (0x100000012163CC80);
            // 0x00E5614C: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E56150: LDRB w8, [x22, #0xac5]     | W8 = (bool)static_value_03734AC5;       
            // 0x00E56154: MOV x20, x2                | X20 = innerException;//m1               
            // 0x00E56158: MOV x19, x1                | X19 = reference;//m1                    
            // 0x00E5615C: MOV x21, x0                | X21 = 1152921509462014832 (0x100000012163FB70);//ML01
            // 0x00E56160: TBNZ w8, #0, #0xe5617c     | if (static_value_03734AC5 == true) goto label_0;
            // 0x00E56164: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x00E56168: LDR x8, [x8, #0x878]       | X8 = 0x2B8EA54;                         
            // 0x00E5616C: LDR w0, [x8]               | W0 = 0x1153;                            
            // 0x00E56170: BL #0x2782188              | X0 = sub_2782188( ?? 0x1153, ????);     
            // 0x00E56174: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E56178: STRB w8, [x22, #0xac5]     | static_value_03734AC5 = true;            //  dest_result_addr=57887429
            label_0:
            // 0x00E5617C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E56180: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00E56184: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00E56188: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E5618C: TBZ w8, #0, #0xe5619c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E56190: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E56194: CBNZ w8, #0xe5619c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E56198: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x00E5619C: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00E561A0: LDR x8, [x8, #0xb00]       | X8 = (string**)(1152921509461986592)("Failed to resolve assembly: \'{0}\'");
            // 0x00E561A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E561A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E561AC: MOV x2, x19                | X2 = reference;//m1                     
            // 0x00E561B0: LDR x1, [x8]               | X1 = "Failed to resolve assembly: \'{0}\'";
            // 0x00E561B4: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "Failed to resolve assembly: \'{0}\'");
            string val_1 = System.String.Format(format:  0, arg0:  "Failed to resolve assembly: \'{0}\'");
            // 0x00E561B8: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x00E561BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E561C0: MOV x0, x21                | X0 = 1152921509462014832 (0x100000012163FB70);//ML01
            // 0x00E561C4: MOV x2, x20                | X2 = innerException;//m1                
            // 0x00E561C8: BL #0x1e72f70              | this..ctor(message:  val_1, innerException:  innerException);
            // 0x00E561CC: STR x19, [x21, #0x70]      | this.reference = reference;              //  dest_result_addr=1152921509462014944
            this.reference = reference;
            // 0x00E561D0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E561D4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E561D8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E561DC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E561E0 (15032800), len: 8  VirtAddr: 0x00E561E0 RVA: 0x00E561E0 token: 100663730 methodIndex: 19319 delegateWrapperIndex: 0 methodInvoker: 0
        private AssemblyResolutionException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
        {
            //
            // Disasemble & Code
            // 0x00E561E0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00E561E4: B #0x1e72fac               | this..ctor(info:  info, context:  new System.Runtime.Serialization.StreamingContext() {state = context.state, additional = context.additional}); return;
            return;
        
        }
    
    }

}
