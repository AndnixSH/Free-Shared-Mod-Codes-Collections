using UnityEngine;
private sealed class TypeSystem.CommonTypeSystem : TypeSystem
{
    // Fields
    private ILRuntime.Mono.Cecil.AssemblyNameReference core_library; //  0x000000A8
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x011ECF60 (18796384), len: 44  VirtAddr: 0x011ECF60 RVA: 0x011ECF60 token: 100664469 methodIndex: 20613 delegateWrapperIndex: 0 methodInvoker: 0
    public TypeSystem.CommonTypeSystem(ILRuntime.Mono.Cecil.ModuleDefinition module)
    {
        //
        // Disasemble & Code
        // 0x011ECF60: STP x20, x19, [sp, #-0x20]! | stack[1152921509552937312] = ???;  stack[1152921509552937320] = ???;  //  dest_result_addr=1152921509552937312 |  dest_result_addr=1152921509552937320
        // 0x011ECF64: STP x29, x30, [sp, #0x10]  | stack[1152921509552937328] = ???;  stack[1152921509552937336] = ???;  //  dest_result_addr=1152921509552937328 |  dest_result_addr=1152921509552937336
        // 0x011ECF68: ADD x29, sp, #0x10         | X29 = (1152921509552937312 + 16) = 1152921509552937328 (0x1000000126CF5970);
        // 0x011ECF6C: MOV x19, x1                | X19 = module;//m1                       
        // 0x011ECF70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x011ECF74: MOV x20, x0                | X20 = 1152921509552949344 (0x1000000126CF8860);//ML01
        // 0x011ECF78: BL #0x16f59f0              | this..ctor();                           
        val_1 = new System.Object();
        // 0x011ECF7C: STR x19, [x20, #0x10]      | mem[1152921509552949360] = module;       //  dest_result_addr=1152921509552949360
        mem[1152921509552949360] = module;
        // 0x011ECF80: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x011ECF84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x011ECF88: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x011ED340 (18797376), len: 4  VirtAddr: 0x011ED340 RVA: 0x011ED340 token: 100664470 methodIndex: 20614 delegateWrapperIndex: 0 methodInvoker: 0
    internal override ILRuntime.Mono.Cecil.TypeReference LookupType(string namespace, string name)
    {
        //
        // Disasemble & Code
        // 0x011ED340: B #0x11ed344               | return this.CreateTypeReference(namespace:  namespace, name:  name);
        return this.CreateTypeReference(namespace:  namespace, name:  name);
    
    }
    //
    // Offset in libil2cpp.so: 0x011ED1BC (18796988), len: 388  VirtAddr: 0x011ED1BC RVA: 0x011ED1BC token: 100664471 methodIndex: 20615 delegateWrapperIndex: 0 methodInvoker: 0
    public ILRuntime.Mono.Cecil.AssemblyNameReference GetCoreLibraryReference()
    {
        //
        // Disasemble & Code
        //  | 
        ILRuntime.Mono.Cecil.AssemblyNameReference val_6;
        //  | 
        var val_7;
        // 0x011ED1BC: STP x22, x21, [sp, #-0x30]! | stack[1152921509553199184] = ???;  stack[1152921509553199192] = ???;  //  dest_result_addr=1152921509553199184 |  dest_result_addr=1152921509553199192
        // 0x011ED1C0: STP x20, x19, [sp, #0x10]  | stack[1152921509553199200] = ???;  stack[1152921509553199208] = ???;  //  dest_result_addr=1152921509553199200 |  dest_result_addr=1152921509553199208
        // 0x011ED1C4: STP x29, x30, [sp, #0x20]  | stack[1152921509553199216] = ???;  stack[1152921509553199224] = ???;  //  dest_result_addr=1152921509553199216 |  dest_result_addr=1152921509553199224
        // 0x011ED1C8: ADD x29, sp, #0x20         | X29 = (1152921509553199184 + 32) = 1152921509553199216 (0x1000000126D35870);
        // 0x011ED1CC: ADRP x19, #0x3736000       | X19 = 57892864 (0x3736000);             
        // 0x011ED1D0: LDRB w8, [x19, #0x179]     | W8 = (bool)static_value_03736179;       
        // 0x011ED1D4: MOV x20, x0                | X20 = 1152921509553211232 (0x1000000126D38760);//ML01
        // 0x011ED1D8: TBNZ w8, #0, #0x11ed1f4    | if (static_value_03736179 == true) goto label_0;
        // 0x011ED1DC: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x011ED1E0: LDR x8, [x8, #0xcc0]       | X8 = 0x2B92370;                         
        // 0x011ED1E4: LDR w0, [x8]               | W0 = 0x1FA1;                            
        // 0x011ED1E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1FA1, ????);     
        // 0x011ED1EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x011ED1F0: STRB w8, [x19, #0x179]     | static_value_03736179 = true;            //  dest_result_addr=57893241
        label_0:
        // 0x011ED1F4: MOV x19, x20               | X19 = 1152921509553211232 (0x1000000126D38760);//ML01
        // 0x011ED1F8: LDR x0, [x19, #0xa8]!      | X0 = this.core_library; //P2            
        val_6 = this.core_library;
        // 0x011ED1FC: CBNZ x0, #0x11ed330        | if (this.core_library != null) goto label_1;
        if(val_6 != null)
        {
            goto label_1;
        }
        // 0x011ED200: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
        // 0x011ED204: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
        // 0x011ED208: LDR x21, [x20, #0x10]      | 
        // 0x011ED20C: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
        // 0x011ED210: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
        // 0x011ED214: TBZ w8, #0, #0x11ed224     | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x011ED218: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
        // 0x011ED21C: CBNZ w8, #0x11ed224        | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x011ED220: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
        label_3:
        // 0x011ED224: MOV x1, x21                | X1 = X21;//m1                           
        ILRuntime.Mono.Cecil.AssemblyNameReference val_1 = X21;
        // 0x011ED228: MOV x2, x19                | X2 = 1152921509553211400 (0x1000000126D38808);//ML01
        // 0x011ED22C: BL #0x11daf80              | X0 = ILRuntime.Mono.Cecil.Mixin.TryGetCoreLibraryReference(module:  null, reference: out  ILRuntime.Mono.Cecil.AssemblyNameReference val_1 = X21);
        bool val_2 = ILRuntime.Mono.Cecil.Mixin.TryGetCoreLibraryReference(module:  null, reference: out  val_1);
        // 0x011ED230: TBNZ w0, #0, #0x11ed32c    | if (val_2 == true) goto label_4;        
        if(val_2 == true)
        {
            goto label_4;
        }
        // 0x011ED234: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x011ED238: LDR x8, [x8, #0xc88]       | X8 = 1152921504737677312;               
        // 0x011ED23C: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.AssemblyNameReference);
        ILRuntime.Mono.Cecil.AssemblyNameReference val_3 = null;
        // 0x011ED240: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.AssemblyNameReference), ????);
        // 0x011ED244: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x011ED248: MOV x21, x0                | X21 = 1152921504737677312 (0x1000000007CC5000);//ML01
        // 0x011ED24C: BL #0xe55360               | .ctor();                                
        val_3 = new ILRuntime.Mono.Cecil.AssemblyNameReference();
        // 0x011ED250: CBNZ x21, #0x11ed258       | if ( != 0) goto label_5;                
        if(null != 0)
        {
            goto label_5;
        }
        // 0x011ED254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_5:
        // 0x011ED258: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x011ED25C: LDR x8, [x8, #0x748]       | X8 = (string**)(1152921509414824416)("mscorlib");
        // 0x011ED260: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x011ED264: MOV x0, x21                | X0 = 1152921504737677312 (0x1000000007CC5000);//ML01
        // 0x011ED268: LDR x1, [x8]               | X1 = "mscorlib";                        
        // 0x011ED26C: BL #0xe55408               | set_Name(value:  "mscorlib");           
        Name = "mscorlib";
        // 0x011ED270: MOV x0, x20                | X0 = 1152921509553211232 (0x1000000126D38760);//ML01
        // 0x011ED274: BL #0x11ed3d8              | X0 = this.GetCorlibVersion();           
        System.Version val_4 = this.GetCorlibVersion();
        // 0x011ED278: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x011ED27C: CBNZ x21, #0x11ed284       | if ( != 0) goto label_6;                
        if(null != 0)
        {
            goto label_6;
        }
        // 0x011ED280: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x011ED284: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x011ED288: MOV x0, x21                | X0 = 1152921504737677312 (0x1000000007CC5000);//ML01
        // 0x011ED28C: MOV x1, x22                | X1 = val_4;//m1                         
        // 0x011ED290: BL #0xe55430               | set_Version(value:  val_4);             
        Version = val_4;
        // 0x011ED294: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x011ED298: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
        // 0x011ED29C: LDR x22, [x8]              | X22 = typeof(System.Byte[]);            
        // 0x011ED2A0: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x011ED2A4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
        // 0x011ED2A8: ORR w1, wzr, #8            | W1 = 8(0x8);                            
        // 0x011ED2AC: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x011ED2B0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        // 0x011ED2B4: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x011ED2B8: LDR x8, [x8, #0x910]       | X8 = 1152921509553178016;               
        // 0x011ED2BC: MOV x22, x0                | X22 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x011ED2C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x011ED2C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x011ED2C8: LDR x2, [x8]               | X2 = -8511746012302509385;              
        // 0x011ED2CC: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x011ED2D0: BL #0x13caf10              | X0 = new [] {}                          
        // 0x011ED2D4: CBNZ x21, #0x11ed2dc       | if ( != 0) goto label_7;                
        if(null != 0)
        {
            goto label_7;
        }
        // 0x011ED2D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_7:
        // 0x011ED2DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x011ED2E0: MOV x0, x21                | X0 = 1152921504737677312 (0x1000000007CC5000);//ML01
        // 0x011ED2E4: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x011ED2E8: BL #0xe55a94               | set_PublicKeyToken(value:  null);       
        PublicKeyToken = null;
        // 0x011ED2EC: LDR x22, [x20, #0x10]      | 
        // 0x011ED2F0: STR x21, [x20, #0xa8]      | this.core_library = typeof(ILRuntime.Mono.Cecil.AssemblyNameReference);  //  dest_result_addr=1152921509553211400
        this.core_library = val_3;
        // 0x011ED2F4: CBNZ x22, #0x11ed2fc       | if ( != null) goto label_8;             
        if(null != null)
        {
            goto label_8;
        }
        // 0x011ED2F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Mono.Cecil.AssemblyNameReference), ????);
        label_8:
        // 0x011ED2FC: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x011ED300: BL #0x11d9764              | X0 = get_AssemblyReferences();          
        ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.AssemblyNameReference> val_5 = AssemblyReferences;
        // 0x011ED304: LDR x20, [x19]             | X20 = typeof(ILRuntime.Mono.Cecil.AssemblyNameReference);
        // 0x011ED308: MOV x21, x0                | X21 = val_5;//m1                        
        val_7 = val_5;
        // 0x011ED30C: CBNZ x21, #0x11ed314       | if (val_5 != null) goto label_9;        
        if(val_7 != null)
        {
            goto label_9;
        }
        // 0x011ED310: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x011ED314: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
        // 0x011ED318: LDR x8, [x8, #0xe88]       | X8 = 1152921509553186208;               
        // 0x011ED31C: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x011ED320: MOV x1, x20                | X1 = 1152921504737677312 (0x1000000007CC5000);//ML01
        // 0x011ED324: LDR x2, [x8]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.AssemblyNameReference>::Add(ILRuntime.Mono.Cecil.AssemblyNameReference item);
        // 0x011ED328: BL #0x1d47324              | val_5.Add(item:  this.core_library);    
        val_7.Add(item:  this.core_library);
        label_4:
        // 0x011ED32C: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Cecil.AssemblyNameReference);
        val_6 = this.core_library;
        label_1:
        // 0x011ED330: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x011ED334: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x011ED338: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x011ED33C: RET                        |  return (ILRuntime.Mono.Cecil.AssemblyNameReference)typeof(ILRuntime.Mono.Cecil.AssemblyNameReference);
        return val_6;
        //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.AssemblyNameReference, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x011ED3D8 (18797528), len: 304  VirtAddr: 0x011ED3D8 RVA: 0x011ED3D8 token: 100664472 methodIndex: 20616 delegateWrapperIndex: 0 methodInvoker: 0
    private System.Version GetCorlibVersion()
    {
        //
        // Disasemble & Code
        //  | 
        System.Version val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        // 0x011ED3D8: STP x20, x19, [sp, #-0x20]! | stack[1152921509553328608] = ???;  stack[1152921509553328616] = ???;  //  dest_result_addr=1152921509553328608 |  dest_result_addr=1152921509553328616
        // 0x011ED3DC: STP x29, x30, [sp, #0x10]  | stack[1152921509553328624] = ???;  stack[1152921509553328632] = ???;  //  dest_result_addr=1152921509553328624 |  dest_result_addr=1152921509553328632
        // 0x011ED3E0: ADD x29, sp, #0x10         | X29 = (1152921509553328608 + 16) = 1152921509553328624 (0x1000000126D551F0);
        // 0x011ED3E4: ADRP x20, #0x3736000       | X20 = 57892864 (0x3736000);             
        // 0x011ED3E8: LDRB w8, [x20, #0x17a]     | W8 = (bool)static_value_0373617A;       
        // 0x011ED3EC: MOV x19, x0                | X19 = 1152921509553340640 (0x1000000126D580E0);//ML01
        // 0x011ED3F0: TBNZ w8, #0, #0x11ed40c    | if (static_value_0373617A == true) goto label_0;
        // 0x011ED3F4: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x011ED3F8: LDR x8, [x8, #0x750]       | X8 = 0x2B92374;                         
        // 0x011ED3FC: LDR w0, [x8]               | W0 = 0x1FA2;                            
        // 0x011ED400: BL #0x2782188              | X0 = sub_2782188( ?? 0x1FA2, ????);     
        // 0x011ED404: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x011ED408: STRB w8, [x20, #0x17a]     | static_value_0373617A = true;            //  dest_result_addr=57893242
        label_0:
        // 0x011ED40C: LDR x19, [x19, #0x10]      | 
        // 0x011ED410: CBNZ x19, #0x11ed418       | if (this != null) goto label_1;         
        if(this != null)
        {
            goto label_1;
        }
        // 0x011ED414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1FA2, ????);     
        label_1:
        // 0x011ED418: LDRSW x8, [x19, #0x94]     | 
        // 0x011ED41C: CMP w8, #3                 | STATE = COMPARE(0x1, 0x3)               
        // 0x011ED420: B.HI #0x11ed4d4            | if (true > 0x3) goto label_2;           
        if(true > 3)
        {
            goto label_2;
        }
        // 0x011ED424: ADRP x9, #0x2a9a000        | X9 = 44670976 (0x2A9A000);              
        // 0x011ED428: ADD x9, x9, #0x164         | X9 = (44670976 + 356) = 44671332 (0x02A9A164);
        // 0x011ED42C: LDR w8, [x9, x8, lsl #2]   | W8 = 0x3;                               
        // 0x011ED430: CMP w8, #5                 | STATE = COMPARE(0x3, 0x5)               
        // 0x011ED434: B.HI #0x11ed4c4            | if (3 > 0x5) goto label_3;              
        if(3 > 5)
        {
            goto label_3;
        }
        // 0x011ED438: ADRP x9, #0x2a9a000        | X9 = 44670976 (0x2A9A000);              
        // 0x011ED43C: ADD x9, x9, #0xf8          | X9 = (44670976 + 248) = 44671224 (0x02A9A0F8);
        // 0x011ED440: LDRSW x8, [x9, x8, lsl #2] | X8 = 0xFFFFFFFFFE753354;                
        // 0x011ED444: ADD x8, x8, x9             | X8 = (-25873580 + 44671224) = 18797644 (0x011ED44C);
        // 0x011ED448: BR x8                      | goto label_TypeSystem_CommonTypeSystem_GetCorlibVersion_GL011ED44C;
        label_TypeSystem_CommonTypeSystem_GetCorlibVersion_GL011ED44C:
        // 0x011ED44C: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x011ED450: LDR x8, [x8, #0x958]       | X8 = 1152921504657272832;               
        // 0x011ED454: LDR x0, [x8]               | X0 = typeof(System.Version);            
        // 0x011ED458: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Version), ????);
        // 0x011ED45C: MOV x19, x0                | X19 = 1152921504657272832 (0x1000000003017000);//ML01
        val_4 = null;
        // 0x011ED460: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        val_5 = 0;
        // 0x011ED464: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        val_6 = 0;
        // 0x011ED468: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        val_7 = 1;
        // 0x011ED46C: B #0x11ed4b4               |  goto label_5;                          
        goto label_5;
        // 0x011ED470: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x011ED474: LDR x8, [x8, #0x958]       | X8 = 1152921504657272832;               
        // 0x011ED478: LDR x0, [x8]               | X0 = typeof(System.Version);            
        // 0x011ED47C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Version), ????);
        // 0x011ED480: MOV x19, x0                | X19 = 1152921504657272832 (0x1000000003017000);//ML01
        val_4 = null;
        // 0x011ED484: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        val_5 = 0;
        // 0x011ED488: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        val_6 = 0;
        // 0x011ED48C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        val_7 = 2;
        // 0x011ED490: B #0x11ed4b4               |  goto label_5;                          
        goto label_5;
        // 0x011ED494: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x011ED498: LDR x8, [x8, #0x958]       | X8 = 1152921504657272832;               
        // 0x011ED49C: LDR x0, [x8]               | X0 = typeof(System.Version);            
        // 0x011ED4A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Version), ????);
        // 0x011ED4A4: MOV x19, x0                | X19 = 1152921504657272832 (0x1000000003017000);//ML01
        val_4 = null;
        // 0x011ED4A8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        val_5 = 0;
        // 0x011ED4AC: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        val_6 = 0;
        // 0x011ED4B0: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        val_7 = 4;
        label_5:
        // 0x011ED4B4: MOV x0, x19                | X0 = 1152921504657272832 (0x1000000003017000);//ML01
        System.Version val_1 = val_4;
        // 0x011ED4B8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x011ED4BC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x011ED4C0: BL #0x273b940              | .ctor(major:  4, minor:  0, build:  0, revision:  0);
        val_1 = new System.Version(major:  4, minor:  0, build:  0, revision:  0);
        label_3:
        // 0x011ED4C4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x011ED4C8: MOV x0, x19                | X0 = 1152921504657272832 (0x1000000003017000);//ML01
        // 0x011ED4CC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x011ED4D0: RET                        |  return (System.Version)typeof(System.Version);
        return (System.Version)val_4;
        //  |  // // {name=val_0, type=System.Version, size=8, nGRN=0 }
        label_2:
        // 0x011ED4D4: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x011ED4D8: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
        // 0x011ED4DC: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
        System.NotSupportedException val_2 = null;
        // 0x011ED4E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
        // 0x011ED4E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x011ED4E8: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
        // 0x011ED4EC: BL #0x1701574              | .ctor();                                
        val_2 = new System.NotSupportedException();
        // 0x011ED4F0: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x011ED4F4: LDR x8, [x8, #0x2c0]       | X8 = 1152921509553311520;               
        // 0x011ED4F8: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
        // 0x011ED4FC: LDR x1, [x8]               | X1 = System.Version TypeSystem.CommonTypeSystem::GetCorlibVersion();
        // 0x011ED500: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
        // 0x011ED504: BL #0x11d249c              | X0 = Resolve(type:  System.Version TypeSystem.CommonTypeSystem::GetCorlibVersion());
        ILRuntime.Mono.Cecil.TypeDefinition val_3 = Resolve(type:  System.Version TypeSystem.CommonTypeSystem::GetCorlibVersion());
    
    }
    //
    // Offset in libil2cpp.so: 0x011ED344 (18797380), len: 148  VirtAddr: 0x011ED344 RVA: 0x011ED344 token: 100664473 methodIndex: 20617 delegateWrapperIndex: 0 methodInvoker: 0
    private ILRuntime.Mono.Cecil.TypeReference CreateTypeReference(string namespace, string name)
    {
        //
        // Disasemble & Code
        // 0x011ED344: STP x24, x23, [sp, #-0x40]! | stack[1152921509553456960] = ???;  stack[1152921509553456968] = ???;  //  dest_result_addr=1152921509553456960 |  dest_result_addr=1152921509553456968
        // 0x011ED348: STP x22, x21, [sp, #0x10]  | stack[1152921509553456976] = ???;  stack[1152921509553456984] = ???;  //  dest_result_addr=1152921509553456976 |  dest_result_addr=1152921509553456984
        // 0x011ED34C: STP x20, x19, [sp, #0x20]  | stack[1152921509553456992] = ???;  stack[1152921509553457000] = ???;  //  dest_result_addr=1152921509553456992 |  dest_result_addr=1152921509553457000
        // 0x011ED350: STP x29, x30, [sp, #0x30]  | stack[1152921509553457008] = ???;  stack[1152921509553457016] = ???;  //  dest_result_addr=1152921509553457008 |  dest_result_addr=1152921509553457016
        // 0x011ED354: ADD x29, sp, #0x30         | X29 = (1152921509553456960 + 48) = 1152921509553457008 (0x1000000126D74770);
        // 0x011ED358: ADRP x22, #0x3736000       | X22 = 57892864 (0x3736000);             
        // 0x011ED35C: LDRB w8, [x22, #0x17b]     | W8 = (bool)static_value_0373617B;       
        // 0x011ED360: MOV x19, x2                | X19 = name;//m1                         
        // 0x011ED364: MOV x20, x1                | X20 = namespace;//m1                    
        // 0x011ED368: MOV x21, x0                | X21 = 1152921509553469024 (0x1000000126D77660);//ML01
        // 0x011ED36C: TBNZ w8, #0, #0x11ed388    | if (static_value_0373617B == true) goto label_0;
        // 0x011ED370: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x011ED374: LDR x8, [x8, #0xcf8]       | X8 = 0x2B9236C;                         
        // 0x011ED378: LDR w0, [x8]               | W0 = 0x1FA0;                            
        // 0x011ED37C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1FA0, ????);     
        // 0x011ED380: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x011ED384: STRB w8, [x22, #0x17b]     | static_value_0373617B = true;            //  dest_result_addr=57893243
        label_0:
        // 0x011ED388: LDR x23, [x21, #0x10]      | 
        // 0x011ED38C: MOV x0, x21                | X0 = 1152921509553469024 (0x1000000126D77660);//ML01
        // 0x011ED390: BL #0x11ed1bc              | X0 = this.GetCoreLibraryReference();    
        ILRuntime.Mono.Cecil.AssemblyNameReference val_1 = this.GetCoreLibraryReference();
        // 0x011ED394: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x011ED398: LDR x8, [x8, #0x490]       | X8 = 1152921504744173568;               
        // 0x011ED39C: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x011ED3A0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Mono.Cecil.TypeReference);
        // 0x011ED3A4: MOV x0, x8                 | X0 = 1152921504744173568 (0x10000000082F7000);//ML01
        ILRuntime.Mono.Cecil.TypeReference val_2 = null;
        // 0x011ED3A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.TypeReference), ????);
        // 0x011ED3AC: MOV x1, x20                | X1 = namespace;//m1                     
        // 0x011ED3B0: MOV x2, x19                | X2 = name;//m1                          
        // 0x011ED3B4: MOV x22, x0                | X22 = 1152921504744173568 (0x10000000082F7000);//ML01
        // 0x011ED3B8: BL #0x11ea584              | .ctor(namespace:  namespace, name:  name);
        val_2 = new ILRuntime.Mono.Cecil.TypeReference(namespace:  namespace, name:  name);
        // 0x011ED3BC: STP x21, x23, [x22, #0x40] | typeof(ILRuntime.Mono.Cecil.TypeReference).__il2cppRuntimeField_40 = val_1;  typeof(ILRuntime.Mono.Cecil.TypeReference).__il2cppRuntimeField_48 = ???;  //  dest_result_addr=1152921504744173632 |  dest_result_addr=1152921504744173640
        typeof(ILRuntime.Mono.Cecil.TypeReference).__il2cppRuntimeField_40 = val_1;
        typeof(ILRuntime.Mono.Cecil.TypeReference).__il2cppRuntimeField_48 = ???;
        // 0x011ED3C0: MOV x0, x22                | X0 = 1152921504744173568 (0x10000000082F7000);//ML01
        // 0x011ED3C4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x011ED3C8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x011ED3CC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x011ED3D0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x011ED3D4: RET                        |  return (ILRuntime.Mono.Cecil.TypeReference)typeof(ILRuntime.Mono.Cecil.TypeReference);
        return (ILRuntime.Mono.Cecil.TypeReference)val_2;
        //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.TypeReference, size=8, nGRN=0 }
    
    }

}
