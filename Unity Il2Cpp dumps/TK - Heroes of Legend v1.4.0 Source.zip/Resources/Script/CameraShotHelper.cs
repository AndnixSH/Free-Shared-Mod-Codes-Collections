using UnityEngine;
public class CameraShotHelper : MonoBehaviour
{
    // Fields
    public const string BRIGHT_DONE = "BRIGHT_DONE";
    public const string GAMESPEED_DONE = "GAMESPEED_DONE";
    public const string LINE_DONE = "LINE_MOVE";
    public static CameraShotHelper instance; // static_offset: 0x00000000
    public CameraBezier cameraBezier; //  0x00000018
    public bool IsOpeningMoveUpdate; //  0x00000020
    public bool isBrightChange; //  0x00000021
    public bool isCircleCameraMoving; //  0x00000022
    private UnityEngine.Transform circle_TargetTr; //  0x00000028
    private UnityEngine.Vector3 circle_TargetPos; //  0x00000030
    private float circle_Speed; //  0x0000003C
    private float circle_Distance; //  0x00000040
    private float circle_High; //  0x00000044
    private float circle_StartAngle; //  0x00000048
    private float brightTime; //  0x0000004C
    private float time_Temp; //  0x00000050
    private float circle_R; //  0x00000054
    private float circle_angled; //  0x00000058
    private int brightId; //  0x0000005C
    public UnityEngine.GameObject brightUI; //  0x00000060
    private int curCameraShotId; //  0x00000068
    private int isRight; //  0x0000006C
    private UnityEngine.Vector3 curCirclePos; //  0x00000070
    private bool isCtrlGameSpeed; //  0x0000007C
    private float curSpeed; //  0x00000080
    private float forNormalTime; //  0x00000084
    private float targetSpeed; //  0x00000088
    private float toNormalTime; //  0x0000008C
    private float targetWaitTime; //  0x00000090
    private float speedTime_Temp; //  0x00000094
    private bool isTargetSpeeded; //  0x00000098
    private bool isreturnSpeed; //  0x00000099
    private int gameSpeedId; //  0x0000009C
    private UnityEngine.Transform line_Tr; //  0x000000A0
    private UnityEngine.Vector3 lineTargetPos; //  0x000000A8
    private float lineTargetDis; //  0x000000B4
    private float lineTime; //  0x000000B8
    public bool isLineRunning; //  0x000000BC
    private UnityEngine.Vector3 zero; //  0x000000C0
    private UnityEngine.Vector3 lineTarget_Temp; //  0x000000CC
    private float lineTime_Temp; //  0x000000D8
    private float lineTruthDis; //  0x000000DC
    private float lineMidDis; //  0x000000E0
    private int lineCameraShotId; //  0x000000E4
    private int isDamp; //  0x000000E8
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BADDB4 (12246452), len: 132  VirtAddr: 0x00BADDB4 RVA: 0x00BADDB4 token: 100690247 methodIndex: 25780 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotHelper()
    {
        //
        // Disasemble & Code
        // 0x00BADDB4: STP x20, x19, [sp, #-0x20]! | stack[1152921514493978416] = ???;  stack[1152921514493978424] = ???;  //  dest_result_addr=1152921514493978416 |  dest_result_addr=1152921514493978424
        // 0x00BADDB8: STP x29, x30, [sp, #0x10]  | stack[1152921514493978432] = ???;  stack[1152921514493978440] = ???;  //  dest_result_addr=1152921514493978432 |  dest_result_addr=1152921514493978440
        // 0x00BADDBC: ADD x29, sp, #0x10         | X29 = (1152921514493978416 + 16) = 1152921514493978432 (0x100000024D51A740);
        // 0x00BADDC0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BADDC4: LDRB w8, [x20, #0xb0b]     | W8 = (bool)static_value_03733B0B;       
        // 0x00BADDC8: MOV x19, x0                | X19 = 1152921514493990448 (0x100000024D51D630);//ML01
        // 0x00BADDCC: TBNZ w8, #0, #0xbadde8     | if (static_value_03733B0B == true) goto label_0;
        // 0x00BADDD0: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x00BADDD4: LDR x8, [x8, #0x868]       | X8 = 0x2B9026C;                         
        // 0x00BADDD8: LDR w0, [x8]               | W0 = 0x175F;                            
        // 0x00BADDDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x175F, ????);     
        // 0x00BADDE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BADDE4: STRB w8, [x20, #0xb0b]     | static_value_03733B0B = true;            //  dest_result_addr=57883403
        label_0:
        // 0x00BADDE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BADDEC: STRB w8, [x19, #0x20]      | this.IsOpeningMoveUpdate = true;         //  dest_result_addr=1152921514493990480
        this.IsOpeningMoveUpdate = true;
        // 0x00BADDF0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BADDF4: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BADDF8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BADDFC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BADE00: TBZ w8, #0, #0xbade10      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BADE04: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BADE08: CBNZ w8, #0xbade10         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BADE0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_2:
        // 0x00BADE10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BADE14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADE18: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_1 = UnityEngine.Vector3.zero;
        // 0x00BADE1C: STP s0, s1, [x19, #0xc0]   | this.zero = val_1;  mem[1152921514493990644] = val_1.y;  //  dest_result_addr=1152921514493990640 |  dest_result_addr=1152921514493990644
        this.zero = val_1;
        mem[1152921514493990644] = val_1.y;
        // 0x00BADE20: STR s2, [x19, #0xc8]       | mem[1152921514493990648] = val_1.z;      //  dest_result_addr=1152921514493990648
        mem[1152921514493990648] = val_1.z;
        // 0x00BADE24: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BADE28: MOV x0, x19                | X0 = 1152921514493990448 (0x100000024D51D630);//ML01
        // 0x00BADE2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADE30: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BADE34: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADE38 (12246584), len: 108  VirtAddr: 0x00BADE38 RVA: 0x00BADE38 token: 100690248 methodIndex: 25781 delegateWrapperIndex: 0 methodInvoker: 0
    private void Awake()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00BADE38: STP x20, x19, [sp, #-0x20]! | stack[1152921514494090416] = ???;  stack[1152921514494090424] = ???;  //  dest_result_addr=1152921514494090416 |  dest_result_addr=1152921514494090424
        // 0x00BADE3C: STP x29, x30, [sp, #0x10]  | stack[1152921514494090432] = ???;  stack[1152921514494090440] = ???;  //  dest_result_addr=1152921514494090432 |  dest_result_addr=1152921514494090440
        // 0x00BADE40: ADD x29, sp, #0x10         | X29 = (1152921514494090416 + 16) = 1152921514494090432 (0x100000024D535CC0);
        // 0x00BADE44: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BADE48: LDRB w8, [x20, #0xb0c]     | W8 = (bool)static_value_03733B0C;       
        // 0x00BADE4C: MOV x19, x0                | X19 = 1152921514494102448 (0x100000024D538BB0);//ML01
        // 0x00BADE50: TBNZ w8, #0, #0xbade6c     | if (static_value_03733B0C == true) goto label_0;
        // 0x00BADE54: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x00BADE58: LDR x8, [x8, #0xb8]        | X8 = 0x2B90270;                         
        // 0x00BADE5C: LDR w0, [x8]               | W0 = 0x1760;                            
        // 0x00BADE60: BL #0x2782188              | X0 = sub_2782188( ?? 0x1760, ????);     
        // 0x00BADE64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BADE68: STRB w8, [x20, #0xb0c]     | static_value_03733B0C = true;            //  dest_result_addr=57883404
        label_0:
        // 0x00BADE6C: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
        // 0x00BADE70: LDR x20, [x20, #0x8b0]     | X20 = 1152921504887996416;              
        // 0x00BADE74: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_1 = null;
        // 0x00BADE78: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00BADE7C: TBZ w8, #0, #0xbade90      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BADE80: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00BADE84: CBNZ w8, #0xbade90         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BADE88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00BADE8C: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_1 = null;
        label_2:
        // 0x00BADE90: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00BADE94: STR x19, [x8]              | CameraShotHelper.instance = this;        //  dest_result_addr=1152921504888000512
        CameraShotHelper.instance = this;
        // 0x00BADE98: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BADE9C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BADEA0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADEA4 (12246692), len: 112  VirtAddr: 0x00BADEA4 RVA: 0x00BADEA4 token: 100690249 methodIndex: 25782 delegateWrapperIndex: 0 methodInvoker: 0
    public void Clear()
    {
        //
        // Disasemble & Code
        // 0x00BADEA4: STP x20, x19, [sp, #-0x20]! | stack[1152921514494206512] = ???;  stack[1152921514494206520] = ???;  //  dest_result_addr=1152921514494206512 |  dest_result_addr=1152921514494206520
        // 0x00BADEA8: STP x29, x30, [sp, #0x10]  | stack[1152921514494206528] = ???;  stack[1152921514494206536] = ???;  //  dest_result_addr=1152921514494206528 |  dest_result_addr=1152921514494206536
        // 0x00BADEAC: ADD x29, sp, #0x10         | X29 = (1152921514494206512 + 16) = 1152921514494206528 (0x100000024D552240);
        // 0x00BADEB0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BADEB4: LDRB w8, [x20, #0xb0d]     | W8 = (bool)static_value_03733B0D;       
        // 0x00BADEB8: MOV x19, x0                | X19 = 1152921514494218544 (0x100000024D555130);//ML01
        // 0x00BADEBC: TBNZ w8, #0, #0xbaded8     | if (static_value_03733B0D == true) goto label_0;
        // 0x00BADEC0: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
        // 0x00BADEC4: LDR x8, [x8, #0xb68]       | X8 = 0x2B90284;                         
        // 0x00BADEC8: LDR w0, [x8]               | W0 = 0x1765;                            
        // 0x00BADECC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1765, ????);     
        // 0x00BADED0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BADED4: STRB w8, [x20, #0xb0d]     | static_value_03733B0D = true;            //  dest_result_addr=57883405
        label_0:
        // 0x00BADED8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BADEDC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BADEE0: LDR x19, [x19, #0x60]      | X19 = this.brightUI; //P2               
        // 0x00BADEE4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BADEE8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BADEEC: TBZ w8, #0, #0xbadefc      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BADEF0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BADEF4: CBNZ w8, #0xbadefc         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BADEF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00BADEFC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BADF00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BADF04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BADF08: MOV x1, x19                | X1 = this.brightUI;//m1                 
        // 0x00BADF0C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BADF10: B #0x1b78bac               | UnityEngine.Object.DestroyImmediate(obj:  0); return;
        UnityEngine.Object.DestroyImmediate(obj:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADF14 (12246804), len: 700  VirtAddr: 0x00BADF14 RVA: 0x00BADF14 token: 100690250 methodIndex: 25783 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        //  | 
        var val_10;
        //  | 
        bool val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        float val_14;
        // 0x00BADF14: STP d9, d8, [sp, #-0x40]!  | stack[1152921514494343152] = ???;  stack[1152921514494343160] = ???;  //  dest_result_addr=1152921514494343152 |  dest_result_addr=1152921514494343160
        // 0x00BADF18: STP x22, x21, [sp, #0x10]  | stack[1152921514494343168] = ???;  stack[1152921514494343176] = ???;  //  dest_result_addr=1152921514494343168 |  dest_result_addr=1152921514494343176
        // 0x00BADF1C: STP x20, x19, [sp, #0x20]  | stack[1152921514494343184] = ???;  stack[1152921514494343192] = ???;  //  dest_result_addr=1152921514494343184 |  dest_result_addr=1152921514494343192
        // 0x00BADF20: STP x29, x30, [sp, #0x30]  | stack[1152921514494343200] = ???;  stack[1152921514494343208] = ???;  //  dest_result_addr=1152921514494343200 |  dest_result_addr=1152921514494343208
        // 0x00BADF24: ADD x29, sp, #0x30         | X29 = (1152921514494343152 + 48) = 1152921514494343200 (0x100000024D573820);
        // 0x00BADF28: SUB sp, sp, #0x10          | SP = (1152921514494343152 - 16) = 1152921514494343136 (0x100000024D5737E0);
        // 0x00BADF2C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BADF30: LDRB w8, [x20, #0xb0e]     | W8 = (bool)static_value_03733B0E;       
        // 0x00BADF34: MOV x19, x0                | X19 = 1152921514494355216 (0x100000024D576710);//ML01
        val_10 = this;
        // 0x00BADF38: TBNZ w8, #0, #0xbadf54     | if (static_value_03733B0E == true) goto label_0;
        // 0x00BADF3C: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00BADF40: LDR x8, [x8, #0x7a8]       | X8 = 0x2B90298;                         
        // 0x00BADF44: LDR w0, [x8]               | W0 = 0x176A;                            
        // 0x00BADF48: BL #0x2782188              | X0 = sub_2782188( ?? 0x176A, ????);     
        // 0x00BADF4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BADF50: STRB w8, [x20, #0xb0e]     | static_value_03733B0E = true;            //  dest_result_addr=57883406
        label_0:
        // 0x00BADF54: LDRB w21, [x19, #0x20]     | W21 = this.IsOpeningMoveUpdate; //P2    
        val_11 = this.IsOpeningMoveUpdate;
        // 0x00BADF58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BADF5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADF60: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_1 = HeroMgr.instance;
        // 0x00BADF64: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00BADF68: CBNZ x20, #0xbadf70        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00BADF6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00BADF70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADF74: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00BADF78: BL #0x28964e8              | X0 = val_1.get_CameraSmoothFollow();    
        CameraSmoothFollow val_2 = val_1.CameraSmoothFollow;
        // 0x00BADF7C: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00BADF80: CBNZ x20, #0xbadf88        | if (val_2 != null) goto label_2;        
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00BADF84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00BADF88: CBZ w21, #0xbadf98         | if (this.IsOpeningMoveUpdate == false) goto label_3;
        if(val_11 == false)
        {
            goto label_3;
        }
        // 0x00BADF8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BADF90: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        val_12 = 1;
        // 0x00BADF94: B #0xbadfa0                |  goto label_4;                          
        goto label_4;
        label_3:
        // 0x00BADF98: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        val_12 = 0;
        // 0x00BADF9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        label_4:
        // 0x00BADFA0: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00BADFA4: BL #0xd7f358               | val_2.set_IsOpeningMoveUpdate(value:  false);
        val_2.IsOpeningMoveUpdate = false;
        // 0x00BADFA8: LDRB w8, [x19, #0x7c]      | W8 = this.isCtrlGameSpeed; //P2         
        // 0x00BADFAC: CBZ w8, #0xbae1b8          | if (this.isCtrlGameSpeed == false) goto label_15;
        if(this.isCtrlGameSpeed == false)
        {
            goto label_15;
        }
        // 0x00BADFB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BADFB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADFB8: BL #0x2691094              | X0 = UnityEngine.Time.get_timeScale();  
        float val_3 = UnityEngine.Time.timeScale;
        // 0x00BADFBC: LDR s9, [x19, #0x94]       | S9 = this.speedTime_Temp; //P2          
        // 0x00BADFC0: FCMP s0, #0.0              | STATE = COMPARE(val_3, 0)               
        // 0x00BADFC4: B.LS #0xbadfec             | if (val_3 <= 0) goto label_6;           
        if(val_3 <= 0f)
        {
            goto label_6;
        }
        // 0x00BADFC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BADFCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADFD0: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_4 = UnityEngine.Time.deltaTime;
        // 0x00BADFD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BADFD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADFDC: MOV v8.16b, v0.16b         | V8 = val_4;//m1                         
        // 0x00BADFE0: BL #0x2691094              | X0 = UnityEngine.Time.get_timeScale();  
        float val_5 = UnityEngine.Time.timeScale;
        // 0x00BADFE4: FDIV s0, s8, s0            | S0 = (val_4 / val_5);                   
        val_14 = val_4 / val_5;
        // 0x00BADFE8: B #0xbadff4                |  goto label_7;                          
        goto label_7;
        label_6:
        // 0x00BADFEC: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BADFF0: LDR s0, [x8, #0xd68]       | S0 = 0.02;                              
        val_14 = 0.02f;
        label_7:
        // 0x00BADFF4: LDRH w8, [x19, #0x98]      | W8 = this.isTargetSpeeded; //P2         
        // 0x00BADFF8: FADD s0, s9, s0            | S0 = (this.speedTime_Temp + val_14);    
        val_14 = this.speedTime_Temp + val_14;
        // 0x00BADFFC: STR s0, [x19, #0x94]       | this.speedTime_Temp = (this.speedTime_Temp + val_14);  //  dest_result_addr=1152921514494355364
        this.speedTime_Temp = val_14;
        // 0x00BAE000: AND w9, w8, #0xff          | W9 = (this.isTargetSpeeded & 255);      
        bool val_6 = this.isTargetSpeeded & 255;
        // 0x00BAE004: CBNZ w9, #0xbae024         | if ((this.isTargetSpeeded & 255) == true) goto label_8;
        if(val_6 == true)
        {
            goto label_8;
        }
        // 0x00BAE008: LDP s1, s2, [x19, #0x84]   | S1 = this.forNormalTime; //P2  S2 = this.targetSpeed; //P2  //  | 
        float val_10 = this.forNormalTime;
        float val_11 = this.targetSpeed;
        // 0x00BAE00C: FMOV s3, #1.00000000       | S3 = 1;                                 
        // 0x00BAE010: FDIV s1, s0, s1            | S1 = ((this.speedTime_Temp + val_14) / this.forNormalTime);
        val_10 = val_14 / val_10;
        // 0x00BAE014: FSUB s2, s3, s2            | S2 = (1f - this.targetSpeed);           
        val_11 = 1f - val_11;
        // 0x00BAE018: FMUL s1, s2, s1            | S1 = ((1f - this.targetSpeed) * ((this.speedTime_Temp + val_14) / this.forNormalTime));
        val_10 = val_11 * val_10;
        // 0x00BAE01C: FSUB s1, s3, s1            | S1 = (1f - ((1f - this.targetSpeed) * ((this.speedTime_Temp + val_14) / this.forNormalTime)));
        val_10 = 1f - val_10;
        // 0x00BAE020: STR s1, [x19, #0x80]       | this.curSpeed = (1f - ((1f - this.targetSpeed) * ((this.speedTime_Temp + val_14) / this.forNormalTime)));  //  dest_result_addr=1152921514494355344
        this.curSpeed = val_10;
        label_8:
        // 0x00BAE024: CMP w8, #0x100             | STATE = COMPARE(this.isTargetSpeeded, 0x100)
        // 0x00BAE028: B.LO #0xbae054             | if (this.isTargetSpeeded < true) goto label_9;
        if(this.isTargetSpeeded < true)
        {
            goto label_9;
        }
        // 0x00BAE02C: LDP s1, s2, [x19, #0x84]   | S1 = this.forNormalTime; //P2  S2 = this.targetSpeed; //P2  //  | 
        float val_13 = this.forNormalTime;
        // 0x00BAE030: LDP s3, s4, [x19, #0x8c]   | S3 = this.toNormalTime; //P2  S4 = this.targetWaitTime; //P2  //  | 
        // 0x00BAE034: FMOV s5, #-1.00000000      | S5 = -1;                                
        float val_12 = -1f;
        // 0x00BAE038: FADD s5, s2, s5            | S5 = (this.targetSpeed + -1f);          
        val_12 = this.targetSpeed + val_12;
        // 0x00BAE03C: FADD s1, s1, s4            | S1 = (this.forNormalTime + this.targetWaitTime);
        val_13 = val_13 + this.targetWaitTime;
        // 0x00BAE040: FSUB s0, s0, s1            | S0 = ((this.speedTime_Temp + val_14) - (this.forNormalTime + this.targetWaitTime));
        val_14 = val_14 - val_13;
        // 0x00BAE044: FDIV s0, s0, s3            | S0 = (((this.speedTime_Temp + val_14) - (this.forNormalTime + this.targetWaitTime)) / this.toNormalTime);
        val_14 = val_14 / this.toNormalTime;
        // 0x00BAE048: FMUL s0, s5, s0            | S0 = ((this.targetSpeed + -1f) * (((this.speedTime_Temp + val_14) - (this.forNormalTime + this.targetWaitTime)) / this.toNormalTime));
        val_14 = val_12 * val_14;
        // 0x00BAE04C: FSUB s0, s2, s0            | S0 = (this.targetSpeed - ((this.targetSpeed + -1f) * (((this.speedTime_Temp + val_14) - (this.forNormalTime + this.targetWaitTime)) / this.toNormalTime)));
        val_14 = this.targetSpeed - val_14;
        // 0x00BAE050: STR s0, [x19, #0x80]       | this.curSpeed = (this.targetSpeed - ((this.targetSpeed + -1f) * (((this.speedTime_Temp + val_14) - (this.forNormalTime + this.targetWaitTime)) / this.toNormalTime)));  //  dest_result_addr=1152921514494355344
        this.curSpeed = val_14;
        label_9:
        // 0x00BAE054: ADRP x21, #0x3668000       | X21 = 57049088 (0x3668000);             
        // 0x00BAE058: LDR x21, [x21, #0x960]     | X21 = 1152921504911851520;              
        val_11 = 1152921504911851520;
        // 0x00BAE05C: LDR x0, [x21]              | X0 = typeof(ZMG);                       
        // 0x00BAE060: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BAE064: TBZ w8, #0, #0xbae074      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00BAE068: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE06C: CBNZ w8, #0xbae074         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00BAE070: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_11:
        // 0x00BAE074: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE078: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE07C: BL #0x26a81b0              | X0 = ZMG.get_TimeMgr();                 
        TimeMgr val_7 = ZMG.TimeMgr;
        // 0x00BAE080: LDR s8, [x19, #0x80]       | S8 = this.curSpeed; //P2                
        // 0x00BAE084: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00BAE088: CBNZ x20, #0xbae090        | if (val_7 != null) goto label_12;       
        if(val_7 != null)
        {
            goto label_12;
        }
        // 0x00BAE08C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_12:
        // 0x00BAE090: ADRP x22, #0x3659000       | X22 = 56987648 (0x3659000);             
        // 0x00BAE094: LDR x22, [x22, #0xde8]     | X22 = (string**)(1152921511103238048)("GAMESPEED");
        // 0x00BAE098: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAE09C: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00BAE0A0: MOV v0.16b, v8.16b         | V0 = this.curSpeed;//m1                 
        // 0x00BAE0A4: LDR x1, [x22]              | X1 = "GAMESPEED";                       
        // 0x00BAE0A8: BL #0xdf12f0               | val_7.AddTimeScale(timeScale:  this.curSpeed, timeKey:  "GAMESPEED");
        val_7.AddTimeScale(timeScale:  this.curSpeed, timeKey:  "GAMESPEED");
        // 0x00BAE0AC: LDR s0, [x19, #0x94]       | S0 = this.speedTime_Temp; //P2          
        // 0x00BAE0B0: LDR s1, [x19, #0x84]       | S1 = this.forNormalTime; //P2           
        float val_14 = this.forNormalTime;
        // 0x00BAE0B4: FCMP s0, s1                | STATE = COMPARE(this.speedTime_Temp, this.forNormalTime)
        // 0x00BAE0B8: B.LT #0xbae0c4             | if (this.speedTime_Temp < this.forNormalTime) goto label_13;
        if(this.speedTime_Temp < val_14)
        {
            goto label_13;
        }
        // 0x00BAE0BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAE0C0: STRB w8, [x19, #0x98]      | this.isTargetSpeeded = true;             //  dest_result_addr=1152921514494355368
        this.isTargetSpeeded = true;
        label_13:
        // 0x00BAE0C4: LDR s2, [x19, #0x90]       | S2 = this.targetWaitTime; //P2          
        // 0x00BAE0C8: FADD s1, s1, s2            | S1 = (this.forNormalTime + this.targetWaitTime);
        val_14 = val_14 + this.targetWaitTime;
        // 0x00BAE0CC: FCMP s0, s1                | STATE = COMPARE(this.speedTime_Temp, (this.forNormalTime + this.targetWaitTime))
        // 0x00BAE0D0: B.LT #0xbae0dc             | if (this.speedTime_Temp < this.forNormalTime) goto label_14;
        if(this.speedTime_Temp < val_14)
        {
            goto label_14;
        }
        // 0x00BAE0D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAE0D8: STRB w8, [x19, #0x99]      | this.isreturnSpeed = true;               //  dest_result_addr=1152921514494355369
        this.isreturnSpeed = true;
        label_14:
        // 0x00BAE0DC: LDR s2, [x19, #0x8c]       | S2 = this.toNormalTime; //P2            
        // 0x00BAE0E0: FADD s1, s1, s2            | S1 = ((this.forNormalTime + this.targetWaitTime) + this.toNormalTime);
        val_14 = val_14 + this.toNormalTime;
        // 0x00BAE0E4: FCMP s0, s1                | STATE = COMPARE(this.speedTime_Temp, ((this.forNormalTime + this.targetWaitTime) + this.toNormalTime))
        // 0x00BAE0E8: B.LT #0xbae1b8             | if (this.speedTime_Temp < this.forNormalTime) goto label_15;
        if(this.speedTime_Temp < val_14)
        {
            goto label_15;
        }
        // 0x00BAE0EC: STRB wzr, [x19, #0x7c]     | this.isCtrlGameSpeed = false;            //  dest_result_addr=1152921514494355340
        this.isCtrlGameSpeed = false;
        // 0x00BAE0F0: STR wzr, [x19, #0x94]      | this.speedTime_Temp = 0;                 //  dest_result_addr=1152921514494355364
        this.speedTime_Temp = 0f;
        // 0x00BAE0F4: LDR x0, [x21]              | X0 = typeof(ZMG);                       
        // 0x00BAE0F8: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BAE0FC: TBZ w8, #0, #0xbae10c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00BAE100: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE104: CBNZ w8, #0xbae10c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00BAE108: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_17:
        // 0x00BAE10C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE110: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE114: BL #0x26a81b0              | X0 = ZMG.get_TimeMgr();                 
        TimeMgr val_8 = ZMG.TimeMgr;
        // 0x00BAE118: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00BAE11C: CBNZ x20, #0xbae124        | if (val_8 != null) goto label_18;       
        if(val_8 != null)
        {
            goto label_18;
        }
        // 0x00BAE120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_18:
        // 0x00BAE124: LDR x1, [x22]              | X1 = "GAMESPEED";                       
        // 0x00BAE128: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAE12C: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x00BAE130: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00BAE134: BL #0xdf12f0               | val_8.AddTimeScale(timeScale:  1f, timeKey:  "GAMESPEED");
        val_8.AddTimeScale(timeScale:  1f, timeKey:  "GAMESPEED");
        // 0x00BAE138: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00BAE13C: LDR w8, [x19, #0x9c]       | W8 = this.gameSpeedId; //P2             
        // 0x00BAE140: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00BAE144: ADD x1, sp, #0xc           | X1 = (1152921514494343136 + 12) = 1152921514494343148 (0x100000024D5737EC);
        // 0x00BAE148: STR w8, [sp, #0xc]         | stack[1152921514494343148] = this.gameSpeedId;  //  dest_result_addr=1152921514494343148
        // 0x00BAE14C: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00BAE150: BL #0x27bc028              | X0 = 1152921514494403600 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.gameSpeedId);
        // 0x00BAE154: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00BAE158: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00BAE15C: MOV x20, x0                | X20 = 1152921514494403600 (0x100000024D582410);//ML01
        // 0x00BAE160: LDR x8, [x8]               | X8 = typeof(CEvent.ZEvent);             
        // 0x00BAE164: MOV x0, x8                 | X0 = 1152921504898326528 (0x10000000115FA000);//ML01
        CEvent.ZEvent val_9 = null;
        // 0x00BAE168: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00BAE16C: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00BAE170: LDR x8, [x8, #0x7b8]       | X8 = (string**)(1152921514494331120)("GAMESPEED_DONE");
        // 0x00BAE174: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAE178: MOV x2, x20                | X2 = 1152921514494403600 (0x100000024D582410);//ML01
        // 0x00BAE17C: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        val_10 = val_9;
        // 0x00BAE180: LDR x1, [x8]               | X1 = "GAMESPEED_DONE";                  
        // 0x00BAE184: BL #0xd7de54               | .ctor(name:  "GAMESPEED_DONE", arg:  this.gameSpeedId);
        val_9 = new CEvent.ZEvent(name:  "GAMESPEED_DONE", arg:  this.gameSpeedId);
        // 0x00BAE188: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00BAE18C: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00BAE190: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00BAE194: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00BAE198: TBZ w8, #0, #0xbae1a8      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00BAE19C: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE1A0: CBNZ w8, #0xbae1a8         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00BAE1A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_20:
        // 0x00BAE1A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE1AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAE1B0: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00BAE1B4: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        label_15:
        // 0x00BAE1B8: SUB sp, x29, #0x30         | SP = (1152921514494343200 - 48) = 1152921514494343152 (0x100000024D5737F0);
        // 0x00BAE1BC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAE1C0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAE1C4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAE1C8: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00BAE1CC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAE1D0 (12247504), len: 5200  VirtAddr: 0x00BAE1D0 RVA: 0x00BAE1D0 token: 100690251 methodIndex: 25784 delegateWrapperIndex: 0 methodInvoker: 0
    private void LateUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        var val_146;
        //  | 
        float val_147;
        //  | 
        UnityEngine.Vector3 val_148;
        //  | 
        UnityEngine.Transform val_149;
        //  | 
        UnityEngine.Vector3 val_150;
        //  | 
        float val_151;
        //  | 
        int val_152;
        //  | 
        float val_153;
        //  | 
        float val_154;
        //  | 
        float val_155;
        //  | 
        var val_156;
        //  | 
        var val_157;
        //  | 
        var val_158;
        //  | 
        float val_159;
        //  | 
        float val_160;
        //  | 
        float val_161;
        //  | 
        var val_162;
        //  | 
        var val_163;
        //  | 
        var val_164;
        //  | 
        float val_165;
        //  | 
        float val_166;
        //  | 
        float val_167;
        //  | 
        var val_168;
        //  | 
        var val_169;
        //  | 
        var val_170;
        //  | 
        UnityEngine.Vector3 val_171;
        //  | 
        float val_172;
        //  | 
        float val_173;
        //  | 
        float val_174;
        //  | 
        var val_175;
        //  | 
        var val_176;
        //  | 
        var val_177;
        //  | 
        var val_178;
        //  | 
        var val_179;
        //  | 
        var val_180;
        //  | 
        float val_181;
        //  | 
        var val_182;
        //  | 
        float val_183;
        //  | 
        float val_184;
        //  | 
        float val_185;
        //  | 
        var val_186;
        //  | 
        var val_187;
        //  | 
        var val_188;
        // 0x00BAE1D0: STP d15, d14, [sp, #-0x80]! | stack[1152921514494700944] = ???;  stack[1152921514494700952] = ???;  //  dest_result_addr=1152921514494700944 |  dest_result_addr=1152921514494700952
        // 0x00BAE1D4: STP d13, d12, [sp, #0x10]  | stack[1152921514494700960] = ???;  stack[1152921514494700968] = ???;  //  dest_result_addr=1152921514494700960 |  dest_result_addr=1152921514494700968
        // 0x00BAE1D8: STP d11, d10, [sp, #0x20]  | stack[1152921514494700976] = ???;  stack[1152921514494700984] = ???;  //  dest_result_addr=1152921514494700976 |  dest_result_addr=1152921514494700984
        // 0x00BAE1DC: STP d9, d8, [sp, #0x30]    | stack[1152921514494700992] = ???;  stack[1152921514494701000] = ???;  //  dest_result_addr=1152921514494700992 |  dest_result_addr=1152921514494701000
        // 0x00BAE1E0: STP x24, x23, [sp, #0x40]  | stack[1152921514494701008] = ???;  stack[1152921514494701016] = ???;  //  dest_result_addr=1152921514494701008 |  dest_result_addr=1152921514494701016
        // 0x00BAE1E4: STP x22, x21, [sp, #0x50]  | stack[1152921514494701024] = ???;  stack[1152921514494701032] = ???;  //  dest_result_addr=1152921514494701024 |  dest_result_addr=1152921514494701032
        // 0x00BAE1E8: STP x20, x19, [sp, #0x60]  | stack[1152921514494701040] = ???;  stack[1152921514494701048] = ???;  //  dest_result_addr=1152921514494701040 |  dest_result_addr=1152921514494701048
        // 0x00BAE1EC: STP x29, x30, [sp, #0x70]  | stack[1152921514494701056] = ???;  stack[1152921514494701064] = ???;  //  dest_result_addr=1152921514494701056 |  dest_result_addr=1152921514494701064
        // 0x00BAE1F0: ADD x29, sp, #0x70         | X29 = (1152921514494700944 + 112) = 1152921514494701056 (0x100000024D5CAE00);
        // 0x00BAE1F4: SUB sp, sp, #0x90          | SP = (1152921514494700944 - 144) = 1152921514494700800 (0x100000024D5CAD00);
        // 0x00BAE1F8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAE1FC: LDRB w8, [x20, #0xb0f]     | W8 = (bool)static_value_03733B0F;       
        // 0x00BAE200: MOV x19, x0                | X19 = 1152921514494713072 (0x100000024D5CDCF0);//ML01
        val_146 = this;
        // 0x00BAE204: TBNZ w8, #0, #0xbae220     | if (static_value_03733B0F == true) goto label_0;
        // 0x00BAE208: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
        // 0x00BAE20C: LDR x8, [x8, #0x400]       | X8 = 0x2B9028C;                         
        // 0x00BAE210: LDR w0, [x8]               | W0 = 0x1767;                            
        // 0x00BAE214: BL #0x2782188              | X0 = sub_2782188( ?? 0x1767, ????);     
        // 0x00BAE218: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAE21C: STRB w8, [x20, #0xb0f]     | static_value_03733B0F = true;            //  dest_result_addr=57883407
        label_0:
        // 0x00BAE220: STR wzr, [sp, #0x88]       | stack[1152921514494700936] = 0x0;        //  dest_result_addr=1152921514494700936
        // 0x00BAE224: STR xzr, [sp, #0x80]       | stack[1152921514494700928] = 0x0;        //  dest_result_addr=1152921514494700928
        // 0x00BAE228: STR wzr, [sp, #0x78]       | stack[1152921514494700920] = 0x0;        //  dest_result_addr=1152921514494700920
        // 0x00BAE22C: STR xzr, [sp, #0x70]       | stack[1152921514494700912] = 0x0;        //  dest_result_addr=1152921514494700912
        // 0x00BAE230: STR wzr, [sp, #0x68]       | stack[1152921514494700904] = 0x0;        //  dest_result_addr=1152921514494700904
        // 0x00BAE234: STR xzr, [sp, #0x60]       | stack[1152921514494700896] = 0x0;        //  dest_result_addr=1152921514494700896
        // 0x00BAE238: STR wzr, [sp, #0x58]       | stack[1152921514494700888] = 0x0;        //  dest_result_addr=1152921514494700888
        // 0x00BAE23C: STR xzr, [sp, #0x50]       | stack[1152921514494700880] = 0x0;        //  dest_result_addr=1152921514494700880
        // 0x00BAE240: STR wzr, [sp, #0x48]       | stack[1152921514494700872] = 0x0;        //  dest_result_addr=1152921514494700872
        // 0x00BAE244: STR xzr, [sp, #0x40]       | stack[1152921514494700864] = 0x0;        //  dest_result_addr=1152921514494700864
        // 0x00BAE248: STR wzr, [sp, #0x38]       | stack[1152921514494700856] = 0x0;        //  dest_result_addr=1152921514494700856
        // 0x00BAE24C: STR xzr, [sp, #0x30]       | stack[1152921514494700848] = 0x0;        //  dest_result_addr=1152921514494700848
        // 0x00BAE250: STR wzr, [sp, #0x28]       | stack[1152921514494700840] = 0x0;        //  dest_result_addr=1152921514494700840
        // 0x00BAE254: STR xzr, [sp, #0x20]       | stack[1152921514494700832] = 0x0;        //  dest_result_addr=1152921514494700832
        // 0x00BAE258: LDRB w8, [x19, #0x22]      | W8 = this.isCircleCameraMoving; //P2    
        // 0x00BAE25C: CBZ w8, #0xbae970          | if (this.isCircleCameraMoving == false) goto label_1;
        if(this.isCircleCameraMoving == false)
        {
            goto label_1;
        }
        // 0x00BAE260: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BAE264: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BAE268: LDR x20, [x19, #0x28]      | X20 = this.circle_TargetTr; //P2        
        // 0x00BAE26C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BAE270: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BAE274: TBZ w8, #0, #0xbae284      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00BAE278: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE27C: CBNZ w8, #0xbae284         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00BAE280: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00BAE284: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE288: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAE28C: MOV x1, x20                | X1 = this.circle_TargetTr;//m1          
        // 0x00BAE290: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAE294: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.circle_TargetTr);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.circle_TargetTr);
        // 0x00BAE298: ADRP x21, #0x363f000       | X21 = 56881152 (0x363F000);             
        // 0x00BAE29C: LDR x21, [x21, #0x3b0]     | X21 = 1152921504695345152;              
        // 0x00BAE2A0: LDR s8, [x19, #0x40]       | S8 = this.circle_Distance; //P2         
        // 0x00BAE2A4: LDR x8, [x21]              | X8 = typeof(UnityEngine.Mathf);         
        // 0x00BAE2A8: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504695345417 (0x1000000005466109);
        // 0x00BAE2AC: LDRH w9, [x9]              | W9 = UnityEngine.Mathf.__il2cppRuntimeField_109;
        // 0x00BAE2B0: AND w9, w9, #0x100         | W9 = (UnityEngine.Mathf.__il2cppRuntimeField_109 & 256);
        // 0x00BAE2B4: AND w9, w9, #0xffff        | W9 = ((UnityEngine.Mathf.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00BAE2B8: TBZ w0, #0, #0xbae34c      | if (val_1 == false) goto label_4;       
        if(val_1 == false)
        {
            goto label_4;
        }
        // 0x00BAE2BC: CBZ w9, #0xbae2d0          | if (((UnityEngine.Mathf.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_6;
        // 0x00BAE2C0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE2C4: CBNZ w9, #0xbae2d0         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00BAE2C8: MOV x0, x8                 | X0 = 1152921504695345152 (0x1000000005466000);//ML01
        // 0x00BAE2CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_6:
        // 0x00BAE2D0: LDR s0, [x19, #0x44]       | S0 = this.circle_High; //P2             
        float val_146 = this.circle_High;
        // 0x00BAE2D4: FMUL s1, s8, s8            | S1 = (this.circle_Distance * this.circle_Distance);
        float val_4 = this.circle_Distance * this.circle_Distance;
        // 0x00BAE2D8: FMUL s0, s0, s0            | S0 = (this.circle_High * this.circle_High);
        val_146 = val_146 * val_146;
        // 0x00BAE2DC: FSUB s1, s1, s0            | S1 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));
        val_4 = val_4 - val_146;
        // 0x00BAE2E0: FSQRT s0, s1               | 
        // 0x00BAE2E4: FCMP s0, s0                | STATE = COMPARE((this.circle_High * this.circle_High), (this.circle_High * this.circle_High))
        // 0x00BAE2E8: B.VC #0xbae2f4             | if (this.circle_High < _TYPE_MAX_) goto label_7;
        if(val_146 < _TYPE_MAX_)
        {
            goto label_7;
        }
        // 0x00BAE2EC: MOV v0.16b, v1.16b         | V0 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));//m1
        // 0x00BAE2F0: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
        label_7:
        // 0x00BAE2F4: LDR w20, [x19, #0x6c]      | W20 = this.isRight; //P2                
        // 0x00BAE2F8: LDR s8, [x19, #0x58]       | S8 = this.circle_angled; //P2           
        // 0x00BAE2FC: LDR s9, [x19, #0x3c]       | S9 = this.circle_Speed; //P2            
        // 0x00BAE300: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE304: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE308: STR s0, [x19, #0x54]       | this.circle_R = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));  //  dest_result_addr=1152921514494713156
        this.circle_R = val_4;
        // 0x00BAE30C: BL #0x2690de0              | X0 = UnityEngine.Time.get_fixedDeltaTime();
        float val_5 = UnityEngine.Time.fixedDeltaTime;
        // 0x00BAE310: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAE314: LDR s1, [x8, #0x76c]       | S1 = 360;                               
        // 0x00BAE318: FMUL s2, s9, s0            | S2 = (this.circle_Speed * val_5);       
        float val_6 = this.circle_Speed * val_5;
        // 0x00BAE31C: FNMUL s0, s9, s0           | S0 = (this.circle_Speed * val_5);       
        val_5 = -(this.circle_Speed * val_5);
        // 0x00BAE320: CMP w20, #1                | STATE = COMPARE(this.isRight, 0x1)      
        // 0x00BAE324: FCSEL s0, s2, s0, eq       | S0 = this.isRight == 1 ? (this.circle_Speed * val_5) : (this.circle_Speed * val_5);
        float val_7 = (this.isRight == 1) ? (val_6) : (val_5);
        // 0x00BAE328: FADD s0, s8, s0            | S0 = (this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_5) : (this.circle_Speed * val_5));
        val_7 = this.circle_angled + val_7;
        // 0x00BAE32C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAE330: STR s0, [x19, #0x58]       | this.circle_angled = (this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_5) : (this.circle_Speed * val_5));  //  dest_result_addr=1152921514494713160
        this.circle_angled = val_7;
        // 0x00BAE334: FCMP s0, s1                | STATE = COMPARE((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_5) : (this.circle_Speed * val_5)), 360)
        // 0x00BAE338: B.GE #0xbae3dc             | if (val_7 >= 360f) goto label_8;        
        if(val_7 >= 360f)
        {
            goto label_8;
        }
        // 0x00BAE33C: LDR s2, [x8, #0x7b4]       | S2 = -360;                              
        // 0x00BAE340: FCMP s0, s2                | STATE = COMPARE((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_5) : (this.circle_Speed * val_5)), -360)
        // 0x00BAE344: B.HI #0xbae3e8             | if (val_7 > -360f) goto label_9;        
        if(val_7 > (-360f))
        {
            goto label_9;
        }
        // 0x00BAE348: B #0xbae3e0                |  goto label_10;                         
        goto label_10;
        label_4:
        // 0x00BAE34C: CBZ w9, #0xbae360          | if (((UnityEngine.Mathf.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_12;
        // 0x00BAE350: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE354: CBNZ w9, #0xbae360         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00BAE358: MOV x0, x8                 | X0 = 1152921504695345152 (0x1000000005466000);//ML01
        // 0x00BAE35C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_12:
        // 0x00BAE360: LDR s0, [x19, #0x44]       | S0 = this.circle_High; //P2             
        float val_147 = this.circle_High;
        // 0x00BAE364: FMUL s1, s8, s8            | S1 = (this.circle_Distance * this.circle_Distance);
        float val_8 = this.circle_Distance * this.circle_Distance;
        // 0x00BAE368: FMUL s0, s0, s0            | S0 = (this.circle_High * this.circle_High);
        val_147 = val_147 * val_147;
        // 0x00BAE36C: FSUB s1, s1, s0            | S1 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));
        val_8 = val_8 - val_147;
        // 0x00BAE370: FSQRT s0, s1               | 
        // 0x00BAE374: FCMP s0, s0                | STATE = COMPARE((this.circle_High * this.circle_High), (this.circle_High * this.circle_High))
        // 0x00BAE378: B.VC #0xbae384             | if (this.circle_High < _TYPE_MAX_) goto label_13;
        if(val_147 < _TYPE_MAX_)
        {
            goto label_13;
        }
        // 0x00BAE37C: MOV v0.16b, v1.16b         | V0 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));//m1
        // 0x00BAE380: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
        label_13:
        // 0x00BAE384: LDR w20, [x19, #0x6c]      | W20 = this.isRight; //P2                
        // 0x00BAE388: LDR s8, [x19, #0x58]       | S8 = this.circle_angled; //P2           
        float val_148 = this.circle_angled;
        // 0x00BAE38C: LDR s9, [x19, #0x3c]       | S9 = this.circle_Speed; //P2            
        // 0x00BAE390: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE398: STR s0, [x19, #0x54]       | this.circle_R = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));  //  dest_result_addr=1152921514494713156
        this.circle_R = val_8;
        // 0x00BAE39C: BL #0x2690de0              | X0 = UnityEngine.Time.get_fixedDeltaTime();
        float val_9 = UnityEngine.Time.fixedDeltaTime;
        // 0x00BAE3A0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAE3A4: FMUL s1, s9, s0            | S1 = (this.circle_Speed * val_9);       
        float val_10 = this.circle_Speed * val_9;
        // 0x00BAE3A8: FNMUL s2, s9, s0           | S2 = (this.circle_Speed * val_9);       
        float val_11 = -(this.circle_Speed * val_9);
        // 0x00BAE3AC: LDR s0, [x8, #0x76c]       | S0 = 360;                               
        // 0x00BAE3B0: CMP w20, #1                | STATE = COMPARE(this.isRight, 0x1)      
        // 0x00BAE3B4: FCSEL s1, s1, s2, eq       | S1 = this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9);
        float val_12 = (this.isRight == 1) ? (val_10) : (val_11);
        // 0x00BAE3B8: FADD s8, s8, s1            | S8 = (this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9));
        val_148 = val_148 + val_12;
        // 0x00BAE3BC: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAE3C0: STR s8, [x19, #0x58]       | this.circle_angled = (this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9));  //  dest_result_addr=1152921514494713160
        this.circle_angled = val_148;
        // 0x00BAE3C4: FCMP s8, s0                | STATE = COMPARE((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9)), 360)
        // 0x00BAE3C8: B.GE #0xbae790             | if (this.circle_angled >= 360f) goto label_14;
        if(val_148 >= 360f)
        {
            goto label_14;
        }
        // 0x00BAE3CC: LDR s1, [x8, #0x7b4]       | S1 = -360;                              
        // 0x00BAE3D0: FCMP s8, s1                | STATE = COMPARE((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9)), -360)
        // 0x00BAE3D4: B.HI #0xbae79c             | if (this.circle_angled > -360f) goto label_15;
        if(val_148 > (-360f))
        {
            goto label_15;
        }
        // 0x00BAE3D8: B #0xbae794                |  goto label_16;                         
        goto label_16;
        label_8:
        // 0x00BAE3DC: LDR s1, [x8, #0x7b4]       | S1 = -360;                              
        label_10:
        // 0x00BAE3E0: FADD s0, s0, s1            | S0 = ((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_5) : (this.circle_Speed * val_5)) + -360f);
        val_7 = val_7 + (-360f);
        // 0x00BAE3E4: STR s0, [x19, #0x58]       | this.circle_angled = ((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_5) : (this.circle_Speed * val_5)) + -360f);  //  dest_result_addr=1152921514494713160
        this.circle_angled = val_7;
        label_9:
        // 0x00BAE3E8: LDR x20, [x19, #0x28]      | X20 = this.circle_TargetTr; //P2        
        // 0x00BAE3EC: CBNZ x20, #0xbae3f4        | if (this.circle_TargetTr != null) goto label_17;
        if(this.circle_TargetTr != null)
        {
            goto label_17;
        }
        // 0x00BAE3F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_17:
        // 0x00BAE3F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE3F8: MOV x0, x20                | X0 = this.circle_TargetTr;//m1          
        // 0x00BAE3FC: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_13 = this.circle_TargetTr.position;
        // 0x00BAE400: LDR x0, [x21]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BAE404: LDP s12, s9, [x19, #0x54]  | S12 = this.circle_R; //P2  S9 = this.circle_angled; //P2  //  | 
        // 0x00BAE408: STR s0, [sp, #0xc]         | stack[1152921514494700812] = val_13.x;   //  dest_result_addr=1152921514494700812
        // 0x00BAE40C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BAE410: TBZ w8, #0, #0xbae420      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00BAE414: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE418: CBNZ w8, #0xbae420         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00BAE41C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_19:
        // 0x00BAE420: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAE424: LDR s13, [x8, #0x7b8]      | S13 = 180;                              
        // 0x00BAE428: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAE42C: LDR s14, [x8, #0xd6c]      | S14 = 3.141593;                         
        val_147 = 3.141593f;
        // 0x00BAE430: FDIV s0, s9, s13           | S0 = (this.circle_angled / 180f);       
        float val_14 = this.circle_angled / 180f;
        // 0x00BAE434: FMUL s0, s0, s14           | S0 = ((this.circle_angled / 180f) * val_147);
        val_14 = val_14 * val_147;
        // 0x00BAE438: BL #0x981480               | X0 = sub_981480( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00BAE43C: LDR x20, [x19, #0x28]      | X20 = this.circle_TargetTr; //P2        
        // 0x00BAE440: MOV v9.16b, v0.16b         | V9 = ((this.circle_angled / 180f) * val_147);//m1
        // 0x00BAE444: CBNZ x20, #0xbae44c        | if (this.circle_TargetTr != null) goto label_20;
        if(this.circle_TargetTr != null)
        {
            goto label_20;
        }
        // 0x00BAE448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_20:
        // 0x00BAE44C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE450: MOV x0, x20                | X0 = this.circle_TargetTr;//m1          
        // 0x00BAE454: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_15 = this.circle_TargetTr.position;
        // 0x00BAE458: LDR s15, [x19, #0x44]      | S15 = this.circle_High; //P2            
        // 0x00BAE45C: LDR x20, [x19, #0x28]      | X20 = this.circle_TargetTr; //P2        
        // 0x00BAE460: MOV v10.16b, v1.16b        | V10 = val_15.y;//m1                     
        // 0x00BAE464: CBNZ x20, #0xbae46c        | if (this.circle_TargetTr != null) goto label_21;
        if(this.circle_TargetTr != null)
        {
            goto label_21;
        }
        // 0x00BAE468: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.circle_TargetTr, ????);
        label_21:
        // 0x00BAE46C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE470: MOV x0, x20                | X0 = this.circle_TargetTr;//m1          
        // 0x00BAE474: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_16 = this.circle_TargetTr.position;
        // 0x00BAE478: LDP s8, s0, [x19, #0x54]   | S8 = this.circle_R; //P2  S0 = this.circle_angled; //P2  //  | 
        float val_149 = this.circle_angled;
        // 0x00BAE47C: MOV v11.16b, v2.16b        | V11 = val_16.z;//m1                     
        // 0x00BAE480: FDIV s0, s0, s13           | S0 = (this.circle_angled / 180f);       
        val_149 = val_149 / 180f;
        // 0x00BAE484: FMUL s0, s0, s14           | S0 = ((this.circle_angled / 180f) * val_147);
        val_149 = val_149 * val_147;
        // 0x00BAE488: BL #0x9811b0               | X0 = sub_9811B0( ?? this.circle_TargetTr, ????);
        // 0x00BAE48C: FMUL s3, s8, s0            | S3 = (this.circle_R * ((this.circle_angled / 180f) * val_147));
        float val_17 = this.circle_R * val_149;
        // 0x00BAE490: LDR s0, [sp, #0xc]         | S0 = val_13.x;                          
        float val_150 = val_13.x;
        // 0x00BAE494: FMUL s2, s12, s9           | S2 = (this.circle_R * ((this.circle_angled / 180f) * val_147));
        float val_18 = this.circle_R * val_14;
        // 0x00BAE498: FADD s1, s10, s15          | S1 = (val_15.y + this.circle_High);     
        float val_19 = val_15.y + this.circle_High;
        // 0x00BAE49C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE4A0: FADD s0, s0, s2            | S0 = (val_13.x + (this.circle_R * ((this.circle_angled / 180f) * val_147)));
        val_150 = val_150 + val_18;
        // 0x00BAE4A4: FADD s2, s11, s3           | S2 = (val_16.z + (this.circle_R * ((this.circle_angled / 180f) * val_147)));
        float val_20 = val_16.z + val_17;
        // 0x00BAE4A8: ADD x0, sp, #0x10          | X0 = (1152921514494700800 + 16) = 1152921514494700816 (0x100000024D5CAD10);
        // 0x00BAE4AC: STR wzr, [sp, #0x18]       | stack[1152921514494700824] = 0x0;        //  dest_result_addr=1152921514494700824
        // 0x00BAE4B0: STR xzr, [sp, #0x10]       | stack[1152921514494700816] = 0x0;        //  dest_result_addr=1152921514494700816
        // 0x00BAE4B4: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00BAE4B8: LDP w8, w9, [sp, #0x10]    | W8 = 0x0; W9 = 0x0;                      //  | 
        // 0x00BAE4BC: LDR w10, [sp, #0x18]       | W10 = 0x0;                              
        // 0x00BAE4C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE4C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE4C8: STP w8, w9, [x19, #0x70]   | this.curCirclePos = new UnityEngine.Vector3();  mem[1152921514494713188] = 0x0;  //  dest_result_addr=1152921514494713184 |  dest_result_addr=1152921514494713188
        this.curCirclePos = 0;
        mem[1152921514494713188] = 0;
        // 0x00BAE4CC: STR w10, [x19, #0x78]      | mem[1152921514494713192] = 0x0;          //  dest_result_addr=1152921514494713192
        mem[1152921514494713192] = 0;
        // 0x00BAE4D0: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_21 = UnityEngine.Camera.main;
        // 0x00BAE4D4: MOV x20, x0                | X20 = val_21;//m1                       
        // 0x00BAE4D8: CBNZ x20, #0xbae4e0        | if (val_21 != null) goto label_22;      
        if(val_21 != null)
        {
            goto label_22;
        }
        // 0x00BAE4DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_22:
        // 0x00BAE4E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE4E4: MOV x0, x20                | X0 = val_21;//m1                        
        // 0x00BAE4E8: BL #0x20d5094              | X0 = val_21.get_transform();            
        UnityEngine.Transform val_22 = val_21.transform;
        // 0x00BAE4EC: MOV x20, x0                | X20 = val_22;//m1                       
        // 0x00BAE4F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE4F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE4F8: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_23 = UnityEngine.Camera.main;
        // 0x00BAE4FC: MOV x21, x0                | X21 = val_23;//m1                       
        // 0x00BAE500: CBNZ x21, #0xbae508        | if (val_23 != null) goto label_23;      
        if(val_23 != null)
        {
            goto label_23;
        }
        // 0x00BAE504: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_23:
        // 0x00BAE508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE50C: MOV x0, x21                | X0 = val_23;//m1                        
        // 0x00BAE510: BL #0x20d5094              | X0 = val_23.get_transform();            
        UnityEngine.Transform val_24 = val_23.transform;
        // 0x00BAE514: MOV x21, x0                | X21 = val_24;//m1                       
        // 0x00BAE518: CBNZ x21, #0xbae520        | if (val_24 != null) goto label_24;      
        if(val_24 != null)
        {
            goto label_24;
        }
        // 0x00BAE51C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_24:
        // 0x00BAE520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE524: MOV x0, x21                | X0 = val_24;//m1                        
        // 0x00BAE528: BL #0x2693510              | X0 = val_24.get_position();             
        UnityEngine.Vector3 val_25 = val_24.position;
        // 0x00BAE52C: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAE530: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAE534: MOV v8.16b, v0.16b         | V8 = val_25.x;//m1                      
        // 0x00BAE538: MOV v9.16b, v1.16b         | V9 = val_25.y;//m1                      
        // 0x00BAE53C: MOV v13.16b, v2.16b        | V13 = val_25.z;//m1                     
        // 0x00BAE540: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAE544: LDP s12, s11, [x19, #0x70] | S12 = this.curCirclePos; //P2            //  | 
        val_148 = this.curCirclePos;
        // 0x00BAE548: LDR s10, [x19, #0x78]      | 
        // 0x00BAE54C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAE550: TBZ w8, #0, #0xbae560      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_26;
        // 0x00BAE554: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE558: CBNZ w8, #0xbae560         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
        // 0x00BAE55C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_26:
        // 0x00BAE560: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE564: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE568: FMOV s6, #0.50000000       | S6 = 0.5;                               
        // 0x00BAE56C: MOV v0.16b, v8.16b         | V0 = val_25.x;//m1                      
        // 0x00BAE570: MOV v1.16b, v9.16b         | V1 = val_25.y;//m1                      
        // 0x00BAE574: MOV v2.16b, v13.16b        | V2 = val_25.z;//m1                      
        // 0x00BAE578: MOV v3.16b, v12.16b        | V3 = this.curCirclePos;//m1             
        // 0x00BAE57C: MOV v4.16b, v11.16b        | V4 = val_16.z;//m1                      
        // 0x00BAE580: MOV v5.16b, v10.16b        | V5 = val_15.y;//m1                      
        // 0x00BAE584: BL #0x2698e54              | X0 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z}, b:  new UnityEngine.Vector3() {x = val_148, y = val_16.z, z = val_15.y}, t:  0.5f);
        UnityEngine.Vector3 val_26 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z}, b:  new UnityEngine.Vector3() {x = val_148, y = val_16.z, z = val_15.y}, t:  0.5f);
        // 0x00BAE588: MOV v8.16b, v0.16b         | V8 = val_26.x;//m1                      
        // 0x00BAE58C: MOV v9.16b, v1.16b         | V9 = val_26.y;//m1                      
        // 0x00BAE590: MOV v10.16b, v2.16b        | V10 = val_26.z;//m1                     
        // 0x00BAE594: CBNZ x20, #0xbae59c        | if (val_22 != null) goto label_27;      
        if(val_22 != null)
        {
            goto label_27;
        }
        // 0x00BAE598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_27:
        // 0x00BAE59C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE5A0: MOV x0, x20                | X0 = val_22;//m1                        
        // 0x00BAE5A4: MOV v0.16b, v8.16b         | V0 = val_26.x;//m1                      
        // 0x00BAE5A8: MOV v1.16b, v9.16b         | V1 = val_26.y;//m1                      
        // 0x00BAE5AC: MOV v2.16b, v10.16b        | V2 = val_26.z;//m1                      
        // 0x00BAE5B0: BL #0x26935b8              | val_22.set_position(value:  new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z});
        val_22.position = new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z};
        // 0x00BAE5B4: LDP s8, s9, [x19, #0x70]   | S8 = this.curCirclePos; //P2             //  | 
        // 0x00BAE5B8: LDR s10, [x19, #0x78]      | 
        // 0x00BAE5BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE5C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE5C4: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_27 = UnityEngine.Camera.main;
        // 0x00BAE5C8: MOV x20, x0                | X20 = val_27;//m1                       
        // 0x00BAE5CC: CBNZ x20, #0xbae5d4        | if (val_27 != null) goto label_28;      
        if(val_27 != null)
        {
            goto label_28;
        }
        // 0x00BAE5D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_28:
        // 0x00BAE5D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE5D8: MOV x0, x20                | X0 = val_27;//m1                        
        // 0x00BAE5DC: BL #0x20d5094              | X0 = val_27.get_transform();            
        UnityEngine.Transform val_28 = val_27.transform;
        // 0x00BAE5E0: MOV x20, x0                | X20 = val_28;//m1                       
        // 0x00BAE5E4: CBNZ x20, #0xbae5ec        | if (val_28 != null) goto label_29;      
        if(val_28 != null)
        {
            goto label_29;
        }
        // 0x00BAE5E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_29:
        // 0x00BAE5EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE5F0: MOV x0, x20                | X0 = val_28;//m1                        
        // 0x00BAE5F4: BL #0x2693510              | X0 = val_28.get_position();             
        UnityEngine.Vector3 val_29 = val_28.position;
        // 0x00BAE5F8: MOV v3.16b, v0.16b         | V3 = val_29.x;//m1                      
        // 0x00BAE5FC: MOV v4.16b, v1.16b         | V4 = val_29.y;//m1                      
        // 0x00BAE600: MOV v5.16b, v2.16b         | V5 = val_29.z;//m1                      
        // 0x00BAE604: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE60C: MOV v0.16b, v8.16b         | V0 = this.curCirclePos;//m1             
        // 0x00BAE610: MOV v1.16b, v9.16b         | V1 = val_26.y;//m1                      
        // 0x00BAE614: MOV v2.16b, v10.16b        | V2 = val_26.z;//m1                      
        // 0x00BAE618: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = this.curCirclePos, y = val_26.y, z = val_26.z}, b:  new UnityEngine.Vector3() {x = val_29.x, y = val_29.y, z = val_29.z});
        float val_30 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = this.curCirclePos, y = val_26.y, z = val_26.z}, b:  new UnityEngine.Vector3() {x = val_29.x, y = val_29.y, z = val_29.z});
        // 0x00BAE61C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE620: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE624: MOV v8.16b, v0.16b         | V8 = val_30;//m1                        
        // 0x00BAE628: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_31 = UnityEngine.Camera.main;
        // 0x00BAE62C: MOV x20, x0                | X20 = val_31;//m1                       
        // 0x00BAE630: CBNZ x20, #0xbae638        | if (val_31 != null) goto label_30;      
        if(val_31 != null)
        {
            goto label_30;
        }
        // 0x00BAE634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_30:
        // 0x00BAE638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE63C: MOV x0, x20                | X0 = val_31;//m1                        
        // 0x00BAE640: BL #0x20d5094              | X0 = val_31.get_transform();            
        UnityEngine.Transform val_32 = val_31.transform;
        // 0x00BAE644: LDP s9, s10, [x19, #0x70]  | S9 = this.curCirclePos; //P2             //  | 
        // 0x00BAE648: LDR s11, [x19, #0x78]      | 
        // 0x00BAE64C: MOV x20, x0                | X20 = val_32;//m1                       
        // 0x00BAE650: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE654: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE658: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_33 = UnityEngine.Camera.main;
        // 0x00BAE65C: MOV x21, x0                | X21 = val_33;//m1                       
        // 0x00BAE660: CBNZ x21, #0xbae668        | if (val_33 != null) goto label_31;      
        if(val_33 != null)
        {
            goto label_31;
        }
        // 0x00BAE664: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
        label_31:
        // 0x00BAE668: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE66C: MOV x0, x21                | X0 = val_33;//m1                        
        // 0x00BAE670: BL #0x20d5094              | X0 = val_33.get_transform();            
        UnityEngine.Transform val_34 = val_33.transform;
        // 0x00BAE674: MOV x21, x0                | X21 = val_34;//m1                       
        // 0x00BAE678: CBNZ x21, #0xbae680        | if (val_34 != null) goto label_32;      
        if(val_34 != null)
        {
            goto label_32;
        }
        // 0x00BAE67C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_32:
        // 0x00BAE680: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE684: MOV x0, x21                | X0 = val_34;//m1                        
        // 0x00BAE688: BL #0x2693510              | X0 = val_34.get_position();             
        UnityEngine.Vector3 val_35 = val_34.position;
        // 0x00BAE68C: MOV v3.16b, v0.16b         | V3 = val_35.x;//m1                      
        // 0x00BAE690: MOV v4.16b, v1.16b         | V4 = val_35.y;//m1                      
        // 0x00BAE694: MOV v5.16b, v2.16b         | V5 = val_35.z;//m1                      
        // 0x00BAE698: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE69C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE6A0: MOV v0.16b, v9.16b         | V0 = this.curCirclePos;//m1             
        // 0x00BAE6A4: MOV v1.16b, v10.16b        | V1 = val_26.z;//m1                      
        // 0x00BAE6A8: MOV v2.16b, v11.16b        | V2 = val_16.z;//m1                      
        // 0x00BAE6AC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.curCirclePos, y = val_26.z, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_35.x, y = val_35.y, z = val_35.z});
        UnityEngine.Vector3 val_36 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.curCirclePos, y = val_26.z, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_35.x, y = val_35.y, z = val_35.z});
        // 0x00BAE6B0: ADD x0, sp, #0x80          | X0 = (1152921514494700800 + 128) = 1152921514494700928 (0x100000024D5CAD80);
        // 0x00BAE6B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE6B8: STP s0, s1, [sp, #0x80]    | stack[1152921514494700928] = val_36.x;  stack[1152921514494700932] = val_36.y;  //  dest_result_addr=1152921514494700928 |  dest_result_addr=1152921514494700932
        // 0x00BAE6BC: STR s2, [sp, #0x88]        | stack[1152921514494700936] = val_36.z;   //  dest_result_addr=1152921514494700936
        // 0x00BAE6C0: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BAE6C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE6C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE6CC: MOV v9.16b, v0.16b         | V9 = val_36.x;//m1                      
        // 0x00BAE6D0: MOV v10.16b, v1.16b        | V10 = val_36.y;//m1                     
        // 0x00BAE6D4: MOV v11.16b, v2.16b        | V11 = val_36.z;//m1                     
        // 0x00BAE6D8: BL #0x2690de0              | X0 = UnityEngine.Time.get_fixedDeltaTime();
        float val_37 = UnityEngine.Time.fixedDeltaTime;
        // 0x00BAE6DC: MOV v3.16b, v0.16b         | V3 = val_37;//m1                        
        // 0x00BAE6E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE6E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE6E8: MOV v0.16b, v9.16b         | V0 = val_36.x;//m1                      
        // 0x00BAE6EC: MOV v1.16b, v10.16b        | V1 = val_36.y;//m1                      
        // 0x00BAE6F0: MOV v2.16b, v11.16b        | V2 = val_36.z;//m1                      
        // 0x00BAE6F4: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_36.x, y = val_36.y, z = val_36.z}, d:  val_37);
        UnityEngine.Vector3 val_38 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_36.x, y = val_36.y, z = val_36.z}, d:  val_37);
        // 0x00BAE6F8: FMOV s3, #8.00000000       | S3 = 8;                                 
        float val_151 = 8f;
        // 0x00BAE6FC: FMUL s3, s8, s3            | S3 = (val_30 * 8f);                     
        val_151 = val_30 * val_151;
        // 0x00BAE700: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE704: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE708: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, d:  8f = val_30 * 8f);
        UnityEngine.Vector3 val_39 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, d:  val_151);
        // 0x00BAE70C: MOV v8.16b, v0.16b         | V8 = val_39.x;//m1                      
        // 0x00BAE710: MOV v9.16b, v1.16b         | V9 = val_39.y;//m1                      
        // 0x00BAE714: MOV v10.16b, v2.16b        | V10 = val_39.z;//m1                     
        // 0x00BAE718: CBNZ x20, #0xbae720        | if (val_32 != null) goto label_33;      
        if(val_32 != null)
        {
            goto label_33;
        }
        // 0x00BAE71C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_33:
        // 0x00BAE720: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAE724: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAE728: MOV x0, x20                | X0 = val_32;//m1                        
        // 0x00BAE72C: MOV v0.16b, v8.16b         | V0 = val_39.x;//m1                      
        // 0x00BAE730: MOV v1.16b, v9.16b         | V1 = val_39.y;//m1                      
        // 0x00BAE734: MOV v2.16b, v10.16b        | V2 = val_39.z;//m1                      
        // 0x00BAE738: BL #0x2694858              | val_32.Translate(translation:  new UnityEngine.Vector3() {x = val_39.x, y = val_39.y, z = val_39.z}, relativeTo:  0);
        val_32.Translate(translation:  new UnityEngine.Vector3() {x = val_39.x, y = val_39.y, z = val_39.z}, relativeTo:  0);
        // 0x00BAE73C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE744: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_40 = UnityEngine.Camera.main;
        // 0x00BAE748: MOV x20, x0                | X20 = val_40;//m1                       
        // 0x00BAE74C: CBNZ x20, #0xbae754        | if (val_40 != null) goto label_34;      
        if(val_40 != null)
        {
            goto label_34;
        }
        // 0x00BAE750: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_34:
        // 0x00BAE754: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE758: MOV x0, x20                | X0 = val_40;//m1                        
        // 0x00BAE75C: BL #0x20d5094              | X0 = val_40.get_transform();            
        UnityEngine.Transform val_41 = val_40.transform;
        // 0x00BAE760: LDR x21, [x19, #0x28]      | X21 = this.circle_TargetTr; //P2        
        val_149 = this.circle_TargetTr;
        // 0x00BAE764: MOV x20, x0                | X20 = val_41;//m1                       
        // 0x00BAE768: CBNZ x21, #0xbae770        | if (this.circle_TargetTr != null) goto label_35;
        if(val_149 != null)
        {
            goto label_35;
        }
        // 0x00BAE76C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
        label_35:
        // 0x00BAE770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE774: MOV x0, x21                | X0 = this.circle_TargetTr;//m1          
        // 0x00BAE778: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_42 = val_149.position;
        // 0x00BAE77C: MOV v8.16b, v0.16b         | V8 = val_42.x;//m1                      
        val_150 = val_42.x;
        // 0x00BAE780: MOV v9.16b, v1.16b         | V9 = val_42.y;//m1                      
        // 0x00BAE784: MOV v10.16b, v2.16b        | V10 = val_42.z;//m1                     
        val_151 = val_42.z;
        // 0x00BAE788: CBNZ x20, #0xbae958        | if (val_41 != null) goto label_47;      
        if(val_41 != null)
        {
            goto label_47;
        }
        // 0x00BAE78C: B #0xbae954                |  goto label_37;                         
        goto label_37;
        label_14:
        // 0x00BAE790: LDR s0, [x8, #0x7b4]       | S0 = -360;                              
        label_16:
        // 0x00BAE794: FADD s8, s8, s0            | S8 = ((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9)) + -360f);
        val_148 = val_148 + (-360f);
        // 0x00BAE798: STR s8, [x19, #0x58]       | this.circle_angled = ((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9)) + -360f);  //  dest_result_addr=1152921514494713160
        this.circle_angled = val_148;
        label_15:
        // 0x00BAE79C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BAE7A0: LDR s0, [x19, #0x30]       | S0 = this.circle_TargetPos; //P2        
        // 0x00BAE7A4: LDR s10, [x19, #0x54]      | S10 = this.circle_R; //P2               
        // 0x00BAE7A8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BAE7AC: STR s0, [sp, #0xc]         | stack[1152921514494700812] = this.circle_TargetPos;  //  dest_result_addr=1152921514494700812
        // 0x00BAE7B0: TBZ w8, #0, #0xbae7c0      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_39;
        // 0x00BAE7B4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE7B8: CBNZ w8, #0xbae7c0         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_39;
        // 0x00BAE7BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_39:
        // 0x00BAE7C0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAE7C4: LDR s11, [x8, #0x7b8]      | S11 = 180;                              
        // 0x00BAE7C8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAE7CC: LDR s12, [x8, #0xd6c]      | S12 = 3.141593;                         
        // 0x00BAE7D0: FDIV s0, s8, s11           | S0 = (((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9)) + -360f) / 180f);
        float val_43 = val_148 / 180f;
        // 0x00BAE7D4: FMUL s0, s0, s12           | S0 = ((((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9)) + -360f) / 180f) * 3.141593f);
        val_43 = val_43 * 3.141593f;
        // 0x00BAE7D8: BL #0x981480               | X0 = sub_981480( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00BAE7DC: LDR s13, [x19, #0x44]      | S13 = this.circle_High; //P2            
        // 0x00BAE7E0: LDP s14, s1, [x19, #0x54]  | S14 = this.circle_R; //P2  S1 = this.circle_angled; //P2  //  | 
        val_147 = this.circle_R;
        // 0x00BAE7E4: LDP s15, s9, [x19, #0x34]  |                                          //  | 
        // 0x00BAE7E8: MOV v8.16b, v0.16b         | V8 = ((((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9)) + -360f) / 180f) * 3.141593f);//m1
        // 0x00BAE7EC: FDIV s0, s1, s11           | S0 = (this.circle_angled / 180f);       
        float val_44 = this.circle_angled / 180f;
        // 0x00BAE7F0: FMUL s0, s0, s12           | S0 = ((this.circle_angled / 180f) * 3.141593f);
        val_44 = val_44 * 3.141593f;
        // 0x00BAE7F4: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00BAE7F8: FMUL s3, s14, s0           | S3 = (this.circle_R * ((this.circle_angled / 180f) * 3.141593f));
        float val_45 = val_147 * val_44;
        // 0x00BAE7FC: LDR s0, [sp, #0xc]         | S0 = this.circle_TargetPos;             
        UnityEngine.Vector3 val_152 = this.circle_TargetPos;
        // 0x00BAE800: FMUL s2, s10, s8           | S2 = (this.circle_R * ((((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9)) + -360f) / 180f) * 3.141593f));
        val_11 = this.circle_R * val_43;
        // 0x00BAE804: FADD s1, s15, s13          | S1 = (S15 + this.circle_High);          
        float val_46 = S15 + this.circle_High;
        // 0x00BAE808: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE80C: FADD s0, s0, s2            | S0 = (this.circle_TargetPos + (this.circle_R * ((((this.circle_angled + this.isRight == 1 ? (this.circle_Speed * val_9) : (this.circle_Speed * val_9)) + -360f) / 180f) * 3.141593f)));
        val_152 = val_152 + val_11;
        // 0x00BAE810: FADD s2, s9, s3            | S2 = (this.circle_Speed + (this.circle_R * ((this.circle_angled / 180f) * 3.141593f)));
        float val_47 = this.circle_Speed + val_45;
        // 0x00BAE814: ADD x0, sp, #0x10          | X0 = (1152921514494700800 + 16) = 1152921514494700816 (0x100000024D5CAD10);
        // 0x00BAE818: STR wzr, [sp, #0x18]       | stack[1152921514494700824] = 0x0;        //  dest_result_addr=1152921514494700824
        // 0x00BAE81C: STR xzr, [sp, #0x10]       | stack[1152921514494700816] = 0x0;        //  dest_result_addr=1152921514494700816
        // 0x00BAE820: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00BAE824: LDP w8, w9, [sp, #0x10]    | W8 = 0x0; W9 = 0x0;                      //  | 
        // 0x00BAE828: LDR w10, [sp, #0x18]       | W10 = 0x0;                              
        // 0x00BAE82C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE834: STP w8, w9, [x19, #0x70]   | this.curCirclePos = new UnityEngine.Vector3();  mem[1152921514494713188] = 0x0;  //  dest_result_addr=1152921514494713184 |  dest_result_addr=1152921514494713188
        this.curCirclePos = 0;
        mem[1152921514494713188] = 0;
        // 0x00BAE838: STR w10, [x19, #0x78]      | mem[1152921514494713192] = 0x0;          //  dest_result_addr=1152921514494713192
        mem[1152921514494713192] = 0;
        // 0x00BAE83C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_48 = UnityEngine.Camera.main;
        // 0x00BAE840: MOV x20, x0                | X20 = val_48;//m1                       
        // 0x00BAE844: CBNZ x20, #0xbae84c        | if (val_48 != null) goto label_40;      
        if(val_48 != null)
        {
            goto label_40;
        }
        // 0x00BAE848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_40:
        // 0x00BAE84C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE850: MOV x0, x20                | X0 = val_48;//m1                        
        // 0x00BAE854: BL #0x20d5094              | X0 = val_48.get_transform();            
        UnityEngine.Transform val_49 = val_48.transform;
        // 0x00BAE858: MOV x20, x0                | X20 = val_49;//m1                       
        // 0x00BAE85C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE864: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_50 = UnityEngine.Camera.main;
        // 0x00BAE868: MOV x21, x0                | X21 = val_50;//m1                       
        // 0x00BAE86C: CBNZ x21, #0xbae874        | if (val_50 != null) goto label_41;      
        if(val_50 != null)
        {
            goto label_41;
        }
        // 0x00BAE870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
        label_41:
        // 0x00BAE874: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE878: MOV x0, x21                | X0 = val_50;//m1                        
        // 0x00BAE87C: BL #0x20d5094              | X0 = val_50.get_transform();            
        UnityEngine.Transform val_51 = val_50.transform;
        // 0x00BAE880: MOV x21, x0                | X21 = val_51;//m1                       
        val_149 = val_51;
        // 0x00BAE884: CBNZ x21, #0xbae88c        | if (val_51 != null) goto label_42;      
        if(val_149 != null)
        {
            goto label_42;
        }
        // 0x00BAE888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
        label_42:
        // 0x00BAE88C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE890: MOV x0, x21                | X0 = val_51;//m1                        
        // 0x00BAE894: BL #0x2693510              | X0 = val_51.get_position();             
        UnityEngine.Vector3 val_52 = val_149.position;
        // 0x00BAE898: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAE89C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAE8A0: MOV v8.16b, v0.16b         | V8 = val_52.x;//m1                      
        // 0x00BAE8A4: MOV v9.16b, v1.16b         | V9 = val_52.y;//m1                      
        // 0x00BAE8A8: MOV v13.16b, v2.16b        | V13 = val_52.z;//m1                     
        // 0x00BAE8AC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAE8B0: LDP s12, s11, [x19, #0x70] | S12 = this.curCirclePos; //P2            //  | 
        val_148 = this.curCirclePos;
        // 0x00BAE8B4: LDR s10, [x19, #0x78]      | 
        // 0x00BAE8B8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAE8BC: TBZ w8, #0, #0xbae8cc      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_44;
        // 0x00BAE8C0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE8C4: CBNZ w8, #0xbae8cc         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
        // 0x00BAE8C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_44:
        // 0x00BAE8CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE8D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE8D4: FMOV s6, #0.50000000       | S6 = 0.5;                               
        // 0x00BAE8D8: MOV v0.16b, v8.16b         | V0 = val_52.x;//m1                      
        // 0x00BAE8DC: MOV v1.16b, v9.16b         | V1 = val_52.y;//m1                      
        // 0x00BAE8E0: MOV v2.16b, v13.16b        | V2 = val_52.z;//m1                      
        // 0x00BAE8E4: MOV v3.16b, v12.16b        | V3 = this.curCirclePos;//m1             
        // 0x00BAE8E8: MOV v4.16b, v11.16b        | V4 = 180;//m1                           
        // 0x00BAE8EC: MOV v5.16b, v10.16b        | V5 = this.circle_R;//m1                 
        // 0x00BAE8F0: BL #0x2698e54              | X0 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = val_52.x, y = val_52.y, z = val_52.z}, b:  new UnityEngine.Vector3() {x = val_148, y = 180f, z = this.circle_R}, t:  0.5f);
        UnityEngine.Vector3 val_53 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = val_52.x, y = val_52.y, z = val_52.z}, b:  new UnityEngine.Vector3() {x = val_148, y = 180f, z = this.circle_R}, t:  0.5f);
        // 0x00BAE8F4: MOV v8.16b, v0.16b         | V8 = val_53.x;//m1                      
        // 0x00BAE8F8: MOV v9.16b, v1.16b         | V9 = val_53.y;//m1                      
        // 0x00BAE8FC: MOV v10.16b, v2.16b        | V10 = val_53.z;//m1                     
        // 0x00BAE900: CBNZ x20, #0xbae908        | if (val_49 != null) goto label_45;      
        if(val_49 != null)
        {
            goto label_45;
        }
        // 0x00BAE904: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_45:
        // 0x00BAE908: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE90C: MOV x0, x20                | X0 = val_49;//m1                        
        // 0x00BAE910: MOV v0.16b, v8.16b         | V0 = val_53.x;//m1                      
        // 0x00BAE914: MOV v1.16b, v9.16b         | V1 = val_53.y;//m1                      
        // 0x00BAE918: MOV v2.16b, v10.16b        | V2 = val_53.z;//m1                      
        // 0x00BAE91C: BL #0x26935b8              | val_49.set_position(value:  new UnityEngine.Vector3() {x = val_53.x, y = val_53.y, z = val_53.z});
        val_49.position = new UnityEngine.Vector3() {x = val_53.x, y = val_53.y, z = val_53.z};
        // 0x00BAE920: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE924: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE928: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_54 = UnityEngine.Camera.main;
        // 0x00BAE92C: MOV x20, x0                | X20 = val_54;//m1                       
        // 0x00BAE930: CBNZ x20, #0xbae938        | if (val_54 != null) goto label_46;      
        if(val_54 != null)
        {
            goto label_46;
        }
        // 0x00BAE934: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_54, ????);     
        label_46:
        // 0x00BAE938: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE93C: MOV x0, x20                | X0 = val_54;//m1                        
        // 0x00BAE940: BL #0x20d5094              | X0 = val_54.get_transform();            
        UnityEngine.Transform val_55 = val_54.transform;
        // 0x00BAE944: LDP s8, s9, [x19, #0x30]   | S8 = this.circle_TargetPos; //P2         //  | 
        val_150 = this.circle_TargetPos;
        // 0x00BAE948: LDR s10, [x19, #0x38]      | 
        // 0x00BAE94C: MOV x20, x0                | X20 = val_55;//m1                       
        // 0x00BAE950: CBNZ x20, #0xbae958        | if (val_55 != null) goto label_47;      
        if(val_55 != null)
        {
            goto label_47;
        }
        label_37:
        // 0x00BAE954: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_47:
        // 0x00BAE958: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE95C: MOV x0, x20                | X0 = val_55;//m1                        
        // 0x00BAE960: MOV v0.16b, v8.16b         | V0 = this.circle_TargetPos;//m1         
        // 0x00BAE964: MOV v1.16b, v9.16b         | V1 = val_53.y;//m1                      
        // 0x00BAE968: MOV v2.16b, v10.16b        | V2 = val_53.z;//m1                      
        // 0x00BAE96C: BL #0x26952ec              | val_55.LookAt(worldPosition:  new UnityEngine.Vector3() {x = val_150, y = val_53.y, z = val_53.z});
        val_55.LookAt(worldPosition:  new UnityEngine.Vector3() {x = val_150, y = val_53.y, z = val_53.z});
        label_1:
        // 0x00BAE970: LDRB w8, [x19, #0xbc]      | W8 = this.isLineRunning; //P2           
        // 0x00BAE974: CBZ w8, #0xbaf5f8          | if (this.isLineRunning == false) goto label_123;
        if(this.isLineRunning == false)
        {
            goto label_123;
        }
        // 0x00BAE978: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BAE97C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BAE980: LDR s0, [x19, #0xb4]       | S0 = this.lineTargetDis; //P2           
        // 0x00BAE984: LDR x20, [x19, #0xa0]      | X20 = this.line_Tr; //P2                
        // 0x00BAE988: FMOV s1, #-1.00000000      | S1 = -1;                                
        // 0x00BAE98C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BAE990: FCMP s0, s1                | STATE = COMPARE(this.lineTargetDis, -1) 
        // 0x00BAE994: ADD x8, x0, #0x109         | X8 = (null + 265) = 1152921504697475337 (0x100000000566E109);
        // 0x00BAE998: LDRH w8, [x8]              | W8 = UnityEngine.Object.__il2cppRuntimeField_109;
        // 0x00BAE99C: AND w8, w8, #0x100         | W8 = (UnityEngine.Object.__il2cppRuntimeField_109 & 256);
        // 0x00BAE9A0: AND w8, w8, #0xffff        | W8 = ((UnityEngine.Object.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00BAE9A4: B.NE #0xbaeacc             | if (this.lineTargetDis != -1f) goto label_49;
        if(this.lineTargetDis != (-1f))
        {
            goto label_49;
        }
        // 0x00BAE9A8: CBZ w8, #0xbae9b8          | if (((UnityEngine.Object.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_51;
        // 0x00BAE9AC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BAE9B0: CBNZ w8, #0xbae9b8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
        // 0x00BAE9B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_51:
        // 0x00BAE9B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE9BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAE9C0: MOV x1, x20                | X1 = this.line_Tr;//m1                  
        // 0x00BAE9C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAE9C8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.line_Tr);
        bool val_58 = UnityEngine.Object.op_Inequality(x:  0, y:  this.line_Tr);
        // 0x00BAE9CC: LDR w23, [x19, #0xe8]      | W23 = this.isDamp; //P2                 
        val_152 = this.isDamp;
        // 0x00BAE9D0: MOV w21, w0                | W21 = val_58;//m1                       
        val_149 = val_58;
        // 0x00BAE9D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAE9D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE9DC: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_59 = UnityEngine.Camera.main;
        // 0x00BAE9E0: MOV x20, x0                | X20 = val_59;//m1                       
        // 0x00BAE9E4: CBNZ x20, #0xbae9ec        | if (val_59 != null) goto label_52;      
        if(val_59 != null)
        {
            goto label_52;
        }
        // 0x00BAE9E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_59, ????);     
        label_52:
        // 0x00BAE9EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAE9F0: MOV x0, x20                | X0 = val_59;//m1                        
        // 0x00BAE9F4: BL #0x20d5094              | X0 = val_59.get_transform();            
        UnityEngine.Transform val_60 = val_59.transform;
        // 0x00BAE9F8: MOV x20, x0                | X20 = val_60;//m1                       
        // 0x00BAE9FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEA00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEA04: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_61 = UnityEngine.Camera.main;
        // 0x00BAEA08: MOV x22, x0                | X22 = val_61;//m1                       
        // 0x00BAEA0C: CBNZ x22, #0xbaea14        | if (val_61 != null) goto label_53;      
        if(val_61 != null)
        {
            goto label_53;
        }
        // 0x00BAEA10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
        label_53:
        // 0x00BAEA14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEA18: MOV x0, x22                | X0 = val_61;//m1                        
        // 0x00BAEA1C: BL #0x20d5094              | X0 = val_61.get_transform();            
        UnityEngine.Transform val_62 = val_61.transform;
        // 0x00BAEA20: MOV x22, x0                | X22 = val_62;//m1                       
        // 0x00BAEA24: CBNZ x22, #0xbaea2c        | if (val_62 != null) goto label_54;      
        if(val_62 != null)
        {
            goto label_54;
        }
        // 0x00BAEA28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_62, ????);     
        label_54:
        // 0x00BAEA2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEA30: MOV x0, x22                | X0 = val_62;//m1                        
        // 0x00BAEA34: BL #0x2693510              | X0 = val_62.get_position();             
        UnityEngine.Vector3 val_63 = val_62.position;
        // 0x00BAEA38: MOV v10.16b, v0.16b        | V10 = val_63.x;//m1                     
        // 0x00BAEA3C: MOV v9.16b, v1.16b         | V9 = val_63.y;//m1                      
        // 0x00BAEA40: MOV v8.16b, v2.16b         | V8 = val_63.z;//m1                      
        // 0x00BAEA44: TBZ w21, #0, #0xbaecc4     | if (val_58 == false) goto label_55;     
        if(val_149 == false)
        {
            goto label_55;
        }
        // 0x00BAEA48: LDR x21, [x19, #0xa0]      | X21 = this.line_Tr; //P2                
        val_149 = this.line_Tr;
        // 0x00BAEA4C: CBNZ x21, #0xbaea54        | if (this.line_Tr != null) goto label_56;
        if(val_149 != null)
        {
            goto label_56;
        }
        // 0x00BAEA50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_62, ????);     
        label_56:
        // 0x00BAEA54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEA58: MOV x0, x21                | X0 = this.line_Tr;//m1                  
        // 0x00BAEA5C: BL #0x2693510              | X0 = this.line_Tr.get_position();       
        UnityEngine.Vector3 val_64 = val_149.position;
        // 0x00BAEA60: MOV v13.16b, v0.16b        | V13 = val_64.x;//m1                     
        // 0x00BAEA64: MOV v12.16b, v1.16b        | V12 = val_64.y;//m1                     
        // 0x00BAEA68: MOV v11.16b, v2.16b        | V11 = val_64.z;//m1                     
        // 0x00BAEA6C: CMP w23, #1                | STATE = COMPARE(this.isDamp, 0x1)       
        // 0x00BAEA70: B.NE #0xbaee54             | if (val_152 != 1) goto label_57;        
        if(val_152 != 1)
        {
            goto label_57;
        }
        // 0x00BAEA74: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAEA78: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAEA7C: LDR s14, [x19, #0xb8]      | S14 = this.lineTime; //P2               
        val_147 = this.lineTime;
        // 0x00BAEA80: ADD x21, x19, #0xc0        | X21 = this.zero;//AP2 res_addr=1152921514494713264
        val_149 = this.zero;
        // 0x00BAEA84: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAEA88: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAEA8C: TBZ w8, #0, #0xbaea9c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_59;
        // 0x00BAEA90: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAEA94: CBNZ w8, #0xbaea9c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_59;
        // 0x00BAEA98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_59:
        // 0x00BAEA9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEAA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAEAA4: MOV v0.16b, v10.16b        | V0 = val_63.x;//m1                      
        val_153 = val_63.x;
        // 0x00BAEAA8: MOV v1.16b, v9.16b         | V1 = val_63.y;//m1                      
        val_154 = val_63.y;
        // 0x00BAEAAC: MOV v2.16b, v8.16b         | V2 = val_63.z;//m1                      
        val_155 = val_63.z;
        // 0x00BAEAB0: MOV v3.16b, v13.16b        | V3 = val_64.x;//m1                      
        // 0x00BAEAB4: MOV v4.16b, v12.16b        | V4 = val_64.y;//m1                      
        // 0x00BAEAB8: MOV v5.16b, v11.16b        | V5 = val_64.z;//m1                      
        // 0x00BAEABC: MOV x1, x21                | X1 = this.zero;//m1                     
        // 0x00BAEAC0: MOV v6.16b, v14.16b        | V6 = this.lineTime;//m1                 
        // 0x00BAEAC4: BL #0x2699498              | X0 = UnityEngine.Vector3.SmoothDamp(current:  new UnityEngine.Vector3() {x = val_153, y = val_154, z = val_155}, target:  new UnityEngine.Vector3() {x = val_64.x, y = val_64.y, z = val_64.z}, currentVelocity: ref  new UnityEngine.Vector3(), smoothTime:  val_147);
        UnityEngine.Vector3 val_65 = UnityEngine.Vector3.SmoothDamp(current:  new UnityEngine.Vector3() {x = val_153, y = val_154, z = val_155}, target:  new UnityEngine.Vector3() {x = val_64.x, y = val_64.y, z = val_64.z}, currentVelocity: ref  new UnityEngine.Vector3(), smoothTime:  val_147);
        // 0x00BAEAC8: B #0xbaeed8                |  goto label_60;                         
        goto label_60;
        label_49:
        // 0x00BAEACC: CBZ w8, #0xbaeadc          | if (((UnityEngine.Object.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_62;
        // 0x00BAEAD0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BAEAD4: CBNZ w8, #0xbaeadc         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_62;
        // 0x00BAEAD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_62:
        // 0x00BAEADC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEAE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAEAE4: MOV x1, x20                | X1 = this.line_Tr;//m1                  
        // 0x00BAEAE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAEAEC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.line_Tr);
        bool val_66 = UnityEngine.Object.op_Inequality(x:  0, y:  this.line_Tr);
        // 0x00BAEAF0: LDR w23, [x19, #0xe8]      | W23 = this.isDamp; //P2                 
        val_152 = this.isDamp;
        // 0x00BAEAF4: MOV w21, w0                | W21 = val_66;//m1                       
        // 0x00BAEAF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEAFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEB00: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_67 = UnityEngine.Camera.main;
        // 0x00BAEB04: MOV x20, x0                | X20 = val_67;//m1                       
        // 0x00BAEB08: CBNZ x20, #0xbaeb10        | if (val_67 != null) goto label_63;      
        if(val_67 != null)
        {
            goto label_63;
        }
        // 0x00BAEB0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_67, ????);     
        label_63:
        // 0x00BAEB10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEB14: MOV x0, x20                | X0 = val_67;//m1                        
        // 0x00BAEB18: BL #0x20d5094              | X0 = val_67.get_transform();            
        UnityEngine.Transform val_68 = val_67.transform;
        // 0x00BAEB1C: MOV x20, x0                | X20 = val_68;//m1                       
        // 0x00BAEB20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEB24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEB28: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_69 = UnityEngine.Camera.main;
        // 0x00BAEB2C: MOV x22, x0                | X22 = val_69;//m1                       
        // 0x00BAEB30: CBNZ x22, #0xbaeb38        | if (val_69 != null) goto label_64;      
        if(val_69 != null)
        {
            goto label_64;
        }
        // 0x00BAEB34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_69, ????);     
        label_64:
        // 0x00BAEB38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEB3C: MOV x0, x22                | X0 = val_69;//m1                        
        // 0x00BAEB40: BL #0x20d5094              | X0 = val_69.get_transform();            
        UnityEngine.Transform val_70 = val_69.transform;
        // 0x00BAEB44: MOV x22, x0                | X22 = val_70;//m1                       
        // 0x00BAEB48: CBNZ x22, #0xbaeb50        | if (val_70 != null) goto label_65;      
        if(val_70 != null)
        {
            goto label_65;
        }
        // 0x00BAEB4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        label_65:
        // 0x00BAEB50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEB54: MOV x0, x22                | X0 = val_70;//m1                        
        // 0x00BAEB58: BL #0x2693510              | X0 = val_70.get_position();             
        UnityEngine.Vector3 val_71 = val_70.position;
        // 0x00BAEB5C: STP s0, s1, [sp, #4]       | stack[1152921514494700804] = val_71.x;  stack[1152921514494700808] = val_71.y;  //  dest_result_addr=1152921514494700804 |  dest_result_addr=1152921514494700808
        // 0x00BAEB60: STR s2, [sp, #0xc]         | stack[1152921514494700812] = val_71.z;   //  dest_result_addr=1152921514494700812
        // 0x00BAEB64: TBZ w21, #0, #0xbaed2c     | if (val_66 == false) goto label_66;     
        if(val_66 == false)
        {
            goto label_66;
        }
        // 0x00BAEB68: LDR x21, [x19, #0xa0]      | X21 = this.line_Tr; //P2                
        // 0x00BAEB6C: CBNZ x21, #0xbaeb74        | if (this.line_Tr != null) goto label_67;
        if(this.line_Tr != null)
        {
            goto label_67;
        }
        // 0x00BAEB70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        label_67:
        // 0x00BAEB74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEB78: MOV x0, x21                | X0 = this.line_Tr;//m1                  
        // 0x00BAEB7C: BL #0x2693510              | X0 = this.line_Tr.get_position();       
        UnityEngine.Vector3 val_72 = this.line_Tr.position;
        // 0x00BAEB80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEB84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEB88: MOV v13.16b, v0.16b        | V13 = val_72.x;//m1                     
        // 0x00BAEB8C: MOV v12.16b, v1.16b        | V12 = val_72.y;//m1                     
        // 0x00BAEB90: STR s2, [sp]               | stack[1152921514494700800] = val_72.z;   //  dest_result_addr=1152921514494700800
        // 0x00BAEB94: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_73 = UnityEngine.Camera.main;
        // 0x00BAEB98: MOV x21, x0                | X21 = val_73;//m1                       
        // 0x00BAEB9C: CBNZ x21, #0xbaeba4        | if (val_73 != null) goto label_68;      
        if(val_73 != null)
        {
            goto label_68;
        }
        // 0x00BAEBA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_73, ????);     
        label_68:
        // 0x00BAEBA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEBA8: MOV x0, x21                | X0 = val_73;//m1                        
        // 0x00BAEBAC: BL #0x20d5094              | X0 = val_73.get_transform();            
        UnityEngine.Transform val_74 = val_73.transform;
        // 0x00BAEBB0: MOV x21, x0                | X21 = val_74;//m1                       
        // 0x00BAEBB4: CBNZ x21, #0xbaebbc        | if (val_74 != null) goto label_69;      
        if(val_74 != null)
        {
            goto label_69;
        }
        // 0x00BAEBB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_74, ????);     
        label_69:
        // 0x00BAEBBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEBC0: MOV x0, x21                | X0 = val_74;//m1                        
        // 0x00BAEBC4: BL #0x2693510              | X0 = val_74.get_position();             
        UnityEngine.Vector3 val_75 = val_74.position;
        // 0x00BAEBC8: LDR x21, [x19, #0xa0]      | X21 = this.line_Tr; //P2                
        // 0x00BAEBCC: MOV v8.16b, v0.16b         | V8 = val_75.x;//m1                      
        // 0x00BAEBD0: MOV v14.16b, v1.16b        | V14 = val_75.y;//m1                     
        // 0x00BAEBD4: MOV v15.16b, v2.16b        | V15 = val_75.z;//m1                     
        // 0x00BAEBD8: CBNZ x21, #0xbaebe0        | if (this.line_Tr != null) goto label_70;
        if(this.line_Tr != null)
        {
            goto label_70;
        }
        // 0x00BAEBDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_74, ????);     
        label_70:
        // 0x00BAEBE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEBE4: MOV x0, x21                | X0 = this.line_Tr;//m1                  
        // 0x00BAEBE8: BL #0x2693510              | X0 = this.line_Tr.get_position();       
        UnityEngine.Vector3 val_76 = this.line_Tr.position;
        // 0x00BAEBEC: ADRP x21, #0x3673000       | X21 = 57094144 (0x3673000);             
        // 0x00BAEBF0: LDR x21, [x21, #0x488]     | X21 = 1152921504695078912;              
        val_149 = 1152921504695078912;
        // 0x00BAEBF4: MOV v10.16b, v0.16b        | V10 = val_76.x;//m1                     
        // 0x00BAEBF8: MOV v9.16b, v1.16b         | V9 = val_76.y;//m1                      
        // 0x00BAEBFC: MOV v11.16b, v2.16b        | V11 = val_76.z;//m1                     
        // 0x00BAEC00: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAEC04: CMP w23, #1                | STATE = COMPARE(this.isDamp, 0x1)       
        // 0x00BAEC08: ADD x8, x0, #0x109         | X8 = (null + 265) = 1152921504695079177 (0x1000000005425109);
        // 0x00BAEC0C: LDRH w8, [x8]              | W8 = UnityEngine.Vector3.__il2cppRuntimeField_109;
        // 0x00BAEC10: AND w8, w8, #0x100         | W8 = (UnityEngine.Vector3.__il2cppRuntimeField_109 & 256);
        // 0x00BAEC14: AND w8, w8, #0xffff        | W8 = ((UnityEngine.Vector3.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00BAEC18: B.NE #0xbaf0f8             | if (val_152 != 1) goto label_71;        
        if(val_152 != 1)
        {
            goto label_71;
        }
        // 0x00BAEC1C: CBZ w8, #0xbaec2c          | if (((UnityEngine.Vector3.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_73;
        // 0x00BAEC20: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAEC24: CBNZ w8, #0xbaec2c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_73;
        // 0x00BAEC28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_73:
        // 0x00BAEC2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEC30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEC34: MOV v0.16b, v8.16b         | V0 = val_75.x;//m1                      
        // 0x00BAEC38: MOV v1.16b, v14.16b        | V1 = val_75.y;//m1                      
        // 0x00BAEC3C: MOV v2.16b, v15.16b        | V2 = val_75.z;//m1                      
        // 0x00BAEC40: MOV v3.16b, v10.16b        | V3 = val_76.x;//m1                      
        // 0x00BAEC44: MOV v4.16b, v9.16b         | V4 = val_76.y;//m1                      
        // 0x00BAEC48: MOV v5.16b, v11.16b        | V5 = val_76.z;//m1                      
        // 0x00BAEC4C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_75.x, y = val_75.y, z = val_75.z}, b:  new UnityEngine.Vector3() {x = val_76.x, y = val_76.y, z = val_76.z});
        UnityEngine.Vector3 val_79 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_75.x, y = val_75.y, z = val_75.z}, b:  new UnityEngine.Vector3() {x = val_76.x, y = val_76.y, z = val_76.z});
        // 0x00BAEC50: ADD x0, sp, #0x70          | X0 = (1152921514494700800 + 112) = 1152921514494700912 (0x100000024D5CAD70);
        // 0x00BAEC54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEC58: STP s0, s1, [sp, #0x70]    | stack[1152921514494700912] = val_79.x;  stack[1152921514494700916] = val_79.y;  //  dest_result_addr=1152921514494700912 |  dest_result_addr=1152921514494700916
        // 0x00BAEC5C: STR s2, [sp, #0x78]        | stack[1152921514494700920] = val_79.z;   //  dest_result_addr=1152921514494700920
        // 0x00BAEC60: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BAEC64: LDR s3, [x19, #0xb4]       | S3 = this.lineTargetDis; //P2           
        // 0x00BAEC68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEC6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEC70: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_79.x, y = val_79.y, z = val_79.z}, d:  this.lineTargetDis);
        UnityEngine.Vector3 val_80 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_79.x, y = val_79.y, z = val_79.z}, d:  this.lineTargetDis);
        // 0x00BAEC74: MOV v5.16b, v2.16b         | V5 = val_80.z;//m1                      
        // 0x00BAEC78: LDR s2, [sp]               | S2 = val_72.z;                          
        // 0x00BAEC7C: MOV v3.16b, v0.16b         | V3 = val_80.x;//m1                      
        // 0x00BAEC80: MOV v4.16b, v1.16b         | V4 = val_80.y;//m1                      
        // 0x00BAEC84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEC88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEC8C: MOV v0.16b, v13.16b        | V0 = val_72.x;//m1                      
        // 0x00BAEC90: MOV v1.16b, v12.16b        | V1 = val_72.y;//m1                      
        // 0x00BAEC94: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_72.x, y = val_72.y, z = val_72.z}, b:  new UnityEngine.Vector3() {x = val_80.x, y = val_80.y, z = val_80.z});
        UnityEngine.Vector3 val_81 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_72.x, y = val_72.y, z = val_72.z}, b:  new UnityEngine.Vector3() {x = val_80.x, y = val_80.y, z = val_80.z});
        // 0x00BAEC98: MOV v3.16b, v0.16b         | V3 = val_81.x;//m1                      
        // 0x00BAEC9C: MOV v4.16b, v1.16b         | V4 = val_81.y;//m1                      
        // 0x00BAECA0: LDR s6, [x19, #0xb8]       | S6 = this.lineTime; //P2                
        // 0x00BAECA4: MOV v5.16b, v2.16b         | V5 = val_81.z;//m1                      
        // 0x00BAECA8: LDP s0, s1, [sp, #4]       | S0 = val_71.x; S1 = val_71.y;            //  | 
        val_159 = val_71.x;
        val_160 = val_71.y;
        // 0x00BAECAC: LDR s2, [sp, #0xc]         | S2 = val_71.z;                          
        val_161 = val_71.z;
        // 0x00BAECB0: ADD x1, x19, #0xc0         | X1 = this.zero;//AP2 res_addr=1152921514494713264
        // 0x00BAECB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAECB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAECBC: BL #0x2699498              | X0 = UnityEngine.Vector3.SmoothDamp(current:  new UnityEngine.Vector3() {x = val_159, y = val_160, z = val_161}, target:  new UnityEngine.Vector3() {x = val_81.x, y = val_81.y, z = val_81.z}, currentVelocity: ref  new UnityEngine.Vector3(), smoothTime:  this.lineTime);
        UnityEngine.Vector3 val_82 = UnityEngine.Vector3.SmoothDamp(current:  new UnityEngine.Vector3() {x = val_159, y = val_160, z = val_161}, target:  new UnityEngine.Vector3() {x = val_81.x, y = val_81.y, z = val_81.z}, currentVelocity: ref  new UnityEngine.Vector3(), smoothTime:  this.lineTime);
        // 0x00BAECC0: B #0xbaf1d0                |  goto label_74;                         
        goto label_74;
        label_55:
        // 0x00BAECC4: LDP s13, s12, [x19, #0xa8] | S13 = this.lineTargetPos; //P2           //  | 
        // 0x00BAECC8: LDR s11, [x19, #0xb0]      | 
        // 0x00BAECCC: CMP w23, #1                | STATE = COMPARE(this.isDamp, 0x1)       
        // 0x00BAECD0: B.NE #0xbaefb4             | if (val_152 != 1) goto label_75;        
        if(val_152 != 1)
        {
            goto label_75;
        }
        // 0x00BAECD4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAECD8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAECDC: LDR s14, [x19, #0xb8]      | S14 = this.lineTime; //P2               
        val_147 = this.lineTime;
        // 0x00BAECE0: ADD x21, x19, #0xc0        | X21 = this.zero;//AP2 res_addr=1152921514494713264
        val_149 = this.zero;
        // 0x00BAECE4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAECE8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAECEC: TBZ w8, #0, #0xbaecfc      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_77;
        // 0x00BAECF0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAECF4: CBNZ w8, #0xbaecfc         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_77;
        // 0x00BAECF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_77:
        // 0x00BAECFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAED00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAED04: MOV v0.16b, v10.16b        | V0 = val_63.x;//m1                      
        val_165 = val_63.x;
        // 0x00BAED08: MOV v1.16b, v9.16b         | V1 = val_63.y;//m1                      
        val_166 = val_63.y;
        // 0x00BAED0C: MOV v2.16b, v8.16b         | V2 = val_63.z;//m1                      
        val_167 = val_63.z;
        // 0x00BAED10: MOV v3.16b, v13.16b        | V3 = this.lineTargetPos;//m1            
        // 0x00BAED14: MOV v4.16b, v12.16b        | V4 = this.curCirclePos;//m1             
        // 0x00BAED18: MOV v5.16b, v11.16b        | V5 = 180;//m1                           
        // 0x00BAED1C: MOV x1, x21                | X1 = this.zero;//m1                     
        // 0x00BAED20: MOV v6.16b, v14.16b        | V6 = this.lineTime;//m1                 
        // 0x00BAED24: BL #0x2699498              | X0 = UnityEngine.Vector3.SmoothDamp(current:  new UnityEngine.Vector3() {x = val_165, y = val_166, z = val_167}, target:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = val_148, z = 180f}, currentVelocity: ref  new UnityEngine.Vector3(), smoothTime:  val_147);
        UnityEngine.Vector3 val_83 = UnityEngine.Vector3.SmoothDamp(current:  new UnityEngine.Vector3() {x = val_165, y = val_166, z = val_167}, target:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = val_148, z = 180f}, currentVelocity: ref  new UnityEngine.Vector3(), smoothTime:  val_147);
        // 0x00BAED28: B #0xbaf038                |  goto label_78;                         
        goto label_78;
        label_66:
        // 0x00BAED2C: LDP s13, s12, [x19, #0xa8] | S13 = this.lineTargetPos; //P2           //  | 
        val_171 = this.lineTargetPos;
        // 0x00BAED30: LDR s0, [x19, #0xb0]       | 
        // 0x00BAED34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAED38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAED3C: STR s0, [sp]               | stack[1152921514494700800] = val_71.x;   //  dest_result_addr=1152921514494700800
        // 0x00BAED40: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_84 = UnityEngine.Camera.main;
        // 0x00BAED44: MOV x21, x0                | X21 = val_84;//m1                       
        // 0x00BAED48: CBNZ x21, #0xbaed50        | if (val_84 != null) goto label_79;      
        if(val_84 != null)
        {
            goto label_79;
        }
        // 0x00BAED4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_84, ????);     
        label_79:
        // 0x00BAED50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAED54: MOV x0, x21                | X0 = val_84;//m1                        
        // 0x00BAED58: BL #0x20d5094              | X0 = val_84.get_transform();            
        UnityEngine.Transform val_85 = val_84.transform;
        // 0x00BAED5C: MOV x21, x0                | X21 = val_85;//m1                       
        // 0x00BAED60: CBNZ x21, #0xbaed68        | if (val_85 != null) goto label_80;      
        if(val_85 != null)
        {
            goto label_80;
        }
        // 0x00BAED64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_85, ????);     
        label_80:
        // 0x00BAED68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAED6C: MOV x0, x21                | X0 = val_85;//m1                        
        // 0x00BAED70: BL #0x2693510              | X0 = val_85.get_position();             
        UnityEngine.Vector3 val_86 = val_85.position;
        // 0x00BAED74: ADRP x21, #0x3673000       | X21 = 57094144 (0x3673000);             
        // 0x00BAED78: LDR x21, [x21, #0x488]     | X21 = 1152921504695078912;              
        val_149 = 1152921504695078912;
        // 0x00BAED7C: MOV v9.16b, v0.16b         | V9 = val_86.x;//m1                      
        // 0x00BAED80: MOV v8.16b, v1.16b         | V8 = val_86.y;//m1                      
        // 0x00BAED84: MOV v11.16b, v2.16b        | V11 = val_86.z;//m1                     
        // 0x00BAED88: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAED8C: CMP w23, #1                | STATE = COMPARE(this.isDamp, 0x1)       
        // 0x00BAED90: ADD x8, x0, #0x109         | X8 = (null + 265) = 1152921504695079177 (0x1000000005425109);
        // 0x00BAED94: LDRH w8, [x8]              | W8 = UnityEngine.Vector3.__il2cppRuntimeField_109;
        // 0x00BAED98: LDP s15, s14, [x19, #0xa8] | S15 = this.lineTargetPos; //P2           //  | 
        // 0x00BAED9C: LDR s10, [x19, #0xb0]      | 
        // 0x00BAEDA0: AND w8, w8, #0x100         | W8 = (UnityEngine.Vector3.__il2cppRuntimeField_109 & 256);
        // 0x00BAEDA4: AND w8, w8, #0xffff        | W8 = ((UnityEngine.Vector3.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00BAEDA8: B.NE #0xbaf31c             | if (val_152 != 1) goto label_81;        
        if(val_152 != 1)
        {
            goto label_81;
        }
        // 0x00BAEDAC: CBZ w8, #0xbaedbc          | if (((UnityEngine.Vector3.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_83;
        // 0x00BAEDB0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAEDB4: CBNZ w8, #0xbaedbc         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_83;
        // 0x00BAEDB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_83:
        // 0x00BAEDBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEDC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEDC4: MOV v0.16b, v9.16b         | V0 = val_86.x;//m1                      
        // 0x00BAEDC8: MOV v1.16b, v8.16b         | V1 = val_86.y;//m1                      
        // 0x00BAEDCC: MOV v2.16b, v11.16b        | V2 = val_86.z;//m1                      
        // 0x00BAEDD0: MOV v3.16b, v15.16b        | V3 = this.lineTargetPos;//m1            
        // 0x00BAEDD4: MOV v4.16b, v14.16b        | V4 = this.circle_R;//m1                 
        // 0x00BAEDD8: MOV v5.16b, v10.16b        | V5 = val_53.z;//m1                      
        // 0x00BAEDDC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_86.x, y = val_86.y, z = val_86.z}, b:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = val_147, z = val_53.z});
        UnityEngine.Vector3 val_89 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_86.x, y = val_86.y, z = val_86.z}, b:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = val_147, z = val_53.z});
        // 0x00BAEDE0: ADD x0, sp, #0x40          | X0 = (1152921514494700800 + 64) = 1152921514494700864 (0x100000024D5CAD40);
        // 0x00BAEDE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEDE8: STP s0, s1, [sp, #0x40]    | stack[1152921514494700864] = val_89.x;  stack[1152921514494700868] = val_89.y;  //  dest_result_addr=1152921514494700864 |  dest_result_addr=1152921514494700868
        // 0x00BAEDEC: STR s2, [sp, #0x48]        | stack[1152921514494700872] = val_89.z;   //  dest_result_addr=1152921514494700872
        // 0x00BAEDF0: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BAEDF4: LDR s3, [x19, #0xb4]       | S3 = this.lineTargetDis; //P2           
        // 0x00BAEDF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEDFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEE00: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_89.x, y = val_89.y, z = val_89.z}, d:  this.lineTargetDis);
        UnityEngine.Vector3 val_90 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_89.x, y = val_89.y, z = val_89.z}, d:  this.lineTargetDis);
        // 0x00BAEE04: MOV v5.16b, v2.16b         | V5 = val_90.z;//m1                      
        // 0x00BAEE08: LDR s2, [sp]               | S2 = val_71.x;                          
        // 0x00BAEE0C: MOV v3.16b, v0.16b         | V3 = val_90.x;//m1                      
        // 0x00BAEE10: MOV v4.16b, v1.16b         | V4 = val_90.y;//m1                      
        // 0x00BAEE14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEE18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEE1C: MOV v0.16b, v13.16b        | V0 = this.lineTargetPos;//m1            
        // 0x00BAEE20: MOV v1.16b, v12.16b        | V1 = this.curCirclePos;//m1             
        // 0x00BAEE24: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_171, y = val_148, z = val_71.x}, b:  new UnityEngine.Vector3() {x = val_90.x, y = val_90.y, z = val_90.z});
        UnityEngine.Vector3 val_91 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_171, y = val_148, z = val_71.x}, b:  new UnityEngine.Vector3() {x = val_90.x, y = val_90.y, z = val_90.z});
        // 0x00BAEE28: MOV v3.16b, v0.16b         | V3 = val_91.x;//m1                      
        // 0x00BAEE2C: MOV v4.16b, v1.16b         | V4 = val_91.y;//m1                      
        // 0x00BAEE30: LDR s6, [x19, #0xb8]       | S6 = this.lineTime; //P2                
        // 0x00BAEE34: MOV v5.16b, v2.16b         | V5 = val_91.z;//m1                      
        // 0x00BAEE38: LDP s0, s1, [sp, #4]       | S0 = val_71.x; S1 = val_71.y;            //  | 
        val_172 = val_71.x;
        val_173 = val_71.y;
        // 0x00BAEE3C: LDR s2, [sp, #0xc]         | S2 = val_71.z;                          
        val_174 = val_71.z;
        // 0x00BAEE40: ADD x1, x19, #0xc0         | X1 = this.zero;//AP2 res_addr=1152921514494713264
        // 0x00BAEE44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEE48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAEE4C: BL #0x2699498              | X0 = UnityEngine.Vector3.SmoothDamp(current:  new UnityEngine.Vector3() {x = val_172, y = val_173, z = val_174}, target:  new UnityEngine.Vector3() {x = val_91.x, y = val_91.y, z = val_91.z}, currentVelocity: ref  new UnityEngine.Vector3(), smoothTime:  this.lineTime);
        UnityEngine.Vector3 val_92 = UnityEngine.Vector3.SmoothDamp(current:  new UnityEngine.Vector3() {x = val_172, y = val_173, z = val_174}, target:  new UnityEngine.Vector3() {x = val_91.x, y = val_91.y, z = val_91.z}, currentVelocity: ref  new UnityEngine.Vector3(), smoothTime:  this.lineTime);
        // 0x00BAEE50: B #0xbaf3f4                |  goto label_84;                         
        goto label_84;
        label_57:
        // 0x00BAEE54: LDR s0, [x19, #0xdc]       | S0 = this.lineTruthDis; //P2            
        // 0x00BAEE58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEE5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEE60: STR s0, [sp, #0xc]         | stack[1152921514494700812] = this.lineTruthDis;  //  dest_result_addr=1152921514494700812
        // 0x00BAEE64: LDR s0, [x19, #0xb8]       | S0 = this.lineTime; //P2                
        // 0x00BAEE68: STR s0, [sp, #8]           | stack[1152921514494700808] = this.lineTime;  //  dest_result_addr=1152921514494700808
        // 0x00BAEE6C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_93 = UnityEngine.Time.deltaTime;
        // 0x00BAEE70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEE74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEE78: MOV v14.16b, v0.16b        | V14 = val_93;//m1                       
        val_147 = val_93;
        // 0x00BAEE7C: BL #0x2691094              | X0 = UnityEngine.Time.get_timeScale();  
        float val_94 = UnityEngine.Time.timeScale;
        // 0x00BAEE80: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAEE84: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAEE88: MOV v15.16b, v0.16b        | V15 = val_94;//m1                       
        // 0x00BAEE8C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAEE90: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAEE94: TBZ w8, #0, #0xbaeea4      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_86;
        // 0x00BAEE98: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAEE9C: CBNZ w8, #0xbaeea4         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_86;
        // 0x00BAEEA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_86:
        // 0x00BAEEA4: LDP s1, s0, [sp, #8]       | S1 = this.lineTime; S0 = this.lineTruthDis; //  | 
        float val_153 = this.lineTruthDis;
        // 0x00BAEEA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEEAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEEB0: MOV v2.16b, v8.16b         | V2 = val_63.z;//m1                      
        val_155 = val_63.z;
        // 0x00BAEEB4: FDIV s0, s0, s1            | S0 = (this.lineTruthDis / this.lineTime);
        val_153 = val_153 / this.lineTime;
        // 0x00BAEEB8: FDIV s1, s14, s15          | S1 = (val_93 / val_94);                 
        float val_95 = val_147 / val_94;
        // 0x00BAEEBC: FMUL s6, s0, s1            | S6 = ((this.lineTruthDis / this.lineTime) * (val_93 / val_94));
        float val_96 = val_153 * val_95;
        // 0x00BAEEC0: MOV v0.16b, v10.16b        | V0 = val_63.x;//m1                      
        val_153 = val_63.x;
        // 0x00BAEEC4: MOV v1.16b, v9.16b         | V1 = val_63.y;//m1                      
        val_154 = val_63.y;
        // 0x00BAEEC8: MOV v3.16b, v13.16b        | V3 = val_64.x;//m1                      
        // 0x00BAEECC: MOV v4.16b, v12.16b        | V4 = val_64.y;//m1                      
        // 0x00BAEED0: MOV v5.16b, v11.16b        | V5 = val_64.z;//m1                      
        // 0x00BAEED4: BL #0x2698f48              | X0 = UnityEngine.Vector3.MoveTowards(current:  new UnityEngine.Vector3() {x = val_153, y = val_154, z = val_155}, target:  new UnityEngine.Vector3() {x = val_64.x, y = val_64.y, z = val_64.z}, maxDistanceDelta:  float val_96 = this.lineTruthDis * val_95);
        UnityEngine.Vector3 val_97 = UnityEngine.Vector3.MoveTowards(current:  new UnityEngine.Vector3() {x = val_153, y = val_154, z = val_155}, target:  new UnityEngine.Vector3() {x = val_64.x, y = val_64.y, z = val_64.z}, maxDistanceDelta:  val_96);
        label_60:
        // 0x00BAEED8: MOV v8.16b, v0.16b         | V8 = val_97.x;//m1                      
        // 0x00BAEEDC: MOV v9.16b, v1.16b         | V9 = val_97.y;//m1                      
        // 0x00BAEEE0: MOV v10.16b, v2.16b        | V10 = val_97.z;//m1                     
        // 0x00BAEEE4: CBNZ x20, #0xbaeeec        | if (val_60 != null) goto label_87;      
        if(val_60 != null)
        {
            goto label_87;
        }
        // 0x00BAEEE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_87:
        // 0x00BAEEEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEEF0: MOV x0, x20                | X0 = val_60;//m1                        
        // 0x00BAEEF4: MOV v0.16b, v8.16b         | V0 = val_97.x;//m1                      
        // 0x00BAEEF8: MOV v1.16b, v9.16b         | V1 = val_97.y;//m1                      
        // 0x00BAEEFC: MOV v2.16b, v10.16b        | V2 = val_97.z;//m1                      
        // 0x00BAEF00: BL #0x26935b8              | val_60.set_position(value:  new UnityEngine.Vector3() {x = val_97.x, y = val_97.y, z = val_97.z});
        val_60.position = new UnityEngine.Vector3() {x = val_97.x, y = val_97.y, z = val_97.z};
        // 0x00BAEF04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEF08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEF0C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_98 = UnityEngine.Camera.main;
        // 0x00BAEF10: MOV x20, x0                | X20 = val_98;//m1                       
        // 0x00BAEF14: CBNZ x20, #0xbaef1c        | if (val_98 != null) goto label_88;      
        if(val_98 != null)
        {
            goto label_88;
        }
        // 0x00BAEF18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_98, ????);     
        label_88:
        // 0x00BAEF1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEF20: MOV x0, x20                | X0 = val_98;//m1                        
        // 0x00BAEF24: BL #0x20d5094              | X0 = val_98.get_transform();            
        UnityEngine.Transform val_99 = val_98.transform;
        // 0x00BAEF28: MOV x20, x0                | X20 = val_99;//m1                       
        // 0x00BAEF2C: CBNZ x20, #0xbaef34        | if (val_99 != null) goto label_89;      
        if(val_99 != null)
        {
            goto label_89;
        }
        // 0x00BAEF30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_99, ????);     
        label_89:
        // 0x00BAEF34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEF38: MOV x0, x20                | X0 = val_99;//m1                        
        // 0x00BAEF3C: BL #0x2693510              | X0 = val_99.get_position();             
        UnityEngine.Vector3 val_100 = val_99.position;
        // 0x00BAEF40: LDR x20, [x19, #0xa0]      | X20 = this.line_Tr; //P2                
        // 0x00BAEF44: MOV v8.16b, v0.16b         | V8 = val_100.x;//m1                     
        val_150 = val_100.x;
        // 0x00BAEF48: MOV v9.16b, v1.16b         | V9 = val_100.y;//m1                     
        // 0x00BAEF4C: MOV v10.16b, v2.16b        | V10 = val_100.z;//m1                    
        val_151 = val_100.z;
        // 0x00BAEF50: CBNZ x20, #0xbaef58        | if (this.line_Tr != null) goto label_90;
        if(this.line_Tr != null)
        {
            goto label_90;
        }
        // 0x00BAEF54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_99, ????);     
        label_90:
        // 0x00BAEF58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEF5C: MOV x0, x20                | X0 = this.line_Tr;//m1                  
        // 0x00BAEF60: BL #0x2693510              | X0 = this.line_Tr.get_position();       
        UnityEngine.Vector3 val_101 = this.line_Tr.position;
        // 0x00BAEF64: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAEF68: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAEF6C: MOV v11.16b, v0.16b        | V11 = val_101.x;//m1                    
        // 0x00BAEF70: MOV v12.16b, v1.16b        | V12 = val_101.y;//m1                    
        val_148 = val_101.y;
        // 0x00BAEF74: MOV v13.16b, v2.16b        | V13 = val_101.z;//m1                    
        // 0x00BAEF78: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAEF7C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAEF80: TBZ w8, #0, #0xbaef90      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_92;
        // 0x00BAEF84: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAEF88: CBNZ w8, #0xbaef90         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_92;
        // 0x00BAEF8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_92:
        // 0x00BAEF90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEF94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEF98: MOV v0.16b, v8.16b         | V0 = val_100.x;//m1                     
        val_181 = val_150;
        // 0x00BAEF9C: MOV v1.16b, v9.16b         | V1 = val_100.y;//m1                     
        // 0x00BAEFA0: MOV v2.16b, v10.16b        | V2 = val_100.z;//m1                     
        // 0x00BAEFA4: MOV v3.16b, v11.16b        | V3 = val_101.x;//m1                     
        // 0x00BAEFA8: MOV v4.16b, v12.16b        | V4 = val_101.y;//m1                     
        // 0x00BAEFAC: MOV v5.16b, v13.16b        | V5 = val_101.z;//m1                     
        // 0x00BAEFB0: B #0xbaf560                |  goto label_101;                        
        goto label_101;
        label_75:
        // 0x00BAEFB4: LDR s0, [x19, #0xdc]       | S0 = this.lineTruthDis; //P2            
        // 0x00BAEFB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEFBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEFC0: STR s0, [sp, #0xc]         | stack[1152921514494700812] = this.lineTruthDis;  //  dest_result_addr=1152921514494700812
        // 0x00BAEFC4: LDR s0, [x19, #0xb8]       | S0 = this.lineTime; //P2                
        // 0x00BAEFC8: STR s0, [sp, #8]           | stack[1152921514494700808] = this.lineTime;  //  dest_result_addr=1152921514494700808
        // 0x00BAEFCC: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_102 = UnityEngine.Time.deltaTime;
        // 0x00BAEFD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAEFD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAEFD8: MOV v14.16b, v0.16b        | V14 = val_102;//m1                      
        val_147 = val_102;
        // 0x00BAEFDC: BL #0x2691094              | X0 = UnityEngine.Time.get_timeScale();  
        float val_103 = UnityEngine.Time.timeScale;
        // 0x00BAEFE0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAEFE4: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAEFE8: MOV v15.16b, v0.16b        | V15 = val_103;//m1                      
        // 0x00BAEFEC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAEFF0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAEFF4: TBZ w8, #0, #0xbaf004      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_95;
        // 0x00BAEFF8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAEFFC: CBNZ w8, #0xbaf004         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_95;
        // 0x00BAF000: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_95:
        // 0x00BAF004: LDP s1, s0, [sp, #8]       | S1 = this.lineTime; S0 = this.lineTruthDis; //  | 
        float val_154 = this.lineTruthDis;
        // 0x00BAF008: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF00C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF010: MOV v2.16b, v8.16b         | V2 = val_63.z;//m1                      
        val_167 = val_63.z;
        // 0x00BAF014: FDIV s0, s0, s1            | S0 = (this.lineTruthDis / this.lineTime);
        val_154 = val_154 / this.lineTime;
        // 0x00BAF018: FDIV s1, s14, s15          | S1 = (val_102 / val_103);               
        float val_104 = val_147 / val_103;
        // 0x00BAF01C: FMUL s6, s0, s1            | S6 = ((this.lineTruthDis / this.lineTime) * (val_102 / val_103));
        float val_105 = val_154 * val_104;
        // 0x00BAF020: MOV v0.16b, v10.16b        | V0 = val_63.x;//m1                      
        val_165 = val_63.x;
        // 0x00BAF024: MOV v1.16b, v9.16b         | V1 = val_63.y;//m1                      
        val_166 = val_63.y;
        // 0x00BAF028: MOV v3.16b, v13.16b        | V3 = this.lineTargetPos;//m1            
        // 0x00BAF02C: MOV v4.16b, v12.16b        | V4 = this.curCirclePos;//m1             
        // 0x00BAF030: MOV v5.16b, v11.16b        | V5 = 180;//m1                           
        // 0x00BAF034: BL #0x2698f48              | X0 = UnityEngine.Vector3.MoveTowards(current:  new UnityEngine.Vector3() {x = val_165, y = val_166, z = val_167}, target:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = val_148, z = 180f}, maxDistanceDelta:  float val_105 = this.lineTruthDis * val_104);
        UnityEngine.Vector3 val_106 = UnityEngine.Vector3.MoveTowards(current:  new UnityEngine.Vector3() {x = val_165, y = val_166, z = val_167}, target:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = val_148, z = 180f}, maxDistanceDelta:  val_105);
        label_78:
        // 0x00BAF038: MOV v8.16b, v0.16b         | V8 = val_106.x;//m1                     
        // 0x00BAF03C: MOV v9.16b, v1.16b         | V9 = val_106.y;//m1                     
        // 0x00BAF040: MOV v10.16b, v2.16b        | V10 = val_106.z;//m1                    
        // 0x00BAF044: CBNZ x20, #0xbaf04c        | if (val_60 != null) goto label_96;      
        if(val_60 != null)
        {
            goto label_96;
        }
        // 0x00BAF048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_96:
        // 0x00BAF04C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF050: MOV x0, x20                | X0 = val_60;//m1                        
        // 0x00BAF054: MOV v0.16b, v8.16b         | V0 = val_106.x;//m1                     
        // 0x00BAF058: MOV v1.16b, v9.16b         | V1 = val_106.y;//m1                     
        // 0x00BAF05C: MOV v2.16b, v10.16b        | V2 = val_106.z;//m1                     
        // 0x00BAF060: BL #0x26935b8              | val_60.set_position(value:  new UnityEngine.Vector3() {x = val_106.x, y = val_106.y, z = val_106.z});
        val_60.position = new UnityEngine.Vector3() {x = val_106.x, y = val_106.y, z = val_106.z};
        // 0x00BAF064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF068: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF06C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_107 = UnityEngine.Camera.main;
        // 0x00BAF070: MOV x20, x0                | X20 = val_107;//m1                      
        // 0x00BAF074: CBNZ x20, #0xbaf07c        | if (val_107 != null) goto label_97;     
        if(val_107 != null)
        {
            goto label_97;
        }
        // 0x00BAF078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_107, ????);    
        label_97:
        // 0x00BAF07C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF080: MOV x0, x20                | X0 = val_107;//m1                       
        // 0x00BAF084: BL #0x20d5094              | X0 = val_107.get_transform();           
        UnityEngine.Transform val_108 = val_107.transform;
        // 0x00BAF088: MOV x20, x0                | X20 = val_108;//m1                      
        // 0x00BAF08C: CBNZ x20, #0xbaf094        | if (val_108 != null) goto label_98;     
        if(val_108 != null)
        {
            goto label_98;
        }
        // 0x00BAF090: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_108, ????);    
        label_98:
        // 0x00BAF094: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF098: MOV x0, x20                | X0 = val_108;//m1                       
        // 0x00BAF09C: BL #0x2693510              | X0 = val_108.get_position();            
        UnityEngine.Vector3 val_109 = val_108.position;
        // 0x00BAF0A0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAF0A4: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAF0A8: MOV v8.16b, v0.16b         | V8 = val_109.x;//m1                     
        val_150 = val_109.x;
        // 0x00BAF0AC: MOV v9.16b, v1.16b         | V9 = val_109.y;//m1                     
        // 0x00BAF0B0: MOV v13.16b, v2.16b        | V13 = val_109.z;//m1                    
        // 0x00BAF0B4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAF0B8: LDP s12, s11, [x19, #0xa8] | S12 = this.lineTargetPos; //P2           //  | 
        val_148 = this.lineTargetPos;
        // 0x00BAF0BC: LDR s10, [x19, #0xb0]      | 
        // 0x00BAF0C0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAF0C4: TBZ w8, #0, #0xbaf0d4      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_100;
        // 0x00BAF0C8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAF0CC: CBNZ w8, #0xbaf0d4         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_100;
        // 0x00BAF0D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_100:
        // 0x00BAF0D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF0D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF0DC: MOV v0.16b, v8.16b         | V0 = val_109.x;//m1                     
        val_181 = val_150;
        // 0x00BAF0E0: MOV v1.16b, v9.16b         | V1 = val_109.y;//m1                     
        // 0x00BAF0E4: MOV v2.16b, v13.16b        | V2 = val_109.z;//m1                     
        // 0x00BAF0E8: MOV v3.16b, v12.16b        | V3 = this.lineTargetPos;//m1            
        // 0x00BAF0EC: MOV v4.16b, v11.16b        | V4 = 180;//m1                           
        // 0x00BAF0F0: MOV v5.16b, v10.16b        | V5 = val_106.z;//m1                     
        // 0x00BAF0F4: B #0xbaf560                |  goto label_101;                        
        goto label_101;
        label_71:
        // 0x00BAF0F8: CBZ w8, #0xbaf108          | if (((UnityEngine.Vector3.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_103;
        // 0x00BAF0FC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAF100: CBNZ w8, #0xbaf108         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_103;
        // 0x00BAF104: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_103:
        // 0x00BAF108: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF10C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF110: MOV v0.16b, v8.16b         | V0 = val_75.x;//m1                      
        // 0x00BAF114: MOV v1.16b, v14.16b        | V1 = val_75.y;//m1                      
        // 0x00BAF118: MOV v2.16b, v15.16b        | V2 = val_75.z;//m1                      
        // 0x00BAF11C: MOV v3.16b, v10.16b        | V3 = val_76.x;//m1                      
        // 0x00BAF120: MOV v4.16b, v9.16b         | V4 = val_76.y;//m1                      
        // 0x00BAF124: MOV v5.16b, v11.16b        | V5 = val_76.z;//m1                      
        // 0x00BAF128: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_75.x, y = val_75.y, z = val_75.z}, b:  new UnityEngine.Vector3() {x = val_76.x, y = val_76.y, z = val_76.z});
        UnityEngine.Vector3 val_110 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_75.x, y = val_75.y, z = val_75.z}, b:  new UnityEngine.Vector3() {x = val_76.x, y = val_76.y, z = val_76.z});
        // 0x00BAF12C: ADD x0, sp, #0x60          | X0 = (1152921514494700800 + 96) = 1152921514494700896 (0x100000024D5CAD60);
        // 0x00BAF130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF134: STP s0, s1, [sp, #0x60]    | stack[1152921514494700896] = val_110.x;  stack[1152921514494700900] = val_110.y;  //  dest_result_addr=1152921514494700896 |  dest_result_addr=1152921514494700900
        // 0x00BAF138: STR s2, [sp, #0x68]        | stack[1152921514494700904] = val_110.z;  //  dest_result_addr=1152921514494700904
        // 0x00BAF13C: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BAF140: LDR s3, [x19, #0xb4]       | S3 = this.lineTargetDis; //P2           
        // 0x00BAF144: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF14C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_110.x, y = val_110.y, z = val_110.z}, d:  this.lineTargetDis);
        UnityEngine.Vector3 val_111 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_110.x, y = val_110.y, z = val_110.z}, d:  this.lineTargetDis);
        // 0x00BAF150: MOV v5.16b, v2.16b         | V5 = val_111.z;//m1                     
        // 0x00BAF154: LDR s2, [sp]               | S2 = val_71.x;                          
        // 0x00BAF158: MOV v3.16b, v0.16b         | V3 = val_111.x;//m1                     
        // 0x00BAF15C: MOV v4.16b, v1.16b         | V4 = val_111.y;//m1                     
        // 0x00BAF160: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF164: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF168: MOV v0.16b, v13.16b        | V0 = val_72.x;//m1                      
        // 0x00BAF16C: MOV v1.16b, v12.16b        | V1 = val_72.y;//m1                      
        // 0x00BAF170: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_72.x, y = val_72.y, z = val_71.x}, b:  new UnityEngine.Vector3() {x = val_111.x, y = val_111.y, z = val_111.z});
        UnityEngine.Vector3 val_112 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_72.x, y = val_72.y, z = val_71.x}, b:  new UnityEngine.Vector3() {x = val_111.x, y = val_111.y, z = val_111.z});
        // 0x00BAF174: LDR s12, [x19, #0xe0]      | S12 = this.lineMidDis; //P2             
        // 0x00BAF178: LDR s13, [x19, #0xb8]      | S13 = this.lineTime; //P2               
        // 0x00BAF17C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF180: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF184: MOV v8.16b, v0.16b         | V8 = val_112.x;//m1                     
        // 0x00BAF188: MOV v9.16b, v1.16b         | V9 = val_112.y;//m1                     
        // 0x00BAF18C: MOV v10.16b, v2.16b        | V10 = val_112.z;//m1                    
        // 0x00BAF190: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_113 = UnityEngine.Time.deltaTime;
        // 0x00BAF194: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF198: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF19C: MOV v11.16b, v0.16b        | V11 = val_113;//m1                      
        // 0x00BAF1A0: BL #0x2691094              | X0 = UnityEngine.Time.get_timeScale();  
        float val_114 = UnityEngine.Time.timeScale;
        // 0x00BAF1A4: FDIV s1, s12, s13          | S1 = (this.lineMidDis / this.lineTime); 
        float val_115 = this.lineMidDis / this.lineTime;
        // 0x00BAF1A8: FDIV s0, s11, s0           | S0 = (val_113 / val_114);               
        val_114 = val_113 / val_114;
        // 0x00BAF1AC: FMUL s6, s1, s0            | S6 = ((this.lineMidDis / this.lineTime) * (val_113 / val_114));
        float val_116 = val_115 * val_114;
        // 0x00BAF1B0: LDP s0, s1, [sp, #4]       | S0 = val_71.x; S1 = this.lineTime;       //  | 
        val_159 = val_71.x;
        val_160 = this.lineTime;
        // 0x00BAF1B4: LDR s2, [sp, #0xc]         | S2 = this.lineTruthDis;                 
        val_161 = this.lineTruthDis;
        // 0x00BAF1B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF1BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF1C0: MOV v3.16b, v8.16b         | V3 = val_112.x;//m1                     
        // 0x00BAF1C4: MOV v4.16b, v9.16b         | V4 = val_112.y;//m1                     
        // 0x00BAF1C8: MOV v5.16b, v10.16b        | V5 = val_112.z;//m1                     
        // 0x00BAF1CC: BL #0x2698f48              | X0 = UnityEngine.Vector3.MoveTowards(current:  new UnityEngine.Vector3() {x = val_159, y = val_160, z = val_161}, target:  new UnityEngine.Vector3() {x = val_112.x, y = val_112.y, z = val_112.z}, maxDistanceDelta:  float val_116 = val_115 * val_114);
        UnityEngine.Vector3 val_117 = UnityEngine.Vector3.MoveTowards(current:  new UnityEngine.Vector3() {x = val_159, y = val_160, z = val_161}, target:  new UnityEngine.Vector3() {x = val_112.x, y = val_112.y, z = val_112.z}, maxDistanceDelta:  val_116);
        label_74:
        // 0x00BAF1D0: MOV v8.16b, v0.16b         | V8 = val_117.x;//m1                     
        // 0x00BAF1D4: MOV v9.16b, v1.16b         | V9 = val_117.y;//m1                     
        // 0x00BAF1D8: MOV v10.16b, v2.16b        | V10 = val_117.z;//m1                    
        // 0x00BAF1DC: CBNZ x20, #0xbaf1e4        | if (val_68 != null) goto label_104;     
        if(val_68 != null)
        {
            goto label_104;
        }
        // 0x00BAF1E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_104:
        // 0x00BAF1E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF1E8: MOV x0, x20                | X0 = val_68;//m1                        
        // 0x00BAF1EC: MOV v0.16b, v8.16b         | V0 = val_117.x;//m1                     
        // 0x00BAF1F0: MOV v1.16b, v9.16b         | V1 = val_117.y;//m1                     
        // 0x00BAF1F4: MOV v2.16b, v10.16b        | V2 = val_117.z;//m1                     
        // 0x00BAF1F8: BL #0x26935b8              | val_68.set_position(value:  new UnityEngine.Vector3() {x = val_117.x, y = val_117.y, z = val_117.z});
        val_68.position = new UnityEngine.Vector3() {x = val_117.x, y = val_117.y, z = val_117.z};
        // 0x00BAF1FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF200: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF204: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_118 = UnityEngine.Camera.main;
        // 0x00BAF208: MOV x20, x0                | X20 = val_118;//m1                      
        // 0x00BAF20C: CBNZ x20, #0xbaf214        | if (val_118 != null) goto label_105;    
        if(val_118 != null)
        {
            goto label_105;
        }
        // 0x00BAF210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_118, ????);    
        label_105:
        // 0x00BAF214: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF218: MOV x0, x20                | X0 = val_118;//m1                       
        // 0x00BAF21C: BL #0x20d5094              | X0 = val_118.get_transform();           
        UnityEngine.Transform val_119 = val_118.transform;
        // 0x00BAF220: MOV x20, x0                | X20 = val_119;//m1                      
        // 0x00BAF224: CBNZ x20, #0xbaf22c        | if (val_119 != null) goto label_106;    
        if(val_119 != null)
        {
            goto label_106;
        }
        // 0x00BAF228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_119, ????);    
        label_106:
        // 0x00BAF22C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF230: MOV x0, x20                | X0 = val_119;//m1                       
        // 0x00BAF234: BL #0x2693510              | X0 = val_119.get_position();            
        UnityEngine.Vector3 val_120 = val_119.position;
        // 0x00BAF238: STP s1, s0, [sp, #8]       | stack[1152921514494700808] = val_120.y;  stack[1152921514494700812] = val_120.x;  //  dest_result_addr=1152921514494700808 |  dest_result_addr=1152921514494700812
        // 0x00BAF23C: LDR x20, [x19, #0xa0]      | X20 = this.line_Tr; //P2                
        // 0x00BAF240: STR s2, [sp, #4]           | stack[1152921514494700804] = val_120.z;  //  dest_result_addr=1152921514494700804
        // 0x00BAF244: CBNZ x20, #0xbaf24c        | if (this.line_Tr != null) goto label_107;
        if(this.line_Tr != null)
        {
            goto label_107;
        }
        // 0x00BAF248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_119, ????);    
        label_107:
        // 0x00BAF24C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF250: MOV x0, x20                | X0 = this.line_Tr;//m1                  
        // 0x00BAF254: BL #0x2693510              | X0 = this.line_Tr.get_position();       
        UnityEngine.Vector3 val_121 = this.line_Tr.position;
        // 0x00BAF258: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF25C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF260: STR s0, [sp]               | stack[1152921514494700800] = val_121.x;  //  dest_result_addr=1152921514494700800
        // 0x00BAF264: MOV v12.16b, v1.16b        | V12 = val_121.y;//m1                    
        val_148 = val_121.y;
        // 0x00BAF268: MOV v13.16b, v2.16b        | V13 = val_121.z;//m1                    
        val_182 = val_121.z;
        // 0x00BAF26C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_122 = UnityEngine.Camera.main;
        // 0x00BAF270: MOV x20, x0                | X20 = val_122;//m1                      
        // 0x00BAF274: CBNZ x20, #0xbaf27c        | if (val_122 != null) goto label_108;    
        if(val_122 != null)
        {
            goto label_108;
        }
        // 0x00BAF278: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_122, ????);    
        label_108:
        // 0x00BAF27C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF280: MOV x0, x20                | X0 = val_122;//m1                       
        // 0x00BAF284: BL #0x20d5094              | X0 = val_122.get_transform();           
        UnityEngine.Transform val_123 = val_122.transform;
        // 0x00BAF288: MOV x20, x0                | X20 = val_123;//m1                      
        // 0x00BAF28C: CBNZ x20, #0xbaf294        | if (val_123 != null) goto label_109;    
        if(val_123 != null)
        {
            goto label_109;
        }
        // 0x00BAF290: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_123, ????);    
        label_109:
        // 0x00BAF294: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF298: MOV x0, x20                | X0 = val_123;//m1                       
        // 0x00BAF29C: BL #0x2693510              | X0 = val_123.get_position();            
        UnityEngine.Vector3 val_124 = val_123.position;
        // 0x00BAF2A0: LDR x20, [x19, #0xa0]      | X20 = this.line_Tr; //P2                
        // 0x00BAF2A4: MOV v14.16b, v0.16b        | V14 = val_124.x;//m1                    
        val_147 = val_124.x;
        // 0x00BAF2A8: MOV v15.16b, v1.16b        | V15 = val_124.y;//m1                    
        // 0x00BAF2AC: MOV v8.16b, v2.16b         | V8 = val_124.z;//m1                     
        val_150 = val_124.z;
        // 0x00BAF2B0: CBNZ x20, #0xbaf2b8        | if (this.line_Tr != null) goto label_110;
        if(this.line_Tr != null)
        {
            goto label_110;
        }
        // 0x00BAF2B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_123, ????);    
        label_110:
        // 0x00BAF2B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF2BC: MOV x0, x20                | X0 = this.line_Tr;//m1                  
        // 0x00BAF2C0: BL #0x2693510              | X0 = this.line_Tr.get_position();       
        UnityEngine.Vector3 val_125 = this.line_Tr.position;
        // 0x00BAF2C4: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAF2C8: MOV v9.16b, v0.16b         | V9 = val_125.x;//m1                     
        // 0x00BAF2CC: MOV v10.16b, v1.16b        | V10 = val_125.y;//m1                    
        val_151 = val_125.y;
        // 0x00BAF2D0: MOV v11.16b, v2.16b        | V11 = val_125.z;//m1                    
        // 0x00BAF2D4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAF2D8: TBZ w8, #0, #0xbaf2e8      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_112;
        // 0x00BAF2DC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAF2E0: CBNZ w8, #0xbaf2e8         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_112;
        // 0x00BAF2E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_112:
        // 0x00BAF2E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF2EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF2F0: MOV v0.16b, v14.16b        | V0 = val_124.x;//m1                     
        val_183 = val_147;
        // 0x00BAF2F4: MOV v1.16b, v15.16b        | V1 = val_124.y;//m1                     
        val_184 = val_124.y;
        // 0x00BAF2F8: MOV v2.16b, v8.16b         | V2 = val_124.z;//m1                     
        val_185 = val_150;
        // 0x00BAF2FC: MOV v3.16b, v9.16b         | V3 = val_125.x;//m1                     
        // 0x00BAF300: MOV v4.16b, v10.16b        | V4 = val_125.y;//m1                     
        // 0x00BAF304: MOV v5.16b, v11.16b        | V5 = val_125.z;//m1                     
        // 0x00BAF308: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_183, y = val_184, z = val_185}, b:  new UnityEngine.Vector3() {x = val_125.x, y = val_151, z = val_125.z});
        UnityEngine.Vector3 val_126 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_183, y = val_184, z = val_185}, b:  new UnityEngine.Vector3() {x = val_125.x, y = val_151, z = val_125.z});
        // 0x00BAF30C: STP s0, s1, [sp, #0x50]    | stack[1152921514494700880] = val_126.x;  stack[1152921514494700884] = val_126.y;  //  dest_result_addr=1152921514494700880 |  dest_result_addr=1152921514494700884
        // 0x00BAF310: STR s2, [sp, #0x58]        | stack[1152921514494700888] = val_126.z;  //  dest_result_addr=1152921514494700888
        // 0x00BAF314: ADD x0, sp, #0x50          | X0 = (1152921514494700800 + 80) = 1152921514494700880 (0x100000024D5CAD50);
        // 0x00BAF318: B #0xbaf508                |  goto label_113;                        
        goto label_113;
        label_81:
        // 0x00BAF31C: CBZ w8, #0xbaf32c          | if (((UnityEngine.Vector3.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_115;
        // 0x00BAF320: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAF324: CBNZ w8, #0xbaf32c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_115;
        // 0x00BAF328: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_115:
        // 0x00BAF32C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF330: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF334: MOV v0.16b, v9.16b         | V0 = val_86.x;//m1                      
        // 0x00BAF338: MOV v1.16b, v8.16b         | V1 = val_86.y;//m1                      
        // 0x00BAF33C: MOV v2.16b, v11.16b        | V2 = val_86.z;//m1                      
        // 0x00BAF340: MOV v3.16b, v15.16b        | V3 = this.lineTargetPos;//m1            
        // 0x00BAF344: MOV v4.16b, v14.16b        | V4 = this.circle_R;//m1                 
        // 0x00BAF348: MOV v5.16b, v10.16b        | V5 = val_53.z;//m1                      
        // 0x00BAF34C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_86.x, y = val_86.y, z = val_86.z}, b:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = val_147, z = val_53.z});
        UnityEngine.Vector3 val_127 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_86.x, y = val_86.y, z = val_86.z}, b:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = val_147, z = val_53.z});
        // 0x00BAF350: ADD x0, sp, #0x30          | X0 = (1152921514494700800 + 48) = 1152921514494700848 (0x100000024D5CAD30);
        // 0x00BAF354: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF358: STP s0, s1, [sp, #0x30]    | stack[1152921514494700848] = val_127.x;  stack[1152921514494700852] = val_127.y;  //  dest_result_addr=1152921514494700848 |  dest_result_addr=1152921514494700852
        // 0x00BAF35C: STR s2, [sp, #0x38]        | stack[1152921514494700856] = val_127.z;  //  dest_result_addr=1152921514494700856
        // 0x00BAF360: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BAF364: LDR s3, [x19, #0xb4]       | S3 = this.lineTargetDis; //P2           
        // 0x00BAF368: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF36C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF370: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_127.x, y = val_127.y, z = val_127.z}, d:  this.lineTargetDis);
        UnityEngine.Vector3 val_128 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_127.x, y = val_127.y, z = val_127.z}, d:  this.lineTargetDis);
        // 0x00BAF374: MOV v5.16b, v2.16b         | V5 = val_128.z;//m1                     
        // 0x00BAF378: LDR s2, [sp]               | S2 = val_121.x;                         
        // 0x00BAF37C: MOV v3.16b, v0.16b         | V3 = val_128.x;//m1                     
        // 0x00BAF380: MOV v4.16b, v1.16b         | V4 = val_128.y;//m1                     
        // 0x00BAF384: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF388: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF38C: MOV v0.16b, v13.16b        | V0 = this.lineTargetPos;//m1            
        // 0x00BAF390: MOV v1.16b, v12.16b        | V1 = this.curCirclePos;//m1             
        // 0x00BAF394: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_171, y = val_148, z = val_121.x}, b:  new UnityEngine.Vector3() {x = val_128.x, y = val_128.y, z = val_128.z});
        UnityEngine.Vector3 val_129 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_171, y = val_148, z = val_121.x}, b:  new UnityEngine.Vector3() {x = val_128.x, y = val_128.y, z = val_128.z});
        // 0x00BAF398: LDR s12, [x19, #0xe0]      | S12 = this.lineMidDis; //P2             
        // 0x00BAF39C: LDR s13, [x19, #0xb8]      | S13 = this.lineTime; //P2               
        val_171 = this.lineTime;
        // 0x00BAF3A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF3A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF3A8: MOV v8.16b, v0.16b         | V8 = val_129.x;//m1                     
        // 0x00BAF3AC: MOV v9.16b, v1.16b         | V9 = val_129.y;//m1                     
        // 0x00BAF3B0: MOV v10.16b, v2.16b        | V10 = val_129.z;//m1                    
        // 0x00BAF3B4: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_130 = UnityEngine.Time.deltaTime;
        // 0x00BAF3B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF3BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF3C0: MOV v11.16b, v0.16b        | V11 = val_130;//m1                      
        // 0x00BAF3C4: BL #0x2691094              | X0 = UnityEngine.Time.get_timeScale();  
        float val_131 = UnityEngine.Time.timeScale;
        // 0x00BAF3C8: FDIV s1, s12, s13          | S1 = (this.lineMidDis / this.lineTime); 
        float val_132 = this.lineMidDis / val_171;
        // 0x00BAF3CC: FDIV s0, s11, s0           | S0 = (val_130 / val_131);               
        val_131 = val_130 / val_131;
        // 0x00BAF3D0: FMUL s6, s1, s0            | S6 = ((this.lineMidDis / this.lineTime) * (val_130 / val_131));
        float val_133 = val_132 * val_131;
        // 0x00BAF3D4: LDP s0, s1, [sp, #4]       | S0 = val_120.z; S1 = val_120.y;          //  | 
        val_172 = val_120.z;
        val_173 = val_120.y;
        // 0x00BAF3D8: LDR s2, [sp, #0xc]         | S2 = val_120.x;                         
        val_174 = val_120.x;
        // 0x00BAF3DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF3E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF3E4: MOV v3.16b, v8.16b         | V3 = val_129.x;//m1                     
        // 0x00BAF3E8: MOV v4.16b, v9.16b         | V4 = val_129.y;//m1                     
        // 0x00BAF3EC: MOV v5.16b, v10.16b        | V5 = val_129.z;//m1                     
        // 0x00BAF3F0: BL #0x2698f48              | X0 = UnityEngine.Vector3.MoveTowards(current:  new UnityEngine.Vector3() {x = val_172, y = val_173, z = val_174}, target:  new UnityEngine.Vector3() {x = val_129.x, y = val_129.y, z = val_129.z}, maxDistanceDelta:  float val_133 = val_132 * val_131);
        UnityEngine.Vector3 val_134 = UnityEngine.Vector3.MoveTowards(current:  new UnityEngine.Vector3() {x = val_172, y = val_173, z = val_174}, target:  new UnityEngine.Vector3() {x = val_129.x, y = val_129.y, z = val_129.z}, maxDistanceDelta:  val_133);
        label_84:
        // 0x00BAF3F4: MOV v8.16b, v0.16b         | V8 = val_134.x;//m1                     
        // 0x00BAF3F8: MOV v9.16b, v1.16b         | V9 = val_134.y;//m1                     
        // 0x00BAF3FC: MOV v10.16b, v2.16b        | V10 = val_134.z;//m1                    
        // 0x00BAF400: CBNZ x20, #0xbaf408        | if (val_68 != null) goto label_116;     
        if(val_68 != null)
        {
            goto label_116;
        }
        // 0x00BAF404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_116:
        // 0x00BAF408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF40C: MOV x0, x20                | X0 = val_68;//m1                        
        // 0x00BAF410: MOV v0.16b, v8.16b         | V0 = val_134.x;//m1                     
        // 0x00BAF414: MOV v1.16b, v9.16b         | V1 = val_134.y;//m1                     
        // 0x00BAF418: MOV v2.16b, v10.16b        | V2 = val_134.z;//m1                     
        // 0x00BAF41C: BL #0x26935b8              | val_68.set_position(value:  new UnityEngine.Vector3() {x = val_134.x, y = val_134.y, z = val_134.z});
        val_68.position = new UnityEngine.Vector3() {x = val_134.x, y = val_134.y, z = val_134.z};
        // 0x00BAF420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF424: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF428: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_135 = UnityEngine.Camera.main;
        // 0x00BAF42C: MOV x20, x0                | X20 = val_135;//m1                      
        // 0x00BAF430: CBNZ x20, #0xbaf438        | if (val_135 != null) goto label_117;    
        if(val_135 != null)
        {
            goto label_117;
        }
        // 0x00BAF434: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_135, ????);    
        label_117:
        // 0x00BAF438: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF43C: MOV x0, x20                | X0 = val_135;//m1                       
        // 0x00BAF440: BL #0x20d5094              | X0 = val_135.get_transform();           
        UnityEngine.Transform val_136 = val_135.transform;
        // 0x00BAF444: MOV x20, x0                | X20 = val_136;//m1                      
        // 0x00BAF448: CBNZ x20, #0xbaf450        | if (val_136 != null) goto label_118;    
        if(val_136 != null)
        {
            goto label_118;
        }
        // 0x00BAF44C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_136, ????);    
        label_118:
        // 0x00BAF450: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF454: MOV x0, x20                | X0 = val_136;//m1                       
        // 0x00BAF458: BL #0x2693510              | X0 = val_136.get_position();            
        UnityEngine.Vector3 val_137 = val_136.position;
        // 0x00BAF45C: STP s1, s0, [sp, #8]       | stack[1152921514494700808] = val_137.y;  stack[1152921514494700812] = val_137.x;  //  dest_result_addr=1152921514494700808 |  dest_result_addr=1152921514494700812
        // 0x00BAF460: LDR s0, [x19, #0xa8]       | S0 = this.lineTargetPos; //P2           
        // 0x00BAF464: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF468: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF46C: STR s0, [sp]               | stack[1152921514494700800] = this.lineTargetPos;  //  dest_result_addr=1152921514494700800
        // 0x00BAF470: LDP s12, s13, [x19, #0xac] |                                          //  | 
        // 0x00BAF474: STR s2, [sp, #4]           | stack[1152921514494700804] = val_137.z;  //  dest_result_addr=1152921514494700804
        // 0x00BAF478: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_138 = UnityEngine.Camera.main;
        // 0x00BAF47C: MOV x20, x0                | X20 = val_138;//m1                      
        // 0x00BAF480: CBNZ x20, #0xbaf488        | if (val_138 != null) goto label_119;    
        if(val_138 != null)
        {
            goto label_119;
        }
        // 0x00BAF484: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_138, ????);    
        label_119:
        // 0x00BAF488: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF48C: MOV x0, x20                | X0 = val_138;//m1                       
        // 0x00BAF490: BL #0x20d5094              | X0 = val_138.get_transform();           
        UnityEngine.Transform val_139 = val_138.transform;
        // 0x00BAF494: MOV x20, x0                | X20 = val_139;//m1                      
        // 0x00BAF498: CBNZ x20, #0xbaf4a0        | if (val_139 != null) goto label_120;    
        if(val_139 != null)
        {
            goto label_120;
        }
        // 0x00BAF49C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_139, ????);    
        label_120:
        // 0x00BAF4A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF4A4: MOV x0, x20                | X0 = val_139;//m1                       
        // 0x00BAF4A8: BL #0x2693510              | X0 = val_139.get_position();            
        UnityEngine.Vector3 val_140 = val_139.position;
        // 0x00BAF4AC: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAF4B0: LDP s10, s9, [x19, #0xa8]  | S10 = this.lineTargetPos; //P2           //  | 
        val_151 = this.lineTargetPos;
        // 0x00BAF4B4: LDR s8, [x19, #0xb0]       | 
        // 0x00BAF4B8: MOV v14.16b, v0.16b        | V14 = val_140.x;//m1                    
        val_147 = val_140.x;
        // 0x00BAF4BC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAF4C0: MOV v15.16b, v1.16b        | V15 = val_140.y;//m1                    
        // 0x00BAF4C4: MOV v11.16b, v2.16b        | V11 = val_140.z;//m1                    
        // 0x00BAF4C8: TBZ w8, #0, #0xbaf4d8      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_122;
        // 0x00BAF4CC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAF4D0: CBNZ w8, #0xbaf4d8         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_122;
        // 0x00BAF4D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_122:
        // 0x00BAF4D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF4DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF4E0: MOV v0.16b, v14.16b        | V0 = val_140.x;//m1                     
        val_183 = val_147;
        // 0x00BAF4E4: MOV v1.16b, v15.16b        | V1 = val_140.y;//m1                     
        val_184 = val_140.y;
        // 0x00BAF4E8: MOV v2.16b, v11.16b        | V2 = val_140.z;//m1                     
        val_185 = val_140.z;
        // 0x00BAF4EC: MOV v3.16b, v10.16b        | V3 = this.lineTargetPos;//m1            
        // 0x00BAF4F0: MOV v4.16b, v9.16b         | V4 = val_134.y;//m1                     
        // 0x00BAF4F4: MOV v5.16b, v8.16b         | V5 = val_134.x;//m1                     
        // 0x00BAF4F8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_183, y = val_184, z = val_185}, b:  new UnityEngine.Vector3() {x = val_151, y = val_134.y, z = val_134.x});
        UnityEngine.Vector3 val_141 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_183, y = val_184, z = val_185}, b:  new UnityEngine.Vector3() {x = val_151, y = val_134.y, z = val_134.x});
        // 0x00BAF4FC: STP s0, s1, [sp, #0x20]    | stack[1152921514494700832] = val_141.x;  stack[1152921514494700836] = val_141.y;  //  dest_result_addr=1152921514494700832 |  dest_result_addr=1152921514494700836
        // 0x00BAF500: STR s2, [sp, #0x28]        | stack[1152921514494700840] = val_141.z;  //  dest_result_addr=1152921514494700840
        // 0x00BAF504: ADD x0, sp, #0x20          | X0 = (1152921514494700800 + 32) = 1152921514494700832 (0x100000024D5CAD20);
        label_113:
        // 0x00BAF508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF50C: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BAF510: LDR s3, [x19, #0xb4]       | S3 = this.lineTargetDis; //P2           
        // 0x00BAF514: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF51C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_141.x, y = val_141.y, z = val_141.z}, d:  this.lineTargetDis);
        UnityEngine.Vector3 val_142 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_141.x, y = val_141.y, z = val_141.z}, d:  this.lineTargetDis);
        // 0x00BAF520: MOV v3.16b, v0.16b         | V3 = val_142.x;//m1                     
        // 0x00BAF524: LDR s0, [sp]               | S0 = this.lineTargetPos;                
        // 0x00BAF528: MOV v4.16b, v1.16b         | V4 = val_142.y;//m1                     
        // 0x00BAF52C: MOV v5.16b, v2.16b         | V5 = val_142.z;//m1                     
        // 0x00BAF530: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF538: MOV v1.16b, v12.16b        | V1 = this.lineMidDis;//m1               
        // 0x00BAF53C: MOV v2.16b, v13.16b        | V2 = this.lineTime;//m1                 
        // 0x00BAF540: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = this.lineMidDis, z = val_171}, b:  new UnityEngine.Vector3() {x = val_142.x, y = val_142.y, z = val_142.z});
        UnityEngine.Vector3 val_143 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = this.lineTargetPos, y = this.lineMidDis, z = val_171}, b:  new UnityEngine.Vector3() {x = val_142.x, y = val_142.y, z = val_142.z});
        // 0x00BAF544: MOV v3.16b, v0.16b         | V3 = val_143.x;//m1                     
        // 0x00BAF548: MOV v4.16b, v1.16b         | V4 = val_143.y;//m1                     
        // 0x00BAF54C: MOV v5.16b, v2.16b         | V5 = val_143.z;//m1                     
        // 0x00BAF550: LDP s1, s0, [sp, #8]       | S1 = val_137.y; S0 = val_137.x;          //  | 
        val_181 = val_137.x;
        // 0x00BAF554: LDR s2, [sp, #4]           | S2 = val_137.z;                         
        // 0x00BAF558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF55C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        label_101:
        // 0x00BAF560: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_181, y = val_137.y, z = val_137.z}, b:  new UnityEngine.Vector3() {x = val_143.x, y = val_143.y, z = val_143.z});
        float val_144 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_181, y = val_137.y, z = val_137.z}, b:  new UnityEngine.Vector3() {x = val_143.x, y = val_143.y, z = val_143.z});
        // 0x00BAF564: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BAF568: LDR s1, [x8, #0x770]       | S1 = 0.01;                              
        // 0x00BAF56C: FCMP s0, s1                | STATE = COMPARE(val_144, 0.00999999977648258)
        // 0x00BAF570: B.HI #0xbaf5f8             | if (val_144 > 0.01f) goto label_123;    
        if(val_144 > 0.01f)
        {
            goto label_123;
        }
        // 0x00BAF574: STRB wzr, [x19, #0xbc]     | this.isLineRunning = false;              //  dest_result_addr=1152921514494713260
        this.isLineRunning = false;
        // 0x00BAF578: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00BAF57C: LDR w8, [x19, #0xe4]       | W8 = this.lineCameraShotId; //P2        
        // 0x00BAF580: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00BAF584: ADD x1, sp, #0x10          | X1 = (1152921514494700800 + 16) = 1152921514494700816 (0x100000024D5CAD10);
        // 0x00BAF588: STR w8, [sp, #0x10]        | stack[1152921514494700816] = this.lineCameraShotId;  //  dest_result_addr=1152921514494700816
        // 0x00BAF58C: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00BAF590: BL #0x27bc028              | X0 = 1152921514494966256 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.lineCameraShotId);
        // 0x00BAF594: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00BAF598: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00BAF59C: MOV x20, x0                | X20 = 1152921514494966256 (0x100000024D60B9F0);//ML01
        // 0x00BAF5A0: LDR x8, [x8]               | X8 = typeof(CEvent.ZEvent);             
        // 0x00BAF5A4: MOV x0, x8                 | X0 = 1152921504898326528 (0x10000000115FA000);//ML01
        CEvent.ZEvent val_145 = null;
        // 0x00BAF5A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00BAF5AC: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00BAF5B0: LDR x8, [x8, #0x510]       | X8 = (string**)(1152921514494688976)("LINE_MOVE");
        // 0x00BAF5B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAF5B8: MOV x2, x20                | X2 = 1152921514494966256 (0x100000024D60B9F0);//ML01
        // 0x00BAF5BC: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        val_146 = val_145;
        // 0x00BAF5C0: LDR x1, [x8]               | X1 = "LINE_MOVE";                       
        // 0x00BAF5C4: BL #0xd7de54               | .ctor(name:  "LINE_MOVE", arg:  this.lineCameraShotId);
        val_145 = new CEvent.ZEvent(name:  "LINE_MOVE", arg:  this.lineCameraShotId);
        // 0x00BAF5C8: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00BAF5CC: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00BAF5D0: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00BAF5D4: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00BAF5D8: TBZ w8, #0, #0xbaf5e8      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_125;
        // 0x00BAF5DC: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00BAF5E0: CBNZ w8, #0xbaf5e8         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_125;
        // 0x00BAF5E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_125:
        // 0x00BAF5E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF5EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAF5F0: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00BAF5F4: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        label_123:
        // 0x00BAF5F8: SUB sp, x29, #0x70         | SP = (1152921514494701056 - 112) = 1152921514494700944 (0x100000024D5CAD90);
        // 0x00BAF5FC: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAF600: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAF604: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAF608: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAF60C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAF610: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAF614: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAF618: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00BAF61C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAF620 (12252704), len: 416  VirtAddr: 0x00BAF620 RVA: 0x00BAF620 token: 100690252 methodIndex: 25785 delegateWrapperIndex: 0 methodInvoker: 0
    private void FixedUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        float val_8;
        //  | 
        var val_9;
        // 0x00BAF620: STP d9, d8, [sp, #-0x30]!  | stack[1152921514495058880] = ???;  stack[1152921514495058888] = ???;  //  dest_result_addr=1152921514495058880 |  dest_result_addr=1152921514495058888
        // 0x00BAF624: STP x20, x19, [sp, #0x10]  | stack[1152921514495058896] = ???;  stack[1152921514495058904] = ???;  //  dest_result_addr=1152921514495058896 |  dest_result_addr=1152921514495058904
        // 0x00BAF628: STP x29, x30, [sp, #0x20]  | stack[1152921514495058912] = ???;  stack[1152921514495058920] = ???;  //  dest_result_addr=1152921514495058912 |  dest_result_addr=1152921514495058920
        // 0x00BAF62C: ADD x29, sp, #0x20         | X29 = (1152921514495058880 + 32) = 1152921514495058912 (0x100000024D6223E0);
        // 0x00BAF630: SUB sp, sp, #0x10          | SP = (1152921514495058880 - 16) = 1152921514495058864 (0x100000024D6223B0);
        // 0x00BAF634: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAF638: LDRB w8, [x20, #0xb10]     | W8 = (bool)static_value_03733B10;       
        // 0x00BAF63C: MOV x19, x0                | X19 = 1152921514495070928 (0x100000024D6252D0);//ML01
        val_7 = this;
        // 0x00BAF640: TBNZ w8, #0, #0xbaf65c     | if (static_value_03733B10 == true) goto label_0;
        // 0x00BAF644: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00BAF648: LDR x8, [x8, #0xae0]       | X8 = 0x2B90288;                         
        // 0x00BAF64C: LDR w0, [x8]               | W0 = 0x1766;                            
        // 0x00BAF650: BL #0x2782188              | X0 = sub_2782188( ?? 0x1766, ????);     
        // 0x00BAF654: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAF658: STRB w8, [x20, #0xb10]     | static_value_03733B10 = true;            //  dest_result_addr=57883408
        label_0:
        // 0x00BAF65C: LDRB w8, [x19, #0x21]      | W8 = this.isBrightChange; //P2          
        // 0x00BAF660: CBZ w8, #0xbaf7ac          | if (this.isBrightChange == false) goto label_9;
        if(this.isBrightChange == false)
        {
            goto label_9;
        }
        // 0x00BAF664: LDR s8, [x19, #0x50]       | S8 = this.time_Temp; //P2               
        val_8 = this.time_Temp;
        // 0x00BAF668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF66C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF670: BL #0x2690de0              | X0 = UnityEngine.Time.get_fixedDeltaTime();
        float val_1 = UnityEngine.Time.fixedDeltaTime;
        // 0x00BAF674: LDR w8, [x19, #0x5c]       | W8 = this.brightId; //P2                
        // 0x00BAF678: FADD s0, s8, s0            | S0 = (this.time_Temp + val_1);          
        val_1 = val_8 + val_1;
        // 0x00BAF67C: STR s0, [x19, #0x50]       | this.time_Temp = (this.time_Temp + val_1);  //  dest_result_addr=1152921514495071008
        this.time_Temp = val_1;
        // 0x00BAF680: CBZ w8, #0xbaf6cc          | if (this.brightId == 0) goto label_2;   
        if(this.brightId == 0)
        {
            goto label_2;
        }
        // 0x00BAF684: CMP w8, #1                 | STATE = COMPARE(this.brightId, 0x1)     
        // 0x00BAF688: B.NE #0xbaf718             | if (this.brightId != 1) goto label_3;   
        if(this.brightId != 1)
        {
            goto label_3;
        }
        // 0x00BAF68C: LDR x20, [x19, #0x60]      | X20 = this.brightUI; //P2               
        // 0x00BAF690: CBNZ x20, #0xbaf698        | if (this.brightUI != null) goto label_4;
        if(this.brightUI != null)
        {
            goto label_4;
        }
        // 0x00BAF694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_4:
        // 0x00BAF698: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00BAF69C: LDR x8, [x8, #0xcf8]       | X8 = 1152921511873753152;               
        // 0x00BAF6A0: MOV x0, x20                | X0 = this.brightUI;//m1                 
        // 0x00BAF6A4: LDR x1, [x8]               | X1 = public UITexture UnityEngine.GameObject::GetComponent<UITexture>();
        // 0x00BAF6A8: BL #0x23d5abc              | X0 = this.brightUI.GetComponent<UITexture>();
        UITexture val_2 = this.brightUI.GetComponent<UITexture>();
        // 0x00BAF6AC: LDP s8, s9, [x19, #0x4c]   | S8 = this.brightTime; //P2  S9 = this.time_Temp; //P2  //  | 
        val_8 = this.brightTime;
        // 0x00BAF6B0: MOV x20, x0                | X20 = val_2;//m1                        
        val_9 = val_2;
        // 0x00BAF6B4: CBNZ x20, #0xbaf6bc        | if (val_2 != null) goto label_5;        
        if(val_9 != null)
        {
            goto label_5;
        }
        // 0x00BAF6B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00BAF6BC: LDR x8, [x20]              | X8 = typeof(UITexture);                 
        // 0x00BAF6C0: FDIV s0, s9, s8            | S0 = (this.time_Temp / this.brightTime);
        float val_3 = this.time_Temp / val_8;
        // 0x00BAF6C4: LDP x9, x1, [x8, #0x190]   | X9 = public System.Void UIWidget::set_alpha(float value); X1 = public System.Void UIWidget::set_alpha(float value); //  | 
        // 0x00BAF6C8: B #0xbaf710                |  goto label_6;                          
        goto label_6;
        label_2:
        // 0x00BAF6CC: LDR x20, [x19, #0x60]      | X20 = this.brightUI; //P2               
        // 0x00BAF6D0: CBNZ x20, #0xbaf6d8        | if (this.brightUI != null) goto label_7;
        if(this.brightUI != null)
        {
            goto label_7;
        }
        // 0x00BAF6D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_7:
        // 0x00BAF6D8: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00BAF6DC: LDR x8, [x8, #0xcf8]       | X8 = 1152921511873753152;               
        // 0x00BAF6E0: MOV x0, x20                | X0 = this.brightUI;//m1                 
        // 0x00BAF6E4: LDR x1, [x8]               | X1 = public UITexture UnityEngine.GameObject::GetComponent<UITexture>();
        // 0x00BAF6E8: BL #0x23d5abc              | X0 = this.brightUI.GetComponent<UITexture>();
        UITexture val_4 = this.brightUI.GetComponent<UITexture>();
        // 0x00BAF6EC: LDP s8, s9, [x19, #0x4c]   | S8 = this.brightTime; //P2  S9 = this.time_Temp; //P2  //  | 
        val_8 = this.brightTime;
        // 0x00BAF6F0: MOV x20, x0                | X20 = val_4;//m1                        
        val_9 = val_4;
        // 0x00BAF6F4: CBNZ x20, #0xbaf6fc        | if (val_4 != null) goto label_8;        
        if(val_9 != null)
        {
            goto label_8;
        }
        // 0x00BAF6F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x00BAF6FC: LDR x8, [x20]              | X8 = typeof(UITexture);                 
        // 0x00BAF700: FDIV s0, s9, s8            | S0 = (this.time_Temp / this.brightTime);
        float val_5 = this.time_Temp / val_8;
        // 0x00BAF704: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x00BAF708: FSUB s0, s1, s0            | S0 = (1f - (this.time_Temp / this.brightTime));
        val_5 = 1f - val_5;
        // 0x00BAF70C: LDP x9, x1, [x8, #0x190]   | X9 = public System.Void UIWidget::set_alpha(float value); X1 = public System.Void UIWidget::set_alpha(float value); //  | 
        label_6:
        // 0x00BAF710: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00BAF714: BLR x9                     | val_4.set_alpha(value:  val_5 = 1f - val_5);
        val_9.alpha = val_5;
        label_3:
        // 0x00BAF718: LDP s0, s1, [x19, #0x4c]   | S0 = this.brightTime; //P2  S1 = this.time_Temp; //P2  //  | 
        // 0x00BAF71C: FCMP s1, s0                | STATE = COMPARE(this.time_Temp, this.brightTime)
        // 0x00BAF720: B.LT #0xbaf7ac             | if (this.time_Temp < this.brightTime) goto label_9;
        if(this.time_Temp < this.brightTime)
        {
            goto label_9;
        }
        // 0x00BAF724: STR wzr, [x19, #0x50]      | this.time_Temp = 0;                      //  dest_result_addr=1152921514495071008
        this.time_Temp = 0f;
        // 0x00BAF728: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00BAF72C: STRB wzr, [x19, #0x21]     | this.isBrightChange = false;             //  dest_result_addr=1152921514495070961
        this.isBrightChange = false;
        // 0x00BAF730: LDR w8, [x19, #0x68]       | W8 = this.curCameraShotId; //P2         
        // 0x00BAF734: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00BAF738: ADD x1, sp, #0xc           | X1 = (1152921514495058864 + 12) = 1152921514495058876 (0x100000024D6223BC);
        // 0x00BAF73C: STR w8, [sp, #0xc]         | stack[1152921514495058876] = this.curCameraShotId;  //  dest_result_addr=1152921514495058876
        // 0x00BAF740: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00BAF744: BL #0x27bc028              | X0 = 1152921514495119312 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.curCameraShotId);
        // 0x00BAF748: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00BAF74C: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00BAF750: MOV x20, x0                | X20 = 1152921514495119312 (0x100000024D630FD0);//ML01
        // 0x00BAF754: LDR x8, [x8]               | X8 = typeof(CEvent.ZEvent);             
        // 0x00BAF758: MOV x0, x8                 | X0 = 1152921504898326528 (0x10000000115FA000);//ML01
        CEvent.ZEvent val_6 = null;
        // 0x00BAF75C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00BAF760: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00BAF764: LDR x8, [x8, #0x758]       | X8 = (string**)(1152921514495046832)("BRIGHT_DONE");
        // 0x00BAF768: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAF76C: MOV x2, x20                | X2 = 1152921514495119312 (0x100000024D630FD0);//ML01
        // 0x00BAF770: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        val_7 = val_6;
        // 0x00BAF774: LDR x1, [x8]               | X1 = "BRIGHT_DONE";                     
        // 0x00BAF778: BL #0xd7de54               | .ctor(name:  "BRIGHT_DONE", arg:  this.curCameraShotId);
        val_6 = new CEvent.ZEvent(name:  "BRIGHT_DONE", arg:  this.curCameraShotId);
        // 0x00BAF77C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00BAF780: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00BAF784: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00BAF788: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00BAF78C: TBZ w8, #0, #0xbaf79c      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00BAF790: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00BAF794: CBNZ w8, #0xbaf79c         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00BAF798: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_11:
        // 0x00BAF79C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF7A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAF7A4: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00BAF7A8: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        label_9:
        // 0x00BAF7AC: SUB sp, x29, #0x20         | SP = (1152921514495058912 - 32) = 1152921514495058880 (0x100000024D6223C0);
        // 0x00BAF7B0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAF7B4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAF7B8: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00BAF7BC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAF7C0 (12253120), len: 1216  VirtAddr: 0x00BAF7C0 RVA: 0x00BAF7C0 token: 100690253 methodIndex: 25786 delegateWrapperIndex: 0 methodInvoker: 0
    public void lineMoveCtrl(int targetId, int isHero, UnityEngine.Vector3 targetPos, float stopDis, float time, int isDamp, int curCameraShotId)
    {
        //
        // Disasemble & Code
        //  | 
        float val_33;
        //  | 
        float val_34;
        //  | 
        float val_35;
        //  | 
        float val_36;
        //  | 
        float val_37;
        //  | 
        float val_38;
        //  | 
        float val_39;
        //  | 
        float val_40;
        //  | 
        var val_41;
        // 0x00BAF7C0: STP d15, d14, [sp, #-0x80]! | stack[1152921514495260912] = ???;  stack[1152921514495260920] = ???;  //  dest_result_addr=1152921514495260912 |  dest_result_addr=1152921514495260920
        // 0x00BAF7C4: STP d13, d12, [sp, #0x10]  | stack[1152921514495260928] = ???;  stack[1152921514495260936] = ???;  //  dest_result_addr=1152921514495260928 |  dest_result_addr=1152921514495260936
        // 0x00BAF7C8: STP d11, d10, [sp, #0x20]  | stack[1152921514495260944] = ???;  stack[1152921514495260952] = ???;  //  dest_result_addr=1152921514495260944 |  dest_result_addr=1152921514495260952
        // 0x00BAF7CC: STP d9, d8, [sp, #0x30]    | stack[1152921514495260960] = ???;  stack[1152921514495260968] = ???;  //  dest_result_addr=1152921514495260960 |  dest_result_addr=1152921514495260968
        // 0x00BAF7D0: STP x24, x23, [sp, #0x40]  | stack[1152921514495260976] = ???;  stack[1152921514495260984] = ???;  //  dest_result_addr=1152921514495260976 |  dest_result_addr=1152921514495260984
        // 0x00BAF7D4: STP x22, x21, [sp, #0x50]  | stack[1152921514495260992] = ???;  stack[1152921514495261000] = ???;  //  dest_result_addr=1152921514495260992 |  dest_result_addr=1152921514495261000
        // 0x00BAF7D8: STP x20, x19, [sp, #0x60]  | stack[1152921514495261008] = ???;  stack[1152921514495261016] = ???;  //  dest_result_addr=1152921514495261008 |  dest_result_addr=1152921514495261016
        // 0x00BAF7DC: STP x29, x30, [sp, #0x70]  | stack[1152921514495261024] = ???;  stack[1152921514495261032] = ???;  //  dest_result_addr=1152921514495261024 |  dest_result_addr=1152921514495261032
        // 0x00BAF7E0: ADD x29, sp, #0x70         | X29 = (1152921514495260912 + 112) = 1152921514495261024 (0x100000024D653960);
        // 0x00BAF7E4: SUB sp, sp, #0x30          | SP = (1152921514495260912 - 48) = 1152921514495260864 (0x100000024D6538C0);
        // 0x00BAF7E8: ADRP x24, #0x3733000       | X24 = 57880576 (0x3733000);             
        // 0x00BAF7EC: LDRB w8, [x24, #0xb11]     | W8 = (bool)static_value_03733B11;       
        // 0x00BAF7F0: MOV w20, w4                | W20 = curCameraShotId;//m1              
        // 0x00BAF7F4: MOV w19, w3                | W19 = isDamp;//m1                       
        // 0x00BAF7F8: MOV v13.16b, v4.16b        | V13 = time;//m1                         
        val_33 = time;
        // 0x00BAF7FC: MOV v11.16b, v3.16b        | V11 = stopDis;//m1                      
        val_34 = stopDis;
        // 0x00BAF800: MOV v12.16b, v2.16b        | V12 = targetPos.z;//m1                  
        val_35 = targetPos.z;
        // 0x00BAF804: MOV v14.16b, v1.16b        | V14 = targetPos.y;//m1                  
        val_36 = targetPos.y;
        // 0x00BAF808: MOV v15.16b, v0.16b        | V15 = targetPos.x;//m1                  
        val_37 = targetPos.x;
        // 0x00BAF80C: MOV w23, w2                | W23 = isHero;//m1                       
        // 0x00BAF810: MOV w22, w1                | W22 = targetId;//m1                     
        // 0x00BAF814: MOV x21, x0                | X21 = 1152921514495273040 (0x100000024D656850);//ML01
        // 0x00BAF818: TBNZ w8, #0, #0xbaf834     | if (static_value_03733B11 == true) goto label_0;
        // 0x00BAF81C: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x00BAF820: LDR x8, [x8, #0x198]       | X8 = 0x2B90290;                         
        // 0x00BAF824: LDR w0, [x8]               | W0 = 0x1768;                            
        // 0x00BAF828: BL #0x2782188              | X0 = sub_2782188( ?? 0x1768, ????);     
        // 0x00BAF82C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAF830: STRB w8, [x24, #0xb11]     | static_value_03733B11 = true;            //  dest_result_addr=57883409
        label_0:
        // 0x00BAF834: STR wzr, [sp, #0x28]       | stack[1152921514495260904] = 0x0;        //  dest_result_addr=1152921514495260904
        // 0x00BAF838: STR xzr, [sp, #0x20]       | stack[1152921514495260896] = 0x0;        //  dest_result_addr=1152921514495260896
        // 0x00BAF83C: STR wzr, [sp, #0x18]       | stack[1152921514495260888] = 0x0;        //  dest_result_addr=1152921514495260888
        // 0x00BAF840: STR xzr, [sp, #0x10]       | stack[1152921514495260880] = 0x0;        //  dest_result_addr=1152921514495260880
        // 0x00BAF844: CMP w22, #1                | STATE = COMPARE(targetId, 0x1)          
        // 0x00BAF848: B.LT #0xbafab0             | if (targetId < 1) goto label_1;         
        if(targetId < 1)
        {
            goto label_1;
        }
        // 0x00BAF84C: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BAF850: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BAF854: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BAF858: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BAF85C: LDR x24, [x8]              | X24 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BAF860: CBNZ x24, #0xbaf868        | if (GameMgr.UPDATEOnOffEffect != null) goto label_2;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_2;
        }
        // 0x00BAF864: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1768, ????);     
        label_2:
        // 0x00BAF868: CMP w23, #1                | STATE = COMPARE(isHero, 0x1)            
        // 0x00BAF86C: CSET w1, eq                | W1 = isHero == 1 ? 1 : 0;               
        bool val_1 = (isHero == 1) ? 1 : 0;
        // 0x00BAF870: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAF874: MOV x0, x24                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BAF878: MOV w2, w22                | W2 = targetId;//m1                      
        // 0x00BAF87C: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_1 = (isHero == 1) ? 1 : 0, id:  targetId);
        CombatEntity val_2 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_1, id:  targetId);
        // 0x00BAF880: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00BAF884: CBNZ x22, #0xbaf88c        | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x00BAF888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00BAF88C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF890: MOV x0, x22                | X0 = val_2;//m1                         
        // 0x00BAF894: STR s12, [sp, #0xc]        | stack[1152921514495260876] = targetPos.z;  //  dest_result_addr=1152921514495260876
        // 0x00BAF898: BL #0x20d50fc              | X0 = val_2.get_gameObject();            
        UnityEngine.GameObject val_3 = val_2.gameObject;
        // 0x00BAF89C: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00BAF8A0: CBNZ x22, #0xbaf8a8        | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00BAF8A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00BAF8A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF8AC: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x00BAF8B0: MOV v12.16b, v11.16b       | V12 = stopDis;//m1                      
        // 0x00BAF8B4: BL #0x1a62c1c              | X0 = val_3.get_transform();             
        UnityEngine.Transform val_4 = val_3.transform;
        // 0x00BAF8B8: STR x0, [x21, #0xa0]       | this.line_Tr = val_4;                    //  dest_result_addr=1152921514495273200
        this.line_Tr = val_4;
        // 0x00BAF8BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF8C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF8C4: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_5 = UnityEngine.Camera.main;
        // 0x00BAF8C8: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00BAF8CC: CBNZ x22, #0xbaf8d4        | if (val_5 != null) goto label_5;        
        if(val_5 != null)
        {
            goto label_5;
        }
        // 0x00BAF8D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_5:
        // 0x00BAF8D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF8D8: MOV x0, x22                | X0 = val_5;//m1                         
        // 0x00BAF8DC: STP s15, s14, [sp, #4]     | stack[1152921514495260868] = targetPos.x;  stack[1152921514495260872] = targetPos.y;  //  dest_result_addr=1152921514495260868 |  dest_result_addr=1152921514495260872
        // 0x00BAF8E0: MOV v11.16b, v13.16b       | V11 = time;//m1                         
        // 0x00BAF8E4: BL #0x20d5094              | X0 = val_5.get_transform();             
        UnityEngine.Transform val_6 = val_5.transform;
        // 0x00BAF8E8: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00BAF8EC: CBNZ x22, #0xbaf8f4        | if (val_6 != null) goto label_6;        
        if(val_6 != null)
        {
            goto label_6;
        }
        // 0x00BAF8F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_6:
        // 0x00BAF8F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF8F8: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00BAF8FC: BL #0x2693510              | X0 = val_6.get_position();              
        UnityEngine.Vector3 val_7 = val_6.position;
        // 0x00BAF900: LDR x22, [x21, #0xa0]      | X22 = this.line_Tr; //P2                
        // 0x00BAF904: MOV v13.16b, v0.16b        | V13 = val_7.x;//m1                      
        // 0x00BAF908: MOV v14.16b, v1.16b        | V14 = val_7.y;//m1                      
        // 0x00BAF90C: MOV v15.16b, v2.16b        | V15 = val_7.z;//m1                      
        // 0x00BAF910: CBNZ x22, #0xbaf918        | if (this.line_Tr != null) goto label_7; 
        if(this.line_Tr != null)
        {
            goto label_7;
        }
        // 0x00BAF914: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_7:
        // 0x00BAF918: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF91C: MOV x0, x22                | X0 = this.line_Tr;//m1                  
        // 0x00BAF920: BL #0x2693510              | X0 = this.line_Tr.get_position();       
        UnityEngine.Vector3 val_8 = this.line_Tr.position;
        // 0x00BAF924: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAF928: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAF92C: MOV v8.16b, v0.16b         | V8 = val_8.x;//m1                       
        // 0x00BAF930: MOV v9.16b, v1.16b         | V9 = val_8.y;//m1                       
        // 0x00BAF934: MOV v10.16b, v2.16b        | V10 = val_8.z;//m1                      
        // 0x00BAF938: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAF93C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAF940: TBZ w8, #0, #0xbaf950      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00BAF944: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAF948: CBNZ w8, #0xbaf950         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00BAF94C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_9:
        // 0x00BAF950: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF954: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF958: MOV v0.16b, v13.16b        | V0 = val_7.x;//m1                       
        // 0x00BAF95C: MOV v1.16b, v14.16b        | V1 = val_7.y;//m1                       
        // 0x00BAF960: MOV v2.16b, v15.16b        | V2 = val_7.z;//m1                       
        // 0x00BAF964: MOV v3.16b, v8.16b         | V3 = val_8.x;//m1                       
        // 0x00BAF968: MOV v4.16b, v9.16b         | V4 = val_8.y;//m1                       
        // 0x00BAF96C: MOV v5.16b, v10.16b        | V5 = val_8.z;//m1                       
        // 0x00BAF970: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
        UnityEngine.Vector3 val_9 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
        // 0x00BAF974: ADD x0, sp, #0x20          | X0 = (1152921514495260864 + 32) = 1152921514495260896 (0x100000024D6538E0);
        // 0x00BAF978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF97C: STP s0, s1, [sp, #0x20]    | stack[1152921514495260896] = val_9.x;  stack[1152921514495260900] = val_9.y;  //  dest_result_addr=1152921514495260896 |  dest_result_addr=1152921514495260900
        // 0x00BAF980: STR s2, [sp, #0x28]        | stack[1152921514495260904] = val_9.z;    //  dest_result_addr=1152921514495260904
        // 0x00BAF984: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BAF988: LDR x22, [x21, #0xa0]      | X22 = this.line_Tr; //P2                
        // 0x00BAF98C: MOV v8.16b, v0.16b         | V8 = val_9.x;//m1                       
        // 0x00BAF990: MOV v9.16b, v1.16b         | V9 = val_9.y;//m1                       
        // 0x00BAF994: MOV v10.16b, v2.16b        | V10 = val_9.z;//m1                      
        // 0x00BAF998: CBNZ x22, #0xbaf9a0        | if (this.line_Tr != null) goto label_10;
        if(this.line_Tr != null)
        {
            goto label_10;
        }
        // 0x00BAF99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000024D6538E0, ????);
        label_10:
        // 0x00BAF9A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF9A4: MOV x0, x22                | X0 = this.line_Tr;//m1                  
        // 0x00BAF9A8: BL #0x2693510              | X0 = this.line_Tr.get_position();       
        UnityEngine.Vector3 val_10 = this.line_Tr.position;
        // 0x00BAF9AC: MOV v13.16b, v0.16b        | V13 = val_10.x;//m1                     
        // 0x00BAF9B0: MOV v14.16b, v1.16b        | V14 = val_10.y;//m1                     
        // 0x00BAF9B4: MOV v15.16b, v2.16b        | V15 = val_10.z;//m1                     
        // 0x00BAF9B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF9BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF9C0: MOV v0.16b, v8.16b         | V0 = val_9.x;//m1                       
        // 0x00BAF9C4: MOV v1.16b, v9.16b         | V1 = val_9.y;//m1                       
        // 0x00BAF9C8: MOV v2.16b, v10.16b        | V2 = val_9.z;//m1                       
        // 0x00BAF9CC: MOV v3.16b, v12.16b        | V3 = stopDis;//m1                       
        // 0x00BAF9D0: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, d:  val_34);
        UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, d:  val_34);
        // 0x00BAF9D4: MOV v3.16b, v0.16b         | V3 = val_11.x;//m1                      
        // 0x00BAF9D8: MOV v4.16b, v1.16b         | V4 = val_11.y;//m1                      
        // 0x00BAF9DC: MOV v5.16b, v2.16b         | V5 = val_11.z;//m1                      
        // 0x00BAF9E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF9E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAF9E8: MOV v0.16b, v13.16b        | V0 = val_10.x;//m1                      
        // 0x00BAF9EC: MOV v1.16b, v14.16b        | V1 = val_10.y;//m1                      
        // 0x00BAF9F0: MOV v2.16b, v15.16b        | V2 = val_10.z;//m1                      
        // 0x00BAF9F4: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
        UnityEngine.Vector3 val_12 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
        // 0x00BAF9F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAF9FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFA00: STP s0, s1, [x21, #0xcc]   | this.lineTarget_Temp = val_12;  mem[1152921514495273248] = val_12.y;  //  dest_result_addr=1152921514495273244 |  dest_result_addr=1152921514495273248
        this.lineTarget_Temp = val_12;
        mem[1152921514495273248] = val_12.y;
        // 0x00BAFA04: STR s2, [x21, #0xd4]       | mem[1152921514495273252] = val_12.z;     //  dest_result_addr=1152921514495273252
        mem[1152921514495273252] = val_12.z;
        // 0x00BAFA08: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_13 = UnityEngine.Camera.main;
        // 0x00BAFA0C: MOV x22, x0                | X22 = val_13;//m1                       
        // 0x00BAFA10: CBNZ x22, #0xbafa18        | if (val_13 != null) goto label_11;      
        if(val_13 != null)
        {
            goto label_11;
        }
        // 0x00BAFA14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_11:
        // 0x00BAFA18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFA1C: MOV x0, x22                | X0 = val_13;//m1                        
        // 0x00BAFA20: BL #0x20d5094              | X0 = val_13.get_transform();            
        UnityEngine.Transform val_14 = val_13.transform;
        // 0x00BAFA24: LDP s15, s14, [sp, #4]     | S15 = targetPos.x; S14 = targetPos.y;    //  | 
        val_37 = val_37;
        val_36 = val_36;
        // 0x00BAFA28: MOV x22, x0                | X22 = val_14;//m1                       
        // 0x00BAFA2C: MOV v13.16b, v11.16b       | V13 = time;//m1                         
        val_33 = val_33;
        // 0x00BAFA30: CBNZ x22, #0xbafa38        | if (val_14 != null) goto label_12;      
        if(val_14 != null)
        {
            goto label_12;
        }
        // 0x00BAFA34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_12:
        // 0x00BAFA38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFA3C: MOV x0, x22                | X0 = val_14;//m1                        
        // 0x00BAFA40: BL #0x2693510              | X0 = val_14.get_position();             
        UnityEngine.Vector3 val_15 = val_14.position;
        // 0x00BAFA44: LDR x22, [x21, #0xa0]      | X22 = this.line_Tr; //P2                
        // 0x00BAFA48: MOV v8.16b, v0.16b         | V8 = val_15.x;//m1                      
        val_38 = val_15.x;
        // 0x00BAFA4C: MOV v9.16b, v1.16b         | V9 = val_15.y;//m1                      
        // 0x00BAFA50: MOV v10.16b, v2.16b        | V10 = val_15.z;//m1                     
        val_39 = val_15.z;
        // 0x00BAFA54: MOV v11.16b, v12.16b       | V11 = stopDis;//m1                      
        val_34 = val_34;
        // 0x00BAFA58: CBNZ x22, #0xbafa60        | if (this.line_Tr != null) goto label_13;
        if(this.line_Tr != null)
        {
            goto label_13;
        }
        // 0x00BAFA5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_13:
        // 0x00BAFA60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFA64: MOV x0, x22                | X0 = this.line_Tr;//m1                  
        // 0x00BAFA68: BL #0x2693510              | X0 = this.line_Tr.get_position();       
        UnityEngine.Vector3 val_16 = this.line_Tr.position;
        // 0x00BAFA6C: MOV v3.16b, v0.16b         | V3 = val_16.x;//m1                      
        // 0x00BAFA70: MOV v4.16b, v1.16b         | V4 = val_16.y;//m1                      
        // 0x00BAFA74: MOV v5.16b, v2.16b         | V5 = val_16.z;//m1                      
        // 0x00BAFA78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFA7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFA80: MOV v0.16b, v8.16b         | V0 = val_15.x;//m1                      
        val_40 = val_38;
        // 0x00BAFA84: MOV v1.16b, v9.16b         | V1 = val_15.y;//m1                      
        // 0x00BAFA88: MOV v2.16b, v10.16b        | V2 = val_15.z;//m1                      
        // 0x00BAFA8C: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_40, y = val_15.y, z = val_39}, b:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z});
        float val_17 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_40, y = val_15.y, z = val_39}, b:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z});
        // 0x00BAFA90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFA94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFA98: STR s0, [x21, #0xdc]       | this.lineTruthDis = val_17;              //  dest_result_addr=1152921514495273260
        this.lineTruthDis = val_17;
        // 0x00BAFA9C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_18 = UnityEngine.Camera.main;
        // 0x00BAFAA0: LDR s12, [sp, #0xc]        | S12 = targetPos.z;                      
        val_35 = val_35;
        // 0x00BAFAA4: MOV x22, x0                | X22 = val_18;//m1                       
        val_41 = val_18;
        // 0x00BAFAA8: CBNZ x22, #0xbafc00        | if (val_18 != null) goto label_22;      
        if(val_41 != null)
        {
            goto label_22;
        }
        // 0x00BAFAAC: B #0xbafbfc                |  goto label_15;                         
        goto label_15;
        label_1:
        // 0x00BAFAB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFAB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFAB8: STR xzr, [x21, #0xa0]      | this.line_Tr = null;                     //  dest_result_addr=1152921514495273200
        this.line_Tr = 0;
        // 0x00BAFABC: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_19 = UnityEngine.Camera.main;
        // 0x00BAFAC0: MOV x22, x0                | X22 = val_19;//m1                       
        // 0x00BAFAC4: CBNZ x22, #0xbafacc        | if (val_19 != null) goto label_16;      
        if(val_19 != null)
        {
            goto label_16;
        }
        // 0x00BAFAC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_16:
        // 0x00BAFACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFAD0: MOV x0, x22                | X0 = val_19;//m1                        
        // 0x00BAFAD4: BL #0x20d5094              | X0 = val_19.get_transform();            
        UnityEngine.Transform val_20 = val_19.transform;
        // 0x00BAFAD8: MOV x22, x0                | X22 = val_20;//m1                       
        // 0x00BAFADC: CBNZ x22, #0xbafae4        | if (val_20 != null) goto label_17;      
        if(val_20 != null)
        {
            goto label_17;
        }
        // 0x00BAFAE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_17:
        // 0x00BAFAE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFAE8: MOV x0, x22                | X0 = val_20;//m1                        
        // 0x00BAFAEC: BL #0x2693510              | X0 = val_20.get_position();             
        UnityEngine.Vector3 val_21 = val_20.position;
        // 0x00BAFAF0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAFAF4: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAFAF8: MOV v8.16b, v0.16b         | V8 = val_21.x;//m1                      
        val_38 = val_21.x;
        // 0x00BAFAFC: MOV v9.16b, v1.16b         | V9 = val_21.y;//m1                      
        // 0x00BAFB00: MOV v10.16b, v2.16b        | V10 = val_21.z;//m1                     
        val_39 = val_21.z;
        // 0x00BAFB04: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAFB08: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAFB0C: TBZ w8, #0, #0xbafb1c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00BAFB10: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAFB14: CBNZ w8, #0xbafb1c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00BAFB18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_19:
        // 0x00BAFB1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFB20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFB24: MOV v0.16b, v8.16b         | V0 = val_21.x;//m1                      
        // 0x00BAFB28: MOV v1.16b, v9.16b         | V1 = val_21.y;//m1                      
        // 0x00BAFB2C: MOV v2.16b, v10.16b        | V2 = val_21.z;//m1                      
        // 0x00BAFB30: MOV v3.16b, v15.16b        | V3 = targetPos.x;//m1                   
        // 0x00BAFB34: MOV v4.16b, v14.16b        | V4 = targetPos.y;//m1                   
        // 0x00BAFB38: MOV v5.16b, v12.16b        | V5 = targetPos.z;//m1                   
        // 0x00BAFB3C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_38, y = val_21.y, z = val_39}, b:  new UnityEngine.Vector3() {x = val_37, y = val_36, z = val_35});
        UnityEngine.Vector3 val_22 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_38, y = val_21.y, z = val_39}, b:  new UnityEngine.Vector3() {x = val_37, y = val_36, z = val_35});
        // 0x00BAFB40: ADD x0, sp, #0x10          | X0 = (1152921514495260864 + 16) = 1152921514495260880 (0x100000024D6538D0);
        // 0x00BAFB44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFB48: STP s0, s1, [sp, #0x10]    | stack[1152921514495260880] = val_22.x;  stack[1152921514495260884] = val_22.y;  //  dest_result_addr=1152921514495260880 |  dest_result_addr=1152921514495260884
        // 0x00BAFB4C: STR s2, [sp, #0x18]        | stack[1152921514495260888] = val_22.z;   //  dest_result_addr=1152921514495260888
        // 0x00BAFB50: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BAFB54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFB58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFB5C: MOV v3.16b, v11.16b        | V3 = stopDis;//m1                       
        // 0x00BAFB60: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z}, d:  val_34);
        UnityEngine.Vector3 val_23 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z}, d:  val_34);
        // 0x00BAFB64: MOV v3.16b, v0.16b         | V3 = val_23.x;//m1                      
        // 0x00BAFB68: MOV v4.16b, v1.16b         | V4 = val_23.y;//m1                      
        // 0x00BAFB6C: MOV v5.16b, v2.16b         | V5 = val_23.z;//m1                      
        // 0x00BAFB70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFB74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFB78: MOV v0.16b, v15.16b        | V0 = targetPos.x;//m1                   
        val_40 = val_37;
        // 0x00BAFB7C: MOV v1.16b, v14.16b        | V1 = targetPos.y;//m1                   
        // 0x00BAFB80: MOV v2.16b, v12.16b        | V2 = targetPos.z;//m1                   
        // 0x00BAFB84: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_40, y = val_36, z = val_35}, b:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z});
        UnityEngine.Vector3 val_24 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_40, y = val_36, z = val_35}, b:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z});
        // 0x00BAFB88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFB8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFB90: STP s0, s1, [x21, #0xcc]   | this.lineTarget_Temp = val_24;  mem[1152921514495273248] = val_24.y;  //  dest_result_addr=1152921514495273244 |  dest_result_addr=1152921514495273248
        this.lineTarget_Temp = val_24;
        mem[1152921514495273248] = val_24.y;
        // 0x00BAFB94: STR s2, [x21, #0xd4]       | mem[1152921514495273252] = val_24.z;     //  dest_result_addr=1152921514495273252
        mem[1152921514495273252] = val_24.z;
        // 0x00BAFB98: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_25 = UnityEngine.Camera.main;
        // 0x00BAFB9C: MOV x22, x0                | X22 = val_25;//m1                       
        // 0x00BAFBA0: CBNZ x22, #0xbafba8        | if (val_25 != null) goto label_20;      
        if(val_25 != null)
        {
            goto label_20;
        }
        // 0x00BAFBA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_20:
        // 0x00BAFBA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFBAC: MOV x0, x22                | X0 = val_25;//m1                        
        // 0x00BAFBB0: BL #0x20d5094              | X0 = val_25.get_transform();            
        UnityEngine.Transform val_26 = val_25.transform;
        // 0x00BAFBB4: MOV x22, x0                | X22 = val_26;//m1                       
        // 0x00BAFBB8: CBNZ x22, #0xbafbc0        | if (val_26 != null) goto label_21;      
        if(val_26 != null)
        {
            goto label_21;
        }
        // 0x00BAFBBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_21:
        // 0x00BAFBC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFBC4: MOV x0, x22                | X0 = val_26;//m1                        
        // 0x00BAFBC8: BL #0x2693510              | X0 = val_26.get_position();             
        UnityEngine.Vector3 val_27 = val_26.position;
        // 0x00BAFBCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFBD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFBD4: MOV v3.16b, v15.16b        | V3 = targetPos.x;//m1                   
        // 0x00BAFBD8: MOV v4.16b, v14.16b        | V4 = targetPos.y;//m1                   
        // 0x00BAFBDC: MOV v5.16b, v12.16b        | V5 = targetPos.z;//m1                   
        // 0x00BAFBE0: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z}, b:  new UnityEngine.Vector3() {x = val_37, y = val_36, z = val_35});
        float val_28 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z}, b:  new UnityEngine.Vector3() {x = val_37, y = val_36, z = val_35});
        // 0x00BAFBE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFBE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFBEC: STR s0, [x21, #0xdc]       | this.lineTruthDis = val_28;              //  dest_result_addr=1152921514495273260
        this.lineTruthDis = val_28;
        // 0x00BAFBF0: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_29 = UnityEngine.Camera.main;
        // 0x00BAFBF4: MOV x22, x0                | X22 = val_29;//m1                       
        val_41 = val_29;
        // 0x00BAFBF8: CBNZ x22, #0xbafc00        | if (val_29 != null) goto label_22;      
        if(val_41 != null)
        {
            goto label_22;
        }
        label_15:
        // 0x00BAFBFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
        label_22:
        // 0x00BAFC00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFC04: MOV x0, x22                | X0 = val_29;//m1                        
        // 0x00BAFC08: BL #0x20d5094              | X0 = val_29.get_transform();            
        UnityEngine.Transform val_30 = val_41.transform;
        // 0x00BAFC0C: MOV x22, x0                | X22 = val_30;//m1                       
        // 0x00BAFC10: CBNZ x22, #0xbafc18        | if (val_30 != null) goto label_23;      
        if(val_30 != null)
        {
            goto label_23;
        }
        // 0x00BAFC14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_23:
        // 0x00BAFC18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFC1C: MOV x0, x22                | X0 = val_30;//m1                        
        // 0x00BAFC20: BL #0x2693510              | X0 = val_30.get_position();             
        UnityEngine.Vector3 val_31 = val_30.position;
        // 0x00BAFC24: LDR s3, [x21, #0xcc]       | S3 = this.lineTarget_Temp; //P2         
        // 0x00BAFC28: LDR s4, [x21, #0xd0]       | 
        // 0x00BAFC2C: LDR s5, [x21, #0xd4]       | 
        // 0x00BAFC30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFC34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFC38: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_31.x, y = val_31.y, z = val_31.z}, b:  new UnityEngine.Vector3() {x = this.lineTarget_Temp, y = val_36, z = val_35});
        float val_32 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_31.x, y = val_31.y, z = val_31.z}, b:  new UnityEngine.Vector3() {x = this.lineTarget_Temp, y = val_36, z = val_35});
        // 0x00BAFC3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAFC40: STR s0, [x21, #0xe0]       | this.lineMidDis = val_32;                //  dest_result_addr=1152921514495273264
        this.lineMidDis = val_32;
        // 0x00BAFC44: STP w20, w19, [x21, #0xe4] | this.lineCameraShotId = curCameraShotId;  this.isDamp = isDamp;  //  dest_result_addr=1152921514495273268 |  dest_result_addr=1152921514495273272
        this.lineCameraShotId = curCameraShotId;
        this.isDamp = isDamp;
        // 0x00BAFC48: STP s15, s14, [x21, #0xa8] | this.lineTargetPos = targetPos;  mem[1152921514495273212] = targetPos.y;  //  dest_result_addr=1152921514495273208 |  dest_result_addr=1152921514495273212
        this.lineTargetPos = targetPos;
        mem[1152921514495273212] = val_36;
        // 0x00BAFC4C: STP s12, s11, [x21, #0xb0] | mem[1152921514495273216] = targetPos.z;  this.lineTargetDis = stopDis;  //  dest_result_addr=1152921514495273216 |  dest_result_addr=1152921514495273220
        mem[1152921514495273216] = val_35;
        this.lineTargetDis = val_34;
        // 0x00BAFC50: STR s13, [x21, #0xb8]      | this.lineTime = time;                    //  dest_result_addr=1152921514495273224
        this.lineTime = val_33;
        // 0x00BAFC54: STRB w8, [x21, #0xbc]      | this.isLineRunning = true;               //  dest_result_addr=1152921514495273228
        this.isLineRunning = true;
        // 0x00BAFC58: SUB sp, x29, #0x70         | SP = (1152921514495261024 - 112) = 1152921514495260912 (0x100000024D6538F0);
        // 0x00BAFC5C: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAFC60: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAFC64: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAFC68: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAFC6C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAFC70: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAFC74: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAFC78: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00BAFC7C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAFC80 (12254336), len: 24  VirtAddr: 0x00BAFC80 RVA: 0x00BAFC80 token: 100690254 methodIndex: 25787 delegateWrapperIndex: 0 methodInvoker: 0
    public void gameSpeedCtrl(float speed, float from, float wait, float to, int id)
    {
        //
        // Disasemble & Code
        // 0x00BAFC80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAFC84: STP s1, s0, [x0, #0x84]    | this.forNormalTime = from;  this.targetSpeed = speed;  //  dest_result_addr=1152921514495454804 |  dest_result_addr=1152921514495454808
        this.forNormalTime = from;
        this.targetSpeed = speed;
        // 0x00BAFC88: STP s3, s2, [x0, #0x8c]    | this.toNormalTime = to;  this.targetWaitTime = wait;  //  dest_result_addr=1152921514495454812 |  dest_result_addr=1152921514495454816
        this.toNormalTime = to;
        this.targetWaitTime = wait;
        // 0x00BAFC8C: STRB w8, [x0, #0x7c]       | this.isCtrlGameSpeed = true;             //  dest_result_addr=1152921514495454796
        this.isCtrlGameSpeed = true;
        // 0x00BAFC90: STR w1, [x0, #0x9c]        | this.gameSpeedId = id;                   //  dest_result_addr=1152921514495454828
        this.gameSpeedId = id;
        // 0x00BAFC94: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAFC98 (12254360), len: 568  VirtAddr: 0x00BAFC98 RVA: 0x00BAFC98 token: 100690255 methodIndex: 25788 delegateWrapperIndex: 0 methodInvoker: 0
    public void brightChange(int brightId, float time, int curCameraShotId)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        float val_9;
        // 0x00BAFC98: STP d9, d8, [sp, #-0x60]!  | stack[1152921514495572096] = ???;  stack[1152921514495572104] = ???;  //  dest_result_addr=1152921514495572096 |  dest_result_addr=1152921514495572104
        // 0x00BAFC9C: STP x26, x25, [sp, #0x10]  | stack[1152921514495572112] = ???;  stack[1152921514495572120] = ???;  //  dest_result_addr=1152921514495572112 |  dest_result_addr=1152921514495572120
        // 0x00BAFCA0: STP x24, x23, [sp, #0x20]  | stack[1152921514495572128] = ???;  stack[1152921514495572136] = ???;  //  dest_result_addr=1152921514495572128 |  dest_result_addr=1152921514495572136
        // 0x00BAFCA4: STP x22, x21, [sp, #0x30]  | stack[1152921514495572144] = ???;  stack[1152921514495572152] = ???;  //  dest_result_addr=1152921514495572144 |  dest_result_addr=1152921514495572152
        // 0x00BAFCA8: STP x20, x19, [sp, #0x40]  | stack[1152921514495572160] = ???;  stack[1152921514495572168] = ???;  //  dest_result_addr=1152921514495572160 |  dest_result_addr=1152921514495572168
        // 0x00BAFCAC: STP x29, x30, [sp, #0x50]  | stack[1152921514495572176] = ???;  stack[1152921514495572184] = ???;  //  dest_result_addr=1152921514495572176 |  dest_result_addr=1152921514495572184
        // 0x00BAFCB0: ADD x29, sp, #0x50         | X29 = (1152921514495572096 + 80) = 1152921514495572176 (0x100000024D69F8D0);
        // 0x00BAFCB4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAFCB8: LDRB w8, [x20, #0xb12]     | W8 = (bool)static_value_03733B12;       
        // 0x00BAFCBC: MOV w21, w2                | W21 = curCameraShotId;//m1              
        // 0x00BAFCC0: MOV v8.16b, v0.16b         | V8 = time;//m1                          
        // 0x00BAFCC4: MOV w22, w1                | W22 = brightId;//m1                     
        // 0x00BAFCC8: MOV x19, x0                | X19 = 1152921514495584192 (0x100000024D6A27C0);//ML01
        // 0x00BAFCCC: TBNZ w8, #0, #0xbafce8     | if (static_value_03733B12 == true) goto label_0;
        // 0x00BAFCD0: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00BAFCD4: LDR x8, [x8, #0xc48]       | X8 = 0x2B90274;                         
        // 0x00BAFCD8: LDR w0, [x8]               | W0 = 0x1761;                            
        // 0x00BAFCDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1761, ????);     
        // 0x00BAFCE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAFCE4: STRB w8, [x20, #0xb12]     | static_value_03733B12 = true;            //  dest_result_addr=57883410
        label_0:
        // 0x00BAFCE8: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
        // 0x00BAFCEC: LDR x8, [x8, #0x630]       | X8 = 1152921504888049664;               
        // 0x00BAFCF0: LDR x0, [x8]               | X0 = typeof(CameraShotHelper.<brightChange>c__AnonStorey0);
        CameraShotHelper.<brightChange>c__AnonStorey0 val_1 = null;
        // 0x00BAFCF4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CameraShotHelper.<brightChange>c__AnonStorey0), ????);
        // 0x00BAFCF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFCFC: MOV x20, x0                | X20 = 1152921504888049664 (0x1000000010C2D000);//ML01
        // 0x00BAFD00: BL #0xd76fa0               | .ctor();                                
        val_1 = new CameraShotHelper.<brightChange>c__AnonStorey0();
        // 0x00BAFD04: CBZ x20, #0xbafd24         | if ( == 0) goto label_1;                
        if(null == 0)
        {
            goto label_1;
        }
        // 0x00BAFD08: MOV x23, x20               | X23 = 1152921504888049664 (0x1000000010C2D000);//ML01
        val_7 = val_1;
        // 0x00BAFD0C: MOV x25, x20               | X25 = 1152921504888049664 (0x1000000010C2D000);//ML01
        val_8 = val_1;
        // 0x00BAFD10: MOV x24, x20               | X24 = 1152921504888049664 (0x1000000010C2D000);//ML01
        val_9 = val_1;
        // 0x00BAFD14: STR w22, [x23, #0x10]!     | typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_10 = brightId;  //  dest_result_addr=1152921504888049680
        typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_10 = brightId;
        // 0x00BAFD18: STR w21, [x25, #0x14]!     | typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_14 = curCameraShotId;  //  dest_result_addr=1152921504888049684
        typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_14 = curCameraShotId;
        // 0x00BAFD1C: STR s8, [x24, #0x18]!      | typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_18 = time;  //  dest_result_addr=1152921504888049688
        typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_18 = time;
        // 0x00BAFD20: B #0xbafd4c                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00BAFD24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BAFD28: ORR w23, wzr, #0x10        | W23 = 16(0x10);                         
        val_7 = 16;
        // 0x00BAFD2C: STR w22, [x23]             | mem[16] = brightId;                      //  dest_result_addr=16
        mem[16] = brightId;
        // 0x00BAFD30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BAFD34: MOV x25, x20               | X25 = 1152921504888049664 (0x1000000010C2D000);//ML01
        val_8 = val_1;
        // 0x00BAFD38: STR w21, [x25, #0x14]!     | typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_14 = curCameraShotId;  //  dest_result_addr=1152921504888049684
        typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_14 = curCameraShotId;
        // 0x00BAFD3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BAFD40: ORR w24, wzr, #0x18        | W24 = 24(0x18);                         
        val_9 = 3.363116E-44f;
        // 0x00BAFD44: STR s8, [x24]              | mem[24] = time;                          //  dest_result_addr=24
        mem[24] = time;
        // 0x00BAFD48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00BAFD4C: STR x19, [x20, #0x20]      | typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_20 = this;  //  dest_result_addr=1152921504888049696
        typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_20 = this;
        // 0x00BAFD50: STR wzr, [x19, #0x50]      | this.time_Temp = 0;                      //  dest_result_addr=1152921514495584272
        this.time_Temp = 0f;
        // 0x00BAFD54: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BAFD58: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BAFD5C: LDR x21, [x19, #0x60]      | X21 = this.brightUI; //P2               
        // 0x00BAFD60: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BAFD64: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BAFD68: TBZ w8, #0, #0xbafd78      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00BAFD6C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BAFD70: CBNZ w8, #0xbafd78         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00BAFD74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x00BAFD78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFD7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFD80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAFD84: MOV x2, x21                | X2 = this.brightUI;//m1                 
        // 0x00BAFD88: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00BAFD8C: TBZ w0, #0, #0xbafe04      | if (val_2 == false) goto label_5;       
        if(val_2 == false)
        {
            goto label_5;
        }
        // 0x00BAFD90: LDR x21, [x19, #0x60]      | X21 = this.brightUI; //P2               
        // 0x00BAFD94: CBNZ x21, #0xbafd9c        | if (this.brightUI != null) goto label_6;
        if(this.brightUI != null)
        {
            goto label_6;
        }
        // 0x00BAFD98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00BAFD9C: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00BAFDA0: LDR x8, [x8, #0xcf8]       | X8 = 1152921511873753152;               
        // 0x00BAFDA4: MOV x0, x21                | X0 = this.brightUI;//m1                 
        // 0x00BAFDA8: LDR x1, [x8]               | X1 = public UITexture UnityEngine.GameObject::GetComponent<UITexture>();
        // 0x00BAFDAC: BL #0x23d5abc              | X0 = this.brightUI.GetComponent<UITexture>();
        UITexture val_3 = this.brightUI.GetComponent<UITexture>();
        // 0x00BAFDB0: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00BAFDB4: CBNZ x20, #0xbafdbc        | if ( != 0) goto label_7;                
        if(null != 0)
        {
            goto label_7;
        }
        // 0x00BAFDB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00BAFDBC: LDR w8, [x23]              | W8 = brightId;                          
        // 0x00BAFDC0: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x00BAFDC4: FMOV s1, wzr               | S1 = 0f;                                
        // 0x00BAFDC8: CMP w8, #1                 | STATE = COMPARE(brightId, 0x1)          
        // 0x00BAFDCC: FCSEL s8, s1, s0, eq       | S8 = val_7 == 1 ? 0f : 1f;              
        float val_4 = (val_7 == 1) ? (0f) : (1f);
        // 0x00BAFDD0: CBNZ x21, #0xbafdd8        | if (val_3 != null) goto label_8;        
        if(val_3 != null)
        {
            goto label_8;
        }
        // 0x00BAFDD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00BAFDD8: LDR x8, [x21]              | X8 = typeof(UITexture);                 
        // 0x00BAFDDC: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00BAFDE0: MOV v0.16b, v8.16b         | V0 = val_7 == 1 ? 0f : 1f;//m1          
        // 0x00BAFDE4: LDP x9, x1, [x8, #0x190]   | X9 = public System.Void UIWidget::set_alpha(float value); X1 = public System.Void UIWidget::set_alpha(float value); //  | 
        // 0x00BAFDE8: BLR x9                     | val_3.set_alpha(value:  val_4);         
        val_3.alpha = val_4;
        // 0x00BAFDEC: CBZ x20, #0xbafe88         | if ( == 0) goto label_9;                
        if(null == 0)
        {
            goto label_9;
        }
        // 0x00BAFDF0: LDR w8, [x25]              | W8 = curCameraShotId;                   
        // 0x00BAFDF4: STR w8, [x19, #0x68]       | this.curCameraShotId = curCameraShotId;  //  dest_result_addr=1152921514495584296
        this.curCameraShotId = typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_14;
        // 0x00BAFDF8: LDR w8, [x23]              | W8 = brightId;                          
        // 0x00BAFDFC: STR w8, [x19, #0x5c]       | this.brightId = brightId;                //  dest_result_addr=1152921514495584284
        this.brightId = mem[16];
        // 0x00BAFE00: B #0xbafea4                |  goto label_10;                         
        goto label_10;
        label_5:
        // 0x00BAFE04: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
        // 0x00BAFE08: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
        // 0x00BAFE0C: LDR x8, [x8, #8]           | X8 = 1152921514495554960;               
        // 0x00BAFE10: LDR x9, [x9, #0xae0]       | X9 = 1152921504903278592;               
        // 0x00BAFE14: LDR x21, [x8]              | X21 = System.Void CameraShotHelper.<brightChange>c__AnonStorey0::<>m__0(Mihua.Asset.ABLoadOperation.AssetOperation ao);
        // 0x00BAFE18: LDR x0, [x9]               | X0 = typeof(Mihua.Asset.OnLoadAsset);   
        Mihua.Asset.OnLoadAsset val_5 = null;
        // 0x00BAFE1C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Asset.OnLoadAsset), ????);
        // 0x00BAFE20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAFE24: MOV x1, x20                | X1 = 1152921504888049664 (0x1000000010C2D000);//ML01
        // 0x00BAFE28: MOV x2, x21                | X2 = 1152921514495554960 (0x100000024D69B590);//ML01
        // 0x00BAFE2C: MOV x19, x0                | X19 = 1152921504903278592 (0x1000000011AB3000);//ML01
        // 0x00BAFE30: BL #0xab6fb4               | .ctor(object:  val_1, method:  System.Void CameraShotHelper.<brightChange>c__AnonStorey0::<>m__0(Mihua.Asset.ABLoadOperation.AssetOperation ao));
        val_5 = new Mihua.Asset.OnLoadAsset(object:  val_1, method:  System.Void CameraShotHelper.<brightChange>c__AnonStorey0::<>m__0(Mihua.Asset.ABLoadOperation.AssetOperation ao));
        // 0x00BAFE34: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00BAFE38: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
        // 0x00BAFE3C: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.AssetMgr);      
        // 0x00BAFE40: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
        // 0x00BAFE44: TBZ w8, #0, #0xbafe54      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00BAFE48: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00BAFE4C: CBNZ w8, #0xbafe54         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00BAFE50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
        label_12:
        // 0x00BAFE54: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00BAFE58: LDR x8, [x8, #0xa48]       | X8 = (string**)(1152921514495555984)("Misc/brightUI.prefab");
        // 0x00BAFE5C: MOV x2, x19                | X2 = 1152921504903278592 (0x1000000011AB3000);//ML01
        // 0x00BAFE60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFE64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAFE68: LDR x1, [x8]               | X1 = "Misc/brightUI.prefab";            
        // 0x00BAFE6C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAFE70: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAFE74: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAFE78: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAFE7C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00BAFE80: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00BAFE84: B #0xab5374                | X0 = Mihua.Asset.AssetMgr.LoadAssetAsync(assetName:  0, onLoadAsset:  "Misc/brightUI.prefab"); return;
        Mihua.Asset.ABLoadOperation.AssetOperation val_6 = Mihua.Asset.AssetMgr.LoadAssetAsync(assetName:  0, onLoadAsset:  "Misc/brightUI.prefab");
        return;
        label_9:
        // 0x00BAFE88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00BAFE8C: LDR w8, [x25]              | W8 = curCameraShotId;                   
        // 0x00BAFE90: STR w8, [x19, #0x68]       | this.curCameraShotId = curCameraShotId;  //  dest_result_addr=1152921514495584296
        this.curCameraShotId = typeof(CameraShotHelper.<brightChange>c__AnonStorey0).__il2cppRuntimeField_14;
        // 0x00BAFE94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        // 0x00BAFE98: LDR w8, [x23]              | W8 = brightId;                          
        // 0x00BAFE9C: STR w8, [x19, #0x5c]       | this.brightId = brightId;                //  dest_result_addr=1152921514495584284
        this.brightId = mem[16];
        // 0x00BAFEA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_10:
        // 0x00BAFEA4: LDR w8, [x24]              | W8 = time;                              
        // 0x00BAFEA8: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00BAFEAC: STRB w9, [x19, #0x21]      | this.isBrightChange = true;              //  dest_result_addr=1152921514495584225
        this.isBrightChange = true;
        // 0x00BAFEB0: STR w8, [x19, #0x4c]       | this.brightTime = time;                  //  dest_result_addr=1152921514495584268
        this.brightTime = val_9;
        // 0x00BAFEB4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAFEB8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAFEBC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAFEC0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00BAFEC4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00BAFEC8: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00BAFECC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAFED0 (12254928), len: 500  VirtAddr: 0x00BAFED0 RVA: 0x00BAFED0 token: 100690256 methodIndex: 25789 delegateWrapperIndex: 0 methodInvoker: 0
    public void circleAction(int id, string boneName, UnityEngine.Vector3 tg, float sp, float dt, float hg, float sa, int isHero, int isRight)
    {
        //
        // Disasemble & Code
        //  | 
        string val_11;
        //  | 
        var val_12;
        // 0x00BAFED0: STP d15, d14, [sp, #-0x80]! | stack[1152921514495729120] = ???;  stack[1152921514495729128] = ???;  //  dest_result_addr=1152921514495729120 |  dest_result_addr=1152921514495729128
        // 0x00BAFED4: STP d13, d12, [sp, #0x10]  | stack[1152921514495729136] = ???;  stack[1152921514495729144] = ???;  //  dest_result_addr=1152921514495729136 |  dest_result_addr=1152921514495729144
        // 0x00BAFED8: STP d11, d10, [sp, #0x20]  | stack[1152921514495729152] = ???;  stack[1152921514495729160] = ???;  //  dest_result_addr=1152921514495729152 |  dest_result_addr=1152921514495729160
        // 0x00BAFEDC: STP d9, d8, [sp, #0x30]    | stack[1152921514495729168] = ???;  stack[1152921514495729176] = ???;  //  dest_result_addr=1152921514495729168 |  dest_result_addr=1152921514495729176
        // 0x00BAFEE0: STP x24, x23, [sp, #0x40]  | stack[1152921514495729184] = ???;  stack[1152921514495729192] = ???;  //  dest_result_addr=1152921514495729184 |  dest_result_addr=1152921514495729192
        // 0x00BAFEE4: STP x22, x21, [sp, #0x50]  | stack[1152921514495729200] = ???;  stack[1152921514495729208] = ???;  //  dest_result_addr=1152921514495729200 |  dest_result_addr=1152921514495729208
        // 0x00BAFEE8: STP x20, x19, [sp, #0x60]  | stack[1152921514495729216] = ???;  stack[1152921514495729224] = ???;  //  dest_result_addr=1152921514495729216 |  dest_result_addr=1152921514495729224
        // 0x00BAFEEC: STP x29, x30, [sp, #0x70]  | stack[1152921514495729232] = ???;  stack[1152921514495729240] = ???;  //  dest_result_addr=1152921514495729232 |  dest_result_addr=1152921514495729240
        // 0x00BAFEF0: ADD x29, sp, #0x70         | X29 = (1152921514495729120 + 112) = 1152921514495729232 (0x100000024D6C5E50);
        // 0x00BAFEF4: ADRP x24, #0x3733000       | X24 = 57880576 (0x3733000);             
        // 0x00BAFEF8: LDRB w8, [x24, #0xb13]     | W8 = (bool)static_value_03733B13;       
        // 0x00BAFEFC: MOV w19, w4                | W19 = isRight;//m1                      
        // 0x00BAFF00: MOV w22, w3                | W22 = isHero;//m1                       
        // 0x00BAFF04: MOV v14.16b, v6.16b        | V14 = sa;//m1                           
        // 0x00BAFF08: MOV v10.16b, v5.16b        | V10 = hg;//m1                           
        // 0x00BAFF0C: MOV v12.16b, v4.16b        | V12 = dt;//m1                           
        // 0x00BAFF10: MOV v8.16b, v3.16b         | V8 = sp;//m1                            
        // 0x00BAFF14: MOV v9.16b, v2.16b         | V9 = tg.z;//m1                          
        // 0x00BAFF18: MOV v11.16b, v1.16b        | V11 = tg.y;//m1                         
        // 0x00BAFF1C: MOV v13.16b, v0.16b        | V13 = tg.x;//m1                         
        // 0x00BAFF20: MOV x21, x2                | X21 = boneName;//m1                     
        val_11 = boneName;
        // 0x00BAFF24: MOV w23, w1                | W23 = id;//m1                           
        // 0x00BAFF28: MOV x20, x0                | X20 = 1152921514495741248 (0x100000024D6C8D40);//ML01
        // 0x00BAFF2C: TBNZ w8, #0, #0xbaff48     | if (static_value_03733B13 == true) goto label_0;
        // 0x00BAFF30: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00BAFF34: LDR x8, [x8, #0xf20]       | X8 = 0x2B90280;                         
        // 0x00BAFF38: LDR w0, [x8]               | W0 = 0x1764;                            
        // 0x00BAFF3C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1764, ????);     
        // 0x00BAFF40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAFF44: STRB w8, [x24, #0xb13]     | static_value_03733B13 = true;            //  dest_result_addr=57883411
        label_0:
        // 0x00BAFF48: STR xzr, [x20, #0x28]      | this.circle_TargetTr = null;             //  dest_result_addr=1152921514495741288
        this.circle_TargetTr = 0;
        // 0x00BAFF4C: CMP w23, #1                | STATE = COMPARE(id, 0x1)                
        // 0x00BAFF50: B.LT #0xbb0084             | if (id < 1) goto label_13;              
        if(id < 1)
        {
            goto label_13;
        }
        // 0x00BAFF54: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BAFF58: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BAFF5C: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BAFF60: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BAFF64: LDR x24, [x8]              | X24 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BAFF68: CBNZ x24, #0xbaff70        | if (GameMgr.UPDATEOnOffEffect != null) goto label_2;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_2;
        }
        // 0x00BAFF6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1764, ????);     
        label_2:
        // 0x00BAFF70: CMP w22, #1                | STATE = COMPARE(isHero, 0x1)            
        // 0x00BAFF74: CSET w1, eq                | W1 = isHero == 1 ? 1 : 0;               
        bool val_1 = (isHero == 1) ? 1 : 0;
        // 0x00BAFF78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAFF7C: MOV x0, x24                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BAFF80: MOV w2, w23                | W2 = id;//m1                            
        // 0x00BAFF84: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_1 = (isHero == 1) ? 1 : 0, id:  id);
        CombatEntity val_2 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_1, id:  id);
        // 0x00BAFF88: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00BAFF8C: CBNZ x22, #0xbaff94        | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x00BAFF90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00BAFF94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFF98: MOV x0, x22                | X0 = val_2;//m1                         
        // 0x00BAFF9C: BL #0x20d50fc              | X0 = val_2.get_gameObject();            
        UnityEngine.GameObject val_3 = val_2.gameObject;
        // 0x00BAFFA0: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00BAFFA4: CBNZ x22, #0xbaffac        | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00BAFFA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00BAFFAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAFFB0: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x00BAFFB4: BL #0x1a62c1c              | X0 = val_3.get_transform();             
        UnityEngine.Transform val_4 = val_3.transform;
        // 0x00BAFFB8: STR x0, [x20, #0x28]       | this.circle_TargetTr = val_4;            //  dest_result_addr=1152921514495741288
        this.circle_TargetTr = val_4;
        // 0x00BAFFBC: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
        // 0x00BAFFC0: LDR x22, [x22, #0xe38]     | X22 = 1152921504608284672;              
        // 0x00BAFFC4: LDR x0, [x22]              | X0 = typeof(System.String);             
        val_12 = null;
        // 0x00BAFFC8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00BAFFCC: TBZ w8, #0, #0xbaffe0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00BAFFD0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00BAFFD4: CBNZ w8, #0xbaffe0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00BAFFD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00BAFFDC: LDR x0, [x22]              | X0 = typeof(System.String);             
        val_12 = null;
        label_6:
        // 0x00BAFFE0: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00BAFFE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAFFE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BAFFEC: MOV x2, x21                | X2 = boneName;//m1                      
        // 0x00BAFFF0: LDR x1, [x8]               | X1 = System.String.Empty;               
        // 0x00BAFFF4: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  System.String.Empty);
        bool val_5 = System.String.op_Inequality(a:  0, b:  System.String.Empty);
        // 0x00BAFFF8: CBZ x21, #0xbb0084         | if (boneName == null) goto label_13;    
        if(val_11 == null)
        {
            goto label_13;
        }
        // 0x00BAFFFC: EOR w8, w0, #1             | W8 = (val_5 ^ 1);                       
        bool val_6 = val_5 ^ 1;
        // 0x00BB0000: AND w8, w8, #1             | W8 = ((val_5 ^ 1) & 1);                 
        bool val_7 = val_6;
        // 0x00BB0004: TBNZ w8, #0, #0xbb0084     | if (((val_5 ^ 1) & 1) == true) goto label_13;
        if(val_7 == true)
        {
            goto label_13;
        }
        // 0x00BB0008: LDR x22, [x20, #0x28]      | X22 = this.circle_TargetTr; //P2        
        // 0x00BB000C: CBNZ x22, #0xbb0014        | if (this.circle_TargetTr != null) goto label_9;
        if(this.circle_TargetTr != null)
        {
            goto label_9;
        }
        // 0x00BB0010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00BB0014: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BB0018: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00BB001C: MOV x0, x22                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB0020: BL #0x2695dd8              | X0 = this.circle_TargetTr.GetChild(index:  2);
        UnityEngine.Transform val_8 = this.circle_TargetTr.GetChild(index:  2);
        // 0x00BB0024: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00BB0028: CBNZ x22, #0xbb0030        | if (val_8 != null) goto label_10;       
        if(val_8 != null)
        {
            goto label_10;
        }
        // 0x00BB002C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_10:
        // 0x00BB0030: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BB0034: MOV x0, x22                | X0 = val_8;//m1                         
        // 0x00BB0038: MOV x1, x21                | X1 = boneName;//m1                      
        // 0x00BB003C: BL #0x2695ac0              | X0 = val_8.Find(name:  val_11);         
        UnityEngine.Transform val_9 = val_8.Find(name:  val_11);
        // 0x00BB0040: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BB0044: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BB0048: MOV x21, x0                | X21 = val_9;//m1                        
        val_11 = val_9;
        // 0x00BB004C: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00BB0050: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BB0054: TBZ w9, #0, #0xbb0068      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00BB0058: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BB005C: CBNZ w9, #0xbb0068         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00BB0060: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00BB0064: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_12:
        // 0x00BB0068: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB006C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0070: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BB0074: MOV x2, x21                | X2 = val_9;//m1                         
        // 0x00BB0078: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_10 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00BB007C: TBZ w0, #0, #0xbb0084      | if (val_10 == false) goto label_13;     
        if(val_10 == false)
        {
            goto label_13;
        }
        // 0x00BB0080: STR x21, [x20, #0x28]      | this.circle_TargetTr = val_9;            //  dest_result_addr=1152921514495741288
        this.circle_TargetTr = val_11;
        label_13:
        // 0x00BB0084: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BB0088: STR s14, [x20, #0x58]      | this.circle_angled = sa;                 //  dest_result_addr=1152921514495741336
        this.circle_angled = sa;
        // 0x00BB008C: STP s12, s10, [x20, #0x40] | this.circle_Distance = dt;  this.circle_High = hg;  //  dest_result_addr=1152921514495741312 |  dest_result_addr=1152921514495741316
        this.circle_Distance = dt;
        this.circle_High = hg;
        // 0x00BB0090: STP s13, s11, [x20, #0x30] | this.circle_TargetPos = tg;  mem[1152921514495741300] = tg.y;  //  dest_result_addr=1152921514495741296 |  dest_result_addr=1152921514495741300
        this.circle_TargetPos = tg;
        mem[1152921514495741300] = tg.y;
        // 0x00BB0094: STP s9, s8, [x20, #0x38]   | mem[1152921514495741304] = tg.z;  this.circle_Speed = sp;  //  dest_result_addr=1152921514495741304 |  dest_result_addr=1152921514495741308
        mem[1152921514495741304] = tg.z;
        this.circle_Speed = sp;
        // 0x00BB0098: STRB w8, [x20, #0x22]      | this.isCircleCameraMoving = true;        //  dest_result_addr=1152921514495741282
        this.isCircleCameraMoving = true;
        // 0x00BB009C: STR w19, [x20, #0x6c]      | this.isRight = isRight;                  //  dest_result_addr=1152921514495741356
        this.isRight = isRight;
        // 0x00BB00A0: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00BB00A4: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00BB00A8: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00BB00AC: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00BB00B0: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BB00B4: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BB00B8: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BB00BC: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00BB00C0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BB00C4 (12255428), len: 2172  VirtAddr: 0x00BB00C4 RVA: 0x00BB00C4 token: 100690257 methodIndex: 25790 delegateWrapperIndex: 0 methodInvoker: 0
    public void circleAction_default(int id, string boneName, UnityEngine.Vector3 tg, int isRight, float sp, int isHero)
    {
        //
        // Disasemble & Code
        //  | 
        float val_69;
        //  | 
        float val_70;
        //  | 
        float val_71;
        //  | 
        var val_72;
        //  | 
        float val_73;
        //  | 
        UnityEngine.Transform val_74;
        //  | 
        float val_75;
        //  | 
        float val_76;
        //  | 
        float val_77;
        //  | 
        float val_78;
        //  | 
        float val_79;
        //  | 
        float val_80;
        //  | 
        float val_81;
        //  | 
        float val_82;
        //  | 
        float val_83;
        //  | 
        float val_84;
        //  | 
        float val_85;
        //  | 
        float val_86;
        // 0x00BB00C4: STP d15, d14, [sp, #-0x80]! | stack[1152921514495996768] = ???;  stack[1152921514495996776] = ???;  //  dest_result_addr=1152921514495996768 |  dest_result_addr=1152921514495996776
        // 0x00BB00C8: STP d13, d12, [sp, #0x10]  | stack[1152921514495996784] = ???;  stack[1152921514495996792] = ???;  //  dest_result_addr=1152921514495996784 |  dest_result_addr=1152921514495996792
        // 0x00BB00CC: STP d11, d10, [sp, #0x20]  | stack[1152921514495996800] = ???;  stack[1152921514495996808] = ???;  //  dest_result_addr=1152921514495996800 |  dest_result_addr=1152921514495996808
        // 0x00BB00D0: STP d9, d8, [sp, #0x30]    | stack[1152921514495996816] = ???;  stack[1152921514495996824] = ???;  //  dest_result_addr=1152921514495996816 |  dest_result_addr=1152921514495996824
        // 0x00BB00D4: STP x24, x23, [sp, #0x40]  | stack[1152921514495996832] = ???;  stack[1152921514495996840] = ???;  //  dest_result_addr=1152921514495996832 |  dest_result_addr=1152921514495996840
        // 0x00BB00D8: STP x22, x21, [sp, #0x50]  | stack[1152921514495996848] = ???;  stack[1152921514495996856] = ???;  //  dest_result_addr=1152921514495996848 |  dest_result_addr=1152921514495996856
        // 0x00BB00DC: STP x20, x19, [sp, #0x60]  | stack[1152921514495996864] = ???;  stack[1152921514495996872] = ???;  //  dest_result_addr=1152921514495996864 |  dest_result_addr=1152921514495996872
        // 0x00BB00E0: STP x29, x30, [sp, #0x70]  | stack[1152921514495996880] = ???;  stack[1152921514495996888] = ???;  //  dest_result_addr=1152921514495996880 |  dest_result_addr=1152921514495996888
        // 0x00BB00E4: ADD x29, sp, #0x70         | X29 = (1152921514495996768 + 112) = 1152921514495996880 (0x100000024D7073D0);
        // 0x00BB00E8: SUB sp, sp, #0x10          | SP = (1152921514495996768 - 16) = 1152921514495996752 (0x100000024D707350);
        // 0x00BB00EC: ADRP x24, #0x3733000       | X24 = 57880576 (0x3733000);             
        // 0x00BB00F0: LDRB w8, [x24, #0xb14]     | W8 = (bool)static_value_03733B14;       
        // 0x00BB00F4: MOV w22, w4                | W22 = isHero;//m1                       
        // 0x00BB00F8: MOV v13.16b, v3.16b        | V13 = sp;//m1                           
        // 0x00BB00FC: MOV w19, w3                | W19 = isRight;//m1                      
        // 0x00BB0100: MOV v9.16b, v2.16b         | V9 = tg.z;//m1                          
        val_69 = tg.z;
        // 0x00BB0104: MOV v11.16b, v1.16b        | V11 = tg.y;//m1                         
        val_70 = tg.y;
        // 0x00BB0108: MOV v15.16b, v0.16b        | V15 = tg.x;//m1                         
        val_71 = tg.x;
        // 0x00BB010C: MOV x21, x2                | X21 = boneName;//m1                     
        // 0x00BB0110: MOV w23, w1                | W23 = id;//m1                           
        // 0x00BB0114: MOV x20, x0                | X20 = 1152921514496008896 (0x100000024D70A2C0);//ML01
        // 0x00BB0118: TBNZ w8, #0, #0xbb0134     | if (static_value_03733B14 == true) goto label_0;
        // 0x00BB011C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00BB0120: LDR x8, [x8, #0xa38]       | X8 = 0x2B90278;                         
        // 0x00BB0124: LDR w0, [x8]               | W0 = 0x1762;                            
        // 0x00BB0128: BL #0x2782188              | X0 = sub_2782188( ?? 0x1762, ????);     
        // 0x00BB012C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BB0130: STRB w8, [x24, #0xb14]     | static_value_03733B14 = true;            //  dest_result_addr=57883412
        label_0:
        // 0x00BB0134: STR xzr, [x20, #0x28]      | this.circle_TargetTr = null;             //  dest_result_addr=1152921514496008936
        this.circle_TargetTr = 0;
        // 0x00BB0138: CMP w23, #1                | STATE = COMPARE(id, 0x1)                
        // 0x00BB013C: B.LT #0xbb052c             | if (id < 1) goto label_1;               
        if(id < 1)
        {
            goto label_1;
        }
        // 0x00BB0140: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BB0144: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BB0148: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BB014C: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BB0150: LDR x24, [x8]              | X24 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BB0154: CBNZ x24, #0xbb015c        | if (GameMgr.UPDATEOnOffEffect != null) goto label_2;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_2;
        }
        // 0x00BB0158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1762, ????);     
        label_2:
        // 0x00BB015C: CMP w22, #1                | STATE = COMPARE(isHero, 0x1)            
        // 0x00BB0160: CSET w1, eq                | W1 = isHero == 1 ? 1 : 0;               
        bool val_1 = (isHero == 1) ? 1 : 0;
        // 0x00BB0164: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BB0168: MOV x0, x24                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BB016C: MOV w2, w23                | W2 = id;//m1                            
        // 0x00BB0170: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_1 = (isHero == 1) ? 1 : 0, id:  id);
        CombatEntity val_2 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_1, id:  id);
        // 0x00BB0174: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00BB0178: CBNZ x22, #0xbb0180        | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x00BB017C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00BB0180: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0184: MOV x0, x22                | X0 = val_2;//m1                         
        // 0x00BB0188: BL #0x20d50fc              | X0 = val_2.get_gameObject();            
        UnityEngine.GameObject val_3 = val_2.gameObject;
        // 0x00BB018C: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00BB0190: CBNZ x22, #0xbb0198        | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00BB0194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00BB0198: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB019C: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x00BB01A0: BL #0x1a62c1c              | X0 = val_3.get_transform();             
        UnityEngine.Transform val_4 = val_3.transform;
        // 0x00BB01A4: STR x0, [x20, #0x28]       | this.circle_TargetTr = val_4;            //  dest_result_addr=1152921514496008936
        this.circle_TargetTr = val_4;
        // 0x00BB01A8: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
        // 0x00BB01AC: LDR x22, [x22, #0xe38]     | X22 = 1152921504608284672;              
        // 0x00BB01B0: LDR x0, [x22]              | X0 = typeof(System.String);             
        val_72 = null;
        // 0x00BB01B4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00BB01B8: TBZ w8, #0, #0xbb01cc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00BB01BC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00BB01C0: CBNZ w8, #0xbb01cc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00BB01C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00BB01C8: LDR x0, [x22]              | X0 = typeof(System.String);             
        val_72 = null;
        label_6:
        // 0x00BB01CC: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00BB01D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB01D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BB01D8: MOV x2, x21                | X2 = boneName;//m1                      
        // 0x00BB01DC: LDR x1, [x8]               | X1 = System.String.Empty;               
        // 0x00BB01E0: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  System.String.Empty);
        bool val_5 = System.String.op_Inequality(a:  0, b:  System.String.Empty);
        // 0x00BB01E4: CBNZ x21, #0xbb01f4        | if (boneName != null) goto label_7;     
        if(boneName != null)
        {
            goto label_7;
        }
        // 0x00BB01E8: EOR w8, w0, #1             | W8 = (val_5 ^ 1);                       
        bool val_6 = val_5 ^ 1;
        // 0x00BB01EC: AND w8, w8, #1             | W8 = ((val_5 ^ 1) & 1);                 
        bool val_7 = val_6;
        // 0x00BB01F0: TBNZ w8, #0, #0xbb0254     | if (((val_5 ^ 1) & 1) == true) goto label_12;
        if(val_7 == true)
        {
            goto label_12;
        }
        label_7:
        // 0x00BB01F4: LDR x22, [x20, #0x28]      | X22 = this.circle_TargetTr; //P2        
        // 0x00BB01F8: CBNZ x22, #0xbb0200        | if (this.circle_TargetTr != null) goto label_9;
        if(this.circle_TargetTr != null)
        {
            goto label_9;
        }
        // 0x00BB01FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00BB0200: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BB0204: MOV x0, x22                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB0208: MOV x1, x21                | X1 = boneName;//m1                      
        // 0x00BB020C: BL #0x2695ac0              | X0 = this.circle_TargetTr.Find(name:  boneName);
        UnityEngine.Transform val_8 = this.circle_TargetTr.Find(name:  boneName);
        // 0x00BB0210: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BB0214: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BB0218: MOV x21, x0                | X21 = val_8;//m1                        
        // 0x00BB021C: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00BB0220: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BB0224: TBZ w9, #0, #0xbb0238      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00BB0228: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BB022C: CBNZ w9, #0xbb0238         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00BB0230: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00BB0234: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_11:
        // 0x00BB0238: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB023C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0240: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BB0244: MOV x2, x21                | X2 = val_8;//m1                         
        // 0x00BB0248: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_9 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00BB024C: TBZ w0, #0, #0xbb0254      | if (val_9 == false) goto label_12;      
        if(val_9 == false)
        {
            goto label_12;
        }
        // 0x00BB0250: STR x21, [x20, #0x28]      | this.circle_TargetTr = val_8;            //  dest_result_addr=1152921514496008936
        this.circle_TargetTr = val_8;
        label_12:
        // 0x00BB0254: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0258: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB025C: STR s11, [sp, #0xc]        | stack[1152921514495996764] = tg.y;       //  dest_result_addr=1152921514495996764
        // 0x00BB0260: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_10 = UnityEngine.Camera.main;
        // 0x00BB0264: MOV x21, x0                | X21 = val_10;//m1                       
        // 0x00BB0268: CBNZ x21, #0xbb0270        | if (val_10 != null) goto label_13;      
        if(val_10 != null)
        {
            goto label_13;
        }
        // 0x00BB026C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_13:
        // 0x00BB0270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0274: MOV x0, x21                | X0 = val_10;//m1                        
        // 0x00BB0278: MOV v11.16b, v15.16b       | V11 = tg.x;//m1                         
        // 0x00BB027C: STR s9, [sp, #8]           | stack[1152921514495996760] = tg.z;       //  dest_result_addr=1152921514495996760
        // 0x00BB0280: BL #0x20d5094              | X0 = val_10.get_transform();            
        UnityEngine.Transform val_11 = val_10.transform;
        // 0x00BB0284: MOV x21, x0                | X21 = val_11;//m1                       
        // 0x00BB0288: CBNZ x21, #0xbb0290        | if (val_11 != null) goto label_14;      
        if(val_11 != null)
        {
            goto label_14;
        }
        // 0x00BB028C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_14:
        // 0x00BB0290: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0294: MOV x0, x21                | X0 = val_11;//m1                        
        // 0x00BB0298: MOV v9.16b, v13.16b        | V9 = sp;//m1                            
        // 0x00BB029C: BL #0x2693510              | X0 = val_11.get_position();             
        UnityEngine.Vector3 val_12 = val_11.position;
        // 0x00BB02A0: LDR x21, [x20, #0x28]      | X21 = this.circle_TargetTr; //P2        
        // 0x00BB02A4: MOV v12.16b, v0.16b        | V12 = val_12.x;//m1                     
        // 0x00BB02A8: MOV v13.16b, v1.16b        | V13 = val_12.y;//m1                     
        // 0x00BB02AC: MOV v14.16b, v2.16b        | V14 = val_12.z;//m1                     
        // 0x00BB02B0: CBNZ x21, #0xbb02b8        | if (this.circle_TargetTr != null) goto label_15;
        if(this.circle_TargetTr != null)
        {
            goto label_15;
        }
        // 0x00BB02B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_15:
        // 0x00BB02B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB02BC: MOV x0, x21                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB02C0: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_13 = this.circle_TargetTr.position;
        // 0x00BB02C4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BB02C8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BB02CC: MOV v15.16b, v0.16b        | V15 = val_13.x;//m1                     
        // 0x00BB02D0: MOV v8.16b, v1.16b         | V8 = val_13.y;//m1                      
        // 0x00BB02D4: MOV v10.16b, v2.16b        | V10 = val_13.z;//m1                     
        // 0x00BB02D8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BB02DC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BB02E0: TBZ w8, #0, #0xbb02f0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00BB02E4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BB02E8: CBNZ w8, #0xbb02f0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00BB02EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_17:
        // 0x00BB02F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB02F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB02F8: MOV v0.16b, v12.16b        | V0 = val_12.x;//m1                      
        // 0x00BB02FC: MOV v1.16b, v13.16b        | V1 = val_12.y;//m1                      
        // 0x00BB0300: MOV v2.16b, v14.16b        | V2 = val_12.z;//m1                      
        // 0x00BB0304: MOV v3.16b, v15.16b        | V3 = val_13.x;//m1                      
        // 0x00BB0308: MOV v4.16b, v8.16b         | V4 = val_13.y;//m1                      
        // 0x00BB030C: MOV v5.16b, v10.16b        | V5 = val_13.z;//m1                      
        // 0x00BB0310: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z});
        float val_14 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z});
        // 0x00BB0314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0318: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB031C: STR s0, [x20, #0x40]       | this.circle_Distance = val_14;           //  dest_result_addr=1152921514496008960
        this.circle_Distance = val_14;
        // 0x00BB0320: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_15 = UnityEngine.Camera.main;
        // 0x00BB0324: MOV x21, x0                | X21 = val_15;//m1                       
        // 0x00BB0328: CBNZ x21, #0xbb0330        | if (val_15 != null) goto label_18;      
        if(val_15 != null)
        {
            goto label_18;
        }
        // 0x00BB032C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_18:
        // 0x00BB0330: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0334: MOV x0, x21                | X0 = val_15;//m1                        
        // 0x00BB0338: BL #0x20d5094              | X0 = val_15.get_transform();            
        UnityEngine.Transform val_16 = val_15.transform;
        // 0x00BB033C: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x00BB0340: CBNZ x21, #0xbb0348        | if (val_16 != null) goto label_19;      
        if(val_16 != null)
        {
            goto label_19;
        }
        // 0x00BB0344: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_19:
        // 0x00BB0348: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB034C: MOV x0, x21                | X0 = val_16;//m1                        
        // 0x00BB0350: BL #0x2693510              | X0 = val_16.get_position();             
        UnityEngine.Vector3 val_17 = val_16.position;
        // 0x00BB0354: LDR x21, [x20, #0x28]      | X21 = this.circle_TargetTr; //P2        
        // 0x00BB0358: MOV v8.16b, v1.16b         | V8 = val_17.y;//m1                      
        // 0x00BB035C: CBNZ x21, #0xbb0364        | if (this.circle_TargetTr != null) goto label_20;
        if(this.circle_TargetTr != null)
        {
            goto label_20;
        }
        // 0x00BB0360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_20:
        // 0x00BB0364: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0368: MOV x0, x21                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB036C: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_18 = this.circle_TargetTr.position;
        // 0x00BB0370: FSUB s0, s8, s1            | S0 = (val_17.y - val_18.y);             
        float val_19 = val_17.y - val_18.y;
        // 0x00BB0374: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0378: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB037C: STR s0, [x20, #0x44]       | this.circle_High = (val_17.y - val_18.y);  //  dest_result_addr=1152921514496008964
        this.circle_High = val_19;
        // 0x00BB0380: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_20 = UnityEngine.Camera.main;
        // 0x00BB0384: MOV x21, x0                | X21 = val_20;//m1                       
        // 0x00BB0388: CBNZ x21, #0xbb0390        | if (val_20 != null) goto label_21;      
        if(val_20 != null)
        {
            goto label_21;
        }
        // 0x00BB038C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_21:
        // 0x00BB0390: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0394: MOV x0, x21                | X0 = val_20;//m1                        
        // 0x00BB0398: BL #0x20d5094              | X0 = val_20.get_transform();            
        UnityEngine.Transform val_21 = val_20.transform;
        // 0x00BB039C: MOV x21, x0                | X21 = val_21;//m1                       
        // 0x00BB03A0: CBNZ x21, #0xbb03a8        | if (val_21 != null) goto label_22;      
        if(val_21 != null)
        {
            goto label_22;
        }
        // 0x00BB03A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_22:
        // 0x00BB03A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB03AC: MOV x0, x21                | X0 = val_21;//m1                        
        // 0x00BB03B0: BL #0x2693510              | X0 = val_21.get_position();             
        UnityEngine.Vector3 val_22 = val_21.position;
        // 0x00BB03B4: LDR x21, [x20, #0x28]      | X21 = this.circle_TargetTr; //P2        
        // 0x00BB03B8: MOV v12.16b, v0.16b        | V12 = val_22.x;//m1                     
        // 0x00BB03BC: CBNZ x21, #0xbb03c4        | if (this.circle_TargetTr != null) goto label_23;
        if(this.circle_TargetTr != null)
        {
            goto label_23;
        }
        // 0x00BB03C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_23:
        // 0x00BB03C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB03C8: MOV x0, x21                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB03CC: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_23 = this.circle_TargetTr.position;
        // 0x00BB03D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB03D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB03D8: MOV v13.16b, v0.16b        | V13 = val_23.x;//m1                     
        // 0x00BB03DC: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_24 = UnityEngine.Camera.main;
        // 0x00BB03E0: MOV x21, x0                | X21 = val_24;//m1                       
        // 0x00BB03E4: CBNZ x21, #0xbb03ec        | if (val_24 != null) goto label_24;      
        if(val_24 != null)
        {
            goto label_24;
        }
        // 0x00BB03E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_24:
        // 0x00BB03EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB03F0: MOV x0, x21                | X0 = val_24;//m1                        
        // 0x00BB03F4: BL #0x20d5094              | X0 = val_24.get_transform();            
        UnityEngine.Transform val_25 = val_24.transform;
        // 0x00BB03F8: MOV x21, x0                | X21 = val_25;//m1                       
        // 0x00BB03FC: CBNZ x21, #0xbb0404        | if (val_25 != null) goto label_25;      
        if(val_25 != null)
        {
            goto label_25;
        }
        // 0x00BB0400: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_25:
        // 0x00BB0404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0408: MOV x0, x21                | X0 = val_25;//m1                        
        // 0x00BB040C: BL #0x2693510              | X0 = val_25.get_position();             
        UnityEngine.Vector3 val_26 = val_25.position;
        // 0x00BB0410: LDR x21, [x20, #0x28]      | X21 = this.circle_TargetTr; //P2        
        // 0x00BB0414: MOV v14.16b, v2.16b        | V14 = val_26.z;//m1                     
        // 0x00BB0418: CBNZ x21, #0xbb0420        | if (this.circle_TargetTr != null) goto label_26;
        if(this.circle_TargetTr != null)
        {
            goto label_26;
        }
        // 0x00BB041C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_26:
        // 0x00BB0420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0424: MOV x0, x21                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB0428: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_27 = this.circle_TargetTr.position;
        // 0x00BB042C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0430: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0434: MOV v15.16b, v2.16b        | V15 = val_27.z;//m1                     
        // 0x00BB0438: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_28 = UnityEngine.Camera.main;
        // 0x00BB043C: MOV x21, x0                | X21 = val_28;//m1                       
        // 0x00BB0440: CBNZ x21, #0xbb0448        | if (val_28 != null) goto label_27;      
        if(val_28 != null)
        {
            goto label_27;
        }
        // 0x00BB0444: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_27:
        // 0x00BB0448: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB044C: MOV x0, x21                | X0 = val_28;//m1                        
        // 0x00BB0450: FSUB s8, s12, s13          | S8 = (val_22.x - val_23.x);             
        float val_29 = val_22.x - val_23.x;
        // 0x00BB0454: BL #0x20d5094              | X0 = val_28.get_transform();            
        UnityEngine.Transform val_30 = val_28.transform;
        // 0x00BB0458: MOV x21, x0                | X21 = val_30;//m1                       
        // 0x00BB045C: CBNZ x21, #0xbb0464        | if (val_30 != null) goto label_28;      
        if(val_30 != null)
        {
            goto label_28;
        }
        // 0x00BB0460: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_28:
        // 0x00BB0464: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0468: MOV x0, x21                | X0 = val_30;//m1                        
        // 0x00BB046C: FSUB s10, s14, s15         | S10 = (val_26.z - val_27.z);            
        val_73 = val_26.z - val_27.z;
        // 0x00BB0470: BL #0x2693510              | X0 = val_30.get_position();             
        UnityEngine.Vector3 val_31 = val_30.position;
        // 0x00BB0474: LDR x21, [x20, #0x28]      | X21 = this.circle_TargetTr; //P2        
        val_74 = this.circle_TargetTr;
        // 0x00BB0478: MOV v12.16b, v0.16b        | V12 = val_31.x;//m1                     
        val_75 = val_31.x;
        // 0x00BB047C: MOV v13.16b, v2.16b        | V13 = val_31.z;//m1                     
        // 0x00BB0480: FCMP s8, #0.0              | STATE = COMPARE((val_22.x - val_23.x), 0)
        // 0x00BB0484: B.PL #0xbb075c             | if (val_29 >= 0) goto label_29;         
        if(val_29 >= 0)
        {
            goto label_29;
        }
        // 0x00BB0488: MOV v14.16b, v9.16b        | V14 = sp;//m1                           
        val_76 = sp;
        // 0x00BB048C: MOV v15.16b, v11.16b       | V15 = tg.x;//m1                         
        val_71 = val_71;
        // 0x00BB0490: FCMP s10, #0.0             | STATE = COMPARE((val_26.z - val_27.z), 0)
        // 0x00BB0494: B.PL #0xbb0828             | if (val_73 >= 0) goto label_30;         
        if(val_73 >= 0)
        {
            goto label_30;
        }
        // 0x00BB0498: LDR s9, [sp, #8]           | S9 = tg.z;                              
        val_69 = val_69;
        // 0x00BB049C: CBNZ x21, #0xbb04a4        | if (this.circle_TargetTr != null) goto label_31;
        if(val_74 != null)
        {
            goto label_31;
        }
        // 0x00BB04A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_31:
        // 0x00BB04A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB04A8: MOV x0, x21                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB04AC: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_32 = val_74.position;
        // 0x00BB04B0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BB04B4: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BB04B8: LDR s8, [x20, #0x40]       | S8 = this.circle_Distance; //P2         
        val_77 = this.circle_Distance;
        // 0x00BB04BC: LDR s11, [sp, #0xc]        | S11 = tg.y;                             
        val_70 = val_70;
        // 0x00BB04C0: MOV v13.16b, v0.16b        | V13 = val_32.x;//m1                     
        // 0x00BB04C4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BB04C8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BB04CC: TBZ w8, #0, #0xbb04dc      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_33;
        // 0x00BB04D0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BB04D4: CBNZ w8, #0xbb04dc         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
        // 0x00BB04D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_33:
        // 0x00BB04DC: LDR s0, [x20, #0x44]       | S0 = this.circle_High; //P2             
        float val_67 = this.circle_High;
        // 0x00BB04E0: FMUL s1, s8, s8            | S1 = (this.circle_Distance * this.circle_Distance);
        float val_33 = val_77 * val_77;
        // 0x00BB04E4: FMUL s0, s0, s0            | S0 = (this.circle_High * this.circle_High);
        val_67 = val_67 * val_67;
        // 0x00BB04E8: FSUB s1, s1, s0            | S1 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));
        val_33 = val_33 - val_67;
        // 0x00BB04EC: FSQRT s0, s1               | 
        // 0x00BB04F0: FCMP s0, s0                | STATE = COMPARE((this.circle_High * this.circle_High), (this.circle_High * this.circle_High))
        // 0x00BB04F4: B.VC #0xbb0500             | if (this.circle_High < _TYPE_MAX_) goto label_34;
        if(val_67 < _TYPE_MAX_)
        {
            goto label_34;
        }
        // 0x00BB04F8: MOV v0.16b, v1.16b         | V0 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));//m1
        val_78 = val_33;
        // 0x00BB04FC: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
        label_34:
        // 0x00BB0500: FSUB s1, s12, s13          | S1 = (val_31.x - val_32.x);             
        float val_34 = val_75 - val_32.x;
        // 0x00BB0504: FDIV s0, s1, s0            | S0 = ((val_31.x - val_32.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High)));
        val_78 = val_34 / val_78;
        // 0x00BB0508: BL #0x980f90               | X0 = sub_980F90( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00BB050C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BB0510: LDR s1, [x8, #0x784]       | S1 = 57.29578;                          
        // 0x00BB0514: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BB0518: LDR s2, [x8, #0xd70]       | S2 = -90;                               
        // 0x00BB051C: FMUL s0, s0, s1            | S0 = (((val_31.x - val_32.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High))) * 57.29578f);
        val_78 = val_78 * 57.29578f;
        // 0x00BB0520: FADD s0, s0, s2            | S0 = ((((val_31.x - val_32.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High))) * 57.29578f) + -90f);
        val_78 = val_78 + (-90f);
        // 0x00BB0524: STR s0, [x20, #0x58]       | this.circle_angled = ((((val_31.x - val_32.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High))) * 57.29578f) + -90f);  //  dest_result_addr=1152921514496008984
        this.circle_angled = val_78;
        // 0x00BB0528: B #0xbb0904                |  goto label_67;                         
        goto label_67;
        label_1:
        // 0x00BB052C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0534: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_35 = UnityEngine.Camera.main;
        // 0x00BB0538: MOV x21, x0                | X21 = val_35;//m1                       
        // 0x00BB053C: CBNZ x21, #0xbb0544        | if (val_35 != null) goto label_36;      
        if(val_35 != null)
        {
            goto label_36;
        }
        // 0x00BB0540: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_36:
        // 0x00BB0544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0548: MOV x0, x21                | X0 = val_35;//m1                        
        // 0x00BB054C: BL #0x20d5094              | X0 = val_35.get_transform();            
        UnityEngine.Transform val_36 = val_35.transform;
        // 0x00BB0550: MOV x21, x0                | X21 = val_36;//m1                       
        // 0x00BB0554: CBNZ x21, #0xbb055c        | if (val_36 != null) goto label_37;      
        if(val_36 != null)
        {
            goto label_37;
        }
        // 0x00BB0558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_37:
        // 0x00BB055C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0560: MOV x0, x21                | X0 = val_36;//m1                        
        // 0x00BB0564: BL #0x2693510              | X0 = val_36.get_position();             
        UnityEngine.Vector3 val_37 = val_36.position;
        // 0x00BB0568: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BB056C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BB0570: MOV v8.16b, v0.16b         | V8 = val_37.x;//m1                      
        // 0x00BB0574: MOV v12.16b, v1.16b        | V12 = val_37.y;//m1                     
        // 0x00BB0578: MOV v10.16b, v2.16b        | V10 = val_37.z;//m1                     
        // 0x00BB057C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BB0580: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BB0584: TBZ w8, #0, #0xbb0594      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_39;
        // 0x00BB0588: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BB058C: CBNZ w8, #0xbb0594         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_39;
        // 0x00BB0590: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_39:
        // 0x00BB0594: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB059C: MOV v0.16b, v8.16b         | V0 = val_37.x;//m1                      
        // 0x00BB05A0: MOV v1.16b, v12.16b        | V1 = val_37.y;//m1                      
        // 0x00BB05A4: MOV v2.16b, v10.16b        | V2 = val_37.z;//m1                      
        // 0x00BB05A8: MOV v3.16b, v15.16b        | V3 = tg.x;//m1                          
        // 0x00BB05AC: MOV v4.16b, v11.16b        | V4 = tg.y;//m1                          
        // 0x00BB05B0: MOV v5.16b, v9.16b         | V5 = tg.z;//m1                          
        // 0x00BB05B4: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_37.x, y = val_37.y, z = val_37.z}, b:  new UnityEngine.Vector3() {x = val_71, y = val_70, z = val_69});
        float val_38 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_37.x, y = val_37.y, z = val_37.z}, b:  new UnityEngine.Vector3() {x = val_71, y = val_70, z = val_69});
        // 0x00BB05B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB05BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB05C0: STR s0, [x20, #0x40]       | this.circle_Distance = val_38;           //  dest_result_addr=1152921514496008960
        this.circle_Distance = val_38;
        // 0x00BB05C4: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_39 = UnityEngine.Camera.main;
        // 0x00BB05C8: MOV x21, x0                | X21 = val_39;//m1                       
        // 0x00BB05CC: CBNZ x21, #0xbb05d4        | if (val_39 != null) goto label_40;      
        if(val_39 != null)
        {
            goto label_40;
        }
        // 0x00BB05D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_40:
        // 0x00BB05D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB05D8: MOV x0, x21                | X0 = val_39;//m1                        
        // 0x00BB05DC: BL #0x20d5094              | X0 = val_39.get_transform();            
        UnityEngine.Transform val_40 = val_39.transform;
        // 0x00BB05E0: MOV x21, x0                | X21 = val_40;//m1                       
        // 0x00BB05E4: CBNZ x21, #0xbb05ec        | if (val_40 != null) goto label_41;      
        if(val_40 != null)
        {
            goto label_41;
        }
        // 0x00BB05E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_41:
        // 0x00BB05EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB05F0: MOV x0, x21                | X0 = val_40;//m1                        
        // 0x00BB05F4: BL #0x2693510              | X0 = val_40.get_position();             
        UnityEngine.Vector3 val_41 = val_40.position;
        // 0x00BB05F8: FSUB s0, s1, s11           | S0 = (val_41.y - tg.y);                 
        float val_42 = val_41.y - val_70;
        // 0x00BB05FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0600: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0604: STR s0, [x20, #0x44]       | this.circle_High = (val_41.y - tg.y);    //  dest_result_addr=1152921514496008964
        this.circle_High = val_42;
        // 0x00BB0608: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_43 = UnityEngine.Camera.main;
        // 0x00BB060C: MOV x21, x0                | X21 = val_43;//m1                       
        // 0x00BB0610: CBNZ x21, #0xbb0618        | if (val_43 != null) goto label_42;      
        if(val_43 != null)
        {
            goto label_42;
        }
        // 0x00BB0614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
        label_42:
        // 0x00BB0618: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB061C: MOV x0, x21                | X0 = val_43;//m1                        
        // 0x00BB0620: BL #0x20d5094              | X0 = val_43.get_transform();            
        UnityEngine.Transform val_44 = val_43.transform;
        // 0x00BB0624: MOV x21, x0                | X21 = val_44;//m1                       
        // 0x00BB0628: CBNZ x21, #0xbb0630        | if (val_44 != null) goto label_43;      
        if(val_44 != null)
        {
            goto label_43;
        }
        // 0x00BB062C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
        label_43:
        // 0x00BB0630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0634: MOV x0, x21                | X0 = val_44;//m1                        
        // 0x00BB0638: BL #0x2693510              | X0 = val_44.get_position();             
        UnityEngine.Vector3 val_45 = val_44.position;
        // 0x00BB063C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0640: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0644: MOV v12.16b, v0.16b        | V12 = val_45.x;//m1                     
        // 0x00BB0648: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_46 = UnityEngine.Camera.main;
        // 0x00BB064C: MOV x21, x0                | X21 = val_46;//m1                       
        // 0x00BB0650: CBNZ x21, #0xbb0658        | if (val_46 != null) goto label_44;      
        if(val_46 != null)
        {
            goto label_44;
        }
        // 0x00BB0654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
        label_44:
        // 0x00BB0658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB065C: MOV x0, x21                | X0 = val_46;//m1                        
        // 0x00BB0660: BL #0x20d5094              | X0 = val_46.get_transform();            
        UnityEngine.Transform val_47 = val_46.transform;
        // 0x00BB0664: MOV x21, x0                | X21 = val_47;//m1                       
        // 0x00BB0668: CBNZ x21, #0xbb0670        | if (val_47 != null) goto label_45;      
        if(val_47 != null)
        {
            goto label_45;
        }
        // 0x00BB066C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_45:
        // 0x00BB0670: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0674: MOV x0, x21                | X0 = val_47;//m1                        
        // 0x00BB0678: STR s13, [sp, #0xc]        | stack[1152921514495996764] = sp;         //  dest_result_addr=1152921514495996764
        // 0x00BB067C: BL #0x2693510              | X0 = val_47.get_position();             
        UnityEngine.Vector3 val_48 = val_47.position;
        // 0x00BB0680: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0684: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0688: MOV v13.16b, v2.16b        | V13 = val_48.z;//m1                     
        // 0x00BB068C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_49 = UnityEngine.Camera.main;
        // 0x00BB0690: MOV x21, x0                | X21 = val_49;//m1                       
        // 0x00BB0694: CBNZ x21, #0xbb069c        | if (val_49 != null) goto label_46;      
        if(val_49 != null)
        {
            goto label_46;
        }
        // 0x00BB0698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
        label_46:
        // 0x00BB069C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB06A0: MOV x0, x21                | X0 = val_49;//m1                        
        // 0x00BB06A4: FSUB s10, s12, s15         | S10 = (val_45.x - tg.x);                
        val_73 = val_45.x - val_71;
        // 0x00BB06A8: BL #0x20d5094              | X0 = val_49.get_transform();            
        UnityEngine.Transform val_50 = val_49.transform;
        // 0x00BB06AC: MOV x21, x0                | X21 = val_50;//m1                       
        val_74 = val_50;
        // 0x00BB06B0: CBNZ x21, #0xbb06b8        | if (val_50 != null) goto label_47;      
        if(val_74 != null)
        {
            goto label_47;
        }
        // 0x00BB06B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
        label_47:
        // 0x00BB06B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB06BC: MOV x0, x21                | X0 = val_50;//m1                        
        // 0x00BB06C0: FSUB s14, s13, s9          | S14 = (val_48.z - tg.z);                
        float val_51 = val_48.z - val_69;
        // 0x00BB06C4: BL #0x2693510              | X0 = val_50.get_position();             
        UnityEngine.Vector3 val_52 = val_74.position;
        // 0x00BB06C8: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BB06CC: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BB06D0: LDR s8, [x20, #0x40]       | S8 = this.circle_Distance; //P2         
        val_77 = this.circle_Distance;
        // 0x00BB06D4: MOV v12.16b, v0.16b        | V12 = val_52.x;//m1                     
        val_75 = val_52.x;
        // 0x00BB06D8: MOV v13.16b, v2.16b        | V13 = val_52.z;//m1                     
        // 0x00BB06DC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BB06E0: FCMP s10, #0.0             | STATE = COMPARE((val_45.x - tg.x), 0)   
        // 0x00BB06E4: ADD x8, x0, #0x109         | X8 = (null + 265) = 1152921504695345417 (0x1000000005466109);
        // 0x00BB06E8: LDRH w8, [x8]              | W8 = UnityEngine.Mathf.__il2cppRuntimeField_109;
        // 0x00BB06EC: AND w8, w8, #0x100         | W8 = (UnityEngine.Mathf.__il2cppRuntimeField_109 & 256);
        // 0x00BB06F0: AND w8, w8, #0xffff        | W8 = ((UnityEngine.Mathf.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00BB06F4: B.PL #0xbb07e0             | if (val_73 >= 0) goto label_48;         
        if(val_73 >= 0)
        {
            goto label_48;
        }
        // 0x00BB06F8: FCMP s14, #0.0             | STATE = COMPARE((val_48.z - tg.z), 0)   
        // 0x00BB06FC: B.PL #0xbb08b0             | if (val_51 >= 0) goto label_49;         
        if(val_51 >= 0)
        {
            goto label_49;
        }
        // 0x00BB0700: CBZ w8, #0xbb0710          | if (((UnityEngine.Mathf.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_51;
        // 0x00BB0704: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BB0708: CBNZ w8, #0xbb0710         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
        // 0x00BB070C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_51:
        // 0x00BB0710: LDR s0, [x20, #0x44]       | S0 = this.circle_High; //P2             
        float val_68 = this.circle_High;
        // 0x00BB0714: FMUL s1, s8, s8            | S1 = (this.circle_Distance * this.circle_Distance);
        float val_55 = val_77 * val_77;
        // 0x00BB0718: FMUL s0, s0, s0            | S0 = (this.circle_High * this.circle_High);
        val_68 = val_68 * val_68;
        // 0x00BB071C: FSUB s1, s1, s0            | S1 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));
        val_55 = val_55 - val_68;
        // 0x00BB0720: FSQRT s0, s1               | 
        // 0x00BB0724: FCMP s0, s0                | STATE = COMPARE((this.circle_High * this.circle_High), (this.circle_High * this.circle_High))
        // 0x00BB0728: B.VC #0xbb0734             | if (this.circle_High < _TYPE_MAX_) goto label_52;
        if(val_68 < _TYPE_MAX_)
        {
            goto label_52;
        }
        // 0x00BB072C: MOV v0.16b, v1.16b         | V0 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));//m1
        val_79 = val_55;
        // 0x00BB0730: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
        label_52:
        // 0x00BB0734: FSUB s1, s12, s15          | S1 = (val_52.x - tg.x);                 
        float val_56 = val_75 - val_71;
        // 0x00BB0738: FDIV s0, s1, s0            | S0 = ((val_52.x - tg.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High)));
        val_79 = val_56 / val_79;
        // 0x00BB073C: BL #0x980f90               | X0 = sub_980F90( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00BB0740: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BB0744: LDR s1, [x8, #0x784]       | S1 = 57.29578;                          
        // 0x00BB0748: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BB074C: LDR s2, [x8, #0xd70]       | S2 = -90;                               
        // 0x00BB0750: FMUL s0, s0, s1            | S0 = (((val_52.x - tg.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High))) * 57.29578f);
        val_79 = val_79 * 57.29578f;
        // 0x00BB0754: FADD s0, s0, s2            | S0 = ((((val_52.x - tg.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High))) * 57.29578f) + -90f);
        val_80 = val_79 + (-90f);
        // 0x00BB0758: B #0xbb08fc                |  goto label_53;                         
        goto label_53;
        label_29:
        // 0x00BB075C: MOV v14.16b, v9.16b        | V14 = sp;//m1                           
        val_76 = sp;
        // 0x00BB0760: LDR s9, [sp, #8]           | S9 = tg.z;                              
        val_69 = val_69;
        // 0x00BB0764: MOV v15.16b, v11.16b       | V15 = tg.x;//m1                         
        val_71 = val_71;
        // 0x00BB0768: FCMP s10, #0.0             | STATE = COMPARE((val_26.z - val_27.z), 0)
        // 0x00BB076C: CBNZ x21, #0xbb0774        | if (this.circle_TargetTr != null) goto label_54;
        if(val_74 != null)
        {
            goto label_54;
        }
        // 0x00BB0770: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_54:
        // 0x00BB0774: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0778: MOV x0, x21                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB077C: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_57 = val_74.position;
        // 0x00BB0780: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BB0784: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BB0788: MOV v12.16b, v2.16b        | V12 = val_57.z;//m1                     
        val_75 = val_57.z;
        // 0x00BB078C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BB0790: LDR s8, [x20, #0x40]       | S8 = this.circle_Distance; //P2         
        val_77 = this.circle_Distance;
        // 0x00BB0794: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BB0798: LDR s11, [sp, #0xc]        | S11 = sp;                               
        val_70 = sp;
        // 0x00BB079C: TBZ w8, #0, #0xbb07ac      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_56;
        // 0x00BB07A0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BB07A4: CBNZ w8, #0xbb07ac         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_56;
        // 0x00BB07A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_56:
        // 0x00BB07AC: LDR s0, [x20, #0x44]       | S0 = this.circle_High; //P2             
        float val_69 = this.circle_High;
        // 0x00BB07B0: FMUL s1, s8, s8            | S1 = (this.circle_Distance * this.circle_Distance);
        float val_58 = val_77 * val_77;
        // 0x00BB07B4: FMUL s0, s0, s0            | S0 = (this.circle_High * this.circle_High);
        val_69 = val_69 * val_69;
        // 0x00BB07B8: FSUB s1, s1, s0            | S1 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));
        val_58 = val_58 - val_69;
        // 0x00BB07BC: FSQRT s0, s1               | 
        // 0x00BB07C0: FCMP s0, s0                | STATE = COMPARE((this.circle_High * this.circle_High), (this.circle_High * this.circle_High))
        // 0x00BB07C4: B.VC #0xbb07d0             | if (this.circle_High < _TYPE_MAX_) goto label_57;
        if(val_69 < _TYPE_MAX_)
        {
            goto label_57;
        }
        // 0x00BB07C8: MOV v0.16b, v1.16b         | V0 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));//m1
        val_81 = val_58;
        // 0x00BB07CC: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
        label_57:
        // 0x00BB07D0: FSUB s1, s13, s12          | S1 = (val_31.z - val_57.z);             
        float val_59 = val_31.z - val_75;
        // 0x00BB07D4: FDIV s0, s1, s0            | S0 = ((val_31.z - val_57.z) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High)));
        val_82 = val_59 / val_81;
        // 0x00BB07D8: BL #0x980f90               | X0 = sub_980F90( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00BB07DC: B #0xbb089c                |  goto label_58;                         
        goto label_58;
        label_48:
        // 0x00BB07E0: FCMP s14, #0.0             | STATE = COMPARE((val_48.z - tg.z), 0)   
        // 0x00BB07E4: CBZ w8, #0xbb07f4          | if (((UnityEngine.Mathf.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_60;
        // 0x00BB07E8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BB07EC: CBNZ w8, #0xbb07f4         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
        // 0x00BB07F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_60:
        // 0x00BB07F4: LDR s0, [x20, #0x44]       | S0 = this.circle_High; //P2             
        float val_70 = this.circle_High;
        // 0x00BB07F8: FMUL s1, s8, s8            | S1 = (this.circle_Distance * this.circle_Distance);
        float val_60 = val_77 * val_77;
        // 0x00BB07FC: FMUL s0, s0, s0            | S0 = (this.circle_High * this.circle_High);
        val_70 = val_70 * val_70;
        // 0x00BB0800: FSUB s1, s1, s0            | S1 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));
        val_60 = val_60 - val_70;
        // 0x00BB0804: FSQRT s0, s1               | 
        // 0x00BB0808: FCMP s0, s0                | STATE = COMPARE((this.circle_High * this.circle_High), (this.circle_High * this.circle_High))
        // 0x00BB080C: B.VC #0xbb0818             | if (this.circle_High < _TYPE_MAX_) goto label_61;
        if(val_70 < _TYPE_MAX_)
        {
            goto label_61;
        }
        // 0x00BB0810: MOV v0.16b, v1.16b         | V0 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));//m1
        val_83 = val_60;
        // 0x00BB0814: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
        label_61:
        // 0x00BB0818: FSUB s1, s13, s9           | S1 = (val_52.z - tg.z);                 
        float val_61 = val_52.z - val_69;
        // 0x00BB081C: FDIV s0, s1, s0            | S0 = ((val_52.z - tg.z) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High)));
        val_84 = val_61 / val_83;
        // 0x00BB0820: BL #0x980f90               | X0 = sub_980F90( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00BB0824: B #0xbb08f0                |  goto label_62;                         
        goto label_62;
        label_30:
        // 0x00BB0828: LDR s9, [sp, #8]           | S9 = tg.z;                              
        val_69 = val_69;
        // 0x00BB082C: CBNZ x21, #0xbb0834        | if (this.circle_TargetTr != null) goto label_63;
        if(val_74 != null)
        {
            goto label_63;
        }
        // 0x00BB0830: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_63:
        // 0x00BB0834: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0838: MOV x0, x21                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB083C: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_62 = val_74.position;
        // 0x00BB0840: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BB0844: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BB0848: LDR s8, [x20, #0x40]       | S8 = this.circle_Distance; //P2         
        val_77 = this.circle_Distance;
        // 0x00BB084C: LDR s11, [sp, #0xc]        | S11 = sp;                               
        val_70 = sp;
        // 0x00BB0850: MOV v13.16b, v0.16b        | V13 = val_62.x;//m1                     
        // 0x00BB0854: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BB0858: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BB085C: TBZ w8, #0, #0xbb086c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_65;
        // 0x00BB0860: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BB0864: CBNZ w8, #0xbb086c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
        // 0x00BB0868: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_65:
        // 0x00BB086C: LDR s0, [x20, #0x44]       | S0 = this.circle_High; //P2             
        float val_71 = this.circle_High;
        // 0x00BB0870: FMUL s1, s8, s8            | S1 = (this.circle_Distance * this.circle_Distance);
        float val_63 = val_77 * val_77;
        // 0x00BB0874: FMUL s0, s0, s0            | S0 = (this.circle_High * this.circle_High);
        val_71 = val_71 * val_71;
        // 0x00BB0878: FSUB s1, s1, s0            | S1 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));
        val_63 = val_63 - val_71;
        // 0x00BB087C: FSQRT s0, s1               | 
        // 0x00BB0880: FCMP s0, s0                | STATE = COMPARE((this.circle_High * this.circle_High), (this.circle_High * this.circle_High))
        // 0x00BB0884: B.VC #0xbb0890             | if (this.circle_High < _TYPE_MAX_) goto label_66;
        if(val_71 < _TYPE_MAX_)
        {
            goto label_66;
        }
        // 0x00BB0888: MOV v0.16b, v1.16b         | V0 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));//m1
        val_85 = val_63;
        // 0x00BB088C: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
        label_66:
        // 0x00BB0890: FSUB s1, s12, s13          | S1 = (val_31.x - val_62.x);             
        float val_64 = val_75 - val_62.x;
        // 0x00BB0894: FDIV s0, s1, s0            | S0 = ((val_31.x - val_62.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High)));
        val_82 = val_64 / val_85;
        // 0x00BB0898: BL #0x980f40               | X0 = sub_980F40( ?? typeof(UnityEngine.Mathf), ????);
        label_58:
        // 0x00BB089C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BB08A0: LDR s1, [x8, #0x784]       | S1 = 57.29578;                          
        // 0x00BB08A4: FMUL s0, s0, s1            | S0 = (((val_31.x - val_62.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High))) * 57.29578f);
        val_82 = val_82 * 57.29578f;
        // 0x00BB08A8: STR s0, [x20, #0x58]       | this.circle_angled = (((val_31.x - val_62.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High))) * 57.29578f);  //  dest_result_addr=1152921514496008984
        this.circle_angled = val_82;
        // 0x00BB08AC: B #0xbb0904                |  goto label_67;                         
        goto label_67;
        label_49:
        // 0x00BB08B0: CBZ w8, #0xbb08c0          | if (((UnityEngine.Mathf.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_69;
        // 0x00BB08B4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BB08B8: CBNZ w8, #0xbb08c0         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
        // 0x00BB08BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_69:
        // 0x00BB08C0: LDR s0, [x20, #0x44]       | S0 = this.circle_High; //P2             
        float val_72 = this.circle_High;
        // 0x00BB08C4: FMUL s1, s8, s8            | S1 = (this.circle_Distance * this.circle_Distance);
        float val_65 = val_77 * val_77;
        // 0x00BB08C8: FMUL s0, s0, s0            | S0 = (this.circle_High * this.circle_High);
        val_72 = val_72 * val_72;
        // 0x00BB08CC: FSUB s1, s1, s0            | S1 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));
        val_65 = val_65 - val_72;
        // 0x00BB08D0: FSQRT s0, s1               | 
        // 0x00BB08D4: FCMP s0, s0                | STATE = COMPARE((this.circle_High * this.circle_High), (this.circle_High * this.circle_High))
        // 0x00BB08D8: B.VC #0xbb08e4             | if (this.circle_High < _TYPE_MAX_) goto label_70;
        if(val_72 < _TYPE_MAX_)
        {
            goto label_70;
        }
        // 0x00BB08DC: MOV v0.16b, v1.16b         | V0 = ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High));//m1
        val_86 = val_65;
        // 0x00BB08E0: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
        label_70:
        // 0x00BB08E4: FSUB s1, s12, s15          | S1 = (val_52.x - tg.x);                 
        float val_66 = val_75 - val_71;
        // 0x00BB08E8: FDIV s0, s1, s0            | S0 = ((val_52.x - tg.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High)));
        val_84 = val_66 / val_86;
        // 0x00BB08EC: BL #0x980f40               | X0 = sub_980F40( ?? typeof(UnityEngine.Mathf), ????);
        label_62:
        // 0x00BB08F0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BB08F4: LDR s1, [x8, #0x784]       | S1 = 57.29578;                          
        // 0x00BB08F8: FMUL s0, s0, s1            | S0 = (((val_52.x - tg.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High))) * 57.29578f);
        val_80 = val_84 * 57.29578f;
        label_53:
        // 0x00BB08FC: STR s0, [x20, #0x58]       | this.circle_angled = (((val_52.x - tg.x) / ((this.circle_Distance * this.circle_Distance) - (this.circle_High * this.circle_High))) * 57.29578f);  //  dest_result_addr=1152921514496008984
        this.circle_angled = val_80;
        // 0x00BB0900: LDR s14, [sp, #0xc]        | S14 = sp;                               
        val_76 = sp;
        label_67:
        // 0x00BB0904: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BB0908: STP s15, s11, [x20, #0x30] | this.circle_TargetPos = tg;  mem[1152921514496008948] = tg.y;  //  dest_result_addr=1152921514496008944 |  dest_result_addr=1152921514496008948
        this.circle_TargetPos = tg;
        mem[1152921514496008948] = val_70;
        // 0x00BB090C: STP s9, s14, [x20, #0x38]  | mem[1152921514496008952] = tg.z;  this.circle_Speed = sp;  //  dest_result_addr=1152921514496008952 |  dest_result_addr=1152921514496008956
        mem[1152921514496008952] = val_69;
        this.circle_Speed = val_76;
        // 0x00BB0910: STR w19, [x20, #0x6c]      | this.isRight = isRight;                  //  dest_result_addr=1152921514496009004
        this.isRight = isRight;
        // 0x00BB0914: STRB w8, [x20, #0x22]      | this.isCircleCameraMoving = true;        //  dest_result_addr=1152921514496008930
        this.isCircleCameraMoving = true;
        // 0x00BB0918: SUB sp, x29, #0x70         | SP = (1152921514495996880 - 112) = 1152921514495996768 (0x100000024D707360);
        // 0x00BB091C: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00BB0920: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00BB0924: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00BB0928: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00BB092C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BB0930: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BB0934: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BB0938: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00BB093C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BB0940 (12257600), len: 580  VirtAddr: 0x00BB0940 RVA: 0x00BB0940 token: 100690258 methodIndex: 25791 delegateWrapperIndex: 0 methodInvoker: 0
    public void circleAction_Effect(int id, float sp, float dt, float hg, float sa, int isRight)
    {
        //
        // Disasemble & Code
        // 0x00BB0940: STP d15, d14, [sp, #-0x70]! | stack[1152921514496264432] = ???;  stack[1152921514496264440] = ???;  //  dest_result_addr=1152921514496264432 |  dest_result_addr=1152921514496264440
        // 0x00BB0944: STP d13, d12, [sp, #0x10]  | stack[1152921514496264448] = ???;  stack[1152921514496264456] = ???;  //  dest_result_addr=1152921514496264448 |  dest_result_addr=1152921514496264456
        // 0x00BB0948: STP d11, d10, [sp, #0x20]  | stack[1152921514496264464] = ???;  stack[1152921514496264472] = ???;  //  dest_result_addr=1152921514496264464 |  dest_result_addr=1152921514496264472
        // 0x00BB094C: STP d9, d8, [sp, #0x30]    | stack[1152921514496264480] = ???;  stack[1152921514496264488] = ???;  //  dest_result_addr=1152921514496264480 |  dest_result_addr=1152921514496264488
        // 0x00BB0950: STP x22, x21, [sp, #0x40]  | stack[1152921514496264496] = ???;  stack[1152921514496264504] = ???;  //  dest_result_addr=1152921514496264496 |  dest_result_addr=1152921514496264504
        // 0x00BB0954: STP x20, x19, [sp, #0x50]  | stack[1152921514496264512] = ???;  stack[1152921514496264520] = ???;  //  dest_result_addr=1152921514496264512 |  dest_result_addr=1152921514496264520
        // 0x00BB0958: STP x29, x30, [sp, #0x60]  | stack[1152921514496264528] = ???;  stack[1152921514496264536] = ???;  //  dest_result_addr=1152921514496264528 |  dest_result_addr=1152921514496264536
        // 0x00BB095C: ADD x29, sp, #0x60         | X29 = (1152921514496264432 + 96) = 1152921514496264528 (0x100000024D748950);
        // 0x00BB0960: SUB sp, sp, #0x20          | SP = (1152921514496264432 - 32) = 1152921514496264400 (0x100000024D7488D0);
        // 0x00BB0964: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00BB0968: LDRB w8, [x22, #0xb15]     | W8 = (bool)static_value_03733B15;       
        // 0x00BB096C: MOV w19, w2                | W19 = isRight;//m1                      
        // 0x00BB0970: MOV v8.16b, v3.16b         | V8 = sa;//m1                            
        // 0x00BB0974: MOV v9.16b, v2.16b         | V9 = hg;//m1                            
        // 0x00BB0978: MOV v10.16b, v1.16b        | V10 = dt;//m1                           
        // 0x00BB097C: MOV w21, w1                | W21 = id;//m1                           
        // 0x00BB0980: MOV x20, x0                | X20 = 1152921514496276544 (0x100000024D74B840);//ML01
        // 0x00BB0984: STR s0, [sp, #0xc]         | stack[1152921514496264412] = sp;         //  dest_result_addr=1152921514496264412
        // 0x00BB0988: TBNZ w8, #0, #0xbb09a4     | if (static_value_03733B15 == true) goto label_0;
        // 0x00BB098C: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00BB0990: LDR x8, [x8, #0xc78]       | X8 = 0x2B9027C;                         
        // 0x00BB0994: LDR w0, [x8]               | W0 = 0x1763;                            
        // 0x00BB0998: BL #0x2782188              | X0 = sub_2782188( ?? 0x1763, ????);     
        // 0x00BB099C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BB09A0: STRB w8, [x22, #0xb15]     | static_value_03733B15 = true;            //  dest_result_addr=57883413
        label_0:
        // 0x00BB09A4: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BB09A8: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00BB09AC: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00BB09B0: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BB09B4: TBZ w8, #0, #0xbb09c4      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BB09B8: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BB09BC: CBNZ w8, #0xbb09c4         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BB09C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00BB09C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB09C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB09CC: BL #0x26a87d0              | X0 = ZMG.get_CameraShotMgr();           
        CameraShotMgr val_1 = ZMG.CameraShotMgr;
        // 0x00BB09D0: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00BB09D4: CBNZ x22, #0xbb09dc        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00BB09D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00BB09DC: LDR x22, [x22, #0x78]      | X22 = val_1.effectDic; //P2             
        // 0x00BB09E0: CBNZ x22, #0xbb09e8        | if (val_1.effectDic != null) goto label_4;
        if(val_1.effectDic != null)
        {
            goto label_4;
        }
        // 0x00BB09E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00BB09E8: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00BB09EC: LDR x8, [x8, #0x408]       | X8 = 1152921510772786640;               
        // 0x00BB09F0: MOV x0, x22                | X0 = val_1.effectDic;//m1               
        // 0x00BB09F4: MOV w1, w21                | W1 = id;//m1                            
        // 0x00BB09F8: LDR x2, [x8]               | X2 = public UnityEngine.GameObject System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::get_Item(System.Int32 key);
        // 0x00BB09FC: BL #0x24144f0              | X0 = val_1.effectDic.get_Item(key:  id);
        UnityEngine.GameObject val_2 = val_1.effectDic.Item[id];
        // 0x00BB0A00: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00BB0A04: CBNZ x21, #0xbb0a0c        | if (val_2 != null) goto label_5;        
        if(val_2 != null)
        {
            goto label_5;
        }
        // 0x00BB0A08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00BB0A0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0A10: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00BB0A14: BL #0x1a62c1c              | X0 = val_2.get_transform();             
        UnityEngine.Transform val_3 = val_2.transform;
        // 0x00BB0A18: STR x0, [x20, #0x28]       | this.circle_TargetTr = val_3;            //  dest_result_addr=1152921514496276584
        this.circle_TargetTr = val_3;
        // 0x00BB0A1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0A20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0A24: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_4 = UnityEngine.Camera.main;
        // 0x00BB0A28: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00BB0A2C: CBNZ x21, #0xbb0a34        | if (val_4 != null) goto label_6;        
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00BB0A30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x00BB0A34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0A38: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00BB0A3C: BL #0x20d5094              | X0 = val_4.get_transform();             
        UnityEngine.Transform val_5 = val_4.transform;
        // 0x00BB0A40: LDR x22, [x20, #0x28]      | X22 = this.circle_TargetTr; //P2        
        // 0x00BB0A44: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00BB0A48: CBNZ x22, #0xbb0a50        | if (this.circle_TargetTr != null) goto label_7;
        if(this.circle_TargetTr != null)
        {
            goto label_7;
        }
        // 0x00BB0A4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00BB0A50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0A54: MOV x0, x22                | X0 = this.circle_TargetTr;//m1          
        // 0x00BB0A58: BL #0x2693510              | X0 = this.circle_TargetTr.get_position();
        UnityEngine.Vector3 val_6 = this.circle_TargetTr.position;
        // 0x00BB0A5C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BB0A60: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BB0A64: MOV v12.16b, v0.16b        | V12 = val_6.x;//m1                      
        // 0x00BB0A68: MOV v13.16b, v1.16b        | V13 = val_6.y;//m1                      
        // 0x00BB0A6C: MOV v14.16b, v2.16b        | V14 = val_6.z;//m1                      
        // 0x00BB0A70: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BB0A74: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BB0A78: TBZ w8, #0, #0xbb0a88      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00BB0A7C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BB0A80: CBNZ w8, #0xbb0a88         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00BB0A84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_9:
        // 0x00BB0A88: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BB0A8C: LDR s0, [x8, #0x7b8]       | S0 = 180;                               
        float val_10 = 180f;
        // 0x00BB0A90: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BB0A94: LDR s1, [x8, #0xd6c]       | S1 = 3.141593;                          
        float val_11 = 3.141593f;
        // 0x00BB0A98: FDIV s0, s8, s0            | S0 = (sa / 180f);                       
        val_10 = sa / val_10;
        // 0x00BB0A9C: FMUL s15, s0, s1           | S15 = ((sa / 180f) * 3.141593f);        
        float val_7 = val_10 * val_11;
        // 0x00BB0AA0: MOV v0.16b, v15.16b        | V0 = ((sa / 180f) * 3.141593f);//m1     
        // 0x00BB0AA4: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00BB0AA8: MOV v11.16b, v0.16b        | V11 = ((sa / 180f) * 3.141593f);//m1    
        // 0x00BB0AAC: MOV v0.16b, v15.16b        | V0 = ((sa / 180f) * 3.141593f);//m1     
        // 0x00BB0AB0: BL #0x981480               | X0 = sub_981480( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00BB0AB4: FMUL s1, s11, s10          | S1 = (((sa / 180f) * 3.141593f) * dt);  
        val_11 = val_7 * dt;
        // 0x00BB0AB8: FMUL s2, s0, s10           | S2 = (((sa / 180f) * 3.141593f) * dt);  
        float val_8 = val_7 * dt;
        // 0x00BB0ABC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0AC0: ADD x0, sp, #0x10          | X0 = (1152921514496264400 + 16) = 1152921514496264416 (0x100000024D7488E0);
        // 0x00BB0AC4: MOV v0.16b, v1.16b         | V0 = (((sa / 180f) * 3.141593f) * dt);//m1
        // 0x00BB0AC8: MOV v1.16b, v9.16b         | V1 = hg;//m1                            
        // 0x00BB0ACC: STR wzr, [sp, #0x18]       | stack[1152921514496264424] = 0x0;        //  dest_result_addr=1152921514496264424
        // 0x00BB0AD0: STR xzr, [sp, #0x10]       | stack[1152921514496264416] = 0x0;        //  dest_result_addr=1152921514496264416
        // 0x00BB0AD4: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00BB0AD8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BB0ADC: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BB0AE0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BB0AE4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BB0AE8: TBZ w8, #0, #0xbb0af8      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00BB0AEC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BB0AF0: CBNZ w8, #0xbb0af8         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00BB0AF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_11:
        // 0x00BB0AF8: LDP s3, s4, [sp, #0x10]    | S3 = 0; S4 = 0;                          //  | 
        // 0x00BB0AFC: LDR s5, [sp, #0x18]        | S5 = 0;                                 
        // 0x00BB0B00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0B04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0B08: MOV v0.16b, v12.16b        | V0 = val_6.x;//m1                       
        // 0x00BB0B0C: MOV v1.16b, v13.16b        | V1 = val_6.y;//m1                       
        // 0x00BB0B10: MOV v2.16b, v14.16b        | V2 = val_6.z;//m1                       
        // 0x00BB0B14: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_9 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00BB0B18: MOV v12.16b, v0.16b        | V12 = val_9.x;//m1                      
        // 0x00BB0B1C: MOV v13.16b, v1.16b        | V13 = val_9.y;//m1                      
        // 0x00BB0B20: MOV v14.16b, v2.16b        | V14 = val_9.z;//m1                      
        // 0x00BB0B24: CBNZ x21, #0xbb0b2c        | if (val_5 != null) goto label_12;       
        if(val_5 != null)
        {
            goto label_12;
        }
        // 0x00BB0B28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_12:
        // 0x00BB0B2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0B30: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00BB0B34: MOV v0.16b, v12.16b        | V0 = val_9.x;//m1                       
        // 0x00BB0B38: MOV v1.16b, v13.16b        | V1 = val_9.y;//m1                       
        // 0x00BB0B3C: MOV v2.16b, v14.16b        | V2 = val_9.z;//m1                       
        // 0x00BB0B40: BL #0x26935b8              | val_5.set_position(value:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
        val_5.position = new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z};
        // 0x00BB0B44: LDR s0, [sp, #0xc]         | S0 = sp;                                
        // 0x00BB0B48: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BB0B4C: STR s8, [x20, #0x58]       | this.circle_angled = sa;                 //  dest_result_addr=1152921514496276632
        this.circle_angled = sa;
        // 0x00BB0B50: STP s0, s10, [x20, #0x3c]  | this.circle_Speed = sp;  this.circle_Distance = dt;  //  dest_result_addr=1152921514496276604 |  dest_result_addr=1152921514496276608
        this.circle_Speed = sp;
        this.circle_Distance = dt;
        // 0x00BB0B54: STR w19, [x20, #0x6c]      | this.isRight = isRight;                  //  dest_result_addr=1152921514496276652
        this.isRight = isRight;
        // 0x00BB0B58: STR s9, [x20, #0x44]       | this.circle_High = hg;                   //  dest_result_addr=1152921514496276612
        this.circle_High = hg;
        // 0x00BB0B5C: STRB w8, [x20, #0x22]      | this.isCircleCameraMoving = true;        //  dest_result_addr=1152921514496276578
        this.isCircleCameraMoving = true;
        // 0x00BB0B60: SUB sp, x29, #0x60         | SP = (1152921514496264528 - 96) = 1152921514496264432 (0x100000024D7488F0);
        // 0x00BB0B64: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00BB0B68: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00BB0B6C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00BB0B70: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BB0B74: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BB0B78: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BB0B7C: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00BB0B80: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BB0B84 (12258180), len: 1684  VirtAddr: 0x00BB0B84 RVA: 0x00BB0B84 token: 100690259 methodIndex: 25792 delegateWrapperIndex: 0 methodInvoker: 0
    public void Preview(UnityEngine.Vector3[] points, UnityEngine.Vector3[] rots, float[] speeds, int[] focusIds, int[] isHeros, float[] smooths, float[] views, float[] rotSpeed, int[] isClockWise, float[] orthographics, int id, int[] isConstants)
    {
        //
        // Disasemble & Code
        //  | 
        var val_18;
        //  | 
        UnityEngine.GameObject val_19;
        // 0x00BB0B84: STP d9, d8, [sp, #-0x70]!  | stack[1152921514496943728] = ???;  stack[1152921514496943736] = ???;  //  dest_result_addr=1152921514496943728 |  dest_result_addr=1152921514496943736
        // 0x00BB0B88: STP x28, x27, [sp, #0x10]  | stack[1152921514496943744] = ???;  stack[1152921514496943752] = ???;  //  dest_result_addr=1152921514496943744 |  dest_result_addr=1152921514496943752
        // 0x00BB0B8C: STP x26, x25, [sp, #0x20]  | stack[1152921514496943760] = ???;  stack[1152921514496943768] = ???;  //  dest_result_addr=1152921514496943760 |  dest_result_addr=1152921514496943768
        // 0x00BB0B90: STP x24, x23, [sp, #0x30]  | stack[1152921514496943776] = ???;  stack[1152921514496943784] = ???;  //  dest_result_addr=1152921514496943776 |  dest_result_addr=1152921514496943784
        // 0x00BB0B94: STP x22, x21, [sp, #0x40]  | stack[1152921514496943792] = ???;  stack[1152921514496943800] = ???;  //  dest_result_addr=1152921514496943792 |  dest_result_addr=1152921514496943800
        // 0x00BB0B98: STP x20, x19, [sp, #0x50]  | stack[1152921514496943808] = ???;  stack[1152921514496943816] = ???;  //  dest_result_addr=1152921514496943808 |  dest_result_addr=1152921514496943816
        // 0x00BB0B9C: STP x29, x30, [sp, #0x60]  | stack[1152921514496943824] = ???;  stack[1152921514496943832] = ???;  //  dest_result_addr=1152921514496943824 |  dest_result_addr=1152921514496943832
        // 0x00BB0BA0: ADD x29, sp, #0x60         | X29 = (1152921514496943728 + 96) = 1152921514496943824 (0x100000024D7EE6D0);
        // 0x00BB0BA4: SUB sp, sp, #0x40          | SP = (1152921514496943728 - 64) = 1152921514496943664 (0x100000024D7EE630);
        // 0x00BB0BA8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BB0BAC: LDRB w8, [x19, #0xb16]     | W8 = (bool)static_value_03733B16;       
        // 0x00BB0BB0: MOV x23, x7                | X23 = views;//m1                        
        // 0x00BB0BB4: MOV x21, x5                | X21 = isHeros;//m1                      
        // 0x00BB0BB8: MOV x22, x4                | X22 = focusIds;//m1                     
        // 0x00BB0BBC: MOV x26, x1                | X26 = points;//m1                       
        // 0x00BB0BC0: MOV x24, x0                | X24 = 1152921514496955840 (0x100000024D7F15C0);//ML01
        // 0x00BB0BC4: STR x6, [sp, #0x30]        | stack[1152921514496943712] = smooths;    //  dest_result_addr=1152921514496943712
        // 0x00BB0BC8: STP x2, x3, [sp, #0x20]    | stack[1152921514496943696] = rots;  stack[1152921514496943704] = speeds;  //  dest_result_addr=1152921514496943696 |  dest_result_addr=1152921514496943704
        // 0x00BB0BCC: TBNZ w8, #0, #0xbb0be8     | if (static_value_03733B16 == true) goto label_0;
        // 0x00BB0BD0: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00BB0BD4: LDR x8, [x8, #0xf58]       | X8 = 0x2B90294;                         
        // 0x00BB0BD8: LDR w0, [x8]               | W0 = 0x1769;                            
        // 0x00BB0BDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1769, ????);     
        // 0x00BB0BE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BB0BE4: STRB w8, [x19, #0xb16]     | static_value_03733B16 = true;            //  dest_result_addr=57883414
        label_0:
        // 0x00BB0BE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0BEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0BF0: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_1 = UnityEngine.Camera.main;
        // 0x00BB0BF4: MOV x27, x0                | X27 = val_1;//m1                        
        // 0x00BB0BF8: CBNZ x27, #0xbb0c00        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00BB0BFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00BB0C00: ADRP x19, #0x35db000       | X19 = 56471552 (0x35DB000);             
        // 0x00BB0C04: LDR x19, [x19, #0x828]     | X19 = 1152921514496802816;              
        // 0x00BB0C08: MOV x0, x27                | X0 = val_1;//m1                         
        // 0x00BB0C0C: LDR x1, [x19]              | X1 = public CameraBezier UnityEngine.Component::GetComponent<CameraBezier>();
        // 0x00BB0C10: BL #0x23d5410              | X0 = val_1.GetComponent<CameraBezier>();
        CameraBezier val_2 = val_1.GetComponent<CameraBezier>();
        // 0x00BB0C14: MOV x27, x0                | X27 = val_2;//m1                        
        // 0x00BB0C18: STR x27, [x24, #0x18]      | this.cameraBezier = val_2;               //  dest_result_addr=1152921514496955864
        this.cameraBezier = val_2;
        // 0x00BB0C1C: ADRP x20, #0x35fe000       | X20 = 56614912 (0x35FE000);             
        // 0x00BB0C20: LDR x20, [x20, #0x810]     | X20 = 1152921504697475072;              
        // 0x00BB0C24: LDR x0, [x20]              | X0 = typeof(UnityEngine.Object);        
        // 0x00BB0C28: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BB0C2C: TBZ w8, #0, #0xbb0c3c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00BB0C30: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BB0C34: CBNZ w8, #0xbb0c3c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00BB0C38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00BB0C3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0C40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BB0C44: MOV x1, x27                | X1 = val_2;//m1                         
        // 0x00BB0C48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BB0C4C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_2);
        bool val_3 = UnityEngine.Object.op_Inequality(x:  0, y:  val_2);
        // 0x00BB0C50: TBZ w0, #0, #0xbb0ca8      | if (val_3 == false) goto label_4;       
        if(val_3 == false)
        {
            goto label_4;
        }
        // 0x00BB0C54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0C58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0C5C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_4 = UnityEngine.Camera.main;
        // 0x00BB0C60: MOV x27, x0                | X27 = val_4;//m1                        
        // 0x00BB0C64: CBNZ x27, #0xbb0c6c        | if (val_4 != null) goto label_5;        
        if(val_4 != null)
        {
            goto label_5;
        }
        // 0x00BB0C68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_5:
        // 0x00BB0C6C: LDR x1, [x19]              | X1 = public CameraBezier UnityEngine.Component::GetComponent<CameraBezier>();
        // 0x00BB0C70: MOV x0, x27                | X0 = val_4;//m1                         
        // 0x00BB0C74: BL #0x23d5410              | X0 = val_4.GetComponent<CameraBezier>();
        CameraBezier val_5 = val_4.GetComponent<CameraBezier>();
        // 0x00BB0C78: LDR x8, [x20]              | X8 = typeof(UnityEngine.Object);        
        // 0x00BB0C7C: MOV x27, x0                | X27 = val_5;//m1                        
        // 0x00BB0C80: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BB0C84: TBZ w9, #0, #0xbb0c98      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00BB0C88: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BB0C8C: CBNZ w9, #0xbb0c98         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00BB0C90: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00BB0C94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_7:
        // 0x00BB0C98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0C9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BB0CA0: MOV x1, x27                | X1 = val_5;//m1                         
        // 0x00BB0CA4: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        label_4:
        // 0x00BB0CA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BB0CAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0CB0: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_6 = UnityEngine.Camera.main;
        // 0x00BB0CB4: MOV x27, x0                | X27 = val_6;//m1                        
        // 0x00BB0CB8: CBNZ x27, #0xbb0cc0        | if (val_6 != null) goto label_8;        
        if(val_6 != null)
        {
            goto label_8;
        }
        // 0x00BB0CBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_8:
        // 0x00BB0CC0: LDR x8, [x29, #0x30]       | X8 = isConstants;                       
        // 0x00BB0CC4: LDR x25, [x29, #0x10]      | X25 = rotSpeed;                         
        // 0x00BB0CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0CCC: MOV x0, x27                | X0 = val_6;//m1                         
        // 0x00BB0CD0: STR x8, [sp, #0x18]        | stack[1152921514496943688] = isConstants;  //  dest_result_addr=1152921514496943688
        // 0x00BB0CD4: LDR x8, [x29, #0x20]       | X8 = orthographics;                     
        // 0x00BB0CD8: STR x23, [sp, #0x38]       | stack[1152921514496943720] = views;      //  dest_result_addr=1152921514496943720
        // 0x00BB0CDC: STR x8, [sp, #0x10]        | stack[1152921514496943680] = orthographics;  //  dest_result_addr=1152921514496943680
        // 0x00BB0CE0: LDR x8, [x29, #0x18]       | X8 = isClockWise;                       
        // 0x00BB0CE4: STR x8, [sp, #8]           | stack[1152921514496943672] = isClockWise;  //  dest_result_addr=1152921514496943672
        // 0x00BB0CE8: BL #0x20d50fc              | X0 = val_6.get_gameObject();            
        UnityEngine.GameObject val_7 = val_6.gameObject;
        // 0x00BB0CEC: MOV x27, x0                | X27 = val_7;//m1                        
        // 0x00BB0CF0: CBNZ x27, #0xbb0cf8        | if (val_7 != null) goto label_9;        
        if(val_7 != null)
        {
            goto label_9;
        }
        // 0x00BB0CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00BB0CF8: LDR w8, [x29, #0x28]       | W8 = id;                                
        // 0x00BB0CFC: MOV x0, x27                | X0 = val_7;//m1                         
        // 0x00BB0D00: STR w8, [sp, #4]           | stack[1152921514496943668] = id;         //  dest_result_addr=1152921514496943668
        // 0x00BB0D04: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00BB0D08: LDR x8, [x8, #0xa80]       | X8 = 1152921514496824320;               
        // 0x00BB0D0C: LDR x1, [x8]               | X1 = public CameraBezier UnityEngine.GameObject::AddComponent<CameraBezier>();
        // 0x00BB0D10: BL #0x23d5984              | X0 = val_7.AddComponent<CameraBezier>();
        CameraBezier val_8 = val_7.AddComponent<CameraBezier>();
        // 0x00BB0D14: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
        val_18 = 0;
        // 0x00BB0D18: STR x0, [x24, #0x18]       | this.cameraBezier = val_8;               //  dest_result_addr=1152921514496955864
        this.cameraBezier = val_8;
        // 0x00BB0D1C: B #0xbb0d3c                |  goto label_10;                         
        goto label_10;
        label_66:
        // 0x00BB0D20: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00BB0D24: LDR x8, [x8, #0x390]       | X8 = 1152921510015558192;               
        // 0x00BB0D28: MOV x0, x27                | X0 = val_7;//m1                         
        // 0x00BB0D2C: MOV w1, w28                | W1 = W28;//m1                           
        // 0x00BB0D30: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.Int32>::Add(System.Int32 item);
        // 0x00BB0D34: BL #0x25e1b34              | val_7.Add(item:  W28);                  
        val_7.Add(item:  W28);
        // 0x00BB0D38: ADD w19, w19, #1           | W19 = (val_18 + 1) = val_18 (0x00000001);
        val_18 = 1;
        label_10:
        // 0x00BB0D3C: CBNZ x26, #0xbb0d44        | if (points != null) goto label_11;      
        if(points != null)
        {
            goto label_11;
        }
        // 0x00BB0D40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_11:
        // 0x00BB0D44: LDR w8, [x26, #0x18]       | W8 = points.Length; //P2                
        // 0x00BB0D48: CMP w19, w8                | STATE = COMPARE(0x1, points.Length)     
        // 0x00BB0D4C: B.GE #0xbb11e0             | if (val_18 >= points.Length) goto label_12;
        if(val_18 >= points.Length)
        {
            goto label_12;
        }
        // 0x00BB0D50: CBNZ x22, #0xbb0d58        | if (focusIds != null) goto label_13;    
        if(focusIds != null)
        {
            goto label_13;
        }
        // 0x00BB0D54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_13:
        // 0x00BB0D58: LDR w8, [x22, #0x18]       | W8 = focusIds.Length; //P2              
        // 0x00BB0D5C: SXTW x20, w19              | X20 = 1 (0x00000001);                   
        // 0x00BB0D60: CMP w19, w8                | STATE = COMPARE(0x1, focusIds.Length)   
        // 0x00BB0D64: B.LO #0xbb0d74             | if (val_18 < focusIds.Length) goto label_14;
        if(val_18 < focusIds.Length)
        {
            goto label_14;
        }
        // 0x00BB0D68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
        // 0x00BB0D6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0D70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        label_14:
        // 0x00BB0D74: ADD x28, x22, x20, lsl #2  | X28 = focusIds[0x1]; //PARR1            
        // 0x00BB0D78: LDR w8, [x28, #0x20]!      | W8 = focusIds[0x1][0]                   
        int val_18 = focusIds[1];
        // 0x00BB0D7C: CMN w8, #1                 | STATE = COMPARE(focusIds[0x1][0], 0x1)  
        // 0x00BB0D80: B.EQ #0xbb0e30             | if (focusIds[1] == 1) goto label_15;    
        if(val_18 == 1)
        {
            goto label_15;
        }
        // 0x00BB0D84: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BB0D88: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00BB0D8C: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00BB0D90: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00BB0D94: LDR x27, [x8]              | X27 = GameMgr.UPDATEOnOffEffect;        
        // 0x00BB0D98: CBNZ x21, #0xbb0da0        | if (isHeros != null) goto label_16;     
        if(isHeros != null)
        {
            goto label_16;
        }
        // 0x00BB0D9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_16:
        // 0x00BB0DA0: LDR w8, [x21, #0x18]       | W8 = isHeros.Length; //P2               
        // 0x00BB0DA4: CMP w19, w8                | STATE = COMPARE(0x1, isHeros.Length)    
        // 0x00BB0DA8: B.LO #0xbb0db8             | if (val_18 < isHeros.Length) goto label_17;
        if(val_18 < isHeros.Length)
        {
            goto label_17;
        }
        // 0x00BB0DAC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
        // 0x00BB0DB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0DB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        label_17:
        // 0x00BB0DB8: ADD x8, x21, x20, lsl #2   | X8 = isHeros[0x1]; //PARR1              
        // 0x00BB0DBC: LDR w23, [x8, #0x20]       | W23 = isHeros[0x1][0]                   
        int val_19 = isHeros[1];
        // 0x00BB0DC0: CBNZ x22, #0xbb0dc8        | if (focusIds != null) goto label_18;    
        if(focusIds != null)
        {
            goto label_18;
        }
        // 0x00BB0DC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_18:
        // 0x00BB0DC8: LDR w8, [x22, #0x18]       | W8 = focusIds.Length; //P2              
        // 0x00BB0DCC: CMP w19, w8                | STATE = COMPARE(0x1, focusIds.Length)   
        // 0x00BB0DD0: B.LO #0xbb0de0             | if (val_18 < focusIds.Length) goto label_19;
        if(val_18 < focusIds.Length)
        {
            goto label_19;
        }
        // 0x00BB0DD4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
        // 0x00BB0DD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0DDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        label_19:
        // 0x00BB0DE0: LDR w28, [x28]             | W28 = focusIds[0x1] + 32;               
        // 0x00BB0DE4: CBNZ x27, #0xbb0dec        | if (GameMgr.UPDATEOnOffEffect != null) goto label_20;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_20;
        }
        // 0x00BB0DE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_20:
        // 0x00BB0DEC: CMP w23, #1                | STATE = COMPARE(isHeros[0x1][0], 0x1)   
        // 0x00BB0DF0: CSET w1, eq                | W1 = isHeros[1] == 1 ? 1 : 0;           
        bool val_9 = (val_19 == 1) ? 1 : 0;
        // 0x00BB0DF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BB0DF8: MOV x0, x27                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00BB0DFC: MOV w2, w28                | W2 = focusIds[0x1] + 32;//m1            
        // 0x00BB0E00: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_9 = (isHeros[1] == 1) ? 1 : 0, id:  focusIds[0x1] + 32);
        CombatEntity val_10 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_9, id:  focusIds[0x1] + 32);
        // 0x00BB0E04: MOV x27, x0                | X27 = val_10;//m1                       
        // 0x00BB0E08: CBNZ x27, #0xbb0e10        | if (val_10 != null) goto label_21;      
        if(val_10 != null)
        {
            goto label_21;
        }
        // 0x00BB0E0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_21:
        // 0x00BB0E10: LDR x27, [x27, #0x58]      | 
        // 0x00BB0E14: CBNZ x27, #0xbb0e1c        | if (val_10 != null) goto label_22;      
        if(val_10 != null)
        {
            goto label_22;
        }
        // 0x00BB0E18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_22:
        // 0x00BB0E1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0E20: MOV x0, x27                | X0 = val_10;//m1                        
        // 0x00BB0E24: BL #0x20d50fc              | X0 = val_10.get_gameObject();           
        UnityEngine.GameObject val_11 = val_10.gameObject;
        // 0x00BB0E28: MOV x27, x0                | X27 = val_11;//m1                       
        val_19 = val_11;
        // 0x00BB0E2C: B #0xbb0e34                |  goto label_23;                         
        goto label_23;
        label_15:
        // 0x00BB0E30: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
        val_19 = 0;
        label_23:
        // 0x00BB0E34: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB0E38: CBNZ x23, #0xbb0e40        | if (this.cameraBezier != null) goto label_24;
        if(this.cameraBezier != null)
        {
            goto label_24;
        }
        // 0x00BB0E3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_24:
        // 0x00BB0E40: LDR x28, [x23, #0x18]      | X28 = this.cameraBezier.points; //P2    
        // 0x00BB0E44: CBNZ x26, #0xbb0e4c        | if (points != null) goto label_25;      
        if(points != null)
        {
            goto label_25;
        }
        // 0x00BB0E48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_25:
        // 0x00BB0E4C: CBNZ x28, #0xbb0e54        | if (this.cameraBezier.points != null) goto label_26;
        if(this.cameraBezier.points != null)
        {
            goto label_26;
        }
        // 0x00BB0E50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_26:
        // 0x00BB0E54: LDR w8, [x26, #0x18]       | W8 = points.Length; //P2                
        // 0x00BB0E58: CMP w19, w8                | STATE = COMPARE(0x1, points.Length)     
        // 0x00BB0E5C: B.LO #0xbb0e6c             | if (val_18 < points.Length) goto label_27;
        if(val_18 < points.Length)
        {
            goto label_27;
        }
        // 0x00BB0E60: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
        // 0x00BB0E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0E68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        label_27:
        // 0x00BB0E6C: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_20 = 12;
        // 0x00BB0E70: MADD x8, x20, x8, x26      | X8 = (1 * 12) + points;                 
        val_20 = points + (1 * val_20);
        // 0x00BB0E74: LDP s0, s1, [x8, #0x20]    | S0 = (1 * 12) + points + 32; S1 = (1 * 12) + points + 32 + 4; //  | 
        // 0x00BB0E78: LDR s2, [x8, #0x28]        | S2 = (1 * 12) + points + 40;            
        // 0x00BB0E7C: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00BB0E80: LDR x8, [x8, #0x7b0]       | X8 = 1152921510909120752;               
        // 0x00BB0E84: MOV x0, x28                | X0 = this.cameraBezier.points;//m1      
        // 0x00BB0E88: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Add(UnityEngine.Vector3 item);
        // 0x00BB0E8C: BL #0x263fe28              | this.cameraBezier.points.Add(item:  new UnityEngine.Vector3() {x = (1 * 12) + points + 32, y = (1 * 12) + points + 32 + 4, z = (1 * 12) + points + 40});
        this.cameraBezier.points.Add(item:  new UnityEngine.Vector3() {x = (1 * 12) + points + 32, y = (1 * 12) + points + 32 + 4, z = (1 * 12) + points + 40});
        // 0x00BB0E90: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB0E94: CBNZ x23, #0xbb0e9c        | if (this.cameraBezier != null) goto label_28;
        if(this.cameraBezier != null)
        {
            goto label_28;
        }
        // 0x00BB0E98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.points, ????);
        label_28:
        // 0x00BB0E9C: LDR x28, [x23, #0x20]      | X28 = this.cameraBezier.rotations; //P2 
        // 0x00BB0EA0: LDR x23, [sp, #0x20]       | X23 = rots;                             
        // 0x00BB0EA4: CBNZ x23, #0xbb0eac        | if (rots != 0) goto label_29;           
        if(rots != 0)
        {
            goto label_29;
        }
        // 0x00BB0EA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.points, ????);
        label_29:
        // 0x00BB0EAC: CBNZ x28, #0xbb0eb4        | if (this.cameraBezier.rotations != null) goto label_30;
        if(this.cameraBezier.rotations != null)
        {
            goto label_30;
        }
        // 0x00BB0EB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.points, ????);
        label_30:
        // 0x00BB0EB4: LDR w8, [x23, #0x18]       | W8 = rots + 24;                         
        // 0x00BB0EB8: CMP w19, w8                | STATE = COMPARE(0x1, rots + 24)         
        // 0x00BB0EBC: B.LO #0xbb0ecc             | if (val_18 < rots + 24) goto label_31;  
        if(val_18 < (rots + 24))
        {
            goto label_31;
        }
        // 0x00BB0EC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.cameraBezier.points, ????);
        // 0x00BB0EC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0EC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.cameraBezier.points, ????);
        label_31:
        // 0x00BB0ECC: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_21 = 12;
        // 0x00BB0ED0: MADD x8, x20, x8, x23      | X8 = (1 * 12) + rots;                   
        val_21 = rots + (1 * val_21);
        // 0x00BB0ED4: LDP s0, s1, [x8, #0x20]    | S0 = (1 * 12) + rots + 32; S1 = (1 * 12) + rots + 32 + 4; //  | 
        // 0x00BB0ED8: LDR s2, [x8, #0x28]        | S2 = (1 * 12) + rots + 40;              
        // 0x00BB0EDC: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00BB0EE0: LDR x8, [x8, #0x7b0]       | X8 = 1152921510909120752;               
        // 0x00BB0EE4: MOV x0, x28                | X0 = this.cameraBezier.rotations;//m1   
        // 0x00BB0EE8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Add(UnityEngine.Vector3 item);
        // 0x00BB0EEC: BL #0x263fe28              | this.cameraBezier.rotations.Add(item:  new UnityEngine.Vector3() {x = (1 * 12) + rots + 32, y = (1 * 12) + rots + 32 + 4, z = (1 * 12) + rots + 40});
        this.cameraBezier.rotations.Add(item:  new UnityEngine.Vector3() {x = (1 * 12) + rots + 32, y = (1 * 12) + rots + 32 + 4, z = (1 * 12) + rots + 40});
        // 0x00BB0EF0: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB0EF4: CBNZ x23, #0xbb0efc        | if (this.cameraBezier != null) goto label_32;
        if(this.cameraBezier != null)
        {
            goto label_32;
        }
        // 0x00BB0EF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.rotations, ????);
        label_32:
        // 0x00BB0EFC: LDR x28, [x23, #0x38]      | X28 = this.cameraBezier.speed; //P2     
        // 0x00BB0F00: LDR x23, [sp, #0x28]       | X23 = speeds;                           
        // 0x00BB0F04: CBNZ x23, #0xbb0f0c        | if (speeds != 0) goto label_33;         
        if(speeds != 0)
        {
            goto label_33;
        }
        // 0x00BB0F08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.rotations, ????);
        label_33:
        // 0x00BB0F0C: LDR w8, [x23, #0x18]       | W8 = speeds + 24;                       
        // 0x00BB0F10: CMP w19, w8                | STATE = COMPARE(0x1, speeds + 24)       
        // 0x00BB0F14: B.LO #0xbb0f24             | if (val_18 < speeds + 24) goto label_34;
        if(val_18 < (speeds + 24))
        {
            goto label_34;
        }
        // 0x00BB0F18: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.cameraBezier.rotations, ????);
        // 0x00BB0F1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0F20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.cameraBezier.rotations, ????);
        label_34:
        // 0x00BB0F24: ADD x8, x23, x20, lsl #2   | X8 = (speeds + 4);                      
        System.Single[] val_12 = speeds + 4;
        // 0x00BB0F28: LDR s8, [x8, #0x20]        | S8 = (speeds + 4) + 32;                 
        // 0x00BB0F2C: CBNZ x28, #0xbb0f34        | if (this.cameraBezier.speed != null) goto label_35;
        if(this.cameraBezier.speed != null)
        {
            goto label_35;
        }
        // 0x00BB0F30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.rotations, ????);
        label_35:
        // 0x00BB0F34: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
        // 0x00BB0F38: LDR x8, [x8, #0xe38]       | X8 = 1152921510888403920;               
        // 0x00BB0F3C: MOV x0, x28                | X0 = this.cameraBezier.speed;//m1       
        // 0x00BB0F40: MOV v0.16b, v8.16b         | V0 = (speeds + 4) + 32;//m1             
        // 0x00BB0F44: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Single>::Add(System.Single item);
        // 0x00BB0F48: BL #0x25f7a38              | this.cameraBezier.speed.Add(item:  (speeds + 4) + 32);
        this.cameraBezier.speed.Add(item:  (speeds + 4) + 32);
        // 0x00BB0F4C: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB0F50: CBNZ x23, #0xbb0f58        | if (this.cameraBezier != null) goto label_36;
        if(this.cameraBezier != null)
        {
            goto label_36;
        }
        // 0x00BB0F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.speed, ????);
        label_36:
        // 0x00BB0F58: LDR x28, [x23, #0x40]      | X28 = this.cameraBezier.focus; //P2     
        // 0x00BB0F5C: CBNZ x28, #0xbb0f64        | if (this.cameraBezier.focus != null) goto label_37;
        if(this.cameraBezier.focus != null)
        {
            goto label_37;
        }
        // 0x00BB0F60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.speed, ????);
        label_37:
        // 0x00BB0F64: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
        // 0x00BB0F68: LDR x8, [x8, #0x5a0]       | X8 = 1152921510860303280;               
        // 0x00BB0F6C: MOV x0, x28                | X0 = this.cameraBezier.focus;//m1       
        // 0x00BB0F70: MOV x1, x27                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0F74: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<UnityEngine.GameObject>::Add(UnityEngine.GameObject item);
        // 0x00BB0F78: BL #0x25ea480              | this.cameraBezier.focus.Add(item:  val_19);
        this.cameraBezier.focus.Add(item:  val_19);
        // 0x00BB0F7C: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB0F80: CBNZ x23, #0xbb0f88        | if (this.cameraBezier != null) goto label_38;
        if(this.cameraBezier != null)
        {
            goto label_38;
        }
        // 0x00BB0F84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.focus, ????);
        label_38:
        // 0x00BB0F88: LDR x27, [x23, #0x50]      | X27 = this.cameraBezier.smooth; //P2    
        // 0x00BB0F8C: LDP x23, x28, [sp, #0x30]  | X23 = smooths; X28 = views;              //  | 
        // 0x00BB0F90: CBNZ x23, #0xbb0f98        | if (smooths != 0) goto label_39;        
        if(smooths != 0)
        {
            goto label_39;
        }
        // 0x00BB0F94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.focus, ????);
        label_39:
        // 0x00BB0F98: LDR w8, [x23, #0x18]       | W8 = smooths + 24;                      
        // 0x00BB0F9C: CMP w19, w8                | STATE = COMPARE(0x1, smooths + 24)      
        // 0x00BB0FA0: B.LO #0xbb0fb0             | if (val_18 < smooths + 24) goto label_40;
        if(val_18 < (smooths + 24))
        {
            goto label_40;
        }
        // 0x00BB0FA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.cameraBezier.focus, ????);
        // 0x00BB0FA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB0FAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.cameraBezier.focus, ????);
        label_40:
        // 0x00BB0FB0: ADD x8, x23, x20, lsl #2   | X8 = (smooths + 4);                     
        System.Single[] val_13 = smooths + 4;
        // 0x00BB0FB4: LDR s8, [x8, #0x20]        | S8 = (smooths + 4) + 32;                
        // 0x00BB0FB8: CBNZ x27, #0xbb0fc0        | if (this.cameraBezier.smooth != null) goto label_41;
        if(this.cameraBezier.smooth != null)
        {
            goto label_41;
        }
        // 0x00BB0FBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.focus, ????);
        label_41:
        // 0x00BB0FC0: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
        // 0x00BB0FC4: LDR x8, [x8, #0xe38]       | X8 = 1152921510888403920;               
        // 0x00BB0FC8: MOV x0, x27                | X0 = this.cameraBezier.smooth;//m1      
        // 0x00BB0FCC: MOV v0.16b, v8.16b         | V0 = (smooths + 4) + 32;//m1            
        // 0x00BB0FD0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Single>::Add(System.Single item);
        // 0x00BB0FD4: BL #0x25f7a38              | this.cameraBezier.smooth.Add(item:  (smooths + 4) + 32);
        this.cameraBezier.smooth.Add(item:  (smooths + 4) + 32);
        // 0x00BB0FD8: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB0FDC: CBNZ x23, #0xbb0fe4        | if (this.cameraBezier != null) goto label_42;
        if(this.cameraBezier != null)
        {
            goto label_42;
        }
        // 0x00BB0FE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.smooth, ????);
        label_42:
        // 0x00BB0FE4: LDR x27, [x23, #0x58]      | X27 = this.cameraBezier.view; //P2      
        // 0x00BB0FE8: CBNZ x28, #0xbb0ff0        | if (views != 0) goto label_43;          
        if(views != 0)
        {
            goto label_43;
        }
        // 0x00BB0FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.smooth, ????);
        label_43:
        // 0x00BB0FF0: LDR w8, [x28, #0x18]       | W8 = views + 24;                        
        // 0x00BB0FF4: CMP w19, w8                | STATE = COMPARE(0x1, views + 24)        
        // 0x00BB0FF8: B.LO #0xbb1008             | if (val_18 < views + 24) goto label_44; 
        if(val_18 < (views + 24))
        {
            goto label_44;
        }
        // 0x00BB0FFC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.cameraBezier.smooth, ????);
        // 0x00BB1000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB1004: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.cameraBezier.smooth, ????);
        label_44:
        // 0x00BB1008: ADD x8, x28, x20, lsl #2   | X8 = (views + 4);                       
        System.Single[] val_14 = views + 4;
        // 0x00BB100C: LDR s8, [x8, #0x20]        | S8 = (views + 4) + 32;                  
        // 0x00BB1010: CBNZ x27, #0xbb1018        | if (this.cameraBezier.view != null) goto label_45;
        if(this.cameraBezier.view != null)
        {
            goto label_45;
        }
        // 0x00BB1014: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.smooth, ????);
        label_45:
        // 0x00BB1018: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
        // 0x00BB101C: LDR x8, [x8, #0xe38]       | X8 = 1152921510888403920;               
        // 0x00BB1020: MOV x0, x27                | X0 = this.cameraBezier.view;//m1        
        // 0x00BB1024: MOV v0.16b, v8.16b         | V0 = (views + 4) + 32;//m1              
        // 0x00BB1028: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Single>::Add(System.Single item);
        // 0x00BB102C: BL #0x25f7a38              | this.cameraBezier.view.Add(item:  (views + 4) + 32);
        this.cameraBezier.view.Add(item:  (views + 4) + 32);
        // 0x00BB1030: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB1034: LDR x28, [sp, #8]          | X28 = isClockWise;                      
        // 0x00BB1038: CBNZ x23, #0xbb1040        | if (this.cameraBezier != null) goto label_46;
        if(this.cameraBezier != null)
        {
            goto label_46;
        }
        // 0x00BB103C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.view, ????);
        label_46:
        // 0x00BB1040: LDR x27, [x23, #0x28]      | X27 = this.cameraBezier.rotSpeed; //P2  
        // 0x00BB1044: CBNZ x25, #0xbb104c        | if (rotSpeed != null) goto label_47;    
        if(rotSpeed != null)
        {
            goto label_47;
        }
        // 0x00BB1048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.view, ????);
        label_47:
        // 0x00BB104C: LDR w8, [x25, #0x18]       | W8 = rotSpeed.Length; //P2              
        // 0x00BB1050: CMP w19, w8                | STATE = COMPARE(0x1, rotSpeed.Length)   
        // 0x00BB1054: B.LO #0xbb1064             | if (val_18 < rotSpeed.Length) goto label_48;
        if(val_18 < rotSpeed.Length)
        {
            goto label_48;
        }
        // 0x00BB1058: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.cameraBezier.view, ????);
        // 0x00BB105C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB1060: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.cameraBezier.view, ????);
        label_48:
        // 0x00BB1064: ADD x8, x25, x20, lsl #2   | X8 = rotSpeed[0x1]; //PARR1             
        // 0x00BB1068: LDR s8, [x8, #0x20]        | S8 = rotSpeed[0x1][0]                   
        float val_22 = rotSpeed[1];
        // 0x00BB106C: CBNZ x27, #0xbb1074        | if (this.cameraBezier.rotSpeed != null) goto label_49;
        if(this.cameraBezier.rotSpeed != null)
        {
            goto label_49;
        }
        // 0x00BB1070: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.view, ????);
        label_49:
        // 0x00BB1074: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
        // 0x00BB1078: LDR x8, [x8, #0xe38]       | X8 = 1152921510888403920;               
        // 0x00BB107C: MOV x0, x27                | X0 = this.cameraBezier.rotSpeed;//m1    
        // 0x00BB1080: MOV v0.16b, v8.16b         | V0 = rotSpeed[0x1][0];//m1              
        // 0x00BB1084: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Single>::Add(System.Single item);
        // 0x00BB1088: BL #0x25f7a38              | this.cameraBezier.rotSpeed.Add(item:  rotSpeed[1]);
        this.cameraBezier.rotSpeed.Add(item:  val_22);
        // 0x00BB108C: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB1090: CBNZ x23, #0xbb1098        | if (this.cameraBezier != null) goto label_50;
        if(this.cameraBezier != null)
        {
            goto label_50;
        }
        // 0x00BB1094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.rotSpeed, ????);
        label_50:
        // 0x00BB1098: LDR x27, [x23, #0x30]      | X27 = this.cameraBezier.isClockWise; //P2 
        // 0x00BB109C: CBNZ x28, #0xbb10a4        | if (isClockWise != 0) goto label_51;    
        if(isClockWise != 0)
        {
            goto label_51;
        }
        // 0x00BB10A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.rotSpeed, ????);
        label_51:
        // 0x00BB10A4: LDR w8, [x28, #0x18]       | W8 = isClockWise + 24;                  
        // 0x00BB10A8: CMP w19, w8                | STATE = COMPARE(0x1, isClockWise + 24)  
        // 0x00BB10AC: B.LO #0xbb10bc             | if (val_18 < isClockWise + 24) goto label_52;
        if(val_18 < (isClockWise + 24))
        {
            goto label_52;
        }
        // 0x00BB10B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.cameraBezier.rotSpeed, ????);
        // 0x00BB10B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB10B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.cameraBezier.rotSpeed, ????);
        label_52:
        // 0x00BB10BC: ADD x8, x28, x20, lsl #2   | X8 = (isClockWise + 4);                 
        System.Int32[] val_15 = isClockWise + 4;
        // 0x00BB10C0: LDR w28, [x8, #0x20]       | W28 = (isClockWise + 4) + 32;           
        // 0x00BB10C4: CBNZ x27, #0xbb10cc        | if (this.cameraBezier.isClockWise != null) goto label_53;
        if(this.cameraBezier.isClockWise != null)
        {
            goto label_53;
        }
        // 0x00BB10C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.rotSpeed, ????);
        label_53:
        // 0x00BB10CC: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00BB10D0: LDR x8, [x8, #0x390]       | X8 = 1152921510015558192;               
        // 0x00BB10D4: MOV x0, x27                | X0 = this.cameraBezier.isClockWise;//m1 
        // 0x00BB10D8: MOV w1, w28                | W1 = (isClockWise + 4) + 32;//m1        
        // 0x00BB10DC: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.Int32>::Add(System.Int32 item);
        // 0x00BB10E0: BL #0x25e1b34              | this.cameraBezier.isClockWise.Add(item:  (isClockWise + 4) + 32);
        this.cameraBezier.isClockWise.Add(item:  (isClockWise + 4) + 32);
        // 0x00BB10E4: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB10E8: CBNZ x23, #0xbb10f0        | if (this.cameraBezier != null) goto label_54;
        if(this.cameraBezier != null)
        {
            goto label_54;
        }
        // 0x00BB10EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.isClockWise, ????);
        label_54:
        // 0x00BB10F0: LDR x27, [x23, #0x68]      | X27 = this.cameraBezier.orthographic; //P2 
        // 0x00BB10F4: LDR x23, [sp, #0x10]       | X23 = orthographics;                    
        // 0x00BB10F8: CBNZ x23, #0xbb1100        | if (orthographics != 0) goto label_55;  
        if(orthographics != 0)
        {
            goto label_55;
        }
        // 0x00BB10FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.isClockWise, ????);
        label_55:
        // 0x00BB1100: LDR w8, [x23, #0x18]       | W8 = orthographics + 24;                
        // 0x00BB1104: CMP w19, w8                | STATE = COMPARE(0x1, orthographics + 24)
        // 0x00BB1108: B.LO #0xbb1118             | if (val_18 < orthographics + 24) goto label_56;
        if(val_18 < (orthographics + 24))
        {
            goto label_56;
        }
        // 0x00BB110C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.cameraBezier.isClockWise, ????);
        // 0x00BB1110: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB1114: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.cameraBezier.isClockWise, ????);
        label_56:
        // 0x00BB1118: ADD x8, x23, x20, lsl #2   | X8 = (orthographics + 4);               
        System.Single[] val_16 = orthographics + 4;
        // 0x00BB111C: LDR s8, [x8, #0x20]        | S8 = (orthographics + 4) + 32;          
        // 0x00BB1120: CBNZ x27, #0xbb1128        | if (this.cameraBezier.orthographic != null) goto label_57;
        if(this.cameraBezier.orthographic != null)
        {
            goto label_57;
        }
        // 0x00BB1124: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.isClockWise, ????);
        label_57:
        // 0x00BB1128: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
        // 0x00BB112C: LDR x8, [x8, #0xe38]       | X8 = 1152921510888403920;               
        // 0x00BB1130: MOV x0, x27                | X0 = this.cameraBezier.orthographic;//m1
        // 0x00BB1134: MOV v0.16b, v8.16b         | V0 = (orthographics + 4) + 32;//m1      
        // 0x00BB1138: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Single>::Add(System.Single item);
        // 0x00BB113C: BL #0x25f7a38              | this.cameraBezier.orthographic.Add(item:  (orthographics + 4) + 32);
        this.cameraBezier.orthographic.Add(item:  (orthographics + 4) + 32);
        // 0x00BB1140: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB1144: CBNZ x23, #0xbb114c        | if (this.cameraBezier != null) goto label_58;
        if(this.cameraBezier != null)
        {
            goto label_58;
        }
        // 0x00BB1148: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.orthographic, ????);
        label_58:
        // 0x00BB114C: LDR x27, [x23, #0x48]      | X27 = this.cameraBezier.isHero; //P2    
        // 0x00BB1150: CBNZ x21, #0xbb1158        | if (isHeros != null) goto label_59;     
        if(isHeros != null)
        {
            goto label_59;
        }
        // 0x00BB1154: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.orthographic, ????);
        label_59:
        // 0x00BB1158: LDR w8, [x21, #0x18]       | W8 = isHeros.Length; //P2               
        // 0x00BB115C: CMP w19, w8                | STATE = COMPARE(0x1, isHeros.Length)    
        // 0x00BB1160: B.LO #0xbb1170             | if (val_18 < isHeros.Length) goto label_60;
        if(val_18 < isHeros.Length)
        {
            goto label_60;
        }
        // 0x00BB1164: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.cameraBezier.orthographic, ????);
        // 0x00BB1168: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB116C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.cameraBezier.orthographic, ????);
        label_60:
        // 0x00BB1170: ADD x8, x21, x20, lsl #2   | X8 = isHeros[0x1]; //PARR1              
        // 0x00BB1174: LDR w28, [x8, #0x20]       | W28 = isHeros[0x1][0]                   
        int val_23 = isHeros[1];
        // 0x00BB1178: CBNZ x27, #0xbb1180        | if (this.cameraBezier.isHero != null) goto label_61;
        if(this.cameraBezier.isHero != null)
        {
            goto label_61;
        }
        // 0x00BB117C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.orthographic, ????);
        label_61:
        // 0x00BB1180: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00BB1184: LDR x8, [x8, #0x390]       | X8 = 1152921510015558192;               
        // 0x00BB1188: MOV x0, x27                | X0 = this.cameraBezier.isHero;//m1      
        // 0x00BB118C: MOV w1, w28                | W1 = isHeros[0x1][0];//m1               
        // 0x00BB1190: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.Int32>::Add(System.Int32 item);
        // 0x00BB1194: BL #0x25e1b34              | this.cameraBezier.isHero.Add(item:  isHeros[1]);
        this.cameraBezier.isHero.Add(item:  val_23);
        // 0x00BB1198: LDR x23, [x24, #0x18]      | X23 = this.cameraBezier; //P2           
        // 0x00BB119C: CBNZ x23, #0xbb11a4        | if (this.cameraBezier != null) goto label_62;
        if(this.cameraBezier != null)
        {
            goto label_62;
        }
        // 0x00BB11A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.isHero, ????);
        label_62:
        // 0x00BB11A4: LDR x27, [x23, #0x70]      | X27 = this.cameraBezier.isConstant; //P2 
        // 0x00BB11A8: LDR x23, [sp, #0x18]       | X23 = isConstants;                      
        // 0x00BB11AC: CBNZ x23, #0xbb11b4        | if (isConstants != 0) goto label_63;    
        if(isConstants != 0)
        {
            goto label_63;
        }
        // 0x00BB11B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.isHero, ????);
        label_63:
        // 0x00BB11B4: LDR w8, [x23, #0x18]       | W8 = isConstants + 24;                  
        // 0x00BB11B8: CMP w19, w8                | STATE = COMPARE(0x1, isConstants + 24)  
        // 0x00BB11BC: B.LO #0xbb11cc             | if (val_18 < isConstants + 24) goto label_64;
        if(val_18 < (isConstants + 24))
        {
            goto label_64;
        }
        // 0x00BB11C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.cameraBezier.isHero, ????);
        // 0x00BB11C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BB11C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.cameraBezier.isHero, ????);
        label_64:
        // 0x00BB11CC: ADD x8, x23, x20, lsl #2   | X8 = (isConstants + 4);                 
        System.Int32[] val_17 = isConstants + 4;
        // 0x00BB11D0: LDR w28, [x8, #0x20]       | W28 = (isConstants + 4) + 32;           
        // 0x00BB11D4: CBNZ x27, #0xbb0d20        | if (this.cameraBezier.isConstant != null) goto label_66;
        if(this.cameraBezier.isConstant != null)
        {
            goto label_66;
        }
        // 0x00BB11D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraBezier.isHero, ????);
        // 0x00BB11DC: B #0xbb0d20                |  goto label_66;                         
        goto label_66;
        label_12:
        // 0x00BB11E0: LDR x19, [x24, #0x18]      | X19 = this.cameraBezier; //P2           
        // 0x00BB11E4: CBNZ x19, #0xbb11ec        | if (this.cameraBezier != null) goto label_67;
        if(this.cameraBezier != null)
        {
            goto label_67;
        }
        // 0x00BB11E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_67:
        // 0x00BB11EC: LDR w8, [sp, #4]           | W8 = id;                                
        // 0x00BB11F0: STR w8, [x19, #0x78]       | this.cameraBezier.cameraShotDoneId = id;  //  dest_result_addr=0
        this.cameraBezier.cameraShotDoneId = id;
        // 0x00BB11F4: SUB sp, x29, #0x60         | SP = (1152921514496943824 - 96) = 1152921514496943728 (0x100000024D7EE670);
        // 0x00BB11F8: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00BB11FC: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00BB1200: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00BB1204: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00BB1208: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00BB120C: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00BB1210: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00BB1214: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BB1218 (12259864), len: 4  VirtAddr: 0x00BB1218 RVA: 0x00BB1218 token: 100690260 methodIndex: 25793 delegateWrapperIndex: 0 methodInvoker: 0
    private static CameraShotHelper()
    {
        //
        // Disasemble & Code
        // 0x00BB1218: RET                        |  return;                                
        return;
    
    }

}
