using UnityEngine;
public class ConfigAssetMgr : Singleton<ConfigAssetMgr>
{
    // Fields
    private ResToABName r2abName; //  0x00000010
    private UnityEngine.WWW www; //  0x00000018
    private int loadedCount; //  0x00000020
    private int totalLoadCount; //  0x00000024
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x287858C
    private bool <isLoaded>k__BackingField; //  0x00000028
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x28785C8
    private bool <isLoading>k__BackingField; //  0x00000029
    
    // Properties
    public bool isLoaded { get; set; }
    public bool isLoading { get; set; }
    public float loadProgress { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B42A34 (11807284), len: 88  VirtAddr: 0x00B42A34 RVA: 0x00B42A34 token: 100693332 methodIndex: 26650 delegateWrapperIndex: 0 methodInvoker: 0
    public ConfigAssetMgr()
    {
        //
        // Disasemble & Code
        // 0x00B42A34: STP x20, x19, [sp, #-0x20]! | stack[1152921514973563632] = ???;  stack[1152921514973563640] = ???;  //  dest_result_addr=1152921514973563632 |  dest_result_addr=1152921514973563640
        // 0x00B42A38: STP x29, x30, [sp, #0x10]  | stack[1152921514973563648] = ???;  stack[1152921514973563656] = ???;  //  dest_result_addr=1152921514973563648 |  dest_result_addr=1152921514973563656
        // 0x00B42A3C: ADD x29, sp, #0x10         | X29 = (1152921514973563632 + 16) = 1152921514973563648 (0x1000000269E78B00);
        // 0x00B42A40: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B42A44: LDRB w8, [x20, #0x7f4]     | W8 = (bool)static_value_037337F4;       
        // 0x00B42A48: MOV x19, x0                | X19 = 1152921514973575664 (0x1000000269E7B9F0);//ML01
        // 0x00B42A4C: TBNZ w8, #0, #0xb42a68     | if (static_value_037337F4 == true) goto label_0;
        // 0x00B42A50: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B42A54: LDR x8, [x8, #0xb00]       | X8 = 0x2B9273C;                         
        // 0x00B42A58: LDR w0, [x8]               | W0 = 0x2094;                            
        // 0x00B42A5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2094, ????);     
        // 0x00B42A60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B42A64: STRB w8, [x20, #0x7f4]     | static_value_037337F4 = true;            //  dest_result_addr=57882612
        label_0:
        // 0x00B42A68: ORR w8, wzr, #3            | W8 = 3(0x3);                            
        // 0x00B42A6C: STR w8, [x19, #0x24]       | this.totalLoadCount = 3;                 //  dest_result_addr=1152921514973575700
        this.totalLoadCount = 3;
        // 0x00B42A70: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00B42A74: LDR x8, [x8, #0xb18]       | X8 = 1152921514973550640;               
        // 0x00B42A78: MOV x0, x19                | X0 = 1152921514973575664 (0x1000000269E7B9F0);//ML01
        // 0x00B42A7C: LDR x1, [x8]               | X1 = public System.Void Singleton<ConfigAssetMgr>::.ctor();
        // 0x00B42A80: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42A84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B42A88: B #0x1a0440c               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42A8C (11807372), len: 8  VirtAddr: 0x00B42A8C RVA: 0x00B42A8C token: 100693333 methodIndex: 26651 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_isLoaded()
    {
        //
        // Disasemble & Code
        // 0x00B42A8C: LDRB w0, [x0, #0x28]       | W0 = this.<isLoaded>k__BackingField; //P2 
        // 0x00B42A90: RET                        |  return (System.Boolean)this.<isLoaded>k__BackingField;
        return this.<isLoaded>k__BackingField;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42A94 (11807380), len: 12  VirtAddr: 0x00B42A94 RVA: 0x00B42A94 token: 100693334 methodIndex: 26652 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_isLoaded(bool value)
    {
        //
        // Disasemble & Code
        // 0x00B42A94: AND w8, w1, #1             | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00B42A98: STRB w8, [x0, #0x28]       | this.<isLoaded>k__BackingField = (value & 1);  //  dest_result_addr=1152921514973799704
        this.<isLoaded>k__BackingField = val_1;
        // 0x00B42A9C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42AA0 (11807392), len: 8  VirtAddr: 0x00B42AA0 RVA: 0x00B42AA0 token: 100693335 methodIndex: 26653 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_isLoading()
    {
        //
        // Disasemble & Code
        // 0x00B42AA0: LDRB w0, [x0, #0x29]       | W0 = this.<isLoading>k__BackingField; //P2 
        // 0x00B42AA4: RET                        |  return (System.Boolean)this.<isLoading>k__BackingField;
        return this.<isLoading>k__BackingField;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42AA8 (11807400), len: 12  VirtAddr: 0x00B42AA8 RVA: 0x00B42AA8 token: 100693336 methodIndex: 26654 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_isLoading(bool value)
    {
        //
        // Disasemble & Code
        // 0x00B42AA8: AND w8, w1, #1             | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00B42AAC: STRB w8, [x0, #0x29]       | this.<isLoading>k__BackingField = (value & 1);  //  dest_result_addr=1152921514974023705
        this.<isLoading>k__BackingField = val_1;
        // 0x00B42AB0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42AB4 (11807412), len: 92  VirtAddr: 0x00B42AB4 RVA: 0x00B42AB4 token: 100693337 methodIndex: 26655 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_loadProgress()
    {
        //
        // Disasemble & Code
        // 0x00B42AB4: STP x22, x21, [sp, #-0x30]! | stack[1152921514974127712] = ???;  stack[1152921514974127720] = ???;  //  dest_result_addr=1152921514974127712 |  dest_result_addr=1152921514974127720
        // 0x00B42AB8: STP x20, x19, [sp, #0x10]  | stack[1152921514974127728] = ???;  stack[1152921514974127736] = ???;  //  dest_result_addr=1152921514974127728 |  dest_result_addr=1152921514974127736
        // 0x00B42ABC: STP x29, x30, [sp, #0x20]  | stack[1152921514974127744] = ???;  stack[1152921514974127752] = ???;  //  dest_result_addr=1152921514974127744 |  dest_result_addr=1152921514974127752
        // 0x00B42AC0: ADD x29, sp, #0x20         | X29 = (1152921514974127712 + 32) = 1152921514974127744 (0x1000000269F02680);
        // 0x00B42AC4: MOV x19, x0                | X19 = 1152921514974139760 (0x1000000269F05570);//ML01
        // 0x00B42AC8: LDR w21, [x19, #0x20]      | W21 = this.loadedCount; //P2            
        // 0x00B42ACC: LDR x20, [x19, #0x18]      | X20 = this.www; //P2                    
        // 0x00B42AD0: CBNZ x20, #0xb42ad8        | if (this.www != null) goto label_0;     
        if(this.www != null)
        {
            goto label_0;
        }
        // 0x00B42AD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B42AD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B42ADC: MOV x0, x20                | X0 = this.www;//m1                      
        // 0x00B42AE0: BL #0x276f34c              | X0 = this.www.get_progress();           
        float val_1 = this.www.progress;
        // 0x00B42AE4: LDR s1, [x19, #0x24]       | S1 = this.totalLoadCount; //P2          
        // 0x00B42AE8: SCVTF s2, w21              | S2 = (float)(this.loadedCount);         
        // 0x00B42AEC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42AF0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B42AF4: FADD s0, s2, s0            | S0 = (this.loadedCount + val_1);        
        val_1 = (float)this.loadedCount + val_1;
        // 0x00B42AF8: SCVTF s1, s1               | S1 = (float)(this.totalLoadCount);      
        float val_2 = (float)this.totalLoadCount;
        // 0x00B42AFC: FMOV s2, #1.00000000       | S2 = 1;                                 
        // 0x00B42B00: FDIV s1, s2, s1            | S1 = (1f / this.totalLoadCount);        
        val_2 = 1f / val_2;
        // 0x00B42B04: FMUL s0, s0, s1            | S0 = ((this.loadedCount + val_1) * (1f / this.totalLoadCount));
        val_1 = val_1 * val_2;
        // 0x00B42B08: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B42B0C: RET                        |  return (System.Single)((this.loadedCount + val_1) * (1f / this.totalLoadCount));
        return (float)val_1;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42B10 (11807504), len: 124  VirtAddr: 0x00B42B10 RVA: 0x00B42B10 token: 100693338 methodIndex: 26656 delegateWrapperIndex: 0 methodInvoker: 0
    public void LoadConfig()
    {
        //
        // Disasemble & Code
        // 0x00B42B10: STP x20, x19, [sp, #-0x20]! | stack[1152921514974252016] = ???;  stack[1152921514974252024] = ???;  //  dest_result_addr=1152921514974252016 |  dest_result_addr=1152921514974252024
        // 0x00B42B14: STP x29, x30, [sp, #0x10]  | stack[1152921514974252032] = ???;  stack[1152921514974252040] = ???;  //  dest_result_addr=1152921514974252032 |  dest_result_addr=1152921514974252040
        // 0x00B42B18: ADD x29, sp, #0x10         | X29 = (1152921514974252016 + 16) = 1152921514974252032 (0x1000000269F20C00);
        // 0x00B42B1C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B42B20: LDRB w8, [x20, #0x7f5]     | W8 = (bool)static_value_037337F5;       
        // 0x00B42B24: MOV x19, x0                | X19 = 1152921514974264048 (0x1000000269F23AF0);//ML01
        // 0x00B42B28: TBNZ w8, #0, #0xb42b44     | if (static_value_037337F5 == true) goto label_0;
        // 0x00B42B2C: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x00B42B30: LDR x8, [x8, #0x3f8]       | X8 = 0x2B92778;                         
        // 0x00B42B34: LDR w0, [x8]               | W0 = 0x20A3;                            
        // 0x00B42B38: BL #0x2782188              | X0 = sub_2782188( ?? 0x20A3, ????);     
        // 0x00B42B3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B42B40: STRB w8, [x20, #0x7f5]     | static_value_037337F5 = true;            //  dest_result_addr=57882613
        label_0:
        // 0x00B42B44: MOV x0, x19                | X0 = 1152921514974264048 (0x1000000269F23AF0);//ML01
        // 0x00B42B48: BL #0xb42b8c               | X0 = this.RunLoadConfig();              
        System.Collections.IEnumerator val_1 = this.RunLoadConfig();
        // 0x00B42B4C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B42B50: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00B42B54: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B42B58: LDR x8, [x8]               | X8 = typeof(BehaviourUtil);             
        // 0x00B42B5C: LDRB w9, [x8, #0x10a]      | W9 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B42B60: TBZ w9, #0, #0xb42b74      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B42B64: LDR w9, [x8, #0xbc]        | W9 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B42B68: CBNZ w9, #0xb42b74         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B42B6C: MOV x0, x8                 | X0 = 1152921504922660864 (0x1000000012D2F000);//ML01
        // 0x00B42B70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_2:
        // 0x00B42B74: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42B78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B42B7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B42B80: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00B42B84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B42B88: B #0xb8d914                | X0 = BehaviourUtil.StartCoroutine(routine:  0); return;
        UnityEngine.Coroutine val_2 = BehaviourUtil.StartCoroutine(routine:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42B8C (11807628), len: 108  VirtAddr: 0x00B42B8C RVA: 0x00B42B8C token: 100693339 methodIndex: 26657 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x2878644
    private System.Collections.IEnumerator RunLoadConfig()
    {
        //
        // Disasemble & Code
        // 0x00B42B8C: STP x20, x19, [sp, #-0x20]! | stack[1152921514974372208] = ???;  stack[1152921514974372216] = ???;  //  dest_result_addr=1152921514974372208 |  dest_result_addr=1152921514974372216
        // 0x00B42B90: STP x29, x30, [sp, #0x10]  | stack[1152921514974372224] = ???;  stack[1152921514974372232] = ???;  //  dest_result_addr=1152921514974372224 |  dest_result_addr=1152921514974372232
        // 0x00B42B94: ADD x29, sp, #0x10         | X29 = (1152921514974372208 + 16) = 1152921514974372224 (0x1000000269F3E180);
        // 0x00B42B98: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B42B9C: LDRB w8, [x20, #0x7f6]     | W8 = (bool)static_value_037337F6;       
        // 0x00B42BA0: MOV x19, x0                | X19 = 1152921514974384240 (0x1000000269F41070);//ML01
        // 0x00B42BA4: TBNZ w8, #0, #0xb42bc0     | if (static_value_037337F6 == true) goto label_0;
        // 0x00B42BA8: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00B42BAC: LDR x8, [x8, #0xed8]       | X8 = 0x2B9277C;                         
        // 0x00B42BB0: LDR w0, [x8]               | W0 = 0x20A4;                            
        // 0x00B42BB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x20A4, ????);     
        // 0x00B42BB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B42BBC: STRB w8, [x20, #0x7f6]     | static_value_037337F6 = true;            //  dest_result_addr=57882614
        label_0:
        // 0x00B42BC0: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B42BC4: LDR x8, [x8, #0x688]       | X8 = 1152921504904237056;               
        // 0x00B42BC8: LDR x0, [x8]               | X0 = typeof(ConfigAssetMgr.<RunLoadConfig>c__Iterator0);
        object val_1 = null;
        // 0x00B42BCC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ConfigAssetMgr.<RunLoadConfig>c__Iterator0), ????);
        // 0x00B42BD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B42BD4: MOV x20, x0                | X20 = 1152921504904237056 (0x1000000011B9D000);//ML01
        // 0x00B42BD8: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00B42BDC: CBNZ x20, #0xb42be4        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B42BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00B42BE4: STR x19, [x20, #0x38]      | typeof(ConfigAssetMgr.<RunLoadConfig>c__Iterator0).__il2cppRuntimeField_38 = this;  //  dest_result_addr=1152921504904237112
        typeof(ConfigAssetMgr.<RunLoadConfig>c__Iterator0).__il2cppRuntimeField_38 = this;
        // 0x00B42BE8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42BEC: MOV x0, x20                | X0 = 1152921504904237056 (0x1000000011B9D000);//ML01
        // 0x00B42BF0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B42BF4: RET                        |  return (System.Collections.IEnumerator)typeof(ConfigAssetMgr.<RunLoadConfig>c__Iterator0);
        return (System.Collections.IEnumerator)val_1;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42C00 (11807744), len: 52  VirtAddr: 0x00B42C00 RVA: 0x00B42C00 token: 100693340 methodIndex: 26658 delegateWrapperIndex: 0 methodInvoker: 0
    public string LoadPathToABPath(string path)
    {
        //
        // Disasemble & Code
        // 0x00B42C00: STP x20, x19, [sp, #-0x20]! | stack[1152921514974492400] = ???;  stack[1152921514974492408] = ???;  //  dest_result_addr=1152921514974492400 |  dest_result_addr=1152921514974492408
        // 0x00B42C04: STP x29, x30, [sp, #0x10]  | stack[1152921514974492416] = ???;  stack[1152921514974492424] = ???;  //  dest_result_addr=1152921514974492416 |  dest_result_addr=1152921514974492424
        // 0x00B42C08: ADD x29, sp, #0x10         | X29 = (1152921514974492400 + 16) = 1152921514974492416 (0x1000000269F5B700);
        // 0x00B42C0C: LDR x20, [x0, #0x10]       | X20 = this.r2abName; //P2               
        // 0x00B42C10: MOV x19, x1                | X19 = path;//m1                         
        // 0x00B42C14: CBNZ x20, #0xb42c1c        | if (this.r2abName != null) goto label_0;
        if(this.r2abName != null)
        {
            goto label_0;
        }
        // 0x00B42C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B42C1C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42C20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B42C24: MOV x0, x20                | X0 = this.r2abName;//m1                 
        // 0x00B42C28: MOV x1, x19                | X1 = path;//m1                          
        // 0x00B42C2C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B42C30: B #0xca0e40                | return this.r2abName.GetABNameByLoad(loadName:  path);
        return this.r2abName.GetABNameByLoad(loadName:  path);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42C34 (11807796), len: 52  VirtAddr: 0x00B42C34 RVA: 0x00B42C34 token: 100693341 methodIndex: 26659 delegateWrapperIndex: 0 methodInvoker: 0
    public string LoadPathToABFullPath(string path)
    {
        //
        // Disasemble & Code
        // 0x00B42C34: STP x20, x19, [sp, #-0x20]! | stack[1152921514974620784] = ???;  stack[1152921514974620792] = ???;  //  dest_result_addr=1152921514974620784 |  dest_result_addr=1152921514974620792
        // 0x00B42C38: STP x29, x30, [sp, #0x10]  | stack[1152921514974620800] = ???;  stack[1152921514974620808] = ???;  //  dest_result_addr=1152921514974620800 |  dest_result_addr=1152921514974620808
        // 0x00B42C3C: ADD x29, sp, #0x10         | X29 = (1152921514974620784 + 16) = 1152921514974620800 (0x1000000269F7AC80);
        // 0x00B42C40: LDR x20, [x0, #0x10]       | X20 = this.r2abName; //P2               
        // 0x00B42C44: MOV x19, x1                | X19 = path;//m1                         
        // 0x00B42C48: CBNZ x20, #0xb42c50        | if (this.r2abName != null) goto label_0;
        if(this.r2abName != null)
        {
            goto label_0;
        }
        // 0x00B42C4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B42C50: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42C54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B42C58: MOV x0, x20                | X0 = this.r2abName;//m1                 
        // 0x00B42C5C: MOV x1, x19                | X1 = path;//m1                          
        // 0x00B42C60: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B42C64: B #0xca0f38                | return this.r2abName.LoadPathToABFullPath(loadName:  path);
        return this.r2abName.LoadPathToABFullPath(loadName:  path);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42C68 (11807848), len: 52  VirtAddr: 0x00B42C68 RVA: 0x00B42C68 token: 100693342 methodIndex: 26660 delegateWrapperIndex: 0 methodInvoker: 0
    public string LoadPathToAssetName(string path)
    {
        //
        // Disasemble & Code
        // 0x00B42C68: STP x20, x19, [sp, #-0x20]! | stack[1152921514974749168] = ???;  stack[1152921514974749176] = ???;  //  dest_result_addr=1152921514974749168 |  dest_result_addr=1152921514974749176
        // 0x00B42C6C: STP x29, x30, [sp, #0x10]  | stack[1152921514974749184] = ???;  stack[1152921514974749192] = ???;  //  dest_result_addr=1152921514974749184 |  dest_result_addr=1152921514974749192
        // 0x00B42C70: ADD x29, sp, #0x10         | X29 = (1152921514974749168 + 16) = 1152921514974749184 (0x1000000269F9A200);
        // 0x00B42C74: LDR x20, [x0, #0x10]       | X20 = this.r2abName; //P2               
        // 0x00B42C78: MOV x19, x1                | X19 = path;//m1                         
        // 0x00B42C7C: CBNZ x20, #0xb42c84        | if (this.r2abName != null) goto label_0;
        if(this.r2abName != null)
        {
            goto label_0;
        }
        // 0x00B42C80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B42C84: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42C88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B42C8C: MOV x0, x20                | X0 = this.r2abName;//m1                 
        // 0x00B42C90: MOV x1, x19                | X1 = path;//m1                          
        // 0x00B42C94: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B42C98: B #0xca1294                | return this.r2abName.GetAssetNameByLoad(loadName:  path);
        return this.r2abName.GetAssetNameByLoad(loadName:  path);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42C9C (11807900), len: 52  VirtAddr: 0x00B42C9C RVA: 0x00B42C9C token: 100693343 methodIndex: 26661 delegateWrapperIndex: 0 methodInvoker: 0
    public string AssetNameToABPath(string assetName)
    {
        //
        // Disasemble & Code
        // 0x00B42C9C: STP x20, x19, [sp, #-0x20]! | stack[1152921514974877552] = ???;  stack[1152921514974877560] = ???;  //  dest_result_addr=1152921514974877552 |  dest_result_addr=1152921514974877560
        // 0x00B42CA0: STP x29, x30, [sp, #0x10]  | stack[1152921514974877568] = ???;  stack[1152921514974877576] = ???;  //  dest_result_addr=1152921514974877568 |  dest_result_addr=1152921514974877576
        // 0x00B42CA4: ADD x29, sp, #0x10         | X29 = (1152921514974877552 + 16) = 1152921514974877568 (0x1000000269FB9780);
        // 0x00B42CA8: LDR x20, [x0, #0x10]       | X20 = this.r2abName; //P2               
        // 0x00B42CAC: MOV x19, x1                | X19 = assetName;//m1                    
        // 0x00B42CB0: CBNZ x20, #0xb42cb8        | if (this.r2abName != null) goto label_0;
        if(this.r2abName != null)
        {
            goto label_0;
        }
        // 0x00B42CB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B42CB8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42CBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B42CC0: MOV x0, x20                | X0 = this.r2abName;//m1                 
        // 0x00B42CC4: MOV x1, x19                | X1 = assetName;//m1                     
        // 0x00B42CC8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B42CCC: B #0xca11c8                | return this.r2abName.GetABNameByAssetName(assetName:  assetName);
        return this.r2abName.GetABNameByAssetName(assetName:  assetName);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42CD0 (11807952), len: 52  VirtAddr: 0x00B42CD0 RVA: 0x00B42CD0 token: 100693344 methodIndex: 26662 delegateWrapperIndex: 0 methodInvoker: 0
    public bool GetIsCompressByABName(string abName)
    {
        //
        // Disasemble & Code
        // 0x00B42CD0: STP x20, x19, [sp, #-0x20]! | stack[1152921514975005936] = ???;  stack[1152921514975005944] = ???;  //  dest_result_addr=1152921514975005936 |  dest_result_addr=1152921514975005944
        // 0x00B42CD4: STP x29, x30, [sp, #0x10]  | stack[1152921514975005952] = ???;  stack[1152921514975005960] = ???;  //  dest_result_addr=1152921514975005952 |  dest_result_addr=1152921514975005960
        // 0x00B42CD8: ADD x29, sp, #0x10         | X29 = (1152921514975005936 + 16) = 1152921514975005952 (0x1000000269FD8D00);
        // 0x00B42CDC: LDR x20, [x0, #0x10]       | X20 = this.r2abName; //P2               
        // 0x00B42CE0: MOV x19, x1                | X19 = abName;//m1                       
        // 0x00B42CE4: CBNZ x20, #0xb42cec        | if (this.r2abName != null) goto label_0;
        if(this.r2abName != null)
        {
            goto label_0;
        }
        // 0x00B42CE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B42CEC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42CF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B42CF4: MOV x0, x20                | X0 = this.r2abName;//m1                 
        // 0x00B42CF8: MOV x1, x19                | X1 = abName;//m1                        
        // 0x00B42CFC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B42D00: B #0xca133c                | return this.r2abName.GetIsCompressByABName(abName:  abName);
        return this.r2abName.GetIsCompressByABName(abName:  abName);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B42D04 (11808004), len: 52  VirtAddr: 0x00B42D04 RVA: 0x00B42D04 token: 100693345 methodIndex: 26663 delegateWrapperIndex: 0 methodInvoker: 0
    public bool IsNullAsset(string path)
    {
        //
        // Disasemble & Code
        // 0x00B42D04: STP x20, x19, [sp, #-0x20]! | stack[1152921514975134320] = ???;  stack[1152921514975134328] = ???;  //  dest_result_addr=1152921514975134320 |  dest_result_addr=1152921514975134328
        // 0x00B42D08: STP x29, x30, [sp, #0x10]  | stack[1152921514975134336] = ???;  stack[1152921514975134344] = ???;  //  dest_result_addr=1152921514975134336 |  dest_result_addr=1152921514975134344
        // 0x00B42D0C: ADD x29, sp, #0x10         | X29 = (1152921514975134320 + 16) = 1152921514975134336 (0x1000000269FF8280);
        // 0x00B42D10: LDR x20, [x0, #0x10]       | X20 = this.r2abName; //P2               
        // 0x00B42D14: MOV x19, x1                | X19 = path;//m1                         
        // 0x00B42D18: CBNZ x20, #0xb42d20        | if (this.r2abName != null) goto label_0;
        if(this.r2abName != null)
        {
            goto label_0;
        }
        // 0x00B42D1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B42D20: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B42D24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B42D28: MOV x0, x20                | X0 = this.r2abName;//m1                 
        // 0x00B42D2C: MOV x1, x19                | X1 = path;//m1                          
        // 0x00B42D30: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B42D34: B #0xca1150                | return this.r2abName.IsNullAsset(loadName:  path);
        return this.r2abName.IsNullAsset(loadName:  path);
    
    }

}
