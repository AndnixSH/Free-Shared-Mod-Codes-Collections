using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x2819DB0
[UnityEngine.AddComponentMenu] // 0x2819DB0
public class ContrastStretchEffect : MonoBehaviour
{
    // Fields
    public float adaptationSpeed; //  0x00000018
    public float limitMinimum; //  0x0000001C
    public float limitMaximum; //  0x00000020
    private UnityEngine.RenderTexture[] adaptRenderTex; //  0x00000028
    private int curAdaptIndex; //  0x00000030
    public UnityEngine.Shader shaderLum; //  0x00000038
    private UnityEngine.Material m_materialLum; //  0x00000040
    public UnityEngine.Shader shaderReduce; //  0x00000048
    private UnityEngine.Material m_materialReduce; //  0x00000050
    public UnityEngine.Shader shaderAdapt; //  0x00000058
    private UnityEngine.Material m_materialAdapt; //  0x00000060
    public UnityEngine.Shader shaderApply; //  0x00000068
    private UnityEngine.Material m_materialApply; //  0x00000070
    
    // Properties
    protected UnityEngine.Material materialLum { get; }
    protected UnityEngine.Material materialReduce { get; }
    protected UnityEngine.Material materialAdapt { get; }
    protected UnityEngine.Material materialApply { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02731704 (41096964), len: 140  VirtAddr: 0x02731704 RVA: 0x02731704 token: 100663368 methodIndex: 24320 delegateWrapperIndex: 0 methodInvoker: 0
    public ContrastStretchEffect()
    {
        //
        // Disasemble & Code
        // 0x02731704: STP x20, x19, [sp, #-0x20]! | stack[1152921509934173632] = ???;  stack[1152921509934173640] = ???;  //  dest_result_addr=1152921509934173632 |  dest_result_addr=1152921509934173640
        // 0x02731708: STP x29, x30, [sp, #0x10]  | stack[1152921509934173648] = ???;  stack[1152921509934173656] = ???;  //  dest_result_addr=1152921509934173648 |  dest_result_addr=1152921509934173656
        // 0x0273170C: ADD x29, sp, #0x10         | X29 = (1152921509934173632 + 16) = 1152921509934173648 (0x100000013D888DD0);
        // 0x02731710: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x02731714: LDRB w8, [x20, #0xac8]     | W8 = (bool)static_value_03743AC8;       
        // 0x02731718: MOV x19, x0                | X19 = 1152921509934185664 (0x100000013D88BCC0);//ML01
        // 0x0273171C: TBNZ w8, #0, #0x2731738    | if (static_value_03743AC8 == true) goto label_0;
        // 0x02731720: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x02731724: LDR x8, [x8, #0x5c8]       | X8 = 0x2B929BC;                         
        // 0x02731728: LDR w0, [x8]               | W0 = 0x2134;                            
        // 0x0273172C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2134, ????);     
        // 0x02731730: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02731734: STRB w8, [x20, #0xac8]     | static_value_03743AC8 = true;            //  dest_result_addr=57948872
        label_0:
        // 0x02731738: MOVZ x8, #0x3e4c, lsl #48  | X8 = 4488962928581541888 (0x3E4C000000000000);//ML01
        // 0x0273173C: MOVK x8, #0xcccd, lsl #32  | X8 = 4489188109421903872 (0x3E4CCCCD00000000);
        // 0x02731740: MOVK x8, #0x3ca3, lsl #16  | X8 = 4489188110439219200 (0x3E4CCCCD3CA30000);
        // 0x02731744: MOVZ w9, #0x3f19, lsl #16  | W9 = 1058603008 (0x3F190000);//ML01     
        // 0x02731748: MOVK x8, #0xd70a           | X8 = 4489188110439274250 (0x3E4CCCCD3CA3D70A);
        // 0x0273174C: MOVK w9, #0x999a           | W9 = 1058642330 (0x3F19999A);           
        // 0x02731750: STR x8, [x19, #0x18]       | this.adaptationSpeed = 0.02; this.limitMinimum = 7.346868E-41;  //  dest_result_addr=1152921509934185688 dest_result_addr=1152921509934185692
        this.adaptationSpeed = 0.02f;
        this.limitMinimum = 7.346868E-41f;
        // 0x02731754: STR w9, [x19, #0x20]       | this.limitMaximum = 0.6;                 //  dest_result_addr=1152921509934185696
        this.limitMaximum = 0.6f;
        // 0x02731758: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x0273175C: LDR x8, [x8, #0x220]       | X8 = 1152921509934157568;               
        // 0x02731760: LDR x20, [x8]              | X20 = typeof(UnityEngine.RenderTexture[]);
        // 0x02731764: MOV x0, x20                | X0 = 1152921509934157568 (0x100000013D884F00);//ML01
        // 0x02731768: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.RenderTexture[]), ????);
        // 0x0273176C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x02731770: MOV x0, x20                | X0 = 1152921509934157568 (0x100000013D884F00);//ML01
        // 0x02731774: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.RenderTexture[]), ????);
        // 0x02731778: STR x0, [x19, #0x28]       | this.adaptRenderTex = typeof(UnityEngine.RenderTexture[]);  //  dest_result_addr=1152921509934185704
        this.adaptRenderTex = null;
        // 0x0273177C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02731780: MOV x0, x19                | X0 = 1152921509934185664 (0x100000013D88BCC0);//ML01
        // 0x02731784: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731788: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0273178C: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02731790 (41097104), len: 200  VirtAddr: 0x02731790 RVA: 0x02731790 token: 100663369 methodIndex: 24321 delegateWrapperIndex: 0 methodInvoker: 0
    protected UnityEngine.Material get_materialLum()
    {
        //
        // Disasemble & Code
        // 0x02731790: STP x22, x21, [sp, #-0x30]! | stack[1152921509934297904] = ???;  stack[1152921509934297912] = ???;  //  dest_result_addr=1152921509934297904 |  dest_result_addr=1152921509934297912
        // 0x02731794: STP x20, x19, [sp, #0x10]  | stack[1152921509934297920] = ???;  stack[1152921509934297928] = ???;  //  dest_result_addr=1152921509934297920 |  dest_result_addr=1152921509934297928
        // 0x02731798: STP x29, x30, [sp, #0x20]  | stack[1152921509934297936] = ???;  stack[1152921509934297944] = ???;  //  dest_result_addr=1152921509934297936 |  dest_result_addr=1152921509934297944
        // 0x0273179C: ADD x29, sp, #0x20         | X29 = (1152921509934297904 + 32) = 1152921509934297936 (0x100000013D8A7350);
        // 0x027317A0: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x027317A4: LDRB w8, [x20, #0xac9]     | W8 = (bool)static_value_03743AC9;       
        // 0x027317A8: MOV x19, x0                | X19 = 1152921509934309952 (0x100000013D8AA240);//ML01
        // 0x027317AC: TBNZ w8, #0, #0x27317c8    | if (static_value_03743AC9 == true) goto label_0;
        // 0x027317B0: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
        // 0x027317B4: LDR x8, [x8, #0xb70]       | X8 = 0x2B929CC;                         
        // 0x027317B8: LDR w0, [x8]               | W0 = 0x2138;                            
        // 0x027317BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2138, ????);     
        // 0x027317C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x027317C4: STRB w8, [x20, #0xac9]     | static_value_03743AC9 = true;            //  dest_result_addr=57948873
        label_0:
        // 0x027317C8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x027317CC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x027317D0: LDR x20, [x19, #0x40]      | X20 = this.m_materialLum; //P2          
        // 0x027317D4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x027317D8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x027317DC: TBZ w8, #0, #0x27317ec     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x027317E0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x027317E4: CBNZ w8, #0x27317ec        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x027317E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x027317EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027317F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027317F4: MOV x1, x20                | X1 = this.m_materialLum;//m1            
        // 0x027317F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027317FC: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.m_materialLum);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.m_materialLum);
        // 0x02731800: TBZ w0, #0, #0x2731844     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x02731804: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x02731808: LDR x21, [x19, #0x38]      | X21 = this.shaderLum; //P2              
        // 0x0273180C: LDR x8, [x8, #0x40]        | X8 = 1152921504696356864;               
        // 0x02731810: LDR x0, [x8]               | X0 = typeof(UnityEngine.Material);      
        UnityEngine.Material val_2 = null;
        // 0x02731814: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Material), ????);
        // 0x02731818: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0273181C: MOV x1, x21                | X1 = this.shaderLum;//m1                
        // 0x02731820: MOV x20, x0                | X20 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x02731824: BL #0x1a77bd8              | .ctor(shader:  this.shaderLum);         
        val_2 = new UnityEngine.Material(shader:  this.shaderLum);
        // 0x02731828: STR x20, [x19, #0x40]      | this.m_materialLum = typeof(UnityEngine.Material);  //  dest_result_addr=1152921509934310016
        this.m_materialLum = val_2;
        // 0x0273182C: CBNZ x20, #0x2731834       | if ( != 0) goto label_4;                
        if(null != 0)
        {
            goto label_4;
        }
        // 0x02731830: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(shader:  this.shaderLum), ????);
        label_4:
        // 0x02731834: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731838: MOVZ w1, #0x3d             | W1 = 61 (0x3D);//ML01                   
        // 0x0273183C: MOV x0, x20                | X0 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x02731840: BL #0x1b77b04              | set_hideFlags(value:  61);              
        hideFlags = 61;
        label_3:
        // 0x02731844: LDR x0, [x19, #0x40]       | X0 = this.m_materialLum; //P2           
        // 0x02731848: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0273184C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02731850: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02731854: RET                        |  return (UnityEngine.Material)this.m_materialLum;
        return this.m_materialLum;
        //  |  // // {name=val_0, type=UnityEngine.Material, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02731858 (41097304), len: 200  VirtAddr: 0x02731858 RVA: 0x02731858 token: 100663370 methodIndex: 24322 delegateWrapperIndex: 0 methodInvoker: 0
    protected UnityEngine.Material get_materialReduce()
    {
        //
        // Disasemble & Code
        // 0x02731858: STP x22, x21, [sp, #-0x30]! | stack[1152921509934434480] = ???;  stack[1152921509934434488] = ???;  //  dest_result_addr=1152921509934434480 |  dest_result_addr=1152921509934434488
        // 0x0273185C: STP x20, x19, [sp, #0x10]  | stack[1152921509934434496] = ???;  stack[1152921509934434504] = ???;  //  dest_result_addr=1152921509934434496 |  dest_result_addr=1152921509934434504
        // 0x02731860: STP x29, x30, [sp, #0x20]  | stack[1152921509934434512] = ???;  stack[1152921509934434520] = ???;  //  dest_result_addr=1152921509934434512 |  dest_result_addr=1152921509934434520
        // 0x02731864: ADD x29, sp, #0x20         | X29 = (1152921509934434480 + 32) = 1152921509934434512 (0x100000013D8C88D0);
        // 0x02731868: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0273186C: LDRB w8, [x20, #0xaca]     | W8 = (bool)static_value_03743ACA;       
        // 0x02731870: MOV x19, x0                | X19 = 1152921509934446528 (0x100000013D8CB7C0);//ML01
        // 0x02731874: TBNZ w8, #0, #0x2731890    | if (static_value_03743ACA == true) goto label_0;
        // 0x02731878: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x0273187C: LDR x8, [x8, #0x558]       | X8 = 0x2B929D0;                         
        // 0x02731880: LDR w0, [x8]               | W0 = 0x2139;                            
        // 0x02731884: BL #0x2782188              | X0 = sub_2782188( ?? 0x2139, ????);     
        // 0x02731888: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0273188C: STRB w8, [x20, #0xaca]     | static_value_03743ACA = true;            //  dest_result_addr=57948874
        label_0:
        // 0x02731890: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02731894: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02731898: LDR x20, [x19, #0x50]      | X20 = this.m_materialReduce; //P2       
        // 0x0273189C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x027318A0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x027318A4: TBZ w8, #0, #0x27318b4     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x027318A8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x027318AC: CBNZ w8, #0x27318b4        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x027318B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x027318B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027318B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027318BC: MOV x1, x20                | X1 = this.m_materialReduce;//m1         
        // 0x027318C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027318C4: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.m_materialReduce);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.m_materialReduce);
        // 0x027318C8: TBZ w0, #0, #0x273190c     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x027318CC: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x027318D0: LDR x21, [x19, #0x48]      | X21 = this.shaderReduce; //P2           
        // 0x027318D4: LDR x8, [x8, #0x40]        | X8 = 1152921504696356864;               
        // 0x027318D8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Material);      
        UnityEngine.Material val_2 = null;
        // 0x027318DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Material), ????);
        // 0x027318E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027318E4: MOV x1, x21                | X1 = this.shaderReduce;//m1             
        // 0x027318E8: MOV x20, x0                | X20 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x027318EC: BL #0x1a77bd8              | .ctor(shader:  this.shaderReduce);      
        val_2 = new UnityEngine.Material(shader:  this.shaderReduce);
        // 0x027318F0: STR x20, [x19, #0x50]      | this.m_materialReduce = typeof(UnityEngine.Material);  //  dest_result_addr=1152921509934446608
        this.m_materialReduce = val_2;
        // 0x027318F4: CBNZ x20, #0x27318fc       | if ( != 0) goto label_4;                
        if(null != 0)
        {
            goto label_4;
        }
        // 0x027318F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(shader:  this.shaderReduce), ????);
        label_4:
        // 0x027318FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731900: MOVZ w1, #0x3d             | W1 = 61 (0x3D);//ML01                   
        // 0x02731904: MOV x0, x20                | X0 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x02731908: BL #0x1b77b04              | set_hideFlags(value:  61);              
        hideFlags = 61;
        label_3:
        // 0x0273190C: LDR x0, [x19, #0x50]       | X0 = this.m_materialReduce; //P2        
        // 0x02731910: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02731914: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02731918: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0273191C: RET                        |  return (UnityEngine.Material)this.m_materialReduce;
        return this.m_materialReduce;
        //  |  // // {name=val_0, type=UnityEngine.Material, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02731920 (41097504), len: 200  VirtAddr: 0x02731920 RVA: 0x02731920 token: 100663371 methodIndex: 24323 delegateWrapperIndex: 0 methodInvoker: 0
    protected UnityEngine.Material get_materialAdapt()
    {
        //
        // Disasemble & Code
        // 0x02731920: STP x22, x21, [sp, #-0x30]! | stack[1152921509934571056] = ???;  stack[1152921509934571064] = ???;  //  dest_result_addr=1152921509934571056 |  dest_result_addr=1152921509934571064
        // 0x02731924: STP x20, x19, [sp, #0x10]  | stack[1152921509934571072] = ???;  stack[1152921509934571080] = ???;  //  dest_result_addr=1152921509934571072 |  dest_result_addr=1152921509934571080
        // 0x02731928: STP x29, x30, [sp, #0x20]  | stack[1152921509934571088] = ???;  stack[1152921509934571096] = ???;  //  dest_result_addr=1152921509934571088 |  dest_result_addr=1152921509934571096
        // 0x0273192C: ADD x29, sp, #0x20         | X29 = (1152921509934571056 + 32) = 1152921509934571088 (0x100000013D8E9E50);
        // 0x02731930: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x02731934: LDRB w8, [x20, #0xacb]     | W8 = (bool)static_value_03743ACB;       
        // 0x02731938: MOV x19, x0                | X19 = 1152921509934583104 (0x100000013D8ECD40);//ML01
        // 0x0273193C: TBNZ w8, #0, #0x2731958    | if (static_value_03743ACB == true) goto label_0;
        // 0x02731940: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x02731944: LDR x8, [x8, #0xba0]       | X8 = 0x2B929C4;                         
        // 0x02731948: LDR w0, [x8]               | W0 = 0x2136;                            
        // 0x0273194C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2136, ????);     
        // 0x02731950: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02731954: STRB w8, [x20, #0xacb]     | static_value_03743ACB = true;            //  dest_result_addr=57948875
        label_0:
        // 0x02731958: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x0273195C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02731960: LDR x20, [x19, #0x60]      | X20 = this.m_materialAdapt; //P2        
        // 0x02731964: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02731968: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0273196C: TBZ w8, #0, #0x273197c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02731970: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731974: CBNZ w8, #0x273197c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02731978: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x0273197C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731980: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731984: MOV x1, x20                | X1 = this.m_materialAdapt;//m1          
        // 0x02731988: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0273198C: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.m_materialAdapt);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.m_materialAdapt);
        // 0x02731990: TBZ w0, #0, #0x27319d4     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x02731994: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x02731998: LDR x21, [x19, #0x58]      | X21 = this.shaderAdapt; //P2            
        // 0x0273199C: LDR x8, [x8, #0x40]        | X8 = 1152921504696356864;               
        // 0x027319A0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Material);      
        UnityEngine.Material val_2 = null;
        // 0x027319A4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Material), ????);
        // 0x027319A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027319AC: MOV x1, x21                | X1 = this.shaderAdapt;//m1              
        // 0x027319B0: MOV x20, x0                | X20 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x027319B4: BL #0x1a77bd8              | .ctor(shader:  this.shaderAdapt);       
        val_2 = new UnityEngine.Material(shader:  this.shaderAdapt);
        // 0x027319B8: STR x20, [x19, #0x60]      | this.m_materialAdapt = typeof(UnityEngine.Material);  //  dest_result_addr=1152921509934583200
        this.m_materialAdapt = val_2;
        // 0x027319BC: CBNZ x20, #0x27319c4       | if ( != 0) goto label_4;                
        if(null != 0)
        {
            goto label_4;
        }
        // 0x027319C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(shader:  this.shaderAdapt), ????);
        label_4:
        // 0x027319C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027319C8: MOVZ w1, #0x3d             | W1 = 61 (0x3D);//ML01                   
        // 0x027319CC: MOV x0, x20                | X0 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x027319D0: BL #0x1b77b04              | set_hideFlags(value:  61);              
        hideFlags = 61;
        label_3:
        // 0x027319D4: LDR x0, [x19, #0x60]       | X0 = this.m_materialAdapt; //P2         
        // 0x027319D8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x027319DC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x027319E0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x027319E4: RET                        |  return (UnityEngine.Material)this.m_materialAdapt;
        return this.m_materialAdapt;
        //  |  // // {name=val_0, type=UnityEngine.Material, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x027319E8 (41097704), len: 200  VirtAddr: 0x027319E8 RVA: 0x027319E8 token: 100663372 methodIndex: 24324 delegateWrapperIndex: 0 methodInvoker: 0
    protected UnityEngine.Material get_materialApply()
    {
        //
        // Disasemble & Code
        // 0x027319E8: STP x22, x21, [sp, #-0x30]! | stack[1152921509934707632] = ???;  stack[1152921509934707640] = ???;  //  dest_result_addr=1152921509934707632 |  dest_result_addr=1152921509934707640
        // 0x027319EC: STP x20, x19, [sp, #0x10]  | stack[1152921509934707648] = ???;  stack[1152921509934707656] = ???;  //  dest_result_addr=1152921509934707648 |  dest_result_addr=1152921509934707656
        // 0x027319F0: STP x29, x30, [sp, #0x20]  | stack[1152921509934707664] = ???;  stack[1152921509934707672] = ???;  //  dest_result_addr=1152921509934707664 |  dest_result_addr=1152921509934707672
        // 0x027319F4: ADD x29, sp, #0x20         | X29 = (1152921509934707632 + 32) = 1152921509934707664 (0x100000013D90B3D0);
        // 0x027319F8: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x027319FC: LDRB w8, [x20, #0xacc]     | W8 = (bool)static_value_03743ACC;       
        // 0x02731A00: MOV x19, x0                | X19 = 1152921509934719680 (0x100000013D90E2C0);//ML01
        // 0x02731A04: TBNZ w8, #0, #0x2731a20    | if (static_value_03743ACC == true) goto label_0;
        // 0x02731A08: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x02731A0C: LDR x8, [x8, #0x400]       | X8 = 0x2B929C8;                         
        // 0x02731A10: LDR w0, [x8]               | W0 = 0x2137;                            
        // 0x02731A14: BL #0x2782188              | X0 = sub_2782188( ?? 0x2137, ????);     
        // 0x02731A18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02731A1C: STRB w8, [x20, #0xacc]     | static_value_03743ACC = true;            //  dest_result_addr=57948876
        label_0:
        // 0x02731A20: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02731A24: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02731A28: LDR x20, [x19, #0x70]      | X20 = this.m_materialApply; //P2        
        // 0x02731A2C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02731A30: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731A34: TBZ w8, #0, #0x2731a44     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02731A38: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731A3C: CBNZ w8, #0x2731a44        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02731A40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x02731A44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731A48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731A4C: MOV x1, x20                | X1 = this.m_materialApply;//m1          
        // 0x02731A50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02731A54: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.m_materialApply);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.m_materialApply);
        // 0x02731A58: TBZ w0, #0, #0x2731a9c     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x02731A5C: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x02731A60: LDR x21, [x19, #0x68]      | X21 = this.shaderApply; //P2            
        // 0x02731A64: LDR x8, [x8, #0x40]        | X8 = 1152921504696356864;               
        // 0x02731A68: LDR x0, [x8]               | X0 = typeof(UnityEngine.Material);      
        UnityEngine.Material val_2 = null;
        // 0x02731A6C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Material), ????);
        // 0x02731A70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731A74: MOV x1, x21                | X1 = this.shaderApply;//m1              
        // 0x02731A78: MOV x20, x0                | X20 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x02731A7C: BL #0x1a77bd8              | .ctor(shader:  this.shaderApply);       
        val_2 = new UnityEngine.Material(shader:  this.shaderApply);
        // 0x02731A80: STR x20, [x19, #0x70]      | this.m_materialApply = typeof(UnityEngine.Material);  //  dest_result_addr=1152921509934719792
        this.m_materialApply = val_2;
        // 0x02731A84: CBNZ x20, #0x2731a8c       | if ( != 0) goto label_4;                
        if(null != 0)
        {
            goto label_4;
        }
        // 0x02731A88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(shader:  this.shaderApply), ????);
        label_4:
        // 0x02731A8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731A90: MOVZ w1, #0x3d             | W1 = 61 (0x3D);//ML01                   
        // 0x02731A94: MOV x0, x20                | X0 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x02731A98: BL #0x1b77b04              | set_hideFlags(value:  61);              
        hideFlags = 61;
        label_3:
        // 0x02731A9C: LDR x0, [x19, #0x70]       | X0 = this.m_materialApply; //P2         
        // 0x02731AA0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02731AA4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02731AA8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02731AAC: RET                        |  return (UnityEngine.Material)this.m_materialApply;
        return this.m_materialApply;
        //  |  // // {name=val_0, type=UnityEngine.Material, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02731AB0 (41097904), len: 188  VirtAddr: 0x02731AB0 RVA: 0x02731AB0 token: 100663373 methodIndex: 24325 delegateWrapperIndex: 0 methodInvoker: 0
    private void Start()
    {
        //
        // Disasemble & Code
        // 0x02731AB0: STP x20, x19, [sp, #-0x20]! | stack[1152921509934848320] = ???;  stack[1152921509934848328] = ???;  //  dest_result_addr=1152921509934848320 |  dest_result_addr=1152921509934848328
        // 0x02731AB4: STP x29, x30, [sp, #0x10]  | stack[1152921509934848336] = ???;  stack[1152921509934848344] = ???;  //  dest_result_addr=1152921509934848336 |  dest_result_addr=1152921509934848344
        // 0x02731AB8: ADD x29, sp, #0x10         | X29 = (1152921509934848320 + 16) = 1152921509934848336 (0x100000013D92D950);
        // 0x02731ABC: MOV x19, x0                | X19 = 1152921509934860352 (0x100000013D930840);//ML01
        // 0x02731AC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731AC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731AC8: BL #0x268dde8              | X0 = UnityEngine.SystemInfo.get_supportsImageEffects();
        bool val_1 = UnityEngine.SystemInfo.supportsImageEffects;
        // 0x02731ACC: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x02731AD0: TBZ w8, #0, #0x2731b54     | if ((val_1 & 1) == false) goto label_8; 
        if(val_2 == false)
        {
            goto label_8;
        }
        // 0x02731AD4: LDR x20, [x19, #0x58]      | X20 = this.shaderAdapt; //P2            
        // 0x02731AD8: CBNZ x20, #0x2731ae0       | if (this.shaderAdapt != null) goto label_1;
        if(this.shaderAdapt != null)
        {
            goto label_1;
        }
        // 0x02731ADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x02731AE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731AE4: MOV x0, x20                | X0 = this.shaderAdapt;//m1              
        // 0x02731AE8: BL #0x1b8e0d8              | X0 = this.shaderAdapt.get_isSupported();
        bool val_3 = this.shaderAdapt.isSupported;
        // 0x02731AEC: TBZ w0, #0, #0x2731b54     | if (val_3 == false) goto label_8;       
        if(val_3 == false)
        {
            goto label_8;
        }
        // 0x02731AF0: LDR x20, [x19, #0x68]      | X20 = this.shaderApply; //P2            
        // 0x02731AF4: CBNZ x20, #0x2731afc       | if (this.shaderApply != null) goto label_3;
        if(this.shaderApply != null)
        {
            goto label_3;
        }
        // 0x02731AF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x02731AFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731B00: MOV x0, x20                | X0 = this.shaderApply;//m1              
        // 0x02731B04: BL #0x1b8e0d8              | X0 = this.shaderApply.get_isSupported();
        bool val_4 = this.shaderApply.isSupported;
        // 0x02731B08: TBZ w0, #0, #0x2731b54     | if (val_4 == false) goto label_8;       
        if(val_4 == false)
        {
            goto label_8;
        }
        // 0x02731B0C: LDR x20, [x19, #0x38]      | X20 = this.shaderLum; //P2              
        // 0x02731B10: CBNZ x20, #0x2731b18       | if (this.shaderLum != null) goto label_5;
        if(this.shaderLum != null)
        {
            goto label_5;
        }
        // 0x02731B14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_5:
        // 0x02731B18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731B1C: MOV x0, x20                | X0 = this.shaderLum;//m1                
        // 0x02731B20: BL #0x1b8e0d8              | X0 = this.shaderLum.get_isSupported();  
        bool val_5 = this.shaderLum.isSupported;
        // 0x02731B24: TBZ w0, #0, #0x2731b54     | if (val_5 == false) goto label_8;       
        if(val_5 == false)
        {
            goto label_8;
        }
        // 0x02731B28: LDR x20, [x19, #0x48]      | X20 = this.shaderReduce; //P2           
        // 0x02731B2C: CBNZ x20, #0x2731b34       | if (this.shaderReduce != null) goto label_7;
        if(this.shaderReduce != null)
        {
            goto label_7;
        }
        // 0x02731B30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x02731B34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731B38: MOV x0, x20                | X0 = this.shaderReduce;//m1             
        // 0x02731B3C: BL #0x1b8e0d8              | X0 = this.shaderReduce.get_isSupported();
        bool val_6 = this.shaderReduce.isSupported;
        // 0x02731B40: AND w8, w0, #1             | W8 = (val_6 & 1);                       
        bool val_7 = val_6;
        // 0x02731B44: TBZ w8, #0, #0x2731b54     | if ((val_6 & 1) == false) goto label_8; 
        if(val_7 == false)
        {
            goto label_8;
        }
        // 0x02731B48: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02731B4C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02731B50: RET                        |  return;                                
        return;
        label_8:
        // 0x02731B54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02731B58: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02731B5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731B60: MOV x0, x19                | X0 = 1152921509934860352 (0x100000013D930840);//ML01
        // 0x02731B64: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02731B68: B #0x20cb458               | this.set_enabled(value:  false); return;
        this.enabled = false;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02731B6C (41098092), len: 384  VirtAddr: 0x02731B6C RVA: 0x02731B6C token: 100663374 methodIndex: 24326 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnEnable()
    {
        //
        // Disasemble & Code
        // 0x02731B6C: STP x24, x23, [sp, #-0x40]! | stack[1152921509935095456] = ???;  stack[1152921509935095464] = ???;  //  dest_result_addr=1152921509935095456 |  dest_result_addr=1152921509935095464
        // 0x02731B70: STP x22, x21, [sp, #0x10]  | stack[1152921509935095472] = ???;  stack[1152921509935095480] = ???;  //  dest_result_addr=1152921509935095472 |  dest_result_addr=1152921509935095480
        // 0x02731B74: STP x20, x19, [sp, #0x20]  | stack[1152921509935095488] = ???;  stack[1152921509935095496] = ???;  //  dest_result_addr=1152921509935095488 |  dest_result_addr=1152921509935095496
        // 0x02731B78: STP x29, x30, [sp, #0x30]  | stack[1152921509935095504] = ???;  stack[1152921509935095512] = ???;  //  dest_result_addr=1152921509935095504 |  dest_result_addr=1152921509935095512
        // 0x02731B7C: ADD x29, sp, #0x30         | X29 = (1152921509935095456 + 48) = 1152921509935095504 (0x100000013D969ED0);
        // 0x02731B80: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x02731B84: LDRB w8, [x20, #0xacd]     | W8 = (bool)static_value_03743ACD;       
        // 0x02731B88: MOV x19, x0                | X19 = 1152921509935107520 (0x100000013D96CDC0);//ML01
        // 0x02731B8C: TBNZ w8, #0, #0x2731ba8    | if (static_value_03743ACD == true) goto label_0;
        // 0x02731B90: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
        // 0x02731B94: LDR x8, [x8, #0xed8]       | X8 = 0x2B929D8;                         
        // 0x02731B98: LDR w0, [x8]               | W0 = 0x213B;                            
        // 0x02731B9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x213B, ????);     
        // 0x02731BA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02731BA4: STRB w8, [x20, #0xacd]     | static_value_03743ACD = true;            //  dest_result_addr=57948877
        label_0:
        // 0x02731BA8: ADRP x22, #0x35fe000       | X22 = 56614912 (0x35FE000);             
        // 0x02731BAC: ADRP x23, #0x364f000       | X23 = 56946688 (0x364F000);             
        // 0x02731BB0: LDR x22, [x22, #0x810]     | X22 = 1152921504697475072;              
        // 0x02731BB4: LDR x23, [x23, #0x9e8]     | X23 = 1152921504697315328;              
        // 0x02731BB8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        var val_6 = 0;
        label_13:
        // 0x02731BBC: LDR x20, [x19, #0x28]      | X20 = this.adaptRenderTex; //P2         
        // 0x02731BC0: CBNZ x20, #0x2731bc8       | if (this.adaptRenderTex != null) goto label_1;
        if(this.adaptRenderTex != null)
        {
            goto label_1;
        }
        // 0x02731BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x213B, ????);     
        label_1:
        // 0x02731BC8: LDR w8, [x20, #0x18]       | W8 = this.adaptRenderTex.Length; //P2   
        // 0x02731BCC: CMP x21, x8                | STATE = COMPARE(0x0, this.adaptRenderTex.Length)
        // 0x02731BD0: B.LO #0x2731be0            | if (0 < this.adaptRenderTex.Length) goto label_2;
        if(val_6 < this.adaptRenderTex.Length)
        {
            goto label_2;
        }
        // 0x02731BD4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x213B, ????);     
        // 0x02731BD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731BDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x213B, ????);     
        label_2:
        // 0x02731BE0: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731BE4: ADD x8, x20, x21, lsl #3   | X8 = this.adaptRenderTex[0x0]; //PARR1  
        // 0x02731BE8: LDR x20, [x8, #0x20]       | X20 = this.adaptRenderTex[0x0][0]       
        UnityEngine.RenderTexture val_4 = this.adaptRenderTex[val_6];
        // 0x02731BEC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731BF0: TBZ w8, #0, #0x2731c00     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x02731BF4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731BF8: CBNZ w8, #0x2731c00        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x02731BFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x02731C00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731C04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731C08: MOV x1, x20                | X1 = this.adaptRenderTex[0x0][0];//m1   
        // 0x02731C0C: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02731C10: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x02731C14: TBNZ w8, #0, #0x2731ccc    | if ((val_1 & 1) == true) goto label_5;  
        if(val_2 == true)
        {
            goto label_5;
        }
        // 0x02731C18: LDR x0, [x23]              | X0 = typeof(UnityEngine.RenderTexture); 
        UnityEngine.RenderTexture val_3 = null;
        // 0x02731C1C: LDR x24, [x19, #0x28]      | X24 = this.adaptRenderTex; //P2         
        // 0x02731C20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.RenderTexture), ????);
        // 0x02731C24: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02731C28: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02731C2C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02731C30: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02731C34: MOV x20, x0                | X20 = 1152921504697315328 (0x1000000005647000);//ML01
        // 0x02731C38: BL #0x1b889e8              | .ctor(width:  1, height:  1, depth:  0);
        val_3 = new UnityEngine.RenderTexture(width:  1, height:  1, depth:  0);
        // 0x02731C3C: CBNZ x24, #0x2731c44       | if (this.adaptRenderTex != null) goto label_6;
        if(this.adaptRenderTex != null)
        {
            goto label_6;
        }
        // 0x02731C40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(width:  1, height:  1, depth:  0), ????);
        label_6:
        // 0x02731C44: CBZ x20, #0x2731c68        | if ( == 0) goto label_8;                
        if(null == 0)
        {
            goto label_8;
        }
        // 0x02731C48: LDR x8, [x24]              | X8 = typeof(UnityEngine.RenderTexture[]);
        // 0x02731C4C: MOV x0, x20                | X0 = 1152921504697315328 (0x1000000005647000);//ML01
        // 0x02731C50: LDR x1, [x8, #0x30]        | X1 = UnityEngine.RenderTexture[].__il2cppRuntimeField_element_class;
        // 0x02731C54: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(UnityEngine.RenderTexture), ????);
        // 0x02731C58: CBNZ x0, #0x2731c68        | if ( != 0) goto label_8;                
        if(null != 0)
        {
            goto label_8;
        }
        // 0x02731C5C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(UnityEngine.RenderTexture), ????);
        // 0x02731C60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731C64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.RenderTexture), ????);
        label_8:
        // 0x02731C68: LDR w8, [x24, #0x18]       | W8 = this.adaptRenderTex.Length; //P2   
        // 0x02731C6C: CMP x21, x8                | STATE = COMPARE(0x0, this.adaptRenderTex.Length)
        // 0x02731C70: B.LO #0x2731c80            | if (0 < this.adaptRenderTex.Length) goto label_9;
        if(val_6 < this.adaptRenderTex.Length)
        {
            goto label_9;
        }
        // 0x02731C74: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.RenderTexture), ????);
        // 0x02731C78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731C7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.RenderTexture), ????);
        label_9:
        // 0x02731C80: ADD x8, x24, x21, lsl #3   | X8 = this.adaptRenderTex[0x0]; //PARR1  
        // 0x02731C84: STR x20, [x8, #0x20]       | this.adaptRenderTex[0x0][0] = typeof(UnityEngine.RenderTexture);  //  dest_result_addr=0
        this.adaptRenderTex[val_6] = val_3;
        // 0x02731C88: LDR x20, [x19, #0x28]      | X20 = this.adaptRenderTex; //P2         
        // 0x02731C8C: CBNZ x20, #0x2731c94       | if (this.adaptRenderTex != null) goto label_10;
        if(this.adaptRenderTex != null)
        {
            goto label_10;
        }
        // 0x02731C90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.RenderTexture), ????);
        label_10:
        // 0x02731C94: LDR w8, [x20, #0x18]       | W8 = this.adaptRenderTex.Length; //P2   
        // 0x02731C98: CMP x21, x8                | STATE = COMPARE(0x0, this.adaptRenderTex.Length)
        // 0x02731C9C: B.LO #0x2731cac            | if (0 < this.adaptRenderTex.Length) goto label_11;
        if(val_6 < this.adaptRenderTex.Length)
        {
            goto label_11;
        }
        // 0x02731CA0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.RenderTexture), ????);
        // 0x02731CA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731CA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.RenderTexture), ????);
        label_11:
        // 0x02731CAC: ADD x8, x20, x21, lsl #3   | X8 = this.adaptRenderTex[0x0]; //PARR1  
        // 0x02731CB0: LDR x20, [x8, #0x20]       | X20 = this.adaptRenderTex[0x0][0]       
        UnityEngine.RenderTexture val_5 = this.adaptRenderTex[val_6];
        // 0x02731CB4: CBNZ x20, #0x2731cbc       | if (this.adaptRenderTex[0x0][0] != null) goto label_12;
        if(val_5 != null)
        {
            goto label_12;
        }
        // 0x02731CB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.RenderTexture), ????);
        label_12:
        // 0x02731CBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731CC0: MOVZ w1, #0x3d             | W1 = 61 (0x3D);//ML01                   
        // 0x02731CC4: MOV x0, x20                | X0 = this.adaptRenderTex[0x0][0];//m1   
        // 0x02731CC8: BL #0x1b77b04              | this.adaptRenderTex[0x0][0].set_hideFlags(value:  61);
        val_5.hideFlags = 61;
        label_5:
        // 0x02731CCC: ADD x21, x21, #1           | X21 = (0 + 1);                          
        val_6 = val_6 + 1;
        // 0x02731CD0: CMP x21, #2                | STATE = COMPARE((0 + 1), 0x2)           
        // 0x02731CD4: B.NE #0x2731bbc            | if (0 != 0x2) goto label_13;            
        if(val_6 != 2)
        {
            goto label_13;
        }
        // 0x02731CD8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x02731CDC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02731CE0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x02731CE4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x02731CE8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02731CEC (41098476), len: 604  VirtAddr: 0x02731CEC RVA: 0x02731CEC token: 100663375 methodIndex: 24327 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnDisable()
    {
        //
        // Disasemble & Code
        // 0x02731CEC: STP x22, x21, [sp, #-0x30]! | stack[1152921509935436848] = ???;  stack[1152921509935436856] = ???;  //  dest_result_addr=1152921509935436848 |  dest_result_addr=1152921509935436856
        // 0x02731CF0: STP x20, x19, [sp, #0x10]  | stack[1152921509935436864] = ???;  stack[1152921509935436872] = ???;  //  dest_result_addr=1152921509935436864 |  dest_result_addr=1152921509935436872
        // 0x02731CF4: STP x29, x30, [sp, #0x20]  | stack[1152921509935436880] = ???;  stack[1152921509935436888] = ???;  //  dest_result_addr=1152921509935436880 |  dest_result_addr=1152921509935436888
        // 0x02731CF8: ADD x29, sp, #0x20         | X29 = (1152921509935436848 + 32) = 1152921509935436880 (0x100000013D9BD450);
        // 0x02731CFC: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x02731D00: LDRB w8, [x20, #0xace]     | W8 = (bool)static_value_03743ACE;       
        // 0x02731D04: MOV x19, x0                | X19 = 1152921509935448896 (0x100000013D9C0340);//ML01
        // 0x02731D08: TBNZ w8, #0, #0x2731d24    | if (static_value_03743ACE == true) goto label_0;
        // 0x02731D0C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x02731D10: LDR x8, [x8, #0x828]       | X8 = 0x2B929D4;                         
        // 0x02731D14: LDR w0, [x8]               | W0 = 0x213A;                            
        // 0x02731D18: BL #0x2782188              | X0 = sub_2782188( ?? 0x213A, ????);     
        // 0x02731D1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02731D20: STRB w8, [x20, #0xace]     | static_value_03743ACE = true;            //  dest_result_addr=57948878
        label_0:
        // 0x02731D24: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x02731D28: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x02731D2C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        var val_6 = 0;
        label_7:
        // 0x02731D30: LDR x20, [x19, #0x28]      | X20 = this.adaptRenderTex; //P2         
        // 0x02731D34: CBNZ x20, #0x2731d3c       | if (this.adaptRenderTex != null) goto label_1;
        if(this.adaptRenderTex != null)
        {
            goto label_1;
        }
        // 0x02731D38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x213A, ????);     
        label_1:
        // 0x02731D3C: LDR w8, [x20, #0x18]       | W8 = this.adaptRenderTex.Length; //P2   
        // 0x02731D40: CMP x22, x8                | STATE = COMPARE(0x0, this.adaptRenderTex.Length)
        // 0x02731D44: B.LO #0x2731d54            | if (0 < this.adaptRenderTex.Length) goto label_2;
        if(val_6 < this.adaptRenderTex.Length)
        {
            goto label_2;
        }
        // 0x02731D48: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x213A, ????);     
        // 0x02731D4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731D50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x213A, ????);     
        label_2:
        // 0x02731D54: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731D58: ADD x8, x20, x22, lsl #3   | X8 = this.adaptRenderTex[0x0]; //PARR1  
        // 0x02731D5C: LDR x20, [x8, #0x20]       | X20 = this.adaptRenderTex[0x0][0]       
        UnityEngine.RenderTexture val_5 = this.adaptRenderTex[val_6];
        // 0x02731D60: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731D64: TBZ w8, #0, #0x2731d74     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x02731D68: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731D6C: CBNZ w8, #0x2731d74        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x02731D70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x02731D74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731D78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731D7C: MOV x1, x20                | X1 = this.adaptRenderTex[0x0][0];//m1   
        // 0x02731D80: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        // 0x02731D84: LDR x20, [x19, #0x28]      | X20 = this.adaptRenderTex; //P2         
        // 0x02731D88: CBNZ x20, #0x2731d90       | if (this.adaptRenderTex != null) goto label_5;
        if(this.adaptRenderTex != null)
        {
            goto label_5;
        }
        // 0x02731D8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_5:
        // 0x02731D90: LDR w8, [x20, #0x18]       | W8 = this.adaptRenderTex.Length; //P2   
        // 0x02731D94: CMP x22, x8                | STATE = COMPARE(0x0, this.adaptRenderTex.Length)
        // 0x02731D98: B.LO #0x2731da8            | if (0 < this.adaptRenderTex.Length) goto label_6;
        if(val_6 < this.adaptRenderTex.Length)
        {
            goto label_6;
        }
        // 0x02731D9C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x02731DA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731DA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_6:
        // 0x02731DA8: ADD x8, x20, x22, lsl #3   | X8 = this.adaptRenderTex[0x0]; //PARR1  
        // 0x02731DAC: ADD x22, x22, #1           | X22 = (0 + 1);                          
        val_6 = val_6 + 1;
        // 0x02731DB0: STR xzr, [x8, #0x20]       | this.adaptRenderTex[0x0][0] = null;      //  dest_result_addr=0
        this.adaptRenderTex[val_6] = 0;
        // 0x02731DB4: CMP x22, #2                | STATE = COMPARE((0 + 1), 0x2)           
        // 0x02731DB8: B.NE #0x2731d30            | if (0 != 0x2) goto label_7;             
        if(val_6 != 2)
        {
            goto label_7;
        }
        // 0x02731DBC: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731DC0: LDR x20, [x19, #0x40]      | X20 = this.m_materialLum; //P2          
        // 0x02731DC4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731DC8: TBZ w8, #0, #0x2731dd8     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x02731DCC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731DD0: CBNZ w8, #0x2731dd8        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x02731DD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_9:
        // 0x02731DD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731DDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731DE0: MOV x1, x20                | X1 = this.m_materialLum;//m1            
        // 0x02731DE4: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02731DE8: TBZ w0, #0, #0x2731e18     | if (val_1 == false) goto label_10;      
        if(val_1 == false)
        {
            goto label_10;
        }
        // 0x02731DEC: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731DF0: LDR x20, [x19, #0x40]      | X20 = this.m_materialLum; //P2          
        // 0x02731DF4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731DF8: TBZ w8, #0, #0x2731e08     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x02731DFC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731E00: CBNZ w8, #0x2731e08        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x02731E04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_12:
        // 0x02731E08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731E0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731E10: MOV x1, x20                | X1 = this.m_materialLum;//m1            
        // 0x02731E14: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        label_10:
        // 0x02731E18: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731E1C: LDR x20, [x19, #0x50]      | X20 = this.m_materialReduce; //P2       
        // 0x02731E20: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731E24: TBZ w8, #0, #0x2731e34     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x02731E28: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731E2C: CBNZ w8, #0x2731e34        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x02731E30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_14:
        // 0x02731E34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731E38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731E3C: MOV x1, x20                | X1 = this.m_materialReduce;//m1         
        // 0x02731E40: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_2 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02731E44: TBZ w0, #0, #0x2731e74     | if (val_2 == false) goto label_15;      
        if(val_2 == false)
        {
            goto label_15;
        }
        // 0x02731E48: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731E4C: LDR x20, [x19, #0x50]      | X20 = this.m_materialReduce; //P2       
        // 0x02731E50: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731E54: TBZ w8, #0, #0x2731e64     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x02731E58: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731E5C: CBNZ w8, #0x2731e64        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x02731E60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_17:
        // 0x02731E64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731E68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731E6C: MOV x1, x20                | X1 = this.m_materialReduce;//m1         
        // 0x02731E70: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        label_15:
        // 0x02731E74: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731E78: LDR x20, [x19, #0x60]      | X20 = this.m_materialAdapt; //P2        
        // 0x02731E7C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731E80: TBZ w8, #0, #0x2731e90     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x02731E84: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731E88: CBNZ w8, #0x2731e90        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x02731E8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_19:
        // 0x02731E90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731E94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731E98: MOV x1, x20                | X1 = this.m_materialAdapt;//m1          
        // 0x02731E9C: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_3 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02731EA0: TBZ w0, #0, #0x2731ed0     | if (val_3 == false) goto label_20;      
        if(val_3 == false)
        {
            goto label_20;
        }
        // 0x02731EA4: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731EA8: LDR x20, [x19, #0x60]      | X20 = this.m_materialAdapt; //P2        
        // 0x02731EAC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731EB0: TBZ w8, #0, #0x2731ec0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_22;
        // 0x02731EB4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731EB8: CBNZ w8, #0x2731ec0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
        // 0x02731EBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_22:
        // 0x02731EC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731EC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731EC8: MOV x1, x20                | X1 = this.m_materialAdapt;//m1          
        // 0x02731ECC: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        label_20:
        // 0x02731ED0: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731ED4: LDR x20, [x19, #0x70]      | X20 = this.m_materialApply; //P2        
        // 0x02731ED8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731EDC: TBZ w8, #0, #0x2731eec     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_24;
        // 0x02731EE0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731EE4: CBNZ w8, #0x2731eec        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
        // 0x02731EE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_24:
        // 0x02731EEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731EF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731EF4: MOV x1, x20                | X1 = this.m_materialApply;//m1          
        // 0x02731EF8: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_4 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02731EFC: TBZ w0, #0, #0x2731f38     | if (val_4 == false) goto label_25;      
        if(val_4 == false)
        {
            goto label_25;
        }
        // 0x02731F00: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02731F04: LDR x19, [x19, #0x70]      | X19 = this.m_materialApply; //P2        
        // 0x02731F08: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02731F0C: TBZ w8, #0, #0x2731f1c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x02731F10: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02731F14: CBNZ w8, #0x2731f1c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x02731F18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_27:
        // 0x02731F1C: MOV x1, x19                | X1 = this.m_materialApply;//m1          
        // 0x02731F20: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02731F24: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02731F28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731F2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731F30: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02731F34: B #0x1b78bac               | UnityEngine.Object.DestroyImmediate(obj:  0); return;
        UnityEngine.Object.DestroyImmediate(obj:  0);
        return;
        label_25:
        // 0x02731F38: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02731F3C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02731F40: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02731F44: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02731F48 (41099080), len: 672  VirtAddr: 0x02731F48 RVA: 0x02731F48 token: 100663376 methodIndex: 24328 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.RenderTexture val_11;
        //  | 
        var val_12;
        // 0x02731F48: STP x26, x25, [sp, #-0x50]! | stack[1152921509935733232] = ???;  stack[1152921509935733240] = ???;  //  dest_result_addr=1152921509935733232 |  dest_result_addr=1152921509935733240
        // 0x02731F4C: STP x24, x23, [sp, #0x10]  | stack[1152921509935733248] = ???;  stack[1152921509935733256] = ???;  //  dest_result_addr=1152921509935733248 |  dest_result_addr=1152921509935733256
        // 0x02731F50: STP x22, x21, [sp, #0x20]  | stack[1152921509935733264] = ???;  stack[1152921509935733272] = ???;  //  dest_result_addr=1152921509935733264 |  dest_result_addr=1152921509935733272
        // 0x02731F54: STP x20, x19, [sp, #0x30]  | stack[1152921509935733280] = ???;  stack[1152921509935733288] = ???;  //  dest_result_addr=1152921509935733280 |  dest_result_addr=1152921509935733288
        // 0x02731F58: STP x29, x30, [sp, #0x40]  | stack[1152921509935733296] = ???;  stack[1152921509935733304] = ???;  //  dest_result_addr=1152921509935733296 |  dest_result_addr=1152921509935733304
        // 0x02731F5C: ADD x29, sp, #0x40         | X29 = (1152921509935733232 + 64) = 1152921509935733296 (0x100000013DA05A30);
        // 0x02731F60: ADRP x22, #0x3743000       | X22 = 57946112 (0x3743000);             
        // 0x02731F64: LDRB w8, [x22, #0xacf]     | W8 = (bool)static_value_03743ACF;       
        // 0x02731F68: MOV x19, x2                | X19 = destination;//m1                  
        // 0x02731F6C: MOV x20, x1                | X20 = source;//m1                       
        // 0x02731F70: MOV x21, x0                | X21 = 1152921509935745312 (0x100000013DA08920);//ML01
        // 0x02731F74: TBNZ w8, #0, #0x2731f90    | if (static_value_03743ACF == true) goto label_0;
        // 0x02731F78: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
        // 0x02731F7C: LDR x8, [x8, #0x250]       | X8 = 0x2B929DC;                         
        // 0x02731F80: LDR w0, [x8]               | W0 = 0x213C;                            
        // 0x02731F84: BL #0x2782188              | X0 = sub_2782188( ?? 0x213C, ????);     
        // 0x02731F88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02731F8C: STRB w8, [x22, #0xacf]     | static_value_03743ACF = true;            //  dest_result_addr=57948879
        label_0:
        // 0x02731F90: CBNZ x20, #0x2731f98       | if (source != null) goto label_1;       
        if(source != null)
        {
            goto label_1;
        }
        // 0x02731F94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x213C, ????);     
        label_1:
        // 0x02731F98: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02731F9C: MOV x0, x20                | X0 = source;//m1                        
        // 0x02731FA0: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02731FA4: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02731FA8: MOV w22, w0                | W22 = source;//m1                       
        // 0x02731FAC: CBNZ x20, #0x2731fb4       | if (source != null) goto label_2;       
        if(source != null)
        {
            goto label_2;
        }
        // 0x02731FB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_2:
        // 0x02731FB4: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02731FB8: MOV x0, x20                | X0 = source;//m1                        
        // 0x02731FBC: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02731FC0: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02731FC4: MOV w2, w0                 | W2 = source;//m1                        
        // 0x02731FC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731FCC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02731FD0: MOV w1, w22                | W1 = source;//m1                        
        // 0x02731FD4: BL #0x1b89198              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        UnityEngine.RenderTexture val_1 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        // 0x02731FD8: MOV x23, x0                | X23 = val_1;//m1                        
        UnityEngine.Material val_11 = val_1;
        // 0x02731FDC: MOV x0, x21                | X0 = 1152921509935745312 (0x100000013DA08920);//ML01
        // 0x02731FE0: BL #0x2731790              | X0 = this.get_materialLum();            
        UnityEngine.Material val_2 = this.materialLum;
        // 0x02731FE4: ADRP x25, #0x3641000       | X25 = 56889344 (0x3641000);             
        // 0x02731FE8: LDR x25, [x25, #0x800]     | X25 = 1152921504693481472;              
        // 0x02731FEC: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x02731FF0: LDR x8, [x25]              | X8 = typeof(UnityEngine.Graphics);      
        // 0x02731FF4: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02731FF8: TBZ w9, #0, #0x273200c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x02731FFC: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02732000: CBNZ w9, #0x273200c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x02732004: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02732008: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_4:
        // 0x0273200C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02732010: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02732014: MOV x1, x20                | X1 = source;//m1                        
        val_11 = source;
        // 0x02732018: MOV x2, x23                | X2 = val_1;//m1                         
        // 0x0273201C: MOV x3, x22                | X3 = val_2;//m1                         
        // 0x02732020: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_11 = source, mat:  val_1);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_11, mat:  val_11);
        // 0x02732024: ORR w26, wzr, #1           | W26 = 1(0x1);                           
        // 0x02732028: B #0x2732054               |  goto label_5;                          
        goto label_5;
        label_11:
        // 0x0273202C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02732030: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02732034: MOV x1, x22                | X1 = val_2;//m1                         
        // 0x02732038: MOV x2, x23                | X2 = val_1;//m1                         
        // 0x0273203C: MOV x3, x24                | X3 = X24;//m1                           
        // 0x02732040: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_2, mat:  val_1);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_2, mat:  val_11);
        // 0x02732044: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02732048: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0273204C: MOV x1, x22                | X1 = val_2;//m1                         
        val_11 = val_2;
        // 0x02732050: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        label_5:
        // 0x02732054: MOV x22, x23               | X22 = val_1;//m1                        
        // 0x02732058: CBNZ x22, #0x2732060       | if (val_1 != null) goto label_6;        
        if(val_11 != null)
        {
            goto label_6;
        }
        // 0x0273205C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x02732060: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02732064: MOV x0, x22                | X0 = val_1;//m1                         
        // 0x02732068: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x0273206C: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02732070: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x02732074: B.GT #0x2732090            | if (val_1 > 0x1) goto label_7;          
        if(val_11 > 1)
        {
            goto label_7;
        }
        // 0x02732078: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0273207C: MOV x0, x22                | X0 = val_1;//m1                         
        // 0x02732080: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02732084: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02732088: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x0273208C: B.LE #0x2732118            | if (val_1 <= 0x1) goto label_8;         
        if(val_11 <= 1)
        {
            goto label_8;
        }
        label_7:
        // 0x02732090: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02732094: MOV x0, x22                | X0 = val_1;//m1                         
        // 0x02732098: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x0273209C: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x027320A0: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x027320A4: CMP w0, #0                 | STATE = COMPARE(val_1, 0x0)             
        // 0x027320A8: CINC w9, w0, lt            | W9 = val_1 < null ? (val_1 + 1) : val_1;
        var val_3 = (val_11 < 0) ? (val_11 + 1) : (val_11);
        // 0x027320AC: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x027320B0: LDP x10, x1, [x8, #0x170]  | X10 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x027320B4: ASR w8, w9, #1             | W8 = (val_1 < null ? (val_1 + 1) : val_1 >> 1);
        var val_4 = val_3 >> 1;
        // 0x027320B8: MOV x0, x22                | X0 = val_1;//m1                         
        // 0x027320BC: CSEL w23, w8, w26, gt      | W23 = val_1 > 0x1 ? (val_1 < null ? (val_1 + 1) : val_1 >> 1) : 1;
        val_11 = (val_11 > 1) ? (val_4) : (1);
        // 0x027320C0: BLR x10                    | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x027320C4: CMP w0, #0                 | STATE = COMPARE(val_1, 0x0)             
        // 0x027320C8: CINC w8, w0, lt            | W8 = val_1 < null ? (val_1 + 1) : val_1;
        var val_5 = (val_11 < 0) ? (val_11 + 1) : (val_11);
        // 0x027320CC: ASR w8, w8, #1             | W8 = (val_1 < null ? (val_1 + 1) : val_1 >> 1);
        val_5 = val_5 >> 1;
        // 0x027320D0: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x027320D4: CSEL w2, w8, w26, gt       | W2 = val_1 > 0x1 ? (val_1 < null ? (val_1 + 1) : val_1 >> 1) : 1;
        var val_6 = (val_11 > 1) ? (val_5) : (1);
        // 0x027320D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027320DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027320E0: MOV w1, w23                | W1 = val_1 > 0x1 ? (val_1 < null ? (val_1 + 1) : val_1 >> 1) : 1;//m1
        // 0x027320E4: BL #0x1b89198              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_1);
        UnityEngine.RenderTexture val_7 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_11);
        // 0x027320E8: MOV x23, x0                | X23 = val_7;//m1                        
        // 0x027320EC: MOV x0, x21                | X0 = 1152921509935745312 (0x100000013DA08920);//ML01
        // 0x027320F0: BL #0x2731858              | X0 = this.get_materialReduce();         
        UnityEngine.Material val_8 = this.materialReduce;
        // 0x027320F4: LDR x8, [x25]              | X8 = typeof(UnityEngine.Graphics);      
        // 0x027320F8: MOV x24, x0                | X24 = val_8;//m1                        
        // 0x027320FC: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02732100: TBZ w9, #0, #0x273202c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x02732104: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02732108: CBNZ w9, #0x273202c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x0273210C: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02732110: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        // 0x02732114: B #0x273202c               |  goto label_11;                         
        goto label_11;
        label_8:
        // 0x02732118: MOV x0, x21                | X0 = 1152921509935745312 (0x100000013DA08920);//ML01
        // 0x0273211C: MOV x1, x22                | X1 = val_1;//m1                         
        // 0x02732120: BL #0x27321e8              | this.CalculateAdaptation(curTexture:  val_1);
        this.CalculateAdaptation(curTexture:  val_11);
        // 0x02732124: MOV x0, x21                | X0 = 1152921509935745312 (0x100000013DA08920);//ML01
        // 0x02732128: BL #0x27319e8              | X0 = this.get_materialApply();          
        UnityEngine.Material val_9 = this.materialApply;
        // 0x0273212C: LDR x24, [x21, #0x28]      | X24 = this.adaptRenderTex; //P2         
        // 0x02732130: LDRSW x26, [x21, #0x30]    | X26 = this.curAdaptIndex; //P2          
        // 0x02732134: MOV x23, x0                | X23 = val_9;//m1                        
        // 0x02732138: CBNZ x24, #0x2732140       | if (this.adaptRenderTex != null) goto label_12;
        if(this.adaptRenderTex != null)
        {
            goto label_12;
        }
        // 0x0273213C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_12:
        // 0x02732140: LDR w8, [x24, #0x18]       | W8 = this.adaptRenderTex.Length; //P2   
        // 0x02732144: CMP w26, w8                | STATE = COMPARE(this.curAdaptIndex, this.adaptRenderTex.Length)
        // 0x02732148: B.LO #0x2732158            | if (this.curAdaptIndex < this.adaptRenderTex.Length) goto label_13;
        if(this.curAdaptIndex < this.adaptRenderTex.Length)
        {
            goto label_13;
        }
        // 0x0273214C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
        // 0x02732150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02732154: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
        label_13:
        // 0x02732158: ADD x8, x24, x26, lsl #3   | X8 = this.adaptRenderTex[this.curAdaptIndex]; //PARR1 
        // 0x0273215C: LDR x24, [x8, #0x20]       | X24 = this.adaptRenderTex[this.curAdaptIndex][0]
        UnityEngine.RenderTexture val_12 = this.adaptRenderTex[this.curAdaptIndex];
        // 0x02732160: CBNZ x23, #0x2732168       | if (val_9 != null) goto label_14;       
        if(val_9 != null)
        {
            goto label_14;
        }
        // 0x02732164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_14:
        // 0x02732168: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x0273216C: LDR x8, [x8, #0x2a0]       | X8 = (string**)(1152921509935717120)("_AdaptTex");
        // 0x02732170: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02732174: MOV x0, x23                | X0 = val_9;//m1                         
        // 0x02732178: MOV x2, x24                | X2 = this.adaptRenderTex[this.curAdaptIndex][0];//m1
        // 0x0273217C: LDR x1, [x8]               | X1 = "_AdaptTex";                       
        // 0x02732180: BL #0x1a780c4              | val_9.SetTexture(name:  "_AdaptTex", value:  this.adaptRenderTex[this.curAdaptIndex]);
        val_9.SetTexture(name:  "_AdaptTex", value:  val_12);
        // 0x02732184: MOV x0, x21                | X0 = 1152921509935745312 (0x100000013DA08920);//ML01
        // 0x02732188: BL #0x27319e8              | X0 = this.get_materialApply();          
        UnityEngine.Material val_10 = this.materialApply;
        // 0x0273218C: LDR x8, [x25]              | X8 = typeof(UnityEngine.Graphics);      
        // 0x02732190: MOV x21, x0                | X21 = val_10;//m1                       
        // 0x02732194: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02732198: TBZ w9, #0, #0x27321ac     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x0273219C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x027321A0: CBNZ w9, #0x27321ac        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x027321A4: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x027321A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_16:
        // 0x027321AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027321B0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x027321B4: MOV x1, x20                | X1 = source;//m1                        
        // 0x027321B8: MOV x2, x19                | X2 = destination;//m1                   
        // 0x027321BC: MOV x3, x21                | X3 = val_10;//m1                        
        // 0x027321C0: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        // 0x027321C4: MOV x1, x22                | X1 = val_1;//m1                         
        // 0x027321C8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x027321CC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x027321D0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x027321D4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x027321D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027321DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027321E0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x027321E4: B #0x1b892ac               | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0); return;
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x027321E8 (41099752), len: 616  VirtAddr: 0x027321E8 RVA: 0x027321E8 token: 100663377 methodIndex: 24329 delegateWrapperIndex: 0 methodInvoker: 0
    private void CalculateAdaptation(UnityEngine.Texture curTexture)
    {
        //
        // Disasemble & Code
        // 0x027321E8: STP d11, d10, [sp, #-0x50]! | stack[1152921509936058416] = ???;  stack[1152921509936058424] = ???;  //  dest_result_addr=1152921509936058416 |  dest_result_addr=1152921509936058424
        // 0x027321EC: STP d9, d8, [sp, #0x10]    | stack[1152921509936058432] = ???;  stack[1152921509936058440] = ???;  //  dest_result_addr=1152921509936058432 |  dest_result_addr=1152921509936058440
        // 0x027321F0: STP x22, x21, [sp, #0x20]  | stack[1152921509936058448] = ???;  stack[1152921509936058456] = ???;  //  dest_result_addr=1152921509936058448 |  dest_result_addr=1152921509936058456
        // 0x027321F4: STP x20, x19, [sp, #0x30]  | stack[1152921509936058464] = ???;  stack[1152921509936058472] = ???;  //  dest_result_addr=1152921509936058464 |  dest_result_addr=1152921509936058472
        // 0x027321F8: STP x29, x30, [sp, #0x40]  | stack[1152921509936058480] = ???;  stack[1152921509936058488] = ???;  //  dest_result_addr=1152921509936058480 |  dest_result_addr=1152921509936058488
        // 0x027321FC: ADD x29, sp, #0x40         | X29 = (1152921509936058416 + 64) = 1152921509936058480 (0x100000013DA55070);
        // 0x02732200: SUB sp, sp, #0x10          | SP = (1152921509936058416 - 16) = 1152921509936058400 (0x100000013DA55020);
        // 0x02732204: ADRP x21, #0x3743000       | X21 = 57946112 (0x3743000);             
        // 0x02732208: LDRB w8, [x21, #0xad0]     | W8 = (bool)static_value_03743AD0;       
        // 0x0273220C: MOV x20, x1                | X20 = curTexture;//m1                   
        // 0x02732210: MOV x19, x0                | X19 = 1152921509936070496 (0x100000013DA57F60);//ML01
        // 0x02732214: TBNZ w8, #0, #0x2732230    | if (static_value_03743AD0 == true) goto label_0;
        // 0x02732218: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
        // 0x0273221C: LDR x8, [x8, #0x818]       | X8 = 0x2B929C0;                         
        // 0x02732220: LDR w0, [x8]               | W0 = 0x2135;                            
        // 0x02732224: BL #0x2782188              | X0 = sub_2782188( ?? 0x2135, ????);     
        // 0x02732228: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0273222C: STRB w8, [x21, #0xad0]     | static_value_03743AD0 = true;            //  dest_result_addr=57948880
        label_0:
        // 0x02732230: LDRSW x22, [x19, #0x30]    | X22 = this.curAdaptIndex; //P2          
        // 0x02732234: LDR s10, [x19, #0x18]      | S10 = this.adaptationSpeed; //P2        
        // 0x02732238: ADD w8, w22, #1            | W8 = (this.curAdaptIndex + 1);          
        int val_1 = this.curAdaptIndex + 1;
        // 0x0273223C: ADD w9, w22, #2            | W9 = (this.curAdaptIndex + 2);          
        int val_2 = this.curAdaptIndex + 2;
        // 0x02732240: CMP w8, #0                 | STATE = COMPARE((this.curAdaptIndex + 1), 0x0)
        // 0x02732244: CSINC w9, w9, w22, lt      | W9 = val_1 < 0 ? (this.curAdaptIndex + 2) : (this.curAdaptIndex + 1);
        var val_3 = (val_1 < 0) ? (val_2) : (this.curAdaptIndex + 1);
        // 0x02732248: AND w9, w9, #0xfffffffe    | W9 = (val_1 < 0 ? (this.curAdaptIndex + 2) : (this.curAdaptIndex + 1) & 4294967294);
        val_3 = val_3 & 4294967294;
        // 0x0273224C: SUB w8, w8, w9             | W8 = ((this.curAdaptIndex + 1) - (val_1 < 0 ? (this.curAdaptIndex + 2) : (this.curAdaptIndex + 1) & 
        val_1 = val_1 - val_3;
        // 0x02732250: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02732254: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02732258: STR w8, [x19, #0x30]       | this.curAdaptIndex = ((this.curAdaptIndex + 1) - (val_1 < 0 ? (this.curAdaptIndex + 2) : (this.curAdaptIndex + 1) & 4294967294));  //  dest_result_addr=1152921509936070544
        this.curAdaptIndex = val_1;
        // 0x0273225C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_4 = UnityEngine.Time.deltaTime;
        // 0x02732260: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x02732264: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x02732268: MOV v8.16b, v0.16b         | V8 = val_4;//m1                         
        // 0x0273226C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x02732270: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x02732274: TBZ w8, #0, #0x2732284     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02732278: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x0273227C: CBNZ w8, #0x2732284        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02732280: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_2:
        // 0x02732284: FMOV s9, #1.00000000       | S9 = 1;                                 
        // 0x02732288: FMOV s1, #30.00000000      | S1 = 30;                                
        float val_11 = 30f;
        // 0x0273228C: FSUB s0, s9, s10           | S0 = (1f - this.adaptationSpeed);       
        float val_5 = 1f - this.adaptationSpeed;
        // 0x02732290: FMUL s1, s8, s1            | S1 = (val_4 * 30f);                     
        val_11 = val_4 * val_11;
        // 0x02732294: BL #0x97ff50               | X0 = sub_97FF50( ?? typeof(UnityEngine.Mathf), ????);
        // 0x02732298: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x0273229C: LDR s1, [x8, #0x770]       | S1 = 0.01;                              
        // 0x027322A0: FSUB s0, s9, s0            | S0 = (1f - (1f - this.adaptationSpeed));
        val_5 = 1f - val_5;
        // 0x027322A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027322A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027322AC: MOV v2.16b, v9.16b         | V2 = 1;//m1                             
        // 0x027322B0: BL #0x1a7dcc8              | X0 = UnityEngine.Mathf.Clamp(value:  val_5 = 1f - val_5, min:  0.01f, max:  1f);
        float val_6 = UnityEngine.Mathf.Clamp(value:  val_5, min:  0.01f, max:  1f);
        // 0x027322B4: MOV x0, x19                | X0 = 1152921509936070496 (0x100000013DA57F60);//ML01
        // 0x027322B8: MOV v8.16b, v0.16b         | V8 = val_6;//m1                         
        // 0x027322BC: BL #0x2731920              | X0 = this.get_materialAdapt();          
        UnityEngine.Material val_7 = this.materialAdapt;
        // 0x027322C0: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x027322C4: CBNZ x21, #0x27322cc       | if (val_7 != null) goto label_3;        
        if(val_7 != null)
        {
            goto label_3;
        }
        // 0x027322C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_3:
        // 0x027322CC: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x027322D0: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921509935915232)("_CurTex");
        // 0x027322D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027322D8: MOV x0, x21                | X0 = val_7;//m1                         
        // 0x027322DC: MOV x2, x20                | X2 = curTexture;//m1                    
        // 0x027322E0: LDR x1, [x8]               | X1 = "_CurTex";                         
        // 0x027322E4: BL #0x1a780c4              | val_7.SetTexture(name:  "_CurTex", value:  curTexture);
        val_7.SetTexture(name:  "_CurTex", value:  curTexture);
        // 0x027322E8: MOV x0, x19                | X0 = 1152921509936070496 (0x100000013DA57F60);//ML01
        // 0x027322EC: BL #0x2731920              | X0 = this.get_materialAdapt();          
        UnityEngine.Material val_8 = this.materialAdapt;
        // 0x027322F0: LDP s1, s2, [x19, #0x1c]   | S1 = this.limitMinimum; //P2  S2 = this.limitMaximum; //P2  //  | 
        // 0x027322F4: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x027322F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027322FC: FMOV s3, wzr               | S3 = 0f;                                
        // 0x02732300: MOV x0, sp                 | X0 = 1152921509936058400 (0x100000013DA55020);//ML01
        // 0x02732304: MOV v0.16b, v8.16b         | V0 = val_6;//m1                         
        // 0x02732308: STP xzr, xzr, [sp]         | stack[1152921509936058400] = 0x0;  stack[1152921509936058408] = 0x0;  //  dest_result_addr=1152921509936058400 |  dest_result_addr=1152921509936058408
        // 0x0273230C: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02732310: CBNZ x20, #0x2732318       | if (val_8 != null) goto label_4;        
        if(val_8 != null)
        {
            goto label_4;
        }
        // 0x02732314: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013DA55020, ????);
        label_4:
        // 0x02732318: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x0273231C: LDR x8, [x8, #0x678]       | X8 = (string**)(1152921509935919424)("_AdaptParams");
        // 0x02732320: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x02732324: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
        // 0x02732328: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0273232C: LDR x1, [x8]               | X1 = "_AdaptParams";                    
        // 0x02732330: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x02732334: BL #0x1a79fa8              | val_8.SetVector(name:  "_AdaptParams", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        val_8.SetVector(name:  "_AdaptParams", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02732338: LDR x20, [x19, #0x28]      | X20 = this.adaptRenderTex; //P2         
        // 0x0273233C: LDRSW x21, [x19, #0x30]    | X21 = this.curAdaptIndex; //P2          
        // 0x02732340: CBNZ x20, #0x2732348       | if (this.adaptRenderTex != null) goto label_5;
        if(this.adaptRenderTex != null)
        {
            goto label_5;
        }
        // 0x02732344: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_5:
        // 0x02732348: LDR w8, [x20, #0x18]       | W8 = this.adaptRenderTex.Length; //P2   
        // 0x0273234C: CMP w21, w8                | STATE = COMPARE(this.curAdaptIndex, this.adaptRenderTex.Length)
        // 0x02732350: B.LO #0x2732360            | if (this.curAdaptIndex < this.adaptRenderTex.Length) goto label_6;
        if(this.curAdaptIndex < this.adaptRenderTex.Length)
        {
            goto label_6;
        }
        // 0x02732354: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
        // 0x02732358: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0273235C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        label_6:
        // 0x02732360: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02732364: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02732368: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x0273236C: ADD x8, x20, x21, lsl #3   | X8 = this.adaptRenderTex[this.curAdaptIndex]; //PARR1 
        // 0x02732370: LDR x20, [x8, #0x20]       | X20 = this.adaptRenderTex[this.curAdaptIndex][0]
        UnityEngine.RenderTexture val_12 = this.adaptRenderTex[this.curAdaptIndex];
        // 0x02732374: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02732378: TBZ w8, #0, #0x2732388     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x0273237C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02732380: CBNZ w8, #0x2732388        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x02732384: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_8:
        // 0x02732388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0273238C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02732390: MOV x1, x20                | X1 = this.adaptRenderTex[this.curAdaptIndex][0];//m1
        // 0x02732394: BL #0x1a6d524              | UnityEngine.Graphics.SetRenderTarget(rt:  0);
        UnityEngine.Graphics.SetRenderTarget(rt:  0);
        // 0x02732398: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0273239C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027323A0: BL #0x20d3bf8              | X0 = UnityEngine.Color.get_black();     
        UnityEngine.Color val_9 = UnityEngine.Color.black;
        // 0x027323A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027323A8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x027323AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027323B0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x027323B4: BL #0x1a66470              | UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_9.r, g = val_9.g, b = val_9.b, a = val_9.a});
        UnityEngine.GL.Clear(clearDepth:  false, clearColor:  false, backgroundColor:  new UnityEngine.Color() {r = val_9.r, g = val_9.g, b = val_9.b, a = val_9.a});
        // 0x027323B8: LDR x20, [x19, #0x28]      | X20 = this.adaptRenderTex; //P2         
        // 0x027323BC: CBNZ x20, #0x27323c4       | if (this.adaptRenderTex != null) goto label_9;
        if(this.adaptRenderTex != null)
        {
            goto label_9;
        }
        // 0x027323C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_9:
        // 0x027323C4: LDR w8, [x20, #0x18]       | W8 = this.adaptRenderTex.Length; //P2   
        // 0x027323C8: CMP w22, w8                | STATE = COMPARE(this.curAdaptIndex, this.adaptRenderTex.Length)
        // 0x027323CC: B.LO #0x27323dc            | if (this.curAdaptIndex < this.adaptRenderTex.Length) goto label_10;
        if(this.curAdaptIndex < this.adaptRenderTex.Length)
        {
            goto label_10;
        }
        // 0x027323D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x027323D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027323D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_10:
        // 0x027323DC: ADD x8, x20, x22, lsl #3   | X8 = this.adaptRenderTex[this.curAdaptIndex]; //PARR1 
        // 0x027323E0: LDR x21, [x19, #0x28]      | X21 = this.adaptRenderTex; //P2         
        // 0x027323E4: LDR x20, [x8, #0x20]       | X20 = this.adaptRenderTex[this.curAdaptIndex][0]
        UnityEngine.RenderTexture val_13 = this.adaptRenderTex[this.curAdaptIndex];
        // 0x027323E8: LDRSW x22, [x19, #0x30]    | X22 = this.curAdaptIndex; //P2          
        // 0x027323EC: CBNZ x21, #0x27323f4       | if (this.adaptRenderTex != null) goto label_11;
        if(this.adaptRenderTex != null)
        {
            goto label_11;
        }
        // 0x027323F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_11:
        // 0x027323F4: LDR w8, [x21, #0x18]       | W8 = this.adaptRenderTex.Length; //P2   
        // 0x027323F8: CMP w22, w8                | STATE = COMPARE(this.curAdaptIndex, this.adaptRenderTex.Length)
        // 0x027323FC: B.LO #0x273240c            | if (this.curAdaptIndex < this.adaptRenderTex.Length) goto label_12;
        if(this.curAdaptIndex < this.adaptRenderTex.Length)
        {
            goto label_12;
        }
        // 0x02732400: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x02732404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02732408: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_12:
        // 0x0273240C: ADD x8, x21, x22, lsl #3   | X8 = this.adaptRenderTex[this.curAdaptIndex]; //PARR1 
        // 0x02732410: LDR x21, [x8, #0x20]       | X21 = this.adaptRenderTex[this.curAdaptIndex][0]
        UnityEngine.RenderTexture val_14 = this.adaptRenderTex[this.curAdaptIndex];
        // 0x02732414: MOV x0, x19                | X0 = 1152921509936070496 (0x100000013DA57F60);//ML01
        // 0x02732418: BL #0x2731920              | X0 = this.get_materialAdapt();          
        UnityEngine.Material val_10 = this.materialAdapt;
        // 0x0273241C: MOV x3, x0                 | X3 = val_10;//m1                        
        // 0x02732420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02732424: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02732428: MOV x1, x20                | X1 = this.adaptRenderTex[this.curAdaptIndex][0];//m1
        // 0x0273242C: MOV x2, x21                | X2 = this.adaptRenderTex[this.curAdaptIndex][0];//m1
        // 0x02732430: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  this.adaptRenderTex[this.curAdaptIndex], mat:  this.adaptRenderTex[this.curAdaptIndex]);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_13, mat:  val_14);
        // 0x02732434: SUB sp, x29, #0x40         | SP = (1152921509936058480 - 64) = 1152921509936058416 (0x100000013DA55030);
        // 0x02732438: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x0273243C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02732440: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x02732444: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x02732448: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x0273244C: RET                        |  return;                                
        return;
    
    }

}
