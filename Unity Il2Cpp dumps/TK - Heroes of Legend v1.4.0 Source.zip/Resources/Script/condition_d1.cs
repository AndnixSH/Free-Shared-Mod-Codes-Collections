using UnityEngine;
public sealed class GameObjectVisitor.condition : MulticastDelegate
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x00C1D09C (12701852), len: 16  VirtAddr: 0x00C1D09C RVA: 0x00C1D09C token: 100696612 methodIndex: 28300 delegateWrapperIndex: 0 methodInvoker: 0
    public GameObjectVisitor.condition(object object, IntPtr method)
    {
        //
        // Disasemble & Code
        // 0x00C1D09C: LDR x8, [x2]               | X8 = method;                            
        // 0x00C1D0A0: STP x1, x2, [x0, #0x20]    | mem[1152921515560609424] = object;  mem[1152921515560609432] = method;  //  dest_result_addr=1152921515560609424 |  dest_result_addr=1152921515560609432
        mem[1152921515560609424] = object;
        mem[1152921515560609432] = method;
        // 0x00C1D0A4: STR x8, [x0, #0x10]        | mem[1152921515560609408] = method;       //  dest_result_addr=1152921515560609408
        mem[1152921515560609408] = method;
        // 0x00C1D0A8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00C1D488 (12702856), len: 920  VirtAddr: 0x00C1D488 RVA: 0x00C1D488 token: 100696613 methodIndex: 28301 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual bool Invoke(UnityEngine.GameObject obj)
    {
        //
        // Disasemble & Code
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        //  | 
        var val_17;
        //  | 
        var val_18;
        //  | 
        var val_19;
        label_1:
        // 0x00C1D488: STP x22, x21, [sp, #-0x30]! | stack[1152921515560733920] = ???;  stack[1152921515560733928] = ???;  //  dest_result_addr=1152921515560733920 |  dest_result_addr=1152921515560733928
        // 0x00C1D48C: STP x20, x19, [sp, #0x10]  | stack[1152921515560733936] = ???;  stack[1152921515560733944] = ???;  //  dest_result_addr=1152921515560733936 |  dest_result_addr=1152921515560733944
        // 0x00C1D490: STP x29, x30, [sp, #0x20]  | stack[1152921515560733952] = ???;  stack[1152921515560733960] = ???;  //  dest_result_addr=1152921515560733952 |  dest_result_addr=1152921515560733960
        // 0x00C1D494: ADD x29, sp, #0x20         | X29 = (1152921515560733920 + 32) = 1152921515560733952 (0x100000028CE70D00);
        // 0x00C1D498: SUB sp, sp, #0x10          | SP = (1152921515560733920 - 16) = 1152921515560733904 (0x100000028CE70CD0);
        // 0x00C1D49C: MOV x22, x0                | X22 = 1152921515560745968 (0x100000028CE73BF0);//ML01
        // 0x00C1D4A0: LDR x0, [x22, #0x58]       | 
        // 0x00C1D4A4: MOV x19, x1                | X19 = obj;//m1                          
        // 0x00C1D4A8: CBZ x0, #0xc1d4b4          | if (this == null) goto label_0;         
        if(this == null)
        {
            goto label_0;
        }
        // 0x00C1D4AC: MOV x1, x19                | X1 = obj;//m1                           
        val_13 = obj;
        // 0x00C1D4B0: BL #0xc1d488               |  R0 = label_1();                        
        label_0:
        // 0x00C1D4B4: LDR x0, [x22, #0x10]       | 
        // 0x00C1D4B8: STR x0, [sp, #8]           | stack[1152921515560733912] = this;       //  dest_result_addr=1152921515560733912
        // 0x00C1D4BC: LDP x21, x20, [x22, #0x20] |                                          //  | 
        // 0x00C1D4C0: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00C1D4C4: BL #0x2796f94              | X0 = sub_2796F94( ?? X20, ????);        
        // 0x00C1D4C8: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00C1D4CC: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X20, ????);        
        // 0x00C1D4D0: LDRB w9, [x20, #0x4e]      | W9 = X20 + 78;                          
        // 0x00C1D4D4: AND w8, w0, #1             | W8 = (X20 & 1);                         
        var val_1 = X20 & 1;
        // 0x00C1D4D8: TBZ w8, #0, #0xc1d574      | if (((X20 & 1) & 0x1) == 0) goto label_2;
        if((val_1 & 1) == 0)
        {
            goto label_2;
        }
        // 0x00C1D4DC: LDRH w8, [x20, #0x4c]      | W8 = X20 + 76;                          
        // 0x00C1D4E0: CMP w9, #1                 | STATE = COMPARE(X20 + 78, 0x1)          
        // 0x00C1D4E4: B.NE #0xc1d584             | if (X20 + 78 != 0x1) goto label_3;      
        if((X20 + 78) != 1)
        {
            goto label_3;
        }
        // 0x00C1D4E8: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
        // 0x00C1D4EC: CMP w8, w9                 | STATE = COMPARE(X20 + 76, 0xFFFF)       
        // 0x00C1D4F0: B.EQ #0xc1d638             | if (X20 + 76 == 65535) goto label_7;    
        if((X20 + 76) == 65535)
        {
            goto label_7;
        }
        // 0x00C1D4F4: CBZ x21, #0xc1d504         | if (X21 == 0) goto label_5;             
        if(X21 == 0)
        {
            goto label_5;
        }
        // 0x00C1D4F8: LDR x8, [x21]              | X8 = X21;                               
        // 0x00C1D4FC: LDRB w8, [x8, #0xed]       | W8 = X21 + 237;                         
        // 0x00C1D500: TBNZ w8, #0, #0xc1d638     | if ((X21 + 237 & 0x1) != 0) goto label_7;
        if(((X21 + 237) & 1) != 0)
        {
            goto label_7;
        }
        label_5:
        // 0x00C1D504: LDR x8, [x22, #0x18]       | 
        // 0x00C1D508: CBZ x8, #0xc1d638          | if (X21 + 237 == 0) goto label_7;       
        if((X21 + 237) == 0)
        {
            goto label_7;
        }
        // 0x00C1D50C: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00C1D510: BL #0x27c0990              | X0 = sub_27C0990( ?? X20, ????);        
        // 0x00C1D514: MOV w22, w0                | W22 = X20;//m1                          
        // 0x00C1D518: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00C1D51C: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
        UnityEngine.Sprite val_2 = X20.pressedSprite;
        // 0x00C1D520: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
        // 0x00C1D524: TBZ w22, #0, #0xc1d67c     | if ((X20 & 0x1) == 0) goto label_8;     
        if((X20 & 1) == 0)
        {
            goto label_8;
        }
        // 0x00C1D528: TBZ w0, #0, #0xc1d734      | if ((val_2 & 0x1) == 0) goto label_9;   
        if((val_2 & 1) == 0)
        {
            goto label_9;
        }
        // 0x00C1D52C: LDR x8, [x21]              | X8 = X21;                               
        var val_19 = X21;
        // 0x00C1D530: LDR x1, [x20, #0x18]       | X1 = X20 + 24;                          
        // 0x00C1D534: LDRH w2, [x20, #0x4c]      | W2 = X20 + 76;                          
        // 0x00C1D538: LDRH w9, [x8, #0x102]      | W9 = X21 + 258;                         
        // 0x00C1D53C: CBZ x9, #0xc1d568          | if (X21 + 258 == 0) goto label_10;      
        if((X21 + 258) == 0)
        {
            goto label_10;
        }
        // 0x00C1D540: LDR x10, [x8, #0x98]       | X10 = X21 + 152;                        
        var val_11 = X21 + 152;
        // 0x00C1D544: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_12 = 0;
        // 0x00C1D548: ADD x10, x10, #8           | X10 = (X21 + 152 + 8);                  
        val_11 = val_11 + 8;
        label_12:
        // 0x00C1D54C: LDUR x12, [x10, #-8]       | X12 = (X21 + 152 + 8) + -8;             
        // 0x00C1D550: CMP x12, x1                | STATE = COMPARE((X21 + 152 + 8) + -8, X20 + 24)
        // 0x00C1D554: B.EQ #0xc1d780             | if ((X21 + 152 + 8) + -8 == X20 + 24) goto label_11;
        if(((X21 + 152 + 8) + -8) == (X20 + 24))
        {
            goto label_11;
        }
        // 0x00C1D558: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x00C1D55C: ADD x10, x10, #0x10        | X10 = ((X21 + 152 + 8) + 16);           
        val_11 = val_11 + 16;
        // 0x00C1D560: CMP x11, x9                | STATE = COMPARE((0 + 1), X21 + 258)     
        // 0x00C1D564: B.LO #0xc1d54c             | if (0 < X21 + 258) goto label_12;       
        if(val_12 < (X21 + 258))
        {
            goto label_12;
        }
        label_10:
        // 0x00C1D568: MOV x0, x21                | X0 = X21;//m1                           
        val_14 = X21;
        // 0x00C1D56C: BL #0x2776c24              | X0 = sub_2776C24( ?? X21, ????);        
        // 0x00C1D570: B #0xc1d790                |  goto label_13;                         
        goto label_13;
        label_2:
        // 0x00C1D574: CMP w9, #1                 | STATE = COMPARE(X20 + 78, 0x1)          
        // 0x00C1D578: B.NE #0xc1d610             | if (X20 + 78 != 0x1) goto label_14;     
        if((X20 + 78) != 1)
        {
            goto label_14;
        }
        // 0x00C1D57C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00C1D580: B #0xc1d63c                |  goto label_15;                         
        goto label_15;
        label_3:
        // 0x00C1D584: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
        // 0x00C1D588: CMP w8, w9                 | STATE = COMPARE(X20 + 76, 0xFFFF)       
        // 0x00C1D58C: B.EQ #0xc1d65c             | if (X20 + 76 == 65535) goto label_19;   
        if((X20 + 76) == 65535)
        {
            goto label_19;
        }
        // 0x00C1D590: CBZ x21, #0xc1d5a0         | if (X21 == 0) goto label_17;            
        if(X21 == 0)
        {
            goto label_17;
        }
        // 0x00C1D594: LDR x8, [x21]              | X8 = X21;                               
        // 0x00C1D598: LDRB w8, [x8, #0xed]       | W8 = X21 + 237;                         
        // 0x00C1D59C: TBNZ w8, #0, #0xc1d65c     | if ((X21 + 237 & 0x1) != 0) goto label_19;
        if(((X21 + 237) & 1) != 0)
        {
            goto label_19;
        }
        label_17:
        // 0x00C1D5A0: LDR x8, [x22, #0x18]       | 
        // 0x00C1D5A4: CBZ x8, #0xc1d65c          | if (X21 + 237 == 0) goto label_19;      
        if((X21 + 237) == 0)
        {
            goto label_19;
        }
        // 0x00C1D5A8: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00C1D5AC: BL #0x27c0990              | X0 = sub_27C0990( ?? X20, ????);        
        // 0x00C1D5B0: MOV w21, w0                | W21 = X20;//m1                          
        // 0x00C1D5B4: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00C1D5B8: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
        UnityEngine.Sprite val_3 = X20.pressedSprite;
        // 0x00C1D5BC: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_3, ????);      
        // 0x00C1D5C0: TBZ w21, #0, #0xc1d6d8     | if ((X20 & 0x1) == 0) goto label_20;    
        if((X20 & 1) == 0)
        {
            goto label_20;
        }
        // 0x00C1D5C4: TBZ w0, #0, #0xc1d748      | if ((val_3 & 0x1) == 0) goto label_21;  
        if((val_3 & 1) == 0)
        {
            goto label_21;
        }
        // 0x00C1D5C8: LDR x8, [x19]              | X8 = typeof(UnityEngine.GameObject);    
        // 0x00C1D5CC: LDR x1, [x20, #0x18]       | X1 = X20 + 24;                          
        // 0x00C1D5D0: LDRH w2, [x20, #0x4c]      | W2 = X20 + 76;                          
        // 0x00C1D5D4: LDRH w9, [x8, #0x102]      | W9 = UnityEngine.GameObject.__il2cppRuntimeField_interface_offsets_count;
        // 0x00C1D5D8: CBZ x9, #0xc1d604          | if (UnityEngine.GameObject.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
        // 0x00C1D5DC: LDR x10, [x8, #0x98]       | X10 = UnityEngine.GameObject.__il2cppRuntimeField_interfaceOffsets;
        // 0x00C1D5E0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_13 = 0;
        // 0x00C1D5E4: ADD x10, x10, #8           | X10 = (UnityEngine.GameObject.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504692666376 (0x10000000051D8008);
        label_24:
        // 0x00C1D5E8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00C1D5EC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X20 + 24)
        // 0x00C1D5F0: B.EQ #0xc1d7b4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X20 + 24) goto label_23;
        // 0x00C1D5F4: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_13 = val_13 + 1;
        // 0x00C1D5F8: ADD x10, x10, #0x10        | X10 = (1152921504692666376 + 16) = 1152921504692666392 (0x10000000051D8018);
        // 0x00C1D5FC: CMP x11, x9                | STATE = COMPARE((0 + 1), UnityEngine.GameObject.__il2cppRuntimeField_interface_offsets_count)
        // 0x00C1D600: B.LO #0xc1d5e8             | if (0 < UnityEngine.GameObject.__il2cppRuntimeField_interface_offsets_count) goto label_24;
        label_22:
        // 0x00C1D604: MOV x0, x19                | X0 = obj;//m1                           
        val_15 = obj;
        // 0x00C1D608: BL #0x2776c24              | X0 = sub_2776C24( ?? obj, ????);        
        // 0x00C1D60C: B #0xc1d7c4                |  goto label_25;                         
        goto label_25;
        label_14:
        // 0x00C1D610: LDR x4, [sp, #8]           | X4 = this;                              
        // 0x00C1D614: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00C1D618: MOV x1, x21                | X1 = X21;//m1                           
        // 0x00C1D61C: MOV x2, x19                | X2 = obj;//m1                           
        // 0x00C1D620: MOV x3, x20                | X3 = X20;//m1                           
        // 0x00C1D624: SUB sp, x29, #0x20         | SP = (1152921515560733952 - 32) = 1152921515560733920 (0x100000028CE70CE0);
        // 0x00C1D628: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00C1D62C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00C1D630: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00C1D634: BR x4                      | X0 = this( ?? 0x0, ????);               
        label_7:
        // 0x00C1D638: MOV x0, x21                | X0 = X21;//m1                           
        label_15:
        // 0x00C1D63C: LDR x3, [sp, #8]           | X3 = this;                              
        // 0x00C1D640: MOV x1, x19                | X1 = obj;//m1                           
        // 0x00C1D644: MOV x2, x20                | X2 = X20;//m1                           
        label_42:
        // 0x00C1D648: SUB sp, x29, #0x20         | SP = (1152921515560733952 - 32) = 1152921515560733920 (0x100000028CE70CE0);
        // 0x00C1D64C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00C1D650: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00C1D654: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00C1D658: BR x3                      | X0 = this( ?? X21, ????);               
        label_19:
        // 0x00C1D65C: LDR x2, [sp, #8]           | X2 = this;                              
        // 0x00C1D660: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00C1D664: MOV x1, x20                | X1 = X20;//m1                           
        label_43:
        // 0x00C1D668: SUB sp, x29, #0x20         | SP = (1152921515560733952 - 32) = 1152921515560733920 (0x100000028CE70CE0);
        // 0x00C1D66C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00C1D670: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00C1D674: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00C1D678: BR x2                      | X0 = this( ?? obj, ????);               
        label_8:
        // 0x00C1D67C: LDRH w22, [x20, #0x4c]     | W22 = X20 + 76;                         
        // 0x00C1D680: TBZ w0, #0, #0xc1d75c      | if ((val_2 & 0x1) == 0) goto label_26;  
        if((val_2 & 1) == 0)
        {
            goto label_26;
        }
        // 0x00C1D684: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00C1D688: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
        UnityEngine.Sprite val_4 = X20.pressedSprite;
        // 0x00C1D68C: LDR x9, [x21]              | X9 = X21;                               
        // 0x00C1D690: MOV x8, x0                 | X8 = val_4;//m1                         
        // 0x00C1D694: LDRH w10, [x9, #0x102]     | W10 = X21 + 258;                        
        // 0x00C1D698: CBZ x10, #0xc1d6c4         | if (X21 + 258 == 0) goto label_27;      
        if((X21 + 258) == 0)
        {
            goto label_27;
        }
        // 0x00C1D69C: LDR x11, [x9, #0x98]       | X11 = X21 + 152;                        
        var val_14 = X21 + 152;
        // 0x00C1D6A0: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
        var val_15 = 0;
        // 0x00C1D6A4: ADD x11, x11, #8           | X11 = (X21 + 152 + 8);                  
        val_14 = val_14 + 8;
        label_29:
        // 0x00C1D6A8: LDUR x13, [x11, #-8]       | X13 = (X21 + 152 + 8) + -8;             
        // 0x00C1D6AC: CMP x13, x8                | STATE = COMPARE((X21 + 152 + 8) + -8, val_4)
        // 0x00C1D6B0: B.EQ #0xc1d7e4             | if ((X21 + 152 + 8) + -8 == val_4) goto label_28;
        if(((X21 + 152 + 8) + -8) == val_4)
        {
            goto label_28;
        }
        // 0x00C1D6B4: ADD x12, x12, #1           | X12 = (0 + 1);                          
        val_15 = val_15 + 1;
        // 0x00C1D6B8: ADD x11, x11, #0x10        | X11 = ((X21 + 152 + 8) + 16);           
        val_14 = val_14 + 16;
        // 0x00C1D6BC: CMP x12, x10               | STATE = COMPARE((0 + 1), X21 + 258)     
        // 0x00C1D6C0: B.LO #0xc1d6a8             | if (0 < X21 + 258) goto label_29;       
        if(val_15 < (X21 + 258))
        {
            goto label_29;
        }
        label_27:
        // 0x00C1D6C4: MOV x0, x21                | X0 = X21;//m1                           
        val_16 = X21;
        // 0x00C1D6C8: MOV x1, x8                 | X1 = val_4;//m1                         
        // 0x00C1D6CC: MOV w2, w22                | W2 = X20 + 76;//m1                      
        // 0x00C1D6D0: BL #0x2776c24              | X0 = sub_2776C24( ?? X21, ????);        
        // 0x00C1D6D4: B #0xc1d7f4                |  goto label_30;                         
        goto label_30;
        label_20:
        // 0x00C1D6D8: LDRH w21, [x20, #0x4c]     | W21 = X20 + 76;                         
        // 0x00C1D6DC: TBZ w0, #0, #0xc1d76c      | if ((val_3 & 0x1) == 0) goto label_31;  
        if((val_3 & 1) == 0)
        {
            goto label_31;
        }
        // 0x00C1D6E0: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00C1D6E4: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
        UnityEngine.Sprite val_5 = X20.pressedSprite;
        // 0x00C1D6E8: LDR x9, [x19]              | X9 = typeof(UnityEngine.GameObject);    
        // 0x00C1D6EC: MOV x8, x0                 | X8 = val_5;//m1                         
        // 0x00C1D6F0: LDRH w10, [x9, #0x102]     | W10 = UnityEngine.GameObject.__il2cppRuntimeField_interface_offsets_count;
        // 0x00C1D6F4: CBZ x10, #0xc1d720         | if (UnityEngine.GameObject.__il2cppRuntimeField_interface_offsets_count == 0) goto label_32;
        // 0x00C1D6F8: LDR x11, [x9, #0x98]       | X11 = UnityEngine.GameObject.__il2cppRuntimeField_interfaceOffsets;
        // 0x00C1D6FC: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
        var val_16 = 0;
        // 0x00C1D700: ADD x11, x11, #8           | X11 = (UnityEngine.GameObject.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504692666376 (0x10000000051D8008);
        label_34:
        // 0x00C1D704: LDUR x13, [x11, #-8]       | X13 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00C1D708: CMP x13, x8                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, val_5)
        // 0x00C1D70C: B.EQ #0xc1d804             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_5) goto label_33;
        // 0x00C1D710: ADD x12, x12, #1           | X12 = (0 + 1);                          
        val_16 = val_16 + 1;
        // 0x00C1D714: ADD x11, x11, #0x10        | X11 = (1152921504692666376 + 16) = 1152921504692666392 (0x10000000051D8018);
        // 0x00C1D718: CMP x12, x10               | STATE = COMPARE((0 + 1), UnityEngine.GameObject.__il2cppRuntimeField_interface_offsets_count)
        // 0x00C1D71C: B.LO #0xc1d704             | if (0 < UnityEngine.GameObject.__il2cppRuntimeField_interface_offsets_count) goto label_34;
        label_32:
        // 0x00C1D720: MOV x0, x19                | X0 = obj;//m1                           
        val_17 = obj;
        // 0x00C1D724: MOV x1, x8                 | X1 = val_5;//m1                         
        val_13 = val_5;
        // 0x00C1D728: MOV w2, w21                | W2 = X20 + 76;//m1                      
        // 0x00C1D72C: BL #0x2776c24              | X0 = sub_2776C24( ?? obj, ????);        
        // 0x00C1D730: B #0xc1d814                |  goto label_35;                         
        goto label_35;
        label_9:
        // 0x00C1D734: LDRH w8, [x20, #0x4c]      | W8 = X20 + 76;                          
        // 0x00C1D738: LDR x9, [x21]              | X9 = X21;                               
        // 0x00C1D73C: ADD x8, x9, x8, lsl #4     | X8 = (X21 + (X20 + 76) << 4);           
        var val_6 = X21 + ((X20 + 76) << 4);
        // 0x00C1D740: LDR x0, [x8, #0x118]       | X0 = (X21 + (X20 + 76) << 4) + 280;     
        val_18 = mem[(X21 + (X20 + 76) << 4) + 280];
        val_18 = (X21 + (X20 + 76) << 4) + 280;
        // 0x00C1D744: B #0xc1d794                |  goto label_36;                         
        goto label_36;
        label_21:
        // 0x00C1D748: LDRH w8, [x20, #0x4c]      | W8 = X20 + 76;                          
        // 0x00C1D74C: LDR x9, [x19]              | X9 = typeof(UnityEngine.GameObject);    
        // 0x00C1D750: ADD x8, x9, x8, lsl #4     | X8 = (1152921504692629504 + (X20 + 76) << 4);
        UnityEngine.GameObject val_7 = 1152921504692629504 + ((X20 + 76) << 4);
        // 0x00C1D754: LDR x0, [x8, #0x118]       |  //  not_find_field!1:280
        val_19 = mem[(1152921504692629504 + (X20 + 76) << 4) + 280];
        // 0x00C1D758: B #0xc1d7c8                |  goto label_37;                         
        goto label_37;
        label_26:
        // 0x00C1D75C: LDR x8, [x21]              | X8 = X21;                               
        var val_17 = X21;
        // 0x00C1D760: ADD x8, x8, w22, uxtw #4   | X8 = (X21 + X20 + 76);                  
        val_17 = val_17 + (X20 + 76);
        // 0x00C1D764: LDP x3, x2, [x8, #0x110]   | X3 = (X21 + X20 + 76) + 272; X2 = (X21 + X20 + 76) + 272 + 8; //  | 
        // 0x00C1D768: B #0xc1d7f8                |  goto label_38;                         
        goto label_38;
        label_31:
        // 0x00C1D76C: LDR x8, [x19]              | X8 = typeof(UnityEngine.GameObject);    
        // 0x00C1D770: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00C1D774: ADD x8, x8, w21, uxtw #4   | X8 = (1152921504692629504 + X20 + 76);  
        UnityEngine.GameObject val_8 = 1152921504692629504 + (X20 + 76);
        // 0x00C1D778: LDP x2, x1, [x8, #0x110]   |                                          //  not_find_field!1:272 |  not_find_field!1:280
        // 0x00C1D77C: B #0xc1d668                |  goto label_43;                         
        goto label_43;
        label_11:
        // 0x00C1D780: LDR w9, [x10]              | W9 = (X21 + 152 + 8);                   
        var val_18 = val_11;
        // 0x00C1D784: ADD w9, w9, w2             | W9 = ((X21 + 152 + 8) + X20 + 76);      
        val_18 = val_18 + (X20 + 76);
        // 0x00C1D788: ADD x8, x8, w9, uxtw #4    | X8 = (X21 + ((X21 + 152 + 8) + X20 + 76));
        val_19 = val_19 + val_18;
        // 0x00C1D78C: ADD x0, x8, #0x110         | X0 = ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272);
        val_14 = val_19 + 272;
        label_13:
        // 0x00C1D790: LDR x0, [x0, #8]           | X0 = ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272) + 8;
        val_18 = mem[((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272) + 8];
        val_18 = ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272) + 8;
        label_36:
        // 0x00C1D794: MOV x1, x20                | X1 = X20;//m1                           
        // 0x00C1D798: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272) + 8, ????);
        // 0x00C1D79C: MOV x8, x0                 | X8 = ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
        // 0x00C1D7A0: LDR x3, [x8]               | X3 = ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272) + 8;
        // 0x00C1D7A4: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00C1D7A8: MOV x1, x19                | X1 = obj;//m1                           
        // 0x00C1D7AC: MOV x2, x8                 | X2 = ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
        // 0x00C1D7B0: B #0xc1d648                |  goto label_42;                         
        goto label_42;
        label_23:
        // 0x00C1D7B4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00C1D7B8: ADD w9, w9, w2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X20 + 76);
        // 0x00C1D7BC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504692629504 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X20 + 76));
        // 0x00C1D7C0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504692629504 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X20 + 76)).272
        label_25:
        // 0x00C1D7C4: LDR x0, [x0, #8]           | 
        label_37:
        // 0x00C1D7C8: MOV x1, x20                | X1 = X20;//m1                           
        // 0x00C1D7CC: BL #0x2796ec8              | X0 = sub_2796EC8( ?? val_3, ????);      
        // 0x00C1D7D0: MOV x8, x0                 | X8 = val_3;//m1                         
        // 0x00C1D7D4: LDR x2, [x8]               | X2 = typeof(UnityEngine.Sprite);        
        // 0x00C1D7D8: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00C1D7DC: MOV x1, x8                 | X1 = val_3;//m1                         
        // 0x00C1D7E0: B #0xc1d668                |  goto label_43;                         
        goto label_43;
        label_28:
        // 0x00C1D7E4: LDR w8, [x11]              | W8 = (X21 + 152 + 8);                   
        var val_20 = val_14;
        // 0x00C1D7E8: ADD w8, w8, w22            | W8 = ((X21 + 152 + 8) + X20 + 76);      
        val_20 = val_20 + (X20 + 76);
        // 0x00C1D7EC: ADD x8, x9, w8, uxtw #4    | X8 = (X21 + ((X21 + 152 + 8) + X20 + 76));
        val_20 = X21 + val_20;
        // 0x00C1D7F0: ADD x0, x8, #0x110         | X0 = ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272);
        val_16 = val_20 + 272;
        label_30:
        // 0x00C1D7F4: LDP x3, x2, [x0]           | X3 = ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272); X2 = ((X21 + ((X21 + 152 + 8) + X20 + 76)) + 272) + 8; //  | 
        label_38:
        // 0x00C1D7F8: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00C1D7FC: MOV x1, x19                | X1 = obj;//m1                           
        // 0x00C1D800: B #0xc1d648                |  goto label_42;                         
        goto label_42;
        label_33:
        // 0x00C1D804: LDR w8, [x11]              | W8 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00C1D808: ADD w8, w8, w21            | W8 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X20 + 76);
        // 0x00C1D80C: ADD x8, x9, w8, uxtw #4    | X8 = (1152921504692629504 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X20 + 76));
        // 0x00C1D810: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504692629504 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X20 + 76)).272
        label_35:
        // 0x00C1D814: LDP x2, x1, [x0]           | X2 = typeof(UnityEngine.Sprite);         //  | 
        // 0x00C1D818: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00C1D81C: B #0xc1d668                |  goto label_43;                         
        goto label_43;
    
    }
    //
    // Offset in libil2cpp.so: 0x00C1E44C (12706892), len: 36  VirtAddr: 0x00C1E44C RVA: 0x00C1E44C token: 100696614 methodIndex: 28302 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual System.IAsyncResult BeginInvoke(UnityEngine.GameObject obj, System.AsyncCallback callback, object object)
    {
        //
        // Disasemble & Code
        // 0x00C1E44C: STP x29, x30, [sp, #-0x10]! | stack[1152921515560878720] = ???;  stack[1152921515560878728] = ???;  //  dest_result_addr=1152921515560878720 |  dest_result_addr=1152921515560878728
        // 0x00C1E450: MOV x29, sp                | X29 = 1152921515560878720 (0x100000028CE94280);//ML01
        // 0x00C1E454: STP xzr, xzr, [sp, #-0x10]! | stack[1152921515560878704] = 0x0;  stack[1152921515560878712] = 0x0;  //  dest_result_addr=1152921515560878704 |  dest_result_addr=1152921515560878712
        // 0x00C1E458: STR x1, [sp]               | stack[1152921515560878704] = obj;        //  dest_result_addr=1152921515560878704
        // 0x00C1E45C: MOV x1, sp                 | X1 = 1152921515560878704 (0x100000028CE94270);//ML01
        // 0x00C1E460: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
        // 0x00C1E464: MOV sp, x29                | SP = 1152921515560878720 (0x100000028CE94280);//ML01
        // 0x00C1E468: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00C1E46C: RET                        |  return (System.IAsyncResult)this;      
        return (System.IAsyncResult)this;
        //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00C1E470 (12706928), len: 64  VirtAddr: 0x00C1E470 RVA: 0x00C1E470 token: 100696615 methodIndex: 28303 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual bool EndInvoke(System.IAsyncResult result)
    {
        //
        // Disasemble & Code
        // 0x00C1E470: STP x20, x19, [sp, #-0x20]! | stack[1152921515561007088] = ???;  stack[1152921515561007096] = ???;  //  dest_result_addr=1152921515561007088 |  dest_result_addr=1152921515561007096
        // 0x00C1E474: STP x29, x30, [sp, #0x10]  | stack[1152921515561007104] = ???;  stack[1152921515561007112] = ???;  //  dest_result_addr=1152921515561007104 |  dest_result_addr=1152921515561007112
        // 0x00C1E478: ADD x29, sp, #0x10         | X29 = (1152921515561007088 + 16) = 1152921515561007104 (0x100000028CEB3800);
        // 0x00C1E47C: MOV x8, x1                 | X8 = result;//m1                        
        // 0x00C1E480: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00C1E484: MOV x0, x8                 | X0 = result;//m1                        
        // 0x00C1E488: BL #0x278fde8              | X0 = sub_278FDE8( ?? result, ????);     
        // 0x00C1E48C: MOV x19, x0                | X19 = result;//m1                       
        // 0x00C1E490: CBNZ x19, #0xc1e498        | if (result != null) goto label_0;       
        if(result != null)
        {
            goto label_0;
        }
        // 0x00C1E494: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? result, ????);     
        label_0:
        // 0x00C1E498: MOV x0, x19                | X0 = result;//m1                        
        // 0x00C1E49C: BL #0x27bc4e8              | result.System.IDisposable.Dispose();    
        result.System.IDisposable.Dispose();
        // 0x00C1E4A0: LDRB w0, [x0]              | W0 = typeof(System.IAsyncResult);       
        // 0x00C1E4A4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00C1E4A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00C1E4AC: RET                        |  return (System.Boolean)typeof(System.IAsyncResult);
        return (bool)null;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }

}
