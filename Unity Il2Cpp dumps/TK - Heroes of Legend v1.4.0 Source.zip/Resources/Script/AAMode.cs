using UnityEngine;
[Serializable]
public enum AAMode
{
    // Fields
    FXAA2 = 0
    ,FXAA3Console = 1
    ,FXAA1PresetA = 2
    ,FXAA1PresetB = 3
    ,NFAA = 4
    ,SSAA = 5
    ,DLAA = 6
    

}
