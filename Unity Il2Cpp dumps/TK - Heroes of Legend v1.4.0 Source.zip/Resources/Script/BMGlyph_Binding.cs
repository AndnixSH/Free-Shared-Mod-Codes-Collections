using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class BMGlyph_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache12; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache13; // static_offset: 0x00000098
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache14; // static_offset: 0x000000A0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache15; // static_offset: 0x000000A8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache16; // static_offset: 0x000000B0
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache17; // static_offset: 0x000000B8
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x000000C0
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x000000C8
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BCF6A8 (12383912), len: 8  VirtAddr: 0x00BCF6A8 RVA: 0x00BCF6A8 token: 100663881 methodIndex: 29926 delegateWrapperIndex: 0 methodInvoker: 0
        public BMGlyph_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BCF6A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF6AC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCF6B0 (12383920), len: 4648  VirtAddr: 0x00BCF6B0 RVA: 0x00BCF6B0 token: 100663882 methodIndex: 29927 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_40;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_41;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_42;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_43;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_45;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_46;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_47;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_48;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_49;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_50;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_51;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_52;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_53;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_54;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_55;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_56;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_57;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_58;
            // 0x00BCF6B0: STP x28, x27, [sp, #-0x60]! | stack[1152921510064401600] = ???;  stack[1152921510064401608] = ???;  //  dest_result_addr=1152921510064401600 |  dest_result_addr=1152921510064401608
            // 0x00BCF6B4: STP x26, x25, [sp, #0x10]  | stack[1152921510064401616] = ???;  stack[1152921510064401624] = ???;  //  dest_result_addr=1152921510064401616 |  dest_result_addr=1152921510064401624
            // 0x00BCF6B8: STP x24, x23, [sp, #0x20]  | stack[1152921510064401632] = ???;  stack[1152921510064401640] = ???;  //  dest_result_addr=1152921510064401632 |  dest_result_addr=1152921510064401640
            // 0x00BCF6BC: STP x22, x21, [sp, #0x30]  | stack[1152921510064401648] = ???;  stack[1152921510064401656] = ???;  //  dest_result_addr=1152921510064401648 |  dest_result_addr=1152921510064401656
            // 0x00BCF6C0: STP x20, x19, [sp, #0x40]  | stack[1152921510064401664] = ???;  stack[1152921510064401672] = ???;  //  dest_result_addr=1152921510064401664 |  dest_result_addr=1152921510064401672
            // 0x00BCF6C4: STP x29, x30, [sp, #0x50]  | stack[1152921510064401680] = ???;  stack[1152921510064401688] = ???;  //  dest_result_addr=1152921510064401680 |  dest_result_addr=1152921510064401688
            // 0x00BCF6C8: ADD x29, sp, #0x50         | X29 = (1152921510064401600 + 80) = 1152921510064401680 (0x10000001454BAD10);
            // 0x00BCF6CC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCF6D0: LDRB w8, [x20, #0xbcf]     | W8 = (bool)static_value_03733BCF;       
            // 0x00BCF6D4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCF6D8: TBNZ w8, #0, #0xbcf6f4     | if (static_value_03733BCF == true) goto label_0;
            // 0x00BCF6DC: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x00BCF6E0: LDR x8, [x8, #0x3b8]       | X8 = 0x2B8F78C;                         
            // 0x00BCF6E4: LDR w0, [x8]               | W0 = 0x14A7;                            
            // 0x00BCF6E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A7, ????);     
            // 0x00BCF6EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCF6F0: STRB w8, [x20, #0xbcf]     | static_value_03733BCF = true;            //  dest_result_addr=57883599
            label_0:
            // 0x00BCF6F4: ADRP x27, #0x3620000       | X27 = 56754176 (0x3620000);             
            // 0x00BCF6F8: LDR x27, [x27, #0x340]     | X27 = 1152921504609562624;              
            // 0x00BCF6FC: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x00BCF700: LDR x0, [x27]              | X0 = typeof(System.Type);               
            // 0x00BCF704: LDR x8, [x8, #0xaf8]       | X8 = 1152921504875962368;               
            // 0x00BCF708: LDR x20, [x8]              | X20 = typeof(BMGlyph);                  
            // 0x00BCF70C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCF710: TBZ w8, #0, #0xbcf720      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BCF714: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCF718: CBNZ w8, #0xbcf720         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BCF71C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BCF720: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF724: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCF728: MOV x1, x20                | X1 = 1152921504875962368 (0x10000000100A6000);//ML01
            // 0x00BCF72C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCF730: ADRP x24, #0x35ef000       | X24 = 56553472 (0x35EF000);             
            // 0x00BCF734: LDR x24, [x24, #0xff0]     | X24 = 1152921504987155056;              
            // 0x00BCF738: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BCF73C: LDR x21, [x24]             | X21 = typeof(System.Type[]);            
            // 0x00BCF740: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCF744: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCF748: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BCF74C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCF750: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCF754: ADRP x26, #0x3611000       | X26 = 56692736 (0x3611000);             
            // 0x00BCF758: LDR x26, [x26, #0x9a8]     | X26 = 1152921504607113216;              
            // 0x00BCF75C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCF760: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF764: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCF768: LDR x1, [x26]              | X1 = typeof(System.Int32);              
            // 0x00BCF76C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCF770: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x00BCF774: CBNZ x21, #0xbcf77c        | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x00BCF778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x00BCF77C: CBZ x22, #0xbcf7a0         | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x00BCF780: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCF784: MOV x0, x22                | X0 = val_2;//m1                         
            // 0x00BCF788: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCF78C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00BCF790: CBNZ x0, #0xbcf7a0         | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x00BCF794: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00BCF798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF79C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_5:
            // 0x00BCF7A0: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCF7A4: CBNZ w8, #0xbcf7b4         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x00BCF7A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00BCF7AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF7B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x00BCF7B4: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;
            // 0x00BCF7B8: CBNZ x20, #0xbcf7c0        | if (val_1 != null) goto label_7;        
            if(val_1 != null)
            {
                goto label_7;
            }
            // 0x00BCF7BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x00BCF7C0: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00BCF7C4: LDR x8, [x8, #0x490]       | X8 = (string**)(1152921510064321200)("GetKerning");
            // 0x00BCF7C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF7CC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCF7D0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCF7D4: LDR x1, [x8]               | X1 = "GetKerning";                      
            // 0x00BCF7D8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCF7DC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCF7E0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCF7E4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetKerning", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_3 = val_1.GetMethod(name:  "GetKerning", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCF7E8: ADRP x25, #0x366d000       | X25 = 57069568 (0x366D000);             
            // 0x00BCF7EC: LDR x25, [x25, #0x908]     | X25 = 1152921504783204352;              
            // 0x00BCF7F0: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCF7F4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCF7F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCF7FC: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache0;
            // 0x00BCF800: CBNZ x22, #0xbcf84c        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache0 != null) goto label_8;
            if((ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache0) != null)
            {
                goto label_8;
            }
            // 0x00BCF804: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00BCF808: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCF80C: LDR x8, [x8, #0xed8]       | X8 = 1152921510064325392;               
            // 0x00BCF810: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCF814: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::GetKerning_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCF818: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_4 = null;
            // 0x00BCF81C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCF820: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF824: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF828: MOV x2, x22                | X2 = 1152921510064325392 (0x10000001454A8310);//ML01
            // 0x00BCF82C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_39 = val_4;
            // 0x00BCF830: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::GetKerning_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::GetKerning_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCF834: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCF838: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCF83C: STR x23, [x8]              | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783208448
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache0 = val_39;
            // 0x00BCF840: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCF844: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCF848: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_8:
            // 0x00BCF84C: CBNZ x19, #0xbcf854        | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x00BCF850: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::GetKerning_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_9:
            // 0x00BCF854: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF858: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCF85C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCF860: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCF864: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_3, func:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache0);
            X1.RegisterCLRMethodRedirection(mi:  val_3, func:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache0);
            // 0x00BCF868: LDR x21, [x24]             | X21 = typeof(System.Type[]);            
            // 0x00BCF86C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCF870: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCF874: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BCF878: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCF87C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCF880: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BCF884: LDR x22, [x26]             | X22 = typeof(System.Int32);             
            // 0x00BCF888: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCF88C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCF890: TBZ w9, #0, #0xbcf8a4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00BCF894: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCF898: CBNZ w9, #0xbcf8a4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00BCF89C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCF8A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_11:
            // 0x00BCF8A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF8A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCF8AC: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BCF8B0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCF8B4: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCF8B8: CBNZ x21, #0xbcf8c0        | if ( != null) goto label_12;            
            if(null != null)
            {
                goto label_12;
            }
            // 0x00BCF8BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x00BCF8C0: CBZ x22, #0xbcf8e4         | if (val_5 == null) goto label_14;       
            if(val_5 == null)
            {
                goto label_14;
            }
            // 0x00BCF8C4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCF8C8: MOV x0, x22                | X0 = val_5;//m1                         
            // 0x00BCF8CC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCF8D0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
            // 0x00BCF8D4: CBNZ x0, #0xbcf8e4         | if (val_5 != null) goto label_14;       
            if(val_5 != null)
            {
                goto label_14;
            }
            // 0x00BCF8D8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
            // 0x00BCF8DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF8E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_14:
            // 0x00BCF8E4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCF8E8: CBNZ w8, #0xbcf8f8         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_15;
            // 0x00BCF8EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x00BCF8F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF8F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_15:
            // 0x00BCF8F8: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_5;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_5;
            // 0x00BCF8FC: LDR x1, [x26]              | X1 = typeof(System.Int32);              
            // 0x00BCF900: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF904: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCF908: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCF90C: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x00BCF910: CBZ x22, #0xbcf934         | if (val_6 == null) goto label_17;       
            if(val_6 == null)
            {
                goto label_17;
            }
            // 0x00BCF914: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCF918: MOV x0, x22                | X0 = val_6;//m1                         
            // 0x00BCF91C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCF920: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x00BCF924: CBNZ x0, #0xbcf934         | if (val_6 != null) goto label_17;       
            if(val_6 != null)
            {
                goto label_17;
            }
            // 0x00BCF928: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
            // 0x00BCF92C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF930: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_17:
            // 0x00BCF934: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCF938: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BCF93C: B.HI #0xbcf94c             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_18;
            // 0x00BCF940: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x00BCF944: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF948: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_18:
            // 0x00BCF94C: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_6;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_6;
            // 0x00BCF950: CBNZ x20, #0xbcf958        | if (val_1 != null) goto label_19;       
            if(val_1 != null)
            {
                goto label_19;
            }
            // 0x00BCF954: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_19:
            // 0x00BCF958: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00BCF95C: LDR x8, [x8, #0x710]       | X8 = (string**)(1152921510064334608)("SetKerning");
            // 0x00BCF960: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF964: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCF968: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCF96C: LDR x1, [x8]               | X1 = "SetKerning";                      
            // 0x00BCF970: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCF974: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCF978: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCF97C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SetKerning", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_7 = val_1.GetMethod(name:  "SetKerning", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCF980: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCF984: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x00BCF988: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCF98C: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache1;
            // 0x00BCF990: CBNZ x22, #0xbcf9dc        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache1 != null) goto label_20;
            if((ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache1) != null)
            {
                goto label_20;
            }
            // 0x00BCF994: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x00BCF998: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCF99C: LDR x8, [x8, #0xc38]       | X8 = 1152921510064338800;               
            // 0x00BCF9A0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCF9A4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::SetKerning_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCF9A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_8 = null;
            // 0x00BCF9AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCF9B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF9B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF9B8: MOV x2, x22                | X2 = 1152921510064338800 (0x10000001454AB770);//ML01
            // 0x00BCF9BC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_39 = val_8;
            // 0x00BCF9C0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::SetKerning_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_8 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::SetKerning_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCF9C4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCF9C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCF9CC: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783208456
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache1 = val_39;
            // 0x00BCF9D0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCF9D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCF9D8: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_20:
            // 0x00BCF9DC: CBNZ x19, #0xbcf9e4        | if (X1 != 0) goto label_21;             
            if(X1 != 0)
            {
                goto label_21;
            }
            // 0x00BCF9E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::SetKerning_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_21:
            // 0x00BCF9E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF9E8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCF9EC: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x00BCF9F0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCF9F4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_7, func:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache1);
            X1.RegisterCLRMethodRedirection(mi:  val_7, func:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache1);
            // 0x00BCF9F8: LDR x21, [x24]             | X21 = typeof(System.Type[]);            
            // 0x00BCF9FC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCFA00: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCFA04: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00BCFA08: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCFA0C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCFA10: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BCFA14: LDR x22, [x26]             | X22 = typeof(System.Int32);             
            // 0x00BCFA18: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCFA1C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCFA20: TBZ w9, #0, #0xbcfa34      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x00BCFA24: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCFA28: CBNZ w9, #0xbcfa34         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x00BCFA2C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCFA30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_23:
            // 0x00BCFA34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCFA38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCFA3C: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BCFA40: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCFA44: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00BCFA48: CBNZ x21, #0xbcfa50        | if ( != null) goto label_24;            
            if(null != null)
            {
                goto label_24;
            }
            // 0x00BCFA4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_24:
            // 0x00BCFA50: CBZ x22, #0xbcfa74         | if (val_9 == null) goto label_26;       
            if(val_9 == null)
            {
                goto label_26;
            }
            // 0x00BCFA54: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCFA58: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x00BCFA5C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCFA60: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x00BCFA64: CBNZ x0, #0xbcfa74         | if (val_9 != null) goto label_26;       
            if(val_9 != null)
            {
                goto label_26;
            }
            // 0x00BCFA68: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x00BCFA6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFA70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_26:
            // 0x00BCFA74: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCFA78: CBNZ w8, #0xbcfa88         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_27;
            // 0x00BCFA7C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x00BCFA80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFA84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_27:
            // 0x00BCFA88: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;
            // 0x00BCFA8C: LDR x1, [x26]              | X1 = typeof(System.Int32);              
            // 0x00BCFA90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCFA94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCFA98: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCFA9C: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x00BCFAA0: CBZ x22, #0xbcfac4         | if (val_10 == null) goto label_29;      
            if(val_10 == null)
            {
                goto label_29;
            }
            // 0x00BCFAA4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCFAA8: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x00BCFAAC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCFAB0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x00BCFAB4: CBNZ x0, #0xbcfac4         | if (val_10 != null) goto label_29;      
            if(val_10 != null)
            {
                goto label_29;
            }
            // 0x00BCFAB8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_10, ????);     
            // 0x00BCFABC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFAC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_29:
            // 0x00BCFAC4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCFAC8: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BCFACC: B.HI #0xbcfadc             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_30;
            // 0x00BCFAD0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x00BCFAD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFAD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_30:
            // 0x00BCFADC: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_10;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_10;
            // 0x00BCFAE0: LDR x1, [x26]              | X1 = typeof(System.Int32);              
            // 0x00BCFAE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCFAE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCFAEC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCFAF0: MOV x22, x0                | X22 = val_11;//m1                       
            // 0x00BCFAF4: CBZ x22, #0xbcfb18         | if (val_11 == null) goto label_32;      
            if(val_11 == null)
            {
                goto label_32;
            }
            // 0x00BCFAF8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCFAFC: MOV x0, x22                | X0 = val_11;//m1                        
            // 0x00BCFB00: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCFB04: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
            // 0x00BCFB08: CBNZ x0, #0xbcfb18         | if (val_11 != null) goto label_32;      
            if(val_11 != null)
            {
                goto label_32;
            }
            // 0x00BCFB0C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
            // 0x00BCFB10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFB14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_32:
            // 0x00BCFB18: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCFB1C: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BCFB20: B.HI #0xbcfb30             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_33;
            // 0x00BCFB24: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
            // 0x00BCFB28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFB2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_33:
            // 0x00BCFB30: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_11;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_11;
            // 0x00BCFB34: LDR x1, [x26]              | X1 = typeof(System.Int32);              
            // 0x00BCFB38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCFB3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCFB40: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCFB44: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x00BCFB48: CBZ x22, #0xbcfb6c         | if (val_12 == null) goto label_35;      
            if(val_12 == null)
            {
                goto label_35;
            }
            // 0x00BCFB4C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCFB50: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x00BCFB54: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCFB58: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x00BCFB5C: CBNZ x0, #0xbcfb6c         | if (val_12 != null) goto label_35;      
            if(val_12 != null)
            {
                goto label_35;
            }
            // 0x00BCFB60: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
            // 0x00BCFB64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFB68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_35:
            // 0x00BCFB6C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCFB70: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x00BCFB74: B.HI #0xbcfb84             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_36;
            // 0x00BCFB78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
            // 0x00BCFB7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFB80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_36:
            // 0x00BCFB84: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_12;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_12;
            // 0x00BCFB88: CBNZ x20, #0xbcfb90        | if (val_1 != null) goto label_37;       
            if(val_1 != null)
            {
                goto label_37;
            }
            // 0x00BCFB8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_37:
            // 0x00BCFB90: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BCFB94: LDR x8, [x8, #0x6c8]       | X8 = (string**)(1152921510060632416)("Trim");
            // 0x00BCFB98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFB9C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCFBA0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCFBA4: LDR x1, [x8]               | X1 = "Trim";                            
            // 0x00BCFBA8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCFBAC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCFBB0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCFBB4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Trim", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_13 = val_1.GetMethod(name:  "Trim", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCFBB8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFBBC: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x00BCFBC0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFBC4: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache2;
            // 0x00BCFBC8: CBNZ x22, #0xbcfc14        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache2 != null) goto label_38;
            if((ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache2) != null)
            {
                goto label_38;
            }
            // 0x00BCFBCC: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00BCFBD0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCFBD4: LDR x8, [x8, #0x388]       | X8 = 1152921510064360304;               
            // 0x00BCFBD8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCFBDC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::Trim_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCFBE0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_14 = null;
            // 0x00BCFBE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCFBE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFBEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFBF0: MOV x2, x22                | X2 = 1152921510064360304 (0x10000001454B0B70);//ML01
            // 0x00BCFBF4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_39 = val_14;
            // 0x00BCFBF8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::Trim_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_14 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::Trim_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCFBFC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFC00: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFC04: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783208464
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache2 = val_39;
            // 0x00BCFC08: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFC0C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFC10: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_38:
            // 0x00BCFC14: CBNZ x19, #0xbcfc1c        | if (X1 != 0) goto label_39;             
            if(X1 != 0)
            {
                goto label_39;
            }
            // 0x00BCFC18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::Trim_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_39:
            // 0x00BCFC1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFC20: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCFC24: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x00BCFC28: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCFC2C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache2);
            X1.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache2);
            // 0x00BCFC30: CBNZ x20, #0xbcfc38        | if (val_1 != null) goto label_40;       
            if(val_1 != null)
            {
                goto label_40;
            }
            // 0x00BCFC34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_40:
            // 0x00BCFC38: ADRP x9, #0x363c000        | X9 = 56868864 (0x363C000);              
            // 0x00BCFC3C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BCFC40: LDR x9, [x9, #0x158]       | X9 = (string**)(1152921510064361328)("index");
            // 0x00BCFC44: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCFC48: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCFC4C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BCFC50: LDR x1, [x9]               | X1 = "index";                           
            // 0x00BCFC54: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BCFC58: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BCFC5C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFC60: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BCFC64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFC68: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache3;
            // 0x00BCFC6C: CBNZ x22, #0xbcfcb8        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache3 != null) goto label_41;
            if((ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache3) != null)
            {
                goto label_41;
            }
            // 0x00BCFC70: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x00BCFC74: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BCFC78: LDR x8, [x8, #0x818]       | X8 = 1152921510064361408;               
            // 0x00BCFC7C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BCFC80: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_index_0(ref object o);
            // 0x00BCFC84: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_15 = null;
            // 0x00BCFC88: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BCFC8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFC90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFC94: MOV x2, x22                | X2 = 1152921510064361408 (0x10000001454B0FC0);//ML01
            // 0x00BCFC98: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_15;
            // 0x00BCFC9C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_index_0(ref object o));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_index_0(ref object o));
            // 0x00BCFCA0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFCA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFCA8: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208472
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache3 = val_39;
            // 0x00BCFCAC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFCB0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFCB4: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            label_41:
            // 0x00BCFCB8: CBNZ x19, #0xbcfcc0        | if (X1 != 0) goto label_42;             
            if(X1 != 0)
            {
                goto label_42;
            }
            // 0x00BCFCBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_index_0(ref object o)), ????);
            label_42:
            // 0x00BCFCC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFCC4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCFCC8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BCFCCC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BCFCD0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache3);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache3);
            // 0x00BCFCD4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFCD8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFCDC: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache4;
            // 0x00BCFCE0: CBNZ x22, #0xbcfd2c        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache4 != null) goto label_43;
            if((ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache4) != null)
            {
                goto label_43;
            }
            // 0x00BCFCE4: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00BCFCE8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BCFCEC: LDR x8, [x8, #0xfd0]       | X8 = 1152921510064362432;               
            // 0x00BCFCF0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BCFCF4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_index_0(ref object o, object v);
            // 0x00BCFCF8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_16 = null;
            // 0x00BCFCFC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BCFD00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFD04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFD08: MOV x2, x22                | X2 = 1152921510064362432 (0x10000001454B13C0);//ML01
            // 0x00BCFD0C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_16;
            // 0x00BCFD10: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_index_0(ref object o, object v));
            val_16 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_index_0(ref object o, object v));
            // 0x00BCFD14: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFD18: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFD1C: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208480
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache4 = val_39;
            // 0x00BCFD20: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFD24: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFD28: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            label_43:
            // 0x00BCFD2C: CBNZ x19, #0xbcfd34        | if (X1 != 0) goto label_44;             
            if(X1 != 0)
            {
                goto label_44;
            }
            // 0x00BCFD30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_index_0(ref object o, object v)), ????);
            label_44:
            // 0x00BCFD34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFD38: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCFD3C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BCFD40: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BCFD44: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache4);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache4);
            // 0x00BCFD48: CBNZ x20, #0xbcfd50        | if (val_1 != null) goto label_45;       
            if(val_1 != null)
            {
                goto label_45;
            }
            // 0x00BCFD4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_45:
            // 0x00BCFD50: ADRP x9, #0x35ea000        | X9 = 56532992 (0x35EA000);              
            // 0x00BCFD54: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BCFD58: LDR x9, [x9, #0x3c0]       | X9 = (string**)(1152921510064363456)("x");
            // 0x00BCFD5C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCFD60: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCFD64: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BCFD68: LDR x1, [x9]               | X1 = "x";                               
            // 0x00BCFD6C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BCFD70: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BCFD74: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFD78: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BCFD7C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFD80: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache5;
            // 0x00BCFD84: CBNZ x22, #0xbcfdd0        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache5 != null) goto label_46;
            if((ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache5) != null)
            {
                goto label_46;
            }
            // 0x00BCFD88: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00BCFD8C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BCFD90: LDR x8, [x8, #0x3a0]       | X8 = 1152921510064363536;               
            // 0x00BCFD94: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BCFD98: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_x_1(ref object o);
            // 0x00BCFD9C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_17 = null;
            // 0x00BCFDA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BCFDA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFDA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFDAC: MOV x2, x22                | X2 = 1152921510064363536 (0x10000001454B1810);//ML01
            // 0x00BCFDB0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_17;
            // 0x00BCFDB4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_x_1(ref object o));
            val_17 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_x_1(ref object o));
            // 0x00BCFDB8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFDBC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFDC0: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208488
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache5 = val_39;
            // 0x00BCFDC4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFDC8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFDCC: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            label_46:
            // 0x00BCFDD0: CBNZ x19, #0xbcfdd8        | if (X1 != 0) goto label_47;             
            if(X1 != 0)
            {
                goto label_47;
            }
            // 0x00BCFDD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_x_1(ref object o)), ????);
            label_47:
            // 0x00BCFDD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFDDC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCFDE0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BCFDE4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BCFDE8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache5);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache5);
            // 0x00BCFDEC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFDF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFDF4: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache6;
            // 0x00BCFDF8: CBNZ x22, #0xbcfe44        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache6 != null) goto label_48;
            if((ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache6) != null)
            {
                goto label_48;
            }
            // 0x00BCFDFC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00BCFE00: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BCFE04: LDR x8, [x8, #0x8a8]       | X8 = 1152921510064364560;               
            // 0x00BCFE08: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BCFE0C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_x_1(ref object o, object v);
            // 0x00BCFE10: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_18 = null;
            // 0x00BCFE14: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BCFE18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFE1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFE20: MOV x2, x22                | X2 = 1152921510064364560 (0x10000001454B1C10);//ML01
            // 0x00BCFE24: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_18;
            // 0x00BCFE28: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_x_1(ref object o, object v));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_x_1(ref object o, object v));
            // 0x00BCFE2C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFE30: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFE34: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208496
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache6 = val_39;
            // 0x00BCFE38: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFE3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFE40: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            label_48:
            // 0x00BCFE44: CBNZ x19, #0xbcfe4c        | if (X1 != 0) goto label_49;             
            if(X1 != 0)
            {
                goto label_49;
            }
            // 0x00BCFE48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_x_1(ref object o, object v)), ????);
            label_49:
            // 0x00BCFE4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFE50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCFE54: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BCFE58: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BCFE5C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache6);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache6);
            // 0x00BCFE60: CBNZ x20, #0xbcfe68        | if (val_1 != null) goto label_50;       
            if(val_1 != null)
            {
                goto label_50;
            }
            // 0x00BCFE64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_50:
            // 0x00BCFE68: ADRP x9, #0x361a000        | X9 = 56729600 (0x361A000);              
            // 0x00BCFE6C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BCFE70: LDR x9, [x9, #0xe50]       | X9 = (string**)(1152921510064365584)("y");
            // 0x00BCFE74: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCFE78: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCFE7C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BCFE80: LDR x1, [x9]               | X1 = "y";                               
            // 0x00BCFE84: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BCFE88: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BCFE8C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFE90: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BCFE94: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFE98: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache7;
            val_40 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache7;
            // 0x00BCFE9C: CBNZ x22, #0xbcfee8        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache7 != null) goto label_51;
            if(val_40 != null)
            {
                goto label_51;
            }
            // 0x00BCFEA0: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00BCFEA4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BCFEA8: LDR x8, [x8, #0xce0]       | X8 = 1152921510064365664;               
            // 0x00BCFEAC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BCFEB0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_y_2(ref object o);
            // 0x00BCFEB4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_19 = null;
            // 0x00BCFEB8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BCFEBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFEC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFEC4: MOV x2, x22                | X2 = 1152921510064365664 (0x10000001454B2060);//ML01
            // 0x00BCFEC8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_19;
            // 0x00BCFECC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_y_2(ref object o));
            val_19 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_y_2(ref object o));
            // 0x00BCFED0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFED4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFED8: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208504
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache7 = val_39;
            // 0x00BCFEDC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFEE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFEE4: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_40 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache7;
            label_51:
            // 0x00BCFEE8: CBNZ x19, #0xbcfef0        | if (X1 != 0) goto label_52;             
            if(X1 != 0)
            {
                goto label_52;
            }
            // 0x00BCFEEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_y_2(ref object o)), ????);
            label_52:
            // 0x00BCFEF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFEF4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCFEF8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BCFEFC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BCFF00: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_40);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_40);
            // 0x00BCFF04: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFF08: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFF0C: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache8;
            val_41 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache8;
            // 0x00BCFF10: CBNZ x22, #0xbcff5c        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache8 != null) goto label_53;
            if(val_41 != null)
            {
                goto label_53;
            }
            // 0x00BCFF14: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x00BCFF18: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BCFF1C: LDR x8, [x8, #0x638]       | X8 = 1152921510064366688;               
            // 0x00BCFF20: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BCFF24: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_y_2(ref object o, object v);
            // 0x00BCFF28: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_20 = null;
            // 0x00BCFF2C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BCFF30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFF34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFF38: MOV x2, x22                | X2 = 1152921510064366688 (0x10000001454B2460);//ML01
            // 0x00BCFF3C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_20;
            // 0x00BCFF40: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_y_2(ref object o, object v));
            val_20 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_y_2(ref object o, object v));
            // 0x00BCFF44: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFF48: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFF4C: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208512
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache8 = val_39;
            // 0x00BCFF50: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFF54: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFF58: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_41 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache8;
            label_53:
            // 0x00BCFF5C: CBNZ x19, #0xbcff64        | if (X1 != 0) goto label_54;             
            if(X1 != 0)
            {
                goto label_54;
            }
            // 0x00BCFF60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_y_2(ref object o, object v)), ????);
            label_54:
            // 0x00BCFF64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFF68: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCFF6C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BCFF70: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BCFF74: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_41);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_41);
            // 0x00BCFF78: CBNZ x20, #0xbcff80        | if (val_1 != null) goto label_55;       
            if(val_1 != null)
            {
                goto label_55;
            }
            // 0x00BCFF7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_55:
            // 0x00BCFF80: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BCFF84: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BCFF88: LDR x9, [x9, #0x600]       | X9 = (string**)(1152921510042161424)("width");
            // 0x00BCFF8C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCFF90: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCFF94: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BCFF98: LDR x1, [x9]               | X1 = "width";                           
            // 0x00BCFF9C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BCFFA0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BCFFA4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFFA8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BCFFAC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFFB0: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache9;
            val_42 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache9;
            // 0x00BCFFB4: CBNZ x22, #0xbd0000        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache9 != null) goto label_56;
            if(val_42 != null)
            {
                goto label_56;
            }
            // 0x00BCFFB8: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x00BCFFBC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BCFFC0: LDR x8, [x8, #0x638]       | X8 = 1152921510064367712;               
            // 0x00BCFFC4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BCFFC8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_width_3(ref object o);
            // 0x00BCFFCC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_21 = null;
            // 0x00BCFFD0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BCFFD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCFFD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCFFDC: MOV x2, x22                | X2 = 1152921510064367712 (0x10000001454B2860);//ML01
            // 0x00BCFFE0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_21;
            // 0x00BCFFE4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_width_3(ref object o));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_width_3(ref object o));
            // 0x00BCFFE8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFFEC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFFF0: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208520
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache9 = val_39;
            // 0x00BCFFF4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BCFFF8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCFFFC: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_42 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache9;
            label_56:
            // 0x00BD0000: CBNZ x19, #0xbd0008        | if (X1 != 0) goto label_57;             
            if(X1 != 0)
            {
                goto label_57;
            }
            // 0x00BD0004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_width_3(ref object o)), ????);
            label_57:
            // 0x00BD0008: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD000C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0010: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD0014: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD0018: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_42);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_42);
            // 0x00BD001C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0020: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0024: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheA;
            val_43 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheA;
            // 0x00BD0028: CBNZ x22, #0xbd0074        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheA != null) goto label_58;
            if(val_43 != null)
            {
                goto label_58;
            }
            // 0x00BD002C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x00BD0030: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD0034: LDR x8, [x8, #0xad8]       | X8 = 1152921510064368736;               
            // 0x00BD0038: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD003C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_width_3(ref object o, object v);
            // 0x00BD0040: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_22 = null;
            // 0x00BD0044: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD0048: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD004C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0050: MOV x2, x22                | X2 = 1152921510064368736 (0x10000001454B2C60);//ML01
            // 0x00BD0054: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_22;
            // 0x00BD0058: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_width_3(ref object o, object v));
            val_22 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_width_3(ref object o, object v));
            // 0x00BD005C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0060: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0064: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208528
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheA = val_39;
            // 0x00BD0068: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD006C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0070: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_43 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheA;
            label_58:
            // 0x00BD0074: CBNZ x19, #0xbd007c        | if (X1 != 0) goto label_59;             
            if(X1 != 0)
            {
                goto label_59;
            }
            // 0x00BD0078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_width_3(ref object o, object v)), ????);
            label_59:
            // 0x00BD007C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0080: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0084: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD0088: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD008C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_43);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_43);
            // 0x00BD0090: CBNZ x20, #0xbd0098        | if (val_1 != null) goto label_60;       
            if(val_1 != null)
            {
                goto label_60;
            }
            // 0x00BD0094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_60:
            // 0x00BD0098: ADRP x9, #0x35d0000        | X9 = 56426496 (0x35D0000);              
            // 0x00BD009C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BD00A0: LDR x9, [x9, #0x3f0]       | X9 = (string**)(1152921510042163552)("height");
            // 0x00BD00A4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD00A8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD00AC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BD00B0: LDR x1, [x9]               | X1 = "height";                          
            // 0x00BD00B4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BD00B8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BD00BC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD00C0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BD00C4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD00C8: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheB;
            val_44 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheB;
            // 0x00BD00CC: CBNZ x22, #0xbd0118        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheB != null) goto label_61;
            if(val_44 != null)
            {
                goto label_61;
            }
            // 0x00BD00D0: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00BD00D4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD00D8: LDR x8, [x8, #0xfc8]       | X8 = 1152921510064369760;               
            // 0x00BD00DC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BD00E0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_height_4(ref object o);
            // 0x00BD00E4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_23 = null;
            // 0x00BD00E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BD00EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD00F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD00F4: MOV x2, x22                | X2 = 1152921510064369760 (0x10000001454B3060);//ML01
            // 0x00BD00F8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_23;
            // 0x00BD00FC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_height_4(ref object o));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_height_4(ref object o));
            // 0x00BD0100: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0104: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0108: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208536
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheB = val_39;
            // 0x00BD010C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0110: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0114: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_44 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheB;
            label_61:
            // 0x00BD0118: CBNZ x19, #0xbd0120        | if (X1 != 0) goto label_62;             
            if(X1 != 0)
            {
                goto label_62;
            }
            // 0x00BD011C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_height_4(ref object o)), ????);
            label_62:
            // 0x00BD0120: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0124: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0128: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD012C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD0130: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_44);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_44);
            // 0x00BD0134: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0138: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD013C: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheC;
            val_45 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheC;
            // 0x00BD0140: CBNZ x22, #0xbd018c        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheC != null) goto label_63;
            if(val_45 != null)
            {
                goto label_63;
            }
            // 0x00BD0144: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00BD0148: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD014C: LDR x8, [x8, #0x3c0]       | X8 = 1152921510064370784;               
            // 0x00BD0150: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD0154: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_height_4(ref object o, object v);
            // 0x00BD0158: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_24 = null;
            // 0x00BD015C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD0160: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0164: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0168: MOV x2, x22                | X2 = 1152921510064370784 (0x10000001454B3460);//ML01
            // 0x00BD016C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_24;
            // 0x00BD0170: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_height_4(ref object o, object v));
            val_24 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_height_4(ref object o, object v));
            // 0x00BD0174: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0178: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD017C: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208544
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheC = val_39;
            // 0x00BD0180: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0184: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0188: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_45 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheC;
            label_63:
            // 0x00BD018C: CBNZ x19, #0xbd0194        | if (X1 != 0) goto label_64;             
            if(X1 != 0)
            {
                goto label_64;
            }
            // 0x00BD0190: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_height_4(ref object o, object v)), ????);
            label_64:
            // 0x00BD0194: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0198: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD019C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD01A0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD01A4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_45);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_45);
            // 0x00BD01A8: CBNZ x20, #0xbd01b0        | if (val_1 != null) goto label_65;       
            if(val_1 != null)
            {
                goto label_65;
            }
            // 0x00BD01AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_65:
            // 0x00BD01B0: ADRP x9, #0x3658000        | X9 = 56983552 (0x3658000);              
            // 0x00BD01B4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BD01B8: LDR x9, [x9, #0x600]       | X9 = (string**)(1152921510064371808)("offsetX");
            // 0x00BD01BC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD01C0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD01C4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BD01C8: LDR x1, [x9]               | X1 = "offsetX";                         
            // 0x00BD01CC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BD01D0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BD01D4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD01D8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BD01DC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD01E0: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheD;
            val_46 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheD;
            // 0x00BD01E4: CBNZ x22, #0xbd0230        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheD != null) goto label_66;
            if(val_46 != null)
            {
                goto label_66;
            }
            // 0x00BD01E8: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00BD01EC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD01F0: LDR x8, [x8, #0xf10]       | X8 = 1152921510064371904;               
            // 0x00BD01F4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BD01F8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_offsetX_5(ref object o);
            // 0x00BD01FC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_25 = null;
            // 0x00BD0200: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BD0204: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0208: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD020C: MOV x2, x22                | X2 = 1152921510064371904 (0x10000001454B38C0);//ML01
            // 0x00BD0210: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_25;
            // 0x00BD0214: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_offsetX_5(ref object o));
            val_25 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_offsetX_5(ref object o));
            // 0x00BD0218: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD021C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0220: STR x23, [x8, #0x68]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208552
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheD = val_39;
            // 0x00BD0224: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0228: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD022C: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_46 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheD;
            label_66:
            // 0x00BD0230: CBNZ x19, #0xbd0238        | if (X1 != 0) goto label_67;             
            if(X1 != 0)
            {
                goto label_67;
            }
            // 0x00BD0234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_offsetX_5(ref object o)), ????);
            label_67:
            // 0x00BD0238: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD023C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0240: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD0244: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD0248: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_46);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_46);
            // 0x00BD024C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0250: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0254: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheE;
            val_47 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheE;
            // 0x00BD0258: CBNZ x22, #0xbd02a4        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheE != null) goto label_68;
            if(val_47 != null)
            {
                goto label_68;
            }
            // 0x00BD025C: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x00BD0260: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD0264: LDR x8, [x8, #0x3a8]       | X8 = 1152921510064372928;               
            // 0x00BD0268: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD026C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_offsetX_5(ref object o, object v);
            // 0x00BD0270: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_26 = null;
            // 0x00BD0274: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD0278: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD027C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0280: MOV x2, x22                | X2 = 1152921510064372928 (0x10000001454B3CC0);//ML01
            // 0x00BD0284: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_26;
            // 0x00BD0288: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_offsetX_5(ref object o, object v));
            val_26 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_offsetX_5(ref object o, object v));
            // 0x00BD028C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0290: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0294: STR x23, [x8, #0x70]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208560
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheE = val_39;
            // 0x00BD0298: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD029C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD02A0: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_47 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheE;
            label_68:
            // 0x00BD02A4: CBNZ x19, #0xbd02ac        | if (X1 != 0) goto label_69;             
            if(X1 != 0)
            {
                goto label_69;
            }
            // 0x00BD02A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_offsetX_5(ref object o, object v)), ????);
            label_69:
            // 0x00BD02AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD02B0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD02B4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD02B8: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD02BC: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_47);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_47);
            // 0x00BD02C0: CBNZ x20, #0xbd02c8        | if (val_1 != null) goto label_70;       
            if(val_1 != null)
            {
                goto label_70;
            }
            // 0x00BD02C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_70:
            // 0x00BD02C8: ADRP x9, #0x3625000        | X9 = 56774656 (0x3625000);              
            // 0x00BD02CC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BD02D0: LDR x9, [x9, #0x808]       | X9 = (string**)(1152921510064373952)("offsetY");
            // 0x00BD02D4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD02D8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD02DC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BD02E0: LDR x1, [x9]               | X1 = "offsetY";                         
            // 0x00BD02E4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BD02E8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BD02EC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD02F0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BD02F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD02F8: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheF;
            val_48 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheF;
            // 0x00BD02FC: CBNZ x22, #0xbd0348        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheF != null) goto label_71;
            if(val_48 != null)
            {
                goto label_71;
            }
            // 0x00BD0300: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x00BD0304: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD0308: LDR x8, [x8, #0x278]       | X8 = 1152921510064374048;               
            // 0x00BD030C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BD0310: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_offsetY_6(ref object o);
            // 0x00BD0314: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_27 = null;
            // 0x00BD0318: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BD031C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0320: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0324: MOV x2, x22                | X2 = 1152921510064374048 (0x10000001454B4120);//ML01
            // 0x00BD0328: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_27;
            // 0x00BD032C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_offsetY_6(ref object o));
            val_27 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_offsetY_6(ref object o));
            // 0x00BD0330: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0334: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0338: STR x23, [x8, #0x78]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208568
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheF = val_39;
            // 0x00BD033C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0340: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0344: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_48 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cacheF;
            label_71:
            // 0x00BD0348: CBNZ x19, #0xbd0350        | if (X1 != 0) goto label_72;             
            if(X1 != 0)
            {
                goto label_72;
            }
            // 0x00BD034C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_offsetY_6(ref object o)), ????);
            label_72:
            // 0x00BD0350: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0354: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0358: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD035C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD0360: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_48);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_48);
            // 0x00BD0364: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0368: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD036C: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache10;
            val_49 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache10;
            // 0x00BD0370: CBNZ x22, #0xbd03bc        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache10 != null) goto label_73;
            if(val_49 != null)
            {
                goto label_73;
            }
            // 0x00BD0374: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BD0378: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD037C: LDR x8, [x8, #0x490]       | X8 = 1152921510064375072;               
            // 0x00BD0380: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD0384: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_offsetY_6(ref object o, object v);
            // 0x00BD0388: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_28 = null;
            // 0x00BD038C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD0390: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0394: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0398: MOV x2, x22                | X2 = 1152921510064375072 (0x10000001454B4520);//ML01
            // 0x00BD039C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_28;
            // 0x00BD03A0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_offsetY_6(ref object o, object v));
            val_28 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_offsetY_6(ref object o, object v));
            // 0x00BD03A4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD03A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD03AC: STR x23, [x8, #0x80]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208576
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache10 = val_39;
            // 0x00BD03B0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD03B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD03B8: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_49 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache10;
            label_73:
            // 0x00BD03BC: CBNZ x19, #0xbd03c4        | if (X1 != 0) goto label_74;             
            if(X1 != 0)
            {
                goto label_74;
            }
            // 0x00BD03C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_offsetY_6(ref object o, object v)), ????);
            label_74:
            // 0x00BD03C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD03C8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD03CC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD03D0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD03D4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_49);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_49);
            // 0x00BD03D8: CBNZ x20, #0xbd03e0        | if (val_1 != null) goto label_75;       
            if(val_1 != null)
            {
                goto label_75;
            }
            // 0x00BD03DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_75:
            // 0x00BD03E0: ADRP x9, #0x3612000        | X9 = 56696832 (0x3612000);              
            // 0x00BD03E4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BD03E8: LDR x9, [x9, #0xb20]       | X9 = (string**)(1152921510064376096)("advance");
            // 0x00BD03EC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD03F0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD03F4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BD03F8: LDR x1, [x9]               | X1 = "advance";                         
            // 0x00BD03FC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BD0400: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BD0404: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0408: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BD040C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0410: LDR x22, [x8, #0x88]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache11;
            val_50 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache11;
            // 0x00BD0414: CBNZ x22, #0xbd0460        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache11 != null) goto label_76;
            if(val_50 != null)
            {
                goto label_76;
            }
            // 0x00BD0418: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00BD041C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD0420: LDR x8, [x8, #0x58]        | X8 = 1152921510064376192;               
            // 0x00BD0424: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BD0428: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_advance_7(ref object o);
            // 0x00BD042C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_29 = null;
            // 0x00BD0430: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BD0434: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0438: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD043C: MOV x2, x22                | X2 = 1152921510064376192 (0x10000001454B4980);//ML01
            // 0x00BD0440: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_29;
            // 0x00BD0444: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_advance_7(ref object o));
            val_29 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_advance_7(ref object o));
            // 0x00BD0448: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD044C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0450: STR x23, [x8, #0x88]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208584
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache11 = val_39;
            // 0x00BD0454: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0458: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD045C: LDR x22, [x8, #0x88]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_50 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache11;
            label_76:
            // 0x00BD0460: CBNZ x19, #0xbd0468        | if (X1 != 0) goto label_77;             
            if(X1 != 0)
            {
                goto label_77;
            }
            // 0x00BD0464: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_advance_7(ref object o)), ????);
            label_77:
            // 0x00BD0468: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD046C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0470: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD0474: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD0478: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_50);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_50);
            // 0x00BD047C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0480: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0484: LDR x22, [x8, #0x90]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache12;
            val_51 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache12;
            // 0x00BD0488: CBNZ x22, #0xbd04d4        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache12 != null) goto label_78;
            if(val_51 != null)
            {
                goto label_78;
            }
            // 0x00BD048C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00BD0490: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD0494: LDR x8, [x8, #0xbe8]       | X8 = 1152921510064377216;               
            // 0x00BD0498: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD049C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_advance_7(ref object o, object v);
            // 0x00BD04A0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_30 = null;
            // 0x00BD04A4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD04A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD04AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD04B0: MOV x2, x22                | X2 = 1152921510064377216 (0x10000001454B4D80);//ML01
            // 0x00BD04B4: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_30;
            // 0x00BD04B8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_advance_7(ref object o, object v));
            val_30 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_advance_7(ref object o, object v));
            // 0x00BD04BC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD04C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD04C4: STR x23, [x8, #0x90]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache12 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208592
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache12 = val_39;
            // 0x00BD04C8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD04CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD04D0: LDR x22, [x8, #0x90]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_51 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache12;
            label_78:
            // 0x00BD04D4: CBNZ x19, #0xbd04dc        | if (X1 != 0) goto label_79;             
            if(X1 != 0)
            {
                goto label_79;
            }
            // 0x00BD04D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_advance_7(ref object o, object v)), ????);
            label_79:
            // 0x00BD04DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD04E0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD04E4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD04E8: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD04EC: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_51);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_51);
            // 0x00BD04F0: CBNZ x20, #0xbd04f8        | if (val_1 != null) goto label_80;       
            if(val_1 != null)
            {
                goto label_80;
            }
            // 0x00BD04F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_80:
            // 0x00BD04F8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD04FC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BD0500: LDR x9, [x9, #0x2c8]       | X9 = (string**)(1152921510064378240)("channel");
            // 0x00BD0504: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD0508: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD050C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BD0510: LDR x1, [x9]               | X1 = "channel";                         
            // 0x00BD0514: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BD0518: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BD051C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0520: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BD0524: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0528: LDR x22, [x8, #0x98]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache13;
            val_52 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache13;
            // 0x00BD052C: CBNZ x22, #0xbd0578        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache13 != null) goto label_81;
            if(val_52 != null)
            {
                goto label_81;
            }
            // 0x00BD0530: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00BD0534: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD0538: LDR x8, [x8, #0x358]       | X8 = 1152921510064378336;               
            // 0x00BD053C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BD0540: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_channel_8(ref object o);
            // 0x00BD0544: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_31 = null;
            // 0x00BD0548: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BD054C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0550: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0554: MOV x2, x22                | X2 = 1152921510064378336 (0x10000001454B51E0);//ML01
            // 0x00BD0558: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_31;
            // 0x00BD055C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_channel_8(ref object o));
            val_31 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_channel_8(ref object o));
            // 0x00BD0560: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0564: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0568: STR x23, [x8, #0x98]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache13 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208600
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache13 = val_39;
            // 0x00BD056C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0570: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0574: LDR x22, [x8, #0x98]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_52 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache13;
            label_81:
            // 0x00BD0578: CBNZ x19, #0xbd0580        | if (X1 != 0) goto label_82;             
            if(X1 != 0)
            {
                goto label_82;
            }
            // 0x00BD057C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_channel_8(ref object o)), ????);
            label_82:
            // 0x00BD0580: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0584: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0588: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD058C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD0590: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_52);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_52);
            // 0x00BD0594: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0598: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD059C: LDR x22, [x8, #0xa0]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache14;
            val_53 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache14;
            // 0x00BD05A0: CBNZ x22, #0xbd05ec        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache14 != null) goto label_83;
            if(val_53 != null)
            {
                goto label_83;
            }
            // 0x00BD05A4: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x00BD05A8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD05AC: LDR x8, [x8, #0x178]       | X8 = 1152921510064379360;               
            // 0x00BD05B0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD05B4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_channel_8(ref object o, object v);
            // 0x00BD05B8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_32 = null;
            // 0x00BD05BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD05C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD05C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD05C8: MOV x2, x22                | X2 = 1152921510064379360 (0x10000001454B55E0);//ML01
            // 0x00BD05CC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_32;
            // 0x00BD05D0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_channel_8(ref object o, object v));
            val_32 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_channel_8(ref object o, object v));
            // 0x00BD05D4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD05D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD05DC: STR x23, [x8, #0xa0]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache14 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208608
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache14 = val_39;
            // 0x00BD05E0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD05E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD05E8: LDR x22, [x8, #0xa0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_53 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache14;
            label_83:
            // 0x00BD05EC: CBNZ x19, #0xbd05f4        | if (X1 != 0) goto label_84;             
            if(X1 != 0)
            {
                goto label_84;
            }
            // 0x00BD05F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_channel_8(ref object o, object v)), ????);
            label_84:
            // 0x00BD05F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD05F8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD05FC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD0600: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD0604: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_53);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_53);
            // 0x00BD0608: CBNZ x20, #0xbd0610        | if (val_1 != null) goto label_85;       
            if(val_1 != null)
            {
                goto label_85;
            }
            // 0x00BD060C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_85:
            // 0x00BD0610: ADRP x9, #0x3645000        | X9 = 56905728 (0x3645000);              
            // 0x00BD0614: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BD0618: LDR x9, [x9, #0xb50]       | X9 = (string**)(1152921510064380384)("kerning");
            // 0x00BD061C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD0620: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD0624: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BD0628: LDR x1, [x9]               | X1 = "kerning";                         
            // 0x00BD062C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BD0630: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BD0634: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0638: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BD063C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0640: LDR x22, [x8, #0xa8]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache15;
            val_54 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache15;
            // 0x00BD0644: CBNZ x22, #0xbd0690        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache15 != null) goto label_86;
            if(val_54 != null)
            {
                goto label_86;
            }
            // 0x00BD0648: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00BD064C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD0650: LDR x8, [x8, #0x500]       | X8 = 1152921510064380480;               
            // 0x00BD0654: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BD0658: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_kerning_9(ref object o);
            // 0x00BD065C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_33 = null;
            // 0x00BD0660: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BD0664: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0668: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD066C: MOV x2, x22                | X2 = 1152921510064380480 (0x10000001454B5A40);//ML01
            // 0x00BD0670: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_39 = val_33;
            // 0x00BD0674: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_kerning_9(ref object o));
            val_33 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_kerning_9(ref object o));
            // 0x00BD0678: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD067C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0680: STR x23, [x8, #0xa8]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache15 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783208616
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache15 = val_39;
            // 0x00BD0684: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0688: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD068C: LDR x22, [x8, #0xa8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_54 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache15;
            label_86:
            // 0x00BD0690: CBNZ x19, #0xbd0698        | if (X1 != 0) goto label_87;             
            if(X1 != 0)
            {
                goto label_87;
            }
            // 0x00BD0694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::get_kerning_9(ref object o)), ????);
            label_87:
            // 0x00BD0698: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD069C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD06A0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD06A4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD06A8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_54);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_54);
            // 0x00BD06AC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD06B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD06B4: LDR x22, [x8, #0xb0]       | X22 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache16;
            val_55 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache16;
            // 0x00BD06B8: CBNZ x22, #0xbd0704        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache16 != null) goto label_88;
            if(val_55 != null)
            {
                goto label_88;
            }
            // 0x00BD06BC: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00BD06C0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD06C4: LDR x8, [x8, #0x600]       | X8 = 1152921510064381504;               
            // 0x00BD06C8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD06CC: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_kerning_9(ref object o, object v);
            // 0x00BD06D0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_34 = null;
            // 0x00BD06D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD06D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD06DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD06E0: MOV x2, x22                | X2 = 1152921510064381504 (0x10000001454B5E40);//ML01
            // 0x00BD06E4: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_39 = val_34;
            // 0x00BD06E8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_kerning_9(ref object o, object v));
            val_34 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_kerning_9(ref object o, object v));
            // 0x00BD06EC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD06F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD06F4: STR x23, [x8, #0xb0]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache16 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783208624
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache16 = val_39;
            // 0x00BD06F8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD06FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0700: LDR x22, [x8, #0xb0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_55 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache16;
            label_88:
            // 0x00BD0704: CBNZ x19, #0xbd070c        | if (X1 != 0) goto label_89;             
            if(X1 != 0)
            {
                goto label_89;
            }
            // 0x00BD0708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMGlyph_Binding::set_kerning_9(ref object o, object v)), ????);
            label_89:
            // 0x00BD070C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0710: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0714: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD0718: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD071C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_55);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_55);
            // 0x00BD0720: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0724: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0728: LDR x21, [x8, #0xc0]       | X21 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache0;
            val_56 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache0;
            // 0x00BD072C: CBNZ x21, #0xbd0778        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache0 != null) goto label_90;
            if(val_56 != null)
            {
                goto label_90;
            }
            // 0x00BD0730: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x00BD0734: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00BD0738: LDR x8, [x8, #0xe70]       | X8 = 1152921510064382528;               
            // 0x00BD073C: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x00BD0740: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::<Register>m__0();
            // 0x00BD0744: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_35 = null;
            // 0x00BD0748: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x00BD074C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0750: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0754: MOV x2, x21                | X2 = 1152921510064382528 (0x10000001454B6240);//ML01
            // 0x00BD0758: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BD075C: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::<Register>m__0());
            val_35 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::<Register>m__0());
            // 0x00BD0760: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0764: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0768: STR x22, [x8, #0xc0]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504783208640
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache0 = val_35;
            // 0x00BD076C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0770: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0774: LDR x21, [x8, #0xc0]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_56 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache0;
            label_90:
            // 0x00BD0778: CBNZ x19, #0xbd0780        | if (X1 != 0) goto label_91;             
            if(X1 != 0)
            {
                goto label_91;
            }
            // 0x00BD077C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::<Register>m__0()), ????);
            label_91:
            // 0x00BD0780: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0784: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0788: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BD078C: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BD0790: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_56);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_56);
            // 0x00BD0794: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0798: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD079C: LDR x21, [x8, #0xc8]       | X21 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache1;
            val_57 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache1;
            // 0x00BD07A0: CBNZ x21, #0xbd07ec        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache1 != null) goto label_92;
            if(val_57 != null)
            {
                goto label_92;
            }
            // 0x00BD07A4: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00BD07A8: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x00BD07AC: LDR x8, [x8, #0xe20]       | X8 = 1152921510064383552;               
            // 0x00BD07B0: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x00BD07B4: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::<Register>m__1(int s);
            // 0x00BD07B8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_36 = null;
            // 0x00BD07BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x00BD07C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD07C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD07C8: MOV x2, x21                | X2 = 1152921510064383552 (0x10000001454B6640);//ML01
            // 0x00BD07CC: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BD07D0: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::<Register>m__1(int s));
            val_36 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::<Register>m__1(int s));
            // 0x00BD07D4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD07D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD07DC: STR x22, [x8, #0xc8]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504783208648
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache1 = val_36;
            // 0x00BD07E0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD07E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD07E8: LDR x21, [x8, #0xc8]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_57 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__am$cache1;
            label_92:
            // 0x00BD07EC: CBNZ x19, #0xbd07f4        | if (X1 != 0) goto label_93;             
            if(X1 != 0)
            {
                goto label_93;
            }
            // 0x00BD07F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMGlyph_Binding::<Register>m__1(int s)), ????);
            label_93:
            // 0x00BD07F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD07F8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD07FC: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BD0800: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BD0804: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_57);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_57);
            // 0x00BD0808: LDR x21, [x24]             | X21 = typeof(System.Type[]);            
            // 0x00BD080C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD0810: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD0814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0818: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD081C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD0820: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD0824: CBNZ x20, #0xbd082c        | if (val_1 != null) goto label_94;       
            if(val_1 != null)
            {
                goto label_94;
            }
            // 0x00BD0828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_94:
            // 0x00BD082C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD0830: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD0834: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x00BD0838: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD083C: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD0840: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD0844: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_37 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD0848: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD084C: MOV x20, x0                | X20 = val_37;//m1                       
            // 0x00BD0850: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0854: LDR x21, [x8, #0xb8]       | X21 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache17;
            val_58 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache17;
            // 0x00BD0858: CBNZ x21, #0xbd08a4        | if (ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache17 != null) goto label_95;
            if(val_58 != null)
            {
                goto label_95;
            }
            // 0x00BD085C: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00BD0860: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD0864: LDR x8, [x8, #0xa0]        | X8 = 1152921510064388672;               
            // 0x00BD0868: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD086C: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD0870: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_38 = null;
            // 0x00BD0874: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD0878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD087C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0880: MOV x2, x21                | X2 = 1152921510064388672 (0x10000001454B7A40);//ML01
            // 0x00BD0884: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD0888: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_38 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD088C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD0890: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD0894: STR x22, [x8, #0xb8]       | ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache17 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783208632
            ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache17 = val_38;
            // 0x00BD0898: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.BMGlyph_Binding);
            // 0x00BD089C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMGlyph_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD08A0: LDR x21, [x8, #0xb8]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_58 = ILRuntime.Runtime.Generated.BMGlyph_Binding.<>f__mg$cache17;
            label_95:
            // 0x00BD08A4: CBNZ x19, #0xbd08ac        | if (X1 != 0) goto label_96;             
            if(X1 != 0)
            {
                goto label_96;
            }
            // 0x00BD08A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMGlyph_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_96:
            // 0x00BD08AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD08B0: MOV x1, x20                | X1 = val_37;//m1                        
            // 0x00BD08B4: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD08B8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD08BC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD08C0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD08C4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD08C8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BD08CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD08D0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BD08D4: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_37, func:  val_58); return;
            X1.RegisterCLRMethodRedirection(mi:  val_37, func:  val_58);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD08D8 (12388568), len: 624  VirtAddr: 0x00BD08D8 RVA: 0x00BD08D8 token: 100663883 methodIndex: 29928 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetKerning_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x00BD08D8: STP x26, x25, [sp, #-0x50]! | stack[1152921510064595536] = ???;  stack[1152921510064595544] = ???;  //  dest_result_addr=1152921510064595536 |  dest_result_addr=1152921510064595544
            // 0x00BD08DC: STP x24, x23, [sp, #0x10]  | stack[1152921510064595552] = ???;  stack[1152921510064595560] = ???;  //  dest_result_addr=1152921510064595552 |  dest_result_addr=1152921510064595560
            // 0x00BD08E0: STP x22, x21, [sp, #0x20]  | stack[1152921510064595568] = ???;  stack[1152921510064595576] = ???;  //  dest_result_addr=1152921510064595568 |  dest_result_addr=1152921510064595576
            // 0x00BD08E4: STP x20, x19, [sp, #0x30]  | stack[1152921510064595584] = ???;  stack[1152921510064595592] = ???;  //  dest_result_addr=1152921510064595584 |  dest_result_addr=1152921510064595592
            // 0x00BD08E8: STP x29, x30, [sp, #0x40]  | stack[1152921510064595600] = ???;  stack[1152921510064595608] = ???;  //  dest_result_addr=1152921510064595600 |  dest_result_addr=1152921510064595608
            // 0x00BD08EC: ADD x29, sp, #0x40         | X29 = (1152921510064595536 + 64) = 1152921510064595600 (0x10000001454EA290);
            // 0x00BD08F0: SUB sp, sp, #0x10          | SP = (1152921510064595536 - 16) = 1152921510064595520 (0x10000001454EA240);
            // 0x00BD08F4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD08F8: LDRB w8, [x19, #0xbd0]     | W8 = (bool)static_value_03733BD0;       
            // 0x00BD08FC: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BD0900: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BD0904: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BD0908: TBNZ w8, #0, #0xbd0924     | if (static_value_03733BD0 == true) goto label_0;
            // 0x00BD090C: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x00BD0910: LDR x8, [x8, #0xb88]       | X8 = 0x2B8F788;                         
            // 0x00BD0914: LDR w0, [x8]               | W0 = 0x14A6;                            
            // 0x00BD0918: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A6, ????);     
            // 0x00BD091C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD0920: STRB w8, [x19, #0xbd0]     | static_value_03733BD0 = true;            //  dest_result_addr=57883600
            label_0:
            // 0x00BD0924: CBNZ x20, #0xbd092c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD0928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14A6, ????);     
            label_1:
            // 0x00BD092C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0930: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD0934: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD0938: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BD093C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0940: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0944: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BD0948: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BD094C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0950: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BD0954: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0958: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD095C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD0960: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BD0964: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0968: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD096C: CBNZ x21, #0xbd0974        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BD0970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BD0974: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BD0978: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD097C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0980: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BD0984: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BD0988: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD098C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD0990: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD0994: ADRP x9, #0x3650000        | X9 = 56950784 (0x3650000);              
            // 0x00BD0998: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BD099C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD09A0: LDR x9, [x9, #0xaf8]       | X9 = 1152921504875962368;               
            // 0x00BD09A4: LDR x25, [x9]              | X25 = typeof(BMGlyph);                  
            // 0x00BD09A8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD09AC: TBZ w9, #0, #0xbd09c0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BD09B0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD09B4: CBNZ w9, #0xbd09c0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BD09B8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD09BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BD09C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD09C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD09C8: MOV x1, x25                | X1 = 1152921504875962368 (0x10000000100A6000);//ML01
            // 0x00BD09CC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD09D0: ADRP x26, #0x366f000       | X26 = 57077760 (0x366F000);             
            // 0x00BD09D4: LDR x26, [x26, #0x7a0]     | X26 = 1152921504826228736;              
            // 0x00BD09D8: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BD09DC: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD09E0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD09E4: TBZ w9, #0, #0xbd09f8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BD09E8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD09EC: CBNZ w9, #0xbd09f8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BD09F0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD09F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BD09F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD09FC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD0A00: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BD0A04: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BD0A08: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BD0A0C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD0A10: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD0A14: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD0A18: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00BD0A1C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD0A20: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD0A24: TBZ w9, #0, #0xbd0a38      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BD0A28: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD0A2C: CBNZ w9, #0xbd0a38         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BD0A30: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD0A34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BD0A38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0A3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0A40: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BD0A44: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x00BD0A48: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BD0A4C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x00BD0A50: CBZ x0, #0xbd0ab4          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BD0A54: ADRP x9, #0x3680000        | X9 = 57147392 (0x3680000);              
            // 0x00BD0A58: LDR x9, [x9, #0x698]       | X9 = 1152921504875962368;               
            // 0x00BD0A5C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD0A60: LDR x1, [x9]               | X1 = typeof(BMGlyph);                   
            // 0x00BD0A64: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD0A68: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD0A6C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD0A70: B.LO #0xbd0a8c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BD0A74: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD0A78: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchy
            // 0x00BD0A7C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD0A80: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD0A84: MOV x23, x0                | X23 = val_7;//m1                        
            val_12 = val_7;
            // 0x00BD0A88: B.EQ #0xbd0ab4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BD0A8C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD0A90: ADD x8, sp, #8             | X8 = (1152921510064595520 + 8) = 1152921510064595528 (0x10000001454EA248);
            // 0x00BD0A94: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD0A98: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510064583616]
            // 0x00BD0A9C: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BD0AA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0AA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BD0AA8: ADD x0, sp, #8             | X0 = (1152921510064595520 + 8) = 1152921510064595528 (0x10000001454EA248);
            // 0x00BD0AAC: BL #0x299a140              | 
            // 0x00BD0AB0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_12 = 0;
            label_11:
            // 0x00BD0AB4: CBNZ x20, #0xbd0abc        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BD0AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001454EA248, ????);
            label_12:
            // 0x00BD0ABC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD0AC0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD0AC4: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BD0AC8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD0ACC: CBNZ x23, #0xbd0ad4        | if (0x0 != 0) goto label_13;            
            if(val_12 != 0)
            {
                goto label_13;
            }
            // 0x00BD0AD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x00BD0AD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD0AD8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0ADC: MOV w1, w21                | W1 = val_3 + 4;//m1                     
            // 0x00BD0AE0: BL #0xb927a4               | X0 = val_12.GetKerning(previousChar:  val_3 + 4);
            int val_10 = val_12.GetKerning(previousChar:  val_3 + 4);
            // 0x00BD0AE4: CBZ x19, #0xbd0b40         | if (val_2 == 0) goto label_14;          
            if(val_2 == 0)
            {
                goto label_14;
            }
            // 0x00BD0AE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD0AEC: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_10;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_10;
            // 0x00BD0AF0: LDR x0, [x26]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD0AF4: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_13 = 8;
            // 0x00BD0AF8: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BD0AFC: TBZ w9, #0, #0xbd0b0c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x00BD0B00: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BD0B04: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BD0B08: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_13 = 219381744;
            label_15:
            // 0x00BD0B0C: ADD x0, x8, x19            | X0 = (val_13 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_11 = val_13 + val_2;
            // 0x00BD0B10: SUB sp, x29, #0x40         | SP = (1152921510064595600 - 64) = 1152921510064595536 (0x10000001454EA250);
            // 0x00BD0B14: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD0B18: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD0B1C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD0B20: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD0B24: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BD0B28: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_13 + val_2);
            return val_11;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD0B2C: MOV x19, x0                | X19 = (val_13 + val_2);//m1             
            // 0x00BD0B30: ADD x0, sp, #8             | X0 = (1152921510064595616 + 8) = 1152921510064595624 (0x10000001454EA2A8);
            // 0x00BD0B34: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001454EA2A8); //ERROR_TYPE
            // 0x00BD0B38: MOV x0, x19                | X0 = (val_13 + val_2);//m1              
            // 0x00BD0B3C: BL #0x980800               | X0 = sub_980800( ?? (val_13 + val_2), ????);
            label_14:
            // 0x00BD0B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_13 + val_2), ????);
            // 0x00BD0B44: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD0B48 (12389192), len: 616  VirtAddr: 0x00BD0B48 RVA: 0x00BD0B48 token: 100663884 methodIndex: 29929 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetKerning_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            //  | 
            var val_11;
            // 0x00BD0B48: STP x26, x25, [sp, #-0x50]! | stack[1152921510064764880] = ???;  stack[1152921510064764888] = ???;  //  dest_result_addr=1152921510064764880 |  dest_result_addr=1152921510064764888
            // 0x00BD0B4C: STP x24, x23, [sp, #0x10]  | stack[1152921510064764896] = ???;  stack[1152921510064764904] = ???;  //  dest_result_addr=1152921510064764896 |  dest_result_addr=1152921510064764904
            // 0x00BD0B50: STP x22, x21, [sp, #0x20]  | stack[1152921510064764912] = ???;  stack[1152921510064764920] = ???;  //  dest_result_addr=1152921510064764912 |  dest_result_addr=1152921510064764920
            // 0x00BD0B54: STP x20, x19, [sp, #0x30]  | stack[1152921510064764928] = ???;  stack[1152921510064764936] = ???;  //  dest_result_addr=1152921510064764928 |  dest_result_addr=1152921510064764936
            // 0x00BD0B58: STP x29, x30, [sp, #0x40]  | stack[1152921510064764944] = ???;  stack[1152921510064764952] = ???;  //  dest_result_addr=1152921510064764944 |  dest_result_addr=1152921510064764952
            // 0x00BD0B5C: ADD x29, sp, #0x40         | X29 = (1152921510064764880 + 64) = 1152921510064764944 (0x1000000145513810);
            // 0x00BD0B60: SUB sp, sp, #0x10          | SP = (1152921510064764880 - 16) = 1152921510064764864 (0x10000001455137C0);
            // 0x00BD0B64: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD0B68: LDRB w8, [x20, #0xbd1]     | W8 = (bool)static_value_03733BD1;       
            // 0x00BD0B6C: MOV x24, x3                | X24 = X3;//m1                           
            // 0x00BD0B70: MOV x23, x2                | X23 = X2;//m1                           
            // 0x00BD0B74: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD0B78: TBNZ w8, #0, #0xbd0b94     | if (static_value_03733BD1 == true) goto label_0;
            // 0x00BD0B7C: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x00BD0B80: LDR x8, [x8, #0x308]       | X8 = 0x2B8F7B8;                         
            // 0x00BD0B84: LDR w0, [x8]               | W0 = 0x14B2;                            
            // 0x00BD0B88: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B2, ????);     
            // 0x00BD0B8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD0B90: STRB w8, [x20, #0xbd1]     | static_value_03733BD1 = true;            //  dest_result_addr=57883601
            label_0:
            // 0x00BD0B94: CBNZ x19, #0xbd0b9c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD0B98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14B2, ????);     
            label_1:
            // 0x00BD0B9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0BA0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0BA4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD0BA8: MOV x25, x0                | X25 = val_1;//m1                        
            // 0x00BD0BAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0BB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0BB4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BD0BB8: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BD0BBC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0BC0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BD0BC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0BC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0BCC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD0BD0: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BD0BD4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0BD8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD0BDC: CBNZ x21, #0xbd0be4        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BD0BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BD0BE4: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BD0BE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0BEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0BF0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BD0BF4: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BD0BF8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0BFC: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BD0C00: CBNZ x22, #0xbd0c08        | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x00BD0C04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x00BD0C08: LDR w22, [x22, #4]         | W22 = val_4 + 4;                        
            // 0x00BD0C0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0C10: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0C14: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BD0C18: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BD0C1C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0C20: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD0C24: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD0C28: ADRP x9, #0x3650000        | X9 = 56950784 (0x3650000);              
            // 0x00BD0C2C: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BD0C30: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD0C34: LDR x9, [x9, #0xaf8]       | X9 = 1152921504875962368;               
            // 0x00BD0C38: LDR x26, [x9]              | X26 = typeof(BMGlyph);                  
            // 0x00BD0C3C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD0C40: TBZ w9, #0, #0xbd0c54      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD0C44: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD0C48: CBNZ w9, #0xbd0c54         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD0C4C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD0C50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x00BD0C54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0C58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD0C5C: MOV x1, x26                | X1 = 1152921504875962368 (0x10000000100A6000);//ML01
            // 0x00BD0C60: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD0C64: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BD0C68: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BD0C6C: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BD0C70: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD0C74: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD0C78: TBZ w9, #0, #0xbd0c8c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD0C7C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD0C80: CBNZ w9, #0xbd0c8c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD0C84: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD0C88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x00BD0C8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0C90: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD0C94: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x00BD0C98: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x00BD0C9C: MOV x3, x24                | X3 = X3;//m1                            
            // 0x00BD0CA0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD0CA4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD0CA8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD0CAC: MOV x24, x0                | X24 = val_7;//m1                        
            // 0x00BD0CB0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD0CB4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD0CB8: TBZ w9, #0, #0xbd0ccc      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00BD0CBC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD0CC0: CBNZ w9, #0xbd0ccc         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00BD0CC4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD0CC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_9:
            // 0x00BD0CCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0CD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0CD4: MOV x1, x26                | X1 = val_6;//m1                         
            // 0x00BD0CD8: MOV x2, x24                | X2 = val_7;//m1                         
            // 0x00BD0CDC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            object val_8 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            // 0x00BD0CE0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BD0CE4: CBZ x0, #0xbd0d48          | if (val_8 == null) goto label_12;       
            if(val_8 == null)
            {
                goto label_12;
            }
            // 0x00BD0CE8: ADRP x9, #0x3680000        | X9 = 57147392 (0x3680000);              
            // 0x00BD0CEC: LDR x9, [x9, #0x698]       | X9 = 1152921504875962368;               
            // 0x00BD0CF0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD0CF4: LDR x1, [x9]               | X1 = typeof(BMGlyph);                   
            // 0x00BD0CF8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD0CFC: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD0D00: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD0D04: B.LO #0xbd0d20             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_11;
            // 0x00BD0D08: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD0D0C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchy
            // 0x00BD0D10: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD0D14: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD0D18: MOV x24, x0                | X24 = val_8;//m1                        
            val_11 = val_8;
            // 0x00BD0D1C: B.EQ #0xbd0d48             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_12;
            label_11:
            // 0x00BD0D20: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD0D24: ADD x8, sp, #8             | X8 = (1152921510064764864 + 8) = 1152921510064764872 (0x10000001455137C8);
            // 0x00BD0D28: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD0D2C: LDR x0, [sp, #8]           | X0 = val_10;                             //  find_add[1152921510064752960]
            // 0x00BD0D30: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x00BD0D34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0D38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x00BD0D3C: ADD x0, sp, #8             | X0 = (1152921510064764864 + 8) = 1152921510064764872 (0x10000001455137C8);
            // 0x00BD0D40: BL #0x299a140              | 
            // 0x00BD0D44: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_12:
            // 0x00BD0D48: CBNZ x19, #0xbd0d50        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00BD0D4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001455137C8, ????);
            label_13:
            // 0x00BD0D50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD0D54: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0D58: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x00BD0D5C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD0D60: CBNZ x24, #0xbd0d68        | if (0x0 != 0) goto label_14;            
            if(val_11 != 0)
            {
                goto label_14;
            }
            // 0x00BD0D64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_14:
            // 0x00BD0D68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0D6C: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0D70: MOV w1, w22                | W1 = val_4 + 4;//m1                     
            // 0x00BD0D74: MOV w2, w21                | W2 = val_3 + 4;//m1                     
            // 0x00BD0D78: BL #0xb9288c               | val_11.SetKerning(previousChar:  val_4 + 4, amount:  val_3 + 4);
            val_11.SetKerning(previousChar:  val_4 + 4, amount:  val_3 + 4);
            // 0x00BD0D7C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BD0D80: SUB sp, x29, #0x40         | SP = (1152921510064764944 - 64) = 1152921510064764880 (0x10000001455137D0);
            // 0x00BD0D84: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD0D88: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD0D8C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD0D90: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD0D94: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BD0D98: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD0D9C: MOV x19, x0                | 
            // 0x00BD0DA0: ADD x0, sp, #8             | 
            // 0x00BD0DA4: BL #0x299a140              | 
            // 0x00BD0DA8: MOV x0, x19                | 
            // 0x00BD0DAC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD0DB0 (12389808), len: 704  VirtAddr: 0x00BD0DB0 RVA: 0x00BD0DB0 token: 100663885 methodIndex: 29930 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Trim_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x00BD0DB0: STP x28, x27, [sp, #-0x60]! | stack[1152921510064934208] = ???;  stack[1152921510064934216] = ???;  //  dest_result_addr=1152921510064934208 |  dest_result_addr=1152921510064934216
            // 0x00BD0DB4: STP x26, x25, [sp, #0x10]  | stack[1152921510064934224] = ???;  stack[1152921510064934232] = ???;  //  dest_result_addr=1152921510064934224 |  dest_result_addr=1152921510064934232
            // 0x00BD0DB8: STP x24, x23, [sp, #0x20]  | stack[1152921510064934240] = ???;  stack[1152921510064934248] = ???;  //  dest_result_addr=1152921510064934240 |  dest_result_addr=1152921510064934248
            // 0x00BD0DBC: STP x22, x21, [sp, #0x30]  | stack[1152921510064934256] = ???;  stack[1152921510064934264] = ???;  //  dest_result_addr=1152921510064934256 |  dest_result_addr=1152921510064934264
            // 0x00BD0DC0: STP x20, x19, [sp, #0x40]  | stack[1152921510064934272] = ???;  stack[1152921510064934280] = ???;  //  dest_result_addr=1152921510064934272 |  dest_result_addr=1152921510064934280
            // 0x00BD0DC4: STP x29, x30, [sp, #0x50]  | stack[1152921510064934288] = ???;  stack[1152921510064934296] = ???;  //  dest_result_addr=1152921510064934288 |  dest_result_addr=1152921510064934296
            // 0x00BD0DC8: ADD x29, sp, #0x50         | X29 = (1152921510064934208 + 80) = 1152921510064934288 (0x100000014553CD90);
            // 0x00BD0DCC: SUB sp, sp, #0x10          | SP = (1152921510064934208 - 16) = 1152921510064934192 (0x100000014553CD30);
            // 0x00BD0DD0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD0DD4: LDRB w8, [x20, #0xbd2]     | W8 = (bool)static_value_03733BD2;       
            // 0x00BD0DD8: MOV x25, x3                | X25 = X3;//m1                           
            // 0x00BD0DDC: MOV x26, x2                | X26 = X2;//m1                           
            // 0x00BD0DE0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD0DE4: TBNZ w8, #0, #0xbd0e00     | if (static_value_03733BD2 == true) goto label_0;
            // 0x00BD0DE8: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x00BD0DEC: LDR x8, [x8, #0xb48]       | X8 = 0x2B8F7BC;                         
            // 0x00BD0DF0: LDR w0, [x8]               | W0 = 0x14B3;                            
            // 0x00BD0DF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B3, ????);     
            // 0x00BD0DF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD0DFC: STRB w8, [x20, #0xbd2]     | static_value_03733BD2 = true;            //  dest_result_addr=57883602
            label_0:
            // 0x00BD0E00: CBNZ x19, #0xbd0e08        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD0E04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14B3, ????);     
            label_1:
            // 0x00BD0E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0E0C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD0E10: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD0E14: MOV x27, x0                | X27 = val_1;//m1                        
            // 0x00BD0E18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0E1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0E20: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00BD0E24: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BD0E28: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0E2C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BD0E30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0E34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0E38: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD0E3C: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BD0E40: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0E44: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD0E48: CBNZ x21, #0xbd0e50        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BD0E4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BD0E50: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BD0E54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0E58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0E5C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BD0E60: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BD0E64: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0E68: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BD0E6C: CBNZ x22, #0xbd0e74        | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x00BD0E70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x00BD0E74: LDR w22, [x22, #4]         | W22 = val_4 + 4;                        
            // 0x00BD0E78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0E7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0E80: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BD0E84: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BD0E88: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0E8C: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BD0E90: CBNZ x23, #0xbd0e98        | if (val_5 != 0) goto label_4;           
            if(val_5 != 0)
            {
                goto label_4;
            }
            // 0x00BD0E94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_4:
            // 0x00BD0E98: LDR w23, [x23, #4]         | W23 = val_5 + 4;                        
            // 0x00BD0E9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0EA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0EA4: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BD0EA8: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BD0EAC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_6 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0EB0: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x00BD0EB4: CBNZ x24, #0xbd0ebc        | if (val_6 != 0) goto label_5;           
            if(val_6 != 0)
            {
                goto label_5;
            }
            // 0x00BD0EB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_5:
            // 0x00BD0EBC: LDR w24, [x24, #4]         | W24 = val_6 + 4;                        
            // 0x00BD0EC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0EC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0EC8: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00BD0ECC: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BD0ED0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD0ED4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD0ED8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD0EDC: ADRP x9, #0x3650000        | X9 = 56950784 (0x3650000);              
            // 0x00BD0EE0: MOV x26, x0                | X26 = val_7;//m1                        
            // 0x00BD0EE4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD0EE8: LDR x9, [x9, #0xaf8]       | X9 = 1152921504875962368;               
            // 0x00BD0EEC: LDR x28, [x9]              | X28 = typeof(BMGlyph);                  
            // 0x00BD0EF0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD0EF4: TBZ w9, #0, #0xbd0f08      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD0EF8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD0EFC: CBNZ w9, #0xbd0f08         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD0F00: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD0F04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x00BD0F08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0F0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD0F10: MOV x1, x28                | X1 = 1152921504875962368 (0x10000000100A6000);//ML01
            // 0x00BD0F14: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD0F18: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BD0F1C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BD0F20: MOV x28, x0                | X28 = val_8;//m1                        
            // 0x00BD0F24: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD0F28: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD0F2C: TBZ w9, #0, #0xbd0f40      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00BD0F30: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD0F34: CBNZ w9, #0xbd0f40         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00BD0F38: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD0F3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_9:
            // 0x00BD0F40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0F44: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD0F48: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x00BD0F4C: MOV x2, x27                | X2 = val_1;//m1                         
            // 0x00BD0F50: MOV x3, x25                | X3 = X3;//m1                            
            // 0x00BD0F54: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD0F58: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD0F5C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD0F60: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BD0F64: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD0F68: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD0F6C: TBZ w9, #0, #0xbd0f80      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00BD0F70: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD0F74: CBNZ w9, #0xbd0f80         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00BD0F78: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD0F7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_11:
            // 0x00BD0F80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD0F84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD0F88: MOV x1, x28                | X1 = val_8;//m1                         
            // 0x00BD0F8C: MOV x2, x25                | X2 = val_9;//m1                         
            // 0x00BD0F90: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x00BD0F94: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00BD0F98: CBZ x0, #0xbd0ffc          | if (val_10 == null) goto label_14;      
            if(val_10 == null)
            {
                goto label_14;
            }
            // 0x00BD0F9C: ADRP x9, #0x3680000        | X9 = 57147392 (0x3680000);              
            // 0x00BD0FA0: LDR x9, [x9, #0x698]       | X9 = 1152921504875962368;               
            // 0x00BD0FA4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD0FA8: LDR x1, [x9]               | X1 = typeof(BMGlyph);                   
            // 0x00BD0FAC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD0FB0: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD0FB4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD0FB8: B.LO #0xbd0fd4             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00BD0FBC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD0FC0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchy
            // 0x00BD0FC4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD0FC8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD0FCC: MOV x25, x0                | X25 = val_10;//m1                       
            val_13 = val_10;
            // 0x00BD0FD0: B.EQ #0xbd0ffc             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x00BD0FD4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD0FD8: ADD x8, sp, #8             | X8 = (1152921510064934192 + 8) = 1152921510064934200 (0x100000014553CD38);
            // 0x00BD0FDC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD0FE0: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510064922304]
            // 0x00BD0FE4: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BD0FE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD0FEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BD0FF0: ADD x0, sp, #8             | X0 = (1152921510064934192 + 8) = 1152921510064934200 (0x100000014553CD38);
            // 0x00BD0FF4: BL #0x299a140              | 
            // 0x00BD0FF8: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_14:
            // 0x00BD0FFC: CBNZ x19, #0xbd1004        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BD1000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014553CD38, ????);
            label_15:
            // 0x00BD1004: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD1008: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD100C: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x00BD1010: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD1014: CBNZ x25, #0xbd101c        | if (0x0 != 0) goto label_16;            
            if(val_13 != 0)
            {
                goto label_16;
            }
            // 0x00BD1018: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x00BD101C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD1020: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            // 0x00BD1024: MOV w1, w24                | W1 = val_6 + 4;//m1                     
            // 0x00BD1028: MOV w2, w23                | W2 = val_5 + 4;//m1                     
            // 0x00BD102C: MOV w3, w22                | W3 = val_4 + 4;//m1                     
            // 0x00BD1030: MOV w4, w21                | W4 = val_3 + 4;//m1                     
            // 0x00BD1034: BL #0xb92714               | val_13.Trim(xMin:  val_6 + 4, yMin:  val_5 + 4, xMax:  val_4 + 4, yMax:  val_3 + 4);
            val_13.Trim(xMin:  val_6 + 4, yMin:  val_5 + 4, xMax:  val_4 + 4, yMax:  val_3 + 4);
            // 0x00BD1038: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BD103C: SUB sp, x29, #0x50         | SP = (1152921510064934288 - 80) = 1152921510064934208 (0x100000014553CD40);
            // 0x00BD1040: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD1044: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD1048: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD104C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD1050: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BD1054: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BD1058: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD105C: MOV x19, x0                | 
            // 0x00BD1060: ADD x0, sp, #8             | 
            // 0x00BD1064: BL #0x299a140              | 
            // 0x00BD1068: MOV x0, x19                | 
            // 0x00BD106C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD1070 (12390512), len: 312  VirtAddr: 0x00BD1070 RVA: 0x00BD1070 token: 100663886 methodIndex: 29931 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_index_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD1070: STP x20, x19, [sp, #-0x20]! | stack[1152921510065083056] = ???;  stack[1152921510065083064] = ???;  //  dest_result_addr=1152921510065083056 |  dest_result_addr=1152921510065083064
            // 0x00BD1074: STP x29, x30, [sp, #0x10]  | stack[1152921510065083072] = ???;  stack[1152921510065083080] = ???;  //  dest_result_addr=1152921510065083072 |  dest_result_addr=1152921510065083080
            // 0x00BD1078: ADD x29, sp, #0x10         | X29 = (1152921510065083056 + 16) = 1152921510065083072 (0x10000001455612C0);
            // 0x00BD107C: SUB sp, sp, #0x20          | SP = (1152921510065083056 - 32) = 1152921510065083024 (0x1000000145561290);
            // 0x00BD1080: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD1084: LDRB w8, [x20, #0xbd3]     | W8 = (bool)static_value_03733BD3;       
            // 0x00BD1088: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD108C: TBNZ w8, #0, #0xbd10a8     | if (static_value_03733BD3 == true) goto label_0;
            // 0x00BD1090: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x00BD1094: LDR x8, [x8, #0xdb0]       | X8 = 0x2B8F76C;                         
            // 0x00BD1098: LDR w0, [x8]               | W0 = 0x149F;                            
            // 0x00BD109C: BL #0x2782188              | X0 = sub_2782188( ?? 0x149F, ????);     
            // 0x00BD10A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD10A4: STRB w8, [x20, #0xbd3]     | static_value_03733BD3 = true;            //  dest_result_addr=57883603
            label_0:
            // 0x00BD10A8: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD10AC: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD10B0: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD10B4: CBZ x19, #0xbd1108         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD10B8: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD10BC: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD10C0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD10C4: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD10C8: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD10CC: B.LO #0xbd10e4             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD10D0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD10D4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD10D8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD10DC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD10E0: B.EQ #0xbd110c             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD10E4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD10E8: ADD x8, sp, #0x10          | X8 = (1152921510065083024 + 16) = 1152921510065083040 (0x10000001455612A0);
            // 0x00BD10EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD10F0: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510065071088]
            // 0x00BD10F4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD10F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD10FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD1100: ADD x0, sp, #0x10          | X0 = (1152921510065083024 + 16) = 1152921510065083040 (0x10000001455612A0);
            // 0x00BD1104: BL #0x299a140              | 
            label_1:
            // 0x00BD1108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001455612A0, ????);
            label_3:
            // 0x00BD110C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD1110: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1114: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD1118: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD111C: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1120: B.LO #0xbd1164             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD1124: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD1128: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD112C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1130: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1134: B.NE #0xbd1164             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD1138: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BD113C: LDR w8, [x19, #0x10]       | W8 = X1 + 16;                           
            // 0x00BD1140: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00BD1144: ADD x1, sp, #0xc           | X1 = (1152921510065083024 + 12) = 1152921510065083036 (0x100000014556129C);
            // 0x00BD1148: STR w8, [sp, #0xc]         | stack[1152921510065083036] = X1 + 16;    //  dest_result_addr=1152921510065083036
            // 0x00BD114C: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00BD1150: BL #0x27bc028              | X0 = 1152921510065131104 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 16);
            // 0x00BD1154: SUB sp, x29, #0x10         | SP = (1152921510065083072 - 16) = 1152921510065083056 (0x10000001455612B0);
            // 0x00BD1158: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD115C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD1160: RET                        |  return (System.Object)X1 + 16;         
            return (object)X1 + 16;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD1164: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD1168: ADD x8, sp, #0x18          | X8 = (1152921510065083024 + 24) = 1152921510065083048 (0x10000001455612A8);
            // 0x00BD116C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD1170: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510065071088]
            // 0x00BD1174: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD1178: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD117C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD1180: ADD x0, sp, #0x18          | X0 = (1152921510065083024 + 24) = 1152921510065083048 (0x10000001455612A8);
            // 0x00BD1184: BL #0x299a140              | 
            // 0x00BD1188: MOV x19, x0                | X19 = 1152921510065083048 (0x10000001455612A8);//ML01
            // 0x00BD118C: ADD x0, sp, #0x10          | X0 = (1152921510065083024 + 16) = 1152921510065083040 (0x10000001455612A0);
            label_6:
            // 0x00BD1190: BL #0x299a140              | 
            // 0x00BD1194: MOV x0, x19                | X0 = 1152921510065083048 (0x10000001455612A8);//ML01
            // 0x00BD1198: BL #0x980800               | X0 = sub_980800( ?? 0x10000001455612A8, ????);
            // 0x00BD119C: MOV x19, x0                | X19 = 1152921510065083048 (0x10000001455612A8);//ML01
            // 0x00BD11A0: ADD x0, sp, #0x18          | X0 = (1152921510065083024 + 24) = 1152921510065083048 (0x10000001455612A8);
            // 0x00BD11A4: B #0xbd1190                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD11A8 (12390824), len: 412  VirtAddr: 0x00BD11A8 RVA: 0x00BD11A8 token: 100663887 methodIndex: 29932 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_index_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD11A8: STP x22, x21, [sp, #-0x30]! | stack[1152921510065211264] = ???;  stack[1152921510065211272] = ???;  //  dest_result_addr=1152921510065211264 |  dest_result_addr=1152921510065211272
            // 0x00BD11AC: STP x20, x19, [sp, #0x10]  | stack[1152921510065211280] = ???;  stack[1152921510065211288] = ???;  //  dest_result_addr=1152921510065211280 |  dest_result_addr=1152921510065211288
            // 0x00BD11B0: STP x29, x30, [sp, #0x20]  | stack[1152921510065211296] = ???;  stack[1152921510065211304] = ???;  //  dest_result_addr=1152921510065211296 |  dest_result_addr=1152921510065211304
            // 0x00BD11B4: ADD x29, sp, #0x20         | X29 = (1152921510065211264 + 32) = 1152921510065211296 (0x10000001455807A0);
            // 0x00BD11B8: SUB sp, sp, #0x20          | SP = (1152921510065211264 - 32) = 1152921510065211232 (0x1000000145580760);
            // 0x00BD11BC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD11C0: LDRB w8, [x21, #0xbd4]     | W8 = (bool)static_value_03733BD4;       
            // 0x00BD11C4: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD11C8: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD11CC: TBNZ w8, #0, #0xbd11e8     | if (static_value_03733BD4 == true) goto label_0;
            // 0x00BD11D0: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00BD11D4: LDR x8, [x8, #0xa28]       | X8 = 0x2B8F79C;                         
            // 0x00BD11D8: LDR w0, [x8]               | W0 = 0x14AB;                            
            // 0x00BD11DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x14AB, ????);     
            // 0x00BD11E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD11E4: STRB w8, [x21, #0xbd4]     | static_value_03733BD4 = true;            //  dest_result_addr=57883604
            label_0:
            // 0x00BD11E8: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD11EC: CBZ x21, #0xbd12a0         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD11F0: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD11F4: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD11F8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD11FC: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1200: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD1204: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1208: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD120C: B.LO #0xbd1224             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD1210: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD1214: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1218: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD121C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1220: B.EQ #0xbd124c             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD1224: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD1228: ADD x8, sp, #8             | X8 = (1152921510065211232 + 8) = 1152921510065211240 (0x1000000145580768);
            // 0x00BD122C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD1230: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510065199312]
            // 0x00BD1234: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD1238: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD123C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD1240: ADD x0, sp, #8             | X0 = (1152921510065211232 + 8) = 1152921510065211240 (0x1000000145580768);
            // 0x00BD1244: BL #0x299a140              | 
            // 0x00BD1248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145580768, ????);
            label_3:
            // 0x00BD124C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD1250: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1254: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD1258: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD125C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1260: B.LO #0xbd1278             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD1264: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD1268: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD126C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1270: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1274: B.EQ #0xbd12a8             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD1278: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD127C: ADD x8, sp, #0x10          | X8 = (1152921510065211232 + 16) = 1152921510065211248 (0x1000000145580770);
            // 0x00BD1280: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD1284: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510065199312]
            // 0x00BD1288: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD128C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1290: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD1294: ADD x0, sp, #0x10          | X0 = (1152921510065211232 + 16) = 1152921510065211248 (0x1000000145580770);
            // 0x00BD1298: BL #0x299a140              | 
            // 0x00BD129C: B #0xbd12a4                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD12A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AB, ????);     
            label_6:
            // 0x00BD12A4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD12A8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD12AC: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00BD12B0: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x00BD12B4: CBNZ x19, #0xbd12bc        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD12B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AB, ????);     
            label_7:
            // 0x00BD12BC: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD12C0: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD12C4: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00BD12C8: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00BD12CC: B.NE #0xbd1314             | if (X2 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD12D0: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD12D4: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD12D8: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BD12DC: STR w8, [x21, #0x10]       | mem[16] = X2;                            //  dest_result_addr=16
            mem[16] = X2;
            // 0x00BD12E0: SUB sp, x29, #0x20         | SP = (1152921510065211296 - 32) = 1152921510065211264 (0x1000000145580780);
            // 0x00BD12E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD12E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD12EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD12F0: RET                        |  return;                                
            return;
            // 0x00BD12F4: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD12F8: ADD x0, sp, #8             | X0 = (1152921510065211312 + 8) = 1152921510065211320 (0x10000001455807B8);
            // 0x00BD12FC: B #0xbd1308                |  goto label_10;                         
            goto label_10;
            // 0x00BD1300: MOV x19, x0                | X19 = 1152921510065211320 (0x10000001455807B8);//ML01
            val_7;
            // 0x00BD1304: ADD x0, sp, #0x10          | X0 = (1152921510065211312 + 16) = 1152921510065211328 (0x10000001455807C0);
            label_10:
            // 0x00BD1308: BL #0x299a140              | 
            // 0x00BD130C: MOV x0, x19                | X0 = 1152921510065211320 (0x10000001455807B8);//ML01
            // 0x00BD1310: BL #0x980800               | X0 = sub_980800( ?? 0x10000001455807B8, ????);
            label_8:
            // 0x00BD1314: ADD x8, sp, #0x18          | X8 = (1152921510065211312 + 24) = 1152921510065211336 (0x10000001455807C8);
            // 0x00BD1318: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD131C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001455807B8, ????);
            // 0x00BD1320: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510065199312]
            // 0x00BD1324: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD1328: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD132C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD1330: ADD x0, sp, #0x18          | X0 = (1152921510065211312 + 24) = 1152921510065211336 (0x10000001455807C8);
            // 0x00BD1334: BL #0x299a140              | 
            // 0x00BD1338: MOV x19, x0                | X19 = 1152921510065211336 (0x10000001455807C8);//ML01
            // 0x00BD133C: ADD x0, sp, #0x18          | X0 = (1152921510065211312 + 24) = 1152921510065211336 (0x10000001455807C8);
            // 0x00BD1340: B #0xbd1308                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD1344 (12391236), len: 312  VirtAddr: 0x00BD1344 RVA: 0x00BD1344 token: 100663888 methodIndex: 29933 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_x_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD1344: STP x20, x19, [sp, #-0x20]! | stack[1152921510065339504] = ???;  stack[1152921510065339512] = ???;  //  dest_result_addr=1152921510065339504 |  dest_result_addr=1152921510065339512
            // 0x00BD1348: STP x29, x30, [sp, #0x10]  | stack[1152921510065339520] = ???;  stack[1152921510065339528] = ???;  //  dest_result_addr=1152921510065339520 |  dest_result_addr=1152921510065339528
            // 0x00BD134C: ADD x29, sp, #0x10         | X29 = (1152921510065339504 + 16) = 1152921510065339520 (0x100000014559FC80);
            // 0x00BD1350: SUB sp, sp, #0x20          | SP = (1152921510065339504 - 32) = 1152921510065339472 (0x100000014559FC50);
            // 0x00BD1354: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD1358: LDRB w8, [x20, #0xbd5]     | W8 = (bool)static_value_03733BD5;       
            // 0x00BD135C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD1360: TBNZ w8, #0, #0xbd137c     | if (static_value_03733BD5 == true) goto label_0;
            // 0x00BD1364: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x00BD1368: LDR x8, [x8, #0x2f0]       | X8 = 0x2B8F780;                         
            // 0x00BD136C: LDR w0, [x8]               | W0 = 0x14A4;                            
            // 0x00BD1370: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A4, ????);     
            // 0x00BD1374: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD1378: STRB w8, [x20, #0xbd5]     | static_value_03733BD5 = true;            //  dest_result_addr=57883605
            label_0:
            // 0x00BD137C: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD1380: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD1384: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD1388: CBZ x19, #0xbd13dc         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD138C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD1390: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1394: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD1398: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD139C: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD13A0: B.LO #0xbd13b8             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD13A4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD13A8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD13AC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD13B0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD13B4: B.EQ #0xbd13e0             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD13B8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD13BC: ADD x8, sp, #0x10          | X8 = (1152921510065339472 + 16) = 1152921510065339488 (0x100000014559FC60);
            // 0x00BD13C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD13C4: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510065327536]
            // 0x00BD13C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD13CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD13D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD13D4: ADD x0, sp, #0x10          | X0 = (1152921510065339472 + 16) = 1152921510065339488 (0x100000014559FC60);
            // 0x00BD13D8: BL #0x299a140              | 
            label_1:
            // 0x00BD13DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014559FC60, ????);
            label_3:
            // 0x00BD13E0: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD13E4: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD13E8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD13EC: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD13F0: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD13F4: B.LO #0xbd1438             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD13F8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD13FC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1400: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1404: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1408: B.NE #0xbd1438             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD140C: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BD1410: LDR w8, [x19, #0x14]       | W8 = X1 + 20;                           
            // 0x00BD1414: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00BD1418: ADD x1, sp, #0xc           | X1 = (1152921510065339472 + 12) = 1152921510065339484 (0x100000014559FC5C);
            // 0x00BD141C: STR w8, [sp, #0xc]         | stack[1152921510065339484] = X1 + 20;    //  dest_result_addr=1152921510065339484
            // 0x00BD1420: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00BD1424: BL #0x27bc028              | X0 = 1152921510065387552 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 20);
            // 0x00BD1428: SUB sp, x29, #0x10         | SP = (1152921510065339520 - 16) = 1152921510065339504 (0x100000014559FC70);
            // 0x00BD142C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD1430: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD1434: RET                        |  return (System.Object)X1 + 20;         
            return (object)X1 + 20;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD1438: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD143C: ADD x8, sp, #0x18          | X8 = (1152921510065339472 + 24) = 1152921510065339496 (0x100000014559FC68);
            // 0x00BD1440: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD1444: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510065327536]
            // 0x00BD1448: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD144C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1450: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD1454: ADD x0, sp, #0x18          | X0 = (1152921510065339472 + 24) = 1152921510065339496 (0x100000014559FC68);
            // 0x00BD1458: BL #0x299a140              | 
            // 0x00BD145C: MOV x19, x0                | X19 = 1152921510065339496 (0x100000014559FC68);//ML01
            // 0x00BD1460: ADD x0, sp, #0x10          | X0 = (1152921510065339472 + 16) = 1152921510065339488 (0x100000014559FC60);
            label_6:
            // 0x00BD1464: BL #0x299a140              | 
            // 0x00BD1468: MOV x0, x19                | X0 = 1152921510065339496 (0x100000014559FC68);//ML01
            // 0x00BD146C: BL #0x980800               | X0 = sub_980800( ?? 0x100000014559FC68, ????);
            // 0x00BD1470: MOV x19, x0                | X19 = 1152921510065339496 (0x100000014559FC68);//ML01
            // 0x00BD1474: ADD x0, sp, #0x18          | X0 = (1152921510065339472 + 24) = 1152921510065339496 (0x100000014559FC68);
            // 0x00BD1478: B #0xbd1464                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD147C (12391548), len: 412  VirtAddr: 0x00BD147C RVA: 0x00BD147C token: 100663889 methodIndex: 29934 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_x_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD147C: STP x22, x21, [sp, #-0x30]! | stack[1152921510065467712] = ???;  stack[1152921510065467720] = ???;  //  dest_result_addr=1152921510065467712 |  dest_result_addr=1152921510065467720
            // 0x00BD1480: STP x20, x19, [sp, #0x10]  | stack[1152921510065467728] = ???;  stack[1152921510065467736] = ???;  //  dest_result_addr=1152921510065467728 |  dest_result_addr=1152921510065467736
            // 0x00BD1484: STP x29, x30, [sp, #0x20]  | stack[1152921510065467744] = ???;  stack[1152921510065467752] = ???;  //  dest_result_addr=1152921510065467744 |  dest_result_addr=1152921510065467752
            // 0x00BD1488: ADD x29, sp, #0x20         | X29 = (1152921510065467712 + 32) = 1152921510065467744 (0x10000001455BF160);
            // 0x00BD148C: SUB sp, sp, #0x20          | SP = (1152921510065467712 - 32) = 1152921510065467680 (0x10000001455BF120);
            // 0x00BD1490: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD1494: LDRB w8, [x21, #0xbd6]     | W8 = (bool)static_value_03733BD6;       
            // 0x00BD1498: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD149C: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD14A0: TBNZ w8, #0, #0xbd14bc     | if (static_value_03733BD6 == true) goto label_0;
            // 0x00BD14A4: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x00BD14A8: LDR x8, [x8, #0x9f8]       | X8 = 0x2B8F7B0;                         
            // 0x00BD14AC: LDR w0, [x8]               | W0 = 0x14B0;                            
            // 0x00BD14B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B0, ????);     
            // 0x00BD14B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD14B8: STRB w8, [x21, #0xbd6]     | static_value_03733BD6 = true;            //  dest_result_addr=57883606
            label_0:
            // 0x00BD14BC: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD14C0: CBZ x21, #0xbd1574         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD14C4: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD14C8: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD14CC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD14D0: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD14D4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD14D8: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD14DC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD14E0: B.LO #0xbd14f8             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD14E4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD14E8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD14EC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD14F0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD14F4: B.EQ #0xbd1520             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD14F8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD14FC: ADD x8, sp, #8             | X8 = (1152921510065467680 + 8) = 1152921510065467688 (0x10000001455BF128);
            // 0x00BD1500: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD1504: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510065455760]
            // 0x00BD1508: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD150C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1510: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD1514: ADD x0, sp, #8             | X0 = (1152921510065467680 + 8) = 1152921510065467688 (0x10000001455BF128);
            // 0x00BD1518: BL #0x299a140              | 
            // 0x00BD151C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001455BF128, ????);
            label_3:
            // 0x00BD1520: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD1524: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1528: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD152C: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1530: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1534: B.LO #0xbd154c             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD1538: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD153C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1540: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1544: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1548: B.EQ #0xbd157c             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD154C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD1550: ADD x8, sp, #0x10          | X8 = (1152921510065467680 + 16) = 1152921510065467696 (0x10000001455BF130);
            // 0x00BD1554: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD1558: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510065455760]
            // 0x00BD155C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD1560: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1564: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD1568: ADD x0, sp, #0x10          | X0 = (1152921510065467680 + 16) = 1152921510065467696 (0x10000001455BF130);
            // 0x00BD156C: BL #0x299a140              | 
            // 0x00BD1570: B #0xbd1578                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD1574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14B0, ????);     
            label_6:
            // 0x00BD1578: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD157C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD1580: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00BD1584: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x00BD1588: CBNZ x19, #0xbd1590        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD158C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14B0, ????);     
            label_7:
            // 0x00BD1590: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD1594: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD1598: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00BD159C: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00BD15A0: B.NE #0xbd15e8             | if (X2 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD15A4: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD15A8: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD15AC: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BD15B0: STR w8, [x21, #0x14]       | mem[20] = X2;                            //  dest_result_addr=20
            mem[20] = X2;
            // 0x00BD15B4: SUB sp, x29, #0x20         | SP = (1152921510065467744 - 32) = 1152921510065467712 (0x10000001455BF140);
            // 0x00BD15B8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD15BC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD15C0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD15C4: RET                        |  return;                                
            return;
            // 0x00BD15C8: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD15CC: ADD x0, sp, #8             | X0 = (1152921510065467760 + 8) = 1152921510065467768 (0x10000001455BF178);
            // 0x00BD15D0: B #0xbd15dc                |  goto label_10;                         
            goto label_10;
            // 0x00BD15D4: MOV x19, x0                | X19 = 1152921510065467768 (0x10000001455BF178);//ML01
            val_7;
            // 0x00BD15D8: ADD x0, sp, #0x10          | X0 = (1152921510065467760 + 16) = 1152921510065467776 (0x10000001455BF180);
            label_10:
            // 0x00BD15DC: BL #0x299a140              | 
            // 0x00BD15E0: MOV x0, x19                | X0 = 1152921510065467768 (0x10000001455BF178);//ML01
            // 0x00BD15E4: BL #0x980800               | X0 = sub_980800( ?? 0x10000001455BF178, ????);
            label_8:
            // 0x00BD15E8: ADD x8, sp, #0x18          | X8 = (1152921510065467760 + 24) = 1152921510065467784 (0x10000001455BF188);
            // 0x00BD15EC: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD15F0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001455BF178, ????);
            // 0x00BD15F4: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510065455760]
            // 0x00BD15F8: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD15FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1600: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD1604: ADD x0, sp, #0x18          | X0 = (1152921510065467760 + 24) = 1152921510065467784 (0x10000001455BF188);
            // 0x00BD1608: BL #0x299a140              | 
            // 0x00BD160C: MOV x19, x0                | X19 = 1152921510065467784 (0x10000001455BF188);//ML01
            // 0x00BD1610: ADD x0, sp, #0x18          | X0 = (1152921510065467760 + 24) = 1152921510065467784 (0x10000001455BF188);
            // 0x00BD1614: B #0xbd15dc                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD1618 (12391960), len: 312  VirtAddr: 0x00BD1618 RVA: 0x00BD1618 token: 100663890 methodIndex: 29935 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_y_2(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD1618: STP x20, x19, [sp, #-0x20]! | stack[1152921510065595952] = ???;  stack[1152921510065595960] = ???;  //  dest_result_addr=1152921510065595952 |  dest_result_addr=1152921510065595960
            // 0x00BD161C: STP x29, x30, [sp, #0x10]  | stack[1152921510065595968] = ???;  stack[1152921510065595976] = ???;  //  dest_result_addr=1152921510065595968 |  dest_result_addr=1152921510065595976
            // 0x00BD1620: ADD x29, sp, #0x10         | X29 = (1152921510065595952 + 16) = 1152921510065595968 (0x10000001455DE640);
            // 0x00BD1624: SUB sp, sp, #0x20          | SP = (1152921510065595952 - 32) = 1152921510065595920 (0x10000001455DE610);
            // 0x00BD1628: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD162C: LDRB w8, [x20, #0xbd7]     | W8 = (bool)static_value_03733BD7;       
            // 0x00BD1630: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD1634: TBNZ w8, #0, #0xbd1650     | if (static_value_03733BD7 == true) goto label_0;
            // 0x00BD1638: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x00BD163C: LDR x8, [x8, #0x698]       | X8 = 0x2B8F784;                         
            // 0x00BD1640: LDR w0, [x8]               | W0 = 0x14A5;                            
            // 0x00BD1644: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A5, ????);     
            // 0x00BD1648: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD164C: STRB w8, [x20, #0xbd7]     | static_value_03733BD7 = true;            //  dest_result_addr=57883607
            label_0:
            // 0x00BD1650: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD1654: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD1658: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD165C: CBZ x19, #0xbd16b0         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD1660: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD1664: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1668: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD166C: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1670: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1674: B.LO #0xbd168c             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD1678: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD167C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1680: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1684: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1688: B.EQ #0xbd16b4             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD168C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD1690: ADD x8, sp, #0x10          | X8 = (1152921510065595920 + 16) = 1152921510065595936 (0x10000001455DE620);
            // 0x00BD1694: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD1698: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510065583984]
            // 0x00BD169C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD16A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD16A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD16A8: ADD x0, sp, #0x10          | X0 = (1152921510065595920 + 16) = 1152921510065595936 (0x10000001455DE620);
            // 0x00BD16AC: BL #0x299a140              | 
            label_1:
            // 0x00BD16B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001455DE620, ????);
            label_3:
            // 0x00BD16B4: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD16B8: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD16BC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD16C0: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD16C4: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD16C8: B.LO #0xbd170c             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD16CC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD16D0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD16D4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD16D8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD16DC: B.NE #0xbd170c             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD16E0: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BD16E4: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
            // 0x00BD16E8: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00BD16EC: ADD x1, sp, #0xc           | X1 = (1152921510065595920 + 12) = 1152921510065595932 (0x10000001455DE61C);
            // 0x00BD16F0: STR w8, [sp, #0xc]         | stack[1152921510065595932] = X1 + 24;    //  dest_result_addr=1152921510065595932
            // 0x00BD16F4: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00BD16F8: BL #0x27bc028              | X0 = 1152921510065644000 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 24);
            // 0x00BD16FC: SUB sp, x29, #0x10         | SP = (1152921510065595968 - 16) = 1152921510065595952 (0x10000001455DE630);
            // 0x00BD1700: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD1704: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD1708: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD170C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD1710: ADD x8, sp, #0x18          | X8 = (1152921510065595920 + 24) = 1152921510065595944 (0x10000001455DE628);
            // 0x00BD1714: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD1718: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510065583984]
            // 0x00BD171C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD1720: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1724: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD1728: ADD x0, sp, #0x18          | X0 = (1152921510065595920 + 24) = 1152921510065595944 (0x10000001455DE628);
            // 0x00BD172C: BL #0x299a140              | 
            // 0x00BD1730: MOV x19, x0                | X19 = 1152921510065595944 (0x10000001455DE628);//ML01
            // 0x00BD1734: ADD x0, sp, #0x10          | X0 = (1152921510065595920 + 16) = 1152921510065595936 (0x10000001455DE620);
            label_6:
            // 0x00BD1738: BL #0x299a140              | 
            // 0x00BD173C: MOV x0, x19                | X0 = 1152921510065595944 (0x10000001455DE628);//ML01
            // 0x00BD1740: BL #0x980800               | X0 = sub_980800( ?? 0x10000001455DE628, ????);
            // 0x00BD1744: MOV x19, x0                | X19 = 1152921510065595944 (0x10000001455DE628);//ML01
            // 0x00BD1748: ADD x0, sp, #0x18          | X0 = (1152921510065595920 + 24) = 1152921510065595944 (0x10000001455DE628);
            // 0x00BD174C: B #0xbd1738                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD1750 (12392272), len: 412  VirtAddr: 0x00BD1750 RVA: 0x00BD1750 token: 100663891 methodIndex: 29936 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_y_2(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD1750: STP x22, x21, [sp, #-0x30]! | stack[1152921510065724160] = ???;  stack[1152921510065724168] = ???;  //  dest_result_addr=1152921510065724160 |  dest_result_addr=1152921510065724168
            // 0x00BD1754: STP x20, x19, [sp, #0x10]  | stack[1152921510065724176] = ???;  stack[1152921510065724184] = ???;  //  dest_result_addr=1152921510065724176 |  dest_result_addr=1152921510065724184
            // 0x00BD1758: STP x29, x30, [sp, #0x20]  | stack[1152921510065724192] = ???;  stack[1152921510065724200] = ???;  //  dest_result_addr=1152921510065724192 |  dest_result_addr=1152921510065724200
            // 0x00BD175C: ADD x29, sp, #0x20         | X29 = (1152921510065724160 + 32) = 1152921510065724192 (0x10000001455FDB20);
            // 0x00BD1760: SUB sp, sp, #0x20          | SP = (1152921510065724160 - 32) = 1152921510065724128 (0x10000001455FDAE0);
            // 0x00BD1764: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD1768: LDRB w8, [x21, #0xbd8]     | W8 = (bool)static_value_03733BD8;       
            // 0x00BD176C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD1770: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD1774: TBNZ w8, #0, #0xbd1790     | if (static_value_03733BD8 == true) goto label_0;
            // 0x00BD1778: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x00BD177C: LDR x8, [x8, #0x938]       | X8 = 0x2B8F7B4;                         
            // 0x00BD1780: LDR w0, [x8]               | W0 = 0x14B1;                            
            // 0x00BD1784: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B1, ????);     
            // 0x00BD1788: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD178C: STRB w8, [x21, #0xbd8]     | static_value_03733BD8 = true;            //  dest_result_addr=57883608
            label_0:
            // 0x00BD1790: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD1794: CBZ x21, #0xbd1848         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD1798: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD179C: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD17A0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD17A4: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD17A8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD17AC: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD17B0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD17B4: B.LO #0xbd17cc             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD17B8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD17BC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD17C0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD17C4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD17C8: B.EQ #0xbd17f4             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD17CC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD17D0: ADD x8, sp, #8             | X8 = (1152921510065724128 + 8) = 1152921510065724136 (0x10000001455FDAE8);
            // 0x00BD17D4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD17D8: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510065712208]
            // 0x00BD17DC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD17E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD17E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD17E8: ADD x0, sp, #8             | X0 = (1152921510065724128 + 8) = 1152921510065724136 (0x10000001455FDAE8);
            // 0x00BD17EC: BL #0x299a140              | 
            // 0x00BD17F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001455FDAE8, ????);
            label_3:
            // 0x00BD17F4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD17F8: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD17FC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD1800: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1804: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1808: B.LO #0xbd1820             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD180C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD1810: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1814: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1818: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD181C: B.EQ #0xbd1850             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD1820: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD1824: ADD x8, sp, #0x10          | X8 = (1152921510065724128 + 16) = 1152921510065724144 (0x10000001455FDAF0);
            // 0x00BD1828: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD182C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510065712208]
            // 0x00BD1830: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD1834: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1838: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD183C: ADD x0, sp, #0x10          | X0 = (1152921510065724128 + 16) = 1152921510065724144 (0x10000001455FDAF0);
            // 0x00BD1840: BL #0x299a140              | 
            // 0x00BD1844: B #0xbd184c                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD1848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14B1, ????);     
            label_6:
            // 0x00BD184C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD1850: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD1854: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00BD1858: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x00BD185C: CBNZ x19, #0xbd1864        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD1860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14B1, ????);     
            label_7:
            // 0x00BD1864: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD1868: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD186C: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00BD1870: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00BD1874: B.NE #0xbd18bc             | if (X2 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD1878: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD187C: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD1880: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BD1884: STR w8, [x21, #0x18]       | mem[24] = X2;                            //  dest_result_addr=24
            mem[24] = X2;
            // 0x00BD1888: SUB sp, x29, #0x20         | SP = (1152921510065724192 - 32) = 1152921510065724160 (0x10000001455FDB00);
            // 0x00BD188C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD1890: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD1894: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD1898: RET                        |  return;                                
            return;
            // 0x00BD189C: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD18A0: ADD x0, sp, #8             | X0 = (1152921510065724208 + 8) = 1152921510065724216 (0x10000001455FDB38);
            // 0x00BD18A4: B #0xbd18b0                |  goto label_10;                         
            goto label_10;
            // 0x00BD18A8: MOV x19, x0                | X19 = 1152921510065724216 (0x10000001455FDB38);//ML01
            val_7;
            // 0x00BD18AC: ADD x0, sp, #0x10          | X0 = (1152921510065724208 + 16) = 1152921510065724224 (0x10000001455FDB40);
            label_10:
            // 0x00BD18B0: BL #0x299a140              | 
            // 0x00BD18B4: MOV x0, x19                | X0 = 1152921510065724216 (0x10000001455FDB38);//ML01
            // 0x00BD18B8: BL #0x980800               | X0 = sub_980800( ?? 0x10000001455FDB38, ????);
            label_8:
            // 0x00BD18BC: ADD x8, sp, #0x18          | X8 = (1152921510065724208 + 24) = 1152921510065724232 (0x10000001455FDB48);
            // 0x00BD18C0: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD18C4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001455FDB38, ????);
            // 0x00BD18C8: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510065712208]
            // 0x00BD18CC: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD18D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD18D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD18D8: ADD x0, sp, #0x18          | X0 = (1152921510065724208 + 24) = 1152921510065724232 (0x10000001455FDB48);
            // 0x00BD18DC: BL #0x299a140              | 
            // 0x00BD18E0: MOV x19, x0                | X19 = 1152921510065724232 (0x10000001455FDB48);//ML01
            // 0x00BD18E4: ADD x0, sp, #0x18          | X0 = (1152921510065724208 + 24) = 1152921510065724232 (0x10000001455FDB48);
            // 0x00BD18E8: B #0xbd18b0                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD18EC (12392684), len: 312  VirtAddr: 0x00BD18EC RVA: 0x00BD18EC token: 100663892 methodIndex: 29937 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_width_3(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD18EC: STP x20, x19, [sp, #-0x20]! | stack[1152921510065852400] = ???;  stack[1152921510065852408] = ???;  //  dest_result_addr=1152921510065852400 |  dest_result_addr=1152921510065852408
            // 0x00BD18F0: STP x29, x30, [sp, #0x10]  | stack[1152921510065852416] = ???;  stack[1152921510065852424] = ???;  //  dest_result_addr=1152921510065852416 |  dest_result_addr=1152921510065852424
            // 0x00BD18F4: ADD x29, sp, #0x10         | X29 = (1152921510065852400 + 16) = 1152921510065852416 (0x100000014561D000);
            // 0x00BD18F8: SUB sp, sp, #0x20          | SP = (1152921510065852400 - 32) = 1152921510065852368 (0x100000014561CFD0);
            // 0x00BD18FC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD1900: LDRB w8, [x20, #0xbd9]     | W8 = (bool)static_value_03733BD9;       
            // 0x00BD1904: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD1908: TBNZ w8, #0, #0xbd1924     | if (static_value_03733BD9 == true) goto label_0;
            // 0x00BD190C: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x00BD1910: LDR x8, [x8, #0x180]       | X8 = 0x2B8F77C;                         
            // 0x00BD1914: LDR w0, [x8]               | W0 = 0x14A3;                            
            // 0x00BD1918: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A3, ????);     
            // 0x00BD191C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD1920: STRB w8, [x20, #0xbd9]     | static_value_03733BD9 = true;            //  dest_result_addr=57883609
            label_0:
            // 0x00BD1924: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD1928: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD192C: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD1930: CBZ x19, #0xbd1984         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD1934: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD1938: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD193C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD1940: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1944: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1948: B.LO #0xbd1960             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD194C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD1950: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1954: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1958: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD195C: B.EQ #0xbd1988             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD1960: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD1964: ADD x8, sp, #0x10          | X8 = (1152921510065852368 + 16) = 1152921510065852384 (0x100000014561CFE0);
            // 0x00BD1968: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD196C: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510065840432]
            // 0x00BD1970: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD1974: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1978: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD197C: ADD x0, sp, #0x10          | X0 = (1152921510065852368 + 16) = 1152921510065852384 (0x100000014561CFE0);
            // 0x00BD1980: BL #0x299a140              | 
            label_1:
            // 0x00BD1984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014561CFE0, ????);
            label_3:
            // 0x00BD1988: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD198C: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1990: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD1994: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1998: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD199C: B.LO #0xbd19e0             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD19A0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD19A4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD19A8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD19AC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD19B0: B.NE #0xbd19e0             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD19B4: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BD19B8: LDR w8, [x19, #0x1c]       | W8 = X1 + 28;                           
            // 0x00BD19BC: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00BD19C0: ADD x1, sp, #0xc           | X1 = (1152921510065852368 + 12) = 1152921510065852380 (0x100000014561CFDC);
            // 0x00BD19C4: STR w8, [sp, #0xc]         | stack[1152921510065852380] = X1 + 28;    //  dest_result_addr=1152921510065852380
            // 0x00BD19C8: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00BD19CC: BL #0x27bc028              | X0 = 1152921510065900448 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 28);
            // 0x00BD19D0: SUB sp, x29, #0x10         | SP = (1152921510065852416 - 16) = 1152921510065852400 (0x100000014561CFF0);
            // 0x00BD19D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD19D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD19DC: RET                        |  return (System.Object)X1 + 28;         
            return (object)X1 + 28;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD19E0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD19E4: ADD x8, sp, #0x18          | X8 = (1152921510065852368 + 24) = 1152921510065852392 (0x100000014561CFE8);
            // 0x00BD19E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD19EC: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510065840432]
            // 0x00BD19F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD19F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD19F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD19FC: ADD x0, sp, #0x18          | X0 = (1152921510065852368 + 24) = 1152921510065852392 (0x100000014561CFE8);
            // 0x00BD1A00: BL #0x299a140              | 
            // 0x00BD1A04: MOV x19, x0                | X19 = 1152921510065852392 (0x100000014561CFE8);//ML01
            // 0x00BD1A08: ADD x0, sp, #0x10          | X0 = (1152921510065852368 + 16) = 1152921510065852384 (0x100000014561CFE0);
            label_6:
            // 0x00BD1A0C: BL #0x299a140              | 
            // 0x00BD1A10: MOV x0, x19                | X0 = 1152921510065852392 (0x100000014561CFE8);//ML01
            // 0x00BD1A14: BL #0x980800               | X0 = sub_980800( ?? 0x100000014561CFE8, ????);
            // 0x00BD1A18: MOV x19, x0                | X19 = 1152921510065852392 (0x100000014561CFE8);//ML01
            // 0x00BD1A1C: ADD x0, sp, #0x18          | X0 = (1152921510065852368 + 24) = 1152921510065852392 (0x100000014561CFE8);
            // 0x00BD1A20: B #0xbd1a0c                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD1A24 (12392996), len: 412  VirtAddr: 0x00BD1A24 RVA: 0x00BD1A24 token: 100663893 methodIndex: 29938 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_width_3(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD1A24: STP x22, x21, [sp, #-0x30]! | stack[1152921510065980608] = ???;  stack[1152921510065980616] = ???;  //  dest_result_addr=1152921510065980608 |  dest_result_addr=1152921510065980616
            // 0x00BD1A28: STP x20, x19, [sp, #0x10]  | stack[1152921510065980624] = ???;  stack[1152921510065980632] = ???;  //  dest_result_addr=1152921510065980624 |  dest_result_addr=1152921510065980632
            // 0x00BD1A2C: STP x29, x30, [sp, #0x20]  | stack[1152921510065980640] = ???;  stack[1152921510065980648] = ???;  //  dest_result_addr=1152921510065980640 |  dest_result_addr=1152921510065980648
            // 0x00BD1A30: ADD x29, sp, #0x20         | X29 = (1152921510065980608 + 32) = 1152921510065980640 (0x100000014563C4E0);
            // 0x00BD1A34: SUB sp, sp, #0x20          | SP = (1152921510065980608 - 32) = 1152921510065980576 (0x100000014563C4A0);
            // 0x00BD1A38: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD1A3C: LDRB w8, [x21, #0xbda]     | W8 = (bool)static_value_03733BDA;       
            // 0x00BD1A40: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD1A44: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD1A48: TBNZ w8, #0, #0xbd1a64     | if (static_value_03733BDA == true) goto label_0;
            // 0x00BD1A4C: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00BD1A50: LDR x8, [x8, #0x38]        | X8 = 0x2B8F7AC;                         
            // 0x00BD1A54: LDR w0, [x8]               | W0 = 0x14AF;                            
            // 0x00BD1A58: BL #0x2782188              | X0 = sub_2782188( ?? 0x14AF, ????);     
            // 0x00BD1A5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD1A60: STRB w8, [x21, #0xbda]     | static_value_03733BDA = true;            //  dest_result_addr=57883610
            label_0:
            // 0x00BD1A64: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD1A68: CBZ x21, #0xbd1b1c         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD1A6C: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD1A70: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD1A74: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD1A78: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1A7C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD1A80: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1A84: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1A88: B.LO #0xbd1aa0             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD1A8C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD1A90: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1A94: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1A98: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1A9C: B.EQ #0xbd1ac8             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD1AA0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD1AA4: ADD x8, sp, #8             | X8 = (1152921510065980576 + 8) = 1152921510065980584 (0x100000014563C4A8);
            // 0x00BD1AA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD1AAC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510065968656]
            // 0x00BD1AB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD1AB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1AB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD1ABC: ADD x0, sp, #8             | X0 = (1152921510065980576 + 8) = 1152921510065980584 (0x100000014563C4A8);
            // 0x00BD1AC0: BL #0x299a140              | 
            // 0x00BD1AC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014563C4A8, ????);
            label_3:
            // 0x00BD1AC8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD1ACC: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1AD0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD1AD4: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1AD8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1ADC: B.LO #0xbd1af4             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD1AE0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD1AE4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1AE8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1AEC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1AF0: B.EQ #0xbd1b24             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD1AF4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD1AF8: ADD x8, sp, #0x10          | X8 = (1152921510065980576 + 16) = 1152921510065980592 (0x100000014563C4B0);
            // 0x00BD1AFC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD1B00: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510065968656]
            // 0x00BD1B04: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD1B08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1B0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD1B10: ADD x0, sp, #0x10          | X0 = (1152921510065980576 + 16) = 1152921510065980592 (0x100000014563C4B0);
            // 0x00BD1B14: BL #0x299a140              | 
            // 0x00BD1B18: B #0xbd1b20                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD1B1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AF, ????);     
            label_6:
            // 0x00BD1B20: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD1B24: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD1B28: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00BD1B2C: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x00BD1B30: CBNZ x19, #0xbd1b38        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD1B34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AF, ????);     
            label_7:
            // 0x00BD1B38: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD1B3C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD1B40: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00BD1B44: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00BD1B48: B.NE #0xbd1b90             | if (X2 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD1B4C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD1B50: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD1B54: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BD1B58: STR w8, [x21, #0x1c]       | mem[28] = X2;                            //  dest_result_addr=28
            mem[28] = X2;
            // 0x00BD1B5C: SUB sp, x29, #0x20         | SP = (1152921510065980640 - 32) = 1152921510065980608 (0x100000014563C4C0);
            // 0x00BD1B60: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD1B64: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD1B68: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD1B6C: RET                        |  return;                                
            return;
            // 0x00BD1B70: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD1B74: ADD x0, sp, #8             | X0 = (1152921510065980656 + 8) = 1152921510065980664 (0x100000014563C4F8);
            // 0x00BD1B78: B #0xbd1b84                |  goto label_10;                         
            goto label_10;
            // 0x00BD1B7C: MOV x19, x0                | X19 = 1152921510065980664 (0x100000014563C4F8);//ML01
            val_7;
            // 0x00BD1B80: ADD x0, sp, #0x10          | X0 = (1152921510065980656 + 16) = 1152921510065980672 (0x100000014563C500);
            label_10:
            // 0x00BD1B84: BL #0x299a140              | 
            // 0x00BD1B88: MOV x0, x19                | X0 = 1152921510065980664 (0x100000014563C4F8);//ML01
            // 0x00BD1B8C: BL #0x980800               | X0 = sub_980800( ?? 0x100000014563C4F8, ????);
            label_8:
            // 0x00BD1B90: ADD x8, sp, #0x18          | X8 = (1152921510065980656 + 24) = 1152921510065980680 (0x100000014563C508);
            // 0x00BD1B94: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD1B98: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x100000014563C4F8, ????);
            // 0x00BD1B9C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510065968656]
            // 0x00BD1BA0: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD1BA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1BA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD1BAC: ADD x0, sp, #0x18          | X0 = (1152921510065980656 + 24) = 1152921510065980680 (0x100000014563C508);
            // 0x00BD1BB0: BL #0x299a140              | 
            // 0x00BD1BB4: MOV x19, x0                | X19 = 1152921510065980680 (0x100000014563C508);//ML01
            // 0x00BD1BB8: ADD x0, sp, #0x18          | X0 = (1152921510065980656 + 24) = 1152921510065980680 (0x100000014563C508);
            // 0x00BD1BBC: B #0xbd1b84                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD1BC0 (12393408), len: 312  VirtAddr: 0x00BD1BC0 RVA: 0x00BD1BC0 token: 100663894 methodIndex: 29939 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_height_4(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD1BC0: STP x20, x19, [sp, #-0x20]! | stack[1152921510066108848] = ???;  stack[1152921510066108856] = ???;  //  dest_result_addr=1152921510066108848 |  dest_result_addr=1152921510066108856
            // 0x00BD1BC4: STP x29, x30, [sp, #0x10]  | stack[1152921510066108864] = ???;  stack[1152921510066108872] = ???;  //  dest_result_addr=1152921510066108864 |  dest_result_addr=1152921510066108872
            // 0x00BD1BC8: ADD x29, sp, #0x10         | X29 = (1152921510066108848 + 16) = 1152921510066108864 (0x100000014565B9C0);
            // 0x00BD1BCC: SUB sp, sp, #0x20          | SP = (1152921510066108848 - 32) = 1152921510066108816 (0x100000014565B990);
            // 0x00BD1BD0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD1BD4: LDRB w8, [x20, #0xbdb]     | W8 = (bool)static_value_03733BDB;       
            // 0x00BD1BD8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD1BDC: TBNZ w8, #0, #0xbd1bf8     | if (static_value_03733BDB == true) goto label_0;
            // 0x00BD1BE0: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x00BD1BE4: LDR x8, [x8, #0xc68]       | X8 = 0x2B8F768;                         
            // 0x00BD1BE8: LDR w0, [x8]               | W0 = 0x149E;                            
            // 0x00BD1BEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x149E, ????);     
            // 0x00BD1BF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD1BF4: STRB w8, [x20, #0xbdb]     | static_value_03733BDB = true;            //  dest_result_addr=57883611
            label_0:
            // 0x00BD1BF8: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD1BFC: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD1C00: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD1C04: CBZ x19, #0xbd1c58         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD1C08: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD1C0C: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1C10: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD1C14: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1C18: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1C1C: B.LO #0xbd1c34             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD1C20: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD1C24: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1C28: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1C2C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1C30: B.EQ #0xbd1c5c             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD1C34: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD1C38: ADD x8, sp, #0x10          | X8 = (1152921510066108816 + 16) = 1152921510066108832 (0x100000014565B9A0);
            // 0x00BD1C3C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD1C40: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510066096880]
            // 0x00BD1C44: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD1C48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1C4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD1C50: ADD x0, sp, #0x10          | X0 = (1152921510066108816 + 16) = 1152921510066108832 (0x100000014565B9A0);
            // 0x00BD1C54: BL #0x299a140              | 
            label_1:
            // 0x00BD1C58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014565B9A0, ????);
            label_3:
            // 0x00BD1C5C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD1C60: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1C64: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD1C68: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1C6C: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1C70: B.LO #0xbd1cb4             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD1C74: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD1C78: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1C7C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1C80: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1C84: B.NE #0xbd1cb4             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD1C88: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BD1C8C: LDR w8, [x19, #0x20]       | W8 = X1 + 32;                           
            // 0x00BD1C90: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00BD1C94: ADD x1, sp, #0xc           | X1 = (1152921510066108816 + 12) = 1152921510066108828 (0x100000014565B99C);
            // 0x00BD1C98: STR w8, [sp, #0xc]         | stack[1152921510066108828] = X1 + 32;    //  dest_result_addr=1152921510066108828
            // 0x00BD1C9C: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00BD1CA0: BL #0x27bc028              | X0 = 1152921510066156896 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 32);
            // 0x00BD1CA4: SUB sp, x29, #0x10         | SP = (1152921510066108864 - 16) = 1152921510066108848 (0x100000014565B9B0);
            // 0x00BD1CA8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD1CAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD1CB0: RET                        |  return (System.Object)X1 + 32;         
            return (object)X1 + 32;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD1CB4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD1CB8: ADD x8, sp, #0x18          | X8 = (1152921510066108816 + 24) = 1152921510066108840 (0x100000014565B9A8);
            // 0x00BD1CBC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD1CC0: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510066096880]
            // 0x00BD1CC4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD1CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1CCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD1CD0: ADD x0, sp, #0x18          | X0 = (1152921510066108816 + 24) = 1152921510066108840 (0x100000014565B9A8);
            // 0x00BD1CD4: BL #0x299a140              | 
            // 0x00BD1CD8: MOV x19, x0                | X19 = 1152921510066108840 (0x100000014565B9A8);//ML01
            // 0x00BD1CDC: ADD x0, sp, #0x10          | X0 = (1152921510066108816 + 16) = 1152921510066108832 (0x100000014565B9A0);
            label_6:
            // 0x00BD1CE0: BL #0x299a140              | 
            // 0x00BD1CE4: MOV x0, x19                | X0 = 1152921510066108840 (0x100000014565B9A8);//ML01
            // 0x00BD1CE8: BL #0x980800               | X0 = sub_980800( ?? 0x100000014565B9A8, ????);
            // 0x00BD1CEC: MOV x19, x0                | X19 = 1152921510066108840 (0x100000014565B9A8);//ML01
            // 0x00BD1CF0: ADD x0, sp, #0x18          | X0 = (1152921510066108816 + 24) = 1152921510066108840 (0x100000014565B9A8);
            // 0x00BD1CF4: B #0xbd1ce0                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD1CF8 (12393720), len: 412  VirtAddr: 0x00BD1CF8 RVA: 0x00BD1CF8 token: 100663895 methodIndex: 29940 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_height_4(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD1CF8: STP x22, x21, [sp, #-0x30]! | stack[1152921510066237056] = ???;  stack[1152921510066237064] = ???;  //  dest_result_addr=1152921510066237056 |  dest_result_addr=1152921510066237064
            // 0x00BD1CFC: STP x20, x19, [sp, #0x10]  | stack[1152921510066237072] = ???;  stack[1152921510066237080] = ???;  //  dest_result_addr=1152921510066237072 |  dest_result_addr=1152921510066237080
            // 0x00BD1D00: STP x29, x30, [sp, #0x20]  | stack[1152921510066237088] = ???;  stack[1152921510066237096] = ???;  //  dest_result_addr=1152921510066237088 |  dest_result_addr=1152921510066237096
            // 0x00BD1D04: ADD x29, sp, #0x20         | X29 = (1152921510066237056 + 32) = 1152921510066237088 (0x100000014567AEA0);
            // 0x00BD1D08: SUB sp, sp, #0x20          | SP = (1152921510066237056 - 32) = 1152921510066237024 (0x100000014567AE60);
            // 0x00BD1D0C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD1D10: LDRB w8, [x21, #0xbdc]     | W8 = (bool)static_value_03733BDC;       
            // 0x00BD1D14: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD1D18: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD1D1C: TBNZ w8, #0, #0xbd1d38     | if (static_value_03733BDC == true) goto label_0;
            // 0x00BD1D20: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x00BD1D24: LDR x8, [x8, #0xe78]       | X8 = 0x2B8F798;                         
            // 0x00BD1D28: LDR w0, [x8]               | W0 = 0x14AA;                            
            // 0x00BD1D2C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14AA, ????);     
            // 0x00BD1D30: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD1D34: STRB w8, [x21, #0xbdc]     | static_value_03733BDC = true;            //  dest_result_addr=57883612
            label_0:
            // 0x00BD1D38: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD1D3C: CBZ x21, #0xbd1df0         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD1D40: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD1D44: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD1D48: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD1D4C: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1D50: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD1D54: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1D58: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1D5C: B.LO #0xbd1d74             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD1D60: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD1D64: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1D68: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1D6C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1D70: B.EQ #0xbd1d9c             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD1D74: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD1D78: ADD x8, sp, #8             | X8 = (1152921510066237024 + 8) = 1152921510066237032 (0x100000014567AE68);
            // 0x00BD1D7C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD1D80: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510066225104]
            // 0x00BD1D84: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD1D88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1D8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD1D90: ADD x0, sp, #8             | X0 = (1152921510066237024 + 8) = 1152921510066237032 (0x100000014567AE68);
            // 0x00BD1D94: BL #0x299a140              | 
            // 0x00BD1D98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014567AE68, ????);
            label_3:
            // 0x00BD1D9C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD1DA0: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1DA4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD1DA8: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1DAC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1DB0: B.LO #0xbd1dc8             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD1DB4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD1DB8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1DBC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1DC0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1DC4: B.EQ #0xbd1df8             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD1DC8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD1DCC: ADD x8, sp, #0x10          | X8 = (1152921510066237024 + 16) = 1152921510066237040 (0x100000014567AE70);
            // 0x00BD1DD0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD1DD4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510066225104]
            // 0x00BD1DD8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD1DDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1DE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD1DE4: ADD x0, sp, #0x10          | X0 = (1152921510066237024 + 16) = 1152921510066237040 (0x100000014567AE70);
            // 0x00BD1DE8: BL #0x299a140              | 
            // 0x00BD1DEC: B #0xbd1df4                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD1DF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AA, ????);     
            label_6:
            // 0x00BD1DF4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD1DF8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD1DFC: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00BD1E00: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x00BD1E04: CBNZ x19, #0xbd1e0c        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD1E08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AA, ????);     
            label_7:
            // 0x00BD1E0C: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD1E10: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD1E14: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00BD1E18: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00BD1E1C: B.NE #0xbd1e64             | if (X2 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD1E20: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD1E24: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD1E28: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BD1E2C: STR w8, [x21, #0x20]       | mem[32] = X2;                            //  dest_result_addr=32
            mem[32] = X2;
            // 0x00BD1E30: SUB sp, x29, #0x20         | SP = (1152921510066237088 - 32) = 1152921510066237056 (0x100000014567AE80);
            // 0x00BD1E34: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD1E38: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD1E3C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD1E40: RET                        |  return;                                
            return;
            // 0x00BD1E44: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD1E48: ADD x0, sp, #8             | X0 = (1152921510066237104 + 8) = 1152921510066237112 (0x100000014567AEB8);
            // 0x00BD1E4C: B #0xbd1e58                |  goto label_10;                         
            goto label_10;
            // 0x00BD1E50: MOV x19, x0                | X19 = 1152921510066237112 (0x100000014567AEB8);//ML01
            val_7;
            // 0x00BD1E54: ADD x0, sp, #0x10          | X0 = (1152921510066237104 + 16) = 1152921510066237120 (0x100000014567AEC0);
            label_10:
            // 0x00BD1E58: BL #0x299a140              | 
            // 0x00BD1E5C: MOV x0, x19                | X0 = 1152921510066237112 (0x100000014567AEB8);//ML01
            // 0x00BD1E60: BL #0x980800               | X0 = sub_980800( ?? 0x100000014567AEB8, ????);
            label_8:
            // 0x00BD1E64: ADD x8, sp, #0x18          | X8 = (1152921510066237104 + 24) = 1152921510066237128 (0x100000014567AEC8);
            // 0x00BD1E68: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD1E6C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x100000014567AEB8, ????);
            // 0x00BD1E70: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510066225104]
            // 0x00BD1E74: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD1E78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1E7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD1E80: ADD x0, sp, #0x18          | X0 = (1152921510066237104 + 24) = 1152921510066237128 (0x100000014567AEC8);
            // 0x00BD1E84: BL #0x299a140              | 
            // 0x00BD1E88: MOV x19, x0                | X19 = 1152921510066237128 (0x100000014567AEC8);//ML01
            // 0x00BD1E8C: ADD x0, sp, #0x18          | X0 = (1152921510066237104 + 24) = 1152921510066237128 (0x100000014567AEC8);
            // 0x00BD1E90: B #0xbd1e58                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD1E94 (12394132), len: 312  VirtAddr: 0x00BD1E94 RVA: 0x00BD1E94 token: 100663896 methodIndex: 29941 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_offsetX_5(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD1E94: STP x20, x19, [sp, #-0x20]! | stack[1152921510066365296] = ???;  stack[1152921510066365304] = ???;  //  dest_result_addr=1152921510066365296 |  dest_result_addr=1152921510066365304
            // 0x00BD1E98: STP x29, x30, [sp, #0x10]  | stack[1152921510066365312] = ???;  stack[1152921510066365320] = ???;  //  dest_result_addr=1152921510066365312 |  dest_result_addr=1152921510066365320
            // 0x00BD1E9C: ADD x29, sp, #0x10         | X29 = (1152921510066365296 + 16) = 1152921510066365312 (0x100000014569A380);
            // 0x00BD1EA0: SUB sp, sp, #0x20          | SP = (1152921510066365296 - 32) = 1152921510066365264 (0x100000014569A350);
            // 0x00BD1EA4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD1EA8: LDRB w8, [x20, #0xbdd]     | W8 = (bool)static_value_03733BDD;       
            // 0x00BD1EAC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD1EB0: TBNZ w8, #0, #0xbd1ecc     | if (static_value_03733BDD == true) goto label_0;
            // 0x00BD1EB4: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x00BD1EB8: LDR x8, [x8, #0x1e0]       | X8 = 0x2B8F774;                         
            // 0x00BD1EBC: LDR w0, [x8]               | W0 = 0x14A1;                            
            // 0x00BD1EC0: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A1, ????);     
            // 0x00BD1EC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD1EC8: STRB w8, [x20, #0xbdd]     | static_value_03733BDD = true;            //  dest_result_addr=57883613
            label_0:
            // 0x00BD1ECC: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD1ED0: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD1ED4: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD1ED8: CBZ x19, #0xbd1f2c         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD1EDC: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD1EE0: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1EE4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD1EE8: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1EEC: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1EF0: B.LO #0xbd1f08             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD1EF4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD1EF8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1EFC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1F00: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1F04: B.EQ #0xbd1f30             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD1F08: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD1F0C: ADD x8, sp, #0x10          | X8 = (1152921510066365264 + 16) = 1152921510066365280 (0x100000014569A360);
            // 0x00BD1F10: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD1F14: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510066353328]
            // 0x00BD1F18: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD1F1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1F20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD1F24: ADD x0, sp, #0x10          | X0 = (1152921510066365264 + 16) = 1152921510066365280 (0x100000014569A360);
            // 0x00BD1F28: BL #0x299a140              | 
            label_1:
            // 0x00BD1F2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014569A360, ????);
            label_3:
            // 0x00BD1F30: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD1F34: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD1F38: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD1F3C: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD1F40: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD1F44: B.LO #0xbd1f88             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD1F48: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD1F4C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD1F50: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD1F54: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD1F58: B.NE #0xbd1f88             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD1F5C: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BD1F60: LDR w8, [x19, #0x24]       | W8 = X1 + 36;                           
            // 0x00BD1F64: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00BD1F68: ADD x1, sp, #0xc           | X1 = (1152921510066365264 + 12) = 1152921510066365276 (0x100000014569A35C);
            // 0x00BD1F6C: STR w8, [sp, #0xc]         | stack[1152921510066365276] = X1 + 36;    //  dest_result_addr=1152921510066365276
            // 0x00BD1F70: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00BD1F74: BL #0x27bc028              | X0 = 1152921510066413344 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 36);
            // 0x00BD1F78: SUB sp, x29, #0x10         | SP = (1152921510066365312 - 16) = 1152921510066365296 (0x100000014569A370);
            // 0x00BD1F7C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD1F80: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD1F84: RET                        |  return (System.Object)X1 + 36;         
            return (object)X1 + 36;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD1F88: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD1F8C: ADD x8, sp, #0x18          | X8 = (1152921510066365264 + 24) = 1152921510066365288 (0x100000014569A368);
            // 0x00BD1F90: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD1F94: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510066353328]
            // 0x00BD1F98: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD1F9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD1FA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD1FA4: ADD x0, sp, #0x18          | X0 = (1152921510066365264 + 24) = 1152921510066365288 (0x100000014569A368);
            // 0x00BD1FA8: BL #0x299a140              | 
            // 0x00BD1FAC: MOV x19, x0                | X19 = 1152921510066365288 (0x100000014569A368);//ML01
            // 0x00BD1FB0: ADD x0, sp, #0x10          | X0 = (1152921510066365264 + 16) = 1152921510066365280 (0x100000014569A360);
            label_6:
            // 0x00BD1FB4: BL #0x299a140              | 
            // 0x00BD1FB8: MOV x0, x19                | X0 = 1152921510066365288 (0x100000014569A368);//ML01
            // 0x00BD1FBC: BL #0x980800               | X0 = sub_980800( ?? 0x100000014569A368, ????);
            // 0x00BD1FC0: MOV x19, x0                | X19 = 1152921510066365288 (0x100000014569A368);//ML01
            // 0x00BD1FC4: ADD x0, sp, #0x18          | X0 = (1152921510066365264 + 24) = 1152921510066365288 (0x100000014569A368);
            // 0x00BD1FC8: B #0xbd1fb4                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD1FCC (12394444), len: 412  VirtAddr: 0x00BD1FCC RVA: 0x00BD1FCC token: 100663897 methodIndex: 29942 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_offsetX_5(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD1FCC: STP x22, x21, [sp, #-0x30]! | stack[1152921510066493504] = ???;  stack[1152921510066493512] = ???;  //  dest_result_addr=1152921510066493504 |  dest_result_addr=1152921510066493512
            // 0x00BD1FD0: STP x20, x19, [sp, #0x10]  | stack[1152921510066493520] = ???;  stack[1152921510066493528] = ???;  //  dest_result_addr=1152921510066493520 |  dest_result_addr=1152921510066493528
            // 0x00BD1FD4: STP x29, x30, [sp, #0x20]  | stack[1152921510066493536] = ???;  stack[1152921510066493544] = ???;  //  dest_result_addr=1152921510066493536 |  dest_result_addr=1152921510066493544
            // 0x00BD1FD8: ADD x29, sp, #0x20         | X29 = (1152921510066493504 + 32) = 1152921510066493536 (0x10000001456B9860);
            // 0x00BD1FDC: SUB sp, sp, #0x20          | SP = (1152921510066493504 - 32) = 1152921510066493472 (0x10000001456B9820);
            // 0x00BD1FE0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD1FE4: LDRB w8, [x21, #0xbde]     | W8 = (bool)static_value_03733BDE;       
            // 0x00BD1FE8: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD1FEC: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD1FF0: TBNZ w8, #0, #0xbd200c     | if (static_value_03733BDE == true) goto label_0;
            // 0x00BD1FF4: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x00BD1FF8: LDR x8, [x8, #0xfc8]       | X8 = 0x2B8F7A4;                         
            // 0x00BD1FFC: LDR w0, [x8]               | W0 = 0x14AD;                            
            // 0x00BD2000: BL #0x2782188              | X0 = sub_2782188( ?? 0x14AD, ????);     
            // 0x00BD2004: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2008: STRB w8, [x21, #0xbde]     | static_value_03733BDE = true;            //  dest_result_addr=57883614
            label_0:
            // 0x00BD200C: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD2010: CBZ x21, #0xbd20c4         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD2014: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD2018: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD201C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD2020: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD2024: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD2028: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD202C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2030: B.LO #0xbd2048             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD2034: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD2038: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD203C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2040: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2044: B.EQ #0xbd2070             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD2048: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD204C: ADD x8, sp, #8             | X8 = (1152921510066493472 + 8) = 1152921510066493480 (0x10000001456B9828);
            // 0x00BD2050: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD2054: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510066481552]
            // 0x00BD2058: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD205C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2060: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD2064: ADD x0, sp, #8             | X0 = (1152921510066493472 + 8) = 1152921510066493480 (0x10000001456B9828);
            // 0x00BD2068: BL #0x299a140              | 
            // 0x00BD206C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001456B9828, ????);
            label_3:
            // 0x00BD2070: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD2074: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD2078: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD207C: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2080: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2084: B.LO #0xbd209c             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD2088: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD208C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2090: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2094: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2098: B.EQ #0xbd20cc             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD209C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD20A0: ADD x8, sp, #0x10          | X8 = (1152921510066493472 + 16) = 1152921510066493488 (0x10000001456B9830);
            // 0x00BD20A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD20A8: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510066481552]
            // 0x00BD20AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD20B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD20B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD20B8: ADD x0, sp, #0x10          | X0 = (1152921510066493472 + 16) = 1152921510066493488 (0x10000001456B9830);
            // 0x00BD20BC: BL #0x299a140              | 
            // 0x00BD20C0: B #0xbd20c8                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD20C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AD, ????);     
            label_6:
            // 0x00BD20C8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD20CC: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD20D0: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00BD20D4: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x00BD20D8: CBNZ x19, #0xbd20e0        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD20DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AD, ????);     
            label_7:
            // 0x00BD20E0: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD20E4: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD20E8: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00BD20EC: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00BD20F0: B.NE #0xbd2138             | if (X2 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD20F4: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD20F8: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD20FC: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BD2100: STR w8, [x21, #0x24]       | mem[36] = X2;                            //  dest_result_addr=36
            mem[36] = X2;
            // 0x00BD2104: SUB sp, x29, #0x20         | SP = (1152921510066493536 - 32) = 1152921510066493504 (0x10000001456B9840);
            // 0x00BD2108: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD210C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD2110: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD2114: RET                        |  return;                                
            return;
            // 0x00BD2118: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD211C: ADD x0, sp, #8             | X0 = (1152921510066493552 + 8) = 1152921510066493560 (0x10000001456B9878);
            // 0x00BD2120: B #0xbd212c                |  goto label_10;                         
            goto label_10;
            // 0x00BD2124: MOV x19, x0                | X19 = 1152921510066493560 (0x10000001456B9878);//ML01
            val_7;
            // 0x00BD2128: ADD x0, sp, #0x10          | X0 = (1152921510066493552 + 16) = 1152921510066493568 (0x10000001456B9880);
            label_10:
            // 0x00BD212C: BL #0x299a140              | 
            // 0x00BD2130: MOV x0, x19                | X0 = 1152921510066493560 (0x10000001456B9878);//ML01
            // 0x00BD2134: BL #0x980800               | X0 = sub_980800( ?? 0x10000001456B9878, ????);
            label_8:
            // 0x00BD2138: ADD x8, sp, #0x18          | X8 = (1152921510066493552 + 24) = 1152921510066493576 (0x10000001456B9888);
            // 0x00BD213C: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD2140: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001456B9878, ????);
            // 0x00BD2144: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510066481552]
            // 0x00BD2148: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD214C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2150: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD2154: ADD x0, sp, #0x18          | X0 = (1152921510066493552 + 24) = 1152921510066493576 (0x10000001456B9888);
            // 0x00BD2158: BL #0x299a140              | 
            // 0x00BD215C: MOV x19, x0                | X19 = 1152921510066493576 (0x10000001456B9888);//ML01
            // 0x00BD2160: ADD x0, sp, #0x18          | X0 = (1152921510066493552 + 24) = 1152921510066493576 (0x10000001456B9888);
            // 0x00BD2164: B #0xbd212c                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD2168 (12394856), len: 312  VirtAddr: 0x00BD2168 RVA: 0x00BD2168 token: 100663898 methodIndex: 29943 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_offsetY_6(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD2168: STP x20, x19, [sp, #-0x20]! | stack[1152921510066621744] = ???;  stack[1152921510066621752] = ???;  //  dest_result_addr=1152921510066621744 |  dest_result_addr=1152921510066621752
            // 0x00BD216C: STP x29, x30, [sp, #0x10]  | stack[1152921510066621760] = ???;  stack[1152921510066621768] = ???;  //  dest_result_addr=1152921510066621760 |  dest_result_addr=1152921510066621768
            // 0x00BD2170: ADD x29, sp, #0x10         | X29 = (1152921510066621744 + 16) = 1152921510066621760 (0x10000001456D8D40);
            // 0x00BD2174: SUB sp, sp, #0x20          | SP = (1152921510066621744 - 32) = 1152921510066621712 (0x10000001456D8D10);
            // 0x00BD2178: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD217C: LDRB w8, [x20, #0xbdf]     | W8 = (bool)static_value_03733BDF;       
            // 0x00BD2180: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD2184: TBNZ w8, #0, #0xbd21a0     | if (static_value_03733BDF == true) goto label_0;
            // 0x00BD2188: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00BD218C: LDR x8, [x8, #0xe00]       | X8 = 0x2B8F778;                         
            // 0x00BD2190: LDR w0, [x8]               | W0 = 0x14A2;                            
            // 0x00BD2194: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A2, ????);     
            // 0x00BD2198: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD219C: STRB w8, [x20, #0xbdf]     | static_value_03733BDF = true;            //  dest_result_addr=57883615
            label_0:
            // 0x00BD21A0: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD21A4: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD21A8: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD21AC: CBZ x19, #0xbd2200         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD21B0: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD21B4: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD21B8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD21BC: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD21C0: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD21C4: B.LO #0xbd21dc             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD21C8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD21CC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD21D0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD21D4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD21D8: B.EQ #0xbd2204             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD21DC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD21E0: ADD x8, sp, #0x10          | X8 = (1152921510066621712 + 16) = 1152921510066621728 (0x10000001456D8D20);
            // 0x00BD21E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD21E8: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510066609776]
            // 0x00BD21EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD21F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD21F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD21F8: ADD x0, sp, #0x10          | X0 = (1152921510066621712 + 16) = 1152921510066621728 (0x10000001456D8D20);
            // 0x00BD21FC: BL #0x299a140              | 
            label_1:
            // 0x00BD2200: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001456D8D20, ????);
            label_3:
            // 0x00BD2204: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD2208: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD220C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD2210: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2214: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2218: B.LO #0xbd225c             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD221C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD2220: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2224: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2228: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD222C: B.NE #0xbd225c             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD2230: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BD2234: LDR w8, [x19, #0x28]       | W8 = X1 + 40;                           
            // 0x00BD2238: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00BD223C: ADD x1, sp, #0xc           | X1 = (1152921510066621712 + 12) = 1152921510066621724 (0x10000001456D8D1C);
            // 0x00BD2240: STR w8, [sp, #0xc]         | stack[1152921510066621724] = X1 + 40;    //  dest_result_addr=1152921510066621724
            // 0x00BD2244: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00BD2248: BL #0x27bc028              | X0 = 1152921510066669792 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 40);
            // 0x00BD224C: SUB sp, x29, #0x10         | SP = (1152921510066621760 - 16) = 1152921510066621744 (0x10000001456D8D30);
            // 0x00BD2250: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD2254: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD2258: RET                        |  return (System.Object)X1 + 40;         
            return (object)X1 + 40;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD225C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD2260: ADD x8, sp, #0x18          | X8 = (1152921510066621712 + 24) = 1152921510066621736 (0x10000001456D8D28);
            // 0x00BD2264: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD2268: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510066609776]
            // 0x00BD226C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD2270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2274: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD2278: ADD x0, sp, #0x18          | X0 = (1152921510066621712 + 24) = 1152921510066621736 (0x10000001456D8D28);
            // 0x00BD227C: BL #0x299a140              | 
            // 0x00BD2280: MOV x19, x0                | X19 = 1152921510066621736 (0x10000001456D8D28);//ML01
            // 0x00BD2284: ADD x0, sp, #0x10          | X0 = (1152921510066621712 + 16) = 1152921510066621728 (0x10000001456D8D20);
            label_6:
            // 0x00BD2288: BL #0x299a140              | 
            // 0x00BD228C: MOV x0, x19                | X0 = 1152921510066621736 (0x10000001456D8D28);//ML01
            // 0x00BD2290: BL #0x980800               | X0 = sub_980800( ?? 0x10000001456D8D28, ????);
            // 0x00BD2294: MOV x19, x0                | X19 = 1152921510066621736 (0x10000001456D8D28);//ML01
            // 0x00BD2298: ADD x0, sp, #0x18          | X0 = (1152921510066621712 + 24) = 1152921510066621736 (0x10000001456D8D28);
            // 0x00BD229C: B #0xbd2288                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD22A0 (12395168), len: 412  VirtAddr: 0x00BD22A0 RVA: 0x00BD22A0 token: 100663899 methodIndex: 29944 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_offsetY_6(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD22A0: STP x22, x21, [sp, #-0x30]! | stack[1152921510066749952] = ???;  stack[1152921510066749960] = ???;  //  dest_result_addr=1152921510066749952 |  dest_result_addr=1152921510066749960
            // 0x00BD22A4: STP x20, x19, [sp, #0x10]  | stack[1152921510066749968] = ???;  stack[1152921510066749976] = ???;  //  dest_result_addr=1152921510066749968 |  dest_result_addr=1152921510066749976
            // 0x00BD22A8: STP x29, x30, [sp, #0x20]  | stack[1152921510066749984] = ???;  stack[1152921510066749992] = ???;  //  dest_result_addr=1152921510066749984 |  dest_result_addr=1152921510066749992
            // 0x00BD22AC: ADD x29, sp, #0x20         | X29 = (1152921510066749952 + 32) = 1152921510066749984 (0x10000001456F8220);
            // 0x00BD22B0: SUB sp, sp, #0x20          | SP = (1152921510066749952 - 32) = 1152921510066749920 (0x10000001456F81E0);
            // 0x00BD22B4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD22B8: LDRB w8, [x21, #0xbe0]     | W8 = (bool)static_value_03733BE0;       
            // 0x00BD22BC: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD22C0: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD22C4: TBNZ w8, #0, #0xbd22e0     | if (static_value_03733BE0 == true) goto label_0;
            // 0x00BD22C8: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00BD22CC: LDR x8, [x8, #0x6f0]       | X8 = 0x2B8F7A8;                         
            // 0x00BD22D0: LDR w0, [x8]               | W0 = 0x14AE;                            
            // 0x00BD22D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x14AE, ????);     
            // 0x00BD22D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD22DC: STRB w8, [x21, #0xbe0]     | static_value_03733BE0 = true;            //  dest_result_addr=57883616
            label_0:
            // 0x00BD22E0: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD22E4: CBZ x21, #0xbd2398         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD22E8: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD22EC: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD22F0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD22F4: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD22F8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD22FC: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2300: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2304: B.LO #0xbd231c             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD2308: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD230C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2310: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2314: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2318: B.EQ #0xbd2344             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD231C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD2320: ADD x8, sp, #8             | X8 = (1152921510066749920 + 8) = 1152921510066749928 (0x10000001456F81E8);
            // 0x00BD2324: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD2328: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510066738000]
            // 0x00BD232C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD2330: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2334: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD2338: ADD x0, sp, #8             | X0 = (1152921510066749920 + 8) = 1152921510066749928 (0x10000001456F81E8);
            // 0x00BD233C: BL #0x299a140              | 
            // 0x00BD2340: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001456F81E8, ????);
            label_3:
            // 0x00BD2344: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD2348: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD234C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD2350: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2354: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2358: B.LO #0xbd2370             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD235C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD2360: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2364: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2368: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD236C: B.EQ #0xbd23a0             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD2370: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD2374: ADD x8, sp, #0x10          | X8 = (1152921510066749920 + 16) = 1152921510066749936 (0x10000001456F81F0);
            // 0x00BD2378: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD237C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510066738000]
            // 0x00BD2380: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD2384: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2388: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD238C: ADD x0, sp, #0x10          | X0 = (1152921510066749920 + 16) = 1152921510066749936 (0x10000001456F81F0);
            // 0x00BD2390: BL #0x299a140              | 
            // 0x00BD2394: B #0xbd239c                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD2398: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AE, ????);     
            label_6:
            // 0x00BD239C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD23A0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD23A4: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00BD23A8: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x00BD23AC: CBNZ x19, #0xbd23b4        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD23B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AE, ????);     
            label_7:
            // 0x00BD23B4: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD23B8: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD23BC: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00BD23C0: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00BD23C4: B.NE #0xbd240c             | if (X2 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD23C8: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD23CC: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD23D0: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BD23D4: STR w8, [x21, #0x28]       | mem[40] = X2;                            //  dest_result_addr=40
            mem[40] = X2;
            // 0x00BD23D8: SUB sp, x29, #0x20         | SP = (1152921510066749984 - 32) = 1152921510066749952 (0x10000001456F8200);
            // 0x00BD23DC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD23E0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD23E4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD23E8: RET                        |  return;                                
            return;
            // 0x00BD23EC: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD23F0: ADD x0, sp, #8             | X0 = (1152921510066750000 + 8) = 1152921510066750008 (0x10000001456F8238);
            // 0x00BD23F4: B #0xbd2400                |  goto label_10;                         
            goto label_10;
            // 0x00BD23F8: MOV x19, x0                | X19 = 1152921510066750008 (0x10000001456F8238);//ML01
            val_7;
            // 0x00BD23FC: ADD x0, sp, #0x10          | X0 = (1152921510066750000 + 16) = 1152921510066750016 (0x10000001456F8240);
            label_10:
            // 0x00BD2400: BL #0x299a140              | 
            // 0x00BD2404: MOV x0, x19                | X0 = 1152921510066750008 (0x10000001456F8238);//ML01
            // 0x00BD2408: BL #0x980800               | X0 = sub_980800( ?? 0x10000001456F8238, ????);
            label_8:
            // 0x00BD240C: ADD x8, sp, #0x18          | X8 = (1152921510066750000 + 24) = 1152921510066750024 (0x10000001456F8248);
            // 0x00BD2410: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD2414: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001456F8238, ????);
            // 0x00BD2418: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510066738000]
            // 0x00BD241C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD2420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2424: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD2428: ADD x0, sp, #0x18          | X0 = (1152921510066750000 + 24) = 1152921510066750024 (0x10000001456F8248);
            // 0x00BD242C: BL #0x299a140              | 
            // 0x00BD2430: MOV x19, x0                | X19 = 1152921510066750024 (0x10000001456F8248);//ML01
            // 0x00BD2434: ADD x0, sp, #0x18          | X0 = (1152921510066750000 + 24) = 1152921510066750024 (0x10000001456F8248);
            // 0x00BD2438: B #0xbd2400                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD243C (12395580), len: 312  VirtAddr: 0x00BD243C RVA: 0x00BD243C token: 100663900 methodIndex: 29945 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_advance_7(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD243C: STP x20, x19, [sp, #-0x20]! | stack[1152921510066878192] = ???;  stack[1152921510066878200] = ???;  //  dest_result_addr=1152921510066878192 |  dest_result_addr=1152921510066878200
            // 0x00BD2440: STP x29, x30, [sp, #0x10]  | stack[1152921510066878208] = ???;  stack[1152921510066878216] = ???;  //  dest_result_addr=1152921510066878208 |  dest_result_addr=1152921510066878216
            // 0x00BD2444: ADD x29, sp, #0x10         | X29 = (1152921510066878192 + 16) = 1152921510066878208 (0x1000000145717700);
            // 0x00BD2448: SUB sp, sp, #0x20          | SP = (1152921510066878192 - 32) = 1152921510066878160 (0x10000001457176D0);
            // 0x00BD244C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD2450: LDRB w8, [x20, #0xbe1]     | W8 = (bool)static_value_03733BE1;       
            // 0x00BD2454: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD2458: TBNZ w8, #0, #0xbd2474     | if (static_value_03733BE1 == true) goto label_0;
            // 0x00BD245C: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x00BD2460: LDR x8, [x8, #0xa70]       | X8 = 0x2B8F760;                         
            // 0x00BD2464: LDR w0, [x8]               | W0 = 0x149C;                            
            // 0x00BD2468: BL #0x2782188              | X0 = sub_2782188( ?? 0x149C, ????);     
            // 0x00BD246C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2470: STRB w8, [x20, #0xbe1]     | static_value_03733BE1 = true;            //  dest_result_addr=57883617
            label_0:
            // 0x00BD2474: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD2478: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD247C: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD2480: CBZ x19, #0xbd24d4         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD2484: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD2488: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD248C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD2490: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2494: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2498: B.LO #0xbd24b0             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD249C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD24A0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD24A4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD24A8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD24AC: B.EQ #0xbd24d8             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD24B0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD24B4: ADD x8, sp, #0x10          | X8 = (1152921510066878160 + 16) = 1152921510066878176 (0x10000001457176E0);
            // 0x00BD24B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD24BC: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510066866224]
            // 0x00BD24C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD24C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD24C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD24CC: ADD x0, sp, #0x10          | X0 = (1152921510066878160 + 16) = 1152921510066878176 (0x10000001457176E0);
            // 0x00BD24D0: BL #0x299a140              | 
            label_1:
            // 0x00BD24D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001457176E0, ????);
            label_3:
            // 0x00BD24D8: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD24DC: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD24E0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD24E4: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD24E8: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD24EC: B.LO #0xbd2530             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD24F0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD24F4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD24F8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD24FC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2500: B.NE #0xbd2530             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD2504: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BD2508: LDR w8, [x19, #0x2c]       | W8 = X1 + 44;                           
            // 0x00BD250C: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00BD2510: ADD x1, sp, #0xc           | X1 = (1152921510066878160 + 12) = 1152921510066878172 (0x10000001457176DC);
            // 0x00BD2514: STR w8, [sp, #0xc]         | stack[1152921510066878172] = X1 + 44;    //  dest_result_addr=1152921510066878172
            // 0x00BD2518: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00BD251C: BL #0x27bc028              | X0 = 1152921510066926240 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 44);
            // 0x00BD2520: SUB sp, x29, #0x10         | SP = (1152921510066878208 - 16) = 1152921510066878192 (0x10000001457176F0);
            // 0x00BD2524: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD2528: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD252C: RET                        |  return (System.Object)X1 + 44;         
            return (object)X1 + 44;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD2530: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD2534: ADD x8, sp, #0x18          | X8 = (1152921510066878160 + 24) = 1152921510066878184 (0x10000001457176E8);
            // 0x00BD2538: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD253C: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510066866224]
            // 0x00BD2540: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD2544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2548: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD254C: ADD x0, sp, #0x18          | X0 = (1152921510066878160 + 24) = 1152921510066878184 (0x10000001457176E8);
            // 0x00BD2550: BL #0x299a140              | 
            // 0x00BD2554: MOV x19, x0                | X19 = 1152921510066878184 (0x10000001457176E8);//ML01
            // 0x00BD2558: ADD x0, sp, #0x10          | X0 = (1152921510066878160 + 16) = 1152921510066878176 (0x10000001457176E0);
            label_6:
            // 0x00BD255C: BL #0x299a140              | 
            // 0x00BD2560: MOV x0, x19                | X0 = 1152921510066878184 (0x10000001457176E8);//ML01
            // 0x00BD2564: BL #0x980800               | X0 = sub_980800( ?? 0x10000001457176E8, ????);
            // 0x00BD2568: MOV x19, x0                | X19 = 1152921510066878184 (0x10000001457176E8);//ML01
            // 0x00BD256C: ADD x0, sp, #0x18          | X0 = (1152921510066878160 + 24) = 1152921510066878184 (0x10000001457176E8);
            // 0x00BD2570: B #0xbd255c                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD2574 (12395892), len: 412  VirtAddr: 0x00BD2574 RVA: 0x00BD2574 token: 100663901 methodIndex: 29946 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_advance_7(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD2574: STP x22, x21, [sp, #-0x30]! | stack[1152921510067006400] = ???;  stack[1152921510067006408] = ???;  //  dest_result_addr=1152921510067006400 |  dest_result_addr=1152921510067006408
            // 0x00BD2578: STP x20, x19, [sp, #0x10]  | stack[1152921510067006416] = ???;  stack[1152921510067006424] = ???;  //  dest_result_addr=1152921510067006416 |  dest_result_addr=1152921510067006424
            // 0x00BD257C: STP x29, x30, [sp, #0x20]  | stack[1152921510067006432] = ???;  stack[1152921510067006440] = ???;  //  dest_result_addr=1152921510067006432 |  dest_result_addr=1152921510067006440
            // 0x00BD2580: ADD x29, sp, #0x20         | X29 = (1152921510067006400 + 32) = 1152921510067006432 (0x1000000145736BE0);
            // 0x00BD2584: SUB sp, sp, #0x20          | SP = (1152921510067006400 - 32) = 1152921510067006368 (0x1000000145736BA0);
            // 0x00BD2588: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD258C: LDRB w8, [x21, #0xbe2]     | W8 = (bool)static_value_03733BE2;       
            // 0x00BD2590: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD2594: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD2598: TBNZ w8, #0, #0xbd25b4     | if (static_value_03733BE2 == true) goto label_0;
            // 0x00BD259C: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00BD25A0: LDR x8, [x8, #0xa98]       | X8 = 0x2B8F790;                         
            // 0x00BD25A4: LDR w0, [x8]               | W0 = 0x14A8;                            
            // 0x00BD25A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A8, ????);     
            // 0x00BD25AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD25B0: STRB w8, [x21, #0xbe2]     | static_value_03733BE2 = true;            //  dest_result_addr=57883618
            label_0:
            // 0x00BD25B4: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD25B8: CBZ x21, #0xbd266c         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD25BC: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD25C0: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD25C4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD25C8: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD25CC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD25D0: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD25D4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD25D8: B.LO #0xbd25f0             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD25DC: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD25E0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD25E4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD25E8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD25EC: B.EQ #0xbd2618             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD25F0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD25F4: ADD x8, sp, #8             | X8 = (1152921510067006368 + 8) = 1152921510067006376 (0x1000000145736BA8);
            // 0x00BD25F8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD25FC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510066994448]
            // 0x00BD2600: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD2604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2608: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD260C: ADD x0, sp, #8             | X0 = (1152921510067006368 + 8) = 1152921510067006376 (0x1000000145736BA8);
            // 0x00BD2610: BL #0x299a140              | 
            // 0x00BD2614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145736BA8, ????);
            label_3:
            // 0x00BD2618: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD261C: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD2620: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD2624: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2628: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD262C: B.LO #0xbd2644             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD2630: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD2634: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2638: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD263C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2640: B.EQ #0xbd2674             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD2644: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD2648: ADD x8, sp, #0x10          | X8 = (1152921510067006368 + 16) = 1152921510067006384 (0x1000000145736BB0);
            // 0x00BD264C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD2650: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510066994448]
            // 0x00BD2654: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD2658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD265C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD2660: ADD x0, sp, #0x10          | X0 = (1152921510067006368 + 16) = 1152921510067006384 (0x1000000145736BB0);
            // 0x00BD2664: BL #0x299a140              | 
            // 0x00BD2668: B #0xbd2670                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD266C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14A8, ????);     
            label_6:
            // 0x00BD2670: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD2674: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD2678: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00BD267C: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x00BD2680: CBNZ x19, #0xbd2688        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD2684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14A8, ????);     
            label_7:
            // 0x00BD2688: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD268C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD2690: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00BD2694: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00BD2698: B.NE #0xbd26e0             | if (X2 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD269C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD26A0: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD26A4: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BD26A8: STR w8, [x21, #0x2c]       | mem[44] = X2;                            //  dest_result_addr=44
            mem[44] = X2;
            // 0x00BD26AC: SUB sp, x29, #0x20         | SP = (1152921510067006432 - 32) = 1152921510067006400 (0x1000000145736BC0);
            // 0x00BD26B0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD26B4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD26B8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD26BC: RET                        |  return;                                
            return;
            // 0x00BD26C0: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD26C4: ADD x0, sp, #8             | X0 = (1152921510067006448 + 8) = 1152921510067006456 (0x1000000145736BF8);
            // 0x00BD26C8: B #0xbd26d4                |  goto label_10;                         
            goto label_10;
            // 0x00BD26CC: MOV x19, x0                | X19 = 1152921510067006456 (0x1000000145736BF8);//ML01
            val_7;
            // 0x00BD26D0: ADD x0, sp, #0x10          | X0 = (1152921510067006448 + 16) = 1152921510067006464 (0x1000000145736C00);
            label_10:
            // 0x00BD26D4: BL #0x299a140              | 
            // 0x00BD26D8: MOV x0, x19                | X0 = 1152921510067006456 (0x1000000145736BF8);//ML01
            // 0x00BD26DC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000145736BF8, ????);
            label_8:
            // 0x00BD26E0: ADD x8, sp, #0x18          | X8 = (1152921510067006448 + 24) = 1152921510067006472 (0x1000000145736C08);
            // 0x00BD26E4: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD26E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000145736BF8, ????);
            // 0x00BD26EC: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510066994448]
            // 0x00BD26F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD26F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD26F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD26FC: ADD x0, sp, #0x18          | X0 = (1152921510067006448 + 24) = 1152921510067006472 (0x1000000145736C08);
            // 0x00BD2700: BL #0x299a140              | 
            // 0x00BD2704: MOV x19, x0                | X19 = 1152921510067006472 (0x1000000145736C08);//ML01
            // 0x00BD2708: ADD x0, sp, #0x18          | X0 = (1152921510067006448 + 24) = 1152921510067006472 (0x1000000145736C08);
            // 0x00BD270C: B #0xbd26d4                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD2710 (12396304), len: 312  VirtAddr: 0x00BD2710 RVA: 0x00BD2710 token: 100663902 methodIndex: 29947 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_channel_8(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD2710: STP x20, x19, [sp, #-0x20]! | stack[1152921510067134640] = ???;  stack[1152921510067134648] = ???;  //  dest_result_addr=1152921510067134640 |  dest_result_addr=1152921510067134648
            // 0x00BD2714: STP x29, x30, [sp, #0x10]  | stack[1152921510067134656] = ???;  stack[1152921510067134664] = ???;  //  dest_result_addr=1152921510067134656 |  dest_result_addr=1152921510067134664
            // 0x00BD2718: ADD x29, sp, #0x10         | X29 = (1152921510067134640 + 16) = 1152921510067134656 (0x10000001457560C0);
            // 0x00BD271C: SUB sp, sp, #0x20          | SP = (1152921510067134640 - 32) = 1152921510067134608 (0x1000000145756090);
            // 0x00BD2720: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD2724: LDRB w8, [x20, #0xbe3]     | W8 = (bool)static_value_03733BE3;       
            // 0x00BD2728: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD272C: TBNZ w8, #0, #0xbd2748     | if (static_value_03733BE3 == true) goto label_0;
            // 0x00BD2730: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
            // 0x00BD2734: LDR x8, [x8, #0x190]       | X8 = 0x2B8F764;                         
            // 0x00BD2738: LDR w0, [x8]               | W0 = 0x149D;                            
            // 0x00BD273C: BL #0x2782188              | X0 = sub_2782188( ?? 0x149D, ????);     
            // 0x00BD2740: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2744: STRB w8, [x20, #0xbe3]     | static_value_03733BE3 = true;            //  dest_result_addr=57883619
            label_0:
            // 0x00BD2748: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD274C: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD2750: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD2754: CBZ x19, #0xbd27a8         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD2758: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD275C: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD2760: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD2764: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2768: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD276C: B.LO #0xbd2784             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD2770: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD2774: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2778: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD277C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2780: B.EQ #0xbd27ac             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD2784: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD2788: ADD x8, sp, #0x10          | X8 = (1152921510067134608 + 16) = 1152921510067134624 (0x10000001457560A0);
            // 0x00BD278C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD2790: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510067122672]
            // 0x00BD2794: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD2798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD279C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD27A0: ADD x0, sp, #0x10          | X0 = (1152921510067134608 + 16) = 1152921510067134624 (0x10000001457560A0);
            // 0x00BD27A4: BL #0x299a140              | 
            label_1:
            // 0x00BD27A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001457560A0, ????);
            label_3:
            // 0x00BD27AC: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD27B0: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD27B4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD27B8: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD27BC: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD27C0: B.LO #0xbd2804             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD27C4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD27C8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD27CC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD27D0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD27D4: B.NE #0xbd2804             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD27D8: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BD27DC: LDR w8, [x19, #0x30]       | W8 = X1 + 48;                           
            // 0x00BD27E0: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00BD27E4: ADD x1, sp, #0xc           | X1 = (1152921510067134608 + 12) = 1152921510067134620 (0x100000014575609C);
            // 0x00BD27E8: STR w8, [sp, #0xc]         | stack[1152921510067134620] = X1 + 48;    //  dest_result_addr=1152921510067134620
            // 0x00BD27EC: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00BD27F0: BL #0x27bc028              | X0 = 1152921510067182688 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), X1 + 48);
            // 0x00BD27F4: SUB sp, x29, #0x10         | SP = (1152921510067134656 - 16) = 1152921510067134640 (0x10000001457560B0);
            // 0x00BD27F8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD27FC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD2800: RET                        |  return (System.Object)X1 + 48;         
            return (object)X1 + 48;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD2804: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD2808: ADD x8, sp, #0x18          | X8 = (1152921510067134608 + 24) = 1152921510067134632 (0x10000001457560A8);
            // 0x00BD280C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD2810: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510067122672]
            // 0x00BD2814: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD2818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD281C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD2820: ADD x0, sp, #0x18          | X0 = (1152921510067134608 + 24) = 1152921510067134632 (0x10000001457560A8);
            // 0x00BD2824: BL #0x299a140              | 
            // 0x00BD2828: MOV x19, x0                | X19 = 1152921510067134632 (0x10000001457560A8);//ML01
            // 0x00BD282C: ADD x0, sp, #0x10          | X0 = (1152921510067134608 + 16) = 1152921510067134624 (0x10000001457560A0);
            label_6:
            // 0x00BD2830: BL #0x299a140              | 
            // 0x00BD2834: MOV x0, x19                | X0 = 1152921510067134632 (0x10000001457560A8);//ML01
            // 0x00BD2838: BL #0x980800               | X0 = sub_980800( ?? 0x10000001457560A8, ????);
            // 0x00BD283C: MOV x19, x0                | X19 = 1152921510067134632 (0x10000001457560A8);//ML01
            // 0x00BD2840: ADD x0, sp, #0x18          | X0 = (1152921510067134608 + 24) = 1152921510067134632 (0x10000001457560A8);
            // 0x00BD2844: B #0xbd2830                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD2848 (12396616), len: 412  VirtAddr: 0x00BD2848 RVA: 0x00BD2848 token: 100663903 methodIndex: 29948 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_channel_8(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD2848: STP x22, x21, [sp, #-0x30]! | stack[1152921510067262848] = ???;  stack[1152921510067262856] = ???;  //  dest_result_addr=1152921510067262848 |  dest_result_addr=1152921510067262856
            // 0x00BD284C: STP x20, x19, [sp, #0x10]  | stack[1152921510067262864] = ???;  stack[1152921510067262872] = ???;  //  dest_result_addr=1152921510067262864 |  dest_result_addr=1152921510067262872
            // 0x00BD2850: STP x29, x30, [sp, #0x20]  | stack[1152921510067262880] = ???;  stack[1152921510067262888] = ???;  //  dest_result_addr=1152921510067262880 |  dest_result_addr=1152921510067262888
            // 0x00BD2854: ADD x29, sp, #0x20         | X29 = (1152921510067262848 + 32) = 1152921510067262880 (0x10000001457755A0);
            // 0x00BD2858: SUB sp, sp, #0x20          | SP = (1152921510067262848 - 32) = 1152921510067262816 (0x1000000145775560);
            // 0x00BD285C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD2860: LDRB w8, [x21, #0xbe4]     | W8 = (bool)static_value_03733BE4;       
            // 0x00BD2864: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD2868: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD286C: TBNZ w8, #0, #0xbd2888     | if (static_value_03733BE4 == true) goto label_0;
            // 0x00BD2870: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00BD2874: LDR x8, [x8, #0xa60]       | X8 = 0x2B8F794;                         
            // 0x00BD2878: LDR w0, [x8]               | W0 = 0x14A9;                            
            // 0x00BD287C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A9, ????);     
            // 0x00BD2880: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2884: STRB w8, [x21, #0xbe4]     | static_value_03733BE4 = true;            //  dest_result_addr=57883620
            label_0:
            // 0x00BD2888: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD288C: CBZ x21, #0xbd2940         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD2890: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD2894: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD2898: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD289C: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD28A0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD28A4: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD28A8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD28AC: B.LO #0xbd28c4             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD28B0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD28B4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD28B8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD28BC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD28C0: B.EQ #0xbd28ec             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD28C4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD28C8: ADD x8, sp, #8             | X8 = (1152921510067262816 + 8) = 1152921510067262824 (0x1000000145775568);
            // 0x00BD28CC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD28D0: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510067250896]
            // 0x00BD28D4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD28D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD28DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD28E0: ADD x0, sp, #8             | X0 = (1152921510067262816 + 8) = 1152921510067262824 (0x1000000145775568);
            // 0x00BD28E4: BL #0x299a140              | 
            // 0x00BD28E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145775568, ????);
            label_3:
            // 0x00BD28EC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD28F0: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD28F4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD28F8: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD28FC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2900: B.LO #0xbd2918             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD2904: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD2908: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD290C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2910: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2914: B.EQ #0xbd2948             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD2918: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD291C: ADD x8, sp, #0x10          | X8 = (1152921510067262816 + 16) = 1152921510067262832 (0x1000000145775570);
            // 0x00BD2920: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD2924: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510067250896]
            // 0x00BD2928: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD292C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2930: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD2934: ADD x0, sp, #0x10          | X0 = (1152921510067262816 + 16) = 1152921510067262832 (0x1000000145775570);
            // 0x00BD2938: BL #0x299a140              | 
            // 0x00BD293C: B #0xbd2944                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD2940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14A9, ????);     
            label_6:
            // 0x00BD2944: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD2948: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD294C: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00BD2950: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x00BD2954: CBNZ x19, #0xbd295c        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD2958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14A9, ????);     
            label_7:
            // 0x00BD295C: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD2960: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD2964: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00BD2968: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00BD296C: B.NE #0xbd29b4             | if (X2 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD2970: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD2974: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD2978: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BD297C: STR w8, [x21, #0x30]       | mem[48] = X2;                            //  dest_result_addr=48
            mem[48] = X2;
            // 0x00BD2980: SUB sp, x29, #0x20         | SP = (1152921510067262880 - 32) = 1152921510067262848 (0x1000000145775580);
            // 0x00BD2984: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD2988: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD298C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD2990: RET                        |  return;                                
            return;
            // 0x00BD2994: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD2998: ADD x0, sp, #8             | X0 = (1152921510067262896 + 8) = 1152921510067262904 (0x10000001457755B8);
            // 0x00BD299C: B #0xbd29a8                |  goto label_10;                         
            goto label_10;
            // 0x00BD29A0: MOV x19, x0                | X19 = 1152921510067262904 (0x10000001457755B8);//ML01
            val_7;
            // 0x00BD29A4: ADD x0, sp, #0x10          | X0 = (1152921510067262896 + 16) = 1152921510067262912 (0x10000001457755C0);
            label_10:
            // 0x00BD29A8: BL #0x299a140              | 
            // 0x00BD29AC: MOV x0, x19                | X0 = 1152921510067262904 (0x10000001457755B8);//ML01
            // 0x00BD29B0: BL #0x980800               | X0 = sub_980800( ?? 0x10000001457755B8, ????);
            label_8:
            // 0x00BD29B4: ADD x8, sp, #0x18          | X8 = (1152921510067262896 + 24) = 1152921510067262920 (0x10000001457755C8);
            // 0x00BD29B8: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD29BC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001457755B8, ????);
            // 0x00BD29C0: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510067250896]
            // 0x00BD29C4: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD29C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD29CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD29D0: ADD x0, sp, #0x18          | X0 = (1152921510067262896 + 24) = 1152921510067262920 (0x10000001457755C8);
            // 0x00BD29D4: BL #0x299a140              | 
            // 0x00BD29D8: MOV x19, x0                | X19 = 1152921510067262920 (0x10000001457755C8);//ML01
            // 0x00BD29DC: ADD x0, sp, #0x18          | X0 = (1152921510067262896 + 24) = 1152921510067262920 (0x10000001457755C8);
            // 0x00BD29E0: B #0xbd29a8                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD29E4 (12397028), len: 288  VirtAddr: 0x00BD29E4 RVA: 0x00BD29E4 token: 100663904 methodIndex: 29949 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_kerning_9(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD29E4: STP x20, x19, [sp, #-0x20]! | stack[1152921510067386992] = ???;  stack[1152921510067387000] = ???;  //  dest_result_addr=1152921510067386992 |  dest_result_addr=1152921510067387000
            // 0x00BD29E8: STP x29, x30, [sp, #0x10]  | stack[1152921510067387008] = ???;  stack[1152921510067387016] = ???;  //  dest_result_addr=1152921510067387008 |  dest_result_addr=1152921510067387016
            // 0x00BD29EC: ADD x29, sp, #0x10         | X29 = (1152921510067386992 + 16) = 1152921510067387008 (0x1000000145793A80);
            // 0x00BD29F0: SUB sp, sp, #0x10          | SP = (1152921510067386992 - 16) = 1152921510067386976 (0x1000000145793A60);
            // 0x00BD29F4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD29F8: LDRB w8, [x20, #0xbe5]     | W8 = (bool)static_value_03733BE5;       
            // 0x00BD29FC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD2A00: TBNZ w8, #0, #0xbd2a1c     | if (static_value_03733BE5 == true) goto label_0;
            // 0x00BD2A04: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x00BD2A08: LDR x8, [x8, #0xf08]       | X8 = 0x2B8F770;                         
            // 0x00BD2A0C: LDR w0, [x8]               | W0 = 0x14A0;                            
            // 0x00BD2A10: BL #0x2782188              | X0 = sub_2782188( ?? 0x14A0, ????);     
            // 0x00BD2A14: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2A18: STRB w8, [x20, #0xbe5]     | static_value_03733BE5 = true;            //  dest_result_addr=57883621
            label_0:
            // 0x00BD2A1C: ADRP x20, #0x3680000       | X20 = 57147392 (0x3680000);             
            // 0x00BD2A20: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD2A24: LDR x20, [x20, #0x698]     | X20 = 1152921504875962368;              
            // 0x00BD2A28: CBZ x19, #0xbd2a7c         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD2A2C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD2A30: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD2A34: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD2A38: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2A3C: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2A40: B.LO #0xbd2a58             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD2A44: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD2A48: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2A4C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2A50: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2A54: B.EQ #0xbd2a80             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD2A58: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD2A5C: MOV x8, sp                 | X8 = 1152921510067386976 (0x1000000145793A60);//ML01
            // 0x00BD2A60: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD2A64: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510067375024]
            // 0x00BD2A68: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD2A6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2A70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD2A74: MOV x0, sp                 | X0 = 1152921510067386976 (0x1000000145793A60);//ML01
            // 0x00BD2A78: BL #0x299a140              | 
            label_1:
            // 0x00BD2A7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145793A60, ????);
            label_3:
            // 0x00BD2A80: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD2A84: LDR x1, [x20]              | X1 = typeof(BMGlyph);                   
            // 0x00BD2A88: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD2A8C: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2A90: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2A94: B.LO #0xbd2ac0             | if (X1 + 260 < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD2A98: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD2A9C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2AA0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2AA4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2AA8: B.NE #0xbd2ac0             | if ((X1 + 176 + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD2AAC: LDR x0, [x19, #0x38]       | X0 = X1 + 56;                           
            // 0x00BD2AB0: SUB sp, x29, #0x10         | SP = (1152921510067387008 - 16) = 1152921510067386992 (0x1000000145793A70);
            // 0x00BD2AB4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD2AB8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD2ABC: RET                        |  return (System.Object)X1 + 56;         
            return (object)X1 + 56;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD2AC0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD2AC4: ADD x8, sp, #8             | X8 = (1152921510067386976 + 8) = 1152921510067386984 (0x1000000145793A68);
            // 0x00BD2AC8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD2ACC: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510067375024]
            // 0x00BD2AD0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD2AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2AD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD2ADC: ADD x0, sp, #8             | X0 = (1152921510067386976 + 8) = 1152921510067386984 (0x1000000145793A68);
            // 0x00BD2AE0: BL #0x299a140              | 
            // 0x00BD2AE4: MOV x19, x0                | X19 = 1152921510067386984 (0x1000000145793A68);//ML01
            // 0x00BD2AE8: MOV x0, sp                 | X0 = 1152921510067386976 (0x1000000145793A60);//ML01
            label_6:
            // 0x00BD2AEC: BL #0x299a140              | 
            // 0x00BD2AF0: MOV x0, x19                | X0 = 1152921510067386984 (0x1000000145793A68);//ML01
            // 0x00BD2AF4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000145793A68, ????);
            // 0x00BD2AF8: MOV x19, x0                | X19 = 1152921510067386984 (0x1000000145793A68);//ML01
            // 0x00BD2AFC: ADD x0, sp, #8             | X0 = (1152921510067386976 + 8) = 1152921510067386984 (0x1000000145793A68);
            // 0x00BD2B00: B #0xbd2aec                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD2B04 (12397316), len: 420  VirtAddr: 0x00BD2B04 RVA: 0x00BD2B04 token: 100663905 methodIndex: 29950 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_kerning_9(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BD2B04: STP x22, x21, [sp, #-0x30]! | stack[1152921510067511104] = ???;  stack[1152921510067511112] = ???;  //  dest_result_addr=1152921510067511104 |  dest_result_addr=1152921510067511112
            // 0x00BD2B08: STP x20, x19, [sp, #0x10]  | stack[1152921510067511120] = ???;  stack[1152921510067511128] = ???;  //  dest_result_addr=1152921510067511120 |  dest_result_addr=1152921510067511128
            // 0x00BD2B0C: STP x29, x30, [sp, #0x20]  | stack[1152921510067511136] = ???;  stack[1152921510067511144] = ???;  //  dest_result_addr=1152921510067511136 |  dest_result_addr=1152921510067511144
            // 0x00BD2B10: ADD x29, sp, #0x20         | X29 = (1152921510067511104 + 32) = 1152921510067511136 (0x10000001457B1F60);
            // 0x00BD2B14: SUB sp, sp, #0x20          | SP = (1152921510067511104 - 32) = 1152921510067511072 (0x10000001457B1F20);
            // 0x00BD2B18: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD2B1C: LDRB w8, [x21, #0xbe6]     | W8 = (bool)static_value_03733BE6;       
            // 0x00BD2B20: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x00BD2B24: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD2B28: TBNZ w8, #0, #0xbd2b44     | if (static_value_03733BE6 == true) goto label_0;
            // 0x00BD2B2C: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x00BD2B30: LDR x8, [x8, #0x1d8]       | X8 = 0x2B8F7A0;                         
            // 0x00BD2B34: LDR w0, [x8]               | W0 = 0x14AC;                            
            // 0x00BD2B38: BL #0x2782188              | X0 = sub_2782188( ?? 0x14AC, ????);     
            // 0x00BD2B3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2B40: STRB w8, [x21, #0xbe6]     | static_value_03733BE6 = true;            //  dest_result_addr=57883622
            label_0:
            // 0x00BD2B44: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x00BD2B48: CBZ x20, #0xbd2bfc         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD2B4C: ADRP x21, #0x3680000       | X21 = 57147392 (0x3680000);             
            // 0x00BD2B50: LDR x21, [x21, #0x698]     | X21 = 1152921504875962368;              
            val_7 = 1152921504875962368;
            // 0x00BD2B54: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BD2B58: LDR x1, [x21]              | X1 = typeof(BMGlyph);                   
            // 0x00BD2B5C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD2B60: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2B64: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2B68: B.LO #0xbd2b80             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD2B6C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD2B70: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2B74: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2B78: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2B7C: B.EQ #0xbd2ba8             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD2B80: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD2B84: ADD x8, sp, #8             | X8 = (1152921510067511072 + 8) = 1152921510067511080 (0x10000001457B1F28);
            // 0x00BD2B88: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD2B8C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510067499152]
            // 0x00BD2B90: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD2B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2B98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD2B9C: ADD x0, sp, #8             | X0 = (1152921510067511072 + 8) = 1152921510067511080 (0x10000001457B1F28);
            // 0x00BD2BA0: BL #0x299a140              | 
            // 0x00BD2BA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001457B1F28, ????);
            label_3:
            // 0x00BD2BA8: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BD2BAC: LDR x1, [x21]              | X1 = typeof(BMGlyph);                   
            // 0x00BD2BB0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD2BB4: LDRB w9, [x1, #0x104]      | W9 = BMGlyph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2BB8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMGlyph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2BBC: B.LO #0xbd2bd4             | if (mem[null + 260] < BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD2BC0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD2BC4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2BC8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2BCC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMGlyph))
            // 0x00BD2BD0: B.EQ #0xbd2c04             | if ((mem[null + 176] + (BMGlyph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD2BD4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD2BD8: ADD x8, sp, #0x10          | X8 = (1152921510067511072 + 16) = 1152921510067511088 (0x10000001457B1F30);
            // 0x00BD2BDC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD2BE0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510067499152]
            // 0x00BD2BE4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD2BE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2BEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD2BF0: ADD x0, sp, #0x10          | X0 = (1152921510067511072 + 16) = 1152921510067511088 (0x10000001457B1F30);
            // 0x00BD2BF4: BL #0x299a140              | 
            // 0x00BD2BF8: B #0xbd2c00                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD2BFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14AC, ????);     
            label_6:
            // 0x00BD2C00: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x00BD2C04: CBZ x19, #0xbd2c60         | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x00BD2C08: ADRP x9, #0x365a000        | X9 = 56991744 (0x365A000);              
            // 0x00BD2C0C: LDR x9, [x9, #0x1c0]       | X9 = 1152921504616644608;               
            // 0x00BD2C10: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD2C14: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.List<T>);
            // 0x00BD2C18: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x00BD2C1C: LDRB w9, [x1, #0x104]      | W9 = System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD2C20: CMP w10, w9                | STATE = COMPARE(X2 + 260, System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD2C24: B.LO #0xbd2c3c             | if (X2 + 260 < System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00BD2C28: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x00BD2C2C: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD2C30: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD2C34: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Collections.Generic.List<T>))
            // 0x00BD2C38: B.EQ #0xbd2c64             | if ((X2 + 176 + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00BD2C3C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD2C40: ADD x8, sp, #0x18          | X8 = (1152921510067511072 + 24) = 1152921510067511096 (0x10000001457B1F38);
            // 0x00BD2C44: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BD2C48: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510067499152]
            // 0x00BD2C4C: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00BD2C50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2C54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00BD2C58: ADD x0, sp, #0x18          | X0 = (1152921510067511072 + 24) = 1152921510067511096 (0x10000001457B1F38);
            // 0x00BD2C5C: BL #0x299a140              | 
            label_7:
            // 0x00BD2C60: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00BD2C64: STR x19, [x20, #0x38]      | mem[56] = 0x0;                           //  dest_result_addr=56
            mem[56] = val_8;
            // 0x00BD2C68: SUB sp, x29, #0x20         | SP = (1152921510067511136 - 32) = 1152921510067511104 (0x10000001457B1F40);
            // 0x00BD2C6C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD2C70: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD2C74: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD2C78: RET                        |  return;                                
            return;
            // 0x00BD2C7C: MOV x19, x0                | 
            // 0x00BD2C80: ADD x0, sp, #8             | 
            // 0x00BD2C84: B #0xbd2c9c                | 
            // 0x00BD2C88: MOV x19, x0                | 
            // 0x00BD2C8C: ADD x0, sp, #0x10          | 
            // 0x00BD2C90: B #0xbd2c9c                | 
            // 0x00BD2C94: MOV x19, x0                | 
            // 0x00BD2C98: ADD x0, sp, #0x18          | 
            label_11:
            // 0x00BD2C9C: BL #0x299a140              | 
            // 0x00BD2CA0: MOV x0, x19                | 
            // 0x00BD2CA4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD2CA8 (12397736), len: 180  VirtAddr: 0x00BD2CA8 RVA: 0x00BD2CA8 token: 100663906 methodIndex: 29951 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BD2CA8: STP x22, x21, [sp, #-0x30]! | stack[1152921510067647600] = ???;  stack[1152921510067647608] = ???;  //  dest_result_addr=1152921510067647600 |  dest_result_addr=1152921510067647608
            // 0x00BD2CAC: STP x20, x19, [sp, #0x10]  | stack[1152921510067647616] = ???;  stack[1152921510067647624] = ???;  //  dest_result_addr=1152921510067647616 |  dest_result_addr=1152921510067647624
            // 0x00BD2CB0: STP x29, x30, [sp, #0x20]  | stack[1152921510067647632] = ???;  stack[1152921510067647640] = ???;  //  dest_result_addr=1152921510067647632 |  dest_result_addr=1152921510067647640
            // 0x00BD2CB4: ADD x29, sp, #0x20         | X29 = (1152921510067647600 + 32) = 1152921510067647632 (0x10000001457D3490);
            // 0x00BD2CB8: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00BD2CBC: LDRB w8, [x22, #0xbe7]     | W8 = (bool)static_value_03733BE7;       
            // 0x00BD2CC0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BD2CC4: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BD2CC8: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BD2CCC: TBNZ w8, #0, #0xbd2ce8     | if (static_value_03733BE7 == true) goto label_0;
            // 0x00BD2CD0: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x00BD2CD4: LDR x8, [x8, #0x710]       | X8 = 0x2B8F75C;                         
            // 0x00BD2CD8: LDR w0, [x8]               | W0 = 0x149B;                            
            // 0x00BD2CDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x149B, ????);     
            // 0x00BD2CE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2CE4: STRB w8, [x22, #0xbe7]     | static_value_03733BE7 = true;            //  dest_result_addr=57883623
            label_0:
            // 0x00BD2CE8: CBNZ x21, #0xbd2cf0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD2CEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x149B, ????);     
            label_1:
            // 0x00BD2CF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2CF4: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BD2CF8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD2CFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD2D00: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BD2D04: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BD2D08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD2D0C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BD2D10: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00BD2D14: LDR x8, [x8, #0x698]       | X8 = 1152921504875962368;               
            // 0x00BD2D18: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BD2D1C: LDR x8, [x8]               | X8 = typeof(BMGlyph);                   
            // 0x00BD2D20: MOV x0, x8                 | X0 = 1152921504875962368 (0x10000000100A6000);//ML01
            BMGlyph val_3 = null;
            // 0x00BD2D24: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BMGlyph), ????);
            // 0x00BD2D28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2D2C: MOV x21, x0                | X21 = 1152921504875962368 (0x10000000100A6000);//ML01
            // 0x00BD2D30: BL #0xb92594               | .ctor();                                
            val_3 = new BMGlyph();
            // 0x00BD2D34: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BD2D38: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BD2D3C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD2D40: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD2D44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD2D48: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BD2D4C: MOV x3, x21                | X3 = 1152921504875962368 (0x10000000100A6000);//ML01
            // 0x00BD2D50: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD2D54: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD2D58: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD2D5C (12397916), len: 92  VirtAddr: 0x00BD2D5C RVA: 0x00BD2D5C token: 100663907 methodIndex: 29952 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x00BD2D5C: STP x20, x19, [sp, #-0x20]! | stack[1152921510067776000] = ???;  stack[1152921510067776008] = ???;  //  dest_result_addr=1152921510067776000 |  dest_result_addr=1152921510067776008
            // 0x00BD2D60: STP x29, x30, [sp, #0x10]  | stack[1152921510067776016] = ???;  stack[1152921510067776024] = ???;  //  dest_result_addr=1152921510067776016 |  dest_result_addr=1152921510067776024
            // 0x00BD2D64: ADD x29, sp, #0x10         | X29 = (1152921510067776000 + 16) = 1152921510067776016 (0x10000001457F2A10);
            // 0x00BD2D68: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD2D6C: LDRB w8, [x19, #0xbe8]     | W8 = (bool)static_value_03733BE8;       
            // 0x00BD2D70: TBNZ w8, #0, #0xbd2d8c     | if (static_value_03733BE8 == true) goto label_0;
            // 0x00BD2D74: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00BD2D78: LDR x8, [x8, #0x8b0]       | X8 = 0x2B8F7C0;                         
            // 0x00BD2D7C: LDR w0, [x8]               | W0 = 0x14B4;                            
            // 0x00BD2D80: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B4, ????);     
            // 0x00BD2D84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2D88: STRB w8, [x19, #0xbe8]     | static_value_03733BE8 = true;            //  dest_result_addr=57883624
            label_0:
            // 0x00BD2D8C: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00BD2D90: LDR x8, [x8, #0x698]       | X8 = 1152921504875962368;               
            // 0x00BD2D94: LDR x0, [x8]               | X0 = typeof(BMGlyph);                   
            BMGlyph val_1 = null;
            // 0x00BD2D98: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BMGlyph), ????);
            // 0x00BD2D9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2DA0: MOV x19, x0                | X19 = 1152921504875962368 (0x10000000100A6000);//ML01
            // 0x00BD2DA4: BL #0xb92594               | .ctor();                                
            val_1 = new BMGlyph();
            // 0x00BD2DA8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD2DAC: MOV x0, x19                | X0 = 1152921504875962368 (0x10000000100A6000);//ML01
            // 0x00BD2DB0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD2DB4: RET                        |  return (System.Object)typeof(BMGlyph); 
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD2DB8 (12398008), len: 92  VirtAddr: 0x00BD2DB8 RVA: 0x00BD2DB8 token: 100663908 methodIndex: 29953 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x00BD2DB8: STP x20, x19, [sp, #-0x20]! | stack[1152921510067892096] = ???;  stack[1152921510067892104] = ???;  //  dest_result_addr=1152921510067892096 |  dest_result_addr=1152921510067892104
            // 0x00BD2DBC: STP x29, x30, [sp, #0x10]  | stack[1152921510067892112] = ???;  stack[1152921510067892120] = ???;  //  dest_result_addr=1152921510067892112 |  dest_result_addr=1152921510067892120
            // 0x00BD2DC0: ADD x29, sp, #0x10         | X29 = (1152921510067892096 + 16) = 1152921510067892112 (0x100000014580EF90);
            // 0x00BD2DC4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD2DC8: LDRB w8, [x20, #0xbe9]     | W8 = (bool)static_value_03733BE9;       
            // 0x00BD2DCC: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00BD2DD0: TBNZ w8, #0, #0xbd2dec     | if (static_value_03733BE9 == true) goto label_0;
            // 0x00BD2DD4: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00BD2DD8: LDR x8, [x8, #0x228]       | X8 = 0x2B8F7C4;                         
            // 0x00BD2DDC: LDR w0, [x8]               | W0 = 0x14B5;                            
            // 0x00BD2DE0: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B5, ????);     
            // 0x00BD2DE4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2DE8: STRB w8, [x20, #0xbe9]     | static_value_03733BE9 = true;            //  dest_result_addr=57883625
            label_0:
            // 0x00BD2DEC: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x00BD2DF0: LDR x8, [x8, #0x728]       | X8 = 1152921510067876032;               
            // 0x00BD2DF4: LDR x20, [x8]              | X20 = typeof(BMGlyph[]);                
            // 0x00BD2DF8: MOV x0, x20                | X0 = 1152921510067876032 (0x100000014580B0C0);//ML01
            // 0x00BD2DFC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(BMGlyph[]), ????);
            // 0x00BD2E00: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD2E04: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00BD2E08: MOV x0, x20                | X0 = 1152921510067876032 (0x100000014580B0C0);//ML01
            // 0x00BD2E0C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD2E10: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(BMGlyph[]), ????);
        
        }
    
    }

}
