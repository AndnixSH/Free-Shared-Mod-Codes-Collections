using UnityEngine;
public class CSAISPlayerData
{
    // Fields
    public uint roleId; //  0x00000010
    public string name; //  0x00000018
    public string unionName; //  0x00000020
    public string icon; //  0x00000028
    public uint rank; //  0x00000030
    public uint lv; //  0x00000034
    public uint vipLv; //  0x00000038
    public uint exp; //  0x0000003C
    public uint power; //  0x00000040
    public uint serviceId; //  0x00000044
    public string serviceName; //  0x00000048
    public CSHeroUnit[] heroGroups; //  0x00000050
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B43384 (11809668), len: 980  VirtAddr: 0x00B43384 RVA: 0x00B43384 token: 100693356 methodIndex: 26672 delegateWrapperIndex: 0 methodInvoker: 0
    public CSAISPlayerData(Newtonsoft.Json.Linq.JToken jToken)
    {
        //
        // Disasemble & Code
        //  | 
        var val_17;
        //  | 
        CSHeroUnit[] val_18;
        // 0x00B43384: STP x26, x25, [sp, #-0x50]! | stack[1152921514979287504] = ???;  stack[1152921514979287512] = ???;  //  dest_result_addr=1152921514979287504 |  dest_result_addr=1152921514979287512
        // 0x00B43388: STP x24, x23, [sp, #0x10]  | stack[1152921514979287520] = ???;  stack[1152921514979287528] = ???;  //  dest_result_addr=1152921514979287520 |  dest_result_addr=1152921514979287528
        // 0x00B4338C: STP x22, x21, [sp, #0x20]  | stack[1152921514979287536] = ???;  stack[1152921514979287544] = ???;  //  dest_result_addr=1152921514979287536 |  dest_result_addr=1152921514979287544
        // 0x00B43390: STP x20, x19, [sp, #0x30]  | stack[1152921514979287552] = ???;  stack[1152921514979287560] = ???;  //  dest_result_addr=1152921514979287552 |  dest_result_addr=1152921514979287560
        // 0x00B43394: STP x29, x30, [sp, #0x40]  | stack[1152921514979287568] = ???;  stack[1152921514979287576] = ???;  //  dest_result_addr=1152921514979287568 |  dest_result_addr=1152921514979287576
        // 0x00B43398: ADD x29, sp, #0x40         | X29 = (1152921514979287504 + 64) = 1152921514979287568 (0x100000026A3EE210);
        // 0x00B4339C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B433A0: LDRB w8, [x21, #0x7f9]     | W8 = (bool)static_value_037337F9;       
        // 0x00B433A4: MOV x20, x1                | X20 = jToken;//m1                       
        // 0x00B433A8: MOV x19, x0                | X19 = 1152921514979299584 (0x100000026A3F1100);//ML01
        // 0x00B433AC: TBNZ w8, #0, #0xb433c8     | if (static_value_037337F9 == true) goto label_0;
        // 0x00B433B0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00B433B4: LDR x8, [x8, #0xb08]       | X8 = 0x2B92F00;                         
        // 0x00B433B8: LDR w0, [x8]               | W0 = 0x2285;                            
        // 0x00B433BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2285, ????);     
        // 0x00B433C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B433C4: STRB w8, [x21, #0x7f9]     | static_value_037337F9 = true;            //  dest_result_addr=57882617
        label_0:
        // 0x00B433C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B433CC: MOV x0, x19                | X0 = 1152921514979299584 (0x100000026A3F1100);//ML01
        // 0x00B433D0: BL #0x16f59f0              | this..ctor();                           
        // 0x00B433D4: CBNZ x20, #0xb433dc        | if (jToken != null) goto label_1;       
        if(jToken != null)
        {
            goto label_1;
        }
        // 0x00B433D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_1:
        // 0x00B433DC: ADRP x9, #0x3633000        | X9 = 56832000 (0x3633000);              
        // 0x00B433E0: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B433E4: LDR x9, [x9, #0x518]       | X9 = (string**)(1152921510257784480)("roleId");
        // 0x00B433E8: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B433EC: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B433F0: LDR x1, [x9]               | X1 = "roleId";                          
        // 0x00B433F4: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B433F8: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B433FC: MOV x21, x0                | X21 = jToken;//m1                       
        // 0x00B43400: CBNZ x21, #0xb43408        | if (jToken != null) goto label_2;       
        if(jToken != null)
        {
            goto label_2;
        }
        // 0x00B43404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_2:
        // 0x00B43408: ADRP x22, #0x3653000       | X22 = 56963072 (0x3653000);             
        // 0x00B4340C: LDR x22, [x22, #0xb28]     | X22 = 1152921514976782000;              
        // 0x00B43410: MOV x0, x21                | X0 = jToken;//m1                        
        // 0x00B43414: LDR x1, [x22]              | X1 = public System.UInt32 Newtonsoft.Json.Linq.JToken::ToObject<System.UInt32>();
        // 0x00B43418: BL #0xfdadb0               | X0 = jToken.ToObject<System.UInt32>();  
        uint val_1 = jToken.ToObject<System.UInt32>();
        // 0x00B4341C: STR w0, [x19, #0x10]       | this.roleId = val_1;                     //  dest_result_addr=1152921514979299600
        this.roleId = val_1;
        // 0x00B43420: ADRP x9, #0x35c6000        | X9 = 56385536 (0x35C6000);              
        // 0x00B43424: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B43428: LDR x9, [x9, #0x5f0]       | X9 = (string**)(1152921509593945888)("name");
        // 0x00B4342C: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B43430: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B43434: LDR x1, [x9]               | X1 = "name";                            
        // 0x00B43438: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B4343C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B43440: MOV x21, x0                | X21 = jToken;//m1                       
        // 0x00B43444: CBNZ x21, #0xb4344c        | if (jToken != null) goto label_3;       
        if(jToken != null)
        {
            goto label_3;
        }
        // 0x00B43448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_3:
        // 0x00B4344C: ADRP x23, #0x35e8000       | X23 = 56524800 (0x35E8000);             
        // 0x00B43450: LDR x23, [x23, #0x898]     | X23 = 1152921514976783024;              
        val_17 = 1152921514976783024;
        // 0x00B43454: MOV x0, x21                | X0 = jToken;//m1                        
        // 0x00B43458: LDR x1, [x23]              | X1 = public System.String Newtonsoft.Json.Linq.JToken::ToObject<System.String>();
        // 0x00B4345C: BL #0xfda9f0               | X0 = jToken.ToObject<System.String>();  
        string val_2 = jToken.ToObject<System.String>();
        // 0x00B43460: STR x0, [x19, #0x18]       | this.name = val_2;                       //  dest_result_addr=1152921514979299608
        this.name = val_2;
        // 0x00B43464: ADRP x9, #0x35f0000        | X9 = 56557568 (0x35F0000);              
        // 0x00B43468: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B4346C: LDR x9, [x9, #0xe50]       | X9 = (string**)(1152921510257790800)("icon");
        // 0x00B43470: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B43474: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B43478: LDR x1, [x9]               | X1 = "icon";                            
        // 0x00B4347C: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B43480: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B43484: MOV x21, x0                | X21 = jToken;//m1                       
        // 0x00B43488: CBNZ x21, #0xb43490        | if (jToken != null) goto label_4;       
        if(jToken != null)
        {
            goto label_4;
        }
        // 0x00B4348C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_4:
        // 0x00B43490: LDR x1, [x23]              | X1 = public System.String Newtonsoft.Json.Linq.JToken::ToObject<System.String>();
        // 0x00B43494: MOV x0, x21                | X0 = jToken;//m1                        
        // 0x00B43498: BL #0xfda9f0               | X0 = jToken.ToObject<System.String>();  
        string val_3 = jToken.ToObject<System.String>();
        // 0x00B4349C: STR x0, [x19, #0x28]       | this.icon = val_3;                       //  dest_result_addr=1152921514979299624
        this.icon = val_3;
        // 0x00B434A0: ADRP x9, #0x35c6000        | X9 = 56385536 (0x35C6000);              
        // 0x00B434A4: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B434A8: LDR x9, [x9, #0x7e0]       | X9 = (string**)(1152921510257792928)("rank");
        // 0x00B434AC: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B434B0: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B434B4: LDR x1, [x9]               | X1 = "rank";                            
        // 0x00B434B8: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B434BC: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B434C0: MOV x21, x0                | X21 = jToken;//m1                       
        // 0x00B434C4: CBNZ x21, #0xb434cc        | if (jToken != null) goto label_5;       
        if(jToken != null)
        {
            goto label_5;
        }
        // 0x00B434C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_5:
        // 0x00B434CC: LDR x1, [x22]              | X1 = public System.UInt32 Newtonsoft.Json.Linq.JToken::ToObject<System.UInt32>();
        // 0x00B434D0: MOV x0, x21                | X0 = jToken;//m1                        
        // 0x00B434D4: BL #0xfdadb0               | X0 = jToken.ToObject<System.UInt32>();  
        uint val_4 = jToken.ToObject<System.UInt32>();
        // 0x00B434D8: STR w0, [x19, #0x30]       | this.rank = val_4;                       //  dest_result_addr=1152921514979299632
        this.rank = val_4;
        // 0x00B434DC: ADRP x9, #0x3671000        | X9 = 57085952 (0x3671000);              
        // 0x00B434E0: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B434E4: LDR x9, [x9, #0xd50]       | X9 = (string**)(1152921510257795056)("lv");
        // 0x00B434E8: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B434EC: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B434F0: LDR x1, [x9]               | X1 = "lv";                              
        // 0x00B434F4: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B434F8: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B434FC: MOV x21, x0                | X21 = jToken;//m1                       
        // 0x00B43500: CBNZ x21, #0xb43508        | if (jToken != null) goto label_6;       
        if(jToken != null)
        {
            goto label_6;
        }
        // 0x00B43504: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_6:
        // 0x00B43508: LDR x1, [x22]              | X1 = public System.UInt32 Newtonsoft.Json.Linq.JToken::ToObject<System.UInt32>();
        // 0x00B4350C: MOV x0, x21                | X0 = jToken;//m1                        
        // 0x00B43510: BL #0xfdadb0               | X0 = jToken.ToObject<System.UInt32>();  
        uint val_5 = jToken.ToObject<System.UInt32>();
        // 0x00B43514: STR w0, [x19, #0x34]       | this.lv = val_5;                         //  dest_result_addr=1152921514979299636
        this.lv = val_5;
        // 0x00B43518: ADRP x9, #0x3600000        | X9 = 56623104 (0x3600000);              
        // 0x00B4351C: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B43520: LDR x9, [x9, #0xe58]       | X9 = (string**)(1152921510122316320)("exp");
        // 0x00B43524: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B43528: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B4352C: LDR x1, [x9]               | X1 = "exp";                             
        // 0x00B43530: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B43534: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B43538: MOV x21, x0                | X21 = jToken;//m1                       
        // 0x00B4353C: CBNZ x21, #0xb43544        | if (jToken != null) goto label_7;       
        if(jToken != null)
        {
            goto label_7;
        }
        // 0x00B43540: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_7:
        // 0x00B43544: LDR x1, [x22]              | X1 = public System.UInt32 Newtonsoft.Json.Linq.JToken::ToObject<System.UInt32>();
        // 0x00B43548: MOV x0, x21                | X0 = jToken;//m1                        
        // 0x00B4354C: BL #0xfdadb0               | X0 = jToken.ToObject<System.UInt32>();  
        uint val_6 = jToken.ToObject<System.UInt32>();
        // 0x00B43550: STR w0, [x19, #0x3c]       | this.exp = val_6;                        //  dest_result_addr=1152921514979299644
        this.exp = val_6;
        // 0x00B43554: ADRP x24, #0x35cc000       | X24 = 56410112 (0x35CC000);             
        // 0x00B43558: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B4355C: LDR x24, [x24, #0x660]     | X24 = (string**)(1152921510122453664)("power");
        // 0x00B43560: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B43564: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B43568: LDR x1, [x24]              | X1 = "power";                           
        // 0x00B4356C: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B43570: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B43574: MOV x21, x0                | X21 = jToken;//m1                       
        // 0x00B43578: CBNZ x21, #0xb43580        | if (jToken != null) goto label_8;       
        if(jToken != null)
        {
            goto label_8;
        }
        // 0x00B4357C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_8:
        // 0x00B43580: LDR x1, [x22]              | X1 = public System.UInt32 Newtonsoft.Json.Linq.JToken::ToObject<System.UInt32>();
        // 0x00B43584: MOV x0, x21                | X0 = jToken;//m1                        
        // 0x00B43588: BL #0xfdadb0               | X0 = jToken.ToObject<System.UInt32>();  
        uint val_7 = jToken.ToObject<System.UInt32>();
        // 0x00B4358C: STR w0, [x19, #0x40]       | this.power = val_7;                      //  dest_result_addr=1152921514979299648
        this.power = val_7;
        // 0x00B43590: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B43594: LDR x1, [x24]              | X1 = "power";                           
        // 0x00B43598: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B4359C: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B435A0: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B435A4: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B435A8: MOV x21, x0                | X21 = jToken;//m1                       
        // 0x00B435AC: CBNZ x21, #0xb435b4        | if (jToken != null) goto label_9;       
        if(jToken != null)
        {
            goto label_9;
        }
        // 0x00B435B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_9:
        // 0x00B435B4: LDR x1, [x22]              | X1 = public System.UInt32 Newtonsoft.Json.Linq.JToken::ToObject<System.UInt32>();
        // 0x00B435B8: MOV x0, x21                | X0 = jToken;//m1                        
        // 0x00B435BC: BL #0xfdadb0               | X0 = jToken.ToObject<System.UInt32>();  
        uint val_8 = jToken.ToObject<System.UInt32>();
        // 0x00B435C0: STR w0, [x19, #0x44]       | this.serviceId = val_8;                  //  dest_result_addr=1152921514979299652
        this.serviceId = val_8;
        // 0x00B435C4: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B435C8: LDR x1, [x24]              | X1 = "power";                           
        // 0x00B435CC: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B435D0: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B435D4: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B435D8: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B435DC: MOV x21, x0                | X21 = jToken;//m1                       
        val_18 = jToken;
        // 0x00B435E0: CBNZ x21, #0xb435e8        | if (jToken != null) goto label_10;      
        if(val_18 != null)
        {
            goto label_10;
        }
        // 0x00B435E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_10:
        // 0x00B435E8: LDR x1, [x23]              | X1 = public System.String Newtonsoft.Json.Linq.JToken::ToObject<System.String>();
        // 0x00B435EC: MOV x0, x21                | X0 = jToken;//m1                        
        // 0x00B435F0: BL #0xfda9f0               | X0 = jToken.ToObject<System.String>();  
        string val_9 = val_18.ToObject<System.String>();
        // 0x00B435F4: STR x0, [x19, #0x48]       | this.serviceName = val_9;                //  dest_result_addr=1152921514979299656
        this.serviceName = val_9;
        // 0x00B435F8: ADRP x9, #0x3636000        | X9 = 56844288 (0x3636000);              
        // 0x00B435FC: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Linq.JToken);
        // 0x00B43600: LDR x9, [x9, #0xa98]       | X9 = (string**)(1152921510257807696)("heroGroups");
        // 0x00B43604: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B43608: LDR x2, [x8, #0x208]       | X2 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_208;
        // 0x00B4360C: LDR x1, [x9]               | X1 = "heroGroups";                      
        // 0x00B43610: LDR x9, [x8, #0x200]       | X9 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200;
        // 0x00B43614: BLR x9                     | X0 = typeof(Newtonsoft.Json.Linq.JToken).__il2cppRuntimeField_200();
        // 0x00B43618: MOV x20, x0                | X20 = jToken;//m1                       
        // 0x00B4361C: CBNZ x20, #0xb43624        | if (jToken != null) goto label_11;      
        if(jToken != null)
        {
            goto label_11;
        }
        // 0x00B43620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? jToken, ????);     
        label_11:
        // 0x00B43624: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
        // 0x00B43628: LDR x8, [x8, #0x340]       | X8 = 1152921514976897216;               
        // 0x00B4362C: MOV x0, x20                | X0 = jToken;//m1                        
        // 0x00B43630: LDR x1, [x8]               | X1 = public Newtonsoft.Json.Linq.JArray Newtonsoft.Json.Linq.JToken::ToObject<Newtonsoft.Json.Linq.JArray>();
        // 0x00B43634: BL #0xfda9f0               | X0 = jToken.ToObject<Newtonsoft.Json.Linq.JArray>();
        Newtonsoft.Json.Linq.JArray val_10 = jToken.ToObject<Newtonsoft.Json.Linq.JArray>();
        // 0x00B43638: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B4363C: CBZ x20, #0xb43740         | if (val_10 == null) goto label_14;      
        if(val_10 == null)
        {
            goto label_14;
        }
        // 0x00B43640: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B43644: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B43648: BL #0x132a574              | X0 = val_10.get_Count();                
        int val_11 = val_10.Count;
        // 0x00B4364C: CMP w0, #1                 | STATE = COMPARE(val_11, 0x1)            
        // 0x00B43650: B.LT #0xb43740             | if (val_11 < 1) goto label_14;          
        if(val_11 < 1)
        {
            goto label_14;
        }
        // 0x00B43654: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B43658: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B4365C: BL #0x132a574              | X0 = val_10.get_Count();                
        int val_12 = val_10.Count;
        // 0x00B43660: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
        // 0x00B43664: LDR x8, [x8, #0xd48]       | X8 = 1152921510260846336;               
        // 0x00B43668: MOV w22, w0                | W22 = val_12;//m1                       
        // 0x00B4366C: LDR x21, [x8]              | X21 = typeof(CSHeroUnit[]);             
        val_18 = null;
        // 0x00B43670: MOV x0, x21                | X0 = 1152921510260846336 (0x1000000151012F00);//ML01
        // 0x00B43674: BL #0x277461c              | X0 = sub_277461C( ?? typeof(CSHeroUnit[]), ????);
        // 0x00B43678: MOV w1, w22                | W1 = val_12;//m1                        
        // 0x00B4367C: MOV x0, x21                | X0 = 1152921510260846336 (0x1000000151012F00);//ML01
        // 0x00B43680: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(CSHeroUnit[]), ????);
        // 0x00B43684: STR x0, [x19, #0x50]       | this.heroGroups = typeof(CSHeroUnit[]);  //  dest_result_addr=1152921514979299664
        this.heroGroups = val_18;
        // 0x00B43688: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B4368C: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B43690: BL #0x132a574              | X0 = val_10.get_Count();                
        int val_13 = val_10.Count;
        // 0x00B43694: CMP w0, #1                 | STATE = COMPARE(val_13, 0x1)            
        // 0x00B43698: B.LT #0xb43740             | if (val_13 < 1) goto label_14;          
        if(val_13 < 1)
        {
            goto label_14;
        }
        // 0x00B4369C: ADRP x24, #0x365b000       | X24 = 56995840 (0x365B000);             
        // 0x00B436A0: LDR x24, [x24, #0x4b8]     | X24 = 1152921504905195520;              
        // 0x00B436A4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        label_19:
        // 0x00B436A8: LDR x25, [x19, #0x50]      | X25 = this.heroGroups; //P2             
        // 0x00B436AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B436B0: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B436B4: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B436B8: BL #0x1327740              | X0 = val_10.get_Item(index:  0);        
        Newtonsoft.Json.Linq.JToken val_14 = val_10.Item[0];
        // 0x00B436BC: LDR x8, [x24]              | X8 = typeof(CSHeroUnit);                
        // 0x00B436C0: MOV x23, x0                | X23 = val_14;//m1                       
        // 0x00B436C4: MOV x0, x8                 | X0 = 1152921504905195520 (0x1000000011C87000);//ML01
        CSHeroUnit val_15 = null;
        // 0x00B436C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CSHeroUnit), ????);
        // 0x00B436CC: MOV x1, x23                | X1 = val_14;//m1                        
        // 0x00B436D0: MOV x22, x0                | X22 = 1152921504905195520 (0x1000000011C87000);//ML01
        // 0x00B436D4: BL #0xb43758               | .ctor(jToken:  val_14);                 
        val_15 = new CSHeroUnit(jToken:  val_14);
        // 0x00B436D8: CBNZ x25, #0xb436e0        | if (this.heroGroups != null) goto label_15;
        if(this.heroGroups != null)
        {
            goto label_15;
        }
        // 0x00B436DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(jToken:  val_14), ????);
        label_15:
        // 0x00B436E0: CBZ x22, #0xb43704         | if ( == 0) goto label_17;               
        if(null == 0)
        {
            goto label_17;
        }
        // 0x00B436E4: LDR x8, [x25]              | X8 = typeof(CSHeroUnit[]);              
        // 0x00B436E8: MOV x0, x22                | X0 = 1152921504905195520 (0x1000000011C87000);//ML01
        // 0x00B436EC: LDR x1, [x8, #0x30]        | X1 = CSHeroUnit[].__il2cppRuntimeField_element_class;
        // 0x00B436F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(CSHeroUnit), ????);
        // 0x00B436F4: CBNZ x0, #0xb43704         | if ( != 0) goto label_17;               
        if(null != 0)
        {
            goto label_17;
        }
        // 0x00B436F8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(CSHeroUnit), ????);
        // 0x00B436FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B43700: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(CSHeroUnit), ????);
        label_17:
        // 0x00B43704: LDR w8, [x25, #0x18]       | W8 = this.heroGroups.Length; //P2       
        // 0x00B43708: SXTW x23, w21              | X23 = 0 (0x00000000);                   
        val_17 = 0;
        // 0x00B4370C: CMP w21, w8                | STATE = COMPARE(0x0, this.heroGroups.Length)
        // 0x00B43710: B.LO #0xb43720             | if (0 < this.heroGroups.Length) goto label_18;
        if(0 < this.heroGroups.Length)
        {
            goto label_18;
        }
        // 0x00B43714: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(CSHeroUnit), ????);
        // 0x00B43718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B4371C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(CSHeroUnit), ????);
        label_18:
        // 0x00B43720: ADD x8, x25, x23, lsl #3   | X8 = this.heroGroups[0x0]; //PARR1      
        // 0x00B43724: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B43728: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B4372C: STR x22, [x8, #0x20]       | this.heroGroups[0x0][0] = typeof(CSHeroUnit);  //  dest_result_addr=0
        this.heroGroups[val_17] = val_15;
        // 0x00B43730: ADD w21, w21, #1           | W21 = (0 + 1);                          
        val_18 = 0 + 1;
        // 0x00B43734: BL #0x132a574              | X0 = val_10.get_Count();                
        int val_16 = val_10.Count;
        // 0x00B43738: CMP w21, w0                | STATE = COMPARE((0 + 1), val_16)        
        // 0x00B4373C: B.LT #0xb436a8             | if (val_18 < val_16) goto label_19;     
        if(val_18 < val_16)
        {
            goto label_19;
        }
        label_14:
        // 0x00B43740: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B43744: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B43748: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B4374C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B43750: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B43754: RET                        |  return;                                
        return;
    
    }

}
