using UnityEngine;
public class Buff : IObject
{
    // Fields
    public float endTime; //  0x00000010
    public int id; //  0x00000014
    public bool handleEff; //  0x00000018
    public bool isFrist; //  0x00000019
    public buffCfg buffDB; //  0x00000020
    public string[] effectNumText; //  0x00000028
    public int[] effectNumPath; //  0x00000030
    public bool isAwaken; //  0x00000038
    public int awakenLv; //  0x0000003C
    public float awakenEndtime; //  0x00000040
    public int awakenAddValue01; //  0x00000044
    public int awakenAddValue02; //  0x00000048
    public int awakenAddValue03; //  0x0000004C
    public int awakenAddValue04; //  0x00000050
    public CombatEntity src; //  0x00000058
    
    // Properties
    public float srcAtkPower { get; }
    public float srcCureP { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B96E60 (12152416), len: 16  VirtAddr: 0x00B96E60 RVA: 0x00B96E60 token: 100692053 methodIndex: 25263 delegateWrapperIndex: 0 methodInvoker: 0
    public Buff()
    {
        //
        // Disasemble & Code
        // 0x00B96E60: MOVZ w8, #0x101            | W8 = 257 (0x101);//ML01                 
        // 0x00B96E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96E68: STRH w8, [x0, #0x18]       | this.handleEff = true; this.isFrist = true;  //  dest_result_addr=1152921514760734632 dest_result_addr=1152921514760734633
        this.handleEff = true;
        this.isFrist = true;
        // 0x00B96E6C: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96E70 (12152432), len: 160  VirtAddr: 0x00B96E70 RVA: 0x00B96E70 token: 100692054 methodIndex: 25264 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_srcAtkPower()
    {
        //
        // Disasemble & Code
        // 0x00B96E70: STP x20, x19, [sp, #-0x20]! | stack[1152921514760842768] = ???;  stack[1152921514760842776] = ???;  //  dest_result_addr=1152921514760842768 |  dest_result_addr=1152921514760842776
        // 0x00B96E74: STP x29, x30, [sp, #0x10]  | stack[1152921514760842784] = ???;  stack[1152921514760842792] = ???;  //  dest_result_addr=1152921514760842784 |  dest_result_addr=1152921514760842792
        // 0x00B96E78: ADD x29, sp, #0x10         | X29 = (1152921514760842768 + 16) = 1152921514760842784 (0x100000025D39AE20);
        // 0x00B96E7C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B96E80: LDRB w8, [x20, #0xa79]     | W8 = (bool)static_value_03733A79;       
        // 0x00B96E84: MOV x19, x0                | X19 = 1152921514760854800 (0x100000025D39DD10);//ML01
        // 0x00B96E88: TBNZ w8, #0, #0xb96ea4     | if (static_value_03733A79 == true) goto label_0;
        // 0x00B96E8C: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
        // 0x00B96E90: LDR x8, [x8, #0xbe8]       | X8 = 0x2B8FA54;                         
        // 0x00B96E94: LDR w0, [x8]               | W0 = 0x1559;                            
        // 0x00B96E98: BL #0x2782188              | X0 = sub_2782188( ?? 0x1559, ????);     
        // 0x00B96E9C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B96EA0: STRB w8, [x20, #0xa79]     | static_value_03733A79 = true;            //  dest_result_addr=57883257
        label_0:
        // 0x00B96EA4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B96EA8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B96EAC: LDR x20, [x19, #0x58]      | X20 = this.src; //P2                    
        // 0x00B96EB0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B96EB4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B96EB8: TBZ w8, #0, #0xb96ec8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B96EBC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B96EC0: CBNZ w8, #0xb96ec8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B96EC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B96EC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B96ECC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96ED0: MOV x1, x20                | X1 = this.src;//m1                      
        // 0x00B96ED4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B96ED8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.src);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.src);
        // 0x00B96EDC: TBZ w0, #0, #0xb96f00      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B96EE0: LDR x19, [x19, #0x58]      | X19 = this.src; //P2                    
        // 0x00B96EE4: CBNZ x19, #0xb96eec        | if (this.src != null) goto label_4;     
        if(this.src != null)
        {
            goto label_4;
        }
        // 0x00B96EE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B96EEC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96EF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96EF4: MOV x0, x19                | X0 = this.src;//m1                      
        // 0x00B96EF8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B96EFC: B #0xd98858                | return this.src.get_atkPower();         
        return this.src.atkPower;
        label_3:
        // 0x00B96F00: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96F04: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B96F08: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B96F0C: RET                        |  return (System.Single)0;               
        return (float)0f;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96F10 (12152592), len: 160  VirtAddr: 0x00B96F10 RVA: 0x00B96F10 token: 100692055 methodIndex: 25265 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_srcCureP()
    {
        //
        // Disasemble & Code
        // 0x00B96F10: STP x20, x19, [sp, #-0x20]! | stack[1152921514760971152] = ???;  stack[1152921514760971160] = ???;  //  dest_result_addr=1152921514760971152 |  dest_result_addr=1152921514760971160
        // 0x00B96F14: STP x29, x30, [sp, #0x10]  | stack[1152921514760971168] = ???;  stack[1152921514760971176] = ???;  //  dest_result_addr=1152921514760971168 |  dest_result_addr=1152921514760971176
        // 0x00B96F18: ADD x29, sp, #0x10         | X29 = (1152921514760971152 + 16) = 1152921514760971168 (0x100000025D3BA3A0);
        // 0x00B96F1C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B96F20: LDRB w8, [x20, #0xa7a]     | W8 = (bool)static_value_03733A7A;       
        // 0x00B96F24: MOV x19, x0                | X19 = 1152921514760983184 (0x100000025D3BD290);//ML01
        // 0x00B96F28: TBNZ w8, #0, #0xb96f44     | if (static_value_03733A7A == true) goto label_0;
        // 0x00B96F2C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B96F30: LDR x8, [x8, #0x6b0]       | X8 = 0x2B8FA58;                         
        // 0x00B96F34: LDR w0, [x8]               | W0 = 0x155A;                            
        // 0x00B96F38: BL #0x2782188              | X0 = sub_2782188( ?? 0x155A, ????);     
        // 0x00B96F3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B96F40: STRB w8, [x20, #0xa7a]     | static_value_03733A7A = true;            //  dest_result_addr=57883258
        label_0:
        // 0x00B96F44: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B96F48: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B96F4C: LDR x20, [x19, #0x58]      | X20 = this.src; //P2                    
        // 0x00B96F50: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B96F54: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B96F58: TBZ w8, #0, #0xb96f68      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B96F5C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B96F60: CBNZ w8, #0xb96f68         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B96F64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B96F68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B96F6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96F70: MOV x1, x20                | X1 = this.src;//m1                      
        // 0x00B96F74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B96F78: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.src);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.src);
        // 0x00B96F7C: TBZ w0, #0, #0xb96fa0      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B96F80: LDR x19, [x19, #0x58]      | X19 = this.src; //P2                    
        // 0x00B96F84: CBNZ x19, #0xb96f8c        | if (this.src != null) goto label_4;     
        if(this.src != null)
        {
            goto label_4;
        }
        // 0x00B96F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B96F8C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96F90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96F94: MOV x0, x19                | X0 = this.src;//m1                      
        // 0x00B96F98: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B96F9C: B #0xd9a294                | return this.src.get_cureP();            
        return this.src.cureP;
        label_3:
        // 0x00B96FA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96FA4: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B96FA8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B96FAC: RET                        |  return (System.Single)0;               
        return (float)0f;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96FB0 (12152752), len: 968  VirtAddr: 0x00B96FB0 RVA: 0x00B96FB0 token: 100692056 methodIndex: 25266 delegateWrapperIndex: 0 methodInvoker: 0
    public void Setup(buffCfg buffDB, int awakenLv, float timeBonus = 0, float timeBonusPer = 0)
    {
        //
        // Disasemble & Code
        //  | 
        var val_9;
        //  | 
        System.String[] val_10;
        //  | 
        System.Int32[] val_11;
        //  | 
        var val_12;
        // 0x00B96FB0: STP d11, d10, [sp, #-0x60]! | stack[1152921514761415008] = ???;  stack[1152921514761415016] = ???;  //  dest_result_addr=1152921514761415008 |  dest_result_addr=1152921514761415016
        // 0x00B96FB4: STP d9, d8, [sp, #0x10]    | stack[1152921514761415024] = ???;  stack[1152921514761415032] = ???;  //  dest_result_addr=1152921514761415024 |  dest_result_addr=1152921514761415032
        // 0x00B96FB8: STP x24, x23, [sp, #0x20]  | stack[1152921514761415040] = ???;  stack[1152921514761415048] = ???;  //  dest_result_addr=1152921514761415040 |  dest_result_addr=1152921514761415048
        // 0x00B96FBC: STP x22, x21, [sp, #0x30]  | stack[1152921514761415056] = ???;  stack[1152921514761415064] = ???;  //  dest_result_addr=1152921514761415056 |  dest_result_addr=1152921514761415064
        // 0x00B96FC0: STP x20, x19, [sp, #0x40]  | stack[1152921514761415072] = ???;  stack[1152921514761415080] = ???;  //  dest_result_addr=1152921514761415072 |  dest_result_addr=1152921514761415080
        // 0x00B96FC4: STP x29, x30, [sp, #0x50]  | stack[1152921514761415088] = ???;  stack[1152921514761415096] = ???;  //  dest_result_addr=1152921514761415088 |  dest_result_addr=1152921514761415096
        // 0x00B96FC8: ADD x29, sp, #0x50         | X29 = (1152921514761415008 + 80) = 1152921514761415088 (0x100000025D4269B0);
        // 0x00B96FCC: SUB sp, sp, #0x10          | SP = (1152921514761415008 - 16) = 1152921514761414992 (0x100000025D426950);
        // 0x00B96FD0: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B96FD4: LDRB w8, [x22, #0xa7b]     | W8 = (bool)static_value_03733A7B;       
        // 0x00B96FD8: MOV v9.16b, v1.16b         | V9 = timeBonusPer;//m1                  
        // 0x00B96FDC: MOV v8.16b, v0.16b         | V8 = timeBonus;//m1                     
        // 0x00B96FE0: MOV w21, w2                | W21 = awakenLv;//m1                     
        // 0x00B96FE4: MOV x20, x1                | X20 = buffDB;//m1                       
        // 0x00B96FE8: MOV x19, x0                | X19 = 1152921514761427104 (0x100000025D4298A0);//ML01
        // 0x00B96FEC: TBNZ w8, #0, #0xb97008     | if (static_value_03733A7B == true) goto label_0;
        // 0x00B96FF0: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00B96FF4: LDR x8, [x8, #0x188]       | X8 = 0x2B8FA5C;                         
        // 0x00B96FF8: LDR w0, [x8]               | W0 = 0x155B;                            
        // 0x00B96FFC: BL #0x2782188              | X0 = sub_2782188( ?? 0x155B, ????);     
        // 0x00B97000: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B97004: STRB w8, [x22, #0xa7b]     | static_value_03733A7B = true;            //  dest_result_addr=57883259
        label_0:
        // 0x00B97008: CBZ x20, #0xb97020         | if (buffDB == null) goto label_1;       
        if(buffDB == null)
        {
            goto label_1;
        }
        // 0x00B9700C: LDR w8, [x20, #0x10]       | W8 = buffDB.id; //P2                    
        // 0x00B97010: MOV x23, x19               | X23 = 1152921514761427104 (0x100000025D4298A0);//ML01
        val_9 = this;
        // 0x00B97014: STR w8, [x23, #0x14]!      | this.id = buffDB.id;                     //  dest_result_addr=1152921514761427124
        this.id = buffDB.id;
        // 0x00B97018: STUR x20, [x23, #0xc]      | mem[1152921514761427136] = buffDB;       //  dest_result_addr=1152921514761427136
        mem[1152921514761427136] = buffDB;
        // 0x00B9701C: B #0xb9703c                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00B97020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x155B, ????);     
        // 0x00B97024: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
        // 0x00B97028: LDR w8, [x8]               | W8 = 0xB70003;                          
        // 0x00B9702C: MOV x23, x19               | X23 = 1152921514761427104 (0x100000025D4298A0);//ML01
        val_9 = this;
        // 0x00B97030: STR w8, [x23, #0x14]!      | this.id = 11993091;                      //  dest_result_addr=1152921514761427124
        this.id = 11993091;
        // 0x00B97034: STUR xzr, [x23, #0xc]      | mem[1152921514761427136] = 0x0;          //  dest_result_addr=1152921514761427136
        mem[1152921514761427136] = 0;
        // 0x00B97038: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x155B, ????);     
        label_2:
        // 0x00B9703C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B97040: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B97044: LDR x22, [x20, #0x90]      | X22 = buffDB.heaven_awaken; //P2        
        // 0x00B97048: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B9704C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B97050: TBZ w8, #0, #0xb97060      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B97054: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B97058: CBNZ w8, #0xb97060         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B9705C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_4:
        // 0x00B97060: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97064: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97068: MOV x1, x22                | X1 = buffDB.heaven_awaken;//m1          
        // 0x00B9706C: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_1 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B97070: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B97074: TBNZ w8, #0, #0xb97190     | if ((val_1 & 1) == true) goto label_11; 
        if(val_2 == true)
        {
            goto label_11;
        }
        // 0x00B97078: CBNZ x20, #0xb97080        | if (buffDB != null) goto label_6;       
        if(buffDB != null)
        {
            goto label_6;
        }
        // 0x00B9707C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00B97080: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B97084: LDR x8, [x8, #0xa90]       | X8 = 1152921504911745024;               
        // 0x00B97088: LDR x22, [x20, #0x90]      | X22 = buffDB.heaven_awaken; //P2        
        // 0x00B9708C: LDR x0, [x8]               | X0 = typeof(Util);                      
        // 0x00B97090: LDRB w8, [x0, #0x10a]      | W8 = Util.__il2cppRuntimeField_10A;     
        // 0x00B97094: TBZ w8, #0, #0xb970a4      | if (Util.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B97098: LDR w8, [x0, #0xbc]        | W8 = Util.__il2cppRuntimeField_cctor_finished;
        // 0x00B9709C: CBNZ w8, #0xb970a4         | if (Util.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B970A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Util), ????);
        label_8:
        // 0x00B970A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B970A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B970AC: MOV x1, x22                | X1 = buffDB.heaven_awaken;//m1          
        // 0x00B970B0: BL #0xe16570               | X0 = Util.GetArticle_Int(str:  0);      
        System.Int32[] val_3 = Util.GetArticle_Int(str:  0);
        // 0x00B970B4: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00B970B8: CBNZ x22, #0xb970c0        | if (val_3 != null) goto label_9;        
        if(val_3 != null)
        {
            goto label_9;
        }
        // 0x00B970BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00B970C0: LDR w8, [x22, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00B970C4: CMP w8, #6                 | STATE = COMPARE(val_3.Length, 0x6)      
        // 0x00B970C8: B.NE #0xb97190             | if (val_3.Length != 6) goto label_11;   
        if(val_3.Length != 6)
        {
            goto label_11;
        }
        // 0x00B970CC: LDR w8, [x22, #0x34]       | W8 = val_3[5]                           
        int val_9 = val_3[5];
        // 0x00B970D0: STR w8, [x19, #0x3c]       | this.awakenLv = val_3[5];                //  dest_result_addr=1152921514761427164
        this.awakenLv = val_9;
        // 0x00B970D4: CMP w8, w21                | STATE = COMPARE(val_3[5], awakenLv)     
        // 0x00B970D8: B.GT #0xb97190             | if (val_3[5] > awakenLv) goto label_11; 
        if(val_9 > awakenLv)
        {
            goto label_11;
        }
        // 0x00B970DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B970E0: STRB w8, [x19, #0x38]      | this.isAwaken = true;                    //  dest_result_addr=1152921514761427160
        this.isAwaken = true;
        // 0x00B970E4: LDR w8, [x22, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00B970E8: CBNZ w8, #0xb970f8         | if (val_3.Length != 0) goto label_12;   
        if(val_3.Length != 0)
        {
            goto label_12;
        }
        // 0x00B970EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B970F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B970F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_12:
        // 0x00B970F8: LDR s0, [x22, #0x20]       | S0 = val_3[0]                           
        int val_10 = val_3[0];
        // 0x00B970FC: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B97100: LDR s1, [x8, #0x770]       | S1 = 0.01;                              
        // 0x00B97104: SCVTF s0, s0               | S0 = (float)(val_3[0]);                 
        float val_11 = (float)val_10;
        // 0x00B97108: FMUL s0, s0, s1            | S0 = (val_3[0] * 0.01f);                
        val_11 = val_11 * 0.01f;
        // 0x00B9710C: STR s0, [x19, #0x40]       | this.awakenEndtime = (val_3[0] * 0.01f);  //  dest_result_addr=1152921514761427168
        this.awakenEndtime = val_11;
        // 0x00B97110: LDR w8, [x22, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00B97114: CMP w8, #1                 | STATE = COMPARE(val_3.Length, 0x1)      
        // 0x00B97118: B.HI #0xb97128             | if (val_3.Length > 1) goto label_13;    
        if(val_3.Length > 1)
        {
            goto label_13;
        }
        // 0x00B9711C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B97120: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B97124: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_13:
        // 0x00B97128: LDR w8, [x22, #0x24]       | W8 = val_3[1]                           
        int val_12 = val_3[1];
        // 0x00B9712C: STR w8, [x19, #0x44]       | this.awakenAddValue01 = val_3[1];        //  dest_result_addr=1152921514761427172
        this.awakenAddValue01 = val_12;
        // 0x00B97130: LDR w8, [x22, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00B97134: CMP w8, #2                 | STATE = COMPARE(val_3.Length, 0x2)      
        // 0x00B97138: B.HI #0xb97148             | if (val_3.Length > 2) goto label_14;    
        if(val_3.Length > 2)
        {
            goto label_14;
        }
        // 0x00B9713C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B97140: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B97144: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_14:
        // 0x00B97148: LDR w8, [x22, #0x28]       | W8 = val_3[2]                           
        int val_13 = val_3[2];
        // 0x00B9714C: STR w8, [x19, #0x48]       | this.awakenAddValue02 = val_3[2];        //  dest_result_addr=1152921514761427176
        this.awakenAddValue02 = val_13;
        // 0x00B97150: LDR w8, [x22, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00B97154: CMP w8, #3                 | STATE = COMPARE(val_3.Length, 0x3)      
        // 0x00B97158: B.HI #0xb97168             | if (val_3.Length > 3) goto label_15;    
        if(val_3.Length > 3)
        {
            goto label_15;
        }
        // 0x00B9715C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B97160: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B97164: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_15:
        // 0x00B97168: LDR w8, [x22, #0x2c]       | W8 = val_3[3]                           
        int val_14 = val_3[3];
        // 0x00B9716C: STR w8, [x19, #0x4c]       | this.awakenAddValue03 = val_3[3];        //  dest_result_addr=1152921514761427180
        this.awakenAddValue03 = val_14;
        // 0x00B97170: LDR w8, [x22, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00B97174: CMP w8, #4                 | STATE = COMPARE(val_3.Length, 0x4)      
        // 0x00B97178: B.HI #0xb97188             | if (val_3.Length > 4) goto label_16;    
        if(val_3.Length > 4)
        {
            goto label_16;
        }
        // 0x00B9717C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B97180: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B97184: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_16:
        // 0x00B97188: LDR w8, [x22, #0x30]       | W8 = val_3[4]                           
        int val_15 = val_3[4];
        // 0x00B9718C: STR w8, [x19, #0x50]       | this.awakenAddValue04 = val_3[4];        //  dest_result_addr=1152921514761427184
        this.awakenAddValue04 = val_15;
        label_11:
        // 0x00B97190: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97194: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B97198: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_4 = UnityEngine.Time.time;
        // 0x00B9719C: MOV v10.16b, v0.16b        | V10 = val_4;//m1                        
        // 0x00B971A0: CBNZ x20, #0xb971a8        | if (buffDB != null) goto label_17;      
        if(buffDB != null)
        {
            goto label_17;
        }
        // 0x00B971A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_17:
        // 0x00B971A8: LDR s0, [x20, #0x14]       | S0 = buffDB.lasttime; //P2              
        float val_17 = buffDB.lasttime;
        // 0x00B971AC: FMOV s2, #1.00000000       | S2 = 1;                                 
        float val_16 = 1f;
        // 0x00B971B0: LDR s1, [x19, #0x40]       | S1 = this.awakenEndtime; //P2           
        // 0x00B971B4: FADD s2, s9, s2            | S2 = (timeBonusPer + 1f);               
        val_16 = timeBonusPer + val_16;
        // 0x00B971B8: FMUL s0, s2, s0            | S0 = ((timeBonusPer + 1f) * buffDB.lasttime);
        val_17 = val_16 * val_17;
        // 0x00B971BC: FADD s0, s10, s0           | S0 = (val_4 + ((timeBonusPer + 1f) * buffDB.lasttime));
        val_17 = val_4 + val_17;
        // 0x00B971C0: FADD s0, s0, s8            | S0 = ((val_4 + ((timeBonusPer + 1f) * buffDB.lasttime)) + timeBonus);
        val_17 = val_17 + timeBonus;
        // 0x00B971C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B971C8: FADD s0, s1, s0            | S0 = (this.awakenEndtime + ((val_4 + ((timeBonusPer + 1f) * buffDB.lasttime)) + timeBonus));
        val_17 = this.awakenEndtime + val_17;
        // 0x00B971CC: STR s0, [x19, #0x10]       | this.endTime = (this.awakenEndtime + ((val_4 + ((timeBonusPer + 1f) * buffDB.lasttime)) + timeBonus));  //  dest_result_addr=1152921514761427120
        this.endTime = val_17;
        // 0x00B971D0: STRB w8, [x19, #0x19]      | this.isFrist = true;                     //  dest_result_addr=1152921514761427129
        this.isFrist = true;
        // 0x00B971D4: CBNZ x20, #0xb971dc        | if (buffDB != null) goto label_18;      
        if(buffDB != null)
        {
            goto label_18;
        }
        // 0x00B971D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_18:
        // 0x00B971DC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B971E0: LDR x8, [x8, #0xa90]       | X8 = 1152921504911745024;               
        // 0x00B971E4: LDR x21, [x20, #0x80]      | X21 = buffDB.effect_text; //P2          
        // 0x00B971E8: LDR x0, [x8]               | X0 = typeof(Util);                      
        // 0x00B971EC: LDRB w8, [x0, #0x10a]      | W8 = Util.__il2cppRuntimeField_10A;     
        // 0x00B971F0: TBZ w8, #0, #0xb97200      | if (Util.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B971F4: LDR w8, [x0, #0xbc]        | W8 = Util.__il2cppRuntimeField_cctor_finished;
        // 0x00B971F8: CBNZ w8, #0xb97200         | if (Util.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B971FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Util), ????);
        label_20:
        // 0x00B97200: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97204: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97208: MOV x1, x21                | X1 = buffDB.effect_text;//m1            
        // 0x00B9720C: BL #0xe164a4               | X0 = Util.SplitStr_commn(str:  0);      
        System.String[] val_5 = Util.SplitStr_commn(str:  0);
        // 0x00B97210: STR x0, [x19, #0x28]       | this.effectNumText = val_5;              //  dest_result_addr=1152921514761427144
        this.effectNumText = val_5;
        // 0x00B97214: LDR x1, [x20, #0x88]       | X1 = buffDB.path_text; //P2             
        // 0x00B97218: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9721C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97220: BL #0xe16570               | X0 = Util.GetArticle_Int(str:  0);      
        System.Int32[] val_6 = Util.GetArticle_Int(str:  0);
        // 0x00B97224: LDR x21, [x19, #0x28]      | X21 = this.effectNumText; //P2          
        val_10 = this.effectNumText;
        // 0x00B97228: MOV x20, x0                | X20 = val_6;//m1                        
        val_11 = val_6;
        // 0x00B9722C: STR x20, [x19, #0x30]      | this.effectNumPath = val_6;              //  dest_result_addr=1152921514761427152
        this.effectNumPath = val_11;
        // 0x00B97230: CBNZ x21, #0xb9723c        | if (this.effectNumText != null) goto label_21;
        if(val_10 != null)
        {
            goto label_21;
        }
        // 0x00B97234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        // 0x00B97238: LDR x20, [x19, #0x30]      | X20 = this.effectNumPath; //P2          
        val_11 = this.effectNumPath;
        label_21:
        // 0x00B9723C: CBNZ x20, #0xb97244        | if (this.effectNumPath != null) goto label_22;
        if(val_11 != null)
        {
            goto label_22;
        }
        // 0x00B97240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_22:
        // 0x00B97244: LDR w8, [x21, #0x18]       | W8 = this.effectNumText.Length; //P2    
        // 0x00B97248: LDR w9, [x20, #0x18]       | W9 = this.effectNumPath.Length; //P2    
        // 0x00B9724C: CMP w8, w9                 | STATE = COMPARE(this.effectNumText.Length, this.effectNumPath.Length)
        // 0x00B97250: B.EQ #0xb97358             | if (this.effectNumText.Length == this.effectNumPath.Length) goto label_29;
        if(this.effectNumText.Length == this.effectNumPath.Length)
        {
            goto label_29;
        }
        // 0x00B97254: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00B97258: LDR w8, [x23]              | W8 = 11993091;                          
        // 0x00B9725C: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00B97260: ADD x1, sp, #0xc           | X1 = (1152921514761414992 + 12) = 1152921514761415004 (0x100000025D42695C);
        // 0x00B97264: STR w8, [sp, #0xc]         | stack[1152921514761415004] = 11993091;   //  dest_result_addr=1152921514761415004
        // 0x00B97268: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00B9726C: BL #0x27bc028              | X0 = 1152921514761663904 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 11993091);
        // 0x00B97270: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
        // 0x00B97274: LDR x8, [x8, #0xd20]       | X8 = (string**)(1152921514761288272)("buff id {0}的effect_text和path_text不一致");
        // 0x00B97278: MOV x2, x0                 | X2 = 1152921514761663904 (0x100000025D4635A0);//ML01
        // 0x00B9727C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97280: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B97284: LDR x1, [x8]               | X1 = "buff id {0}的effect_text和path_text不一致";
        // 0x00B97288: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "buff id {0}的effect_text和path_text不一致");
        string val_7 = EString.EFormat(format:  0, arg0:  "buff id {0}的effect_text和path_text不一致");
        // 0x00B9728C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B97290: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B97294: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B97298: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B9729C: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B972A0: TBZ w9, #0, #0xb972b4      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x00B972A4: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B972A8: CBNZ w9, #0xb972b4         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x00B972AC: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B972B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_25:
        // 0x00B972B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B972B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B972BC: MOV x1, x20                | X1 = val_7;//m1                         
        // 0x00B972C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B972C4: ORR w22, wzr, #1           | W22 = 1(0x1);                           
        // 0x00B972C8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_7);
        EDebug.Log(message:  0, isShowStack:  val_7);
        // 0x00B972CC: LDR x21, [x19, #0x28]      | X21 = this.effectNumText; //P2          
        // 0x00B972D0: CBNZ x21, #0xb972d8        | if (this.effectNumText != null) goto label_26;
        if(this.effectNumText != null)
        {
            goto label_26;
        }
        // 0x00B972D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_26:
        // 0x00B972D8: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00B972DC: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
        // 0x00B972E0: LDR w21, [x21, #0x18]      | W21 = this.effectNumText.Length; //P2   
        // 0x00B972E4: LDR x20, [x8]              | X20 = typeof(System.Int32[]);           
        // 0x00B972E8: MOV x0, x20                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
        // 0x00B972EC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Int32[]), ????);
        // 0x00B972F0: MOV x0, x20                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
        // 0x00B972F4: MOV x1, x21                | X1 = this.effectNumText.Length;//m1     
        // 0x00B972F8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Int32[]), ????);
        // 0x00B972FC: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_12 = 0;
        // 0x00B97300: STR x0, [x19, #0x30]       | this.effectNumPath = typeof(System.Int32[]);  //  dest_result_addr=1152921514761427152
        this.effectNumPath = null;
        // 0x00B97304: B #0xb97314                |  goto label_27;                         
        goto label_27;
        label_32:
        // 0x00B97308: ADD x8, x21, x23, lsl #2   | X8 = (this.effectNumText.Length + 4611686059045708496);
        int val_8 = this.effectNumText.Length + 4611686059045708496;
        // 0x00B9730C: ADD w20, w20, #1           | W20 = (val_12 + 1) = val_12 (0x00000001);
        val_12 = 1;
        // 0x00B97310: STR w22, [x8, #0x20]       | mem2[0] = 0x1;                           //  dest_result_addr=0
        mem2[0] = 1;
        label_27:
        // 0x00B97314: LDR x21, [x19, #0x28]      | X21 = this.effectNumText; //P2          
        val_10 = this.effectNumText;
        // 0x00B97318: CBNZ x21, #0xb97320        | if (this.effectNumText != null) goto label_28;
        if(val_10 != null)
        {
            goto label_28;
        }
        // 0x00B9731C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
        label_28:
        // 0x00B97320: LDR w8, [x21, #0x18]       | W8 = this.effectNumText.Length; //P2    
        // 0x00B97324: CMP w20, w8                | STATE = COMPARE(0x1, this.effectNumText.Length)
        // 0x00B97328: B.GE #0xb97358             | if (val_12 >= this.effectNumText.Length) goto label_29;
        if(val_12 >= this.effectNumText.Length)
        {
            goto label_29;
        }
        // 0x00B9732C: LDR x21, [x19, #0x30]      | X21 = this.effectNumPath; //P2          
        // 0x00B97330: CBNZ x21, #0xb97338        | if (this.effectNumPath != null) goto label_30;
        if(this.effectNumPath != null)
        {
            goto label_30;
        }
        // 0x00B97334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
        label_30:
        // 0x00B97338: LDR w8, [x21, #0x18]       | W8 = this.effectNumPath.Length; //P2    
        // 0x00B9733C: SXTW x23, w20              | X23 = 1 (0x00000001);                   
        // 0x00B97340: CMP w20, w8                | STATE = COMPARE(0x1, this.effectNumPath.Length)
        // 0x00B97344: B.LO #0xb97308             | if (val_12 < this.effectNumPath.Length) goto label_32;
        if(val_12 < this.effectNumPath.Length)
        {
            goto label_32;
        }
        // 0x00B97348: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Int32[]), ????);
        // 0x00B9734C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B97350: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Int32[]), ????);
        // 0x00B97354: B #0xb97308                |  goto label_32;                         
        goto label_32;
        label_29:
        // 0x00B97358: SUB sp, x29, #0x50         | SP = (1152921514761415088 - 80) = 1152921514761415008 (0x100000025D426960);
        // 0x00B9735C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B97360: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B97364: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B97368: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B9736C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B97370: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x00B97374: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B97378 (12153720), len: 144  VirtAddr: 0x00B97378 RVA: 0x00B97378 token: 100692057 methodIndex: 25267 delegateWrapperIndex: 0 methodInvoker: 0
    public bool HasFun(BuffEnum.EBuffFunType funType)
    {
        //
        // Disasemble & Code
        //  | 
        buffCfg val_2;
        // 0x00B97378: STP x22, x21, [sp, #-0x30]! | stack[1152921514761871120] = ???;  stack[1152921514761871128] = ???;  //  dest_result_addr=1152921514761871120 |  dest_result_addr=1152921514761871128
        // 0x00B9737C: STP x20, x19, [sp, #0x10]  | stack[1152921514761871136] = ???;  stack[1152921514761871144] = ???;  //  dest_result_addr=1152921514761871136 |  dest_result_addr=1152921514761871144
        // 0x00B97380: STP x29, x30, [sp, #0x20]  | stack[1152921514761871152] = ???;  stack[1152921514761871160] = ???;  //  dest_result_addr=1152921514761871152 |  dest_result_addr=1152921514761871160
        // 0x00B97384: ADD x29, sp, #0x20         | X29 = (1152921514761871120 + 32) = 1152921514761871152 (0x100000025D495F30);
        // 0x00B97388: MOV x20, x0                | X20 = 1152921514761883168 (0x100000025D498E20);//ML01
        // 0x00B9738C: LDR x21, [x20, #0x20]      | X21 = this.buffDB; //P2                 
        val_2 = this.buffDB;
        // 0x00B97390: MOV w19, w1                | W19 = funType;//m1                      
        // 0x00B97394: CBNZ x21, #0xb9739c        | if (this.buffDB != null) goto label_0;  
        if(val_2 != null)
        {
            goto label_0;
        }
        // 0x00B97398: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B9739C: LDR w8, [x21, #0x30]       | W8 = this.buffDB.fun1; //P2             
        // 0x00B973A0: CMP w8, w19                | STATE = COMPARE(this.buffDB.fun1, funType)
        // 0x00B973A4: B.EQ #0xb973d8             | if (this.buffDB.fun1 == funType) goto label_3;
        if(this.buffDB.fun1 == funType)
        {
            goto label_3;
        }
        // 0x00B973A8: LDR x21, [x20, #0x20]      | X21 = this.buffDB; //P2                 
        val_2 = this.buffDB;
        // 0x00B973AC: CBNZ x21, #0xb973b4        | if (this.buffDB != null) goto label_2;  
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00B973B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x00B973B4: LDR w8, [x21, #0x38]       | W8 = this.buffDB.fun2; //P2             
        // 0x00B973B8: CMP w8, w19                | STATE = COMPARE(this.buffDB.fun2, funType)
        // 0x00B973BC: B.EQ #0xb973d8             | if (this.buffDB.fun2 == funType) goto label_3;
        if(this.buffDB.fun2 == funType)
        {
            goto label_3;
        }
        // 0x00B973C0: LDR x21, [x20, #0x20]      | X21 = this.buffDB; //P2                 
        val_2 = this.buffDB;
        // 0x00B973C4: CBNZ x21, #0xb973cc        | if (this.buffDB != null) goto label_4;  
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B973C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_4:
        // 0x00B973CC: LDR w8, [x21, #0x40]       | W8 = this.buffDB.fun3; //P2             
        // 0x00B973D0: CMP w8, w19                | STATE = COMPARE(this.buffDB.fun3, funType)
        // 0x00B973D4: B.NE #0xb973ec             | if (this.buffDB.fun3 != funType) goto label_5;
        if(this.buffDB.fun3 != funType)
        {
            goto label_5;
        }
        label_3:
        // 0x00B973D8: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        label_7:
        // 0x00B973DC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B973E0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B973E4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B973E8: RET                        |  return (System.Boolean)true;           
        return (bool)1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        label_5:
        // 0x00B973EC: LDR x20, [x20, #0x20]      | X20 = this.buffDB; //P2                 
        // 0x00B973F0: CBNZ x20, #0xb973f8        | if (this.buffDB != null) goto label_6;  
        if(this.buffDB != null)
        {
            goto label_6;
        }
        // 0x00B973F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_6:
        // 0x00B973F8: LDR w8, [x20, #0x48]       | W8 = this.buffDB.fun4; //P2             
        // 0x00B973FC: CMP w8, w19                | STATE = COMPARE(this.buffDB.fun4, funType)
        // 0x00B97400: CSET w0, eq                | W0 = this.buffDB.fun4 == funType ? 1 : 0;
        var val_1 = (this.buffDB.fun4 == funType) ? 1 : 0;
        // 0x00B97404: B #0xb973dc                |  goto label_7;                          
        goto label_7;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B97408 (12153864), len: 40  VirtAddr: 0x00B97408 RVA: 0x00B97408 token: 100692058 methodIndex: 25268 delegateWrapperIndex: 0 methodInvoker: 0
    public void Reset()
    {
        //
        // Disasemble & Code
        // 0x00B97408: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B9740C: STRB wzr, [x0, #0x38]      | this.isAwaken = false;                   //  dest_result_addr=1152921514762015704
        this.isAwaken = false;
        // 0x00B97410: STUR xzr, [x0, #0x4c]      | this.awakenAddValue03 = 0; this.awakenAddValue04 = 0;  //  dest_result_addr=1152921514762015724 dest_result_addr=1152921514762015728
        this.awakenAddValue03 = 0;
        this.awakenAddValue04 = 0;
        // 0x00B97414: STUR xzr, [x0, #0x44]      | this.awakenAddValue01 = 0; this.awakenAddValue02 = 0;  //  dest_result_addr=1152921514762015716 dest_result_addr=1152921514762015720
        this.awakenAddValue01 = 0;
        this.awakenAddValue02 = 0;
        // 0x00B97418: STUR xzr, [x0, #0x3c]      | this.awakenLv = 0; this.awakenEndtime = 0;  //  dest_result_addr=1152921514762015708 dest_result_addr=1152921514762015712
        this.awakenLv = 0;
        this.awakenEndtime = 0f;
        // 0x00B9741C: STR xzr, [x0, #0x58]       | this.src = null;                         //  dest_result_addr=1152921514762015736
        this.src = 0;
        // 0x00B97420: STP xzr, xzr, [x0, #0x28]  | this.effectNumText = null;  this.effectNumPath = null;  //  dest_result_addr=1152921514762015688 |  dest_result_addr=1152921514762015696
        this.effectNumText = 0;
        this.effectNumPath = 0;
        // 0x00B97424: STRB w8, [x0, #0x18]       | this.handleEff = true;                   //  dest_result_addr=1152921514762015672
        this.handleEff = true;
        // 0x00B97428: STR xzr, [x0, #0x20]       | this.buffDB = null;                      //  dest_result_addr=1152921514762015680
        this.buffDB = 0;
        // 0x00B9742C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B97430 (12153904), len: 28  VirtAddr: 0x00B97430 RVA: 0x00B97430 token: 100692059 methodIndex: 25269 delegateWrapperIndex: 0 methodInvoker: 0
    public void Cleanup()
    {
        //
        // Disasemble & Code
        // 0x00B97430: STR xzr, [x0, #0x58]       | this.src = null;                         //  dest_result_addr=1152921514762127736
        this.src = 0;
        // 0x00B97434: STRB wzr, [x0, #0x38]      | this.isAwaken = false;                   //  dest_result_addr=1152921514762127704
        this.isAwaken = false;
        // 0x00B97438: STP xzr, xzr, [x0, #0x28]  | this.effectNumText = null;  this.effectNumPath = null;  //  dest_result_addr=1152921514762127688 |  dest_result_addr=1152921514762127696
        this.effectNumText = 0;
        this.effectNumPath = 0;
        // 0x00B9743C: STR xzr, [x0, #0x20]       | this.buffDB = null;                      //  dest_result_addr=1152921514762127680
        this.buffDB = 0;
        // 0x00B97440: STUR xzr, [x0, #0x4c]      | this.awakenAddValue03 = 0; this.awakenAddValue04 = 0;  //  dest_result_addr=1152921514762127724 dest_result_addr=1152921514762127728
        this.awakenAddValue03 = 0;
        this.awakenAddValue04 = 0;
        // 0x00B97444: STUR xzr, [x0, #0x44]      | this.awakenAddValue01 = 0; this.awakenAddValue02 = 0;  //  dest_result_addr=1152921514762127716 dest_result_addr=1152921514762127720
        this.awakenAddValue01 = 0;
        this.awakenAddValue02 = 0;
        // 0x00B97448: RET                        |  return;                                
        return;
    
    }

}
