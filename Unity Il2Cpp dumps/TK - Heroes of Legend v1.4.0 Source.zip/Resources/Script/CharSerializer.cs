using UnityEngine;

namespace ProtoBuf.Serializers
{
    internal sealed class CharSerializer : UInt16Serializer
    {
        // Fields
        private static readonly System.Type expectedType; // static_offset: 0x00000000
        
        // Properties
        public override System.Type ExpectedType { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x02983828 (43530280), len: 120  VirtAddr: 0x02983828 RVA: 0x02983828 token: 100689821 methodIndex: 54020 delegateWrapperIndex: 0 methodInvoker: 0
        public CharSerializer(ProtoBuf.Meta.TypeModel model)
        {
            //
            // Disasemble & Code
            // 0x02983828: STP x22, x21, [sp, #-0x30]! | stack[1152921514436038000] = ???;  stack[1152921514436038008] = ???;  //  dest_result_addr=1152921514436038000 |  dest_result_addr=1152921514436038008
            // 0x0298382C: STP x20, x19, [sp, #0x10]  | stack[1152921514436038016] = ???;  stack[1152921514436038024] = ???;  //  dest_result_addr=1152921514436038016 |  dest_result_addr=1152921514436038024
            // 0x02983830: STP x29, x30, [sp, #0x20]  | stack[1152921514436038032] = ???;  stack[1152921514436038040] = ???;  //  dest_result_addr=1152921514436038032 |  dest_result_addr=1152921514436038040
            // 0x02983834: ADD x29, sp, #0x20         | X29 = (1152921514436038000 + 32) = 1152921514436038032 (0x1000000249DD8D90);
            // 0x02983838: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x0298383C: LDRB w8, [x21, #0xf1f]     | W8 = (bool)static_value_037B8F1F;       
            // 0x02983840: MOV x19, x1                | X19 = model;//m1                        
            // 0x02983844: MOV x20, x0                | X20 = 1152921514436050048 (0x1000000249DDBC80);//ML01
            // 0x02983848: TBNZ w8, #0, #0x2983864    | if (static_value_037B8F1F == true) goto label_0;
            // 0x0298384C: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x02983850: LDR x8, [x8, #0xfd8]       | X8 = 0x2B9065C;                         
            // 0x02983854: LDR w0, [x8]               | W0 = 0x185B;                            
            // 0x02983858: BL #0x2782188              | X0 = sub_2782188( ?? 0x185B, ????);     
            // 0x0298385C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02983860: STRB w8, [x21, #0xf1f]     | static_value_037B8F1F = true;            //  dest_result_addr=58429215
            label_0:
            // 0x02983864: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x02983868: LDR x8, [x8, #0x7a8]       | X8 = 1152921504886718464;               
            // 0x0298386C: LDR x0, [x8]               | X0 = typeof(ProtoBuf.Serializers.UInt16Serializer);
            // 0x02983870: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Serializers.UInt16Serializer.__il2cppRuntimeField_10A;
            // 0x02983874: TBZ w8, #0, #0x2983884     | if (ProtoBuf.Serializers.UInt16Serializer.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x02983878: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Serializers.UInt16Serializer.__il2cppRuntimeField_cctor_finished;
            // 0x0298387C: CBNZ w8, #0x2983884        | if (ProtoBuf.Serializers.UInt16Serializer.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x02983880: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Serializers.UInt16Serializer), ????);
            label_2:
            // 0x02983884: MOV x0, x20                | X0 = 1152921514436050048 (0x1000000249DDBC80);//ML01
            // 0x02983888: MOV x1, x19                | X1 = model;//m1                         
            // 0x0298388C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02983890: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02983894: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02983898: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0298389C: B #0xc8d43c                | this..ctor(model:  model); return;      
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0298BAD8 (43563736), len: 104  VirtAddr: 0x0298BAD8 RVA: 0x0298BAD8 token: 100689822 methodIndex: 54021 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type get_ExpectedType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0298BAD8: STP x20, x19, [sp, #-0x20]! | stack[1152921514436154112] = ???;  stack[1152921514436154120] = ???;  //  dest_result_addr=1152921514436154112 |  dest_result_addr=1152921514436154120
            // 0x0298BADC: STP x29, x30, [sp, #0x10]  | stack[1152921514436154128] = ???;  stack[1152921514436154136] = ???;  //  dest_result_addr=1152921514436154128 |  dest_result_addr=1152921514436154136
            // 0x0298BAE0: ADD x29, sp, #0x10         | X29 = (1152921514436154112 + 16) = 1152921514436154128 (0x1000000249DF5310);
            // 0x0298BAE4: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298BAE8: LDRB w8, [x19, #0xf20]     | W8 = (bool)static_value_037B8F20;       
            // 0x0298BAEC: TBNZ w8, #0, #0x298bb08    | if (static_value_037B8F20 == true) goto label_0;
            // 0x0298BAF0: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x0298BAF4: LDR x8, [x8, #0x740]       | X8 = 0x2B90660;                         
            // 0x0298BAF8: LDR w0, [x8]               | W0 = 0x185C;                            
            // 0x0298BAFC: BL #0x2782188              | X0 = sub_2782188( ?? 0x185C, ????);     
            // 0x0298BB00: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298BB04: STRB w8, [x19, #0xf20]     | static_value_037B8F20 = true;            //  dest_result_addr=58429216
            label_0:
            // 0x0298BB08: ADRP x19, #0x35f2000       | X19 = 56565760 (0x35F2000);             
            // 0x0298BB0C: LDR x19, [x19, #0x3c0]     | X19 = 1152921504884961280;              
            // 0x0298BB10: LDR x0, [x19]              | X0 = typeof(ProtoBuf.Serializers.CharSerializer);
            val_1 = null;
            // 0x0298BB14: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Serializers.CharSerializer.__il2cppRuntimeField_10A;
            // 0x0298BB18: TBZ w8, #0, #0x298bb2c     | if (ProtoBuf.Serializers.CharSerializer.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298BB1C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Serializers.CharSerializer.__il2cppRuntimeField_cctor_finished;
            // 0x0298BB20: CBNZ w8, #0x298bb2c        | if (ProtoBuf.Serializers.CharSerializer.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298BB24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Serializers.CharSerializer), ????);
            // 0x0298BB28: LDR x0, [x19]              | X0 = typeof(ProtoBuf.Serializers.CharSerializer);
            val_1 = null;
            label_2:
            // 0x0298BB2C: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.Serializers.CharSerializer.__il2cppRuntimeField_static_fields;
            // 0x0298BB30: LDR x0, [x8]               | X0 = ProtoBuf.Serializers.CharSerializer.expectedType;
            // 0x0298BB34: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298BB38: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298BB3C: RET                        |  return (System.Type)ProtoBuf.Serializers.CharSerializer.expectedType;
            return ProtoBuf.Serializers.CharSerializer.expectedType;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298BB40 (43563840), len: 228  VirtAddr: 0x0298BB40 RVA: 0x0298BB40 token: 100689823 methodIndex: 54022 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Write(object value, ProtoBuf.ProtoWriter dest)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0298BB40: STP x22, x21, [sp, #-0x30]! | stack[1152921514436274288] = ???;  stack[1152921514436274296] = ???;  //  dest_result_addr=1152921514436274288 |  dest_result_addr=1152921514436274296
            // 0x0298BB44: STP x20, x19, [sp, #0x10]  | stack[1152921514436274304] = ???;  stack[1152921514436274312] = ???;  //  dest_result_addr=1152921514436274304 |  dest_result_addr=1152921514436274312
            // 0x0298BB48: STP x29, x30, [sp, #0x20]  | stack[1152921514436274320] = ???;  stack[1152921514436274328] = ???;  //  dest_result_addr=1152921514436274320 |  dest_result_addr=1152921514436274328
            // 0x0298BB4C: ADD x29, sp, #0x20         | X29 = (1152921514436274288 + 32) = 1152921514436274320 (0x1000000249E12890);
            // 0x0298BB50: SUB sp, sp, #0x10          | SP = (1152921514436274288 - 16) = 1152921514436274272 (0x1000000249E12860);
            // 0x0298BB54: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x0298BB58: LDRB w8, [x21, #0xf21]     | W8 = (bool)static_value_037B8F21;       
            // 0x0298BB5C: MOV x19, x2                | X19 = dest;//m1                         
            // 0x0298BB60: MOV x20, x1                | X20 = value;//m1                        
            // 0x0298BB64: TBNZ w8, #0, #0x298bb80    | if (static_value_037B8F21 == true) goto label_0;
            // 0x0298BB68: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x0298BB6C: LDR x8, [x8, #0x418]       | X8 = 0x2B90668;                         
            // 0x0298BB70: LDR w0, [x8]               | W0 = 0x185E;                            
            // 0x0298BB74: BL #0x2782188              | X0 = sub_2782188( ?? 0x185E, ????);     
            // 0x0298BB78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298BB7C: STRB w8, [x21, #0xf21]     | static_value_037B8F21 = true;            //  dest_result_addr=58429217
            label_0:
            // 0x0298BB80: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x0298BB84: LDR x8, [x8, #0x778]       | X8 = 1152921504884428800;               
            // 0x0298BB88: LDR x0, [x8]               | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x0298BB8C: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x0298BB90: TBZ w8, #0, #0x298bba0     | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298BB94: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x0298BB98: CBNZ w8, #0x298bba0        | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298BB9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_2:
            // 0x0298BBA0: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0298BBA4: LDR x8, [x8, #0x6e8]       | X8 = 1152921504608231424;               
            // 0x0298BBA8: LDR x21, [x8]              | X21 = typeof(System.Char);              
            // 0x0298BBAC: CBNZ x20, #0x298bbb4       | if (value != null) goto label_3;        
            if(value != null)
            {
                goto label_3;
            }
            // 0x0298BBB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_3:
            // 0x0298BBB4: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0298BBB8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298BBBC: LDR x8, [x21, #0x30]       | X8 = System.Char.__il2cppRuntimeField_element_class;
            // 0x0298BBC0: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Char.__il2cppRuntimeField_element_class)
            // 0x0298BBC4: B.NE #0x298bbec            | if (System.Object.__il2cppRuntimeField_element_class != System.Char.__il2cppRuntimeField_element_class) goto label_4;
            // 0x0298BBC8: MOV x0, x20                | X0 = value;//m1                         
            // 0x0298BBCC: BL #0x27bc4e8              | value.System.IDisposable.Dispose();     
            value.System.IDisposable.Dispose();
            // 0x0298BBD0: LDRH w1, [x0]              | W1 = typeof(System.Object);             
            // 0x0298BBD4: MOV x2, x19                | X2 = dest;//m1                          
            // 0x0298BBD8: SUB sp, x29, #0x20         | SP = (1152921514436274320 - 32) = 1152921514436274288 (0x1000000249E12870);
            // 0x0298BBDC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0298BBE0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0298BBE4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0298BBE8: B #0x2978bc0               | ProtoBuf.ProtoWriter.WriteUInt16(value:  value, writer:  null); return;
            ProtoBuf.ProtoWriter.WriteUInt16(value:  value, writer:  null);
            return;
            label_4:
            // 0x0298BBEC: ADD x8, sp, #8             | X8 = (1152921514436274272 + 8) = 1152921514436274280 (0x1000000249E12868);
            // 0x0298BBF0: MOV x1, x21                | X1 = 1152921504608231424 (0x1000000000152000);//ML01
            // 0x0298BBF4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298BBF8: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921514436262336]
            // 0x0298BBFC: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x0298BC00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298BC04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x0298BC08: ADD x0, sp, #8             | X0 = (1152921514436274272 + 8) = 1152921514436274280 (0x1000000249E12868);
            // 0x0298BC0C: BL #0x299a140              | 
            // 0x0298BC10: MOV x19, x0                | X19 = 1152921514436274280 (0x1000000249E12868);//ML01
            // 0x0298BC14: ADD x0, sp, #8             | X0 = (1152921514436274272 + 8) = 1152921514436274280 (0x1000000249E12868);
            // 0x0298BC18: BL #0x299a140              | 
            // 0x0298BC1C: MOV x0, x19                | X0 = 1152921514436274280 (0x1000000249E12868);//ML01
            // 0x0298BC20: BL #0x980800               | X0 = sub_980800( ?? 0x1000000249E12868, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x0298BC24 (43564068), len: 116  VirtAddr: 0x0298BC24 RVA: 0x0298BC24 token: 100689824 methodIndex: 54023 delegateWrapperIndex: 0 methodInvoker: 0
        public override object Read(object value, ProtoBuf.ProtoReader source)
        {
            //
            // Disasemble & Code
            // 0x0298BC24: STP x20, x19, [sp, #-0x20]! | stack[1152921514436406784] = ???;  stack[1152921514436406792] = ???;  //  dest_result_addr=1152921514436406784 |  dest_result_addr=1152921514436406792
            // 0x0298BC28: STP x29, x30, [sp, #0x10]  | stack[1152921514436406800] = ???;  stack[1152921514436406808] = ???;  //  dest_result_addr=1152921514436406800 |  dest_result_addr=1152921514436406808
            // 0x0298BC2C: ADD x29, sp, #0x10         | X29 = (1152921514436406784 + 16) = 1152921514436406800 (0x1000000249E32E10);
            // 0x0298BC30: SUB sp, sp, #0x10          | SP = (1152921514436406784 - 16) = 1152921514436406768 (0x1000000249E32DF0);
            // 0x0298BC34: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x0298BC38: LDRB w8, [x20, #0xf22]     | W8 = (bool)static_value_037B8F22;       
            // 0x0298BC3C: MOV x19, x2                | X19 = source;//m1                       
            // 0x0298BC40: TBNZ w8, #0, #0x298bc5c    | if (static_value_037B8F22 == true) goto label_0;
            // 0x0298BC44: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x0298BC48: LDR x8, [x8, #0x4f8]       | X8 = 0x2B90664;                         
            // 0x0298BC4C: LDR w0, [x8]               | W0 = 0x185D;                            
            // 0x0298BC50: BL #0x2782188              | X0 = sub_2782188( ?? 0x185D, ????);     
            // 0x0298BC54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298BC58: STRB w8, [x20, #0xf22]     | static_value_037B8F22 = true;            //  dest_result_addr=58429218
            label_0:
            // 0x0298BC5C: CBNZ x19, #0x298bc64       | if (source != null) goto label_1;       
            if(source != null)
            {
                goto label_1;
            }
            // 0x0298BC60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x185D, ????);     
            label_1:
            // 0x0298BC64: MOV x0, x19                | X0 = source;//m1                        
            // 0x0298BC68: BL #0x297ea74              | X0 = source.ReadUInt16();               
            ushort val_1 = source.ReadUInt16();
            // 0x0298BC6C: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0298BC70: LDR x8, [x8, #0x6e8]       | X8 = 1152921504608231424;               
            // 0x0298BC74: STRH w0, [sp, #0xe]        | stack[1152921514436406782] = val_1;      //  dest_result_addr=1152921514436406782
            // 0x0298BC78: ADD x1, sp, #0xe           | X1 = (1152921514436406768 + 14) = 1152921514436406782 (0x1000000249E32DFE);
            // 0x0298BC7C: LDR x8, [x8]               | X8 = typeof(System.Char);               
            // 0x0298BC80: MOV x0, x8                 | X0 = 1152921504608231424 (0x1000000000152000);//ML01
            // 0x0298BC84: BL #0x27bc028              | X0 = 1152921514436459008 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Char), val_1);
            // 0x0298BC88: SUB sp, x29, #0x10         | SP = (1152921514436406800 - 16) = 1152921514436406784 (0x1000000249E32E00);
            // 0x0298BC8C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298BC90: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298BC94: RET                        |  return (System.Object)val_1;           
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298BC98 (43564184), len: 140  VirtAddr: 0x0298BC98 RVA: 0x0298BC98 token: 100689825 methodIndex: 54024 delegateWrapperIndex: 0 methodInvoker: 0
        private static CharSerializer()
        {
            //
            // Disasemble & Code
            // 0x0298BC98: STP x20, x19, [sp, #-0x20]! | stack[1152921514436535168] = ???;  stack[1152921514436535176] = ???;  //  dest_result_addr=1152921514436535168 |  dest_result_addr=1152921514436535176
            // 0x0298BC9C: STP x29, x30, [sp, #0x10]  | stack[1152921514436535184] = ???;  stack[1152921514436535192] = ???;  //  dest_result_addr=1152921514436535184 |  dest_result_addr=1152921514436535192
            // 0x0298BCA0: ADD x29, sp, #0x10         | X29 = (1152921514436535168 + 16) = 1152921514436535184 (0x1000000249E52390);
            // 0x0298BCA4: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298BCA8: LDRB w8, [x19, #0xf23]     | W8 = (bool)static_value_037B8F23;       
            // 0x0298BCAC: TBNZ w8, #0, #0x298bcc8    | if (static_value_037B8F23 == true) goto label_0;
            // 0x0298BCB0: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x0298BCB4: LDR x8, [x8, #0x858]       | X8 = 0x2B90658;                         
            // 0x0298BCB8: LDR w0, [x8]               | W0 = 0x185A;                            
            // 0x0298BCBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x185A, ????);     
            // 0x0298BCC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298BCC4: STRB w8, [x19, #0xf23]     | static_value_037B8F23 = true;            //  dest_result_addr=58429219
            label_0:
            // 0x0298BCC8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0298BCCC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0298BCD0: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0298BCD4: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x0298BCD8: LDR x8, [x8, #0xcc8]       | X8 = 1152921504608231424;               
            // 0x0298BCDC: LDR x19, [x8]              | X19 = typeof(System.Char);              
            // 0x0298BCE0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0298BCE4: TBZ w8, #0, #0x298bcf4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298BCE8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0298BCEC: CBNZ w8, #0x298bcf4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298BCF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0298BCF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0298BCF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0298BCFC: MOV x1, x19                | X1 = 1152921504608231424 (0x1000000000152000);//ML01
            // 0x0298BD00: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0298BD04: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x0298BD08: LDR x8, [x8, #0x3c0]       | X8 = 1152921504884961280;               
            // 0x0298BD0C: LDR x8, [x8]               | X8 = typeof(ProtoBuf.Serializers.CharSerializer);
            // 0x0298BD10: LDR x8, [x8, #0xa0]        | X8 = ProtoBuf.Serializers.CharSerializer.__il2cppRuntimeField_static_fields;
            // 0x0298BD14: STR x0, [x8]               | ProtoBuf.Serializers.CharSerializer.expectedType = val_1;  //  dest_result_addr=1152921504884965376
            ProtoBuf.Serializers.CharSerializer.expectedType = val_1;
            // 0x0298BD18: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298BD1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298BD20: RET                        |  return;                                
            return;
        
        }
    
    }

}
